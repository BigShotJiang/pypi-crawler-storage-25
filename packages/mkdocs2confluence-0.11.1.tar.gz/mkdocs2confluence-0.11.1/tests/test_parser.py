"""Tests for parser.markdown — Milestone 5.

Coverage:
- headings: levels, anchors, nesting
- paragraphs: single, multi-line, multiple
- fenced code blocks: no attrs, language, full attrs, tilde fences
- section tree structure
- mixed content
- integration against real fixture files
"""

from __future__ import annotations

from pathlib import Path

import pytest

from mkdocs_to_confluence.ir import (
    Admonition,
    CodeBlock,
    IRNode,
    Paragraph,
    Section,
    TextNode,
    walk,
)
from mkdocs_to_confluence.parser import parse
from mkdocs_to_confluence.parser.markdown import _make_anchor, _parse_info_string

# ── Helpers ───────────────────────────────────────────────────────────────────


def only(nodes: tuple[IRNode, ...], kind: type) -> list[IRNode]:
    """Return all nodes of *kind* from a depth-first walk of *nodes*."""
    result = []
    for root in nodes:
        result.extend(n for n in walk(root) if isinstance(n, kind))
    return result


def first(nodes: tuple[IRNode, ...], kind: type) -> IRNode:
    """Return the first node of *kind* found by depth-first walk."""
    found = only(nodes, kind)
    assert found, f"No {kind.__name__} found in tree"
    return found[0]


# ── _make_anchor ─────────────────────────────────────────────────────────────


class TestMakeAnchor:
    def test_simple_lowercase(self) -> None:
        assert _make_anchor("Hello World") == "hello-world"

    def test_already_lowercase(self) -> None:
        assert _make_anchor("hello world") == "hello-world"

    def test_punctuation_stripped(self) -> None:
        assert _make_anchor("Hello, World!") == "hello-world"

    def test_multiple_spaces_collapsed(self) -> None:
        assert _make_anchor("Hello   World") == "hello-world"

    def test_leading_trailing_stripped(self) -> None:
        assert _make_anchor("  Hello  ") == "hello"

    def test_special_chars_removed(self) -> None:
        assert _make_anchor("C++ Guide") == "c-guide"

    def test_hyphen_preserved(self) -> None:
        assert _make_anchor("Step-by-step Guide") == "step-by-step-guide"

    def test_numbers_preserved(self) -> None:
        assert _make_anchor("Section 1.2") == "section-12"

    def test_unicode_letters_preserved(self) -> None:
        # \w matches unicode letters in Python
        result = _make_anchor("Über Guide")
        assert "ber" in result or "über" in result  # platform-dependent unicode


# ── _parse_info_string ────────────────────────────────────────────────────────


class TestParseInfoString:
    def test_empty_string(self) -> None:
        lang, title, linenums, ln_start, hl = _parse_info_string("")
        assert lang is None
        assert title is None
        assert linenums is False
        assert ln_start == 1
        assert hl == ()

    def test_language_only(self) -> None:
        lang, title, linenums, ln_start, hl = _parse_info_string("python")
        assert lang == "python"
        assert title is None
        assert linenums is False

    def test_bash_language(self) -> None:
        lang, *_ = _parse_info_string("bash")
        assert lang == "bash"

    def test_language_with_title(self) -> None:
        lang, title, *_ = _parse_info_string('python title="main.py"')
        assert lang == "python"
        assert title == "main.py"

    def test_linenums_enables_line_numbers(self) -> None:
        _, _, linenums, ln_start, _ = _parse_info_string('python linenums="1"')
        assert linenums is True
        assert ln_start == 1

    def test_linenums_custom_start(self) -> None:
        _, _, linenums, ln_start, _ = _parse_info_string('python linenums="5"')
        assert linenums is True
        assert ln_start == 5

    def test_hl_lines_single(self) -> None:
        _, _, _, _, hl = _parse_info_string('python hl_lines="3"')
        assert hl == (3,)

    def test_hl_lines_multiple(self) -> None:
        _, _, _, _, hl = _parse_info_string('python hl_lines="2 3 5"')
        assert hl == (2, 3, 5)

    def test_full_attrs(self) -> None:
        lang, title, linenums, ln_start, hl = _parse_info_string(
            'python title="example.py" linenums="1" hl_lines="2 3"'
        )
        assert lang == "python"
        assert title == "example.py"
        assert linenums is True
        assert ln_start == 1
        assert hl == (2, 3)

    def test_no_language_with_title(self) -> None:
        lang, title, *_ = _parse_info_string('title="README.md"')
        assert lang is None
        assert title == "README.md"

    def test_single_quotes(self) -> None:
        lang, title, *_ = _parse_info_string("python title='main.py'")
        assert title == "main.py"


# ── Heading parsing ───────────────────────────────────────────────────────────


class TestHeadings:
    def test_h1_creates_section(self) -> None:
        nodes = parse("# Hello\n")
        assert len(nodes) == 1
        assert isinstance(nodes[0], Section)

    def test_h1_level(self) -> None:
        nodes = parse("# Hello\n")
        assert nodes[0].level == 1  # type: ignore[union-attr]

    def test_h2_level(self) -> None:
        nodes = parse("## Hello\n")
        assert nodes[0].level == 2  # type: ignore[union-attr]

    def test_h6_level(self) -> None:
        nodes = parse("###### Deep\n")
        assert nodes[0].level == 6  # type: ignore[union-attr]

    def test_heading_title_text(self) -> None:
        nodes = parse("# My Title\n")
        section = nodes[0]
        assert isinstance(section, Section)
        assert len(section.title) == 1
        assert isinstance(section.title[0], TextNode)
        assert section.title[0].text == "My Title"

    def test_heading_anchor_generated(self) -> None:
        nodes = parse("# My Title\n")
        section = nodes[0]
        assert isinstance(section, Section)
        assert section.anchor == "my-title"

    def test_heading_anchor_with_punctuation(self) -> None:
        nodes = parse("## Hello, World!\n")
        section = nodes[0]
        assert isinstance(section, Section)
        assert section.anchor == "hello-world"

    def test_multiple_top_level_headings(self) -> None:
        nodes = parse("# One\n## Two\n## Three\n")
        # One H1 containing two H2 sections
        assert len(nodes) == 1
        assert isinstance(nodes[0], Section)
        assert nodes[0].level == 1
        assert len(nodes[0].children) == 2

    def test_sibling_h2_headings(self) -> None:
        nodes = parse("# Root\n## A\n## B\n")
        root = nodes[0]
        assert isinstance(root, Section)
        sections = [c for c in root.children if isinstance(c, Section)]
        assert len(sections) == 2
        assert sections[0].title[0].text == "A"
        assert sections[1].title[0].text == "B"

    def test_h3_nested_inside_h2(self) -> None:
        nodes = parse("## Parent\n### Child\n")
        parent = nodes[0]
        assert isinstance(parent, Section)
        assert parent.level == 2
        child = parent.children[0]
        assert isinstance(child, Section)
        assert child.level == 3

    def test_content_before_heading_goes_to_root(self) -> None:
        nodes = parse("Intro text.\n\n# Heading\n")
        assert len(nodes) == 2
        assert isinstance(nodes[0], Paragraph)
        assert isinstance(nodes[1], Section)


# ── Paragraph parsing ─────────────────────────────────────────────────────────


class TestParagraphs:
    def test_single_line_paragraph(self) -> None:
        nodes = parse("Hello world.\n")
        assert len(nodes) == 1
        assert isinstance(nodes[0], Paragraph)

    def test_paragraph_contains_text_node(self) -> None:
        nodes = parse("Hello world.\n")
        para = nodes[0]
        assert isinstance(para, Paragraph)
        assert len(para.children) == 1
        assert isinstance(para.children[0], TextNode)

    def test_paragraph_text_content(self) -> None:
        nodes = parse("Hello world.\n")
        para = nodes[0]
        assert isinstance(para, Paragraph)
        assert para.children[0].text == "Hello world."

    def test_multi_line_paragraph_joined(self) -> None:
        nodes = parse("Line one.\nLine two.\n")
        para = nodes[0]
        assert isinstance(para, Paragraph)
        assert "Line one." in para.children[0].text
        assert "Line two." in para.children[0].text

    def test_blank_line_separates_paragraphs(self) -> None:
        nodes = parse("First.\n\nSecond.\n")
        paras = [n for n in nodes if isinstance(n, Paragraph)]
        assert len(paras) == 2

    def test_multiple_blank_lines_same_as_one(self) -> None:
        nodes = parse("First.\n\n\nSecond.\n")
        paras = [n for n in nodes if isinstance(n, Paragraph)]
        assert len(paras) == 2

    def test_paragraph_inside_section(self) -> None:
        nodes = parse("# Heading\n\nParagraph text.\n")
        section = nodes[0]
        assert isinstance(section, Section)
        assert len(section.children) == 1
        assert isinstance(section.children[0], Paragraph)

    def test_two_paragraphs_inside_section(self) -> None:
        nodes = parse("# Heading\n\nFirst.\n\nSecond.\n")
        section = nodes[0]
        assert isinstance(section, Section)
        paras = [c for c in section.children if isinstance(c, Paragraph)]
        assert len(paras) == 2


# ── Code block parsing ────────────────────────────────────────────────────────


class TestCodeBlocks:
    def test_basic_code_block(self) -> None:
        md = "```\nprint('hi')\n```\n"
        nodes = parse(md)
        assert len(nodes) == 1
        assert isinstance(nodes[0], CodeBlock)

    def test_code_content_preserved(self) -> None:
        md = "```\nhello\nworld\n```\n"
        cb = first(parse(md), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert "hello" in cb.code
        assert "world" in cb.code

    def test_code_block_no_language(self) -> None:
        cb = first(parse("```\ncode\n```\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language is None

    def test_code_block_with_language(self) -> None:
        cb = first(parse("```python\ncode\n```\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language == "python"

    def test_code_block_bash(self) -> None:
        cb = first(parse("```bash\npip install x\n```\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language == "bash"

    def test_code_block_with_title(self) -> None:
        cb = first(parse('```python title="main.py"\ncode\n```\n'), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.title == "main.py"

    def test_code_block_with_linenums(self) -> None:
        cb = first(parse('```python linenums="1"\ncode\n```\n'), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.linenums is True
        assert cb.linenums_start == 1

    def test_code_block_linenums_custom_start(self) -> None:
        cb = first(parse('```python linenums="5"\ncode\n```\n'), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.linenums_start == 5

    def test_code_block_hl_lines(self) -> None:
        cb = first(parse('```python hl_lines="2 3"\nA\nB\nC\n```\n'), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.highlight_lines == (2, 3)

    def test_code_block_full_attrs(self) -> None:
        md = '```python title="ex.py" linenums="1" hl_lines="2 3"\nA\nB\nC\n```\n'
        cb = first(parse(md), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language == "python"
        assert cb.title == "ex.py"
        assert cb.linenums is True
        assert cb.highlight_lines == (2, 3)

    def test_tilde_fence(self) -> None:
        cb = first(parse("~~~python\ncode\n~~~\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language == "python"

    def test_longer_fence_marker(self) -> None:
        cb = first(parse("````python\ncode\n````\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.language == "python"

    def test_code_block_inside_section(self) -> None:
        md = "# Heading\n\n```python\ncode\n```\n"
        nodes = parse(md)
        section = nodes[0]
        assert isinstance(section, Section)
        cb = section.children[0]
        assert isinstance(cb, CodeBlock)

    def test_code_block_multiline_code(self) -> None:
        md = "```python\ndef f():\n    return 1\n\nprint(f())\n```\n"
        cb = first(parse(md), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert "def f():" in cb.code
        assert "return 1" in cb.code
        assert "print(f())" in cb.code

    def test_heading_inside_fence_not_parsed(self) -> None:
        md = "```\n# Not a heading\n```\n"
        nodes = parse(md)
        # Should be one CodeBlock, no Section
        assert len(nodes) == 1
        assert isinstance(nodes[0], CodeBlock)

    def test_code_block_default_values(self) -> None:
        cb = first(parse("```\ncode\n```\n"), CodeBlock)
        assert isinstance(cb, CodeBlock)
        assert cb.linenums is False
        assert cb.linenums_start == 1
        assert cb.highlight_lines == ()
        assert cb.title is None


# ── Section tree structure ────────────────────────────────────────────────────


class TestSectionTree:
    def test_empty_document(self) -> None:
        nodes = parse("")
        assert nodes == ()

    def test_blank_only_document(self) -> None:
        nodes = parse("\n\n\n")
        assert nodes == ()

    def test_single_h1_empty_body(self) -> None:
        nodes = parse("# Title\n")
        assert len(nodes) == 1
        section = nodes[0]
        assert isinstance(section, Section)
        assert section.children == ()

    def test_h1_contains_h2_and_h3(self) -> None:
        md = "# H1\n## H2\n### H3\n"
        nodes = parse(md)
        assert len(nodes) == 1
        h1 = nodes[0]
        assert isinstance(h1, Section)
        assert h1.level == 1
        assert len(h1.children) == 1
        h2 = h1.children[0]
        assert isinstance(h2, Section)
        assert h2.level == 2
        assert len(h2.children) == 1
        h3 = h2.children[0]
        assert isinstance(h3, Section)
        assert h3.level == 3

    def test_two_h1s_produce_two_top_level_sections(self) -> None:
        nodes = parse("# First\n# Second\n")
        assert len(nodes) == 2
        assert all(isinstance(n, Section) and n.level == 1 for n in nodes)

    def test_h2_after_h1_then_another_h2_both_children_of_h1(self) -> None:
        md = "# Root\n## Alpha\n\nContent A.\n## Beta\n\nContent B.\n"
        nodes = parse(md)
        root = nodes[0]
        assert isinstance(root, Section)
        sections = [c for c in root.children if isinstance(c, Section)]
        assert len(sections) == 2
        assert sections[0].title[0].text == "Alpha"
        assert sections[1].title[0].text == "Beta"

    def test_content_before_first_heading_is_in_root(self) -> None:
        md = "Preamble.\n\n# Section\n"
        nodes = parse(md)
        assert len(nodes) == 2
        assert isinstance(nodes[0], Paragraph)
        assert isinstance(nodes[1], Section)

    def test_walk_collects_all_code_blocks(self) -> None:
        md = "# A\n```py\ncode1\n```\n## B\n```js\ncode2\n```\n"
        nodes = parse(md)
        blocks = only(nodes, CodeBlock)
        assert len(blocks) == 2

    def test_walk_collects_all_paragraphs(self) -> None:
        md = "# A\n\nPara 1.\n\n## B\n\nPara 2.\n\nPara 3.\n"
        nodes = parse(md)
        paras = only(nodes, Paragraph)
        assert len(paras) == 3

    def test_section_is_immutable(self) -> None:
        import dataclasses

        nodes = parse("# Hello\n")
        with pytest.raises((dataclasses.FrozenInstanceError, AttributeError)):
            nodes[0].level = 99  # type: ignore[misc]


# ── Admonition parsing ────────────────────────────────────────────────────────


class TestAdmonitions:
    def test_basic_note_is_admonition(self) -> None:
        nodes = parse("!!! note\n    Body text.\n")
        assert len(nodes) == 1
        assert isinstance(nodes[0], Admonition)

    def test_kind_parsed(self) -> None:
        adm = first(parse("!!! warning\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.kind == "warning"

    def test_all_known_kinds(self) -> None:
        kinds = ["note", "tip", "warning", "danger", "info", "success",
                 "failure", "bug", "abstract", "quote", "example"]
        for kind in kinds:
            adm = first(parse(f"!!! {kind}\n    Body.\n"), Admonition)
            assert isinstance(adm, Admonition)
            assert adm.kind == kind

    def test_no_title_gives_none(self) -> None:
        adm = first(parse("!!! note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.title is None

    def test_double_quoted_title(self) -> None:
        adm = first(parse('!!! warning "Be careful"\n    Body.\n'), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.title == "Be careful"

    def test_single_quoted_title(self) -> None:
        adm = first(parse("!!! tip 'Pro tip'\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.title == "Pro tip"

    def test_title_with_single_quotes_inside_double_quoted(self) -> None:
        adm = first(parse("???+ note \"What 'best effort' means (C4)\"\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.title == "What 'best effort' means (C4)"

    def test_title_with_double_quotes_inside_single_quoted(self) -> None:
        adm = first(parse("!!! note 'title with \"double\" quotes'\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.title == 'title with "double" quotes'

    def test_bold_markers_stripped_from_title(self) -> None:
        adm = first(parse('!!! info "**Test**"\n    Body.\n'), Admonition)
        assert adm.title == "Test"

    def test_italic_markers_stripped_from_title(self) -> None:
        adm = first(parse('!!! info "*Test*"\n    Body.\n'), Admonition)
        assert adm.title == "Test"

    def test_mixed_md_stripped_from_title(self) -> None:
        adm = first(parse('!!! info "**Bold** and *italic*"\n    Body.\n'), Admonition)
        assert adm.title == "Bold and italic"


        adm = first(parse("!!! note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.collapsible is False

    def test_question_mark_is_collapsible(self) -> None:
        adm = first(parse("??? note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.collapsible is True

    def test_question_mark_plus_is_collapsible(self) -> None:
        adm = first(parse("???+ note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.collapsible is True

    def test_question_mark_plus_is_expanded(self) -> None:
        adm = first(parse("???+ note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.expanded is True

    def test_question_mark_no_plus_is_not_expanded(self) -> None:
        adm = first(parse("??? note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.expanded is False

    def test_bang_is_not_expanded(self) -> None:
        adm = first(parse("!!! note\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.expanded is False

    def test_body_paragraph_parsed(self) -> None:
        adm = first(parse("!!! note\n    Body text here.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert len(adm.children) == 1
        assert isinstance(adm.children[0], Paragraph)

    def test_body_paragraph_text(self) -> None:
        adm = first(parse("!!! note\n    Hello world.\n"), Admonition)
        assert isinstance(adm, Admonition)
        para = adm.children[0]
        assert isinstance(para, Paragraph)
        assert para.children[0].text == "Hello world."

    def test_body_two_paragraphs(self) -> None:
        md = "!!! note\n    First para.\n\n    Second para.\n"
        adm = first(parse(md), Admonition)
        assert isinstance(adm, Admonition)
        paras = [c for c in adm.children if isinstance(c, Paragraph)]
        assert len(paras) == 2

    def test_body_code_block(self) -> None:
        md = (
            "!!! info\n"
            "    ```python\n"
            "    print('hi')\n"
            "    ```\n"
        )
        adm = first(parse(md), Admonition)
        assert isinstance(adm, Admonition)
        cb = adm.children[0]
        assert isinstance(cb, CodeBlock)
        assert cb.language == "python"

    def test_body_paragraph_then_code_block(self) -> None:
        md = (
            "!!! warning\n"
            "    Read this first.\n"
            "\n"
            "    ```bash\n"
            "    rm -rf /\n"
            "    ```\n"
        )
        adm = first(parse(md), Admonition)
        assert isinstance(adm, Admonition)
        assert len(adm.children) == 2
        assert isinstance(adm.children[0], Paragraph)
        assert isinstance(adm.children[1], CodeBlock)

    def test_empty_body_gives_empty_children(self) -> None:
        adm = first(parse("!!! note\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.children == ()

    def test_admonition_followed_by_paragraph(self) -> None:
        md = "!!! note\n    Body.\n\nFollowing paragraph.\n"
        nodes = parse(md)
        assert len(nodes) == 2
        assert isinstance(nodes[0], Admonition)
        assert isinstance(nodes[1], Paragraph)

    def test_admonition_inside_section(self) -> None:
        md = "# Heading\n\n!!! tip\n    Tip body.\n"
        nodes = parse(md)
        section = nodes[0]
        assert isinstance(section, Section)
        adm = section.children[0]
        assert isinstance(adm, Admonition)

    def test_multiple_admonitions(self) -> None:
        md = "!!! note\n    Note body.\n\n!!! warning\n    Warning body.\n"
        nodes = parse(md)
        assert len(nodes) == 2
        assert all(isinstance(n, Admonition) for n in nodes)
        assert nodes[0].kind == "note"  # type: ignore[union-attr]
        assert nodes[1].kind == "warning"  # type: ignore[union-attr]

    def test_walk_finds_nested_code_in_admonition(self) -> None:
        md = "!!! info\n    ```python\n    pass\n    ```\n"
        nodes = parse(md)
        blocks = only(nodes, CodeBlock)
        assert len(blocks) == 1

    def test_admonition_is_immutable(self) -> None:
        import dataclasses
        adm = first(parse("!!! note\n    Body.\n"), Admonition)
        with pytest.raises((dataclasses.FrozenInstanceError, AttributeError)):
            adm.kind = "warning"  # type: ignore[misc]

    def test_unknown_kind_still_parsed(self) -> None:
        adm = first(parse("!!! mycustomtype\n    Body.\n"), Admonition)
        assert isinstance(adm, Admonition)
        assert adm.kind == "mycustomtype"

    def test_paragraph_before_admonition_not_merged(self) -> None:
        md = "Intro text.\n!!! note\n    Body.\n"
        nodes = parse(md)
        assert len(nodes) == 2
        assert isinstance(nodes[0], Paragraph)
        assert isinstance(nodes[1], Admonition)


# ── Integration: real fixture files ──────────────────────────────────────────


class TestFixtureIntegration:
    def test_headings_fixture(self, docs_dir: Path) -> None:
        text = (docs_dir / "headings.md").read_text(encoding="utf-8")
        nodes = parse(text)
        assert len(nodes) == 1
        root = nodes[0]
        assert isinstance(root, Section)
        assert root.title[0].text == "Main Title"

    def test_headings_fixture_h2_children(self, docs_dir: Path) -> None:
        text = (docs_dir / "headings.md").read_text(encoding="utf-8")
        nodes = parse(text)
        root = nodes[0]
        assert isinstance(root, Section)
        h2s = [c for c in root.children if isinstance(c, Section) and c.level == 2]
        assert len(h2s) == 2
        assert h2s[0].title[0].text == "Section One"
        assert h2s[1].title[0].text == "Section Two"

    def test_headings_fixture_h3_nested(self, docs_dir: Path) -> None:
        text = (docs_dir / "headings.md").read_text(encoding="utf-8")
        nodes = parse(text)
        root = nodes[0]
        assert isinstance(root, Section)
        section_one = next(
            c for c in root.children if isinstance(c, Section) and c.level == 2
        )
        h3s = [c for c in section_one.children if isinstance(c, Section)]
        assert len(h3s) == 2

    def test_mixed_fixture_parses(self, docs_dir: Path) -> None:
        text = (docs_dir / "mixed.md").read_text(encoding="utf-8")
        nodes = parse(text)
        assert len(nodes) > 0

    def test_mixed_fixture_has_code_blocks(self, docs_dir: Path) -> None:
        text = (docs_dir / "mixed.md").read_text(encoding="utf-8")
        nodes = parse(text)
        blocks = only(nodes, CodeBlock)
        assert len(blocks) == 2

    def test_mixed_fixture_bash_block(self, docs_dir: Path) -> None:
        text = (docs_dir / "mixed.md").read_text(encoding="utf-8")
        nodes = parse(text)
        blocks = only(nodes, CodeBlock)
        langs = [b.language for b in blocks if isinstance(b, CodeBlock)]
        assert "bash" in langs

    def test_mixed_fixture_python_block_attrs(self, docs_dir: Path) -> None:
        text = (docs_dir / "mixed.md").read_text(encoding="utf-8")
        nodes = parse(text)
        blocks = only(nodes, CodeBlock)
        py_block = next(
            b for b in blocks if isinstance(b, CodeBlock) and b.language == "python"
        )
        assert py_block.title == "main.py"
        assert py_block.linenums is True
        assert py_block.highlight_lines == (2, 3)

    def test_sample_getting_started(self) -> None:
        path = (
            Path(__file__).parent.parent
            / "samples"
            / "tech-docs"
            / "docs"
            / "getting-started.md"
        )
        text = path.read_text(encoding="utf-8")
        nodes = parse(text)
        # Should have at least one section and at least one code block
        sections = only(nodes, Section)
        blocks = only(nodes, CodeBlock)
        assert len(sections) >= 1
        assert len(blocks) >= 1

    def test_admonitions_fixture(self, docs_dir: Path) -> None:
        text = (docs_dir / "admonitions.md").read_text(encoding="utf-8")
        nodes = parse(text)
        admonitions = only(nodes, Admonition)
        assert len(admonitions) >= 8  # fixture has many admonition types

    def test_admonitions_fixture_has_collapsible(self, docs_dir: Path) -> None:
        text = (docs_dir / "admonitions.md").read_text(encoding="utf-8")
        nodes = parse(text)
        admonitions = only(nodes, Admonition)
        collapsible = [a for a in admonitions if isinstance(a, Admonition) and a.collapsible]
        assert len(collapsible) >= 1

    def test_admonitions_fixture_nested_code_block(self, docs_dir: Path) -> None:
        text = (docs_dir / "admonitions.md").read_text(encoding="utf-8")
        nodes = parse(text)
        # The info admonition contains a fenced code block inside
        info_adm = next(
            a for a in only(nodes, Admonition)
            if isinstance(a, Admonition) and a.kind == "info"
        )
        nested_blocks = [c for c in info_adm.children if isinstance(c, CodeBlock)]
        assert len(nested_blocks) == 1
        assert nested_blocks[0].language == "python"

    def test_sample_getting_started_has_admonition(self) -> None:
        path = (
            Path(__file__).parent.parent
            / "samples"
            / "tech-docs"
            / "docs"
            / "getting-started.md"
        )
        text = path.read_text(encoding="utf-8")
        nodes = parse(text)
        admonitions = only(nodes, Admonition)
        assert len(admonitions) >= 1


# ── Inline parsing ────────────────────────────────────────────────────────────


from mkdocs_to_confluence.ir import (  # noqa: E402
    BlockQuote,
    BoldNode,
    BulletList,
    CodeInlineNode,
    DefinitionItem,
    DefinitionList,
    HorizontalRule,
    ImageNode,
    InsertNode,
    ItalicNode,
    LinkNode,
    OrderedList,
    StrikethroughNode,
    SubscriptNode,
    SuperscriptNode,
    Table,
)


class TestInlineParsing:
    def test_plain_text_becomes_text_node(self) -> None:
        para = first(parse("Hello world.\n"), Paragraph)
        assert isinstance(para, Paragraph)
        assert isinstance(para.children[0], TextNode)
        assert para.children[0].text == "Hello world."

    def test_bold_star(self) -> None:
        para = first(parse("Hello **world**.\n"), Paragraph)
        assert isinstance(para, Paragraph)
        bold = next(n for n in para.children if isinstance(n, BoldNode))
        assert isinstance(bold.children[0], TextNode)
        assert bold.children[0].text == "world"

    def test_italic_star(self) -> None:
        para = first(parse("Hello *world*.\n"), Paragraph)
        assert isinstance(para, Paragraph)
        italic = next(n for n in para.children if isinstance(n, ItalicNode))
        assert italic.children[0].text == "world"  # type: ignore[union-attr]

    def test_strikethrough(self) -> None:
        para = first(parse("Hello ~~old~~ text.\n"), Paragraph)
        assert isinstance(para, Paragraph)
        strike = next(n for n in para.children if isinstance(n, StrikethroughNode))
        assert strike.children[0].text == "old"  # type: ignore[union-attr]

    def test_subscript(self) -> None:
        para = first(parse("H~2~O\n"), Paragraph)
        assert isinstance(para, Paragraph)
        sub = next(n for n in para.children if isinstance(n, SubscriptNode))
        assert sub.children[0].text == "2"  # type: ignore[union-attr]

    def test_superscript(self) -> None:
        para = first(parse("x^2^\n"), Paragraph)
        assert isinstance(para, Paragraph)
        sup = next(n for n in para.children if isinstance(n, SuperscriptNode))
        assert sup.children[0].text == "2"  # type: ignore[union-attr]

    def test_insert_underline(self) -> None:
        para = first(parse("^^inserted^^\n"), Paragraph)
        assert isinstance(para, Paragraph)
        ins = next(n for n in para.children if isinstance(n, InsertNode))
        assert ins.children[0].text == "inserted"  # type: ignore[union-attr]

    def test_insert_does_not_consume_superscript(self) -> None:
        """^^text^^ should produce InsertNode, not two SuperscriptNodes."""
        para = first(parse("^^hello^^\n"), Paragraph)
        nodes = [n for n in para.children if isinstance(n, InsertNode)]
        sup_nodes = [n for n in para.children if isinstance(n, SuperscriptNode)]
        assert len(nodes) == 1
        assert len(sup_nodes) == 0

    def test_bare_url_autolink(self) -> None:
        para = first(parse("See https://example.com for details.\n"), Paragraph)
        link = next(n for n in para.children if isinstance(n, LinkNode))
        assert link.href == "https://example.com"
        assert link.children[0].text == "https://example.com"  # type: ignore[union-attr]

    def test_bare_url_http(self) -> None:
        para = first(parse("Visit http://example.com today.\n"), Paragraph)
        link = next(n for n in para.children if isinstance(n, LinkNode))
        assert link.href == "http://example.com"

    def test_trailing_backslash_hard_break(self) -> None:
        from mkdocs_to_confluence.ir import LineBreakNode
        nodes = parse("Line one\\\nLine two\n")
        para = first(nodes, Paragraph)
        assert any(isinstance(n, LineBreakNode) for n in para.children)

    def test_inline_code(self) -> None:
        para = first(parse("Use `foo()` here.\n"), Paragraph)
        assert isinstance(para, Paragraph)
        code = next(n for n in para.children if isinstance(n, CodeInlineNode))
        assert code.code == "foo()"

    def test_link(self) -> None:
        para = first(parse("[Click here](https://example.com)\n"), Paragraph)
        assert isinstance(para, Paragraph)
        link = next(n for n in para.children if isinstance(n, LinkNode))
        assert link.href == "https://example.com"
        assert link.children[0].text == "Click here"  # type: ignore[union-attr]

    def test_heading_bold(self) -> None:
        nodes = parse("# **Bold** heading\n")
        section = nodes[0]
        assert isinstance(section, Section)
        assert any(isinstance(n, BoldNode) for n in section.title)

    def test_image_attr_block_stripped(self) -> None:
        """{ loading=lazy } and similar attribute blocks must not appear as text."""
        para = first(parse("![Alt text](img.png){ loading=lazy }\n"), Paragraph)
        assert isinstance(para, Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.src == "img.png"
        assert img.alt == "Alt text"
        # No stray text nodes containing the attribute block
        text_content = "".join(
            n.text for n in para.children if isinstance(n, TextNode)
        )
        assert "{" not in text_content
        assert "loading" not in text_content

    def test_image_width_attr(self) -> None:
        """{ width="400" } sets ImageNode.width."""
        para = first(parse('![logo](img.png){ width="400" }\n'), Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.width == 400
        assert img.height is None

    def test_image_height_attr(self) -> None:
        """{ height="200" } sets ImageNode.height."""
        para = first(parse('![logo](img.png){ height="200" }\n'), Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.height == 200
        assert img.width is None

    def test_image_width_and_height_attr(self) -> None:
        """Both width and height can be set together."""
        para = first(parse('![logo](img.png){ width="640" height="480" }\n'), Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.width == 640
        assert img.height == 480

    def test_image_align_attr(self) -> None:
        """{ align="center" } sets ImageNode.align."""
        para = first(parse('![logo](img.png){ align="center" }\n'), Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.align == "center"

    def test_image_no_attr_block(self) -> None:
        """Images without attr blocks have None sizing fields."""
        para = first(parse("![logo](img.png)\n"), Paragraph)
        img = next(n for n in para.children if isinstance(n, ImageNode))
        assert img.width is None
        assert img.height is None
        assert img.align is None


# ── List parsing ──────────────────────────────────────────────────────────────


class TestListParsing:
    def test_bullet_list_nodes(self) -> None:
        nodes = parse("- Alpha\n- Beta\n- Gamma\n")
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        assert len(bl.items) == 3

    def test_bullet_item_text(self) -> None:
        nodes = parse("- Hello world\n")
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        assert bl.items[0].children[0].text == "Hello world"  # type: ignore[union-attr]

    def test_bullet_item_with_link(self) -> None:
        nodes = parse("- [Docs](docs.md)\n")
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        link = next(
            n for n in bl.items[0].children if isinstance(n, LinkNode)
        )
        assert link.href == "docs.md"

    def test_task_list_checked(self) -> None:
        nodes = parse("- [x] Done item\n")
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        assert bl.items[0].task is True

    def test_task_list_unchecked(self) -> None:
        nodes = parse("- [ ] Todo item\n")
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        assert bl.items[0].task is False

    def test_ordered_list(self) -> None:
        nodes = parse("1. First\n2. Second\n3. Third\n")
        ol = first(nodes, OrderedList)
        assert isinstance(ol, OrderedList)
        assert len(ol.items) == 3
        assert ol.start == 1

    def test_ordered_list_custom_start(self) -> None:
        nodes = parse("5. Fifth\n6. Sixth\n")
        ol = first(nodes, OrderedList)
        assert isinstance(ol, OrderedList)
        assert ol.start == 5

    def test_loose_ordered_list_is_single_node(self) -> None:
        """Blank lines between items (loose list) must not split into multiple OLs."""
        nodes = parse("1. First\n\n1. Second\n\n1. Third\n")
        ols = only(nodes, OrderedList)
        assert len(ols) == 1, "loose ordered list must produce exactly one OrderedList"
        assert len(ols[0].items) == 3

    def test_loose_bullet_list_is_single_node(self) -> None:
        """Blank lines between items (loose list) must not split into multiple ULs."""
        nodes = parse("- Apple\n\n- Banana\n\n- Cherry\n")
        uls = only(nodes, BulletList)
        assert len(uls) == 1, "loose bullet list must produce exactly one BulletList"
        assert len(uls[0].items) == 3

    def test_loose_ordered_list_in_admonition(self) -> None:
        """Loose ordered list inside an admonition must stay as one OrderedList."""
        md = "!!! note\n    1. First\n\n    1. Second\n\n    1. Third\n"
        nodes = parse(md)
        adm = first(nodes, Admonition)
        assert adm is not None
        ols = only(adm.children, OrderedList)
        assert len(ols) == 1, "loose ordered list in admonition must be a single OrderedList"
        assert len(ols[0].items) == 3

    def test_ordered_list_with_continuation_text_in_admonition(self) -> None:
        """Items with hard-break + continuation paragraph must stay as one OrderedList."""
        md = (
            "!!! note \"Takeaways\"\n"
            "\n"
            "    1. **First point.**\n"
            "       Continuation of first.\n"
            "\n"
            "    1. **Second point.**\n"
            "       Continuation of second.\n"
            "\n"
            "    1. **Third point.**\n"
            "       Continuation of third.\n"
        )
        nodes = parse(md)
        adm = first(nodes, Admonition)
        assert adm is not None
        ols = only(adm.children, OrderedList)
        assert len(ols) == 1, "continuation text must not split the ordered list"
        assert len(ols[0].items) == 3
        # Continuation text should be joined into the item
        item_text = "".join(
            getattr(c, "text", "") for c in ols[0].items[0].children
        )
        assert "Continuation" in item_text or "First point" in item_text

    def test_nested_bullet_list(self) -> None:
        md = "- item 1\n  - nested 1\n  - nested 2\n- item 2\n"
        nodes = parse(md)
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        assert len(bl.items) == 2
        # First item must have a nested BulletList as a child.
        nested = next((c for c in bl.items[0].children if isinstance(c, BulletList)), None)
        assert nested is not None, "expected nested BulletList in first item"
        assert len(nested.items) == 2
        assert nested.items[0].children[0].text == "nested 1"  # type: ignore[union-attr]
        assert nested.items[1].children[0].text == "nested 2"  # type: ignore[union-attr]

    def test_nested_ordered_list(self) -> None:
        md = "1. first\n   1. sub one\n   2. sub two\n2. second\n"
        nodes = parse(md)
        ol = first(nodes, OrderedList)
        assert isinstance(ol, OrderedList)
        nested = next((c for c in ol.items[0].children if isinstance(c, OrderedList)), None)
        assert nested is not None, "expected nested OrderedList in first item"
        assert len(nested.items) == 2

    def test_deeply_nested_bullet_list(self) -> None:
        md = "- a\n  - b\n    - c\n"
        nodes = parse(md)
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        level2 = next((c for c in bl.items[0].children if isinstance(c, BulletList)), None)
        assert level2 is not None
        level3 = next((c for c in level2.items[0].children if isinstance(c, BulletList)), None)
        assert level3 is not None
        assert level3.items[0].children[0].text == "c"  # type: ignore[union-attr]

    def test_mixed_nested_list(self) -> None:
        """Bullet list item containing an ordered sub-list."""
        md = "- item\n  1. sub one\n  2. sub two\n"
        nodes = parse(md)
        bl = first(nodes, BulletList)
        assert isinstance(bl, BulletList)
        nested_ol = next((c for c in bl.items[0].children if isinstance(c, OrderedList)), None)
        assert nested_ol is not None
        assert len(nested_ol.items) == 2


# ── Definition list parsing ───────────────────────────────────────────────────


class TestDefinitionListParsing:
    def test_basic_definition_list(self) -> None:
        md = "Apple\n:   A fruit\n"
        dl = first(parse(md), DefinitionList)
        assert isinstance(dl, DefinitionList)
        assert len(dl.items) == 1
        item = dl.items[0]
        assert isinstance(item, DefinitionItem)
        assert item.term[0].text == "Apple"  # type: ignore[union-attr]
        assert item.definitions[0][0].text == "A fruit"  # type: ignore[union-attr]

    def test_multiple_definitions_per_term(self) -> None:
        md = "Color\n:   Red\n:   Blue\n"
        dl = first(parse(md), DefinitionList)
        assert isinstance(dl, DefinitionList)
        assert len(dl.items[0].definitions) == 2

    def test_multiple_terms(self) -> None:
        md = "Cat\n:   A feline\n\nDog\n:   A canine\n"
        nodes = parse(md)
        dls = [n for n in nodes if isinstance(n, DefinitionList)]
        assert len(dls) == 2

    def test_definition_list_inline_term(self) -> None:
        md = "**Bold** term\n:   Description\n"
        dl = first(parse(md), DefinitionList)
        assert isinstance(dl, DefinitionList)
        from mkdocs_to_confluence.ir.nodes import BoldNode
        assert any(isinstance(n, BoldNode) for n in dl.items[0].term)


# ── Table parsing ─────────────────────────────────────────────────────────────


class TestTableParsing:
    def test_basic_table(self) -> None:
        md = "| A | B |\n|---|---|\n| 1 | 2 |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)

    def test_table_header_cells(self) -> None:
        md = "| Name | Value |\n|------|-------|\n| foo  | bar   |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)
        assert tbl.header.cells[0].children[0].text == "Name"  # type: ignore[union-attr]
        assert tbl.header.cells[1].children[0].text == "Value"  # type: ignore[union-attr]

    def test_table_body_rows(self) -> None:
        md = "| A | B |\n|---|---|\n| x | y |\n| p | q |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)
        assert len(tbl.rows) == 2

    def test_table_header_is_th(self) -> None:
        md = "| H1 | H2 |\n|----|----|\n| v1 | v2 |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)
        assert all(c.is_header for c in tbl.header.cells)

    def test_table_right_align(self) -> None:
        md = "| Num |\n| ---: |\n| 42 |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)
        assert tbl.rows[0].cells[0].align == "right"

    def test_table_center_align(self) -> None:
        md = "| X |\n| :---: |\n| v |\n"
        tbl = first(parse(md), Table)
        assert isinstance(tbl, Table)
        assert tbl.rows[0].cells[0].align == "center"


# ── Blockquote and HR parsing ─────────────────────────────────────────────────


class TestBlockquoteAndHR:
    def test_blockquote(self) -> None:
        nodes = parse("> Hello\n")
        bq = first(nodes, BlockQuote)
        assert isinstance(bq, BlockQuote)

    def test_blockquote_inline(self) -> None:
        nodes = parse("> **Bold** text\n")
        bq = first(nodes, BlockQuote)
        assert isinstance(bq, BlockQuote)
        para = first(bq.children, Paragraph)
        assert isinstance(para, Paragraph)
        assert any(isinstance(n, BoldNode) for n in para.children)

    def test_horizontal_rule_dashes(self) -> None:
        nodes = parse("---\n")
        assert any(isinstance(n, HorizontalRule) for n in nodes)

    def test_horizontal_rule_stars(self) -> None:
        nodes = parse("***\n")
        assert any(isinstance(n, HorizontalRule) for n in nodes)

    def test_hr_does_not_break_surrounding_paragraphs(self) -> None:
        nodes = parse("Before.\n\n---\n\nAfter.\n")
        paras = only(nodes, Paragraph)
        assert len(paras) == 2


class TestFootnotes:
    def test_footnote_ref_produces_FootnoteRef_node(self) -> None:
        from mkdocs_to_confluence.ir import FootnoteRef
        nodes = parse("Text[^1] more.\n\n[^1]: Definition.\n")
        paras = [n for n in nodes if isinstance(n, Paragraph)]
        assert paras, "expected at least one paragraph"
        refs = [c for c in paras[0].children if isinstance(c, FootnoteRef)]
        assert len(refs) == 1
        assert refs[0].label == "1"
        assert refs[0].number == 1

    def test_footnote_def_produces_FootnoteBlock(self) -> None:
        from mkdocs_to_confluence.ir import FootnoteBlock
        nodes = parse("Text[^note].\n\n[^note]: The definition.\n")
        blocks = [n for n in nodes if isinstance(n, FootnoteBlock)]
        assert len(blocks) == 1
        assert len(blocks[0].items) == 1
        assert blocks[0].items[0].label == "note"

    def test_footnote_numbers_by_definition_order(self) -> None:
        from mkdocs_to_confluence.ir import FootnoteRef
        md = "Ref B[^b] and Ref A[^a].\n\n[^a]: First defined.\n[^b]: Second defined.\n"
        nodes = parse(md)
        paras = [n for n in nodes if isinstance(n, Paragraph)]
        refs = {c.label: c.number for para in paras for c in para.children if isinstance(c, FootnoteRef)}
        assert refs["a"] == 1, "^a defined first → number 1"
        assert refs["b"] == 2, "^b defined second → number 2"

    def test_multiple_footnotes_in_block(self) -> None:
        from mkdocs_to_confluence.ir import FootnoteBlock
        md = "A[^x]. B[^y].\n\n[^x]: Def X.\n[^y]: Def Y.\n"
        nodes = parse(md)
        blocks = [n for n in nodes if isinstance(n, FootnoteBlock)]
        assert len(blocks) == 1
        labels = [fn.label for fn in blocks[0].items]
        assert "x" in labels
        assert "y" in labels


# ── Inline HTML passthrough ───────────────────────────────────────────────────


class TestInlineHtmlParsing:
    def test_br_produces_line_break_node(self) -> None:
        from mkdocs_to_confluence.ir import LineBreakNode
        para = first(parse("Line one<br>Line two\n"), Paragraph)
        assert any(isinstance(n, LineBreakNode) for n in para.children)

    def test_br_self_closing_variants(self) -> None:
        from mkdocs_to_confluence.ir import LineBreakNode
        for variant in ("Line<br/>end", "Line<br />end", "Line<BR>end"):
            para = first(parse(f"{variant}\n"), Paragraph)
            assert any(isinstance(n, LineBreakNode) for n in para.children), variant

    def test_mark_produces_inline_html_node(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        para = first(parse("Text <mark>highlight</mark> end\n"), Paragraph)
        node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
        assert node.tag == "mark"
        assert node.children[0].text == "highlight"  # type: ignore[union-attr]

    def test_kbd_produces_inline_html_node(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        para = first(parse("Press <kbd>Ctrl+C</kbd> to copy\n"), Paragraph)
        node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
        assert node.tag == "kbd"
        assert node.children[0].text == "Ctrl+C"  # type: ignore[union-attr]

    def test_sub_sup_u_small(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        for tag in ("sub", "sup", "u", "small"):
            para = first(parse(f"Text <{tag}>x</{tag}> end\n"), Paragraph)
            node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
            assert node.tag == tag

    def test_s_del_normalised_to_s(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        for src_tag in ("s", "del"):
            para = first(parse(f"Text <{src_tag}>old</{src_tag}> end\n"), Paragraph)
            node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
            assert node.tag == "s", f"<{src_tag}> should normalise to 's'"

    def test_unclosed_tag_falls_through_as_text(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode, TextNode
        para = first(parse("Text <mark>no close\n"), Paragraph)
        # No InlineHtmlNode — the tag text is emitted as raw characters
        assert not any(isinstance(n, InlineHtmlNode) for n in para.children)
        raw = "".join(n.text for n in para.children if isinstance(n, TextNode))
        assert "<mark>" in raw

    def test_span_with_class_produces_raw_inline_html(self) -> None:
        from mkdocs_to_confluence.ir import RawInlineHtml
        para = first(parse('Text <span class="crit-level">C0</span> end\n'), Paragraph)
        node = next(n for n in para.children if isinstance(n, RawInlineHtml))
        assert node.html_str == '<span class="crit-level">C0</span>'

    def test_span_without_attrs_not_treated_as_raw(self) -> None:
        # Plain <span> (no attributes) is not in the known-tag list either,
        # so it falls through to generic handler.
        from mkdocs_to_confluence.ir import RawInlineHtml
        para = first(parse("<span>plain</span>\n"), Paragraph)
        assert any(isinstance(n, RawInlineHtml) for n in para.children)

    def test_raw_inline_html_emitted_verbatim(self) -> None:
        from mkdocs_to_confluence.emitter.xhtml import emit
        nodes = parse('| Col |\n|-----|\n| <span class="hl">X</span> |\n')
        xhtml = emit(nodes)
        assert '<span class="hl">X</span>' in xhtml


class TestKeyboardKeys:
    def test_single_key(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        para = first(parse("Press ++ctrl++\n"), Paragraph)
        node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
        assert node.tag == "kbd"
        assert node.children[0].text == "Ctrl"  # type: ignore[union-attr]

    def test_combined_keys(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode, TextNode
        para = first(parse("Press ++ctrl+alt+del++\n"), Paragraph)
        kbd_nodes = [n for n in para.children if isinstance(n, InlineHtmlNode)]
        sep_nodes = [n for n in para.children if isinstance(n, TextNode) and n.text == "+"]
        assert len(kbd_nodes) == 3
        assert len(sep_nodes) == 2
        assert kbd_nodes[0].children[0].text == "Ctrl"  # type: ignore[union-attr]
        assert kbd_nodes[1].children[0].text == "Alt"   # type: ignore[union-attr]
        assert kbd_nodes[2].children[0].text == "Del"   # type: ignore[union-attr]

    def test_known_key_names_normalised(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        cases = [
            ("++enter++", "Enter"),
            ("++esc++", "Esc"),
            ("++shift++", "Shift"),
            ("++cmd++", "⌘"),
            ("++tab++", "Tab"),
            ("++up++", "↑"),
            ("++page-up++", "PgUp"),
        ]
        for src, expected in cases:
            para = first(parse(f"{src}\n"), Paragraph)
            node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
            assert node.children[0].text == expected, f"{src} → {node.children[0].text!r}"  # type: ignore[union-attr]

    def test_unknown_key_falls_back_to_title_case(self) -> None:
        from mkdocs_to_confluence.ir import InlineHtmlNode
        para = first(parse("++mykey++\n"), Paragraph)
        node = next(n for n in para.children if isinstance(n, InlineHtmlNode))
        assert node.children[0].text == "Mykey"  # type: ignore[union-attr]

    def test_double_plus_in_plain_text_not_matched(self) -> None:
        """++ not followed by valid key pattern should pass through as text."""
        para = first(parse("C++ is a language\n"), Paragraph)
        text = "".join(n.text for n in para.children if isinstance(n, TextNode))
        assert "C++" in text


class TestGridCards:
    def test_bullet_list_items_become_cards(self) -> None:
        from mkdocs_to_confluence.ir import GridCards, Paragraph
        md = (
            '<div class="grid cards" markdown>\n'
            "- **Fast** — compiles quickly\n"
            "- **Secure** — no credentials stored\n"
            "</div>\n"
        )
        nodes = parse(md)
        gc = next(n for n in nodes if isinstance(n, GridCards))
        assert len(gc.items) == 2
        assert any(isinstance(n, Paragraph) for n in gc.items[0])
        assert any(isinstance(n, Paragraph) for n in gc.items[1])

    def test_admonition_items_become_cards(self) -> None:
        from mkdocs_to_confluence.ir import Admonition, GridCards
        md = (
            '<div class="grid cards" markdown>\n'
            '\n'
            '!!! tip "Card 1"\n'
            '    First card content\n'
            '\n'
            '!!! info "Card 2"\n'
            '    Second card content\n'
            '\n'
            '</div>\n'
        )
        nodes = parse(md)
        gc = next(n for n in nodes if isinstance(n, GridCards))
        assert len(gc.items) == 2
        assert any(isinstance(n, Admonition) for n in gc.items[0])
        assert any(isinstance(n, Admonition) for n in gc.items[1])

    def test_single_card(self) -> None:
        from mkdocs_to_confluence.ir import GridCards
        md = (
            '<div class="grid cards" markdown>\n'
            "- Only one card\n"
            "</div>\n"
        )
        nodes = parse(md)
        gc = next(n for n in nodes if isinstance(n, GridCards))
        assert len(gc.items) == 1

    def test_three_cards(self) -> None:
        from mkdocs_to_confluence.ir import GridCards
        md = (
            '<div class="grid cards" markdown>\n'
            "- Card A\n"
            "- Card B\n"
            "- Card C\n"
            "</div>\n"
        )
        nodes = parse(md)
        gc = next(n for n in nodes if isinstance(n, GridCards))
        assert len(gc.items) == 3


class TestAnchorNode:
    def test_anchor_id_parsed(self) -> None:
        from mkdocs_to_confluence.ir import AnchorNode
        para = first(parse('Some text <a id="my-anchor"></a> more\n'), Paragraph)
        assert any(isinstance(n, AnchorNode) and n.name == "my-anchor" for n in para.children)

    def test_anchor_name_parsed(self) -> None:
        from mkdocs_to_confluence.ir import AnchorNode
        para = first(parse('Some text <a name="my-anchor"></a> more\n'), Paragraph)
        assert any(isinstance(n, AnchorNode) and n.name == "my-anchor" for n in para.children)

    def test_anchor_self_closing_parsed(self) -> None:
        from mkdocs_to_confluence.ir import AnchorNode
        para = first(parse('Before <a id="target"/> after\n'), Paragraph)
        assert any(isinstance(n, AnchorNode) and n.name == "target" for n in para.children)

    def test_anchor_open_only_parsed(self) -> None:
        from mkdocs_to_confluence.ir import AnchorNode
        para = first(parse('Before <a id="target"> after\n'), Paragraph)
        assert any(isinstance(n, AnchorNode) and n.name == "target" for n in para.children)

    def test_anchor_emitted_as_confluence_macro(self) -> None:
        from mkdocs_to_confluence.emitter.xhtml import emit
        nodes = parse('Go to <a id="section-1"></a> here\n')
        xhtml = emit(nodes)
        assert 'ac:structured-macro ac:name="anchor"' in xhtml
        assert "section-1" in xhtml

    def test_anchor_link_and_target_roundtrip(self) -> None:
        """[Text](#target) link + <a id="target"> definition renders correctly."""
        from mkdocs_to_confluence.emitter.xhtml import emit
        nodes = parse('[Jump](#section-1)\n\n<a id="section-1"></a>\n')
        xhtml = emit(nodes)
        assert 'href="#section-1"' in xhtml
        assert 'ac:structured-macro ac:name="anchor"' in xhtml
        assert "section-1" in xhtml
