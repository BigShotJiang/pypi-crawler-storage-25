"""macOS Android file transfer CLI."""

__all__ = ["__version__"]

__version__ = "0.2.4"
