"""Text-only heading-candidate annotator (Tier 1 fallback / primary for v1.6.1 PDF path)."""

from __future__ import annotations

import re

from ..blocks import BlockHint
from ..taxonomy import HEADING_TO_LABEL, lookup_canonical_label

# Build alternation regex from all canonical heading variants, longest first.
_CANONICAL_VARIANTS = sorted(
    {v for variants in HEADING_TO_LABEL.keys() for v in variants},
    key=len,
    reverse=True,
)
_CANONICAL_ALT = "|".join(re.escape(v) for v in _CANONICAL_VARIANTS)

# Numbering-prefix used by Pass 1a / 1b to peel a leading section number from
# the heading line.  Matches:
#   - Arabic: "1.", "2.3.", "1.4.1."
#   - Roman:  "I.", "II.", "IV." (IEEE / ACM technical papers)
#   - Single capital letter: "A.", "B." (IEEE second-level subsections)
# Anchored by a required trailing space so we don't eat words that just
# happen to begin with capital letters.
_NUM_PREFIX_FRAG = (
    r"(?:"
    r"\d+(?:\.\d+)*\.?"          # 1, 2.3, 1.4.1
    r"|[IVX]+\.?"                 # I, II, IV
    r"|[A-Z]\."                   # A., B., C.
    r")[ \t]+"
)

# Pattern A+B: canonical heading at line start — passes (a) Capital-letter body or
# (b) end-of-line disambiguator.  The preceded-by-blank check (c) is handled in
# annotate_text by inspecting the characters before the match start.
_CANONICAL_PARA_HEADING = re.compile(
    rf"(?im)"
    rf"^[ \t]*"
    rf"(?:{_NUM_PREFIX_FRAG})?"
    rf"(?P<heading>{_CANONICAL_ALT})"
    rf"\b",
)

# Pattern C: canonical heading preceded by a newline (single or blank line).
# Catches headings whose body starts with a lowercase word (e.g.
# "Keywords emotional pluralistic...") — these would fail the Capital-body
# disambiguator in Pattern A+B alone, AND fail the blank-line predecessor
# check when the gap is only one newline (common in PSPB-style PDFs where
# Keywords immediately follows the last sentence of the abstract).
# The Title-Case / ALL-CAPS post-filter prevents body-text false positives.
_CANONICAL_AFTER_BLANK = re.compile(
    rf"(?im)"
    rf"\n[ \t]*(?:\n[ \t]*)?"
    rf"(?:{_NUM_PREFIX_FRAG})?"
    rf"(?P<heading>{_CANONICAL_ALT})"
    rf"\b",
)

# Existing line-isolated heading pattern (kept for non-canonical / subheading capture).
_HEADING_LINE = re.compile(
    r"""(?xm)
    ^
    [ \t]*
    (?:\#{1,6}[ \t]+)?
    (?:\d+(?:\.\d+)*\.?[ \t]+)?
    (?P<heading>
        # v2.4.24 (cycle 9): extended character classes to admit digits
        # and colons. Catches AOM-style subsection labels like
        # "STUDY 1: QUASI-FIELD EXPERIMENT" / "STUDY 2: LABORATORY
        # EXPERIMENT" / "OVERVIEW OF THE STUDIES" that v2.4.23 left as
        # inline bold lines. Real headings can contain digits (study
        # numbers, table numbers) and colons (label:descriptor).
        [A-Z][A-Za-z0-9 &\-/:,]{0,80}
        |
        [A-Z][A-Z0-9 &\-/:,]{0,80}
        |
        (?:[A-Z][ \t]){2,30}[A-Z]
    )
    [ \t]*[:.]?[ \t]*
    $
    """,
)

_UNDERLINED_HEADING = re.compile(
    r"""(?xm)
    ^[ \t]*(?P<heading>[A-Z][A-Za-z &\-/]{0,80})[ \t]*\n
    [ \t]*[-=]{2,}[ \t]*$
    """,
)

# Case-sensitive match for a Capital letter immediately after whitespace.
# Used in Pass 1 to detect "Heading CapitalBodyWord" pattern.
_CAPITAL_WORD_AFTER = re.compile(r"[ \t]+[A-Z]")
# Matches end-of-line after the heading (optional trailing colon/period/space).
_END_OF_LINE = re.compile(r"[ \t]*[:.]?[ \t]*(?:\n|$)")
# v2.4.18 (SECTIONING fix): a heading followed by a lowercase word on the
# same line is body prose, not a heading. Canonical example: "Results from
# our study have implications…" — the word "Results" matches the canonical
# heading list but the following lowercase "from" reveals it's the first
# word of a body sentence.
_LOWERCASE_WORD_AFTER = re.compile(r"[ \t]+[a-z]")

# v2.4.18: function-word check distinguishes body prose ("Results from our
# study…") from keyword-list headings ("Keywords emotional pluralistic
# ignorance…"). Body sentences use English function words (from/of/the/
# in/with/to/by/for/on/at/and/are/is/was/were/has/had/have/that/this/which).
# Keyword lists don't. A heading whose trailing content starts with a
# function word is body prose — even if the canonical heading word matches.
_FUNCTION_WORD_AFTER = re.compile(
    r"[ \t]+(?:"
    # Prepositions / articles / conjunctions
    r"from|of|the|in|with|to|by|for|on|at|and|or|but|nor|so|yet|"
    r"a|an|into|onto|about|after|before|between|during|though|although|"
    r"because|while|since|under|over|across|through|via|per|than|then|"
    # Pronouns / determiners
    r"our|their|its|his|her|my|your|these|those|this|that|which|whom|whose|"
    # Auxiliary / linking verbs
    r"are|is|was|were|has|had|have|being|been|be|am|do|does|did|"
    r"will|would|can|could|may|might|shall|should|must|"
    # Common post-"Results"/"Methods" body openers (descriptive verbs)
    r"based|derived|obtained|observed|showed|shown|indicated|suggested|"
    r"demonstrated|found|revealed|reveal|presented|present|presents|"
    r"reported|report|reports|support|supports|supported|"
    r"show|shows|indicate|indicates|suggest|suggests|demonstrate|demonstrates|"
    r"regarding|including|excluding|using|comparing|examining|"
    # Common adverbs at sentence start
    r"however|moreover|furthermore|thus|hence|therefore|consequently|"
    r"additionally|finally|first|second|third|next|"
    # 'as' / 'when' / 'where' starters
    r"as|when|where|whereas|whether|if|unless"
    r")\b",
    # Case-SENSITIVE: only reject when the function word is lowercase
    # ("from", "the", "based"). Capital-letter "The"/"From" starts a body
    # SENTENCE after a heading (e.g. "Funding The author(s) disclosed…")
    # — those are real heading + body pairs, not body-prose openers.
)


def _next_nonblank_line(text: str, after_pos: int) -> str | None:
    """Return the next non-blank line of text starting after `after_pos`,
    or None if no such line exists."""
    i = after_pos
    while i < len(text):
        # Skip blank lines (lines containing only whitespace).
        line_end = text.find("\n", i)
        if line_end < 0:
            line_end = len(text)
        line = text[i:line_end].strip()
        if line:
            return line
        i = line_end + 1
    return None


def _is_fully_isolated_heading(text: str, line_start: int, heading_end: int) -> bool:
    """True if the matched heading word occupies its entire line AND that line
    is preceded by a blank line AND the next non-blank line starts with an
    uppercase letter (i.e. a real paragraph / sentence start).

    Used to admit lowercase-typography canonical headings (e.g. Elsevier's
    spaced-letter "a b s t r a c t" rendered by pdftotext as a lone lowercase
    "abstract" line, with the abstract paragraph following directly on the
    next line) while still rejecting body usages like:

      - "abstract concept of fairness in psychology"  (other words on same line)
      - "abstract\\nis a word that can mean many things..."  (next line is
         lowercase — a body sentence continuation, not a paragraph start).
    """
    # The heading must be at the start of its line (after optional whitespace).
    line_actual_start = text.rfind("\n", 0, line_start) + 1
    leading = text[line_actual_start:line_start]
    if leading and leading.strip():
        return False
    # Nothing else on the heading line after the heading word (allow trailing
    # whitespace / colon / period only).
    line_end = text.find("\n", heading_end)
    if line_end < 0:
        line_end = len(text)
    trailing = text[heading_end:line_end].strip(" \t:.")
    if trailing:
        return False
    # Blank line BEFORE: walk back over whitespace on the prior line; if we hit
    # '\n' or doc-start, it was a blank line.
    if line_actual_start == 0:
        before_ok = True
    else:
        prev_line_end = line_actual_start - 1
        if prev_line_end <= 0:
            before_ok = True
        else:
            j = prev_line_end - 1
            while j >= 0 and text[j] in " \t":
                j -= 1
            before_ok = j < 0 or text[j] == "\n"
    if not before_ok:
        return False
    # Find the next non-blank line and check that it starts with uppercase.
    if line_end >= len(text):
        # Heading at very end of doc — no following paragraph; that's not a
        # real heading.
        return False
    k = line_end + 1
    while k < len(text):
        # Skip whitespace at line start
        line_content_start = k
        while k < len(text) and text[k] in " \t":
            k += 1
        if k >= len(text):
            return False
        if text[k] == "\n":
            # Blank line — keep scanning for the next non-blank.
            k += 1
            continue
        # Found first non-blank content of the next non-blank line.
        return text[k].isupper()
    return False


def _looks_like_table_cell(text: str, heading_end: int, heading_was_line_isolated: bool) -> bool:
    """A heading that was line-isolated and is followed by a tiny next line is
    likely a table row label (e.g., CRediT author-contribution table rows).

    Requires ALL of:
    1. The heading was line-isolated (not followed by a Capital body word on same line).
    2. The heading occupies its entire line — i.e., the text between `heading_end`
       and the next newline is blank (optional trailing colon/space only).
    3. There is a blank line immediately after the heading line.
    4. The first non-blank line after that blank line is tiny (< 20 chars).

    Condition 2 prevents false positives when a canonical heading word appears
    at the START of a long line (e.g. "Keywords emotional pluralistic ignorance...")
    — `heading_end` points mid-line there, not at end-of-line.
    Condition 3 prevents false positives when a heading is immediately followed
    by another heading or body text (e.g. "Introduction\\nBackground\\n").
    """
    if not heading_was_line_isolated:
        return False
    # Condition 2: heading must occupy the rest of its line.
    # Find the newline that ends the heading's line.
    line_end = text.find("\n", heading_end)
    if line_end < 0:
        return False  # No newline — end of text, not a table row.
    rest_of_line = text[heading_end:line_end].strip(" \t:.")
    if rest_of_line:
        # There is substantive text after the heading on the same line (e.g.
        # "Keywords emotional..." or "Methodology for data collection...").
        # This is NOT a table row label — it's a heading+body line.
        return False
    # Condition 3: the line immediately following the heading line must be blank.
    i = line_end + 1
    j = i
    while j < len(text) and text[j] in " \t":
        j += 1
    if j >= len(text) or text[j] != "\n":
        # Not blank — e.g. "Introduction\nBackground\n". Not a table cell.
        return False
    # Condition 4: first non-blank line after the blank separator is tiny.
    # Use a very conservative threshold (≤ 5 chars) to only catch genuine
    # single-character or very short table cells (e.g. "X", "✓", "Yes").
    # Real body text, even a short sentence fragment, is longer than this.
    next_line = _next_nonblank_line(text, i)
    if next_line is None:
        return False
    if len(next_line) <= 5:
        return True

    # v2.4.24 (cycle 9): table-COLUMN-header detection. If the heading is
    # PRECEDED by 2+ short standalone-line "noun phrase" siblings (each
    # ≤30 chars, blank-line separated), it's a table column header row,
    # not a section heading. Canonical example caught by this check:
    # amj_1 Table 1 has column headers `Study and Context\n\nFeedback
    # Directions\n\nFindings\n\n<body row>` — without this check, the
    # third column header "Findings" gets promoted to `## Findings`.
    line_actual_start = text.rfind("\n", 0, heading_end - 1) + 1
    if line_actual_start > 0:
        # Walk back: collect the previous up to 3 non-blank paragraphs.
        siblings: list[str] = []
        k = line_actual_start - 1
        while k > 0 and len(siblings) < 3:
            # Skip blank lines
            while k > 0 and text[k] in (" ", "\t", "\n"):
                if text[k] == "\n":
                    k -= 1
                    break
                k -= 1
            if k <= 0:
                break
            # k is at the last non-whitespace char of a line. Walk to start.
            line_end_local = k + 1
            while k > 0 and text[k] not in ("\n",):
                k -= 1
            line_start_local = k if text[k] == "\n" else 0
            if text[line_start_local] == "\n":
                line_start_local += 1
            prev_line = text[line_start_local:line_end_local].strip()
            if not prev_line:
                k -= 1
                continue
            siblings.append(prev_line)
            # Check that line_start_local was preceded by blank (sibling
            # was standalone, not part of a longer paragraph).
            if line_start_local < 2:
                pass
            else:
                # The char before line_start_local should be `\n` (then
                # before that another `\n` for blank-line separation).
                prev_char = text[line_start_local - 1] if line_start_local >= 1 else "\n"
                prev_prev_char = text[line_start_local - 2] if line_start_local >= 2 else "\n"
                if not (prev_char == "\n" and prev_prev_char == "\n"):
                    # Not blank-line-separated — sibling is part of a
                    # longer paragraph, not a table cell. Stop collecting.
                    break
            k -= 1
        # Require ALL collected siblings (need ≥ 2) to be short
        # noun-phrase-like (≤ 30 chars, no terminal punctuation, no
        # function words that suggest body prose).
        if len(siblings) >= 2:
            def _looks_like_table_header_cell(s: str) -> bool:
                if len(s) > 30:
                    return False
                if s.endswith((".", "!", "?")):
                    return False
                # No common body-prose function words.
                if re.search(r"\b(?:the|is|was|are|were|that|which|with|of|in|to|by|for|on|at|from)\b", s, re.IGNORECASE):
                    return False
                return True
            if all(_looks_like_table_header_cell(s) for s in siblings[:2]):
                return True

    return False


def annotate_text(text: str) -> list[BlockHint]:
    """Scan `text` for heading candidates.

    Three passes:
      1. Canonical taxonomy headings at paragraph-leading line starts (may be
         followed by body text on the same line — handles publishers that
         collapse heading and first-paragraph onto one wrapped line).
      2. Underlined headings (`Heading\\n=====` style).
      3. General heading-line pattern (line-isolated, capitalized) — catches
         non-canonical headings that become `subheadings` in Tier 2.
    """
    hints: list[BlockHint] = []
    seen_offsets: set[int] = set()

    # Pass 1a: canonical heading at line start — disambiguated by Capital-body (b)
    # or end-of-line (c), OR by a blank-line predecessor check (a) done inline.
    # "Funding acquisition" is rejected: no blank line before it (fails a),
    # "acquisition" is lowercase (fails b), and it's not at end-of-line (fails c).
    for m in _CANONICAL_PARA_HEADING.finditer(text):
        start = m.start("heading")
        if start in seen_offsets:
            continue
        heading_text = m.group("heading")
        # Accept the heading if it starts with an uppercase letter
        # (Title Case, Sentence case, or ALL CAPS).  Reject all-lowercase
        # body usages ("abstract concept of fairness") unless the word is
        # fully line-isolated (Elsevier "a b s t r a c t" spaced-letter
        # typography, flattened by pdftotext to lone lowercase).
        # The disambiguation checks below (blank-line predecessor, Capital
        # body, end-of-line) keep body sentences like "Methods are widely
        # used in..." from misfiring even though they start with uppercase.
        if not heading_text[:1].isupper():
            if not _is_fully_isolated_heading(text, m.start(), m.end("heading")):
                continue

        line_start = m.start()
        heading_end = start + len(heading_text)
        after_heading = text[heading_end:]

        # (a) Preceded by blank line or at start-of-doc.
        preceded_by_blank = False
        if line_start == 0:
            preceded_by_blank = True
        else:
            i = line_start - 1
            while i > 0 and text[i] in " \t":
                i -= 1
            if text[i] == "\n":
                j = i - 1
                while j > 0 and text[j] in " \t":
                    j -= 1
                if text[j] == "\n" or j == 0:
                    preceded_by_blank = True

        # (b) Followed by a Capital-letter word on same line (case-sensitive).
        followed_by_capital = bool(_CAPITAL_WORD_AFTER.match(after_heading))

        # (c) At end-of-line (with optional trailing colon/period/space).
        at_end_of_line = bool(_END_OF_LINE.match(after_heading))

        # v2.4.18 (SECTIONING fix): hard-reject the body-prose case.
        #
        # The previous rule `(a) OR (b) OR (c)` admitted canonical heading
        # words at paragraph starts even when the next same-line word
        # revealed body prose ("Results from our study…", "Results based
        # on the top-50…", "Methods of analysis…"). A function-word check
        # is the right discriminator: keyword-list / subsection-label
        # lowercase-body NEVER starts with a function/preposition/
        # auxiliary/common-body-verb word. Body sentences DO.
        #
        # Approach: keep the original a/b/c disambiguator (it correctly
        # admits "Funding The author(s) disclosed…", "Keywords: …",
        # "Method body."), then add a HARD REJECT for the function-word
        # pattern. See ``_FUNCTION_WORD_AFTER`` for the curated list of
        # ~50 body-opener words.
        followed_by_function_word = bool(_FUNCTION_WORD_AFTER.match(after_heading))
        if followed_by_function_word:
            continue

        if not (preceded_by_blank or followed_by_capital or at_end_of_line):
            continue

        # Table-cell filter: if the heading was line-isolated (not followed by a
        # Capital body word on the same line) and the next non-blank line is < 20
        # chars, this is likely a CRediT table row label, not a real heading.
        # Add to seen_offsets even on rejection so Pass 3 doesn't re-emit it.
        is_line_isolated = not followed_by_capital
        if _looks_like_table_cell(text, m.end(), is_line_isolated):
            seen_offsets.add(start)
            continue

        seen_offsets.add(start)
        hints.append(BlockHint(
            text=heading_text,
            char_start=start,
            char_end=start + len(heading_text),
            page=None,
            is_heading_candidate=True,
            heading_strength="strong",
            heading_source="text_pattern",
        ))

    # Pass 1b: canonical heading preceded by a newline (Pattern C).
    # Catches headings whose body starts with a lowercase word — e.g.
    # "Keywords emotional pluralistic ignorance..." — where pass 1a's
    # Capital-body and end-of-line disambiguators both fail.  Matches
    # single-newline separation (common in PSPB PDFs: abstract body → Keywords
    # on next line) as well as blank-line separation.  seen_offsets deduplicates.
    for m in _CANONICAL_AFTER_BLANK.finditer(text):
        start = m.start("heading")
        if start in seen_offsets:
            continue
        heading_text = m.group("heading")
        # Same case rule as Pass 1a: first letter must be uppercase, with the
        # line-isolated lowercase carve-out for Elsevier "a b s t r a c t"
        # typography.
        if not heading_text[:1].isupper():
            if not _is_fully_isolated_heading(text, start, m.end("heading")):
                continue
        # Pass 1b only catches blank-line-preceded headings, which means the
        # heading might be followed by either body or another tiny line.
        # Apply the table-cell filter here too — if next line is < 20 chars, reject.
        # For pass 1b, "is_line_isolated" is effectively True because the regex
        # didn't constrain what follows.
        # Add to seen_offsets even on rejection so Pass 3 doesn't re-emit it.
        if _looks_like_table_cell(text, m.end(), True):
            seen_offsets.add(start)
            continue
        # v2.4.18 (SECTIONING fix): same function-word reject as Pass 1a.
        # "Results from our study…" matches Pass 1b too — block it here.
        # Pass 1b's intent is to catch "Keywords emotional pluralistic…"
        # cases where the trailing words are a list, not a sentence —
        # function-word presence reliably distinguishes the two.
        heading_end_1b = m.end("heading")
        after_heading_1b = text[heading_end_1b:]
        if _FUNCTION_WORD_AFTER.match(after_heading_1b):
            seen_offsets.add(start)
            continue
        seen_offsets.add(start)
        hints.append(BlockHint(
            text=heading_text,
            char_start=start,
            char_end=start + len(heading_text),
            page=None,
            is_heading_candidate=True,
            heading_strength="strong",
            heading_source="text_pattern",
        ))

    # Pass 2: underlined headings.
    for m in _UNDERLINED_HEADING.finditer(text):
        start = m.start("heading")
        if start in seen_offsets:
            continue
        seen_offsets.add(start)
        hints.append(BlockHint(
            text=m.group("heading"),
            char_start=start,
            char_end=m.end("heading"),
            page=None,
            is_heading_candidate=True,
            heading_strength="strong",
            heading_source="text_pattern",
        ))

    # Pass 3: general heading-line pattern.
    # For canonical headings: accept if preceded by at least one newline.
    # For non-canonical (weak) headings that will become subheadings: require
    # ISOLATION (blank line before AND blank line after) so that table rows and
    # body-text sentences are filtered out. Also require ≥ 5 chars + ≥ 2 words,
    # and reject lines that end with a sentence-terminal period (heading lines
    # don't end with periods; body sentences do).
    for m in _HEADING_LINE.finditer(text):
        start = m.start("heading")
        if start in seen_offsets:
            continue
        line_start = m.start()
        line_end = m.end()
        heading = m.group("heading").strip()
        if len(heading) < 2:
            continue
        is_canonical = lookup_canonical_label(heading) is not None
        strength = "strong" if is_canonical else "weak"

        if is_canonical:
            # Canonical headings: just need a preceding newline (same as before).
            before = text[max(0, line_start - 2):line_start]
            if before and not before.endswith("\n\n") and not before.endswith("\n"):
                continue
        else:
            # Non-canonical (weak) headings: require full isolation + quality filters.
            # (1) ≥ 5 chars AND ≥ 2 words.
            if len(heading) < 5 or len(heading.split()) < 2:
                continue
            # (2) Reject lines that end with a period — those are body sentences.
            raw_line = text[line_start:line_end].rstrip()
            if raw_line.endswith("."):
                continue
            # (3) Require blank line BEFORE the heading line.
            before4 = text[max(0, line_start - 4):line_start]
            blank_before = (
                line_start == 0
                or "\n\n" in before4
                or before4.endswith("\n\n")
            )
            if not blank_before:
                continue
            # (4) Require blank line AFTER the heading line.
            after4 = text[line_end:min(len(text), line_end + 4)]
            blank_after = (
                line_end == len(text)
                or "\n\n" in after4
                or after4.startswith("\n\n")
            )
            if not blank_after:
                continue

        seen_offsets.add(start)
        hints.append(BlockHint(
            text=heading,
            char_start=start,
            char_end=m.end("heading"),
            page=None,
            is_heading_candidate=True,
            heading_strength=strength,
            heading_source="text_pattern",
        ))

    hints.sort(key=lambda h: h.char_start)
    return hints
