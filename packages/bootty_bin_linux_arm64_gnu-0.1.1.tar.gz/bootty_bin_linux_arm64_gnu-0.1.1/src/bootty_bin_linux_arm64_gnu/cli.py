""" bootty-bin-linux-arm64-gnu """


def main() -> None:
    print("  bootty-bin-linux-arm64-gnu  ")
