"""Slash command dispatch for the --no-tui interactive session loop.

Delegates to the shared ``CommandHandler`` (same one used by the TUI) so
that both modes always have the same command set.  TUI-only *actions*
(sessions picker, model picker, MCP panel, login widget) are replaced
with text-based equivalents.
"""

from __future__ import annotations

from ember_code.backend.command_handler import CommandHandler, CommandResult
from ember_code.core.session.core import Session
from ember_code.core.utils.display import print_error, print_info, print_markdown


async def dispatch(session: Session, command: str) -> bool:
    """Dispatch a slash command. Returns True if handled, False if unknown."""
    handler = CommandHandler(session)
    result = await handler.handle(command.strip())

    # Unknown command — let the caller handle it (skill matching, etc.)
    if result.kind == "error" and "Unknown command" in result.content:
        return False

    await _render_result(session, result)
    return True


async def _render_result(session: Session, result: CommandResult) -> None:
    """Render a CommandResult as plain text output."""
    if result.action == "quit":
        raise SystemExit(0)
    elif result.action == "clear":
        print_info(f"Conversation cleared. New session: {session.session_id}")
    elif result.action == "sessions":
        await _text_sessions(session)
    elif result.action == "model":
        _text_model_picker(session)
    elif result.action == "mcp":
        _text_mcp_status(session)
    elif result.action == "compact":
        print_info("Context compacted. Old messages summarized and cleared.")
        if result.content:
            print_info(f"Summary:\n{result.content}")
    elif result.action == "login":
        print_info("Login is only available in TUI mode. Run without --no-tui to use /login.")
    elif result.kind == "markdown":
        print_markdown(result.content)
    elif result.kind == "info":
        print_info(result.content)
    elif result.kind == "error":
        print_error(result.content)


# ── Text fallbacks for TUI-only actions ──────────────────────────────


async def _text_sessions(session: Session) -> None:
    """List past sessions as text (no interactive picker)."""
    sessions = []
    if hasattr(session.persistence, "list_sessions"):
        sessions = await session.persistence.list_sessions()
    if not sessions:
        print_info("No past sessions found.")
        return
    lines = ["## Sessions"]
    for s in sessions[:20]:
        name = getattr(s, "name", "") or getattr(s, "session_id", str(s))
        lines.append(f"- {name}")
    lines.append("\n[dim]Use --resume <id> to resume a session.[/dim]")
    print_markdown("\n".join(lines))


def _text_model_picker(session: Session) -> None:
    """List available models as text (no interactive picker)."""
    registry = session.settings.models.registry
    current = session.settings.models.default
    lines = ["## Models"]
    for name in sorted(registry.keys()):
        marker = " (current)" if name == current else ""
        lines.append(f"- {name}{marker}")
    lines.append("\n[dim]Use /model <name> to switch.[/dim]")
    print_markdown("\n".join(lines))


def _text_mcp_status(session: Session) -> None:
    """Show MCP server status as text (no interactive panel)."""
    mgr = session.mcp_manager
    servers = mgr.list_servers()
    if not servers:
        print_info("No MCP servers configured.")
        return
    connected = set(mgr.list_connected())
    lines = ["## MCP Servers"]
    for name in servers:
        if name in connected:
            tools = mgr.get_tools(name)
            lines.append(f"- ● {name} — connected ({len(tools)} tools)")
        else:
            error = mgr.get_error(name)
            status = f"error: {error}" if error else "disconnected"
            lines.append(f"- ○ {name} — {status}")
    print_markdown("\n".join(lines))
