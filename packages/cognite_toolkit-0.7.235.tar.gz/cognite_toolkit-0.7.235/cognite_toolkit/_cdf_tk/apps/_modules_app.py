import contextlib
from enum import Enum
from pathlib import Path
from typing import Annotated

import typer
from rich import print

from cognite_toolkit._cdf_tk.cdf_toml import CDFToml
from cognite_toolkit._cdf_tk.client import ToolkitClient
from cognite_toolkit._cdf_tk.commands import ModulesCommand, PullCommand
from cognite_toolkit._cdf_tk.feature_flags import Flags
from cognite_toolkit._cdf_tk.utils.auth import EnvironmentVariables
from cognite_toolkit._version import __version__

CDF_TOML = CDFToml.load(Path.cwd())


class ModulesListFormats(str, Enum):
    table = "table"
    json = "json"


class ModulesApp(typer.Typer):
    def __init__(self, *args, **kwargs) -> None:  # type: ignore
        super().__init__(*args, **kwargs)
        self.callback(invoke_without_command=True)(self.main)
        self.command()(self.init)
        self.command()(self.upgrade)
        self.command()(self.pull)
        self.command()(self.list)
        self.command()(self.add)

    def main(self, ctx: typer.Context) -> None:
        """Commands to manage modules"""
        if ctx.invoked_subcommand is None:
            print("Use [bold yellow]cdf modules --help[/] for more information.")

    def init(
        self,
        organization_dir: Annotated[
            Path | None,
            typer.Argument(
                help="Directory path to project to initialize or upgrade with templates.",
            ),
        ] = None,
        all: Annotated[
            bool,
            typer.Option(
                "--all",
                "-a",
                help="Copy all available templates.",
            ),
        ] = False,
        clean: Annotated[
            bool,
            typer.Option(
                "--clean",
                "-a",
                help="Clean target directory if it exists",
            ),
        ] = False,
        library_url: Annotated[
            str | None,
            typer.Option(
                "--library-url",
                "-u",
                help="URL of the library to add to the project.",
            ),
        ] = None,
        library_checksum: Annotated[
            str | None,
            typer.Option(
                "--library-checksum",
                "-c",
                help="Library zip checksum (optional; accepted for compatibility, not verified).",
            ),
        ] = None,
        verbose: Annotated[
            bool,
            typer.Option(
                "--verbose",
                "-v",
                help="Turn on to get more verbose output when running the command",
            ),
        ] = False,
    ) -> None:
        """Initialize or upgrade a new CDF project with templates interactively."""
        client: ToolkitClient | None = None
        with contextlib.redirect_stdout(None), contextlib.suppress(Exception):
            # Try to load client if possible, but ignore errors.
            # This is only used for logging purposes in the command.
            client = EnvironmentVariables.create_from_environment().get_client()

        with ModulesCommand(client=client) as cmd:
            cmd.run(
                lambda: cmd.init(
                    organization_dir=organization_dir,
                    select_all=all,
                    clean=clean,
                    library_url=library_url,
                    library_checksum=library_checksum,
                )
            )

    def upgrade(
        self,
        organization_dir: Annotated[
            Path,
            typer.Option(
                "--organization-dir",
                "-o",
                help="Where to find the module templates to build from",
            ),
        ] = CDF_TOML.cdf.default_organization_dir,
        verbose: Annotated[
            bool,
            typer.Option(
                "--verbose",
                "-v",
                help="Print details of each change applied in the upgrade process.",
            ),
        ] = False,
    ) -> None:
        client: ToolkitClient | None = None
        with contextlib.redirect_stdout(None), contextlib.suppress(Exception):
            # Try to load client if possible, but ignore errors.
            # This is only used for logging purposes in the command.
            client = EnvironmentVariables.create_from_environment().get_client()

        cmd = ModulesCommand(client=client)
        cmd.run(lambda: cmd.upgrade(organization_dir=organization_dir, verbose=verbose))

    # This is a trick to use an f-string for the docstring
    upgrade.__doc__ = f"""Upgrade the existing CDF project modules to version {__version__}."""

    def add(
        self,
        organization_dir: Annotated[
            Path,
            typer.Option(
                "--organization-dir",
                "-o",
                help="Path to project directory with the modules. This is used to search for available functions.",
            ),
        ] = CDF_TOML.cdf.default_organization_dir,
        deployment_pack: Annotated[
            str | None,
            typer.Option(
                "--deployment-pack",
                "-d",
                help="Name of a specific module to download and install from the library without interactive prompts.",
                hidden=not Flags.DEPLOYMENT_PACK.is_enabled(),
            ),
        ] = None,
        verbose: Annotated[
            bool,
            typer.Option(
                "--verbose",
                "-v",
                help="Turn on to get more verbose output when running the command",
            ),
        ] = False,
    ) -> None:
        """Add one or more new module(s) to the project."""
        client: ToolkitClient | None = None
        if not Flags.DEPLOYMENT_PACK.is_enabled():
            deployment_pack = None
        with contextlib.redirect_stdout(None), contextlib.suppress(Exception):
            # Try to load client if possible, but ignore errors.
            # This is only used for logging purposes in the command.
            client = EnvironmentVariables.create_from_environment().get_client()
        with ModulesCommand(client=client) as cmd:
            cmd.run(lambda: cmd.add(organization_dir=organization_dir, deployment_pack=deployment_pack))

    def pull(
        self,
        ctx: typer.Context,
        module_name_or_path: Annotated[
            str | None,
            typer.Argument(
                help="The module or path to module to pull from CDF. If not provided, interactive mode will be used.",
                allow_dash=True,
            ),
        ] = None,
        organization_dir: Annotated[
            Path,
            typer.Option(
                "--organization-dir",
                "-o",
                help="Where to find the module templates to build from",
            ),
        ] = CDF_TOML.cdf.default_organization_dir,
        build_env: Annotated[
            str,
            typer.Option(
                "--env",
                "-e",
                help="Build environment to use.",
            ),
        ] = CDF_TOML.cdf.default_env,
        dry_run: Annotated[
            bool,
            typer.Option(
                "--dry-run",
                "-d",
                help="Do now change the local files on the disk.",
            ),
        ] = False,
        verbose: Annotated[
            bool,
            typer.Option(
                "--verbose",
                "-v",
                help="Print details of each change applied in the pull process.",
            ),
        ] = False,
    ) -> None:
        """Pull a module from CDF. This will overwrite the local files with the latest version from CDF."""
        env_vars = EnvironmentVariables.create_from_environment()
        cmd = PullCommand(client=env_vars.get_client())
        cmd.run(
            lambda: cmd.pull_module(
                module_name_or_path=module_name_or_path,
                organization_dir=organization_dir,
                env=build_env,
                dry_run=dry_run,
                verbose=verbose,
                env_vars=env_vars,
            )
        )

    def list(
        self,
        organization_dir: Annotated[
            Path,
            typer.Option(
                "--organization-dir",
                "-o",
                help="Where to find the module templates to build from",
            ),
        ] = CDF_TOML.cdf.default_organization_dir,
        build_env: Annotated[
            str | None,
            typer.Option(
                "--env",
                help="Build environment to use.",
            ),
        ] = CDF_TOML.cdf.default_env,
        output_format: Annotated[
            ModulesListFormats,
            typer.Option(
                "--format",
                "-f",
                help="Output format for modules list. Supported formats: table, json.",
                hidden=not Flags.MODULES_LIST_JSON.is_enabled(),
            ),
        ] = ModulesListFormats.table,
        verbose: Annotated[
            bool,
            typer.Option(
                "--verbose",
                "-v",
                help="Turn on to get more verbose output when running the command",
            ),
        ] = False,
    ) -> None:
        """List all available modules in the project."""
        client: ToolkitClient | None = None
        with contextlib.redirect_stdout(None), contextlib.suppress(Exception):
            # Try to load client if possible, but ignore errors.
            # This is only used for logging purposes in the command.
            client = EnvironmentVariables.create_from_environment().get_client()

        cmd = ModulesCommand(client=client)
        cmd.run(
            lambda: cmd.list(
                organization_dir=organization_dir,
                build_env_name=build_env,
                output_format=output_format.value,
            )
        )
