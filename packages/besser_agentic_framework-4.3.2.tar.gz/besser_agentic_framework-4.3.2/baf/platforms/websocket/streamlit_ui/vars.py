# Streamlit session_state keys
ASSISTANT = 'assistant'
BUTTONS = 'buttons'
HISTORY = 'history'
QUEUE = 'queue'
SESSION_MONITORING = 'session_monitoring'
SUBMIT_FILE = 'submit_file'
SUBMIT_TEXT = 'submit_text'
SUBMIT_AUDIO = 'submit_audio'
USER = 'user'
WEBSOCKET = 'websocket'
WS_HOST = 'ws_host'
WS_PORT = 'ws_port'
WEBSOCKET_READY = 'websocket_ready'
PLAYED_AUDIO_IDS = 'played_audio_ids'
CHAT_INTERFACE_STYLES = 'chat_interface_styles'
CHAT_INTERFACE_STYLE_SIGNATURE = 'chat_interface_style_signature'

# Time interval to check if a streamlit session is still active, in seconds
SESSION_MONITORING_INTERVAL = 1

# New agent messages are printed with a typing effect. This is the time between words being printed, in seconds
TYPING_TIME = 0.05

