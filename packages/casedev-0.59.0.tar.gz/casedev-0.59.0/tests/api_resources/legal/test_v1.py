# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from casedev import Casedev, AsyncCasedev
from tests.utils import assert_matches_type
from casedev._utils import parse_date
from casedev.types.legal import (
    V1FindResponse,
    V1DraftResponse,
    V1DocketResponse,
    V1VerifyResponse,
    V1SimilarResponse,
    V1ResearchResponse,
    V1SecFilingResponse,
    V1ListCourtsResponse,
    V1GetFullTextResponse,
    V1GetCitationsResponse,
    V1PatentSearchResponse,
    V1TrademarkSearchResponse,
    V1ListJurisdictionsResponse,
    V1GetCitationsFromURLResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestV1:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_docket(self, client: Casedev) -> None:
        v1 = client.legal.v1.docket(
            type="search",
        )
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    def test_method_docket_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.docket(
            type="search",
            acknowledge_pacer_fees=True,
            court="court",
            date_filed_after=parse_date("2019-12-27"),
            date_filed_before=parse_date("2019-12-27"),
            docket_id="docketId",
            include_entries=True,
            limit=1,
            live=True,
            offset=0,
            query="xx",
        )
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_docket(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.docket(
            type="search",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_docket(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.docket(
            type="search",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1DocketResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_draft(self, client: Casedev) -> None:
        v1 = client.legal.v1.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        )
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    def test_method_draft_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
            citations=True,
            format="format",
            length={
                "target": 0,
                "unit": "words",
            },
            model="model",
            object_ids=["string"],
            output_name="output_name",
            output_type="pdf",
            verified=True,
        )
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_draft(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_draft(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1DraftResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_find(self, client: Casedev) -> None:
        v1 = client.legal.v1.find(
            query="xxx",
        )
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    def test_method_find_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.find(
            query="xxx",
            jurisdiction="jurisdiction",
            num_results=1,
        )
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_find(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.find(
            query="xxx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_find(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.find(
            query="xxx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1FindResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_get_citations(self, client: Casedev) -> None:
        v1 = client.legal.v1.get_citations(
            text="text",
        )
        assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_get_citations(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.get_citations(
            text="text",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_get_citations(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.get_citations(
            text="text",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_get_citations_from_url(self, client: Casedev) -> None:
        v1 = client.legal.v1.get_citations_from_url(
            url="https://example.com",
        )
        assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_get_citations_from_url(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.get_citations_from_url(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_get_citations_from_url(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.get_citations_from_url(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_get_full_text(self, client: Casedev) -> None:
        v1 = client.legal.v1.get_full_text(
            url="https://example.com",
        )
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    def test_method_get_full_text_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.get_full_text(
            url="https://example.com",
            highlight_query="highlightQuery",
            max_characters=1000,
            summary_query="summaryQuery",
        )
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_get_full_text(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.get_full_text(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_get_full_text(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.get_full_text(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_courts(self, client: Casedev) -> None:
        v1 = client.legal.v1.list_courts()
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    def test_method_list_courts_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.list_courts(
            in_use_only=True,
            jurisdiction="jurisdiction",
            limit=1,
            offset=0,
            query="xx",
        )
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_list_courts(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.list_courts()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_list_courts(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.list_courts() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_list_jurisdictions(self, client: Casedev) -> None:
        v1 = client.legal.v1.list_jurisdictions(
            name="xx",
        )
        assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_list_jurisdictions(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.list_jurisdictions(
            name="xx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_list_jurisdictions(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.list_jurisdictions(
            name="xx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_patent_search(self, client: Casedev) -> None:
        v1 = client.legal.v1.patent_search(
            query="x",
        )
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    def test_method_patent_search_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.patent_search(
            query="x",
            application_status="applicationStatus",
            application_type="Utility",
            assignee="assignee",
            filing_date_from=parse_date("2019-12-27"),
            filing_date_to=parse_date("2019-12-27"),
            grant_date_from=parse_date("2019-12-27"),
            grant_date_to=parse_date("2019-12-27"),
            inventor="inventor",
            limit=1,
            offset=0,
            sort_by="filingDate",
            sort_order="asc",
        )
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_patent_search(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.patent_search(
            query="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_patent_search(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.patent_search(
            query="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_research(self, client: Casedev) -> None:
        v1 = client.legal.v1.research(
            query="xxx",
        )
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    def test_method_research_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.research(
            query="xxx",
            additional_queries=["string"],
            jurisdiction="jurisdiction",
            num_results=1,
        )
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_research(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.research(
            query="xxx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_research(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.research(
            query="xxx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1ResearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_sec_filing(self, client: Casedev) -> None:
        v1 = client.legal.v1.sec_filing(
            type="search",
        )
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    def test_method_sec_filing_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.sec_filing(
            type="search",
            cik="cik",
            date_after=parse_date("2019-12-27"),
            date_before=parse_date("2019-12-27"),
            entity="entity",
            form_types=["string"],
            limit=1,
            offset=0,
            query="xx",
            ticker="ticker",
        )
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_sec_filing(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.sec_filing(
            type="search",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_sec_filing(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.sec_filing(
            type="search",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1SecFilingResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_similar(self, client: Casedev) -> None:
        v1 = client.legal.v1.similar(
            url="https://example.com",
        )
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    def test_method_similar_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.similar(
            url="https://example.com",
            jurisdiction="jurisdiction",
            num_results=1,
            start_published_date=parse_date("2019-12-27"),
        )
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_similar(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.similar(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_similar(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.similar(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1SimilarResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_trademark_search(self, client: Casedev) -> None:
        v1 = client.legal.v1.trademark_search()
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    def test_method_trademark_search_with_all_params(self, client: Casedev) -> None:
        v1 = client.legal.v1.trademark_search(
            registration_number="registrationNumber",
            serial_number="serialNumber",
        )
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_trademark_search(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.trademark_search()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_trademark_search(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.trademark_search() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_verify(self, client: Casedev) -> None:
        v1 = client.legal.v1.verify(
            text="text",
        )
        assert_matches_type(V1VerifyResponse, v1, path=["response"])

    @parametrize
    def test_raw_response_verify(self, client: Casedev) -> None:
        response = client.legal.v1.with_raw_response.verify(
            text="text",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = response.parse()
        assert_matches_type(V1VerifyResponse, v1, path=["response"])

    @parametrize
    def test_streaming_response_verify(self, client: Casedev) -> None:
        with client.legal.v1.with_streaming_response.verify(
            text="text",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = response.parse()
            assert_matches_type(V1VerifyResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncV1:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_docket(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.docket(
            type="search",
        )
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    async def test_method_docket_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.docket(
            type="search",
            acknowledge_pacer_fees=True,
            court="court",
            date_filed_after=parse_date("2019-12-27"),
            date_filed_before=parse_date("2019-12-27"),
            docket_id="docketId",
            include_entries=True,
            limit=1,
            live=True,
            offset=0,
            query="xx",
        )
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_docket(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.docket(
            type="search",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1DocketResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_docket(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.docket(
            type="search",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1DocketResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_draft(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        )
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    async def test_method_draft_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
            citations=True,
            format="format",
            length={
                "target": 0,
                "unit": "words",
            },
            model="model",
            object_ids=["string"],
            output_name="output_name",
            output_type="pdf",
            verified=True,
        )
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_draft(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1DraftResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_draft(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.draft(
            instructions="xxxxxxxxxx",
            vault_id="vault_id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1DraftResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_find(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.find(
            query="xxx",
        )
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    async def test_method_find_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.find(
            query="xxx",
            jurisdiction="jurisdiction",
            num_results=1,
        )
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_find(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.find(
            query="xxx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1FindResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_find(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.find(
            query="xxx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1FindResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_get_citations(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.get_citations(
            text="text",
        )
        assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_get_citations(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.get_citations(
            text="text",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_get_citations(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.get_citations(
            text="text",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1GetCitationsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_get_citations_from_url(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.get_citations_from_url(
            url="https://example.com",
        )
        assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_get_citations_from_url(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.get_citations_from_url(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_get_citations_from_url(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.get_citations_from_url(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1GetCitationsFromURLResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_get_full_text(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.get_full_text(
            url="https://example.com",
        )
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    async def test_method_get_full_text_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.get_full_text(
            url="https://example.com",
            highlight_query="highlightQuery",
            max_characters=1000,
            summary_query="summaryQuery",
        )
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_get_full_text(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.get_full_text(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_get_full_text(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.get_full_text(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1GetFullTextResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_courts(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.list_courts()
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    async def test_method_list_courts_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.list_courts(
            in_use_only=True,
            jurisdiction="jurisdiction",
            limit=1,
            offset=0,
            query="xx",
        )
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_list_courts(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.list_courts()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_list_courts(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.list_courts() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1ListCourtsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_list_jurisdictions(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.list_jurisdictions(
            name="xx",
        )
        assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_list_jurisdictions(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.list_jurisdictions(
            name="xx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_list_jurisdictions(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.list_jurisdictions(
            name="xx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1ListJurisdictionsResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_patent_search(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.patent_search(
            query="x",
        )
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    async def test_method_patent_search_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.patent_search(
            query="x",
            application_status="applicationStatus",
            application_type="Utility",
            assignee="assignee",
            filing_date_from=parse_date("2019-12-27"),
            filing_date_to=parse_date("2019-12-27"),
            grant_date_from=parse_date("2019-12-27"),
            grant_date_to=parse_date("2019-12-27"),
            inventor="inventor",
            limit=1,
            offset=0,
            sort_by="filingDate",
            sort_order="asc",
        )
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_patent_search(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.patent_search(
            query="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_patent_search(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.patent_search(
            query="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1PatentSearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_research(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.research(
            query="xxx",
        )
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    async def test_method_research_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.research(
            query="xxx",
            additional_queries=["string"],
            jurisdiction="jurisdiction",
            num_results=1,
        )
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_research(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.research(
            query="xxx",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1ResearchResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_research(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.research(
            query="xxx",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1ResearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_sec_filing(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.sec_filing(
            type="search",
        )
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    async def test_method_sec_filing_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.sec_filing(
            type="search",
            cik="cik",
            date_after=parse_date("2019-12-27"),
            date_before=parse_date("2019-12-27"),
            entity="entity",
            form_types=["string"],
            limit=1,
            offset=0,
            query="xx",
            ticker="ticker",
        )
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_sec_filing(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.sec_filing(
            type="search",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1SecFilingResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_sec_filing(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.sec_filing(
            type="search",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1SecFilingResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_similar(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.similar(
            url="https://example.com",
        )
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    async def test_method_similar_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.similar(
            url="https://example.com",
            jurisdiction="jurisdiction",
            num_results=1,
            start_published_date=parse_date("2019-12-27"),
        )
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_similar(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.similar(
            url="https://example.com",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1SimilarResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_similar(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.similar(
            url="https://example.com",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1SimilarResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_trademark_search(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.trademark_search()
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    async def test_method_trademark_search_with_all_params(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.trademark_search(
            registration_number="registrationNumber",
            serial_number="serialNumber",
        )
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_trademark_search(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.trademark_search()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_trademark_search(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.trademark_search() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1TrademarkSearchResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_verify(self, async_client: AsyncCasedev) -> None:
        v1 = await async_client.legal.v1.verify(
            text="text",
        )
        assert_matches_type(V1VerifyResponse, v1, path=["response"])

    @parametrize
    async def test_raw_response_verify(self, async_client: AsyncCasedev) -> None:
        response = await async_client.legal.v1.with_raw_response.verify(
            text="text",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        v1 = await response.parse()
        assert_matches_type(V1VerifyResponse, v1, path=["response"])

    @parametrize
    async def test_streaming_response_verify(self, async_client: AsyncCasedev) -> None:
        async with async_client.legal.v1.with_streaming_response.verify(
            text="text",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            v1 = await response.parse()
            assert_matches_type(V1VerifyResponse, v1, path=["response"])

        assert cast(Any, response.is_closed) is True
