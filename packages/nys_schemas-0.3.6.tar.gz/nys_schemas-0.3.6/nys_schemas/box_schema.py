from typing import Optional, Union

from pydantic import BaseModel, Field, root_validator, validator


SECTION_CODE_DESCRIPTION = (
    "Legacy section code stored as integer with binary digits (8-bit semantics). "
    "String inputs are accepted for compatibility: <=8 chars (legacy), exactly 16 chars, "
    "or exactly 32 chars."
)

SECTION_CODE_32_DESCRIPTION = (
    "Canonical 32-bit section code stored as integer with binary digits. "
    "This field is the source of truth for overlap/placement logic."
)


def _normalize_stored_32(section_code: Union[str, int]) -> str:
    section_code_str = str(section_code).strip()
    if not section_code_str:
        raise ValueError("Section code cannot be empty")
    if section_code_str.startswith("-"):
        raise ValueError("Section code cannot be negative")
    if any(char not in {"0", "1"} for char in section_code_str):
        raise ValueError("Section code must contain only '0' and '1'")
    if len(section_code_str) > 32:
        raise ValueError("Integer section code must be up to 32 binary digits")
    return section_code_str.zfill(32)


def _normalize_legacy_8_from_32(section_code_32: Union[str, int]) -> int:
    canonical_32 = _normalize_stored_32(section_code_32)
    compressed_bits = []
    for row_block in range(2):
        top_row_start = row_block * 16
        bottom_row_start = top_row_start + 8
        for col_block in range(4):
            left_col = col_block * 2
            right_col = left_col + 1
            block_bits = (
                canonical_32[top_row_start + left_col],
                canonical_32[top_row_start + right_col],
                canonical_32[bottom_row_start + left_col],
                canonical_32[bottom_row_start + right_col],
            )
            compressed_bits.append("1" if all(bit == "1" for bit in block_bits) else "0")
    return int("".join(compressed_bits))


def _project_response_section_codes(cls, values):
    if values is None:
        return values

    if isinstance(values, dict):
        normalized_values = dict(values)
    else:
        # Avoid expanding ORM GetterDict into a full dict because it can touch
        # lazy relationships (e.g. `carrier`) on detached instances.
        normalized_values = {}
        for field_name in ("id", "section_code", "section_code_32"):
            try:
                field_value = values.get(field_name)
            except Exception:
                continue
            if field_value is not None:
                normalized_values[field_name] = field_value

    section_code = normalized_values.get("section_code")
    section_code_32 = normalized_values.get("section_code_32")

    # DB stores canonical 32-bit in section_code.
    if section_code_32 is None and section_code is not None:
        section_code_32 = section_code
        normalized_values["section_code_32"] = section_code_32

    # API response field section_code remains legacy 8-bit projection.
    if section_code_32 is not None:
        normalized_values["section_code"] = _normalize_legacy_8_from_32(section_code_32)

    return normalized_values


def _validate_section_code_format(section_code: Optional[Union[str, int]]) -> Optional[Union[str, int]]:
    if section_code is None:
        return section_code

    if isinstance(section_code, bool):
        raise ValueError("Section code cannot be boolean")

    if isinstance(section_code, int):
        if section_code < 0:
            raise ValueError("Section code cannot be negative")
        section_code_str = str(section_code)
        if len(section_code_str) > 32:
            raise ValueError("Integer section code must be up to 32 binary digits")
        if any(char not in {"0", "1"} for char in section_code_str):
            raise ValueError("Section code must contain only '0' and '1'")
        return section_code

    section_code_str = str(section_code).strip()
    if not section_code_str:
        raise ValueError("Section code cannot be empty")
    if any(char not in {"0", "1"} for char in section_code_str):
        raise ValueError("Section code must contain only '0' and '1'")
    if len(section_code_str) not in (16, 32) and len(section_code_str) > 8:
        raise ValueError("Section code must be <=8, exactly 16, or exactly 32 binary characters")

    return section_code_str

class Box(BaseModel):
    section_code: int = Field(description=SECTION_CODE_DESCRIPTION)
    section_code_32: Optional[int] = Field(default=None, description=SECTION_CODE_32_DESCRIPTION)

    _response_projection_validator = root_validator(allow_reuse=True, pre=True)(
        _project_response_section_codes
    )
    _section_code_validator = validator("section_code", allow_reuse=True, pre=True)(
        _validate_section_code_format
    )

    class Config:
        orm_mode = True

class BoxCreate(BaseModel):
    section_code: Optional[Union[str, int]] = Field(
        default=None,
        description=SECTION_CODE_DESCRIPTION,
    )

    _section_code_validator = validator("section_code", allow_reuse=True, pre=True)(
        _validate_section_code_format
    )

    class Config:
        orm_mode = True

class BoxPatch(BaseModel):
    section_code: Optional[Union[str, int]] = Field(
        default=None,
        description=SECTION_CODE_DESCRIPTION,
    )

    _section_code_validator = validator("section_code", allow_reuse=True, pre=True)(
        _validate_section_code_format
    )

    class Config:
        orm_mode = True

class BoxResponse(Box):
    id: int 
