"""Database package scaffold."""
