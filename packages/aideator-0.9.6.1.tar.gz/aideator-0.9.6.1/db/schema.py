"""Schema migration scaffold."""
