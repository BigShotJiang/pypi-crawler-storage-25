"""API package scaffold."""
