"""External adapter package scaffold."""
