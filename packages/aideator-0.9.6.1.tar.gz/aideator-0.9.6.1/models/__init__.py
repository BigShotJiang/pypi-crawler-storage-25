"""Domain model package scaffold."""
