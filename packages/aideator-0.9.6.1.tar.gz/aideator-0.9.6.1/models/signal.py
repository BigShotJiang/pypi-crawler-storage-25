"""Signal model scaffold."""
