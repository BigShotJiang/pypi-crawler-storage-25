"""Telemetry scaffold."""
