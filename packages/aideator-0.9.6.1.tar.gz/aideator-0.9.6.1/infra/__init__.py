"""Infra package scaffold."""
