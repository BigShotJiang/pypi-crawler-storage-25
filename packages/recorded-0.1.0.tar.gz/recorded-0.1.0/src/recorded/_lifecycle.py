"""Recording machinery shared between bare-call and leader execution.

Both bare-call (sync and async wrappers in `_decorator`) and the leader
process (`_cli._execute_claimed_row`) delegate into this layer for the
universal serialize-validate-record flow. Holds the helpers that don't
belong in `_decorator` (which is the call-site spine) or `_cli` (which
is the leader's event-loop driver).

Contents:
- `make_error_json`: single source of truth for `{type, message}` JSON.
- `_validate_call_args`: refuse-to-compile rules at call time.
- `_capture_request`, `_serialize_request`: request envelope + JSON.
- `_serialize_error`, `_serialize_recording_failure`: error envelope + JSON.
- `_write_completion`, `_build_data_json`: success-path recording
  (response + data projection + attach buffer flush).
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import TYPE_CHECKING, Any

from . import _registry, _storage
from ._context import _UNSET, JobContext, current_job
from ._errors import ConfigurationError, SerializationError

_logger = logging.getLogger("recorded")

if TYPE_CHECKING:
    from ._recorder import Recorder


# ---------------------------------------------------------------------------
# Error JSON shape
# ---------------------------------------------------------------------------


def make_error_json(type_: str, message: str) -> str:
    """Single source of truth for the `{type, message}` JSON shape used by
    every error writer (`_serialize_error`, `_serialize_recording_failure`,
    the leader's cancel marker, the unknown-kind marker, the reaper).

    Consumers like `JoinedSiblingFailedError` read `.message` to format
    their string; any other key is silently dropped.
    """
    return json.dumps({"type": type_, "message": message})


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def _validate_call_args(
    entry: _registry.RegistryEntry,
    key: str | None,
    args: tuple[Any, ...] = (),
    kwargs: dict[str, Any] | None = None,
    *,
    submit: bool = False,
) -> None:
    """Call-time validation of decorator + call-shape combinations.

    Three checks, all refuse-to-compile rather than silently mis-record:

    1. `key=` against an auto-derived kind. The default kind comes from
       `f"{module}.{qualname}"` and silently changes when the function
       is renamed or moved — exactly the failure mode idempotency was
       meant to prevent.

    2. `request=Model` against a multi-argument call shape. The capture
       envelope for multi-arg / kwarg calls is `{args, kwargs}` — that
       shape can't be validated through a typed request model. Mirrors
       the `key=` + auto-kind precedent: misuse caught at call time, not
       silently mis-recorded.

    3. `.submit()` against a multi-argument call shape. The leader process
       reconstructs the call from the stored request envelope; round-
       tripping `{args, kwargs}` and unpacking it generically can collide
       with naturally-shaped dicts. `.submit()` therefore requires a
       single positional argument, full stop. For multi-argument
       functions, define a `request=Model` that captures the call shape
       and pass that one model instance, or use the bare-call form
       (which has the live args and never round-trips).
    """
    if key is not None and entry.auto_kind:
        raise ConfigurationError(
            f'{entry.kind} uses an auto-derived kind ("{entry.kind}"). '
            "Idempotency keys require an explicit kind to remain stable across "
            'renames. Add: @recorder(kind="...")'
        )
    if entry.request.model is not None:
        kw = kwargs or {}
        if len(args) != 1 or kw:
            raise ConfigurationError(
                f"{entry.kind}: request=Model requires single-positional-arg "
                f"call shape; got args={len(args)}, kwargs={list(kw)}. "
                "Either drop request=Model or simplify the call shape."
            )
    if submit:
        kw = kwargs or {}
        if len(args) != 1 or kw:
            raise ConfigurationError(
                f"{entry.kind}: .submit() requires a single positional "
                f"argument; got args={len(args)}, kwargs={list(kw)}. "
                "Define a request=Model that captures your call shape and "
                "pass that one model instance, or use the bare-call form "
                "for in-process execution with the native call shape."
            )


# ---------------------------------------------------------------------------
# Request capture + serialization
# ---------------------------------------------------------------------------


def _capture_request(args: tuple[Any, ...], kwargs: dict[str, Any]) -> Any:
    """Single positional arg → that arg. Otherwise → {args, kwargs} envelope."""
    if len(args) == 1 and not kwargs:
        return args[0]
    return {"args": list(args), "kwargs": kwargs}


def _serialize_request(entry: _registry.RegistryEntry, captured: Any) -> str | None:
    """Serialize captured request before any DB write — raises propagate
    to the caller (no row is written, the wrapped function is not run),
    so `SerializationError` here is annotated with `slot="request"` so
    callers can branch on which slot rejected the input.
    """
    if captured is None:
        return None
    try:
        serialized = entry.request.serialize(captured)
    except SerializationError as exc:
        exc.slot = "request"
        raise
    return json.dumps(serialized)


# ---------------------------------------------------------------------------
# Error serialization
# ---------------------------------------------------------------------------


def _serialize_error(entry: _registry.RegistryEntry, exc: BaseException) -> str:
    """Compose the JSON payload written to `error_json`.

    Default shape: `{type: <ExcClass>, message: <str(exc)>}` derived from
    the live exception. If the wrapped function called `attach_error(...)`,
    the attached payload is routed through `entry.error.serialize(...)`
    and used instead. Works in both modes:

    - `error=Model` (typed): the payload is validated by construction
      through the model and dumped.
    - passthrough (no `error=Model`): the payload is `_to_native`-rendered
      and stored as-is. No model declaration required for advanced devs
      who want structured error payloads without committing to a schema.

    The original exception still propagates verbatim to the caller —
    `attach_error` only re-shapes the *recording*. If the attached payload
    fails validation through the adapter we fall back to the default
    `{type, message}` so a serialization bug never silently drops the
    record.
    """
    ctx = current_job.get()
    if ctx is not None and ctx.error_buffer is not _UNSET:
        try:
            return json.dumps(entry.error.serialize(ctx.error_buffer))
        except Exception as adapter_exc:
            # Fall through to {type, message} of the *original* exc rather
            # than masking the underlying failure. Caller still sees `exc`.
            # Log the adapter failure so the silent fallback is visible —
            # raising would itself violate wrap-transparency by replacing
            # the user's exception with one the bare function couldn't
            # produce.
            _logger.warning(
                "recorded[%s]: error=Model adapter rejected attach_error "
                "payload (%s); recording fell back to {type, message} of "
                "the original exception. Fix the attached payload to match "
                "the registered model.",
                entry.kind,
                adapter_exc,
            )
    return make_error_json(type(exc).__name__, str(exc))


def _serialize_recording_failure(exc: BaseException) -> str:
    """Error JSON for the case where the wrapped function succeeded but
    the recorder couldn't serialize its result."""
    return make_error_json(
        type(exc).__name__,
        f"recorder failed to serialize response: {exc}",
    )


# ---------------------------------------------------------------------------
# Success-path recording: response, data projection, attach buffer
# ---------------------------------------------------------------------------


def _write_completion(
    recorder_inst: Recorder,
    entry: _registry.RegistryEntry,
    job_id: str,
    result: Any,
    buffer: dict[str, Any],
) -> None:
    response_json = None if result is None else json.dumps(entry.response.serialize(result))
    data_json = _build_data_json(recorder_inst, entry, result, buffer)
    recorder_inst._mark_completed(job_id, _storage.now_iso(), response_json, data_json)


def _build_data_json(
    recorder_inst: Recorder,
    entry: _registry.RegistryEntry,
    response: Any,
    buffer: dict[str, Any],
) -> str | None:
    """Compose `data_json` from optional projection + attach buffer.

    Conflict rule (WHY.md): the projection populates initial keys;
    attaches merge in last-write-wins.

    Projection runs only when the response shape matches the data slot's
    declared model — either an instance of the model, or a dict that
    validates against it. Anything else falls through to `{}`; if
    `warn_on_data_drift` is on, the drift is surfaced once per
    `(kind, reason)` per Recorder.
    """
    projected: dict[str, Any] = {}
    project_error: Exception | None = None
    try:
        projected = entry.data.project(response)
    except Exception as exc:
        # Projection is opportunistic — a partial response is still
        # recorded via response_json; we just skip the projected slice.
        project_error = exc

    merged = {**projected, **buffer}

    if (
        recorder_inst.warn_on_data_drift
        and entry.data.model is not None
        and response is not None
        and not merged
    ):
        _warn_data_drift_once(recorder_inst, entry, project_error)

    if not merged:
        return None
    return json.dumps(merged)


def _warn_data_drift_once(
    recorder_inst: Recorder,
    entry: _registry.RegistryEntry,
    exc: Exception | None,
) -> None:
    """Per-Recorder dedup: one warning per `(kind, reason)`."""
    reason = "projection_raised" if exc is not None else "shape_mismatch"
    key = (entry.kind, reason)
    if key in recorder_inst._drift_warned:
        return
    recorder_inst._drift_warned.add(key)
    model = entry.data.model
    model_name = model.__name__ if model is not None else "?"
    detail = f" (projection raised: {exc})" if exc is not None else ""
    _logger.warning(
        "recorded[%s]: data_model=%s declared but projection produced empty "
        "data — response did not match the model%s. To fix: return an "
        "instance of %s, or call attach({...}) inside the function with "
        "what you want queryable. Disable this warning with "
        "configure(warn_on_data_drift=False).",
        entry.kind,
        model_name,
        detail,
        model_name,
    )


def _run_and_record(
    recorder_inst: Recorder,
    entry: _registry.RegistryEntry,
    job_id: str,
    invoke: Any,  # 0-arg callable returning the wrapped fn's result
) -> Any:
    """Set context, invoke `invoke()`, record outcome, return the result.

    Sync variant. Used by the bare-call sync wrapper.

    Wrap-transparency: when the wrapped function returns successfully,
    this function returns that value — even if the recorder fails to
    serialize it. The bare function would never raise on a recording
    failure, so the decorated callable can't either. Recording failures
    mark the row failed and emit a warning via `recorded` logger.
    """
    ctx = JobContext(job_id=job_id, kind=entry.kind, recorder=recorder_inst, entry=entry)
    token = current_job.set(ctx)
    try:
        try:
            result = invoke()
        except Exception as exc:
            recorder_inst._mark_failed(job_id, _storage.now_iso(), _serialize_error(entry, exc))
            raise
        try:
            _write_completion(recorder_inst, entry, job_id, result, ctx.buffer)
        except Exception as exc:
            recorder_inst._mark_failed(
                job_id, _storage.now_iso(), _serialize_recording_failure(exc)
            )
            _logger.warning(
                "recorded[%s]: failed to serialize response from %s: %s. "
                "Row %s marked failed; the wrapped function's return value "
                "is propagated to the caller.",
                entry.kind,
                entry.kind,
                exc,
                job_id,
            )
        return result
    finally:
        current_job.reset(token)


async def _run_and_record_async(
    recorder_inst: Recorder,
    entry: _registry.RegistryEntry,
    job_id: str,
    invoke: Any,  # 0-arg callable returning an awaitable of the fn's result
) -> Any:
    """Async variant of `_run_and_record`. Used by the bare-call async
    wrapper and the leader's `_execute_claimed_row`.

    `invoke` is a 0-arg callable returning a coroutine (or any awaitable).
    SQL writes go through `asyncio.to_thread` so they don't block the loop.

    Wrap-transparency: see `_run_and_record`. Recording failures on the
    success path are logged but do not propagate as exceptions — the
    bare function would have returned the value too.

    `CancelledError` (BaseException, not Exception) is not caught — it
    propagates so the caller's task-cancellation protocol stays intact.
    """
    ctx = JobContext(job_id=job_id, kind=entry.kind, recorder=recorder_inst, entry=entry)
    token = current_job.set(ctx)
    try:
        try:
            result = await invoke()
        except Exception as exc:
            await asyncio.to_thread(
                recorder_inst._mark_failed,
                job_id,
                _storage.now_iso(),
                _serialize_error(entry, exc),
            )
            raise
        try:
            await asyncio.to_thread(
                _write_completion, recorder_inst, entry, job_id, result, ctx.buffer
            )
        except Exception as exc:
            await asyncio.to_thread(
                recorder_inst._mark_failed,
                job_id,
                _storage.now_iso(),
                _serialize_recording_failure(exc),
            )
            _logger.warning(
                "recorded[%s]: failed to serialize response from %s: %s. "
                "Row %s marked failed; the wrapped function's return value "
                "is propagated to the caller.",
                entry.kind,
                entry.kind,
                exc,
                job_id,
            )
        return result
    finally:
        current_job.reset(token)
