from __future__ import annotations

from typing import Any

from sapiopycommons.general.aliases import AliasUtil, SapioRecord

from tot_sdk.webservice.pojos.pipeline import VersionId


class PipelineResult:
    record_id: int | None
    data_record_name: str | None
    created_by: str | None
    date_created: int | None
    related_parent_record_id: int | None
    descriptive_status: str | None
    duration: int | None
    duration_date: int | None
    end_date: int | None
    failure_reason: str | None
    is_failed: bool | None
    last_modified_by: str | None
    last_modified_date: int | None
    pipeline_status: str | None
    pipeline_template_id: str | None
    pipeline_template_name: str | None
    pipeline_template_version: int | None
    pipeline_template_version_id: str | None
    start_date: int | None

    def __init__(self):
        self.record_id = None
        self.data_record_name = None
        self.created_by = None
        self.date_created = None
        self.related_parent_record_id = None
        self.descriptive_status = None
        self.duration = None
        self.duration_date = None
        self.end_date = None
        self.failure_reason = None
        self.is_failed = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.pipeline_status = None
        self.pipeline_template_id = None
        self.pipeline_template_name = None
        self.pipeline_template_version = None
        self.pipeline_template_version_id = None
        self.start_date = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineResult:
        result = PipelineResult()
        result.record_id = json_dct.get("recordId")
        result.data_record_name = json_dct.get("dataRecordName")
        result.created_by = json_dct.get("createdBy")
        result.date_created = json_dct.get("dateCreated")
        result.related_parent_record_id = json_dct.get("relatedParentRecordId")
        result.descriptive_status = json_dct.get("descriptiveStatus")
        result.duration = json_dct.get("duration")
        result.duration_date = json_dct.get("durationDate")
        result.end_date = json_dct.get("endDate")
        result.failure_reason = json_dct.get("failureReason")
        result.is_failed = json_dct.get("isFailed")
        result.last_modified_by = json_dct.get("lastModifiedBy")
        result.last_modified_date = json_dct.get("lastModifiedDate")
        result.pipeline_status = json_dct.get("pipelineStatus")
        result.pipeline_template_id = json_dct.get("pipelineTemplateId")
        result.pipeline_template_name = json_dct.get("pipelineTemplateName")
        result.pipeline_template_version = json_dct.get("pipelineTemplateVersion")
        result.pipeline_template_version_id = json_dct.get("pipelineTemplateVersionId")
        result.start_date = json_dct.get("startDate")
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "recordId": self.record_id,
            "dataRecordName": self.data_record_name,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "relatedParentRecordId": self.related_parent_record_id,
            "descriptiveStatus": self.descriptive_status,
            "duration": self.duration,
            "durationDate": self.duration_date,
            "endDate": self.end_date,
            "failureReason": self.failure_reason,
            "isFailed": self.is_failed,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "pipelineStatus": self.pipeline_status,
            "pipelineTemplateId": self.pipeline_template_id,
            "pipelineTemplateName": self.pipeline_template_name,
            "pipelineTemplateVersion": self.pipeline_template_version,
            "pipelineTemplateVersionId": self.pipeline_template_version_id,
            "startDate": self.start_date,
        }


class PipelineStepResult:
    record_id: int | None
    data_record_name: str | None
    created_by: str | None
    date_created: int | None
    related_parent_record_id: int | None
    agent_config_version_id: str | None
    descriptive_status: str | None
    duration: int | None
    duration_date: int | None
    end_date: int | None
    failure_reason: str | None
    is_failed: bool | None
    last_modified_by: str | None
    last_modified_date: int | None
    pipeline_step_template_id: str | None
    processed_item_count: int | None
    start_date: int | None
    step_status: str | None
    step_summary: str | None
    step_template_name: str | None
    total_item_count: int | None

    def __init__(self):
        self.record_id = None
        self.data_record_name = None
        self.created_by = None
        self.date_created = None
        self.related_parent_record_id = None
        self.agent_config_version_id = None
        self.descriptive_status = None
        self.duration = None
        self.duration_date = None
        self.end_date = None
        self.failure_reason = None
        self.is_failed = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.pipeline_step_template_id = None
        self.processed_item_count = None
        self.start_date = None
        self.step_status = None
        self.step_summary = None
        self.step_template_name = None
        self.total_item_count = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineStepResult:
        result = PipelineStepResult()
        result.record_id = json_dct.get("recordId")
        result.data_record_name = json_dct.get("dataRecordName")
        result.created_by = json_dct.get("createdBy")
        result.date_created = json_dct.get("dateCreated")
        result.related_parent_record_id = json_dct.get("relatedParentRecordId")
        result.agent_config_version_id = json_dct.get("agentConfigVersionId")
        result.descriptive_status = json_dct.get("descriptiveStatus")
        result.duration = json_dct.get("duration")
        result.duration_date = json_dct.get("durationDate")
        result.end_date = json_dct.get("endDate")
        result.failure_reason = json_dct.get("failureReason")
        result.is_failed = json_dct.get("isFailed")
        result.last_modified_by = json_dct.get("lastModifiedBy")
        result.last_modified_date = json_dct.get("lastModifiedDate")
        result.pipeline_step_template_id = json_dct.get("pipelineStepTemplateId")
        result.processed_item_count = json_dct.get("processedItemCount")
        result.start_date = json_dct.get("startDate")
        result.step_status = json_dct.get("stepStatus")
        result.step_summary = json_dct.get("stepSummary")
        result.step_template_name = json_dct.get("stepTemplateName")
        result.total_item_count = json_dct.get("totalItemCount")
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "recordId": self.record_id,
            "dataRecordName": self.data_record_name,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "relatedParentRecordId": self.related_parent_record_id,
            "agentConfigVersionId": self.agent_config_version_id,
            "descriptiveStatus": self.descriptive_status,
            "duration": self.duration,
            "durationDate": self.duration_date,
            "endDate": self.end_date,
            "failureReason": self.failure_reason,
            "isFailed": self.is_failed,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "pipelineStepTemplateId": self.pipeline_step_template_id,
            "processedItemCount": self.processed_item_count,
            "startDate": self.start_date,
            "stepStatus": self.step_status,
            "stepSummary": self.step_summary,
            "stepTemplateName": self.step_template_name,
            "totalItemCount": self.total_item_count,
        }


class PipelineStepOutputResult:
    pipeline_step_id: int | None
    output_index: int
    output_name: str | None
    content_type: str | None
    content: str | None
    file_name: str | None
    hash_id: str | None

    def __init__(self):
        self.pipeline_step_id = None
        self.output_index = 0
        self.output_name = None
        self.content_type = None
        self.content = None
        self.file_name = None
        self.hash_id = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineStepOutputResult:
        result = PipelineStepOutputResult()
        result.pipeline_step_id = json_dct.get("pipelineStepId")
        result.output_index = json_dct.get("outputIndex", 0)
        result.output_name = json_dct.get("outputName")
        result.content_type = json_dct.get("contentType")
        result.content = json_dct.get("content")
        result.file_name = json_dct.get("fileName")
        result.hash_id = json_dct.get("hashId")
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "pipelineStepId": self.pipeline_step_id,
            "outputIndex": self.output_index,
            "outputName": self.output_name,
            "contentType": self.content_type,
            "content": self.content,
            "fileName": self.file_name,
            "hashId": self.hash_id,
        }


class ScoutResult:
    record_id: int | None
    data_record_name: str | None
    created_by: str | None
    date_created: int | None
    conversation_guid: str | None
    duration: int | None
    end_date: int | None
    last_modified_by: str | None
    last_modified_date: int | None
    pipeline_group_name: str | None
    pipeline_group_owner: str | None
    pipeline_group_status: str | None
    start_date: int | None

    def __init__(self):
        self.record_id = None
        self.data_record_name = None
        self.created_by = None
        self.date_created = None
        self.conversation_guid = None
        self.duration = None
        self.end_date = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.pipeline_group_name = None
        self.pipeline_group_owner = None
        self.pipeline_group_status = None
        self.start_date = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> ScoutResult:
        result = ScoutResult()
        result.record_id = json_dct.get("recordId")
        result.data_record_name = json_dct.get("dataRecordName")
        result.created_by = json_dct.get("createdBy")
        result.date_created = json_dct.get("dateCreated")
        result.conversation_guid = json_dct.get("conversationGuid")
        result.duration = json_dct.get("duration")
        result.end_date = json_dct.get("endDate")
        result.last_modified_by = json_dct.get("lastModifiedBy")
        result.last_modified_date = json_dct.get("lastModifiedDate")
        result.pipeline_group_name = json_dct.get("pipelineGroupName")
        result.pipeline_group_owner = json_dct.get("pipelineGroupOwner")
        result.pipeline_group_status = json_dct.get("pipelineGroupStatus")
        result.start_date = json_dct.get("startDate")
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "recordId": self.record_id,
            "dataRecordName": self.data_record_name,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "conversationGuid": self.conversation_guid,
            "duration": self.duration,
            "endDate": self.end_date,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "pipelineGroupName": self.pipeline_group_name,
            "pipelineGroupOwner": self.pipeline_group_owner,
            "pipelineGroupStatus": self.pipeline_group_status,
            "startDate": self.start_date,
        }


class FoundationsPipelineTemplateResult:
    id: str | None
    display_name: str | None
    description: str | None
    category: str | None
    active: bool
    restricted: bool
    version: int | None
    created_by: str | None
    date_created: int | None
    last_modified_by: str | None
    last_modified_date: int | None
    published_by: str | None
    published_date: int | None

    def __init__(self):
        self.id = None
        self.display_name = None
        self.description = None
        self.category = None
        self.active = True
        self.restricted = False
        self.version = None
        self.created_by = None
        self.date_created = None
        self.last_modified_by = None
        self.last_modified_date = None
        self.published_by = None
        self.published_date = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> FoundationsPipelineTemplateResult:
        result = FoundationsPipelineTemplateResult()
        result.id = json_dct.get("id")
        result.display_name = json_dct.get("displayName")
        result.description = json_dct.get("description")
        result.category = json_dct.get("category")
        result.active = json_dct.get("active", True)
        result.restricted = json_dct.get("restricted", False)
        result.version = json_dct.get("version")
        result.created_by = json_dct.get("createdBy")
        result.date_created = json_dct.get("dateCreated")
        result.last_modified_by = json_dct.get("lastModifiedBy")
        result.last_modified_date = json_dct.get("lastModifiedDate")
        result.published_by = json_dct.get("publishedBy")
        result.published_date = json_dct.get("publishedDate")
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "displayName": self.display_name,
            "description": self.description,
            "category": self.category,
            "active": self.active,
            "restricted": self.restricted,
            "version": self.version,
            "createdBy": self.created_by,
            "dateCreated": self.date_created,
            "lastModifiedBy": self.last_modified_by,
            "lastModifiedDate": self.last_modified_date,
            "publishedBy": self.published_by,
            "publishedDate": self.published_date,
        }


class PipelineTemplateBlueprintResult:
    pipeline_template_id: str | None
    pipeline_template_name: str | None
    version: str | None
    blueprint: str | None
    step_template_id_to_metadata: dict[str, dict[str, Any]]

    def __init__(self):
        self.pipeline_template_id = None
        self.pipeline_template_name = None
        self.version = None
        self.blueprint = None
        self.step_template_id_to_metadata = {}

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> PipelineTemplateBlueprintResult:
        result = PipelineTemplateBlueprintResult()
        result.pipeline_template_id = json_dct.get("pipelineTemplateId")
        result.pipeline_template_name = json_dct.get("pipelineTemplateName")
        result.version = json_dct.get("version")
        result.blueprint = json_dct.get("blueprint")
        result.step_template_id_to_metadata = json_dct.get("stepTemplateIdToMetadata") or {}
        return result

    def to_json(self) -> dict[str, Any]:
        return {
            "pipelineTemplateId": self.pipeline_template_id,
            "pipelineTemplateName": self.pipeline_template_name,
            "version": self.version,
            "blueprint": self.blueprint,
            "stepTemplateIdToMetadata": self.step_template_id_to_metadata,
        }


class StepInputFile:
    file_name: str | None
    file_data: str | None

    def __init__(self, file_data: str | None = None, file_name: str | None = None):
        self.file_name = file_name
        self.file_data = file_data

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> StepInputFile:
        return StepInputFile(
            file_data=json_dct.get("fileData"),
            file_name=json_dct.get("fileName"),
        )

    def to_json(self) -> dict[str, Any]:
        return {
            "fileName": self.file_name,
            "fileData": self.file_data,
        }


class StepInput:
    input_records: list[dict[str, Any]]
    input_files: list[StepInputFile]

    def __init__(
            self,
            input_records: list[dict[str, Any] | SapioRecord] | None = None,
            input_files: list[StepInputFile | dict[str, Any]] | None = None,
    ):
        self.input_records = []
        for record in input_records or []:
            if isinstance(record, dict):
                self.input_records.append(record)
            else:
                self.input_records.append(AliasUtil.to_field_map(record, True))
        self.input_files = [
            input_file if isinstance(input_file, StepInputFile) else StepInputFile.from_json(input_file)
            for input_file in input_files or []
        ]

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> StepInput:
        return StepInput(
            input_records=json_dct.get("inputRecords") or [],
            input_files=json_dct.get("inputFiles") or [],
        )

    def to_json(self) -> dict[str, Any]:
        return {
            "inputRecords": self.input_records,
            "inputFiles": [input_file.to_json() for input_file in self.input_files],
        }


class StartPipelineRequest:
    pipeline_template_id: str
    step_inputs: dict[str, StepInput | dict[str, Any]]
    step_runtime_parameters: dict[str, dict[str, Any]]

    def __init__(
            self,
            pipeline_template_id: VersionId | str,
            step_inputs: dict[str | int, StepInput | dict[str, Any]] | None = None,
            step_runtime_parameters: dict[str | int, dict[str, Any]] | None = None,
    ):
        if isinstance(pipeline_template_id, VersionId):
            self.pipeline_template_id = pipeline_template_id.to_json()
        else:
            self.pipeline_template_id = pipeline_template_id
        self.step_inputs = {str(key): value for key, value in (step_inputs or {}).items()}
        self.step_runtime_parameters = {
            str(key): value for key, value in (step_runtime_parameters or {}).items()
        }

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> StartPipelineRequest:
        return StartPipelineRequest(
            pipeline_template_id=json_dct.get("pipelineTemplateId", ""),
            step_inputs={
                key: StepInput.from_json(value)
                for key, value in (json_dct.get("stepInputs") or {}).items()
            },
            step_runtime_parameters=json_dct.get("stepRuntimeParameters") or {},
        )

    def to_json(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "pipelineTemplateId": self.pipeline_template_id,
        }
        if self.step_inputs:
            result["stepInputs"] = {
                key: value.to_json() if isinstance(value, StepInput) else value
                for key, value in self.step_inputs.items()
            }
        if self.step_runtime_parameters:
            result["stepRuntimeParameters"] = self.step_runtime_parameters
        return result


class StartPipelineResponse:
    success: bool
    pipeline_record_id: int | None
    message: str | None
    warnings: list[str] | None

    def __init__(self):
        self.success = False
        self.pipeline_record_id = None
        self.message = None
        self.warnings = None

    @staticmethod
    def from_json(json_dct: dict[str, Any]) -> StartPipelineResponse:
        response = StartPipelineResponse()
        response.success = json_dct.get("success", False)
        response.pipeline_record_id = json_dct.get("pipelineRecordId")
        response.message = json_dct.get("message")
        response.warnings = json_dct.get("warnings")
        return response

    def to_json(self) -> dict[str, Any]:
        return {
            "success": self.success,
            "pipelineRecordId": self.pipeline_record_id,
            "message": self.message,
            "warnings": self.warnings,
        }
