from sapiopylib.rest.pojo.datatype.FieldDefinition import FieldType
from sapiopylib.rest.utils.recordmodel.RecordModelWrapper import WrappedRecordModel, WrapperField
from sapiopylib.rest.pojo.DateRange import DateRange
from typing import Optional, Final

class VeloxPipelineModel(WrappedRecordModel):
    """
    Auto-Generated Record Model Wrapper for data type VeloxPipeline
    Data Type Display Name: Pipeline (Pipelines)
    Fields: CreatedBy, DataRecordName, DateCreated, VeloxAdditionalTokenCost, VeloxDeferredTokenUsage, VeloxDescriptiveStatus, VeloxDisplayName, VeloxDuration, VeloxDurationDate, VeloxEndDate, VeloxFailureReason, VeloxInterpretation, VeloxIsFailed, VeloxLastModifiedBy, VeloxLastModifiedDate, VeloxPipelineGroupLink, VeloxPipelineStatus, VeloxPipelineTemplateBlob, VeloxPipelineTemplateId, VeloxPipelineTemplateName, VeloxPipelineTemplateVersion, VeloxPipelineTemplateVersionId, VeloxReasoning, VeloxStartDate, VeloxTokenCost, VeloxTokenUsageCommitted
    The data type used to store the individual instance details for executed pipelines.
    """
    DATA_TYPE_NAME: Final[str] = 'VeloxPipeline'
    DISPLAY_NAME: Final[str] = "Pipeline"
    PLURAL_DISPLAY_NAME: Final[str] = "Pipelines"
    CREATEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("CreatedBy", FieldType.STRING, display_name="Created By")
    DATARECORDNAME__FIELD_NAME: Final[WrapperField] = WrapperField("DataRecordName", FieldType.IDENTIFIER, display_name="ID")
    DATECREATED__FIELD_NAME: Final[WrapperField] = WrapperField("DateCreated", FieldType.DATE, display_name="Date Created")
    VELOXADDITIONALTOKENCOST__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxAdditionalTokenCost", FieldType.DOUBLE, display_name="Additional Token Cost")
    VELOXDEFERREDTOKENUSAGE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDeferredTokenUsage", FieldType.BOOLEAN, display_name="Deferred Token Usage")
    VELOXDESCRIPTIVESTATUS__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDescriptiveStatus", FieldType.STRING, display_name="Descriptive Pipeline Status")
    VELOXDISPLAYNAME__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDisplayName", FieldType.STRING, display_name="Display Name")
    VELOXDURATION__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDuration", FieldType.LONG, display_name="Duration")
    VELOXDURATIONDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDurationDate", FieldType.LONG, display_name="Duration")
    VELOXENDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxEndDate", FieldType.DATE, display_name="End Date")
    VELOXFAILUREREASON__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxFailureReason", FieldType.STRING, display_name="Failure Reason")
    VELOXINTERPRETATION__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxInterpretation", FieldType.STRING, display_name="Interpretation")
    VELOXISFAILED__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxIsFailed", FieldType.BOOLEAN, display_name="Is Failed")
    VELOXLASTMODIFIEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedBy", FieldType.STRING, display_name="Last Modified By")
    VELOXLASTMODIFIEDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedDate", FieldType.DATE, display_name="Last Modified Date")
    VELOXPIPELINEGROUPLINK__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineGroupLink", FieldType.SIDE_LINK, display_name="Pipeline Group")
    VELOXPIPELINESTATUS__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineStatus", FieldType.STRING, display_name="Pipeline Status")
    VELOXPIPELINETEMPLATEBLOB__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineTemplateBlob", FieldType.FILE_BLOB, display_name="Pipeline Template Data")
    VELOXPIPELINETEMPLATEID__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineTemplateId", FieldType.STRING, display_name="Pipeline Template ID")
    VELOXPIPELINETEMPLATENAME__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineTemplateName", FieldType.STRING, display_name="Pipeline Template Name")
    VELOXPIPELINETEMPLATEVERSION__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineTemplateVersion", FieldType.INTEGER, display_name="Pipeline Template Version")
    VELOXPIPELINETEMPLATEVERSIONID__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineTemplateVersionId", FieldType.STRING, display_name="Pipeline Template Version ID")
    VELOXREASONING__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxReasoning", FieldType.STRING, display_name="Reasoning")
    VELOXSTARTDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStartDate", FieldType.DATE, display_name="Start Date")
    VELOXTOKENCOST__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxTokenCost", FieldType.DOUBLE, display_name="Token Cost")
    VELOXTOKENUSAGECOMMITTED__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxTokenUsageCommitted", FieldType.BOOLEAN, display_name="Token Usage Committed")

    @classmethod
    def get_wrapper_data_type_name(cls):
        return cls.DATA_TYPE_NAME

    def get_CreatedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'CreatedBy' from this record model
        """
        return self.get_field_value(self.CREATEDBY__FIELD_NAME.field_name)

    def get_DataRecordName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'DataRecordName' from this record model
        """
        return self.get_field_value(self.DATARECORDNAME__FIELD_NAME.field_name)

    def get_DateCreated_field(self) -> Optional[int]:
        """
        Get data field value with field name 'DateCreated' from this record model
        """
        return self.get_field_value(self.DATECREATED__FIELD_NAME.field_name)

    def set_VeloxAdditionalTokenCost_field(self, value: Optional[float]):
        """
        Set data field with field name 'VeloxAdditionalTokenCost' on this record model
        """
        self.set_field_value(self.VELOXADDITIONALTOKENCOST__FIELD_NAME.field_name, value)

    def get_VeloxAdditionalTokenCost_field(self) -> Optional[float]:
        """
        Get data field value with field name 'VeloxAdditionalTokenCost' from this record model
        """
        return self.get_field_value(self.VELOXADDITIONALTOKENCOST__FIELD_NAME.field_name)

    def set_VeloxDeferredTokenUsage_field(self, value: Optional[bool]):
        """
        Set data field with field name 'VeloxDeferredTokenUsage' on this record model
        """
        self.set_field_value(self.VELOXDEFERREDTOKENUSAGE__FIELD_NAME.field_name, value)

    def get_VeloxDeferredTokenUsage_field(self) -> Optional[bool]:
        """
        Get data field value with field name 'VeloxDeferredTokenUsage' from this record model
        """
        return self.get_field_value(self.VELOXDEFERREDTOKENUSAGE__FIELD_NAME.field_name)

    def set_VeloxDescriptiveStatus_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxDescriptiveStatus' on this record model
        """
        self.set_field_value(self.VELOXDESCRIPTIVESTATUS__FIELD_NAME.field_name, value)

    def get_VeloxDescriptiveStatus_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxDescriptiveStatus' from this record model
        """
        return self.get_field_value(self.VELOXDESCRIPTIVESTATUS__FIELD_NAME.field_name)

    def set_VeloxDisplayName_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxDisplayName' on this record model
        """
        self.set_field_value(self.VELOXDISPLAYNAME__FIELD_NAME.field_name, value)

    def get_VeloxDisplayName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxDisplayName' from this record model
        """
        return self.get_field_value(self.VELOXDISPLAYNAME__FIELD_NAME.field_name)

    def set_VeloxDuration_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxDuration' on this record model
        """
        self.set_field_value(self.VELOXDURATION__FIELD_NAME.field_name, value)

    def get_VeloxDuration_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxDuration' from this record model
        """
        return self.get_field_value(self.VELOXDURATION__FIELD_NAME.field_name)

    def set_VeloxDurationDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxDurationDate' on this record model
        """
        self.set_field_value(self.VELOXDURATIONDATE__FIELD_NAME.field_name, value)

    def get_VeloxDurationDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxDurationDate' from this record model
        """
        return self.get_field_value(self.VELOXDURATIONDATE__FIELD_NAME.field_name)

    def set_VeloxEndDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxEndDate' on this record model
        """
        self.set_field_value(self.VELOXENDDATE__FIELD_NAME.field_name, value)

    def get_VeloxEndDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxEndDate' from this record model
        """
        return self.get_field_value(self.VELOXENDDATE__FIELD_NAME.field_name)

    def set_VeloxFailureReason_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxFailureReason' on this record model
        """
        self.set_field_value(self.VELOXFAILUREREASON__FIELD_NAME.field_name, value)

    def get_VeloxFailureReason_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxFailureReason' from this record model
        """
        return self.get_field_value(self.VELOXFAILUREREASON__FIELD_NAME.field_name)

    def set_VeloxInterpretation_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxInterpretation' on this record model
        """
        self.set_field_value(self.VELOXINTERPRETATION__FIELD_NAME.field_name, value)

    def get_VeloxInterpretation_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxInterpretation' from this record model
        """
        return self.get_field_value(self.VELOXINTERPRETATION__FIELD_NAME.field_name)

    def set_VeloxIsFailed_field(self, value: Optional[bool]):
        """
        Set data field with field name 'VeloxIsFailed' on this record model
        """
        self.set_field_value(self.VELOXISFAILED__FIELD_NAME.field_name, value)

    def get_VeloxIsFailed_field(self) -> Optional[bool]:
        """
        Get data field value with field name 'VeloxIsFailed' from this record model
        """
        return self.get_field_value(self.VELOXISFAILED__FIELD_NAME.field_name)

    def get_VeloxLastModifiedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxLastModifiedBy' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDBY__FIELD_NAME.field_name)

    def get_VeloxLastModifiedDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxLastModifiedDate' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDDATE__FIELD_NAME.field_name)

    def set_VeloxPipelineGroupLink_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxPipelineGroupLink' on this record model
        """
        self.set_field_value(self.VELOXPIPELINEGROUPLINK__FIELD_NAME.field_name, value)

    def get_VeloxPipelineGroupLink_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxPipelineGroupLink' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINEGROUPLINK__FIELD_NAME.field_name)

    def set_VeloxPipelineStatus_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineStatus' on this record model
        """
        self.set_field_value(self.VELOXPIPELINESTATUS__FIELD_NAME.field_name, value)

    def get_VeloxPipelineStatus_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineStatus' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINESTATUS__FIELD_NAME.field_name)

    def get_VeloxPipelineTemplateBlob_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineTemplateBlob' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINETEMPLATEBLOB__FIELD_NAME.field_name)

    def set_VeloxPipelineTemplateId_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineTemplateId' on this record model
        """
        self.set_field_value(self.VELOXPIPELINETEMPLATEID__FIELD_NAME.field_name, value)

    def get_VeloxPipelineTemplateId_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineTemplateId' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINETEMPLATEID__FIELD_NAME.field_name)

    def set_VeloxPipelineTemplateName_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineTemplateName' on this record model
        """
        self.set_field_value(self.VELOXPIPELINETEMPLATENAME__FIELD_NAME.field_name, value)

    def get_VeloxPipelineTemplateName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineTemplateName' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINETEMPLATENAME__FIELD_NAME.field_name)

    def set_VeloxPipelineTemplateVersion_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxPipelineTemplateVersion' on this record model
        """
        self.set_field_value(self.VELOXPIPELINETEMPLATEVERSION__FIELD_NAME.field_name, value)

    def get_VeloxPipelineTemplateVersion_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxPipelineTemplateVersion' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINETEMPLATEVERSION__FIELD_NAME.field_name)

    def set_VeloxPipelineTemplateVersionId_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineTemplateVersionId' on this record model
        """
        self.set_field_value(self.VELOXPIPELINETEMPLATEVERSIONID__FIELD_NAME.field_name, value)

    def get_VeloxPipelineTemplateVersionId_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineTemplateVersionId' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINETEMPLATEVERSIONID__FIELD_NAME.field_name)

    def set_VeloxReasoning_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxReasoning' on this record model
        """
        self.set_field_value(self.VELOXREASONING__FIELD_NAME.field_name, value)

    def get_VeloxReasoning_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxReasoning' from this record model
        """
        return self.get_field_value(self.VELOXREASONING__FIELD_NAME.field_name)

    def set_VeloxStartDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxStartDate' on this record model
        """
        self.set_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name, value)

    def get_VeloxStartDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxStartDate' from this record model
        """
        return self.get_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name)

    def set_VeloxTokenCost_field(self, value: Optional[float]):
        """
        Set data field with field name 'VeloxTokenCost' on this record model
        """
        self.set_field_value(self.VELOXTOKENCOST__FIELD_NAME.field_name, value)

    def get_VeloxTokenCost_field(self) -> Optional[float]:
        """
        Get data field value with field name 'VeloxTokenCost' from this record model
        """
        return self.get_field_value(self.VELOXTOKENCOST__FIELD_NAME.field_name)

    def set_VeloxTokenUsageCommitted_field(self, value: Optional[bool]):
        """
        Set data field with field name 'VeloxTokenUsageCommitted' on this record model
        """
        self.set_field_value(self.VELOXTOKENUSAGECOMMITTED__FIELD_NAME.field_name, value)

    def get_VeloxTokenUsageCommitted_field(self) -> Optional[bool]:
        """
        Get data field value with field name 'VeloxTokenUsageCommitted' from this record model
        """
        return self.get_field_value(self.VELOXTOKENUSAGECOMMITTED__FIELD_NAME.field_name)


class VeloxPipelineGroupModel(WrappedRecordModel):
    """
    Auto-Generated Record Model Wrapper for data type VeloxPipelineGroup
    Data Type Display Name: Research Task (Research Tasks)
    Fields: CreatedBy, DataRecordName, DateCreated, VeloxConversationGuid, VeloxDuration, VeloxEndDate, VeloxLastModifiedBy, VeloxLastModifiedDate, VeloxPipelineGroupName, VeloxPipelineGroupOwner, VeloxPipelineGroupStatus, VeloxStartDate
    The data type used to group related pipeline executions that share a conversation context.
    """
    DATA_TYPE_NAME: Final[str] = 'VeloxPipelineGroup'
    DISPLAY_NAME: Final[str] = "Research Task"
    PLURAL_DISPLAY_NAME: Final[str] = "Research Tasks"
    CREATEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("CreatedBy", FieldType.STRING, display_name="Created By")
    DATARECORDNAME__FIELD_NAME: Final[WrapperField] = WrapperField("DataRecordName", FieldType.IDENTIFIER, display_name="ID")
    DATECREATED__FIELD_NAME: Final[WrapperField] = WrapperField("DateCreated", FieldType.DATE, display_name="Date Created")
    VELOXCONVERSATIONGUID__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxConversationGuid", FieldType.STRING, display_name="Conversation GUID")
    VELOXDURATION__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDuration", FieldType.LONG, display_name="Duration")
    VELOXENDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxEndDate", FieldType.DATE, display_name="End Date")
    VELOXLASTMODIFIEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedBy", FieldType.STRING, display_name="Last Modified By")
    VELOXLASTMODIFIEDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedDate", FieldType.DATE, display_name="Last Modified Date")
    VELOXPIPELINEGROUPNAME__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineGroupName", FieldType.STRING, display_name="Name")
    VELOXPIPELINEGROUPOWNER__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineGroupOwner", FieldType.STRING, display_name="Owner")
    VELOXPIPELINEGROUPSTATUS__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineGroupStatus", FieldType.STRING, display_name="Status")
    VELOXSTARTDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStartDate", FieldType.DATE, display_name="Start Date")

    @classmethod
    def get_wrapper_data_type_name(cls):
        return cls.DATA_TYPE_NAME

    def get_CreatedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'CreatedBy' from this record model
        """
        return self.get_field_value(self.CREATEDBY__FIELD_NAME.field_name)

    def get_DataRecordName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'DataRecordName' from this record model
        """
        return self.get_field_value(self.DATARECORDNAME__FIELD_NAME.field_name)

    def get_DateCreated_field(self) -> Optional[int]:
        """
        Get data field value with field name 'DateCreated' from this record model
        """
        return self.get_field_value(self.DATECREATED__FIELD_NAME.field_name)

    def set_VeloxConversationGuid_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxConversationGuid' on this record model
        """
        self.set_field_value(self.VELOXCONVERSATIONGUID__FIELD_NAME.field_name, value)

    def get_VeloxConversationGuid_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxConversationGuid' from this record model
        """
        return self.get_field_value(self.VELOXCONVERSATIONGUID__FIELD_NAME.field_name)

    def set_VeloxDuration_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxDuration' on this record model
        """
        self.set_field_value(self.VELOXDURATION__FIELD_NAME.field_name, value)

    def get_VeloxDuration_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxDuration' from this record model
        """
        return self.get_field_value(self.VELOXDURATION__FIELD_NAME.field_name)

    def set_VeloxEndDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxEndDate' on this record model
        """
        self.set_field_value(self.VELOXENDDATE__FIELD_NAME.field_name, value)

    def get_VeloxEndDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxEndDate' from this record model
        """
        return self.get_field_value(self.VELOXENDDATE__FIELD_NAME.field_name)

    def get_VeloxLastModifiedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxLastModifiedBy' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDBY__FIELD_NAME.field_name)

    def get_VeloxLastModifiedDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxLastModifiedDate' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDDATE__FIELD_NAME.field_name)

    def set_VeloxPipelineGroupName_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineGroupName' on this record model
        """
        self.set_field_value(self.VELOXPIPELINEGROUPNAME__FIELD_NAME.field_name, value)

    def get_VeloxPipelineGroupName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineGroupName' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINEGROUPNAME__FIELD_NAME.field_name)

    def set_VeloxPipelineGroupOwner_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineGroupOwner' on this record model
        """
        self.set_field_value(self.VELOXPIPELINEGROUPOWNER__FIELD_NAME.field_name, value)

    def get_VeloxPipelineGroupOwner_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineGroupOwner' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINEGROUPOWNER__FIELD_NAME.field_name)

    def set_VeloxPipelineGroupStatus_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineGroupStatus' on this record model
        """
        self.set_field_value(self.VELOXPIPELINEGROUPSTATUS__FIELD_NAME.field_name, value)

    def get_VeloxPipelineGroupStatus_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineGroupStatus' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINEGROUPSTATUS__FIELD_NAME.field_name)

    def set_VeloxStartDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxStartDate' on this record model
        """
        self.set_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name, value)

    def get_VeloxStartDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxStartDate' from this record model
        """
        return self.get_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name)


class VeloxPipelineStepModel(WrappedRecordModel):
    """
    Auto-Generated Record Model Wrapper for data type VeloxPipelineStep
    Data Type Display Name: Pipeline Step (Pipeline Steps)
    Fields: CreatedBy, DataRecordName, DateCreated, VeloxAgentConfigVersionId, VeloxDescriptiveStatus, VeloxDuration, VeloxDurationDate, VeloxEndDate, VeloxExecutionProfile, VeloxFailureReason, VeloxIsFailed, VeloxLastModifiedBy, VeloxLastModifiedDate, VeloxPipelineGroupLink, VeloxPipelineStepTemplateId, VeloxProcessedItemCount, VeloxStartDate, VeloxStepStatus, VeloxStepSummary, VeloxStepTemplateName, VeloxStepType, VeloxTokenCost, VeloxTotalItemCount
    The data type used to store the individual instance details for executed steps within pipelines.
    """
    DATA_TYPE_NAME: Final[str] = 'VeloxPipelineStep'
    DISPLAY_NAME: Final[str] = "Pipeline Step"
    PLURAL_DISPLAY_NAME: Final[str] = "Pipeline Steps"
    CREATEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("CreatedBy", FieldType.STRING, display_name="Created By")
    DATARECORDNAME__FIELD_NAME: Final[WrapperField] = WrapperField("DataRecordName", FieldType.IDENTIFIER, display_name="ID")
    DATECREATED__FIELD_NAME: Final[WrapperField] = WrapperField("DateCreated", FieldType.DATE, display_name="Date Created")
    VELOXAGENTCONFIGVERSIONID__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxAgentConfigVersionId", FieldType.STRING, display_name="Agent Configuration Version ID")
    VELOXDESCRIPTIVESTATUS__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDescriptiveStatus", FieldType.STRING, display_name="Descriptive Step Status")
    VELOXDURATION__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDuration", FieldType.LONG, display_name="Duration")
    VELOXDURATIONDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxDurationDate", FieldType.LONG, display_name="Duration")
    VELOXENDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxEndDate", FieldType.DATE, display_name="End Date")
    VELOXEXECUTIONPROFILE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxExecutionProfile", FieldType.STRING, display_name="Execution Profile")
    VELOXFAILUREREASON__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxFailureReason", FieldType.STRING, display_name="Failure Reason")
    VELOXISFAILED__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxIsFailed", FieldType.BOOLEAN, display_name="Is Failed")
    VELOXLASTMODIFIEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedBy", FieldType.STRING, display_name="Last Modified By")
    VELOXLASTMODIFIEDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedDate", FieldType.DATE, display_name="Last Modified Date")
    VELOXPIPELINEGROUPLINK__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineGroupLink", FieldType.SIDE_LINK, display_name="Pipeline Group")
    VELOXPIPELINESTEPTEMPLATEID__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxPipelineStepTemplateId", FieldType.STRING, display_name="Step Template ID")
    VELOXPROCESSEDITEMCOUNT__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxProcessedItemCount", FieldType.INTEGER, display_name="Processed Item Count")
    VELOXSTARTDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStartDate", FieldType.DATE, display_name="Start Date")
    VELOXSTEPSTATUS__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStepStatus", FieldType.STRING, display_name="Step Status")
    VELOXSTEPSUMMARY__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStepSummary", FieldType.STRING, display_name="Step Summary")
    VELOXSTEPTEMPLATENAME__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStepTemplateName", FieldType.STRING, display_name="Step Template Name")
    VELOXSTEPTYPE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxStepType", FieldType.STRING, display_name="Step Type")
    VELOXTOKENCOST__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxTokenCost", FieldType.DOUBLE, display_name="Token Cost")
    VELOXTOTALITEMCOUNT__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxTotalItemCount", FieldType.INTEGER, display_name="Total Item Count")

    @classmethod
    def get_wrapper_data_type_name(cls):
        return cls.DATA_TYPE_NAME

    def get_CreatedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'CreatedBy' from this record model
        """
        return self.get_field_value(self.CREATEDBY__FIELD_NAME.field_name)

    def get_DataRecordName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'DataRecordName' from this record model
        """
        return self.get_field_value(self.DATARECORDNAME__FIELD_NAME.field_name)

    def get_DateCreated_field(self) -> Optional[int]:
        """
        Get data field value with field name 'DateCreated' from this record model
        """
        return self.get_field_value(self.DATECREATED__FIELD_NAME.field_name)

    def set_VeloxAgentConfigVersionId_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxAgentConfigVersionId' on this record model
        """
        self.set_field_value(self.VELOXAGENTCONFIGVERSIONID__FIELD_NAME.field_name, value)

    def get_VeloxAgentConfigVersionId_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxAgentConfigVersionId' from this record model
        """
        return self.get_field_value(self.VELOXAGENTCONFIGVERSIONID__FIELD_NAME.field_name)

    def set_VeloxDescriptiveStatus_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxDescriptiveStatus' on this record model
        """
        self.set_field_value(self.VELOXDESCRIPTIVESTATUS__FIELD_NAME.field_name, value)

    def get_VeloxDescriptiveStatus_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxDescriptiveStatus' from this record model
        """
        return self.get_field_value(self.VELOXDESCRIPTIVESTATUS__FIELD_NAME.field_name)

    def set_VeloxDuration_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxDuration' on this record model
        """
        self.set_field_value(self.VELOXDURATION__FIELD_NAME.field_name, value)

    def get_VeloxDuration_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxDuration' from this record model
        """
        return self.get_field_value(self.VELOXDURATION__FIELD_NAME.field_name)

    def set_VeloxDurationDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxDurationDate' on this record model
        """
        self.set_field_value(self.VELOXDURATIONDATE__FIELD_NAME.field_name, value)

    def get_VeloxDurationDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxDurationDate' from this record model
        """
        return self.get_field_value(self.VELOXDURATIONDATE__FIELD_NAME.field_name)

    def set_VeloxEndDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxEndDate' on this record model
        """
        self.set_field_value(self.VELOXENDDATE__FIELD_NAME.field_name, value)

    def get_VeloxEndDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxEndDate' from this record model
        """
        return self.get_field_value(self.VELOXENDDATE__FIELD_NAME.field_name)

    def set_VeloxExecutionProfile_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxExecutionProfile' on this record model
        """
        self.set_field_value(self.VELOXEXECUTIONPROFILE__FIELD_NAME.field_name, value)

    def get_VeloxExecutionProfile_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxExecutionProfile' from this record model
        """
        return self.get_field_value(self.VELOXEXECUTIONPROFILE__FIELD_NAME.field_name)

    def set_VeloxFailureReason_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxFailureReason' on this record model
        """
        self.set_field_value(self.VELOXFAILUREREASON__FIELD_NAME.field_name, value)

    def get_VeloxFailureReason_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxFailureReason' from this record model
        """
        return self.get_field_value(self.VELOXFAILUREREASON__FIELD_NAME.field_name)

    def set_VeloxIsFailed_field(self, value: Optional[bool]):
        """
        Set data field with field name 'VeloxIsFailed' on this record model
        """
        self.set_field_value(self.VELOXISFAILED__FIELD_NAME.field_name, value)

    def get_VeloxIsFailed_field(self) -> Optional[bool]:
        """
        Get data field value with field name 'VeloxIsFailed' from this record model
        """
        return self.get_field_value(self.VELOXISFAILED__FIELD_NAME.field_name)

    def get_VeloxLastModifiedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxLastModifiedBy' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDBY__FIELD_NAME.field_name)

    def get_VeloxLastModifiedDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxLastModifiedDate' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDDATE__FIELD_NAME.field_name)

    def set_VeloxPipelineGroupLink_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxPipelineGroupLink' on this record model
        """
        self.set_field_value(self.VELOXPIPELINEGROUPLINK__FIELD_NAME.field_name, value)

    def get_VeloxPipelineGroupLink_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxPipelineGroupLink' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINEGROUPLINK__FIELD_NAME.field_name)

    def set_VeloxPipelineStepTemplateId_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxPipelineStepTemplateId' on this record model
        """
        self.set_field_value(self.VELOXPIPELINESTEPTEMPLATEID__FIELD_NAME.field_name, value)

    def get_VeloxPipelineStepTemplateId_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxPipelineStepTemplateId' from this record model
        """
        return self.get_field_value(self.VELOXPIPELINESTEPTEMPLATEID__FIELD_NAME.field_name)

    def set_VeloxProcessedItemCount_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxProcessedItemCount' on this record model
        """
        self.set_field_value(self.VELOXPROCESSEDITEMCOUNT__FIELD_NAME.field_name, value)

    def get_VeloxProcessedItemCount_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxProcessedItemCount' from this record model
        """
        return self.get_field_value(self.VELOXPROCESSEDITEMCOUNT__FIELD_NAME.field_name)

    def set_VeloxStartDate_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxStartDate' on this record model
        """
        self.set_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name, value)

    def get_VeloxStartDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxStartDate' from this record model
        """
        return self.get_field_value(self.VELOXSTARTDATE__FIELD_NAME.field_name)

    def set_VeloxStepStatus_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxStepStatus' on this record model
        """
        self.set_field_value(self.VELOXSTEPSTATUS__FIELD_NAME.field_name, value)

    def get_VeloxStepStatus_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxStepStatus' from this record model
        """
        return self.get_field_value(self.VELOXSTEPSTATUS__FIELD_NAME.field_name)

    def set_VeloxStepSummary_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxStepSummary' on this record model
        """
        self.set_field_value(self.VELOXSTEPSUMMARY__FIELD_NAME.field_name, value)

    def get_VeloxStepSummary_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxStepSummary' from this record model
        """
        return self.get_field_value(self.VELOXSTEPSUMMARY__FIELD_NAME.field_name)

    def set_VeloxStepTemplateName_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxStepTemplateName' on this record model
        """
        self.set_field_value(self.VELOXSTEPTEMPLATENAME__FIELD_NAME.field_name, value)

    def get_VeloxStepTemplateName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxStepTemplateName' from this record model
        """
        return self.get_field_value(self.VELOXSTEPTEMPLATENAME__FIELD_NAME.field_name)

    def set_VeloxStepType_field(self, value: Optional[str]):
        """
        Set data field with field name 'VeloxStepType' on this record model
        """
        self.set_field_value(self.VELOXSTEPTYPE__FIELD_NAME.field_name, value)

    def get_VeloxStepType_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxStepType' from this record model
        """
        return self.get_field_value(self.VELOXSTEPTYPE__FIELD_NAME.field_name)

    def set_VeloxTokenCost_field(self, value: Optional[float]):
        """
        Set data field with field name 'VeloxTokenCost' on this record model
        """
        self.set_field_value(self.VELOXTOKENCOST__FIELD_NAME.field_name, value)

    def get_VeloxTokenCost_field(self) -> Optional[float]:
        """
        Get data field value with field name 'VeloxTokenCost' from this record model
        """
        return self.get_field_value(self.VELOXTOKENCOST__FIELD_NAME.field_name)

    def set_VeloxTotalItemCount_field(self, value: Optional[int]):
        """
        Set data field with field name 'VeloxTotalItemCount' on this record model
        """
        self.set_field_value(self.VELOXTOTALITEMCOUNT__FIELD_NAME.field_name, value)

    def get_VeloxTotalItemCount_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxTotalItemCount' from this record model
        """
        return self.get_field_value(self.VELOXTOTALITEMCOUNT__FIELD_NAME.field_name)


class VeloxPipelineStepOutputRecordModel(WrappedRecordModel):
    """
    Auto-Generated Record Model Wrapper for data type VeloxPipelineStepOutputRecord
    Data Type Display Name: Pipeline Step Output Record (Pipeline Step Output Records)
    Fields: CreatedBy, DataRecordName, DateCreated, OutputDataTypeName, OutputRecordId, StepOutputIndex, VeloxLastModifiedBy, VeloxLastModifiedDate
    The data type used to store output records generated by pipeline steps.
    """
    DATA_TYPE_NAME: Final[str] = 'VeloxPipelineStepOutputRecord'
    DISPLAY_NAME: Final[str] = "Pipeline Step Output Record"
    PLURAL_DISPLAY_NAME: Final[str] = "Pipeline Step Output Records"
    CREATEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("CreatedBy", FieldType.STRING, display_name="Created By")
    DATARECORDNAME__FIELD_NAME: Final[WrapperField] = WrapperField("DataRecordName", FieldType.IDENTIFIER, display_name="ID")
    DATECREATED__FIELD_NAME: Final[WrapperField] = WrapperField("DateCreated", FieldType.DATE, display_name="Date Created")
    OUTPUTDATATYPENAME__FIELD_NAME: Final[WrapperField] = WrapperField("OutputDataTypeName", FieldType.STRING, display_name="Output Data Type Name")
    OUTPUTRECORDID__FIELD_NAME: Final[WrapperField] = WrapperField("OutputRecordId", FieldType.LONG, display_name="Output Record ID")
    STEPOUTPUTINDEX__FIELD_NAME: Final[WrapperField] = WrapperField("StepOutputIndex", FieldType.SHORT, display_name="Output Index")
    VELOXLASTMODIFIEDBY__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedBy", FieldType.STRING, display_name="Last Modified By")
    VELOXLASTMODIFIEDDATE__FIELD_NAME: Final[WrapperField] = WrapperField("VeloxLastModifiedDate", FieldType.DATE, display_name="Last Modified Date")

    @classmethod
    def get_wrapper_data_type_name(cls):
        return cls.DATA_TYPE_NAME

    def get_CreatedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'CreatedBy' from this record model
        """
        return self.get_field_value(self.CREATEDBY__FIELD_NAME.field_name)

    def get_DataRecordName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'DataRecordName' from this record model
        """
        return self.get_field_value(self.DATARECORDNAME__FIELD_NAME.field_name)

    def get_DateCreated_field(self) -> Optional[int]:
        """
        Get data field value with field name 'DateCreated' from this record model
        """
        return self.get_field_value(self.DATECREATED__FIELD_NAME.field_name)

    def set_OutputDataTypeName_field(self, value: Optional[str]):
        """
        Set data field with field name 'OutputDataTypeName' on this record model
        """
        self.set_field_value(self.OUTPUTDATATYPENAME__FIELD_NAME.field_name, value)

    def get_OutputDataTypeName_field(self) -> Optional[str]:
        """
        Get data field value with field name 'OutputDataTypeName' from this record model
        """
        return self.get_field_value(self.OUTPUTDATATYPENAME__FIELD_NAME.field_name)

    def set_OutputRecordId_field(self, value: Optional[int]):
        """
        Set data field with field name 'OutputRecordId' on this record model
        """
        self.set_field_value(self.OUTPUTRECORDID__FIELD_NAME.field_name, value)

    def get_OutputRecordId_field(self) -> Optional[int]:
        """
        Get data field value with field name 'OutputRecordId' from this record model
        """
        return self.get_field_value(self.OUTPUTRECORDID__FIELD_NAME.field_name)

    def set_StepOutputIndex_field(self, value: Optional[int]):
        """
        Set data field with field name 'StepOutputIndex' on this record model
        """
        self.set_field_value(self.STEPOUTPUTINDEX__FIELD_NAME.field_name, value)

    def get_StepOutputIndex_field(self) -> Optional[int]:
        """
        Get data field value with field name 'StepOutputIndex' from this record model
        """
        return self.get_field_value(self.STEPOUTPUTINDEX__FIELD_NAME.field_name)

    def get_VeloxLastModifiedBy_field(self) -> Optional[str]:
        """
        Get data field value with field name 'VeloxLastModifiedBy' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDBY__FIELD_NAME.field_name)

    def get_VeloxLastModifiedDate_field(self) -> Optional[int]:
        """
        Get data field value with field name 'VeloxLastModifiedDate' from this record model
        """
        return self.get_field_value(self.VELOXLASTMODIFIEDDATE__FIELD_NAME.field_name)
