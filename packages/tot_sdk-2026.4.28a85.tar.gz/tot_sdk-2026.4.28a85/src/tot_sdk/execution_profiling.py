from __future__ import annotations

import json
import os
import threading
import time
from dataclasses import dataclass
from typing import Any

import psutil
from pynvml import NVMLError, nvmlDeviceGetComputeRunningProcesses, nvmlDeviceGetCount, \
    nvmlDeviceGetGraphicsRunningProcesses, nvmlDeviceGetHandleByIndex, nvmlDeviceGetMemoryInfo, \
    nvmlDeviceGetUtilizationRates, nvmlInit, nvmlShutdown


def _round_float(value: float | None) -> float | None:
    return None if value is None else round(value, 3)


def _format_bytes(value: int | None) -> str | None:
    if value is None:
        return None
    units: list[str] = ["B", "KiB", "MiB", "GiB", "TiB"]
    size: float = float(value)
    for unit in units:
        if size < 1024.0 or unit == units[-1]:
            if unit == "B":
                return f"{int(size)} {unit}"
            return f"{size:.2f} {unit}"
        size /= 1024.0
    return f"{size:.2f} TiB"


@dataclass(slots=True)
class ProcessExecutionProfile:
    runtime_seconds: float
    cpu_time_seconds: float | None = None
    cpu_percent_avg: float | None = None
    cpu_percent_peak: float | None = None
    memory_rss_bytes_avg: int | None = None
    memory_rss_bytes_peak: int | None = None
    gpu_memory_bytes_peak: int | None = None
    sampled_pid_count_peak: int = 0

    def to_json(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "runtime_seconds": _round_float(self.runtime_seconds),
            "cpu_time_seconds": _round_float(self.cpu_time_seconds),
            "cpu_percent_avg": _round_float(self.cpu_percent_avg),
            "cpu_percent_peak": _round_float(self.cpu_percent_peak),
            "memory_rss_bytes_avg": self.memory_rss_bytes_avg,
            "memory_rss_bytes_peak": self.memory_rss_bytes_peak,
            "gpu_memory_bytes_peak": self.gpu_memory_bytes_peak,
            "sampled_pid_count_peak": self.sampled_pid_count_peak,
        }
        return {key: value for key, value in payload.items() if value is not None}

    def to_str(self) -> str:
        parts: list[str] = [f"runtime={self.runtime_seconds:.3f}s"]
        if self.cpu_time_seconds is not None:
            parts.append(f"cpu_time={self.cpu_time_seconds:.3f}s")
        if self.cpu_percent_avg is not None:
            parts.append(f"cpu_avg={self.cpu_percent_avg:.1f}%")
        if self.cpu_percent_peak is not None:
            parts.append(f"cpu_peak={self.cpu_percent_peak:.1f}%")
        if self.memory_rss_bytes_peak is not None:
            parts.append(f"rss_peak={_format_bytes(self.memory_rss_bytes_peak)}")
        if self.gpu_memory_bytes_peak is not None:
            parts.append(f"gpu_mem_peak={_format_bytes(self.gpu_memory_bytes_peak)}")
        if self.sampled_pid_count_peak > 1:
            parts.append(f"pid_peak={self.sampled_pid_count_peak}")
        return "; ".join(parts)


@dataclass(slots=True)
class MachineExecutionProfile:
    cpu_percent_avg: float | None = None
    cpu_percent_peak: float | None = None
    memory_used_bytes_avg: int | None = None
    memory_used_bytes_peak: int | None = None
    memory_percent_avg: float | None = None
    memory_percent_peak: float | None = None
    gpu_device_util_percent_avg: float | None = None
    gpu_device_util_percent_peak: float | None = None
    gpu_memory_used_bytes_avg: int | None = None
    gpu_memory_used_bytes_peak: int | None = None

    def to_json(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "cpu_percent_avg": _round_float(self.cpu_percent_avg),
            "cpu_percent_peak": _round_float(self.cpu_percent_peak),
            "memory_used_bytes_avg": self.memory_used_bytes_avg,
            "memory_used_bytes_peak": self.memory_used_bytes_peak,
            "memory_percent_avg": _round_float(self.memory_percent_avg),
            "memory_percent_peak": _round_float(self.memory_percent_peak),
            "gpu_device_util_percent_avg": _round_float(self.gpu_device_util_percent_avg),
            "gpu_device_util_percent_peak": _round_float(self.gpu_device_util_percent_peak),
            "gpu_memory_used_bytes_avg": self.gpu_memory_used_bytes_avg,
            "gpu_memory_used_bytes_peak": self.gpu_memory_used_bytes_peak,
        }
        return {key: value for key, value in payload.items() if value is not None}

    def to_str(self) -> str:
        parts: list[str] = []
        if self.cpu_percent_avg is not None:
            parts.append(f"cpu_avg={self.cpu_percent_avg:.1f}%")
        if self.cpu_percent_peak is not None:
            parts.append(f"cpu_peak={self.cpu_percent_peak:.1f}%")
        if self.memory_used_bytes_peak is not None:
            parts.append(f"mem_used_peak={_format_bytes(self.memory_used_bytes_peak)}")
        if self.memory_percent_peak is not None:
            parts.append(f"mem_pct_peak={self.memory_percent_peak:.1f}%")
        if self.gpu_device_util_percent_avg is not None:
            parts.append(f"gpu_avg={self.gpu_device_util_percent_avg:.1f}%")
        if self.gpu_device_util_percent_peak is not None:
            parts.append(f"gpu_peak={self.gpu_device_util_percent_peak:.1f}%")
        if self.gpu_memory_used_bytes_peak is not None:
            parts.append(f"gpu_mem_used_peak={_format_bytes(self.gpu_memory_used_bytes_peak)}")
        return "; ".join(parts)


@dataclass(slots=True)
class ExecutionProfile:
    process: ProcessExecutionProfile
    machine: MachineExecutionProfile

    def to_json(self) -> dict[str, Any]:
        return {
            "machine": self.machine.to_json(),
            "process": self.process.to_json(),
        }

    def to_json_str(self) -> str:
        return json.dumps(self.to_json(), sort_keys=True)

    def to_str(self) -> str:
        parts: list[str] = [f"process[{self.process.to_str()}]"]
        machine_summary: str = self.machine.to_str()
        if machine_summary:
            parts.append(f"machine[{machine_summary}]")
        return "; ".join(parts)


class ProcessTreeProfiler:
    """Sample CPU, memory, and best-effort GPU metrics for the current process tree."""

    sample_interval_seconds: float
    include_gpu: bool
    root_pid: int

    _lock: threading.Lock
    _stop_event: threading.Event
    _thread: threading.Thread | None
    _start_time: float | None
    _last_sample_time: float | None
    _registered_pids: set[int]
    _known_cpu_seconds: dict[int, float]

    _cpu_time_seconds_total: float
    _cpu_percent_sum: float
    _cpu_percent_samples: int
    _cpu_percent_peak: float

    _memory_rss_sum: int
    _memory_samples: int
    _memory_rss_peak: int

    _gpu_memory_peak: int
    _gpu_util_sum: float
    _gpu_util_samples: int
    _gpu_util_peak: float

    _sampled_pid_count_peak: int

    _machine_cpu_percent_sum: float
    _machine_cpu_percent_samples: int
    _machine_cpu_percent_peak: float
    _machine_memory_used_sum: int
    _machine_memory_used_samples: int
    _machine_memory_used_peak: int
    _machine_memory_percent_sum: float
    _machine_memory_percent_samples: int
    _machine_memory_percent_peak: float
    _machine_gpu_util_sum: float
    _machine_gpu_util_samples: int
    _machine_gpu_util_peak: float
    _machine_gpu_memory_used_sum: int
    _machine_gpu_memory_used_samples: int
    _machine_gpu_memory_used_peak: int

    _nvml_initialized: bool
    _nvml_disabled: bool

    def __init__(self, sample_interval_seconds: float = 0.1, include_gpu: bool = False) -> None:
        self.sample_interval_seconds = sample_interval_seconds
        self.include_gpu = include_gpu
        self.root_pid = os.getpid()

        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread = None
        self._start_time = None
        self._last_sample_time = None
        self._registered_pids = set()
        self._known_cpu_seconds = {}

        self._cpu_time_seconds_total = 0.0
        self._cpu_percent_sum = 0.0
        self._cpu_percent_samples = 0
        self._cpu_percent_peak = 0.0

        self._memory_rss_sum = 0
        self._memory_samples = 0
        self._memory_rss_peak = 0

        self._gpu_memory_peak = 0
        self._gpu_util_sum = 0.0
        self._gpu_util_samples = 0
        self._gpu_util_peak = 0.0

        self._sampled_pid_count_peak = 0

        self._machine_cpu_percent_sum = 0.0
        self._machine_cpu_percent_samples = 0
        self._machine_cpu_percent_peak = 0.0
        self._machine_memory_used_sum = 0
        self._machine_memory_used_samples = 0
        self._machine_memory_used_peak = 0
        self._machine_memory_percent_sum = 0.0
        self._machine_memory_percent_samples = 0
        self._machine_memory_percent_peak = 0.0
        self._machine_gpu_util_sum = 0.0
        self._machine_gpu_util_samples = 0
        self._machine_gpu_util_peak = 0.0
        self._machine_gpu_memory_used_sum = 0
        self._machine_gpu_memory_used_samples = 0
        self._machine_gpu_memory_used_peak = 0

        self._nvml_initialized = False
        self._nvml_disabled = not include_gpu or nvmlInit is None

    def start(self) -> None:
        if self._thread is not None:
            return
        self._start_time = time.perf_counter()
        self._sample(initial=True)
        self._thread = threading.Thread(target=self._run, name="ProcessTreeProfiler", daemon=True)
        self._thread.start()

    def stop(self) -> ExecutionProfile:
        if self._start_time is None:
            self._start_time = time.perf_counter()
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join()
        self._sample()
        runtime_seconds: float = max(time.perf_counter() - self._start_time, 0.0)

        if self._nvml_initialized:
            try:
                nvmlShutdown()
            except NVMLError:
                pass
            self._nvml_initialized = False

        memory_avg: int | None = None
        if self._memory_samples:
            memory_avg = int(self._memory_rss_sum / self._memory_samples)

        cpu_avg: float | None = None
        if self._cpu_percent_samples:
            cpu_avg = self._cpu_percent_sum / self._cpu_percent_samples

        machine_cpu_avg: float | None = None
        if self._machine_cpu_percent_samples:
            machine_cpu_avg = self._machine_cpu_percent_sum / self._machine_cpu_percent_samples

        machine_memory_used_avg: int | None = None
        if self._machine_memory_used_samples:
            machine_memory_used_avg = int(self._machine_memory_used_sum / self._machine_memory_used_samples)

        machine_memory_percent_avg: float | None = None
        if self._machine_memory_percent_samples:
            machine_memory_percent_avg = self._machine_memory_percent_sum / self._machine_memory_percent_samples

        machine_gpu_util_avg: float | None = None
        if self._machine_gpu_util_samples:
            machine_gpu_util_avg = self._machine_gpu_util_sum / self._machine_gpu_util_samples

        machine_gpu_memory_used_avg: int | None = None
        if self._machine_gpu_memory_used_samples:
            machine_gpu_memory_used_avg = int(
                self._machine_gpu_memory_used_sum / self._machine_gpu_memory_used_samples
            )

        return ExecutionProfile(
            process=ProcessExecutionProfile(
                runtime_seconds=runtime_seconds,
                cpu_time_seconds=self._cpu_time_seconds_total,
                cpu_percent_avg=cpu_avg,
                cpu_percent_peak=self._cpu_percent_peak,
                memory_rss_bytes_avg=memory_avg,
                memory_rss_bytes_peak=self._memory_rss_peak,
                gpu_memory_bytes_peak=self._gpu_memory_peak or None,
                sampled_pid_count_peak=self._sampled_pid_count_peak,
            ),
            machine=MachineExecutionProfile(
                cpu_percent_avg=machine_cpu_avg,
                cpu_percent_peak=self._machine_cpu_percent_peak if self._machine_cpu_percent_samples else None,
                memory_used_bytes_avg=machine_memory_used_avg,
                memory_used_bytes_peak=self._machine_memory_used_peak if self._machine_memory_used_samples else None,
                memory_percent_avg=machine_memory_percent_avg,
                memory_percent_peak=(
                    self._machine_memory_percent_peak if self._machine_memory_percent_samples else None
                ),
                gpu_device_util_percent_avg=machine_gpu_util_avg,
                gpu_device_util_percent_peak=(
                    self._machine_gpu_util_peak if self._machine_gpu_util_samples else None
                ),
                gpu_memory_used_bytes_avg=machine_gpu_memory_used_avg,
                gpu_memory_used_bytes_peak=(
                    self._machine_gpu_memory_used_peak if self._machine_gpu_memory_used_samples else None
                ),
            ),
        )

    def register_subprocess(self, pid: int) -> None:
        with self._lock:
            self._registered_pids.add(pid)
            # Child processes are created after the profiler starts, so count their full CPU time on first sample.
            self._known_cpu_seconds.setdefault(pid, 0.0)

    def _run(self) -> None:
        while not self._stop_event.wait(self.sample_interval_seconds):
            self._sample()

    def _sample(self, initial: bool = False) -> None:
        with self._lock:
            now: float = time.perf_counter()
            processes: dict[int, psutil.Process] = self._get_live_processes()
            self._sampled_pid_count_peak = max(self._sampled_pid_count_peak, len(processes))

            total_rss: int = 0
            cpu_delta_seconds: float = 0.0

            for pid, process in processes.items():
                try:
                    cpu_seconds: float = self._get_cpu_seconds(process)
                    rss_bytes: int = process.memory_info().rss
                except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                    continue

                previous_cpu_seconds: float | None = self._known_cpu_seconds.get(pid)
                if not initial:
                    if previous_cpu_seconds is None:
                        cpu_delta_seconds += cpu_seconds
                    else:
                        cpu_delta_seconds += max(cpu_seconds - previous_cpu_seconds, 0.0)
                self._known_cpu_seconds[pid] = cpu_seconds
                total_rss += rss_bytes

            if not initial and self._last_sample_time is not None:
                elapsed_seconds: float = max(now - self._last_sample_time, 1e-9)
                cpu_percent: float = cpu_delta_seconds / elapsed_seconds * 100.0
                self._cpu_time_seconds_total += cpu_delta_seconds
                self._cpu_percent_sum += cpu_percent
                self._cpu_percent_samples += 1
                self._cpu_percent_peak = max(self._cpu_percent_peak, cpu_percent)

            self._memory_rss_sum += total_rss
            self._memory_samples += 1
            self._memory_rss_peak = max(self._memory_rss_peak, total_rss)
            self._last_sample_time = now

            self._sample_machine_metrics(initial)
            self._sample_gpu_metrics(set(processes))

    def _get_live_processes(self) -> dict[int, psutil.Process]:
        live_processes: dict[int, psutil.Process] = {}
        candidate_pids: set[int] = {self.root_pid}
        candidate_pids.update(self._registered_pids)

        try:
            root_process = psutil.Process(self.root_pid)
            live_processes[self.root_pid] = root_process
            for child in root_process.children(recursive=True):
                live_processes[child.pid] = child
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            pass

        for pid in candidate_pids:
            if pid in live_processes:
                continue
            try:
                live_processes[pid] = psutil.Process(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
        return live_processes

    @staticmethod
    def _get_cpu_seconds(process: psutil.Process) -> float:
        cpu_times = process.cpu_times()
        return float(cpu_times.user + cpu_times.system)

    def _sample_machine_metrics(self, initial: bool) -> None:
        machine_memory = psutil.virtual_memory()
        self._machine_memory_used_sum += machine_memory.used
        self._machine_memory_used_samples += 1
        self._machine_memory_used_peak = max(self._machine_memory_used_peak, machine_memory.used)
        self._machine_memory_percent_sum += machine_memory.percent
        self._machine_memory_percent_samples += 1
        self._machine_memory_percent_peak = max(self._machine_memory_percent_peak, float(machine_memory.percent))

        machine_cpu_percent: float = float(psutil.cpu_percent(interval=None))
        if initial:
            return
        self._machine_cpu_percent_sum += machine_cpu_percent
        self._machine_cpu_percent_samples += 1
        self._machine_cpu_percent_peak = max(self._machine_cpu_percent_peak, machine_cpu_percent)

    def _sample_gpu_metrics(self, process_pids: set[int]) -> None:
        if self._nvml_disabled:
            return

        if not self._nvml_initialized:
            try:
                nvmlInit()
                self._nvml_initialized = True
            except NVMLError:
                self._nvml_disabled = True
                return

        total_gpu_memory: int = 0
        machine_device_utils: list[float] = []
        machine_total_gpu_memory_used: int = 0
        try:
            device_count: int = nvmlDeviceGetCount()
        except NVMLError:
            self._nvml_disabled = True
            return

        process_getters = [nvmlDeviceGetComputeRunningProcesses]
        if nvmlDeviceGetGraphicsRunningProcesses is not None:
            process_getters.append(nvmlDeviceGetGraphicsRunningProcesses)

        for device_index in range(device_count):
            try:
                handle = nvmlDeviceGetHandleByIndex(device_index)
            except NVMLError:
                continue

            try:
                utilization = nvmlDeviceGetUtilizationRates(handle)
                machine_device_utils.append(float(utilization.gpu))
            except NVMLError:
                pass

            try:
                memory_info = nvmlDeviceGetMemoryInfo(handle)
                machine_total_gpu_memory_used += int(memory_info.used)
            except NVMLError:
                pass

            for getter in process_getters:
                if getter is None:
                    continue
                try:
                    running_processes = getter(handle)
                except NVMLError:
                    continue
                for process in running_processes:
                    pid: int | None = getattr(process, "pid", None)
                    if pid not in process_pids:
                        continue
                    used_gpu_memory: int | None = getattr(process, "usedGpuMemory", None)
                    if isinstance(used_gpu_memory, int) and used_gpu_memory >= 0:
                        total_gpu_memory += used_gpu_memory

        if total_gpu_memory:
            self._gpu_memory_peak = max(self._gpu_memory_peak, total_gpu_memory)
        if machine_device_utils:
            sample_util: float = sum(machine_device_utils) / len(machine_device_utils)
            self._machine_gpu_util_sum += sample_util
            self._machine_gpu_util_samples += 1
            self._machine_gpu_util_peak = max(self._machine_gpu_util_peak, sample_util)
        if device_count > 0:
            self._machine_gpu_memory_used_sum += machine_total_gpu_memory_used
            self._machine_gpu_memory_used_samples += 1
            self._machine_gpu_memory_used_peak = max(
                self._machine_gpu_memory_used_peak,
                machine_total_gpu_memory_used,
            )
