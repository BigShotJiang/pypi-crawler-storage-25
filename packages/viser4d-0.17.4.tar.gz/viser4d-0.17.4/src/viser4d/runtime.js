"use strict";
(() => {
  // audio/messages.ts
  function isAudioMessage(message) {
    return message.type === "AddAudioMessage" || message.type === "SetAudioVolumeMessage" || message.type === "SetAudioWaveformMessage" || message.type === "AppendAudioMessage" || message.type === "RemoveAudioMessage";
  }

  // binary.ts
  function decodeBase64Bytes(base64Text) {
    const binary = atob(base64Text);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes;
  }
  function decodeAudioArray(payload) {
    const buffer = decodeBase64Bytes(payload.data).buffer;
    switch (payload.dtype) {
      case "int16":
        return new Int16Array(buffer);
      case "int32":
        return new Int32Array(buffer);
      case "float64":
        return new Float64Array(buffer);
      case "float32":
        return new Float32Array(buffer);
      case "uint8":
        return new Uint8Array(buffer);
      default:
        return new Int16Array(buffer);
    }
  }
  function samplesToFloat32(samples) {
    if (samples instanceof Float32Array) {
      return samples;
    }
    if (samples instanceof Float64Array) {
      return Float32Array.from(samples);
    }
    if (samples instanceof Int16Array) {
      const out = new Float32Array(samples.length);
      for (let i = 0; i < samples.length; i += 1) {
        out[i] = (samples[i] ?? 0) / 32768;
      }
      return out;
    }
    if (samples instanceof Int32Array) {
      const out = new Float32Array(samples.length);
      for (let i = 0; i < samples.length; i += 1) {
        out[i] = (samples[i] ?? 0) / 2147483648;
      }
      return out;
    }
    if (samples instanceof Uint8Array) {
      const out = new Float32Array(samples.length);
      for (let i = 0; i < samples.length; i += 1) {
        out[i] = ((samples[i] ?? 128) - 128) / 128;
      }
      return out;
    }
    return Float32Array.from(samples);
  }
  function decodeAudioWaveform(payload) {
    const flat = samplesToFloat32(decodeAudioArray(payload));
    const channels = [];
    for (let channel = 0; channel < payload.numChannels; channel += 1) {
      const out = new Float32Array(payload.numFrames);
      for (let frame = 0; frame < payload.numFrames; frame += 1) {
        out[frame] = flat[frame * payload.numChannels + channel] ?? 0;
      }
      channels.push(out);
    }
    return channels;
  }

  // bridge/protocol.ts
  function isObjectRecord(value) {
    return !!value && typeof value === "object";
  }
  function isViewerLike(value) {
    return isObjectRecord(value) && isObjectRecord(value.mutable) && "useGuiConfig" in value && "guiActions" in value && "useSceneTree" in value;
  }
  function getReactRoot() {
    const root = document.getElementById("root");
    if (!root) {
      throw new Error("[viser4d] Could not find #root while locating the viewer.");
    }
    const rootRecord = root;
    if (!isObjectRecord(rootRecord)) {
      throw new Error("[viser4d] React root is not an object while locating the viewer.");
    }
    const containerKey = Object.keys(rootRecord).find(
      (key) => key.startsWith("__reactContainer$")
    );
    const reactRoot = containerKey ? rootRecord[containerKey] : null;
    if (!isObjectRecord(reactRoot)) {
      throw new Error("[viser4d] Could not find the React container while locating the viewer.");
    }
    return reactRoot;
  }
  function findFiber(predicate) {
    const seen = /* @__PURE__ */ new Set();
    const stack = [getReactRoot()];
    while (stack.length) {
      const fiber = stack.pop();
      if (!fiber || seen.has(fiber)) {
        continue;
      }
      seen.add(fiber);
      if (predicate(fiber)) {
        return fiber;
      }
      if (fiber.child) {
        stack.push(fiber.child);
      }
      if (fiber.sibling) {
        stack.push(fiber.sibling);
      }
    }
    return null;
  }
  function getWindow() {
    return window;
  }
  function findViewer() {
    const fiber = findFiber((candidate) => isViewerLike(candidate.memoizedProps?.value));
    if (fiber) {
      return fiber.memoizedProps.value;
    }
    throw new Error("[viser4d] Could not locate the viewer in the React fiber tree.");
  }
  function findPlaybackTimeSlider() {
    return document.querySelector("[role='slider'][aria-valuenow]");
  }

  // audio/runtime.ts
  function makeTrackState(step, sampleRate = 44100) {
    return {
      channels: 1,
      sampleRate,
      waveform: [new Float32Array(0)],
      volume: 1,
      startStep: step,
      removed: false
    };
  }
  function getMessageSampleRate(message) {
    return message.type === "AddAudioMessage" ? message.sampleRate : void 0;
  }
  function mergeTrackState(base, override) {
    if (!base && !override) {
      return null;
    }
    if (!base) {
      if (!override?.waveform || override.sampleRate == null) {
        return null;
      }
      return {
        channels: override.channels ?? override.waveform.length,
        sampleRate: override.sampleRate,
        waveform: override.waveform,
        volume: override.volume ?? 1,
        startStep: override.startStep ?? 0,
        removed: override.removed ?? false
      };
    }
    if (!override) {
      return base;
    }
    return {
      channels: override.channels ?? base.channels,
      sampleRate: override.sampleRate ?? base.sampleRate,
      waveform: override.waveform ?? base.waveform,
      volume: override.volume ?? base.volume,
      startStep: override.startStep ?? base.startStep,
      removed: override.removed ?? base.removed
    };
  }
  function appendWaveforms(head, tail) {
    return head.map((samples, channel) => {
      const merged = new Float32Array(samples.length + (tail[channel]?.length ?? 0));
      merged.set(samples, 0);
      merged.set(tail[channel] ?? new Float32Array(0), samples.length);
      return merged;
    });
  }
  function trackFrameCount(track) {
    return track.waveform[0]?.length ?? 0;
  }
  var AudioRuntime = class {
    constructor(getTransportStep, debugPush) {
      this.getTransportStep = getTransportStep;
      this.debugPush = debugPush;
      this.ctx = null;
      this.timelineTracks = /* @__PURE__ */ new Map();
      this.liveOverrides = /* @__PURE__ */ new Map();
      this.runtimeTracks = /* @__PURE__ */ new Map();
      this.playing = false;
      this.currentStep = 0;
      this.fps = 30;
      this.stepRate = 30;
      this.nextSourceToken = 1;
    }
    ensureContext() {
      if (!this.ctx) {
        const AudioContextClass = getWindow().AudioContext || getWindow().webkitAudioContext;
        this.ctx = AudioContextClass ? new AudioContextClass() : null;
      }
      return this.ctx;
    }
    getPlaybackStep() {
      return this.playing ? this.getTransportStep() : this.currentStep;
    }
    getTrackNames() {
      return /* @__PURE__ */ new Set([
        ...this.timelineTracks.keys(),
        ...this.liveOverrides.keys(),
        ...this.runtimeTracks.keys()
      ]);
    }
    getEffectiveTrack(name) {
      const timelineTrack = this.timelineTracks.get(name);
      const liveOverride = this.liveOverrides.get(name);
      return mergeTrackState(timelineTrack, liveOverride);
    }
    getRuntimeTrack(name) {
      const runtimeTrack = this.runtimeTracks.get(name);
      if (runtimeTrack) {
        return runtimeTrack;
      }
      const created = {
        source: null,
        gain: null,
        buffer: null,
        bufferWaveform: null,
        bufferSampleRate: null,
        token: 0
      };
      this.runtimeTracks.set(name, created);
      return created;
    }
    setStepRate(stepRate) {
      this.stepRate = Math.max(1e-6, stepRate || this.stepRate || 30);
    }
    buildBuffer(track, runtimeTrack) {
      const ctx = this.ensureContext();
      if (!ctx) {
        return null;
      }
      if (runtimeTrack.buffer && runtimeTrack.bufferWaveform === track.waveform && runtimeTrack.bufferSampleRate === track.sampleRate) {
        return runtimeTrack.buffer;
      }
      const buffer = ctx.createBuffer(track.channels, trackFrameCount(track), track.sampleRate);
      for (let channel = 0; channel < track.channels; channel += 1) {
        buffer.copyToChannel(
          new Float32Array(track.waveform[channel] ?? new Float32Array(0)),
          channel
        );
      }
      runtimeTrack.buffer = buffer;
      runtimeTrack.bufferWaveform = track.waveform;
      runtimeTrack.bufferSampleRate = track.sampleRate;
      return buffer;
    }
    applyOp(target, step, message, partial) {
      const next = target ?? (partial ? {} : makeTrackState(step, getMessageSampleRate(message)));
      let effect = "none";
      switch (message.type) {
        case "AddAudioMessage":
          next.sampleRate = message.sampleRate;
          next.channels = message.waveform.numChannels;
          next.waveform = decodeAudioWaveform(message.waveform);
          next.volume = message.volume;
          next.startStep = step;
          next.removed = false;
          effect = "reschedule";
          break;
        case "SetAudioVolumeMessage":
          next.volume = message.volume;
          effect = "volume";
          break;
        case "SetAudioWaveformMessage":
          next.channels = message.waveform.numChannels;
          next.waveform = decodeAudioWaveform(message.waveform);
          next.removed = false;
          effect = "reschedule";
          break;
        case "AppendAudioMessage": {
          const tail = decodeAudioWaveform(message.waveform);
          next.channels = message.waveform.numChannels;
          next.waveform = next.waveform ? appendWaveforms(next.waveform, tail) : tail;
          effect = "reschedule";
          break;
        }
        case "RemoveAudioMessage":
          next.removed = true;
          effect = "reschedule";
          break;
      }
      return { track: next, effect };
    }
    applyOps(targetMap, step, messages, eventName, partial) {
      for (const message of messages) {
        const current = targetMap.get(message.name);
        const hasWaveform = current && "waveform" in current && current.waveform;
        const target = partial || hasWaveform ? current || null : makeTrackState(step, getMessageSampleRate(message));
        const result = this.applyOp(target, step, message, partial);
        targetMap.set(message.name, result.track);
        this.debugPush(eventName, {
          name: message.name,
          step,
          type: message.type,
          effect: result.effect
        });
        if (result.effect === "volume") {
          this.updateTrackVolume(message.name);
        } else if (result.effect === "reschedule") {
          this.reconcileTrack(message.name);
        }
      }
    }
    applyTimelineMessages(step, messages) {
      this.applyOps(
        this.timelineTracks,
        step,
        messages,
        "audio.timeline_message",
        false
      );
    }
    applyLiveMessages(step, messages) {
      this.applyOps(
        this.liveOverrides,
        step,
        messages,
        "audio.live_message",
        true
      );
    }
    updateTrackVolume(name) {
      const runtimeTrack = this.runtimeTracks.get(name);
      const effective = this.getEffectiveTrack(name);
      if (runtimeTrack?.gain && effective) {
        runtimeTrack.gain.gain.value = effective.volume;
      }
    }
    stopRuntimeTrack(runtimeTrack) {
      runtimeTrack.token += 1;
      if (runtimeTrack.source) {
        try {
          runtimeTrack.source.stop();
        } catch (error) {
          this.debugPush("audio.stop_error", {
            error: error instanceof Error ? error.message : String(error)
          });
        }
        runtimeTrack.source.disconnect();
        runtimeTrack.source = null;
      }
      if (runtimeTrack.gain) {
        runtimeTrack.gain.disconnect();
        runtimeTrack.gain = null;
      }
    }
    stopAllNodes() {
      for (const runtimeTrack of this.runtimeTracks.values()) {
        this.stopRuntimeTrack(runtimeTrack);
      }
    }
    getClipDurationSteps(track) {
      return trackFrameCount(track) / track.sampleRate * this.stepRate;
    }
    isTrackActiveAtStep(track, playbackStep) {
      return playbackStep >= track.startStep && playbackStep < track.startStep + this.getClipDurationSteps(track);
    }
    reconcileTrack(name) {
      const ctx = this.ensureContext();
      if (!ctx) {
        return;
      }
      const runtimeTrack = this.getRuntimeTrack(name);
      this.stopRuntimeTrack(runtimeTrack);
      if (!this.playing) {
        return;
      }
      if (typeof ctx.resume === "function" && ctx.state === "suspended") {
        ctx.resume().catch(() => {
        });
      }
      const track = this.getEffectiveTrack(name);
      if (!track || track.removed || !trackFrameCount(track)) {
        return;
      }
      const playbackStep = this.getPlaybackStep();
      const endStep = track.startStep + this.getClipDurationSteps(track);
      if (playbackStep >= endStep) {
        return;
      }
      const source = ctx.createBufferSource();
      const gain = ctx.createGain();
      source.buffer = this.buildBuffer(track, runtimeTrack);
      if (!source.buffer) {
        return;
      }
      gain.gain.value = track.volume;
      source.playbackRate.value = this.fps / this.stepRate;
      source.connect(gain);
      gain.connect(ctx.destination);
      const token = ++this.nextSourceToken;
      runtimeTrack.token = token;
      source.onended = () => {
        if (runtimeTrack.token !== token) {
          return;
        }
        runtimeTrack.source = null;
        if (runtimeTrack.gain === gain) {
          runtimeTrack.gain.disconnect();
          runtimeTrack.gain = null;
        }
        const effective = this.getEffectiveTrack(name);
        if (this.playing && effective && !effective.removed && trackFrameCount(effective) && this.isTrackActiveAtStep(effective, this.getPlaybackStep())) {
          this.reconcileTrack(name);
        }
      };
      source.start(
        ctx.currentTime + Math.max(0, (track.startStep - playbackStep) / this.fps),
        Math.max(0, (playbackStep - track.startStep) / this.stepRate)
      );
      runtimeTrack.source = source;
      runtimeTrack.gain = gain;
    }
    rescheduleAll() {
      for (const name of this.getTrackNames()) {
        this.reconcileTrack(name);
      }
    }
    play(step, fps) {
      this.currentStep = step;
      this.fps = fps;
      this.playing = true;
      this.rescheduleAll();
    }
    pause(step, fps) {
      this.currentStep = step;
      this.fps = fps;
      this.playing = false;
      this.stopAllNodes();
    }
    seek(step, fps, playing) {
      this.currentStep = step;
      this.fps = fps;
      this.playing = playing;
      if (playing) {
        this.rescheduleAll();
        return;
      }
      this.stopAllNodes();
    }
    setFps(step, fps, playing) {
      this.currentStep = step;
      this.fps = fps;
      if (playing) {
        this.playing = true;
        this.rescheduleAll();
        return;
      }
      this.playing = false;
      this.stopAllNodes();
    }
    reset() {
      this.stopAllNodes();
      this.timelineTracks.clear();
      this.liveOverrides.clear();
      this.runtimeTracks.clear();
      this.playing = false;
      this.currentStep = 0;
      this.fps = 30;
      this.stepRate = 30;
      this.nextSourceToken = 1;
    }
    resetTimeline() {
      this.stopAllNodes();
      this.timelineTracks.clear();
      this.currentStep = 0;
    }
  };

  // bridge/filePlaybackAdapter.ts
  var FilePlaybackAdapter = class {
    constructor(readPlaybackTime, debugPush) {
      this.readPlaybackTime = readPlaybackTime;
      this.disposed = false;
      this.playbackTime = 0;
      this.playbackPlaying = false;
      this.playbackObserved = false;
      this.pendingMessages = [];
      this.syncScheduled = false;
      this.audio = new AudioRuntime(() => this.playbackTime, debugPush);
      this.audio.setStepRate(1);
    }
    dispose() {
      this.disposed = true;
      this.audio.reset();
      this.playbackTime = 0;
      this.playbackPlaying = false;
      this.playbackObserved = false;
      this.pendingMessages = [];
      this.syncScheduled = false;
    }
    enqueue(message) {
      if (this.disposed) {
        return;
      }
      this.pendingMessages.push(message);
      this.scheduleSync();
    }
    sync() {
      if (this.disposed) {
        return;
      }
      const nextTime = this.readPlaybackTime();
      if (nextTime === null) {
        return;
      }
      const delta = nextTime - this.playbackTime;
      const jumped = Math.abs(delta) > 0.2;
      const playing = delta > 1e-4;
      const playbackStateChanged = playing !== this.playbackPlaying;
      const pausedButMoved = !playing && Math.abs(delta) > 1e-4;
      if (!this.playbackObserved) {
        this.playbackObserved = true;
        this.playbackTime = nextTime;
        this.flushPendingMessages(nextTime);
        this.audio.seek(nextTime, 1, false);
        return;
      }
      if (delta < -1e-4) {
        this.audio.resetTimeline();
      }
      if (jumped) {
        this.audio.seek(nextTime, 1, playing);
      } else if (playbackStateChanged) {
        if (playing) {
          this.audio.play(nextTime, 1);
        } else {
          this.audio.pause(nextTime, 1);
        }
      } else if (pausedButMoved) {
        this.audio.seek(nextTime, 1, false);
      }
      this.playbackTime = nextTime;
      this.playbackPlaying = playing;
      this.flushPendingMessages(nextTime);
    }
    flushPendingMessages(playbackTime) {
      if (this.pendingMessages.length === 0) {
        return;
      }
      this.audio.applyLiveMessages(playbackTime, this.pendingMessages);
      this.pendingMessages = [];
    }
    scheduleSync() {
      if (this.syncScheduled) {
        return;
      }
      this.syncScheduled = true;
      getWindow().requestAnimationFrame(() => {
        if (this.disposed) {
          return;
        }
        this.syncScheduled = false;
        this.sync();
      });
    }
  };

  // bridge/blockState.ts
  function makeLoadedBlock(payload) {
    return {
      checkpoint: {
        sceneEntries: new Map(
          payload.checkpointSceneEntries.map((entry) => [entry.key, entry.message])
        ),
        audioEntries: audioMessageMap(payload.checkpointAudioMessages)
      },
      stepPatches: payload.stepPatches.map(makeLoadedStatePatch)
    };
  }
  function patchLoadedBlock(block, patch) {
    for (const key of patch.checkpointSceneDeletes) {
      block.checkpoint.sceneEntries.delete(key);
    }
    for (const entry of patch.checkpointScenePuts) {
      block.checkpoint.sceneEntries.set(entry.key, entry.message);
    }
    for (const name of patch.checkpointAudioDeletes) {
      block.checkpoint.audioEntries.delete(name);
    }
    for (const [name, message] of audioMessageMap(patch.checkpointAudioPuts)) {
      block.checkpoint.audioEntries.set(name, message);
    }
    for (const update of patch.stepPatchUpdates) {
      block.stepPatches[update.stepOffset] = makeLoadedStatePatch(update.patch);
    }
  }
  function materializeCheckpointMessages(checkpoint) {
    return [
      ...materializeSceneEntries(checkpoint.sceneEntries.values()),
      ...checkpoint.audioEntries.values()
    ];
  }
  function materializeStatePatchMessages(patch) {
    const sceneDeletes = patch.sceneDeleteNodes.map((name) => ({
      type: "RemoveSceneNodeMessage",
      name
    }));
    return [
      ...sceneDeletes,
      ...materializeSceneEntries(patch.scenePuts.values()),
      ...patch.audioMessages
    ];
  }
  function makeLoadedStatePatch(patch) {
    return {
      scenePuts: new Map(patch.scenePuts.map((entry) => [entry.key, entry.message])),
      sceneDeleteNodes: [...patch.sceneDeleteNodes],
      audioMessages: patch.audioMessages.filter(isAudioMessage)
    };
  }
  function audioMessageMap(messages) {
    const audioEntries = /* @__PURE__ */ new Map();
    for (const message of messages) {
      if (!isAudioMessage(message)) {
        continue;
      }
      audioEntries.set(message.name, message);
    }
    return audioEntries;
  }
  function materializeSceneEntries(messages) {
    const unnamedMessages = [];
    const nodeMessages = /* @__PURE__ */ new Map();
    for (const message of messages) {
      const name = extractMessageName(message);
      if (name === null) {
        unnamedMessages.push(message);
        continue;
      }
      const sceneMessages2 = nodeMessages.get(name) ?? [];
      sceneMessages2.push(message);
      nodeMessages.set(name, sceneMessages2);
    }
    const sceneMessages = [...unnamedMessages];
    const sortedNodeNames = Array.from(nodeMessages.keys()).sort(compareSceneNodeNames);
    for (const name of sortedNodeNames) {
      const messagesForNode = nodeMessages.get(name) ?? [];
      sceneMessages.push(...messagesForNode.filter(isCreateSceneNodeMessage));
      sceneMessages.push(
        ...messagesForNode.filter((message) => !isCreateSceneNodeMessage(message))
      );
    }
    return sceneMessages;
  }
  function compareSceneNodeNames(left, right) {
    const depthDifference = left.split("/").length - right.split("/").length;
    if (depthDifference !== 0) {
      return depthDifference;
    }
    return left.localeCompare(right);
  }
  function extractMessageName(message) {
    return typeof message.name === "string" && message.name.length > 0 ? message.name : null;
  }
  function isCreateSceneNodeMessage(message) {
    return "props" in message;
  }

  // bridge/preloadPlanner.ts
  function planPreload(currentBlock, manifests, budgetBytes, loaded) {
    const blockCount = manifests.length;
    if (blockCount === 0) {
      return { required: [], speculative: [], evictions: [] };
    }
    const focus = Math.max(0, Math.min(blockCount - 1, currentBlock));
    const required = [focus];
    let used = manifests[focus].payloadByteSize ?? 0;
    if (focus > 0) {
      required.push(focus - 1);
      used += manifests[focus - 1].payloadByteSize ?? 0;
    }
    const desired = new Set(required);
    const speculative = [];
    for (let offset = 1; offset < blockCount; offset += 1) {
      if (used >= budgetBytes) {
        break;
      }
      const index = (focus + offset) % blockCount;
      if (desired.has(index)) {
        continue;
      }
      const size = manifests[index].payloadByteSize;
      if (size === null) {
        speculative.push(index);
        desired.add(index);
        break;
      }
      if (used + size > budgetBytes) {
        break;
      }
      speculative.push(index);
      desired.add(index);
      used += size;
    }
    const evictions = [];
    for (const block of loaded.keys()) {
      if (!desired.has(block)) {
        evictions.push(block);
      }
    }
    evictions.sort((a, b) => a - b);
    return { required, speculative, evictions };
  }

  // bridge/blockCache.ts
  var BlockCache = class {
    constructor(io) {
      this.io = io;
      this.blockSize = 32;
      this.pendingStep = null;
      this.budgetBytes = 0;
      this.manifests = [];
      this.blocks = /* @__PURE__ */ new Map();
      this.pendingRequests = /* @__PURE__ */ new Set();
    }
    getBlock(step) {
      return this.blocks.get(this.blockIndexOf(step)) ?? null;
    }
    getBlockByIndex(blockIndex) {
      return this.blocks.get(blockIndex) ?? null;
    }
    hasBlockIndex(blockIndex) {
      return this.blocks.has(blockIndex);
    }
    blockIndexOf(step) {
      return Math.floor(step / this.blockSize);
    }
    blockStartStep(blockIndex) {
      return blockIndex * this.blockSize;
    }
    loadBlock(blockIndex, block) {
      this.pendingRequests.delete(blockIndex);
      this.blocks.set(blockIndex, makeLoadedBlock(block));
    }
    patchBlock(blockIndex, patch) {
      const block = this.blocks.get(blockIndex);
      if (!block) {
        return false;
      }
      patchLoadedBlock(block, patch);
      return true;
    }
    reset() {
      this.pendingStep = null;
      this.blocks.clear();
      this.pendingRequests.clear();
    }
    setManifests(manifests) {
      this.manifests = manifests;
    }
    setBudgetBytes(bytes) {
      this.budgetBytes = bytes;
    }
    syncCurrentBlock(currentBlock, appliedBlock = -1) {
      if (this.manifests.length === 0 || this.budgetBytes <= 0) {
        return;
      }
      const plan = planPreload(
        currentBlock,
        this.manifests,
        this.budgetBytes,
        this.blocks
      );
      const desired = /* @__PURE__ */ new Set([...plan.required, ...plan.speculative]);
      for (const blockIndex of [...this.pendingRequests]) {
        if (desired.has(blockIndex)) {
          continue;
        }
        this.pendingRequests.delete(blockIndex);
        this.io.discardBlock(blockIndex);
      }
      for (const blockIndex of plan.evictions) {
        if (blockIndex === appliedBlock) {
          continue;
        }
        this.blocks.delete(blockIndex);
        this.pendingRequests.delete(blockIndex);
        this.io.discardBlock(blockIndex);
      }
      let requiredInFlight = false;
      for (const blockIndex of plan.required) {
        if (this.blocks.has(blockIndex)) {
          continue;
        }
        requiredInFlight = true;
        if (!this.pendingRequests.has(blockIndex)) {
          this.issueRequest(blockIndex);
        }
      }
      if (requiredInFlight) {
        return;
      }
      for (const blockIndex of plan.speculative) {
        if (this.blocks.has(blockIndex)) {
          continue;
        }
        if (!this.pendingRequests.has(blockIndex)) {
          this.issueRequest(blockIndex);
        }
        return;
      }
    }
    ensureStepLoaded(step) {
      const blockIndex = this.blockIndexOf(step);
      if (this.blocks.has(blockIndex)) {
        return true;
      }
      this.pendingStep = step;
      if (!this.pendingRequests.has(blockIndex)) {
        this.issueRequest(blockIndex);
      }
      return false;
    }
    issueRequest(blockIndex) {
      this.pendingRequests.add(blockIndex);
      this.io.requestBlock(blockIndex);
    }
  };

  // bridge/generatedRuntimeMessages.ts
  var typeSetRuntimeControlMessage = /* @__PURE__ */ new Set(["RuntimeClearMessage", "RuntimeConfigureMessage", "RuntimeManifestsMessage", "RuntimeLoadBlockMessage", "RuntimeSeekMessage", "RuntimeRefreshMessage", "RuntimePlayMessage", "RuntimePauseMessage", "RuntimeSetSpeedMessage", "RuntimePatchBlockMessage", "RuntimeApplyMessageUpdateMessage"]);
  function isRuntimeControlMessage(message) {
    return typeSetRuntimeControlMessage.has(message.type);
  }

  // bridge/playbackEngine.ts
  var PlaybackEngine = class {
    constructor(config, scene, blocks, audio, callbacks) {
      this.config = config;
      this.scene = scene;
      this.blocks = blocks;
      this.audio = audio;
      this.callbacks = callbacks;
      this.playing = false;
      this.currentStep = 0;
      this.playStartStep = 0;
      this.playStartPerfTime = 0;
      this.rafId = null;
    }
    updateConfig(config) {
      this.config = config;
    }
    getTransportStep(timestamp = performance.now()) {
      if (!this.playing) {
        return this.currentStep;
      }
      return this.playStartStep + (timestamp - this.playStartPerfTime) / 1e3 * this.getPlaybackFps();
    }
    play(payload) {
      const step = this.getTransportStep();
      this.config.speed = payload.speed;
      this.config.loop = payload.loop;
      this.playing = true;
      this.anchorTransport(step);
      this.audio.play(step, this.getPlaybackFps());
      if (this.rafId !== null) {
        getWindow().cancelAnimationFrame(this.rafId);
      }
      this.callbacks.sendSpeedToServer(payload.speed);
      this.callbacks.sendPlaybackStateToServer(true);
      this.callbacks.syncPlaybackButtons();
      this.rafId = getWindow().requestAnimationFrame((ts) => this.tick(ts));
    }
    pause() {
      const step = this.getTransportStep();
      this.currentStep = step;
      this.playing = false;
      if (this.rafId !== null) {
        getWindow().cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      this.audio.pause(step, this.getPlaybackFps());
      this.callbacks.sendPlaybackStateToServer(false);
      this.callbacks.syncTimestepToServer(Math.floor(this.currentStep), true);
      this.callbacks.syncPlaybackButtons();
    }
    seek(payload) {
      const step = Math.max(
        0,
        Math.min(this.config.numSteps - 1, payload.step)
      );
      this.currentStep = step;
      if (this.playing) {
        this.anchorTransport(step);
      }
      if (!this.blocks.ensureStepLoaded(step)) {
        return;
      }
      this.scene.applyThrough(step);
      this.audio.seek(step, this.getPlaybackFps(), this.playing);
      this.callbacks.syncTimestepToServer(step, true);
    }
    refresh() {
      this.scene.rebuildThrough(Math.floor(this.currentStep));
    }
    setSpeed(payload) {
      const step = this.getTransportStep();
      this.config.speed = payload.speed;
      this.config.loop = payload.loop;
      this.anchorTransport(step);
      this.audio.setFps(step, this.getPlaybackFps(), this.playing);
      this.callbacks.sendSpeedToServer(payload.speed);
    }
    syncAudioTransport() {
      this.audio.seek(this.currentStep, this.getPlaybackFps(), this.playing);
    }
    dispose() {
      if (this.rafId !== null) {
        getWindow().cancelAnimationFrame(this.rafId);
        this.rafId = null;
      }
      this.playing = false;
      this.currentStep = 0;
      this.playStartStep = 0;
      this.playStartPerfTime = 0;
    }
    getPlaybackFps() {
      return this.config.timelineFps * this.config.speed;
    }
    anchorTransport(step, timestamp = performance.now()) {
      this.currentStep = step;
      this.playStartStep = step;
      this.playStartPerfTime = timestamp;
    }
    tick(timestamp) {
      if (!this.playing) {
        return;
      }
      const previousStep = this.currentStep;
      const next = this.getTransportStep(timestamp);
      if (next >= this.config.numSteps) {
        if (!this.config.loop) {
          this.currentStep = this.config.numSteps - 1;
          this.playing = false;
          this.audio.pause(this.currentStep, this.getPlaybackFps());
          this.callbacks.syncAdvancedTimesteps(
            previousStep,
            this.currentStep,
            true
          );
          this.callbacks.sendPlaybackStateToServer(false);
          this.callbacks.syncPlaybackButtons();
          return;
        }
        this.anchorTransport(0, timestamp);
        this.scene.rebuildThrough(0);
        this.audio.play(0, this.getPlaybackFps());
        this.callbacks.syncAdvancedTimesteps(previousStep, 0, true);
      } else {
        this.currentStep = next;
        this.scene.advanceThrough(Math.floor(this.currentStep));
        this.callbacks.syncAdvancedTimesteps(previousStep, this.currentStep);
      }
      this.rafId = getWindow().requestAnimationFrame((ts) => this.tick(ts));
    }
  };

  // bridge/sceneApplicator.ts
  var SceneApplicator = class {
    constructor(pushMessages, audio, blocks, renderedTimelineNodes) {
      this.pushMessages = pushMessages;
      this.audio = audio;
      this.blocks = blocks;
      this.renderedTimelineNodes = renderedTimelineNodes;
      this.appliedStep = -1;
      this.appliedBlock = -1;
      this.liveSceneOverrides = /* @__PURE__ */ new Map();
    }
    applyStepMessages(step, messages, preservedNodes = _NO_PRESERVED_NODES) {
      const sceneMessages = [];
      const audioMessages = [];
      for (const message of messages) {
        if (isAudioMessage(message)) {
          audioMessages.push(message);
        } else {
          const normalized = this.normalizeSceneMessage(message, preservedNodes);
          if (!normalized) {
            continue;
          }
          this.trackTimelineNode(normalized);
          sceneMessages.push(normalized);
        }
      }
      if (sceneMessages.length) {
        this.pushMessages(sceneMessages);
      }
      if (audioMessages.length) {
        this.audio.applyTimelineMessages(step, audioMessages);
      }
    }
    resetState() {
      this.removeRenderedTimelineNodes();
      this.audio.resetTimeline();
      this.liveSceneOverrides.clear();
      this.appliedStep = -1;
      this.appliedBlock = -1;
    }
    applyLiveMessage(step, key, message) {
      this.updateLiveSceneOverride(key, message);
      if (!this.shouldApplyLiveMessage(message)) {
        return;
      }
      this.applyStepMessages(step, [message]);
    }
    rebuildThrough(step) {
      if (!this.blocks.ensureStepLoaded(step)) {
        return;
      }
      const preservedNodes = this.prepareForRebuild(step);
      this.audio.resetTimeline();
      this.appliedStep = -1;
      this.appliedBlock = -1;
      this.advanceThrough(step, preservedNodes);
    }
    applyThrough(step, preservedNodes = _NO_PRESERVED_NODES) {
      const blockIndex = this.blocks.blockIndexOf(step);
      if (this.appliedStep >= 0 && (blockIndex !== this.appliedBlock || step < this.appliedStep)) {
        this.rebuildThrough(step);
        return;
      }
      this.advanceThrough(step, preservedNodes);
    }
    advanceThrough(step, preservedNodes = _NO_PRESERVED_NODES) {
      if (!this.blocks.ensureStepLoaded(step)) {
        return;
      }
      if (this.appliedStep < 0) {
        const block = this.blocks.getBlock(step);
        if (!block) {
          return;
        }
        const blockIndex = this.blocks.blockIndexOf(step);
        const checkpointMessages = materializeCheckpointMessages(block.checkpoint);
        if (checkpointMessages.length) {
          this.applyStepMessages(
            this.blocks.blockStartStep(blockIndex),
            checkpointMessages,
            preservedNodes
          );
        }
        this.appliedBlock = blockIndex;
        this.appliedStep = this.blocks.blockStartStep(blockIndex) - 1;
      }
      let nextStep = this.appliedStep + 1;
      while (nextStep <= step) {
        if (!this.blocks.ensureStepLoaded(nextStep)) {
          return;
        }
        const block = this.blocks.getBlock(nextStep);
        if (!block) {
          return;
        }
        const blockIndex = this.blocks.blockIndexOf(nextStep);
        const blockStart = this.blocks.blockStartStep(blockIndex);
        const blockEnd = Math.min(
          step,
          blockStart + block.stepPatches.length - 1
        );
        for (let index = nextStep; index <= blockEnd; index += 1) {
          const patch = block.stepPatches[index - blockStart];
          const messages = patch ? materializeStatePatchMessages(patch) : [];
          if (messages.length) {
            this.applyStepMessages(index, messages, preservedNodes);
          }
          this.applyLiveSceneOverrides(index, preservedNodes);
        }
        this.appliedBlock = blockIndex;
        this.appliedStep = blockEnd;
        nextStep = blockEnd + 1;
      }
    }
    removeRenderedTimelineNodes() {
      this.removeTrackedTimelineNodes(new Set(this.renderedTimelineNodes.keys()));
    }
    prepareForRebuild(step) {
      const targetNodes = this.collectTargetTimelineNodes(step);
      const preservedNodes = /* @__PURE__ */ new Set();
      const nodesToRemove = /* @__PURE__ */ new Set();
      for (const [name, currentType] of this.renderedTimelineNodes) {
        if (targetNodes.get(name) === currentType) {
          preservedNodes.add(name);
          continue;
        }
        nodesToRemove.add(name);
      }
      this.removeTrackedTimelineNodes(nodesToRemove);
      return preservedNodes;
    }
    collectTargetTimelineNodes(step) {
      const block = this.blocks.getBlock(step);
      if (!block) {
        return /* @__PURE__ */ new Map();
      }
      const targetNodes = /* @__PURE__ */ new Map();
      for (const message of block.checkpoint.sceneEntries.values()) {
        this.trackTimelineNode(message, targetNodes);
      }
      const blockIndex = this.blocks.blockIndexOf(step);
      const blockStart = this.blocks.blockStartStep(blockIndex);
      for (let index = blockStart; index <= step; index += 1) {
        const patch = block.stepPatches[index - blockStart];
        if (!patch) {
          continue;
        }
        for (const name of patch.sceneDeleteNodes) {
          this.trackRemoval(name, targetNodes);
        }
        for (const message of patch.scenePuts.values()) {
          this.trackTimelineNode(message, targetNodes);
        }
      }
      return targetNodes;
    }
    removeTrackedTimelineNodes(nodesToRemove) {
      if (!nodesToRemove.size) {
        return;
      }
      const minimalRemovals = Array.from(nodesToRemove).filter(
        (name) => !hasAncestorInSet(name, nodesToRemove)
      );
      this.pushMessages(
        minimalRemovals.map((name) => ({
          type: "RemoveSceneNodeMessage",
          name
        }))
      );
      for (const name of Array.from(this.renderedTimelineNodes.keys())) {
        if (hasAncestorInSet(name, nodesToRemove) || nodesToRemove.has(name)) {
          this.renderedTimelineNodes.delete(name);
        }
      }
    }
    applyLiveSceneOverrides(step, preservedNodes) {
      const messages = [];
      for (const message of this.liveSceneOverrides.values()) {
        if (this.shouldApplyLiveMessage(message)) {
          messages.push(message);
        }
      }
      if (messages.length > 0) {
        this.applyStepMessages(step, messages, preservedNodes);
      }
    }
    shouldApplyLiveMessage(message) {
      const name = typeof message.name === "string" ? message.name : null;
      if (name === null) {
        return true;
      }
      if (message.type === "RemoveSceneNodeMessage") {
        for (const nodeName of this.renderedTimelineNodes.keys()) {
          if (isNodeOrDescendant(nodeName, name)) {
            return true;
          }
        }
        return false;
      }
      return this.renderedTimelineNodes.has(name);
    }
    updateLiveSceneOverride(key, message) {
      const name = typeof message.name === "string" ? message.name : null;
      if (message.type === "RemoveSceneNodeMessage" && name !== null) {
        for (const [overrideKey, overrideMessage] of Array.from(this.liveSceneOverrides.entries())) {
          const overrideName = typeof overrideMessage.name === "string" ? overrideMessage.name : null;
          if (overrideName !== null && isNodeOrDescendant(overrideName, name)) {
            this.liveSceneOverrides.delete(overrideKey);
          }
        }
      }
      this.liveSceneOverrides.set(key, message);
    }
    // During a cross-block rebuild, per-step patches may carry Remove messages
    // for nodes that also re-appear in the target state (same type at both
    // ends). We keep those subtrees mounted to avoid churn; dropping the Remove
    // here lets the re-create flow through viser's upsert unchanged. Non-Remove
    // messages always pass through: viser's addSceneNode is already idempotent
    // for existing nodes, and going through the full create path preserves the
    // side effects (skinnedMeshState init, nodeRefFromName clear, pose gating)
    // that a SceneNodeUpdateMessage rewrite would silently skip.
    normalizeSceneMessage(message, preservedNodes) {
      if (message.type !== "RemoveSceneNodeMessage") {
        return message;
      }
      const name = typeof message.name === "string" ? message.name : null;
      if (name === null) {
        return message;
      }
      for (const preservedName of preservedNodes) {
        if (isNodeOrDescendant(preservedName, name)) {
          return null;
        }
      }
      return message;
    }
    trackTimelineNode(message, renderedTimelineNodes = this.renderedTimelineNodes) {
      const name = typeof message.name === "string" ? message.name : null;
      if (!name) {
        return;
      }
      if (message.type === "RemoveSceneNodeMessage") {
        this.trackRemoval(name, renderedTimelineNodes);
        return;
      }
      if (isCreateSceneNodeMessage2(message)) {
        renderedTimelineNodes.set(name, message.type);
      }
    }
    trackRemoval(name, renderedTimelineNodes = this.renderedTimelineNodes) {
      for (const nodeName of Array.from(renderedTimelineNodes.keys())) {
        if (isNodeOrDescendant(nodeName, name)) {
          renderedTimelineNodes.delete(nodeName);
        }
      }
    }
  };
  var _NO_PRESERVED_NODES = /* @__PURE__ */ new Set();
  function isNodeOrDescendant(nodeName, parentName) {
    return nodeName === parentName || nodeName.startsWith(`${parentName}/`);
  }
  function hasAncestorInSet(name, names) {
    let slash = name.lastIndexOf("/");
    while (slash > 0) {
      const parent = name.slice(0, slash);
      if (names.has(parent)) {
        return true;
      }
      slash = parent.lastIndexOf("/");
    }
    return false;
  }
  function isCreateSceneNodeMessage2(message) {
    return "props" in message;
  }

  // bridge/timelineController.ts
  var debugState = {
    enabled: false,
    logs: [],
    maxLogs: 400,
    push(event, payload) {
      this.logs.push({
        time: Number(performance.now().toFixed(1)),
        event,
        payload
      });
      if (this.logs.length > this.maxLogs) {
        this.logs.shift();
      }
      if (this.enabled) {
        console.debug("[viser4d]", event, payload);
      }
    },
    clear() {
      this.logs.length = 0;
    },
    setEnabled(enabled) {
      this.enabled = !!enabled;
    }
  };
  var TimelineController = class {
    constructor(io) {
      this.io = io;
      this.debug = debugState;
      this.config = {
        numSteps: 1,
        blockSize: 32,
        timelineFps: 30,
        speed: 1,
        loop: false,
        clientChunkCacheBytes: 0,
        blockManifests: [],
        timelineSliderUuid: null,
        speedSliderUuid: null,
        stepButtonsUuid: null,
        playButtonUuid: null,
        pauseButtonUuid: null
      };
      this.lastLocalSliderStep = -1;
      this.lastSyncedStep = -1;
      this.lastFocusBlock = -1;
      this.audio = new AudioRuntime(
        () => this.engine.getTransportStep(),
        (event, payload) => debugState.push(event, payload)
      );
      this.blocks = new BlockCache({
        requestBlock: (blockIndex) => this.requestBlockFromServer(blockIndex),
        discardBlock: (blockIndex) => this.reportBlockDiscard(blockIndex)
      });
      this.scene = new SceneApplicator(
        (messages) => this.io.pushMessages(messages),
        this.audio,
        this.blocks,
        /* @__PURE__ */ new Map()
      );
      this.engine = new PlaybackEngine(
        this.config,
        this.scene,
        this.blocks,
        this.audio,
        {
          syncAdvancedTimesteps: (previousStep, nextStep, forceFinal) => this.syncAdvancedTimesteps(previousStep, nextStep, forceFinal),
          syncTimestepToServer: (step, force) => this.syncTimestepToServer(step, force),
          syncPlaybackButtons: () => this.syncPlaybackButtons(),
          sendPlaybackStateToServer: (isPlaying) => this.sendPlaybackStateToServer(isPlaying),
          sendSpeedToServer: (speed) => this.sendSpeedToServer(speed)
        }
      );
    }
    dispose() {
      this.engine.dispose();
      this.audio.reset();
    }
    onViewerReady(isWebsocket) {
      if (!isWebsocket) {
        return;
      }
      this.sendRuntimeEvent({ type: "RuntimeReadyMessage" });
    }
    handleQueuedMessage(message) {
      if (!isRuntimeControlMessage(message)) {
        return false;
      }
      this.handleRuntimeMessage(message);
      return true;
    }
    handleGuiMessage(message) {
      const { uuid } = message;
      const value = message.updates.value;
      if (uuid === this.config.timelineSliderUuid) {
        const step = Number(value);
        if (!Number.isFinite(step)) {
          return true;
        }
        this.engine.seek({ step });
        return true;
      }
      if (uuid === this.config.speedSliderUuid) {
        const speed = Number(value);
        if (!Number.isFinite(speed)) {
          return true;
        }
        this.engine.setSpeed({ speed, loop: this.config.loop });
        return true;
      }
      if (uuid === this.config.stepButtonsUuid) {
        const currentStep = this.currentStep();
        if (value === "Prev") {
          this.engine.seek({ step: currentStep - 1 });
        } else if (value === "Next") {
          this.engine.seek({ step: currentStep + 1 });
        }
        return true;
      }
      if (uuid === this.config.playButtonUuid) {
        const isAtEnd = this.currentStep() === this.config.numSteps - 1;
        if (!this.config.loop && isAtEnd) {
          this.engine.seek({ step: 0 });
        }
        this.engine.play({ speed: this.config.speed, loop: this.config.loop });
        return true;
      }
      if (uuid === this.config.pauseButtonUuid) {
        this.engine.pause();
        return true;
      }
      return false;
    }
    configure(message) {
      this.config = {
        ...this.config,
        numSteps: message.numSteps,
        blockSize: message.blockSize,
        timelineFps: message.timelineFps,
        speed: message.speed,
        loop: message.loop,
        clientChunkCacheBytes: message.clientChunkCacheBytes,
        blockManifests: message.blockManifests,
        timelineSliderUuid: message.timelineSliderUuid,
        speedSliderUuid: message.speedSliderUuid,
        stepButtonsUuid: message.stepButtonsUuid,
        playButtonUuid: message.playButtonUuid,
        pauseButtonUuid: message.pauseButtonUuid
      };
      this.blocks.blockSize = this.config.blockSize;
      this.blocks.setBudgetBytes(this.config.clientChunkCacheBytes);
      this.blocks.setManifests(this.config.blockManifests);
      this.engine.updateConfig(this.config);
      this.audio.setStepRate(this.config.timelineFps);
      debugState.push("runtime.configure", {
        ...this.config,
        blockManifests: this.config.blockManifests.length
      });
      this.engine.syncAudioTransport();
      this.syncPlaybackButtons();
      this.refocusPreload(this.currentStep(), true);
    }
    applyManifests(message) {
      this.config = {
        ...this.config,
        blockManifests: message.blockManifests
      };
      this.blocks.setManifests(message.blockManifests);
      debugState.push("runtime.manifests", {
        count: message.blockManifests.length
      });
      this.refocusPreload(this.currentStep(), true);
    }
    clear() {
      this.engine.dispose();
      this.blocks.reset();
      this.scene.resetState();
      this.audio.reset();
      this.lastLocalSliderStep = -1;
      this.lastSyncedStep = -1;
      this.lastFocusBlock = -1;
      debugState.push("runtime.clear", null);
    }
    loadBlock(message) {
      this.blocks.loadBlock(message.block, {
        checkpointSceneEntries: message.checkpointSceneEntries,
        checkpointAudioMessages: message.checkpointAudioMessages,
        stepPatches: message.stepPatches
      });
      this.afterBlockLoad(message.block);
    }
    patchBlock(message) {
      const currentStep = this.currentStep();
      const patched = this.blocks.patchBlock(message.block, {
        checkpointScenePuts: message.checkpointScenePuts,
        checkpointSceneDeletes: message.checkpointSceneDeletes,
        checkpointAudioPuts: message.checkpointAudioPuts,
        checkpointAudioDeletes: message.checkpointAudioDeletes,
        stepPatchUpdates: message.stepPatchUpdates
      });
      if (!patched) {
        return;
      }
      debugState.push("runtime.patch_block", {
        block: message.block,
        stepPatchUpdates: message.stepPatchUpdates.length
      });
      const activeBlock = this.blocks.blockIndexOf(currentStep);
      if (message.block === activeBlock && this.scene.appliedBlock === activeBlock) {
        this.scene.rebuildThrough(currentStep);
      }
    }
    afterBlockLoad(blockIndex) {
      const currentStep = this.currentStep();
      const activeBlock = this.blocks.blockIndexOf(currentStep);
      if (blockIndex === activeBlock && this.scene.appliedBlock === activeBlock) {
        this.scene.rebuildThrough(currentStep);
      } else {
        const pendingStep = this.blocks.pendingStep;
        if (pendingStep !== null && this.blocks.getBlock(pendingStep)) {
          this.blocks.pendingStep = null;
          this.engine.seek({ step: pendingStep });
        }
      }
      this.refocusPreload(currentStep, true);
    }
    requestBlockFromServer(blockIndex) {
      debugState.push("runtime.load_block.request", { block: blockIndex });
      this.sendRuntimeEvent({
        type: "RuntimeBlockRequestMessage",
        blockIndex
      });
    }
    reportBlockDiscard(blockIndex) {
      debugState.push("runtime.block_discard", { block: blockIndex });
      this.sendRuntimeEvent({
        type: "RuntimeBlockDiscardMessage",
        blockIndex
      });
    }
    seek(message) {
      this.engine.seek({ step: message.step });
    }
    refresh() {
      this.engine.refresh();
    }
    play(message) {
      this.engine.play({ speed: message.speed, loop: message.loop });
    }
    pause() {
      this.engine.pause();
    }
    setSpeed(message) {
      this.engine.setSpeed({ speed: message.speed, loop: message.loop });
    }
    applyMessageUpdate(message) {
      const currentStep = this.currentStep();
      const updatedMessage = message.message;
      const name = typeof updatedMessage.name === "string" ? updatedMessage.name : null;
      debugState.push("runtime.apply_message_update", {
        key: message.key,
        type: updatedMessage.type,
        name,
        step: currentStep
      });
      if (isAudioMessage(updatedMessage)) {
        this.audio.applyLiveMessages(currentStep, [updatedMessage]);
        return;
      }
      this.scene.applyLiveMessage(currentStep, message.key, updatedMessage);
    }
    handleRuntimeMessage(message) {
      switch (message.type) {
        case "RuntimeConfigureMessage":
          this.configure(message);
          return;
        case "RuntimeManifestsMessage":
          this.applyManifests(message);
          return;
        case "RuntimeClearMessage":
          this.clear();
          return;
        case "RuntimeLoadBlockMessage":
          this.loadBlock(message);
          return;
        case "RuntimePatchBlockMessage":
          this.patchBlock(message);
          return;
        case "RuntimeSeekMessage":
          this.seek(message);
          return;
        case "RuntimeRefreshMessage":
          this.refresh();
          return;
        case "RuntimePlayMessage":
          this.play(message);
          return;
        case "RuntimePauseMessage":
          this.pause();
          return;
        case "RuntimeSetSpeedMessage":
          this.setSpeed(message);
          return;
        case "RuntimeApplyMessageUpdateMessage":
          this.applyMessageUpdate(message);
          return;
      }
    }
    sendRuntimeEvent(message) {
      this.io.sendRuntimeEvent(message);
    }
    syncPlaybackButtons() {
      const sync = (uuid, visible) => {
        if (!uuid) {
          return;
        }
        this.io.updateGuiVisible(uuid, visible);
      };
      sync(this.config.playButtonUuid, !this.engine.playing);
      sync(this.config.pauseButtonUuid, this.engine.playing);
    }
    syncTimelineSlider(step, force = false) {
      const sliderUuid = this.config.timelineSliderUuid;
      if (!sliderUuid) {
        return;
      }
      const clampedStep = this.clampStep(step);
      const stepChanged = clampedStep !== this.lastLocalSliderStep;
      if (!force && !stepChanged) {
        return;
      }
      this.lastLocalSliderStep = clampedStep;
      this.io.pushMessages([
        {
          type: "GuiUpdateMessage",
          uuid: sliderUuid,
          updates: { value: clampedStep }
        }
      ]);
    }
    sendTimestepToServer(step, force = false) {
      const clampedStep = this.clampStep(step);
      if (!force && clampedStep === this.lastSyncedStep) {
        return;
      }
      this.lastSyncedStep = clampedStep;
      this.sendRuntimeEvent({
        type: "RuntimeTimestepMessage",
        step: clampedStep
      });
    }
    syncTimestepToServer(step, force = false) {
      this.syncTimelineSlider(step, force);
      this.sendTimestepToServer(step, force);
      this.refocusPreload(step);
    }
    refocusPreload(step, force = false) {
      const blockIndex = this.blocks.blockIndexOf(this.clampStep(step));
      if (!force && blockIndex === this.lastFocusBlock) {
        return;
      }
      this.lastFocusBlock = blockIndex;
      this.blocks.syncCurrentBlock(blockIndex, this.scene.appliedBlock);
    }
    syncAdvancedTimesteps(previousStep, nextStep, forceFinal = false) {
      const previousDiscrete = Math.floor(previousStep);
      const nextDiscrete = Math.floor(nextStep);
      const numSteps = this.config.numSteps;
      this.syncTimelineSlider(nextDiscrete, forceFinal);
      this.refocusPreload(nextDiscrete);
      if (nextDiscrete === previousDiscrete) {
        if (forceFinal) {
          this.sendTimestepToServer(nextDiscrete, true);
        }
        return;
      }
      if (nextDiscrete > previousDiscrete) {
        for (let step = previousDiscrete + 1; step <= nextDiscrete; step += 1) {
          this.sendTimestepToServer(step);
        }
        return;
      }
      for (let step = previousDiscrete + 1; step < numSteps; step += 1) {
        this.sendTimestepToServer(step);
      }
      for (let step = 0; step <= nextDiscrete; step += 1) {
        this.sendTimestepToServer(step);
      }
    }
    clampStep(step) {
      return Math.max(0, Math.min(this.config.numSteps - 1, step));
    }
    currentStep() {
      return Math.floor(this.engine.currentStep);
    }
    sendSpeedToServer(speed) {
      this.sendRuntimeEvent({
        type: "RuntimeSpeedMessage",
        speed
      });
    }
    sendPlaybackStateToServer(isPlaying) {
      this.sendRuntimeEvent({
        type: "RuntimePlaybackStateMessage",
        isPlaying
      });
    }
  };

  // bridge/viewerAdapter.ts
  var ViewerAdapter = class {
    constructor(handlers) {
      this.handlers = handlers;
      this.viewer = null;
      this.playbackTimeSlider = null;
      this.disposed = false;
      this.undoQueueIngress = null;
      this.undoGuiMessageInterceptor = null;
      this.queuePush = null;
      this.playbackMonitor = null;
    }
    install() {
      this.installWhenReady();
    }
    dispose() {
      this.disposed = true;
      this.undoQueueIngress?.();
      this.undoQueueIngress = null;
      this.undoGuiMessageInterceptor?.();
      this.undoGuiMessageInterceptor = null;
      this.playbackMonitor?.disconnect();
      this.playbackMonitor = null;
      this.viewer = null;
      this.playbackTimeSlider = null;
      this.queuePush = null;
    }
    getMessageSource() {
      return this.getViewer().messageSource;
    }
    pushMessages(messages) {
      if (this.queuePush) {
        this.queuePush(...messages);
        return;
      }
      this.getViewer().mutable.current.messageQueue.push(...messages);
    }
    sendMessage(message) {
      this.getViewer().mutable.current.sendMessage(message);
    }
    updateGuiVisible(uuid, visible) {
      const viewer = this.getViewer();
      const hasGuiControl = viewer.useGuiConfig.get(uuid) !== void 0;
      if (!hasGuiControl) {
        return;
      }
      viewer.guiActions.updateGuiProps(uuid, { visible });
    }
    getPlaybackTime() {
      const slider = this.getPlaybackTimeSlider();
      if (!slider) {
        return null;
      }
      const value = slider.getAttribute("aria-valuenow");
      if (value === null) {
        return null;
      }
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : null;
    }
    installWhenReady() {
      if (this.disposed) {
        return;
      }
      try {
        this.configureQueueIngress();
        this.installGuiMessageInterceptor();
        const messageSource = this.getMessageSource();
        if (messageSource !== "websocket") {
          this.installPlaybackMonitor();
        }
        this.handlers.onReady();
      } catch {
        if (!this.disposed) {
          getWindow().requestAnimationFrame(() => this.installWhenReady());
        }
      }
    }
    getViewer() {
      if (!this.viewer) {
        this.viewer = findViewer();
      }
      return this.viewer;
    }
    getPlaybackTimeSlider() {
      if (!this.playbackTimeSlider || !this.playbackTimeSlider.isConnected) {
        this.playbackTimeSlider = findPlaybackTimeSlider();
      }
      return this.playbackTimeSlider;
    }
    configureQueueIngress() {
      if (this.undoQueueIngress) {
        return;
      }
      const queue = this.getViewer().mutable.current.messageQueue;
      const originalPush = queue.push.bind(queue);
      const wrappedPush = (...messages) => {
        const forwarded = [];
        for (const message of messages) {
          if (this.handlers.handleQueuedMessage(message)) {
            continue;
          }
          forwarded.push(message);
        }
        return originalPush(...forwarded);
      };
      this.queuePush = originalPush;
      queue.push = wrappedPush;
      this.undoQueueIngress = () => {
        if (queue.push === wrappedPush) {
          queue.push = originalPush;
        }
      };
    }
    installGuiMessageInterceptor() {
      if (this.undoGuiMessageInterceptor) {
        return;
      }
      const mutable = this.getViewer().mutable.current;
      let rawSendMessage = mutable.sendMessage;
      const wrappedSendMessage = (message) => {
        const isGuiUpdate = message.type === "GuiUpdateMessage";
        if (isGuiUpdate) {
          const guiMessage = message;
          if (this.handlers.handleGuiMessage(guiMessage)) {
            return;
          }
        }
        rawSendMessage(message);
      };
      Object.defineProperty(mutable, "sendMessage", {
        configurable: true,
        enumerable: true,
        get: () => wrappedSendMessage,
        set: (value) => {
          rawSendMessage = value;
        }
      });
      this.undoGuiMessageInterceptor = () => {
        Object.defineProperty(mutable, "sendMessage", {
          configurable: true,
          enumerable: true,
          writable: true,
          value: rawSendMessage
        });
      };
    }
    installPlaybackMonitor() {
      if (this.playbackMonitor) {
        return;
      }
      const slider = this.getPlaybackTimeSlider();
      if (!slider) {
        throw new Error("[viser4d] Could not find the playback slider.");
      }
      this.playbackMonitor = new MutationObserver(() => {
        this.handlers.handlePlaybackTimeChange();
      });
      this.playbackMonitor.observe(slider, {
        attributes: true,
        attributeFilter: ["aria-valuenow"]
      });
      this.handlers.handlePlaybackTimeChange();
    }
  };

  // bridge/runtime.ts
  var TimelineRuntime = class {
    constructor() {
      const viewer = new ViewerAdapter({
        handleQueuedMessage: (message) => this.handleQueuedMessage(message),
        handleGuiMessage: (message) => this.controller.handleGuiMessage(message),
        handlePlaybackTimeChange: () => this.filePlayback.sync(),
        onReady: () => this.handleViewerReady()
      });
      this.viewer = viewer;
      this.controller = new TimelineController({
        pushMessages: (messages) => viewer.pushMessages(messages),
        sendRuntimeEvent: (message) => viewer.sendMessage(message),
        updateGuiVisible: (uuid, visible) => viewer.updateGuiVisible(uuid, visible)
      });
      this.filePlayback = new FilePlaybackAdapter(
        () => viewer.getPlaybackTime(),
        (event, payload) => this.controller.debug.push(event, payload)
      );
      viewer.install();
    }
    get debug() {
      return this.controller.debug;
    }
    dispose() {
      this.viewer.dispose();
      this.controller.dispose();
      this.filePlayback.dispose();
    }
    handleQueuedMessage(message) {
      if (this.controller.handleQueuedMessage(message)) {
        return true;
      }
      const isWebsocket = this.viewer.getMessageSource() === "websocket";
      if (!isAudioMessage(message) || isWebsocket) {
        return false;
      }
      this.filePlayback.enqueue(message);
      return true;
    }
    handleViewerReady() {
      const isWebsocket = this.viewer.getMessageSource() === "websocket";
      this.controller.onViewerReady(isWebsocket);
    }
  };

  // index.ts
  var windowRef = window;
  windowRef.__VISER4D__?.dispose();
  windowRef.__VISER4D__ = new TimelineRuntime();
})();
