"""Compatibility shims for features that depend on the running Python version."""

import sys

if sys.version_info >= (3, 13):
    from warnings import deprecated
else:
    from typing_extensions import deprecated

__all__ = ("deprecated",)
