r"""
Types for interfacing between a :class:`.Core`
and libretro.py's :mod:`driver implementations <libretro.drivers>`.

.. seealso::

    :class:`.EnvironmentDriver`
        The :class:`~typing.Protocol` that defines the layer
        between :class:`.Core`\s and libretro.py's drivers.

    :mod:`libretro.drivers.environment`
        libretro.py's included :class:`.EnvironmentDriver` implementations.
"""

from ctypes import c_bool, c_uint
from enum import IntEnum, unique

from libretro.ctypes import CIntArg, TypedFunctionPointer, c_void_ptr

RETRO_ENVIRONMENT_EXPERIMENTAL = 0x10000
RETRO_ENVIRONMENT_PRIVATE = 0x20000
RETRO_ENVIRONMENT_SET_ROTATION = 1
RETRO_ENVIRONMENT_GET_OVERSCAN = 2
RETRO_ENVIRONMENT_GET_CAN_DUPE = 3
RETRO_ENVIRONMENT_SET_MESSAGE = 6
RETRO_ENVIRONMENT_SHUTDOWN = 7
RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL = 8
RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY = 9
RETRO_ENVIRONMENT_SET_PIXEL_FORMAT = 10
RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS = 11
RETRO_ENVIRONMENT_SET_KEYBOARD_CALLBACK = 12
RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE = 13
RETRO_ENVIRONMENT_SET_HW_RENDER = 14
RETRO_ENVIRONMENT_GET_VARIABLE = 15
RETRO_ENVIRONMENT_SET_VARIABLES = 16
RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE = 17
RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME = 18
RETRO_ENVIRONMENT_GET_LIBRETRO_PATH = 19
RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK = 21
RETRO_ENVIRONMENT_SET_AUDIO_CALLBACK = 22
RETRO_ENVIRONMENT_GET_RUMBLE_INTERFACE = 23
RETRO_ENVIRONMENT_GET_INPUT_DEVICE_CAPABILITIES = 24
RETRO_ENVIRONMENT_GET_SENSOR_INTERFACE = 25 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_CAMERA_INTERFACE = 26 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_LOG_INTERFACE = 27
RETRO_ENVIRONMENT_GET_PERF_INTERFACE = 28
RETRO_ENVIRONMENT_GET_LOCATION_INTERFACE = 29
RETRO_ENVIRONMENT_GET_CONTENT_DIRECTORY = 30
RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY = 30
RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY = 31
RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO = 32
RETRO_ENVIRONMENT_SET_PROC_ADDRESS_CALLBACK = 33
RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO = 34
RETRO_ENVIRONMENT_SET_CONTROLLER_INFO = 35
RETRO_ENVIRONMENT_SET_MEMORY_MAPS = 36 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_SET_GEOMETRY = 37
RETRO_ENVIRONMENT_GET_USERNAME = 38
RETRO_ENVIRONMENT_GET_LANGUAGE = 39
RETRO_ENVIRONMENT_GET_CURRENT_SOFTWARE_FRAMEBUFFER = 40 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_HW_RENDER_INTERFACE = 41 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS = 42 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_SET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE = 43 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS = 44
RETRO_ENVIRONMENT_SET_HW_SHARED_CONTEXT = 44 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_VFS_INTERFACE = 45 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_LED_INTERFACE = 46 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE = 47 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_MIDI_INTERFACE = 48 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_FASTFORWARDING = 49 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_TARGET_REFRESH_RATE = 50 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_INPUT_BITMASKS = 51 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION = 52
RETRO_ENVIRONMENT_SET_CORE_OPTIONS = 53
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL = 54
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY = 55
RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER = 56
RETRO_ENVIRONMENT_GET_DISK_CONTROL_INTERFACE_VERSION = 57
RETRO_ENVIRONMENT_SET_DISK_CONTROL_EXT_INTERFACE = 58
RETRO_ENVIRONMENT_GET_MESSAGE_INTERFACE_VERSION = 59
RETRO_ENVIRONMENT_SET_MESSAGE_EXT = 60
RETRO_ENVIRONMENT_GET_INPUT_MAX_USERS = 61
RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK = 62
RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY = 63
RETRO_ENVIRONMENT_SET_FASTFORWARDING_OVERRIDE = 64
RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE = 65
RETRO_ENVIRONMENT_GET_GAME_INFO_EXT = 66
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2 = 67
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL = 68
RETRO_ENVIRONMENT_SET_CORE_OPTIONS_UPDATE_DISPLAY_CALLBACK = 69
RETRO_ENVIRONMENT_SET_VARIABLE = 70
RETRO_ENVIRONMENT_GET_THROTTLE_STATE = 71 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_SAVESTATE_CONTEXT = 72 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE_SUPPORT = (
    73 | RETRO_ENVIRONMENT_EXPERIMENTAL
)
RETRO_ENVIRONMENT_GET_JIT_CAPABLE = 74
RETRO_ENVIRONMENT_GET_MICROPHONE_INTERFACE = 75 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_SET_NETPACKET_INTERFACE = 76
RETRO_ENVIRONMENT_GET_DEVICE_POWER = 77 | RETRO_ENVIRONMENT_EXPERIMENTAL
RETRO_ENVIRONMENT_GET_PLAYLIST_DIRECTORY = 79
RETRO_ENVIRONMENT_GET_FILE_BROWSER_START_DIRECTORY = 80

RETRO_API_VERSION = 1

API_VERSION = RETRO_API_VERSION
"""The version of the libretro API that this library implements."""


@unique
class EnvironmentCall(IntEnum):
    """
    Enumeration of all :c:macro:`RETRO_ENVIRONMENT` callback identifiers.

    Each member corresponds to a ``RETRO_ENVIRONMENT_*`` constant in ``libretro.h``.
    Passed as the ``cmd`` argument to :func:`retro_environment_t`.

    >>> from libretro.api import EnvironmentCall
    >>> EnvironmentCall.SHUTDOWN
    <EnvironmentCall.SHUTDOWN: 7>
    """

    SET_ROTATION = RETRO_ENVIRONMENT_SET_ROTATION
    """
    .. seealso:: :attr:`.VideoDriver.rotation`
    """
    GET_OVERSCAN = RETRO_ENVIRONMENT_GET_OVERSCAN
    GET_CAN_DUPE = RETRO_ENVIRONMENT_GET_CAN_DUPE
    """
    .. seealso:: :attr:`.VideoDriver.can_dupe`
    """

    SET_MESSAGE = RETRO_ENVIRONMENT_SET_MESSAGE
    """
    .. seealso:: :meth:`.MessageDriver.set_message`
    """

    SHUTDOWN = RETRO_ENVIRONMENT_SHUTDOWN
    SET_PERFORMANCE_LEVEL = RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL
    GET_SYSTEM_DIRECTORY = RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY
    """
    .. seealso:: :meth:`.PathDriver.system_dir`
    """

    SET_PIXEL_FORMAT = RETRO_ENVIRONMENT_SET_PIXEL_FORMAT
    """
    .. seealso:: :attr:`.VideoDriver.pixel_format`
    """

    SET_INPUT_DESCRIPTORS = RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS
    """
    .. seealso:: :attr:`.InputDriver.descriptors`
    """

    SET_KEYBOARD_CALLBACK = RETRO_ENVIRONMENT_SET_KEYBOARD_CALLBACK
    """
    .. seealso:: :attr:`.InputDriver.keyboard_callback`
    """

    SET_DISK_CONTROL_INTERFACE = RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE
    """
    .. seealso:: :class:`.DiskDriver`
    """

    SET_HW_RENDER = RETRO_ENVIRONMENT_SET_HW_RENDER
    """
    .. seealso:: :attr:`.VideoDriver.set_context`
    """

    SET_HW_RENDER_EXPERIMENTAL = RETRO_ENVIRONMENT_SET_HW_RENDER | RETRO_ENVIRONMENT_EXPERIMENTAL
    """
    .. seealso:: :attr:`.VideoDriver.set_context`
    """

    GET_VARIABLE = RETRO_ENVIRONMENT_GET_VARIABLE
    """
    .. seealso:: :attr:`.OptionDriver.variables`
    """

    SET_VARIABLES = RETRO_ENVIRONMENT_SET_VARIABLES
    """
    .. seealso:: :attr:`.OptionDriver.set_variables`
    """

    GET_VARIABLE_UPDATE = RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE
    """
    .. seealso:: :attr:`.OptionDriver.variable_updated`
    """
    SET_SUPPORT_NO_GAME = RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME
    GET_LIBRETRO_PATH = RETRO_ENVIRONMENT_GET_LIBRETRO_PATH
    """
    .. seealso:: :meth:`.PathDriver.libretro_path`
    """

    SET_FRAME_TIME_CALLBACK = RETRO_ENVIRONMENT_SET_FRAME_TIME_CALLBACK
    """
    .. seealso:: :attr:`.TimingDriver.frame_time_callback`
    """

    SET_AUDIO_CALLBACK = RETRO_ENVIRONMENT_SET_AUDIO_CALLBACK
    """
    .. seealso:: :attr:`.AudioDriver.callbacks`
    """

    GET_RUMBLE_INTERFACE = RETRO_ENVIRONMENT_GET_RUMBLE_INTERFACE
    """
    .. seealso:: :class:`.RumbleDriver`
    """

    GET_INPUT_DEVICE_CAPABILITIES = RETRO_ENVIRONMENT_GET_INPUT_DEVICE_CAPABILITIES
    """
    .. seealso:: :attr:`.InputDriver.device_capabilities`
    """

    GET_SENSOR_INTERFACE = RETRO_ENVIRONMENT_GET_SENSOR_INTERFACE
    """
    .. seealso:: :class:`.SensorDriver`
    """

    GET_CAMERA_INTERFACE = RETRO_ENVIRONMENT_GET_CAMERA_INTERFACE
    """
    .. seealso:: :class:`.CameraDriver`
    """

    GET_LOG_INTERFACE = RETRO_ENVIRONMENT_GET_LOG_INTERFACE
    """
    .. seealso:: :class:`.LogDriver`
    """

    GET_PERF_INTERFACE = RETRO_ENVIRONMENT_GET_PERF_INTERFACE
    """
    .. seealso:: :class:`.PerfDriver`
    """

    GET_LOCATION_INTERFACE = RETRO_ENVIRONMENT_GET_LOCATION_INTERFACE
    """
    .. seealso:: :class:`.LocationDriver`
    """

    GET_CORE_ASSETS_DIRECTORY = RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY
    """
    .. seealso:: :attr:`.PathDriver.core_assets_dir`
    """

    GET_SAVE_DIRECTORY = RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY
    """
    .. seealso:: :attr:`.PathDriver.save_dir`
    """

    SET_SYSTEM_AV_INFO = RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO
    """
    .. seealso:: :attr:`.AudioDriver.system_av_info`
    """

    SET_PROC_ADDRESS_CALLBACK = RETRO_ENVIRONMENT_SET_PROC_ADDRESS_CALLBACK
    """
    .. seealso:: :class:`.retro_get_proc_address_interface`
    """

    SET_SUBSYSTEM_INFO = RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO
    """
    .. seealso:: :attr:`.ContentDriver.subsystem_info`
    """

    SET_CONTROLLER_INFO = RETRO_ENVIRONMENT_SET_CONTROLLER_INFO
    """
    .. seealso:: :attr:`.InputDriver.controller_info`
    """

    SET_MEMORY_MAPS = RETRO_ENVIRONMENT_SET_MEMORY_MAPS
    """
    .. seealso:: :class:`.retro_memory_map`
    """

    SET_GEOMETRY = RETRO_ENVIRONMENT_SET_GEOMETRY
    """
    .. seealso:: :attr:`.VideoDriver.geometry`
    """

    GET_USERNAME = RETRO_ENVIRONMENT_GET_USERNAME
    """
    .. seealso:: :attr:`.UserDriver.username`
    """

    GET_LANGUAGE = RETRO_ENVIRONMENT_GET_LANGUAGE
    """
    .. seealso:: :attr:`.UserDriver.language`
    """

    GET_CURRENT_SOFTWARE_FRAMEBUFFER = RETRO_ENVIRONMENT_GET_CURRENT_SOFTWARE_FRAMEBUFFER
    """
    .. seealso:: :meth:`.VideoDriver.get_software_framebuffer`
    """

    GET_HW_RENDER_INTERFACE = RETRO_ENVIRONMENT_GET_HW_RENDER_INTERFACE
    """
    .. seealso:: :attr:`.VideoDriver.hw_render_interface`
    """

    SET_SUPPORT_ACHIEVEMENTS = RETRO_ENVIRONMENT_SET_SUPPORT_ACHIEVEMENTS
    SET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE = (
        RETRO_ENVIRONMENT_SET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE
    )
    """
    .. seealso:: :class:`.retro_hw_render_context_negotiation_interface`
    """

    SET_SERIALIZATION_QUIRKS = RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS
    """
    .. seealso:: :class:`.SerializationQuirks`
    """

    SET_HW_SHARED_CONTEXT = RETRO_ENVIRONMENT_SET_HW_SHARED_CONTEXT
    """
    .. seealso:: :attr:`.VideoDriver.shared_context`
    """

    GET_VFS_INTERFACE = RETRO_ENVIRONMENT_GET_VFS_INTERFACE
    """
    .. seealso:: :class:`.FileSystemDriver`
    """

    GET_LED_INTERFACE = RETRO_ENVIRONMENT_GET_LED_INTERFACE
    """
    .. seealso:: :class:`.LedDriver`
    """

    GET_AUDIO_VIDEO_ENABLE = RETRO_ENVIRONMENT_GET_AUDIO_VIDEO_ENABLE
    """
    .. seealso:: :class:`.AvEnableFlags`
    """

    GET_MIDI_INTERFACE = RETRO_ENVIRONMENT_GET_MIDI_INTERFACE
    """
    .. seealso:: :class:`.MidiDriver`
    """

    GET_FASTFORWARDING = RETRO_ENVIRONMENT_GET_FASTFORWARDING
    """
    .. seealso:: :attr:`.TimingDriver.throttle_state`
    """

    GET_TARGET_REFRESH_RATE = RETRO_ENVIRONMENT_GET_TARGET_REFRESH_RATE
    """
    .. seealso:: :attr:`.TimingDriver.target_refresh_rate`
    """

    GET_INPUT_BITMASKS = RETRO_ENVIRONMENT_GET_INPUT_BITMASKS
    """
    .. seealso:: :attr:`.InputDriver.bitmasks_supported`
    """

    GET_CORE_OPTIONS_VERSION = RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION
    """
    .. seealso:: :attr:`.OptionDriver.version`
    """

    SET_CORE_OPTIONS = RETRO_ENVIRONMENT_SET_CORE_OPTIONS
    """
    .. seealso:: :attr:`.OptionDriver.set_options`
    """

    SET_CORE_OPTIONS_INTL = RETRO_ENVIRONMENT_SET_CORE_OPTIONS_INTL
    """
    .. seealso:: :attr:`.OptionDriver.set_options_intl`
    """

    SET_CORE_OPTIONS_DISPLAY = RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY
    """
    .. seealso:: :attr:`.OptionDriver.set_display`
    """

    GET_PREFERRED_HW_RENDER = RETRO_ENVIRONMENT_GET_PREFERRED_HW_RENDER
    """
    .. seealso:: :attr:`.VideoDriver.preferred_context`
    """

    GET_DISK_CONTROL_INTERFACE_VERSION = RETRO_ENVIRONMENT_GET_DISK_CONTROL_INTERFACE_VERSION
    SET_DISK_CONTROL_EXT_INTERFACE = RETRO_ENVIRONMENT_SET_DISK_CONTROL_EXT_INTERFACE

    GET_MESSAGE_INTERFACE_VERSION = RETRO_ENVIRONMENT_GET_MESSAGE_INTERFACE_VERSION
    """
    .. seealso:: :attr:`.MessageDriver.version`
    """

    SET_MESSAGE_EXT = RETRO_ENVIRONMENT_SET_MESSAGE_EXT
    """
    .. seealso:: :meth:`.MessageDriver.set_message`
    """

    GET_INPUT_MAX_USERS = RETRO_ENVIRONMENT_GET_INPUT_MAX_USERS
    """
    .. seealso:: :attr:`.InputDriver.max_users`
    """

    SET_AUDIO_BUFFER_STATUS_CALLBACK = RETRO_ENVIRONMENT_SET_AUDIO_BUFFER_STATUS_CALLBACK
    """
    .. seealso:: :attr:`.AudioDriver.buffer_status`
    """

    SET_MINIMUM_AUDIO_LATENCY = RETRO_ENVIRONMENT_SET_MINIMUM_AUDIO_LATENCY
    """
    .. seealso:: :attr:`.AudioDriver.minimum_latency`
    """

    SET_FASTFORWARDING_OVERRIDE = RETRO_ENVIRONMENT_SET_FASTFORWARDING_OVERRIDE
    """
    .. seealso:: :attr:`.TimingDriver.fastforwarding_override`
    """

    SET_CONTENT_INFO_OVERRIDE = RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE
    """
    .. seealso:: :attr:`.ContentDriver.overrides`
    """

    GET_GAME_INFO_EXT = RETRO_ENVIRONMENT_GET_GAME_INFO_EXT
    """
    .. seealso:: :attr:`.ContentDriver.game_info_ext`
    """

    SET_CORE_OPTIONS_V2 = RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2
    """
    .. seealso:: :attr:`.OptionDriver.set_options_v2`
    """

    SET_CORE_OPTIONS_V2_INTL = RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL
    """
    .. seealso:: :attr:`.OptionDriver.set_options_v2_intl`
    """

    SET_CORE_OPTIONS_UPDATE_DISPLAY_CALLBACK = (
        RETRO_ENVIRONMENT_SET_CORE_OPTIONS_UPDATE_DISPLAY_CALLBACK
    )
    """
    .. seealso:: :attr:`.OptionDriver.update_display_callback`
    """

    SET_VARIABLE = RETRO_ENVIRONMENT_SET_VARIABLE
    """
    .. seealso:: :attr:`.OptionDriver.set_variable`
    """

    GET_THROTTLE_STATE = RETRO_ENVIRONMENT_GET_THROTTLE_STATE
    """
    .. seealso:: :attr:`.TimingDriver.throttle_state`
    """

    GET_SAVESTATE_CONTEXT = RETRO_ENVIRONMENT_GET_SAVESTATE_CONTEXT
    """
    .. seealso:: :class:`.SavestateContext`
    """

    GET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE_SUPPORT = (
        RETRO_ENVIRONMENT_GET_HW_RENDER_CONTEXT_NEGOTIATION_INTERFACE_SUPPORT
    )

    GET_JIT_CAPABLE = RETRO_ENVIRONMENT_GET_JIT_CAPABLE
    GET_MICROPHONE_INTERFACE = RETRO_ENVIRONMENT_GET_MICROPHONE_INTERFACE
    """
    .. seealso:: :class:`.MicrophoneDriver`
    """

    SET_NETPACKET_INTERFACE = RETRO_ENVIRONMENT_SET_NETPACKET_INTERFACE
    GET_DEVICE_POWER = RETRO_ENVIRONMENT_GET_DEVICE_POWER
    """
    .. seealso:: :class:`.PowerDriver`
    """

    GET_PLAYLIST_DIRECTORY = RETRO_ENVIRONMENT_GET_PLAYLIST_DIRECTORY
    """
    .. seealso:: :attr:`.PathDriver.playlist_dir`
    """

    GET_FILE_BROWSER_START_DIRECTORY = RETRO_ENVIRONMENT_GET_FILE_BROWSER_START_DIRECTORY
    """
    .. seealso:: :attr:`.PathDriver.file_browser_start_dir`
    """


retro_environment_t = TypedFunctionPointer[c_bool, [CIntArg[c_uint], c_void_ptr]]
"""
Dispatch an environment call from the core to the frontend.

Registered by the :term:`frontend` and called by the :term:`core`
to perform tasks that don't have a dedicated entry point in libretro,
such as querying frontend capabilities or registering structured data.

:param cmd: One of the :class:`.EnvironmentCall` constants (possibly OR'd
    with :data:`~libretro.api.environment.RETRO_ENVIRONMENT_EXPERIMENTAL`
    or :data:`~libretro.api.environment.RETRO_ENVIRONMENT_PRIVATE`).
:param data: A :class:`~libretro.ctypes.c_void_ptr` to the environment-call-specific input or output buffer,
    or :obj:`None` if the call doesn't take any data.
:return: :obj:`True` if the environment call was recognized and (where applicable) succeeded,
    :obj:`False` if the frontend doesn't recognize ``cmd`` or rejected the request.

Corresponds to :c:type:`retro_environment_t` in ``libretro.h``.
"""


__all__ = [
    "EnvironmentCall",
    "retro_environment_t",
    "API_VERSION",
]
