"""Prints the info returned by a :term:`core`'s ``retro_get_system_info``."""

from typer.main import get_command

from ._common import CoreArg, prepare


def main(libretro: CoreArg):
    """
    Load a libretro core and displays its system info.
    Exits with 0 upon success.
    """
    system_info = libretro.get_system_info()

    library_name = system_info.library_name
    library_version = system_info.library_version
    block_extract = system_info.block_extract
    need_fullpath = system_info.need_fullpath
    valid_extensions = system_info.valid_extensions

    print("library_name:", "NULL" if library_name is None else library_name.decode())
    print("library_version:", "NULL" if library_version is None else library_version.decode())
    print("block_extract:", block_extract)
    print("need_fullpath:", need_fullpath)
    print("valid_extensions:", "NULL" if valid_extensions is None else valid_extensions.decode())


app = prepare(main)
command = get_command(app)

if __name__ == "__main__":
    app()
