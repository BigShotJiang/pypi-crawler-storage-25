from lzma import *
