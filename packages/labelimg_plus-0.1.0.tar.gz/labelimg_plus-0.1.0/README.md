# LabelImg Plus Installer

This package installs the required dependencies for **LabelImg Plus**.

## Install

```bash
pip install labelimg-plus
```

## What this package does

It installs these dependencies automatically:

- PyQt5
- lxml
- Pillow
- PyYAML
- opencv-python
- ultralytics

## Next step

After installing dependencies, download the full LabelImg Plus project from GitHub and run it locally.

## Notes

- This PyPI package is an installer/dependency package.
- The full application source is distributed separately.
