"""
Unit tests for ConfigureService.

Tests the async generator-based configuration management service including
target listing, connection testing, and configuration operations.
"""

import pytest
from pathlib import Path
from unittest.mock import Mock, patch, AsyncMock, MagicMock
from typing import Any, Dict, Optional

from features.configure.events import (
    ConfigureConnectionTestEvent,
    ConfigureErrorEvent,
    ConfigureInputNeededEvent,
    ConfigureStatusEvent,
    ConfigureSuccessEvent,
    ConfigureTargetDetailEvent,
    ConfigureTargetListEvent,
)
from features.configure.models import ConfigureInput, ConfigureOptions


class TestConfigureServiceInit:
    """Tests for ConfigureService initialization."""

    def test_initialization(self):
        """Test service initializes correctly.

        Verifies that ConfigureService can be instantiated without errors.
        This test will fail until ConfigureService is implemented.
        """
        from features.configure.service import ConfigureService

        service = ConfigureService()
        assert service is not None


class TestConfigureServiceListTargets:
    """Tests for list_targets() method."""

    @pytest.fixture
    def service(self):
        """Create ConfigureService instance.

        Provides a fresh service instance for each test.
        """
        from features.configure.service import ConfigureService

        return ConfigureService()

    @pytest.fixture
    def input_data(self):
        """Create test input data for list operation.

        Returns ConfigureInput with no target specified (for list operation).
        """
        return ConfigureInput(target_name=None)

    @pytest.fixture
    def options(self):
        """Create test options for list operation.

        Returns ConfigureOptions configured for listing targets.
        """
        return ConfigureOptions(operation="list")

    @pytest.mark.asyncio
    async def test_list_targets_yields_events(self, service, input_data, options):
        """Test that list_targets() yields at least one event.

        Verifies that the async generator yields events when listing targets.
        This is the RED phase test - it will fail because ConfigureService
        doesn't exist yet. Once implemented, it should yield at least one
        event (status, target_list, or error).
        """
        events = []

        async for event in service.list_targets(input_data, options):
            events.append(event)

        # RED phase: This assertion will fail until list_targets is implemented
        assert len(events) >= 1

    @pytest.mark.asyncio
    async def test_list_targets_yields_target_list_event(
        self, service, input_data, options
    ):
        """Test that list_targets() yields a ConfigureTargetListEvent.

        Verifies that the service yields a target list event containing
        the configured targets. This test expects at least one event of
        type ConfigureTargetListEvent.
        """
        events = []

        async for event in service.list_targets(input_data, options):
            events.append(event)

        # RED phase: This will fail until list_targets is implemented
        target_list_events = [
            e for e in events if isinstance(e, ConfigureTargetListEvent)
        ]
        assert len(target_list_events) >= 1

    @pytest.mark.asyncio
    async def test_list_targets_event_has_targets_field(
        self, service, input_data, options
    ):
        """Test that ConfigureTargetListEvent has targets field.

        Verifies that the target list event contains a targets field
        with the expected structure (list of dicts with target info).
        """
        events = []

        async for event in service.list_targets(input_data, options):
            events.append(event)

        # RED phase: This will fail until list_targets is implemented
        target_list_events = [
            e for e in events if isinstance(e, ConfigureTargetListEvent)
        ]
        assert len(target_list_events) > 0
        assert hasattr(target_list_events[0], "targets")
        assert isinstance(target_list_events[0].targets, list)


class TestConfigureServiceEventTypes:
    """Tests for event type structure and validation."""

    def test_configure_status_event_structure(self):
        """Test ConfigureStatusEvent has correct structure.

        Verifies that the status event dataclass has the expected fields
        and type discriminator.
        """
        event = ConfigureStatusEvent(type="status", message="Loading targets...")
        assert event.type == "status"
        assert event.message == "Loading targets..."

    def test_configure_target_list_event_structure(self):
        """Test ConfigureTargetListEvent has correct structure.

        Verifies that the target list event has targets and optional
        default_target fields.
        """
        event = ConfigureTargetListEvent(
            type="target_list",
            targets=[
                {
                    "name": "prod",
                    "engine": "postgresql",
                    "has_password": True,
                    "is_default": True,
                }
            ],
            default_target="prod",
        )
        assert event.type == "target_list"
        assert len(event.targets) == 1
        assert event.default_target == "prod"

    def test_configure_error_event_structure(self):
        """Test ConfigureErrorEvent has correct structure.

        Verifies that error events contain message and optional operation/target fields.
        """
        event = ConfigureErrorEvent(
            type="error",
            message="Connection failed",
            operation="test",
            target_name="prod",
        )
        assert event.type == "error"
        assert event.message == "Connection failed"
        assert event.operation == "test"
        assert event.target_name == "prod"


class TestTargetNotFoundIncludesHint:
    """Target-not-found errors must include 'rdst configure list' hint."""

    @pytest.fixture
    def service(self):
        from features.configure.service import ConfigureService
        return ConfigureService()

    @pytest.fixture
    def mock_config(self):
        cfg = Mock()
        cfg.get.return_value = None
        cfg.list_targets.return_value = []
        cfg.get_default.return_value = None
        return cfg

    @pytest.mark.asyncio
    async def test_get_target_not_found_includes_hint(self, service, mock_config):
        with patch.object(service, "_load_config", return_value=mock_config):
            events = []
            async for event in service.get_target("nonexistent"):
                events.append(event)
        error_events = [e for e in events if isinstance(e, ConfigureErrorEvent)]
        assert len(error_events) == 1
        assert "rdst configure list" in error_events[0].message

    @pytest.mark.asyncio
    async def test_test_connection_not_found_includes_hint(self, service, mock_config):
        with patch.object(service, "_load_config", return_value=mock_config):
            events = []
            async for event in service.test_connection("nonexistent"):
                events.append(event)
        error_events = [e for e in events if isinstance(e, ConfigureErrorEvent)]
        assert len(error_events) == 1
        assert "rdst configure list" in error_events[0].message


class TestConfigureCommandNoTargetError:
    """When no target is specified and no default is configured, configure test
    should return a non-empty error message (not silently empty)."""

    def test_configure_test_no_target_returns_error_message(self):
        """Bug fix: 'rdst configure test' with no target and no default
        should return a clear error message, not an empty string."""
        from features.configure.cli.command import ConfigureCommand

        cmd = ConfigureCommand(client=None)

        with (
            patch("shared.config.targets.TargetsConfig.load", return_value=None),
            patch("shared.config.targets.TargetsConfig.get_default", return_value=None),
        ):
            result = cmd.execute(subcommand="test")

        assert result.ok is False
        assert result.message != "", (
            "Error message should not be empty when no target is specified "
            "and no default is configured"
        )
        assert "target" in result.message.lower() or "configure" in result.message.lower(), (
            f"Error message should mention target or configure. Got: {result.message!r}"
        )


class TestPgVersionNotTruncated:
    """PG version string must not be truncated at 80 chars.

    Tests the truncation logic used in _perform_connection_test:
        (version[:120] + "...") if len(version) > 120 else version
    """

    @staticmethod
    def _apply_version_truncation(version: str) -> str:
        """Reproduce the truncation logic from ConfigureService."""
        return (version[:120] + "...") if len(version) > 120 else version

    def test_120_char_version_not_truncated(self):
        """A 120-char version string should be preserved in full."""
        version = "P" * 120
        result = self._apply_version_truncation(version)
        assert result == version
        assert "..." not in result

    def test_short_version_not_truncated(self):
        """A normal PG version string should not be truncated."""
        version = "PostgreSQL 16.2 on x86_64-pc-linux-gnu"
        result = self._apply_version_truncation(version)
        assert result == version

    def test_very_long_version_truncated_with_ellipsis(self):
        """Versions over 120 chars should be truncated with '...'."""
        version = "P" * 200
        result = self._apply_version_truncation(version)
        assert len(result) == 123
        assert result.endswith("...")


class TestTestConnectionSingleStatusMessage:
    """test_connection must emit exactly ONE status/progress message, not two."""

    @pytest.fixture
    def service(self):
        from features.configure.service import ConfigureService
        return ConfigureService()

    @pytest.mark.asyncio
    async def test_no_duplicate_testing_connection_status(self, service):
        """Bug fix: test_connection previously emitted a duplicate
        'Testing connection to' ConfigureStatusEvent before the
        ConfigureConnectionTestEvent. Verify only one status-like
        message is emitted before the result.

        The expected event sequence is:
          1. ConfigureConnectionTestEvent (status="in_progress") - the connecting message
          2. ConfigureConnectionTestEvent (status="success"|"failed") - the result
        There should be NO ConfigureStatusEvent with "Testing connection" text.
        """
        mock_config = {
            "engine": "postgresql",
            "host": "localhost",
            "port": 5432,
            "user": "test",
            "database": "testdb",
        }

        mock_cfg = Mock()
        mock_cfg.get.return_value = mock_config
        mock_cfg.get_default.return_value = "test-target"

        events = []
        with patch.object(service, "_load_config", return_value=mock_cfg):
            with patch.object(
                service,
                "_perform_connection_test",
                new_callable=AsyncMock,
                return_value={"success": True, "message": "Connected!", "server_version": "PG 15"},
            ):
                async for event in service.test_connection("test-target"):
                    events.append(event)

        # No ConfigureStatusEvent should be emitted — only ConnectionTestEvents
        status_events = [
            e for e in events if isinstance(e, ConfigureStatusEvent)
        ]
        assert len(status_events) == 0, (
            f"Expected zero ConfigureStatusEvent in test_connection, "
            f"got {len(status_events)}: {[e.message for e in status_events]}"
        )

        # Should have exactly 2 ConnectionTestEvents: in_progress + success
        conn_events = [
            e for e in events if isinstance(e, ConfigureConnectionTestEvent)
        ]
        assert len(conn_events) == 2, (
            f"Expected 2 ConfigureConnectionTestEvent, got {len(conn_events)}"
        )
        assert conn_events[0].status == "in_progress"
        assert conn_events[1].status == "success"
