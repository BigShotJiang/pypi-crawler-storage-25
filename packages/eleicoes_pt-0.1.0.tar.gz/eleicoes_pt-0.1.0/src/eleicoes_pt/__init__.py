"""
eleicoes-pt — Resultados eleitorais portugueses desde 1975, em acesso aberto.

Dados pré-processados a partir das fontes oficiais do MAI (Ministério da
Administração Interna), publicados como release no GitHub e acessíveis
diretamente por este pacote.

Tipos de eleição disponíveis:
  AR    — Assembleia da República
  CM    — Câmaras Municipais
  AM    — Assembleias Municipais
  AF    — Assembleias de Freguesia
  PR    — Presidente da República
  PE    — Parlamento Europeu
  ALRAM — Assembleia Legislativa da Região Autónoma da Madeira
  ALRAA — Assembleia Legislativa da Região Autónoma dos Açores

Utilização::

    from eleicoes_pt import fetch, list_available

    # Ver o que está disponível
    print(list_available())

    # Obter resultados
    data = fetch("AR", 2024)
    data = fetch("CM", 2021)

Para comparar os dados publicados com os ficheiros originais do MAI::

    from eleicoes_pt import audit
    audit("AR", 2024)
"""

from .client import fetch, list_available, audit

__all__ = ["fetch", "list_available", "audit"]
