"""
Cliente para descarregar e auditar dados eleitorais publicados no GitHub Release.
"""

import gzip
import json
import urllib.request
from pathlib import Path

_RELEASE_BASE = "https://github.com/openlousada/eleicoes-pt/releases/download/data"

_ELECTION_TYPES = {"AR", "CM", "AM", "AF", "PR", "PE", "ALRAM", "ALRAA"}

# Mapeamento tipo → anos disponíveis (actualizado com cada release)
_AVAILABLE: dict[str, list[int]] = {
    "AR":    [1975, 1976, 1979, 1980, 1983, 1985, 1987, 1991, 1995, 1999, 2002,
              2005, 2009, 2011, 2015, 2019, 2022, 2024],
    "CM":    [1982, 1985, 1989, 1993, 1997, 2001],
    "AM":    [1982, 1985, 1989, 1993],
    "AF":    [1982, 1985, 1989, 1993, 1997],
    "PR":    [1976, 1980, 1986, 1991, 1996, 2001, 2006, 2011],
    "PE":    [1987, 1994, 1999, 2004, 2009],
    "ALRAM": [1976, 1980, 1984, 1988, 1992, 1996],
    "ALRAA": [1976],
}


def list_available() -> dict[str, list[int]]:
    """Devolve os tipos e anos disponíveis no release de dados."""
    return {k: list(v) for k, v in _AVAILABLE.items()}


def fetch(election_type: str, year: int, cache_dir: Path | None = None) -> list[dict]:
    """
    Descarrega e devolve os resultados eleitorais para o tipo e ano indicados.

    Args:
        election_type: Tipo de eleição (ex: "AR", "CM", "PR"). Case-insensitive.
        year:          Ano eleitoral.
        cache_dir:     Directório de cache local. Se None, usa uma pasta
                       temporária do sistema. Ficheiros em cache evitam nova
                       transferência de rede.

    Returns:
        Lista de dicts com os resultados. A estrutura varia por tipo de eleição.

    Raises:
        ValueError: Tipo ou ano não disponível.
        urllib.error.HTTPError: Falha na transferência.

    Exemplo::

        from eleicoes_pt import fetch
        resultados = fetch("AR", 2024)
        for r in resultados[:3]:
            print(r)
    """
    election_type = election_type.upper()
    if election_type not in _ELECTION_TYPES:
        raise ValueError(f"Tipo de eleição desconhecido: {election_type!r}. "
                         f"Disponíveis: {sorted(_ELECTION_TYPES)}")
    available_years = _AVAILABLE.get(election_type, [])
    if year not in available_years:
        raise ValueError(f"Ano {year} não disponível para {election_type}. "
                         f"Disponíveis: {available_years}")

    filename = f"{election_type}_{year}.json.gz"
    url = f"{_RELEASE_BASE}/{filename}"

    if cache_dir is not None:
        cache_dir = Path(cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        cached = cache_dir / filename
        if cached.exists():
            return _load_gz(cached)

    data = _download(url)

    if cache_dir is not None:
        cached.write_bytes(data)

    return json.loads(gzip.decompress(data))


def audit(election_type: str, year: int) -> dict:
    """
    Compara os dados publicados com o ficheiro XLSX original do MAI.

    Descarrega o ficheiro original da fonte oficial e o JSON publicado,
    e reporta diferenças. Útil para verificar a integridade dos dados.

    Args:
        election_type: Tipo de eleição (ex: "AR").
        year:          Ano eleitoral.

    Returns:
        Dict com ``{"match": bool, "published_count": int, "source_count": int,
        "differences": list}``.

    Nota:
        Requer ``xlrd`` ou ``openpyxl`` instalado (dependência opcional).
        Instale com ``pip install eleicoes-pt[audit]``.
    """
    try:
        import importlib
        importlib.import_module("openpyxl")
    except ImportError:
        raise ImportError(
            "Para usar audit(), instale as dependências opcionais: "
            "pip install eleicoes-pt[audit]"
        )

    published = fetch(election_type, year)
    # A lógica de comparação com o XLSX original do MAI é específica por tipo.
    # Esta função está reservada para implementação futura por tipo de eleição.
    raise NotImplementedError(
        f"Auditoria para {election_type} ainda não implementada. "
        "Contribuições bem-vindas — ver CONTRIBUTING.md."
    )


def _download(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "eleicoes-pt"})
    with urllib.request.urlopen(req, timeout=60) as resp:
        return resp.read()


def _load_gz(path: Path) -> list[dict]:
    with gzip.open(path, "rb") as f:
        return json.loads(f.read())
