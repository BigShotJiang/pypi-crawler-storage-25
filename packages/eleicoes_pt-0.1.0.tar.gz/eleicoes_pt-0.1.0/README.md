# eleicoes-pt

![banner](https://raw.githubusercontent.com/openlousada/eleicoes-pt/main/banner.png)

Resultados eleitorais portugueses desde 1975, em acesso aberto.

Dados pré-processados a partir das fontes oficiais do MAI (Ministério da Administração Interna), disponíveis para download directo sem necessidade de parsear XLSX ou tratar formatos históricos.

---

## Instalação

```bash
pip install eleicoes-pt
```

---

## Utilização

```python
from eleicoes_pt import fetch, list_available

# Ver o que está disponível
print(list_available())
# {
#   'AR': [1975, 1976, 1979, 1980, 1983, 1985, 1987, 1991, 1995, ...],
#   'CM': [1982, 1985, 1989, ...],
#   ...
# }

# Obter resultados
resultados = fetch("AR", 2024)
resultados = fetch("CM", 2021)
resultados = fetch("PR", 2011)
```

Os dados são devolvidos como lista de dicts. Ficheiros descarregados ficam disponíveis offline se passar `cache_dir`:

```python
from pathlib import Path
resultados = fetch("AR", 2024, cache_dir=Path("~/.cache/eleicoes-pt").expanduser())
```

---

## Tipos de eleição

| Código  | Eleição                                              |
|---------|------------------------------------------------------|
| `AR`    | Assembleia da República                              |
| `CM`    | Câmaras Municipais                                   |
| `AM`    | Assembleias Municipais                               |
| `AF`    | Assembleias de Freguesia                             |
| `PR`    | Presidente da República                              |
| `PE`    | Parlamento Europeu                                   |
| `ALRAM` | Assembleia Legislativa da Região Autónoma da Madeira |
| `ALRAA` | Assembleia Legislativa da Região Autónoma dos Açores |

---

## Modo de auditoria

Para verificar a integridade dos dados publicados face ao ficheiro original do MAI:

```bash
pip install eleicoes-pt[audit]
```

```python
from eleicoes_pt import audit
audit("AR", 2024)
```

---

## Fonte dos dados

Todos os dados provêm do MAI — Ministério da Administração Interna, disponíveis em [sg.mai.gov.pt](https://www.sg.mai.gov.pt). Os ficheiros originais (XLSX) são processados uma vez e publicados neste repositório como release de dados para facilitar o acesso.

---

## Licença

MIT © [Open Lousada](https://github.com/openlousada)
