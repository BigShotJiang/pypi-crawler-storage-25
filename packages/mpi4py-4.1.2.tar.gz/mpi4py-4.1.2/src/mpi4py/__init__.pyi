from typing import Sequence

__version__: str = ...
__author__: str = ...
__credits__: str = ...

from . import MPI

__all__: list[str] = ["MPI"]

class Rc:
    initialize: bool = True
    threads: bool = True
    thread_level: str = "multiple"
    finalize: bool | None = None
    fast_reduce: bool = True
    recv_mprobe: bool = True
    irecv_bufsz: int = 32768
    errors: str = "exception"
    def __init__(
        self,
        **kwargs: bool | int | str | None,
    ) -> None: ...
    def __call__(
        self,
        **kwargs: bool | int | str | None,
    ) -> None: ...
    def __setattr__(
        self,
        name: str,
        value: bool | int | str | None,
    ) -> None: ...

rc: Rc = ...

def get_include() -> str: ...
def get_config() -> dict[str, str]: ...
def profile(
    name: str,
    *,
    path: str | Sequence[str] | None = None,
) -> None: ...
