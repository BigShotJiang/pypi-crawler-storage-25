from requests.auth import HTTPBasicAuth


def get_auth(username: str, password: str) -> HTTPBasicAuth:
    """
    Returns HTTPBasicAuth instance with given credentials.

    :param username:
    :param password:
    :return: HTTPBasicAuth instance
    """
    return HTTPBasicAuth(username, password)
