BASE_URL = "https://migros-api.themindsite.com"

CRAWLING_DATA_ENDPOINT = "/api/crawling_data"
MATCHING_DATA_ENDPOINT = "/api/matching_data"
