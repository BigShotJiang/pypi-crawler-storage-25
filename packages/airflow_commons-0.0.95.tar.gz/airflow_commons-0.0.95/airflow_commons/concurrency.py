from concurrent.futures.thread import ThreadPoolExecutor

from airflow_commons.internal.util.log_utils import get_logger


class ThreadPoolOperator(ThreadPoolExecutor):
    def __init__(self, max_workers: int):
        super().__init__(max_workers=max_workers)
        self.futures = {}
        self.logger = get_logger(__name__)

    def register(self, operation_id: int, operation, *args, **kwargs):
        self.futures[operation_id] = self.submit(operation, *args, **kwargs)

    def finish(self):
        self.shutdown(wait=True, cancel_futures=False)
        self.check_failures()

    def check_failures(self):
        failed_operation_count = 0
        for operation_id, future in self.futures.items():
            exception = future.exception()
            if exception:
                self.logger.error(
                    f"An error occurred during operation {operation_id} processing with exception: "
                    + str(exception)
                )
                failed_operation_count += 1
        if failed_operation_count > 0:
            raise Exception(
                f"Errors occurred, failed operation count is {failed_operation_count}"
            )
