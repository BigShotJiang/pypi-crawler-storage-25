import{l as o,a as r}from"../chunks/-09Pgo8V.js";export{o as load_css,r as start};
