from __future__ import annotations

import asyncio

import pytest

from agent_app.grid_node.config import GridNodeConfig
from agent_app.grid_node.protocol import Slot, Stereotype
from agent_app.grid_node.supervisor import start_grid_node_supervisor


class FakeClock:
    def __init__(self) -> None:
        self.sleeps: list[float] = []

    async def sleep(self, _delay: float) -> None:
        self.sleeps.append(_delay)
        await asyncio.sleep(0)


class RecordingService:
    def __init__(self, *, fail_start: bool = False, request_stop: bool = False, fail_heartbeat: bool = False) -> None:
        self.fail_start = fail_start
        self.request_stop = request_stop
        self.fail_heartbeat = fail_heartbeat
        self.stop_called = False
        self.heartbeat_calls = 0

    async def start(self) -> None:
        if self.fail_start:
            raise RuntimeError("boom")

    async def stop(self) -> None:
        self.stop_called = True

    async def run_heartbeat_once(self) -> None:
        self.heartbeat_calls += 1
        if self.fail_heartbeat:
            raise RuntimeError("heartbeat failed")
        if self.request_stop:
            self.request_stop = False

    def snapshot(self) -> dict[str, object]:
        return {"requested_stop": self.request_stop}


class FlakyServiceFactory:
    def __init__(self, *, failures_before_success: int) -> None:
        self.failures_before_success = failures_before_success
        self.created = 0

    def __call__(self) -> RecordingService:
        self.created += 1
        return RecordingService(fail_start=self.created <= self.failures_before_success)


class AlwaysCrashingServiceFactory:
    def __init__(self) -> None:
        self.created = 0

    def __call__(self) -> RecordingService:
        self.created += 1
        return RecordingService(fail_start=True)


@pytest.mark.asyncio
async def test_supervisor_restarts_service_after_crash() -> None:
    factory = FlakyServiceFactory(failures_before_success=1)
    handle = start_grid_node_supervisor(factory=factory, clock=FakeClock())
    await handle.start()
    await handle.wait_until_running()
    assert factory.created == 2
    await handle.stop()


@pytest.mark.asyncio
async def test_supervisor_reports_errored_after_five_crashes_in_window() -> None:
    factory = AlwaysCrashingServiceFactory()
    handle = start_grid_node_supervisor(factory=factory, clock=FakeClock())
    await handle.start()
    await handle.wait_until_errored()
    assert handle.errored is True
    assert factory.created == 5


@pytest.mark.asyncio
async def test_supervisor_reports_errored_when_factory_raises() -> None:
    # Factory exceptions (e.g. config errors, transient zmq init failures)
    # must drive the supervisor through its retry path rather than crashing
    # the task silently and stalling `wait_until_running`/`wait_until_errored`.
    attempts = 0

    def crashing_factory() -> RecordingService:
        nonlocal attempts
        attempts += 1
        raise RuntimeError("factory boom")

    handle = start_grid_node_supervisor(factory=crashing_factory, clock=FakeClock())
    await handle.start()
    await handle.wait_until_errored()
    assert handle.errored is True
    assert attempts == 5


@pytest.mark.asyncio
async def test_supervisor_calls_stop_when_service_requests_stop() -> None:
    services: list[RecordingService] = []

    def factory() -> RecordingService:
        service = RecordingService(request_stop=True)
        services.append(service)
        return service

    handle = start_grid_node_supervisor(factory=factory, clock=FakeClock())
    await handle.start()
    await handle.wait_until_stopped()
    assert services[0].stop_called is True


@pytest.mark.asyncio
async def test_supervisor_runs_periodic_heartbeat_with_config_interval() -> None:
    service = RecordingService()
    clock = FakeClock()
    handle = start_grid_node_supervisor(factory=lambda: service, clock=clock, config=_config(heartbeat_sec=2.5))
    await handle.start()
    await handle.wait_until_running()
    for _ in range(20):
        if service.heartbeat_calls:
            break
        await asyncio.sleep(0)
    assert service.heartbeat_calls >= 1
    assert clock.sleeps[-1] == 2.5
    await handle.stop()


def test_supervisor_snapshot_includes_status() -> None:
    handle = start_grid_node_supervisor(factory=RecordingService, clock=FakeClock())
    assert handle.snapshot()["status"] == "starting"


@pytest.mark.asyncio
async def test_supervisor_reports_stopped_after_stop() -> None:
    service = RecordingService()
    handle = start_grid_node_supervisor(factory=lambda: service, clock=FakeClock())
    await handle.start()
    await handle.wait_until_running()
    await handle.stop()
    assert handle.snapshot()["status"] == "stopped"
    assert handle.snapshot()["running"] is False


@pytest.mark.asyncio
async def test_supervisor_reports_errored_after_heartbeat_failure() -> None:
    service = RecordingService(fail_heartbeat=True)
    handle = start_grid_node_supervisor(factory=lambda: service, clock=FakeClock(), config=_config(heartbeat_sec=1.0))
    await handle.start()
    await handle.wait_until_errored()
    assert service.stop_called is True
    assert handle.snapshot()["status"] == "error"


class HeartbeatFlakyService(RecordingService):
    def __init__(self, *, fail_first_heartbeat: bool) -> None:
        super().__init__()
        self._fail_first_heartbeat = fail_first_heartbeat

    async def run_heartbeat_once(self) -> None:
        self.heartbeat_calls += 1
        if self._fail_first_heartbeat and self.heartbeat_calls == 1:
            raise RuntimeError("heartbeat flap")


class HeartbeatFlakyServiceFactory:
    """Mints a single failing service then healthy ones, so the supervisor
    settles instead of cycling — used to assert single-flap recovery."""

    def __init__(self) -> None:
        self.services: list[HeartbeatFlakyService] = []

    @property
    def created(self) -> int:
        return len(self.services)

    def __call__(self) -> HeartbeatFlakyService:
        service = HeartbeatFlakyService(fail_first_heartbeat=not self.services)
        self.services.append(service)
        return service


@pytest.mark.asyncio
async def test_supervisor_restarts_service_when_heartbeat_raises() -> None:
    """A heartbeat-time crash used to set ``_errored`` and exit the supervisor,
    leaving the dead ``GridNodeService`` reachable via ``handle.service`` —
    subsequent ``reconfigure`` calls would invoke ``reregister_with_caps_update``
    on the stopped instance and raise ``called before start()``. The supervisor
    must restart instead: stop the dead instance, factory a fresh one, and
    resume heartbeating. ``_errored`` only fires after the backoff budget is
    exhausted within the window.
    """
    factory = HeartbeatFlakyServiceFactory()
    clock = FakeClock()
    handle = start_grid_node_supervisor(factory=factory, clock=clock, config=_config(heartbeat_sec=0.01))
    await handle.start()
    await handle.wait_until_running()
    for _ in range(200):
        if factory.created >= 2 and any(s.heartbeat_calls >= 1 for s in factory.services[1:]):
            break
        await asyncio.sleep(0)
    assert factory.created >= 2, "supervisor did not respawn service after heartbeat failure"
    assert factory.services[0].stop_called is True, "supervisor did not stop dead service before restart"
    assert handle.errored is False
    # Backoff must space restart attempts to prevent a tight crash loop — a
    # regression that drops ``await self._clock.sleep(backoff.next_delay())``
    # from the heartbeat-fail path would skip this entry entirely.
    assert any(delay >= 1.0 for delay in clock.sleeps), (
        f"supervisor did not honor backoff sleep before restart; recorded sleeps: {clock.sleeps}"
    )
    await handle.stop()


class AlwaysHeartbeatCrashingService(RecordingService):
    async def run_heartbeat_once(self) -> None:
        self.heartbeat_calls += 1
        raise RuntimeError("heartbeat always fails")


@pytest.mark.asyncio
async def test_supervisor_reports_errored_after_repeated_heartbeat_failures() -> None:
    """When heartbeat crashes survive every restart attempt, the shared backoff
    budget eventually trips and ``_errored`` becomes terminal — preventing an
    infinite restart loop on a permanently broken relay.
    """
    services: list[AlwaysHeartbeatCrashingService] = []

    def factory() -> AlwaysHeartbeatCrashingService:
        service = AlwaysHeartbeatCrashingService()
        services.append(service)
        return service

    handle = start_grid_node_supervisor(factory=factory, clock=FakeClock(), config=_config(heartbeat_sec=0.01))
    await handle.start()
    await handle.wait_until_errored()
    assert handle.errored is True
    assert handle.is_running() is False
    assert len(services) >= 2
    assert all(s.stop_called for s in services)


def _config(*, heartbeat_sec: float) -> GridNodeConfig:
    return GridNodeConfig(
        node_id="node-1",
        node_uri="http://127.0.0.1:5555",
        appium_upstream="http://127.0.0.1:4723",
        slots=[Slot(id="slot-1", stereotype=Stereotype(caps={"platformName": "Android"}))],
        hub_publish_url="tcp://127.0.0.1:4442",
        hub_subscribe_url="tcp://127.0.0.1:4443",
        heartbeat_sec=heartbeat_sec,
        session_timeout_sec=300.0,
        proxy_timeout_sec=30.0,
    )
