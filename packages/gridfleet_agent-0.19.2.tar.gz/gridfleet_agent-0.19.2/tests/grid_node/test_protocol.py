from __future__ import annotations

import json
from pathlib import Path

from agent_app.grid_node.protocol import EventType, Slot, Stereotype, build_slots, event_envelope
from tests.grid_node.fixtures._substitute import substitute_placeholders

FIXTURES = Path(__file__).parent / "fixtures" / "decoded"


def test_known_event_types_match_captured_fixtures() -> None:
    assert {event.value for event in EventType} == {
        "node-added",
        "node-heartbeat",
        "session-created",
        "session-closed",
        "node-drain-started",
        "node-drain-complete",
        "node-removed",
    }


def test_event_envelope_shape_matches_captured_node_added() -> None:
    golden = substitute_placeholders(json.loads((FIXTURES / "01_node_bringup" / "node_added.json").read_text()))
    envelope = event_envelope(EventType.NODE_ADDED, golden["data"])
    assert envelope == golden


def test_build_slots_emits_android_native_and_chrome_slots() -> None:
    slots = build_slots(
        base_caps={"platformName": "Android", "appium:platform": "android_mobile"},
        grid_slots=["native", "chrome"],
    )
    assert [slot.stereotype.caps.get("browserName") for slot in slots] == [None, "chrome"]
    assert all(slot.stereotype.caps["platformName"] == "Android" for slot in slots)


def test_build_slots_defaults_grid_run_id_to_free() -> None:
    slots = build_slots(
        base_caps={"platformName": "Android", "appium:platform": "android_mobile"},
        grid_slots=["native", "chrome"],
    )

    assert all(slot.stereotype.caps["gridfleet:run_id"] == "free" for slot in slots)


def test_build_slots_preserves_explicit_grid_run_id() -> None:
    slots = build_slots(
        base_caps={"platformName": "Android", "gridfleet:run_id": "run-1"},
        grid_slots=["native"],
    )

    assert slots[0].stereotype.caps["gridfleet:run_id"] == "run-1"


def test_build_slots_sets_browser_name_for_non_native_slots() -> None:
    slots = build_slots(
        base_caps={"platformName": "Android"},
        grid_slots=["native", "chrome", "firefox"],
    )
    assert slots[0].stereotype.caps.get("browserName") is None
    assert slots[1].stereotype.caps["browserName"] == "chrome"
    assert slots[2].stereotype.caps["browserName"] == "firefox"


def test_slot_round_trip_dict() -> None:
    slot = Slot(id="slot-1", stereotype=Stereotype(caps={"platformName": "iOS"}), state="AVAILABLE")
    assert Slot.from_dict(slot.to_dict()) == slot
