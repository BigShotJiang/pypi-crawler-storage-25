"""Background task that ships queued log lines to the manager."""

from __future__ import annotations

import asyncio
import contextlib
import logging
from typing import TYPE_CHECKING, Any
from uuid import UUID

from agent_app import observability as agent_observability
from agent_app.logs.schemas import AgentLogBatch, ShippedLogLine

if TYPE_CHECKING:
    import httpx

    from agent_app.pack.host_identity import HostIdentity

logger = logging.getLogger("agent.logs.shipper")
DROP_REPORT_INTERVAL_SEC = 60.0


class LogShipperTask:
    def __init__(
        self,
        *,
        client: httpx.AsyncClient,
        host_identity: HostIdentity,
        boot_id: UUID,
        queue: asyncio.Queue[ShippedLogLine],
        base_url: str = "",
        auth: httpx.Auth | None = None,
        batch_size: int = 200,
        flush_interval_sec: float = 2.0,
        backoff_initial_sec: float = 1.0,
        backoff_max_sec: float = 60.0,
        drop_report_interval_sec: float = DROP_REPORT_INTERVAL_SEC,
    ) -> None:
        self._client = client
        self._host_identity = host_identity
        self._boot_id = boot_id
        self._queue = queue
        self._base_url = base_url.rstrip("/")
        self._auth = auth
        self._batch_size = batch_size
        self._flush_interval = flush_interval_sec
        self._backoff_initial = backoff_initial_sec
        self._backoff_max = backoff_max_sec
        self._drop_report_interval = drop_report_interval_sec
        self._stop = asyncio.Event()
        self._last_reported_queue_drops = 0
        self._last_reported_rejected = 0
        self._drop_report_task: asyncio.Task[None] | None = None
        self.dropped_rejected = 0

    def stop(self) -> None:
        self._stop.set()

    async def run(self) -> None:
        self._drop_report_task = asyncio.create_task(self._drop_report_loop())
        try:
            while not self._stop.is_set():
                batch = await self._collect_batch()
                if not batch:
                    continue
                await self._ship_with_retry(batch)
            remaining = await self._drain_queue()
            if remaining:
                await self._ship_with_retry(remaining)
        except asyncio.CancelledError:
            remaining = await self._drain_queue()
            if remaining:
                try:
                    await self._ship_with_retry(remaining)
                finally:
                    await self._stop_drop_report()
                    raise
        finally:
            await self._stop_drop_report()
            self._emit_drop_report()

    async def _stop_drop_report(self) -> None:
        task = self._drop_report_task
        if task is None:
            return
        if not task.done():
            task.cancel()
        with contextlib.suppress(asyncio.CancelledError, Exception):
            await task

    async def _drop_report_loop(self) -> None:
        try:
            while not self._stop.is_set():
                try:
                    await asyncio.wait_for(self._stop.wait(), timeout=self._drop_report_interval)
                except TimeoutError:
                    self._emit_drop_report()
        except asyncio.CancelledError:
            return

    def _emit_drop_report(self) -> None:
        handler = agent_observability.shipper_handler
        queue_drops = handler.dropped_count if handler is not None else 0
        rejected = self.dropped_rejected
        delta_queue = queue_drops - self._last_reported_queue_drops
        delta_rejected = rejected - self._last_reported_rejected
        if delta_queue == 0 and delta_rejected == 0:
            return
        logger.warning(
            "log shipper drops: queue=%d (+%d), rejected=%d (+%d)",
            queue_drops,
            delta_queue,
            rejected,
            delta_rejected,
        )
        self._last_reported_queue_drops = queue_drops
        self._last_reported_rejected = rejected

    async def _collect_batch(self) -> list[ShippedLogLine]:
        batch: list[ShippedLogLine] = []
        get_task = asyncio.create_task(self._queue.get())
        stop_task = asyncio.create_task(self._stop.wait())
        done, pending = await asyncio.wait(
            {get_task, stop_task},
            timeout=self._flush_interval,
            return_when=asyncio.FIRST_COMPLETED,
        )
        for task in pending:
            task.cancel()
        if get_task not in done:
            await asyncio.gather(*pending, return_exceptions=True)
            return batch
        first = get_task.result()
        batch.append(first)
        while len(batch) < self._batch_size:
            try:
                batch.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                break
        return batch

    async def _drain_queue(self) -> list[ShippedLogLine]:
        out: list[ShippedLogLine] = []
        while True:
            try:
                out.append(self._queue.get_nowait())
            except asyncio.QueueEmpty:
                return out

    def _current_host_uuid(self) -> UUID | None:
        raw = self._host_identity.get()
        if raw is None:
            return None
        try:
            return UUID(raw)
        except ValueError:
            return None

    async def _ship_with_retry(self, batch: list[ShippedLogLine]) -> None:
        payload = AgentLogBatch(boot_id=self._boot_id, lines=batch)
        serialized = payload.model_dump(mode="json")
        post_kwargs: dict[str, Any] = {"json": serialized}
        if self._auth is not None:
            post_kwargs["auth"] = self._auth
        delay = self._backoff_initial
        while not self._stop.is_set():
            host_uuid = self._current_host_uuid()
            if host_uuid is None:
                logger.warning("log batch deferred: host identity not assigned or not a UUID")
                self.dropped_rejected += len(batch)
                return
            url = f"{self._base_url}/agent/{host_uuid}/log-batch" if self._base_url else f"/agent/{host_uuid}/log-batch"
            try:
                response = await self._client.post(url, **post_kwargs)
            except Exception as exc:
                logger.warning("log batch network error: %s", exc)
            else:
                if response.status_code in (200, 202):
                    return
                if 400 <= response.status_code < 500:
                    logger.warning("log batch rejected %s: %s", response.status_code, response.text[:200])
                    self.dropped_rejected += len(batch)
                    return
                logger.warning("log batch 5xx %s; will retry", response.status_code)
            await asyncio.sleep(delay)
            delay = min(delay * 2, self._backoff_max)
