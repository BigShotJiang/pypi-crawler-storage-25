"""redactron CLI — orchestration only, no business logic."""

from __future__ import annotations

import json as json_mod
import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from redactron.vault.store import VaultStore

import typer

from redactron import __version__
from redactron.config import default_profile_path
from redactron.errors import ProfileValidationError, RedactronError
from redactron.profile import Profile

log = logging.getLogger(__name__)

_BANNER = (
    "██████╗ ███████╗██████╗  █████╗  ██████╗████████╗██████╗  ██████╗ ███╗   ██╗\n"
    "██╔══██╗██╔════╝██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔═══██╗████╗  ██║\n"
    "██████╔╝█████╗  ██║  ██║███████║██║        ██║   ██████╔╝██║   ██║██╔██╗ ██║\n"
    "██╔══██╗██╔══╝  ██║  ██║██╔══██║██║        ██║   ██╔══██╗██║   ██║██║╚██╗██║\n"
    "██║  ██║███████╗██████╔╝██║  ██║╚██████╗   ██║   ██║  ██║╚██████╔╝██║ ╚████║\n"
    "╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝ ╚═════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═══╝"
)
_TAGLINE = "Local-only PII redaction. No cloud. No subscription."


def _print_banner(quiet: bool = False) -> None:
    """Print the ASCII banner + tagline unless quiet, NO_COLOR, or non-TTY stdout."""
    import os
    import sys
    if quiet or os.environ.get("NO_COLOR") or not sys.stdout.isatty():
        return
    from rich.console import Console
    console = Console(highlight=False)
    console.print(_BANNER, style="bold cyan")
    console.print(_TAGLINE, style="dim white")
    console.print()

app = typer.Typer(
    name="redactron",
    help="Local-only CLI for batch PII redaction in PDFs.",
    add_completion=False,
)


def _error(msg: str, debug: bool = False, exc: Optional[BaseException] = None) -> None:
    """Print a user-friendly error and exit 1."""
    typer.echo(f"Error: {msg}", err=True)
    if debug and exc is not None:
        import traceback
        traceback.print_exc()
    raise typer.Exit(1)


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(  # noqa: UP007
        None, "--version", "-V", is_eager=True, help="Show version and exit."
    ),
) -> None:
    """redactron — local-only PDF PII redaction."""
    if version:
        typer.echo(f"redactron {__version__}")
        raise typer.Exit()
    if ctx.invoked_subcommand is None:
        typer.echo("Use --help to see available commands.")


@app.command("version")
def version_cmd() -> None:
    """Show version and exit."""
    _print_banner()
    typer.echo(f"redactron {__version__}")


@app.command()
def init() -> None:
    """Create ~/.redactron/ directory and initialize the audit database.

    No profile.yaml is created. Use the template-first workflow instead:
      1. Copy docs/examples/profile-template.yaml to /tmp/<client>.yaml
      2. Fill in your PII values
      3. redactron profile add --client <id> --from /tmp/<client>.yaml
    """
    import os

    profile_dir = Path.home() / ".redactron"
    profile_dir.mkdir(parents=True, exist_ok=True)
    typer.echo(f"✅ Created directory: {profile_dir}")

    # Touch the audit DB (creates schema if absent)
    db_path = Path(os.environ.get("REDACTRON_DB", str(profile_dir / "audit.db")))
    if not db_path.exists():
        import sqlite3
        # Importing log_run triggers schema creation on first use; just connect to create file
        conn = sqlite3.connect(str(db_path))
        conn.close()
        typer.echo(f"✅ Initialized audit database: {db_path}")
    else:
        typer.echo(f"   Audit database already exists: {db_path}")

    # Backwards-compat: warn if legacy profile.yaml exists
    legacy = profile_dir / "profile.yaml"
    if legacy.exists():
        typer.echo(
            "⚠️  Legacy profile.yaml detected. It will continue to work but is deprecated.\n"
            f"   Migrate with: redactron profile add --client default --from {legacy}",
            err=True,
        )
    else:
        typer.echo(
            "\nTo add your first client profile:\n"
            "  1. Copy docs/examples/profile-template.yaml to /tmp/me.yaml\n"
            "  2. Fill in your PII values\n"
            "  3. redactron profile add --client me --from /tmp/me.yaml"
        )


@app.command()
def run(
    path: Path = typer.Argument(..., help="PDF file or directory to redact."),
    profile: str = typer.Option("", "--profile", "-p", help="Profile YAML path."),
    output: str = typer.Option("", "--output", "-o", help="Output path."),
    threshold: float = typer.Option(0.5, "--threshold", "-t", help="Detection score threshold."),
    no_ocr: bool = typer.Option(False, "--no-ocr", help="Disable OCR on image-only pages."),
    force_ocr: bool = typer.Option(False, "--force-ocr", help="Force OCR on every page."),
    no_verify: bool = typer.Option(False, "--no-verify", help="Skip post-redaction verification."),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON."),
    subject: str = typer.Option("", "--subject", "-s", help="Subject slug for audit tagging."),
    no_report: bool = typer.Option(False, "--no-report", help="Skip writing report files."),
    per_file_reports: bool = typer.Option(
        False, "--per-file-reports", help="Write per-file reports (default: consolidated only)."
    ),
    debug: bool = typer.Option(False, "--debug", help="Show full stack traces on error."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress banner and progress."),
    client: str = typer.Option("", "--client", "-c", help="Load profile from vault by client ID."),
) -> None:
    """Redact PII from a PDF file or directory of PDFs."""
    _print_banner(quiet or json_output)
    from redactron.profile import load_profile

    if client:
        loaded_profile = _load_profile_for_client(client)
    else:
        profile_path = Path(profile) if profile else default_profile_path()
        vault_path = _default_vault_path()

        # Backwards-compat: if vault exists and no explicit --profile, warn
        if not profile and vault_path.exists() and profile_path.exists():
            typer.echo(
                "⚠️  Deprecation: both profile.yaml and vault.enc found. "
                "Using profile.yaml. Migrate with: redactron profile import profile.yaml",
                err=True,
            )

        try:
            loaded_profile = load_profile(profile_path)
        except ProfileValidationError as exc:
            msg = str(exc)
            typer.echo(
                f"❌ Profile error: {msg}\n"
                "See docs/PROFILE.md for the full schema. Use --debug for details.",
                err=True,
            )
            if debug:
                import traceback
                traceback.print_exc()
            raise typer.Exit(1) from exc

    log.info(
        "Loaded profile: %s (subject: %s)",
        loaded_profile.name,
        loaded_profile.subject.display_name,
    )

    try:
        _run_pipeline(
            path=path,
            profile=loaded_profile,
            output=Path(output) if output else None,
            threshold=threshold,
            verify=not no_verify,
            json_output=json_output,
            subject_id=subject,
            write_reports=not no_report,
            per_file_reports=per_file_reports,
            ocr_enabled=not no_ocr,
            force_ocr=force_ocr,
        )
    except typer.Exit:
        raise
    except RedactronError as exc:
        _error(str(exc), debug=debug, exc=exc)
    except Exception as exc:
        _error(f"Unexpected error: {exc}", debug=debug, exc=exc)


def _run_pipeline(
    path: Path,
    profile: Profile,
    output: Optional[Path],
    threshold: float,
    verify: bool,
    json_output: bool,
    subject_id: str = "",
    write_reports: bool = True,
    per_file_reports: bool = False,
    ocr_enabled: bool = True,
    force_ocr: bool = False,
) -> None:
    """Orchestrate extract → detect → redact → verify for one or more PDFs."""
    import time

    from rich.console import Console

    from redactron.pipeline import BatchFileError, _categorize_error, run_pipeline

    pdfs = _collect_pdfs(path)
    if not pdfs:
        typer.echo("No PDF files found.", err=True)
        raise typer.Exit(1)

    batch = len(pdfs) > 1
    results = []
    errors: list[BatchFileError] = []
    console = Console(highlight=False)
    err_console = Console(highlight=False, stderr=True)

    for idx, pdf_path in enumerate(pdfs, 1):
        out_path = _output_path(pdf_path, output, batch)
        t0 = time.monotonic()
        try:
            result = run_pipeline(
                pdf_path,
                out_path,
                profile,
                score_threshold=threshold,
                verify=verify,
                write_reports=write_reports and per_file_reports,
                ocr_enabled=ocr_enabled,
                force_ocr=force_ocr,
            )
        except Exception as exc:
            category, mitigation = _categorize_error(exc)
            errors.append(BatchFileError(
                path=pdf_path,
                category=category,
                message=str(exc).splitlines()[0],
                mitigation=mitigation,
            ))
            log.debug("Error processing %s: %s", pdf_path, exc, exc_info=True)
            if not json_output:
                err_console.print(
                    f"  [red]✗[/red] {pdf_path.name}  "
                    f"[dim]\\[{category}][/dim] {mitigation}"
                )
            continue

        dur = time.monotonic() - t0
        det = len(result.detections)
        vf = result.verification_passed

        if vf is False:
            status_icon = "[red]✗[/red]"
        elif det == 0:
            status_icon = "[white]⚪[/white]"
        else:
            status_icon = "[green]✓[/green]"

        r: dict[str, object] = {
            "input": str(result.input_path),
            "output": str(result.output_path),
            "detections": det,
            "duration_s": round(dur, 1),
            "subject": subject_id or None,
            "verification": None,
        }
        if vf is not None:
            r["verification"] = {"passed": vf, "survivors": result.survivors}

        results.append(r)

        if not json_output:
            vstr = "" if vf is None else (" [green]✓[/green]" if vf else " [red]✗ survivors[/red]")
            console.print(
                f"  {status_icon} [cyan]{pdf_path.name}[/cyan]  "
                f"{det} detections  {dur:.1f}s{vstr}"
            )

    if json_output:
        typer.echo(json_mod.dumps(results, indent=2))
        return

    # Error summary
    if errors:
        err_console.print(f"\n[yellow]⚠️  {len(errors)} file(s) failed:[/yellow]")
        for e in errors:
            err_console.print(
                f"  [red]✗[/red] {e.path.name}  "
                f"[dim]\\[{e.category}][/dim] {e.message}\n"
                f"    [dim]→ {e.mitigation}[/dim]"
            )

    n_ok = len(results)
    n_err = len(errors)
    total_det = sum(r["detections"] for r in results if isinstance(r["detections"], int))

    if batch:
        console.print(
            f"\n[bold]Summary:[/bold] {n_ok} processed, "
            f"{n_err} errored, {total_det} total redactions"
        )

    # Consolidated batch report
    if batch and write_reports:
        from datetime import datetime

        from redactron.report.markdown import write_batch_summary
        run_ts = datetime.now().strftime("%Y-%m-%d-%H%M")
        reports_dir = (output or pdfs[0].parent) / "redacted-reports"
        md_path, _ = write_batch_summary(results, errors, reports_dir, run_ts)
        console.print(f"[dim]Report: {md_path}[/dim]")

    if n_err > 0:
        raise typer.Exit(1 if n_ok > 0 else 2)


def _collect_pdfs(path: Path) -> list[Path]:
    """Return list of PDF paths from a file or directory."""
    if path.is_file():
        return [path]
    if path.is_dir():
        return sorted(path.rglob("*.pdf"))
    return []


def _output_path(input_path: Path, output: Optional[Path], batch: bool) -> Path:
    """Compute the output path for a redacted PDF.

    Single-file: alongside input (or explicit --output).
    Batch: {input_dir}/redacted/{stem}_redacted.pdf
    """
    stem = input_path.stem + "_redacted"
    name = stem + ".pdf"
    if output is None:
        if batch:
            return input_path.parent / "redacted" / name
        return input_path.parent / name
    if batch:
        return output / "redacted" / name
    return output


_DEFAULT_PROFILE = """\
version: 1
name: default
subject:
  display_name: "Your Name"
  aliases: []
  addresses: []
  phones: []
  emails: []
  ssns: []
  account_numbers: []
  custom_patterns: []
detection:
  use_presidio: false
  presidio_entities: []
  fuzzy_match: true
  match_threshold: 0.85
  full_token_min_length: 2
  ocr_fallback: true
"""

# ---------------------------------------------------------------------------
# subject subcommand group
# ---------------------------------------------------------------------------

subject_app = typer.Typer(name="subject", help="Manage redaction subjects.")
app.add_typer(subject_app)


@subject_app.command("add")
def subject_add(
    subject_id: str = typer.Argument(..., help="Subject slug (e.g. 'alice-smith')."),
    display_name: str = typer.Option("", "--name", "-n", help="Display name."),
) -> None:
    """Create or update a subject entry in the audit log."""
    from redactron.audit.log import add_subject

    name = display_name or subject_id
    add_subject(subject_id, name)
    typer.echo(f"Subject '{subject_id}' ({name}) saved.")


@subject_app.command("list")
def subject_list() -> None:
    """List all subjects in the audit log."""
    from redactron.audit.log import list_subjects

    subjects = list_subjects()
    if not subjects:
        typer.echo("No subjects found. Use `redactron subject add <id>` to create one.")
        return
    for s in subjects:
        typer.echo(f"{s['id']:20s}  {s['display_name']:30s}  docs={s['document_count']}")


@subject_app.command("show")
def subject_show(
    subject_id: str = typer.Argument(..., help="Subject slug."),
) -> None:
    """Show details for a specific subject."""
    from redactron.audit.log import get_subject

    s = get_subject(subject_id)
    if s is None:
        typer.echo(f"Subject '{subject_id}' not found.", err=True)
        raise typer.Exit(1)
    typer.echo(f"ID:             {s['id']}")
    typer.echo(f"Display name:   {s['display_name']}")
    typer.echo(f"Created:        {s['created_at']}")
    typer.echo(f"Last used:      {s['last_used_at']}")
    typer.echo(f"Document count: {s['document_count']}")


# ---------------------------------------------------------------------------
# dry-run command
# ---------------------------------------------------------------------------


@app.command("dry-run")
def dry_run(
    path: Path = typer.Argument(..., help="PDF file or directory to scan."),
    profile: str = typer.Option("", "--profile", "-p", help="Profile YAML path."),
    threshold: float = typer.Option(0.5, "--threshold", "-t", help="Detection score threshold."),
    json_output: bool = typer.Option(False, "--json", help="Output results as JSON."),
    debug: bool = typer.Option(False, "--debug", help="Show full stack traces on error."),
) -> None:
    """Show what would be redacted without writing any output files.

    Exits 0 if detections found, 1 if none.
    """
    from redactron.profile import load_profile

    profile_path = Path(profile) if profile else default_profile_path()
    try:
        loaded_profile = load_profile(profile_path)
    except ProfileValidationError as exc:
        _error(str(exc), debug=debug, exc=exc)
        return

    pdfs = _collect_pdfs(path)
    if not pdfs:
        typer.echo("No PDF files found.", err=True)
        raise typer.Exit(1)

    try:
        all_detections = _dry_run_pipeline(pdfs, loaded_profile, threshold)
    except RedactronError as exc:
        _error(str(exc), debug=debug, exc=exc)
        return

    if json_output:
        import json as _json
        typer.echo(_json.dumps(
            [
                {
                    "file": str(d["file"]),
                    "page": d["page"],
                    "entity_type": d["entity_type"],
                    "text": d["text"],
                    "score": d["score"],
                }
                for d in all_detections
            ],
            indent=2,
        ))
    else:
        if not all_detections:
            typer.echo("No PII detected.")
            raise typer.Exit(1)
        # Print table
        typer.echo(f"{'File':<30} {'Page':>4}  {'Type':<20} {'Score':>5}  Text")
        typer.echo("-" * 90)
        for d in all_detections:
            fname = Path(str(d["file"])).name[:28]
            text_preview = str(d["text"])[:40]
            score = d["score"]
            etype = d["entity_type"]
            typer.echo(f"{fname:<30} {d['page']:>4}  {etype:<20} {score:>5.2f}  {text_preview}")
        typer.echo(f"\n{len(all_detections)} detection(s) across {len(pdfs)} file(s).")

    if not all_detections:
        raise typer.Exit(1)


def _dry_run_pipeline(
    pdfs: list[Path],
    profile: Profile,
    score_threshold: float,
) -> list[dict]:  # type: ignore[type-arg]
    """Run extract+detect only; return list of detection dicts."""
    from redactron.detect.account_detector import detect_custom_patterns
    from redactron.detect.address_detector import detect_addresses
    from redactron.detect.name_detector import detect_names
    from redactron.extract.text_layer import extract_text_layers, open_pdf
    from redactron.redact.partial import detect_account_numbers

    results = []
    for pdf_path in pdfs:
        doc = open_pdf(pdf_path)
        layers = extract_text_layers(doc)

        detections = []
        detections.extend(detect_names(layers, profile))
        detections.extend(detect_addresses(layers, profile))
        detections.extend(detect_account_numbers(doc, profile))
        detections.extend(detect_custom_patterns(layers, profile))

        if profile.detection.use_presidio and profile.detection.presidio_entities:
            from redactron.detect.presidio_detector import detect as presidio_detect
            detections.extend(
                presidio_detect(
                    layers,
                    entities=list(profile.detection.presidio_entities),
                    score_threshold=score_threshold,
                )
            )

        for det in detections:
            results.append({
                "file": pdf_path,
                "page": det.page_num,
                "entity_type": det.entity_type,
                "text": det.text,
                "score": det.score,
            })

    return results


# ---------------------------------------------------------------------------
# verify command
# ---------------------------------------------------------------------------


@app.command()
def verify(
    path: Path = typer.Argument(..., help="Redacted PDF to verify."),
    profile: str = typer.Option("", "--profile", "-p", help="Profile YAML path."),
    threshold: float = typer.Option(0.5, "--threshold", "-t", help="Detection score threshold."),
    json_output: bool = typer.Option(False, "--json", help="Output result as JSON."),
    debug: bool = typer.Option(False, "--debug", help="Show full stack traces on error."),
) -> None:
    """Verify a redacted PDF for PII survivors.

    Exits 0 if clean, 1 if survivors found.
    """
    from redactron.extract.text_layer import open_pdf
    from redactron.profile import load_profile
    from redactron.verify.verifier import verify_redaction

    profile_path = Path(profile) if profile else default_profile_path()
    try:
        loaded_profile = load_profile(profile_path)
    except ProfileValidationError as exc:
        _error(str(exc), debug=debug, exc=exc)
        return

    try:
        doc = open_pdf(path)
        result = verify_redaction(doc, loaded_profile, score_threshold=threshold)
    except RedactronError as exc:
        _error(str(exc), debug=debug, exc=exc)
        return

    if json_output:
        import json as _json
        typer.echo(_json.dumps({
            "passed": result.passed,
            "survivors": [s.text for s in result.survivors],
            "duration_ms": result.duration_ms,
        }, indent=2))
    else:
        if result.passed:
            ms = result.duration_ms
            typer.echo(f"✅ {path.name}: clean — no PII survivors detected ({ms}ms)")
        else:
            typer.echo(
                f"❌ {path.name}: {len(result.survivors)} PII survivor(s) detected:",
                err=True,
            )
            for s in result.survivors:
                typer.echo(f"  page {s.page_num}: [{s.entity_type}] {s.text!r}", err=True)

    if not result.passed:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# log command
# ---------------------------------------------------------------------------


@app.command("log")
def log_cmd(
    subject: str = typer.Option("", "--subject", "-s", help="Filter by subject slug."),
    limit: int = typer.Option(20, "--limit", "-n", help="Number of rows to show."),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON."),
) -> None:
    """Show recent audit log entries."""
    from redactron.audit.log import get_runs

    rows = get_runs(subject_id=subject or None, limit=limit)

    if json_output:
        import json as _json
        typer.echo(_json.dumps(rows, indent=2, default=str))
        return

    if not rows:
        typer.echo("No audit log entries found.")
        return

    typer.echo(f"{'ID':>4}  {'File':<30} {'Subject':<15} {'Det':>4} {'V':>1}  Processed")
    typer.echo("-" * 80)
    for r in rows:
        fname = (r.get("original_filename") or "")[:28]
        subj = (r.get("subject_id") or "")[:13]
        det = r.get("items_detected", 0)
        vp = r.get("verification_passed")
        v_icon = "✅" if vp == 1 else ("❌" if vp == 0 else "-")
        ts = str(r.get("processed_at", ""))[:19]
        typer.echo(f"{r['id']:>4}  {fname:<30} {subj:<15} {det:>4} {v_icon}  {ts}")


# ---------------------------------------------------------------------------
# report command
# ---------------------------------------------------------------------------


@app.command()
def report(
    run_id: int = typer.Argument(..., help="Audit log run ID (from `redactron log`)."),
) -> None:
    """Re-render the Markdown report for a past run from the audit log."""
    from redactron.audit.log import get_runs
    from redactron.report.markdown import render_from_db

    rows = get_runs(limit=run_id + 100)
    # rows are newest-first; find by id
    match = next((r for r in rows if r["id"] == run_id), None)
    if match is None:
        typer.echo(f"Run ID {run_id} not found in audit log.", err=True)
        raise typer.Exit(1)
    typer.echo(render_from_db(match))


if __name__ == "__main__":
    app()


# ---------------------------------------------------------------------------
# vault subcommand group (M3.5)
# ---------------------------------------------------------------------------

vault_app = typer.Typer(name="vault", help="Manage the encrypted profile vault.")
app.add_typer(vault_app)


def _default_vault_path() -> Path:
    return Path.home() / ".redactron" / "vault.enc"


def _get_vault_store() -> VaultStore:  # noqa: F821
    from redactron.vault.keychain import get_keychain_backend
    from redactron.vault.store import VaultStore

    return VaultStore(_default_vault_path(), get_keychain_backend())


def _load_profile_for_client(client_id: str) -> Profile:
    """Load a Profile from the vault for the given client_id."""
    store = _get_vault_store()
    profile_dict = store.get_profile(client_id)
    if profile_dict is None:
        metas = store.list_profiles()
        available = ", ".join(m.client_id for m in metas) or "(none)"
        typer.echo(
            f"Error: client '{client_id}' not found in vault. Available: {available}",
            err=True,
        )
        raise typer.Exit(1)
    return Profile.model_validate(profile_dict)


@vault_app.command("init")
def vault_init() -> None:
    """Create the encrypted vault and store master key in macOS Keychain."""
    from redactron.vault.keychain import get_keychain_backend
    from redactron.vault.store import VaultStore

    vault_path = _default_vault_path()
    if vault_path.exists():
        typer.echo(f"Vault already exists: {vault_path}")
        raise typer.Exit()

    store = VaultStore(vault_path, get_keychain_backend())
    store.save({"version": 1, "profiles": {}})
    typer.echo(f"✅ Vault created: {vault_path}")
    typer.echo("Add profiles with: redactron profile add --client <id>")


# ---------------------------------------------------------------------------
# profile subcommand group (M3.5)
# ---------------------------------------------------------------------------

profile_app = typer.Typer(name="profile", help="Manage encrypted client profiles.")
app.add_typer(profile_app)


def _mask_value(value: str, keep_last: int = 4) -> str:
    """Mask a string, keeping only the last N characters."""
    if len(value) <= keep_last:
        return value
    return "*" * (len(value) - keep_last) + value[-keep_last:]


def _mask_profile(profile_dict: dict) -> dict:  # type: ignore[type-arg]
    """Return a copy of profile_dict with PII values masked."""
    import copy

    masked = copy.deepcopy(profile_dict)
    subj = masked.get("subject", {})
    if subj.get("display_name"):
        parts = subj["display_name"].split()
        subj["display_name"] = " ".join(
            (p[0] + "***") if len(p) > 1 else p for p in parts
        )
    for field in ("phones", "emails", "ssns", "addresses"):
        if subj.get(field):
            subj[field] = [_mask_value(str(v)) for v in subj[field]]
    if subj.get("account_numbers"):
        subj["account_numbers"] = [
            {**a, "value": _mask_value(str(a.get("value", "")))}
            for a in subj["account_numbers"]
        ]
    return masked


@profile_app.command("add")
def profile_add(
    client: str = typer.Option(..., "--client", "-c", help="Client ID slug."),
    display_name: str = typer.Option("", "--name", "-n", help="Display name."),
    from_yaml: str = typer.Option(
        "", "--from", help="Import from YAML file (source is secure-wiped)."
    ),
    keep_source: bool = typer.Option(
        False, "--keep-source", help="Keep source YAML after import (default: wipe)."
    ),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without writing or wiping."),
) -> None:
    """Add a new client profile to the vault. Source YAML is secure-wiped after import."""
    import os

    import yaml

    from redactron.profile import load_profile

    store = _get_vault_store()

    if from_yaml:
        src_path = Path(from_yaml)
        profile_obj = load_profile(src_path)
        profile_dict = profile_obj.model_dump(mode="json")
        name = display_name or profile_obj.subject.display_name

        if dry_run:
            typer.echo(f"[dry-run] Would import '{from_yaml}' as client '{client}':")
            typer.echo(yaml.dump(profile_dict, default_flow_style=False))
            return

        try:
            store.add_profile(client, profile_dict, name)
            typer.echo(f"✅ Profile '{client}' ({name}) added to vault.")
        except Exception as exc:
            typer.echo(f"Error: {exc}", err=True)
            raise typer.Exit(1) from exc

        # Secure-wipe source unless --keep-source
        if not keep_source and src_path.exists():
            size = src_path.stat().st_size
            with src_path.open("wb") as fh:
                fh.write(os.urandom(max(size, 1)))
            src_path.unlink()
            typer.echo(f"🔒 Source file wiped: {src_path}")
    else:
        if dry_run:
            typer.echo("[dry-run] No --from specified; nothing to validate.")
            return
        if not display_name:
            display_name = typer.prompt("Display name")
        profile_dict = {"subject": {"display_name": display_name}, "detection": {}}
        name = display_name
        try:
            store.add_profile(client, profile_dict, name)
            typer.echo(f"✅ Profile '{client}' ({name}) added to vault.")
        except Exception as exc:
            typer.echo(f"Error: {exc}", err=True)
            raise typer.Exit(1) from exc


@profile_app.command("list")
def profile_list() -> None:
    """List all client profiles (no PII shown)."""
    store = _get_vault_store()
    metas = store.list_profiles()
    if not metas:
        typer.echo("No profiles found. Use `redactron profile add --client <id>`.")
        return
    typer.echo(f"{'Client ID':<20}  {'Display Name':<30}  Created")
    typer.echo("-" * 70)
    for m in metas:
        typer.echo(f"{m.client_id:<20}  {m.display_name:<30}  {m.created_at[:10]}")


@profile_app.command("show")
def profile_show(
    client: str = typer.Argument(..., help="Client ID to show."),
    reveal: bool = typer.Option(
        False, "--reveal", help="Show unmasked values (requires Touch ID)."
    ),
) -> None:
    """Show a client profile. Values are masked by default."""
    import sys

    import yaml

    store = _get_vault_store()
    profile_dict = store.get_profile(client)
    if profile_dict is None:
        typer.echo(f"Profile '{client}' not found.", err=True)
        raise typer.Exit(1)

    if reveal:
        if not sys.stdin.isatty():
            typer.echo("Error: --reveal requires an interactive terminal.", err=True)
            raise typer.Exit(1)
        confirm = typer.confirm(
            "⚠️  This will display unmasked PII. Are you sure?", default=False
        )
        if not confirm:
            typer.echo("Aborted.")
            raise typer.Exit()
        # Touch ID is triggered by the vault open() call already made above.
        typer.echo(yaml.dump(profile_dict, default_flow_style=False))
    else:
        typer.echo(yaml.dump(_mask_profile(profile_dict), default_flow_style=False))


@profile_app.command("delete")
def profile_delete(
    client: str = typer.Argument(..., help="Client ID to delete."),
) -> None:
    """Delete a client profile from the vault."""
    confirm = typer.confirm(f"Delete profile '{client}'?", default=False)
    if not confirm:
        typer.echo("Aborted.")
        raise typer.Exit()
    store = _get_vault_store()
    store.delete_profile(client)
    typer.echo(f"Profile '{client}' deleted.")


@profile_app.command("rename")
def profile_rename(
    old_id: str = typer.Argument(..., help="Current client ID."),
    new_id: str = typer.Argument(..., help="New client ID."),
) -> None:
    """Rename a client profile."""
    store = _get_vault_store()
    try:
        store.rename_profile(old_id, new_id)
        typer.echo(f"Profile '{old_id}' renamed to '{new_id}'.")
    except Exception as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc


@profile_app.command("import")
def profile_import(
    yaml_path: Path = typer.Argument(..., help="Legacy profile.yaml to import."),
    client: str = typer.Option("", "--client", "-c", help="Client ID (default: filename stem)."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Validate without writing or wiping."),
) -> None:
    """Import a legacy profile.yaml into the vault and secure-wipe the source."""
    import yaml

    from redactron.vault.migrate import migrate_profile

    client_id = client or yaml_path.stem
    store = _get_vault_store()

    if dry_run:
        from redactron.vault.migrate import migrate_profile as _mp
        profile_dict = _mp(yaml_path, client_id, store, dry_run=True)
        typer.echo(f"[dry-run] Would import '{yaml_path}' as client '{client_id}':")
        typer.echo(yaml.dump(profile_dict, default_flow_style=False))
        return

    try:
        migrate_profile(yaml_path, client_id, store)
        typer.echo(f"✅ Imported '{yaml_path}' as client '{client_id}'. Source file wiped.")
    except Exception as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc


@profile_app.command("edit")
def profile_edit(
    client: str = typer.Argument(..., help="Client ID to edit."),
) -> None:
    """Open profile in $EDITOR, re-encrypt on save. Temp file is secure-wiped."""
    import os
    import shlex
    import subprocess
    import tempfile

    import yaml

    store = _get_vault_store()
    profile_dict = store.get_profile(client)
    if profile_dict is None:
        typer.echo(f"Profile '{client}' not found.", err=True)
        raise typer.Exit(1)

    # BLD-FIX-13: merge existing data onto full schema defaults so all fields visible
    # Use hardcoded dict to avoid Pydantic validation (BLD-FIX-34: Subject(display_name='') crashes)
    _PROFILE_DEFAULTS: dict = {  # type: ignore[type-arg]
        "version": 1,
        "name": "",
        "subject": {
            "display_name": "",
            "aliases": [],
            "addresses": [],
            "phones": [],
            "emails": [],
            "ssns": [],
            "account_numbers": [],
            "custom_patterns": [],
        },
        "detection": {
            "use_presidio": False,
            "presidio_entities": [],
            "fuzzy_match": True,
            "match_threshold": 0.85,
            "full_token_min_length": 2,
            "ocr_fallback": True,
            "column_aware": True,
            "scan_figures": False,
            "address_line_bridge_window": 3,
        },
    }
    merged: dict = {**_PROFILE_DEFAULTS, **profile_dict}  # type: ignore[type-arg]
    merged["subject"] = {**_PROFILE_DEFAULTS["subject"], **profile_dict.get("subject", {})}
    merged["detection"] = {**_PROFILE_DEFAULTS["detection"], **profile_dict.get("detection", {})}

    # BLD-FIX-12: shlex.split so EDITOR="code --wait" works correctly
    editor_str = os.environ.get("EDITOR", "vi")
    editor_cmd = shlex.split(editor_str)

    with tempfile.NamedTemporaryFile(
        suffix=".yaml", mode="w", delete=False, prefix=f"redactron_{client}_"
    ) as tmp:
        tmp_path = Path(tmp.name)
        tmp.write(yaml.dump(merged, default_flow_style=False))

    try:
        tmp_path.chmod(0o600)
        subprocess.run([*editor_cmd, str(tmp_path)], check=True)
        updated = yaml.safe_load(tmp_path.read_text())
        store.update_profile(client, updated)
        typer.echo(f"✅ Profile '{client}' updated.")
    except Exception as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(1) from exc
    finally:
        # Secure-wipe: overwrite with random bytes then unlink
        if tmp_path.exists():
            size = tmp_path.stat().st_size
            with tmp_path.open("wb") as fh:
                fh.write(os.urandom(max(size, 1)))
            tmp_path.unlink()
