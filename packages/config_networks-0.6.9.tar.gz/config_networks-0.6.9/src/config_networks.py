"""
see readme for best description
build a neural network from config files
for examples of config files, look in net_configs
supported FFN layers, CNN layers, and dictionary netowrks (for when input space is a dictionary of multiple images/vectors)
also supports 'split' - allows for splitting into multiple heads (i.e. policy, value)
    returns a tuple of tensors when passed into CustomNN
"""

import inspect

import torch
from torch import nn


def get_kwargs(Constructor, dic):
    """
    returns a kwargs dict to pass into Constructor
    takes only keys from dic that belong in Constructor
        if Constructor is called as Constructor(kwarg1=None,kwarg2=None) and dic={'fake_kwarg':c,'kwarg1':t},
            output will be {'kwarg1':t}
    """
    keywords = inspect.getfullargspec(Constructor).args
    return {k: dic[k] for k in keywords if k in dic}


def layer_from_config_dict(dic, input_shape, only_shape=False):
    """
    returns nn layer from a layer config dict
    handles Linear, flatten, relu, tanh, cnn, maxpool, avgpool, dropout, identity
    Args:
        dic: layer config dict
        {
            'type': type of layer (REQUIRED)
            'other parameters': other values
        }
            i.e.
            {
             'type':'CNN',
             'channels':64,
             'kernel':(9,9),
             'stride':(3,3),
             'padding':(0,0),
            }
            {
             'type':'ReLU',
            }
        input_shape: UNBATCHED shape of input to network
            required for some layer types
            if we have unbatched_input_shape, then should set input_shape=(1,*unbatched_input_shape)
        only_shape: only calculate shapes, do not make networks
    Returns:
        layer, output shape (tuple or none)
    """
    assert input_shape is not None
    Typ: str = dic["type"]
    typ = Typ.lower()
    layer = None

    # these layers do not change the shape, and do not require any calculation of input dimension
    # any additional kwargs are found by get_kwargs and passed to the torch constructor
    easy_layers = {
        "identity": nn.Identity,
        "relu": nn.ReLU,
        "sigmoid": nn.Sigmoid,
        "leakyrelu": nn.LeakyReLU,
        "tanh": nn.Tanh,
        "softmax": nn.Softmax,
        "dropout": nn.Dropout,
        "dropout1d": nn.Dropout1d,
        "dropout2d": nn.Dropout2d,
        "dropout3d": nn.Dropout3d,
    }

    # stores the layer, and whether out_channels is required
    # this is so we only have to compute the cnn output shape once
    cnn_layers = {
        "cnn": (nn.Conv2d, True),
        "maxpool": (nn.MaxPool2d, False),
        "avgpool": (nn.AvgPool2d, False),
    }
    if typ in easy_layers:
        if not only_shape:
            Layer = easy_layers[typ]
            layer = Layer(**get_kwargs(Layer, dic))
        shape = input_shape
    elif typ == "linear":
        # passes calculated shape into in_features, computes output shape
        assert "out_features" in dic, "REQUIRED argument out_features"
        out_features = dic["out_features"]
        if not only_shape:
            layer = nn.Linear(
                in_features=input_shape[-1],
                **get_kwargs(nn.Linear, dic),
            )
        shape = list(input_shape[:-1]) + [out_features]
    elif typ == "flatten":
        start_dim = dic.get("start_dim", 1)
        end_dim = dic.get("end_dim", -1)
        dic = dic.copy()
        dic["start_dim"] = start_dim
        dic["end_dim"] = end_dim
        if not only_shape:
            layer = nn.Flatten(**get_kwargs(nn.Flatten, dic))
        # INCLUSIVE of end dim
        # convert to batched first to make this less annoying (+1s everywhere)
        input_shape = [-1] + list(input_shape)
        # shenanagins to avoid issues with end_dim=-1
        middle_shape = input_shape[end_dim]
        for dim in input_shape[start_dim:end_dim]:
            middle_shape = middle_shape * dim
        # input_shape[end_dim+1:] also fails for end_dim=-1
        shape = input_shape[:start_dim] + [middle_shape] + (input_shape[end_dim:])[1:]
        # remove the batched shape
        shape = shape[1:]
    elif typ == "embedding":
        assert "num_embeddings" in dic and "embedding_dim" in dic, "REQUIRED arguments num_embeddings and embedding_dim"
        if not only_shape:
            layer = nn.Embedding(**get_kwargs(nn.Embedding, dic))
        shape = list(input_shape) + [dic["embedding_dim"]]
    # image stuff has annoying output shape calculation
    # only need to write it once
    elif typ in cnn_layers:
        dic = dic.copy()
        Layer, requires_out_channels = cnn_layers[typ]
        (in_channels, H, W) = input_shape
        kernel_size = dic["kernel_size"]
        if type(kernel_size) is int:
            kernel_size = (kernel_size, kernel_size)
        dic["kernel_size"] = kernel_size

        stride = dic.get("stride", 1)
        if type(stride) is int:
            stride = (stride, stride)
        dic["stride"] = stride

        padding = dic.get("padding", 0)
        if type(padding) is int:
            padding = (padding, padding)
        dic["padding"] = padding

        # this is used in Conv2d
        dic["in_channels"] = in_channels

        Hp, Wp = (
            (H + 2 * padding[0] - kernel_size[0]) // stride[0] + 1,
            (W + 2 * padding[1] - kernel_size[1]) // stride[1] + 1,
        )
        if requires_out_channels:
            assert "out_channels" in dic, "REQUIRED argument out_channels in " + typ + " layer"

            out_channels = dic["out_channels"]
        else:
            out_channels = in_channels
        if not only_shape:
            layer = Layer(**get_kwargs(Layer, dic))
        shape = (out_channels, Hp, Wp)
    elif (Typ in dir(nn)) or (Typ.startswith("torch.nn.") and Typ[len("torch.nn.") :] in dir(nn)):
        if Typ[len("torch.nn.") :] in dir(nn):
            Typ = Typ[len("torch.nn.") :]
        Layer = getattr(nn, Typ)
        # needs this to calculate next layer, if we are using unknown torch layers
        assert "output_shape" in dic, "output_shape required for torch layers"
        kwargs = get_kwargs(Layer, dic)
        layer = Layer(**kwargs)
        shape = dic["output_shape"]
    elif typ == "custom":
        assert "output_shape" in dic, "output_shape required for custom layers"
        assert "module" in dic, "module required for custom layers"
        Layer = dic["module"]
        kwargs = get_kwargs(Layer, dic)
        layer = Layer(**kwargs)
        shape = dic["output_shape"]
    else:
        raise Exception("type unknown:", typ)
    shape = tuple(shape)
    return layer, shape


def convert_shape(shape):
    if type(shape) is dict:
        return {k: convert_shape(s) for k, s in shape.items()}
    elif type(shape[0]) is int:
        return tuple(shape)
    else:
        return tuple(convert_shape(s) for s in shape)


class _CustomNNSplit(nn.Module):
    """
    Network to split an input into a tuple, applying each specified head to the input
    """

    def __init__(
        self,
        input_shape,
        layer_dict_lists,
    ):
        """
        Args:
            input_shape: shape of input
            layer_dict_lists: list of lists of layer dicts
        """
        super().__init__()
        input_shape = convert_shape(input_shape)
        heads = []  # list of CustomNN objects that are the heads
        output_shapes = []
        for layer_dict_list in layer_dict_lists:
            if layer_dict_list is None or len(layer_dict_list) == 0:
                heads.append(nn.Identity())
                output_shapes.append(input_shape)
            else:
                structure = {
                    "input_shape": input_shape,
                    "layers": layer_dict_list,
                }
                head = CustomNN(structure=structure)
                heads.append(head)
                output_shapes.append(head.output_shape)

        self.heads = nn.ModuleList(heads)
        self.output_shape = tuple(output_shapes)

    def forward(self, X):
        return tuple(head(X) for head in self.heads)


class _CustomNNParallel(nn.Module):
    """
    Network to compute on tuple of tensors in parallel,
        after computation, can leave as a tuple, concatenate them along a dimension, or take the sum
    """

    def __init__(
        self,
        input_shape,
        layer_dict_lists=None,
        combine_tails="tuple",
        **kwargs,
    ):
        """
        Args:
            input_shape: shape of input, is a tuple of input shapes
            layer_dict_lists: list of lists of layer dicts
                same length as input_shape, the ith layer dict list will be applied to the ith input before combining
                if None, does no computation on each branch
                each list can also be swapped with None, which does no computation
            combine_tails: how to combine the tuple
        """
        super().__init__()
        input_shape = convert_shape(input_shape)
        if layer_dict_lists is None:
            layer_dict_lists = [None for _ in input_shape]
        assert len(input_shape) == len(layer_dict_lists), (
            f"number of branches ({len(layer_dict_lists)}) must match length of input tuple ({len(input_shape)})"
        )
        tails = []  # list of CustomNN objects that are the tails
        out_shapes = []
        for in_sh, layer_dict_list in zip(input_shape, layer_dict_lists):
            if layer_dict_list is None or len(layer_dict_list) == 0:
                tails.append(nn.Identity())
                out_shapes.append(in_sh)
            else:
                structure = {
                    "input_shape": in_sh,
                    "layers": layer_dict_list,
                }
                tail = CustomNN(structure=structure)
                tails.append(tail)
                out_shapes.append(tail.output_shape)
        out_shapes = tuple(out_shapes)
        self.tails = nn.ModuleList(tails)
        self.combine_tails = combine_tails
        self.extra_kwargs = kwargs

        if "combined_idxs" in self.extra_kwargs:
            self.extra_kwargs["uncombined_idxs"] = [i for i in range(len(out_shapes)) if i not in self.extra_kwargs["combined_idxs"]]
        if self.combine_tails == "tuple" or self.combine_tails == "dict":
            if "extract_sub_tuples" in self.extra_kwargs:
                self.extra_kwargs["extract_sub_tuples"] = set(self.extra_kwargs["extract_sub_tuples"])
                self.output_shape = []
                for i, sh in enumerate(out_shapes):
                    if i in self.extra_kwargs["extract_sub_tuples"]:
                        # sh is a tuple of shapes, extend the array by these shapes
                        assert type(sh[0]) is tuple, f'indices specified by "extract_sub_tuples" must be tuples, index {i} is a tensor'
                        self.output_shape.extend(sh)
                    else:
                        self.output_shape.append(sh)
                self.output_shape = tuple(self.output_shape)
            else:
                self.output_shape = out_shapes
            if self.combine_tails == "dict":
                assert "output_keys" in self.extra_kwargs, "if converting tuple to dict, 'output_keys' must be specified"
                assert len(self.extra_kwargs["output_keys"]) == len(self.output_shape), (
                    f"number of output keys must be match number of elements in the tuple ({len(self.output_shape)}). recieved keys {self.extra_kwargs['output_keys']}"
                )
                self.output_shape = {key_i: output_keys_i for key_i, output_keys_i in zip(self.extra_kwargs["output_keys"], self.output_shape)}
        elif self.combine_tails == "sum":
            combined_idxs = self.extra_kwargs.get("combined_idxs", list(range(len(out_shapes))))
            comb_shape = out_shapes[combined_idxs[0]]
            assert all(out_shapes[idx] == comb_shape for idx in combined_idxs), (
                f"when combining with sum, all shapes should be same size. Got {[out_shapes[idx] for idx in combined_idxs]}"
            )
            if "combined_idxs" in self.extra_kwargs:
                self.output_shape = []
                for i, sh in enumerate(out_shapes):
                    if i not in combined_idxs:
                        self.output_shape.append(sh)
                self.output_shape.insert(
                    self.extra_kwargs.get("idx_of_combination", len(self.output_shape)),
                    comb_shape,
                )
                self.output_shape = tuple(self.output_shape)
            else:
                self.output_shape = comb_shape
        elif self.combine_tails == "concat":
            combined_idxs = self.extra_kwargs.get("combined_idxs", list(range(len(out_shapes))))
            dim = self.extra_kwargs.get("dim", -1)
            comb_shape = list(out_shapes[combined_idxs[0]])
            for comb_idx in combined_idxs[1:]:
                comb_shape[dim] += out_shapes[comb_idx][dim]
            comb_shape = tuple(comb_shape)
            if "combined_idxs" in self.extra_kwargs:
                self.output_shape = []
                for i, sh in enumerate(out_shapes):
                    if i not in combined_idxs:
                        self.output_shape.append(sh)
                self.output_shape.insert(
                    self.extra_kwargs.get("idx_of_combination", len(self.output_shape)),
                    comb_shape,
                )
            else:
                self.output_shape = comb_shape
        else:
            raise Exception("combination type unknown:", self.combine_tails)

    def forward(self, X):
        pre_com = tuple(tail(X_i) for tail, X_i in zip(self.tails, X))
        if self.combine_tails == "tuple" or self.combine_tails == "dict":
            if "extract_sub_tuples" in self.extra_kwargs:
                out = []
                for i, tail_output in enumerate(pre_com):
                    if i in self.extra_kwargs["extract_sub_tuples"]:
                        # sh is a tuple of shapes, extend the array by these shapes
                        out.extend(tail_output)
                    else:
                        out.append(tail_output)
                output = tuple(out)
            else:
                output = pre_com
            if self.combine_tails == "dict":
                return {k: output_k for k, output_k in zip(self.extra_kwargs["output_keys"], output)}
            else:
                return output
        elif self.combine_tails == "sum":
            if "combined_idxs" in self.extra_kwargs:
                combined = torch.sum(torch.stack([pre_com[comb_idx] for comb_idx in self.extra_kwargs["combined_idxs"]], dim=0), dim=0)
                uncombined = [pre_com[uncomb_idx] for uncomb_idx in self.extra_kwargs["uncombined_idxs"]]
                uncombined.insert(
                    self.extra_kwargs.get("idx_of_combination", len(uncombined)),
                    combined,
                )
                return tuple(uncombined)
            else:
                return torch.sum(torch.stack(pre_com, dim=0), dim=0)
        elif self.combine_tails == "concat":
            if "combined_idxs" in self.extra_kwargs:
                combined = torch.concat(
                    [pre_com[comb_idx] for comb_idx in self.extra_kwargs["combined_idxs"]],
                    dim=self.extra_kwargs.get("dim", -1),
                )
                uncombined = [pre_com[uncomb_idx] for uncomb_idx in self.extra_kwargs["uncombined_idxs"]]
                uncombined.insert(
                    self.extra_kwargs.get("idx_of_combination", len(uncombined)),
                    combined,
                )
                return tuple(uncombined)
            else:
                return torch.concat(pre_com, dim=self.extra_kwargs.get("dim", -1))
        else:
            raise Exception("combination type unknown:", self.combine_tails)


class _CustomNNParallelDict(nn.Module):
    """
    Network to compute on dict of tensors in parallel,
    """

    def __init__(
        self,
        input_shape,
        layer_dict_lists=None,
        combine_tails="dict",
        **kwargs,
    ):
        """
        Args:
            input_shape: shape of input, is a DICT of input shapes
            layer_dict_lists: DICT of lists of layer dicts
                same length as input_shape, the ith layer dict list will be applied to the ith input before combining
                if None, does no computation on each branch
                each list can also be swapped with None, which does no computation
            combine_tails: how to combine the tuple
        """
        super().__init__()
        input_shape = convert_shape(input_shape)
        assert type(input_shape) is dict, "input type must be dict for this module"
        if layer_dict_lists is None:
            layer_dict_lists = {k: None for k in input_shape}
        assert set(input_shape.keys()) == set(layer_dict_lists.keys()), (
            f"branch keys ({layer_dict_lists.keys()}) must match input keys ({input_shape.keys()})"
        )
        self.keys = set(input_shape.keys())
        tails = dict()  # dict of CustomNN objects that are the tails
        out_shapes = dict()
        for key in self.keys:
            layer_dict_list = layer_dict_lists[key]
            in_sh = input_shape[key]
            if layer_dict_list is None or len(layer_dict_list) == 0:
                tails[key] = nn.Identity()
                out_shapes[key] = in_sh
            else:
                structure = {
                    "input_shape": in_sh,
                    "layers": layer_dict_list,
                }
                tail = CustomNN(structure=structure)
                tails[key] = tail
                out_shapes[key] = tail.output_shape
        self.tails = nn.ModuleDict(tails)
        self.combine_tails = combine_tails
        self.extra_kwargs = kwargs

        if self.combine_tails == "dict":
            if "output_keys_to_combination" in self.extra_kwargs:
                self.output_shape = dict()
                self.final_layer = dict()
                for key, combination_dict in self.extra_kwargs["output_keys_to_combination"].items():
                    assert "input_keys" in combination_dict, f"must specify which keys to use when combining to make '{key}'"
                    self.final_layer[key] = _CustomNNParallel(
                        input_shape=tuple(out_shapes[k] for k in combination_dict["input_keys"]),
                        layer_dict_lists=None,
                        combine_tails=combination_dict["combination"],
                        **combination_dict,
                    )
                    self.output_shape[key] = self.final_layer[key].output_shape
                self.final_layer = nn.ModuleDict(self.final_layer)
            else:
                self.output_shape = out_shapes
                self.final_layer = nn.Identity()
        else:
            assert "key_order" in self.extra_kwargs, "if combining all elements of dict, must specify order"
            self.final_layer = _CustomNNParallel(
                input_shape=tuple(out_shapes[k] for k in self.extra_kwargs["key_order"]),
                layer_dict_lists=None,
                combine_tails=self.combine_tails,
                **kwargs,
            )
            self.output_shape = self.final_layer.output_shape

    def forward(self, X):
        pre_com = {k: self.tails[k](X[k]) for k in self.keys}
        if self.combine_tails == "dict":
            if "output_keys_to_combination" in self.extra_kwargs:
                return {
                    key: self.final_layer[key](tuple(pre_com[k] for k in combination_dict["input_keys"]))  # pyright: ignore[reportIndexIssue]
                    for key, combination_dict in self.extra_kwargs["output_keys_to_combination"].items()
                }
            else:
                return pre_com
        else:
            return self.final_layer(tuple(pre_com[k] for k in self.extra_kwargs["key_order"]))  # pyright: ignore[reportCallIssue]


class CustomNN(nn.Module):
    """
    custom network built with config file
    """

    def __init__(
        self,
        structure,
    ):
        """
        Args:
            structure: dict specifies network structure
                can also put in None, then enter config file
                (input_shape -> unbatched original input shape
                layers -> list of dicts for each layer)

        """
        super().__init__()
        assert "layers" in structure, "config dict must contain key 'layers'"
        assert "input_shape" in structure, "config dict must contain key 'input_shape'"
        shape = structure["input_shape"]
        shape = convert_shape(shape)
        layers = []
        for i, dic in enumerate(structure["layers"]):
            if dic["type"] == "split":
                assert "branches" in dic
                split_lyr = _CustomNNSplit(input_shape=shape, layer_dict_lists=dic["branches"])
                layers.append(split_lyr)
                shape = split_lyr.output_shape
                if "combination" in dic:
                    if dic["combination"] == "tuple" and "extract_sub_tuples" not in dic:
                        pass
                        # print('no need to specify combinatation==tuple')
                    else:
                        merge_lyr = _CustomNNParallel(
                            input_shape=shape,
                            layer_dict_lists=None,
                            combine_tails=dic["combination"],
                            **dic,
                        )
                        layers.append(merge_lyr)
                        shape = merge_lyr.output_shape
            elif dic["type"] == "parallel":
                branches = dic.get("branches", None)
                if type(branches) is dict:
                    par_lyr = _CustomNNParallelDict(
                        input_shape=shape,
                        layer_dict_lists=branches,
                        combine_tails=dic.get("combination", "dict"),
                        **dic,  # give it any extra kwargs that are in dic
                    )
                else:
                    par_lyr = _CustomNNParallel(
                        input_shape=shape,
                        layer_dict_lists=branches,
                        combine_tails=dic.get("combination", "tuple"),
                        **dic,  # give it any extra kwargs that are in dic
                    )
                layers.append(par_lyr)
                shape = par_lyr.output_shape
            elif dic["type"] == "repeat":
                for _ in range(dic["times"]):
                    substrucure = {"input_shape": shape, "layers": dic["block"]}
                    block = CustomNN(structure=substrucure)
                    layers.append(block)
                    shape = block.output_shape
            else:
                layer, shape = layer_from_config_dict(
                    dic=dic,
                    input_shape=shape,
                    only_shape=False,
                )
                layers.append(layer)
        if len(layers) == 1:
            self.network = layers[0]
        else:
            self.network = nn.Sequential(*layers)
        self.output_shape = shape

    def forward(self, X):
        return self.network(X)
