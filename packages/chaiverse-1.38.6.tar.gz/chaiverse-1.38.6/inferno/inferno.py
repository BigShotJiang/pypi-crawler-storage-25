from chaiverse.inferno.async_inferno import AsyncInfernoModel
from chaiverse.inferno.abstract_inferno import _AbstractInfernoModel
from chaiverse.lib.async_tools import yield_to_sync


class InfernoModel(_AbstractInfernoModel):
    """
    Synchronous implementation of an InfernoModel
    """

    @classmethod
    @yield_to_sync
    def create(cls, **kwargs):
        return super().create(**kwargs)

    @classmethod
    @yield_to_sync
    def from_id(cls, default=None, **kwargs):
        return super().from_id(default, **kwargs)

    @classmethod
    @yield_to_sync
    def where(cls, **kwargs):
        return super().where(**kwargs)

    @classmethod
    @yield_to_sync
    def all(cls, **kwargs):
        return super().all(**kwargs)

    @classmethod
    @yield_to_sync
    def paginate(cls, index, limit, order_by=None):
        return super().paginate(index, limit, order_by)

    @classmethod
    @yield_to_sync
    def is_in_database(cls, **kwargs):
        return super().is_in_database(**kwargs)

    @yield_to_sync
    def save(self):
        return super().save()

    @yield_to_sync
    def delete(self):
        return super().delete()

    @yield_to_sync
    def refresh(self):
        return super().refresh()

    @yield_to_sync
    def to_lazy(self):
        return super().to_lazy()
