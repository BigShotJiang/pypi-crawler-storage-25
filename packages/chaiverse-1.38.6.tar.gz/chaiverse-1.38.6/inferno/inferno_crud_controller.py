from fastapi_utils.cbv import cbv as controller

def crud_controller(inferno_model, router):
    def wrapper(cls):
        # TODO: To ensure we don't override any similar routes that are set in
        # the actual controller that this is applied to, we check this. It's
        # quite mad. Ideally this should just work via inheritance, but that seems broken.
        existing_routes = [(route.path, route.methods) for route in router.routes]
        class InfernoCRUDController():
            if (f"/{inferno_model.path}", {"POST"}) not in existing_routes:
                @router.post(f"/{inferno_model.path}")
                def create(self, model: inferno_model):
                    model.save()
                    model_id = getattr(model, model._id)
                    return {model._id: model_id}

            if (f"/{inferno_model.path}/{{model_id}}", {"GET"}) not in existing_routes:
                @router.get(f"/{inferno_model.path}/{{model_id}}")
                def get(self, model_id: str):
                    model = inferno_model.from_id(**{inferno_model._id: model_id})
                    return model

            if (f"/{inferno_model.path}/{{model_id}}", {"PATCH"}) not in existing_routes:
                @router.patch(f"/{inferno_model.path}/{{model_id}}")
                def patch(self, model_id: str, model: inferno_model):
                    model.save()
                    return model

            if (f"/{inferno_model.path}/{{model_id}}", {"DELETE"}) not in existing_routes:
                @router.delete(f"/{inferno_model.path}/{{model_id}}")
                def delete(self, model_id: str):
                    model = inferno_model.lazy.from_id(**{inferno_model._id: model_id})
                    model.delete()
                    return model

            if (f"/{inferno_model.path}", {"GET"}) not in existing_routes:
                @router.get(f"/{inferno_model.path}")
                def all(self):
                    return inferno_model.all()

        # Mixin the InfernoCRUDController behaviour
        controller_class = type(cls.__name__, (cls, InfernoCRUDController), {})
        # Mixin FastAPI controller behaviour
        controller(router)(controller_class)
        # Install create route
        return controller_class
    return wrapper


def async_crud_controller(inferno_model, router):
    # TODO: We could probably make this DRYer by using yield_to_sync and
    # yield_to_async, but it might look quite complex.
    def wrapper(cls):
        existing_routes = [(route.path, route.methods) for route in router.routes]
        from fastapi import Request
        class AsyncInfernoCRUDController():
            if (f"/{inferno_model.path}", {"POST"}) not in existing_routes:
                @router.post(f"/{inferno_model.path}")
                async def create(self, request: Request, model: inferno_model):
                    await model.save()
                    model_id = getattr(model, model._id)
                    return {model._id: model_id}

            if (f"/{inferno_model.path}/{{model_id}}", {"GET"}) not in existing_routes:
                @router.get(f"/{inferno_model.path}/{{model_id}}")
                async def get(self, model_id: str):
                    model = await inferno_model.from_id(**{inferno_model._id: model_id})
                    return model

            if (f"/{inferno_model.path}/{{model_id}}", {"PATCH"}) not in existing_routes:
                @router.patch(f"/{inferno_model.path}/{{model_id}}")
                async def patch(self, model_id: str, model: inferno_model):
                    await model.save()
                    return model

            if (f"/{inferno_model.path}/{{model_id}}", {"DELETE"}) not in existing_routes:
                @router.delete(f"/{inferno_model.path}/{{model_id}}")
                async def delete(self, model_id: str):
                    model = inferno_model.lazy.from_id(**{inferno_model._id: model_id})
                    await model.delete()
                    return model

            if (f"/{inferno_model.path}", {"GET"}) not in existing_routes:
                @router.get(f"/{inferno_model.path}")
                async def all(self):
                    return await inferno_model.all()

        # Mixin the InfernoCRUDController behaviour
        controller_class = type(cls.__name__, (cls, AsyncInfernoCRUDController), {})
        # Mixin FastAPI controller behaviour
        controller(router)(controller_class)
        # Install create route
        return controller_class
    return wrapper
