from contextlib import contextmanager
import logging
from typing import ClassVar, List, Optional

from fastapi.encoders import jsonable_encoder
from pydantic_core._pydantic_core import ValidationError
from pydantic import BaseModel, Field
from redis import Redis

from chaiverse.database import _InfernoDatabaseAdapter
from chaiverse.inferno.inferno_cache import cache
from chaiverse.inferno.inferno_logger import InfernoLoggerHandler, InfernoLogEntry
from chaiverse.inferno.lazy_inferno import LazyInfernoModelMixin
from chaiverse.lib.async_tools import yield_to_sync
from chaiverse.lib.dict_tools import deep_get
from chaiverse.lib.func import deserialize_function, is_base_64, class_property


class RecordNotFoundError(Exception):
    pass


class _AbstractInfernoModel(BaseModel):
    """
    Inferno is a light-weight object relational-mapper (ORM/ODM)
    for Firebase. It maps records in the database to python
    objects to ensure type-safety, validation and encourage
    cleaner coding standards when interfacing with the database.
    """
    database: ClassVar[_InfernoDatabaseAdapter]
    path: ClassVar[str]
    # Must set execlude as otherwise pydantic tries to
    # serialize it
    cache: ClassVar[Optional[Redis]] = Field(exclude=True)

    logs: Optional[List[InfernoLogEntry]] = None

    class Config:
        arbitrary_types_allowed = True

    @class_property
    def lazy(cls):
        # Mixin lazy behaviour into base class
        lazy_class = type(f"Lazy{cls.__name__}", (LazyInfernoModelMixin, cls), {})
        return lazy_class

    @classmethod
    def create(cls, **kwargs):
        data = cls(**kwargs)
        msg = f'entry with id "{data.id}" already exists in database! Please use a different id'
        is_in = yield cls.is_in_database(**{cls._id: data.id})
        assert not is_in, msg
        return data

    @classmethod
    def from_id(cls, default=None, **kwargs):
        instance_id = cls._get_instance_id(kwargs)
        data = yield cls.database.get(path=f'{cls.path}/{instance_id}') or default
        if data is None:
            raise RecordNotFoundError(f'no entry with id "{instance_id}" found on database!')
        if cls._id not in data:
            data[cls._id] = instance_id
        return cls(**data)

    @classmethod
    def from_records(cls, records):
        instances = []
        for record in records:
            try:
                instance = cls(**record)
                instances.append(instance)
            except ValidationError as ex:
                logging.error(str(ex))
        return instances

    @classmethod
    def where(cls, **kwargs):
        records = yield cls.database.where(path=cls.path, **kwargs)
        return cls.from_records(records)

    @classmethod
    def all(cls, **kwargs):
        all_entries = yield cls.database.get(path=cls.path)
        all_records = all_entries.values() if all_entries else []
        return cls.from_records(all_records)

    @classmethod
    def paginate(cls, index, limit, order_by=None):
        # Paginate (in reverse order) an Inferno model with a sortable id
        if order_by == None:
            order_by = cls._id
        entries = yield cls.database.query_by_child_value_range(
            cls.path, order_by, end_at=index, limit_to_last=limit
        )
        entries = cls.from_records(entries.values()) if entries else []
        entries.sort(key=lambda x: deep_get(x.to_dict(), order_by), reverse=True)
        return entries

    @classmethod
    def is_in_database(cls, **kwargs):
        instance_id = cls._get_instance_id(kwargs)
        is_in = yield cls.database.is_in_database(path=f'{cls.path}/{instance_id}')
        return is_in

    def to_dict(self, exclude_none=True, **kwargs):
        serialised_record = jsonable_encoder(
            self, exclude_none=exclude_none, **kwargs
        )
        # Logs are often written in a separate thread, so we drop them if
        # they're none to avoid overwriting
        if "logs" in serialised_record and serialised_record["logs"] == None:
            serialised_record.pop("logs")
        return serialised_record

    def to_lazy(self):
        kwargs = {self.__class__._id: self.id}
        lazy_model = yield self.lazy.from_id(**kwargs)
        return lazy_model

    @contextmanager
    def register_logger(self, lazy=True):
        handler = InfernoLoggerHandler(inferno_model=self, level=logging.DEBUG, lazy=lazy)
        try:
            root_logger = logging.getLogger()
            root_logger.addHandler(handler)
            yield
        finally:
            root_logger.removeHandler(handler)

    def save(self):
        record = self._build_save_record()
        yield self.database.multi_update(path="/", record=record)

    def delete(self):
        path = f"{self.path}/{self.id}"
        yield self.database.remove(path)

    def refresh(self):
        instance_id = getattr(self, self._id)
        data = yield self.database.get(path=f'{self.path}/{instance_id}')
        new_instance = self.__class__(**data)
        for field in self.__fields__:
            new_value = getattr(new_instance, field)
            self._set_field(field, new_value)

    @property
    def id(self):
        id_field = self.__class__._id
        instance_id = getattr(self, id_field)
        return instance_id

    @classmethod
    def _get_denormalised_fields(cls):
        # Cannot set this as a Pydantic ClassVar as it gets shared across all
        # InfernoModel instances
        denormalised_fields = getattr(cls, "_denormalised_fields", {})
        return denormalised_fields

    @classmethod
    def _get_instance_id(cls, kwargs):
        assert cls._id in kwargs, f'invalid keyword id, please use keyword "{cls._id}"'
        instance_id = kwargs[cls._id]
        return instance_id

    def _build_save_record(self):
        record = {self.path: {self.id: self.to_dict(exclude_none=True)}}
        # TODO: This ensures that if a dictionary field is not set, then it is
        # deleted. This really should be in the Firebase adapter.
        record = _empty_dict_to_none(record)
        for field, path in self._get_denormalised_fields().items():
            denormalised_record = {path: {self.id: self.to_dict(include=[self._id, field])}}
            record.update(denormalised_record)
        return record

    def _set_field(self, field, value):
        new_data = {field: value}
        data = self.to_dict()
        data.update(new_data)
        try:
            self.__class__.model_validate(data)
        except Exception as ex:
            test = ex
            errors = [
                error for error in ex.errors() if error["loc"] and error["loc"][0] in data.keys()
            ]
            if errors:
                new_ex = ValidationError.from_exception_data(
                    title=ex.title,
                    line_errors=errors,
                )
                raise new_ex
        setattr(self, field, value)


def set_id(field: str):
    def wrapped(cls):
        cls._id = field
        return cls
    return wrapped


def denormalise_field(field: str, path_format: str = "{path}_{field}_denormalisation"):
    # Used to duplicate information in an Inferno model to improve read
    # performance, as is usually suggested when dealing with NoSQL databases
    # (especially Firebase)
    # See https://firebase.blog/posts/2013/04/denormalizing-your-data-is-normal
    def wrapped(cls):
        denormalisation_path = path_format.format(path=cls.path, field=field)
        cls._denormalised_fields = getattr(cls, "_denormalised_fields", {})
        cls._denormalised_fields[field] = denormalisation_path
        return cls
    return wrapped


def _empty_dict_to_none(mapping):
    for key, value in mapping.items():
        if isinstance(value, dict) and len(value) > 0:
            mapping[key] = _empty_dict_to_none(value)
        elif value == {}:
            mapping[key] = None
    return mapping
