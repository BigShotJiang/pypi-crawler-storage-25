from functools import wraps
import json

from pydantic import BaseModel

class cache():
    def __init__(self, ttl: float):
        self.ttl = ttl
        self.cache_instance = None
        self.function_path = None
        self.function_return_type = None

    def __call__(self, function):
        self.function_path = f"{function.__module__}.{function.__qualname__}"
        self.function_return_type = function.__annotations__.get("return", None)

        @wraps(function)
        def wrapper(*args, **kwargs):
            # To be able to access the cache instance
            nonlocal self
            # Grab the redis cache instance from the InfernoModel's schema
            self.cache_instance = args[0].cache
            value = self.get(*args, **kwargs)
            # Cache miss, so we fallback to the underlying database
            # and then store the value in the cache
            if value is None:
                value = function(*args, **kwargs)
                self.set(value, *args, **kwargs)
            return value
        return wrapper

    def get(self, *args, **kwargs):
        prefix = self.get_prefix(*args, **kwargs)
        value = self.cache_instance.get(prefix)
        if value is not None:
            value = json.loads(value)
            value = self._deserialise_value(args[0], value)
        return value

    def set(self, value, *args, **kwargs):
        prefix = self.get_prefix(*args, **kwargs)
        serialised_record = self._serialise_value(value)
        json_record = json.dumps(serialised_record)
        self.cache_instance.set(prefix, json_record)
        self.cache_instance.expire(prefix, self.ttl)

    def get_prefix(self, *args, **kwargs):
        args = self._get_args_prefix(*args)
        kwargs = self._get_kwargs_prefix(**kwargs)
        if args and kwargs:
            kwargs = ", {kwargs}"
        prefix = f"{self.function_path}({args}{kwargs})"
        return prefix

    def _get_args_prefix(self, *args):
        # The first argument is either the class object
        # or instance object itself, we don't need this in the prefix
        args = list(args)
        args.pop(0)
        args = ", ".join(args)
        return args

    def _get_kwargs_prefix(self, **kwargs):
        kwargs = [f"{key}={value}" for key, value in kwargs.items()]
        kwargs = ", ".join(kwargs)
        return kwargs

    def _deserialise_value(self, cls, value):
        if type(value) == list:
            value = [self._deserialise_value(cls, v) for v in value]
        elif self.function_return_type and issubclass(self.function_return_type, BaseModel):
            value = self.function_return_type(**value)
        elif self.function_return_type:
            assert isinstance(value, self.function_return_type), "Value not of expected return type, custom deserialisation logic needed!"
            pass
        elif isinstance(value, dict):
            # No return type is specified, so we just fallback to trying to
            # deserialise into the InfernoModel this cache is declared within
            value = cls(**value)
        else:
            raise NotImplementedError("Failed to deserialize data from cache!")
        return value

    def _serialise_value(self, value):
        if type(value) == list:
            serialised_record = [self._serialise_value(v) for v in value]
        elif value.__class__.__name__ == "InfernoModel":
            serialised_record = value.to_dict()
        elif isinstance(value, BaseModel):
            serialised_record = value.dict()
        else:
            serialised_record = value
        return serialised_record
