from datetime import datetime
import logging

from pydantic import BaseModel, Field
from pytz import UTC

from chaiverse.chaiverse_secrets import scrub_secrets
from chaiverse.lib.async_tools import yield_to_sync


class InfernoLogEntry(BaseModel):
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    entry: str
    level: str
    line_number: int
    path: str

    @staticmethod
    def from_logging_record(record: logging.LogRecord):
        entry = str(scrub_secrets(record.msg))
        log_entry = InfernoLogEntry(
            timestamp=datetime.utcfromtimestamp(record.created).replace(tzinfo=UTC),
            entry=entry,
            level=record.levelname,
            line_number=record.lineno,
            path=record.pathname
        )
        return log_entry


class InfernoLoggerHandler(logging.Handler):
    def __init__(self, inferno_model, level, lazy=True):
        super().__init__(level)
        # Convert to lazy to ensure we are not overwriting data in other
        # threads while logging
        self.inferno_model = inferno_model.to_lazy() if lazy else inferno_model

    @yield_to_sync
    def emit(self, record):
        log_entry = InfernoLogEntry.from_logging_record(record)
        logs = yield self.inferno_model.logs
        if not logs:
            self.inferno_model.logs = []
        self.inferno_model.logs.append(log_entry)
        yield self.inferno_model.save()
