import builtins
from dill.source import getsource
from inspect import isclass
from functools import partial
from typing import Annotated, Callable, Optional

from pydantic import BaseModel, BeforeValidator, PlainSerializer, field_validator

from chaiverse.lib.func import is_base_64


def get_source(function):
    source = getattr(function, "__source__", None) or _get_source(function)
    return source


def _get_source(function):
    source = getsource(function)
    source = source.lstrip()
    # Check if we need to add an import to facilitate subclasses
    if isclass(function) and len(function.__bases__) > 0:
        source = _get_subclass_source(function, source)
    return source


def _get_subclass_source(function, source):
    assert len(function.__bases__) == 1, "Multi-inheritance not supported!"
    base = function.__bases__[0]
    # If this is a builtin python superclass, there is nothing to do
    if base.__name__ in dir(builtins):
        return source
    module = base.__module__
    package = module.split(".")[1]
    import_source = f"import importlib\n{package} = importlib.import_module('{module}')\n"
    source = import_source + source
    # If the subclass is directly imported, we need to modify the class
    # definition to append the package name
    name = base.__name__
    source = source.replace(f"({name})", f"({package}.{name})")
    return source


def process_callable(func):
    if type(func) == list:
        func = [process_callable(f) for f in func]
    elif type(func) == str and is_base_64(func):
        # Deprecated unsafe base64 functions are rejected
        pass
    elif type(func) == str:
        func = load_function(func)
    elif type(func) == partial:
        func = InfernoPartial.from_orm(func)
    elif isinstance(func, dict):
        func = InfernoPartial(**func)
    elif getattr(func, "__name__", None) == "<lambda>":
        # Seems difficult to get source code of inline lambdas
        raise NotImplementedError("Cannot use lambda callables in Inferno!")
    return func


def load_function(source):
    # Remove any unwanted indentation
    source = source.lstrip()
    locals = {}
    # Execute the python code, with no access to globals, and empty
    # locals for later inspection
    exec(source, None, locals)
    func = list(locals.values())[-1]
    assert callable(func), f"{func} is not callable"
    # Not possible to get source code for function defined by exec
    # so we store it for future reference
    func.__source__ = source
    return func


InfernoCallable = Annotated[
    Callable, PlainSerializer(get_source),
    BeforeValidator(process_callable)
]


class InfernoPartial(BaseModel):
    func: Optional[InfernoCallable] = None
    args: Optional[tuple] = ()
    keywords: Optional[dict] = {}

    @field_validator("args", mode="before")
    def validate_args(cls, args):
        if args == None:
            args = ()
        return args

    @field_validator("keywords", mode="before")
    def validate_kwargs(cls, kwargs):
        if kwargs == None:
            kwargs = {}
        return kwargs

    class Config():
        # Set ORM mode so that we can easily create an InfernoPartial from a
        # partial via pydantic type-hinting
        orm_mode = True
        from_attributes = True

    def __call__(self, *args, **kwargs):
        loaded_partial = partial(self.func, *self.args, **self.keywords)
        return loaded_partial(*args, **kwargs)

    @property
    def __name__(self):
        return self.func.__name__

    @property
    def __wrapped__(self):
        return self.func
