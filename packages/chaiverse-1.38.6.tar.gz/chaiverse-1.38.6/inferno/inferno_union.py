from collections.abc import Iterable
from inspect import isclass
from typing import Annotated, Union

from pydantic import Field, TypeAdapter
from pydantic._internal._model_construction import ModelMetaclass

from chaiverse.inferno import AsyncInfernoModel, InfernoModel
from chaiverse.lib.func import class_property


class InfernoUnionMetaClass(ModelMetaclass):
    def __setattr__(self, name, value):
        # We do this so we can set database patches at the Union level, and
        # ensure they propogate to the polymorphisms
        # This has to be in a metaclass, because the Inferno database field is
        # a class attribute
        if getattr(self, "database", None) and name == "database":
            for cls in self._polymorphisms:
                cls.database = value
        super().__setattr__(name, value)


class _InfernoUnion():
    """
    Helper class to do polymorphism with InfernoModel.
    Example:
            class BaseSubmission(InfernoModel):
                platform = Literal["base"]

            class RewardSubmission(InfernoModel):
                platform = Literal["reward"]

            Submission = InfernoUnion[BaseSubmission, RewardSubmission]
    This relies on Pydantic's valdiation behaviour to resolve the correct class,
    so each polymorphism must implement a discriminator in a similar fashion to 'platform'
    in the above example.
    """
    @class_property
    def greatest_common_superclass(cls):
        return get_greatest_common_superclass(cls._polymorphisms)

    @classmethod
    def discriminate(cls, discriminator):
        discriminated_class = type(f"DiscriminatedInfernoUnion", (cls, ), {})
        discriminated_class.discriminator = discriminator
        return discriminated_class

    def __new__(cls, *args, **kwargs):
        instance = cls._adapter.validate_python(kwargs) if kwargs else object.__new__(cls)
        return instance

    def __init__(self, *args, **kwargs):
        pass

    def __class_getitem__(cls, classes):
        cls._validate_union(classes)
        greatest_common_superclass = get_greatest_common_superclass(classes)
        new_class = type(cls.__name__, (greatest_common_superclass, cls), {})
        new_class._polymorphisms = classes
        new_class._adapter = cls._get_adapter(classes)
        new_class.database = classes[0].database
        new_class.path = classes[0].path
        new_class._id = classes[0]._id
        return new_class

    @classmethod
    def _get_adapter(cls, classes):
        underlying_union = Union[classes]
        if hasattr(cls, "discriminator"):
            underlying_union = Annotated[underlying_union, Field(discriminator=cls.discriminator)]
        return TypeAdapter(underlying_union)

    @classmethod
    def _validate_union(cls, item):
        item = item if isinstance(item, Iterable) else [item]
        assert all([isclass(i) for i in item]), "Can only create an InfernoUnion from classes!"
        assert all([issubclass(i, InfernoModel) or issubclass(i, AsyncInfernoModel) for i in item]), "Can only create an InfernoUnion from InfernoModels!"
        assert len(set([i.database for i in item])) == 1, "Cannot create an InfernoUnion from InfernoModels with different databases!"
        assert len(set([i.path for i in item])) == 1, "Cannot create an InfernoUnion from InfernoModels with different paths!"


def get_greatest_common_superclass(classes):
    classes = [cls.mro() for cls in classes]
    for x in classes[0]:
        if all(x in mro for mro in classes):
            return x


class InfernoUnion(_InfernoUnion, InfernoModel, metaclass=InfernoUnionMetaClass):
    @class_property
    def lazy(cls):
        lazy_cls = cls.greatest_common_superclass.lazy
        lazy_cls.database = cls.database
        lazy_class = AsyncInfernoModel.lazy
        return lazy_cls


class AsyncInfernoUnion(_InfernoUnion, AsyncInfernoModel, metaclass=InfernoUnionMetaClass):
    pass
