"""Playwright browser lifecycle manager for the anyweb daemon.

Handles launching, context creation (with anti-detection), page management,
and graceful shutdown. Designed to run inside a long-lived daemon process.
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import os
import signal
import time

from playwright.async_api import (
    Browser,
    BrowserContext,
    Page,
    Playwright,
    async_playwright,
)

from anyweb.core.anti_detect import (
    apply_anti_detect_scripts,
    apply_stealth,
    get_stealth_context_options,
)
from anyweb.core.session import SessionManager

logger = logging.getLogger(__name__)

_browser_pids: set[int] = set()
_playwright_pids: set[int] = set()


def _kill_tracked_pids() -> None:
    """Kill any tracked browser and playwright processes on interpreter exit."""
    for pid in list(_browser_pids | _playwright_pids):
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError:
            pass
    _browser_pids.clear()
    _playwright_pids.clear()


atexit.register(_kill_tracked_pids)


class BrowserManager:
    """Manages a single Playwright browser instance inside the daemon.

    Keeps the browser alive between commands for low-latency responses.
    """

    def __init__(
        self,
        session_manager: SessionManager | None = None,
    ) -> None:
        self.headless = True
        self.session_manager = session_manager or SessionManager()
        self._playwright: Playwright | None = None
        self._browser: Browser | None = None
        self._contexts: dict[str, BrowserContext] = {}
        self._pages: dict[str, Page] = {}
        self._cdp_mode = False
        self._cdp_endpoint: str | None = None
        self._start_lock = asyncio.Lock()
        self._context_locks: dict[str, asyncio.Lock] = {}
        self._page_locks: dict[str, asyncio.Lock] = {}
        self._page_last_access: dict[str, float] = {}

    def _context_lock(self, platform: str) -> asyncio.Lock:
        """Get per-platform lock for context creation. Safe in single-threaded asyncio."""
        if platform not in self._context_locks:
            self._context_locks[platform] = asyncio.Lock()
        return self._context_locks[platform]

    def _page_lock(self, platform: str) -> asyncio.Lock:
        """Get per-platform lock for page creation. Safe in single-threaded asyncio."""
        if platform not in self._page_locks:
            self._page_locks[platform] = asyncio.Lock()
        return self._page_locks[platform]

    @property
    def is_running(self) -> bool:
        return self._browser is not None and self._browser.is_connected()

    def _on_browser_disconnected(self) -> None:
        """Handle browser disconnect — clear state so next call triggers reconnect."""
        logger.warning("Browser disconnected, will reconnect on next command")
        self._browser = None
        self._contexts.clear()
        self._pages.clear()
        self._page_last_access.clear()
        # Keep _playwright alive — it's reusable
        # Keep _cdp_endpoint — needed for reconnect
        # Keep _cdp_mode — still in CDP mode

    async def start(self) -> None:
        """Launch the Playwright browser."""
        async with self._start_lock:
            if self._browser:
                return
            self._playwright = await async_playwright().start()
            self._track_playwright_pid()
            try:
                from anyweb.core.chrome import find_chrome_channel

                self._browser = await self._playwright.chromium.launch(
                    headless=self.headless,
                    channel=find_chrome_channel(),
                    args=[
                        "--disable-blink-features=AutomationControlled",
                        "--disable-infobars",
                        "--no-first-run",
                    ],
                )
            except Exception:
                await self._playwright.stop()
                self._playwright = None
                raise
            self._browser.on("disconnected", self._on_browser_disconnected)
            try:
                pid = self._browser.process.pid  # type: ignore[union-attr]
                _browser_pids.add(pid)
                logger.info("[RES] BrowserManager created (mode=headless, pid=%d)", pid)
            except Exception:
                logger.info("[RES] BrowserManager created (mode=headless)")

    async def connect_via_cdp_direct(self, cdp_endpoint: str) -> None:
        """Connect to a live browser via CDP (direct, no extension needed).

        Accepts HTTP endpoint (e.g. http://localhost:9222) — auto-discovers WS URL.
        Supports auto-reconnect: if browser disconnects, next call to
        ensure_connected() will re-establish the connection.
        """
        self._cdp_endpoint = cdp_endpoint
        self._cdp_mode = True
        await self._cdp_connect()

    async def _cdp_connect(self) -> None:
        """Internal: establish CDP connection. Called on first use and on reconnect."""
        async with self._start_lock:
            if self._browser and self._browser.is_connected():
                return

            # Clean up stale playwright instance
            if self._playwright:
                try:
                    await self._playwright.stop()
                except Exception:
                    logger.warning("Failed to stop stale Playwright instance", exc_info=True)
                self._playwright = None
            self._browser = None
            self._contexts.clear()
            self._pages.clear()

            endpoint = self._cdp_endpoint
            if not endpoint:
                raise RuntimeError("No CDP endpoint configured")

            # Discover WS URL from HTTP endpoint
            import aiohttp

            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get(
                        f"{endpoint}/json/version",
                        timeout=aiohttp.ClientTimeout(total=5),
                    ) as resp:
                        info = await resp.json()
                        ws_url = info["webSocketDebuggerUrl"]
                except Exception as exc:
                    raise RuntimeError(
                        f"无法连接浏览器 CDP ({endpoint})。请确认浏览器已启动并带 --remote-debugging-port。错误: {exc}"
                    ) from exc

            self._playwright = await async_playwright().start()
            self._track_playwright_pid()
            self._browser = await self._playwright.chromium.connect_over_cdp(
                ws_url,
                timeout=15000,
            )
            self._browser.on("disconnected", self._on_browser_disconnected)
            logger.info("[RES] BrowserManager created (mode=cdp, ws=%s)", ws_url)

    async def ensure_connected(self) -> None:
        """Ensure CDP connection is alive, reconnect if needed."""
        if self._cdp_endpoint and not self.is_running:
            logger.info("CDP connection lost, reconnecting...")
            await self._cdp_connect()

    async def get_context(
        self,
        platform: str = "default",
        *,
        load_session: bool = True,
    ) -> BrowserContext:
        """Get or create a browser context for a platform."""
        # Fast path (no lock)
        if platform in self._contexts:
            return self._contexts[platform]
        # Slow path (locked)
        async with self._context_lock(platform):
            if platform in self._contexts:  # double-check
                return self._contexts[platform]
            return await self._create_context(platform, load_session)

    async def _create_context(self, platform: str, load_session: bool) -> BrowserContext:
        """Create a new context — must be called under _context_lock."""
        if not self._browser:
            await self.start()
        assert self._browser is not None

        # CDP mode: use the user's existing browser context (has their cookies)
        if self._cdp_mode:
            contexts = self._browser.contexts
            if contexts:
                context = contexts[0]
                self._contexts[platform] = context
                logger.info("Using default browser context for %s (cdp mode)", platform)
                return context

        opts = get_stealth_context_options()

        if load_session:
            state = self.session_manager.load_session_state(platform)
            if state is not None:
                opts["storage_state"] = state
                logger.info("Restored session for %s", platform)

        context = await self._browser.new_context(**opts)
        self._contexts[platform] = context
        return context

    async def get_page(self, platform: str = "default") -> Page:
        """Get the active page, creating one if needed."""
        return await self.get_named_page(platform, "default")

    async def get_named_page(self, platform: str, page_id: str = "default") -> Page:
        """Get or create a named page within a platform's context.

        Multiple named pages share the same context (cookies) but are
        independent browser tabs.

        In CDP mode all platforms share the same browser context, so a
        non-default ``page_id`` is treated as a globally unique tab handle:
        if a tab with that name already exists under any platform, return it
        instead of creating a blank ghost tab. This prevents the bug where a
        sticky-platform flip (e.g. after reading a non-X URL) silently routed
        ``--page grok1`` to a fresh ``generic:grok1`` instead of the real
        ``x:grok1``.
        """
        if self._cdp_mode and page_id != "default":
            suffix = f":{page_id}"
            for existing_key, existing_page in self._pages.items():
                if existing_key.endswith(suffix) and not existing_page.is_closed():
                    if existing_key != f"{platform}:{page_id}":
                        logger.info(
                            "[RES] Page name '%s' resolved to existing key=%s (requested platform=%s)",
                            page_id,
                            existing_key,
                            platform,
                        )
                    self._page_last_access[existing_key] = time.time()
                    return existing_page

        key = f"{platform}:{page_id}"
        # Fast path (no lock)
        if key in self._pages:
            page = self._pages[key]
            if not page.is_closed():
                self._page_last_access[key] = time.time()
                return page
        # Slow path (locked)
        async with self._page_lock(key):
            if key in self._pages:
                page = self._pages[key]
                if not page.is_closed():
                    self._page_last_access[key] = time.time()
                    return page
            context = await self.get_context(platform)
            page = await context.new_page()
            if not self._cdp_mode:
                await apply_stealth(page)
                await apply_anti_detect_scripts(page)
            self._pages[key] = page
            self._page_last_access[key] = time.time()
            logger.info("[RES] Page created key=%s", key)
            return page

    async def new_page(self, platform: str) -> Page:
        """Create a new stealth page (adapter-managed lifecycle).

        Unlike get_page(), this creates a fresh page each call.
        The caller is responsible for closing it.
        """
        context = await self.get_context(platform)
        page = await context.new_page()
        if not self._cdp_mode:
            await apply_stealth(page)
            await apply_anti_detect_scripts(page)
        return page

    async def save_session(self, platform: str) -> str:
        """Persist the current context's cookies / storage state."""
        context = self._contexts.get(platform)
        if context is None:
            raise RuntimeError(f"No active context for platform '{platform}'")
        return await self.session_manager.save_session(platform, context)

    async def close_context(self, platform: str) -> None:
        """Close and remove a platform's browser context and all its named pages."""
        prefix = f"{platform}:"
        keys_to_remove = [k for k in self._pages if k.startswith(prefix)]
        for key in keys_to_remove:
            self._pages.pop(key, None)
            logger.info("[RES] Page closed key=%s", key)
        context = self._contexts.pop(platform, None)
        if context:
            await context.close()
            logger.info("[RES] Context closed for %s", platform)

    def _track_playwright_pid(self) -> None:
        """Record the Playwright node subprocess PID for cleanup."""
        if not self._playwright:
            return
        try:
            proc = self._playwright._connection._transport._proc  # type: ignore[attr-defined]
            if proc and proc.pid:
                _playwright_pids.add(proc.pid)
        except Exception:
            pass

    async def _stop_playwright(self) -> None:
        """Stop Playwright and ensure its node subprocess exits."""
        if not self._playwright:
            return
        pw_pid: int | None = None
        try:
            proc = self._playwright._connection._transport._proc  # type: ignore[attr-defined]
            pw_pid = proc.pid if proc else None
        except Exception:
            pass

        try:
            await self._playwright.stop()
        except Exception:
            logger.warning("Playwright stop failed", exc_info=True)

        if pw_pid:
            _playwright_pids.discard(pw_pid)
            try:
                os.kill(pw_pid, 0)  # check if still alive
                os.kill(pw_pid, signal.SIGTERM)
                logger.info("[CLEANUP] Killed playwright node PID %d", pw_pid)
            except OSError:
                pass
        self._playwright = None

    async def idle_cleanup_loop(self, idle_threshold: int = 600, interval: int = 300) -> None:
        """Periodically close idle pages. In CDP mode, shutdown after extended idle.

        Args:
            idle_threshold: Seconds of inactivity before closing a page (default 10 min).
            interval: Seconds between scans (default 5 min).
        """
        CDP_IDLE_TIMEOUT = 300

        while True:
            await asyncio.sleep(interval)
            now = time.time()
            for key in list(self._page_last_access):
                idle_s = now - self._page_last_access.get(key, now)
                if idle_s <= idle_threshold:
                    continue
                page = self._pages.get(key)
                if page and not page.is_closed():
                    try:
                        await page.close()
                        logger.info("[CLEANUP] Idle page closed: %s (idle %.0fs)", key, idle_s)
                    except Exception:
                        logger.warning("[CLEANUP] Failed to close idle page: %s", key)
                self._pages.pop(key, None)
                self._page_last_access.pop(key, None)

            # CDP mode: shutdown Chrome if no pages left and idle too long
            if self._cdp_mode and not self._pages:
                latest = max(self._page_last_access.values(), default=0)
                if latest > 0 and (now - latest) > CDP_IDLE_TIMEOUT:
                    logger.info("[LIFECYCLE] CDP Chrome idle for %ds with no pages, shutting down", int(now - latest))
                    await self.close()
                    break

            # Memory health check
            try:
                import subprocess

                out = subprocess.check_output(["ps", "-o", "rss=", "-p", str(os.getpid())], text=True)
                rss_mb = int(out.strip()) // 1024
                if rss_mb > 4096:
                    logger.error("[HEALTH] Critical memory: %dM RSS", rss_mb)
                elif rss_mb > 2048:
                    logger.warning("[HEALTH] High memory: %dM RSS", rss_mb)
            except Exception:
                pass

    async def close(self) -> None:
        """Shutdown browser resources.

        CDP mode: close pages we created, then disconnect.
        Headless mode: fully close the browser we launched.
        """
        if self._cdp_mode:
            # Close pages that anyweb created (tracked in _pages)
            for key, page in list(self._pages.items()):
                if not page.is_closed():
                    try:
                        await page.close()
                        logger.info("[CLEANUP] CDP page closed: %s", key)
                    except Exception:
                        logger.warning("[CLEANUP] Failed to close CDP page: %s", key)
            self._pages.clear()
            self._page_last_access.clear()
            self._contexts.clear()
            if self._browser:
                try:
                    pid = self._browser.process.pid  # type: ignore[union-attr]
                    _browser_pids.discard(pid)
                except Exception:
                    pass
                try:
                    await self._browser.close()
                except Exception:
                    pass
                self._browser = None
            await self._stop_playwright()
            logger.info("[RES] BrowserManager disconnected (CDP-safe)")
        else:
            # Headless: we own the browser, close everything
            for name in list(self._contexts):
                await self.close_context(name)
            self._page_last_access.clear()
            if self._browser:
                try:
                    pid = self._browser.process.pid  # type: ignore[union-attr]
                    _browser_pids.discard(pid)
                except Exception:
                    pass
                await self._browser.close()
                self._browser = None
            await self._stop_playwright()
            logger.info("[RES] BrowserManager closed (pages=%d, contexts=%d)", len(self._pages), len(self._contexts))
