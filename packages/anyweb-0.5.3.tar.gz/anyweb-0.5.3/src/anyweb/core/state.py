"""Page state extraction — returns indexed interactive elements.

The `state` command is one of anyweb's key features (borrowed from browser-use).
It scans the current page and returns a numbered list of interactive elements
(links, buttons, inputs, selects, textareas) so the agent can reference them
by index number instead of CSS selectors.
"""

from __future__ import annotations

from dataclasses import dataclass

from playwright.async_api import Page

# Shared CSS selector for interactive elements (used in JS snippets)
INTERACTIVE_SELECTOR = (
    "a, button, input, select, textarea, "
    '[role="button"], [role="link"], [role="tab"], '
    '[onclick], [contenteditable="true"]'
)

# JavaScript that extracts interactive elements from the page
_EXTRACT_ELEMENTS_JS = (
    """
() => {
    const INTERACTIVE = '%s';"""
    % INTERACTIVE_SELECTOR
    + """
    const elements = document.querySelectorAll(INTERACTIVE);
    const results = [];
    const seen = new Set();

    for (const el of elements) {
        // Skip hidden elements
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') continue;

        const rect = el.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) continue;

        // Build description
        const tag = el.tagName.toLowerCase();
        const type = el.getAttribute('type') || '';
        const role = el.getAttribute('role') || '';
        const text = (el.textContent || '').trim().substring(0, 80);
        const placeholder = el.getAttribute('placeholder') || '';
        const ariaLabel = el.getAttribute('aria-label') || '';
        const href = el.getAttribute('href') || '';
        const value = el.value || '';
        const name = el.getAttribute('name') || '';

        // Build a unique key to deduplicate
        const key = `${tag}|${text}|${href}|${placeholder}|${name}`;
        if (seen.has(key)) continue;
        seen.add(key);

        // Build label: prefer aria-label > text > placeholder > name
        let label = ariaLabel || text || placeholder || name || '';
        if (label.length > 60) label = label.substring(0, 57) + '...';

        // Build type description
        let desc = tag;
        if (type) desc += `[${type}]`;
        if (role && role !== tag) desc += `[role=${role}]`;

        results.push({
            tag: tag,
            type: type,
            role: role,
            text: label,
            href: href ? href.substring(0, 100) : '',
            placeholder: placeholder,
            value: value ? value.substring(0, 50) : '',
            bbox: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                w: Math.round(rect.width),
                h: Math.round(rect.height),
            },
            desc: desc,
        });
    }
    return results;
}
"""
)

# JavaScript to click element by index
_CLICK_BY_INDEX_JS = (
    """
(index) => {
    const INTERACTIVE = '%s';"""
    % INTERACTIVE_SELECTOR
    + """
    const elements = document.querySelectorAll(INTERACTIVE);
    const visible = [];
    const seen = new Set();

    for (const el of elements) {
        const style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') continue;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 && rect.height === 0) continue;

        const tag = el.tagName.toLowerCase();
        const text = (el.textContent || '').trim().substring(0, 80);
        const href = el.getAttribute('href') || '';
        const placeholder = el.getAttribute('placeholder') || '';
        const name = el.getAttribute('name') || '';
        const key = `${tag}|${text}|${href}|${placeholder}|${name}`;
        if (seen.has(key)) continue;
        seen.add(key);

        visible.push(el);
    }

    if (index < 0 || index >= visible.length) {
        throw new Error(`Index ${index} out of range (0-${visible.length - 1})`);
    }
    const target = visible[index];
    target.scrollIntoView({behavior: 'smooth', block: 'center'});
    return {
        tag: target.tagName.toLowerCase(),
        text: (target.textContent || '').trim().substring(0, 80),
    };
}
"""
)


@dataclass
class ElementInfo:
    """Information about an interactive element on the page."""

    index: int
    tag: str
    type: str
    role: str
    text: str
    href: str
    placeholder: str
    value: str
    bbox: dict
    desc: str

    def format_line(self) -> str:
        """Format as a single line for CLI output."""
        parts = [f"[{self.index}]", self.desc]
        if self.text:
            parts.append(f'"{self.text}"')
        if self.href:
            parts.append(f"-> {self.href}")
        if self.placeholder:
            parts.append(f"({self.placeholder})")
        if self.value:
            parts.append(f"val={self.value}")
        return " ".join(parts)


async def extract_state(page: Page) -> list[ElementInfo]:
    """Extract all interactive elements from the page with index numbers."""
    raw = await page.evaluate(_EXTRACT_ELEMENTS_JS)
    elements = []
    for i, item in enumerate(raw):
        elements.append(
            ElementInfo(
                index=i,
                tag=item["tag"],
                type=item.get("type", ""),
                role=item.get("role", ""),
                text=item.get("text", ""),
                href=item.get("href", ""),
                placeholder=item.get("placeholder", ""),
                value=item.get("value", ""),
                bbox=item.get("bbox", {}),
                desc=item.get("desc", item["tag"]),
            )
        )
    return elements


def format_state(url: str, title: str, elements: list[ElementInfo]) -> str:
    """Format state output for CLI display."""
    lines = [
        f"URL: {url}",
        f"Title: {title}",
        f"Interactive elements: {len(elements)}",
        "---",
    ]
    for el in elements:
        lines.append(el.format_line())
    return "\n".join(lines)


async def get_element_by_index(page: Page, index: int) -> dict:
    """Scroll to and return info about an element by its index."""
    return await page.evaluate(_CLICK_BY_INDEX_JS, index)


async def click_by_index(page: Page, index: int) -> dict:
    """Click an interactive element by its index number."""
    info = await get_element_by_index(page, index)
    await page.evaluate(
        _VISIBLE_ELEMENTS_ACTION_JS % "visible[index].click();",
        index,
    )
    return info


async def hover_by_index(page: Page, index: int) -> None:
    """Hover over an interactive element by its index number."""
    await page.evaluate(
        _VISIBLE_ELEMENTS_ACTION_JS % "visible[index].dispatchEvent(new MouseEvent('mouseover', {bubbles: true}));",
        index,
    )


# Generic JS template: find visible elements, run action on visible[index]
_VISIBLE_ELEMENTS_ACTION_JS = (
    """(index) => {
    const INTERACTIVE = '%s';
    const els = document.querySelectorAll(INTERACTIVE);
    const visible = []; const seen = new Set();
    for (const el of els) {
        const s = window.getComputedStyle(el);
        if (s.display === 'none' || s.visibility === 'hidden') continue;
        const r = el.getBoundingClientRect();
        if (r.width === 0 && r.height === 0) continue;
        const t = el.tagName.toLowerCase();
        const tx = (el.textContent||'').trim().substring(0,80);
        const h = el.getAttribute('href')||'';
        const p = el.getAttribute('placeholder')||'';
        const n = el.getAttribute('name')||'';
        const k = t+'|'+tx+'|'+h+'|'+p+'|'+n;
        if (seen.has(k)) continue; seen.add(k);
        visible.push(el);
    }
    if (index >= 0 && index < visible.length) { %%s }
}"""
    % INTERACTIVE_SELECTOR
).replace("%%s", "%s")


def is_index(target: str) -> bool:
    """Check if a target string is a numeric index vs CSS selector."""
    return target.isdigit()
