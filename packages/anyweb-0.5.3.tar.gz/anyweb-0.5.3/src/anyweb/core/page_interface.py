"""Unified page interface for Playwright and Chrome extension backends."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class PageInterface(Protocol):
    """Protocol defining the page operations used by adapters.

    Both PlaywrightPage and ChromeExtensionPage implement this,
    allowing adapters to work with either backend.
    """

    async def goto(self, url: str, wait_until: str = "domcontentloaded", timeout: int = 30000) -> None: ...

    async def evaluate(self, expression: str) -> Any: ...

    async def inner_text(self, selector: str = "body") -> str: ...

    async def click(self, selector: str) -> None: ...

    async def type_text(self, text: str, delay: int = 50) -> None: ...

    async def wait_for_selector(self, selector: str, timeout: int = 30000) -> None: ...

    async def title(self) -> str: ...

    @property
    def url(self) -> str: ...

    async def query_selector(self, selector: str) -> Any: ...

    async def close(self) -> None: ...
