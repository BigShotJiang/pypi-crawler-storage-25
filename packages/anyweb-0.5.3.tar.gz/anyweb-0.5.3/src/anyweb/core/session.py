"""Session (cookie / storage_state) persistence manager.

Saves and loads Playwright storage states so users don't have to re-login
every time the daemon restarts.
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from playwright.async_api import BrowserContext

from anyweb.core.paths import SESSIONS_DIR

logger = logging.getLogger(__name__)


class SessionManager:
    """Manages platform session persistence via Playwright storage_state."""

    def __init__(self, session_dir: Path | str | None = None) -> None:
        self.session_dir = Path(session_dir) if session_dir else SESSIONS_DIR
        self.session_dir.mkdir(parents=True, exist_ok=True)

    def _session_path(self, platform: str) -> Path:
        return self.session_dir / f"{platform}_session.json"

    def has_session(self, platform: str) -> bool:
        path = self._session_path(platform)
        return path.exists() and path.stat().st_size > 0

    async def save_session(self, platform: str, context: BrowserContext) -> str:
        path = self._session_path(platform)
        await context.storage_state(path=str(path))
        logger.info("Session saved for %s at %s", platform, path)
        return str(path)

    def save_cookies(self, platform: str, cookies: list[dict], origins: list[dict] | None = None) -> str:
        """Persist cookies in Playwright storage_state format."""
        path = self._session_path(platform)
        path.write_text(
            json.dumps(
                {
                    "cookies": cookies,
                    "origins": origins or [],
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        logger.info("Session cookies saved for %s at %s", platform, path)
        return str(path)

    def load_session_state(self, platform: str) -> dict | None:
        path = self._session_path(platform)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Failed to load session for %s: %s", platform, exc)
            return None

        cookies = data.get("cookies", [])
        now = time.time()
        before = len(cookies)
        cookies = [c for c in cookies if c.get("expires", -1) < 0 or c["expires"] > now]
        if len(cookies) < before:
            logger.info(
                "Dropped %d expired cookies for %s",
                before - len(cookies),
                platform,
            )
        data["cookies"] = cookies
        logger.info("Session loaded for %s from %s", platform, path)
        return data

    def delete_session(self, platform: str) -> bool:
        path = self._session_path(platform)
        if path.exists():
            path.unlink()
            logger.info("Session deleted for %s", platform)
            return True
        return False
