"""Accessibility tree extraction via CDP.

Uses Chrome DevTools Protocol ``Accessibility.getFullAXTree`` to build a
compact, token-efficient representation of the page — the industry-standard
approach for AI agent page understanding (2026 consensus).

Ref IDs (``e0``, ``e1``, …) are assigned to interactive nodes and cached
so that ``click e5`` deterministically targets the same DOM element.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any

from playwright.async_api import Page

logger = logging.getLogger(__name__)

# AX roles considered interactive (can be clicked / typed into).
INTERACTIVE_ROLES = frozenset(
    {
        "button",
        "checkbox",
        "combobox",
        "link",
        "menuitem",
        "menuitemcheckbox",
        "menuitemradio",
        "option",
        "radio",
        "searchbox",
        "slider",
        "spinbutton",
        "switch",
        "tab",
        "textbox",
        "treeitem",
    }
)

# Roles that are structural / grouping — skip in compact output.
_SKIP_ROLES = frozenset(
    {
        "none",
        "presentation",
        "generic",
        "InlineTextBox",
        "LineBreak",
    }
)

_TEXT_ROLES = frozenset({"StaticText", "text"})
_NO_SPACE_BEFORE = frozenset(".,;:!?%)]}，。！？；：、）】》")
_NO_SPACE_AFTER = frozenset("([{（【《")
_NON_TEXT_NAME_LIMIT = 80


@dataclass
class AXNode:
    """A single accessibility tree node."""

    role: str
    name: str
    ref: str = ""  # e.g. "e0" — only for interactive nodes
    value: str = ""
    description: str = ""
    focused: bool = False
    disabled: bool = False
    checked: str = ""  # "true", "false", "mixed", or ""
    expanded: str = ""  # "true", "false", or ""
    level: int = 0  # heading level
    url: str = ""
    children: list[AXNode] = field(default_factory=list)
    backend_node_id: int = 0  # for ref-based interaction


@dataclass
class AXSnapshot:
    """Complete accessibility snapshot with ref cache."""

    url: str
    title: str
    root: AXNode
    ref_cache: dict[str, int] = field(default_factory=dict)  # ref -> backendDOMNodeId


def _parse_ax_properties(props: list[dict]) -> dict:
    """Extract useful properties from the CDP AX node properties list."""
    result: dict = {}
    for p in props:
        name = p.get("name", "")
        val = p.get("value", {})
        v = val.get("value")
        if name == "focused" and v:
            result["focused"] = True
        elif name == "disabled" and v:
            result["disabled"] = True
        elif name == "checked":
            result["checked"] = str(v) if v is not None else ""
        elif name == "expanded":
            result["expanded"] = str(v) if v is not None else ""
        elif name == "level" and v:
            result["level"] = int(v)
        elif name == "url" and v:
            result["url"] = str(v)
    return result


def _clean_text(value: str) -> str:
    """Collapse AX text whitespace while preserving readable word boundaries."""
    return " ".join(value.split())


def _join_text(left: str, right: str) -> str:
    """Join adjacent StaticText fragments without creating punctuation gaps."""
    left = _clean_text(left)
    right = _clean_text(right)
    if not left:
        return right
    if not right:
        return left
    if right[0] in _NO_SPACE_BEFORE or left[-1] in _NO_SPACE_AFTER:
        return left + right
    return f"{left} {right}"


def _same_text(left: str, right: str) -> bool:
    return bool(left and right) and _clean_text(left) == _clean_text(right)


def _format_name(node: AXNode) -> str:
    """Format node names without truncating page content text."""
    if _is_text_node(node):
        return node.name
    if len(node.name) > _NON_TEXT_NAME_LIMIT:
        return node.name[: _NON_TEXT_NAME_LIMIT - 3] + "..."
    return node.name


def _is_text_node(node: AXNode) -> bool:
    return node.role in _TEXT_ROLES


def _is_plain_wrapper(node: AXNode) -> bool:
    """Return True for structural AX wrappers that add no semantic content."""
    return (
        node.role in _SKIP_ROLES
        and not node.ref
        and not _clean_text(node.name)
        and not _clean_text(node.value)
        and not _clean_text(node.description)
        and not node.focused
        and not node.disabled
        and not node.checked
        and not node.expanded
        and not node.level
        and not node.url
    )


def _clean_tree(node: AXNode) -> AXNode | None:
    """Remove structural AX noise while preserving clickable refs.

    X/Grok pages contain very deep ``generic``/``none`` wrapper chains and
    duplicate StaticText under named links/buttons. Cleaning after ref assignment
    keeps element IDs stable while making ``state --ax`` much cheaper to read.
    """
    if _is_text_node(node):
        node.name = _clean_text(node.name)
        if not node.name:
            return None

    cleaned_children: list[AXNode] = []
    for child in node.children:
        cleaned = _clean_tree(child)
        if not cleaned:
            continue
        if _is_plain_wrapper(cleaned):
            cleaned_children.extend(cleaned.children)
        else:
            cleaned_children.append(cleaned)

    merged_children: list[AXNode] = []
    for child in cleaned_children:
        if merged_children and _is_text_node(merged_children[-1]) and _is_text_node(child):
            merged_children[-1].name = _join_text(merged_children[-1].name, child.name)
            continue
        merged_children.append(child)

    children: list[AXNode] = []
    for child in merged_children:
        if _is_text_node(child) and _same_text(child.name, node.name):
            continue
        children.append(child)

    node.children = children

    if _is_plain_wrapper(node) and not node.children:
        return None

    return node


def _build_tree(
    nodes: list[dict],
    interactive_only: bool = False,
) -> tuple[AXNode, dict[str, int]]:
    """Build AXNode tree from CDP ``Accessibility.getFullAXTree`` response.

    Returns (root_node, ref_cache) where ref_cache maps ref IDs to
    backend DOM node IDs.
    """
    # Build node map: nodeId -> cdp_node
    node_map: dict[str, dict] = {}
    for n in nodes:
        node_map[n["nodeId"]] = n

    # Build parent->children mapping
    children_map: dict[str, list[str]] = {}
    for n in nodes:
        for child_id in n.get("childIds", []):
            children_map.setdefault(n["nodeId"], []).append(child_id)

    ref_cache: dict[str, int] = {}
    ref_counter = [0]

    def _convert(node_id: str, depth: int = 0) -> AXNode | None:
        cdp_node = node_map.get(node_id)
        if not cdp_node:
            return None

        role_val = cdp_node.get("role", {}).get("value", "none")
        name_val = cdp_node.get("name", {}).get("value", "")
        desc_val = cdp_node.get("description", {}).get("value", "")
        value_val = cdp_node.get("value", {}).get("value", "")

        # Parse properties
        props = _parse_ax_properties(cdp_node.get("properties", []))

        is_interactive = role_val in INTERACTIVE_ROLES

        # Build children first
        child_ids = children_map.get(node_id, [])
        children: list[AXNode] = []
        for cid in child_ids:
            child = _convert(cid, depth + 1)
            if child:
                children.append(child)

        # Skip non-interesting nodes
        if role_val in _SKIP_ROLES and not children:
            return None

        # In interactive-only mode, skip non-interactive leaf nodes
        if interactive_only and not is_interactive and not children:
            # Skip static text nodes
            if role_val in ("StaticText", "text"):
                return None

        # Assign ref to interactive nodes
        ref = ""
        if is_interactive:
            ref = f"e{ref_counter[0]}"
            ref_counter[0] += 1
            backend_id = cdp_node.get("backendDOMNodeId", 0)
            if backend_id:
                ref_cache[ref] = backend_id

        node = AXNode(
            role=role_val,
            name=name_val,
            ref=ref,
            value=value_val if isinstance(value_val, str) else str(value_val) if value_val else "",
            description=desc_val,
            focused=props.get("focused", False),
            disabled=props.get("disabled", False),
            checked=props.get("checked", ""),
            expanded=props.get("expanded", ""),
            level=props.get("level", 0),
            url=props.get("url", ""),
            children=children,
            backend_node_id=cdp_node.get("backendDOMNodeId", 0),
        )

        # In interactive-only mode, flatten non-interactive parents
        # that have only one child — reduce noise
        if interactive_only and not is_interactive and len(children) == 1:
            return children[0]

        return node

    root_id = nodes[0]["nodeId"] if nodes else ""
    root = _convert(root_id) or AXNode(role="RootWebArea", name="")
    root = _clean_tree(root) or AXNode(role="RootWebArea", name="")

    return root, ref_cache


def format_compact(node: AXNode, depth: int = 0, max_depth: int = 0) -> list[str]:
    """Format AX tree in compact text format (PinchTab-style).

    Example output::

        e0:link "Home" -> /
        e1:button "Menu"
          e2:link "About" -> /about
          e3:link "Contact" -> /contact
        heading "Welcome" [level=2]
        e4:textbox "Search..." *
    """
    if max_depth and depth > max_depth:
        return []

    lines: list[str] = []
    indent = "  " * depth

    # Build the line
    parts: list[str] = []

    # Ref + role
    if node.ref:
        parts.append(f"{node.ref}:{node.role}")
    else:
        parts.append(node.role)

    # Name (quoted)
    if node.name:
        name = _format_name(node)
        parts.append(f'"{name}"')

    # Value (for textbox etc.)
    if node.value and node.value != node.name:
        val = node.value
        if len(val) > 40:
            val = val[:37] + "..."
        parts.append(f"val={val}")

    # Flags
    flags: list[str] = []
    if node.focused:
        flags.append("*")
    if node.disabled:
        flags.append("-")
    if node.checked:
        flags.append(f"checked={node.checked}")
    if node.expanded:
        flags.append(f"expanded={node.expanded}")
    if node.level:
        flags.append(f"level={node.level}")
    if flags:
        parts.append(" ".join(flags))

    # URL (for links)
    if node.url:
        url = node.url
        if len(url) > 80:
            url = url[:77] + "..."
        parts.append(f"-> {url}")

    line = indent + " ".join(parts)
    lines.append(line)

    # Children
    for child in node.children:
        lines.extend(format_compact(child, depth + 1, max_depth))

    return lines


async def get_ax_snapshot(
    page: Page,
    *,
    interactive_only: bool = False,
    max_depth: int = 0,
    cdp_sender: Any | None = None,
) -> AXSnapshot:
    """Get an accessibility tree snapshot of the page.

    Args:
        page: Playwright page.
        interactive_only: Only include interactive elements and their ancestors.
        max_depth: Maximum tree depth (0 = unlimited).
        cdp_sender: Optional async callable(method, params) for sending CDP
            commands directly (used in cdp mode where new_cdp_session
            crashes Playwright).

    Returns:
        AXSnapshot with formatted tree and ref cache.
    """
    if cdp_sender:
        result = await cdp_sender("Accessibility.getFullAXTree", {})
        nodes = result.get("nodes", [])
    else:
        cdp = await page.context.new_cdp_session(page)
        try:
            result = await cdp.send("Accessibility.getFullAXTree")
            nodes = result.get("nodes", [])
        finally:
            await cdp.detach()

    root, ref_cache = _build_tree(nodes, interactive_only=interactive_only)

    url = page.url
    title = await page.title()

    snapshot = AXSnapshot(
        url=url,
        title=title,
        root=root,
        ref_cache=ref_cache,
    )

    return snapshot


def format_snapshot(snapshot: AXSnapshot, max_depth: int = 0) -> str:
    """Format a snapshot as text output."""
    lines = [
        f"URL: {snapshot.url}",
        f"Title: {snapshot.title}",
        f"Refs: {len(snapshot.ref_cache)} interactive elements",
        "---",
    ]
    lines.extend(format_compact(snapshot.root, max_depth=max_depth))
    return "\n".join(lines)


async def click_by_ref(
    page: Page,
    ref: str,
    ref_cache: dict[str, int],
    cdp_sender: Any | None = None,
) -> dict:
    """Click an element by its AX tree ref (e.g. 'e5').

    Uses the cached backend DOM node ID for deterministic targeting.
    In cdp mode, uses cdp_sender to avoid new_cdp_session crashes.
    """
    backend_id = ref_cache.get(ref)
    if backend_id is None:
        raise ValueError(f"Unknown ref '{ref}'. Run 'state --ax' first.")

    # Use a single CDP session for all operations so objectId stays valid
    cdp = None
    try:
        if not cdp_sender:
            cdp = await page.context.new_cdp_session(page)

        async def _send(method: str, params: dict) -> dict:
            if cdp_sender:
                return await cdp_sender(method, params)
            assert cdp is not None
            return await cdp.send(method, params)

        # Scroll into view
        try:
            await _send("DOM.scrollIntoViewIfNeeded", {"backendNodeId": backend_id})
        except Exception:
            pass

        # Get bounding box for click coordinates
        box_result = await _send("DOM.getBoxModel", {"backendNodeId": backend_id})
        content = box_result["model"]["content"]
        # content is [x1,y1, x2,y2, x3,y3, x4,y4]
        cx = (content[0] + content[2]) / 2
        cy = (content[1] + content[5]) / 2

        # Get node description (best-effort, not critical for click)
        info: dict = {}
        try:
            await _send("Runtime.enable", {})
            result = await _send("DOM.resolveNode", {"backendNodeId": backend_id})
            object_id = result["object"]["objectId"]
            desc = await _send(
                "Runtime.callFunctionOn",
                {
                    "objectId": object_id,
                    "functionDeclaration": """function() {
                        return {
                            tag: this.tagName ? this.tagName.toLowerCase() : '',
                            text: (this.textContent || '').trim().substring(0, 80),
                            role: this.getAttribute('role') || '',
                        };
                    }""",
                    "returnByValue": True,
                },
            )
            info = desc.get("result", {}).get("value", {})
        except Exception:
            logger.debug("Failed to get node description for %s, clicking anyway", ref)

        # Use Playwright's mouse for realistic click (handles viewport offset)
        await page.mouse.click(cx, cy)

        return {"ref": ref, **info}
    finally:
        if cdp:
            await cdp.detach()


def is_ax_ref(target: str) -> bool:
    """Check if target is an AX ref like 'e5'."""
    return bool(target) and target[0] == "e" and target[1:].isdigit()
