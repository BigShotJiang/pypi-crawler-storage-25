"""Human behavior simulation utilities.

Physical models for realistic mouse movement, scrolling, and typing patterns.
"""

from __future__ import annotations

import asyncio
import random

from playwright.async_api import Page


def generate_smooth_track(distance: float) -> list[float]:
    """Generate a smooth movement track simulating human drag/swipe."""
    track: list[float] = []
    current = 0.0
    mid = distance * 0.7
    t = 0.15
    v = 0.0

    for _ in range(1000):
        if current >= distance:
            break
        a = random.uniform(3, 5) if current < mid else -random.uniform(4, 6)
        v0 = v
        v = max(min(v0 + a * t, 20), 0)
        move = v0 * t + 0.5 * a * t * t
        if move > 0:
            current += move
            if current > distance:
                move -= current - distance
                current = distance
            if move > 0:
                track.append(round(move, 2))
        else:
            remaining = distance - current
            if remaining > 0:
                step = min(1.0, remaining)
                track.append(round(step, 2))
                current += step
            else:
                break

    if current < distance:
        track.append(round(distance - current, 2))
    return track


async def human_type(page: Page, selector: str, text: str) -> None:
    """Type text with human-like delays between keystrokes."""
    await page.click(selector)
    for char in text:
        await page.keyboard.type(char, delay=random.randint(50, 180))
        if random.random() < 0.05:
            await asyncio.sleep(random.uniform(0.2, 0.6))


async def human_scroll(
    page: Page,
    direction: str = "down",
    amount: int = 500,
    steps: int = 0,
    selector: str | None = None,
) -> None:
    """Scroll the page with human-like behavior."""
    if steps <= 0:
        steps = max(3, amount // random.randint(80, 150))

    delta_sign = 1 if direction == "down" else -1
    remaining = amount

    if selector:
        el = await page.query_selector(selector)
        if not el:
            msg = f"scroll selector not found: {selector}"
            raise ValueError(msg)
        for _ in range(steps):
            if remaining <= 0:
                break
            chunk = min(remaining, random.randint(60, 160))
            remaining -= chunk
            await el.evaluate("(el, dy) => el.scrollBy(0, dy)", chunk * delta_sign)
            await asyncio.sleep(random.uniform(0.02, 0.12))
    else:
        for _ in range(steps):
            if remaining <= 0:
                break
            chunk = min(remaining, random.randint(60, 160))
            remaining -= chunk
            await page.mouse.wheel(0, chunk * delta_sign)
            await asyncio.sleep(random.uniform(0.02, 0.12))

    await asyncio.sleep(random.uniform(0.1, 0.3))


async def human_move_to(page: Page, x: float, y: float) -> None:
    """Move mouse to target coordinates with a smooth, curved path."""
    start_x = random.randint(100, 400)
    start_y = random.randint(100, 400)
    dx = x - start_x
    dy = y - start_y
    steps = random.randint(15, 30)

    for i in range(steps):
        progress = (i + 1) / steps
        ease = progress * progress * (3 - 2 * progress)
        cx = start_x + dx * ease + random.uniform(-2, 2)
        cy = start_y + dy * ease + random.uniform(-2, 2)
        await page.mouse.move(cx, cy)
        await asyncio.sleep(random.uniform(0.005, 0.02))


async def random_delay(min_s: float = 0.5, max_s: float = 2.0) -> None:
    """Sleep for a random duration to mimic human thinking time."""
    await asyncio.sleep(random.uniform(min_s, max_s))
