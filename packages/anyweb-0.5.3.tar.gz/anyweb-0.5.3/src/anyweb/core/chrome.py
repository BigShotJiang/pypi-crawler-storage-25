"""Cross-platform Chrome/Chromium discovery."""

from __future__ import annotations

import os
import platform
import shutil


def find_chrome_executable() -> str | None:
    """Find a Chrome or Chromium executable on the current platform."""
    system = platform.system()
    candidates: list[str] = []

    if system == "Darwin":
        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
        ]
    elif system == "Linux":
        candidates = [
            "google-chrome",
            "google-chrome-stable",
            "chromium-browser",
            "chromium",
        ]
    elif system == "Windows":
        for env_var in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
            base = os.environ.get(env_var, "")
            if base:
                candidates.append(os.path.join(base, "Google", "Chrome", "Application", "chrome.exe"))

    for candidate in candidates:
        if os.path.isabs(candidate) and os.path.exists(candidate):
            return candidate
        resolved = shutil.which(candidate)
        if resolved:
            return resolved
    return None


def find_chrome_channel() -> str:
    """Return 'chrome' as the Playwright channel.

    Always uses Chrome (not Chromium) — Chromium gets caught by anti-bot
    detection on platforms like X/Twitter.
    """
    return "chrome"
