"""Unified path and port constants for anyweb."""

from __future__ import annotations

import os
import platform
import subprocess
from pathlib import Path

ANYWEB_DIR = Path.home() / ".anyweb"
SESSIONS_DIR = ANYWEB_DIR / "sessions"
CHROME_PROFILE_DIR = ANYWEB_DIR / "chrome-profile"
CDP_PORT = 9222
CDP_ENDPOINT = f"http://127.0.0.1:{CDP_PORT}"


def _chrome_profile_candidates() -> list[Path]:
    """Return candidate Chrome profile directories for the current OS."""
    system = platform.system()
    if system == "Darwin":
        return [Path.home() / "Library" / "Application Support" / "Google" / "Chrome"]
    if system == "Linux":
        return [Path.home() / ".config" / "google-chrome"]
    if system == "Windows":
        local = os.environ.get("LOCALAPPDATA", "")
        if local:
            return [Path(local) / "Google" / "Chrome" / "User Data"]
    return []


def system_chrome_profile() -> Path | None:
    """Detect the user's default Chrome profile directory.

    Returns the user-data-dir (parent of Default/) if Default/Cookies exists.
    """
    for candidate in _chrome_profile_candidates():
        if (candidate / "Default" / "Cookies").exists():
            return candidate
    return None


def is_system_chrome_running() -> bool:
    """Check if the user's Chrome browser is currently running."""
    system = platform.system()
    try:
        if system in ("Darwin", "Linux"):
            result = subprocess.run(
                ["pgrep", "-f", "Google Chrome"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        if system == "Windows":
            result = subprocess.run(
                ["tasklist", "/FI", "IMAGENAME eq chrome.exe"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return "chrome.exe" in result.stdout.lower()
    except Exception:
        pass
    return False
