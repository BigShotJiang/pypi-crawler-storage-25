"""CLI entry point for anyweb.

Usage:
    anyweb open https://example.com
    anyweb state
    anyweb click 5
    anyweb eval "document.title"
    anyweb close
"""

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from anyweb.core.paths import ANYWEB_DIR, system_chrome_profile, is_system_chrome_running
from anyweb.core.chrome import find_chrome_executable
from anyweb.daemon import (
    is_daemon_running,
    send_command,
    start_daemon,
)

# Interactive commands that operate on a platform page
_INTERACTIVE_CMDS = {
    "state",
    "click",
    "type",
    "input",
    "keys",
    "scroll",
    "eval",
    "screenshot",
    "wait",
    "get",
    "hover",
    "back",
}


def _get_platform(session: str) -> str:
    """Read the last-used platform from session state file."""
    p = ANYWEB_DIR / f"{session}.platform"
    return p.read_text().strip() if p.exists() else "generic"


def _set_platform(session: str, platform: str) -> None:
    """Write the current platform to session state file."""
    p = ANYWEB_DIR / f"{session}.platform"
    p.write_text(platform)


def _ensure_daemon(session: str) -> None:
    """Start the daemon if not already running."""
    if not is_daemon_running(session):
        start_daemon(session)
        if not is_daemon_running(session):
            print("Error: Failed to start daemon", file=sys.stderr)
            sys.exit(1)


def _run(session: str, command: dict) -> dict:
    """Send a command to the daemon and return the result."""
    _ensure_daemon(session)
    return asyncio.run(send_command(session, command))


def _output(response: dict, as_json: bool = False, as_markdown: bool = False) -> None:
    """Print the response to stdout."""
    if not response.get("ok", False):
        print(f"Error: {response.get('error', 'Unknown error')}", file=sys.stderr)
        sys.exit(1)

    data = response.get("data", {})

    if as_json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return

    if as_markdown and "content" in data and "title" in data:
        _output_markdown(data)
        return

    # Smart formatting based on content
    if "content" in data and "title" in data:
        # read command output
        if data.get("title"):
            print(f"# {data['title']}")
            if data.get("author"):
                print(f"by {data['author']}")
            print()
        print(data["content"])
    elif "results" in data and isinstance(data["results"], list):
        # search command output
        for i, r in enumerate(data["results"]):
            print(f"[{i}] {r.get('title', '')}")
            if r.get("url"):
                print(f"    {r['url']}")
            if r.get("summary"):
                summary = r["summary"][:120]
                print(f"    {summary}")
            print()
    elif "text" in data and isinstance(data["text"], str):
        print(data["text"])
    elif "result" in data:
        result = data["result"]
        if isinstance(result, str):
            print(result)
        elif result is not None:
            print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        # Default: compact JSON
        print(json.dumps(data, ensure_ascii=False))


def _output_markdown(data: dict) -> None:
    """Format read output as Markdown with embedded images."""
    lines = []
    if data.get("title"):
        lines.append(f"# {data['title']}")
        lines.append("")
    if data.get("author"):
        lines.append(f"> Author: {data['author']}")
        lines.append("")
    if data.get("url"):
        lines.append(f"> Source: {data['url']}")
        lines.append("")

    content = data.get("content", "")
    lines.append(content)

    # Append image URLs as markdown images
    images = data.get("images", [])
    if images:
        lines.append("")
        lines.append("## Images")
        lines.append("")
        for img in images:
            if isinstance(img, dict):
                alt = img.get("alt", "image")
                url = img.get("url", "")
            else:
                alt, url = "image", str(img)
            lines.append(f"![{alt}]({url})")

    # Metadata footer
    platform = data.get("platform", "")
    if platform and platform != "generic":
        lines.append("")
        lines.append(f"---\nPlatform: {platform}")

    print("\n".join(lines))


def _filter_log_lines(
    lines: list[str],
    *,
    cmd_only: bool = False,
    engine: str | None = None,
    errors_only: bool = False,
) -> list[str]:
    """Filter log lines by criteria."""
    result = lines
    if cmd_only:
        result = [l for l in result if "[CMD]" in l]
    if engine:
        result = [l for l in result if f"[{engine}:" in l]
    if errors_only:
        result = [l for l in result if "ERROR" in l or "TIMEOUT" in l]
    return result


def _log(
    follow: bool = False,
    show_all: bool = False,
    n: int = 20,
    engine: str | None = None,
    errors_only: bool = False,
) -> None:
    """View daemon command log."""
    from anyweb.daemon import log_path

    lp = log_path()
    if not lp.exists():
        print("No log file found. Daemon has not been started yet.", file=sys.stderr)
        sys.exit(1)

    if follow:
        import subprocess

        subprocess.run(["tail", "-f", str(lp)])
        return

    lines = lp.read_text().splitlines()
    lines = _filter_log_lines(
        lines,
        cmd_only=not show_all,
        engine=engine,
        errors_only=errors_only,
    )
    for line in lines[-n:]:
        print(line)


_AUTH_COOKIES = {
    "x": "auth_token",
    "zhihu": "z_c0",
    "xhs": "customer-sso-sid",
    "wechat": "slave_sid",
}

_PLATFORMS = ["x", "zhihu", "xhs", "wechat"]


def _check_chrome() -> list[tuple[str, str]]:
    """Check Chrome installation and profiles."""
    results = []
    chrome_path = find_chrome_executable()
    if chrome_path:
        results.append(("OK", f"Chrome found: {chrome_path}"))
    else:
        results.append(("FAIL", "Chrome not found"))

    sys_profile = system_chrome_profile()
    if sys_profile:
        results.append(("OK", f"System Chrome profile: {sys_profile}"))
    else:
        results.append(("--", "System Chrome profile: not found"))

    anyweb_profile = ANYWEB_DIR / "chrome-profile"
    if anyweb_profile.exists():
        results.append(("OK", f"anyweb profile: {anyweb_profile}"))
    else:
        results.append(("--", "anyweb profile: not created yet"))

    return results


def _check_credentials(session_dir, platforms=None):
    """Check credential status per platform.

    Returns (results, issues) where results is list of (status, message, platform)
    and issues is list of (issue_type, platform).
    """
    import time as _time

    platforms = platforms or _PLATFORMS
    results = []
    issues = []

    for platform in platforms:
        session_file = session_dir / f"{platform}_session.json"
        if not session_file.exists():
            results.append(("--", "no session", platform))
            issues.append(("missing", platform))
            continue

        try:
            data = json.loads(session_file.read_text())
        except (json.JSONDecodeError, OSError):
            results.append(("!!", "session file corrupt", platform))
            issues.append(("corrupt", platform))
            continue

        cookies = data.get("cookies", [])
        auth_name = _AUTH_COOKIES.get(platform)
        has_auth = any(c.get("name") == auth_name for c in cookies) if auth_name else len(cookies) > 5

        if not has_auth:
            results.append(("!!", "auth cookie missing", platform))
            issues.append(("invalid", platform))
            continue

        now = _time.time()
        auth_cookies = [c for c in cookies if c.get("name") == auth_name]
        if auth_cookies:
            exp = auth_cookies[0].get("expires", -1)
            if exp > 0 and exp < now:
                results.append(("!!", "expired", platform))
                issues.append(("expired", platform))
                continue
            elif exp > 0:
                days_left = int((exp - now) / 86400)
                results.append(("OK", f"valid ({days_left} days left)", platform))
            else:
                results.append(("OK", "valid (no expiry)", platform))
        else:
            results.append(("OK", f"valid ({len(cookies)} cookies)", platform))

    return results, issues


def _doctor(fix: bool = False) -> None:
    """Check dependencies, Chrome, credentials, and optionally auto-fix."""
    import shutil
    import subprocess

    all_ok = True

    print("=== Dependencies ===")
    checks = []
    checks.append(("Python 3.11+", sys.version_info >= (3, 11)))

    try:
        import playwright  # noqa: F401

        checks.append(("playwright package", True))
    except ImportError:
        checks.append(("playwright package", False))

    pw_path = shutil.which("playwright")
    if pw_path:
        result = subprocess.run(
            ["playwright", "install", "--dry-run"],
            capture_output=True,
            text=True,
        )
        checks.append(("Playwright browsers", result.returncode == 0))
    else:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "--dry-run"],
            capture_output=True,
            text=True,
        )
        checks.append(("Playwright browsers", result.returncode == 0))

    try:
        import playwright_stealth  # noqa: F401

        checks.append(("playwright-stealth", True))
    except ImportError:
        checks.append(("playwright-stealth", False))

    for name, ok in checks:
        status = "OK" if ok else "FAIL"
        if not ok:
            all_ok = False
        print(f"  [{status}] {name}")

    print("\n=== Chrome ===")
    chrome_results = _check_chrome()
    for status, msg in chrome_results:
        if status == "FAIL":
            all_ok = False
        print(f"  [{status}] {msg}")

    print("\n=== Credentials ===")
    session_dir = ANYWEB_DIR / "sessions"
    session_dir.mkdir(parents=True, exist_ok=True)
    cred_results, issues = _check_credentials(session_dir)
    for status, msg, platform in cred_results:
        if status in ("!!", "FAIL"):
            all_ok = False
        print(f"  [{status}] {platform:8s} {msg}")

    fixable = [i for i in issues if i[0] in ("expired", "invalid", "corrupt")]
    manual = [i for i in issues if i[0] == "missing"]

    if fixable or manual:
        print("\n=== Recommended Actions ===")
        for issue_type, platform in fixable:
            print(f"  anyweb login {platform}          # refresh {issue_type} session")
        for issue_type, platform in manual:
            print(f"  anyweb login {platform}          # first-time login")

    if fix and fixable:
        print("\n=== Auto-fixing ===")
        chrome_running = is_system_chrome_running()
        if chrome_running:
            print("  [!!] Chrome is running. Close Chrome to allow credential import.")
            print("       After closing, run: anyweb doctor --fix")
        else:
            for issue_type, platform in fixable:
                print(f"  [FIX] {platform}: importing from system Chrome...")
                session = "default"
                if not is_daemon_running(session):
                    start_daemon(session)
                result = asyncio.run(
                    send_command(
                        session,
                        {
                            "cmd": "login",
                            "args": {"platform": platform, "method": "import"},
                        },
                    )
                )
                if result.get("ok") and result.get("data", {}).get("success"):
                    data = result["data"]
                    print(f"        {data.get('message', 'OK')}")
                else:
                    err = result.get("data", {}).get("message") or result.get("error", "unknown")
                    print(f"        Failed: {err}")
                    print(f"        Try: anyweb login {platform} --method browser")

            print("\n=== Result ===")
            cred_results2, _ = _check_credentials(session_dir)
            for status, msg, platform in cred_results2:
                print(f"  [{status}] {platform:8s} {msg}")

    if all_ok and not issues:
        print("\nAll checks passed. anyweb is ready to use.")
    elif not fix and fixable:
        print(f"\nRun 'anyweb doctor --fix' to auto-repair {len(fixable)} issue(s).")

    if not all_ok:
        sys.exit(1)


def _install() -> None:
    """Install Playwright browsers."""
    import subprocess

    print("Installing Playwright browsers...")
    result = subprocess.run(
        [sys.executable, "-m", "playwright", "install", "chromium"],
    )
    if result.returncode == 0:
        print("Playwright Chromium installed successfully.")
    else:
        print("Failed to install browsers.", file=sys.stderr)
        sys.exit(1)


def _format_status(data: dict) -> None:
    """Pretty-print the status command output."""
    import datetime

    # Daemon
    d = data.get("daemon", {})
    uptime = d.get("uptime_s", 0)
    h, m = divmod(uptime // 60, 60)
    uptime_str = f"{h}h {m}m" if h else f"{m}m"
    rss = d.get("rss_mb", "?")
    print("=== anyweb daemon ===")
    print(f"PID: {d.get('pid', '?')} | Uptime: {uptime_str} | RSS: {rss}M")
    print()

    # Browsers
    print("=== Browsers ===")
    for b in data.get("browsers", []):
        status = "running" if b.get("running") else "stopped"
        extra = ""
        if b.get("browser_pid"):
            extra = f" → PID {b['browser_pid']}"
            if b.get("browser_rss_mb"):
                extra += f" ({b['browser_rss_mb']}M)"
        print(f"  {b['mode']:<10}: {status} | pages: {b.get('pages', 0)} | contexts: {b.get('contexts', 0)}{extra}")
    chrome = data.get("chrome")
    if chrome and chrome.get("pid"):
        print(f"  chrome    : PID {chrome['pid']} (RSS: {chrome.get('rss_mb', '?')}M) [AI-managed]")
    if not data.get("browsers"):
        print("  (none)")
    print()

    # Pages
    print("=== Pages ===")
    pages = data.get("pages", [])
    if pages:
        for p in pages:
            idle_m, idle_s = divmod(p.get("idle_s", 0), 60)
            idle_str = f"{idle_m}m {idle_s}s" if idle_m else f"{idle_s}s"
            status = "(closed)" if p.get("closed") else p.get("url", "")
            if len(status) > 60:
                status = status[:57] + "..."
            print(f"  {p['key']:<16}: {status} | idle: {idle_str}")
    else:
        print("  (no active pages)")
    print()

    # Orphans
    orphans = data.get("orphans", [])
    print("=== Processes ===")
    if orphans:
        for o in orphans:
            print(f"  orphan playwright: PID {o['pid']} ({o.get('rss_mb', '?')}M) ⚠️")
    else:
        print("  (no orphan processes)")
    print()

    # Sessions
    print("=== Sessions ===")
    sessions = data.get("sessions", [])
    if sessions:
        now = datetime.datetime.now().timestamp()
        for s in sessions:
            if s.get("error"):
                print(f"  {s['platform']:<10}: ❌ {s['error']}")
                continue
            saved = datetime.datetime.fromtimestamp(s.get("saved", 0)).strftime("%Y-%m-%d %H:%M")
            cookies = s.get("cookie_count", 0)
            exp = s.get("auth_expiry")
            if not s.get("has_auth"):
                exp_str = "no auth cookie ❌"
            elif exp is None:
                exp_str = "no expiry"
            elif s.get("expired"):
                exp_str = "expired ❌"
            elif exp - now < 7 * 86400:
                exp_str = f"expires {datetime.datetime.fromtimestamp(exp).strftime('%Y-%m-%d')} ⚠️ soon"
            else:
                exp_str = f"expires {datetime.datetime.fromtimestamp(exp).strftime('%Y-%m-%d')}"
            print(f"  {s['platform']:<10}: saved {saved} | cookies: {cookies} | {exp_str}")
    else:
        print("  (no saved sessions)")

    # Recommended actions for expired/errored sessions
    actions = [s for s in sessions if s.get("recommended_action")]
    if actions:
        print()
        print("=== Recommended Actions ===")
        for s in actions:
            print(f"  {s['recommended_action']}")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="anyweb",
        description="Browser automation for AI agents",
        epilog="""browser modes (two engines run simultaneously):
  headless  fast background browser, uses saved session cookies (default)
  headed    real Chrome window with your login cookies

Auto-routing: auth sites (x.com, zhihu, xiaohongshu, weixin, grok)
auto-use headed mode. Override with --headless or --headed per command.

IMPORTANT: a named page (--page) lives in one engine. All commands to the
same page auto-follow via page affinity. If you override the engine on
open, subsequent commands follow automatically. If you see about:blank or
duplicate page names in 'anyweb status', the page split across engines.

examples:
  anyweb read https://example.com              # headless (default)
  anyweb open https://x.com                    # headed (auth site)
  anyweb open --headless https://x.com/i/grok  # override: no login needed
  anyweb read --headed https://mysite.com       # override: need login""",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--session", "-s", default="default", help="Named session (default: default)")
    parser.add_argument("--json", dest="as_json", action="store_true", help="JSON output")
    parser.add_argument("--markdown", dest="as_markdown", action="store_true", help="Markdown output (for read)")
    parser.add_argument("--mcp", action="store_true", help="Run as MCP server (stdio transport)")

    sub = parser.add_subparsers(dest="command", help="Command to execute")

    def _add_engine_flags(p: argparse.ArgumentParser) -> None:
        p.add_argument("--headless", action="store_true", help="Force background browser (skip auth-site auto-routing)")
        p.add_argument("--headed", action="store_true", help="Force real Chrome with login cookies")

    # --- open ---
    p_open = sub.add_parser("open", help="Open URL in browser (auth sites auto-use real Chrome)")
    p_open.add_argument("url", help="URL to open")
    p_open.add_argument(
        "--platform", "-p", default="default", help="Platform for cookie isolation (x/zhihu/xhs/generic)"
    )
    p_open.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_open)

    # --- state ---
    p_state = sub.add_parser("state", help="List page elements for interaction (use --ax for accessibility tree)")
    p_state.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_state.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    p_state.add_argument("--ax", action="store_true", help="Show accessibility tree instead of DOM elements")
    p_state.add_argument(
        "--interactive-only", "-i", action="store_true", help="Only show clickable/typeable elements (reduces output)"
    )
    p_state.add_argument("--depth", type=int, default=0, help="AX mode: max tree depth (0=unlimited)")
    _add_engine_flags(p_state)

    # --- click ---
    p_click = sub.add_parser("click", help="Click element by AX ref (e5), index (3), or CSS selector")
    p_click.add_argument("target", help="AX ref (e5), element index (3), or CSS selector")
    p_click.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_click.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_click)

    # --- type ---
    p_type = sub.add_parser("type", help="Type text into the focused element")
    p_type.add_argument("text", help="Text to type")
    p_type.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_type.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_type)

    # --- input ---
    p_input = sub.add_parser("input", help="Click element then type (combines click + type)")
    p_input.add_argument("target", help="AX ref (e5), element index (3), or CSS selector")
    p_input.add_argument("text", help="Text to type")
    p_input.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_input.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_input)

    # --- keys ---
    p_keys = sub.add_parser("keys", help="Press key combo (e.g. Enter, Control+a, Escape)")
    p_keys.add_argument("combo", help="Key combo (e.g. Enter, Control+a)")
    p_keys.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_keys.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_keys)

    # --- scroll ---
    p_scroll = sub.add_parser("scroll", help="Scroll page up/down by pixels")
    p_scroll.add_argument("direction", choices=["up", "down"], default="down", nargs="?", help="Scroll direction")
    p_scroll.add_argument("--amount", type=int, default=500, help="Pixels to scroll")
    p_scroll.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_scroll.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_scroll)

    # --- eval ---
    p_eval = sub.add_parser("eval", help="Run JavaScript on page (supports async/Promises)")
    p_eval.add_argument("expression", help="JavaScript expression")
    p_eval.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_eval.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_eval)

    # --- screenshot ---
    p_ss = sub.add_parser("screenshot", help="Capture page screenshot as PNG")
    p_ss.add_argument("path", nargs="?", help="Output file path")
    p_ss.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_ss.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_ss)

    # --- wait ---
    p_wait = sub.add_parser("wait", help="Wait for element, text, or page to stabilize")
    p_wait.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_wait.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_wait)
    p_wait_sub = p_wait.add_subparsers(dest="mode", help="Wait mode")

    p_wait_sel = p_wait_sub.add_parser("selector", help="Wait for CSS selector")
    p_wait_sel.add_argument("value", help="CSS selector")
    p_wait_sel.add_argument("--timeout", type=int, default=30000)

    p_wait_txt = p_wait_sub.add_parser("text", help="Wait for text on page")
    p_wait_txt.add_argument("value", help="Text to wait for")
    p_wait_txt.add_argument("--timeout", type=int, default=30000)

    p_wait_stb = p_wait_sub.add_parser("stable", help="Wait for page to stabilize")
    p_wait_stb.add_argument("--timeout", type=int, default=60000)
    p_wait_stb.add_argument("--threshold", type=int, default=3)

    p_wait_cs = p_wait_sub.add_parser("content-stable", help="Wait for content to stop changing")
    p_wait_cs.add_argument("--timeout", type=int, default=60000)
    p_wait_cs.add_argument("--duration", type=float, default=3.0, help="Seconds content must be stable")

    # --- get ---
    p_get = sub.add_parser("get", help="Get page title/url/html/text or element value")
    p_get.add_argument("what", choices=["title", "url", "html", "text", "value"], help="What to get")
    p_get.add_argument("selector", nargs="?", help="Optional CSS selector")
    p_get.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_get.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_get)

    # --- hover ---
    p_hover = sub.add_parser("hover", help="Hover over element (trigger tooltips/menus)")
    p_hover.add_argument("target", help="AX ref (e5), element index (3), or CSS selector")
    p_hover.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_hover.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_hover)

    # --- back ---
    p_back = sub.add_parser("back", help="Go back to previous page")
    p_back.add_argument("--platform", "-p", help="Platform for cookie isolation (x/zhihu/xhs/generic)")
    p_back.add_argument("--page", default="default", help="Named tab for parallel use (e.g. --page grok1)")
    _add_engine_flags(p_back)

    # --- cookies ---
    p_cookies = sub.add_parser("cookies", help="Manage saved login cookies")
    p_cookies_sub = p_cookies.add_subparsers(dest="action", help="Cookie action")

    p_cookies_sub.add_parser("get", help="List cookies")

    p_cookies_exp = p_cookies_sub.add_parser("export", help="Export cookies to file")
    p_cookies_exp.add_argument("--platform", help="Platform name")

    p_cookies_imp = p_cookies_sub.add_parser("import", help="Import cookies from file")
    p_cookies_imp.add_argument("path", help="JSON file path")
    p_cookies_imp.add_argument("--platform", help="Platform name")

    p_cookies_sub.add_parser("clear", help="Clear all cookies")

    # --- close ---
    p_close = sub.add_parser("close", help="Close browsers and save cookies (daemon stays for next command)")
    p_close.add_argument("--page", default=None, help="Close specific named page only")

    # --- shutdown ---
    sub.add_parser("shutdown", help="Stop everything (browsers + daemon)")

    # =================================================================
    # Platform intelligence layer
    # =================================================================

    # --- read ---
    p_read = sub.add_parser("read", help="Extract content from URL (auto-detects platform, handles login/scrolling)")
    p_read.add_argument("url", help="URL to read")
    p_read.add_argument("--platform", "-p", help="Force platform (x/zhihu/xhs/generic)")
    p_read.add_argument("--limit", type=int, help="Max items to extract (e.g. tweets, answers)")
    p_read.add_argument("--comment-limit", type=int, help="Comment limit (xhs)")
    _add_engine_flags(p_read)

    # --- search ---
    p_search = sub.add_parser("search", help="Search on a platform (x/zhihu/xhs/wechat)")
    p_search.add_argument("platform", choices=["x", "zhihu", "xhs", "wechat"], help="Platform to search")
    p_search.add_argument("query", help="Search query")
    p_search.add_argument("--limit", type=int, default=10, help="Max results")
    _add_engine_flags(p_search)

    # --- login ---
    p_login = sub.add_parser("login", help="Open login page in real Chrome and save cookies")
    p_login.add_argument("platform", choices=["x", "zhihu", "xhs", "wechat"], help="Platform to login")
    p_login.add_argument("--method", default="auto", choices=["auto", "import", "browser", "cookie"])
    _add_engine_flags(p_login)

    # --- intercept ---
    p_intercept = sub.add_parser("intercept", help="Open URL and capture API responses matching pattern")
    p_intercept.add_argument("url", help="URL to open")
    p_intercept.add_argument(
        "--pattern", action="append", dest="patterns", help="URL pattern to intercept (can repeat)"
    )
    p_intercept.add_argument("--platform", "-p", help="Force platform")
    _add_engine_flags(p_intercept)

    # --- sessions ---
    sub.add_parser("sessions", help="List active browser sessions and pages")

    # --- status ---
    sub.add_parser("status", help="Show running browsers, open pages, and cookie status")

    # --- log ---
    p_log = sub.add_parser("log", help="Show command history with timing and engine info")
    p_log.add_argument("--all", dest="log_all", action="store_true", help="Show all log lines (not just commands)")
    p_log.add_argument("--follow", "-f", action="store_true", help="Follow log in real-time")
    p_log.add_argument("-n", type=int, default=20, help="Number of lines to show")
    p_log.add_argument("--engine", choices=["headless", "headed"], help="Filter by engine")
    p_log.add_argument("--errors", action="store_true", help="Show only errors and timeouts")

    # --- doctor ---
    p_doctor = sub.add_parser("doctor", help="Check dependencies and system health")
    p_doctor.add_argument("--fix", action="store_true", help="Auto-fix credential issues")

    # --- install ---
    sub.add_parser("install", help="Install Playwright browsers")

    args = parser.parse_args(argv)

    if args.mcp:
        from anyweb.mcp import main as mcp_main

        mcp_main()
        return

    if not args.command:
        parser.print_help()
        sys.exit(0)

    session = args.session
    as_json = args.as_json
    as_markdown = args.as_markdown

    # Handle commands that don't need the daemon
    cmd = args.command

    if cmd == "doctor":
        _doctor(fix=args.fix)
        return
    elif cmd == "install":
        _install()
        return
    elif cmd == "log":
        _log(follow=args.follow, show_all=args.log_all, n=args.n, engine=args.engine, errors_only=args.errors)
        return

    # Build command dict
    cmd_args: dict = {}

    # Resolve platform for interactive commands: explicit --platform > state file
    def _resolve_platform() -> str:
        explicit = getattr(args, "platform", None)
        return explicit if explicit else _get_platform(session)

    if cmd == "open":
        platform = args.platform if args.platform != "default" else "generic"
        cmd_args = {"url": args.url, "platform": platform, "page": args.page}
    elif cmd == "state":
        cmd_args = {"platform": _resolve_platform(), "page": args.page}
        if args.ax:
            cmd_args["ax"] = True
        if getattr(args, "interactive_only", False):
            cmd_args["interactive_only"] = True
        if getattr(args, "depth", 0):
            cmd_args["max_depth"] = args.depth
    elif cmd == "click":
        cmd_args = {"target": args.target, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "type":
        cmd_args = {"text": args.text, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "input":
        cmd_args = {"target": args.target, "text": args.text, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "keys":
        cmd_args = {"combo": args.combo, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "scroll":
        cmd_args = {
            "direction": args.direction or "down",
            "amount": args.amount,
            "platform": _resolve_platform(),
            "page": args.page,
        }
    elif cmd == "eval":
        cmd_args = {"expression": args.expression, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "screenshot":
        cmd_args = {"path": args.path, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "wait":
        if not args.mode:
            print("Error: specify wait mode: selector, text, or stable", file=sys.stderr)
            sys.exit(1)
        cmd_args = {"mode": args.mode, "timeout": args.timeout, "platform": _resolve_platform(), "page": args.page}
        if args.mode in ("selector", "text"):
            cmd_args["value"] = args.value
        elif args.mode == "stable":
            cmd_args["threshold"] = args.threshold
        elif args.mode == "content-stable":
            cmd_args["value"] = getattr(args, "duration", 3.0)
    elif cmd == "get":
        cmd_args = {"what": args.what, "platform": _resolve_platform(), "page": args.page}
        if args.selector:
            cmd_args["selector"] = args.selector
    elif cmd == "hover":
        cmd_args = {"target": args.target, "platform": _resolve_platform(), "page": args.page}
    elif cmd == "back":
        cmd_args = {"platform": _resolve_platform(), "page": args.page}
    elif cmd == "cookies":
        action = args.action or "get"
        cmd_args = {"action": action}
        if action == "import":
            cmd_args["path"] = args.path
        if hasattr(args, "platform") and args.platform:
            cmd_args["platform"] = args.platform
    elif cmd == "read":
        cmd_args = {"url": args.url}
        if args.platform:
            cmd_args["platform"] = args.platform
        if args.limit:
            cmd_args["limit"] = args.limit
        if args.comment_limit:
            cmd_args["comment_limit"] = args.comment_limit
    elif cmd == "search":
        cmd_args = {"platform": args.platform, "query": args.query, "limit": args.limit}
    elif cmd == "login":
        cmd_args = {"platform": args.platform, "method": args.method}
    elif cmd == "close":
        if getattr(args, "page", None):
            cmd_args = {"page": args.page}
    elif cmd == "intercept":
        cmd_args = {"url": args.url, "patterns": args.patterns or []}
        if args.platform:
            cmd_args["platform"] = args.platform

    engine_override = None
    if getattr(args, "headless", False):
        engine_override = "headless"
    elif getattr(args, "headed", False):
        engine_override = "headed"

    request = {"cmd": cmd, "args": cmd_args}
    if engine_override:
        request["engine_override"] = engine_override

    response = _run(session, request)

    # Save platform from response for next command
    data = response.get("data", {})
    if response.get("ok") and isinstance(data, dict) and "platform" in data:
        _set_platform(session, data["platform"])

    # Status command gets special formatting
    if cmd == "status" and response.get("ok") and not as_json:
        _format_status(response.get("data", {}))
        return

    _output(response, as_json=as_json, as_markdown=as_markdown)


if __name__ == "__main__":
    main()
