"""Daemon process — keeps the browser alive between CLI commands.

Architecture:
  CLI command → Unix socket → Daemon process → Playwright browser

The daemon auto-starts on first command and stays alive until `anyweb close`.
Each named session gets its own daemon + socket + browser instance.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import subprocess
import time
from pathlib import Path

from anyweb.core.accessibility import (
    click_by_ref,
    format_snapshot,
    get_ax_snapshot,
    is_ax_ref,
)
from anyweb.core.browser import BrowserManager
from anyweb.core.paths import (
    ANYWEB_DIR,
    CDP_ENDPOINT,
    CDP_PORT,
    CHROME_PROFILE_DIR,
    is_system_chrome_running,
    system_chrome_profile,
)
from anyweb.core.state import (
    click_by_index,
    extract_state,
    format_state,
    hover_by_index,
    is_index,
)

logger = logging.getLogger(__name__)


class CdpUnavailableError(RuntimeError):
    """Raised when CDP Chrome cannot be started or connected."""


# Domain → platform mapping for auto-detection
_DOMAIN_PLATFORM_MAP: dict[str, str] = {
    "zhihu.com": "zhihu",
    "xiaohongshu.com": "xhs",
    "xhslink.com": "xhs",
    "twitter.com": "x",
    "x.com": "x",
}


def detect_platform_from_url(url: str) -> str:
    """Auto-detect platform from URL domain. Returns 'generic' if unknown."""
    from urllib.parse import urlparse

    try:
        host = urlparse(url).netloc.lower()
        for domain, platform in _DOMAIN_PLATFORM_MAP.items():
            if host == domain or host.endswith(f".{domain}"):
                return platform
    except Exception:
        pass
    return "generic"


MAX_MSG_SIZE = 10 * 1024 * 1024  # 10 MB max message


async def type_keyboard_text(keyboard, text: str, delay: int = 50) -> None:
    """Type text while preserving newlines without triggering chat submit.

    Chat surfaces such as Grok submit on Enter. Playwright's ``keyboard.type``
    sends Enter for ``\n``, so multiline prompts can accidentally become many
    separate questions. Shift+Enter preserves the intended line breaks.
    """
    normalized = text.replace("\r\n", "\n").replace("\r", "\n")
    parts = normalized.split("\n")
    for index, part in enumerate(parts):
        if part:
            await keyboard.type(part, delay=delay)
        if index < len(parts) - 1:
            await keyboard.press("Shift+Enter")


def socket_path(session: str = "default") -> Path:
    return ANYWEB_DIR / f"{session}.sock"


def pid_path(session: str = "default") -> Path:
    return ANYWEB_DIR / f"{session}.pid"


def log_path() -> Path:
    return ANYWEB_DIR / "daemon.log"


def chrome_pid_path() -> Path:
    return ANYWEB_DIR / "chrome.pid"


def is_daemon_running(session: str = "default") -> bool:
    """Check if a daemon is running for the given session."""
    pf = pid_path(session)
    if not pf.exists():
        return False
    try:
        pid = int(pf.read_text().strip())
        os.kill(pid, 0)  # Check if process exists
        return True
    except (ValueError, OSError):
        # Stale PID file
        pf.unlink(missing_ok=True)
        socket_path(session).unlink(missing_ok=True)
        return False


def start_daemon(session: str = "default") -> None:
    """Fork a daemon process for the given session."""
    ANYWEB_DIR.mkdir(parents=True, exist_ok=True)

    pid = os.fork()
    if pid > 0:
        # Parent: wait briefly for daemon to start
        import time

        for _ in range(30):
            time.sleep(0.1)
            if socket_path(session).exists():
                return
        return

    # Child: become session leader
    os.setsid()

    # Double fork to fully detach
    pid2 = os.fork()
    if pid2 > 0:
        os._exit(0)

    # Grandchild: this is the daemon
    # Redirect stdio
    devnull = os.open(os.devnull, os.O_RDWR)
    os.dup2(devnull, 0)

    log_file = os.open(str(log_path()), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
    os.dup2(log_file, 1)
    os.dup2(log_file, 2)
    os.close(devnull)
    os.close(log_file)

    # Write PID file
    pid_path(session).write_text(str(os.getpid()))

    # Configure logging for daemon
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )

    # Run the daemon event loop
    try:
        asyncio.run(_daemon_main(session))
    finally:
        pid_path(session).unlink(missing_ok=True)
        socket_path(session).unlink(missing_ok=True)
        os._exit(0)


async def _daemon_main(session: str) -> None:
    """Main async loop for the daemon process."""
    sock = socket_path(session)
    sock.unlink(missing_ok=True)

    bm = BrowserManager()
    handler = CommandHandler(bm, session=session)

    server = await asyncio.start_unix_server(
        lambda r, w: _handle_connection(r, w, handler),
        path=str(sock),
    )
    # Make socket accessible
    sock.chmod(0o600)

    logger.info("Daemon started (session=%s, pid=%d)", session, os.getpid())

    # Start idle cleanup loop
    asyncio.create_task(bm.idle_cleanup_loop())

    # Handle SIGTERM for graceful shutdown
    shutdown_event = asyncio.Event()

    def _shutdown(signum: int, frame: object) -> None:
        logger.info("Received signal %d, shutting down", signum)
        shutdown_event.set()

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    try:
        await shutdown_event.wait()
    finally:
        server.close()
        await server.wait_closed()
        await bm.close()
        if handler._bm_cdp:
            await handler._bm_cdp.close()
        logger.info("Daemon stopped (session=%s)", session)


async def _handle_connection(
    reader: asyncio.StreamReader,
    writer: asyncio.StreamWriter,
    handler: CommandHandler,
) -> None:
    """Handle a single client connection."""
    try:
        # Read length-prefixed JSON message
        length_bytes = await reader.readexactly(4)
        length = int.from_bytes(length_bytes, "big")
        if length > MAX_MSG_SIZE:
            await _send_response(writer, {"ok": False, "error": "Message too large"})
            return

        data = await reader.readexactly(length)
        request = json.loads(data.decode("utf-8"))

        # Execute command
        response = await handler.execute(request)
        await _send_response(writer, response)

    except asyncio.IncompleteReadError:
        pass
    except Exception as exc:
        logger.exception("Error handling connection")
        try:
            await _send_response(writer, {"ok": False, "error": str(exc)})
        except Exception:
            pass
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


async def _send_response(writer: asyncio.StreamWriter, data: dict) -> None:
    """Send a length-prefixed JSON response."""
    payload = json.dumps(data, ensure_ascii=False, default=str).encode("utf-8")
    writer.write(len(payload).to_bytes(4, "big"))
    writer.write(payload)
    await writer.drain()


async def send_command(session: str, command: dict) -> dict:
    """Send a command to a running daemon and return the response."""
    sock = socket_path(session)
    reader, writer = await asyncio.open_unix_connection(path=str(sock))

    try:
        payload = json.dumps(command, ensure_ascii=False).encode("utf-8")
        writer.write(len(payload).to_bytes(4, "big"))
        writer.write(payload)
        await writer.drain()

        length_bytes = await reader.readexactly(4)
        length = int.from_bytes(length_bytes, "big")
        data = await reader.readexactly(length)
        return json.loads(data.decode("utf-8"))
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass


class CommandHandler:
    """Handles commands from CLI clients."""

    _TIMEOUT_OVERRIDES: dict[str, int] = {"login": 300, "eval": 300}

    def __init__(
        self,
        browser_manager: BrowserManager,
        session: str = "default",
    ) -> None:
        self._bm_headless = browser_manager
        self._bm_cdp: BrowserManager | None = None  # lazy-init on first --cdp use
        self.bm = browser_manager  # active BM, switched per command
        self._adapters: dict = {}  # keyed by (mode, platform)
        self._page_sem = asyncio.Semaphore(5)
        self._start_time = time.time()
        self._session_name = session

    @staticmethod
    def _create_adapter(platform: str, bm: BrowserManager):  # noqa: ANN205
        """Create a fresh adapter for the given platform and BrowserManager."""
        from anyweb.adapters.generic import GenericAdapter
        from anyweb.adapters.twitter import TwitterBrowserAdapter
        from anyweb.adapters.xhs import XHSAdapter
        from anyweb.adapters.zhihu import ZhihuAdapter

        adapter_map = {
            "x": TwitterBrowserAdapter,
            "zhihu": ZhihuAdapter,
            "xhs": XHSAdapter,
            "generic": GenericAdapter,
        }
        cls = adapter_map.get(platform, GenericAdapter)
        return cls(bm)

    def _get_adapter(self, platform: str):  # noqa: ANN202
        """Get or create a cached adapter for the given platform and active BM."""
        key = (id(self.bm), platform)
        if key in self._adapters:
            return self._adapters[key]
        adapter = self._create_adapter(platform, self.bm)
        self._adapters[key] = adapter
        return adapter

    async def _gated_call(
        self,
        coro_fn,  # noqa: ANN001
        total_timeout: int = 120,
        work_timeout: int = 60,
    ):  # noqa: ANN202
        """Run behind page semaphore with two-layer timeout.

        Args:
            coro_fn: Zero-arg async callable (NOT a coroutine object).
            total_timeout: Wall-clock timeout including queue wait.
            work_timeout: Timeout for actual work after semaphore acquired.
        """
        pages_before = set(self.bm._pages.keys())
        try:
            async with asyncio.timeout(total_timeout):
                async with self._page_sem:
                    async with asyncio.timeout(work_timeout):
                        return await coro_fn()
        except TimeoutError:
            # Clean up pages leaked by the timed-out coroutine
            leaked = set(self.bm._pages.keys()) - pages_before
            for key in leaked:
                page = self.bm._pages.pop(key, None)
                self.bm._page_last_access.pop(key, None)
                if page and not page.is_closed():
                    try:
                        await page.close()
                        logger.warning("[CLEANUP] Timeout-leaked page closed: %s", key)
                    except Exception:
                        pass
            raise

    @staticmethod
    def _summarize_args(cmd: str, args: dict) -> str:
        """Build a concise one-line summary of command arguments for logging."""
        parts: list[str] = []
        for key in ("page", "platform"):
            if key in args and args[key] not in ("default", "generic"):
                parts.append(f"{key}={args[key]}")
        if "url" in args:
            parts.append(f"url={args['url'][:80]}")
        if "target" in args:
            parts.append(f"target={args['target'][:40]}")
        if "text" in args:
            t = args["text"]
            parts.append(f"text={t[:60]!r}{'...' if len(t) > 60 else ''} ({len(t)} chars)")
        if "expression" in args:
            parts.append(f"expr=({len(args['expression'])} chars)")
        if "combo" in args:
            parts.append(f"combo={args['combo']}")
        if "mode" in args:
            parts.append(f"mode={args['mode']}")
        if "value" in args:
            val = args["value"]
            parts.append(f"value={str(val)[:60]}")
        if "what" in args:
            parts.append(f"what={args['what']}")
        if "action" in args:
            parts.append(f"action={args['action']}")
        if "timeout" in args:
            parts.append(f"timeout={args['timeout']}")
        if "direction" in args:
            parts.append(f"direction={args['direction']}")
        return " ".join(parts)

    @staticmethod
    def _result_hint(result: object) -> str:
        """Extract key fields from command result for the log line."""
        if not isinstance(result, dict):
            return ""
        for key in ("clicked", "typed", "keys", "waited", "url", "path"):
            if key in result:
                val = str(result[key])
                return f" {key}={val[:60]}"
        return ""

    @staticmethod
    async def _is_cdp_port_open(endpoint: str) -> bool:
        """Check if a CDP endpoint is responding."""
        import aiohttp

        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{endpoint}/json/version",
                    timeout=aiohttp.ClientTimeout(total=2),
                ) as resp:
                    return resp.status == 200
        except Exception:
            return False

    @staticmethod
    def _spawn_chrome(start_url: str | None = None, *, enable_cdp: bool = True) -> int | None:
        """Launch real Chrome with the shared anyweb profile."""
        from anyweb.core.chrome import find_chrome_executable

        chrome_path = find_chrome_executable()
        if not chrome_path:
            logger.error("[CHROME] Could not find Chrome/Chromium.")
            return None
        profile_dir = str(CHROME_PROFILE_DIR)
        os.makedirs(profile_dir, exist_ok=True)

        try:
            cmd = [
                chrome_path,
                f"--user-data-dir={profile_dir}",
                "--no-first-run",
            ]
            if enable_cdp:
                cmd.extend(
                    [
                        f"--remote-debugging-port={CDP_PORT}",
                        "--remote-allow-origins=*",
                        "--disable-blink-features=AutomationControlled",
                        "--disable-infobars",
                    ]
                )
            if start_url:
                cmd.append(start_url)
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            chrome_pid_path().write_text(str(proc.pid))
            logger.info("[CHROME] Spawned Chrome PID %d cdp=%s", proc.pid, enable_cdp)
            return proc.pid
        except Exception as exc:
            logger.error("[CHROME] Failed to spawn Chrome: %s", exc)
            return None

    @staticmethod
    def _spawn_chrome_with_cdp(start_url: str | None = None) -> int | None:
        """Launch Chrome with CDP debugging port. Returns PID or None."""
        return CommandHandler._spawn_chrome(start_url=start_url, enable_cdp=True)

    @staticmethod
    def _spawn_chrome_for_login(start_url: str) -> int | None:
        """Launch Chrome for manual login without CDP or Playwright."""
        return CommandHandler._spawn_chrome(start_url=start_url, enable_cdp=False)

    @staticmethod
    async def _wait_for_cdp_port(endpoint: str, timeout: int = 10) -> None:
        """Wait until CDP endpoint is ready."""
        import aiohttp

        for _ in range(timeout * 2):
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.get(
                        f"{endpoint}/json/version",
                        timeout=aiohttp.ClientTimeout(total=1),
                    ) as resp:
                        if resp.status == 200:
                            return
            except Exception:
                pass
            await asyncio.sleep(0.5)
        raise RuntimeError(f"Chrome CDP not ready after {timeout}s on {endpoint}")

    @staticmethod
    async def _wait_for_process_exit(pid: int, timeout: int = 300) -> bool:
        """Wait for a spawned Chrome process to exit."""
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                done_pid, _ = os.waitpid(pid, os.WNOHANG)
                if done_pid == pid:
                    return True
            except ChildProcessError:
                return True
            try:
                os.kill(pid, 0)
            except OSError:
                return True
            await asyncio.sleep(1)
        return False

    @staticmethod
    def _cookie_domains_for_platform(platform: str) -> tuple[str, ...]:
        if platform == "x":
            return ("x.com", "twitter.com")
        if platform == "zhihu":
            return ("zhihu.com",)
        if platform == "xhs":
            return ("xiaohongshu.com", "xhslink.com")
        if platform == "wechat":
            return ("mp.weixin.qq.com", "qq.com")
        return (platform,)

    @classmethod
    def _filter_cookies_for_platform(cls, platform: str, cookies: list[dict]) -> list[dict]:
        """Filter raw CDP cookies to the target platform domains."""
        domains = cls._cookie_domains_for_platform(platform)
        filtered = []
        for cookie in cookies:
            domain = str(cookie.get("domain", "")).lstrip(".").lower()
            if any(domain == d or domain.endswith(f".{d}") for d in domains):
                filtered.append(cookie)
        return filtered

    @staticmethod
    def _to_storage_state_cookie(cookie: dict) -> dict:
        """Convert a CDP cookie object to Playwright storage_state format."""
        converted = {
            "name": cookie.get("name", ""),
            "value": cookie.get("value", ""),
            "domain": cookie.get("domain", ""),
            "path": cookie.get("path", "/"),
            "expires": cookie.get("expires", -1),
            "httpOnly": bool(cookie.get("httpOnly", False)),
            "secure": bool(cookie.get("secure", False)),
        }
        same_site = cookie.get("sameSite")
        if same_site in {"Strict", "Lax", "None"}:
            converted["sameSite"] = same_site
        return converted

    @classmethod
    async def _extract_cookies_raw_cdp(cls, endpoint: str) -> list[dict]:
        """Extract Chrome cookies via raw CDP WebSocket without Playwright."""
        import aiohttp
        import websockets

        async with aiohttp.ClientSession() as session:
            async with session.get(
                f"{endpoint}/json",
                timeout=aiohttp.ClientTimeout(total=5),
            ) as resp:
                targets = await resp.json()

            ws_url = ""
            for target in targets:
                if target.get("type") == "page" and target.get("webSocketDebuggerUrl"):
                    ws_url = target["webSocketDebuggerUrl"]
                    break

            if not ws_url:
                async with session.get(
                    f"{endpoint}/json/version",
                    timeout=aiohttp.ClientTimeout(total=5),
                ) as resp:
                    info = await resp.json()
                    ws_url = info["webSocketDebuggerUrl"]

        async with websockets.connect(ws_url, max_size=MAX_MSG_SIZE) as ws:
            for msg_id, method in ((1, "Network.getAllCookies"), (2, "Storage.getCookies")):
                await ws.send(json.dumps({"id": msg_id, "method": method}))
                while True:
                    response = json.loads(await ws.recv())
                    if response.get("id") != msg_id:
                        continue
                    if "error" in response:
                        break
                    return response.get("result", {}).get("cookies", [])

        return []

    @staticmethod
    def _kill_chrome() -> None:
        """Kill the Chrome instance we spawned."""
        pf = chrome_pid_path()
        if not pf.exists():
            return
        try:
            pid = int(pf.read_text().strip())
            os.kill(pid, signal.SIGTERM)
            logger.info("[CHROME] Killed Chrome PID %d", pid)
        except (ValueError, OSError):
            pass
        pf.unlink(missing_ok=True)

    async def cmd_import_credentials(self, platform: str) -> dict:
        """Import credentials from the user's system Chrome profile.

        Dual-write: copies cookie files to anyweb chrome-profile (for CDP)
        AND extracts cookies to session.json (for headless Playwright).
        """
        sys_profile = system_chrome_profile()
        if sys_profile is None:
            return {
                "success": False,
                "platform": platform,
                "message": "System Chrome profile not found.",
                "session_file": "",
            }

        if is_system_chrome_running():
            return {
                "success": False,
                "platform": platform,
                "message": "Chrome is running. Close Chrome then retry.",
                "action_required": "close_chrome",
                "fix_command": "anyweb login " + platform,
                "session_file": "",
            }

        # Step 1: Copy cookie files to anyweb profile
        import shutil

        anyweb_default = CHROME_PROFILE_DIR / "Default"
        anyweb_default.mkdir(parents=True, exist_ok=True)

        for filename in ("Cookies", "Cookies-journal"):
            src = sys_profile / "Default" / filename
            if src.exists():
                shutil.copy2(str(src), str(anyweb_default / filename))
                logger.info("[IMPORT] Copied %s", filename)

        local_state = sys_profile / "Local State"
        if local_state.exists():
            shutil.copy2(str(local_state), str(CHROME_PROFILE_DIR / "Local State"))
            logger.info("[IMPORT] Copied Local State")

        # Step 2: Spawn CDP Chrome to extract cookies
        pid = self._spawn_chrome_with_cdp()
        if pid is None:
            return {
                "success": False,
                "platform": platform,
                "message": "Could not start Chrome for cookie extraction.",
                "session_file": "",
            }

        try:
            await self._wait_for_cdp_port(CDP_ENDPOINT)
            raw_cookies = await self._extract_cookies_raw_cdp(CDP_ENDPOINT)
            platform_cookies = self._filter_cookies_for_platform(platform, raw_cookies)

            if not self._has_auth_cookie(platform, platform_cookies):
                return {
                    "success": False,
                    "platform": platform,
                    "message": f"No auth cookie for {platform} found in Chrome profile.",
                    "session_file": "",
                }

            cookies = [self._to_storage_state_cookie(c) for c in platform_cookies]
            session_file = self._bm_headless.session_manager.save_cookies(platform, cookies)

            return {
                "success": True,
                "platform": platform,
                "message": f"Imported {len(cookies)} cookies from system Chrome.",
                "session_file": session_file,
            }
        finally:
            self._kill_chrome()

    async def _ensure_cdp_bm(self) -> BrowserManager:
        """Connect to an already-running Chrome CDP endpoint."""
        if self._bm_cdp:
            await self._bm_cdp.ensure_connected()
            return self._bm_cdp

        cdp_endpoint = CDP_ENDPOINT
        bm = BrowserManager()
        try:
            await bm.connect_via_cdp_direct(cdp_endpoint)
        except Exception:
            await bm.close()
            raise

        # Register disconnect callback to clear reference
        original_handler = bm._on_browser_disconnected

        def _on_cdp_disconnect():
            original_handler()
            logger.info("[LIFECYCLE] CDP browser disconnected, clearing _bm_cdp")
            self._bm_cdp = None

        if bm._browser:
            bm._browser.on("disconnected", lambda: _on_cdp_disconnect())

        self._bm_cdp = bm
        asyncio.create_task(bm.idle_cleanup_loop())
        return bm

    _NON_BROWSER_CMDS = frozenset(
        {
            "status",
            "sessions",
            "login",
            "close",
            "shutdown",
            "import_credentials",
            "cookies",
        }
    )

    _AUTH_DOMAINS = (
        "x.com",
        "twitter.com",
        "zhihu.com",
        "xiaohongshu.com",
        "xhslink.com",
        "mp.weixin.qq.com",
        "grok.com",
    )

    def _route_engine(self, cmd: str, args: dict) -> tuple[str, str]:
        """Decide which engine (headless or headed) to use for a command."""
        if cmd in self._NON_BROWSER_CMDS:
            return ("headless", "default")

        url = args.get("url", "")
        page = args.get("page", "default")

        if page != "default":
            if self._bm_cdp:
                for key in self._bm_cdp._pages:
                    if key.endswith(f":{page}"):
                        return ("headed", "page_affinity")
            for key in self._bm_headless._pages:
                if key.endswith(f":{page}"):
                    return ("headless", "page_affinity")

        if "grok" in url.lower() or "grok" in page.lower():
            return ("headed", "grok_requires_headed")

        if any(d in url for d in self._AUTH_DOMAINS):
            return ("headed", "auth_domain")

        return ("headless", "default")

    async def _ensure_cdp_chrome(self) -> BrowserManager:
        """Ensure CDP Chrome is running and connected. Start Chrome if needed."""
        if await self._is_cdp_port_open(CDP_ENDPOINT):
            return await self._ensure_cdp_bm()

        pid = self._spawn_chrome_with_cdp()
        if pid is None:
            raise CdpUnavailableError("Could not start Chrome")

        await self._wait_for_cdp_port(CDP_ENDPOINT)
        return await self._ensure_cdp_bm()

    @staticmethod
    def _is_antibot_error(exc: Exception) -> bool:
        """Detect if an error is likely caused by anti-bot detection."""
        msg = str(exc).lower()
        indicators = (
            "cloudflare",
            "challenge",
            "access denied",
            "403",
            "captcha",
            "verify you are human",
            "ray id",
        )
        return any(ind in msg for ind in indicators)

    async def execute(self, request: dict) -> dict:
        """Dispatch a command and return the result."""
        cmd = request.get("cmd", "")
        args = request.get("args", {})
        engine_override = request.get("engine_override")

        if engine_override == "headless":
            engine, reason = "headless", "user_override"
        elif engine_override == "headed":
            engine, reason = "headed", "user_override"
        else:
            engine, reason = self._route_engine(cmd, args)

        if engine == "headed":
            try:
                self.bm = await self._ensure_cdp_chrome()
            except (CdpUnavailableError, Exception) as exc:
                logger.warning("[ROUTE] CDP unavailable (%s), falling back to headless", exc)
                self.bm = self._bm_headless
                engine = "headless"
                reason = "cdp_unavailable_fallback"
        else:
            self.bm = self._bm_headless

        method = getattr(self, f"cmd_{cmd}", None)
        if method is None:
            return {"ok": False, "error": f"Unknown command: {cmd}"}

        engine_tag = f"[{engine}:{reason}]"
        summary = self._summarize_args(cmd, args)
        timeout = self._TIMEOUT_OVERRIDES.get(cmd, 120)
        t0 = asyncio.get_event_loop().time()
        try:
            async with asyncio.timeout(timeout):
                result = await method(**args)
            elapsed = asyncio.get_event_loop().time() - t0
            hint = self._result_hint(result)
            logger.info("[CMD] %s %s → OK %.1fs %s%s", cmd, summary, elapsed, engine_tag, hint)
            return {"ok": True, "data": result, "engine": engine, "reason": reason}
        except TimeoutError:
            elapsed = asyncio.get_event_loop().time() - t0
            logger.error("[CMD] %s %s → TIMEOUT %.1fs %s", cmd, summary, elapsed, engine_tag)
            return {
                "ok": False,
                "error": f"Command '{cmd}' timed out after {timeout}s",
                "engine": engine,
                "reason": reason,
            }
        except Exception as exc:
            elapsed = asyncio.get_event_loop().time() - t0
            logger.error("[CMD] %s %s → ERROR %.1fs %s %s", cmd, summary, elapsed, engine_tag, exc)

            if engine == "headless" and reason != "user_override" and self._is_antibot_error(exc):
                logger.info("[RETRY] Upgrading to headed after anti-bot error: %s", cmd)
                try:
                    self.bm = await self._ensure_cdp_chrome()
                    async with asyncio.timeout(timeout):
                        result = await method(**args)
                    elapsed2 = asyncio.get_event_loop().time() - t0
                    hint = self._result_hint(result)
                    retry_tag = "[headed:retry_after_headless_fail]"
                    logger.info("[CMD] %s %s → OK %.1fs %s%s", cmd, summary, elapsed2, retry_tag, hint)
                    return {"ok": True, "data": result, "engine": "headed", "reason": "retry_after_headless_fail"}
                except Exception as retry_exc:
                    logger.error("[RETRY] headed retry also failed: %s", retry_exc)

            return {"ok": False, "error": str(exc), "engine": engine, "reason": reason}

    async def cmd_open(self, url: str, platform: str = "generic", page: str = "default") -> dict:
        """Navigate to a URL."""
        if platform == "generic":
            detected = detect_platform_from_url(url)
            if detected != "generic":
                platform = detected
        pg = await self.bm.get_named_page(platform, page)
        await pg.goto(url, wait_until="domcontentloaded", timeout=30000)
        return {"url": pg.url, "title": await pg.title(), "platform": platform, "page": page}

    async def cmd_state(
        self,
        platform: str = "generic",
        page: str = "default",
        ax: bool = False,
        interactive_only: bool = False,
        max_depth: int = 0,
    ) -> dict:
        """Return page state with indexed interactive elements.

        Args:
            ax: Use accessibility tree instead of DOM-based extraction.
            interactive_only: AX mode only — show interactive elements only.
            max_depth: AX mode only — limit tree depth (0 = unlimited).
        """
        pg = await self.bm.get_named_page(platform, page)
        if ax:
            snapshot = await get_ax_snapshot(
                pg,
                interactive_only=interactive_only,
                max_depth=max_depth,
            )
            text = format_snapshot(snapshot, max_depth=max_depth)
            # Cache refs on the daemon for click_by_ref
            self._ax_ref_cache = snapshot.ref_cache
            return {"text": text, "count": len(snapshot.ref_cache)}
        elements = await extract_state(pg)
        text = format_state(pg.url, await pg.title(), elements)
        return {"text": text, "count": len(elements)}

    async def cmd_click(self, target: str, platform: str = "generic", page: str = "default") -> dict:
        """Click an element by index, AX ref (e.g. 'e5'), or CSS selector."""
        pg = await self.bm.get_named_page(platform, page)
        if is_ax_ref(target):
            ref_cache = getattr(self, "_ax_ref_cache", {})
            info = await click_by_ref(pg, target, ref_cache)
            return {"clicked": f"ref {target}", **info}
        elif is_index(target):
            info = await click_by_index(pg, int(target))
            return {"clicked": f"index {target}", **info}
        else:
            await pg.click(target)
            return {"clicked": target}

    async def cmd_type(self, text: str, platform: str = "generic", page: str = "default") -> dict:
        """Type text using keyboard events (works with React controlled components)."""
        pg = await self.bm.get_named_page(platform, page)
        await type_keyboard_text(pg.keyboard, text, delay=50)
        return {"typed": len(text)}

    async def cmd_input(self, target: str, text: str, platform: str = "generic", page: str = "default") -> dict:
        """Click an element then type text into it."""
        await self.cmd_click(target=target, platform=platform, page=page)
        await asyncio.sleep(0.1)
        await self.cmd_type(text=text, platform=platform, page=page)
        return {"target": target, "typed": len(text)}

    async def cmd_keys(self, combo: str, platform: str = "generic", page: str = "default") -> dict:
        """Send keyboard events (e.g. 'Enter', 'Control+a')."""
        pg = await self.bm.get_named_page(platform, page)
        if "+" in combo:
            await pg.keyboard.press(combo)
        else:
            await pg.keyboard.press(combo)
        return {"keys": combo}

    async def cmd_scroll(
        self,
        direction: str = "down",
        amount: int = 500,
        platform: str = "generic",
        page: str = "default",
    ) -> dict:
        """Scroll the page."""
        pg = await self.bm.get_named_page(platform, page)
        from anyweb.core.human_behavior import human_scroll

        await human_scroll(pg, direction=direction, amount=amount)
        return {"direction": direction, "amount": amount}

    async def cmd_eval(self, expression: str, platform: str = "generic", page: str = "default") -> dict:
        """Execute JavaScript and return the result (supports Promises)."""
        pg = await self.bm.get_named_page(platform, page)
        result = await pg.evaluate(expression)
        return {"result": result}

    async def cmd_screenshot(self, path: str | None = None, platform: str = "generic", page: str = "default") -> dict:
        """Take a screenshot of the page."""
        pg = await self.bm.get_named_page(platform, page)
        if path is None:
            path = str(ANYWEB_DIR / "screenshot.png")
        await pg.screenshot(path=path, full_page=False)
        return {"path": path}

    async def cmd_wait(
        self,
        mode: str = "selector",
        value: str = "",
        timeout: int = 30000,
        threshold: int = 3,
        platform: str = "generic",
        page: str = "default",
    ) -> dict:
        """Wait for a condition.

        Modes:
          - selector: wait for CSS selector to appear
          - text: wait for text to appear on page
          - stable: wait for page text to stop changing (observer pattern)
        """
        pg = await self.bm.get_named_page(platform, page)

        if mode == "selector":
            await pg.wait_for_selector(value, timeout=timeout)
            return {"waited": f"selector '{value}'"}

        elif mode == "text":
            await pg.wait_for_function(
                f"document.body.innerText.includes({json.dumps(value)})",
                timeout=timeout,
            )
            return {"waited": f"text '{value}'"}

        elif mode == "stable":
            # Observer pattern: wait until page text length stabilizes
            check_interval = 3.0  # seconds between checks
            stable_count = 0
            last_len = 0
            growth_seen = False
            elapsed = 0.0
            timeout_s = timeout / 1000.0

            # Initial wait for content to start loading
            await asyncio.sleep(min(5.0, timeout_s / 4))
            elapsed += min(5.0, timeout_s / 4)

            while elapsed < timeout_s:
                text_len = await pg.evaluate("document.body.innerText.length")

                if text_len > last_len + 50:
                    growth_seen = True
                    stable_count = 0
                elif abs(text_len - last_len) < 10:
                    stable_count += 1
                else:
                    stable_count = 0

                last_len = text_len

                if growth_seen and stable_count >= threshold:
                    return {
                        "waited": "stable",
                        "text_length": text_len,
                        "elapsed_s": round(elapsed, 1),
                    }

                await asyncio.sleep(check_interval)
                elapsed += check_interval

            return {
                "waited": "stable (timeout)",
                "text_length": last_len,
                "elapsed_s": round(elapsed, 1),
            }

        elif mode == "content-stable":
            import hashlib

            try:
                stable_duration = float(value) if value else 3.0
            except (ValueError, TypeError):
                stable_duration = 3.0
            last_hash = ""
            stable_since: float | None = None
            elapsed = 0.0
            timeout_s = timeout / 1000.0
            text = ""

            while elapsed < timeout_s:
                text = await pg.evaluate("document.body.innerText")
                h = hashlib.md5(text.encode()).hexdigest()

                if h == last_hash:
                    if stable_since is None:
                        stable_since = elapsed
                    elif elapsed - stable_since >= stable_duration:
                        return {
                            "waited": "content-stable",
                            "stable_for": round(elapsed - stable_since, 1),
                            "text_length": len(text),
                            "elapsed_s": round(elapsed, 1),
                        }
                else:
                    stable_since = None
                    last_hash = h

                await asyncio.sleep(1.0)
                elapsed += 1.0

            return {
                "waited": "content-stable (timeout)",
                "text_length": len(text),
                "elapsed_s": round(elapsed, 1),
            }

        else:
            return {"ok": False, "error": f"Unknown wait mode: {mode}"}

    async def cmd_get(
        self,
        what: str,
        selector: str | None = None,
        platform: str = "generic",
        page: str = "default",
    ) -> dict:
        """Get information from the page.

        Modes: title, url, html, text, value, attributes, bbox
        """
        pg = await self.bm.get_named_page(platform, page)

        if what == "title":
            return {"result": await pg.title()}
        elif what == "url":
            return {"result": pg.url}
        elif what == "text":
            if selector:
                el = await pg.query_selector(selector)
                if el:
                    return {"result": await el.inner_text()}
                return {"result": None, "error": f"Selector not found: {selector}"}
            return {"result": await pg.evaluate("document.body.innerText")}
        elif what == "html":
            if selector:
                el = await pg.query_selector(selector)
                if el:
                    return {"result": await el.inner_html()}
                return {"result": None, "error": f"Selector not found: {selector}"}
            return {"result": await pg.content()}
        elif what == "value":
            if not selector:
                return {"result": None, "error": "Selector required for 'value'"}
            result = await pg.evaluate(f"document.querySelector({json.dumps(selector)})?.value")
            return {"result": result}
        else:
            return {"result": None, "error": f"Unknown get mode: {what}"}

    async def cmd_hover(self, target: str, platform: str = "generic", page: str = "default") -> dict:
        """Hover over an element."""
        pg = await self.bm.get_named_page(platform, page)
        if is_index(target):
            await hover_by_index(pg, int(target))
            return {"hovered": f"index {target}"}
        else:
            await pg.hover(target)
            return {"hovered": target}

    async def cmd_back(self, platform: str = "generic", page: str = "default") -> dict:
        """Navigate back."""
        pg = await self.bm.get_named_page(platform, page)
        await pg.go_back()
        return {"url": pg.url}

    async def cmd_cookies(
        self,
        action: str = "get",
        path: str | None = None,
        platform: str | None = None,
    ) -> dict:
        """Cookie management: get, import, export, clear."""
        p = platform or "generic"
        context = await self.bm.get_context(p)

        if action == "get":
            cookies = await context.cookies()
            return {"cookies": cookies, "count": len(cookies)}

        elif action == "export":
            export_path = await self.bm.save_session(p)
            return {"exported": export_path}

        elif action == "import":
            if not path:
                return {"error": "Path required for import"}
            import json as _json

            data = _json.loads(Path(path).read_text())
            cookies = data.get("cookies", data) if isinstance(data, dict) else data
            await context.add_cookies(cookies)
            return {"imported": len(cookies)}

        elif action == "clear":
            await context.clear_cookies()
            return {"cleared": True}

        return {"error": f"Unknown cookie action: {action}"}

    async def cmd_close(self, page: str | None = None) -> dict:
        """Close browser resources. Daemon stays alive.

        If *page* is given, close only that named page. Otherwise close all.
        """
        if page is not None:
            closed = False
            for bm in (self._bm_headless, self._bm_cdp):
                if bm is None:
                    continue
                matched_key = None
                for key in list(bm._pages):
                    if key.endswith(f":{page}") or key == page:
                        matched_key = key
                        break
                if matched_key:
                    p = bm._pages.pop(matched_key)
                    bm._page_last_access.pop(matched_key, None)
                    if not p.is_closed():
                        await p.close()
                    closed = True
                    break
            if not closed:
                return {"closed": False, "error": f"Page '{page}' not found"}
            return {"closed": True, "page": page}

        saved = await self._save_all_sessions()
        await self._bm_headless.close()
        if self._bm_cdp:
            await self._bm_cdp.close()
            self._bm_cdp = None
        self._kill_chrome()
        self._bm_headless = BrowserManager()
        self.bm = self._bm_headless
        self._adapters.clear()
        return {"closed": True, "sessions_saved": saved}

    async def cmd_shutdown(self) -> dict:
        """Close all browsers and stop the daemon."""
        await self.cmd_close()
        pid_path(self._session_name).unlink(missing_ok=True)
        socket_path(self._session_name).unlink(missing_ok=True)
        os.kill(os.getpid(), signal.SIGTERM)
        return {"shutdown": True}

    async def _save_all_sessions(self) -> list[str]:
        """Save sessions for all active contexts across all BMs."""
        saved: list[str] = []
        for label, bm in [("headless", self._bm_headless), ("cdp", self._bm_cdp)]:
            if bm is None:
                continue
            for platform in list(bm._contexts):
                try:
                    await bm.save_session(platform)
                    saved.append(f"{label}:{platform}")
                except Exception as exc:
                    logger.warning("Failed to save session %s/%s: %s", label, platform, exc)
        return saved

    async def cmd_sessions(self) -> dict:
        """List active contexts and resource health."""
        contexts = list(self.bm._contexts.keys())
        pages = list(self.bm._pages.keys())
        browsers = []
        for label, bm in [("headless", self._bm_headless), ("cdp", self._bm_cdp)]:
            if bm and bm.is_running:
                browsers.append({"mode": label, "pages": len(bm._pages), "contexts": len(bm._contexts)})
        return {"sessions": contexts, "pages": pages, "browsers": browsers}

    async def cmd_status(self) -> dict:
        """Full system status: daemon, browsers, pages, processes, sessions."""
        now = time.time()

        def _get_rss(pid: int) -> int | None:
            """Get RSS in MB for a PID."""
            try:
                out = subprocess.check_output(["ps", "-o", "rss=", "-p", str(pid)], text=True)
                return int(out.strip()) // 1024
            except Exception:
                return None

        # Daemon info
        daemon_pid = os.getpid()
        daemon_info = {
            "pid": daemon_pid,
            "rss_mb": _get_rss(daemon_pid),
            "uptime_s": int(now - self._start_time),
        }

        # Browsers
        browsers = []
        for label, bm in [("headless", self._bm_headless), ("cdp", self._bm_cdp)]:
            if bm is None:
                continue
            entry: dict = {
                "mode": label,
                "running": bm.is_running,
                "pages": len(bm._pages),
                "contexts": len(bm._contexts),
            }
            if bm.is_running and bm._browser:
                try:
                    bp = bm._browser.process  # type: ignore[union-attr]
                    if bp:
                        entry["browser_pid"] = bp.pid
                        entry["browser_rss_mb"] = _get_rss(bp.pid)
                except Exception:
                    pass
            browsers.append(entry)

        # Chrome PID (if we spawned it)
        chrome_info = None
        pf = chrome_pid_path()
        if pf.exists():
            try:
                cpid = int(pf.read_text().strip())
                os.kill(cpid, 0)  # alive check
                chrome_info = {"pid": cpid, "rss_mb": _get_rss(cpid)}
            except (ValueError, OSError):
                chrome_info = {"pid": None, "status": "dead"}

        # Pages
        pages = []
        for label, bm in [("headless", self._bm_headless), ("cdp", self._bm_cdp)]:
            if bm is None:
                continue
            for key, page in bm._pages.items():
                idle_s = now - bm._page_last_access.get(key, now)
                try:
                    url = page.url if not page.is_closed() else "(closed)"
                except Exception:
                    url = "(error)"
                pages.append(
                    {
                        "key": key,
                        "mode": label,
                        "url": url,
                        "closed": page.is_closed(),
                        "idle_s": int(idle_s),
                    }
                )

        # Orphan process detection
        orphans = []
        try:
            out = subprocess.check_output(["pgrep", "-f", "playwright/driver/node"], text=True)
            known_pids = set()
            for bm in [self._bm_headless, self._bm_cdp]:
                if bm and bm._playwright:
                    try:
                        proc = bm._playwright._connection._transport._proc  # type: ignore[attr-defined]
                        if proc:
                            known_pids.add(proc.pid)
                    except Exception:
                        pass
            for line in out.strip().splitlines():
                pid = int(line.strip())
                if pid not in known_pids:
                    orphans.append({"pid": pid, "rss_mb": _get_rss(pid)})
        except Exception:
            pass

        # Sessions
        sessions = []
        session_dir = ANYWEB_DIR / "sessions"
        if session_dir.exists():
            for sf in sorted(session_dir.glob("*_session.json")):
                platform = sf.stem.replace("_session", "")
                try:
                    data = json.loads(sf.read_text())
                    cookies = data.get("cookies", [])

                    auth_name = {
                        "x": "auth_token",
                        "zhihu": "z_c0",
                        "xhs": "customer-sso-sid",
                        "wechat": "slave_sid",
                    }.get(platform)

                    auth_expiry = None
                    has_auth = False
                    for c in cookies:
                        if auth_name and c.get("name") == auth_name:
                            has_auth = True
                            exp = c.get("expires", -1)
                            if exp > 0:
                                auth_expiry = exp

                    entry = {
                        "platform": platform,
                        "saved": sf.stat().st_mtime,
                        "cookie_count": len(cookies),
                        "auth_expiry": auth_expiry,
                        "has_auth": has_auth,
                        "expired": has_auth and auth_expiry is not None and auth_expiry < now,
                    }
                    if not has_auth:
                        entry["expired"] = True
                        entry["recommended_action"] = f"anyweb login {platform}"
                    elif entry["expired"]:
                        entry["recommended_action"] = f"anyweb login {platform}"
                    sessions.append(entry)
                except Exception:
                    sessions.append({"platform": platform, "error": "parse failed"})

        return {
            "daemon": daemon_info,
            "browsers": browsers,
            "chrome": chrome_info,
            "pages": pages,
            "orphans": orphans,
            "sessions": sessions,
        }

    # ------------------------------------------------------------------
    # Platform intelligence layer (Phase 2)
    # ------------------------------------------------------------------

    async def cmd_read(self, url: str, platform: str | None = None, **kwargs) -> dict:
        """Smart read: auto-detect platform, apply anti-detect, return structured content."""
        p = platform or detect_platform_from_url(url)
        adapter = self._get_adapter(p)
        result = await self._gated_call(lambda: adapter.read(url, **kwargs))
        return {**result.to_dict(), "platform": p}

    async def cmd_search(self, platform: str, query: str, limit: int = 10) -> dict:
        """Search within a platform."""
        adapter = self._get_adapter(platform)
        results = await self._gated_call(lambda: adapter.search(query, limit=limit))
        return {"results": [r.to_dict() for r in results], "count": len(results), "platform": platform}

    @staticmethod
    def _has_auth_cookie(platform: str, cookies: list[dict]) -> bool:
        """Check if cookies contain a valid auth token for the platform."""
        cookie_names = {c.get("name", "") for c in cookies}
        if platform == "x":
            return "auth_token" in cookie_names
        if platform == "zhihu":
            return "z_c0" in cookie_names
        if platform == "xhs":
            return "customer-sso-sid" in cookie_names or "xsecappid" in cookie_names
        if platform == "wechat":
            return "slave_sid" in cookie_names
        return len(cookies) > 5

    _LOGIN_URLS: dict[str, str] = {
        "x": "https://x.com/login",
        "zhihu": "https://www.zhihu.com/signin",
        "xhs": "https://www.xiaohongshu.com",
        "wechat": "https://mp.weixin.qq.com/",
    }

    async def cmd_login(self, platform: str, method: str = "auto") -> dict:
        """Login to a platform and save session.

        Methods:
        - "auto": check existing session -> try import -> fall back to browser
        - "import": import from system Chrome only
        - "browser": legacy manual login (spawn Chrome, user logs in, extract cookies)
        - "cookie": adapter-specific cookie import
        """
        from anyweb.adapters.base import LoginMethod

        m = LoginMethod(method)

        # --- auto: try fast paths first ---
        if m == LoginMethod.AUTO:
            if self._is_session_valid(platform):
                return {
                    "success": True,
                    "platform": platform,
                    "method": method,
                    "message": f"Already logged in to {platform}.",
                    "session_file": str(self._bm_headless.session_manager._session_path(platform)),
                }
            import_result = await self.cmd_import_credentials(platform)
            if import_result["success"]:
                return {**import_result, "method": method}
            if import_result.get("action_required") == "close_chrome":
                return {**import_result, "method": method}
            return await self.cmd_login(platform, method="browser")

        # --- import: system Chrome only ---
        if m == LoginMethod.IMPORT:
            result = await self.cmd_import_credentials(platform)
            return {**result, "method": method}

        # --- cookie / api_key: delegate to adapter ---
        if m not in (LoginMethod.BROWSER,):
            adapter = self._get_adapter(platform)
            status = await adapter.login(m)
            return {**status.to_dict(), "platform": platform}

        # --- browser: legacy manual login ---
        login_url = self._LOGIN_URLS.get(platform, f"https://{platform}.com")
        cdp_endpoint = CDP_ENDPOINT

        if await self._is_cdp_port_open(cdp_endpoint):
            return {
                "success": False,
                "platform": platform,
                "method": method,
                "message": f"Chrome CDP is already running at {cdp_endpoint}. Close it before login.",
                "session_file": "",
            }

        login_pid = self._spawn_chrome_for_login(start_url=login_url)
        if login_pid is None:
            return {
                "success": False,
                "platform": platform,
                "method": method,
                "message": "Could not find Chrome.",
            }

        logger.info(
            "Please login to %s in the Chrome window, then close that Chrome window.",
            platform,
        )

        if not await self._wait_for_process_exit(login_pid, timeout=300):
            self._kill_chrome()
            return {
                "success": False,
                "platform": platform,
                "method": method,
                "message": "Login timed out. Log in, then close the Chrome window.",
                "session_file": "",
            }

        extract_pid = self._spawn_chrome_with_cdp(start_url=login_url)
        if extract_pid is None:
            return {
                "success": False,
                "platform": platform,
                "method": method,
                "message": "Could not restart Chrome for cookie extraction.",
                "session_file": "",
            }

        try:
            await self._wait_for_cdp_port(cdp_endpoint)
            raw_cookies = await self._extract_cookies_raw_cdp(cdp_endpoint)
            platform_cookies = self._filter_cookies_for_platform(platform, raw_cookies)

            if not self._has_auth_cookie(platform, platform_cookies):
                return {
                    "success": False,
                    "platform": platform,
                    "method": method,
                    "message": "Login cookie not found after Chrome closed.",
                    "session_file": "",
                }

            cookies = [self._to_storage_state_cookie(c) for c in platform_cookies]
            session_file = self._bm_headless.session_manager.save_cookies(platform, cookies)
            return {
                "success": True,
                "platform": platform,
                "method": method,
                "message": "Login successful.",
                "session_file": session_file,
            }
        finally:
            self._kill_chrome()

    def _is_session_valid(self, platform: str) -> bool:
        """Check if a platform session exists and has a non-expired auth cookie."""
        import time as _time

        state = self._bm_headless.session_manager.load_session_state(platform)
        if state is None:
            return False
        cookies = state.get("cookies", [])
        if not self._has_auth_cookie(platform, cookies):
            return False
        now = _time.time()
        for c in cookies:
            if c.get("name") in ("auth_token", "z_c0", "customer-sso-sid", "xsecappid", "slave_sid"):
                exp = c.get("expires", -1)
                if exp > 0 and exp < now:
                    return False
        return True

    async def cmd_intercept(
        self,
        url: str,
        patterns: list[str] | None = None,
        platform: str | None = None,
    ) -> dict:
        """Navigate to URL with network interception enabled."""
        from typing import Any

        p = platform or detect_platform_from_url(url)
        intercept_patterns = patterns or []

        async def _do_intercept() -> dict:
            page = await self.bm.new_page(p)
            try:
                intercepted: list[dict[str, Any]] = []

                async def _on_response(response) -> None:  # noqa: ANN001
                    resp_url = response.url
                    if not any(pat in resp_url for pat in intercept_patterns):
                        return
                    content_type = response.headers.get("content-type", "")
                    if not any(t in content_type for t in ("json", "text", "javascript", "xml")):
                        return
                    entry: dict[str, Any] = {
                        "url": resp_url,
                        "status": response.status,
                        "content_type": content_type,
                    }
                    try:
                        entry["body"] = await response.json()
                    except Exception:
                        try:
                            text = await response.text()
                            if len(text) > 20000:
                                text = text[:20000] + "\n... (truncated)"
                            entry["body_text"] = text
                        except Exception as exc:
                            entry["error"] = f"Could not read body: {exc}"
                    intercepted.append(entry)

                if intercept_patterns:
                    page.on("response", _on_response)

                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
                await asyncio.sleep(3)

                return {
                    "url": page.url,
                    "title": await page.title(),
                    "intercepted_count": len(intercepted),
                    "intercepted": intercepted,
                    "platform": p,
                }
            finally:
                await page.close()

        return await self._gated_call(_do_intercept)
