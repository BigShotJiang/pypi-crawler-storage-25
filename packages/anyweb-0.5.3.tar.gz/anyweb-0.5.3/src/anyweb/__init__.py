"""anyweb — CLI-first browser automation with platform intelligence."""

__version__ = "0.5.3"
