"""MCP compatibility layer — exposes anyweb as an MCP server.

Usage:
    anyweb --mcp          (stdio transport)
    python -m anyweb.mcp  (same)

This is a thin wrapper that translates MCP tool calls into daemon commands.
The daemon handles all browser automation; this layer just bridges protocols.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from mcp.server.fastmcp import FastMCP

from anyweb.daemon import is_daemon_running, send_command, start_daemon

logger = logging.getLogger(__name__)

mcp = FastMCP("anyweb")


def _ensure_daemon(session: str = "default") -> None:
    """Start the daemon if not already running."""
    if not is_daemon_running(session):
        start_daemon(session)


async def _cmd(cmd: str, **kwargs: Any) -> dict:
    """Send a command to the daemon."""
    _ensure_daemon()
    return await send_command("default", {"cmd": cmd, "args": kwargs})


def _unwrap(response: dict) -> str:
    """Convert daemon response to MCP tool result string."""
    if not response.get("ok", False):
        return json.dumps({"error": response.get("error", "Unknown error")}, ensure_ascii=False, indent=2)
    return json.dumps(response.get("data", {}), ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# MCP Tools — mirror ucal's 5 tools for drop-in compatibility
# ---------------------------------------------------------------------------


@mcp.tool(
    name="anyweb_platform_read",
    annotations={
        "title": "Read Platform Content",
        "readOnlyHint": True,
        "openWorldHint": True,
    },
)
async def anyweb_platform_read(
    url: str,
    platform: str = "generic",
    comment_limit: int | None = None,
    expand_replies: int = 1,
) -> str:
    """Read content from a URL with platform-specific intelligence.

    Auto-detects the platform from the URL domain if not specified.
    Supported platforms: x, zhihu, xhs, generic.

    Args:
        url: The URL to read.
        platform: Platform identifier (auto-detected if 'generic').
        comment_limit: Max comments to extract.
        expand_replies: Times to expand reply threads (0-3).

    Returns:
        JSON with title, content, author, url, platform.
    """
    kwargs: dict[str, Any] = {"url": url, "platform": platform}
    if comment_limit is not None:
        kwargs["comment_limit"] = comment_limit
    if expand_replies != 1:
        kwargs["expand_replies"] = expand_replies
    return _unwrap(await _cmd("read", **kwargs))


@mcp.tool(
    name="anyweb_platform_search",
    annotations={
        "title": "Search Platform Content",
        "readOnlyHint": True,
        "openWorldHint": True,
    },
)
async def anyweb_platform_search(
    platform: str,
    query: str,
    limit: int = 10,
) -> str:
    """Search for content on a platform.

    Args:
        platform: Platform to search (x, zhihu, xhs).
        query: Search query.
        limit: Max results (1-100).

    Returns:
        JSON array of search results.
    """
    return _unwrap(await _cmd("search", platform=platform, query=query, limit=limit))


@mcp.tool(
    name="anyweb_platform_login",
    annotations={
        "title": "Login to Platform",
        "readOnlyHint": False,
        "openWorldHint": True,
    },
)
async def anyweb_platform_login(
    platform: str,
    method: str = "browser",
) -> str:
    """Login to a platform and save the session.

    Args:
        platform: Platform to login to (x, zhihu, xhs).
        method: Login method ('browser' or 'cookie').

    Returns:
        JSON with login status.
    """
    return _unwrap(await _cmd("login", platform=platform, method=method))


@mcp.tool(
    name="anyweb_browser_action",
    annotations={
        "title": "Execute Browser Actions",
        "readOnlyHint": False,
        "openWorldHint": True,
    },
)
async def anyweb_browser_action(
    actions: list[dict[str, Any]],
    url: str = "",
    platform: str = "generic",
    page: str = "default",
) -> str:
    """Execute a sequence of browser actions.

    Translates ucal-style action sequences into anyweb atomic commands.
    Supported action types: goto, click, type, keyboard_type, scroll,
    screenshot, extract_text, wait, eval_js.

    Args:
        actions: List of action dicts with 'type' and type-specific params.
        url: Starting URL to navigate to before actions.
        platform: Platform context for browser page isolation.
        page: Named page tab for parallel use (default: "default").

    Returns:
        JSON array of results for each action.
    """
    results = []

    # Navigate to URL first if provided
    if url:
        resp = await _cmd("open", url=url, platform=platform, page=page)
        if not resp.get("ok"):
            return json.dumps([{"error": resp.get("error")}], ensure_ascii=False, indent=2)

    for action in actions:
        action_type = action.get("type", "")
        try:
            if action_type == "goto":
                resp = await _cmd("open", url=action["url"], platform=platform, page=page)
            elif action_type == "click":
                resp = await _cmd("click", target=action["selector"], platform=platform, page=page)
            elif action_type == "type":
                # page.fill style
                resp = await _cmd("input", target=action["selector"], text=action["text"], platform=platform, page=page)
            elif action_type == "keyboard_type":
                # Click then keyboard.type
                await _cmd("click", target=action["selector"], platform=platform, page=page)
                await asyncio.sleep(0.1)
                resp = await _cmd("type", text=action["text"], platform=platform, page=page)
            elif action_type == "scroll":
                resp = await _cmd(
                    "scroll",
                    direction=action.get("direction", "down"),
                    amount=action.get("amount", 500),
                    platform=platform,
                    page=page,
                )
            elif action_type == "screenshot":
                resp = await _cmd("screenshot", path=action.get("path"), platform=platform, page=page)
            elif action_type == "extract_text":
                resp = await _cmd("get", what="text", selector=action.get("selector"), platform=platform, page=page)
            elif action_type == "wait":
                timeout = action.get("timeout", 30000)
                resp = await _cmd(
                    "wait",
                    mode="selector",
                    value=action["selector"],
                    timeout=timeout,
                    platform=platform,
                    page=page,
                )
            elif action_type == "eval_js":
                resp = await _cmd("eval", expression=action["expression"], platform=platform, page=page)
            else:
                resp = {"ok": False, "error": f"Unknown action type: {action_type}"}

            results.append(resp.get("data", {}) if resp.get("ok") else {"error": resp.get("error")})
        except Exception as exc:
            results.append({"error": str(exc)})

    return json.dumps(results, ensure_ascii=False, indent=2)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Run anyweb as an MCP server."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
    )
    mcp.run()


if __name__ == "__main__":
    main()
