"""Generic website adapter.

Fallback adapter that works with any website via Playwright.
Extracts text content from arbitrary URLs.
"""

from __future__ import annotations

import logging
from typing import Any

from anyweb.adapters.base import (
    AdapterType,
    BaseAdapter,
    ContentResult,
    ExtractResult,
    LoginMethod,
    LoginStatus,
    SearchResult,
)
from anyweb.core.browser import BrowserManager
from anyweb.core.human_behavior import human_scroll, random_delay

logger = logging.getLogger(__name__)


class GenericAdapter(BaseAdapter):
    """Generic adapter for any website using Playwright."""

    platform_name = "generic"
    adapter_type = AdapterType.BROWSER

    def __init__(self, browser_manager: BrowserManager) -> None:
        self._bm = browser_manager

    def is_logged_in(self) -> bool:
        return True

    async def login(self, method: LoginMethod = LoginMethod.BROWSER) -> LoginStatus:
        return LoginStatus(
            success=True,
            platform=self.platform_name,
            method=method.value,
            message="Generic adapter requires no login.",
        )

    async def search(self, query: str, limit: int = 10) -> list[SearchResult]:
        return [
            SearchResult(
                title="Search not supported",
                url="",
                summary="The generic adapter doesn't support search. Use read with a URL.",
                platform=self.platform_name,
            )
        ]

    async def read(self, url: str, **kwargs: Any) -> ContentResult:
        """Read content from any URL."""
        page = await self._bm.new_page("generic")
        try:
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=30000)
            except Exception:
                # Some sites (e.g. WeChat MP) abort during redirect — wait for final page
                await page.wait_for_load_state("domcontentloaded", timeout=10000)
            await random_delay(1.0, 3.0)

            # Scroll to trigger lazy loading
            await human_scroll(page, direction="down", amount=600)
            await random_delay(0.5, 1.0)

            result = await page.evaluate("""
                () => {
                    const title = document.title;
                    const selectors = [
                        'article', 'main', '[role="main"]',
                        '.content', '.post-content', '#content'
                    ];
                    let body = '';
                    for (const sel of selectors) {
                        const el = document.querySelector(sel);
                        if (el) { body = el.innerText.trim(); break; }
                    }
                    if (!body) body = document.body.innerText;
                    return { title, body };
                }
            """)
            title = result["title"]
            body = result["body"]

            return ContentResult(
                title=title,
                content=body,
                url=url,
                platform=self.platform_name,
            )
        except Exception as exc:
            logger.error("Generic read failed for %s: %s", url, exc)
            return ContentResult(
                title="Error",
                content=f"Failed to read page: {exc}",
                url=url,
                platform=self.platform_name,
            )
        finally:
            await page.close()

    async def extract(self, url: str, fields: list[str]) -> ExtractResult:
        content = await self.read(url)
        all_fields: dict[str, Any] = {
            "title": content.title,
            "content": content.content,
            "url": url,
            "platform": self.platform_name,
        }
        selected = {k: all_fields.get(k, "") for k in fields} if fields else all_fields
        return ExtractResult(
            fields=selected,
            url=url,
            platform=self.platform_name,
        )
