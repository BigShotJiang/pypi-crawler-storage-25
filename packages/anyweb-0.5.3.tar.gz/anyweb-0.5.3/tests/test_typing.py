"""Tests for keyboard typing behavior."""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from anyweb.daemon import type_keyboard_text


@pytest.mark.asyncio
async def test_type_keyboard_text_uses_shift_enter_for_newlines() -> None:
    keyboard = AsyncMock()

    await type_keyboard_text(keyboard, "line 1\nline 2\nline 3", delay=7)

    assert keyboard.method_calls == [
        ("type", ("line 1",), {"delay": 7}),
        ("press", ("Shift+Enter",), {}),
        ("type", ("line 2",), {"delay": 7}),
        ("press", ("Shift+Enter",), {}),
        ("type", ("line 3",), {"delay": 7}),
    ]


@pytest.mark.asyncio
async def test_type_keyboard_text_normalizes_crlf() -> None:
    keyboard = AsyncMock()

    await type_keyboard_text(keyboard, "a\r\nb", delay=50)

    assert keyboard.method_calls == [
        ("type", ("a",), {"delay": 50}),
        ("press", ("Shift+Enter",), {}),
        ("type", ("b",), {"delay": 50}),
    ]
