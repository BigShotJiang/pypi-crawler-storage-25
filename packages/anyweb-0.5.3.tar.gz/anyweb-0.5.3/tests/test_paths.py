"""Tests for path detection utilities."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from anyweb.core.paths import is_system_chrome_running, system_chrome_profile


def test_system_chrome_profile_returns_path_when_cookies_exist(tmp_path: Path) -> None:
    default = tmp_path / "Default"
    default.mkdir()
    (default / "Cookies").write_bytes(b"sqlite")

    with patch("anyweb.core.paths._chrome_profile_candidates", return_value=[tmp_path]):
        result = system_chrome_profile()

    assert result == tmp_path


def test_system_chrome_profile_returns_none_when_no_cookies(tmp_path: Path) -> None:
    with patch("anyweb.core.paths._chrome_profile_candidates", return_value=[tmp_path]):
        result = system_chrome_profile()

    assert result is None


def test_is_system_chrome_running_false_when_no_chrome() -> None:
    with patch("anyweb.core.paths.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 1
        mock_run.return_value.stdout = ""
        assert is_system_chrome_running() is False


def test_is_system_chrome_running_true_when_chrome_process() -> None:
    with patch("anyweb.core.paths.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = "12345\n"
        assert is_system_chrome_running() is True
