"""Tests for doctor credential checks."""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import patch

from anyweb.cli import _check_credentials, _check_chrome


def test_check_credentials_valid_session(tmp_path: Path) -> None:
    session_data = {
        "cookies": [
            {"name": "auth_token", "value": "v", "expires": time.time() + 86400},
        ],
        "origins": [],
    }
    (tmp_path / "x_session.json").write_text(json.dumps(session_data))

    results, issues = _check_credentials(tmp_path, ["x"])
    assert results[0][0] == "OK"
    assert len(issues) == 0


def test_check_credentials_expired_session(tmp_path: Path) -> None:
    session_data = {
        "cookies": [
            {"name": "auth_token", "value": "v", "expires": 1000000},
        ],
        "origins": [],
    }
    (tmp_path / "x_session.json").write_text(json.dumps(session_data))

    results, issues = _check_credentials(tmp_path, ["x"])
    assert results[0][0] == "!!"
    assert issues[0] == ("expired", "x")


def test_check_credentials_missing_session(tmp_path: Path) -> None:
    results, issues = _check_credentials(tmp_path, ["x"])
    assert results[0][0] == "--"
    assert issues[0] == ("missing", "x")


def test_check_chrome_found() -> None:
    with (
        patch("anyweb.cli.find_chrome_executable", return_value="/usr/bin/chrome"),
        patch("anyweb.cli.system_chrome_profile", return_value=Path("/fake")),
    ):
        results = _check_chrome()
    assert any("Chrome found" in r[1] for r in results)
    assert any("System Chrome profile" in r[1] for r in results)


def test_check_credentials_wechat_valid(tmp_path: Path) -> None:
    session_data = {
        "cookies": [
            {"name": "slave_sid", "value": "v", "expires": time.time() + 86400},
        ],
        "origins": [],
    }
    (tmp_path / "wechat_session.json").write_text(json.dumps(session_data))

    results, issues = _check_credentials(tmp_path, ["wechat"])
    assert results[0][0] == "OK"
    assert len(issues) == 0


def test_check_chrome_not_found() -> None:
    with (
        patch("anyweb.cli.find_chrome_executable", return_value=None),
        patch("anyweb.cli.system_chrome_profile", return_value=None),
    ):
        results = _check_chrome()
    assert any(r[0] == "FAIL" for r in results)
