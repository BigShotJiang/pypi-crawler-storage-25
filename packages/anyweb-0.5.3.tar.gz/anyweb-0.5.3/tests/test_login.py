"""Tests for login cookie extraction helpers."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from anyweb.core.session import SessionManager
from anyweb.daemon import CommandHandler


def test_filter_cookies_for_platform_keeps_target_domains() -> None:
    cookies = [
        {"name": "auth_token", "domain": ".x.com", "value": "x"},
        {"name": "twid", "domain": ".twitter.com", "value": "t"},
        {"name": "other", "domain": ".example.com", "value": "e"},
    ]

    filtered = CommandHandler._filter_cookies_for_platform("x", cookies)

    assert [c["name"] for c in filtered] == ["auth_token", "twid"]


def test_to_storage_state_cookie_removes_cdp_only_fields() -> None:
    cookie = {
        "name": "auth_token",
        "value": "secret",
        "domain": ".x.com",
        "path": "/",
        "expires": 1790000000,
        "httpOnly": True,
        "secure": True,
        "sameSite": "None",
        "priority": "Medium",
        "sourcePort": 443,
    }

    converted = CommandHandler._to_storage_state_cookie(cookie)

    assert converted == {
        "name": "auth_token",
        "value": "secret",
        "domain": ".x.com",
        "path": "/",
        "expires": 1790000000,
        "httpOnly": True,
        "secure": True,
        "sameSite": "None",
    }


def test_session_manager_save_cookies_writes_storage_state(tmp_path) -> None:
    manager = SessionManager(tmp_path)

    path = manager.save_cookies("x", [{"name": "auth_token", "value": "secret"}])

    assert json.loads((tmp_path / "x_session.json").read_text()) == {
        "cookies": [{"name": "auth_token", "value": "secret"}],
        "origins": [],
    }
    assert path == str(tmp_path / "x_session.json")


@pytest.mark.asyncio
async def test_browser_login_uses_raw_cdp_extraction_not_playwright(tmp_path) -> None:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    raw_cookies = [
        {
            "name": "auth_token",
            "value": "secret",
            "domain": ".x.com",
            "path": "/",
            "expires": 1790000000,
            "httpOnly": True,
            "secure": True,
            "sameSite": "None",
        }
    ]

    with (
        patch.object(handler, "_is_cdp_port_open", new=AsyncMock(return_value=False)),
        patch.object(handler, "_spawn_chrome_for_login", return_value=111),
        patch.object(handler, "_wait_for_process_exit", new=AsyncMock(return_value=True)),
        patch.object(handler, "_spawn_chrome_with_cdp", return_value=222),
        patch.object(handler, "_wait_for_cdp_port", new=AsyncMock()),
        patch.object(handler, "_extract_cookies_raw_cdp", new=AsyncMock(return_value=raw_cookies)),
        patch.object(handler, "_kill_chrome") as kill_chrome,
        patch("anyweb.daemon.BrowserManager") as playwright_bm,
    ):
        result = await handler.cmd_login("x", method="browser")

    assert result["success"] is True
    assert result["session_file"] == str(tmp_path / "x_session.json")
    assert json.loads((tmp_path / "x_session.json").read_text())["cookies"][0]["name"] == "auth_token"
    assert not playwright_bm.return_value.connect_via_cdp_direct.called
    kill_chrome.assert_called_once()


# --- Credential import tests ---

import tempfile
from pathlib import Path


def test_has_auth_cookie_x() -> None:
    assert CommandHandler._has_auth_cookie("x", [{"name": "auth_token"}]) is True
    assert CommandHandler._has_auth_cookie("x", [{"name": "other"}]) is False


def test_has_auth_cookie_zhihu() -> None:
    assert CommandHandler._has_auth_cookie("zhihu", [{"name": "z_c0"}]) is True
    assert CommandHandler._has_auth_cookie("zhihu", [{"name": "other"}]) is False


@pytest.mark.asyncio
async def test_import_credentials_copies_cookies_and_saves_session(tmp_path: Path) -> None:
    """import_credentials should: copy Chrome files, spawn CDP, extract cookies, save session."""
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    # Create fake system Chrome profile
    sys_chrome = tmp_path / "system_chrome"
    sys_default = sys_chrome / "Default"
    sys_default.mkdir(parents=True)
    (sys_default / "Cookies").write_bytes(b"fake-cookies-db")
    (sys_chrome / "Local State").write_text('{"key": "value"}')

    # Create anyweb profile dir
    anyweb_profile = tmp_path / "anyweb_profile"
    anyweb_default = anyweb_profile / "Default"
    anyweb_default.mkdir(parents=True)

    raw_cookies = [
        {
            "name": "auth_token",
            "value": "secret",
            "domain": ".x.com",
            "path": "/",
            "expires": 1790000000,
            "httpOnly": True,
            "secure": True,
            "sameSite": "None",
        },
    ]

    with (
        patch("anyweb.daemon.system_chrome_profile", return_value=sys_chrome),
        patch("anyweb.daemon.is_system_chrome_running", return_value=False),
        patch("anyweb.daemon.CHROME_PROFILE_DIR", anyweb_profile),
        patch.object(handler, "_spawn_chrome_with_cdp", return_value=333),
        patch.object(handler, "_wait_for_cdp_port", new=AsyncMock()),
        patch.object(handler, "_extract_cookies_raw_cdp", new=AsyncMock(return_value=raw_cookies)),
        patch.object(handler, "_kill_chrome"),
    ):
        result = await handler.cmd_import_credentials("x")

    assert result["success"] is True
    assert "session_file" in result
    # Verify cookies were copied to anyweb profile
    assert (anyweb_default / "Cookies").read_bytes() == b"fake-cookies-db"
    # Verify session was saved (dual-write)
    session_data = json.loads((tmp_path / "x_session.json").read_text())
    assert session_data["cookies"][0]["name"] == "auth_token"


@pytest.mark.asyncio
async def test_import_credentials_fails_when_chrome_running(tmp_path: Path) -> None:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    sys_chrome = tmp_path / "system_chrome"
    sys_default = sys_chrome / "Default"
    sys_default.mkdir(parents=True)
    (sys_default / "Cookies").write_bytes(b"data")

    with (
        patch("anyweb.daemon.system_chrome_profile", return_value=sys_chrome),
        patch("anyweb.daemon.is_system_chrome_running", return_value=True),
    ):
        result = await handler.cmd_import_credentials("x")

    assert result["success"] is False
    assert result["action_required"] == "close_chrome"


@pytest.mark.asyncio
async def test_import_credentials_fails_when_no_system_chrome(tmp_path: Path) -> None:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    with patch("anyweb.daemon.system_chrome_profile", return_value=None):
        result = await handler.cmd_import_credentials("x")

    assert result["success"] is False
    assert "not found" in result["message"].lower()


# --- Auto login method tests ---


@pytest.mark.asyncio
async def test_login_auto_returns_success_when_session_valid(tmp_path: Path) -> None:
    """auto method should skip import if session is already valid."""
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    import time

    session_data = {
        "cookies": [
            {
                "name": "auth_token",
                "value": "valid",
                "domain": ".x.com",
                "path": "/",
                "expires": time.time() + 86400,
                "httpOnly": True,
                "secure": True,
            },
        ],
        "origins": [],
    }
    (tmp_path / "x_session.json").write_text(json.dumps(session_data))

    result = await handler.cmd_login("x", method="auto")

    assert result["success"] is True
    assert "already" in result["message"].lower()


@pytest.mark.asyncio
async def test_login_auto_imports_when_session_expired(tmp_path: Path) -> None:
    """auto method should try import_credentials when session is expired."""
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    handler = CommandHandler(bm)

    session_data = {
        "cookies": [
            {
                "name": "auth_token",
                "value": "old",
                "domain": ".x.com",
                "path": "/",
                "expires": 1000000,
                "httpOnly": True,
                "secure": True,
            },
        ],
        "origins": [],
    }
    (tmp_path / "x_session.json").write_text(json.dumps(session_data))

    import_result = {
        "success": True,
        "platform": "x",
        "message": "Imported 5 cookies.",
        "session_file": str(tmp_path / "x_session.json"),
    }

    with patch.object(handler, "cmd_import_credentials", new=AsyncMock(return_value=import_result)):
        result = await handler.cmd_login("x", method="auto")

    assert result["success"] is True


# --- wechat platform ---


def test_wechat_cookie_domain_filter() -> None:
    cookies = [
        {"name": "slave_sid", "domain": "mp.weixin.qq.com", "value": "s"},
        {"name": "_clck", "domain": ".qq.com", "value": "c"},
        {"name": "other", "domain": ".google.com", "value": "g"},
    ]
    filtered = CommandHandler._filter_cookies_for_platform("wechat", cookies)
    domains = {c["domain"] for c in filtered}
    assert ".google.com" not in domains
    assert len(filtered) == 2


def test_wechat_has_auth_cookie() -> None:
    cookies = [
        {"name": "slave_sid", "value": "v"},
        {"name": "data_ticket", "value": "t"},
    ]
    assert CommandHandler._has_auth_cookie("wechat", cookies) is True


def test_wechat_has_auth_cookie_missing() -> None:
    cookies = [{"name": "data_ticket", "value": "t"}]
    assert CommandHandler._has_auth_cookie("wechat", cookies) is False


def test_wechat_session_valid(tmp_path: Path) -> None:
    import time

    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    bm._pages = {}
    handler = CommandHandler(bm)

    session_data = {
        "cookies": [
            {
                "name": "slave_sid",
                "value": "valid",
                "domain": "mp.weixin.qq.com",
                "expires": time.time() + 86400,
            },
        ],
        "origins": [],
    }
    (tmp_path / "wechat_session.json").write_text(json.dumps(session_data))
    assert handler._is_session_valid("wechat") is True
