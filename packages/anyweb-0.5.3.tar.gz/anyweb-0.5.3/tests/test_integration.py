"""Integration tests for the redesigned login + routing flow."""

from __future__ import annotations

import json
import time
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from anyweb.core.session import SessionManager
from anyweb.daemon import CommandHandler


@pytest.fixture
def handler_with_session(tmp_path: Path):
    """Create a CommandHandler with valid X session."""
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    bm._pages = {}
    handler = CommandHandler(bm)

    session_data = {
        "cookies": [
            {
                "name": "auth_token",
                "value": "valid_token",
                "domain": ".x.com",
                "path": "/",
                "expires": time.time() + 86400 * 30,
                "httpOnly": True,
                "secure": True,
            },
        ],
        "origins": [],
    }
    (tmp_path / "x_session.json").write_text(json.dumps(session_data))
    return handler


@pytest.mark.asyncio
async def test_auto_login_skips_import_when_session_valid(handler_with_session) -> None:
    """Full flow: auto login should return immediately with valid session."""
    result = await handler_with_session.cmd_login("x", method="auto")
    assert result["success"] is True
    assert "already" in result["message"].lower()


def test_route_engine_grok_to_cdp(handler_with_session) -> None:
    engine, reason = handler_with_session._route_engine(
        "open", {"url": "https://x.com/i/grok?new=true", "page": "grok1"}
    )
    assert engine == "cdp"


def test_route_engine_read_to_headless(handler_with_session) -> None:
    engine, reason = handler_with_session._route_engine("read", {"url": "https://x.com/karpathy"})
    assert engine == "headless"


@pytest.mark.asyncio
async def test_execute_includes_engine_in_response(handler_with_session) -> None:
    """execute() should include engine and reason in every response."""
    handler = handler_with_session
    handler.bm = handler._bm_headless

    with patch.object(handler, "cmd_status", new=AsyncMock(return_value={"daemon": {}})):
        result = await handler.execute({"cmd": "status", "args": {}})

    assert result["ok"] is True
    assert "engine" in result
    assert "reason" in result


def test_is_antibot_error() -> None:
    assert CommandHandler._is_antibot_error(Exception("Cloudflare challenge detected")) is True
    assert CommandHandler._is_antibot_error(Exception("403 Forbidden")) is True
    assert CommandHandler._is_antibot_error(Exception("Element not found")) is False
    assert CommandHandler._is_antibot_error(Exception("Timeout")) is False


# --- status recommended_action ---


@pytest.mark.asyncio
async def test_status_expired_session_has_recommended_action(tmp_path: Path) -> None:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    bm._pages = {}
    bm._contexts = {}
    bm.is_running = True
    bm._browser = None
    handler = CommandHandler(bm)

    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    session_data = {
        "cookies": [{"name": "auth_token", "value": "v", "expires": 1000000}],
        "origins": [],
    }
    (session_dir / "x_session.json").write_text(json.dumps(session_data))

    with patch("anyweb.daemon.ANYWEB_DIR", tmp_path):
        result = await handler.cmd_status()
    sessions = result["sessions"]
    x_session = [s for s in sessions if s["platform"] == "x"][0]
    assert x_session["expired"] is True
    assert x_session["recommended_action"] == "anyweb login x"


@pytest.mark.asyncio
async def test_status_valid_session_no_recommended_action(tmp_path: Path) -> None:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    bm._pages = {}
    bm._contexts = {}
    bm.is_running = True
    bm._browser = None
    handler = CommandHandler(bm)

    session_dir = tmp_path / "sessions"
    session_dir.mkdir()
    session_data = {
        "cookies": [
            {"name": "auth_token", "value": "v", "expires": time.time() + 86400 * 30},
        ],
        "origins": [],
    }
    (session_dir / "x_session.json").write_text(json.dumps(session_data))

    with patch("anyweb.daemon.ANYWEB_DIR", tmp_path):
        result = await handler.cmd_status()
    sessions = result["sessions"]
    x_session = [s for s in sessions if s["platform"] == "x"][0]
    assert x_session["expired"] is False
    assert "recommended_action" not in x_session


# --- close --page ---


@pytest.mark.asyncio
async def test_close_specific_page(handler_with_session) -> None:
    handler = handler_with_session
    page1 = AsyncMock()
    page1.is_closed = MagicMock(return_value=False)
    page2 = AsyncMock()
    page2.is_closed = MagicMock(return_value=False)
    handler._bm_headless._pages = {"x:grok1": page1, "x:grok2": page2}
    handler._bm_headless._page_last_access = {"x:grok1": 0, "x:grok2": 0}

    result = await handler.cmd_close(page="grok1")
    assert result["closed"] is True
    assert result["page"] == "grok1"
    page1.close.assert_awaited_once()
    assert "x:grok2" in handler._bm_headless._pages
    assert "x:grok1" not in handler._bm_headless._pages


@pytest.mark.asyncio
async def test_close_nonexistent_page(handler_with_session) -> None:
    handler = handler_with_session
    handler._bm_headless._pages = {}

    result = await handler.cmd_close(page="nosuch")
    assert result["closed"] is False
    assert "not found" in result["error"]
