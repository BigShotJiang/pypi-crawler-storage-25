"""Tests for log filtering logic."""

from __future__ import annotations

from anyweb.cli import _filter_log_lines


def test_filter_cmd_only() -> None:
    lines = [
        "2026-05-13 [INFO] [CMD] open url=x → OK 1.0s [headless:default]",
        "2026-05-13 [INFO] Some internal log",
        "2026-05-13 [INFO] [CMD] read url=y → OK 0.5s [cdp:grok]",
    ]
    result = _filter_log_lines(lines, cmd_only=True)
    assert len(result) == 2


def test_filter_by_engine() -> None:
    lines = [
        "2026-05-13 [INFO] [CMD] open → OK 1.0s [headless:default]",
        "2026-05-13 [INFO] [CMD] open → OK 2.0s [cdp:grok_requires_cdp]",
        "2026-05-13 [INFO] [CMD] read → OK 0.5s [headless:default]",
    ]
    result = _filter_log_lines(lines, cmd_only=True, engine="cdp")
    assert len(result) == 1
    assert "[cdp:" in result[0]


def test_filter_errors_only() -> None:
    lines = [
        "2026-05-13 [INFO] [CMD] open → OK 1.0s [headless:default]",
        "2026-05-13 [ERROR] [CMD] read → ERROR 15.0s [headless:default] Timeout",
        "2026-05-13 [ERROR] [CMD] wait → TIMEOUT 30.0s [cdp:grok]",
    ]
    result = _filter_log_lines(lines, cmd_only=True, errors_only=True)
    assert len(result) == 2


def test_filter_combined() -> None:
    lines = [
        "2026-05-13 [INFO] [CMD] open → OK [headless:default]",
        "2026-05-13 [ERROR] [CMD] read → ERROR [headless:default] Timeout",
        "2026-05-13 [ERROR] [CMD] wait → ERROR [cdp:grok] CF block",
        "2026-05-13 [INFO] [CMD] open → OK [cdp:grok_requires_cdp]",
    ]
    result = _filter_log_lines(lines, cmd_only=True, engine="headless", errors_only=True)
    assert len(result) == 1
    assert "headless" in result[0]
