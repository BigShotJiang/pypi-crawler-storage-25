"""Tests for dual-engine routing logic."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from anyweb.core.session import SessionManager
from anyweb.daemon import CommandHandler


def _make_handler(tmp_path) -> CommandHandler:
    bm = MagicMock()
    bm.session_manager = SessionManager(tmp_path)
    bm._pages = {}
    return CommandHandler(bm)


# --- _route_engine tests ---


def test_route_engine_returns_headed_for_grok_url(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("open", {"url": "https://x.com/i/grok?new=true", "page": "grok1"})
    assert engine == "headed"
    assert "grok" in reason


def test_route_engine_returns_headed_for_grok_page(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("click", {"url": "", "page": "grok1", "target": "textarea"})
    assert engine == "headed"


def test_route_engine_returns_headed_for_auth_domain(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("open", {"url": "https://x.com/home", "page": "default"})
    assert engine == "headed"
    assert reason == "auth_domain"


def test_route_read_xcom_to_headed(tmp_path) -> None:
    """x.com is an auth domain, so read routes to headed."""
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("read", {"url": "https://x.com/karpathy"})
    assert engine == "headed"
    assert reason == "auth_domain"


def test_route_engine_returns_headless_for_default(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("open", {"url": "https://example.com", "page": "default"})
    assert engine == "headless"
    assert reason == "default"


def test_route_search_to_headless(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("search", {"url": "", "platform": "x", "query": "AI"})
    assert engine == "headless"


def test_route_grok_com_to_headed(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("open", {"url": "https://grok.com/chat", "page": "default"})
    assert engine == "headed"
    assert "grok" in reason or "auth" in reason


def test_route_page_affinity_stays_headed(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    cdp_bm = MagicMock()
    cdp_bm._pages = {"x:chat1": MagicMock()}
    handler._bm_cdp = cdp_bm

    engine, reason = handler._route_engine("type", {"url": "", "page": "chat1", "text": "hello"})
    assert engine == "headed"
    assert reason == "page_affinity"


def test_route_page_affinity_headless_over_grok_name(tmp_path) -> None:
    """Page opened in headless should stay in headless even if name contains 'grok'."""
    handler = _make_handler(tmp_path)
    handler._bm_headless._pages = {"x:grok1": MagicMock()}

    engine, reason = handler._route_engine("wait", {"url": "", "page": "grok1"})
    assert engine == "headless"
    assert reason == "page_affinity"


def test_route_page_affinity_headless_over_auth_domain(tmp_path) -> None:
    """Page opened in headless stays there even for auth domain URLs."""
    handler = _make_handler(tmp_path)
    handler._bm_headless._pages = {"x:mypage": MagicMock()}

    engine, reason = handler._route_engine(
        "click", {"url": "https://x.com/something", "page": "mypage", "target": "e5"}
    )
    assert engine == "headless"
    assert reason == "page_affinity"


def test_route_status_command_to_headless(tmp_path) -> None:
    handler = _make_handler(tmp_path)
    engine, reason = handler._route_engine("status", {})
    assert engine == "headless"


# --- execute() engine_override tests ---


def test_execute_headless_override_skips_route(tmp_path) -> None:
    """--headless override should bypass _route_engine and use headless."""
    handler = _make_handler(tmp_path)
    handler.cmd_open = AsyncMock(return_value={"url": "https://x.com"})

    request = {
        "cmd": "open",
        "args": {"url": "https://x.com", "page": "default"},
        "engine_override": "headless",
    }

    result = asyncio.run(handler.execute(request))

    assert result["ok"]
    assert result["engine"] == "headless"
    assert result["reason"] == "user_override"


def test_execute_headed_override_skips_route(tmp_path) -> None:
    """--headed override should bypass _route_engine and use headed."""
    handler = _make_handler(tmp_path)
    handler.cmd_open = AsyncMock(return_value={"url": "https://example.com"})

    with patch.object(handler, "_ensure_cdp_chrome", new_callable=AsyncMock) as mock_cdp:
        mock_cdp.return_value = MagicMock()
        request = {
            "cmd": "open",
            "args": {"url": "https://example.com", "page": "default"},
            "engine_override": "headed",
        }
        result = asyncio.run(handler.execute(request))

    assert result["ok"]
    assert result["engine"] == "headed"
    assert result["reason"] == "user_override"


def test_execute_no_override_uses_route_engine(tmp_path) -> None:
    """No override should use _route_engine as before."""
    handler = _make_handler(tmp_path)
    handler.cmd_open = AsyncMock(return_value={"url": "https://example.com"})

    request = {
        "cmd": "open",
        "args": {"url": "https://example.com", "page": "default"},
    }

    result = asyncio.run(handler.execute(request))

    assert result["ok"]
    assert result["engine"] == "headless"
    assert result["reason"] == "default"


def test_execute_headless_override_no_antibot_retry(tmp_path) -> None:
    """--headless override should NOT auto-upgrade to headed on anti-bot error."""
    handler = _make_handler(tmp_path)
    handler.cmd_open = AsyncMock(side_effect=Exception("403 access denied cloudflare"))

    request = {
        "cmd": "open",
        "args": {"url": "https://example.com", "page": "default"},
        "engine_override": "headless",
    }

    result = asyncio.run(handler.execute(request))

    assert not result["ok"]
    assert result["engine"] == "headless"
    assert result["reason"] == "user_override"
