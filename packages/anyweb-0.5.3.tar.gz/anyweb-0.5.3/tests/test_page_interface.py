"""Tests for PageInterface protocol."""


def test_page_interface_has_expected_methods():
    from anyweb.core.page_interface import PageInterface

    for attr in ("goto", "evaluate", "inner_text", "click", "type_text", "wait_for_selector", "title", "url", "close"):
        assert hasattr(PageInterface, attr)
