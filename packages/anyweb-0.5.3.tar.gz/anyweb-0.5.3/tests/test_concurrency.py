"""Concurrency safety tests for anyweb.

Verifies that shared mutable state, locks, semaphores, and browser crash
recovery work correctly under concurrent access.
"""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from anyweb.core.browser import BrowserManager

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_mock_page(closed: bool = False) -> MagicMock:
    page = AsyncMock()
    # is_closed() is a sync method in Playwright, so use MagicMock
    page.is_closed = MagicMock(return_value=closed)
    page.close = AsyncMock()
    return page


def _make_mock_context() -> MagicMock:
    ctx = AsyncMock()
    ctx.new_page = AsyncMock(side_effect=lambda: _make_mock_page())
    ctx.close = AsyncMock()
    return ctx


def _make_mock_browser() -> MagicMock:
    browser = MagicMock()
    browser.new_context = AsyncMock(side_effect=lambda **kw: _make_mock_context())
    browser.close = AsyncMock()
    browser.on = MagicMock()
    browser.process = MagicMock()
    browser.process.pid = 12345
    return browser


@pytest.fixture
def bm() -> BrowserManager:
    """BrowserManager with mocked internals."""
    mgr = BrowserManager()
    mgr._browser = _make_mock_browser()
    mgr._playwright = AsyncMock()
    return mgr


# ---------------------------------------------------------------------------
# 1. get_context creates exactly one context per platform under concurrency
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_context_no_duplicate(bm: BrowserManager) -> None:
    """Concurrent get_context calls for same platform must yield one context."""
    results = await asyncio.gather(
        bm.get_context("twitter"),
        bm.get_context("twitter"),
        bm.get_context("twitter"),
    )
    # All should return the same context object
    assert results[0] is results[1] is results[2]
    # new_context should be called exactly once
    assert bm._browser.new_context.await_count == 1


# ---------------------------------------------------------------------------
# 2. get_context creates separate contexts for different platforms
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_context_platform_isolation(bm: BrowserManager) -> None:
    """Different platforms get different contexts."""
    ctx_a, ctx_b = await asyncio.gather(
        bm.get_context("twitter"),
        bm.get_context("zhihu"),
    )
    assert ctx_a is not ctx_b
    assert bm._browser.new_context.await_count == 2


# ---------------------------------------------------------------------------
# 3. get_page creates exactly one page per platform under concurrency
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_page_no_duplicate(bm: BrowserManager) -> None:
    """Concurrent get_page calls for same platform must yield one page."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        results = await asyncio.gather(
            bm.get_page("generic"),
            bm.get_page("generic"),
            bm.get_page("generic"),
        )
    assert results[0] is results[1] is results[2]


# ---------------------------------------------------------------------------
# 4. new_page creates a fresh page each call
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_new_page_creates_fresh(bm: BrowserManager) -> None:
    """Each new_page call must return a distinct page."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        pages = await asyncio.gather(
            bm.new_page("generic"),
            bm.new_page("generic"),
        )
    assert pages[0] is not pages[1]


# ---------------------------------------------------------------------------
# 5. Browser disconnect clears state for recovery
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_browser_disconnect_clears_state(bm: BrowserManager) -> None:
    """Browser disconnect callback must clear all state."""
    # Populate some state
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        await bm.get_page("twitter")

    assert len(bm._contexts) > 0
    assert len(bm._pages) > 0

    # Simulate disconnect
    bm._on_browser_disconnected()

    assert bm._browser is None
    assert len(bm._contexts) == 0
    assert len(bm._pages) == 0


# ---------------------------------------------------------------------------
# 6. get_page replaces closed page
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_page_replaces_closed(bm: BrowserManager) -> None:
    """If the cached page is closed, get_page should create a new one."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        page1 = await bm.get_page("generic")

        # Mark page as closed
        page1.is_closed.return_value = True

        page2 = await bm.get_page("generic")
        assert page2 is not page1


# ---------------------------------------------------------------------------
# 7. CommandHandler._gated_call respects semaphore
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_gated_call_semaphore_limits_concurrency() -> None:
    """_gated_call should limit concurrent work to semaphore capacity."""
    from anyweb.daemon import CommandHandler

    handler = CommandHandler(MagicMock())
    handler._page_sem = asyncio.Semaphore(2)

    active = 0
    max_active = 0

    async def tracked_work() -> str:
        nonlocal active, max_active
        active += 1
        max_active = max(max_active, active)
        await asyncio.sleep(0.05)
        active -= 1
        return "done"

    results = await asyncio.gather(
        handler._gated_call(tracked_work),
        handler._gated_call(tracked_work),
        handler._gated_call(tracked_work),
        handler._gated_call(tracked_work),
    )
    assert all(r == "done" for r in results)
    assert max_active <= 2


# ---------------------------------------------------------------------------
# 8. _gated_call raises TimeoutError on slow work
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_gated_call_timeout() -> None:
    """_gated_call should raise TimeoutError if work exceeds timeout."""
    from anyweb.daemon import CommandHandler

    handler = CommandHandler(MagicMock())

    async def slow_work() -> None:
        await asyncio.sleep(10)

    with pytest.raises(TimeoutError):
        await handler._gated_call(slow_work, total_timeout=0.1, work_timeout=0.05)


# ---------------------------------------------------------------------------
# 9. execute wraps unknown commands gracefully
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execute_unknown_command() -> None:
    """execute should return error for unknown commands."""
    from anyweb.daemon import CommandHandler

    handler = CommandHandler(MagicMock())
    result = await handler.execute({"cmd": "nonexistent", "args": {}})
    assert result["ok"] is False
    assert "Unknown command" in result["error"]


# ---------------------------------------------------------------------------
# 10. detect_platform_from_url
# ---------------------------------------------------------------------------


def test_detect_platform_from_url() -> None:
    """URL-based platform detection must match known domains."""
    from anyweb.daemon import detect_platform_from_url

    assert detect_platform_from_url("https://x.com/user/status/123") == "x"
    assert detect_platform_from_url("https://twitter.com/user") == "x"
    assert detect_platform_from_url("https://www.zhihu.com/question/1") == "zhihu"
    assert detect_platform_from_url("https://www.xiaohongshu.com/explore/abc") == "xhs"
    assert detect_platform_from_url("https://example.com/page") == "generic"
    assert detect_platform_from_url("not-a-url") == "generic"


# ---------------------------------------------------------------------------
# 11. get_named_page: same platform + same page_id → same page
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_page_same_id_returns_same(bm: BrowserManager) -> None:
    """Same platform + same page_id must return the same page."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        p1 = await bm.get_named_page("x", "grok1")
        p2 = await bm.get_named_page("x", "grok1")
    assert p1 is p2


# ---------------------------------------------------------------------------
# 12. get_named_page: same platform + different page_id → different pages
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_page_different_ids_return_different(bm: BrowserManager) -> None:
    """Same platform + different page_ids must return different pages sharing one context."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        p1 = await bm.get_named_page("x", "grok1")
        p2 = await bm.get_named_page("x", "grok2")
    assert p1 is not p2
    # Both share the same context (only one context for "x")
    assert bm._browser.new_context.await_count == 1


# ---------------------------------------------------------------------------
# 13. get_named_page: different platform → different context and pages
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_page_different_platform(bm: BrowserManager) -> None:
    """Different platforms must yield different contexts and pages."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        p1 = await bm.get_named_page("x", "tab1")
        p2 = await bm.get_named_page("zhihu", "tab1")
    assert p1 is not p2
    assert bm._browser.new_context.await_count == 2


# ---------------------------------------------------------------------------
# 13b. cdp mode: named page is global — avoids ghost-page bug from sticky
#      platform flips during a daily-report mixed read flow
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_named_page_cdp_mode_global_lookup() -> None:
    """In cdp mode, a non-default page_id resolves to any existing tab with
    that name regardless of the requested platform.

    Reproduces the bug where a sticky platform flip (e.g. after reading a
    non-X URL) caused ``--page grok1`` without ``--platform x`` to create a
    blank ``generic:grok1`` tab instead of reusing the real ``x:grok1``.
    """
    mgr = BrowserManager()
    mgr._cdp_mode = True
    mgr._browser = _make_mock_browser()
    mgr._playwright = AsyncMock()
    # Pre-populate the shared default context for cdp mode
    shared_ctx = _make_mock_context()
    mgr._browser.contexts = [shared_ctx]

    # Create the real grok1 tab under platform "x"
    p_real = await mgr.get_named_page("x", "grok1")
    assert "x:grok1" in mgr._pages

    # Now sticky-platform flips to "generic" — caller asks for grok1
    # without realizing. Should reuse the existing x:grok1, NOT create
    # generic:grok1.
    p_resolved = await mgr.get_named_page("generic", "grok1")
    assert p_resolved is p_real
    assert "generic:grok1" not in mgr._pages, "ghost page must not be created"

    # default pages remain platform-scoped (different platform → different tab)
    p_default_x = await mgr.get_named_page("x", "default")
    p_default_generic = await mgr.get_named_page("generic", "default")
    assert p_default_x is not p_default_generic


# ---------------------------------------------------------------------------
# 14. get_page delegates to get_named_page with "default"
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_page_delegates_to_named(bm: BrowserManager) -> None:
    """get_page should return the same page as get_named_page(platform, 'default')."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        page_default = await bm.get_page("generic")
        page_named = await bm.get_named_page("generic", "default")
    assert page_default is page_named


# ---------------------------------------------------------------------------
# 15. close_context removes all named pages for that platform
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_close_context_removes_all_named_pages(bm: BrowserManager) -> None:
    """close_context must remove all pages keyed with platform prefix."""
    with (
        patch("anyweb.core.browser.apply_stealth", new_callable=AsyncMock),
        patch("anyweb.core.browser.apply_anti_detect_scripts", new_callable=AsyncMock),
    ):
        await bm.get_named_page("x", "grok1")
        await bm.get_named_page("x", "grok2")
        await bm.get_named_page("zhihu", "default")

    assert "x:grok1" in bm._pages
    assert "x:grok2" in bm._pages
    assert "zhihu:default" in bm._pages

    await bm.close_context("x")

    assert "x:grok1" not in bm._pages
    assert "x:grok2" not in bm._pages
    # zhihu page untouched
    assert "zhihu:default" in bm._pages


# ---------------------------------------------------------------------------
# 16. _summarize_args produces correct summaries
# ---------------------------------------------------------------------------


def test_summarize_args_basic() -> None:
    """_summarize_args should include key params and truncate long values."""
    from anyweb.daemon import CommandHandler

    s = CommandHandler._summarize_args
    # page and platform shown only when non-default
    assert "page=grok1" in s("open", {"page": "grok1", "platform": "x", "url": "https://x.com"})
    assert "platform=x" in s("open", {"page": "grok1", "platform": "x", "url": "https://x.com"})
    assert "page=" not in s("open", {"page": "default", "platform": "generic", "url": "https://x.com"})

    # text truncation
    long_text = "a" * 100
    result = s("type", {"text": long_text})
    assert "(100 chars)" in result
    assert "..." in result

    # expression shows only length
    result = s("eval", {"expression": "document.title"})
    assert "expr=(14 chars)" in result
    assert "document.title" not in result

    # wait params
    result = s("wait", {"mode": "selector", "value": "textarea", "timeout": 15000})
    assert "mode=selector" in result
    assert "value=textarea" in result
    assert "timeout=15000" in result

    # get params
    assert "what=text" in s("get", {"what": "text"})

    # cookies action
    assert "action=export" in s("cookies", {"action": "export"})


# ---------------------------------------------------------------------------
# 17. _result_hint extracts key fields
# ---------------------------------------------------------------------------


def test_result_hint() -> None:
    """_result_hint should extract clicked/typed/keys from result dict."""
    from anyweb.daemon import CommandHandler

    h = CommandHandler._result_hint
    assert h({"clicked": "textarea"}) == " clicked=textarea"
    assert h({"typed": 156}) == " typed=156"
    assert h({"keys": "Enter"}) == " keys=Enter"
    assert h({"waited": "selector 'textarea'"}) == " waited=selector 'textarea'"
    assert h({"some_other": "value"}) == ""
    assert h("not a dict") == ""


# ---------------------------------------------------------------------------
# 18. execute() logs OK / TIMEOUT / ERROR
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_execute_logs_cmd(caplog) -> None:
    """execute() should log [CMD] with result status."""
    import logging

    from anyweb.daemon import CommandHandler

    handler = CommandHandler(MagicMock())

    with caplog.at_level(logging.INFO, logger="anyweb.daemon"):
        result = await handler.execute({"cmd": "sessions", "args": {}})

    assert result["ok"] is True
    cmd_logs = [r for r in caplog.records if "[CMD]" in r.message]
    assert len(cmd_logs) == 1
    assert "sessions" in cmd_logs[0].message
    assert "OK" in cmd_logs[0].message
