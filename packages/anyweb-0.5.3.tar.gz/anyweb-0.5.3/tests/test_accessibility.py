"""Tests for accessibility tree compaction."""

from __future__ import annotations

from anyweb.core.accessibility import AXNode, _build_tree, format_compact


def _node(
    node_id: str,
    role: str,
    name: str = "",
    *,
    child_ids: list[str] | None = None,
    backend_id: int = 0,
) -> dict:
    data = {
        "nodeId": node_id,
        "role": {"value": role},
        "name": {"value": name},
    }
    if child_ids:
        data["childIds"] = child_ids
    if backend_id:
        data["backendDOMNodeId"] = backend_id
    return data


def test_build_tree_unwraps_plain_wrappers_merges_text_and_dedupes_link_text() -> None:
    nodes = [
        _node("1", "RootWebArea", "Example", child_ids=["2", "5"]),
        _node("2", "generic", child_ids=["3"]),
        _node("3", "none", child_ids=["4a", "4b"]),
        _node("4a", "StaticText", "Hello"),
        _node("4b", "StaticText", "world"),
        _node("5", "link", "Docs", child_ids=["6"], backend_id=42),
        _node("6", "StaticText", "Docs"),
    ]

    root, ref_cache = _build_tree(nodes)

    assert [child.role for child in root.children] == ["StaticText", "link"]
    assert root.children[0].name == "Hello world"
    assert root.children[1].ref == "e0"
    assert root.children[1].children == []
    assert ref_cache == {"e0": 42}


def test_build_tree_dedupes_link_text_after_merging_fragments() -> None:
    nodes = [
        _node("1", "RootWebArea", "Example", child_ids=["2"]),
        _node("2", "link", "1,085 following", child_ids=["3", "4"], backend_id=42),
        _node("3", "StaticText", "1,085"),
        _node("4", "StaticText", "following"),
    ]

    root, ref_cache = _build_tree(nodes)

    assert root.children[0].children == []
    assert ref_cache == {"e0": 42}


def test_build_tree_drops_blank_text_and_empty_wrappers() -> None:
    nodes = [
        _node("1", "RootWebArea", "Example", child_ids=["2", "4"]),
        _node("2", "generic", child_ids=["3"]),
        _node("3", "StaticText", "   "),
        _node("4", "none"),
    ]

    root, ref_cache = _build_tree(nodes)

    assert root.children == []
    assert ref_cache == {}


def test_format_compact_does_not_truncate_static_text_content() -> None:
    long_text = (
        "No major new funding/IPO announcements on May 7. Earlier context remains important "
        "because partnerships and pilots carried the robotics discussion."
    )

    lines = format_compact(AXNode(role="StaticText", name=long_text))

    assert lines == [f'StaticText "{long_text}"']


def test_format_compact_still_truncates_non_text_node_names() -> None:
    long_name = "article summary " * 12

    lines = format_compact(AXNode(role="article", name=long_name))

    assert lines[0].endswith('..."')
    assert len(lines[0]) < len(f'article "{long_name}"')
