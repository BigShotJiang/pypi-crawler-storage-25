from unicode_fol_kit import FOLParser

parser = FOLParser()

node = parser.parse("∀x ((Object(x) ∧ HasThreeDimensionalShape(x) ∧ ∀y ∀z ((Point(y) ∧ OnSurfaceOf(y, x) ∧ Point(z) ∧ OnSurfaceOf(z, x)) → distance(y, centerOf(x)) = distance(z, centerOf(x)))) → Sphere(x))")

print(node.tree_str())
