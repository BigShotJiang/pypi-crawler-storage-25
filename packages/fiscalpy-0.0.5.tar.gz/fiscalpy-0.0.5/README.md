# FiscalPY

Funciones para limpieza de datasets fiscales en Colombia (por ahora solo incluye territorial y presupuesto general de la nación).

## Instalación

```bash
pip install fiscalpy
```

## ¿Cómo usarla?

### Presupuesto nacional

Para la limpieza del presupuesto nacional, se cuenta con dos funciones `limpieza_gastos_pgn` y `limpieza_ingresos_pgn`. Es importante que los datos provengan directamente de la página del Ministerio de Hacienda y Crédito Público de Colombia, y que la primera fila de los datasets sea la que da los nombres a las columnas.

Para emplearlo:

```
from fiscalpy import limpieza_gastos_pgn, limpieza_ingresos_pgn
import pandas as pd

gastos = pd.read_excel('gastos.xlsx')
rentas = pd.read_excel('rentas.xlsx')

gastos_limpios = limpieza_gastos_pgn(gastos)
rentas_limpias = limpieza_ingresos_pgn(gastos)
```

El resultado en cada caso son datasets normalizados, preparados para análisis descriptivo, tanto estadístico como gráfico.

### Territorial

Se tienen tres funciones: `limpieza_ingresos_territoriales`, `limpieza_gastos_territoriales`, `columnas_ingresos_territoriales`

```python
from fiscalpy import limpieza_ingresos_territoriales, limpieza_gastos_territoriales
```

Tanto la función de `limpieza_ingresos_territoriales` como de `limpieza_gastos_territoriales` soportan la normalización de los datos de ingresos y gastos, de ejecución y de programación, de las entidades territoriales. Lo primero que se debe hacer es importar los datasets con ayuda de `pandas`. Asegúrese de que la importación se realice de manera correcta o la función no se ejecutará correctamente.

Una vez se hayan importando los datos se puede utilizar la función apropiada para cada caso:

```python
import pandas as pd
from fiscalpy import limpieza_ingresos_territoriales

df = pd.read_excel('datos_ejecucion_2025.xlsx')

norm_data = limpieza_ingresos_territoriales(df, tipo='ejecucion')
```

En el argumento `tipo` de cada función se debe especificar si se está trabajando con datos de ejecución o con datos de programación.

La función de `columnas_ingresos_territoriales` permite generar tres columnas para las columnas de ingreso que agregan la información a partir de tres criterios. El primero agrega la información en tres categorías:

- Recursos propios
- Transferencias
- Recursos de capital

La segunda agrega la información en cuatro categorías:

- Ingresos tributarios
- Ingresos no tribugtarios
- Transferencias
- Recursos de capital

La tercera agrega la información teniendo en cuenta las fuentes de ingresos más relevantes tanto para municipios como para departamentos.