from __future__ import annotations
import json
import time
from pathlib import Path

from kanban_framework.types import Task, TaskRun, TaskStatus, Phase, AutoMode, ControlMode
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.infra.config import Config
from kanban_framework.infra.consts import Consts


class TaskNotFoundError(Exception):
    pass


class TaskManager:
    def __init__(self, fs: Filesystem, config: Config):
        self._fs = fs
        self._cfg = config

    def create(self, title: str, description: str, draft: bool = False) -> Task:
        task_id = self._next_task_id()
        status = TaskStatus.DRAFT if draft else TaskStatus.PENDING
        task = Task(id=task_id, title=title, description=description, status=status)
        if not draft:
            task.history.append({
                "phase": "plan",
                "status": "started",
                "started_at": time.time(),
            })
        self._write_task(task)
        # Defensive: ensure task.json always exists (fix #144)
        tf = self._fs.task_dir(task_id) / "task.json"
        if not tf.is_file():
            self._write_task(task)
        if draft:
            self._create_inbox_only(task_id)
        else:
            self._create_task_templates(task_id)
        return task

    def _create_task_templates(self, task_id: str) -> None:
        """Create template files for a new task, including inbox.md."""
        task_dir = self._fs.task_dir(task_id)
        self._fs.ensure_dir(task_dir)

        # Create inbox.md template (natural language, no format restrictions)
        inbox_path = task_dir / "inbox.md"
        if not self._fs.file_exists(inbox_path):
            inbox_path.write_text(
                f"# Task Inbox — {task_id}\n\n"
                f"## 用户反馈渠道\n\n"
                f"在此记录任务相关的用户反馈、改进建议、待办事项等。\n\n"
                f"可以使用自然语言自由记录，LLM 会自动解析和理解。\n\n"
                f"### 示例\n\n"
                f"- 觉得这个功能还需要优化一下性能\n"
                f"- 测试发现边界情况下有问题，需要修复\n"
                f"- 想增加一个导出功能\n\n"
                f"---\n\n"
                f"**提示**: 使用 \\`kanban inbox add {task_id} \"反馈内容\"\\` 添加新事项\n",
                encoding="utf-8"
            )

    def _create_inbox_only(self, task_id: str) -> None:
        """Create only inbox.md for a draft task (no spec/plan templates)."""
        task_dir = self._fs.task_dir(task_id)
        self._fs.ensure_dir(task_dir)
        inbox_path = task_dir / "inbox.md"
        if not self._fs.file_exists(inbox_path):
            inbox_path.write_text(
                f"# Task Inbox — {task_id}\n\n"
                f"## 需求收集\n\n"
                f"在此用自然语言描述需求，模型会自动分析并补全 spec.md。\n\n"
                f"可以填写：功能需求、改进建议、待修复问题、设计想法等。\n\n"
                f"---\n\n"
                f"**提示**: 使用 \\`kanban inbox add {task_id} \"内容\"\\` 或直接编辑此文件\n",
                encoding="utf-8"
            )

    def show(self, task_id: str) -> Task:
        tf = self._fs.task_file(task_id)
        if not self._fs.file_exists(tf):
            raise TaskNotFoundError(f"Task {task_id} not found")
        return self._read_task(tf)

    def status(self) -> dict:
        tasks = []
        seen_ids = set()
        # New format: tasks/TASK-NNN/task.json
        for f in sorted(self._fs.kanban_dir.glob("tasks/TASK-*/task.json")):
            data = json.loads(f.read_text(encoding="utf-8"))
            tasks.append(data)
            seen_ids.add(data.get("id", ""))
        # Old format: tasks/TASK-NNN.json (skip if already found in new format)
        for f in sorted(self._fs.kanban_dir.glob("tasks/TASK-*.json")):
            if f.stem not in seen_ids:
                tasks.append(json.loads(f.read_text(encoding="utf-8")))
        by_status: dict[str, int] = {}
        for t in tasks:
            s = t.get("status", "unknown")
            by_status[s] = by_status.get(s, 0) + 1
        # Sort by priority descending (higher priority first)
        tasks.sort(key=lambda t: t.get("priority", 5), reverse=True)
        return {"total": len(tasks), "by_status": by_status, "tasks": tasks}

    def update(self, task_id: str, **kwargs) -> Task:
        task = self.show(task_id)
        for key, value in kwargs.items():
            if key == "phase" and isinstance(value, str):
                value = Phase(value)
            if key == "status" and isinstance(value, str):
                value = TaskStatus(value)
            if key == "control_mode" and isinstance(value, str):
                value = ControlMode(value)
            if hasattr(task, key):
                setattr(task, key, value)
        self._write_task(task)
        return task

    def record_decision(self, task_id: str, action: str) -> None:
        task = self.show(task_id)
        task.history.append({
            "phase": "user_decision",
            "action": action,
            "timestamp": time.time(),
        })
        self._write_task(task)

    def delete(self, task_id: str) -> None:
        import shutil
        # Remove directory-based task (new format)
        task_dir = self._fs.task_dir(task_id)
        if task_dir.is_dir():
            shutil.rmtree(task_dir)
        # Remove flat file (old format)
        flat = self._fs.kanban_dir / "tasks" / f"{task_id}.json"
        if flat.is_file():
            flat.unlink()

    # ── TaskRun management ──────────────────────────────────────────────

    def create_run(self, task_id: str, phase: str, agent_role: str = "") -> TaskRun:
        """Create a new TaskRun for an agent spawn. Returns the run record."""
        task = self.show(task_id)
        task.total_runs += 1
        task.current_run_id = task.total_runs
        run = TaskRun(
            run_id=task.total_runs,
            task_id=task_id,
            phase=phase,
            agent_role=agent_role,
            status="active",
            started_at=str(time.time()),
        )
        self._write_task(task)
        self._write_run(run)
        return run

    def complete_run(
        self, task_id: str, run_id: int,
        summary: str = "", metadata: dict | None = None
    ) -> TaskRun:
        """Mark a run as completed with handoff summary and metadata."""
        run = self._read_run(task_id, run_id)
        run.status = "completed"
        run.summary = summary
        run.metadata = metadata or {}
        run.ended_at = str(time.time())
        if run.started_at:
            try:
                run.duration_seconds = round(
                    float(run.ended_at) - float(run.started_at), 1
                )
            except (ValueError, TypeError):
                pass
        self._write_run(run)
        return run

    def fail_run(
        self, task_id: str, run_id: int, error: str = ""
    ) -> TaskRun:
        """Mark a run as failed with error description."""
        run = self._read_run(task_id, run_id)
        run.status = "failed"
        run.error = error
        run.ended_at = str(time.time())
        if run.started_at:
            try:
                run.duration_seconds = round(
                    float(run.ended_at) - float(run.started_at), 1
                )
            except (ValueError, TypeError):
                pass
        self._write_run(run)
        return run

    def get_run(self, task_id: str, run_id: int) -> TaskRun | None:
        """Get a specific run record, or None if not found."""
        try:
            return self._read_run(task_id, run_id)
        except (FileNotFoundError, Exception):
            return None

    def list_runs(self, task_id: str) -> list[TaskRun]:
        """List all runs for a task, sorted by run_id."""
        runs_dir = self._fs.task_dir(task_id) / "runs"
        if not runs_dir.is_dir():
            return []
        runs = []
        for rf in sorted(runs_dir.glob("*.json")):
            try:
                data = json.loads(rf.read_text(encoding="utf-8"))
                runs.append(self._run_from_dict(data))
            except (json.JSONDecodeError, Exception):
                pass
        return runs

    def build_worker_context(self, task_id: str) -> dict:
        """Build context object for injection into agent spawn_prompt.

        Includes: prior run attempts, parent task handoff summaries.
        Returns a dict ready for template variable $worker_context.
        """
        ctx: dict = {"prior_runs": [], "parent_handoffs": []}

        # Prior runs for this task (retry context)
        runs = self.list_runs(task_id)
        for r in runs:
            if r.status != "active":
                entry = {
                    "run_id": r.run_id,
                    "phase": r.phase,
                    "agent_role": r.agent_role,
                    "status": r.status,
                }
                if r.summary:
                    entry["summary"] = r.summary
                if r.error:
                    entry["error"] = r.error
                if r.metadata and r.metadata.get("decisions"):
                    entry["decisions"] = r.metadata["decisions"]
                ctx["prior_runs"].append(entry)

        return ctx

    # ── Internal helpers ────────────────────────────────────────────────

    def _runs_dir(self, task_id: str) -> Path:
        d = self._fs.task_dir(task_id) / "runs"
        self._fs.ensure_dir(d)
        return d

    def _run_path(self, task_id: str, run_id: int) -> Path:
        return self._runs_dir(task_id) / f"{run_id:03d}.json"

    def _write_run(self, run: TaskRun) -> None:
        data = {
            "run_id": run.run_id,
            "task_id": run.task_id,
            "phase": run.phase,
            "agent_role": run.agent_role,
            "status": run.status,
            "summary": run.summary,
            "metadata": run.metadata or {},
            "error": run.error,
            "started_at": run.started_at,
            "ended_at": run.ended_at,
            "duration_seconds": run.duration_seconds,
        }
        self._fs.write_json(self._run_path(run.task_id, run.run_id), data)

    def _read_run(self, task_id: str, run_id: int) -> TaskRun:
        data = self._fs.read_json(self._run_path(task_id, run_id))
        return self._run_from_dict(data)

    @staticmethod
    def _run_from_dict(data: dict) -> TaskRun:
        return TaskRun(
            run_id=data["run_id"],
            task_id=data["task_id"],
            phase=data.get("phase", ""),
            agent_role=data.get("agent_role", ""),
            status=data.get("status", "active"),
            summary=data.get("summary", ""),
            metadata=data.get("metadata", {}),
            error=data.get("error", ""),
            started_at=data.get("started_at", ""),
            ended_at=data.get("ended_at", ""),
            duration_seconds=data.get("duration_seconds", 0.0),
        )

    def _next_task_id(self) -> str:
        # Persistent counter with file lock to prevent race conditions (#254)
        counter_file = self._fs.kanban_dir / "next_id.txt"
        base = self._cfg.task_id_base
        default_start = (base * 100 + 1) if base else 1

        import fcntl
        lock_file = None
        try:
            lock_file = open(str(counter_file) + ".lock", "w")
            fcntl.flock(lock_file, fcntl.LOCK_EX)
            if counter_file.is_file():
                try:
                    next_num = int(counter_file.read_text(encoding="utf-8").strip())
                except (ValueError, OSError):
                    next_num = default_start
            else:
                next_num = default_start
        except Exception:
            if counter_file.is_file():
                try:
                    next_num = int(counter_file.read_text(encoding="utf-8").strip())
                except (ValueError, OSError):
                    next_num = default_start
            else:
                next_num = default_start
        finally:
            if lock_file:
                try:
                    fcntl.flock(lock_file, fcntl.LOCK_UN)
                    lock_file.close()
                except Exception:
                    pass

        # Also scan existing tasks/archive to catch any higher IDs (e.g. from
        # older versions that didn't use the counter file)
        for pattern in ("tasks/TASK-*/task.json", "tasks/TASK-*.json",
                        "archive/TASK-*/task.json", "archive/TASK-*.json"):
            for p in self._fs.kanban_dir.glob(pattern):
                parts = p.parts
                for part in parts:
                    if part.startswith("TASK-"):
                        try:
                            n = int(part.replace(".json", "").split("-")[1])
                            if n >= next_num:
                                next_num = n + 1
                        except (IndexError, ValueError):
                            pass
                        break

        task_id = f"{Consts.TASK_ID_PREFIX}{next_num:03d}"
        counter_file.write_text(str(next_num + 1), encoding="utf-8")
        return task_id

    def _read_task(self, path: Path) -> Task:
        import json as _json
        try:
            data = self._fs.read_json(path)
        except (_json.JSONDecodeError, Exception) as e:
            raise TaskNotFoundError(
                f"Failed to parse task file {path}: {e}"
            ) from e
        # Parse auto_mode from JSON
        auto_mode_data = data.get("auto_mode", {})
        if isinstance(auto_mode_data, dict):
            auto_mode = AutoMode(
                auto_brainstorm=auto_mode_data.get("auto_brainstorm", False),
                auto_iteration=auto_mode_data.get("auto_iteration", False),
                auto_lightweight=auto_mode_data.get("auto_lightweight", False),
                auto_archive=auto_mode_data.get("auto_archive", False),
                auto_worktree=auto_mode_data.get("auto_worktree", False),
            )
        elif isinstance(auto_mode_data, bool):
            # Legacy support: boolean -> enable all
            auto_mode = AutoMode(
                auto_brainstorm=auto_mode_data,
                auto_iteration=auto_mode_data,
                auto_lightweight=auto_mode_data,
                auto_archive=auto_mode_data,
                auto_worktree=auto_mode_data,
            )
        else:
            auto_mode = AutoMode()

        # Parse control_mode from JSON, with legacy auto_mode fallback
        control_mode_raw = data.get("control_mode")
        if control_mode_raw in ("auto", "semi", "manual"):
            control_mode = ControlMode(control_mode_raw)
        elif isinstance(auto_mode_data, dict) and all(auto_mode_data.values()):
            # Legacy: all auto_mode flags true -> ControlMode.AUTO
            control_mode = ControlMode.AUTO
        else:
            control_mode = ControlMode.SEMI

        return Task(
            id=data["id"],
            title=data["title"],
            description=data.get("description", ""),
            status=TaskStatus(data.get("status", "pending")),
            phase=Phase(data["phase"]) if data.get("phase") else Phase.PLAN,
            iteration=data.get("iteration", 1),
            lightweight=data.get("lightweight", False),
            mode=data.get("mode", "full"),
            control_mode=control_mode,
            custom_fsm=data.get("custom_fsm"),
            history=data.get("history", []),
            scores=data.get("scores", {}),
            score_history=data.get("score_history", []),
            auto_mode=auto_mode,
            user_decision=data.get("user_decision"),
            test_config=data.get("test_config"),
            current_run_id=data.get("current_run_id", 0),
            total_runs=data.get("total_runs", 0),
        )

    def _write_task(self, task: Task) -> None:
        data = {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "status": task.status.value,
            "phase": task.phase.value,
            "iteration": task.iteration,
            "lightweight": task.lightweight,
            "mode": task.mode,
            "control_mode": task.control_mode.value,
            "custom_fsm": task.custom_fsm,
            "history": task.history,
            "scores": task.scores,
            "score_history": task.score_history,
            "auto_mode": {
                "auto_brainstorm": task.auto_mode.auto_brainstorm,
                "auto_iteration": task.auto_mode.auto_iteration,
                "auto_lightweight": task.auto_mode.auto_lightweight,
                "auto_archive": task.auto_mode.auto_archive,
                "auto_worktree": task.auto_mode.auto_worktree,
            },
            "user_decision": task.user_decision,
            "test_config": task.test_config,
            "current_run_id": task.current_run_id,
            "total_runs": task.total_runs,
        }
        # Always use new directory format: tasks/TASK-NNN/task.json
        task_dir = self._fs.task_dir(task.id)
        self._fs.ensure_dir(task_dir)
        self._fs.write_json(task_dir / "task.json", data)
        # Clean up old flat format to prevent stale data
        old_file = self._fs.kanban_dir / "tasks" / f"{task.id}.json"
        if old_file.is_file():
            old_file.unlink()
