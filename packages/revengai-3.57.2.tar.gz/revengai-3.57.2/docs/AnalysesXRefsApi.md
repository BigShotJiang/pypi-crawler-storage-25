# revengai.AnalysesXRefsApi

All URIs are relative to *https://api.reveng.ai*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_xref_by_vaddr**](AnalysesXRefsApi.md#get_xref_by_vaddr) | **GET** /v2/analyses/{analysis_id}/xrefs/{vaddr} | [Beta] Look up xrefs by virtual address


# **get_xref_by_vaddr**
> BaseResponseXrefResponse get_xref_by_vaddr(analysis_id, vaddr)

[Beta] Look up xrefs by virtual address

**This endpoint is in beta and may change without notice.**

### Example

* Api Key Authentication (APIKey):

```python
import revengai
from revengai.models.base_response_xref_response import BaseResponseXrefResponse
from revengai.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to https://api.reveng.ai
# See configuration.py for a list of all supported configuration parameters.
configuration = revengai.Configuration(
    host = "https://api.reveng.ai"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure API key authorization: APIKey
configuration.api_key['APIKey'] = os.environ["API_KEY"]

# Uncomment below to setup prefix (e.g. Bearer) for API key, if needed
# configuration.api_key_prefix['APIKey'] = 'Bearer'

# Enter a context with an instance of the API client
with revengai.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = revengai.AnalysesXRefsApi(api_client)
    analysis_id = 56 # int | 
    vaddr = 56 # int | Virtual address to match against xrefs

    try:
        # [Beta] Look up xrefs by virtual address
        api_response = api_instance.get_xref_by_vaddr(analysis_id, vaddr)
        print("The response of AnalysesXRefsApi->get_xref_by_vaddr:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AnalysesXRefsApi->get_xref_by_vaddr: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **analysis_id** | **int**|  | 
 **vaddr** | **int**| Virtual address to match against xrefs | 

### Return type

[**BaseResponseXrefResponse**](BaseResponseXrefResponse.md)

### Authorization

[APIKey](../README.md#APIKey)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Successful Response |  -  |
**422** | Invalid request parameters |  -  |
**404** | Xref or analysis cache not found |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

