"""Metapackage marker for aws-resource-validator-security."""
