"""
Authentication backends and views for Vector-generated Django apps.

Provides JWTCookieAuthentication, DevAutoAuthentication, and auth token
exchange views for apps using Vector's hosted auth proxy.
"""

from govector_auth.authentication import DevAutoAuthentication, JWTCookieAuthentication
from govector_auth.views import AuthTokenView, CurrentUserView, LogoutView, TokenRefreshView
from govector_auth.views_billing import EntitlementsView

__all__ = [
    "JWTCookieAuthentication",
    "DevAutoAuthentication",
    "AuthTokenView",
    "TokenRefreshView",
    "CurrentUserView",
    "LogoutView",
    "EntitlementsView",
]
