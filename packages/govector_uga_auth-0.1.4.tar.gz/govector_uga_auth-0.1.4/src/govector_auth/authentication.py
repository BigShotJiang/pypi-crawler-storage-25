"""
DRF authentication backends for Vector-generated apps.

JWTCookieAuthentication reads JWT from HttpOnly cookies with CSRF enforcement.
DevAutoAuthentication provides a fallback dev user when auth is not configured.
"""

import os

from django.conf import settings
from django.contrib.auth import get_user_model
from rest_framework import exceptions
from rest_framework.authentication import BaseAuthentication, CSRFCheck
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError


class JWTCookieAuthentication(JWTAuthentication):
    """
    Authenticates requests via a SimpleJWT access token stored in an
    HttpOnly cookie. Falls back to the standard Authorization header
    when no cookie is present.

    When the token comes from a cookie, CSRF validation is enforced on
    unsafe HTTP methods (POST, PUT, PATCH, DELETE).
    """

    def authenticate(self, request):
        raw_token = request.COOKIES.get(settings.ACCESS_TOKEN_COOKIE)

        if raw_token is not None:
            try:
                validated_token = self.get_validated_token(raw_token.encode())
            except (InvalidToken, TokenError):
                return None

            self.enforce_csrf(request)
            return self.get_user(validated_token), validated_token

        return super().authenticate(request)

    def enforce_csrf(self, request):
        """Enforce CSRF validation for cookie-based authentication."""

        def dummy_get_response(request):
            return None

        check = CSRFCheck(dummy_get_response)
        check.process_request(request)
        reason = check.process_view(request, None, (), {})
        if reason:
            raise exceptions.PermissionDenied(f"CSRF Failed: {reason}")


class DevAutoAuthentication(BaseAuthentication):
    """
    Fallback authentication that auto-authenticates requests when no
    credentials are provided and auth is not configured.

    When VECTOR_AUTH_PROXY_URL is set (auth enabled), returns None so
    unauthenticated requests get a proper 401.
    """

    _cached_user = None

    def authenticate(self, request):
        if os.getenv("VECTOR_AUTH_PROXY_URL"):
            return None

        if DevAutoAuthentication._cached_user is not None:
            return (DevAutoAuthentication._cached_user, None)

        User = get_user_model()
        email = os.getenv("DEV_USER_EMAIL", "dev@localhost")

        user, _ = User.objects.get_or_create(
            email=email,
            defaults={"is_active": True},
        )

        DevAutoAuthentication._cached_user = user
        return (user, None)
