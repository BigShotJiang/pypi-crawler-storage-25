"""
Auth token exchange views for Vector-generated Django apps.

Handles JWT verification from Vector's auth proxy, token refresh,
current user retrieval, and logout with cookie cleanup.
"""

from __future__ import annotations

import base64
import logging
import os

import jwt
import requests as http_requests
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicNumbers
from django.conf import settings as django_settings
from django.contrib.auth import get_user_model
from django.middleware.csrf import get_token
from rest_framework import serializers, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import InvalidToken, TokenError
from rest_framework_simplejwt.tokens import RefreshToken

logger = logging.getLogger(__name__)

User = get_user_model()

_jwks_cache: dict | None = None


def _base64url_decode(s: str) -> bytes:
    """Decode base64url-encoded string (no padding)."""
    s += "=" * (4 - len(s) % 4)
    return base64.urlsafe_b64decode(s)


def _get_jwks() -> dict:
    """Fetch and cache JWKS from Vector's auth proxy."""
    global _jwks_cache
    if _jwks_cache is not None:
        return _jwks_cache

    proxy_url = os.getenv("VECTOR_AUTH_PROXY_URL", "")
    if not proxy_url:
        return {"keys": []}

    jwks_url = f"{proxy_url.rstrip('/')}/.well-known/jwks.json"
    try:
        resp = http_requests.get(jwks_url, timeout=5)
        resp.raise_for_status()
        _jwks_cache = resp.json()
        return _jwks_cache
    except Exception:
        logger.warning("Failed to fetch JWKS from %s", jwks_url, exc_info=True)
        return {"keys": []}


def _get_public_key_from_jwks(kid: str | None = None):
    """Get the RSA public key from the JWKS, optionally matching by kid."""
    jwks = _get_jwks()
    keys = jwks.get("keys", [])
    if not keys:
        return None

    jwk = None
    for key in keys:
        if kid and key.get("kid") == kid:
            jwk = key
            break
    if jwk is None:
        jwk = keys[0]

    n = int.from_bytes(_base64url_decode(jwk["n"]), byteorder="big")
    e = int.from_bytes(_base64url_decode(jwk["e"]), byteorder="big")
    return RSAPublicNumbers(e, n).public_key(default_backend())


class _AuthTokenSerializer(serializers.Serializer):
    token = serializers.CharField()


class AuthTokenView(APIView):
    """POST /api/accounts/auth/token — exchange auth proxy JWT for session."""

    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request: Request) -> Response:
        serializer = _AuthTokenSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        token = serializer.validated_data["token"]

        try:
            unverified_header = jwt.get_unverified_header(token)
        except jwt.DecodeError:
            return Response(
                {"detail": "Invalid token."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        kid = unverified_header.get("kid")
        public_key = _get_public_key_from_jwks(kid)
        if not public_key:
            return Response(
                {"detail": "Authentication is not configured."},
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )

        try:
            payload = jwt.decode(token, public_key, algorithms=["RS256"])
        except jwt.ExpiredSignatureError:
            return Response(
                {"detail": "Token has expired."},
                status=status.HTTP_401_UNAUTHORIZED,
            )
        except jwt.InvalidTokenError:
            return Response(
                {"detail": "Invalid token."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        email = payload.get("email")
        if not email:
            return Response(
                {"detail": "Token missing email claim."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        vector_uga_user_id = payload.get("user_id", "")

        user, created = User.objects.get_or_create(
            email=email,
            defaults={
                "first_name": payload.get("first_name") or "",
                "last_name": payload.get("last_name") or "",
                "picture": payload.get("picture") or "",
                "vector_uga_user_id": vector_uga_user_id,
                "is_active": True,
            },
        )

        if not created:
            updated = False
            for field in ("first_name", "last_name", "picture"):
                new_value = payload.get(field) or ""
                if new_value and getattr(user, field) != new_value:
                    setattr(user, field, new_value)
                    updated = True
            if vector_uga_user_id and user.vector_uga_user_id != vector_uga_user_id:
                user.vector_uga_user_id = vector_uga_user_id
                updated = True
            if updated:
                user.save()

        refresh = RefreshToken.for_user(user)

        response = Response(
            {"user": _serialize_user(user)},
            status=status.HTTP_200_OK,
        )

        _set_auth_cookies(response, refresh)

        response.set_cookie(
            key="uga_jwt",
            value=token,
            max_age=60 * 60 * 24,
            httponly=True,
            secure=django_settings.ACCESS_TOKEN_COOKIE_SECURE,
            samesite=django_settings.ACCESS_TOKEN_COOKIE_SAMESITE,
            path="/",
        )

        get_token(request)
        return response


class TokenRefreshView(APIView):
    """POST /api/accounts/auth/refresh — rotate refresh token."""

    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request: Request) -> Response:
        raw_refresh = request.COOKIES.get(django_settings.REFRESH_TOKEN_COOKIE)
        if not raw_refresh:
            return Response(
                {"detail": "No refresh token."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        try:
            old_refresh = RefreshToken(raw_refresh)
        except (InvalidToken, TokenError):
            response = Response(
                {"detail": "Refresh token expired."},
                status=status.HTTP_401_UNAUTHORIZED,
            )
            _clear_auth_cookies(response)
            return response

        user_id = old_refresh.payload.get("user_id")
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            return Response(
                {"detail": "User not found."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        new_refresh = RefreshToken.for_user(user)
        response = Response(status=status.HTTP_204_NO_CONTENT)
        _set_auth_cookies(response, new_refresh)
        return response


class CurrentUserView(APIView):
    """GET /api/accounts/me/ — returns current authenticated user."""

    permission_classes = [IsAuthenticated]

    def get(self, request: Request) -> Response:
        return Response(
            {"user": _serialize_user(request.user)},
            status=status.HTTP_200_OK,
        )


class LogoutView(APIView):
    """POST /api/accounts/logout/ — clears auth cookies."""

    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request: Request) -> Response:
        response = Response(
            {"detail": "Logged out."},
            status=status.HTTP_200_OK,
        )
        _clear_auth_cookies(response)
        response.delete_cookie(
            key="uga_jwt",
            path="/",
            samesite=django_settings.ACCESS_TOKEN_COOKIE_SAMESITE,
        )
        return response


def _serialize_user(user) -> dict:
    """Serialize user to dict without depending on app-specific serializers."""
    return {
        "id": user.pk,
        "email": user.email,
        "first_name": getattr(user, "first_name", ""),
        "last_name": getattr(user, "last_name", ""),
        "full_name": getattr(user, "full_name", user.email),
        "picture": getattr(user, "picture", ""),
    }


def _set_auth_cookies(response: Response, refresh: RefreshToken) -> None:
    """Set access and refresh token cookies on response."""
    response.set_cookie(
        key=django_settings.ACCESS_TOKEN_COOKIE,
        value=str(refresh.access_token),
        max_age=django_settings.ACCESS_TOKEN_COOKIE_MAX_AGE,
        httponly=django_settings.ACCESS_TOKEN_COOKIE_HTTPONLY,
        secure=django_settings.ACCESS_TOKEN_COOKIE_SECURE,
        samesite=django_settings.ACCESS_TOKEN_COOKIE_SAMESITE,
        path=django_settings.ACCESS_TOKEN_COOKIE_PATH,
    )
    response.set_cookie(
        key=django_settings.REFRESH_TOKEN_COOKIE,
        value=str(refresh),
        max_age=django_settings.REFRESH_TOKEN_COOKIE_MAX_AGE,
        httponly=django_settings.REFRESH_TOKEN_COOKIE_HTTPONLY,
        secure=django_settings.REFRESH_TOKEN_COOKIE_SECURE,
        samesite=django_settings.REFRESH_TOKEN_COOKIE_SAMESITE,
        path=django_settings.REFRESH_TOKEN_COOKIE_PATH,
    )


def _clear_auth_cookies(response: Response) -> None:
    """Clear access and refresh token cookies."""
    response.delete_cookie(
        key=django_settings.ACCESS_TOKEN_COOKIE,
        path=django_settings.ACCESS_TOKEN_COOKIE_PATH,
        samesite=django_settings.ACCESS_TOKEN_COOKIE_SAMESITE,
    )
    response.delete_cookie(
        key=django_settings.REFRESH_TOKEN_COOKIE,
        path=django_settings.REFRESH_TOKEN_COOKIE_PATH,
        samesite=django_settings.REFRESH_TOKEN_COOKIE_SAMESITE,
    )
