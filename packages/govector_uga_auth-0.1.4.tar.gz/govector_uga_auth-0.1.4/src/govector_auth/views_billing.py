"""
Entitlements proxy view for UGA billing.

Proxies entitlements requests from the UGA frontend to Vector's API.
Uses the local user's vector_uga_user_id to identify the user to Vector.

This keeps auth same-origin (local SimpleJWT cookies work) while allowing
the UGA to check subscription status via Vector's API.

Route: GET /api/accounts/billing/entitlements/
"""

from __future__ import annotations

import logging
import os

import requests as http_requests
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView

logger = logging.getLogger(__name__)

VECTOR_API_URL = os.getenv("VECTOR_API_URL", "")
VECTOR_APP_ID = os.getenv("VITE_APP_ID", "")
VECTOR_API_TOKEN = os.getenv("VECTOR_API_TOKEN", "")
VECTOR_ORIGIN = os.getenv("VECTOR_ORIGIN", "")


class EntitlementsView(APIView):
    """GET /api/accounts/billing/entitlements/

    Proxies entitlements check to Vector's API.

    Returns:
    - 401: User not authenticated (needs login)
    - 200 with allowed=true: User has subscription access
    - 200 with allowed=false: User needs subscription (includes redirect_link)
    """

    permission_classes = [IsAuthenticated]

    def get(self, request: Request) -> Response:
        user = request.user

        # Get the Vector UGAUser ID from the local user
        vector_uga_user_id = getattr(user, "vector_uga_user_id", None)
        if not vector_uga_user_id:
            logger.warning(
                "User %s has no vector_uga_user_id, cannot check entitlements",
                user.id,
            )
            # Return allowed=true so app doesn't block, but log the issue
            return self._fallback_response("no-vector-user-id")

        # Call Vector's entitlements API
        if not VECTOR_API_URL or not VECTOR_APP_ID:
            # Billing not configured - allow access (app is free or not using billing)
            return self._fallback_response("not-configured")

        try:
            url = f"{VECTOR_API_URL}/api/user-billing/apps/{VECTOR_APP_ID}/entitlements/"
            headers = {
                "X-UGA-Api-Token": VECTOR_API_TOKEN,
                "X-Vector-UGA-User-Id": str(vector_uga_user_id),
            }
            if VECTOR_ORIGIN:
                headers["X-Vector-Origin"] = VECTOR_ORIGIN

            response = http_requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()

            return Response(response.json(), status=status.HTTP_200_OK)

        except http_requests.exceptions.HTTPError as e:
            logger.error("Vector entitlements API error: %s", e)
            return self._fallback_response("api-error")
        except http_requests.exceptions.RequestException as e:
            logger.error("Vector entitlements API request failed: %s", e)
            return self._fallback_response("network-error")

    def _fallback_response(self, reason: str) -> Response:
        """Return a fallback 'allowed' response when we can't reach Vector."""
        return Response(
            {
                "entitlements": [
                    {
                        "type": "platform",
                        "status": None,
                        "allowed": True,
                        "redirect_link": None,
                    }
                ],
                "cache": {
                    "expires_at": None,
                    "version": f"fallback-{reason}",
                },
            },
            status=status.HTTP_200_OK,
        )
