from django.urls import path

from govector_auth import AuthTokenView, CurrentUserView, EntitlementsView, LogoutView, TokenRefreshView

urlpatterns = [
    path("api/accounts/auth/token", AuthTokenView.as_view()),
    path("api/accounts/auth/refresh", TokenRefreshView.as_view()),
    path("api/accounts/me/", CurrentUserView.as_view()),
    path("api/accounts/logout/", LogoutView.as_view()),
    path("api/accounts/billing/entitlements/", EntitlementsView.as_view()),
]
