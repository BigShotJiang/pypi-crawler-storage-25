from unittest.mock import patch, MagicMock

import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

User = get_user_model()


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user(db):
    return User.objects.create_user(username="testuser", email="test@example.com", password="testpass")


class TestEntitlementsView:
    def test_returns_401_when_unauthenticated(self, api_client, db):
        response = api_client.get("/api/accounts/billing/entitlements/")
        assert response.status_code == 401

    def test_returns_fallback_when_no_vector_user_id(self, api_client, user):
        api_client.force_authenticate(user=user)
        response = api_client.get("/api/accounts/billing/entitlements/")
        assert response.status_code == 200
        assert response.data["entitlements"][0]["allowed"] is True
        assert response.data["cache"]["version"] == "fallback-no-vector-user-id"

    @patch("govector_auth.views_billing.VECTOR_API_URL", "")
    @patch("govector_auth.views_billing.VECTOR_APP_ID", "")
    def test_returns_fallback_when_not_configured(self, api_client, user):
        user.vector_uga_user_id = "uga-123"
        user.save()
        api_client.force_authenticate(user=user)
        response = api_client.get("/api/accounts/billing/entitlements/")
        assert response.status_code == 200
        assert response.data["cache"]["version"] == "fallback-not-configured"

    @patch("govector_auth.views_billing.http_requests.get")
    @patch("govector_auth.views_billing.VECTOR_APP_ID", "app-1")
    @patch("govector_auth.views_billing.VECTOR_API_URL", "https://api.vector.test")
    def test_proxies_to_vector_api(self, mock_get, api_client, user):
        user.vector_uga_user_id = "uga-123"
        user.save()
        api_client.force_authenticate(user=user)

        mock_response = MagicMock()
        mock_response.json.return_value = {
            "entitlements": [{"type": "platform", "status": "active", "allowed": True, "redirect_link": None}],
            "cache": {"expires_at": "2026-04-01T00:00:00Z", "version": "v1"},
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response

        response = api_client.get("/api/accounts/billing/entitlements/")
        assert response.status_code == 200
        assert response.data["entitlements"][0]["allowed"] is True

        mock_get.assert_called_once()
        call_args = mock_get.call_args
        assert "uga-123" in call_args[1]["headers"]["X-Vector-UGA-User-Id"]

    @patch("govector_auth.views_billing.http_requests.get")
    @patch("govector_auth.views_billing.VECTOR_APP_ID", "app-1")
    @patch("govector_auth.views_billing.VECTOR_API_URL", "https://api.vector.test")
    def test_returns_fallback_on_network_error(self, mock_get, api_client, user):
        import requests
        user.vector_uga_user_id = "uga-123"
        user.save()
        api_client.force_authenticate(user=user)

        mock_get.side_effect = requests.exceptions.ConnectionError("connection refused")

        response = api_client.get("/api/accounts/billing/entitlements/")
        assert response.status_code == 200
        assert response.data["cache"]["version"] == "fallback-network-error"
