import os
from unittest.mock import patch

import pytest
from django.contrib.auth import get_user_model
from django.test import RequestFactory
from rest_framework_simplejwt.tokens import RefreshToken

from govector_auth.authentication import DevAutoAuthentication, JWTCookieAuthentication

User = get_user_model()


@pytest.fixture
def user(db):
    return User.objects.create_user(username="testuser", email="test@example.com", password="testpass")


@pytest.fixture
def rf():
    return RequestFactory()


class TestJWTCookieAuthentication:
    def test_authenticates_from_cookie(self, user, rf):
        refresh = RefreshToken.for_user(user)
        access_token = str(refresh.access_token)

        request = rf.get("/", HTTP_COOKIE=f"access_token={access_token}")
        request.META["HTTP_X_CSRFTOKEN"] = "fake"
        # GET requests don't need CSRF
        auth = JWTCookieAuthentication()
        result = auth.authenticate(request)

        assert result is not None
        auth_user, token = result
        assert auth_user.pk == user.pk

    def test_returns_none_for_invalid_cookie(self, rf):
        request = rf.get("/", HTTP_COOKIE="access_token=invalid-token")
        auth = JWTCookieAuthentication()
        result = auth.authenticate(request)
        assert result is None

    def test_returns_none_when_no_cookie(self, rf):
        request = rf.get("/")
        request.META["HTTP_AUTHORIZATION"] = ""
        auth = JWTCookieAuthentication()
        result = auth.authenticate(request)
        assert result is None


class TestDevAutoAuthentication:
    def test_creates_dev_user_when_auth_not_configured(self, db, rf):
        DevAutoAuthentication._cached_user = None
        request = rf.get("/")

        with patch.dict(os.environ, {}, clear=True):
            auth = DevAutoAuthentication()
            result = auth.authenticate(request)

        assert result is not None
        dev_user, _ = result
        assert dev_user.email == "dev@localhost"

    def test_returns_none_when_auth_is_configured(self, rf):
        DevAutoAuthentication._cached_user = None
        request = rf.get("/")

        with patch.dict(os.environ, {"VECTOR_AUTH_PROXY_URL": "https://auth.example.com"}):
            auth = DevAutoAuthentication()
            result = auth.authenticate(request)

        assert result is None

    def test_uses_custom_dev_email(self, db, rf):
        DevAutoAuthentication._cached_user = None
        request = rf.get("/")

        with patch.dict(os.environ, {"DEV_USER_EMAIL": "custom@dev.local"}, clear=True):
            auth = DevAutoAuthentication()
            result = auth.authenticate(request)

        assert result is not None
        assert result[0].email == "custom@dev.local"

    def test_caches_dev_user(self, db, rf):
        DevAutoAuthentication._cached_user = None
        request = rf.get("/")

        with patch.dict(os.environ, {}, clear=True):
            auth = DevAutoAuthentication()
            result1 = auth.authenticate(request)
            result2 = auth.authenticate(request)

        assert result1[0].pk == result2[0].pk
        assert DevAutoAuthentication._cached_user is not None
