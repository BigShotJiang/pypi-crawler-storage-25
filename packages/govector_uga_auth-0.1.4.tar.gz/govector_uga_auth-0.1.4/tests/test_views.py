import pytest
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import RefreshToken

User = get_user_model()


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user(db):
    return User.objects.create_user(username="testuser", email="test@example.com", password="testpass")


class TestCurrentUserView:
    def test_returns_user_when_authenticated(self, api_client, user):
        api_client.force_authenticate(user=user)
        response = api_client.get("/api/accounts/me/")
        assert response.status_code == 200
        assert response.data["user"]["email"] == "test@example.com"

    def test_returns_401_when_unauthenticated(self, api_client, db):
        response = api_client.get("/api/accounts/me/")
        assert response.status_code == 401


class TestLogoutView:
    def test_clears_cookies(self, api_client, db):
        response = api_client.post("/api/accounts/logout/")
        assert response.status_code == 200
        assert response.data["detail"] == "Logged out."
        # Check cookies are deleted
        cookies = {c.key: c for c in response.cookies.values()}
        if "access_token" in cookies:
            assert cookies["access_token"]["max-age"] == 0


class TestTokenRefreshView:
    def test_refreshes_token(self, api_client, user):
        refresh = RefreshToken.for_user(user)
        api_client.cookies["refresh_token"] = str(refresh)
        response = api_client.post("/api/accounts/auth/refresh")
        assert response.status_code == 204
        assert "access_token" in response.cookies
        assert "refresh_token" in response.cookies

    def test_returns_401_without_refresh_token(self, api_client, db):
        response = api_client.post("/api/accounts/auth/refresh")
        assert response.status_code == 401

    def test_returns_401_with_invalid_refresh_token(self, api_client, db):
        api_client.cookies["refresh_token"] = "invalid-token"
        response = api_client.post("/api/accounts/auth/refresh")
        assert response.status_code == 401


class TestAuthTokenView:
    def test_returns_401_for_invalid_token(self, api_client, db):
        response = api_client.post("/api/accounts/auth/token", {"token": "invalid"})
        assert response.status_code == 401

    def test_returns_400_without_token(self, api_client, db):
        response = api_client.post("/api/accounts/auth/token", {})
        assert response.status_code == 400
