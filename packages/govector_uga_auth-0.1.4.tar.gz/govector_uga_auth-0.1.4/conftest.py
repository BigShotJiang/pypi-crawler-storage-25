import django
from django.conf import settings


def pytest_configure():
    settings.configure(
        DATABASES={
            "default": {
                "ENGINE": "django.db.backends.sqlite3",
                "NAME": ":memory:",
            }
        },
        INSTALLED_APPS=[
            "django.contrib.contenttypes",
            "django.contrib.auth",
            "rest_framework",
        ],
        ROOT_URLCONF="tests.urls",
        REST_FRAMEWORK={
            "DEFAULT_AUTHENTICATION_CLASSES": [
                "govector_auth.JWTCookieAuthentication",
            ],
        },
        # SimpleJWT settings
        SIMPLE_JWT={
            "AUTH_HEADER_TYPES": ("Bearer",),
        },
        # Cookie settings required by govector_auth
        ACCESS_TOKEN_COOKIE="access_token",
        REFRESH_TOKEN_COOKIE="refresh_token",
        ACCESS_TOKEN_COOKIE_MAX_AGE=300,
        ACCESS_TOKEN_COOKIE_HTTPONLY=True,
        ACCESS_TOKEN_COOKIE_SECURE=False,
        ACCESS_TOKEN_COOKIE_SAMESITE="Lax",
        ACCESS_TOKEN_COOKIE_PATH="/",
        REFRESH_TOKEN_COOKIE_MAX_AGE=604800,
        REFRESH_TOKEN_COOKIE_HTTPONLY=True,
        REFRESH_TOKEN_COOKIE_SECURE=False,
        REFRESH_TOKEN_COOKIE_SAMESITE="Lax",
        REFRESH_TOKEN_COOKIE_PATH="/",
        SECRET_KEY="test-secret-key-not-for-production",
    )
    django.setup()
