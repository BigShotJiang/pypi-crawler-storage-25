from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ActivityOut")


@_attrs_define
class ActivityOut:
    """
    Attributes:
        id (int):
        user_id (int | None):
        action (str):
        resource_type (None | str):
        resource_id (None | str):
        summary (str):
        created_at (str):
    """

    id: int
    user_id: int | None
    action: str
    resource_type: None | str
    resource_id: None | str
    summary: str
    created_at: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        user_id: int | None
        user_id = self.user_id

        action = self.action

        resource_type: None | str
        resource_type = self.resource_type

        resource_id: None | str
        resource_id = self.resource_id

        summary = self.summary

        created_at = self.created_at

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "user_id": user_id,
                "action": action,
                "resource_type": resource_type,
                "resource_id": resource_id,
                "summary": summary,
                "created_at": created_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        def _parse_user_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        user_id = _parse_user_id(d.pop("user_id"))

        action = d.pop("action")

        def _parse_resource_type(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        resource_type = _parse_resource_type(d.pop("resource_type"))

        def _parse_resource_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        resource_id = _parse_resource_id(d.pop("resource_id"))

        summary = d.pop("summary")

        created_at = d.pop("created_at")

        activity_out = cls(
            id=id,
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            summary=summary,
            created_at=created_at,
        )

        activity_out.additional_properties = d
        return activity_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
