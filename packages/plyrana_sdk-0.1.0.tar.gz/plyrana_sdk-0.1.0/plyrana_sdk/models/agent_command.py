from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_command_payload import AgentCommandPayload


T = TypeVar("T", bound="AgentCommand")


@_attrs_define
class AgentCommand:
    """
    Attributes:
        id (str):
        type_ (str):
        payload (AgentCommandPayload | Unset):
    """

    id: str
    type_: str
    payload: AgentCommandPayload | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        type_ = self.type_

        payload: dict[str, Any] | Unset = UNSET
        if not isinstance(self.payload, Unset):
            payload = self.payload.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "type": type_,
            }
        )
        if payload is not UNSET:
            field_dict["payload"] = payload

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_command_payload import AgentCommandPayload

        d = dict(src_dict)
        id = d.pop("id")

        type_ = d.pop("type")

        _payload = d.pop("payload", UNSET)
        payload: AgentCommandPayload | Unset
        if isinstance(_payload, Unset):
            payload = UNSET
        else:
            payload = AgentCommandPayload.from_dict(_payload)

        agent_command = cls(
            id=id,
            type_=type_,
            payload=payload,
        )

        agent_command.additional_properties = d
        return agent_command

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
