from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.automation_fire_log_out_context_json import AutomationFireLogOutContextJson


T = TypeVar("T", bound="AutomationFireLogOut")


@_attrs_define
class AutomationFireLogOut:
    """
    Attributes:
        id (int):
        rule_id (int):
        fired_at (datetime.datetime):
        success (bool):
        error_message (None | str | Unset):
        context_json (AutomationFireLogOutContextJson | Unset):
    """

    id: int
    rule_id: int
    fired_at: datetime.datetime
    success: bool
    error_message: None | str | Unset = UNSET
    context_json: AutomationFireLogOutContextJson | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        rule_id = self.rule_id

        fired_at = self.fired_at.isoformat()

        success = self.success

        error_message: None | str | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        else:
            error_message = self.error_message

        context_json: dict[str, Any] | Unset = UNSET
        if not isinstance(self.context_json, Unset):
            context_json = self.context_json.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "rule_id": rule_id,
                "fired_at": fired_at,
                "success": success,
            }
        )
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if context_json is not UNSET:
            field_dict["context_json"] = context_json

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.automation_fire_log_out_context_json import AutomationFireLogOutContextJson

        d = dict(src_dict)
        id = d.pop("id")

        rule_id = d.pop("rule_id")

        fired_at = isoparse(d.pop("fired_at"))

        success = d.pop("success")

        def _parse_error_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        _context_json = d.pop("context_json", UNSET)
        context_json: AutomationFireLogOutContextJson | Unset
        if isinstance(_context_json, Unset):
            context_json = UNSET
        else:
            context_json = AutomationFireLogOutContextJson.from_dict(_context_json)

        automation_fire_log_out = cls(
            id=id,
            rule_id=rule_id,
            fired_at=fired_at,
            success=success,
            error_message=error_message,
            context_json=context_json,
        )

        automation_fire_log_out.additional_properties = d
        return automation_fire_log_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
