from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.alert_rule_create_in_condition_config import AlertRuleCreateInConditionConfig


T = TypeVar("T", bound="AlertRuleCreateIn")


@_attrs_define
class AlertRuleCreateIn:
    """
    Attributes:
        name (str):
        condition_type (str):
        condition_config (AlertRuleCreateInConditionConfig | Unset):
        entity_id (None | str | Unset):
        severity (str | Unset):  Default: 'warning'.
        enabled (bool | Unset):  Default: True.
        cooldown_seconds (int | Unset):  Default: 300.
    """

    name: str
    condition_type: str
    condition_config: AlertRuleCreateInConditionConfig | Unset = UNSET
    entity_id: None | str | Unset = UNSET
    severity: str | Unset = "warning"
    enabled: bool | Unset = True
    cooldown_seconds: int | Unset = 300
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        condition_type = self.condition_type

        condition_config: dict[str, Any] | Unset = UNSET
        if not isinstance(self.condition_config, Unset):
            condition_config = self.condition_config.to_dict()

        entity_id: None | str | Unset
        if isinstance(self.entity_id, Unset):
            entity_id = UNSET
        else:
            entity_id = self.entity_id

        severity = self.severity

        enabled = self.enabled

        cooldown_seconds = self.cooldown_seconds

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "condition_type": condition_type,
            }
        )
        if condition_config is not UNSET:
            field_dict["condition_config"] = condition_config
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id
        if severity is not UNSET:
            field_dict["severity"] = severity
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if cooldown_seconds is not UNSET:
            field_dict["cooldown_seconds"] = cooldown_seconds

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_rule_create_in_condition_config import AlertRuleCreateInConditionConfig

        d = dict(src_dict)
        name = d.pop("name")

        condition_type = d.pop("condition_type")

        _condition_config = d.pop("condition_config", UNSET)
        condition_config: AlertRuleCreateInConditionConfig | Unset
        if isinstance(_condition_config, Unset):
            condition_config = UNSET
        else:
            condition_config = AlertRuleCreateInConditionConfig.from_dict(_condition_config)

        def _parse_entity_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        entity_id = _parse_entity_id(d.pop("entity_id", UNSET))

        severity = d.pop("severity", UNSET)

        enabled = d.pop("enabled", UNSET)

        cooldown_seconds = d.pop("cooldown_seconds", UNSET)

        alert_rule_create_in = cls(
            name=name,
            condition_type=condition_type,
            condition_config=condition_config,
            entity_id=entity_id,
            severity=severity,
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
        )

        alert_rule_create_in.additional_properties = d
        return alert_rule_create_in

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
