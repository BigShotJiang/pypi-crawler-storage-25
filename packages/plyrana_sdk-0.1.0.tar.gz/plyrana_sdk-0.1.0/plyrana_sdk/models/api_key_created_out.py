from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ApiKeyCreatedOut")


@_attrs_define
class ApiKeyCreatedOut:
    """
    Attributes:
        id (int):
        name (str):
        key_prefix (str):
        caps (list[str]):
        expires_at (None | str):
        last_used_at (None | str):
        revoked (bool):
        created_at (str):
        key (str):
    """

    id: int
    name: str
    key_prefix: str
    caps: list[str]
    expires_at: None | str
    last_used_at: None | str
    revoked: bool
    created_at: str
    key: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        key_prefix = self.key_prefix

        caps = self.caps

        expires_at: None | str
        expires_at = self.expires_at

        last_used_at: None | str
        last_used_at = self.last_used_at

        revoked = self.revoked

        created_at = self.created_at

        key = self.key

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "key_prefix": key_prefix,
                "caps": caps,
                "expires_at": expires_at,
                "last_used_at": last_used_at,
                "revoked": revoked,
                "created_at": created_at,
                "key": key,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        key_prefix = d.pop("key_prefix")

        caps = cast(list[str], d.pop("caps"))

        def _parse_expires_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        expires_at = _parse_expires_at(d.pop("expires_at"))

        def _parse_last_used_at(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_used_at = _parse_last_used_at(d.pop("last_used_at"))

        revoked = d.pop("revoked")

        created_at = d.pop("created_at")

        key = d.pop("key")

        api_key_created_out = cls(
            id=id,
            name=name,
            key_prefix=key_prefix,
            caps=caps,
            expires_at=expires_at,
            last_used_at=last_used_at,
            revoked=revoked,
            created_at=created_at,
            key=key,
        )

        api_key_created_out.additional_properties = d
        return api_key_created_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
