from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentHeartbeatRequest")


@_attrs_define
class AgentHeartbeatRequest:
    """
    Attributes:
        uptime (float | Unset):  Default: 0.0.
        status (str | Unset):  Default: 'alive'.
    """

    uptime: float | Unset = 0.0
    status: str | Unset = "alive"
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        uptime = self.uptime

        status = self.status

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if uptime is not UNSET:
            field_dict["uptime"] = uptime
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        uptime = d.pop("uptime", UNSET)

        status = d.pop("status", UNSET)

        agent_heartbeat_request = cls(
            uptime=uptime,
            status=status,
        )

        agent_heartbeat_request.additional_properties = d
        return agent_heartbeat_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
