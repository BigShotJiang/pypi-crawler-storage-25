from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentHandshakeResponse")


@_attrs_define
class AgentHandshakeResponse:
    """
    Attributes:
        status (str):
        device_id (int):
        device_uid (str):
        server_version (str | Unset):  Default: '0.1.0'.
        heartbeat_interval (int | Unset):  Default: 30.
        telemetry_interval (int | Unset):  Default: 60.
    """

    status: str
    device_id: int
    device_uid: str
    server_version: str | Unset = "0.1.0"
    heartbeat_interval: int | Unset = 30
    telemetry_interval: int | Unset = 60
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        status = self.status

        device_id = self.device_id

        device_uid = self.device_uid

        server_version = self.server_version

        heartbeat_interval = self.heartbeat_interval

        telemetry_interval = self.telemetry_interval

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "status": status,
                "device_id": device_id,
                "device_uid": device_uid,
            }
        )
        if server_version is not UNSET:
            field_dict["server_version"] = server_version
        if heartbeat_interval is not UNSET:
            field_dict["heartbeat_interval"] = heartbeat_interval
        if telemetry_interval is not UNSET:
            field_dict["telemetry_interval"] = telemetry_interval

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = d.pop("status")

        device_id = d.pop("device_id")

        device_uid = d.pop("device_uid")

        server_version = d.pop("server_version", UNSET)

        heartbeat_interval = d.pop("heartbeat_interval", UNSET)

        telemetry_interval = d.pop("telemetry_interval", UNSET)

        agent_handshake_response = cls(
            status=status,
            device_id=device_id,
            device_uid=device_uid,
            server_version=server_version,
            heartbeat_interval=heartbeat_interval,
            telemetry_interval=telemetry_interval,
        )

        agent_handshake_response.additional_properties = d
        return agent_handshake_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
