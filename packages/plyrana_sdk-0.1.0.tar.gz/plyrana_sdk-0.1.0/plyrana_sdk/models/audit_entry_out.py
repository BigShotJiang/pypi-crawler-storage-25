from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_entry_out_metadata_type_0 import AuditEntryOutMetadataType0


T = TypeVar("T", bound="AuditEntryOut")


@_attrs_define
class AuditEntryOut:
    """
    Attributes:
        id (int):
        ts (datetime.datetime):
        actor_type (str):
        actor_id (str):
        action (str):
        resource (None | str):
        trace_id (None | str):
        metadata (AuditEntryOutMetadataType0 | None | Unset):
    """

    id: int
    ts: datetime.datetime
    actor_type: str
    actor_id: str
    action: str
    resource: None | str
    trace_id: None | str
    metadata: AuditEntryOutMetadataType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.audit_entry_out_metadata_type_0 import AuditEntryOutMetadataType0

        id = self.id

        ts = self.ts.isoformat()

        actor_type = self.actor_type

        actor_id = self.actor_id

        action = self.action

        resource: None | str
        resource = self.resource

        trace_id: None | str
        trace_id = self.trace_id

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, AuditEntryOutMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "ts": ts,
                "actor_type": actor_type,
                "actor_id": actor_id,
                "action": action,
                "resource": resource,
                "trace_id": trace_id,
            }
        )
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_entry_out_metadata_type_0 import AuditEntryOutMetadataType0

        d = dict(src_dict)
        id = d.pop("id")

        ts = isoparse(d.pop("ts"))

        actor_type = d.pop("actor_type")

        actor_id = d.pop("actor_id")

        action = d.pop("action")

        def _parse_resource(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        resource = _parse_resource(d.pop("resource"))

        def _parse_trace_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        trace_id = _parse_trace_id(d.pop("trace_id"))

        def _parse_metadata(data: object) -> AuditEntryOutMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = AuditEntryOutMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuditEntryOutMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        audit_entry_out = cls(
            id=id,
            ts=ts,
            actor_type=actor_type,
            actor_id=actor_id,
            action=action,
            resource=resource,
            trace_id=trace_id,
            metadata=metadata,
        )

        audit_entry_out.additional_properties = d
        return audit_entry_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
