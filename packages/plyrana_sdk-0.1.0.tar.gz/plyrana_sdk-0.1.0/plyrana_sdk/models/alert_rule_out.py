from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.alert_rule_out_condition_config import AlertRuleOutConditionConfig


T = TypeVar("T", bound="AlertRuleOut")


@_attrs_define
class AlertRuleOut:
    """
    Attributes:
        id (int):
        name (str):
        condition_type (str):
        condition_config (AlertRuleOutConditionConfig):
        entity_id (None | str):
        severity (str):
        enabled (bool):
        cooldown_seconds (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
    """

    id: int
    name: str
    condition_type: str
    condition_config: AlertRuleOutConditionConfig
    entity_id: None | str
    severity: str
    enabled: bool
    cooldown_seconds: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        condition_type = self.condition_type

        condition_config = self.condition_config.to_dict()

        entity_id: None | str
        entity_id = self.entity_id

        severity = self.severity

        enabled = self.enabled

        cooldown_seconds = self.cooldown_seconds

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "name": name,
                "condition_type": condition_type,
                "condition_config": condition_config,
                "entity_id": entity_id,
                "severity": severity,
                "enabled": enabled,
                "cooldown_seconds": cooldown_seconds,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_rule_out_condition_config import AlertRuleOutConditionConfig

        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        condition_type = d.pop("condition_type")

        condition_config = AlertRuleOutConditionConfig.from_dict(d.pop("condition_config"))

        def _parse_entity_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        entity_id = _parse_entity_id(d.pop("entity_id"))

        severity = d.pop("severity")

        enabled = d.pop("enabled")

        cooldown_seconds = d.pop("cooldown_seconds")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        alert_rule_out = cls(
            id=id,
            name=name,
            condition_type=condition_type,
            condition_config=condition_config,
            entity_id=entity_id,
            severity=severity,
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
            created_at=created_at,
            updated_at=updated_at,
        )

        alert_rule_out.additional_properties = d
        return alert_rule_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
