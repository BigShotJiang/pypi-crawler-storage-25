from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AnnotationQuery")


@_attrs_define
class AnnotationQuery:
    """
    Attributes:
        name (None | str | Unset):
        datasource (None | str | Unset):
        icon_color (None | str | Unset):
        enable (bool | Unset):  Default: True.
    """

    name: None | str | Unset = UNSET
    datasource: None | str | Unset = UNSET
    icon_color: None | str | Unset = UNSET
    enable: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        datasource: None | str | Unset
        if isinstance(self.datasource, Unset):
            datasource = UNSET
        else:
            datasource = self.datasource

        icon_color: None | str | Unset
        if isinstance(self.icon_color, Unset):
            icon_color = UNSET
        else:
            icon_color = self.icon_color

        enable = self.enable

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if datasource is not UNSET:
            field_dict["datasource"] = datasource
        if icon_color is not UNSET:
            field_dict["iconColor"] = icon_color
        if enable is not UNSET:
            field_dict["enable"] = enable

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_datasource(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        datasource = _parse_datasource(d.pop("datasource", UNSET))

        def _parse_icon_color(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        icon_color = _parse_icon_color(d.pop("iconColor", UNSET))

        enable = d.pop("enable", UNSET)

        annotation_query = cls(
            name=name,
            datasource=datasource,
            icon_color=icon_color,
            enable=enable,
        )

        annotation_query.additional_properties = d
        return annotation_query

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
