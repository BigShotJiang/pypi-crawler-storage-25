from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AgentHandshakeRequest")


@_attrs_define
class AgentHandshakeRequest:
    """
    Attributes:
        agent_version (str):
        platform (str):
        hostname (str):
        capabilities (list[str] | Unset):
    """

    agent_version: str
    platform: str
    hostname: str
    capabilities: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_version = self.agent_version

        platform = self.platform

        hostname = self.hostname

        capabilities: list[str] | Unset = UNSET
        if not isinstance(self.capabilities, Unset):
            capabilities = self.capabilities

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_version": agent_version,
                "platform": platform,
                "hostname": hostname,
            }
        )
        if capabilities is not UNSET:
            field_dict["capabilities"] = capabilities

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_version = d.pop("agent_version")

        platform = d.pop("platform")

        hostname = d.pop("hostname")

        capabilities = cast(list[str], d.pop("capabilities", UNSET))

        agent_handshake_request = cls(
            agent_version=agent_version,
            platform=platform,
            hostname=hostname,
            capabilities=capabilities,
        )

        agent_handshake_request.additional_properties = d
        return agent_handshake_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
