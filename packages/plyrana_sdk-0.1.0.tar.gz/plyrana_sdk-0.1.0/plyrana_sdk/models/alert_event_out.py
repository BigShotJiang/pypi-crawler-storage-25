from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

T = TypeVar("T", bound="AlertEventOut")


@_attrs_define
class AlertEventOut:
    """
    Attributes:
        id (int):
        rule_id (int):
        entity_id (None | str):
        device_id (int | None):
        status (str):
        message (str):
        triggered_at (datetime.datetime):
        acknowledged_at (datetime.datetime | None):
        resolved_at (datetime.datetime | None):
        acknowledged_by (None | str):
    """

    id: int
    rule_id: int
    entity_id: None | str
    device_id: int | None
    status: str
    message: str
    triggered_at: datetime.datetime
    acknowledged_at: datetime.datetime | None
    resolved_at: datetime.datetime | None
    acknowledged_by: None | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        rule_id = self.rule_id

        entity_id: None | str
        entity_id = self.entity_id

        device_id: int | None
        device_id = self.device_id

        status = self.status

        message = self.message

        triggered_at = self.triggered_at.isoformat()

        acknowledged_at: None | str
        if isinstance(self.acknowledged_at, datetime.datetime):
            acknowledged_at = self.acknowledged_at.isoformat()
        else:
            acknowledged_at = self.acknowledged_at

        resolved_at: None | str
        if isinstance(self.resolved_at, datetime.datetime):
            resolved_at = self.resolved_at.isoformat()
        else:
            resolved_at = self.resolved_at

        acknowledged_by: None | str
        acknowledged_by = self.acknowledged_by

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "rule_id": rule_id,
                "entity_id": entity_id,
                "device_id": device_id,
                "status": status,
                "message": message,
                "triggered_at": triggered_at,
                "acknowledged_at": acknowledged_at,
                "resolved_at": resolved_at,
                "acknowledged_by": acknowledged_by,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        rule_id = d.pop("rule_id")

        def _parse_entity_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        entity_id = _parse_entity_id(d.pop("entity_id"))

        def _parse_device_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        device_id = _parse_device_id(d.pop("device_id"))

        status = d.pop("status")

        message = d.pop("message")

        triggered_at = isoparse(d.pop("triggered_at"))

        def _parse_acknowledged_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                acknowledged_at_type_0 = isoparse(data)

                return acknowledged_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        acknowledged_at = _parse_acknowledged_at(d.pop("acknowledged_at"))

        def _parse_resolved_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                resolved_at_type_0 = isoparse(data)

                return resolved_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        resolved_at = _parse_resolved_at(d.pop("resolved_at"))

        def _parse_acknowledged_by(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        acknowledged_by = _parse_acknowledged_by(d.pop("acknowledged_by"))

        alert_event_out = cls(
            id=id,
            rule_id=rule_id,
            entity_id=entity_id,
            device_id=device_id,
            status=status,
            message=message,
            triggered_at=triggered_at,
            acknowledged_at=acknowledged_at,
            resolved_at=resolved_at,
            acknowledged_by=acknowledged_by,
        )

        alert_event_out.additional_properties = d
        return alert_event_out

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
