from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AnomalyHint")


@_attrs_define
class AnomalyHint:
    """
    Attributes:
        variable_key (str):
        device_id (int | None):
        current_value (float | None):
        mean (float):
        stddev (float):
        z_score (float):
        hint (str):
    """

    variable_key: str
    device_id: int | None
    current_value: float | None
    mean: float
    stddev: float
    z_score: float
    hint: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        variable_key = self.variable_key

        device_id: int | None
        device_id = self.device_id

        current_value: float | None
        current_value = self.current_value

        mean = self.mean

        stddev = self.stddev

        z_score = self.z_score

        hint = self.hint

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "variable_key": variable_key,
                "device_id": device_id,
                "current_value": current_value,
                "mean": mean,
                "stddev": stddev,
                "z_score": z_score,
                "hint": hint,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        variable_key = d.pop("variable_key")

        def _parse_device_id(data: object) -> int | None:
            if data is None:
                return data
            return cast(int | None, data)

        device_id = _parse_device_id(d.pop("device_id"))

        def _parse_current_value(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        current_value = _parse_current_value(d.pop("current_value"))

        mean = d.pop("mean")

        stddev = d.pop("stddev")

        z_score = d.pop("z_score")

        hint = d.pop("hint")

        anomaly_hint = cls(
            variable_key=variable_key,
            device_id=device_id,
            current_value=current_value,
            mean=mean,
            stddev=stddev,
            z_score=z_score,
            hint=hint,
        )

        anomaly_hint.additional_properties = d
        return anomaly_hint

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
