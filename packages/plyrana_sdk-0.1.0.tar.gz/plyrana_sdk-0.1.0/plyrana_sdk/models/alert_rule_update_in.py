from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.alert_rule_update_in_condition_config_type_0 import AlertRuleUpdateInConditionConfigType0


T = TypeVar("T", bound="AlertRuleUpdateIn")


@_attrs_define
class AlertRuleUpdateIn:
    """
    Attributes:
        name (None | str | Unset):
        condition_config (AlertRuleUpdateInConditionConfigType0 | None | Unset):
        entity_id (None | str | Unset):
        severity (None | str | Unset):
        enabled (bool | None | Unset):
        cooldown_seconds (int | None | Unset):
    """

    name: None | str | Unset = UNSET
    condition_config: AlertRuleUpdateInConditionConfigType0 | None | Unset = UNSET
    entity_id: None | str | Unset = UNSET
    severity: None | str | Unset = UNSET
    enabled: bool | None | Unset = UNSET
    cooldown_seconds: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_rule_update_in_condition_config_type_0 import AlertRuleUpdateInConditionConfigType0

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        condition_config: dict[str, Any] | None | Unset
        if isinstance(self.condition_config, Unset):
            condition_config = UNSET
        elif isinstance(self.condition_config, AlertRuleUpdateInConditionConfigType0):
            condition_config = self.condition_config.to_dict()
        else:
            condition_config = self.condition_config

        entity_id: None | str | Unset
        if isinstance(self.entity_id, Unset):
            entity_id = UNSET
        else:
            entity_id = self.entity_id

        severity: None | str | Unset
        if isinstance(self.severity, Unset):
            severity = UNSET
        else:
            severity = self.severity

        enabled: bool | None | Unset
        if isinstance(self.enabled, Unset):
            enabled = UNSET
        else:
            enabled = self.enabled

        cooldown_seconds: int | None | Unset
        if isinstance(self.cooldown_seconds, Unset):
            cooldown_seconds = UNSET
        else:
            cooldown_seconds = self.cooldown_seconds

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if condition_config is not UNSET:
            field_dict["condition_config"] = condition_config
        if entity_id is not UNSET:
            field_dict["entity_id"] = entity_id
        if severity is not UNSET:
            field_dict["severity"] = severity
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if cooldown_seconds is not UNSET:
            field_dict["cooldown_seconds"] = cooldown_seconds

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_rule_update_in_condition_config_type_0 import AlertRuleUpdateInConditionConfigType0

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_condition_config(data: object) -> AlertRuleUpdateInConditionConfigType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                condition_config_type_0 = AlertRuleUpdateInConditionConfigType0.from_dict(data)

                return condition_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AlertRuleUpdateInConditionConfigType0 | None | Unset, data)

        condition_config = _parse_condition_config(d.pop("condition_config", UNSET))

        def _parse_entity_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        entity_id = _parse_entity_id(d.pop("entity_id", UNSET))

        def _parse_severity(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        severity = _parse_severity(d.pop("severity", UNSET))

        def _parse_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enabled = _parse_enabled(d.pop("enabled", UNSET))

        def _parse_cooldown_seconds(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        cooldown_seconds = _parse_cooldown_seconds(d.pop("cooldown_seconds", UNSET))

        alert_rule_update_in = cls(
            name=name,
            condition_config=condition_config,
            entity_id=entity_id,
            severity=severity,
            enabled=enabled,
            cooldown_seconds=cooldown_seconds,
        )

        alert_rule_update_in.additional_properties = d
        return alert_rule_update_in

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
