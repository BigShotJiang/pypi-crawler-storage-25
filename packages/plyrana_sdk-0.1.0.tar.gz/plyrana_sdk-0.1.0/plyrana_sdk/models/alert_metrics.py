from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AlertMetrics")


@_attrs_define
class AlertMetrics:
    """
    Attributes:
        firing (int):
        acknowledged (int):
    """

    firing: int
    acknowledged: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        firing = self.firing

        acknowledged = self.acknowledged

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "firing": firing,
                "acknowledged": acknowledged,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        firing = d.pop("firing")

        acknowledged = d.pop("acknowledged")

        alert_metrics = cls(
            firing=firing,
            acknowledged=acknowledged,
        )

        alert_metrics.additional_properties = d
        return alert_metrics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
