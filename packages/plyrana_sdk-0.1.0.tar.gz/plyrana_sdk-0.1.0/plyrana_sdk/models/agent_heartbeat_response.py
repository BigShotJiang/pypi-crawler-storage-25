from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.agent_command import AgentCommand
    from ..models.agent_heartbeat_response_config import AgentHeartbeatResponseConfig


T = TypeVar("T", bound="AgentHeartbeatResponse")


@_attrs_define
class AgentHeartbeatResponse:
    """
    Attributes:
        ack (bool | Unset):  Default: True.
        commands (list[AgentCommand] | Unset):
        config (AgentHeartbeatResponseConfig | Unset):
    """

    ack: bool | Unset = True
    commands: list[AgentCommand] | Unset = UNSET
    config: AgentHeartbeatResponseConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ack = self.ack

        commands: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.commands, Unset):
            commands = []
            for commands_item_data in self.commands:
                commands_item = commands_item_data.to_dict()
                commands.append(commands_item)

        config: dict[str, Any] | Unset = UNSET
        if not isinstance(self.config, Unset):
            config = self.config.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if ack is not UNSET:
            field_dict["ack"] = ack
        if commands is not UNSET:
            field_dict["commands"] = commands
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_command import AgentCommand
        from ..models.agent_heartbeat_response_config import AgentHeartbeatResponseConfig

        d = dict(src_dict)
        ack = d.pop("ack", UNSET)

        _commands = d.pop("commands", UNSET)
        commands: list[AgentCommand] | Unset = UNSET
        if _commands is not UNSET:
            commands = []
            for commands_item_data in _commands:
                commands_item = AgentCommand.from_dict(commands_item_data)

                commands.append(commands_item)

        _config = d.pop("config", UNSET)
        config: AgentHeartbeatResponseConfig | Unset
        if isinstance(_config, Unset):
            config = UNSET
        else:
            config = AgentHeartbeatResponseConfig.from_dict(_config)

        agent_heartbeat_response = cls(
            ack=ack,
            commands=commands,
            config=config,
        )

        agent_heartbeat_response.additional_properties = d
        return agent_heartbeat_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
