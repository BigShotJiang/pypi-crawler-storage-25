from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.annotation_query import AnnotationQuery
    from ..models.grafana_range_raw import GrafanaRangeRaw


T = TypeVar("T", bound="AnnotationIn")


@_attrs_define
class AnnotationIn:
    """
    Attributes:
        range_ (GrafanaRangeRaw | None | Unset):
        annotation (AnnotationQuery | None | Unset):
    """

    range_: GrafanaRangeRaw | None | Unset = UNSET
    annotation: AnnotationQuery | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.annotation_query import AnnotationQuery
        from ..models.grafana_range_raw import GrafanaRangeRaw

        range_: dict[str, Any] | None | Unset
        if isinstance(self.range_, Unset):
            range_ = UNSET
        elif isinstance(self.range_, GrafanaRangeRaw):
            range_ = self.range_.to_dict()
        else:
            range_ = self.range_

        annotation: dict[str, Any] | None | Unset
        if isinstance(self.annotation, Unset):
            annotation = UNSET
        elif isinstance(self.annotation, AnnotationQuery):
            annotation = self.annotation.to_dict()
        else:
            annotation = self.annotation

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if range_ is not UNSET:
            field_dict["range"] = range_
        if annotation is not UNSET:
            field_dict["annotation"] = annotation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.annotation_query import AnnotationQuery
        from ..models.grafana_range_raw import GrafanaRangeRaw

        d = dict(src_dict)

        def _parse_range_(data: object) -> GrafanaRangeRaw | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                range_type_0 = GrafanaRangeRaw.from_dict(data)

                return range_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(GrafanaRangeRaw | None | Unset, data)

        range_ = _parse_range_(d.pop("range", UNSET))

        def _parse_annotation(data: object) -> AnnotationQuery | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                annotation_type_0 = AnnotationQuery.from_dict(data)

                return annotation_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AnnotationQuery | None | Unset, data)

        annotation = _parse_annotation(d.pop("annotation", UNSET))

        annotation_in = cls(
            range_=range_,
            annotation=annotation,
        )

        annotation_in.additional_properties = d
        return annotation_in

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
