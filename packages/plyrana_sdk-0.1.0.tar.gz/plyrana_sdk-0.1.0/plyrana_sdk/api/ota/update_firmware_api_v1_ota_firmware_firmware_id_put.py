from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.firmware_version_out import FirmwareVersionOut
from ...models.firmware_version_update import FirmwareVersionUpdate
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    firmware_id: int,
    *,
    body: FirmwareVersionUpdate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/ota/firmware/{firmware_id}".format(
            firmware_id=quote(str(firmware_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FirmwareVersionOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FirmwareVersionOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FirmwareVersionOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    firmware_id: int,
    *,
    client: AuthenticatedClient,
    body: FirmwareVersionUpdate,
) -> Response[FirmwareVersionOut | HTTPValidationError]:
    """Update Firmware

    Args:
        firmware_id (int):
        body (FirmwareVersionUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FirmwareVersionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        firmware_id=firmware_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    firmware_id: int,
    *,
    client: AuthenticatedClient,
    body: FirmwareVersionUpdate,
) -> FirmwareVersionOut | HTTPValidationError | None:
    """Update Firmware

    Args:
        firmware_id (int):
        body (FirmwareVersionUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FirmwareVersionOut | HTTPValidationError
    """

    return sync_detailed(
        firmware_id=firmware_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    firmware_id: int,
    *,
    client: AuthenticatedClient,
    body: FirmwareVersionUpdate,
) -> Response[FirmwareVersionOut | HTTPValidationError]:
    """Update Firmware

    Args:
        firmware_id (int):
        body (FirmwareVersionUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FirmwareVersionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        firmware_id=firmware_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    firmware_id: int,
    *,
    client: AuthenticatedClient,
    body: FirmwareVersionUpdate,
) -> FirmwareVersionOut | HTTPValidationError | None:
    """Update Firmware

    Args:
        firmware_id (int):
        body (FirmwareVersionUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FirmwareVersionOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            firmware_id=firmware_id,
            client=client,
            body=body,
        )
    ).parsed
