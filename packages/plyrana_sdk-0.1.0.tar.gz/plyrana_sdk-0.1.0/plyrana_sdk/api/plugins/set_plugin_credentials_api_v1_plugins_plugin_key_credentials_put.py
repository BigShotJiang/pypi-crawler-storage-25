from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.plugin_credentials_in import PluginCredentialsIn
from ...types import Response


def _get_kwargs(
    plugin_key: str,
    *,
    body: PluginCredentialsIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/plugins/{plugin_key}/credentials".format(
            plugin_key=quote(str(plugin_key), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    plugin_key: str,
    *,
    client: AuthenticatedClient,
    body: PluginCredentialsIn,
) -> Response[Any | HTTPValidationError]:
    """Set Plugin Credentials

     Store credentials for a connector plugin in SecretV1.

    Plaintext values are NEVER returned — only the list of updated field
    keys. Unknown fields (not in the plugin's ``credential_schema``) are
    rejected with 400 so typos surface early. Missing required fields are
    allowed here (partial update); completeness is enforced by the
    consuming subsystem when it reads the secrets.

    Args:
        plugin_key (str):
        body (PluginCredentialsIn): Body for PUT /plugins/{key}/credentials — maps schema field
            keys to values.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        plugin_key=plugin_key,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    plugin_key: str,
    *,
    client: AuthenticatedClient,
    body: PluginCredentialsIn,
) -> Any | HTTPValidationError | None:
    """Set Plugin Credentials

     Store credentials for a connector plugin in SecretV1.

    Plaintext values are NEVER returned — only the list of updated field
    keys. Unknown fields (not in the plugin's ``credential_schema``) are
    rejected with 400 so typos surface early. Missing required fields are
    allowed here (partial update); completeness is enforced by the
    consuming subsystem when it reads the secrets.

    Args:
        plugin_key (str):
        body (PluginCredentialsIn): Body for PUT /plugins/{key}/credentials — maps schema field
            keys to values.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        plugin_key=plugin_key,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    plugin_key: str,
    *,
    client: AuthenticatedClient,
    body: PluginCredentialsIn,
) -> Response[Any | HTTPValidationError]:
    """Set Plugin Credentials

     Store credentials for a connector plugin in SecretV1.

    Plaintext values are NEVER returned — only the list of updated field
    keys. Unknown fields (not in the plugin's ``credential_schema``) are
    rejected with 400 so typos surface early. Missing required fields are
    allowed here (partial update); completeness is enforced by the
    consuming subsystem when it reads the secrets.

    Args:
        plugin_key (str):
        body (PluginCredentialsIn): Body for PUT /plugins/{key}/credentials — maps schema field
            keys to values.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        plugin_key=plugin_key,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    plugin_key: str,
    *,
    client: AuthenticatedClient,
    body: PluginCredentialsIn,
) -> Any | HTTPValidationError | None:
    """Set Plugin Credentials

     Store credentials for a connector plugin in SecretV1.

    Plaintext values are NEVER returned — only the list of updated field
    keys. Unknown fields (not in the plugin's ``credential_schema``) are
    rejected with 400 so typos surface early. Missing required fields are
    allowed here (partial update); completeness is enforced by the
    consuming subsystem when it reads the secrets.

    Args:
        plugin_key (str):
        body (PluginCredentialsIn): Body for PUT /plugins/{key}/credentials — maps schema field
            keys to values.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            plugin_key=plugin_key,
            client=client,
            body=body,
        )
    ).parsed
