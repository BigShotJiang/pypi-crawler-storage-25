from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_task_out import UserTaskOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    device_id: int,
    *,
    status: None | str | Unset = UNSET,
    limit: int | Unset = 50,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    else:
        json_status = status
    params["status"] = json_status

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/devices/{device_id}/tasks".format(
            device_id=quote(str(device_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[UserTaskOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = UserTaskOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[UserTaskOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    status: None | str | Unset = UNSET,
    limit: int | Unset = 50,
) -> Response[HTTPValidationError | list[UserTaskOut]]:
    """List Device Tasks

    Args:
        device_id (int):
        status (None | str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UserTaskOut]]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        status=status,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: int,
    *,
    client: AuthenticatedClient,
    status: None | str | Unset = UNSET,
    limit: int | Unset = 50,
) -> HTTPValidationError | list[UserTaskOut] | None:
    """List Device Tasks

    Args:
        device_id (int):
        status (None | str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UserTaskOut]
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
        status=status,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    status: None | str | Unset = UNSET,
    limit: int | Unset = 50,
) -> Response[HTTPValidationError | list[UserTaskOut]]:
    """List Device Tasks

    Args:
        device_id (int):
        status (None | str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UserTaskOut]]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        status=status,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: int,
    *,
    client: AuthenticatedClient,
    status: None | str | Unset = UNSET,
    limit: int | Unset = 50,
) -> HTTPValidationError | list[UserTaskOut] | None:
    """List Device Tasks

    Args:
        device_id (int):
        status (None | str | Unset):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UserTaskOut]
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
            status=status,
            limit=limit,
        )
    ).parsed
