from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.device_type_update_in import DeviceTypeUpdateIn
from ...models.device_type_update_out import DeviceTypeUpdateOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    device_id: int,
    *,
    body: DeviceTypeUpdateIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/api/v1/devices/{device_id}/type".format(
            device_id=quote(str(device_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceTypeUpdateOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeviceTypeUpdateOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceTypeUpdateOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: DeviceTypeUpdateIn,
) -> Response[DeviceTypeUpdateOut | HTTPValidationError]:
    """Update Device Type

    Args:
        device_id (int):
        body (DeviceTypeUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceTypeUpdateOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: DeviceTypeUpdateIn,
) -> DeviceTypeUpdateOut | HTTPValidationError | None:
    """Update Device Type

    Args:
        device_id (int):
        body (DeviceTypeUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceTypeUpdateOut | HTTPValidationError
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: DeviceTypeUpdateIn,
) -> Response[DeviceTypeUpdateOut | HTTPValidationError]:
    """Update Device Type

    Args:
        device_id (int):
        body (DeviceTypeUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceTypeUpdateOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: DeviceTypeUpdateIn,
) -> DeviceTypeUpdateOut | HTTPValidationError | None:
    """Update Device Type

    Args:
        device_id (int):
        body (DeviceTypeUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceTypeUpdateOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
            body=body,
        )
    ).parsed
