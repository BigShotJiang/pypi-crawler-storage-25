from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_task_create_in import UserTaskCreateIn
from ...models.user_task_create_out import UserTaskCreateOut
from ...types import Response


def _get_kwargs(
    device_id: int,
    *,
    body: UserTaskCreateIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/devices/{device_id}/tasks".format(
            device_id=quote(str(device_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | UserTaskCreateOut | None:
    if response.status_code == 200:
        response_200 = UserTaskCreateOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | UserTaskCreateOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: UserTaskCreateIn,
) -> Response[HTTPValidationError | UserTaskCreateOut]:
    """Create Task For Device

    Args:
        device_id (int):
        body (UserTaskCreateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserTaskCreateOut]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: UserTaskCreateIn,
) -> HTTPValidationError | UserTaskCreateOut | None:
    """Create Task For Device

    Args:
        device_id (int):
        body (UserTaskCreateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserTaskCreateOut
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: UserTaskCreateIn,
) -> Response[HTTPValidationError | UserTaskCreateOut]:
    """Create Task For Device

    Args:
        device_id (int):
        body (UserTaskCreateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserTaskCreateOut]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: int,
    *,
    client: AuthenticatedClient,
    body: UserTaskCreateIn,
) -> HTTPValidationError | UserTaskCreateOut | None:
    """Create Task For Device

    Args:
        device_id (int):
        body (UserTaskCreateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserTaskCreateOut
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
            body=body,
        )
    ).parsed
