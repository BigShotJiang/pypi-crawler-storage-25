from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_telemetry_out import UserTelemetryOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    device_id: int,
    *,
    limit: int | Unset = 50,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/devices/{device_id}/telemetry/recent".format(
            device_id=quote(str(device_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[UserTelemetryOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = UserTelemetryOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[UserTelemetryOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
) -> Response[HTTPValidationError | list[UserTelemetryOut]]:
    """Get Device Telemetry Recent

    Args:
        device_id (int):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UserTelemetryOut]]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: int,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
) -> HTTPValidationError | list[UserTelemetryOut] | None:
    """Get Device Telemetry Recent

    Args:
        device_id (int):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UserTelemetryOut]
    """

    return sync_detailed(
        device_id=device_id,
        client=client,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    device_id: int,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
) -> Response[HTTPValidationError | list[UserTelemetryOut]]:
    """Get Device Telemetry Recent

    Args:
        device_id (int):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UserTelemetryOut]]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: int,
    *,
    client: AuthenticatedClient,
    limit: int | Unset = 50,
) -> HTTPValidationError | list[UserTelemetryOut] | None:
    """Get Device Telemetry Recent

    Args:
        device_id (int):
        limit (int | Unset):  Default: 50.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UserTelemetryOut]
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            client=client,
            limit=limit,
        )
    ).parsed
