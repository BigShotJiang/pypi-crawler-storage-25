from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_task_cancel_out import UserTaskCancelOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    device_id: int,
    task_id: int,
    *,
    force: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["force"] = force

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/devices/{device_id}/tasks/{task_id}/cancel".format(
            device_id=quote(str(device_id), safe=""),
            task_id=quote(str(task_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | UserTaskCancelOut | None:
    if response.status_code == 200:
        response_200 = UserTaskCancelOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | UserTaskCancelOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_id: int,
    task_id: int,
    *,
    client: AuthenticatedClient,
    force: bool | Unset = False,
) -> Response[HTTPValidationError | UserTaskCancelOut]:
    """Cancel Task For Device

    Args:
        device_id (int):
        task_id (int):
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserTaskCancelOut]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        task_id=task_id,
        force=force,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_id: int,
    task_id: int,
    *,
    client: AuthenticatedClient,
    force: bool | Unset = False,
) -> HTTPValidationError | UserTaskCancelOut | None:
    """Cancel Task For Device

    Args:
        device_id (int):
        task_id (int):
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserTaskCancelOut
    """

    return sync_detailed(
        device_id=device_id,
        task_id=task_id,
        client=client,
        force=force,
    ).parsed


async def asyncio_detailed(
    device_id: int,
    task_id: int,
    *,
    client: AuthenticatedClient,
    force: bool | Unset = False,
) -> Response[HTTPValidationError | UserTaskCancelOut]:
    """Cancel Task For Device

    Args:
        device_id (int):
        task_id (int):
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | UserTaskCancelOut]
    """

    kwargs = _get_kwargs(
        device_id=device_id,
        task_id=task_id,
        force=force,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_id: int,
    task_id: int,
    *,
    client: AuthenticatedClient,
    force: bool | Unset = False,
) -> HTTPValidationError | UserTaskCancelOut | None:
    """Cancel Task For Device

    Args:
        device_id (int):
        task_id (int):
        force (bool | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | UserTaskCancelOut
    """

    return (
        await asyncio_detailed(
            device_id=device_id,
            task_id=task_id,
            client=client,
            force=force,
        )
    ).parsed
