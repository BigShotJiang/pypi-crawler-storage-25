from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    build_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/firmware/builds/{build_id}/logs".format(
            build_id=quote(str(build_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    build_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | str]:
    """Get Build Logs

     Return the build's captured stdout/stderr as plain text.

    For builds still in-flight, this returns what's been written to the
    DB so far. Frontend polls this endpoint for the live log tail.

    Args:
        build_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        build_id=build_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    build_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | str | None:
    """Get Build Logs

     Return the build's captured stdout/stderr as plain text.

    For builds still in-flight, this returns what's been written to the
    DB so far. Frontend polls this endpoint for the live log tail.

    Args:
        build_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return sync_detailed(
        build_id=build_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    build_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | str]:
    """Get Build Logs

     Return the build's captured stdout/stderr as plain text.

    For builds still in-flight, this returns what's been written to the
    DB so far. Frontend polls this endpoint for the live log tail.

    Args:
        build_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        build_id=build_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    build_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | str | None:
    """Get Build Logs

     Return the build's captured stdout/stderr as plain text.

    For builds still in-flight, this returns what's been written to the
    DB so far. Frontend polls this endpoint for the live log tail.

    Args:
        build_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return (
        await asyncio_detailed(
            build_id=build_id,
            client=client,
        )
    ).parsed
