from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.build_out import BuildOut
from ...models.build_request_in import BuildRequestIn
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: BuildRequestIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/firmware/build",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BuildOut | HTTPValidationError | None:
    if response.status_code == 202:
        response_202 = BuildOut.from_dict(response.json())

        return response_202

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BuildOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BuildRequestIn,
) -> Response[BuildOut | HTTPValidationError]:
    """Start Build

     Queue a new firmware build.

    Returns 202 Accepted + the build row in ``queued`` state. The actual
    compile happens in an ``asyncio.Task`` that bumps the row through
    ``building`` → ``success`` / ``failed``. Clients should poll
    ``GET /firmware/builds/{id}`` for status.

    Args:
        body (BuildRequestIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BuildOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: BuildRequestIn,
) -> BuildOut | HTTPValidationError | None:
    """Start Build

     Queue a new firmware build.

    Returns 202 Accepted + the build row in ``queued`` state. The actual
    compile happens in an ``asyncio.Task`` that bumps the row through
    ``building`` → ``success`` / ``failed``. Clients should poll
    ``GET /firmware/builds/{id}`` for status.

    Args:
        body (BuildRequestIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BuildOut | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BuildRequestIn,
) -> Response[BuildOut | HTTPValidationError]:
    """Start Build

     Queue a new firmware build.

    Returns 202 Accepted + the build row in ``queued`` state. The actual
    compile happens in an ``asyncio.Task`` that bumps the row through
    ``building`` → ``success`` / ``failed``. Clients should poll
    ``GET /firmware/builds/{id}`` for status.

    Args:
        body (BuildRequestIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BuildOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BuildRequestIn,
) -> BuildOut | HTTPValidationError | None:
    """Start Build

     Queue a new firmware build.

    Returns 202 Accepted + the build row in ``queued`` state. The actual
    compile happens in an ``asyncio.Task`` that bumps the row through
    ``building`` → ``success`` / ``failed``. Clients should poll
    ``GET /firmware/builds/{id}`` for status.

    Args:
        body (BuildRequestIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BuildOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
