from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ota_push_in import OtaPushIn
from ...models.ota_push_out import OtaPushOut
from ...types import Response


def _get_kwargs(
    build_id: int,
    *,
    body: OtaPushIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/firmware/builds/{build_id}/ota".format(
            build_id=quote(str(build_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | OtaPushOut | None:
    if response.status_code == 201:
        response_201 = OtaPushOut.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | OtaPushOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    build_id: int,
    *,
    client: AuthenticatedClient,
    body: OtaPushIn,
) -> Response[HTTPValidationError | OtaPushOut]:
    """Push Build To Ota

     Promote a successful build to an OTA rollout.

    Creates FirmwareVersion + OtaRollout + DeviceOtaStatus atomically.
    The rollout is immediately ``active`` with strategy ``immediate``
    so the next `/ota/check` poll from the target device returns the
    new firmware. ``firmware_builds.ota_rollout_id`` is set so the UI
    can poll status via list_builds.

    Args:
        build_id (int):
        body (OtaPushIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | OtaPushOut]
    """

    kwargs = _get_kwargs(
        build_id=build_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    build_id: int,
    *,
    client: AuthenticatedClient,
    body: OtaPushIn,
) -> HTTPValidationError | OtaPushOut | None:
    """Push Build To Ota

     Promote a successful build to an OTA rollout.

    Creates FirmwareVersion + OtaRollout + DeviceOtaStatus atomically.
    The rollout is immediately ``active`` with strategy ``immediate``
    so the next `/ota/check` poll from the target device returns the
    new firmware. ``firmware_builds.ota_rollout_id`` is set so the UI
    can poll status via list_builds.

    Args:
        build_id (int):
        body (OtaPushIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | OtaPushOut
    """

    return sync_detailed(
        build_id=build_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    build_id: int,
    *,
    client: AuthenticatedClient,
    body: OtaPushIn,
) -> Response[HTTPValidationError | OtaPushOut]:
    """Push Build To Ota

     Promote a successful build to an OTA rollout.

    Creates FirmwareVersion + OtaRollout + DeviceOtaStatus atomically.
    The rollout is immediately ``active`` with strategy ``immediate``
    so the next `/ota/check` poll from the target device returns the
    new firmware. ``firmware_builds.ota_rollout_id`` is set so the UI
    can poll status via list_builds.

    Args:
        build_id (int):
        body (OtaPushIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | OtaPushOut]
    """

    kwargs = _get_kwargs(
        build_id=build_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    build_id: int,
    *,
    client: AuthenticatedClient,
    body: OtaPushIn,
) -> HTTPValidationError | OtaPushOut | None:
    """Push Build To Ota

     Promote a successful build to an OTA rollout.

    Creates FirmwareVersion + OtaRollout + DeviceOtaStatus atomically.
    The rollout is immediately ``active`` with strategy ``immediate``
    so the next `/ota/check` poll from the target device returns the
    new firmware. ``firmware_builds.ota_rollout_id`` is set so the UI
    can poll status via list_builds.

    Args:
        build_id (int):
        body (OtaPushIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | OtaPushOut
    """

    return (
        await asyncio_detailed(
            build_id=build_id,
            client=client,
            body=body,
        )
    ).parsed
