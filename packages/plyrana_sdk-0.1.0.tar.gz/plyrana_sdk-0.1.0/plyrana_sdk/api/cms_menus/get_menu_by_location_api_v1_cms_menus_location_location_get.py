from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_menu_public_out import CmsMenuPublicOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    location: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/cms/menus/location/{location}".format(
            location=quote(str(location), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsMenuPublicOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CmsMenuPublicOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsMenuPublicOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    location: str,
    *,
    client: AuthenticatedClient,
) -> Response[CmsMenuPublicOut | HTTPValidationError]:
    """Get Menu By Location

     Public menu lookup by location — used by frontend to render nav bars.

    Resolves menu items that reference pages by id: if a referenced page is
    private/unpublished, it is filtered out so it never leaks into the UI.

    Args:
        location (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsMenuPublicOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        location=location,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    location: str,
    *,
    client: AuthenticatedClient,
) -> CmsMenuPublicOut | HTTPValidationError | None:
    """Get Menu By Location

     Public menu lookup by location — used by frontend to render nav bars.

    Resolves menu items that reference pages by id: if a referenced page is
    private/unpublished, it is filtered out so it never leaks into the UI.

    Args:
        location (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsMenuPublicOut | HTTPValidationError
    """

    return sync_detailed(
        location=location,
        client=client,
    ).parsed


async def asyncio_detailed(
    location: str,
    *,
    client: AuthenticatedClient,
) -> Response[CmsMenuPublicOut | HTTPValidationError]:
    """Get Menu By Location

     Public menu lookup by location — used by frontend to render nav bars.

    Resolves menu items that reference pages by id: if a referenced page is
    private/unpublished, it is filtered out so it never leaks into the UI.

    Args:
        location (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsMenuPublicOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        location=location,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    location: str,
    *,
    client: AuthenticatedClient,
) -> CmsMenuPublicOut | HTTPValidationError | None:
    """Get Menu By Location

     Public menu lookup by location — used by frontend to render nav bars.

    Resolves menu items that reference pages by id: if a referenced page is
    private/unpublished, it is filtered out so it never leaks into the UI.

    Args:
        location (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsMenuPublicOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            location=location,
            client=client,
        )
    ).parsed
