from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_menu_out import CmsMenuOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    menu_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/cms/menus/{menu_id}".format(
            menu_id=quote(str(menu_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsMenuOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CmsMenuOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsMenuOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    menu_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsMenuOut | HTTPValidationError]:
    """Get Menu

    Args:
        menu_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsMenuOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        menu_id=menu_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    menu_id: int,
    *,
    client: AuthenticatedClient,
) -> CmsMenuOut | HTTPValidationError | None:
    """Get Menu

    Args:
        menu_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsMenuOut | HTTPValidationError
    """

    return sync_detailed(
        menu_id=menu_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    menu_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsMenuOut | HTTPValidationError]:
    """Get Menu

    Args:
        menu_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsMenuOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        menu_id=menu_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    menu_id: int,
    *,
    client: AuthenticatedClient,
) -> CmsMenuOut | HTTPValidationError | None:
    """Get Menu

    Args:
        menu_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsMenuOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            menu_id=menu_id,
            client=client,
        )
    ).parsed
