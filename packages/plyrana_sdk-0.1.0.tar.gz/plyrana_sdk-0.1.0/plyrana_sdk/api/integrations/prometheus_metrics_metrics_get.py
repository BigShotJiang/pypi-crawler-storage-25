from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/metrics",
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any]:
    """Prometheus Metrics

     Sprint 16 — Prometheus exporter.

    Exposes HUBEX state in Prometheus text format at the standard
    ``/metrics`` path (no auth, no prefix) so an existing Prometheus
    instance can scrape it without custom config. Intended for trusted
    internal networks (docker-compose, VPC). Disable via the
    ``prometheus_exporter`` feature flag if you prefer to keep this off.

    Returns 404 when the feature flag is disabled so external scrapers
    get a clean signal instead of empty metrics.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
) -> Response[Any]:
    """Prometheus Metrics

     Sprint 16 — Prometheus exporter.

    Exposes HUBEX state in Prometheus text format at the standard
    ``/metrics`` path (no auth, no prefix) so an existing Prometheus
    instance can scrape it without custom config. Intended for trusted
    internal networks (docker-compose, VPC). Disable via the
    ``prometheus_exporter`` feature flag if you prefer to keep this off.

    Returns 404 when the feature flag is disabled so external scrapers
    get a clean signal instead of empty metrics.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)
