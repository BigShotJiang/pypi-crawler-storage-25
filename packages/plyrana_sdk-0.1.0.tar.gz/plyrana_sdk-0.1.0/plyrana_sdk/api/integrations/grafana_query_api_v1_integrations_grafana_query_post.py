from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.grafana_query_api_v1_integrations_grafana_query_post_response_200_item import (
    GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.query_in import QueryIn
from ...types import Response


def _get_kwargs(
    *,
    body: QueryIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/integrations/grafana/query",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item.from_dict(
                response_200_item_data
            )

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: QueryIn,
) -> Response[HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]]:
    """Grafana Query

     SimpleJSON `/query` — time-series data for each target.

    Args:
        body (QueryIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: QueryIn,
) -> HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item] | None:
    """Grafana Query

     SimpleJSON `/query` — time-series data for each target.

    Args:
        body (QueryIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: QueryIn,
) -> Response[HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]]:
    """Grafana Query

     SimpleJSON `/query` — time-series data for each target.

    Args:
        body (QueryIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: QueryIn,
) -> HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item] | None:
    """Grafana Query

     SimpleJSON `/query` — time-series data for each target.

    Args:
        body (QueryIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[GrafanaQueryApiV1IntegrationsGrafanaQueryPostResponse200Item]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
