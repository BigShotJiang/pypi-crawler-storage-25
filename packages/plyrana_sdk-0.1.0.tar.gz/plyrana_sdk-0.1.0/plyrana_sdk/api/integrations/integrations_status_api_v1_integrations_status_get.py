from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.integrations_status_api_v1_integrations_status_get_response_integrations_status_api_v1_integrations_status_get import (
    IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/integrations/status",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet | None:
    if response.status_code == 200:
        response_200 = (
            IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet.from_dict(
                response.json()
            )
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet]:
    """Integrations Status

     Aggregated snapshot of all outbound integrations.

    Used by Settings → Integrations so an admin can see at a glance
    which integrations are enabled / configured / healthy without
    polling each status endpoint individually.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet | None:
    """Integrations Status

     Aggregated snapshot of all outbound integrations.

    Used by Settings → Integrations so an admin can see at a glance
    which integrations are enabled / configured / healthy without
    polling each status endpoint individually.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet]:
    """Integrations Status

     Aggregated snapshot of all outbound integrations.

    Used by Settings → Integrations so an admin can see at a glance
    which integrations are enabled / configured / healthy without
    polling each status endpoint individually.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet | None:
    """Integrations Status

     Aggregated snapshot of all outbound integrations.

    Used by Settings → Integrations so an admin can see at a glance
    which integrations are enabled / configured / healthy without
    polling each status endpoint individually.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IntegrationsStatusApiV1IntegrationsStatusGetResponseIntegrationsStatusApiV1IntegrationsStatusGet
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
