from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.simulator_create import SimulatorCreate
from ...models.simulator_out import SimulatorOut
from ...types import Response


def _get_kwargs(
    *,
    body: SimulatorCreate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/simulator/configs",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SimulatorOut | None:
    if response.status_code == 201:
        response_201 = SimulatorOut.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SimulatorOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: SimulatorCreate,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Create Simulator

     Create a new simulator configuration.

    If is_virtual_device is true, a virtual device is created automatically.
    If device_uid is provided and is_virtual_device is false, the simulator attaches
    to the existing device.
    If a template is specified, its variable_patterns are used as defaults (unless
    the caller provides their own).

    Args:
        body (SimulatorCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: SimulatorCreate,
) -> HTTPValidationError | SimulatorOut | None:
    """Create Simulator

     Create a new simulator configuration.

    If is_virtual_device is true, a virtual device is created automatically.
    If device_uid is provided and is_virtual_device is false, the simulator attaches
    to the existing device.
    If a template is specified, its variable_patterns are used as defaults (unless
    the caller provides their own).

    Args:
        body (SimulatorCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: SimulatorCreate,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Create Simulator

     Create a new simulator configuration.

    If is_virtual_device is true, a virtual device is created automatically.
    If device_uid is provided and is_virtual_device is false, the simulator attaches
    to the existing device.
    If a template is specified, its variable_patterns are used as defaults (unless
    the caller provides their own).

    Args:
        body (SimulatorCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: SimulatorCreate,
) -> HTTPValidationError | SimulatorOut | None:
    """Create Simulator

     Create a new simulator configuration.

    If is_virtual_device is true, a virtual device is created automatically.
    If device_uid is provided and is_virtual_device is false, the simulator attaches
    to the existing device.
    If a template is specified, its variable_patterns are used as defaults (unless
    the caller provides their own).

    Args:
        body (SimulatorCreate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
