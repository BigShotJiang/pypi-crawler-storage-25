from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.pulse_single_value_api_v1_simulator_configs_sim_id_pulse_post_response_pulse_single_value_api_v1_simulator_configs_sim_id_pulse_post import (
    PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost,
)
from ...models.simulator_quick_pulse import SimulatorQuickPulse
from ...types import Response


def _get_kwargs(
    sim_id: int,
    *,
    body: SimulatorQuickPulse,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/simulator/configs/{sim_id}/pulse".format(
            sim_id=quote(str(sim_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
    | None
):
    if response.status_code == 200:
        response_200 = PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> Response[
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
]:
    """Pulse Single Value

     Send a single value for one variable on the simulator's device.

    Args:
        sim_id (int):
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> (
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
    | None
):
    """Pulse Single Value

     Send a single value for one variable on the simulator's device.

    Args:
        sim_id (int):
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
    """

    return sync_detailed(
        sim_id=sim_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> Response[
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
]:
    """Pulse Single Value

     Send a single value for one variable on the simulator's device.

    Args:
        sim_id (int):
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> (
    HTTPValidationError
    | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
    | None
):
    """Pulse Single Value

     Send a single value for one variable on the simulator's device.

    Args:
        sim_id (int):
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PulseSingleValueApiV1SimulatorConfigsSimIdPulsePostResponsePulseSingleValueApiV1SimulatorConfigsSimIdPulsePost
    """

    return (
        await asyncio_detailed(
            sim_id=sim_id,
            client=client,
            body=body,
        )
    ).parsed
