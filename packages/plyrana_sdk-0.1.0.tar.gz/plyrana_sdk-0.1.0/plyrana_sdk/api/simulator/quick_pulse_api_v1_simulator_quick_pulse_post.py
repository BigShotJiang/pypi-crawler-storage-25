from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.quick_pulse_api_v1_simulator_quick_pulse_post_response_quick_pulse_api_v1_simulator_quick_pulse_post import (
    QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost,
)
from ...models.simulator_quick_pulse import SimulatorQuickPulse
from ...types import Response


def _get_kwargs(
    *,
    body: SimulatorQuickPulse,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/simulator/quick-pulse",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost | None:
    if response.status_code == 200:
        response_200 = QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> Response[
    HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost
]:
    """Quick Pulse

     Push a single value for any variable on any device owned by the user.

    Useful from Device Detail page to quickly inject test data without
    creating a full simulator configuration.

    Args:
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost | None:
    """Quick Pulse

     Push a single value for any variable on any device owned by the user.

    Useful from Device Detail page to quickly inject test data without
    creating a full simulator configuration.

    Args:
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> Response[
    HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost
]:
    """Quick Pulse

     Push a single value for any variable on any device owned by the user.

    Useful from Device Detail page to quickly inject test data without
    creating a full simulator configuration.

    Args:
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: SimulatorQuickPulse,
) -> HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost | None:
    """Quick Pulse

     Push a single value for any variable on any device owned by the user.

    Useful from Device Detail page to quickly inject test data without
    creating a full simulator configuration.

    Args:
        body (SimulatorQuickPulse):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | QuickPulseApiV1SimulatorQuickPulsePostResponseQuickPulseApiV1SimulatorQuickPulsePost
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
