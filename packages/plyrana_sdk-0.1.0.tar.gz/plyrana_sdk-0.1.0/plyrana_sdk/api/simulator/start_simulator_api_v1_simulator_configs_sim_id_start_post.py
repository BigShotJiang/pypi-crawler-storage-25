from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.simulator_out import SimulatorOut
from ...types import Response


def _get_kwargs(
    sim_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/simulator/configs/{sim_id}/start".format(
            sim_id=quote(str(sim_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SimulatorOut | None:
    if response.status_code == 200:
        response_200 = SimulatorOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SimulatorOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Start Simulator

     Start a simulator. Begins generating data in the background.

    Args:
        sim_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sim_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | SimulatorOut | None:
    """Start Simulator

     Start a simulator. Begins generating data in the background.

    Args:
        sim_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return sync_detailed(
        sim_id=sim_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Start Simulator

     Start a simulator. Begins generating data in the background.

    Args:
        sim_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sim_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | SimulatorOut | None:
    """Start Simulator

     Start a simulator. Begins generating data in the background.

    Args:
        sim_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return (
        await asyncio_detailed(
            sim_id=sim_id,
            client=client,
        )
    ).parsed
