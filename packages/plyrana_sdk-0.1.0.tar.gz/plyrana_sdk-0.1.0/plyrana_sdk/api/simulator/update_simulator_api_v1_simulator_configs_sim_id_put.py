from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.simulator_out import SimulatorOut
from ...models.simulator_update import SimulatorUpdate
from ...types import Response


def _get_kwargs(
    sim_id: int,
    *,
    body: SimulatorUpdate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/simulator/configs/{sim_id}".format(
            sim_id=quote(str(sim_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SimulatorOut | None:
    if response.status_code == 200:
        response_200 = SimulatorOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SimulatorOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorUpdate,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Update Simulator

     Update a simulator configuration. Stops the simulator if it's running.

    Args:
        sim_id (int):
        body (SimulatorUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorUpdate,
) -> HTTPValidationError | SimulatorOut | None:
    """Update Simulator

     Update a simulator configuration. Stops the simulator if it's running.

    Args:
        sim_id (int):
        body (SimulatorUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return sync_detailed(
        sim_id=sim_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorUpdate,
) -> Response[HTTPValidationError | SimulatorOut]:
    """Update Simulator

     Update a simulator configuration. Stops the simulator if it's running.

    Args:
        sim_id (int):
        body (SimulatorUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SimulatorOut]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    body: SimulatorUpdate,
) -> HTTPValidationError | SimulatorOut | None:
    """Update Simulator

     Update a simulator configuration. Stops the simulator if it's running.

    Args:
        sim_id (int):
        body (SimulatorUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SimulatorOut
    """

    return (
        await asyncio_detailed(
            sim_id=sim_id,
            client=client,
            body=body,
        )
    ).parsed
