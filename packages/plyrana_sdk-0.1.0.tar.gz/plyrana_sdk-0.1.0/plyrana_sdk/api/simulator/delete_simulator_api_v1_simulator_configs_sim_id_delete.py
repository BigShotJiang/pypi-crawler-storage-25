from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    sim_id: int,
    *,
    delete_device: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["delete_device"] = delete_device

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/v1/simulator/configs/{sim_id}".format(
            sim_id=quote(str(sim_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    delete_device: bool | Unset = False,
) -> Response[Any | HTTPValidationError]:
    """Delete Simulator

     Delete a simulator. Optionally deletes the associated virtual device.

    Args:
        sim_id (int):
        delete_device (bool | Unset): Also delete the virtual device Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        delete_device=delete_device,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    delete_device: bool | Unset = False,
) -> Any | HTTPValidationError | None:
    """Delete Simulator

     Delete a simulator. Optionally deletes the associated virtual device.

    Args:
        sim_id (int):
        delete_device (bool | Unset): Also delete the virtual device Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        sim_id=sim_id,
        client=client,
        delete_device=delete_device,
    ).parsed


async def asyncio_detailed(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    delete_device: bool | Unset = False,
) -> Response[Any | HTTPValidationError]:
    """Delete Simulator

     Delete a simulator. Optionally deletes the associated virtual device.

    Args:
        sim_id (int):
        delete_device (bool | Unset): Also delete the virtual device Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        sim_id=sim_id,
        delete_device=delete_device,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    sim_id: int,
    *,
    client: AuthenticatedClient,
    delete_device: bool | Unset = False,
) -> Any | HTTPValidationError | None:
    """Delete Simulator

     Delete a simulator. Optionally deletes the associated virtual device.

    Args:
        sim_id (int):
        delete_device (bool | Unset): Also delete the virtual device Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            sim_id=sim_id,
            client=client,
            delete_device=delete_device,
        )
    ).parsed
