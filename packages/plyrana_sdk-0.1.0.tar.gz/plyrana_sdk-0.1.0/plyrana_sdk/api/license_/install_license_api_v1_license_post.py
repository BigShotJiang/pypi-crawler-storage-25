from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.license_info_out import LicenseInfoOut
from ...models.license_upload_in import LicenseUploadIn
from ...types import Response


def _get_kwargs(
    *,
    body: LicenseUploadIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/license",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | LicenseInfoOut | None:
    if response.status_code == 200:
        response_200 = LicenseInfoOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | LicenseInfoOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: LicenseUploadIn,
) -> Response[HTTPValidationError | LicenseInfoOut]:
    """Install License

     Verify + install a new license file.

    Behavior on signature failure: returns 422 with the parsed payload's
    error field so the admin UI can show what was wrong (expired,
    tampered, unknown edition, ...). The active license is NOT changed
    on failure — the previous license remains in force.

    Args:
        body (LicenseUploadIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LicenseInfoOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: LicenseUploadIn,
) -> HTTPValidationError | LicenseInfoOut | None:
    """Install License

     Verify + install a new license file.

    Behavior on signature failure: returns 422 with the parsed payload's
    error field so the admin UI can show what was wrong (expired,
    tampered, unknown edition, ...). The active license is NOT changed
    on failure — the previous license remains in force.

    Args:
        body (LicenseUploadIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LicenseInfoOut
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: LicenseUploadIn,
) -> Response[HTTPValidationError | LicenseInfoOut]:
    """Install License

     Verify + install a new license file.

    Behavior on signature failure: returns 422 with the parsed payload's
    error field so the admin UI can show what was wrong (expired,
    tampered, unknown edition, ...). The active license is NOT changed
    on failure — the previous license remains in force.

    Args:
        body (LicenseUploadIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | LicenseInfoOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: LicenseUploadIn,
) -> HTTPValidationError | LicenseInfoOut | None:
    """Install License

     Verify + install a new license file.

    Behavior on signature failure: returns 422 with the parsed payload's
    error field so the admin UI can show what was wrong (expired,
    tampered, unknown edition, ...). The active license is NOT changed
    on failure — the previous license remains in force.

    Args:
        body (LicenseUploadIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | LicenseInfoOut
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
