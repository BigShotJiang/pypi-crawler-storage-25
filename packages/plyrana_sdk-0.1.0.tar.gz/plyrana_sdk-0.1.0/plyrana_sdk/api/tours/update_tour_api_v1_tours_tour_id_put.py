from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.tour_out import TourOut
from ...models.tour_update import TourUpdate
from ...types import Response


def _get_kwargs(
    tour_id: int,
    *,
    body: TourUpdate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/tours/{tour_id}".format(
            tour_id=quote(str(tour_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | TourOut | None:
    if response.status_code == 200:
        response_200 = TourOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | TourOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    tour_id: int,
    *,
    client: AuthenticatedClient,
    body: TourUpdate,
) -> Response[HTTPValidationError | TourOut]:
    """Update Tour

     Update a tour.

    Args:
        tour_id (int):
        body (TourUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TourOut]
    """

    kwargs = _get_kwargs(
        tour_id=tour_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    tour_id: int,
    *,
    client: AuthenticatedClient,
    body: TourUpdate,
) -> HTTPValidationError | TourOut | None:
    """Update Tour

     Update a tour.

    Args:
        tour_id (int):
        body (TourUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TourOut
    """

    return sync_detailed(
        tour_id=tour_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    tour_id: int,
    *,
    client: AuthenticatedClient,
    body: TourUpdate,
) -> Response[HTTPValidationError | TourOut]:
    """Update Tour

     Update a tour.

    Args:
        tour_id (int):
        body (TourUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TourOut]
    """

    kwargs = _get_kwargs(
        tour_id=tour_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    tour_id: int,
    *,
    client: AuthenticatedClient,
    body: TourUpdate,
) -> HTTPValidationError | TourOut | None:
    """Update Tour

     Update a tour.

    Args:
        tour_id (int):
        body (TourUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TourOut
    """

    return (
        await asyncio_detailed(
            tour_id=tour_id,
            client=client,
            body=body,
        )
    ).parsed
