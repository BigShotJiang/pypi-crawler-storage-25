from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_system_limits_api_v1_system_limits_get_response_get_system_limits_api_v1_system_limits_get import (
    GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/system/limits",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet | None:
    if response.status_code == 200:
        response_200 = GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet.from_dict(
            response.json()
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet]:
    """Get System Limits

     Return current edition and soft-limit status for tracked resources.

    Sprint 9.5: aligned with ``docs/EDITIONS.md`` §2.1. Counted resources:
    users, orgs, api_keys, plugin_slots. Config values: history_days,
    rate_limit_rpm. Devices/Dashboards/Automations/Variables/Webhooks are
    unlimited and therefore not exposed here.

    The license layer (``GET /api/v1/license``) carries the authoritative
    per-tier values; this endpoint reflects the running settings (env
    vars) and counts current rows. Frontend uses both: license for the
    edition badge + tier display, this for the soft-limit-warning bar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet | None:
    """Get System Limits

     Return current edition and soft-limit status for tracked resources.

    Sprint 9.5: aligned with ``docs/EDITIONS.md`` §2.1. Counted resources:
    users, orgs, api_keys, plugin_slots. Config values: history_days,
    rate_limit_rpm. Devices/Dashboards/Automations/Variables/Webhooks are
    unlimited and therefore not exposed here.

    The license layer (``GET /api/v1/license``) carries the authoritative
    per-tier values; this endpoint reflects the running settings (env
    vars) and counts current rows. Frontend uses both: license for the
    edition badge + tier display, this for the soft-limit-warning bar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet]:
    """Get System Limits

     Return current edition and soft-limit status for tracked resources.

    Sprint 9.5: aligned with ``docs/EDITIONS.md`` §2.1. Counted resources:
    users, orgs, api_keys, plugin_slots. Config values: history_days,
    rate_limit_rpm. Devices/Dashboards/Automations/Variables/Webhooks are
    unlimited and therefore not exposed here.

    The license layer (``GET /api/v1/license``) carries the authoritative
    per-tier values; this endpoint reflects the running settings (env
    vars) and counts current rows. Frontend uses both: license for the
    edition badge + tier display, this for the soft-limit-warning bar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet | None:
    """Get System Limits

     Return current edition and soft-limit status for tracked resources.

    Sprint 9.5: aligned with ``docs/EDITIONS.md`` §2.1. Counted resources:
    users, orgs, api_keys, plugin_slots. Config values: history_days,
    rate_limit_rpm. Devices/Dashboards/Automations/Variables/Webhooks are
    unlimited and therefore not exposed here.

    The license layer (``GET /api/v1/license``) carries the authoritative
    per-tier values; this endpoint reflects the running settings (env
    vars) and counts current rows. Frontend uses both: license for the
    edition badge + tier display, this for the soft-limit-warning bar.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetSystemLimitsApiV1SystemLimitsGetResponseGetSystemLimitsApiV1SystemLimitsGet
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
