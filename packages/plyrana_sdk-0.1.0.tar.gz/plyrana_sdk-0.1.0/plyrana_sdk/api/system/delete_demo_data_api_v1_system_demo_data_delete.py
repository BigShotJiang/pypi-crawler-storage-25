from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_demo_data_api_v1_system_demo_data_delete_response_delete_demo_data_api_v1_system_demo_data_delete import (
    DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/v1/system/demo-data",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete | None:
    if response.status_code == 200:
        response_200 = DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete.from_dict(
            response.json()
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete]:
    """Delete Demo Data

     Remove all demo data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete | None:
    """Delete Demo Data

     Remove all demo data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete]:
    """Delete Demo Data

     Remove all demo data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete | None:
    """Delete Demo Data

     Remove all demo data.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteDemoDataApiV1SystemDemoDataDeleteResponseDeleteDemoDataApiV1SystemDemoDataDelete
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
