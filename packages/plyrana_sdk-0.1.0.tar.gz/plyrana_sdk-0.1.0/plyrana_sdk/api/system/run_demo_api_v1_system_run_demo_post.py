from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.run_demo_api_v1_system_run_demo_post_response_run_demo_api_v1_system_run_demo_post import (
    RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    sequence: str | Unset = "teaser",
    speed: float | Unset = 1.0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["sequence"] = sequence

    params["speed"] = speed

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/system/run-demo",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost | None:
    if response.status_code == 200:
        response_200 = RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    sequence: str | Unset = "teaser",
    speed: float | Unset = 1.0,
) -> Response[HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost]:
    """Run Demo

     Start an automated demo presentation that controls the UI via MCP commands.

    Args:
        sequence (str | Unset): Demo sequence: teaser, short, full Default: 'teaser'.
        speed (float | Unset): Playback speed multiplier Default: 1.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost]
    """

    kwargs = _get_kwargs(
        sequence=sequence,
        speed=speed,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    sequence: str | Unset = "teaser",
    speed: float | Unset = 1.0,
) -> HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost | None:
    """Run Demo

     Start an automated demo presentation that controls the UI via MCP commands.

    Args:
        sequence (str | Unset): Demo sequence: teaser, short, full Default: 'teaser'.
        speed (float | Unset): Playback speed multiplier Default: 1.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost
    """

    return sync_detailed(
        client=client,
        sequence=sequence,
        speed=speed,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    sequence: str | Unset = "teaser",
    speed: float | Unset = 1.0,
) -> Response[HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost]:
    """Run Demo

     Start an automated demo presentation that controls the UI via MCP commands.

    Args:
        sequence (str | Unset): Demo sequence: teaser, short, full Default: 'teaser'.
        speed (float | Unset): Playback speed multiplier Default: 1.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost]
    """

    kwargs = _get_kwargs(
        sequence=sequence,
        speed=speed,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    sequence: str | Unset = "teaser",
    speed: float | Unset = 1.0,
) -> HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost | None:
    """Run Demo

     Start an automated demo presentation that controls the UI via MCP commands.

    Args:
        sequence (str | Unset): Demo sequence: teaser, short, full Default: 'teaser'.
        speed (float | Unset): Playback speed multiplier Default: 1.0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | RunDemoApiV1SystemRunDemoPostResponseRunDemoApiV1SystemRunDemoPost
    """

    return (
        await asyncio_detailed(
            client=client,
            sequence=sequence,
            speed=speed,
        )
    ).parsed
