from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.reset_all_data_api_v1_system_reset_delete_response_reset_all_data_api_v1_system_reset_delete import (
    ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/api/v1/system/reset",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete | None:
    if response.status_code == 200:
        response_200 = ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete.from_dict(
            response.json()
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete]:
    """Reset All Data

     Delete ALL user data for a clean slate.

    Clears: devices, variables (definitions + values + history), automations,
    alerts, dashboards (+ widgets), entities, webhooks, custom endpoints,
    custom tours, simulator configs, device profiles, components, events,
    audit log, notifications, OTA firmware, and reports.

    Protected by cap.admin capability in the auth guard.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete | None:
    """Reset All Data

     Delete ALL user data for a clean slate.

    Clears: devices, variables (definitions + values + history), automations,
    alerts, dashboards (+ widgets), entities, webhooks, custom endpoints,
    custom tours, simulator configs, device profiles, components, events,
    audit log, notifications, OTA firmware, and reports.

    Protected by cap.admin capability in the auth guard.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete]:
    """Reset All Data

     Delete ALL user data for a clean slate.

    Clears: devices, variables (definitions + values + history), automations,
    alerts, dashboards (+ widgets), entities, webhooks, custom endpoints,
    custom tours, simulator configs, device profiles, components, events,
    audit log, notifications, OTA firmware, and reports.

    Protected by cap.admin capability in the auth guard.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete | None:
    """Reset All Data

     Delete ALL user data for a clean slate.

    Clears: devices, variables (definitions + values + history), automations,
    alerts, dashboards (+ widgets), entities, webhooks, custom endpoints,
    custom tours, simulator configs, device profiles, components, events,
    audit log, notifications, OTA firmware, and reports.

    Protected by cap.admin capability in the auth guard.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ResetAllDataApiV1SystemResetDeleteResponseResetAllDataApiV1SystemResetDelete
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
