from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.load_demo_data_api_v1_system_demo_data_post_response_load_demo_data_api_v1_system_demo_data_post import (
    LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/system/demo-data",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost | None:
    if response.status_code == 200:
        response_200 = LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost.from_dict(
            response.json()
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost]:
    """Load Demo Data

     Load demo data (devices, variables, automations, dashboard).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost | None:
    """Load Demo Data

     Load demo data (devices, variables, automations, dashboard).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost]:
    """Load Demo Data

     Load demo data (devices, variables, automations, dashboard).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost | None:
    """Load Demo Data

     Load demo data (devices, variables, automations, dashboard).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        LoadDemoDataApiV1SystemDemoDataPostResponseLoadDemoDataApiV1SystemDemoDataPost
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
