from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.anomaly_hint import AnomalyHint
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    hours: int | Unset = 24,
    threshold: float | Unset = 2.5,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["hours"] = hours

    params["threshold"] = threshold

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/observability/anomalies",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[AnomalyHint] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = AnomalyHint.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[AnomalyHint]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    hours: int | Unset = 24,
    threshold: float | Unset = 2.5,
) -> Response[HTTPValidationError | list[AnomalyHint]]:
    """Detect Anomalies

     Simple z-score anomaly detection on recent variable history.

    Args:
        hours (int | Unset):  Default: 24.
        threshold (float | Unset):  Default: 2.5.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[AnomalyHint]]
    """

    kwargs = _get_kwargs(
        hours=hours,
        threshold=threshold,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    hours: int | Unset = 24,
    threshold: float | Unset = 2.5,
) -> HTTPValidationError | list[AnomalyHint] | None:
    """Detect Anomalies

     Simple z-score anomaly detection on recent variable history.

    Args:
        hours (int | Unset):  Default: 24.
        threshold (float | Unset):  Default: 2.5.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[AnomalyHint]
    """

    return sync_detailed(
        client=client,
        hours=hours,
        threshold=threshold,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    hours: int | Unset = 24,
    threshold: float | Unset = 2.5,
) -> Response[HTTPValidationError | list[AnomalyHint]]:
    """Detect Anomalies

     Simple z-score anomaly detection on recent variable history.

    Args:
        hours (int | Unset):  Default: 24.
        threshold (float | Unset):  Default: 2.5.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[AnomalyHint]]
    """

    kwargs = _get_kwargs(
        hours=hours,
        threshold=threshold,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    hours: int | Unset = 24,
    threshold: float | Unset = 2.5,
) -> HTTPValidationError | list[AnomalyHint] | None:
    """Detect Anomalies

     Simple z-score anomaly detection on recent variable history.

    Args:
        hours (int | Unset):  Default: 24.
        threshold (float | Unset):  Default: 2.5.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[AnomalyHint]
    """

    return (
        await asyncio_detailed(
            client=client,
            hours=hours,
            threshold=threshold,
        )
    ).parsed
