from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.trace_entry import TraceEntry
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    minutes: int | Unset = 60,
    device_uid: None | str | Unset = UNSET,
    limit: int | Unset = 200,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["minutes"] = minutes

    json_device_uid: None | str | Unset
    if isinstance(device_uid, Unset):
        json_device_uid = UNSET
    else:
        json_device_uid = device_uid
    params["device_uid"] = json_device_uid

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/observability/traces",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[TraceEntry] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = TraceEntry.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[TraceEntry]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    minutes: int | Unset = 60,
    device_uid: None | str | Unset = UNSET,
    limit: int | Unset = 200,
) -> Response[HTTPValidationError | list[TraceEntry]]:
    """Get Traces

     Timeline view: correlated events, audit entries, alerts, and automations.

    Args:
        minutes (int | Unset):  Default: 60.
        device_uid (None | str | Unset):
        limit (int | Unset):  Default: 200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[TraceEntry]]
    """

    kwargs = _get_kwargs(
        minutes=minutes,
        device_uid=device_uid,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    minutes: int | Unset = 60,
    device_uid: None | str | Unset = UNSET,
    limit: int | Unset = 200,
) -> HTTPValidationError | list[TraceEntry] | None:
    """Get Traces

     Timeline view: correlated events, audit entries, alerts, and automations.

    Args:
        minutes (int | Unset):  Default: 60.
        device_uid (None | str | Unset):
        limit (int | Unset):  Default: 200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[TraceEntry]
    """

    return sync_detailed(
        client=client,
        minutes=minutes,
        device_uid=device_uid,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    minutes: int | Unset = 60,
    device_uid: None | str | Unset = UNSET,
    limit: int | Unset = 200,
) -> Response[HTTPValidationError | list[TraceEntry]]:
    """Get Traces

     Timeline view: correlated events, audit entries, alerts, and automations.

    Args:
        minutes (int | Unset):  Default: 60.
        device_uid (None | str | Unset):
        limit (int | Unset):  Default: 200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[TraceEntry]]
    """

    kwargs = _get_kwargs(
        minutes=minutes,
        device_uid=device_uid,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    minutes: int | Unset = 60,
    device_uid: None | str | Unset = UNSET,
    limit: int | Unset = 200,
) -> HTTPValidationError | list[TraceEntry] | None:
    """Get Traces

     Timeline view: correlated events, audit entries, alerts, and automations.

    Args:
        minutes (int | Unset):  Default: 60.
        device_uid (None | str | Unset):
        limit (int | Unset):  Default: 200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[TraceEntry]
    """

    return (
        await asyncio_detailed(
            client=client,
            minutes=minutes,
            device_uid=device_uid,
            limit=limit,
        )
    ).parsed
