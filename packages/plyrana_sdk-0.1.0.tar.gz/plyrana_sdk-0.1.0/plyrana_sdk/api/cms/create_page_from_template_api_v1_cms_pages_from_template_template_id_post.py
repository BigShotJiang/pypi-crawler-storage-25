from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_page_out import CmsPageOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    template_id: str,
    *,
    slug: str,
    title: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["slug"] = slug

    params["title"] = title

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/cms/pages/from-template/{template_id}".format(
            template_id=quote(str(template_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsPageOut | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = CmsPageOut.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsPageOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    template_id: str,
    *,
    client: AuthenticatedClient,
    slug: str,
    title: str,
) -> Response[CmsPageOut | HTTPValidationError]:
    """Create Page From Template

     Create a new CMS page from a predefined template.

    Args:
        template_id (str):
        slug (str):
        title (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        template_id=template_id,
        slug=slug,
        title=title,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    template_id: str,
    *,
    client: AuthenticatedClient,
    slug: str,
    title: str,
) -> CmsPageOut | HTTPValidationError | None:
    """Create Page From Template

     Create a new CMS page from a predefined template.

    Args:
        template_id (str):
        slug (str):
        title (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageOut | HTTPValidationError
    """

    return sync_detailed(
        template_id=template_id,
        client=client,
        slug=slug,
        title=title,
    ).parsed


async def asyncio_detailed(
    template_id: str,
    *,
    client: AuthenticatedClient,
    slug: str,
    title: str,
) -> Response[CmsPageOut | HTTPValidationError]:
    """Create Page From Template

     Create a new CMS page from a predefined template.

    Args:
        template_id (str):
        slug (str):
        title (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        template_id=template_id,
        slug=slug,
        title=title,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    template_id: str,
    *,
    client: AuthenticatedClient,
    slug: str,
    title: str,
) -> CmsPageOut | HTTPValidationError | None:
    """Create Page From Template

     Create a new CMS page from a predefined template.

    Args:
        template_id (str):
        slug (str):
        title (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            template_id=template_id,
            client=client,
            slug=slug,
            title=title,
        )
    ).parsed
