from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_page_version_out import CmsPageVersionOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    page_id: int,
    ver: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/cms/pages/{page_id}/versions/{ver}".format(
            page_id=quote(str(page_id), safe=""),
            ver=quote(str(ver), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsPageVersionOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CmsPageVersionOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsPageVersionOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    page_id: int,
    ver: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsPageVersionOut | HTTPValidationError]:
    """Get Page Version

    Args:
        page_id (int):
        ver (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageVersionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        page_id=page_id,
        ver=ver,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    page_id: int,
    ver: int,
    *,
    client: AuthenticatedClient,
) -> CmsPageVersionOut | HTTPValidationError | None:
    """Get Page Version

    Args:
        page_id (int):
        ver (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageVersionOut | HTTPValidationError
    """

    return sync_detailed(
        page_id=page_id,
        ver=ver,
        client=client,
    ).parsed


async def asyncio_detailed(
    page_id: int,
    ver: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsPageVersionOut | HTTPValidationError]:
    """Get Page Version

    Args:
        page_id (int):
        ver (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageVersionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        page_id=page_id,
        ver=ver,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    page_id: int,
    ver: int,
    *,
    client: AuthenticatedClient,
) -> CmsPageVersionOut | HTTPValidationError | None:
    """Get Page Version

    Args:
        page_id (int):
        ver (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageVersionOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            page_id=page_id,
            ver=ver,
            client=client,
        )
    ).parsed
