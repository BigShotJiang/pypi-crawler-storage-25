from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_page_out import CmsPageOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    page_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/cms/pages/{page_id}/unarchive".format(
            page_id=quote(str(page_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsPageOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CmsPageOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsPageOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    page_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsPageOut | HTTPValidationError]:
    """Unarchive Page

     Restore an archived page to draft status.

    Args:
        page_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        page_id=page_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    page_id: int,
    *,
    client: AuthenticatedClient,
) -> CmsPageOut | HTTPValidationError | None:
    """Unarchive Page

     Restore an archived page to draft status.

    Args:
        page_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageOut | HTTPValidationError
    """

    return sync_detailed(
        page_id=page_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    page_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[CmsPageOut | HTTPValidationError]:
    """Unarchive Page

     Restore an archived page to draft status.

    Args:
        page_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsPageOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        page_id=page_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    page_id: int,
    *,
    client: AuthenticatedClient,
) -> CmsPageOut | HTTPValidationError | None:
    """Unarchive Page

     Restore an archived page to draft status.

    Args:
        page_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsPageOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            page_id=page_id,
            client=client,
        )
    ).parsed
