from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.audit_entry_out import AuditEntryOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    actor_id: None | str | Unset = UNSET,
    action: None | str | Unset = UNSET,
    limit: int | Unset = 100,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_actor_id: None | str | Unset
    if isinstance(actor_id, Unset):
        json_actor_id = UNSET
    else:
        json_actor_id = actor_id
    params["actor_id"] = json_actor_id

    json_action: None | str | Unset
    if isinstance(action, Unset):
        json_action = UNSET
    else:
        json_action = action
    params["action"] = json_action

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/audit",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[AuditEntryOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = AuditEntryOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[AuditEntryOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    actor_id: None | str | Unset = UNSET,
    action: None | str | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[HTTPValidationError | list[AuditEntryOut]]:
    """List Audit Entries

    Args:
        actor_id (None | str | Unset):
        action (None | str | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[AuditEntryOut]]
    """

    kwargs = _get_kwargs(
        actor_id=actor_id,
        action=action,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    actor_id: None | str | Unset = UNSET,
    action: None | str | Unset = UNSET,
    limit: int | Unset = 100,
) -> HTTPValidationError | list[AuditEntryOut] | None:
    """List Audit Entries

    Args:
        actor_id (None | str | Unset):
        action (None | str | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[AuditEntryOut]
    """

    return sync_detailed(
        client=client,
        actor_id=actor_id,
        action=action,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    actor_id: None | str | Unset = UNSET,
    action: None | str | Unset = UNSET,
    limit: int | Unset = 100,
) -> Response[HTTPValidationError | list[AuditEntryOut]]:
    """List Audit Entries

    Args:
        actor_id (None | str | Unset):
        action (None | str | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[AuditEntryOut]]
    """

    kwargs = _get_kwargs(
        actor_id=actor_id,
        action=action,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    actor_id: None | str | Unset = UNSET,
    action: None | str | Unset = UNSET,
    limit: int | Unset = 100,
) -> HTTPValidationError | list[AuditEntryOut] | None:
    """List Audit Entries

    Args:
        actor_id (None | str | Unset):
        action (None | str | Unset):
        limit (int | Unset):  Default: 100.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[AuditEntryOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            actor_id=actor_id,
            action=action,
            limit=limit,
        )
    ).parsed
