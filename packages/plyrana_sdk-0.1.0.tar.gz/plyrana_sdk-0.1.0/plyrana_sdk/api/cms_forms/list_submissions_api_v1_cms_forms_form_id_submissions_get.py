from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_form_submission_out import CmsFormSubmissionOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    form_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/cms/forms/{form_id}/submissions".format(
            form_id=quote(str(form_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[CmsFormSubmissionOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = CmsFormSubmissionOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[CmsFormSubmissionOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    form_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | list[CmsFormSubmissionOut]]:
    """List Submissions

    Args:
        form_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[CmsFormSubmissionOut]]
    """

    kwargs = _get_kwargs(
        form_id=form_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    form_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | list[CmsFormSubmissionOut] | None:
    """List Submissions

    Args:
        form_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[CmsFormSubmissionOut]
    """

    return sync_detailed(
        form_id=form_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    form_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | list[CmsFormSubmissionOut]]:
    """List Submissions

    Args:
        form_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[CmsFormSubmissionOut]]
    """

    kwargs = _get_kwargs(
        form_id=form_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    form_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | list[CmsFormSubmissionOut] | None:
    """List Submissions

    Args:
        form_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[CmsFormSubmissionOut]
    """

    return (
        await asyncio_detailed(
            form_id=form_id,
            client=client,
        )
    ).parsed
