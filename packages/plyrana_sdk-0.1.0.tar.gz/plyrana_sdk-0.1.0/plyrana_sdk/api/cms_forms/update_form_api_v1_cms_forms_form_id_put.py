from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cms_form_out import CmsFormOut
from ...models.cms_form_update import CmsFormUpdate
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    form_id: int,
    *,
    body: CmsFormUpdate,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/cms/forms/{form_id}".format(
            form_id=quote(str(form_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CmsFormOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = CmsFormOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CmsFormOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    form_id: int,
    *,
    client: AuthenticatedClient,
    body: CmsFormUpdate,
) -> Response[CmsFormOut | HTTPValidationError]:
    """Update Form

    Args:
        form_id (int):
        body (CmsFormUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsFormOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        form_id=form_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    form_id: int,
    *,
    client: AuthenticatedClient,
    body: CmsFormUpdate,
) -> CmsFormOut | HTTPValidationError | None:
    """Update Form

    Args:
        form_id (int):
        body (CmsFormUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsFormOut | HTTPValidationError
    """

    return sync_detailed(
        form_id=form_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    form_id: int,
    *,
    client: AuthenticatedClient,
    body: CmsFormUpdate,
) -> Response[CmsFormOut | HTTPValidationError]:
    """Update Form

    Args:
        form_id (int):
        body (CmsFormUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CmsFormOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        form_id=form_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    form_id: int,
    *,
    client: AuthenticatedClient,
    body: CmsFormUpdate,
) -> CmsFormOut | HTTPValidationError | None:
    """Update Form

    Args:
        form_id (int):
        body (CmsFormUpdate):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CmsFormOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            form_id=form_id,
            client=client,
            body=body,
        )
    ).parsed
