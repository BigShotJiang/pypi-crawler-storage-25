from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.effect_out import EffectOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    after_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    kind: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_after_id: int | None | Unset
    if isinstance(after_id, Unset):
        json_after_id = UNSET
    else:
        json_after_id = after_id
    params["after_id"] = json_after_id

    params["limit"] = limit

    json_kind: None | str | Unset
    if isinstance(kind, Unset):
        json_kind = UNSET
    else:
        json_kind = kind
    params["kind"] = json_kind

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/effects",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[EffectOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = EffectOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[EffectOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    after_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    kind: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[EffectOut]]:
    """List Effects

    Args:
        after_id (int | None | Unset):
        limit (int | Unset):  Default: 100.
        kind (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[EffectOut]]
    """

    kwargs = _get_kwargs(
        after_id=after_id,
        limit=limit,
        kind=kind,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    after_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    kind: None | str | Unset = UNSET,
) -> HTTPValidationError | list[EffectOut] | None:
    """List Effects

    Args:
        after_id (int | None | Unset):
        limit (int | Unset):  Default: 100.
        kind (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[EffectOut]
    """

    return sync_detailed(
        client=client,
        after_id=after_id,
        limit=limit,
        kind=kind,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    after_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    kind: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[EffectOut]]:
    """List Effects

    Args:
        after_id (int | None | Unset):
        limit (int | Unset):  Default: 100.
        kind (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[EffectOut]]
    """

    kwargs = _get_kwargs(
        after_id=after_id,
        limit=limit,
        kind=kind,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    after_id: int | None | Unset = UNSET,
    limit: int | Unset = 100,
    kind: None | str | Unset = UNSET,
) -> HTTPValidationError | list[EffectOut] | None:
    """List Effects

    Args:
        after_id (int | None | Unset):
        limit (int | Unset):  Default: 100.
        kind (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[EffectOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            after_id=after_id,
            limit=limit,
            kind=kind,
        )
    ).parsed
