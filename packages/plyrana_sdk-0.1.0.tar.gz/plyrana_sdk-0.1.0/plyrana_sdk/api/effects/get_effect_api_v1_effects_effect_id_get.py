from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.effect_out import EffectOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    effect_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/effects/{effect_id}".format(
            effect_id=quote(str(effect_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EffectOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EffectOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EffectOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    effect_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[EffectOut | HTTPValidationError]:
    """Get Effect

    Args:
        effect_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EffectOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        effect_id=effect_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    effect_id: str,
    *,
    client: AuthenticatedClient,
) -> EffectOut | HTTPValidationError | None:
    """Get Effect

    Args:
        effect_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EffectOut | HTTPValidationError
    """

    return sync_detailed(
        effect_id=effect_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    effect_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[EffectOut | HTTPValidationError]:
    """Get Effect

    Args:
        effect_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EffectOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        effect_id=effect_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    effect_id: str,
    *,
    client: AuthenticatedClient,
) -> EffectOut | HTTPValidationError | None:
    """Get Effect

    Args:
        effect_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EffectOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            effect_id=effect_id,
            client=client,
        )
    ).parsed
