from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.feature_flags_list_out import FeatureFlagsListOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    public: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["public"] = public

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/config/features",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FeatureFlagsListOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FeatureFlagsListOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FeatureFlagsListOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    public: bool | Unset = False,
) -> Response[FeatureFlagsListOut | HTTPValidationError]:
    """List Feature Flags

     List every togglable feature with its current runtime state.

    Sprint 8.5: includes ``maturity`` (stable/beta/alpha/coming_soon) and
    honors ``HUBEX_DEMO_MODE`` for ``?public=true`` requests.

    Args:
        public (bool | Unset): If true and HUBEX_DEMO_MODE=1 is set, hide non-stable/non-beta
            features. Use for the public nav / unauthenticated discovery. Settings → Features always
            lists everything (admin tool). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FeatureFlagsListOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        public=public,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    public: bool | Unset = False,
) -> FeatureFlagsListOut | HTTPValidationError | None:
    """List Feature Flags

     List every togglable feature with its current runtime state.

    Sprint 8.5: includes ``maturity`` (stable/beta/alpha/coming_soon) and
    honors ``HUBEX_DEMO_MODE`` for ``?public=true`` requests.

    Args:
        public (bool | Unset): If true and HUBEX_DEMO_MODE=1 is set, hide non-stable/non-beta
            features. Use for the public nav / unauthenticated discovery. Settings → Features always
            lists everything (admin tool). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FeatureFlagsListOut | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        public=public,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    public: bool | Unset = False,
) -> Response[FeatureFlagsListOut | HTTPValidationError]:
    """List Feature Flags

     List every togglable feature with its current runtime state.

    Sprint 8.5: includes ``maturity`` (stable/beta/alpha/coming_soon) and
    honors ``HUBEX_DEMO_MODE`` for ``?public=true`` requests.

    Args:
        public (bool | Unset): If true and HUBEX_DEMO_MODE=1 is set, hide non-stable/non-beta
            features. Use for the public nav / unauthenticated discovery. Settings → Features always
            lists everything (admin tool). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FeatureFlagsListOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        public=public,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    public: bool | Unset = False,
) -> FeatureFlagsListOut | HTTPValidationError | None:
    """List Feature Flags

     List every togglable feature with its current runtime state.

    Sprint 8.5: includes ``maturity`` (stable/beta/alpha/coming_soon) and
    honors ``HUBEX_DEMO_MODE`` for ``?public=true`` requests.

    Args:
        public (bool | Unset): If true and HUBEX_DEMO_MODE=1 is set, hide non-stable/non-beta
            features. Use for the public nav / unauthenticated discovery. Settings → Features always
            lists everything (admin tool). Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FeatureFlagsListOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            public=public,
        )
    ).parsed
