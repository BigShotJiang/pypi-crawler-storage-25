from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.secret_meta_out import SecretMetaOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    namespace: None | str | Unset = UNSET,
    key_prefix: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_namespace: None | str | Unset
    if isinstance(namespace, Unset):
        json_namespace = UNSET
    else:
        json_namespace = namespace
    params["namespace"] = json_namespace

    json_key_prefix: None | str | Unset
    if isinstance(key_prefix, Unset):
        json_key_prefix = UNSET
    else:
        json_key_prefix = key_prefix
    params["key_prefix"] = json_key_prefix

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/secrets",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[SecretMetaOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = SecretMetaOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[SecretMetaOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    namespace: None | str | Unset = UNSET,
    key_prefix: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[SecretMetaOut]]:
    """List Secrets

    Args:
        namespace (None | str | Unset):
        key_prefix (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SecretMetaOut]]
    """

    kwargs = _get_kwargs(
        namespace=namespace,
        key_prefix=key_prefix,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    namespace: None | str | Unset = UNSET,
    key_prefix: None | str | Unset = UNSET,
) -> HTTPValidationError | list[SecretMetaOut] | None:
    """List Secrets

    Args:
        namespace (None | str | Unset):
        key_prefix (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SecretMetaOut]
    """

    return sync_detailed(
        client=client,
        namespace=namespace,
        key_prefix=key_prefix,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    namespace: None | str | Unset = UNSET,
    key_prefix: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[SecretMetaOut]]:
    """List Secrets

    Args:
        namespace (None | str | Unset):
        key_prefix (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SecretMetaOut]]
    """

    kwargs = _get_kwargs(
        namespace=namespace,
        key_prefix=key_prefix,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    namespace: None | str | Unset = UNSET,
    key_prefix: None | str | Unset = UNSET,
) -> HTTPValidationError | list[SecretMetaOut] | None:
    """List Secrets

    Args:
        namespace (None | str | Unset):
        key_prefix (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SecretMetaOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            namespace=namespace,
            key_prefix=key_prefix,
        )
    ).parsed
