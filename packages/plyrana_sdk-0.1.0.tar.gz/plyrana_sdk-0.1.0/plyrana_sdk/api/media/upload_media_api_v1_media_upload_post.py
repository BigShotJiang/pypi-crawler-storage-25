from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_upload_media_api_v1_media_upload_post import BodyUploadMediaApiV1MediaUploadPost
from ...models.http_validation_error import HTTPValidationError
from ...models.media_asset_out import MediaAssetOut
from ...types import Response


def _get_kwargs(
    *,
    body: BodyUploadMediaApiV1MediaUploadPost,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/media/upload",
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | MediaAssetOut | None:
    if response.status_code == 201:
        response_201 = MediaAssetOut.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | MediaAssetOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadMediaApiV1MediaUploadPost,
) -> Response[HTTPValidationError | MediaAssetOut]:
    """Upload Media

     Upload a new media asset. Max 20MB. Images, videos, PDFs.

    Args:
        body (BodyUploadMediaApiV1MediaUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MediaAssetOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: BodyUploadMediaApiV1MediaUploadPost,
) -> HTTPValidationError | MediaAssetOut | None:
    """Upload Media

     Upload a new media asset. Max 20MB. Images, videos, PDFs.

    Args:
        body (BodyUploadMediaApiV1MediaUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MediaAssetOut
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BodyUploadMediaApiV1MediaUploadPost,
) -> Response[HTTPValidationError | MediaAssetOut]:
    """Upload Media

     Upload a new media asset. Max 20MB. Images, videos, PDFs.

    Args:
        body (BodyUploadMediaApiV1MediaUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MediaAssetOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BodyUploadMediaApiV1MediaUploadPost,
) -> HTTPValidationError | MediaAssetOut | None:
    """Upload Media

     Upload a new media asset. Max 20MB. Images, videos, PDFs.

    Args:
        body (BodyUploadMediaApiV1MediaUploadPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MediaAssetOut
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
