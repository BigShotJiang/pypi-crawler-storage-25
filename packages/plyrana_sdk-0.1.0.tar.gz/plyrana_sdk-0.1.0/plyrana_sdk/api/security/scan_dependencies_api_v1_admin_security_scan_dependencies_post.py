from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.security_scan_out import SecurityScanOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    scope: str | Unset = "all",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["scope"] = scope

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/admin/security/scan/dependencies",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[SecurityScanOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = SecurityScanOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[SecurityScanOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    scope: str | Unset = "all",
) -> Response[HTTPValidationError | list[SecurityScanOut]]:
    """Scan Dependencies

     Run pip-audit + npm audit and persist one SecurityScan row per scanner.

    Sprint 10 — Phase A. Synchronous (the audits take 10-60 seconds).
    Returns the persisted rows (one per scanner that ran). Failures of
    one scanner do not prevent the other from running — each yields its
    own row with status='failed' + error_code/error_message.

    Args:
        scope (str | Unset):  Default: 'all'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SecurityScanOut]]
    """

    kwargs = _get_kwargs(
        scope=scope,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    scope: str | Unset = "all",
) -> HTTPValidationError | list[SecurityScanOut] | None:
    """Scan Dependencies

     Run pip-audit + npm audit and persist one SecurityScan row per scanner.

    Sprint 10 — Phase A. Synchronous (the audits take 10-60 seconds).
    Returns the persisted rows (one per scanner that ran). Failures of
    one scanner do not prevent the other from running — each yields its
    own row with status='failed' + error_code/error_message.

    Args:
        scope (str | Unset):  Default: 'all'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SecurityScanOut]
    """

    return sync_detailed(
        client=client,
        scope=scope,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    scope: str | Unset = "all",
) -> Response[HTTPValidationError | list[SecurityScanOut]]:
    """Scan Dependencies

     Run pip-audit + npm audit and persist one SecurityScan row per scanner.

    Sprint 10 — Phase A. Synchronous (the audits take 10-60 seconds).
    Returns the persisted rows (one per scanner that ran). Failures of
    one scanner do not prevent the other from running — each yields its
    own row with status='failed' + error_code/error_message.

    Args:
        scope (str | Unset):  Default: 'all'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SecurityScanOut]]
    """

    kwargs = _get_kwargs(
        scope=scope,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    scope: str | Unset = "all",
) -> HTTPValidationError | list[SecurityScanOut] | None:
    """Scan Dependencies

     Run pip-audit + npm audit and persist one SecurityScan row per scanner.

    Sprint 10 — Phase A. Synchronous (the audits take 10-60 seconds).
    Returns the persisted rows (one per scanner that ran). Failures of
    one scanner do not prevent the other from running — each yields its
    own row with status='failed' + error_code/error_message.

    Args:
        scope (str | Unset):  Default: 'all'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SecurityScanOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            scope=scope,
        )
    ).parsed
