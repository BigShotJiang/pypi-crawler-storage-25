from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.security_scan_out import SecurityScanOut
from ...types import Response


def _get_kwargs(
    scan_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/admin/security/scans/{scan_id}".format(
            scan_id=quote(str(scan_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SecurityScanOut | None:
    if response.status_code == 200:
        response_200 = SecurityScanOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SecurityScanOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    scan_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | SecurityScanOut]:
    """Get Scan

     Full scan detail incl. findings_json.

    Args:
        scan_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SecurityScanOut]
    """

    kwargs = _get_kwargs(
        scan_id=scan_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    scan_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | SecurityScanOut | None:
    """Get Scan

     Full scan detail incl. findings_json.

    Args:
        scan_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SecurityScanOut
    """

    return sync_detailed(
        scan_id=scan_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    scan_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | SecurityScanOut]:
    """Get Scan

     Full scan detail incl. findings_json.

    Args:
        scan_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SecurityScanOut]
    """

    kwargs = _get_kwargs(
        scan_id=scan_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    scan_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | SecurityScanOut | None:
    """Get Scan

     Full scan detail incl. findings_json.

    Args:
        scan_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SecurityScanOut
    """

    return (
        await asyncio_detailed(
            scan_id=scan_id,
            client=client,
        )
    ).parsed
