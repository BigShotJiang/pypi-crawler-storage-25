from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.image_scan_in import ImageScanIn
from ...models.security_scan_out import SecurityScanOut
from ...types import Response


def _get_kwargs(
    *,
    body: ImageScanIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/admin/security/scan/image",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SecurityScanOut | None:
    if response.status_code == 202:
        response_202 = SecurityScanOut.from_dict(response.json())

        return response_202

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SecurityScanOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ImageScanIn,
) -> Response[HTTPValidationError | SecurityScanOut]:
    """Scan Image

     Queue a Trivy image scan as an ephemeral sidecar container.

    Returns 202 + the queued SecurityScan row immediately. The actual
    scan runs in the background (10-60s). Poll GET /scans/{id} for status.

    Requires the ``orchestrator`` feature + a configured Portainer
    backend. On absence: row gets persisted with status='failed' +
    error_code='PORTAINER_UNAVAILABLE' so the UI can surface it.

    Args:
        body (ImageScanIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SecurityScanOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ImageScanIn,
) -> HTTPValidationError | SecurityScanOut | None:
    """Scan Image

     Queue a Trivy image scan as an ephemeral sidecar container.

    Returns 202 + the queued SecurityScan row immediately. The actual
    scan runs in the background (10-60s). Poll GET /scans/{id} for status.

    Requires the ``orchestrator`` feature + a configured Portainer
    backend. On absence: row gets persisted with status='failed' +
    error_code='PORTAINER_UNAVAILABLE' so the UI can surface it.

    Args:
        body (ImageScanIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SecurityScanOut
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ImageScanIn,
) -> Response[HTTPValidationError | SecurityScanOut]:
    """Scan Image

     Queue a Trivy image scan as an ephemeral sidecar container.

    Returns 202 + the queued SecurityScan row immediately. The actual
    scan runs in the background (10-60s). Poll GET /scans/{id} for status.

    Requires the ``orchestrator`` feature + a configured Portainer
    backend. On absence: row gets persisted with status='failed' +
    error_code='PORTAINER_UNAVAILABLE' so the UI can surface it.

    Args:
        body (ImageScanIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SecurityScanOut]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ImageScanIn,
) -> HTTPValidationError | SecurityScanOut | None:
    """Scan Image

     Queue a Trivy image scan as an ephemeral sidecar container.

    Returns 202 + the queued SecurityScan row immediately. The actual
    scan runs in the background (10-60s). Poll GET /scans/{id} for status.

    Requires the ``orchestrator`` feature + a configured Portainer
    backend. On absence: row gets persisted with status='failed' +
    error_code='PORTAINER_UNAVAILABLE' so the UI can surface it.

    Args:
        body (ImageScanIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SecurityScanOut
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
