from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.signal_read_out import SignalReadOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    stream: str,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["stream"] = stream

    json_cursor: int | None | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/signals",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SignalReadOut | None:
    if response.status_code == 200:
        response_200 = SignalReadOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SignalReadOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    stream: str,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[HTTPValidationError | SignalReadOut]:
    """List Signals

    Args:
        stream (str):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SignalReadOut]
    """

    kwargs = _get_kwargs(
        stream=stream,
        cursor=cursor,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    stream: str,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> HTTPValidationError | SignalReadOut | None:
    """List Signals

    Args:
        stream (str):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SignalReadOut
    """

    return sync_detailed(
        client=client,
        stream=stream,
        cursor=cursor,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    stream: str,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[HTTPValidationError | SignalReadOut]:
    """List Signals

    Args:
        stream (str):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SignalReadOut]
    """

    kwargs = _get_kwargs(
        stream=stream,
        cursor=cursor,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    stream: str,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> HTTPValidationError | SignalReadOut | None:
    """List Signals

    Args:
        stream (str):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SignalReadOut
    """

    return (
        await asyncio_detailed(
            client=client,
            stream=stream,
            cursor=cursor,
            limit=limit,
        )
    ).parsed
