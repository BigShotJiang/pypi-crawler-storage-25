from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.member_role_update_in import MemberRoleUpdateIn
from ...models.org_member_out import OrgMemberOut
from ...types import Response


def _get_kwargs(
    org_id: int,
    target_user_id: int,
    *,
    body: MemberRoleUpdateIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/v1/orgs/{org_id}/members/{target_user_id}".format(
            org_id=quote(str(org_id), safe=""),
            target_user_id=quote(str(target_user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | OrgMemberOut | None:
    if response.status_code == 200:
        response_200 = OrgMemberOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | OrgMemberOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    org_id: int,
    target_user_id: int,
    *,
    client: AuthenticatedClient,
    body: MemberRoleUpdateIn,
) -> Response[HTTPValidationError | OrgMemberOut]:
    """Update Member Role

    Args:
        org_id (int):
        target_user_id (int):
        body (MemberRoleUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | OrgMemberOut]
    """

    kwargs = _get_kwargs(
        org_id=org_id,
        target_user_id=target_user_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    org_id: int,
    target_user_id: int,
    *,
    client: AuthenticatedClient,
    body: MemberRoleUpdateIn,
) -> HTTPValidationError | OrgMemberOut | None:
    """Update Member Role

    Args:
        org_id (int):
        target_user_id (int):
        body (MemberRoleUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | OrgMemberOut
    """

    return sync_detailed(
        org_id=org_id,
        target_user_id=target_user_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    org_id: int,
    target_user_id: int,
    *,
    client: AuthenticatedClient,
    body: MemberRoleUpdateIn,
) -> Response[HTTPValidationError | OrgMemberOut]:
    """Update Member Role

    Args:
        org_id (int):
        target_user_id (int):
        body (MemberRoleUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | OrgMemberOut]
    """

    kwargs = _get_kwargs(
        org_id=org_id,
        target_user_id=target_user_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    org_id: int,
    target_user_id: int,
    *,
    client: AuthenticatedClient,
    body: MemberRoleUpdateIn,
) -> HTTPValidationError | OrgMemberOut | None:
    """Update Member Role

    Args:
        org_id (int):
        target_user_id (int):
        body (MemberRoleUpdateIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | OrgMemberOut
    """

    return (
        await asyncio_detailed(
            org_id=org_id,
            target_user_id=target_user_id,
            client=client,
            body=body,
        )
    ).parsed
