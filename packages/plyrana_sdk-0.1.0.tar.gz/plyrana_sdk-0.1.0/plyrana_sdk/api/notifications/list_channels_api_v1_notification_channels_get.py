from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.channel_out import ChannelOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    include_config: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["include_config"] = include_config

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/notification-channels",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[ChannelOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = ChannelOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[ChannelOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    include_config: bool | Unset = False,
) -> Response[HTTPValidationError | list[ChannelOut]]:
    """List Channels

     List all notification channels (newest first).

    Args:
        include_config (bool | Unset): Return raw config (admin diagnostics only) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[ChannelOut]]
    """

    kwargs = _get_kwargs(
        include_config=include_config,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    include_config: bool | Unset = False,
) -> HTTPValidationError | list[ChannelOut] | None:
    """List Channels

     List all notification channels (newest first).

    Args:
        include_config (bool | Unset): Return raw config (admin diagnostics only) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[ChannelOut]
    """

    return sync_detailed(
        client=client,
        include_config=include_config,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    include_config: bool | Unset = False,
) -> Response[HTTPValidationError | list[ChannelOut]]:
    """List Channels

     List all notification channels (newest first).

    Args:
        include_config (bool | Unset): Return raw config (admin diagnostics only) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[ChannelOut]]
    """

    kwargs = _get_kwargs(
        include_config=include_config,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    include_config: bool | Unset = False,
) -> HTTPValidationError | list[ChannelOut] | None:
    """List Channels

     List all notification channels (newest first).

    Args:
        include_config (bool | Unset): Return raw config (admin diagnostics only) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[ChannelOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            include_config=include_config,
        )
    ).parsed
