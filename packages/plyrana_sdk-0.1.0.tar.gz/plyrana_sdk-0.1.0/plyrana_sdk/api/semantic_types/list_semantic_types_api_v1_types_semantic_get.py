from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.semantic_type_out import SemanticTypeOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    builtin: bool | None | Unset = UNSET,
    base_type: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_builtin: bool | None | Unset
    if isinstance(builtin, Unset):
        json_builtin = UNSET
    else:
        json_builtin = builtin
    params["builtin"] = json_builtin

    json_base_type: None | str | Unset
    if isinstance(base_type, Unset):
        json_base_type = UNSET
    else:
        json_base_type = base_type
    params["base_type"] = json_base_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/types/semantic",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[SemanticTypeOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = SemanticTypeOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[SemanticTypeOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    builtin: bool | None | Unset = UNSET,
    base_type: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[SemanticTypeOut]]:
    """List Semantic Types

    Args:
        builtin (bool | None | Unset):
        base_type (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SemanticTypeOut]]
    """

    kwargs = _get_kwargs(
        builtin=builtin,
        base_type=base_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    builtin: bool | None | Unset = UNSET,
    base_type: None | str | Unset = UNSET,
) -> HTTPValidationError | list[SemanticTypeOut] | None:
    """List Semantic Types

    Args:
        builtin (bool | None | Unset):
        base_type (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SemanticTypeOut]
    """

    return sync_detailed(
        client=client,
        builtin=builtin,
        base_type=base_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    builtin: bool | None | Unset = UNSET,
    base_type: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | list[SemanticTypeOut]]:
    """List Semantic Types

    Args:
        builtin (bool | None | Unset):
        base_type (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SemanticTypeOut]]
    """

    kwargs = _get_kwargs(
        builtin=builtin,
        base_type=base_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    builtin: bool | None | Unset = UNSET,
    base_type: None | str | Unset = UNSET,
) -> HTTPValidationError | list[SemanticTypeOut] | None:
    """List Semantic Types

    Args:
        builtin (bool | None | Unset):
        base_type (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SemanticTypeOut]
    """

    return (
        await asyncio_detailed(
            client=client,
            builtin=builtin,
            base_type=base_type,
        )
    ).parsed
