from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.unit_conversion_out import UnitConversionOut
from ...types import Response


def _get_kwargs(
    type_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/types/semantic/{type_id}/conversions".format(
            type_id=quote(str(type_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[UnitConversionOut] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = UnitConversionOut.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[UnitConversionOut]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    type_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | list[UnitConversionOut]]:
    """List Conversions

    Args:
        type_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UnitConversionOut]]
    """

    kwargs = _get_kwargs(
        type_id=type_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    type_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | list[UnitConversionOut] | None:
    """List Conversions

    Args:
        type_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UnitConversionOut]
    """

    return sync_detailed(
        type_id=type_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    type_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | list[UnitConversionOut]]:
    """List Conversions

    Args:
        type_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[UnitConversionOut]]
    """

    kwargs = _get_kwargs(
        type_id=type_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    type_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | list[UnitConversionOut] | None:
    """List Conversions

    Args:
        type_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[UnitConversionOut]
    """

    return (
        await asyncio_detailed(
            type_id=type_id,
            client=client,
        )
    ).parsed
