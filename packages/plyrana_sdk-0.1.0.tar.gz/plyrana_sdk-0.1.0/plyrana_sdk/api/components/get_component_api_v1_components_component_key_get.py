from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.component_out import ComponentOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    component_key: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/components/{component_key}".format(
            component_key=quote(str(component_key), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ComponentOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ComponentOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ComponentOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    component_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ComponentOut | HTTPValidationError]:
    """Get Component

    Args:
        component_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ComponentOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        component_key=component_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    component_key: str,
    *,
    client: AuthenticatedClient,
) -> ComponentOut | HTTPValidationError | None:
    """Get Component

    Args:
        component_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ComponentOut | HTTPValidationError
    """

    return sync_detailed(
        component_key=component_key,
        client=client,
    ).parsed


async def asyncio_detailed(
    component_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ComponentOut | HTTPValidationError]:
    """Get Component

    Args:
        component_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ComponentOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        component_key=component_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    component_key: str,
    *,
    client: AuthenticatedClient,
) -> ComponentOut | HTTPValidationError | None:
    """Get Component

    Args:
        component_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ComponentOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            component_key=component_key,
            client=client,
        )
    ).parsed
