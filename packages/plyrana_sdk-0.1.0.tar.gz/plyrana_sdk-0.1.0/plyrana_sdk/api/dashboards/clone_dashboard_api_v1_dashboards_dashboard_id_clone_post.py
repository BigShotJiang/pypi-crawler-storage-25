from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.dashboard_clone_request import DashboardCloneRequest
from ...models.dashboard_out import DashboardOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    dashboard_id: int,
    *,
    body: DashboardCloneRequest | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/dashboards/{dashboard_id}/clone".format(
            dashboard_id=quote(str(dashboard_id), safe=""),
        ),
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DashboardOut | HTTPValidationError | None:
    if response.status_code == 201:
        response_201 = DashboardOut.from_dict(response.json())

        return response_201

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DashboardOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    dashboard_id: int,
    *,
    client: AuthenticatedClient,
    body: DashboardCloneRequest | Unset = UNSET,
) -> Response[DashboardOut | HTTPValidationError]:
    """Clone Dashboard

     Clone a dashboard with all its widgets.

    Args:
        dashboard_id (int):
        body (DashboardCloneRequest | Unset): Clone a dashboard with optional new name and entity
            scope.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        dashboard_id=dashboard_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    dashboard_id: int,
    *,
    client: AuthenticatedClient,
    body: DashboardCloneRequest | Unset = UNSET,
) -> DashboardOut | HTTPValidationError | None:
    """Clone Dashboard

     Clone a dashboard with all its widgets.

    Args:
        dashboard_id (int):
        body (DashboardCloneRequest | Unset): Clone a dashboard with optional new name and entity
            scope.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardOut | HTTPValidationError
    """

    return sync_detailed(
        dashboard_id=dashboard_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    dashboard_id: int,
    *,
    client: AuthenticatedClient,
    body: DashboardCloneRequest | Unset = UNSET,
) -> Response[DashboardOut | HTTPValidationError]:
    """Clone Dashboard

     Clone a dashboard with all its widgets.

    Args:
        dashboard_id (int):
        body (DashboardCloneRequest | Unset): Clone a dashboard with optional new name and entity
            scope.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        dashboard_id=dashboard_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    dashboard_id: int,
    *,
    client: AuthenticatedClient,
    body: DashboardCloneRequest | Unset = UNSET,
) -> DashboardOut | HTTPValidationError | None:
    """Clone Dashboard

     Clone a dashboard with all its widgets.

    Args:
        dashboard_id (int):
        body (DashboardCloneRequest | Unset): Clone a dashboard with optional new name and entity
            scope.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            dashboard_id=dashboard_id,
            client=client,
            body=body,
        )
    ).parsed
