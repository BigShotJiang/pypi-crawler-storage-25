from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.dashboard_out import DashboardOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    token: str,
    *,
    pin: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_pin: None | str | Unset
    if isinstance(pin, Unset):
        json_pin = UNSET
    else:
        json_pin = pin
    params["pin"] = json_pin

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/dashboards/embed/{token}".format(
            token=quote(str(token), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DashboardOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DashboardOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DashboardOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    token: str,
    *,
    client: AuthenticatedClient,
    pin: None | str | Unset = UNSET,
) -> Response[DashboardOut | HTTPValidationError]:
    """Get Embed Dashboard

     Access an embeddable dashboard. Returns data with permissive framing headers.

    Args:
        token (str):
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        token=token,
        pin=pin,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    token: str,
    *,
    client: AuthenticatedClient,
    pin: None | str | Unset = UNSET,
) -> DashboardOut | HTTPValidationError | None:
    """Get Embed Dashboard

     Access an embeddable dashboard. Returns data with permissive framing headers.

    Args:
        token (str):
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardOut | HTTPValidationError
    """

    return sync_detailed(
        token=token,
        client=client,
        pin=pin,
    ).parsed


async def asyncio_detailed(
    token: str,
    *,
    client: AuthenticatedClient,
    pin: None | str | Unset = UNSET,
) -> Response[DashboardOut | HTTPValidationError]:
    """Get Embed Dashboard

     Access an embeddable dashboard. Returns data with permissive framing headers.

    Args:
        token (str):
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        token=token,
        pin=pin,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    token: str,
    *,
    client: AuthenticatedClient,
    pin: None | str | Unset = UNSET,
) -> DashboardOut | HTTPValidationError | None:
    """Get Embed Dashboard

     Access an embeddable dashboard. Returns data with permissive framing headers.

    Args:
        token (str):
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            token=token,
            client=client,
            pin=pin,
        )
    ).parsed
