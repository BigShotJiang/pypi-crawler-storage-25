from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.variable_history_out import VariableHistoryOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    token: str,
    *,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: int | None | Unset = UNSET,
    limit: int | Unset = 300,
    pin: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["key"] = key

    json_device_uid: None | str | Unset
    if isinstance(device_uid, Unset):
        json_device_uid = UNSET
    else:
        json_device_uid = device_uid
    params["deviceUid"] = json_device_uid

    json_from_: int | None | Unset
    if isinstance(from_, Unset):
        json_from_ = UNSET
    else:
        json_from_ = from_
    params["from"] = json_from_

    params["limit"] = limit

    json_pin: None | str | Unset
    if isinstance(pin, Unset):
        json_pin = UNSET
    else:
        json_pin = pin
    params["pin"] = json_pin

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/dashboards/public/{token}/history".format(
            token=quote(str(token), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VariableHistoryOut | None:
    if response.status_code == 200:
        response_200 = VariableHistoryOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VariableHistoryOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    token: str,
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: int | None | Unset = UNSET,
    limit: int | Unset = 300,
    pin: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | VariableHistoryOut]:
    """Get Public Variable History

     Fetch variable history for a widget on a public dashboard.
    Only allows fetching data for variable_keys that actually exist
    on the dashboard's widgets (security guard).

    Args:
        token (str):
        key (str):
        device_uid (None | str | Unset):
        from_ (int | None | Unset):
        limit (int | Unset):  Default: 300.
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableHistoryOut]
    """

    kwargs = _get_kwargs(
        token=token,
        key=key,
        device_uid=device_uid,
        from_=from_,
        limit=limit,
        pin=pin,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    token: str,
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: int | None | Unset = UNSET,
    limit: int | Unset = 300,
    pin: None | str | Unset = UNSET,
) -> HTTPValidationError | VariableHistoryOut | None:
    """Get Public Variable History

     Fetch variable history for a widget on a public dashboard.
    Only allows fetching data for variable_keys that actually exist
    on the dashboard's widgets (security guard).

    Args:
        token (str):
        key (str):
        device_uid (None | str | Unset):
        from_ (int | None | Unset):
        limit (int | Unset):  Default: 300.
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableHistoryOut
    """

    return sync_detailed(
        token=token,
        client=client,
        key=key,
        device_uid=device_uid,
        from_=from_,
        limit=limit,
        pin=pin,
    ).parsed


async def asyncio_detailed(
    token: str,
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: int | None | Unset = UNSET,
    limit: int | Unset = 300,
    pin: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | VariableHistoryOut]:
    """Get Public Variable History

     Fetch variable history for a widget on a public dashboard.
    Only allows fetching data for variable_keys that actually exist
    on the dashboard's widgets (security guard).

    Args:
        token (str):
        key (str):
        device_uid (None | str | Unset):
        from_ (int | None | Unset):
        limit (int | Unset):  Default: 300.
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableHistoryOut]
    """

    kwargs = _get_kwargs(
        token=token,
        key=key,
        device_uid=device_uid,
        from_=from_,
        limit=limit,
        pin=pin,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    token: str,
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: int | None | Unset = UNSET,
    limit: int | Unset = 300,
    pin: None | str | Unset = UNSET,
) -> HTTPValidationError | VariableHistoryOut | None:
    """Get Public Variable History

     Fetch variable history for a widget on a public dashboard.
    Only allows fetching data for variable_keys that actually exist
    on the dashboard's widgets (security guard).

    Args:
        token (str):
        key (str):
        device_uid (None | str | Unset):
        from_ (int | None | Unset):
        limit (int | Unset):  Default: 300.
        pin (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableHistoryOut
    """

    return (
        await asyncio_detailed(
            token=token,
            client=client,
            key=key,
            device_uid=device_uid,
            from_=from_,
            limit=limit,
            pin=pin,
        )
    ).parsed
