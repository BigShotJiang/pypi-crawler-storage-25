from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.changelog_response import ChangelogResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    since: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_since: None | str | Unset
    if isinstance(since, Unset):
        json_since = UNSET
    else:
        json_since = since
    params["since"] = json_since

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/changelog",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ChangelogResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ChangelogResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ChangelogResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    since: None | str | Unset = UNSET,
) -> Response[ChangelogResponse | HTTPValidationError]:
    """Get Changelog

     Return the parsed changelog. Optional ``since`` filter trims older releases.

    Args:
        since (None | str | Unset): ISO-date; only return entries newer than this

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChangelogResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        since=since,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    since: None | str | Unset = UNSET,
) -> ChangelogResponse | HTTPValidationError | None:
    """Get Changelog

     Return the parsed changelog. Optional ``since`` filter trims older releases.

    Args:
        since (None | str | Unset): ISO-date; only return entries newer than this

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChangelogResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        since=since,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    since: None | str | Unset = UNSET,
) -> Response[ChangelogResponse | HTTPValidationError]:
    """Get Changelog

     Return the parsed changelog. Optional ``since`` filter trims older releases.

    Args:
        since (None | str | Unset): ISO-date; only return entries newer than this

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChangelogResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        since=since,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    since: None | str | Unset = UNSET,
) -> ChangelogResponse | HTTPValidationError | None:
    """Get Changelog

     Return the parsed changelog. Optional ``since`` filter trims older releases.

    Args:
        since (None | str | Unset): ISO-date; only return entries newer than this

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChangelogResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            since=since,
        )
    ).parsed
