from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execution_definition_workers_out import ExecutionDefinitionWorkersOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    definition_key: str,
    *,
    active_within_seconds: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_active_within_seconds: int | None | Unset
    if isinstance(active_within_seconds, Unset):
        json_active_within_seconds = UNSET
    else:
        json_active_within_seconds = active_within_seconds
    params["active_within_seconds"] = json_active_within_seconds

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/executions/definitions/{definition_key}/workers".format(
            definition_key=quote(str(definition_key), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExecutionDefinitionWorkersOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExecutionDefinitionWorkersOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExecutionDefinitionWorkersOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    definition_key: str,
    *,
    client: AuthenticatedClient,
    active_within_seconds: int | None | Unset = UNSET,
) -> Response[ExecutionDefinitionWorkersOut | HTTPValidationError]:
    """Get Execution Definition Workers

    Args:
        definition_key (str):
        active_within_seconds (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionDefinitionWorkersOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
        active_within_seconds=active_within_seconds,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    definition_key: str,
    *,
    client: AuthenticatedClient,
    active_within_seconds: int | None | Unset = UNSET,
) -> ExecutionDefinitionWorkersOut | HTTPValidationError | None:
    """Get Execution Definition Workers

    Args:
        definition_key (str):
        active_within_seconds (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionDefinitionWorkersOut | HTTPValidationError
    """

    return sync_detailed(
        definition_key=definition_key,
        client=client,
        active_within_seconds=active_within_seconds,
    ).parsed


async def asyncio_detailed(
    definition_key: str,
    *,
    client: AuthenticatedClient,
    active_within_seconds: int | None | Unset = UNSET,
) -> Response[ExecutionDefinitionWorkersOut | HTTPValidationError]:
    """Get Execution Definition Workers

    Args:
        definition_key (str):
        active_within_seconds (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionDefinitionWorkersOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
        active_within_seconds=active_within_seconds,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    definition_key: str,
    *,
    client: AuthenticatedClient,
    active_within_seconds: int | None | Unset = UNSET,
) -> ExecutionDefinitionWorkersOut | HTTPValidationError | None:
    """Get Execution Definition Workers

    Args:
        definition_key (str):
        active_within_seconds (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionDefinitionWorkersOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            definition_key=definition_key,
            client=client,
            active_within_seconds=active_within_seconds,
        )
    ).parsed
