from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execution_release_in import ExecutionReleaseIn
from ...models.execution_run_out import ExecutionRunOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    run_id: int,
    *,
    body: ExecutionReleaseIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/executions/runs/{run_id}/release".format(
            run_id=quote(str(run_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExecutionRunOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExecutionRunOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExecutionRunOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    run_id: int,
    *,
    client: AuthenticatedClient,
    body: ExecutionReleaseIn,
) -> Response[ExecutionRunOut | HTTPValidationError]:
    """Release Execution Run

    Args:
        run_id (int):
        body (ExecutionReleaseIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionRunOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    run_id: int,
    *,
    client: AuthenticatedClient,
    body: ExecutionReleaseIn,
) -> ExecutionRunOut | HTTPValidationError | None:
    """Release Execution Run

    Args:
        run_id (int):
        body (ExecutionReleaseIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionRunOut | HTTPValidationError
    """

    return sync_detailed(
        run_id=run_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    run_id: int,
    *,
    client: AuthenticatedClient,
    body: ExecutionReleaseIn,
) -> Response[ExecutionRunOut | HTTPValidationError]:
    """Release Execution Run

    Args:
        run_id (int):
        body (ExecutionReleaseIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionRunOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        run_id=run_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    run_id: int,
    *,
    client: AuthenticatedClient,
    body: ExecutionReleaseIn,
) -> ExecutionRunOut | HTTPValidationError | None:
    """Release Execution Run

    Args:
        run_id (int):
        body (ExecutionReleaseIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionRunOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            run_id=run_id,
            client=client,
            body=body,
        )
    ).parsed
