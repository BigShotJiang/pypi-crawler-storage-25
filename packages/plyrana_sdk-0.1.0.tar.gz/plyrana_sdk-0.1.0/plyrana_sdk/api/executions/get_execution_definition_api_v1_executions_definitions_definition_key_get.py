from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execution_definition_out import ExecutionDefinitionOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    definition_key: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/executions/definitions/{definition_key}".format(
            definition_key=quote(str(definition_key), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExecutionDefinitionOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExecutionDefinitionOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExecutionDefinitionOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    definition_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ExecutionDefinitionOut | HTTPValidationError]:
    """Get Execution Definition

    Args:
        definition_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionDefinitionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    definition_key: str,
    *,
    client: AuthenticatedClient,
) -> ExecutionDefinitionOut | HTTPValidationError | None:
    """Get Execution Definition

    Args:
        definition_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionDefinitionOut | HTTPValidationError
    """

    return sync_detailed(
        definition_key=definition_key,
        client=client,
    ).parsed


async def asyncio_detailed(
    definition_key: str,
    *,
    client: AuthenticatedClient,
) -> Response[ExecutionDefinitionOut | HTTPValidationError]:
    """Get Execution Definition

    Args:
        definition_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionDefinitionOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    definition_key: str,
    *,
    client: AuthenticatedClient,
) -> ExecutionDefinitionOut | HTTPValidationError | None:
    """Get Execution Definition

    Args:
        definition_key (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionDefinitionOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            definition_key=definition_key,
            client=client,
        )
    ).parsed
