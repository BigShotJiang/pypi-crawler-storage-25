from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execution_run_read_out import ExecutionRunReadOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    definition_key: str,
    status: None | str | Unset = UNSET,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["definition_key"] = definition_key

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    else:
        json_status = status
    params["status"] = json_status

    json_cursor: int | None | Unset
    if isinstance(cursor, Unset):
        json_cursor = UNSET
    else:
        json_cursor = cursor
    params["cursor"] = json_cursor

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/executions/runs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExecutionRunReadOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExecutionRunReadOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExecutionRunReadOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    definition_key: str,
    status: None | str | Unset = UNSET,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[ExecutionRunReadOut | HTTPValidationError]:
    """List Execution Runs

    Args:
        definition_key (str):
        status (None | str | Unset):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionRunReadOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
        status=status,
        cursor=cursor,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    definition_key: str,
    status: None | str | Unset = UNSET,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> ExecutionRunReadOut | HTTPValidationError | None:
    """List Execution Runs

    Args:
        definition_key (str):
        status (None | str | Unset):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionRunReadOut | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        definition_key=definition_key,
        status=status,
        cursor=cursor,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    definition_key: str,
    status: None | str | Unset = UNSET,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> Response[ExecutionRunReadOut | HTTPValidationError]:
    """List Execution Runs

    Args:
        definition_key (str):
        status (None | str | Unset):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionRunReadOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        definition_key=definition_key,
        status=status,
        cursor=cursor,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    definition_key: str,
    status: None | str | Unset = UNSET,
    cursor: int | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
) -> ExecutionRunReadOut | HTTPValidationError | None:
    """List Execution Runs

    Args:
        definition_key (str):
        status (None | str | Unset):
        cursor (int | None | Unset):
        limit (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionRunReadOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            definition_key=definition_key,
            status=status,
            cursor=cursor,
            limit=limit,
        )
    ).parsed
