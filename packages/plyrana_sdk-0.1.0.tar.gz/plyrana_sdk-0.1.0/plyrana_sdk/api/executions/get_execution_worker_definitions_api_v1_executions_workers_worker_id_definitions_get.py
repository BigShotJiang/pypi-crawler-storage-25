from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.execution_worker_definitions_out import ExecutionWorkerDefinitionsOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    worker_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/executions/workers/{worker_id}/definitions".format(
            worker_id=quote(str(worker_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ExecutionWorkerDefinitionsOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ExecutionWorkerDefinitionsOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ExecutionWorkerDefinitionsOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ExecutionWorkerDefinitionsOut | HTTPValidationError]:
    """Get Execution Worker Definitions

    Args:
        worker_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionWorkerDefinitionsOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    worker_id: str,
    *,
    client: AuthenticatedClient,
) -> ExecutionWorkerDefinitionsOut | HTTPValidationError | None:
    """Get Execution Worker Definitions

    Args:
        worker_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionWorkerDefinitionsOut | HTTPValidationError
    """

    return sync_detailed(
        worker_id=worker_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    worker_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[ExecutionWorkerDefinitionsOut | HTTPValidationError]:
    """Get Execution Worker Definitions

    Args:
        worker_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ExecutionWorkerDefinitionsOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        worker_id=worker_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    worker_id: str,
    *,
    client: AuthenticatedClient,
) -> ExecutionWorkerDefinitionsOut | HTTPValidationError | None:
    """Get Execution Worker Definitions

    Args:
        worker_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ExecutionWorkerDefinitionsOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            worker_id=worker_id,
            client=client,
        )
    ).parsed
