from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.task_renew_out import TaskRenewOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    task_id: int,
    *,
    lease_seconds: int | Unset = 60,
    lease_token: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["lease_seconds"] = lease_seconds

    json_lease_token: None | str | Unset
    if isinstance(lease_token, Unset):
        json_lease_token = UNSET
    else:
        json_lease_token = lease_token
    params["lease_token"] = json_lease_token

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/tasks/{task_id}/renew".format(
            task_id=quote(str(task_id), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | TaskRenewOut | None:
    if response.status_code == 200:
        response_200 = TaskRenewOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | TaskRenewOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    task_id: int,
    *,
    client: AuthenticatedClient,
    lease_seconds: int | Unset = 60,
    lease_token: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | TaskRenewOut]:
    """Renew Task

    Args:
        task_id (int):
        lease_seconds (int | Unset):  Default: 60.
        lease_token (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TaskRenewOut]
    """

    kwargs = _get_kwargs(
        task_id=task_id,
        lease_seconds=lease_seconds,
        lease_token=lease_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    task_id: int,
    *,
    client: AuthenticatedClient,
    lease_seconds: int | Unset = 60,
    lease_token: None | str | Unset = UNSET,
) -> HTTPValidationError | TaskRenewOut | None:
    """Renew Task

    Args:
        task_id (int):
        lease_seconds (int | Unset):  Default: 60.
        lease_token (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TaskRenewOut
    """

    return sync_detailed(
        task_id=task_id,
        client=client,
        lease_seconds=lease_seconds,
        lease_token=lease_token,
    ).parsed


async def asyncio_detailed(
    task_id: int,
    *,
    client: AuthenticatedClient,
    lease_seconds: int | Unset = 60,
    lease_token: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | TaskRenewOut]:
    """Renew Task

    Args:
        task_id (int):
        lease_seconds (int | Unset):  Default: 60.
        lease_token (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TaskRenewOut]
    """

    kwargs = _get_kwargs(
        task_id=task_id,
        lease_seconds=lease_seconds,
        lease_token=lease_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    task_id: int,
    *,
    client: AuthenticatedClient,
    lease_seconds: int | Unset = 60,
    lease_token: None | str | Unset = UNSET,
) -> HTTPValidationError | TaskRenewOut | None:
    """Renew Task

    Args:
        task_id (int):
        lease_seconds (int | Unset):  Default: 60.
        lease_token (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TaskRenewOut
    """

    return (
        await asyncio_detailed(
            task_id=task_id,
            client=client,
            lease_seconds=lease_seconds,
            lease_token=lease_token,
        )
    ).parsed
