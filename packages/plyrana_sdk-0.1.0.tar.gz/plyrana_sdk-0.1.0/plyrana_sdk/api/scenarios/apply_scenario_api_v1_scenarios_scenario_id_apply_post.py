from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.scenario_apply_result import ScenarioApplyResult
from ...types import Response


def _get_kwargs(
    scenario_id: int,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/scenarios/{scenario_id}/apply".format(
            scenario_id=quote(str(scenario_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | ScenarioApplyResult | None:
    if response.status_code == 200:
        response_200 = ScenarioApplyResult.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | ScenarioApplyResult]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    scenario_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | ScenarioApplyResult]:
    """Apply Scenario

     Apply all bindings in order. Best-effort: failures don't abort.

    Each binding is a single create_or_update_value call; the function
    raises HTTPException on e.g. VAR_READONLY — we catch + log and
    continue with the next binding.

    Args:
        scenario_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ScenarioApplyResult]
    """

    kwargs = _get_kwargs(
        scenario_id=scenario_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    scenario_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | ScenarioApplyResult | None:
    """Apply Scenario

     Apply all bindings in order. Best-effort: failures don't abort.

    Each binding is a single create_or_update_value call; the function
    raises HTTPException on e.g. VAR_READONLY — we catch + log and
    continue with the next binding.

    Args:
        scenario_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ScenarioApplyResult
    """

    return sync_detailed(
        scenario_id=scenario_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    scenario_id: int,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | ScenarioApplyResult]:
    """Apply Scenario

     Apply all bindings in order. Best-effort: failures don't abort.

    Each binding is a single create_or_update_value call; the function
    raises HTTPException on e.g. VAR_READONLY — we catch + log and
    continue with the next binding.

    Args:
        scenario_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | ScenarioApplyResult]
    """

    kwargs = _get_kwargs(
        scenario_id=scenario_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    scenario_id: int,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | ScenarioApplyResult | None:
    """Apply Scenario

     Apply all bindings in order. Best-effort: failures don't abort.

    Each binding is a single create_or_update_value call; the function
    raises HTTPException on e.g. VAR_READONLY — we catch + log and
    continue with the next binding.

    Args:
        scenario_id (int):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | ScenarioApplyResult
    """

    return (
        await asyncio_detailed(
            scenario_id=scenario_id,
            client=client,
        )
    ).parsed
