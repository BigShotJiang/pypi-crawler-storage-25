from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.bulk_set_in import BulkSetIn
from ...models.bulk_set_result import BulkSetResult
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: BulkSetIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/variables/bulk-set",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BulkSetResult | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = BulkSetResult.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BulkSetResult | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BulkSetIn,
) -> Response[BulkSetResult | HTTPValidationError]:
    """Bulk Set Values

     Set multiple variable values in a single request.

    If allow_partial=True (default), failures are collected and the successful
    items are committed. If allow_partial=False, any single failure rolls back
    all changes.

    Args:
        body (BulkSetIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkSetResult | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: BulkSetIn,
) -> BulkSetResult | HTTPValidationError | None:
    """Bulk Set Values

     Set multiple variable values in a single request.

    If allow_partial=True (default), failures are collected and the successful
    items are committed. If allow_partial=False, any single failure rolls back
    all changes.

    Args:
        body (BulkSetIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkSetResult | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BulkSetIn,
) -> Response[BulkSetResult | HTTPValidationError]:
    """Bulk Set Values

     Set multiple variable values in a single request.

    If allow_partial=True (default), failures are collected and the successful
    items are committed. If allow_partial=False, any single failure rolls back
    all changes.

    Args:
        body (BulkSetIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkSetResult | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BulkSetIn,
) -> BulkSetResult | HTTPValidationError | None:
    """Bulk Set Values

     Set multiple variable values in a single request.

    If allow_partial=True (default), failures are collected and the successful
    items are committed. If allow_partial=False, any single failure rolls back
    all changes.

    Args:
        body (BulkSetIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkSetResult | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
