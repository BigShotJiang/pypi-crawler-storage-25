from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.variable_snapshot_v3_out import VariableSnapshotV3Out
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    device_uid: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_device_uid: None | str | Unset
    if isinstance(device_uid, Unset):
        json_device_uid = UNSET
    else:
        json_device_uid = device_uid
    params["deviceUid"] = json_device_uid

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/variables/snapshot",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VariableSnapshotV3Out | None:
    if response.status_code == 200:
        response_200 = VariableSnapshotV3Out.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VariableSnapshotV3Out]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    device_uid: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | VariableSnapshotV3Out]:
    """Get Snapshot V3

    Args:
        device_uid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableSnapshotV3Out]
    """

    kwargs = _get_kwargs(
        device_uid=device_uid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    device_uid: None | str | Unset = UNSET,
) -> HTTPValidationError | VariableSnapshotV3Out | None:
    """Get Snapshot V3

    Args:
        device_uid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableSnapshotV3Out
    """

    return sync_detailed(
        client=client,
        device_uid=device_uid,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    device_uid: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | VariableSnapshotV3Out]:
    """Get Snapshot V3

    Args:
        device_uid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableSnapshotV3Out]
    """

    kwargs = _get_kwargs(
        device_uid=device_uid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    device_uid: None | str | Unset = UNSET,
) -> HTTPValidationError | VariableSnapshotV3Out | None:
    """Get Snapshot V3

    Args:
        device_uid (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableSnapshotV3Out
    """

    return (
        await asyncio_detailed(
            client=client,
            device_uid=device_uid,
        )
    ).parsed
