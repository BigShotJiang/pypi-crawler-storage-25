import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.variable_history_out import VariableHistoryOut
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: datetime.datetime | None | Unset = UNSET,
    to: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 500,
    downsample: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["key"] = key

    json_device_uid: None | str | Unset
    if isinstance(device_uid, Unset):
        json_device_uid = UNSET
    else:
        json_device_uid = device_uid
    params["deviceUid"] = json_device_uid

    json_from_: None | str | Unset
    if isinstance(from_, Unset):
        json_from_ = UNSET
    elif isinstance(from_, datetime.datetime):
        json_from_ = from_.isoformat()
    else:
        json_from_ = from_
    params["from"] = json_from_

    json_to: None | str | Unset
    if isinstance(to, Unset):
        json_to = UNSET
    elif isinstance(to, datetime.datetime):
        json_to = to.isoformat()
    else:
        json_to = to
    params["to"] = json_to

    params["limit"] = limit

    json_downsample: int | None | Unset
    if isinstance(downsample, Unset):
        json_downsample = UNSET
    else:
        json_downsample = downsample
    params["downsample"] = json_downsample

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/variables/history",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VariableHistoryOut | None:
    if response.status_code == 200:
        response_200 = VariableHistoryOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VariableHistoryOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: datetime.datetime | None | Unset = UNSET,
    to: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 500,
    downsample: int | None | Unset = UNSET,
) -> Response[HTTPValidationError | VariableHistoryOut]:
    """Get Variable History

     Get time-series history for a variable. Optionally downsample.

    Args:
        key (str):
        device_uid (None | str | Unset):
        from_ (datetime.datetime | None | Unset):
        to (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 500.
        downsample (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableHistoryOut]
    """

    kwargs = _get_kwargs(
        key=key,
        device_uid=device_uid,
        from_=from_,
        to=to,
        limit=limit,
        downsample=downsample,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: datetime.datetime | None | Unset = UNSET,
    to: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 500,
    downsample: int | None | Unset = UNSET,
) -> HTTPValidationError | VariableHistoryOut | None:
    """Get Variable History

     Get time-series history for a variable. Optionally downsample.

    Args:
        key (str):
        device_uid (None | str | Unset):
        from_ (datetime.datetime | None | Unset):
        to (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 500.
        downsample (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableHistoryOut
    """

    return sync_detailed(
        client=client,
        key=key,
        device_uid=device_uid,
        from_=from_,
        to=to,
        limit=limit,
        downsample=downsample,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: datetime.datetime | None | Unset = UNSET,
    to: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 500,
    downsample: int | None | Unset = UNSET,
) -> Response[HTTPValidationError | VariableHistoryOut]:
    """Get Variable History

     Get time-series history for a variable. Optionally downsample.

    Args:
        key (str):
        device_uid (None | str | Unset):
        from_ (datetime.datetime | None | Unset):
        to (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 500.
        downsample (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VariableHistoryOut]
    """

    kwargs = _get_kwargs(
        key=key,
        device_uid=device_uid,
        from_=from_,
        to=to,
        limit=limit,
        downsample=downsample,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    key: str,
    device_uid: None | str | Unset = UNSET,
    from_: datetime.datetime | None | Unset = UNSET,
    to: datetime.datetime | None | Unset = UNSET,
    limit: int | Unset = 500,
    downsample: int | None | Unset = UNSET,
) -> HTTPValidationError | VariableHistoryOut | None:
    """Get Variable History

     Get time-series history for a variable. Optionally downsample.

    Args:
        key (str):
        device_uid (None | str | Unset):
        from_ (datetime.datetime | None | Unset):
        to (datetime.datetime | None | Unset):
        limit (int | Unset):  Default: 500.
        downsample (int | None | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VariableHistoryOut
    """

    return (
        await asyncio_detailed(
            client=client,
            key=key,
            device_uid=device_uid,
            from_=from_,
            to=to,
            limit=limit,
            downsample=downsample,
        )
    ).parsed
