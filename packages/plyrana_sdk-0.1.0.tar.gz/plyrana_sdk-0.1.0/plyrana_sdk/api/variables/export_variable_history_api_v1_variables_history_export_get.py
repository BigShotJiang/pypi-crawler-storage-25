from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    variable_key: str | Unset = UNSET,
    device_uid: str | Unset = UNSET,
    limit: int | Unset = 5000,
    format_: str | Unset = "csv",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["variable_key"] = variable_key

    params["device_uid"] = device_uid

    params["limit"] = limit

    params["format"] = format_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/variables/history/export",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    variable_key: str | Unset = UNSET,
    device_uid: str | Unset = UNSET,
    limit: int | Unset = 5000,
    format_: str | Unset = "csv",
) -> Response[Any | HTTPValidationError]:
    """Export Variable History

     Export variable history as CSV or JSON.

    Args:
        variable_key (str | Unset):
        device_uid (str | Unset):
        limit (int | Unset):  Default: 5000.
        format_ (str | Unset):  Default: 'csv'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        variable_key=variable_key,
        device_uid=device_uid,
        limit=limit,
        format_=format_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    variable_key: str | Unset = UNSET,
    device_uid: str | Unset = UNSET,
    limit: int | Unset = 5000,
    format_: str | Unset = "csv",
) -> Any | HTTPValidationError | None:
    """Export Variable History

     Export variable history as CSV or JSON.

    Args:
        variable_key (str | Unset):
        device_uid (str | Unset):
        limit (int | Unset):  Default: 5000.
        format_ (str | Unset):  Default: 'csv'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        variable_key=variable_key,
        device_uid=device_uid,
        limit=limit,
        format_=format_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    variable_key: str | Unset = UNSET,
    device_uid: str | Unset = UNSET,
    limit: int | Unset = 5000,
    format_: str | Unset = "csv",
) -> Response[Any | HTTPValidationError]:
    """Export Variable History

     Export variable history as CSV or JSON.

    Args:
        variable_key (str | Unset):
        device_uid (str | Unset):
        limit (int | Unset):  Default: 5000.
        format_ (str | Unset):  Default: 'csv'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        variable_key=variable_key,
        device_uid=device_uid,
        limit=limit,
        format_=format_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    variable_key: str | Unset = UNSET,
    device_uid: str | Unset = UNSET,
    limit: int | Unset = 5000,
    format_: str | Unset = "csv",
) -> Any | HTTPValidationError | None:
    """Export Variable History

     Export variable history as CSV or JSON.

    Args:
        variable_key (str | Unset):
        device_uid (str | Unset):
        limit (int | Unset):  Default: 5000.
        format_ (str | Unset):  Default: 'csv'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            variable_key=variable_key,
            device_uid=device_uid,
            limit=limit,
            format_=format_,
        )
    ).parsed
