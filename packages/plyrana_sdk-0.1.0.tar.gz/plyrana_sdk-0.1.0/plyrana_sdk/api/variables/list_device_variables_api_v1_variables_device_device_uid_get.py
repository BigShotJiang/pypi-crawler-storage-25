from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.device_variables_out import DeviceVariablesOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    device_uid: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/variables/device/{device_uid}".format(
            device_uid=quote(str(device_uid), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DeviceVariablesOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DeviceVariablesOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DeviceVariablesOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    device_uid: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceVariablesOut | HTTPValidationError]:
    """List Device Variables

    Args:
        device_uid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceVariablesOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        device_uid=device_uid,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    device_uid: str,
    *,
    client: AuthenticatedClient,
) -> DeviceVariablesOut | HTTPValidationError | None:
    """List Device Variables

    Args:
        device_uid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceVariablesOut | HTTPValidationError
    """

    return sync_detailed(
        device_uid=device_uid,
        client=client,
    ).parsed


async def asyncio_detailed(
    device_uid: str,
    *,
    client: AuthenticatedClient,
) -> Response[DeviceVariablesOut | HTTPValidationError]:
    """List Device Variables

    Args:
        device_uid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeviceVariablesOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        device_uid=device_uid,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    device_uid: str,
    *,
    client: AuthenticatedClient,
) -> DeviceVariablesOut | HTTPValidationError | None:
    """List Device Variables

    Args:
        device_uid (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeviceVariablesOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            device_uid=device_uid,
            client=client,
        )
    ).parsed
