from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.pairing_status_out import PairingStatusOut
from ...types import UNSET, Response


def _get_kwargs(
    *,
    pairing_code: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["pairingCode"] = pairing_code

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/pairing/status",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | PairingStatusOut | None:
    if response.status_code == 200:
        response_200 = PairingStatusOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | PairingStatusOut]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    pairing_code: str,
) -> Response[HTTPValidationError | PairingStatusOut]:
    """Pairing Status

     Read-only status for a pairing_code.
    - claimed=true when code has been used/claimed by a user

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PairingStatusOut]
    """

    kwargs = _get_kwargs(
        pairing_code=pairing_code,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    pairing_code: str,
) -> HTTPValidationError | PairingStatusOut | None:
    """Pairing Status

     Read-only status for a pairing_code.
    - claimed=true when code has been used/claimed by a user

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PairingStatusOut
    """

    return sync_detailed(
        client=client,
        pairing_code=pairing_code,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    pairing_code: str,
) -> Response[HTTPValidationError | PairingStatusOut]:
    """Pairing Status

     Read-only status for a pairing_code.
    - claimed=true when code has been used/claimed by a user

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | PairingStatusOut]
    """

    kwargs = _get_kwargs(
        pairing_code=pairing_code,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    pairing_code: str,
) -> HTTPValidationError | PairingStatusOut | None:
    """Pairing Status

     Read-only status for a pairing_code.
    - claimed=true when code has been used/claimed by a user

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | PairingStatusOut
    """

    return (
        await asyncio_detailed(
            client=client,
            pairing_code=pairing_code,
        )
    ).parsed
