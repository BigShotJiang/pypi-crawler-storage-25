from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    pairing_code: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/devices/pairing/{pairing_code}/qr".format(
            pairing_code=quote(str(pairing_code), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    pairing_code: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | HTTPValidationError]:
    r"""Pairing Qr Code

     Return an SVG QR code for the given pairing code.

    The QR payload is a JSON string:
      {\"code\":\"XXXXXXXX\",\"uid\":\"<device_uid>\"}

    Requires user authentication so only dashboard users can fetch QR codes.

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        pairing_code=pairing_code,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    pairing_code: str,
    *,
    client: AuthenticatedClient,
) -> Any | HTTPValidationError | None:
    r"""Pairing Qr Code

     Return an SVG QR code for the given pairing code.

    The QR payload is a JSON string:
      {\"code\":\"XXXXXXXX\",\"uid\":\"<device_uid>\"}

    Requires user authentication so only dashboard users can fetch QR codes.

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        pairing_code=pairing_code,
        client=client,
    ).parsed


async def asyncio_detailed(
    pairing_code: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | HTTPValidationError]:
    r"""Pairing Qr Code

     Return an SVG QR code for the given pairing code.

    The QR payload is a JSON string:
      {\"code\":\"XXXXXXXX\",\"uid\":\"<device_uid>\"}

    Requires user authentication so only dashboard users can fetch QR codes.

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        pairing_code=pairing_code,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    pairing_code: str,
    *,
    client: AuthenticatedClient,
) -> Any | HTTPValidationError | None:
    r"""Pairing Qr Code

     Return an SVG QR code for the given pairing code.

    The QR payload is a JSON string:
      {\"code\":\"XXXXXXXX\",\"uid\":\"<device_uid>\"}

    Requires user authentication so only dashboard users can fetch QR codes.

    Args:
        pairing_code (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            pairing_code=pairing_code,
            client=client,
        )
    ).parsed
