from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.feedback_in import FeedbackIn
from ...models.feedback_out import FeedbackOut
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: FeedbackIn,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/events/feedback",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FeedbackOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FeedbackOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FeedbackOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: FeedbackIn,
) -> Response[FeedbackOut | HTTPValidationError]:
    """Submit Feedback

     Submit user feedback with silent metadata for analysis.

    Feedback is stored as an event in the 'feedback' stream so admins
    can query, filter, and export it using the standard events API.
    The metadata (page, viewport, recent pages, console errors, etc.)
    is collected silently by the frontend widget — the user only sees
    and fills in the message text.

    Args:
        body (FeedbackIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FeedbackOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: FeedbackIn,
) -> FeedbackOut | HTTPValidationError | None:
    """Submit Feedback

     Submit user feedback with silent metadata for analysis.

    Feedback is stored as an event in the 'feedback' stream so admins
    can query, filter, and export it using the standard events API.
    The metadata (page, viewport, recent pages, console errors, etc.)
    is collected silently by the frontend widget — the user only sees
    and fills in the message text.

    Args:
        body (FeedbackIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FeedbackOut | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: FeedbackIn,
) -> Response[FeedbackOut | HTTPValidationError]:
    """Submit Feedback

     Submit user feedback with silent metadata for analysis.

    Feedback is stored as an event in the 'feedback' stream so admins
    can query, filter, and export it using the standard events API.
    The metadata (page, viewport, recent pages, console errors, etc.)
    is collected silently by the frontend widget — the user only sees
    and fills in the message text.

    Args:
        body (FeedbackIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FeedbackOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: FeedbackIn,
) -> FeedbackOut | HTTPValidationError | None:
    """Submit Feedback

     Submit user feedback with silent metadata for analysis.

    Feedback is stored as an event in the 'feedback' stream so admins
    can query, filter, and export it using the standard events API.
    The metadata (page, viewport, recent pages, console errors, etc.)
    is collected silently by the frontend widget — the user only sees
    and fills in the message text.

    Args:
        body (FeedbackIn):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FeedbackOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
