from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.event_read_out import EventReadOut
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    stream: str | Unset = "system",
    cursor: int | Unset = 0,
    limit: int | Unset = 100,
    from_ts: float | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["stream"] = stream

    params["cursor"] = cursor

    params["limit"] = limit

    json_from_ts: float | None | Unset
    if isinstance(from_ts, Unset):
        json_from_ts = UNSET
    else:
        json_from_ts = from_ts
    params["from_ts"] = json_from_ts

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/events",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EventReadOut | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EventReadOut.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EventReadOut | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    stream: str | Unset = "system",
    cursor: int | Unset = 0,
    limit: int | Unset = 100,
    from_ts: float | None | Unset = UNSET,
) -> Response[EventReadOut | HTTPValidationError]:
    """Read Events

    Args:
        stream (str | Unset):  Default: 'system'.
        cursor (int | Unset):  Default: 0.
        limit (int | Unset):  Default: 100.
        from_ts (float | None | Unset): Unix timestamp (seconds). If set, returns events after
            this time and overrides cursor.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EventReadOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        stream=stream,
        cursor=cursor,
        limit=limit,
        from_ts=from_ts,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    stream: str | Unset = "system",
    cursor: int | Unset = 0,
    limit: int | Unset = 100,
    from_ts: float | None | Unset = UNSET,
) -> EventReadOut | HTTPValidationError | None:
    """Read Events

    Args:
        stream (str | Unset):  Default: 'system'.
        cursor (int | Unset):  Default: 0.
        limit (int | Unset):  Default: 100.
        from_ts (float | None | Unset): Unix timestamp (seconds). If set, returns events after
            this time and overrides cursor.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EventReadOut | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        stream=stream,
        cursor=cursor,
        limit=limit,
        from_ts=from_ts,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    stream: str | Unset = "system",
    cursor: int | Unset = 0,
    limit: int | Unset = 100,
    from_ts: float | None | Unset = UNSET,
) -> Response[EventReadOut | HTTPValidationError]:
    """Read Events

    Args:
        stream (str | Unset):  Default: 'system'.
        cursor (int | Unset):  Default: 0.
        limit (int | Unset):  Default: 100.
        from_ts (float | None | Unset): Unix timestamp (seconds). If set, returns events after
            this time and overrides cursor.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EventReadOut | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        stream=stream,
        cursor=cursor,
        limit=limit,
        from_ts=from_ts,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    stream: str | Unset = "system",
    cursor: int | Unset = 0,
    limit: int | Unset = 100,
    from_ts: float | None | Unset = UNSET,
) -> EventReadOut | HTTPValidationError | None:
    """Read Events

    Args:
        stream (str | Unset):  Default: 'system'.
        cursor (int | Unset):  Default: 0.
        limit (int | Unset):  Default: 100.
        from_ts (float | None | Unset): Unix timestamp (seconds). If set, returns events after
            this time and overrides cursor.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EventReadOut | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            stream=stream,
            cursor=cursor,
            limit=limit,
            from_ts=from_ts,
        )
    ).parsed
