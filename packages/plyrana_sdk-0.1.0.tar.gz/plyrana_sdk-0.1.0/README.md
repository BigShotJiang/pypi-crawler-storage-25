# plyrana-sdk — Python SDK for Plyrana

Auto-generated Python client for the [Plyrana](https://github.com/plyrana/core) REST API. Full type safety via attrs, httpx-based, sync + async support.

## Install

```bash
pip install plyrana-sdk
```

## Quick Start

```python
from plyrana_sdk import AuthenticatedClient
from plyrana_sdk.api.devices import list_devices
from plyrana_sdk.api.variables import set_variable
from plyrana_sdk.models import VariableValueIn

client = AuthenticatedClient(
    base_url="http://localhost:8000",
    token="your-jwt-or-api-key",
)

# List all devices
devices = list_devices.sync(client=client)
for dev in devices:
    print(dev.uid, dev.name)

# Set a variable
set_variable.sync(
    device_uid="esp32-living-room",
    key="temperature",
    client=client,
    body=VariableValueIn(value=22.5),
)
```

## Async support

Every endpoint has `.sync()` and `.asyncio()`:

```python
import asyncio
from plyrana_sdk.api.devices import list_devices

async def main():
    devices = await list_devices.asyncio(client=client)
    print(devices)

asyncio.run(main())
```

## Authentication

- **JWT** — from `POST /api/v1/auth/login`
- **API Key** — from Settings → API Keys (prefix `plk_`)

## Regenerate from latest spec

```bash
curl http://localhost:8000/openapi.json > /tmp/openapi.json
openapi-python-client generate --path /tmp/openapi.json --overwrite
```

## License

AGPL-3.0 — see [LICENSE](../../LICENSE) in the main repo.
