from dataclasses import dataclass


@dataclass
class DigiKeyConfig:
    client_id: str
    client_secret: str
    redirect_uri: str = "https://localhost:8139/digikey_callback"
    callback_port: int = 8139
    storage_path: str = "token_storage.json"
    sandbox: bool = False
    auth_timeout: int = 120
