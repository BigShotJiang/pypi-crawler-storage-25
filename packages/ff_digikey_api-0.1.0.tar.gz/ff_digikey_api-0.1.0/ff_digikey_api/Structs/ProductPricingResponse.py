from dataclasses import dataclass, field

from ff_digikey_api.Structs.Product import Product


@dataclass
class ProductPricingResponse:
    products: list[Product] = field(default_factory=list)
    products_count: int = 0
    raw_data: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "ProductPricingResponse":
        products = [Product.from_dict(p) for p in data.get("ProductPricings", data.get("Products", []))]
        return cls(
            products=products,
            products_count=data.get("ProductsCount", 0),
            raw_data=data,
        )
