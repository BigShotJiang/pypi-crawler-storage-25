import os

from loguru import logger

from ff_digikey_api.Constants.Endpoints import BASE_URL, SANDBOX_BASE_URL
from ff_digikey_api.Structs.DigiKeyConfig import DigiKeyConfig
from ff_digikey_api.Structs.DigiKeyLocale import DigiKeyLocale
from ff_digikey_api.Structs.KeywordSearchRequest import KeywordSearchRequest
from ff_digikey_api.Structs.KeywordSearchResponse import KeywordSearchResponse
from ff_digikey_api.Structs.Product import Product
from ff_digikey_api.Structs.ProductPricingResponse import ProductPricingResponse
from ff_digikey_api.Structs.Manufacturer import Manufacturer
from ff_digikey_api.Structs.Category import Category
from ff_digikey_api.Structs.FilterOptions import FilterOptions
from ff_digikey_api.Structs.SortOptions import SortOptions
from ff_digikey_api.Structs.ParametricFilterRequest import ParametricFilterRequest
from ff_digikey_api.Util.ParametricExpression import parse_expression
from ff_digikey_api.Util.ParametricMatcher import match_filters
from ff_digikey_api.Core.HttpClient.HttpClient import HttpClient
from ff_digikey_api.Service.TokenManager.TokenManager import TokenManager
from ff_digikey_api.Service.ProductService.ProductService import ProductService


class DigiKeyClient:
    def __init__(self, client_id: str, client_secret: str, locale: DigiKeyLocale | None = None, **kwargs):
        sandbox = kwargs.get("sandbox", False)
        storage_path = kwargs.get("storage_path", "token_storage.json")
        callback_port = kwargs.get("callback_port", 8139)
        redirect_uri = kwargs.get("redirect_uri", "https://localhost:8139/digikey_callback")
        auth_timeout = kwargs.get("auth_timeout", 120)

        self._config = DigiKeyConfig(
            client_id=client_id,
            client_secret=client_secret,
            redirect_uri=redirect_uri,
            callback_port=callback_port,
            storage_path=storage_path,
            sandbox=sandbox,
            auth_timeout=auth_timeout,
        )
        self._locale = locale if locale else DigiKeyLocale()
        base_url = SANDBOX_BASE_URL if sandbox else BASE_URL
        self._token_manager = TokenManager(self._config)
        self._http_client = HttpClient(base_url=base_url, client_id=client_id, locale=self._locale)
        self._product_service = ProductService(self._http_client)
        logger.info("DigiKeyClient 초기화")

    @classmethod
    def from_env(cls, env_file: str | None = None) -> "DigiKeyClient":
        # python-dotenv가 있으면 로드
        if env_file:
            try:
                from dotenv import load_dotenv
                load_dotenv(env_file)
            except ImportError:
                pass

        client_id = os.environ.get("DIGIKEY_CLIENT_ID")
        client_secret = os.environ.get("DIGIKEY_CLIENT_SECRET")
        if not client_id or not client_secret:
            raise ValueError("DIGIKEY_CLIENT_ID and DIGIKEY_CLIENT_SECRET must be set")

        language = os.environ.get("DIGIKEY_LANGUAGE", "en")
        currency = os.environ.get("DIGIKEY_CURRENCY", "USD")
        site = os.environ.get("DIGIKEY_SITE", "US")
        locale = DigiKeyLocale(language=language, currency=currency, site=site)

        sandbox_str = os.environ.get("DIGIKEY_SANDBOX", "false")
        sandbox = sandbox_str.lower() in ("true", "1", "yes")

        return cls(
            client_id=client_id,
            client_secret=client_secret,
            locale=locale,
            sandbox=sandbox,
        )

    def is_authenticated(self) -> bool:
        return self._token_manager.is_authenticated()

    def authorize(self):
        logger.info("authorize 시작")
        self._token_manager.authorize()

    def search(self, keywords: str, limit: int = 50, offset: int = 0,
               filters: FilterOptions | None = None, sort: SortOptions | None = None) -> KeywordSearchResponse:
        logger.info(f"search 시작: keywords={keywords}")
        token = self._token_manager.get_access_token()
        request = KeywordSearchRequest(keywords=keywords, limit=limit, offset=offset, filters=filters, sort=sort)
        return self._product_service.keyword_search(token, request)

    def parametric_search(
        self,
        keywords: str,
        expressions: list[str] | str,
        limit: int = 50,
        offset: int = 0,
        filters: FilterOptions | None = None,
        sort: SortOptions | None = None,
        category_id: int | None = None,
    ) -> KeywordSearchResponse:
        logger.info(f"parametric_search: keywords={keywords}, expressions={expressions}")

        if isinstance(expressions, str):
            expressions = [expressions]
        parsed = [parse_expression(e) for e in expressions]

        # category 미지정 시: 검색 결과에서 리프 카테고리 추출
        if category_id is None:
            pre = self.search(keywords, limit=5, offset=0, filters=filters)
            for p in pre.products:
                if p.category and p.category.id:
                    category_id = self._find_leaf_category(p.category)
                    break
            if category_id is None:
                raise ValueError("category not found: provide category_id explicitly")

        # probe: CategoryFilter 포함하여 ParametricFilters 획득
        probe_filters = FilterOptions(category_ids=[category_id])
        if filters:
            probe_filters = FilterOptions(
                manufacturer_ids=list(filters.manufacturer_ids),
                category_ids=[category_id] + [c for c in filters.category_ids if c != category_id],
                status_ids=list(filters.status_ids),
                packaging_ids=list(filters.packaging_ids),
                marketplace=filters.marketplace,
            )
        probe = self.search(keywords, limit=1, offset=0, filters=probe_filters)
        fo = probe.filter_options

        parametric_filters = fo.get("ParametricFilters")
        if not parametric_filters:
            raise ValueError("ParametricFilters not found in response (category_id={})".format(category_id))

        # 매칭
        matches = match_filters(parsed, parametric_filters)
        pfr = ParametricFilterRequest.from_match_results(matches, category_id=category_id)

        # 필터 적용 검색
        new_filters = FilterOptions(
            manufacturer_ids=list(probe_filters.manufacturer_ids),
            category_ids=list(probe_filters.category_ids),
            status_ids=list(probe_filters.status_ids),
            packaging_ids=list(probe_filters.packaging_ids),
            marketplace=probe_filters.marketplace,
            parametric_filter=pfr,
        )

        return self.search(keywords, limit=limit, offset=offset, filters=new_filters, sort=sort)

    @staticmethod
    def _find_leaf_category(category: Category) -> int:
        children = category.raw_data.get("ChildCategories", [])
        if children:
            return children[0]["CategoryId"]
        return category.id

    def product_details(self, product_number: str) -> Product:
        logger.info(f"product_details 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.product_details(token, product_number)

    def pricing(self, product_number: str, **kwargs) -> ProductPricingResponse:
        logger.info(f"pricing 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.pricing(token, product_number, **kwargs)

    def associations(self, product_number: str) -> list[Product]:
        logger.info(f"associations 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.associations(token, product_number)

    def substitutions(self, product_number: str) -> list[Product]:
        logger.info(f"substitutions 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.substitutions(token, product_number)

    def recommended_products(self, product_number: str) -> list[Product]:
        logger.info(f"recommended_products 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.recommended_products(token, product_number)

    def alternate_packaging(self, product_number: str) -> list[Product]:
        logger.info(f"alternate_packaging 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.alternate_packaging(token, product_number)

    def media(self, product_number: str) -> dict:
        logger.info(f"media 시작: product_number={product_number}")
        token = self._token_manager.get_access_token()
        return self._product_service.media(token, product_number)

    def manufacturers(self) -> list[Manufacturer]:
        logger.info("manufacturers 시작")
        token = self._token_manager.get_access_token()
        return self._product_service.manufacturers(token)

    def categories(self) -> list[Category]:
        logger.info("categories 시작")
        token = self._token_manager.get_access_token()
        return self._product_service.categories(token)

    def close(self):
        logger.info("DigiKeyClient 종료")
        self._http_client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
