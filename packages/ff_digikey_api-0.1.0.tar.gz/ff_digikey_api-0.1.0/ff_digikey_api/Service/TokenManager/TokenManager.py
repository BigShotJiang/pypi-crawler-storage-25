import time
import webbrowser

import httpx
from loguru import logger

from ff_digikey_api.Constants.Endpoints import (
    AUTH_URL, TOKEN_URL, SANDBOX_AUTH_URL, SANDBOX_TOKEN_URL,
)
from ff_digikey_api.Structs.DigiKeyConfig import DigiKeyConfig
from ff_digikey_api.Structs.TokenData import TokenData
from ff_digikey_api.Core.TokenStorage.TokenStorage import TokenStorage
from ff_digikey_api.Core.CallbackServer.CallbackServer import CallbackServer
from ff_digikey_api.Service.TokenManager.TokenExpiredError import TokenExpiredError


class TokenManager:
    def __init__(self, config: DigiKeyConfig):
        self._config = config
        self._storage = TokenStorage(config.storage_path)
        self._callback_server = CallbackServer(config.callback_port, config.redirect_uri)
        self._cached_token: TokenData | None = None
        logger.info("TokenManager 초기화")

    def authorize(self):
        # 3-Legged OAuth 최초 인증 흐름
        logger.info("authorize 시작")
        auth_url = self._build_authorize_url()
        webbrowser.open(auth_url)
        code = self._callback_server.wait_for_code(self._config.auth_timeout)
        token_data = self._exchange_code(code)
        self._storage.save(token_data)
        self._cached_token = token_data
        logger.info("authorize 완료")

    def get_access_token(self) -> str:
        logger.info("get_access_token 시작")
        # 1. 캐시된 토큰이 유효하면 즉시 반환
        if self._cached_token and not self._cached_token.is_expired():
            return self._cached_token.access_token

        # 2. 캐시 없으면 저장소에서 로드
        if self._cached_token is None:
            self._cached_token = self._storage.load()

        # 3. 토큰 없음
        if self._cached_token is None:
            raise TokenExpiredError("Not authenticated")

        # 4. access_token 유효
        if not self._cached_token.is_expired():
            return self._cached_token.access_token

        # 5. refresh_token 유효 -> refresh
        if not self._cached_token.is_refresh_expired():
            self._cached_token = self._refresh_token(self._cached_token)
            return self._cached_token.access_token

        # 6. refresh_token도 만료
        raise TokenExpiredError()

    def is_authenticated(self) -> bool:
        logger.info("is_authenticated 확인")
        # 캐시 확인
        token = self._cached_token
        if token is None:
            token = self._storage.load()
        if token is None:
            return False
        # refresh 가능한지 확인
        if not token.is_expired():
            return True
        if not token.is_refresh_expired():
            return True
        return False

    def _exchange_code(self, code: str) -> TokenData:
        logger.info("_exchange_code 시작")
        url = self._get_token_url()
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": self._config.redirect_uri,
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
        }
        response = httpx.post(url, data=data)
        response.raise_for_status()
        body = response.json()
        now = time.time()
        expires_in = body.get("expires_in", 0)
        refresh_expires_in = body.get("refresh_token_expires_in")
        token_data = TokenData(
            access_token=body["access_token"],
            refresh_token=body.get("refresh_token"),
            expires=now + expires_in - 30,
            refresh_token_expires=now + refresh_expires_in if refresh_expires_in else None,
            token_type=body.get("token_type", "Bearer"),
        )
        return token_data

    def _refresh_token(self, token_data: TokenData) -> TokenData:
        logger.info("_refresh_token 시작")
        url = self._get_token_url()
        data = {
            "grant_type": "refresh_token",
            "refresh_token": token_data.refresh_token,
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
        }
        response = httpx.post(url, data=data)
        if response.status_code == 401:
            logger.error("refresh_token 무효 (401)")
            self._cached_token = None
            raise TokenExpiredError("Refresh token is invalid. Re-authentication required.")
        response.raise_for_status()
        body = response.json()
        now = time.time()
        expires_in = body.get("expires_in", 0)
        refresh_expires_in = body.get("refresh_token_expires_in")
        new_token = TokenData(
            access_token=body["access_token"],
            refresh_token=body.get("refresh_token"),
            expires=now + expires_in - 30,
            refresh_token_expires=now + refresh_expires_in if refresh_expires_in else None,
            token_type=body.get("token_type", "Bearer"),
        )
        self._storage.save(new_token)
        self._cached_token = new_token
        return new_token

    def _get_token_url(self) -> str:
        if self._config.sandbox:
            return SANDBOX_TOKEN_URL
        return TOKEN_URL

    def _get_auth_url(self) -> str:
        if self._config.sandbox:
            return SANDBOX_AUTH_URL
        return AUTH_URL

    def _build_authorize_url(self) -> str:
        from urllib.parse import urlencode
        base = self._get_auth_url()
        params = {
            "response_type": "code",
            "client_id": self._config.client_id,
            "redirect_uri": self._config.redirect_uri,
        }
        return f"{base}?{urlencode(params)}"
