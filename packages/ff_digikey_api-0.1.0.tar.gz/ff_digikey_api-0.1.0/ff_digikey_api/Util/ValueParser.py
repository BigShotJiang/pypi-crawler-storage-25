from __future__ import annotations

import re

_SI_PREFIX = {
    "p": 1e-12,
    "n": 1e-9,
    "u": 1e-6,
    "\u00b5": 1e-6,
    "m": 1e-3,
    "k": 1e3,
    "K": 1e3,
    "M": 1e6,
    "G": 1e9,
    "T": 1e12,
}

_PATTERN = re.compile(
    r"^\s*([+-]?\d+\.?\d*)\s*([pnumkKMGT\u00b5]?)(.*)$"
)


def parse_numeric_value(text: str) -> float | None:
    if not text or not text.strip():
        return None

    text = text.strip()
    # % -> 숫자 부분만 추출
    if text.endswith("%"):
        text = text[:-1]

    m = _PATTERN.match(text)
    if not m:
        return None

    number_str, prefix, _ = m.groups()
    value = float(number_str)
    if prefix:
        value *= _SI_PREFIX.get(prefix, 1.0)
    return value
