import ssl
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, urlencode

from loguru import logger

from certauth.certauth import CertificateAuthority

from ff_digikey_api.Constants.Endpoints import AUTH_URL
from ff_digikey_api.Core.CallbackServer.CallbackTimeoutError import CallbackTimeoutError


class CallbackServer:
    def __init__(self, port: int = 8139, redirect_uri: str = "https://localhost:8139/digikey_callback"):
        self._port = port
        self._redirect_uri = redirect_uri
        self._auth_code: str | None = None
        self._event = threading.Event()
        logger.info(f"CallbackServer 초기화: port={port}")

    def wait_for_code(self, timeout: int = 120) -> str:
        logger.info(f"OAuth 콜백 대기 시작: timeout={timeout}s")
        ca = CertificateAuthority("DigiKey OAuth CA", "ca.pem", cert_cache="certs")
        cert_file = ca.cert_for_host("localhost")

        # SSL 컨텍스트 설정
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ssl_context.load_cert_chain(cert_file)

        server_ref = self

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                params = parse_qs(parsed.query)
                code = params.get("code", [None])[0]
                if code:
                    server_ref._auth_code = code
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(b"<html><body><h1>Authorization successful. You can close this window.</h1></body></html>")
                    server_ref._event.set()
                else:
                    self.send_response(400)
                    self.end_headers()

            def log_message(self, format, *args):
                # 기본 로그 억제
                pass

        httpd = HTTPServer(("localhost", self._port), _Handler)
        httpd.socket = ssl_context.wrap_socket(httpd.socket, server_side=True)

        thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        thread.start()
        logger.debug("HTTPS 콜백 서버 시작")

        try:
            if not self._event.wait(timeout=timeout):
                raise CallbackTimeoutError(timeout=timeout)
            logger.info("OAuth 인증 코드 수신 완료")
            return self._auth_code
        finally:
            httpd.shutdown()
            logger.debug("콜백 서버 종료")

    def get_authorize_url(self, client_id: str, redirect_uri: str) -> str:
        logger.info("DigiKey 인증 URL 생성")
        params = {
            "response_type": "code",
            "client_id": client_id,
            "redirect_uri": redirect_uri,
        }
        return f"{AUTH_URL}?{urlencode(params)}"
