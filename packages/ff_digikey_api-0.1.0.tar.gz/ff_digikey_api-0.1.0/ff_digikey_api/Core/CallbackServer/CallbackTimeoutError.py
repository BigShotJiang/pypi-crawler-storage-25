class CallbackTimeoutError(Exception):
    def __init__(self, timeout: int):
        self.timeout = timeout
        super().__init__(f"OAuth callback timed out after {timeout} seconds")
