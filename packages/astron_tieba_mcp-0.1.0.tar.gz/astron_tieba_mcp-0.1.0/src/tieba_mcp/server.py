"""Astron Tieba MCP server."""

from __future__ import annotations

import gzip
import hashlib
import html as html_lib
import json
import os
import re
import urllib.request
from datetime import datetime, timezone
from typing import Any
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse

from mcp.server.fastmcp import FastMCP

from tieba_mcp import __version__
from tieba_mcp.posts.protobuf import PbPageReqIdl_pb2, PbPageResIdl_pb2
from tieba_mcp.profile.protobuf import ProfileReqIdl_pb2, ProfileResIdl_pb2
from tieba_mcp.user_contents.protobuf import UserPostReqIdl_pb2, UserPostResIdl_pb2


BASE_URL = "https://tieba.baidu.com"
APP_BASE_HOST = "tiebac.baidu.com"
MAIN_VERSION = "12.64.1.1"
HOT_TOPIC_API = f"{BASE_URL}/hottopic/browse/topicList"
HOT_TOPIC_DETAIL_URL = f"{BASE_URL}/hottopic/browse/hottopic"
MOBILE_FORUM_URL = f"{BASE_URL}/mo/q/forum"
USER_JSON_URL = "http://tieba.baidu.com/i/sys/user_json"
THREAD_DETAIL_API_URL = f"http://{APP_BASE_HOST}/c/f/pb/page?cmd=302001"
AUTHOR_PROFILE_API_URL = f"http://{APP_BASE_HOST}/c/u/user/profile?cmd=303012"
AUTHOR_CONTENT_API_URL = f"http://{APP_BASE_HOST}/c/u/feed/userpost?cmd=303002"
SEARCH_API_URL = f"http://{APP_BASE_HOST}/c/s/searchpost"
PORTRAIT_BASE_URL = (
    "https://gss0.bdstatic.com/6LZ1dD3d1sgCo2Kml5_Y_D3/sys/portrait/item/"
)

AUTHOR_CONTENT_SCAN_PAGE_SIZE = 20
THREAD_DETAIL_PAGE_SIZE = 20
PROXY_MULTIPART_BOUNDARY = "-*_r1999"

_COUNT_RE = re.compile(r"[\d,.]+")
_TAG_RE = re.compile(r"<[^>]+>")
_THREAD_TID_RE = re.compile(r'data-tid="(\d+)"')
_FORUM_THREAD_RE = re.compile(r'<li class="tl_shadow tl_shadow_new ".*?</li>', re.S)
_TITLE_RE = re.compile(r"<title>(.*?)</title>", re.I | re.S)
_FORUM_NAME_RE = re.compile(r'<span class="forum-name-txt">(.*?)</span>', re.S)
_THREAD_HREF_RE = re.compile(r'<a href="([^"]+)"\s+class="j_common ti_item')
_THREAD_TITLE_RE = re.compile(r'<div class="ti_title">\s*<span>(.*?)</span>', re.S)
_THREAD_AUTHOR_RE = re.compile(r'<span class="ti_author">\s*(.*?)</span>', re.S)
_THREAD_TIME_RE = re.compile(r'<span class="ti_time">(.*?)</span>', re.S)
_THREAD_REPLY_RE = re.compile(r'<span class="btn_icon">(\d+)</span>', re.S)
_THREAD_AUTHOR_URL_RE = re.compile(r'data-url="([^"]+/home/main\?un=[^"]+)"')
_THREAD_PAGE_HINT_RE = re.compile(r"pageBottom|frs_more_spinner|moreSpinner|pager_new")
_RELATED_THREAD_BLOCK_RE = re.compile(r'<li class="thread-item">.*?</li>', re.S)
_RELATED_THREAD_TITLE_RE = re.compile(
    r'class="title track-thread-title">(.*?)</a>', re.S
)
_RELATED_THREAD_REPLY_RE = re.compile(r'<span class="reply-num">(\d+)</span>', re.S)
_RELATED_THREAD_HREF_RE = re.compile(
    r'<a href="([^"]+)"[^>]*class="title track-thread-title"', re.S
)
_TOPIC_PAGE_MARKER = "PageData.topic"
_THREAD_URL_ID_RE = re.compile(r"/p/(\d+)")
_TOPIC_ID_RE = re.compile(r"topic_id=(\d+)")
_AUTHOR_UID_RE = re.compile(r"(^\d+$)|(?:[?&]id=)(\d+)")

mcp = FastMCP("TIEBA_MCP")


def get_timeout_seconds() -> float:
    raw = os.getenv("TIEBA_MCP_TIMEOUT_SECONDS", "30").strip()
    try:
        value = float(raw)
    except ValueError as exc:
        raise RuntimeError("TIEBA_MCP_TIMEOUT_SECONDS 必须是数字") from exc
    if value <= 0:
        raise RuntimeError("TIEBA_MCP_TIMEOUT_SECONDS 必须大于 0")
    return value


def get_web_user_agent() -> str:
    value = os.getenv("TIEBA_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36 "
        f"Astron-Tieba-MCP/{__version__}"
    )


def get_app_user_agent() -> str:
    value = os.getenv("TIEBA_MCP_USER_AGENT", "").strip()
    if value:
        return value
    return f"aiotieba/{MAIN_VERSION}"


def _to_int(value: Any) -> int | None:
    if value in (None, ""):
        return None
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return int(value)
    match = _COUNT_RE.search(str(value))
    if not match:
        return None
    text = match.group(0).replace(",", "")
    try:
        return int(float(text))
    except ValueError:
        return None


def _unix_to_iso(value: Any) -> str:
    timestamp = _to_int(value)
    if timestamp is None:
        return ""
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).astimezone().isoformat()


def clean_text(value: str) -> str:
    text = html_lib.unescape(str(value or ""))
    text = _TAG_RE.sub(" ", text)
    return " ".join(text.split())


def _first_text(*values: Any) -> str:
    for value in values:
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def _safe_html_text(value: Any) -> str:
    return clean_text(html_lib.unescape(str(value or "")))


def _normalize_limit(limit: int, *, maximum: int = 50) -> int:
    value = _to_int(limit)
    if value is None:
        return 20
    return max(1, min(value, maximum))


def _parse_page_cursor(cursor: str) -> int:
    value = _to_int(cursor)
    if value is None or value <= 0:
        return 1
    return value


def _normalize_url(value: str) -> str:
    text = html_lib.unescape(str(value or "")).strip()
    if not text:
        return ""
    if text.startswith("//"):
        return f"https:{text}"
    if text.startswith("http://"):
        return f"https://{text[len('http://'):]}"
    if text.startswith("https://"):
        return text
    if text.startswith("tb."):
        return f"{PORTRAIT_BASE_URL}{text}"
    return urljoin(BASE_URL, text)


def _build_thread_url(tid: str | int) -> str:
    return f"{BASE_URL}/p/{str(tid).strip()}"


def _build_topic_detail_url(topic_id: str | int, topic_name: str = "") -> str:
    topic_id_text = quote(str(topic_id).strip())
    url = f"{HOT_TOPIC_DETAIL_URL}?topic_id={topic_id_text}"
    topic_name_text = quote(topic_name.strip())
    if topic_name_text:
        url = f"{url}&topic_name={topic_name_text}"
    return url


def _build_forum_url(channel: str, page: int = 1) -> str:
    keyword = quote(_resolve_forum_keyword(channel))
    url = f"{MOBILE_FORUM_URL}?kw={keyword}"
    if page > 1:
        url = f"{url}&page={page}"
    return url


def _build_author_url(*, user_name: str = "", user_id: str = "") -> str:
    normalized_name = str(user_name or "").strip()
    if normalized_name:
        return f"{BASE_URL}/home/main?un={quote(normalized_name)}&ie=utf-8&fr=home"
    normalized_uid = str(user_id or "").strip()
    if normalized_uid:
        return f"{BASE_URL}/home/main?id={quote(normalized_uid)}&fr=home"
    return ""


def _build_paging(*, has_more: bool = False, next_cursor: str = "") -> dict[str, Any]:
    return {
        "has_more": bool(has_more),
        "next_cursor": next_cursor if has_more else "",
    }


def _build_list_result(
    capability: str,
    items: list[dict[str, Any]],
    raw: dict[str, Any],
    *,
    has_more: bool = False,
    next_cursor: str = "",
) -> dict[str, Any]:
    return {
        "platform": "tieba",
        "capability": capability,
        "update_time": "",
        "items": items,
        "paging": _build_paging(has_more=has_more, next_cursor=next_cursor),
        "raw": raw,
    }


def _build_author_result(author: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "tieba",
        "author": author,
        "raw": raw,
    }


def _build_detail_result(item: dict[str, Any], raw: dict[str, Any]) -> dict[str, Any]:
    return {
        "platform": "tieba",
        "item": item,
        "raw": raw,
    }


def _request_bytes(
    request: urllib.request.Request,
    *,
    timeout: float | None = None,
) -> tuple[bytes, urllib.response.addinfourl]:
    try:
        with urllib.request.urlopen(request, timeout=timeout or get_timeout_seconds()) as response:
            raw = response.read()
            encoding = response.headers.get("Content-Encoding", "")
            if "gzip" in encoding.lower():
                raw = gzip.decompress(raw)
            return raw, response
    except Exception as exc:  # noqa: BLE001
        url = getattr(request, "full_url", "")
        raise RuntimeError(f"请求失败: {url}; error={exc}") from exc


def _request_text(url: str, *, headers: dict[str, str] | None = None) -> str:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": get_web_user_agent(),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Encoding": "gzip",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            **(headers or {}),
        },
    )
    raw, _ = _request_bytes(request)
    return raw.decode("utf-8", "ignore")


def _request_json(url: str, *, headers: dict[str, str] | None = None) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": get_web_user_agent(),
            "Accept": "application/json, text/plain, */*",
            "Accept-Encoding": "gzip",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
            **(headers or {}),
        },
    )
    raw, _ = _request_bytes(request)
    try:
        payload = json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"响应不是合法 JSON: {url}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError(f"响应不是对象: {url}")
    return payload


def _tieba_sign(pairs: list[tuple[str, Any]]) -> str:
    source = "".join(f"{key}={value}" for key, value in pairs) + "tiebaclient!!!"
    return hashlib.md5(source.encode("utf-8")).hexdigest().upper()


def _request_app_form_json(
    url: str,
    *,
    pairs: list[tuple[str, Any]],
) -> dict[str, Any]:
    signed_pairs = list(pairs)
    signed_pairs.append(("sign", _tieba_sign(signed_pairs)))
    body = "&".join(
        f"{quote(str(key), safe='')}={quote(str(value), safe='')}"
        for key, value in signed_pairs
    ).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "User-Agent": get_app_user_agent(),
            "Accept-Encoding": "gzip",
            "Connection": "keep-alive",
            "Host": APP_BASE_HOST,
            "Content-Type": "application/x-www-form-urlencoded",
        },
    )
    raw, _ = _request_bytes(request)
    try:
        payload = json.loads(raw)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"响应不是合法 JSON: {url}") from exc
    if not isinstance(payload, dict):
        raise RuntimeError(f"响应不是对象: {url}")
    code = _to_int(payload.get("error_code"))
    if code not in (None, 0):
        raise RuntimeError(
            f"调用失败: url={url}; error_code={code}; message={payload.get('error_msg')}"
        )
    return payload


def _build_multipart_body(payload: bytes) -> bytes:
    boundary = PROXY_MULTIPART_BOUNDARY
    return (
        f"--{boundary}\r\n"
        'Content-Disposition: form-data; name="data"; filename="file"\r\n'
        "\r\n"
    ).encode("utf-8") + payload + f"\r\n--{boundary}--\r\n".encode("utf-8")


def _request_app_protobuf(
    url: str,
    *,
    payload: bytes,
    response_type: Any,
) -> Any:
    request = urllib.request.Request(
        url,
        data=_build_multipart_body(payload),
        method="POST",
        headers={
            "User-Agent": get_app_user_agent(),
            "x_bd_data_type": "protobuf",
            "Accept-Encoding": "gzip",
            "Connection": "keep-alive",
            "Host": APP_BASE_HOST,
            "Content-Type": f"multipart/form-data; boundary={PROXY_MULTIPART_BOUNDARY}",
        },
    )
    raw, _ = _request_bytes(request)
    response = response_type()
    try:
        response.ParseFromString(raw)
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"响应不是合法 protobuf: {url}") from exc
    if getattr(getattr(response, "error", None), "errorno", 0):
        raise RuntimeError(
            f"调用失败: url={url}; error_code={response.error.errorno}; "
            f"message={response.error.errmsg}"
        )
    return response


def _extract_query_value(url: str, key: str) -> str:
    parsed = urlparse(url)
    return _first_text(parse_qs(parsed.query).get(key, [""]))


def _resolve_forum_keyword(channel: str) -> str:
    text = clean_text(html_lib.unescape(str(channel or "")))
    text = text.removesuffix("吧")
    return text or "爱"


def _resolve_author_target(author_id: str, url: str) -> str:
    text = str(author_id or "").strip()
    if text:
        return text
    parsed_url = str(url or "").strip()
    if not parsed_url:
        return ""
    parsed = urlparse(parsed_url)
    return _first_text(
        parse_qs(parsed.query).get("un", [""]),
        parse_qs(parsed.query).get("id", [""]),
        unquote(parsed.path.rsplit("/", 1)[-1]),
    )


def _resolve_content_target(content_id: str, url: str) -> dict[str, str]:
    raw_id = str(content_id or "").strip()
    raw_url = str(url or "").strip()
    if raw_url:
        parsed = urlparse(raw_url)
        path_match = _THREAD_URL_ID_RE.search(parsed.path)
        if path_match:
            return {"kind": "thread", "id": path_match.group(1), "url": raw_url}
        topic_id = _first_text(parse_qs(parsed.query).get("topic_id", [""]))
        if topic_id:
            return {
                "kind": "topic",
                "id": topic_id,
                "topic_name": _first_text(parse_qs(parsed.query).get("topic_name", [""])),
                "url": raw_url,
            }
    if raw_id:
        return {"kind": "unknown", "id": raw_id, "url": raw_url}
    return {"kind": "", "id": "", "url": raw_url}


def _resolve_user_identity(author_id: str, url: str) -> dict[str, Any]:
    target = _resolve_author_target(author_id, url)
    if not target:
        raise RuntimeError("author_id 或 url 至少提供一个有效作者标识")
    if target.isdigit():
        return {
            "uid": int(target),
            "author_id": target,
            "user_name": "",
            "display_name": "",
            "portrait": "",
            "raw": {},
        }
    payload = _request_json(
        f"{USER_JSON_URL}?un={quote(target)}&ie=utf-8",
        headers={"Referer": BASE_URL},
    )
    creator = payload.get("creator") if isinstance(payload.get("creator"), dict) else {}
    uid = _to_int(creator.get("id"))
    if uid is None:
        raise RuntimeError(f"未能解析作者 ID: {target}")
    return {
        "uid": uid,
        "author_id": _first_text(creator.get("name"), target),
        "user_name": _first_text(creator.get("name"), target),
        "display_name": _first_text(
            creator.get("name_show"),
            creator.get("show_nickname"),
            creator.get("name"),
        ),
        "portrait": _first_text(creator.get("portrait")),
        "raw": payload,
    }


def _pb_text(contents: Any) -> str:
    parts: list[str] = []
    for fragment in contents or []:
        fragment_type = _to_int(getattr(fragment, "type", 0)) or 0
        text = _first_text(getattr(fragment, "text", ""), getattr(fragment, "link", ""))
        if fragment_type in {0, 1, 2, 4, 9, 11, 18, 27, 35, 36, 37, 40}:
            normalized = clean_text(text)
            if normalized:
                parts.append(normalized)
    return clean_text("".join(parts))


def _pb_media_urls(media_list: Any) -> list[str]:
    urls: list[str] = []
    for media in media_list or []:
        url = _normalize_url(
            _first_text(
                getattr(media, "big_pic", ""),
                getattr(media, "small_pic", ""),
                getattr(media, "water_pic", ""),
                getattr(media, "origin_pic", ""),
            )
        )
        if url:
            urls.append(url)
    return urls


def _pb_video_cover(video_info: Any) -> str:
    return _normalize_url(_first_text(getattr(video_info, "thumbnail_url", "")))


def _pb_user_display_name(user_proto: Any) -> str:
    return clean_text(
        _first_text(getattr(user_proto, "name_show", ""), getattr(user_proto, "name", ""))
    )


def _pb_user_identifier(user_proto: Any, *, fallback: str = "") -> str:
    uid = _to_int(getattr(user_proto, "id", 0))
    if uid:
        return str(uid)
    name = clean_text(getattr(user_proto, "name", ""))
    return name or fallback


def _extract_js_object(text: str, marker: str) -> dict[str, Any] | None:
    index = text.find(marker)
    if index == -1:
        return None
    start = text.find("{", index)
    if start == -1:
        return None

    depth = 0
    in_string = False
    escape = False
    for position in range(start, len(text)):
        char = text[position]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
            continue
        if char == "{":
            depth += 1
            continue
        if char == "}":
            depth -= 1
            if depth == 0:
                try:
                    parsed = json.loads(text[start : position + 1])
                except Exception:  # noqa: BLE001
                    return None
                return parsed if isinstance(parsed, dict) else None
    return None


def _build_hot_item(item: dict[str, Any], rank: int) -> dict[str, Any]:
    discuss_num = _to_int(item.get("discuss_num"))
    title = clean_text(_first_text(item.get("topic_name"), item.get("title")))
    summary = clean_text(_first_text(item.get("topic_desc"), item.get("abstract")))
    return {
        "id": _first_text(item.get("topic_id"), item.get("id"), title),
        "title": title,
        "summary": summary,
        "content": summary,
        "url": _normalize_url(_first_text(item.get("topic_url"), item.get("url"))),
        "cover": _normalize_url(
            _first_text(item.get("topic_pic"), item.get("topic_avatar"), item.get("cover"))
        ),
        "author_name": clean_text(_first_text(item.get("author_name"))),
        "author_id": _first_text(item.get("author_id")),
        "publish_time": _unix_to_iso(item.get("create_time")),
        "rank": rank,
        "hot_value": discuss_num,
        "hot_text": clean_text(_first_text(item.get("hot_text")))
        or (f"{discuss_num} 讨论" if discuss_num is not None else ""),
        "comment_count": discuss_num,
        "view_count": _to_int(item.get("content_num")),
        "source_type": "topic",
        "tags": [clean_text(item.get("tag"))] if clean_text(item.get("tag", "")) else [],
        "raw": item,
    }


def _extract_hot_topic_list(payload: dict[str, Any]) -> list[dict[str, Any]]:
    data = payload.get("data") if isinstance(payload.get("data"), dict) else {}
    bang_topic = data.get("bang_topic") if isinstance(data.get("bang_topic"), dict) else {}
    topic_list = bang_topic.get("topic_list") if isinstance(bang_topic.get("topic_list"), list) else []
    return [item for item in topic_list if isinstance(item, dict)]


def _extract_thread_blocks(html_text: str) -> list[str]:
    return [match.group(0) for match in _FORUM_THREAD_RE.finditer(html_text)]


def _extract_related_thread_blocks(html_text: str) -> list[str]:
    return [match.group(0) for match in _RELATED_THREAD_BLOCK_RE.finditer(html_text)]


def _build_thread_item(block: str, rank: int) -> dict[str, Any]:
    tid_match = _THREAD_TID_RE.search(block)
    href_match = _THREAD_HREF_RE.search(block)
    title_match = _THREAD_TITLE_RE.search(block)
    author_match = _THREAD_AUTHOR_RE.search(block)
    time_match = _THREAD_TIME_RE.search(block)
    reply_match = _THREAD_REPLY_RE.search(block)
    author_url_match = _THREAD_AUTHOR_URL_RE.search(block)

    tid = _first_text(tid_match.group(1) if tid_match else "")
    href = html_lib.unescape(_first_text(href_match.group(1) if href_match else ""))
    author_url = html_lib.unescape(
        _first_text(author_url_match.group(1) if author_url_match else "")
    )
    author_name = _safe_html_text(author_match.group(1) if author_match else "")
    title = _safe_html_text(title_match.group(1) if title_match else "")
    time_text = _safe_html_text(time_match.group(1) if time_match else "")
    reply_count = _to_int(reply_match.group(1) if reply_match else "")
    author_id = _first_text(_extract_query_value(author_url, "un"))
    return {
        "id": tid or href or title,
        "title": title,
        "summary": title,
        "content": title,
        "url": _normalize_url(href),
        "cover": "",
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": time_text,
        "rank": rank,
        "comment_count": reply_count,
        "source_type": "thread",
        "tags": [],
        "raw": {
            "tid": tid,
            "href": href,
            "author_url": author_url,
            "reply_count": reply_count,
            "time_text": time_text,
            "block": block,
        },
    }


def _build_related_thread_item(block: str, rank: int) -> dict[str, Any]:
    title_match = _RELATED_THREAD_TITLE_RE.search(block)
    href_match = _RELATED_THREAD_HREF_RE.search(block)
    reply_match = _RELATED_THREAD_REPLY_RE.search(block)
    title = _safe_html_text(title_match.group(1) if title_match else "")
    href = html_lib.unescape(_first_text(href_match.group(1) if href_match else ""))
    reply_count = _to_int(reply_match.group(1) if reply_match else "")
    item_id = href.rsplit("/", 1)[-1] or title
    return {
        "id": item_id,
        "title": title,
        "summary": title,
        "content": title,
        "url": _normalize_url(href),
        "cover": "",
        "author_name": "",
        "author_id": "",
        "publish_time": "",
        "rank": rank,
        "comment_count": reply_count,
        "source_type": "thread",
        "tags": [],
        "raw": {
            "href": href,
            "reply_count": reply_count,
            "block": block,
        },
    }


def _parse_hot_list(payload: dict[str, Any], limit: int) -> dict[str, Any]:
    items = [
        _build_hot_item(item, index)
        for index, item in enumerate(_extract_hot_topic_list(payload)[:limit], start=1)
    ]
    return _build_list_result("hot_list", items, payload)


def _parse_feed_list(html_text: str, forum_name: str, *, page: int, limit: int) -> dict[str, Any]:
    blocks = _extract_thread_blocks(html_text)
    items = [_build_thread_item(block, index) for index, block in enumerate(blocks[:limit], start=1)]
    has_more = bool(_THREAD_PAGE_HINT_RE.search(html_text)) and len(blocks) >= len(items)
    raw = {
        "forum_name": _safe_html_text(
            _FORUM_NAME_RE.search(html_text).group(1)
            if _FORUM_NAME_RE.search(html_text)
            else forum_name
        ),
        "title": _safe_html_text(
            _TITLE_RE.search(html_text).group(1) if _TITLE_RE.search(html_text) else ""
        ),
        "page": page,
        "thread_count": len(blocks),
    }
    return _build_list_result(
        "feed_list",
        items,
        raw,
        has_more=has_more,
        next_cursor=str(page + 1) if has_more else "",
    )


def _build_topic_detail_item(topic: dict[str, Any], html_text: str, url: str) -> dict[str, Any]:
    hot_value = _to_int(topic.get("hot_value"))
    real_discuss_num = _to_int(topic.get("real_discuss_num"))
    total_post_num = _to_int(topic.get("total_post_num"))
    hot_number = hot_value or real_discuss_num or total_post_num
    title = clean_text(_first_text(topic.get("topic_name"), topic.get("share_title")))
    summary = clean_text(_first_text(topic.get("topic_desc"), topic.get("share_title")))
    return {
        "id": _first_text(topic.get("topic_id"), topic.get("id"), title),
        "title": title,
        "summary": summary,
        "content": summary,
        "url": _normalize_url(_first_text(topic.get("topic_url"), url)),
        "cover": _normalize_url(_first_text(topic.get("topic_pic"), topic.get("share_pic"))),
        "author_name": clean_text(_first_text(topic.get("author_name"))),
        "author_id": _first_text(topic.get("author_id")),
        "publish_time": _unix_to_iso(topic.get("create_time")),
        "rank": 1,
        "hot_value": hot_number,
        "hot_text": clean_text(_first_text(topic.get("hot_text")))
        or (f"{hot_number} 讨论" if hot_number is not None else ""),
        "comment_count": real_discuss_num or total_post_num,
        "view_count": _to_int(topic.get("content_num")),
        "source_type": "topic",
        "tags": [clean_text(topic.get("come_from"))]
        if clean_text(_first_text(topic.get("come_from")))
        else [],
        "raw": {
            "topic": topic,
            "related_thread_count": len(_extract_related_thread_blocks(html_text)),
        },
    }


def _parse_topic_detail(html_text: str, url: str) -> dict[str, Any]:
    topic = _extract_js_object(html_text, _TOPIC_PAGE_MARKER)
    if not isinstance(topic, dict):
        raise RuntimeError("贴吧热榜详情页未找到主题数据")
    item = _build_topic_detail_item(topic, html_text, url)
    related_items = [
        _build_related_thread_item(block, index)
        for index, block in enumerate(_extract_related_thread_blocks(html_text)[:5], start=1)
    ]
    return _build_detail_result(
        item,
        {
            "topic": topic,
            "related_threads": related_items,
            "page_title": _safe_html_text(
                _TITLE_RE.search(html_text).group(1) if _TITLE_RE.search(html_text) else ""
            ),
            "url": url,
        },
    )


def _fetch_hot_list_data(*, limit: int, refresh: bool) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    payload = _request_json(HOT_TOPIC_API, headers={"Referer": BASE_URL})
    return _parse_hot_list(payload, safe_limit)


def _fetch_feed_list_data(
    *,
    channel: str,
    cursor: str,
    limit: int,
    refresh: bool,
) -> dict[str, Any]:
    del refresh
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    forum_name = _resolve_forum_keyword(channel)
    html_text = _request_text(_build_forum_url(forum_name, page=page), headers={"Referer": BASE_URL})
    return _parse_feed_list(html_text, forum_name, page=page, limit=safe_limit)


def _parse_search_item(item: dict[str, Any], rank: int) -> dict[str, Any]:
    author = item.get("author") if isinstance(item.get("author"), dict) else {}
    content = clean_text(_first_text(item.get("content")))
    title = clean_text(_first_text(item.get("title")))
    forum_name = clean_text(_first_text(item.get("fname")))
    tid = _first_text(item.get("tid"))
    author_name = clean_text(_first_text(author.get("name_show"), author.get("name")))
    author_id = clean_text(_first_text(author.get("name"), author_name))
    return {
        "id": tid or _first_text(item.get("pid"), title),
        "title": title,
        "summary": content or title,
        "content": content or title,
        "url": _build_thread_url(tid) if tid else "",
        "cover": "",
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": _unix_to_iso(item.get("time")),
        "rank": rank,
        "comment_count": None,
        "view_count": None,
        "source_type": "thread",
        "tags": [forum_name] if forum_name else [],
        "raw": item,
    }


def _fetch_search_content_data(*, query: str, cursor: str, limit: int) -> dict[str, Any]:
    keyword = query.strip()
    if not keyword:
        raise RuntimeError("query 不能为空")
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    payload = _request_app_form_json(
        SEARCH_API_URL,
        pairs=[
            ("_client_version", MAIN_VERSION),
            ("kw", ""),
            ("only_thread", 1),
            ("pn", page),
            ("rn", safe_limit),
            ("sm", 0),
            ("word", keyword),
        ],
    )
    post_list = payload.get("post_list") if isinstance(payload.get("post_list"), list) else []
    items = [
        _parse_search_item(item, index)
        for index, item in enumerate((entry for entry in post_list if isinstance(entry, dict)), start=1)
    ]
    page_info = payload.get("page") if isinstance(payload.get("page"), dict) else {}
    has_more = bool(_to_int(page_info.get("has_more")))
    raw = dict(payload)
    raw["request"] = {"query": keyword, "page": page}
    return _build_list_result(
        "search",
        items[:safe_limit],
        raw,
        has_more=has_more,
        next_cursor=str(page + 1) if has_more else "",
    )


def _fetch_profile_proto(uid: int) -> Any:
    request_proto = ProfileReqIdl_pb2.ProfileReqIdl()
    request_proto.data.common._client_type = 2
    request_proto.data.common._client_version = MAIN_VERSION
    request_proto.data.uid = uid
    request_proto.data.need_post_count = 1
    request_proto.data.pn = 1
    return _request_app_protobuf(
        AUTHOR_PROFILE_API_URL,
        payload=request_proto.SerializeToString(),
        response_type=ProfileResIdl_pb2.ProfileResIdl,
    )


def _fetch_user_threads_proto(uid: int, *, page: int, limit: int) -> Any:
    request_proto = UserPostReqIdl_pb2.UserPostReqIdl()
    request_proto.data.common._client_type = 2
    request_proto.data.common._client_version = MAIN_VERSION
    request_proto.data.user_id = uid
    request_proto.data.rn = limit
    request_proto.data.is_thread = 1
    request_proto.data.need_content = 1
    request_proto.data.pn = page
    request_proto.data.is_view_card = 2
    return _request_app_protobuf(
        AUTHOR_CONTENT_API_URL,
        payload=request_proto.SerializeToString(),
        response_type=UserPostResIdl_pb2.UserPostResIdl,
    )


def _fetch_thread_detail_proto(tid: int, *, page: int = 1, limit: int = THREAD_DETAIL_PAGE_SIZE) -> Any:
    request_proto = PbPageReqIdl_pb2.PbPageReqIdl()
    request_proto.data.common._client_type = 2
    request_proto.data.common._client_version = MAIN_VERSION
    request_proto.data.kz = tid
    request_proto.data.pn = page
    request_proto.data.rn = max(2, limit)
    request_proto.data.r = 0
    request_proto.data.lz = 0
    return _request_app_protobuf(
        THREAD_DETAIL_API_URL,
        payload=request_proto.SerializeToString(),
        response_type=PbPageResIdl_pb2.PbPageResIdl,
    )


def _parse_author_profile(identity: dict[str, Any]) -> dict[str, Any]:
    response = _fetch_profile_proto(identity["uid"])
    user = response.data.user
    author_id = str(_to_int(getattr(user, "id", 0)) or identity["author_id"])
    user_name = clean_text(_first_text(getattr(user, "name", ""), identity.get("user_name", "")))
    display_name = clean_text(
        _first_text(getattr(user, "name_show", ""), user_name, identity.get("display_name", ""))
    )
    portrait = _normalize_url(
        _first_text(getattr(user, "portrait", ""), identity.get("portrait", ""))
    )
    author = {
        "id": author_id,
        "name": display_name or user_name,
        "url": _build_author_url(user_name=user_name, user_id=author_id),
        "avatar": portrait,
        "bio": clean_text(_first_text(getattr(user, "intro", ""))),
        "follower_count": _to_int(getattr(user, "fans_num", 0)),
        "following_count": _to_int(getattr(user, "concern_num", 0)),
        "content_count": _to_int(getattr(user, "post_num", 0)),
        "raw": {
            "identity": identity,
            "user": {
                "id": author_id,
                "user_name": user_name,
                "display_name": display_name,
                "portrait": getattr(user, "portrait", ""),
                "tieba_uid": _first_text(getattr(user, "tieba_uid", "")),
                "fans_num": _to_int(getattr(user, "fans_num", 0)),
                "concern_num": _to_int(getattr(user, "concern_num", 0)),
                "post_num": _to_int(getattr(user, "post_num", 0)),
                "agree_num": _to_int(getattr(response.data.user_agree_info, "total_agree_num", 0)),
                "intro": clean_text(_first_text(getattr(user, "intro", ""))),
            },
        },
    }
    return _build_author_result(
        author,
        {
            "identity": identity,
            "profile": {
                "agree_num": _to_int(getattr(response.data.user_agree_info, "total_agree_num", 0)),
                "anti_block_stat": _to_int(getattr(response.data.anti_stat, "block_stat", 0)),
                "anti_hide_stat": _to_int(getattr(response.data.anti_stat, "hide_stat", 0)),
                "anti_days_tofree": _to_int(getattr(response.data.anti_stat, "days_tofree", 0)),
            },
        },
    )


def _parse_user_thread_item(post_info: Any, rank: int) -> dict[str, Any]:
    title = clean_text(_first_text(getattr(post_info, "title", "")))
    content = _pb_text(getattr(post_info, "first_post_content", []))
    media_urls = _pb_media_urls(getattr(post_info, "media", []))
    video_cover = _pb_video_cover(getattr(post_info, "video_info", None))
    cover = _first_text(*(media_urls + [video_cover]))
    author_name = clean_text(
        _first_text(getattr(post_info, "name_show", ""), getattr(post_info, "user_name", ""))
    )
    author_id = str(_to_int(getattr(post_info, "user_id", 0)) or _first_text(getattr(post_info, "user_name", "")))
    forum_name = clean_text(_first_text(getattr(post_info, "forum_name", "")))
    tid = str(_to_int(getattr(post_info, "thread_id", 0)) or "")
    return {
        "id": tid or str(_to_int(getattr(post_info, "post_id", 0)) or ""),
        "title": title,
        "summary": content or title,
        "content": content or title,
        "url": _build_thread_url(tid) if tid else "",
        "cover": cover,
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": _unix_to_iso(getattr(post_info, "create_time", 0)),
        "rank": rank,
        "comment_count": _to_int(getattr(post_info, "reply_num", 0)),
        "like_count": _to_int(getattr(getattr(post_info, "agree", None), "agree_num", 0)),
        "share_count": _to_int(getattr(post_info, "share_num", 0)),
        "view_count": _to_int(getattr(post_info, "freq_num", 0)),
        "source_type": "thread",
        "tags": [forum_name] if forum_name else [],
        "raw": {
            "forum_id": _to_int(getattr(post_info, "forum_id", 0)),
            "forum_name": forum_name,
            "thread_id": tid,
            "post_id": str(_to_int(getattr(post_info, "post_id", 0)) or ""),
            "thread_type": _to_int(getattr(post_info, "thread_type", 0)),
            "media_urls": media_urls,
        },
    }


def _fetch_author_content_list_data(
    *,
    author_id: str,
    url: str,
    cursor: str,
    limit: int,
) -> dict[str, Any]:
    safe_limit = _normalize_limit(limit)
    page = _parse_page_cursor(cursor)
    identity = _resolve_user_identity(author_id, url)
    response = _fetch_user_threads_proto(identity["uid"], page=page, limit=safe_limit)
    raw_post_list = list(getattr(response.data, "post_list", []))
    items = [
        _parse_user_thread_item(post_info, index)
        for index, post_info in enumerate(raw_post_list[:safe_limit], start=1)
    ]
    has_more = len(raw_post_list) >= safe_limit
    raw = {
        "identity": identity,
        "returned_count": len(raw_post_list),
        "request": {"page": page, "limit": safe_limit},
    }
    return _build_list_result(
        "author_content_list",
        items,
        raw,
        has_more=has_more,
        next_cursor=str(page + 1) if has_more else "",
    )


def _parse_thread_comment_item(comment_proto: Any, users: dict[int, Any], rank: int) -> dict[str, Any]:
    author_id = _to_int(getattr(comment_proto, "author_id", 0))
    user_proto = users.get(author_id) or getattr(comment_proto, "author", None)
    author_name = _pb_user_display_name(user_proto)
    author_identifier = _pb_user_identifier(user_proto, fallback=str(author_id or ""))
    return {
        "id": str(_to_int(getattr(comment_proto, "id", 0)) or ""),
        "content": _pb_text(getattr(comment_proto, "content", [])),
        "author_name": author_name,
        "author_id": author_identifier,
        "publish_time": _unix_to_iso(getattr(comment_proto, "time", 0)),
        "like_count": _to_int(getattr(getattr(comment_proto, "agree", None), "agree_num", 0)),
        "rank": rank,
    }


def _parse_thread_post_item(post_proto: Any, users: dict[int, Any], rank: int) -> dict[str, Any]:
    author_id = _to_int(getattr(post_proto, "author_id", 0))
    user_proto = users.get(author_id) or getattr(post_proto, "author", None)
    author_name = _pb_user_display_name(user_proto)
    author_identifier = _pb_user_identifier(user_proto, fallback=str(author_id or ""))
    comments = [
        _parse_thread_comment_item(comment_proto, users, comment_rank)
        for comment_rank, comment_proto in enumerate(
            getattr(getattr(post_proto, "sub_post_list", None), "sub_post_list", [])[:5],
            start=1,
        )
    ]
    return {
        "id": str(_to_int(getattr(post_proto, "id", 0)) or ""),
        "floor": _to_int(getattr(post_proto, "floor", 0)),
        "content": _pb_text(getattr(post_proto, "content", [])),
        "author_name": author_name,
        "author_id": author_identifier,
        "publish_time": _unix_to_iso(getattr(post_proto, "time", 0)),
        "comment_count": _to_int(getattr(post_proto, "sub_post_number", 0)),
        "like_count": _to_int(getattr(getattr(post_proto, "agree", None), "agree_num", 0)),
        "rank": rank,
        "comments": comments,
    }


def _parse_thread_detail(response: Any, *, source_url: str = "") -> dict[str, Any]:
    forum = response.data.forum
    thread = response.data.thread
    users = {
        _to_int(getattr(user_proto, "id", 0)) or 0: user_proto
        for user_proto in getattr(response.data, "user_list", [])
    }
    origin = getattr(thread, "origin_thread_info", None)
    content = _pb_text(getattr(origin, "content", [])) or _pb_text(
        getattr(thread, "first_post_content", [])
    )
    media_urls = _pb_media_urls(getattr(origin, "media", []))
    video_cover = _pb_video_cover(getattr(origin, "video_info", None))
    cover = _first_text(*(media_urls + [video_cover]))
    author_proto = getattr(thread, "author", None)
    author_name = _pb_user_display_name(author_proto)
    author_id = _pb_user_identifier(author_proto, fallback=str(_to_int(getattr(thread, "author_id", 0)) or ""))
    item = {
        "id": str(_to_int(getattr(thread, "id", 0)) or ""),
        "title": clean_text(_first_text(getattr(thread, "title", ""))),
        "summary": content or clean_text(_first_text(getattr(thread, "title", ""))),
        "content": content or clean_text(_first_text(getattr(thread, "title", ""))),
        "url": source_url or _build_thread_url(_to_int(getattr(thread, "id", 0)) or ""),
        "cover": cover,
        "author_name": author_name,
        "author_id": author_id,
        "publish_time": _unix_to_iso(getattr(thread, "create_time", 0)),
        "rank": 1,
        "comment_count": _to_int(getattr(thread, "reply_num", 0)),
        "like_count": _to_int(getattr(getattr(thread, "agree", None), "agree_num", 0)),
        "share_count": _to_int(getattr(thread, "share_num", 0)),
        "view_count": _to_int(
            getattr(response.data, "thread_freq_num", 0) or getattr(thread, "view_num", 0)
        ),
        "source_type": "thread",
        "tags": [clean_text(_first_text(getattr(forum, "name", "")))]
        if clean_text(_first_text(getattr(forum, "name", "")))
        else [],
        "raw": {
            "thread_id": _to_int(getattr(thread, "id", 0)),
            "forum_id": _to_int(getattr(forum, "id", 0)),
            "forum_name": clean_text(_first_text(getattr(forum, "name", ""))),
            "post_id": _to_int(getattr(thread, "post_id", 0)),
            "media_urls": media_urls,
            "is_share_thread": bool(_to_int(getattr(thread, "is_share_thread", 0))),
            "thread_type": _to_int(getattr(thread, "thread_type", 0)),
        },
    }
    reply_items = [
        _parse_thread_post_item(post_proto, users, rank)
        for rank, post_proto in enumerate(getattr(response.data, "post_list", [])[:10], start=1)
    ]
    return _build_detail_result(
        item,
        {
            "forum": {
                "id": _to_int(getattr(forum, "id", 0)),
                "name": clean_text(_first_text(getattr(forum, "name", ""))),
                "member_num": _to_int(getattr(forum, "member_num", 0)),
                "post_num": _to_int(getattr(forum, "post_num", 0)),
            },
            "page": {
                "current_page": _to_int(getattr(response.data.page, "current_page", 0)),
                "total_page": _to_int(getattr(response.data.page, "total_page", 0)),
                "total_count": _to_int(getattr(response.data.page, "total_count", 0)),
                "has_more": bool(_to_int(getattr(response.data.page, "has_more", 0))),
            },
            "replies": reply_items,
        },
    )


def _fetch_content_detail_data(*, content_id: str, url: str) -> dict[str, Any]:
    target = _resolve_content_target(content_id, url)
    if not target["id"]:
        raise RuntimeError("content_id 或 url 至少提供一个有效内容标识")

    if target["kind"] == "thread":
        response = _fetch_thread_detail_proto(int(target["id"]))
        return _parse_thread_detail(response, source_url=url or _build_thread_url(target["id"]))

    if target["kind"] == "topic":
        detail_url = url or _build_topic_detail_url(target["id"], target.get("topic_name", ""))
        html_text = _request_text(detail_url, headers={"Referer": BASE_URL})
        return _parse_topic_detail(html_text, detail_url)

    try:
        response = _fetch_thread_detail_proto(int(target["id"]))
        return _parse_thread_detail(response, source_url=url or _build_thread_url(target["id"]))
    except Exception:
        detail_url = url or _build_topic_detail_url(target["id"])
        html_text = _request_text(detail_url, headers={"Referer": BASE_URL})
        return _parse_topic_detail(html_text, detail_url)


@mcp.tool(name="get_hot_list", description="读取贴吧热议榜单。")
def get_hot_list(limit: int = 20, refresh: bool = False) -> dict[str, Any]:
    return _fetch_hot_list_data(limit=limit, refresh=refresh)


@mcp.tool(name="get_feed_list", description="读取指定贴吧的公开帖子流。")
def get_feed_list(
    channel: str = "",
    cursor: str = "",
    limit: int = 20,
    refresh: bool = False,
) -> dict[str, Any]:
    return _fetch_feed_list_data(
        channel=channel,
        cursor=cursor,
        limit=limit,
        refresh=refresh,
    )


@mcp.tool(name="search_content", description="搜索贴吧全站公开帖子。")
def search_content(query: str, cursor: str = "", limit: int = 20) -> dict[str, Any]:
    return _fetch_search_content_data(query=query, cursor=cursor, limit=limit)


@mcp.tool(name="get_content_detail", description="读取贴吧热榜话题详情或普通帖子详情。")
def get_content_detail(content_id: str = "", url: str = "") -> dict[str, Any]:
    return _fetch_content_detail_data(content_id=content_id, url=url)


@mcp.tool(name="get_author_profile", description="读取贴吧作者公开主页。")
def get_author_profile(author_id: str = "", url: str = "") -> dict[str, Any]:
    identity = _resolve_user_identity(author_id, url)
    return _parse_author_profile(identity)


@mcp.tool(name="get_author_content_list", description="读取贴吧作者公开发帖列表。")
def get_author_content_list(
    author_id: str = "",
    url: str = "",
    cursor: str = "",
    limit: int = 20,
) -> dict[str, Any]:
    return _fetch_author_content_list_data(
        author_id=author_id,
        url=url,
        cursor=cursor,
        limit=limit,
    )


def main() -> None:
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
