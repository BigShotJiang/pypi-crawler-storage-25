# 百度贴吧公开内容 MCP Server

## 概述

`Astron-tieba-mcp` 是一个基于 MCP 协议的百度贴吧工具服务，直接调用贴吧游客态公开接口获取公开内容，不依赖额外的 Astron 后端服务，也不依赖 Playwright 等浏览器运行时。

当前工程形态：
- 使用 `MCP Python SDK`
- 使用单文件 `server.py` 承载工具定义和 HTTP / protobuf 调用
- 通过独立 `pyproject` 打包
- 支持 `uvx` 一键启动
- 通过环境变量配置超时和 User-Agent

当前提供 6 个原子工具：
- `get_hot_list`
- `get_feed_list`
- `search_content`
- `get_content_detail`
- `get_author_profile`
- `get_author_content_list`


## 工具

### 1. 获取热榜 `get_hot_list`
- 描述：读取贴吧热议榜单。
- 参数：
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 2. 获取信息流 `get_feed_list`
- 描述：读取指定贴吧的移动端公开帖子流。
- 参数：
  - `channel`：贴吧名，支持传 `Python` 或 `Python吧`
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`
  - `refresh`：是否刷新，默认 `False`

### 3. 搜索内容 `search_content`
- 描述：通过贴吧匿名 app 搜索接口读取全站帖子结果。
- 参数：
  - `query`：搜索词，必填
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`

### 4. 获取内容详情 `get_content_detail`
- 描述：读取贴吧热榜话题详情或普通帖子详情。
- 参数：
  - `content_id`：内容 ID，可以是 `topic_id` 或 `tid`
  - `url`：内容完整 URL

### 5. 获取作者主页 `get_author_profile`
- 描述：读取贴吧作者公开主页。
- 参数：
  - `author_id`：作者用户名或用户 ID
  - `url`：作者主页 URL

### 6. 获取作者作品列表 `get_author_content_list`
- 描述：读取贴吧作者公开发帖列表。
- 参数：
  - `author_id`：作者用户名或用户 ID
  - `url`：作者主页 URL
  - `cursor`：分页游标，默认空，内部按页码处理
  - `limit`：返回条数，默认 `20`


## 环境变量

这个包默认不需要认证信息。

可选环境变量：

```bash
export TIEBA_MCP_TIMEOUT_SECONDS="30"
export TIEBA_MCP_USER_AGENT="Mozilla/5.0 ..."
```

说明：
- `TIEBA_MCP_TIMEOUT_SECONDS` 控制公开接口请求超时。
- `TIEBA_MCP_USER_AGENT` 用于覆盖默认请求头。


## 开始

### 推荐方式：使用 uvx 一键启动

```bash
uvx --from Astron-tieba-mcp tieba-mcp
```

如果你还没有安装 `uv` / `uvx`，可先执行：

```bash
curl -fsSL https://install.astral.sh/uv | bash
```

### 使用 pip 安装

```bash
pip install Astron-tieba-mcp
tieba-mcp
```

### 本地源码运行

```bash
cd tieba-mcp
PYTHONPATH=src python3 -m tieba_mcp.server
```


## MCP 客户端配置

### 使用 uvx

```json
{
  "mcpServers": {
    "tieba-mcp": {
      "command": "uvx",
      "args": ["--from", "Astron-tieba-mcp", "tieba-mcp"],
      "env": {
        "TIEBA_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```

### 使用本地源码

```json
{
  "mcpServers": {
    "tieba-mcp": {
      "command": "python3",
      "args": ["-m", "tieba_mcp.server"],
      "env": {
        "PYTHONPATH": "/path/to/tieba-mcp/src",
        "TIEBA_MCP_TIMEOUT_SECONDS": "30"
      }
    }
  }
}
```


## 说明

1. 这个 MCP 直接请求贴吧游客态公开接口，不依赖额外的 Astron 后端服务。
2. 当前仅面向公开内容能力，不包含登录态、私有内容或用户专属数据。
3. 搜索、帖子详情、作者主页和作者发帖列表都走匿名 app 端公开接口，不需要浏览器抓取。
4. 返回结果尽量保持结构化 JSON，便于 Cursor、Claude Desktop 等客户端继续消费。
5. 游客态公开接口可能受网络、地区或平台风控影响，偶发失败时建议稍后重试。


## 发布到 PyPI

```bash
cd tieba-mcp
rm -rf build dist src/*.egg-info
python3 -m build --no-isolation
python3 -m twine check dist/*
python3 -m twine upload dist/*
```


## License

Apache License 2.0. See `LICENSE`.
