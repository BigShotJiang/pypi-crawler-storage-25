import torch
import cv2
import numpy as np
import os
from PIL import Image
from diffusers import StableDiffusionControlNetPipeline, ControlNetModel, DPMSolverMultistepScheduler
from deep_translator import GoogleTranslator

# Donanım ayarları
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

# 1. ControlNet ve Model Yükleme
controlnet = ControlNetModel.from_pretrained(
    "lllyasviel/sd-controlnet-canny", 
    torch_dtype=dtype
)

_pipe = StableDiffusionControlNetPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    controlnet=controlnet,
    torch_dtype=dtype,
    safety_checker=None
).to(device)

_pipe.scheduler = DPMSolverMultistepScheduler.from_config(_pipe.scheduler.config)
translator = GoogleTranslator(source="tr", target="en")

def create_loop(prompt: str, foto: str) -> str:
    # A. Referans Görsel İşleme (Canny Edge)
    input_image = Image.open(foto).convert("RGB")
    image_np = np.array(input_image)
    
    # Kenar algılama ile iskelet çıkarma
    image_canny = cv2.Canny(image_np, 100, 200)
    image_canny = image_canny[:, :, None]
    image_canny = np.concatenate([image_canny, image_canny, image_canny], axis=2)
    canny_image = Image.fromarray(image_canny)

    # B. Prompt Hazırlığı
    # Türkçe giriş gelirse İngilizce'ye çevirir
    translated_prompt = translator.translate(prompt)
    
    # Kalite takıları (Quality Tags)
    final_prompt = f"{translated_prompt}, highly detailed, masterpiece, 8k wallpaper"
    negative_prompt = "lowres, bad anatomy, worst quality, blurry, deformed face"

    # C. Üretim Süreci
    output = _pipe(
        prompt=final_prompt,
        image=canny_image, 
        negative_prompt=negative_prompt,
        num_inference_steps=30,
        controlnet_conditioning_scale=0.7 # 0.7 referansa iyi sadık kalır ama yaratıcılığa da alan bırakır
    ).images[0]

    # D. Kayıt
    output_path = "vho_result.png"
    output.save(output_path)
    return os.path.abspath(output_path)

