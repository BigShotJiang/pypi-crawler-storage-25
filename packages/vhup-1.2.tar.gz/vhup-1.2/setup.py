from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    README = f.read()

setup(
    name="vhup",
    version="1.2",
    packages=find_packages(),
    install_requires=[
        "torch>=2.0.0",
        "diffusers>=0.28.0",
        "torchvision",
        "controlnet-aux",
        "opencv-python",
        "transformers>=4.40.0",
        "accelerate>=0.30.0",
        "safetensors",
        "imageio>=2.31.0",
        "imageio-ffmpeg>=0.4.9",
        "deep-translator",
        "numpy",
        "face_recognition",
        "Pillow",
        "insightface>=0.7.3",
        "onnxruntime-gpu",
        "peft",
        "sentencepiece",
        "protobuf"
        ],
    description="Vho: İşlevsel ve kolaylaştırılmış görsel oluşturma kütüphanesi",
    long_description=README,
    long_description_content_type="text/markdown",
    author="Bedirhan",
    author_email="bedirhan.oytpass@gmail.com",
    license="MIT",
    keywords=["görsel", "kolay", "basitleştirilmiş"],
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10"
    ],
)
