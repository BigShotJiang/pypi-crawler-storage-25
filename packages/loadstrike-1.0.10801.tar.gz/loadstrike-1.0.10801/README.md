# LoadStrike for Python

LoadStrike for Python lets you define, run, and report load scenarios directly from your application or test suite.

## Requirements

- Python 3.9 or later

## Install

```bash
pip install loadstrike
```

## What You Can Do

- Define scenarios, steps, load simulations, thresholds, and metrics in code
- Run workloads in-process and collect structured results
- Generate HTML, Markdown, TXT, and CSV reports
- Extend runs with correlation, distributed execution, and reporting sinks when needed

## Supported Transports

- HTTP
- Kafka
- RabbitMQ
- NATS
- Redis Streams
- Azure Event Hubs
- Push Diffusion
- Delegate and custom stream endpoints

## Supported Reporting Sinks

- InfluxDB
- TimescaleDB
- Grafana Loki
- Datadog
- Splunk HEC
- OpenTelemetry Collector

## Quick Start

```python
from loadstrike_sdk import (
    LoadStrikeResponse,
    LoadStrikeRunner,
    LoadStrikeScenario,
    LoadStrikeSimulation,
    LoadStrikeStep,
)

scenario = (
    LoadStrikeScenario.create(
        "orders",
        lambda context: LoadStrikeStep.run(
            "publish-order",
            context,
            lambda: LoadStrikeResponse.ok("200"),
        ).as_reply(),
    )
    .with_load_simulations(LoadStrikeSimulation.inject(10, 1, 20))
)

result = (
    LoadStrikeRunner.register_scenarios(scenario)
    .with_runner_key("rkl_your_runner_key")
    .run()
)
```

Use a runner key from your LoadStrike portal account when executing live workloads.

## Documentation And Examples

https://loadstrike.com/documentation
