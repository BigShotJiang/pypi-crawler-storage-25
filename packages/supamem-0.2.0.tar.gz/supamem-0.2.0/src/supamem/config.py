"""Per-project config discovery for supamem (D-38 precedence ladder).

Resolution order (highest to lowest):

1. ``$SUPAMEM_CONFIG`` env var pointing to an explicit TOML file
2. ``<cwd>/.supamem/config.toml`` (the canonical project config).
   MCP stdio defaults ``cwd`` to ``Path.cwd()``; set ``SUPAMEM_PROJECT_ROOT`` to your
   workspace root when the host launches the server outside the repo (Cursor/IDE).
3. ``<cwd>/pyproject.toml`` ``[tool.supamem]`` section
4. Auto-detect: presence of ``<cwd>/.claude/insights/`` seeds ``sources``
5. Defaults baked into ``ResolvedConfig``

Per-key resolution: each field is resolved independently. A user can put just
``QDRANT_URL`` in env and inherit everything else from a TOML file.

Legacy single-key env vars (compatibility with earlier embed-dev-memories.py):
- ``QDRANT_URL``, ``QDRANT_API_KEY``, ``COLLECTION_NAME``, ``EMBEDDING_MODEL``

Implementation note: lower-precedence rungs are applied FIRST, then higher
rungs unconditionally overwrite. The ``ConfigChain`` record always reflects the
last writer per field, which matches user-visible precedence.

NOTE on secrets: ``ResolvedConfig.qdrant_api_key`` may contain a user secret.
``supamem doctor`` (plan 11) MUST redact this field by default — see STRIDE
T-80.6-03-01.
"""
from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

Source = Literal["env", "supamem_toml", "pyproject", "auto_detect", "default"]


@dataclass
class ResolvedConfig:
    qdrant_url: str = "http://localhost:6333"
    qdrant_api_key: str = ""
    collection: str = "dev_memory_tuned_hybrid"
    embedder: str = "minilm"
    chunker: str = "markdown_header"
    sources: list[str] = field(default_factory=list)
    chunk_size: int = 200
    fusion: str = "rrf"
    drop_tokens: list[str] = field(default_factory=list)
    goldens_path: str = ""
    cache_dir: str = ""
    allow_legacy_collection: bool = False
    # Regress baselines — Phase 80.1 D-19 defaults; project-tunable for
    # corpora outside the supamem-internal calibration set (added v0.1.2).
    regress_baseline_recall_at_5: float = 0.60
    regress_baseline_total_tokens: int = 4000
    regress_baseline_p95_latency_ms: int = 500
    # MCP response caps — Phase 5 D-09 / D-10. Three flat fields populated
    # from the two-level [supamem.mcp.caps] TOML table via _NESTED_TABLES.
    mcp_caps_max_top_k: int = 25
    mcp_caps_max_query_chars: int = 250
    mcp_caps_max_preview_chars: int = 200


@dataclass
class ConfigChain:
    qdrant_url: Source = "default"
    qdrant_api_key: Source = "default"
    collection: Source = "default"
    embedder: Source = "default"
    chunker: Source = "default"
    sources: Source = "default"
    chunk_size: Source = "default"
    fusion: Source = "default"
    drop_tokens: Source = "default"
    goldens_path: Source = "default"
    cache_dir: Source = "default"
    regress_baseline_recall_at_5: Source = "default"
    regress_baseline_total_tokens: Source = "default"
    regress_baseline_p95_latency_ms: Source = "default"
    mcp_caps_max_top_k: Source = "default"
    mcp_caps_max_query_chars: Source = "default"
    mcp_caps_max_preview_chars: Source = "default"


_LEGACY_ENV: dict[str, str] = {
    "QDRANT_URL": "qdrant_url",
    "QDRANT_API_KEY": "qdrant_api_key",
    "COLLECTION_NAME": "collection",
    "EMBEDDING_MODEL": "embedder",
}

_NESTED_TABLES: list[tuple[str, dict[str, str]]] = [
    ("hook", {"drop_tokens": "drop_tokens"}),
    (
        "eval",
        {
            "goldens_path": "goldens_path",
            "baseline_recall_at_5": "regress_baseline_recall_at_5",
            "baseline_total_tokens": "regress_baseline_total_tokens",
            "baseline_p95_latency_ms": "regress_baseline_p95_latency_ms",
        },
    ),
    ("cache", {"cache_dir": "cache_dir"}),
    # Two-level dotted path: [supamem.mcp.caps] → flat mcp_caps_* fields.
    # _apply_nested drills through "mcp" then "caps"; _apply_section skips
    # the FIRST segment ("mcp") in its skip-set to avoid setattr accidents.
    (
        "mcp.caps",
        {
            "max_top_k": "mcp_caps_max_top_k",
            "max_query_chars": "mcp_caps_max_query_chars",
            "max_preview_chars": "mcp_caps_max_preview_chars",
        },
    ),
]


def _load_toml(p: Path) -> dict[str, Any]:
    try:
        return tomllib.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"supamem: failed to parse {p}: {exc}") from exc


def _apply_section(
    cfg: ResolvedConfig,
    chain: ConfigChain,
    section: dict[str, Any],
    source: Source,
) -> None:
    """Apply flat field overrides from a [supamem] / [tool.supamem] section."""
    # For dotted nested keys (e.g. "mcp.caps") only the FIRST segment
    # ("mcp") ever appears as a top-level key in the TOML data — skip that.
    skip_first_segments = {sub.split(".", 1)[0] for sub, _ in _NESTED_TABLES}
    for key, value in section.items():
        if hasattr(cfg, key) and not isinstance(getattr(cfg, key), dict):
            # skip nested tables (hook/eval/cache/mcp) — handled by _apply_nested
            if key in skip_first_segments:
                continue
            setattr(cfg, key, value)
            setattr(chain, key, source)


def _apply_nested(
    cfg: ResolvedConfig,
    chain: ConfigChain,
    section: dict[str, Any],
    source: Source,
) -> None:
    """Apply nested [supamem.hook], [supamem.eval], [supamem.cache], [supamem.mcp.caps] tables.

    A ``sub_key`` containing one or more dots (e.g. ``"mcp.caps"``) is drilled
    level-by-level through ``section`` via ``dict.get(part, {})``. Single-level
    keys keep the existing flat behavior. A non-dict at any intermediate level
    falls through harmlessly (defaults remain in effect).
    """
    for sub_key, field_map in _NESTED_TABLES:
        sub: Any = section
        for part in sub_key.split("."):
            if not isinstance(sub, dict):
                sub = {}
                break
            sub = sub.get(part, {})
        if not isinstance(sub, dict):
            continue
        for src_key, dst_field in field_map.items():
            if src_key in sub:
                setattr(cfg, dst_field, sub[src_key])
                setattr(chain, dst_field, source)


def find_project_root(start: Path | None = None) -> Path | None:
    """Walk parents from ``start`` looking for a supamem-aware project root.

    A directory qualifies if it contains either:

    * ``.supamem/config.toml`` (canonical project config), OR
    * ``pyproject.toml`` whose parsed contents include a ``[tool.supamem]`` table.

    Used by ``supamem mcp-server`` when ``SUPAMEM_PROJECT_ROOT`` is unset, so MCP
    hosts that spawn the subprocess from a non-workspace cwd (Cursor, some IDE
    integrations) can still locate the workspace's ``.supamem/config.toml``.

    Stops at the filesystem root or at ``$HOME`` (whichever comes first) to avoid
    scanning above the user's home directory. Returns ``None`` if no marker is
    found. Tradeoff: a parent project further up the tree could be picked up
    accidentally — that is why ``SUPAMEM_PROJECT_ROOT`` remains the preferred,
    explicit mechanism.
    """
    start = (start or Path.cwd()).resolve()
    try:
        home = Path.home().resolve()
    except (RuntimeError, OSError):
        home = None

    current = start
    while True:
        if (current / ".supamem" / "config.toml").is_file():
            return current
        pyproject = current / "pyproject.toml"
        if pyproject.is_file():
            try:
                data = _load_toml(pyproject)
            except RuntimeError:
                data = {}
            if isinstance(data.get("tool"), dict) and isinstance(
                data["tool"].get("supamem"), dict
            ):
                return current

        parent = current.parent
        if parent == current:
            return None
        if home is not None and current == home:
            return None
        current = parent


def load_config(cwd: Path | None = None) -> tuple[ResolvedConfig, ConfigChain]:
    """Resolve the supamem config for ``cwd`` (defaults to ``Path.cwd()``)."""
    cwd = cwd or Path.cwd()
    cfg = ResolvedConfig()
    chain = ConfigChain()

    # ── 4. Auto-detect (lowest applied rung) ──────────────────────────────
    if (cwd / ".claude" / "insights").exists():
        cfg.sources = [".claude/insights/", ".claude/rules/"]
        chain.sources = "auto_detect"

    # ── 3. pyproject.toml [tool.supamem] ──────────────────────────────────
    pyproject = cwd / "pyproject.toml"
    if pyproject.is_file():
        data = _load_toml(pyproject)
        section = data.get("tool", {}).get("supamem", {}) or {}
        _apply_section(cfg, chain, section, "pyproject")
        _apply_nested(cfg, chain, section, "pyproject")

    # ── 2. .supamem/config.toml ───────────────────────────────────────────
    supamem_toml = cwd / ".supamem" / "config.toml"
    if supamem_toml.is_file():
        data = _load_toml(supamem_toml)
        section = data.get("supamem", {}) or {}
        _apply_section(cfg, chain, section, "supamem_toml")
        _apply_nested(cfg, chain, section, "supamem_toml")

    # ── 1a. SUPAMEM_CONFIG explicit path ──────────────────────────────────
    explicit = os.environ.get("SUPAMEM_CONFIG", "").strip()
    if explicit:
        ep = Path(explicit)
        if not ep.is_file():
            raise FileNotFoundError(
                f"supamem: SUPAMEM_CONFIG points to missing file: {ep}"
            )
        data = _load_toml(ep)
        section = data.get("supamem", {}) or {}
        _apply_section(cfg, chain, section, "env")
        _apply_nested(cfg, chain, section, "env")

    # ── 1b. Legacy single-key env vars (highest precedence) ───────────────
    for env_name, field_name in _LEGACY_ENV.items():
        val = os.environ.get(env_name)
        if val is not None and val != "":
            setattr(cfg, field_name, val)
            setattr(chain, field_name, "env")

    return cfg, chain
