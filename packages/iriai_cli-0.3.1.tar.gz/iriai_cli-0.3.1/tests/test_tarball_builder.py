"""
Tests for CLI tarball_builder module.

Tests SECRET_PATTERNS parity with PreflightAnalyzer (C3 fix),
should_include filtering, create_project_tarball, and
IGNORED_DIRS/IGNORED_FILES handling.
"""

import tarfile
import tempfile
from pathlib import Path

import pytest

from iriai_cli.tarball_builder import (
    IGNORED_DIRS,
    IGNORED_FILES,
    SECRET_PATTERNS,
    _matches_secret_pattern,
    create_project_tarball,
    should_include,
)


# =============================================================================
# Fixtures
# =============================================================================


@pytest.fixture
def project_dir():
    """Create a temporary project directory with sample files."""
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp)
        (d / "src").mkdir()
        (d / "src" / "main.tsx").write_text("import React from 'react'")
        (d / "src" / "App.tsx").write_text("export default App")
        (d / "package.json").write_text('{"name":"test","dependencies":{"react":"^18.0.0"}}')
        (d / "README.md").write_text("# Test Project")
        yield d


# =============================================================================
# SECRET_PATTERNS Parity (C3 FIX)
# =============================================================================


class TestSecretPatternsParity:
    """Verify SECRET_PATTERNS matches PreflightAnalyzer exactly (C3)."""

    def test_all_patterns_present(self):
        """C3: SECRET_PATTERNS must be byte-for-byte identical across files."""
        expected = {
            ".env", ".env.local", ".env.production", ".env.development",
            "*.pem", "*.key", "*.p12", "*.pfx",
            "credentials.*", "secrets.*",
            ".npmrc", ".pypirc",
        }
        assert SECRET_PATTERNS == expected

    def test_pattern_count(self):
        assert len(SECRET_PATTERNS) == 12


# =============================================================================
# _matches_secret_pattern
# =============================================================================


class TestMatchesSecretPattern:
    """Tests for _matches_secret_pattern function."""

    def test_env_file(self):
        assert _matches_secret_pattern(".env") is True

    def test_env_local(self):
        assert _matches_secret_pattern(".env.local") is True

    def test_env_production(self):
        """C3: .env.production must be detected."""
        assert _matches_secret_pattern(".env.production") is True

    def test_env_development(self):
        """C3: .env.development must be detected."""
        assert _matches_secret_pattern(".env.development") is True

    def test_env_custom(self):
        """Any .env.* variant should match via startswith check."""
        assert _matches_secret_pattern(".env.staging") is True

    def test_pem_file(self):
        assert _matches_secret_pattern("server.pem") is True

    def test_key_file(self):
        assert _matches_secret_pattern("private.key") is True

    def test_p12_file(self):
        assert _matches_secret_pattern("cert.p12") is True

    def test_pfx_file(self):
        assert _matches_secret_pattern("cert.pfx") is True

    def test_npmrc(self):
        assert _matches_secret_pattern(".npmrc") is True

    def test_pypirc(self):
        assert _matches_secret_pattern(".pypirc") is True

    def test_normal_source_file(self):
        assert _matches_secret_pattern("App.tsx") is False

    def test_package_json(self):
        assert _matches_secret_pattern("package.json") is False

    def test_readme(self):
        assert _matches_secret_pattern("README.md") is False

    def test_config_ts(self):
        assert _matches_secret_pattern("vite.config.ts") is False


# =============================================================================
# should_include
# =============================================================================


class TestShouldInclude:
    """Tests for should_include function."""

    def test_includes_normal_source(self, project_dir):
        path = project_dir / "src" / "main.tsx"
        assert should_include(path, project_dir) is True

    def test_excludes_git_directory(self, project_dir):
        git_file = project_dir / ".git" / "config"
        git_file.parent.mkdir(parents=True, exist_ok=True)
        git_file.write_text("config")
        assert should_include(git_file, project_dir) is False

    def test_excludes_node_modules(self, project_dir):
        nm_file = project_dir / "node_modules" / "react" / "index.js"
        nm_file.parent.mkdir(parents=True, exist_ok=True)
        nm_file.write_text("module")
        assert should_include(nm_file, project_dir) is False

    def test_excludes_venv(self, project_dir):
        venv_file = project_dir / "venv" / "lib" / "python.py"
        venv_file.parent.mkdir(parents=True, exist_ok=True)
        venv_file.write_text("lib")
        assert should_include(venv_file, project_dir) is False

    def test_excludes_pycache(self, project_dir):
        cache_file = project_dir / "__pycache__" / "module.pyc"
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.write_text("bytecode")
        assert should_include(cache_file, project_dir) is False

    def test_excludes_ds_store(self, project_dir):
        ds_file = project_dir / ".DS_Store"
        ds_file.write_text("")
        assert should_include(ds_file, project_dir) is False

    def test_excludes_thumbs_db(self, project_dir):
        thumbs_file = project_dir / "Thumbs.db"
        thumbs_file.write_text("")
        assert should_include(thumbs_file, project_dir) is False

    def test_excludes_env_file(self, project_dir):
        """C3: .env must not be included in tarball."""
        env_file = project_dir / ".env"
        env_file.write_text("SECRET=1")
        assert should_include(env_file, project_dir) is False

    def test_excludes_env_production(self, project_dir):
        """C3: .env.production must not be included."""
        env_file = project_dir / ".env.production"
        env_file.write_text("PROD_SECRET=1")
        assert should_include(env_file, project_dir) is False

    def test_excludes_pem_file(self, project_dir):
        """C3: .pem files must not be included."""
        pem_file = project_dir / "server.pem"
        pem_file.write_text("-----BEGIN CERTIFICATE-----")
        assert should_include(pem_file, project_dir) is False

    def test_excludes_key_file(self, project_dir):
        """C3: .key files must not be included."""
        key_file = project_dir / "private.key"
        key_file.write_text("-----BEGIN PRIVATE KEY-----")
        assert should_include(key_file, project_dir) is False

    def test_excludes_all_ignored_dirs(self, project_dir):
        for d in IGNORED_DIRS:
            dir_file = project_dir / d / "file.txt"
            dir_file.parent.mkdir(parents=True, exist_ok=True)
            dir_file.write_text("content")
            assert should_include(dir_file, project_dir) is False, f"Should exclude {d}"

    def test_includes_package_json(self, project_dir):
        assert should_include(project_dir / "package.json", project_dir) is True

    def test_includes_nested_source(self, project_dir):
        nested = project_dir / "src" / "components" / "Button.tsx"
        nested.parent.mkdir(parents=True, exist_ok=True)
        nested.write_text("export Button")
        assert should_include(nested, project_dir) is True


# =============================================================================
# IGNORED_DIRS coverage
# =============================================================================


class TestIgnoredDirs:
    """Tests for IGNORED_DIRS set completeness."""

    def test_contains_git(self):
        assert ".git" in IGNORED_DIRS

    def test_contains_node_modules(self):
        assert "node_modules" in IGNORED_DIRS

    def test_contains_venv(self):
        assert ".venv" in IGNORED_DIRS
        assert "venv" in IGNORED_DIRS

    def test_contains_pycache(self):
        assert "__pycache__" in IGNORED_DIRS

    def test_contains_build_dirs(self):
        assert "dist" in IGNORED_DIRS
        assert "build" in IGNORED_DIRS

    def test_contains_framework_dirs(self):
        assert ".next" in IGNORED_DIRS
        assert ".nuxt" in IGNORED_DIRS

    def test_contains_cache_dirs(self):
        assert ".pytest_cache" in IGNORED_DIRS
        assert ".mypy_cache" in IGNORED_DIRS


# =============================================================================
# create_project_tarball
# =============================================================================


class TestCreateProjectTarball:
    """Tests for create_project_tarball function."""

    def test_creates_tarball_file(self, project_dir):
        result = create_project_tarball(project_dir)
        assert result.exists()
        assert result.suffix == ".gz"
        assert result.stat().st_size > 0
        # Cleanup
        result.unlink(missing_ok=True)

    def test_tarball_is_valid_gzip(self, project_dir):
        result = create_project_tarball(project_dir)
        content = result.read_bytes()
        assert content[:2] == b"\x1f\x8b"  # gzip magic number
        result.unlink(missing_ok=True)

    def test_tarball_contains_source_files(self, project_dir):
        result = create_project_tarball(project_dir)
        with tarfile.open(result, "r:gz") as tar:
            names = tar.getnames()
            assert any("main.tsx" in n for n in names)
            assert any("package.json" in n for n in names)
        result.unlink(missing_ok=True)

    def test_tarball_excludes_git(self, project_dir):
        (project_dir / ".git").mkdir()
        (project_dir / ".git" / "config").write_text("gitconfig")
        result = create_project_tarball(project_dir)
        with tarfile.open(result, "r:gz") as tar:
            names = tar.getnames()
            assert not any(".git" in n for n in names)
        result.unlink(missing_ok=True)

    def test_tarball_excludes_node_modules(self, project_dir):
        (project_dir / "node_modules" / "react").mkdir(parents=True)
        (project_dir / "node_modules" / "react" / "index.js").write_text("module")
        result = create_project_tarball(project_dir)
        with tarfile.open(result, "r:gz") as tar:
            names = tar.getnames()
            assert not any("node_modules" in n for n in names)
        result.unlink(missing_ok=True)

    def test_tarball_excludes_secret_files(self, project_dir):
        """C3: Secret files must not be included in tarball."""
        (project_dir / ".env").write_text("SECRET=1")
        (project_dir / ".env.production").write_text("PROD_SECRET=1")
        (project_dir / "server.pem").write_text("CERT")
        result = create_project_tarball(project_dir)
        with tarfile.open(result, "r:gz") as tar:
            names = tar.getnames()
            assert not any(".env" in n for n in names)
            assert not any(".pem" in n for n in names)
        result.unlink(missing_ok=True)

    def test_tarball_excludes_ds_store(self, project_dir):
        (project_dir / ".DS_Store").write_text("")
        result = create_project_tarball(project_dir)
        with tarfile.open(result, "r:gz") as tar:
            names = tar.getnames()
            assert not any(".DS_Store" in n for n in names)
        result.unlink(missing_ok=True)
