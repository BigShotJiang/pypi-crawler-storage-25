"""Local filesystem analyzer for --local mode.

Port of the engine's local_analyzer.py without SQLAlchemy dependencies.
Produces the same dict structures (RepoSummary, ExistingIntegration) that
the prompt builder expects.
"""

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

IGNORED_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__",
    ".pytest_cache", "dist", "build", ".next", ".nuxt",
}

SECRET_PATTERNS = {
    ".env", ".env.local", ".env.production", ".env.development",
    "*.pem", "*.key", "*.p12", "*.pfx",
    "credentials.*", "secrets.*",
    ".npmrc", ".pypirc",
}


def _matches_secret_pattern(path: str) -> bool:
    """Check if a file path matches common secret patterns."""
    filename = path.split("/")[-1]
    for pattern in SECRET_PATTERNS:
        if pattern.startswith("*"):
            if filename.endswith(pattern[1:]):
                return True
        elif filename == pattern or filename.startswith(".env"):
            return True
    return False


def analyze_local(project_dir: Path, module_defs: list[dict] | None = None):
    """Analyze a local project directory.

    Args:
        project_dir: Path to project root.
        module_defs: Optional list of module definition dicts to check.

    Returns:
        Tuple of (repo_summary dict, existing_integrations dict, relevant_files dict).
    """
    files = _list_files(project_dir)
    manifests = _read_manifests(project_dir, files)

    framework, framework_version, language, bundler, package_manager = _detect_stack(manifests)
    entry_points = _find_entry_points(files, framework)
    conventions = _extract_conventions(project_dir, files, language)

    repo_summary = {
        "framework": framework,
        "framework_version": framework_version,
        "bundler": bundler,
        "language": language,
        "entry_points": entry_points,
        "package_manager": package_manager,
        "file_count": len(files),
        "code_conventions": conventions,
    }

    existing_integrations = {}
    if module_defs:
        for mod in module_defs:
            name = mod.get("name", "")
            existing_integrations[name] = _detect_existing(
                project_dir, files, manifests, mod
            )

    relevant_files = _collect_relevant_files(project_dir, files, entry_points)

    return repo_summary, existing_integrations, relevant_files


def _list_files(project_dir: Path) -> list[str]:
    files = []
    for path in project_dir.rglob("*"):
        if path.is_file():
            rel = str(path.relative_to(project_dir))
            if any(part in IGNORED_DIRS for part in path.relative_to(project_dir).parts):
                continue
            if _matches_secret_pattern(rel):
                continue
            files.append(rel)
    return sorted(files)


def _read_manifests(project_dir: Path, files: list[str]) -> dict[str, str]:
    manifest_patterns = {"package.json", "requirements.txt", "pyproject.toml", "Cargo.toml", "go.mod"}
    manifests = {}
    for f in files:
        if Path(f).name in manifest_patterns and f.count("/") <= 1:
            try:
                manifests[f] = (project_dir / f).read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                pass
    return manifests


def _detect_stack(manifests):
    framework = None
    framework_version = None
    language = None
    bundler = None
    package_manager = None

    if "package.json" in manifests:
        language = "typescript"
        package_manager = "npm"
        try:
            pkg = json.loads(manifests["package.json"])
            deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
            if "react" in deps:
                framework = "react"
                framework_version = deps.get("react", "").lstrip("^~")
            elif "vue" in deps:
                framework = "vue"
                framework_version = deps.get("vue", "").lstrip("^~")
            elif "next" in deps:
                framework = "nextjs"
                framework_version = deps.get("next", "").lstrip("^~")
            elif "svelte" in deps:
                framework = "svelte"
            if "vite" in deps:
                bundler = "vite"
            elif "@parcel/core" in deps or "parcel" in deps:
                bundler = "parcel"
            elif "webpack" in deps:
                bundler = "webpack"
            if pkg.get("packageManager", "").startswith("yarn"):
                package_manager = "yarn"
            elif pkg.get("packageManager", "").startswith("pnpm"):
                package_manager = "pnpm"
        except json.JSONDecodeError:
            pass
    elif "requirements.txt" in manifests or "pyproject.toml" in manifests:
        language = "python"
        package_manager = "pip"
        req_content = manifests.get("requirements.txt", "") + manifests.get("pyproject.toml", "")
        if "fastapi" in req_content.lower():
            framework = "fastapi"
        elif "django" in req_content.lower():
            framework = "django"
        elif "flask" in req_content.lower():
            framework = "flask"
    elif "go.mod" in manifests:
        language = "go"
    elif "Cargo.toml" in manifests:
        language = "rust"

    return framework, framework_version, language, bundler, package_manager


def _find_entry_points(files, framework):
    candidates = []
    patterns = [
        r"^src/(main|index|app)\.(ts|tsx|js|jsx)$",
        r"^src/App\.(ts|tsx|js|jsx)$",
        r"^(app|main)\.(py|ts|js)$",
        r"^index\.(ts|tsx|js|jsx|html)$",
    ]
    for f in files:
        for p in patterns:
            if re.match(p, f):
                candidates.append(f)
                break
    return candidates


def _extract_conventions(project_dir, files, language):
    conventions = {
        "indent": "spaces:2",
        "quotes": "single",
        "semicolons": False,
        "trailing_commas": "all",
        "import_style": "named",
    }
    sample_ext = {".ts", ".tsx", ".js", ".jsx"} if language == "typescript" else {".py"}
    samples = [f for f in files if Path(f).suffix in sample_ext][:5]
    for f in samples:
        try:
            content = (project_dir / f).read_text(encoding="utf-8")
            lines = content.split("\n")
            for line in lines:
                if line and line[0] == " ":
                    spaces = len(line) - len(line.lstrip(" "))
                    conventions["indent"] = f"spaces:{spaces}" if spaces in (2, 4) else "spaces:2"
                    break
                elif line and line[0] == "\t":
                    conventions["indent"] = "tabs"
                    break
            if language == "typescript":
                conventions["quotes"] = "single" if content.count("'") > content.count('"') else "double"
                conventions["semicolons"] = ";\n" in content or "; " in content
            break
        except (OSError, UnicodeDecodeError):
            continue
    return conventions


def _detect_existing(project_dir, files, manifests, module_def):
    """Detect if a module is already installed."""
    analyze = module_def.get("analyze", {})
    detection_rules = analyze.get("detection_rules", [])
    installed = False

    for rule in detection_rules:
        if _evaluate_detection_rule(project_dir, files, manifests, rule):
            installed = True
            break

    issues = []
    if installed:
        for rule in analyze.get("misconfiguration_rules", []):
            if _evaluate_misconfig_rule(project_dir, files, manifests, rule):
                issues.append(rule.get("message", ""))

    status = None
    if installed:
        status = "misconfigured" if issues else "installed"

    return {
        "installed": installed,
        "status": status,
        "issues": issues,
    }


def _evaluate_detection_rule(project_dir, files, manifests, rule):
    rule_type = rule.get("type", "")
    if rule_type == "file_exists":
        pattern = rule.get("file_pattern", "")
        return any(re.match(pattern, f) for f in files) if pattern else False
    elif rule_type == "file_contains":
        fp = rule.get("file_pattern", "")
        pat = rule.get("pattern", "")
        if fp and pat:
            for f in files:
                if re.match(fp, f):
                    try:
                        content = (project_dir / f).read_text(encoding="utf-8")
                        if re.search(pat, content):
                            return True
                    except (OSError, UnicodeDecodeError):
                        pass
        return False
    elif rule_type == "package_installed":
        pkg_name = rule.get("package_name", "")
        if pkg_name:
            pkg_content = manifests.get("package.json", "")
            if pkg_content:
                try:
                    pkg = json.loads(pkg_content)
                    all_deps = {**pkg.get("dependencies", {}), **pkg.get("devDependencies", {})}
                    return pkg_name in all_deps
                except json.JSONDecodeError:
                    pass
            req_content = manifests.get("requirements.txt", "")
            if pkg_name.lower() in req_content.lower():
                return True
        return False
    return False


def _evaluate_misconfig_rule(project_dir, files, manifests, rule):
    check_type = rule.get("check_type", "")
    if check_type == "file_contains":
        fp = rule.get("file_pattern", "")
        pat = rule.get("pattern", "")
        if fp and pat:
            for f in files:
                if re.match(fp, f):
                    try:
                        content = (project_dir / f).read_text(encoding="utf-8")
                        if re.search(pat, content):
                            return True
                    except (OSError, UnicodeDecodeError):
                        pass
        return False
    elif check_type == "file_not_contains":
        fp = rule.get("file_pattern", "")
        pat = rule.get("pattern", "")
        if fp and pat:
            for f in files:
                if re.match(fp, f):
                    try:
                        content = (project_dir / f).read_text(encoding="utf-8")
                        if not re.search(pat, content):
                            return True
                    except (OSError, UnicodeDecodeError):
                        pass
        return False
    return False


def _collect_relevant_files(project_dir, files, entry_points):
    relevant = {}
    MAX_FILES = 30
    MAX_FILE_SIZE = 50_000

    for ep in entry_points:
        if ep in files and not _matches_secret_pattern(ep):
            try:
                content = (project_dir / ep).read_text(encoding="utf-8")
                if len(content) <= MAX_FILE_SIZE:
                    relevant[ep] = content
            except (OSError, UnicodeDecodeError):
                pass

    config_patterns = [
        r"^tsconfig\.json$", r"^vite\.config\.(ts|js)$",
        r"^webpack\.config\.(ts|js)$", r"^\.env\.example$",
        r"^package\.json$", r"^requirements\.txt$", r"^pyproject\.toml$",
    ]
    for f in files:
        if len(relevant) >= MAX_FILES:
            break
        for pattern in config_patterns:
            if re.match(pattern, f):
                try:
                    content = (project_dir / f).read_text(encoding="utf-8")
                    if len(content) <= MAX_FILE_SIZE:
                        relevant[f] = content
                except (OSError, UnicodeDecodeError):
                    pass
                break

    source_ext = {".ts", ".tsx", ".js", ".jsx", ".py", ".go", ".rs"}
    for f in files:
        if len(relevant) >= MAX_FILES:
            break
        if f not in relevant and Path(f).suffix in source_ext:
            try:
                content = (project_dir / f).read_text(encoding="utf-8")
                if len(content) <= MAX_FILE_SIZE:
                    relevant[f] = content
            except (OSError, UnicodeDecodeError):
                pass

    return relevant
