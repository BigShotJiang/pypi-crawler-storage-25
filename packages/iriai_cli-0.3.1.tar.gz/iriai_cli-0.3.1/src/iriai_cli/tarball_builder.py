"""Build tarballs from local project directories."""

import logging
import tarfile
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)


IGNORED_DIRS = {
    ".git",
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    "dist",
    "build",
    ".next",
    ".nuxt",
}

IGNORED_FILES = {
    ".DS_Store",
    "Thumbs.db",
}

# C3 FIX: Match PreflightAnalyzer's SECRET_PATTERNS exactly
SECRET_PATTERNS = {
    ".env", ".env.local", ".env.production", ".env.development",
    "*.pem", "*.key", "*.p12", "*.pfx",
    "credentials.*", "secrets.*",
    ".npmrc", ".pypirc",
}


def _matches_secret_pattern(filename: str) -> bool:
    """Check if a filename matches common secret patterns."""
    for pattern in SECRET_PATTERNS:
        if pattern.startswith("*"):
            if filename.endswith(pattern[1:]):
                return True
        elif filename == pattern or filename.startswith(".env"):
            return True
    return False


def should_include(path: Path, base_dir: Path) -> bool:
    """Check if a path should be included in the tarball."""
    relative = path.relative_to(base_dir)

    # Check if any parent is an ignored directory
    if any(part in IGNORED_DIRS for part in relative.parts):
        return False

    # Check if file is ignored
    if path.name in IGNORED_FILES:
        return False

    # Never include secret files
    if _matches_secret_pattern(path.name):
        return False

    return True


def create_project_tarball(project_dir: Path) -> Path:
    """Create a gzipped tarball of the project directory.

    Args:
        project_dir: Path to project root.

    Returns:
        Path to created tarball (in temp directory).
    """
    temp_file = Path(tempfile.gettempdir()) / f"iriai-{project_dir.name}.tar.gz"

    with tarfile.open(temp_file, "w:gz") as tar:
        for path in project_dir.rglob("*"):
            if path.is_file() and should_include(path, project_dir):
                arcname = path.relative_to(project_dir)
                tar.add(path, arcname=arcname)
                logger.debug(f"Added to tarball: {arcname}")

    logger.info(f"Created tarball: {temp_file} ({temp_file.stat().st_size} bytes)")
    return temp_file
