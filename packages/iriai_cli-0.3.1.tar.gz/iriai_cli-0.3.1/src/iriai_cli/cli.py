"""Main CLI command definitions."""

import click
from rich.console import Console

from . import __version__

console = Console()


@click.group()
@click.version_option(__version__)
def main():
    """Iriai CLI — Integrate platform modules into your local project."""
    pass


@main.group()
def modules():
    """Manage available modules."""
    pass


@modules.command("list")
def modules_list():
    """List all available modules."""
    import asyncio

    from rich.table import Table

    from .api_client import APIClient, APIError

    client = APIClient()

    try:
        modules_data = asyncio.run(client.get_modules())
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        return

    if not modules_data:
        console.print("[yellow]No modules available.[/yellow]")
        return

    table = Table(title="Available Modules")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Version", style="magenta")
    table.add_column("Description")

    for module in modules_data:
        table.add_row(
            module["name"],
            module["version"],
            module["description"],
        )

    console.print(table)
    console.print("\nRun 'iriai analyze' to see which modules apply to your project.")


@main.command()
def analyze():
    """Analyze the current directory for module compatibility."""
    import asyncio
    from pathlib import Path

    from rich.table import Table

    from .api_client import APIClient, APIError
    from .tarball_builder import create_project_tarball

    console.print("Analyzing current directory...\n")

    # Create tarball
    project_dir = Path.cwd()

    try:
        tarball_path = create_project_tarball(project_dir)
    except Exception as e:
        console.print(f"[red]Error creating tarball:[/red] {e}")
        return

    # Call analyze endpoint
    client = APIClient()

    try:
        result = asyncio.run(client.analyze(str(tarball_path)))
    except APIError as e:
        console.print(f"[red]Analysis failed:[/red] {e}")
        tarball_path.unlink(missing_ok=True)
        return
    finally:
        tarball_path.unlink(missing_ok=True)

    # Display results
    repo = result.get("repo_summary", {})
    console.print("[bold]Project Analysis[/bold]\n")
    console.print(f"Framework: [cyan]{repo.get('framework', 'unknown')}[/cyan]")
    console.print(f"Language: [cyan]{repo.get('language', 'unknown')}[/cyan]")
    console.print(f"Bundler: [cyan]{repo.get('bundler', 'unknown')}[/cyan]")

    # Module status table
    existing = result.get("existing_integrations", {})

    if existing:
        console.print("\n[bold]Module Status[/bold]\n")

        table = Table()
        table.add_column("Module", style="cyan")
        table.add_column("Status")
        table.add_column("Issues")

        for module_name, status in existing.items():
            status_value = status.get("status")

            # Color-code status
            if not status_value or status_value == "not_installed":
                status_display = "[dim]not installed[/dim]"
            elif status_value == "installed":
                status_display = "[green]installed[/green]"
            elif status_value == "misconfigured":
                status_display = "[yellow]misconfigured[/yellow]"
            else:
                status_display = status_value

            issues = status.get("issues", [])
            issues_display = f"{len(issues)} issues" if issues else "[dim]—[/dim]"

            table.add_row(module_name, status_display, issues_display)

        console.print(table)

    # Show competing solutions
    if result.get("competing_solutions_detected"):
        console.print("\n[bold yellow]Competing Solutions Detected[/bold yellow]\n")
        for module_name, status in existing.items():
            for cs in status.get("competing_solutions", []):
                if cs.get("detected"):
                    console.print(f"  {cs['name']}: {cs['warning_message']}")

    # Actionable suggestions
    installable = [
        name for name, status in existing.items()
        if not status.get("installed")
    ]
    repairable = [
        name for name, status in existing.items()
        if status.get("status") == "misconfigured"
    ]

    if installable:
        console.print(f"\nSuggested: [cyan]iriai integrate {' '.join(installable)}[/cyan]")
    if repairable:
        console.print(
            f"Repair: [yellow]iriai integrate {' '.join(repairable)} --action repair[/yellow]"
        )


@main.command()
@click.argument("module_names", nargs=-1, required=True)
@click.option(
    "--action",
    type=click.Choice(["install", "repair", "overwrite"]),
    default="install",
    help="Action to perform",
)
@click.option(
    "--depth",
    type=click.Choice(["core", "full"]),
    default="full",
    help="Integration depth",
)
@click.option("--yes", is_flag=True, help="Skip interactive prompts")
@click.option("--dry-run", is_flag=True, help="Show changes without applying")
@click.option("--local", is_flag=True, help="Run locally via Claude Code instead of engine API")
def integrate(module_names, action, depth, yes, dry_run, local):
    """Integrate modules into the current project."""
    if local:
        _integrate_local(module_names, action, depth, yes, dry_run)
    else:
        _integrate_remote(module_names, action, depth, yes, dry_run)


def _integrate_local(module_names, action, depth, yes, dry_run):
    """Run integration locally via Claude Code subprocess."""
    from pathlib import Path

    from .file_writer import FileWriter
    from .local_analyzer import analyze_local
    from .local_llm import run_local_integration
    from .module_loader import load_module

    console.print(f"Integrating [cyan]{', '.join(module_names)}[/cyan] [dim](local mode)[/dim]...")
    console.print(f"   Action: {action}, Depth: {depth}")

    if dry_run:
        console.print("   [yellow](Dry run mode — no files will be written)[/yellow]")
    if yes:
        console.print("   [yellow](Auto-apply mode — all changes will be applied)[/yellow]")

    project_dir = Path.cwd()

    # Load module definitions from local YAML files
    module_defs = {}
    for name in module_names:
        mod = load_module(name)
        if not mod:
            console.print(f"[red]Module not found:[/red] {name}")
            console.print("Check IRIAI_MODULES_DIR or run 'iriai modules list' for available modules.")
            return
        module_defs[name] = mod

    # Analyze local project
    console.print("\nAnalyzing project...")
    repo_summary, existing_integrations, relevant_files = analyze_local(
        project_dir, module_defs=list(module_defs.values())
    )

    console.print(
        f"   Framework: [cyan]{repo_summary.get('framework', 'unknown')}[/cyan], "
        f"Language: [cyan]{repo_summary.get('language', 'unknown')}[/cyan]"
    )

    # Run LLM integration for each module via Claude Code
    writer = FileWriter(project_dir, auto_yes=yes, dry_run=dry_run)
    total_cost = 0.0
    total_duration = 0

    for name in module_names:
        module_def = module_defs[name]
        existing = existing_integrations.get(name, {})

        console.print(f"\n[bold cyan]Module: {name}[/bold cyan]")
        console.print("   Invoking Claude Code...")

        try:
            result = run_local_integration(
                module_def=module_def,
                repo_summary=repo_summary,
                relevant_files=relevant_files,
                action=action,
                integration_depth=depth,
                existing_info=existing,
            )
        except RuntimeError as e:
            console.print(f"[red]Error:[/red] {e}")
            return

        # Track costs
        meta = result.get("_meta", {})
        total_cost += meta.get("cost_usd", 0.0)
        total_duration += meta.get("duration_ms", 0)

        # Show confidence
        score = result.get("confidence_score", 0)
        if score >= 0.85:
            tier_display = "[green]high[/green]"
        elif score >= 0.6:
            tier_display = "[yellow]medium[/yellow]"
        else:
            tier_display = "[red]low[/red]"
        console.print(f"   Confidence: {tier_display} ({score:.2f})")

        # Show concerns
        concerns = result.get("concerns", [])
        if concerns:
            for concern in concerns:
                console.print(f"   [yellow]Concern:[/yellow] {concern}")

        # Apply file operations
        changes = result.get("changes", [])
        if not changes:
            console.print("   [dim]No file changes[/dim]")
            continue

        applied_count = 0
        for change in changes:
            op = {
                "path": change["path"],
                "action": change["action"],
                "content": change.get("new_content"),
                "original_content": change.get("original_content"),
            }
            if writer.apply_operation(op):
                applied_count += 1

        console.print(f"\n   Applied {applied_count}/{len(changes)} changes")

        # Show package instructions
        pkg_instructions = result.get("package_instructions", [])
        if pkg_instructions:
            console.print("\n   [bold]Run these commands:[/bold]")
            for cmd in pkg_instructions:
                console.print(f"   $ {cmd}")

    console.print(f"\n[green]Done![/green]")

    if dry_run:
        console.print("\nRun without --dry-run to apply changes.")

    if total_cost:
        console.print(f"\nCost: ${total_cost:.4f}")
    if total_duration:
        console.print(f"Duration: {total_duration / 1000:.1f}s")


def _integrate_remote(module_names, action, depth, yes, dry_run):
    """Run integration via the engine API (default mode)."""
    import asyncio
    from pathlib import Path

    from .api_client import APIClient, APIError
    from .file_writer import FileWriter
    from .tarball_builder import create_project_tarball

    console.print(f"Integrating [cyan]{', '.join(module_names)}[/cyan]...")
    console.print(f"   Action: {action}, Depth: {depth}")

    if dry_run:
        console.print("   [yellow](Dry run mode — no files will be written)[/yellow]")
    if yes:
        console.print("   [yellow](Auto-apply mode — all changes will be applied)[/yellow]")

    # Step 1: Create tarball
    project_dir = Path.cwd()
    console.print(f"\nCreating tarball from {project_dir}...")

    try:
        tarball_path = create_project_tarball(project_dir)
    except Exception as e:
        console.print(f"[red]Error creating tarball:[/red] {e}")
        return

    # Step 2: Call integration endpoint
    console.print("Uploading to integration engine...")

    client = APIClient()
    modules_dict = {name: action for name in module_names}

    try:
        result = asyncio.run(
            client.integrate_local(
                tarball_path=str(tarball_path),
                modules=modules_dict,
                integration_depth=depth,
            )
        )
    except APIError as e:
        console.print(f"[red]Integration failed:[/red] {e}")
        tarball_path.unlink(missing_ok=True)
        return
    finally:
        # Cleanup tarball
        tarball_path.unlink(missing_ok=True)

    # Step 3: Apply file operations
    console.print(f"\nIntegration complete! Applying changes...\n")

    writer = FileWriter(project_dir, auto_yes=yes, dry_run=dry_run)

    for module_result in result.get("module_results", []):
        console.print(f"\n[bold cyan]Module: {module_result['module']}[/bold cyan]")

        file_ops = module_result.get("file_operations", [])
        if not file_ops:
            console.print("  [dim]No file changes[/dim]")
            continue

        applied_count = 0
        for op in file_ops:
            if writer.apply_operation(op):
                applied_count += 1

        console.print(f"\n  Applied {applied_count}/{len(file_ops)} changes")

    console.print(f"\n[green]Done![/green]")

    if dry_run:
        console.print("\nRun without --dry-run to apply changes.")

    # Show summary
    cost = result.get("cost_usd", 0.0)
    duration = result.get("duration_ms", 0)
    if cost:
        console.print(f"\nCost: ${cost:.4f}")
    if duration:
        console.print(f"Duration: {duration / 1000:.1f}s")


@main.command()
def login():
    """Authenticate with the Iriai platform via browser."""
    from .auth import login as do_login
    do_login()


@main.command()
def logout():
    """Remove stored credentials."""
    from .auth import logout as do_logout
    do_logout()


@main.command("fix-deploy")
@click.option("--app-id", required=True, help="Application ID")
@click.option("--service", default=None, help="Service name (omit to analyze all services)")
@click.option("--issue", default=None, help="Describe a runtime issue (e.g. 'frontend can\\'t reach backend')")
@click.option("--fix-request", default=None, type=int, help="Fix request ID from web console")
@click.option("--auto-approve", is_flag=True, help="Auto-approve if fix env builds successfully")
def fix_deploy(app_id, service, issue, fix_request, auto_approve):
    """Diagnose and fix a failed deployment or runtime issue."""
    from .fix_deploy import run_fix_deploy
    run_fix_deploy(app_id, service, auto_approve, issue=issue, fix_request_id=fix_request)


if __name__ == "__main__":
    main()
