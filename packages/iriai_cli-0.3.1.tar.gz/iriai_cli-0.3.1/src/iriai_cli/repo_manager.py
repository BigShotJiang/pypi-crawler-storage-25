"""Clone mirror repos to a temp workspace for Claude Code exploration."""

import asyncio
import logging
import shutil
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)


class RepoManager:
    """Clones mirror repos to a temp workspace for Claude Code exploration."""

    def __init__(self):
        self.workspace: Path | None = None

    async def clone_services(self, clone_urls: list[dict]) -> Path:
        """Clone each service's mirror repo into a shared workspace dir.

        Args:
            clone_urls: List of dicts with service_name, clone_url, branch.

        Returns:
            Path to workspace root containing service subdirectories.

        Structure:
            /tmp/iriai-fix-XXXXX/
                api/          <- cloned from mirror
                frontend/     <- cloned from mirror
        """
        self.workspace = Path(tempfile.mkdtemp(prefix="iriai-fix-"))
        logger.info(f"Created workspace: {self.workspace}")

        for entry in clone_urls:
            service_name = entry["service_name"]
            clone_url = entry["clone_url"]
            branch = entry.get("branch", "main")
            target_dir = self.workspace / service_name

            logger.info(f"Cloning {service_name} (branch: {branch})...")

            proc = await asyncio.create_subprocess_exec(
                "git", "clone", "--depth", "1", "--branch", branch,
                clone_url, str(target_dir),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            if proc.returncode != 0:
                # Log but don't fail — some services may not have mirrors
                err_msg = stderr.decode().strip()
                # Redact tokens from error messages
                if "x-access-token:" in err_msg:
                    err_msg = err_msg.split("@")[-1] if "@" in err_msg else "***"
                logger.warning(f"Failed to clone {service_name}: {err_msg}")
            else:
                logger.info(f"Cloned {service_name} to {target_dir}")

        return self.workspace

    def cleanup(self):
        """Remove the temp workspace."""
        if self.workspace and self.workspace.exists():
            shutil.rmtree(self.workspace, ignore_errors=True)
            logger.info(f"Cleaned up workspace: {self.workspace}")
            self.workspace = None
