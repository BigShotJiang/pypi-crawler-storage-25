"""Load module definitions from the integration engine API or local YAML files.

By default, fetches module definitions from the integration engine API.
Set IRIAI_MODULES_DIR to load from local YAML files instead (for development).
"""

import asyncio
import logging
import os
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)


def _get_local_modules_dir() -> Path | None:
    """Return local modules directory if IRIAI_MODULES_DIR is set, else None."""
    env_path = os.getenv("IRIAI_MODULES_DIR")
    if env_path:
        return Path(env_path)
    return None


def _load_module_from_disk(name: str, modules_dir: Path) -> dict | None:
    """Load a single module definition from a local YAML file."""
    yaml_path = modules_dir / f"{name}.yaml"
    if not yaml_path.exists():
        logger.warning(f"Module YAML not found: {yaml_path}")
        return None

    try:
        with open(yaml_path) as f:
            data = yaml.safe_load(f)
        if isinstance(data, dict) and "module" in data:
            return data["module"]
        return data
    except Exception as e:
        logger.error(f"Failed to load module {name}: {e}")
        return None


def _load_all_modules_from_disk(modules_dir: Path) -> list[dict]:
    """Load all module definitions from a local directory."""
    if not modules_dir.exists():
        logger.warning(f"Modules directory not found: {modules_dir}")
        return []

    modules = []
    for yaml_path in sorted(modules_dir.glob("*.yaml")):
        try:
            with open(yaml_path) as f:
                data = yaml.safe_load(f)
            if isinstance(data, dict) and "module" in data:
                modules.append(data["module"])
            elif isinstance(data, dict):
                modules.append(data)
        except Exception as e:
            logger.warning(f"Failed to load {yaml_path.name}: {e}")
    return modules


def load_module(name: str) -> dict | None:
    """Load a single module definition by name.

    Uses IRIAI_MODULES_DIR if set, otherwise fetches from the integration engine API.

    Args:
        name: Module name (e.g., "auth-react").

    Returns:
        Module definition dict, or None if not found.
    """
    local_dir = _get_local_modules_dir()
    if local_dir:
        return _load_module_from_disk(name, local_dir)

    from .api_client import APIClient, APIError

    client = APIClient()
    try:
        return asyncio.run(client.get_module_definition(name))
    except APIError as e:
        if e.status_code == 404:
            return None
        logger.error(f"Failed to fetch module '{name}' from API: {e}")
        return None


def load_all_modules() -> list[dict]:
    """Load all module definitions.

    Uses IRIAI_MODULES_DIR if set, otherwise fetches from the integration engine API.

    Returns:
        List of module definition dicts.
    """
    local_dir = _get_local_modules_dir()
    if local_dir:
        return _load_all_modules_from_disk(local_dir)

    from .api_client import APIClient, APIError

    client = APIClient()
    try:
        modules_metadata = asyncio.run(client.get_modules())
    except APIError as e:
        logger.error(f"Failed to fetch modules from API: {e}")
        return []

    modules = []
    for meta in modules_metadata:
        name = meta.get("name")
        if not name:
            continue
        try:
            full_def = asyncio.run(client.get_module_definition(name))
            if full_def:
                modules.append(full_def)
        except APIError as e:
            logger.warning(f"Failed to fetch module '{name}': {e}")
    return modules
