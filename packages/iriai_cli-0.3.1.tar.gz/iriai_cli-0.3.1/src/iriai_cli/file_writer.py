"""Interactive file writer for applying integration results."""

import logging
from pathlib import Path

import click
from rich.console import Console
from rich.syntax import Syntax

console = Console()
logger = logging.getLogger(__name__)


def _detect_lexer(path: Path) -> str:
    """Detect the syntax lexer from file extension."""
    ext_map = {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "tsx",
        ".js": "javascript",
        ".jsx": "jsx",
        ".json": "json",
        ".toml": "toml",
        ".yaml": "yaml",
        ".yml": "yaml",
        ".html": "html",
        ".css": "css",
        ".md": "markdown",
    }
    return ext_map.get(path.suffix, "text")


class FileWriter:
    """Handles writing files to disk with user prompts."""

    def __init__(self, base_dir: Path, auto_yes: bool = False, dry_run: bool = False):
        self.base_dir = base_dir
        self.auto_yes = auto_yes
        self.dry_run = dry_run
        self.overwrite_all = False

    def apply_operation(self, operation: dict) -> bool:
        """Apply a single file operation.

        Args:
            operation: Dict with "path", "action", "content", "original_content".

        Returns:
            True if operation was applied, False if skipped.
        """
        path = self.base_dir / operation["path"]
        action = operation["action"]
        content = operation.get("content")

        if action == "create":
            return self._handle_create(path, content)
        elif action == "modify":
            return self._handle_modify(path, content, operation.get("original_content"))
        elif action == "delete":
            return self._handle_delete(path)
        else:
            console.print(f"[red]Unknown action: {action}[/red]")
            return False

    def _handle_create(self, path: Path, content: str) -> bool:
        """Handle file creation."""
        if path.exists() and not self.overwrite_all:
            console.print(f"\n[yellow]File exists:[/yellow] {path.relative_to(self.base_dir)}")
            choice = self._prompt_overwrite()
            if choice == "skip":
                return False
            elif choice == "overwrite_all":
                self.overwrite_all = True

        rel = path.relative_to(self.base_dir)
        console.print(f"[green]Creating:[/green] {rel}")

        if self.dry_run:
            console.print("  (Dry run — file not written)")
            return True

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return True

    def _handle_modify(self, path: Path, new_content: str, original_content: str | None) -> bool:
        """Handle file modification."""
        rel = path.relative_to(self.base_dir) if path.is_relative_to(self.base_dir) else path

        if not path.exists():
            console.print(f"[yellow]Warning:[/yellow] File does not exist: {rel}")
            console.print("Creating instead...")
            return self._handle_create(path, new_content)

        console.print(f"\n[blue]Modifying:[/blue] {rel}")

        if not self.auto_yes and not self.overwrite_all:
            choice = self._prompt_modify(path, new_content, original_content)
            if choice == "skip":
                return False
            elif choice == "overwrite_all":
                self.overwrite_all = True

        if self.dry_run:
            console.print("  (Dry run — file not written)")
            return True

        path.write_text(new_content, encoding="utf-8")
        console.print(f"[green]  Applied[/green]")
        return True

    def _handle_delete(self, path: Path) -> bool:
        """Handle file deletion."""
        rel = path.relative_to(self.base_dir) if path.is_relative_to(self.base_dir) else path

        if not path.exists():
            console.print(f"[dim]Skipping:[/dim] {rel} (already deleted)")
            return True

        console.print(f"\n[red]Deleting:[/red] {rel}")

        if not self.auto_yes and not self.overwrite_all:
            choice = click.confirm("Delete this file?", default=False)
            if not choice:
                return False

        if self.dry_run:
            console.print("  (Dry run — file not deleted)")
            return True

        path.unlink()
        console.print(f"[green]  Deleted[/green]")
        return True

    def _prompt_overwrite(self) -> str:
        """Prompt user for overwrite decision."""
        if self.auto_yes:
            return "apply"

        choice = click.prompt(
            "File exists. [A]pply, [S]kip, [O]verwrite all",
            type=click.Choice(["a", "s", "o"], case_sensitive=False),
            default="s",
        ).lower()

        if choice == "a":
            return "apply"
        elif choice == "o":
            return "overwrite_all"
        return "skip"

    def _prompt_modify(self, path: Path, new_content: str, original: str | None) -> str:
        """Prompt user for modify decision with diff display."""
        lexer = _detect_lexer(path)

        current = path.read_text(encoding="utf-8") if path.exists() else ""

        console.print("\n[bold]Current content:[/bold]")
        preview = current[:2000]
        console.print(Syntax(preview, lexer, line_numbers=True))
        if len(current) > 2000:
            console.print(f"[dim]... ({len(current) - 2000} more characters)[/dim]")

        console.print("\n[bold]New content:[/bold]")
        preview = new_content[:2000]
        console.print(Syntax(preview, lexer, line_numbers=True))
        if len(new_content) > 2000:
            console.print(f"[dim]... ({len(new_content) - 2000} more characters)[/dim]")

        choice = click.prompt(
            "\n[A]pply, [S]kip, [O]verwrite all",
            type=click.Choice(["a", "s", "o"], case_sensitive=False),
            default="s",
        ).lower()

        if choice == "a":
            return "apply"
        elif choice == "o":
            return "overwrite_all"
        return "skip"
