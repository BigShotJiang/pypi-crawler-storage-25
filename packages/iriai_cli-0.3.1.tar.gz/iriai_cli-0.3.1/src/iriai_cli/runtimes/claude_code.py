"""Lightweight AgentRuntime wrapping the Claude Agent SDK.

Follows the same pattern as iriai-build-v2's ClaudeAgentRuntime but stripped
down for CLI use: ephemeral mode only, no session cycling, no interactive mode.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel

from iriai_compose.runner import AgentRuntime

if TYPE_CHECKING:
    from iriai_compose.actors import Role
    from iriai_compose.workflow import Workspace

logger = logging.getLogger(__name__)


def _inline_defs(schema: dict[str, Any]) -> dict[str, Any]:
    """Resolve ``$ref`` references by inlining ``$defs``.

    Pydantic generates JSON schemas with ``$defs`` + ``$ref`` for nested
    models.  The Claude API's constrained decoding does not support
    ``$ref``, so we inline all definitions to make the full structure
    visible at every nesting level.
    """
    defs = schema.pop("$defs", None)
    if not defs:
        return schema

    def _resolve(obj: Any) -> Any:
        if isinstance(obj, dict):
            ref = obj.get("$ref")
            if ref and isinstance(ref, str):
                name = ref.rsplit("/", 1)[-1]
                if name in defs:
                    return _resolve(defs[name])
                return obj
            return {k: _resolve(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [_resolve(item) for item in obj]
        return obj

    return _resolve(schema)


class ClaudeCodeRuntime(AgentRuntime):
    """Agent runtime using the Claude Agent SDK for structured output.

    Each ``invoke()`` call creates a fresh ``ClaudeSDKClient`` (ephemeral mode).
    Structured output is enforced via the SDK's ``output_format`` option when
    ``output_type`` is provided.
    """

    name = "claude-code"

    def __init__(
        self,
        on_message: Callable[[Any], None] | None = None,
    ) -> None:
        try:
            import claude_agent_sdk  # noqa: F401
        except ImportError:
            raise ImportError(
                "ClaudeCodeRuntime requires the 'claude-agent-sdk' package. "
                "Install it with: pip install claude-agent-sdk"
            )
        self.on_message = on_message

    async def invoke(
        self,
        role: Role,
        prompt: str,
        *,
        output_type: type[BaseModel] | None = None,
        workspace: Workspace | None = None,
        session_key: str | None = None,
    ) -> str | BaseModel:
        from claude_agent_sdk import ClaudeAgentOptions, ClaudeSDKClient
        from claude_agent_sdk.types import ResultMessage

        options = self._build_options(role, workspace, output_type)

        async with ClaudeSDKClient(options=options) as client:
            await client.query(prompt)
            result_msg = None
            async for msg in client.receive_response():
                if self.on_message is not None:
                    self.on_message(msg)
                if isinstance(msg, ResultMessage):
                    result_msg = msg

        if result_msg is None:
            raise RuntimeError("Claude query completed without a result message")

        if not output_type:
            return result_msg.result or ""

        # SDK guarantees structured output when output_format is set
        if result_msg.subtype == "error_max_structured_output_retries":
            raise RuntimeError(
                f"Claude could not produce valid {output_type.__name__} "
                f"after multiple attempts. Last result: {result_msg.result}"
            )

        if result_msg.structured_output is None:
            raise RuntimeError(
                f"Structured output is None for {output_type.__name__}. "
                f"Result text: {repr(result_msg.result)[:500] if result_msg.result else 'empty'}"
            )

        return output_type.model_validate(result_msg.structured_output)

    def _build_options(
        self,
        role: Role,
        workspace: Workspace | None,
        output_type: type[BaseModel] | None = None,
    ) -> Any:
        """Construct ClaudeAgentOptions from a role."""
        from claude_agent_sdk import ClaudeAgentOptions

        options = ClaudeAgentOptions(
            system_prompt=role.prompt,
            allowed_tools=role.tools,
            model=role.model or "claude-opus-4-6",
            cwd=str(workspace.path) if workspace else None,
            permission_mode="bypassPermissions",
            effort=role.effort if role.effort is not None else "high",
        )

        if output_type:
            options.output_format = {
                "type": "json_schema",
                "schema": _inline_defs(output_type.model_json_schema()),
            }

        return options
