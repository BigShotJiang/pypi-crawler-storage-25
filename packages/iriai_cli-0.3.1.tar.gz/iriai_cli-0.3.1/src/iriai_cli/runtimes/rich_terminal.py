"""InteractionRuntime using Rich console for terminal interaction.

Provides Gate approval, Choose selection, and Respond input using the Rich
library that the CLI already depends on — avoids adding questionary.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

from rich.console import Console
from rich.panel import Panel

from iriai_compose.runner import InteractionRuntime

if TYPE_CHECKING:
    from iriai_compose.pending import Pending


class RichInteractionRuntime(InteractionRuntime):
    """Terminal interaction runtime using Rich for display."""

    name = "terminal"

    def __init__(self, console: Console | None = None) -> None:
        self.console = console or Console()

    async def resolve(self, pending: Pending) -> str | bool:
        if pending.kind == "approve":
            return await self._approve(pending)
        elif pending.kind == "choose":
            return await self._choose(pending)
        else:  # respond
            return await self._respond(pending)

    async def _approve(self, pending: Pending) -> bool | str:
        self.console.print()
        self.console.print(Panel(pending.prompt, title="Review", border_style="cyan"))
        response = await asyncio.to_thread(
            self.console.input,
            "[bold]Approve? [y/n/feedback]:[/bold] ",
        )
        response = response.strip().lower()
        if response in ("y", "yes", "approve"):
            return True
        if response in ("n", "no", "reject"):
            return False
        return response  # feedback string

    async def _choose(self, pending: Pending) -> str:
        self.console.print()
        self.console.print(pending.prompt)
        options = pending.options or []
        for i, opt in enumerate(options, 1):
            self.console.print(f"  {i}. {opt}")
        while True:
            response = await asyncio.to_thread(
                self.console.input,
                "[bold]Select (number):[/bold] ",
            )
            try:
                idx = int(response.strip()) - 1
                if 0 <= idx < len(options):
                    return options[idx]
            except ValueError:
                pass
            self.console.print("[red]Invalid selection, try again.[/red]")

    async def _respond(self, pending: Pending) -> str:
        self.console.print()
        self.console.print(pending.prompt)
        return await asyncio.to_thread(
            self.console.input,
            "[bold]> [/bold]",
        )
