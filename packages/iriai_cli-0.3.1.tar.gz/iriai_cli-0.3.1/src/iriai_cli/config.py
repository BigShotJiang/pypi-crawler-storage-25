"""CLI configuration from environment variables."""

import os


class Config:
    """CLI configuration."""

    def __init__(self):
        self.engine_url = os.getenv(
            "IRIAI_ENGINE_URL",
            "https://integration.iriai.app",
        ).rstrip("/")

        self.api_token = os.getenv("IRIAI_API_TOKEN")

        self.deploy_console_url = os.getenv(
            "IRIAI_DEPLOY_URL",
            "https://api.useiriai.com",
        ).rstrip("/")

        self.auth_service_url = os.getenv(
            "IRIAI_AUTH_URL",
            "https://auth.iriai.app",
        ).rstrip("/")

        self.oauth_client_id = os.getenv("IRIAI_OAUTH_CLIENT_ID", "dev-console")

    @property
    def headers(self) -> dict[str, str]:
        """HTTP headers for engine requests."""
        headers = {"Content-Type": "application/json"}
        if self.api_token:
            headers["Authorization"] = f"Bearer {self.api_token}"
        return headers


config = Config()
