"""HTTP client for deploy-console API (fix-deploy endpoints)."""

import logging
from typing import Any

import httpx

from .auth import AuthError, get_token
from .api_client import APIError
from .config import config

logger = logging.getLogger(__name__)


class DeployClient:
    """Async HTTP client for the deploy-console service."""

    def __init__(self, base_url: str | None = None, timeout: int = 30):
        self.base_url = base_url or config.deploy_console_url
        self.timeout = timeout

    def _headers(self) -> dict[str, str]:
        """Build request headers with auth token."""
        token = get_token()
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

    async def get_fix_context(
        self,
        app_id: str,
        service_name: str | None = None,
        issue: str | None = None,
        fix_request_id: int | None = None,
    ) -> dict[str, Any]:
        """Fetch fix-deploy context (build logs, runtime logs, config, IDs).

        GET /deployments/fix-deploy/context?app_id=...
        When service_name is None, returns context for all services.
        """
        params: dict[str, Any] = {"app_id": app_id}
        if service_name:
            params["service_name"] = service_name
        if issue:
            params["issue"] = issue
        if fix_request_id is not None:
            params["fix_request_id"] = fix_request_id

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/deployments/fix-deploy/context",
                    params=params,
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 401:
                    raise AuthError("Session expired. Run 'iriai login' again.")
                raise APIError(
                    f"Failed to fetch fix context: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def get_clone_urls(self, app_id: str) -> dict[str, Any]:
        """Fetch authenticated clone URLs for mirror repos.

        GET /deployments/fix-deploy/clone-urls?app_id=...
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/deployments/fix-deploy/clone-urls",
                    params={"app_id": app_id},
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 401:
                    raise AuthError("Session expired. Run 'iriai login' again.")
                raise APIError(
                    f"Failed to fetch clone URLs: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def apply_fix(self, payload: dict) -> dict[str, Any]:
        """Submit fix changes and create fix environment.

        POST /deployments/fix-deploy/apply
        """
        async with httpx.AsyncClient(timeout=120) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/deployments/fix-deploy/apply",
                    json=payload,
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                detail = ""
                try:
                    detail = e.response.json().get("detail", "")
                except Exception:
                    pass
                raise APIError(
                    f"Fix apply failed: {detail or e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def get_fix_status(self, fix_environment_id: int) -> dict[str, Any]:
        """Poll fix environment deployment status.

        GET /deployments/fix-deploy/{id}/status
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/deployments/fix-deploy/{fix_environment_id}/status",
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Failed to get fix status: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def approve_fix(self, fix_environment_id: int) -> dict[str, Any]:
        """Approve a successful fix environment.

        POST /deployments/fix-deploy/{id}/approve
        """
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/deployments/fix-deploy/{fix_environment_id}/approve",
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Fix approve failed: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def reject_fix(self, fix_environment_id: int) -> dict[str, Any]:
        """Reject a fix environment.

        POST /deployments/fix-deploy/{id}/reject
        """
        async with httpx.AsyncClient(timeout=60) as client:
            try:
                response = await client.post(
                    f"{self.base_url}/deployments/fix-deploy/{fix_environment_id}/reject",
                    headers=self._headers(),
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Fix reject failed: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")
