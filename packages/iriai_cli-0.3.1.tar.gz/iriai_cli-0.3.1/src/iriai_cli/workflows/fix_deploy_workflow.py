"""Fix-deploy workflow: multi-phase diagnosis and fix generation.

Phases:
  1. DiagnosePhase — Agent explores repos, analyzes logs, produces structured diagnosis
  2. ReviewPhase  — Human reviews and approves the diagnosis (Gate)
  3. FixPhase     — Agent generates minimal code/config changes based on diagnosis
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from iriai_compose.actors import AgentActor, InteractionActor, Role
from iriai_compose.runner import WorkflowRunner
from iriai_compose.tasks import Ask, Gate
from iriai_compose.workflow import Feature, Phase, Workflow

from ..fix_deploy_llm import (
    DIAGNOSIS_SYSTEM_PROMPT,
    FIX_SYSTEM_PROMPT,
    build_diagnosis_prompt,
    build_fix_prompt,
)


# ── Pydantic output models ──────────────────────────────────────────────


class DiagnosisResult(BaseModel):
    """Structured output from the diagnosis phase."""

    hypothesis: str  # "The issue occurs because [X]"
    root_cause_details: str  # Detailed explanation with evidence from logs/code
    affected_services: list[str] = Field(default_factory=list)
    confidence_score: float  # 0.0 to 1.0
    concerns: list[str] = Field(default_factory=list)


class FixFileChange(BaseModel):
    """A single file change in the fix."""

    path: str  # e.g. "frontend/nginx.conf"
    action: str  # create | modify | delete
    original_content: str | None = None
    new_content: str | None = None


class FixConfigChanges(BaseModel):
    """Railway service configuration changes."""

    build_command: str | None = None
    start_command: str | None = None
    root_directory: str | None = None
    dockerfile_path: str | None = None
    env_vars: dict[str, str] = Field(default_factory=dict)


class FixDeployResult(BaseModel):
    """Structured output from the fix generation phase."""

    fix_type: str  # code_change | env_var | build_config | documentation
    changes: list[FixFileChange] = Field(default_factory=list)
    config_changes: FixConfigChanges | None = None
    package_instructions: list[str] = Field(default_factory=list)
    confidence_score: float
    explanation: str  # Human-readable explanation of what the fix does


class FixDeployState(BaseModel):
    """Workflow state threaded through phases."""

    context: dict
    workspace_path: str | None = None
    diagnosis: DiagnosisResult | None = None
    fix: FixDeployResult | None = None


# ── Roles & Actors ──────────────────────────────────────────────────────


debugger_role = Role(
    name="deployment_debugger",
    prompt=DIAGNOSIS_SYSTEM_PROMPT,
    tools=["Read", "Glob", "Grep", "Bash(ls:*,find:*)", "WebFetch"],
    model="claude-opus-4-6",
    effort="high",
)

fixer_role = Role(
    name="deployment_fixer",
    prompt=FIX_SYSTEM_PROMPT,
    tools=["Read", "Glob", "Grep"],
    model="claude-opus-4-6",
    effort="high",
)

debugger = AgentActor(name="debugger", role=debugger_role, persistent=False)
fixer = AgentActor(name="fixer", role=fixer_role, persistent=False)
developer = InteractionActor(name="developer", resolver="terminal")


# ── Phases ───────────────────────────────────────────────────────────────


class DiagnosePhase(Phase):
    """Explore repos and produce a structured diagnosis."""

    name = "diagnose"

    async def execute(
        self, runner: WorkflowRunner, feature: Feature, state: FixDeployState
    ) -> FixDeployState:
        prompt = build_diagnosis_prompt(state.context)
        result = await runner.run(
            Ask(actor=debugger, prompt=prompt, output_type=DiagnosisResult),
            feature,
        )
        state.diagnosis = result
        # Store diagnosis as artifact so FixPhase can access it via context_keys
        await runner.artifacts.put(
            "diagnosis", result.model_dump_json(indent=2), feature=feature
        )
        return state


class ReviewPhase(Phase):
    """Human reviews the diagnosis before fix generation."""

    name = "review"

    async def execute(
        self, runner: WorkflowRunner, feature: Feature, state: FixDeployState
    ) -> FixDeployState:
        diagnosis = state.diagnosis
        prompt = _format_diagnosis_for_review(diagnosis)
        result = await runner.run(
            Gate(approver=developer, prompt=prompt),
            feature,
        )
        if result is False:
            raise DiagnosisRejected("Diagnosis rejected by user")
        if isinstance(result, str) and result:
            # User provided feedback — append as concern
            state.diagnosis.concerns.append(f"User feedback: {result}")
        return state


class FixPhase(Phase):
    """Generate minimal code/config changes based on the diagnosis."""

    name = "fix"

    async def execute(
        self, runner: WorkflowRunner, feature: Feature, state: FixDeployState
    ) -> FixDeployState:
        diagnosis_text = state.diagnosis.model_dump_json(indent=2)
        prompt = build_fix_prompt(state.context, diagnosis_text)
        result = await runner.run(
            Ask(
                actor=fixer,
                prompt=prompt,
                output_type=FixDeployResult,
                context_keys=["diagnosis"],
            ),
            feature,
        )
        state.fix = result
        return state


# ── Workflow ─────────────────────────────────────────────────────────────


class FixDeployWorkflow(Workflow):
    """Three-phase fix-deploy workflow: Diagnose → Review → Fix."""

    name = "fix-deploy"

    def build_phases(self) -> list[type[Phase]]:
        return [DiagnosePhase, ReviewPhase, FixPhase]


# ── Exceptions ───────────────────────────────────────────────────────────


class DiagnosisRejected(RuntimeError):
    """Raised when the user rejects the diagnosis during review."""


# ── Helpers ──────────────────────────────────────────────────────────────


def _format_diagnosis_for_review(diagnosis: DiagnosisResult) -> str:
    """Format the diagnosis for human review in the Gate prompt."""
    parts = [
        f"Hypothesis: {diagnosis.hypothesis}",
        f"\nRoot cause: {diagnosis.root_cause_details}",
    ]
    if diagnosis.affected_services:
        parts.append(f"\nAffected services: {', '.join(diagnosis.affected_services)}")
    parts.append(f"\nConfidence: {diagnosis.confidence_score:.0%}")
    if diagnosis.concerns:
        parts.append("\nConcerns:")
        for concern in diagnosis.concerns:
            parts.append(f"  - {concern}")
    return "\n".join(parts)
