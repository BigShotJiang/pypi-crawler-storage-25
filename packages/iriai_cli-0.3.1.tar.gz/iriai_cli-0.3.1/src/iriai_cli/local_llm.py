"""Local LLM integration via Claude Code subprocess.

Builds the same prompt as the engine's LLMIntegrator._build_prompt(),
then invokes `claude -p` to get structured output. This is a drop-in
replacement for the engine API call when using --local mode.
"""

import json
import logging
import shutil
import subprocess

logger = logging.getLogger(__name__)


# JSON schema appended to prompt so Claude returns structured output
OUTPUT_SCHEMA = """\

## Output Format

You MUST respond with ONLY a valid JSON object (no markdown fences, no explanation) matching this exact schema:

```
{
  "changes": [
    {
      "path": "relative/file/path",
      "action": "create" | "modify" | "delete",
      "original_content": "original content for modify actions or null",
      "new_content": "new content for create/modify or null"
    }
  ],
  "package_instructions": ["npm install ...", ...],
  "env_vars": [{"name": "VAR", "value": "default", "scope": "app"}],
  "confidence_score": 0.0 to 1.0,
  "concerns": ["any concerns or uncertainties"]
}
```

IMPORTANT: Output ONLY the JSON object. No markdown code fences. No explanation before or after."""


def build_prompt(
    module_def: dict,
    repo_summary: dict,
    relevant_files: dict[str, str],
    action: str,
    integration_depth: str = "full",
    existing_issues: list[str] | None = None,
    misconfigurations: list[dict] | None = None,
) -> str:
    """Build the LLM prompt — mirrors LLMIntegrator._build_prompt().

    Args:
        module_def: Module definition dict (from YAML).
        repo_summary: Repo analysis dict.
        relevant_files: Path → content mapping.
        action: install, repair, or overwrite.
        integration_depth: core or full.
        existing_issues: Known issues to address.
        misconfigurations: Detected misconfiguration rules.

    Returns:
        Complete prompt string.
    """
    name = module_def.get("name", "unknown")
    display_name = module_def.get("display_name", name)
    version = module_def.get("version", "0.0.0")
    description = module_def.get("description", "")
    distribution = module_def.get("distribution")
    prompt_template = module_def.get("prompt_template", "")

    conventions = repo_summary.get("code_conventions", {})

    parts = [
        f"## Integration Task\n\n"
        f"Action: {action} the '{display_name}' module.\n"
        f"Module: {name} v{version}\n"
        f"Description: {description}\n",

        f"\n## Repo Summary\n\n"
        f"Framework: {repo_summary.get('framework')} {repo_summary.get('framework_version') or ''}\n"
        f"Bundler: {repo_summary.get('bundler') or 'none'}\n"
        f"Language: {repo_summary.get('language') or 'unknown'}\n"
        f"Package Manager: {repo_summary.get('package_manager') or 'unknown'}\n"
        f"Entry Points: {', '.join(repo_summary.get('entry_points', []))}\n"
        f"Code Conventions:\n"
        f"  Indent: {conventions.get('indent', 'spaces:2')}\n"
        f"  Quotes: {conventions.get('quotes', 'single')}\n"
        f"  Semicolons: {conventions.get('semicolons', False)}\n",
    ]

    # Integration depth
    if integration_depth == "full" and name == "pwa":
        parts.append(
            f"\n## Integration Depth: FULL\n\n"
            f"Generate ALL files: MF-ification files AND the dedicated PWA wrapper.\n\n"
            f"**Path convention for PWA wrapper files:**\n"
            f"Prefix all PWA wrapper file paths with `__pwa_wrapper__/`. "
            f"For example: `__pwa_wrapper__/src/App.tsx`, `__pwa_wrapper__/package.json`.\n"
            f"MF-ification files (mf-entry.tsx, vite.mf.config.ts, etc.) use normal paths "
            f"relative to the project root.\n"
        )
    else:
        parts.append(
            f"\n## Integration Depth: {integration_depth.upper()}\n\n"
            f"Generate {'all files and modifications' if integration_depth == 'full' else 'only the minimum setup (marked as CORE in the guide)'}.\n"
        )

    # Distribution info
    if distribution:
        dist_type = distribution.get("type", "")
        parts.append(f"\n## Package Distribution\n\n")
        if dist_type == "tarball":
            parts.append(
                f"The package tarball has been pre-copied to `{distribution.get('target_path')}` in the project.\n"
                f"Package name: `{distribution.get('package_name')}`\n"
                f"Add to package.json dependencies: `{distribution.get('package_json_entry')}`\n"
                f"Do NOT generate npm install commands — the tarball is already in place.\n"
            )
        elif dist_type == "git":
            parts.append(
                f"Add to requirements.txt: `{distribution.get('requirements_entry')}`\n"
                f"Package name: `{distribution.get('package_name')}`\n"
            )

    # Module integration guide (prompt template from YAML)
    parts.append(f"\n## Module Integration Guide\n\n{prompt_template}\n")

    # Misconfigurations
    if misconfigurations:
        misconfig_text = "\n".join(
            f"- [{m.get('rule_id', m.get('id', '?'))}] {m.get('message', '')} — Repair: {m.get('repair_hint', '')}"
            for m in misconfigurations
        )
        parts.append(
            f"\n## Detected Misconfigurations to Repair\n\n{misconfig_text}\n"
        )

    if existing_issues:
        issues_text = "\n".join(f"- {issue}" for issue in existing_issues)
        parts.append(
            f"\n## Existing Integration Issues\n\n"
            f"This module is already partially installed but has the following "
            f"misconfigurations that must be repaired:\n\n{issues_text}\n"
        )

    # Relevant source files
    if relevant_files:
        parts.append("\n## Relevant Source Files\n")
        for path, content in relevant_files.items():
            truncated = content[:3000] if len(content) > 3000 else content
            parts.append(f"\n### {path}\n```\n{truncated}\n```\n")

    # Output format instructions
    parts.append(OUTPUT_SCHEMA)

    return "\n".join(parts)


def invoke_claude(prompt: str, cwd: str | None = None) -> dict:
    """Invoke Claude Code as a subprocess and parse the response.

    Args:
        prompt: The full prompt to send.
        cwd: Optional working directory for Claude Code (e.g. cloned repo workspace).

    Returns:
        Parsed integration result dict with 'changes', 'confidence_score', etc.

    Raises:
        RuntimeError: If claude is not found or returns an error.
    """
    if not shutil.which("claude"):
        raise RuntimeError(
            "Claude Code CLI not found. Install it or use the engine API instead.\n"
            "See: https://docs.anthropic.com/en/docs/claude-code"
        )

    logger.info("Invoking Claude Code locally...")

    result = subprocess.run(
        ["claude", "-p", prompt, "--output-format", "json"],
        capture_output=True,
        text=True,
        timeout=600,  # 10 minute timeout
        cwd=cwd,
    )

    if result.returncode != 0:
        stderr = result.stderr.strip()
        raise RuntimeError(f"Claude Code failed (exit {result.returncode}): {stderr}")

    # Parse Claude Code JSON output
    try:
        claude_output = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Failed to parse Claude Code output as JSON: {e}\nOutput: {result.stdout[:500]}")

    # Claude Code --output-format json wraps the response
    response_text = claude_output.get("result", "")
    cost_usd = claude_output.get("cost_usd", 0.0)
    duration_ms = claude_output.get("duration_ms", 0)

    if claude_output.get("is_error"):
        raise RuntimeError(f"Claude Code returned an error: {response_text}")

    # Parse the structured JSON from Claude's response text
    integration_result = _parse_integration_result(response_text)
    integration_result["_meta"] = {
        "cost_usd": cost_usd,
        "duration_ms": duration_ms,
        "session_id": claude_output.get("session_id"),
    }

    return integration_result


def _parse_integration_result(text: str) -> dict:
    """Parse the integration result JSON from Claude's response text.

    Handles cases where Claude wraps the JSON in markdown fences.
    """
    text = text.strip()

    # Try direct JSON parse first
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Try extracting from markdown code fences
    if "```" in text:
        # Find the JSON block
        lines = text.split("\n")
        in_block = False
        json_lines = []
        for line in lines:
            if line.strip().startswith("```") and not in_block:
                in_block = True
                continue
            elif line.strip() == "```" and in_block:
                break
            elif in_block:
                json_lines.append(line)

        if json_lines:
            try:
                return json.loads("\n".join(json_lines))
            except json.JSONDecodeError:
                pass

    # Try finding JSON object boundaries
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1 and end > start:
        try:
            return json.loads(text[start:end + 1])
        except json.JSONDecodeError:
            pass

    raise RuntimeError(
        f"Could not parse integration result from Claude's response.\n"
        f"Expected JSON object. Got:\n{text[:500]}"
    )


def run_local_integration(
    module_def: dict,
    repo_summary: dict,
    relevant_files: dict[str, str],
    action: str,
    integration_depth: str = "full",
    existing_info: dict | None = None,
) -> dict:
    """Run a single module integration locally via Claude Code.

    Args:
        module_def: Module definition dict.
        repo_summary: Repo analysis dict.
        relevant_files: Path → content mapping.
        action: install, repair, or overwrite.
        integration_depth: core or full.
        existing_info: Existing integration status dict.

    Returns:
        Dict with 'changes', 'confidence_score', 'concerns', etc.
    """
    # Build misconfiguration context
    misconfigurations = None
    existing_issues = None
    if existing_info and existing_info.get("issues"):
        existing_issues = existing_info["issues"]
        # Build misconfig dicts from module's analyze rules
        analyze = module_def.get("analyze", {})
        misconfigurations = [
            rule for rule in analyze.get("misconfiguration_rules", [])
        ]

    prompt = build_prompt(
        module_def=module_def,
        repo_summary=repo_summary,
        relevant_files=relevant_files,
        action=action,
        integration_depth=integration_depth,
        existing_issues=existing_issues,
        misconfigurations=misconfigurations,
    )

    return invoke_claude(prompt)
