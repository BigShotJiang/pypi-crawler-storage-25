"""OAuth authentication for CLI via browser-based PKCE flow."""

import base64
import hashlib
import json
import logging
import os
import secrets
import threading
import time
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from .config import config

logger = logging.getLogger(__name__)

CREDENTIALS_PATH = Path.home() / ".iriai" / "credentials.json"
CALLBACK_PORTS = [19823, 19824]


class AuthError(Exception):
    """Authentication error."""
    pass


def _generate_pkce() -> tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge (S256)."""
    verifier = secrets.token_urlsafe(64)[:128]
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def save_credentials(data: dict) -> None:
    """Save credentials to disk with restricted permissions."""
    CREDENTIALS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CREDENTIALS_PATH.write_text(json.dumps(data, indent=2))
    os.chmod(CREDENTIALS_PATH, 0o600)


def load_credentials() -> dict | None:
    """Load credentials from disk."""
    if not CREDENTIALS_PATH.exists():
        return None
    try:
        return json.loads(CREDENTIALS_PATH.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _token_expired(creds: dict) -> bool:
    """Check if the access token is expired (with 60s buffer)."""
    expires_at = creds.get("expires_at", 0)
    return time.time() >= (expires_at - 60)


def _refresh_access_token(creds: dict) -> dict:
    """Refresh the access token using the refresh token."""
    refresh_token = creds.get("refresh_token")
    if not refresh_token:
        raise AuthError("No refresh token available. Run 'iriai login' again.")

    with httpx.Client(timeout=15) as client:
        resp = client.post(
            f"{config.auth_service_url}/oauth/token",
            data={
                "grant_type": "refresh_token",
                "client_id": config.oauth_client_id,
                "refresh_token": refresh_token,
            },
        )

    if resp.status_code != 200:
        raise AuthError(f"Token refresh failed ({resp.status_code}). Run 'iriai login' again.")

    token_data = resp.json()
    creds["access_token"] = token_data["access_token"]
    creds["expires_at"] = time.time() + token_data.get("expires_in", 3600)
    if "refresh_token" in token_data:
        creds["refresh_token"] = token_data["refresh_token"]

    save_credentials(creds)
    return creds


def get_token() -> str:
    """Get a valid access token, refreshing if needed.

    Returns:
        The access token string.

    Raises:
        AuthError: If not logged in or refresh fails.
    """
    creds = load_credentials()
    if not creds:
        raise AuthError("Not authenticated. Run 'iriai login' first.")

    if _token_expired(creds):
        try:
            creds = _refresh_access_token(creds)
        except AuthError:
            raise AuthError("Session expired. Run 'iriai login' again.")

    return creds["access_token"]


def login() -> None:
    """Run the browser-based OAuth PKCE login flow."""
    from rich.console import Console
    console = Console()

    verifier, challenge = _generate_pkce()
    state = secrets.token_urlsafe(32)

    # Find an available port
    server = None
    port = None
    for p in CALLBACK_PORTS:
        try:
            server = HTTPServer(("127.0.0.1", p), _CallbackHandler)
            port = p
            break
        except OSError:
            continue

    if not server or not port:
        console.print("[red]Error:[/red] Could not bind to callback ports (19823-19824).")
        return

    redirect_uri = f"http://127.0.0.1:{port}/callback"

    # Build authorization URL
    params = {
        "client_id": config.oauth_client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": "openid profile email",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    auth_url = f"{config.auth_service_url}/oauth/authorize?{urlencode(params)}"

    # Store state on the server for the callback handler
    server._auth_state = state  # type: ignore[attr-defined]
    server._auth_code = None  # type: ignore[attr-defined]
    server._auth_error = None  # type: ignore[attr-defined]

    console.print("Opening browser for authentication...")
    console.print(f"[dim]If browser doesn't open, visit:[/dim]\n{auth_url}\n")

    webbrowser.open(auth_url)

    # Wait for callback (timeout after 120s)
    server.timeout = 120
    server.handle_request()
    server.server_close()

    auth_code = server._auth_code  # type: ignore[attr-defined]
    auth_error = server._auth_error  # type: ignore[attr-defined]

    if auth_error:
        console.print(f"[red]Authentication failed:[/red] {auth_error}")
        return

    if not auth_code:
        console.print("[red]Authentication timed out or was cancelled.[/red]")
        return

    # Exchange code for tokens
    console.print("Exchanging authorization code...")

    with httpx.Client(timeout=15) as client:
        resp = client.post(
            f"{config.auth_service_url}/oauth/token",
            data={
                "grant_type": "authorization_code",
                "client_id": config.oauth_client_id,
                "code": auth_code,
                "redirect_uri": redirect_uri,
                "code_verifier": verifier,
            },
        )

    if resp.status_code != 200:
        console.print(f"[red]Token exchange failed:[/red] {resp.status_code} {resp.text}")
        return

    token_data = resp.json()
    creds = {
        "access_token": token_data["access_token"],
        "refresh_token": token_data.get("refresh_token"),
        "expires_at": time.time() + token_data.get("expires_in", 3600),
    }

    save_credentials(creds)
    console.print("[green]Logged in successfully![/green]")
    console.print(f"Credentials saved to {CREDENTIALS_PATH}")


def logout() -> None:
    """Remove stored credentials."""
    from rich.console import Console
    console = Console()

    if CREDENTIALS_PATH.exists():
        CREDENTIALS_PATH.unlink()
        console.print("Logged out. Credentials removed.")
    else:
        console.print("Not currently logged in.")


class _CallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for the OAuth callback."""

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        error = params.get("error", [None])[0]
        if error:
            self.server._auth_error = error  # type: ignore[attr-defined]
            self._respond("Authentication failed. You can close this tab.")
            return

        code = params.get("code", [None])[0]
        state = params.get("state", [None])[0]

        if state != self.server._auth_state:  # type: ignore[attr-defined]
            self.server._auth_error = "State mismatch"  # type: ignore[attr-defined]
            self._respond("Authentication failed: state mismatch.")
            return

        self.server._auth_code = code  # type: ignore[attr-defined]
        self._respond("Authentication successful! You can close this tab.")

    def _respond(self, message: str):
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        html = f"<html><body><h2>{message}</h2></body></html>"
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        # Suppress default HTTP server logs
        pass
