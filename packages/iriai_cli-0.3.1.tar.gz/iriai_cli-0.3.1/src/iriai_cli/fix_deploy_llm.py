"""LLM prompt builder for fix-deploy diagnosis and fix generation.

Builds prompts for the multi-phase fix-deploy workflow:
- Phase 1 (Diagnose): explore cloned repos and diagnose deployment issues
- Phase 3 (Fix): generate minimal code/config changes to fix the root cause
"""

import logging

logger = logging.getLogger(__name__)


DIAGNOSIS_SYSTEM_PROMPT = """\
You are a deployment debugging agent for cloud deployments on Railway.

You have access to the source code of each service in this directory. Each
subdirectory is a service (e.g. ./api/, ./frontend/). Explore the code to
understand the architecture and diagnose the issue.

Follow this internal methodology when investigating (do NOT write out these
steps — they guide your exploration only, not your output):

1. HYPOTHESIS — Read the deployment context (logs, env vars, topology, user
   issue). Form a specific, testable hypothesis.

2. ROOT CAUSE ANALYSIS — Explore the source code in the service directories
   to confirm your hypothesis. Read config files, Dockerfiles, package.json,
   requirements.txt, nginx configs, API client code, environment variable
   usage, etc.

3. DIAGNOSIS — Synthesize your findings into a clear, evidence-based diagnosis.

Your hypothesis must be SPECIFIC:
  Bad:  "Something is wrong with the deployment"
  Good: "The frontend returns 502 on API calls because the nginx proxy_pass
         resolves 'api' via Docker Compose DNS (127.0.0.11) which doesn't
         exist on Railway — the upstream should use Railway's private domain"

Railway platform reference — consult these docs when you need platform-specific information:
- Networking (private domains, public domains): https://docs.railway.com/reference/private-networking
- Volumes (persistent storage, NOT Docker Compose mounts): https://docs.railway.com/reference/volumes
- Build & deploy (nixpacks, Dockerfile, image): https://docs.railway.com/reference/build-and-start-commands
- Environment variables & reference variables: https://docs.railway.com/guides/variables

When diagnosing platform-specific issues (networking, port binding, volumes, builder
behavior), fetch the relevant Railway doc page above before proposing a diagnosis.
Do not guess at Railway platform mechanics.

Key rules:
- The app must listen on the PORT environment variable (not hardcoded ports)
- Environment variables set on one service are NOT available to others
- Frontend services (React, Vue, etc.) make API calls FROM THE BROWSER, not from
  the server. Any URL a frontend uses to reach the backend must be a PUBLIC domain
  (e.g. https://{service-name}.up.railway.app), NOT a private Railway internal
  domain ({service}.railway.internal). Private domains only work for server-to-server
  communication within a Railway project.
- Only backend/server services should use private Railway internal domains
  ({service}.railway.internal) for inter-service communication.
"""


FIX_SYSTEM_PROMPT = """\
You are a deployment fix generator for cloud deployments on Railway.

Given a deployment diagnosis, generate the MINIMAL code or configuration change
needed to fix the root cause. Your changes should be:

1. Targeted — only change what's necessary to fix the diagnosed issue
2. Safe — preserve existing functionality, don't break other services
3. Complete — include all files that need to change (configs, code, etc.)

For file changes, provide the full new content of each file (not diffs).
For config changes, only specify fields that need to change.

Key Railway platform rules:
- The app must listen on the PORT environment variable (not hardcoded ports)
- Environment variables set on one service are NOT available to others
- Frontend API URLs must be PUBLIC domains (https://{service}.up.railway.app),
  not private Railway internal domains
- Only backend services should use private domains ({service}.railway.internal)
  for inter-service communication
"""


def _truncate_logs(logs: str, max_lines: int = 100) -> str:
    """Truncate logs to last N lines."""
    if not logs:
        return ""
    lines = logs.strip().split("\n")
    if len(lines) > max_lines:
        return "[...truncated...]\n" + "\n".join(lines[-max_lines:])
    return logs


def build_diagnosis_prompt(context: dict) -> str:
    """Build the LLM prompt for deployment issue diagnosis.

    The prompt provides deployment context (logs, topology, env vars, issue)
    and instructs Claude to explore the cloned repos in the working
    directory to diagnose the issue.
    """
    parts: list[str] = []

    # User-reported issue
    issue = context.get("issue")
    if issue:
        parts.append(f"## User-Reported Issue\n\n{issue}\n")
        screenshot_urls = context.get("screenshot_urls", [])
        if screenshot_urls:
            parts.append(
                "Screenshots (URLs for reference): "
                + ", ".join(screenshot_urls)
                + "\n"
            )

    # Deployment environment context
    env_type = context.get("environment")
    subdomain = context.get("subdomain")
    dep_status = context.get("deployment_env_status")
    if env_type or subdomain:
        env_parts = [f"Environment: {env_type or 'unknown'}"]
        if subdomain:
            env_parts.append(f"Subdomain: {subdomain}")
        if dep_status:
            env_parts.append(f"Deployment status: {dep_status}")
        commit_sha = context.get("git_commit_sha")
        if commit_sha:
            env_parts.append(f"Deployed commit: {commit_sha}")
        parts.append("\n## Deployment Environment\n\n" + "\n".join(env_parts) + "\n")

    # Service topology with directory mapping
    all_services = context.get("all_services", [])
    services_ctx = context.get("services", [])

    # Build service name → has_repo mapping
    cloned_services = {
        svc.get("service_name")
        for svc in services_ctx
        if svc.get("mirror_repo_path")
    }

    if all_services:
        topo_lines = []
        for svc in all_services:
            name = svc.get("name", "?")
            svc_type = svc.get("type", "?")
            status = svc.get("status", "?")
            volume_mount = svc.get("volume_mount")

            detail_parts = [svc_type, status]
            if volume_mount:
                detail_parts.append(f"volume: {volume_mount}")
            port = svc.get("port")
            if port:
                detail_parts.append(f"port: {port}")
            hc = svc.get("health_check_path")
            if hc:
                detail_parts.append(f"healthcheck: {hc}")

            suffix = f" → ./{name}/" if name in cloned_services else ""
            topo_lines.append(f"- {name} ({', '.join(detail_parts)}){suffix}")
        parts.append("\n## Service Topology\n\n" + "\n".join(topo_lines) + "\n")

    # Per-service deployment context
    for svc in services_ctx:
        svc_name = svc.get("service_name", "unknown")
        parts.append(f"\n## Service: {svc_name}\n")

        # Config summary
        cfg_parts = []
        if svc.get("builder_type"):
            cfg_parts.append(f"Builder: {svc['builder_type']}")
        if svc.get("build_command"):
            cfg_parts.append(f"Build command: {svc['build_command']}")
        if svc.get("start_command"):
            cfg_parts.append(f"Start command: {svc['start_command']}")
        if svc.get("root_directory"):
            cfg_parts.append(f"Root directory: {svc['root_directory']}")
        if svc.get("dockerfile_path"):
            cfg_parts.append(f"Dockerfile: {svc['dockerfile_path']}")
        if svc.get("port"):
            cfg_parts.append(f"Port: {svc['port']}")
        if svc.get("health_check_path"):
            cfg_parts.append(f"Health check: {svc['health_check_path']}")
        if svc.get("image"):
            cfg_parts.append(f"Image: {svc['image']}")
        if svc.get("build_target"):
            cfg_parts.append(f"Build target: {svc['build_target']}")
        if svc.get("build_args"):
            cfg_parts.append(f"Build args: {svc['build_args']}")
        if svc.get("version"):
            cfg_parts.append(f"Version: {svc['version']}")
        if svc.get("configuration"):
            cfg_parts.append(f"Configuration: {svc['configuration']}")
        if svc.get("subdomain_suffix"):
            cfg_parts.append(f"Subdomain suffix: {svc['subdomain_suffix']}")
        if svc.get("repo_url"):
            cfg_parts.append(f"Repository: {svc['repo_url']}")
        if svc.get("branch"):
            cfg_parts.append(f"Branch: {svc['branch']}")
        if svc.get("mirror_repo_path"):
            cfg_parts.append(f"Source code: ./{svc_name}/")
        if cfg_parts:
            parts.append("\n".join(cfg_parts) + "\n")

        # Status & deployment info
        status_parts = []
        if svc.get("service_status"):
            status_parts.append(f"Status: {svc['service_status']}")
        if svc.get("health_status"):
            status_parts.append(f"Health: {svc['health_status']}")
        if svc.get("deployed_at"):
            status_parts.append(f"Deployed at: {svc['deployed_at']}")
        if svc.get("deployment_url"):
            status_parts.append(f"URL: {svc['deployment_url']}")
        if svc.get("commit_hash"):
            commit = svc["commit_hash"][:8]
            if svc.get("commit_message"):
                commit += f" — {svc['commit_message']}"
            if svc.get("commit_author"):
                commit += f" ({svc['commit_author']})"
            status_parts.append(f"Commit: {commit}")
        if status_parts:
            parts.append(f"\n### {svc_name} — Status\n\n" + "\n".join(status_parts) + "\n")

        # Domains
        domains_data = svc.get("domains", {})
        svc_domains = domains_data.get("service_domains", [])
        custom_domains = domains_data.get("custom_domains", [])
        if svc_domains or custom_domains:
            domain_lines = []
            for d in svc_domains:
                line = d.get("domain", "?")
                tp = d.get("targetPort")
                if tp:
                    line += f" → port {tp}"
                domain_lines.append(f"- {line}")
            for d in custom_domains:
                domain_lines.append(f"- {d.get('domain', '?')} (custom)")
            parts.append(f"\n### {svc_name} — Domains\n\n" + "\n".join(domain_lines) + "\n")

        # Environment variables (full values if available, else names only)
        env_vars = svc.get("env_vars", {})
        env_var_names = svc.get("env_var_names", [])
        if env_vars:
            env_lines = [f"  {k}={v}" for k, v in sorted(env_vars.items())]
            parts.append(
                f"\n### {svc_name} — Environment Variables\n\n"
                + "\n".join(env_lines) + "\n"
            )
        elif env_var_names:
            parts.append(
                f"\n### {svc_name} — Environment Variables (names only)\n\n"
                + ", ".join(env_var_names) + "\n"
            )

        # Platform-defined env vars (from AppService.environment_variables)
        platform_env = svc.get("environment_variables", {})
        if platform_env:
            env_lines = [f"  {k}={v}" for k, v in sorted(platform_env.items())]
            parts.append(
                f"\n### {svc_name} — Platform Environment Variables\n\n"
                + "\n".join(env_lines) + "\n"
            )

        # Build logs
        build_logs = _truncate_logs(svc.get("build_logs", ""))
        if build_logs:
            parts.append(f"\n### {svc_name} — Build Logs\n\n```\n{build_logs}\n```\n")

        # Runtime logs
        runtime_logs = _truncate_logs(svc.get("runtime_logs", ""))
        if runtime_logs:
            parts.append(f"\n### {svc_name} — Runtime Logs\n\n```\n{runtime_logs}\n```\n")

    # Task instructions
    if cloned_services:
        parts.append(
            "\n## Your Task\n\n"
            "Explore the service repos in this directory to diagnose the issue. "
            "Each service's source code is in a subdirectory matching its name. "
            "Read the relevant files (configs, Dockerfiles, source code, etc.) "
            "to understand what's wrong and provide your diagnosis.\n"
        )
    else:
        parts.append(
            "\n## Your Task\n\n"
            "Analyze the logs and configuration above to diagnose the issue.\n"
        )

    return "\n".join(parts)


def build_fix_prompt(context: dict, diagnosis_text: str) -> str:
    """Build the LLM prompt for fix generation.

    The prompt provides the diagnosis from Phase 1 and the deployment context,
    then asks for minimal code/config changes to fix the issue.
    """
    parts: list[str] = []

    parts.append(f"## Diagnosis\n\n{diagnosis_text}\n")

    # Include service topology for reference
    all_services = context.get("all_services", [])
    services_ctx = context.get("services", [])

    cloned_services = {
        svc.get("service_name")
        for svc in services_ctx
        if svc.get("mirror_repo_path")
    }

    if all_services:
        topo_lines = []
        for svc in all_services:
            name = svc.get("name", "?")
            svc_type = svc.get("type", "?")
            status = svc.get("status", "?")
            suffix = f" → ./{name}/" if name in cloned_services else ""
            topo_lines.append(f"- {name} ({svc_type}, {status}){suffix}")
        parts.append("\n## Service Topology\n\n" + "\n".join(topo_lines) + "\n")

    # Include env vars and domains per service for the fixer
    for svc in services_ctx:
        svc_name = svc.get("service_name", "unknown")

        # Environment variables (full values for fix generation)
        env_vars = svc.get("env_vars", {})
        env_var_names = svc.get("env_var_names", [])
        if env_vars:
            env_lines = [f"  {k}={v}" for k, v in sorted(env_vars.items())]
            parts.append(
                f"\n### {svc_name} — Environment Variables\n\n"
                + "\n".join(env_lines) + "\n"
            )
        elif env_var_names:
            parts.append(
                f"\n### {svc_name} — Environment Variables (names only)\n\n"
                + ", ".join(env_var_names) + "\n"
            )

        # Domains
        domains_data = svc.get("domains", {})
        svc_domains = domains_data.get("service_domains", [])
        custom_domains = domains_data.get("custom_domains", [])
        if svc_domains or custom_domains:
            domain_lines = []
            for d in svc_domains:
                line = d.get("domain", "?")
                tp = d.get("targetPort")
                if tp:
                    line += f" → port {tp}"
                domain_lines.append(f"- {line}")
            for d in custom_domains:
                domain_lines.append(f"- {d.get('domain', '?')} (custom)")
            parts.append(f"\n### {svc_name} — Domains\n\n" + "\n".join(domain_lines) + "\n")

        # Port config
        port = svc.get("port")
        if port:
            parts.append(f"\n### {svc_name} — Config\n\nPort: {port}\n")

    if cloned_services:
        parts.append(
            "\n## Your Task\n\n"
            "Based on the diagnosis above, generate the minimal fix. "
            "Explore the service repos in this directory if you need to read "
            "existing files before proposing changes. Each service's source "
            "code is in a subdirectory matching its name.\n"
        )
    else:
        parts.append(
            "\n## Your Task\n\n"
            "Based on the diagnosis above, generate the minimal fix.\n"
        )

    return "\n".join(parts)
