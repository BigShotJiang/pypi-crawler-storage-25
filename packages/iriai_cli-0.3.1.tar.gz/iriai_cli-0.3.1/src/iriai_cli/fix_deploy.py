"""Core fix-deploy command logic.

Uses an iriai-compose workflow for multi-phase diagnosis and fix generation:
  Phase 1: DiagnosePhase — agent explores repos and produces structured diagnosis
  Phase 2: ReviewPhase  — human reviews and approves the diagnosis
  Phase 3: FixPhase     — agent generates minimal code/config changes
"""

import asyncio
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table

from .api_client import APIError
from .auth import AuthError
from .deploy_client import DeployClient
from .repo_manager import RepoManager

console = Console()


def run_fix_deploy(
    app_id: str,
    service_name: str | None = None,
    auto_approve: bool = False,
    issue: str | None = None,
    fix_request_id: int | None = None,
) -> None:
    """Run the fix-deploy flow."""
    asyncio.run(_fix_deploy_async(app_id, service_name, auto_approve, issue, fix_request_id))


async def _fix_deploy_async(
    app_id: str,
    service_name: str | None,
    auto_approve: bool,
    issue: str | None = None,
    fix_request_id: int | None = None,
) -> None:
    """Async fix-deploy flow."""

    # Step 1: Auth
    try:
        from .auth import get_token
        get_token()
    except AuthError as e:
        console.print(f"[red]Error:[/red] {e}")
        return

    client = DeployClient()

    # Step 2: Fetch context
    mode = "runtime issue" if (issue or fix_request_id) else "build failure"
    scope = f"[cyan]{service_name}[/cyan]" if service_name else "[cyan]all services[/cyan]"
    console.print(f"Fetching {mode} context for {scope}...")
    try:
        context = await client.get_fix_context(
            app_id, service_name, issue=issue, fix_request_id=fix_request_id
        )
    except APIError as e:
        console.print(f"[red]Error:[/red] {e}")
        return
    except AuthError as e:
        console.print(f"[red]Auth error:[/red] {e}")
        return

    # Step 3: Display context summary
    services_ctx = context.get("services", [])

    # Show issue if present
    issue_text = context.get("issue")
    if issue_text:
        console.print(f"\n[bold]Reported issue:[/bold] {issue_text}")
    screenshots = context.get("screenshot_urls", [])
    if screenshots:
        console.print(f"[bold]Screenshots:[/bold] {len(screenshots)} attached")

    if len(services_ctx) > 1:
        # Multi-service: show summary table
        console.print()
        svc_table = Table(title="Services")
        svc_table.add_column("Service", style="cyan")
        svc_table.add_column("Type")
        svc_table.add_column("Status")
        svc_table.add_column("Volume", style="dim")
        svc_table.add_column("Repo")
        for svc in services_ctx:
            status = svc.get("service_status", "?")
            color = "green" if status == "active" else "red" if status == "failed" else "yellow"
            svc_table.add_row(
                svc.get("service_name", "?"),
                svc.get("service_type", "?"),
                f"[{color}]{status}[/{color}]",
                svc.get("volume_mount") or "",
                svc.get("repo_url", "N/A") or "N/A",
            )
        console.print(svc_table)

        # Show last 5 lines of logs per service
        for svc in services_ctx:
            svc_name = svc.get("service_name", "?")
            for log_key, label, style in [
                ("build_logs", "Build", "red"),
                ("runtime_logs", "Runtime", "yellow"),
            ]:
                logs = svc.get(log_key, "")
                if logs:
                    lines = logs.strip().split("\n")
                    preview = "\n".join(lines[-5:])
                    console.print(f"\n[bold]{svc_name} — {label} logs (last 5 lines):[/bold]")
                    console.print(Panel(preview, border_style=style))
    else:
        # Single-service: show flat context
        console.print()
        console.print(f"[bold]Repository:[/bold] {context.get('repo_url', 'N/A')}")
        console.print(f"[bold]Branch:[/bold] {context.get('branch', 'N/A')}")
        console.print(f"[bold]Status:[/bold] {context.get('service_status', 'N/A')}")
        volume = context.get("volume_mount")
        if volume:
            console.print(f"[bold]Volume:[/bold] {volume}")

        build_logs = context.get("build_logs", "")
        if build_logs:
            log_lines = build_logs.strip().split("\n")
            preview = "\n".join(log_lines[-10:])
            console.print(f"\n[bold]Build logs (last 10 lines):[/bold]")
            console.print(Panel(preview, border_style="red"))

        runtime_logs = context.get("runtime_logs", "")
        if runtime_logs:
            rt_lines = runtime_logs.strip().split("\n")
            rt_preview = "\n".join(rt_lines[-10:])
            console.print(f"\n[bold]Runtime logs (last 10 lines):[/bold]")
            console.print(Panel(rt_preview, border_style="yellow"))

    # Step 4: Clone mirror repos for local exploration
    repo_manager = RepoManager()
    workspace = None

    try:
        console.print("\n[bold]Fetching clone URLs...[/bold]")
        clone_data = await client.get_clone_urls(app_id)
        clone_urls = clone_data.get("clone_urls", [])

        if clone_urls:
            console.print(f"Cloning {len(clone_urls)} service repo(s)...")
            workspace = await repo_manager.clone_services(clone_urls)
            console.print(f"Repos cloned to [dim]{workspace}[/dim]")
        else:
            console.print("[yellow]No mirror repos available — analyzing from logs only[/yellow]")
    except (APIError, AuthError) as e:
        console.print(f"[yellow]Warning: could not clone repos ({e}). Analyzing from logs only.[/yellow]")

    # Step 5: Run multi-phase workflow (Diagnose → Review → Fix)
    console.print(f"\n[bold]Running fix-deploy workflow...[/bold]")

    try:
        final_state = await _run_fix_workflow(
            context=context,
            workspace_path=str(workspace) if workspace else None,
            app_id=app_id,
        )
    except _DiagnosisRejectedError:
        console.print("Diagnosis rejected. Cancelled.")
        repo_manager.cleanup()
        return
    except RuntimeError as e:
        console.print(f"[red]Workflow failed:[/red] {e}")
        repo_manager.cleanup()
        return

    # Step 6: Display fix results
    diagnosis = final_state.diagnosis
    fix = final_state.fix

    if fix:
        _display_fix(fix)

    # Step 7: User confirmation to apply
    if not auto_approve:
        console.print()
        proceed = console.input("[bold]Proceed with fix deployment? [y/N]:[/bold] ")
        if proceed.lower() not in ("y", "yes"):
            console.print("Cancelled.")
            repo_manager.cleanup()
            return

    # Step 8: Send to backend
    console.print("\n[bold]Creating fix environment...[/bold]")

    changes = fix.changes if fix else []
    config_changes = fix.config_changes if fix else None

    payload = {
        "app_id": app_id,
        "service_name": service_name or context.get("service_name", ""),
        "diagnosis": diagnosis.hypothesis if diagnosis else "Unable to determine root cause",
        "code_changes": [
            {"path": c.path, "action": c.action, "content": c.new_content}
            for c in changes
        ],
    }
    if fix_request_id is not None:
        payload["fix_request_id"] = fix_request_id
    if config_changes:
        filtered = {}
        if config_changes.build_command is not None:
            filtered["build_command"] = config_changes.build_command
        if config_changes.start_command is not None:
            filtered["start_command"] = config_changes.start_command
        if config_changes.root_directory is not None:
            filtered["root_directory"] = config_changes.root_directory
        if config_changes.dockerfile_path is not None:
            filtered["dockerfile_path"] = config_changes.dockerfile_path
        if config_changes.env_vars:
            filtered["env_vars"] = config_changes.env_vars
        if filtered:
            payload["config_changes"] = filtered

    try:
        apply_result = await client.apply_fix(payload)
    except APIError as e:
        # Check if a fix environment already exists — offer to replace it
        error_msg = str(e)
        if "Active fix environment already exists" in error_msg:
            import re
            id_match = re.search(r"id:\s*(\d+)", error_msg)
            if id_match:
                existing_id = int(id_match.group(1))
                replace = console.input(
                    f"[yellow]Fix environment #{existing_id} already exists.[/yellow] "
                    "Replace it? [y/N]: "
                )
                if replace.lower() in ("y", "yes"):
                    console.print("Cleaning up existing fix environment...")
                    try:
                        await client.reject_fix(existing_id)
                    except APIError as reject_err:
                        console.print(f"[red]Failed to clean up:[/red] {reject_err}")
                        return
                    console.print("Retrying fix deployment...")
                    try:
                        apply_result = await client.apply_fix(payload)
                    except APIError as retry_err:
                        console.print(f"[red]Error:[/red] {retry_err}")
                        return
                else:
                    console.print("Cancelled.")
                    return
            else:
                console.print(f"[red]Error:[/red] {e}")
                return
        else:
            console.print(f"[red]Error:[/red] {e}")
            return

    fix_env_id = apply_result["fix_environment_id"]
    fix_branch = apply_result.get("fix_branch", "")
    console.print(f"Fix environment created (id: {fix_env_id}, branch: {fix_branch})")

    # Step 9: Poll for status
    console.print("\nWaiting for fix environment to deploy...")

    dep_status = "deploying"
    status_result = {}

    with console.status("[bold]Deploying...") as spinner:
        while True:
            await asyncio.sleep(10)
            try:
                status_result = await client.get_fix_status(fix_env_id)
            except APIError:
                continue

            dep_status = status_result.get("deployment_status", "unknown")

            if dep_status in ("active", "failed"):
                break

    # Show final status
    console.print()
    services = status_result.get("services", [])
    table = Table(title="Fix Environment Services")
    table.add_column("Service", style="cyan")
    table.add_column("Status")
    table.add_column("Target")

    for svc in services:
        svc_status = svc.get("status", "unknown")
        color = "green" if svc_status == "active" else "red" if svc_status == "failed" else "yellow"
        target = "[bold]→ FIX[/bold]" if svc.get("is_target") else ""
        table.add_row(svc["service_name"], f"[{color}]{svc_status}[/{color}]", target)

    console.print(table)

    # Step 10: Approve or reject
    if dep_status == "failed":
        console.print("\n[red]Fix environment build failed.[/red]")
        try:
            await client.reject_fix(fix_env_id)
            console.print("Fix environment cleaned up.")
        except APIError as e:
            console.print(f"[yellow]Warning: cleanup failed:[/yellow] {e}")
        repo_manager.cleanup()
        return

    console.print("\n[green]Fix environment is active![/green]")

    if auto_approve:
        action = "approve"
    else:
        action = console.input("[bold]Approve fix (creates PR + applies config) or reject? [approve/reject]:[/bold] ")

    if action.lower() in ("approve", "a", "yes", "y"):
        console.print("Approving fix...")
        try:
            approve_result = await client.approve_fix(fix_env_id)
            pr_url = approve_result.get("pr_url")
            config_applied = approve_result.get("config_applied", False)

            if pr_url:
                console.print(f"[green]PR created:[/green] {pr_url}")
            if config_applied:
                console.print("[green]Config changes applied to staging.[/green]")
            console.print(f"\n{approve_result.get('message', 'Fix approved.')}")
        except APIError as e:
            console.print(f"[red]Approve failed:[/red] {e}")
    else:
        console.print("Rejecting fix...")
        try:
            await client.reject_fix(fix_env_id)
            console.print("Fix environment cleaned up.")
        except APIError as e:
            console.print(f"[yellow]Warning: cleanup failed:[/yellow] {e}")

    # Always clean up cloned repos
    repo_manager.cleanup()


# ── Workflow runner ──────────────────────────────────────────────────────


class _DiagnosisRejectedError(RuntimeError):
    """Wrapper so the caller can distinguish rejection from other errors."""


async def _run_fix_workflow(
    context: dict,
    workspace_path: str | None,
    app_id: str,
) -> "FixDeployState":
    """Set up and execute the fix-deploy workflow via iriai-compose."""
    from iriai_compose.runner import DefaultWorkflowRunner
    from iriai_compose.storage import (
        DefaultContextProvider,
        InMemoryArtifactStore,
        InMemorySessionStore,
    )
    from iriai_compose.workflow import Feature, Workspace

    from .runtimes.claude_code import ClaudeCodeRuntime
    from .runtimes.rich_terminal import RichInteractionRuntime
    from .workflows.fix_deploy_workflow import (
        DiagnosisRejected,
        FixDeployState,
        FixDeployWorkflow,
    )

    # In-memory stores (no server needed for CLI)
    artifacts = InMemoryArtifactStore()
    sessions = InMemorySessionStore()
    context_provider = DefaultContextProvider(artifacts=artifacts)

    # Runtimes
    agent_runtime = ClaudeCodeRuntime(on_message=_on_agent_message)
    interaction_runtime = RichInteractionRuntime(console=console)

    # Workspace (cloned repos)
    workspaces = {}
    if workspace_path:
        workspaces["fix"] = Workspace(id="fix", path=Path(workspace_path))

    runner = DefaultWorkflowRunner(
        agent_runtime=agent_runtime,
        interaction_runtimes={"terminal": interaction_runtime},
        artifacts=artifacts,
        sessions=sessions,
        context_provider=context_provider,
        workspaces=workspaces or None,
    )

    feature = Feature(
        id=f"fix-{app_id}",
        name=f"Fix deploy {app_id}",
        slug=f"fix-{app_id}",
        workflow_name="fix-deploy",
        workspace_id="fix" if workspace_path else "",
    )

    state = FixDeployState(context=context, workspace_path=workspace_path)

    try:
        final_state = await runner.execute_workflow(FixDeployWorkflow(), feature, state)
    except DiagnosisRejected:
        raise _DiagnosisRejectedError()

    return final_state


def _on_agent_message(msg: object) -> None:
    """Callback for streaming agent messages during workflow execution."""
    # Show tool use progress to the user
    msg_type = getattr(msg, "type", None)
    if msg_type == "assistant":
        content = getattr(msg, "content", None)
        if isinstance(content, list):
            for block in content:
                if getattr(block, "type", None) == "tool_use":
                    tool_name = getattr(block, "name", "?")
                    console.print(f"  [dim]→ {tool_name}[/dim]", highlight=False)


# ── Display helpers ──────────────────────────────────────────────────────


def _display_fix(fix) -> None:
    """Display the fix results using Rich."""
    from .workflows.fix_deploy_workflow import FixDeployResult

    if not isinstance(fix, FixDeployResult):
        return

    console.print(Panel(
        f"[bold]{fix.explanation}[/bold]\n\n"
        f"Fix type: {fix.fix_type}\n"
        f"Confidence: {_confidence_display(fix.confidence_score)}",
        title="Proposed Fix",
        border_style="green",
    ))

    # Show code changes
    if fix.changes:
        console.print(f"\n[bold]Code changes ({len(fix.changes)} files):[/bold]")
        for change in fix.changes:
            color = _action_color(change.action)
            console.print(f"  [{color}]{change.action}[/{color}] {change.path}")
            if change.new_content and len(change.new_content) < 500:
                ext = change.path.rsplit(".", 1)[-1] if "." in change.path else "txt"
                console.print(Syntax(change.new_content, ext, theme="monokai", line_numbers=True))

    # Show config changes
    if fix.config_changes:
        cfg = fix.config_changes
        console.print(f"\n[bold]Config changes:[/bold]")
        if cfg.build_command is not None:
            console.print(f"  [magenta]build_command[/magenta] = {cfg.build_command}")
        if cfg.start_command is not None:
            console.print(f"  [magenta]start_command[/magenta] = {cfg.start_command}")
        if cfg.root_directory is not None:
            console.print(f"  [magenta]root_directory[/magenta] = {cfg.root_directory}")
        if cfg.dockerfile_path is not None:
            console.print(f"  [magenta]dockerfile_path[/magenta] = {cfg.dockerfile_path}")
        if cfg.env_vars:
            for var_name, var_value in cfg.env_vars.items():
                console.print(f"  [magenta]env_var[/magenta] {var_name}={var_value}")

    # Show package instructions
    if fix.package_instructions:
        console.print(f"\n[bold]Package instructions:[/bold]")
        for instruction in fix.package_instructions:
            console.print(f"  $ {instruction}")


def _confidence_display(score: float) -> str:
    if score >= 0.85:
        return f"[green]{score:.2f} (high)[/green]"
    elif score >= 0.6:
        return f"[yellow]{score:.2f} (medium)[/yellow]"
    return f"[red]{score:.2f} (low)[/red]"


def _action_color(action: str) -> str:
    """Color for file action display."""
    return {"create": "green", "modify": "yellow", "delete": "red"}.get(action, "white")
