"""Iriai CLI — Local module integration tool."""

__version__ = "0.1.0"
