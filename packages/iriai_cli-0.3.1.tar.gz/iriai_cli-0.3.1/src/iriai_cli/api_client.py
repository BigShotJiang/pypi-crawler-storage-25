"""HTTP client for integration engine API."""

import logging
from typing import Any

import httpx
from rich.console import Console

from .config import config

logger = logging.getLogger(__name__)
console = Console()


class APIError(Exception):
    """Base error for API communication."""

    def __init__(self, message: str, status_code: int | None = None):
        self.status_code = status_code
        super().__init__(message)


class APIClient:
    """Async HTTP client for the integration engine."""

    def __init__(self, base_url: str | None = None, timeout: int = 30):
        self.base_url = base_url or config.engine_url
        self.timeout = timeout

    async def get_modules(self) -> list[dict[str, Any]]:
        """Fetch available modules.

        Returns:
            List of module metadata dicts.
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/api/modules",
                    headers=config.headers,
                )
                response.raise_for_status()
                data = response.json()
                return data.get("modules", [])
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Failed to fetch modules: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def get_module_definition(self, name: str) -> dict[str, Any]:
        """Fetch a full module definition by name.

        Args:
            name: Module name (e.g., "auth-react").

        Returns:
            Full module definition dict including prompt_template, analyze config, etc.
        """
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            try:
                response = await client.get(
                    f"{self.base_url}/api/modules/{name}",
                    headers=config.headers,
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                if e.response.status_code == 404:
                    raise APIError(f"Module '{name}' not found", status_code=404)
                raise APIError(
                    f"Failed to fetch module '{name}': {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def analyze(self, tarball_path: str, modules: list[str] | None = None) -> dict[str, Any]:
        """Analyze a project tarball via POST /api/analyze-local.

        Args:
            tarball_path: Path to .tar.gz file.
            modules: Optional list of module names to check.

        Returns:
            Analysis result dict.
        """
        import json as _json

        async with httpx.AsyncClient(timeout=60) as client:
            try:
                with open(tarball_path, "rb") as f:
                    files = {"tarball": ("project.tar.gz", f, "application/gzip")}
                    data = {}
                    if modules:
                        data["modules"] = _json.dumps(modules)
                    headers = {}
                    if config.api_token:
                        headers["Authorization"] = f"Bearer {config.api_token}"
                    response = await client.post(
                        f"{self.base_url}/api/analyze-local",
                        headers=headers,
                        files=files,
                        data=data,
                    )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Analysis failed: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")

    async def integrate_local(
        self,
        tarball_path: str,
        modules: dict[str, str],
        integration_depth: str = "full",
        competing_solution_choices: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Trigger local integration.

        Args:
            tarball_path: Path to project tarball.
            modules: Module name -> action mapping.
            integration_depth: "core" or "full".
            competing_solution_choices: Optional competing solution choices.

        Returns:
            Integration result dict with file operations.
        """
        import json

        async with httpx.AsyncClient(timeout=120) as client:
            try:
                with open(tarball_path, "rb") as f:
                    files = {"tarball": ("project.tar.gz", f, "application/gzip")}
                    data = {
                        "modules": json.dumps(modules),
                        "integration_depth": integration_depth,
                    }
                    if competing_solution_choices:
                        data["competing_solution_choices"] = json.dumps(
                            competing_solution_choices
                        )

                    headers = {}
                    if config.api_token:
                        headers["Authorization"] = f"Bearer {config.api_token}"

                    response = await client.post(
                        f"{self.base_url}/api/integrate-local",
                        headers=headers,
                        files=files,
                        data=data,
                    )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise APIError(
                    f"Integration failed: {e.response.status_code}",
                    status_code=e.response.status_code,
                )
            except httpx.RequestError as e:
                raise APIError(f"Network error: {e}")
