# iriai-cli

Command-line tool for integrating Iriai platform modules into your local projects.

## Installation

```bash
pip install iriai-cli
# or
pipx install iriai-cli
```

## Usage

```bash
# List available modules
iriai modules list

# Analyze your project
iriai analyze

# Install a module
iriai integrate auth-react --action install

# Repair a misconfigured module
iriai integrate auth-react --action repair

# Install multiple modules
iriai integrate auth-react auth-python pwa --action install
```

## Features

- Local file integration (no Git commits required)
- Pre-flight analysis and misconfiguration detection
- LLM-powered code generation via engine API or locally via Claude Code (`--local`)
- Interactive file write prompts (Apply/Skip/Overwrite-all)
- Syntax-highlighted diffs
- Secret file filtering (`.env`, `*.pem`, `*.key`, `credentials.*`, etc.)
- Dry-run mode for previewing changes

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `IRIAI_ENGINE_URL` | `https://integration.iriai.app` | Integration engine base URL |
| `IRIAI_API_TOKEN` | *(none)* | Bearer token for authenticated modules (get from deploy console) |
| `IRIAI_MODULES_DIR` | *(fetched from API)* | Override: load module definitions from local YAML files instead of API |

```bash
# Point to local engine during development
export IRIAI_ENGINE_URL=http://localhost:8005

# Set API token for authenticated modules
export IRIAI_API_TOKEN=your_token_here
```

## Commands

### `iriai modules list`

List all available modules with their versions and descriptions.

### `iriai analyze`

Analyze the current directory for module compatibility and misconfigurations. Creates a tarball of the project directory (excluding secrets and ignored files) and uploads it to the engine's `POST /api/analyze-local` endpoint.

### `iriai integrate <modules...>`

Integrate one or more modules into your project.

Options:
- `--action`: `install`, `repair`, or `overwrite` (default: `install`)
- `--depth`: `core` or `full` (default: `full`)
- `--yes`: Skip interactive prompts, apply all changes
- `--dry-run`: Show what would be changed without writing files
- `--local`: Run entirely locally via Claude Code (`claude -p`) instead of the engine API

### Local Mode (`--local`)

The `--local` flag runs LLM integration on your machine via Claude Code instead of the engine API:

```bash
iriai integrate auth-react --local
```

This mode:
1. Fetches module definitions from the integration engine API
2. Analyzes the project locally (same logic as the engine)
3. Builds a prompt identical to `LLMIntegrator._build_prompt()`
4. Invokes `claude -p` subprocess with a 5-minute timeout
5. Parses the structured JSON response
6. Applies file operations through interactive prompts

**Requirements:** Claude Code CLI (`claude`) must be installed and on your PATH.

**Note:** Profile matching is skipped in local mode (requires database). Most integrations work without profile-specific config.

For development, set `IRIAI_MODULES_DIR` to load module definitions from local YAML files instead of the API.

## License

MIT
