"""OTelObservableClient — a drop-in subclass of ``ResilientClient`` that emits
OpenTelemetry metrics + span events from each call's visible-degradation trail.

Seamless explicit-mode usage: change one word:

    from keel_llm_reliability import ResilientClient        # before
    from keel_llm_otel import OTelObservableClient as ResilientClient  # after

…or import it under its own name and use it directly. Same constructor, same
methods, same return types — observability is layered on by overriding
``failover`` / ``fan_out`` to emit signals after they return. The underlying
``keel-llm-reliability`` library is unchanged; this class is purely additive.

For zero-code-change instrumentation (an even more seamless path), see
``OTelInstrumentor`` in ``keel_llm_otel.instrumentor`` — the OTel-standard
auto-instrumentation entry point.
"""

from __future__ import annotations

from collections.abc import Sequence

from keel_llm_protocol import ModelAdapter
from keel_llm_reliability import (
    FailoverResult,
    FanOutResult,
    Request,
    ResilientClient,
)
from keel_llm_reliability.collaborators import Breaker, Limiter
from opentelemetry import metrics, trace

from keel_llm_otel.signals import Signals
from keel_llm_otel.instrumentor import is_instrumented

__all__ = ["OTelObservableClient"]


class OTelObservableClient(ResilientClient):
    """Drop-in replacement for ``ResilientClient`` with OTel emission.

    Constructor mirrors ``ResilientClient`` exactly, plus optional ``meter`` /
    ``tracer`` overrides. When omitted, the global OTel meter/tracer are used —
    which means *zero* overhead if no OTel SDK is configured (the API hands
    back no-op instruments).
    """

    def __init__(
        self,
        adapters: Sequence[ModelAdapter],
        *,
        breaker: Breaker | None = None,
        limiter: Limiter | None = None,
        transient_retries: int = 0,
        meter: metrics.Meter | None = None,
        tracer: trace.Tracer | None = None,
    ) -> None:
        super().__init__(
            adapters,
            breaker=breaker,
            limiter=limiter,
            transient_retries=transient_retries,
        )
        self._signals = Signals(meter=meter, tracer=tracer)

    async def failover(self, request: Request) -> FailoverResult:
        result = await super().failover(request)
        # If the auto-instrumentor is active, the patched parent method already
        # emitted via the instrumentor's Signals — skip ours to avoid double-counting.
        if not is_instrumented():
            self._signals.emit_failover(result)
        return result

    async def fan_out(self, request: Request) -> FanOutResult:
        result = await super().fan_out(request)
        if not is_instrumented():
            self._signals.emit_fan_out(result)
        return result
