"""keel-llm-otel — OpenTelemetry metrics + span events for keel-llm-reliability.

Three ways to use it; all produce identical signals:

1. **Auto-instrumentation (zero code change)** — requires the ``[auto]`` extra:
   ``pip install 'keel-llm-otel[auto]'``, then run with
   ``opentelemetry-instrument python yourapp.py`` (or call
   ``OTelInstrumentor().instrument()`` once at startup).
   ``ResilientClient`` is patched to emit metrics + span events automatically.

2. **Drop-in subclass (one-word code change)** — lean install:
   ``pip install keel-llm-otel``, then use ``OTelObservableClient`` wherever
   you'd use ``ResilientClient`` — same constructor, same methods.

3. **Direct emission (decoupled from keel-llm-reliability orchestration)** —
   ``Signals.emit(...)`` accepts any iterable of ``AttemptLike``, so a consumer
   with their own orchestrator can emit on the same OTel vocabulary without
   adopting ``keel-llm-reliability``. Lean install; no extras needed.

``keel-llm-reliability`` itself stays observability-free; this package is
purely additive.
"""

from __future__ import annotations

from keel_llm_otel.client import OTelObservableClient
from keel_llm_otel.signals import AttemptLike, ErrorLike, Signals

__all__ = ["AttemptLike", "ErrorLike", "OTelObservableClient", "Signals"]

# OTelInstrumentor only exists when the `[auto]` extra is installed (it needs
# `opentelemetry-instrumentation`'s `BaseInstrumentor`). The lean install
# (subclass + Signals) is fully usable without it.
try:
    from keel_llm_otel.instrumentor import OTelInstrumentor

    __all__.append("OTelInstrumentor")
except ImportError:  # pragma: no cover

    def __getattr__(name: str) -> object:
        if name == "OTelInstrumentor":
            raise ImportError(
                "OTelInstrumentor requires the auto-instrumentation extra. "
                "Install with: pip install 'keel-llm-otel[auto]'"
            )
        raise AttributeError(f"module 'keel_llm_otel' has no attribute {name!r}")
