"""OTel signal emission — structurally decoupled from any specific orchestrator.

``Signals`` accepts a generic *attempts trail* (anything satisfying the
``AttemptLike`` Protocol) and emits OTel metrics + span events from it. So:

- ``keel-llm-reliability``'s ``Attempt`` / ``FailoverResult`` / ``FanOutResult``
  satisfy the protocol naturally — ``OTelObservableClient`` and
  ``OTelInstrumentor`` use the convenience wrappers ``emit_failover`` /
  ``emit_fan_out``.
- *Any other consumer* with a compatible per-attempt disposition (e.g. an
  in-tree fan-out that doesn't use Keel's orchestrator) builds a list of objects
  satisfying ``AttemptLike`` and calls ``Signals.emit(...)`` directly — same
  OTel vocabulary, no ``keel-llm-reliability`` dependency at the consumption
  point.

This is the same shape as the injected-collaborator move that made
``keel-llm-reliability`` itself adoptable across consumer designs.
"""

from __future__ import annotations

from collections.abc import Iterable
from typing import Protocol, runtime_checkable

from keel_llm_reliability import FailoverResult, FanOutResult
from opentelemetry import metrics, trace

__all__ = ["INSTRUMENTATION_NAME", "AttemptLike", "ErrorLike", "Signals"]

INSTRUMENTATION_NAME = "keel-llm-otel"


@runtime_checkable
class ErrorLike(Protocol):
    """Structural shape for the ``error`` field on an attempt. The standard
    ``category`` values are ``"backpressure"`` / ``"transient"`` / ``"terminal"``
    (the ``keel-llm-protocol`` taxonomy), but any string works — the emission
    layer doesn't enforce the vocabulary."""

    @property
    def category(self) -> str: ...


@runtime_checkable
class AttemptLike(Protocol):
    """Structural shape for one provider interaction in a reliability call.

    ``keel_llm_reliability.Attempt`` satisfies this with no change. Any other
    consumer's per-attempt disposition that exposes these four attributes also
    satisfies it.

    Conventions for ``outcome`` (recommended but not enforced) — these are the
    values that downstream dashboards / queries / SLOs will key on:
    ``"success"``, ``"preempted_open"``, ``"preempted_limited"``,
    ``"deferred_backpressure"``, ``"empty"``, ``"failed"``.
    """

    @property
    def model_key(self) -> str: ...

    @property
    def outcome(self) -> str: ...

    @property
    def latency_ms(self) -> int: ...

    @property
    def error(self) -> ErrorLike | None: ...


class Signals:
    """OTel emission for a reliability call's attempts trail.

    Constructs three instruments lazily against an injected (or default)
    ``Meter``; emission is defensive — any error in the meter / tracer is
    swallowed so observability never breaks the underlying call.
    """

    def __init__(
        self,
        meter: metrics.Meter | None = None,
        tracer: trace.Tracer | None = None,
    ) -> None:
        self._meter = meter if meter is not None else metrics.get_meter(INSTRUMENTATION_NAME)
        self._tracer = tracer if tracer is not None else trace.get_tracer(INSTRUMENTATION_NAME)
        # Counter names follow modern OTel convention — no `_total` suffix; the
        # Prometheus exporter adds it automatically when needed.
        self._attempts = self._meter.create_counter(
            name="keel.llm.reliability.attempts",
            description="Per-provider interaction outcomes in a reliability call.",
            unit="1",
        )
        self._duration = self._meter.create_histogram(
            name="keel.llm.reliability.attempt_duration_ms",
            description="Latency per provider interaction.",
            unit="ms",
        )
        self._calls = self._meter.create_counter(
            name="keel.llm.reliability.calls",
            description="Reliability calls by strategy and outcome.",
            unit="1",
        )

    # --- canonical, decoupled entry point ----------------------------------- #

    def emit(
        self,
        *,
        strategy: str,
        attempts: Iterable[AttemptLike],
        succeeded: bool,
        degraded: bool,
    ) -> None:
        """Emit OTel signals for one reliability call's attempts trail.

        ``strategy`` is free-form (``"failover"`` / ``"fan_out"`` / your own
        orchestrator's name). ``attempts`` is any iterable of ``AttemptLike``.
        ``succeeded`` / ``degraded`` are the call-level summary.
        """
        try:
            self._calls.add(
                1,
                {"strategy": strategy, "succeeded": succeeded, "degraded": degraded},
            )
            current_span = trace.get_current_span()
            for a in attempts:
                error_category = a.error.category if a.error is not None else "none"
                self._attempts.add(
                    1,
                    {
                        "strategy": strategy,
                        # Label name aligns with OTel's incubating gen_ai conventions
                        # so reliability-layer dispositions can be joined with
                        # adapter-level gen_ai.* metrics in cross-layer queries.
                        "gen_ai.request.model": a.model_key,
                        "outcome": a.outcome,
                        "error_category": error_category,
                    },
                )
                self._duration.record(
                    a.latency_ms,
                    {
                        "strategy": strategy,
                        "gen_ai.request.model": a.model_key,
                        "outcome": a.outcome,
                    },
                )
                if current_span.is_recording():
                    current_span.add_event(
                        name="keel.attempt",
                        attributes={
                            "keel.strategy": strategy,
                            "gen_ai.request.model": a.model_key,
                            "keel.outcome": a.outcome,
                            "keel.latency_ms": a.latency_ms,
                            "keel.error_category": error_category,
                        },
                    )
        except Exception:
            # Observability must never break the underlying call.
            pass

    # --- convenience wrappers for keel-llm-reliability result types --------- #

    def emit_failover(self, result: FailoverResult) -> None:
        degraded = (not result.succeeded) or any(
            a.outcome != "success" for a in result.attempts
        )
        self.emit(
            strategy="failover",
            attempts=result.attempts,
            succeeded=result.succeeded,
            degraded=degraded,
        )

    def emit_fan_out(self, result: FanOutResult) -> None:
        self.emit(
            strategy="fan_out",
            attempts=result.attempts,
            succeeded=len(result.successes) > 0,
            degraded=result.degraded,
        )
