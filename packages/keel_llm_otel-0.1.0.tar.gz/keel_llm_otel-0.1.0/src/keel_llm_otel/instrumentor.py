"""OTelInstrumentor — auto-instrument ``keel-llm-reliability`` with zero code change.

This is the OTel-standard auto-instrumentation pattern (same shape as
``opentelemetry-instrumentation-httpx`` / ``-requests`` / ``-flask``). It needs
the ``opentelemetry-instrumentation`` runtime (which pulls in ``wrapt``); to
keep the lean install lean, that dep lives behind a Python extra:

    pip install 'keel-llm-otel[auto]'

…then either:

1. **CLI bootstrap (most seamless, no code change at all):**

       opentelemetry-instrument python yourapp.py

2. **Programmatic activation (one line at startup):**

       from keel_llm_otel import OTelInstrumentor
       OTelInstrumentor().instrument()

Either way, the consumer's existing ``ResilientClient`` usage is unchanged.
``OTelInstrumentor().uninstrument()`` restores the originals (idempotent).

``is_instrumented()`` is always available (even on the lean install) so
``OTelObservableClient`` can detect when the patched parent will emit and
skip its own emission — avoiding double-counting.
"""

from __future__ import annotations

from collections.abc import Collection
from typing import Any

from keel_llm_reliability import FailoverResult, FanOutResult, Request, ResilientClient
from opentelemetry import metrics, trace

from keel_llm_otel.signals import INSTRUMENTATION_NAME, Signals

# Module-level handles so the global patch state is queryable from
# ``OTelObservableClient`` (which lives in the lean install) without it needing
# to import ``BaseInstrumentor`` itself.
_original_failover: Any = None
_original_fan_out: Any = None


def is_instrumented() -> bool:
    """True iff ``OTelInstrumentor`` has patched ``ResilientClient`` globally.

    Always importable, even on the lean install (without the ``[auto]`` extra).
    Used by ``OTelObservableClient`` to skip its own emission when the
    auto-instrumentor is active — avoiding double-counting.
    """
    return _original_failover is not None


# ----------------------------------------------------------------------------- #
# Auto-instrumentor — only defined when the `[auto]` extra is installed.       #
# ----------------------------------------------------------------------------- #
try:
    # opentelemetry-instrumentation ships without type stubs; the import is real
    # at runtime but mypy can't resolve it.
    from opentelemetry.instrumentation.instrumentor import BaseInstrumentor  # type: ignore[attr-defined]

    _HAS_AUTO_INSTRUMENT = True
except ImportError:
    _HAS_AUTO_INSTRUMENT = False


if _HAS_AUTO_INSTRUMENT:

    class OTelInstrumentor(BaseInstrumentor):  # type: ignore[misc]
        """Auto-instrumentor for ``keel-llm-reliability``."""

        def instrumentation_dependencies(self) -> Collection[str]:
            return ["keel-llm-reliability >= 0.1.2"]

        def _instrument(self, **kwargs: Any) -> None:
            global _original_failover, _original_fan_out
            # Re-entrant: if already instrumented, do nothing (matches every
            # other OTel instrumentation package's behaviour).
            if _original_failover is not None:
                return

            meter_provider = kwargs.get("meter_provider") or metrics.get_meter_provider()
            tracer_provider = kwargs.get("tracer_provider") or trace.get_tracer_provider()
            signals = Signals(
                meter=meter_provider.get_meter(INSTRUMENTATION_NAME),
                tracer=tracer_provider.get_tracer(INSTRUMENTATION_NAME),
            )

            _original_failover = ResilientClient.failover
            _original_fan_out = ResilientClient.fan_out
            captured_failover = _original_failover
            captured_fan_out = _original_fan_out

            async def patched_failover(
                self: ResilientClient, request: Request
            ) -> FailoverResult:
                result = await captured_failover(self, request)
                signals.emit_failover(result)
                return result

            async def patched_fan_out(
                self: ResilientClient, request: Request
            ) -> FanOutResult:
                result = await captured_fan_out(self, request)
                signals.emit_fan_out(result)
                return result

            ResilientClient.failover = patched_failover  # type: ignore[method-assign]
            ResilientClient.fan_out = patched_fan_out  # type: ignore[method-assign]

        def _uninstrument(self, **kwargs: Any) -> None:
            global _original_failover, _original_fan_out
            if _original_failover is None:
                return
            ResilientClient.failover = _original_failover  # type: ignore[method-assign]
            ResilientClient.fan_out = _original_fan_out  # type: ignore[method-assign]
            _original_failover = None
            _original_fan_out = None

    __all__ = ["OTelInstrumentor", "is_instrumented"]
else:
    # Lean install: OTelInstrumentor isn't available. The lean path
    # (OTelObservableClient + Signals) is fully usable without it.
    __all__ = ["is_instrumented"]
