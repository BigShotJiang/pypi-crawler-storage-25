# Changelog

All notable changes to `keel-llm-otel` are documented here, following
[Keep a Changelog](https://keepachangelog.com/). In `0.x`; pin exact versions.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- `OTelObservableClient` — pure external wrapper around `ResilientClient` from
  `keel-llm-reliability`. Delegates `failover` / `fan_out` to the inner client,
  then emits OpenTelemetry signals from the returned `Attempt` trail.
- **Metrics** (counter names follow modern OTel convention — no `_total`
  suffix; the Prometheus exporter adds it automatically. The model-name label
  uses OTel's incubating GenAI convention `gen_ai.request.model` so
  reliability-layer dispositions can be joined with adapter-level `gen_ai.*`
  metrics in cross-layer queries):
  - `keel.llm.reliability.attempts` (Counter) — labels `strategy` /
    `gen_ai.request.model` / `outcome` / `error_category`.
  - `keel.llm.reliability.attempt_duration_ms` (Histogram, ms) — labels
    `strategy` / `gen_ai.request.model` / `outcome`.
  - `keel.llm.reliability.calls` (Counter) — labels `strategy` /
    `succeeded` / `degraded`.
- **`Signals` is decoupled from `keel-llm-reliability`'s result types** — the
  canonical entry point is `Signals.emit(*, strategy, attempts, succeeded,
  degraded)` accepting any iterable of `AttemptLike` (a structural Protocol).
  This lets consumers with their own multi-model orchestrator emit on the same
  OTel vocabulary without adopting `keel-llm-reliability`'s `ResilientClient`.
  `emit_failover(result)` / `emit_fan_out(result)` are convenience wrappers.
- **Auto-instrumentation is opt-in via `[auto]`** — lean install:
  `pip install keel-llm-otel` ships `OTelObservableClient` + `Signals` only
  (deps: `keel-llm-reliability` + `opentelemetry-api`). The zero-code-change
  `OTelInstrumentor` path requires `pip install 'keel-llm-otel[auto]'`, which
  adds `opentelemetry-instrumentation` (+ transitive `wrapt`).
- **`[full]` extra — the recommended one-install path for distributed tracing.**
  `pip install 'keel-llm-otel[full]'` adds `opentelemetry-instrumentation-httpx`
  on top of `[auto]`, so a single install gives both reliability-layer signals
  AND per-provider HTTP child spans with `traceparent` injection. Eliminates the
  silent-incomplete-data failure mode where a consumer installs only the
  package and assumes one-package == full tracing.
- **Span events:** if the caller has a current span, each `Attempt` is added as
  a `keel.attempt` event with `keel.strategy`, `keel.model_key`, `keel.outcome`,
  `keel.latency_ms`, `keel.error_category` attributes.
- **Defensive emission:** observability errors are caught and swallowed — never
  propagate; the wrapped call's result is always returned.
- **No double-emit when both paths active:** if a consumer happens to enable
  `OTelInstrumentor` *and* use `OTelObservableClient` together, the subclass
  detects the active instrumentor and skips its own emission so attempts are
  counted exactly once.
- Depends only on `keel-llm-reliability` + `opentelemetry-api` (the consumer
  brings the OTel SDK + exporters). Optional `[sdk]` extra installs the
  reference SDK for tests / one-shot setups.
- PEP 561 `py.typed`; `mypy --strict` clean.

### Notes

- This is a **pure external wrapper**: `keel-llm-reliability` itself stays
  observability-free. The library produces the visible-degradation trail; this
  package consumes it after the call. The same `Attempt` contract is open to
  other backends (Prometheus, Datadog APM, structured-log emitters) — write a
  ~80-LOC wrapper following the same pattern.
- v0 does **not** start new spans. Proper async span-context propagation into
  provider HTTP calls belongs in adapter-level HTTP instrumentation (e.g.
  `opentelemetry-instrumentation-httpx`), not in a reliability-layer wrapper.
