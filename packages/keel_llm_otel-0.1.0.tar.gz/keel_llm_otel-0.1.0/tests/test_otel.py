"""Tests for keel-llm-otel — both seamless paths (drop-in subclass + auto-instrumentor)."""

from __future__ import annotations

import asyncio
from collections.abc import Sequence
from typing import Any

import pytest
from keel_llm_protocol import (
    AdapterResponse,
    HealthStatus,
    Message,
    RateLimitError,
    ResponseFormat,
    user,
)
from keel_llm_reliability import Request, ResilientClient
from opentelemetry import metrics, trace
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
    InMemorySpanExporter,
)

from keel_llm_otel import OTelInstrumentor, OTelObservableClient


# --------------------------------------------------------------------------- #
# Minimal adapter fake
# --------------------------------------------------------------------------- #


def resp(key: str, text: str = "ok") -> AdapterResponse:
    return AdapterResponse(text=text, model_key=key, model_id=key)


class FakeAdapter:
    def __init__(self, key: str, actions: Sequence[AdapterResponse | Exception]) -> None:
        self._key = key
        self._actions = list(actions)
        self.calls = 0

    @property
    def model_key(self) -> str:
        return self._key

    @property
    def capabilities(self) -> frozenset[str]:
        return frozenset()

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        action = self._actions[min(self.calls, len(self._actions) - 1)]
        self.calls += 1
        if isinstance(action, Exception):
            raise action
        return action

    async def health_check(self) -> HealthStatus:
        return HealthStatus(self._key, healthy=True)


REQ = Request(messages=[user("hi")])


# --------------------------------------------------------------------------- #
# Fixtures
# --------------------------------------------------------------------------- #


@pytest.fixture
def otel_env() -> tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer]:
    """Fresh in-memory meter + tracer per test; no global-state pollution."""
    reader = InMemoryMetricReader()
    meter = MeterProvider(metric_readers=[reader]).get_meter("test")

    span_exporter = InMemorySpanExporter()
    tp = TracerProvider()
    tp.add_span_processor(SimpleSpanProcessor(span_exporter))
    tracer = tp.get_tracer("test")
    return reader, meter, span_exporter, tracer


def _collect(reader: InMemoryMetricReader) -> dict[str, list[dict[str, Any]]]:
    data = reader.get_metrics_data()
    out: dict[str, list[dict[str, Any]]] = {}
    if data is None:
        return out
    for rm in data.resource_metrics:
        for sm in rm.scope_metrics:
            for m in sm.metrics:
                pts: list[dict[str, Any]] = []
                for dp in m.data.data_points:
                    v: Any = getattr(dp, "value", None)
                    if v is None:
                        v = getattr(dp, "count", None)
                    pts.append({"labels": dict(dp.attributes), "value": v})
                out[m.name] = pts
    return out


# --------------------------------------------------------------------------- #
# Drop-in subclass (Path 2 — one-word code change)
# --------------------------------------------------------------------------- #


def test_subclass_is_drop_in_for_resilient_client() -> None:
    """OTelObservableClient is a ResilientClient — same constructor + methods."""
    client = OTelObservableClient([FakeAdapter("a", [resp("a")])])
    assert isinstance(client, ResilientClient)
    # default behavior identical
    result = asyncio.run(client.failover(REQ))
    assert result.succeeded and result.response is not None and result.response.model_key == "a"


def test_subclass_emits_attempts_and_call_counters(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    reader, meter, _, tracer = otel_env
    client = OTelObservableClient([FakeAdapter("a", [resp("a")]), FakeAdapter("b", [resp("b")])],
                                  meter=meter, tracer=tracer)
    asyncio.run(client.failover(REQ))

    m = _collect(reader)
    attempts = m["keel.llm.reliability.attempts"]
    assert len(attempts) == 1 and attempts[0]["value"] == 1
    labels = attempts[0]["labels"]
    assert labels["strategy"] == "failover" and labels["outcome"] == "success"
    assert labels["error_category"] == "none"
    # OTel gen_ai convention: model label name aligns for cross-layer queries.
    assert labels["gen_ai.request.model"] == "a"

    calls = m["keel.llm.reliability.calls"]
    assert calls[0]["labels"]["succeeded"] is True
    assert calls[0]["labels"]["degraded"] is False

    assert m["keel.llm.reliability.attempt_duration_ms"][0]["value"] == 1


def test_subclass_fan_out_with_degradation(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    reader, meter, _, _ = otel_env
    client = OTelObservableClient(
        [FakeAdapter("a", [resp("a")]), FakeAdapter("b", [RateLimitError("429")])],
        meter=meter,
    )
    result = asyncio.run(client.fan_out(REQ))
    assert len(result.successes) == 1 and result.degraded is True

    attempts = _collect(reader)["keel.llm.reliability.attempts"]
    outcomes = {p["labels"]["outcome"] for p in attempts}
    assert outcomes == {"success", "deferred_backpressure"}
    for p in attempts:
        if p["labels"]["outcome"] == "deferred_backpressure":
            assert p["labels"]["error_category"] == "backpressure"


def test_subclass_adds_span_events_to_caller_span(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    _, meter, span_exporter, caller_tracer = otel_env
    client = OTelObservableClient([FakeAdapter("a", [resp("a")])], meter=meter, tracer=caller_tracer)

    async def run() -> None:
        with caller_tracer.start_as_current_span("llm.call"):
            await client.failover(REQ)

    asyncio.run(run())
    spans = span_exporter.get_finished_spans()
    assert len(spans) == 1
    events = [e for e in spans[0].events if e.name == "keel.attempt"]
    assert len(events) == 1
    attrs = dict(events[0].attributes or {})
    assert attrs["keel.outcome"] == "success"
    assert attrs["gen_ai.request.model"] == "a"


def test_emit_errors_are_swallowed() -> None:
    """If emission blows up, the call still returns its result."""

    class ExplodingMeter:
        def create_counter(self, *a: Any, **kw: Any) -> Any:
            class _C:
                def add(self, *args: Any, **kwargs: Any) -> None:
                    raise RuntimeError("boom")
            return _C()

        def create_histogram(self, *a: Any, **kw: Any) -> Any:
            class _H:
                def record(self, *args: Any, **kwargs: Any) -> None:
                    raise RuntimeError("boom")
            return _H()

    client = OTelObservableClient([FakeAdapter("a", [resp("a")])], meter=ExplodingMeter())  # type: ignore[arg-type]
    result = asyncio.run(client.failover(REQ))
    assert result.succeeded


# --------------------------------------------------------------------------- #
# Auto-instrumentor (Path 1 — zero code change)
# --------------------------------------------------------------------------- #


def test_instrumentor_patches_resilient_client_zero_code_change(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    """After OTelInstrumentor().instrument(), an *unmodified* ResilientClient
    call emits OTel signals. The consumer's code is unchanged."""
    reader, meter, _, tracer = otel_env

    # Build a meter/tracer provider whose meter is the one wired to our reader.
    class _MP:
        def get_meter(self, name: str) -> metrics.Meter:
            return meter

    class _TP:
        def get_tracer(self, name: str) -> trace.Tracer:
            return tracer

    instrumentor = OTelInstrumentor()
    instrumentor.instrument(meter_provider=_MP(), tracer_provider=_TP())
    try:
        # Plain ResilientClient — no Keel-otel import in the consumer's call:
        plain_client = ResilientClient([FakeAdapter("a", [resp("a")])])
        result = asyncio.run(plain_client.failover(REQ))
        assert result.succeeded

        # Signals emitted from the *patched* method:
        attempts = _collect(reader)["keel.llm.reliability.attempts"]
        assert len(attempts) == 1
        assert attempts[0]["labels"]["strategy"] == "failover"
        assert attempts[0]["labels"]["outcome"] == "success"
    finally:
        instrumentor.uninstrument()


def test_no_double_emit_when_both_paths_active(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    """Regression guard: if a consumer accidentally enables both the
    auto-instrumentor *and* uses OTelObservableClient, attempts must be counted
    exactly once — the subclass detects the active instrumentor and skips its
    own emission so only the patched parent emits.
    """
    reader, meter, _, _ = otel_env

    class _MP:
        def get_meter(self, name: str) -> metrics.Meter:
            return meter

    inst = OTelInstrumentor()
    inst.instrument(meter_provider=_MP())
    try:
        # subclass + instrumentor both active, both pointed at the same meter
        client = OTelObservableClient([FakeAdapter("a", [resp("a")])], meter=meter)
        asyncio.run(client.failover(REQ))

        attempts = _collect(reader)["keel.llm.reliability.attempts"]
        total = sum(p["value"] for p in attempts)
        assert total == 1, f"expected exactly one attempt counted, got {total} (double-emit)"
    finally:
        inst.uninstrument()


def test_uninstrument_restores_originals() -> None:
    instrumentor = OTelInstrumentor()
    pristine_failover = ResilientClient.failover
    pristine_fan_out = ResilientClient.fan_out

    instrumentor.instrument()
    assert ResilientClient.failover is not pristine_failover  # patched

    instrumentor.uninstrument()
    assert ResilientClient.failover is pristine_failover  # restored
    assert ResilientClient.fan_out is pristine_fan_out


# --------------------------------------------------------------------------- #
# Re-entrancy regression tests (requested in the bridge bars-check)
# --------------------------------------------------------------------------- #


def test_instrument_called_twice_is_a_noop() -> None:
    """Calling .instrument() twice doesn't double-patch — second call is a no-op
    (matches the behaviour of every other OTel instrumentation package)."""
    instrumentor = OTelInstrumentor()
    pristine = ResilientClient.failover
    instrumentor.instrument()
    after_first = ResilientClient.failover
    instrumentor.instrument()  # second call
    after_second = ResilientClient.failover
    try:
        assert after_first is not pristine        # first call patched
        assert after_second is after_first         # second call DID NOT re-wrap
    finally:
        instrumentor.uninstrument()


def test_subclass_works_constructed_both_before_and_after_instrument(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    """OTelObservableClient instances constructed before or after instrument()
    both still emit exactly once per call (the auto-skip is checked at call
    time, not construction time)."""
    reader, meter, _, _ = otel_env

    class _MP:
        def get_meter(self, name: str) -> metrics.Meter:
            return meter

    client_before = OTelObservableClient([FakeAdapter("a", [resp("a")])], meter=meter)
    instrumentor = OTelInstrumentor()
    instrumentor.instrument(meter_provider=_MP())
    try:
        client_after = OTelObservableClient([FakeAdapter("b", [resp("b")])], meter=meter)
        asyncio.run(client_before.failover(REQ))
        asyncio.run(client_after.failover(REQ))
        attempts = _collect(reader)["keel.llm.reliability.attempts"]
        total = sum(p["value"] for p in attempts)
        # Two calls × one attempt each = 2, NOT 4 (double-emit guard works for
        # both pre- and post-construction subclass instances).
        assert total == 2, f"expected 2 attempts, got {total}"
    finally:
        instrumentor.uninstrument()


def test_subclass_of_otel_observable_client_still_works(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    """Consumers can subclass OTelObservableClient further (e.g. to add their
    own behaviour) without breaking emission."""
    reader, meter, _, _ = otel_env

    class TaggedClient(OTelObservableClient):
        async def failover(self, request: Request) -> Any:
            # consumer override pre-processes; still calls super for emission
            return await super().failover(request)

    client = TaggedClient([FakeAdapter("a", [resp("a")])], meter=meter)
    asyncio.run(client.failover(REQ))
    attempts = _collect(reader)["keel.llm.reliability.attempts"]
    assert sum(p["value"] for p in attempts) == 1


# --------------------------------------------------------------------------- #
# Decoupled consumer (Q4 — Signals.emit accepts AttemptLike from any source)
# --------------------------------------------------------------------------- #


def test_signals_emit_accepts_structural_attempts_without_keel_reliability(
    otel_env: tuple[InMemoryMetricReader, metrics.Meter, InMemorySpanExporter, trace.Tracer],
) -> None:
    """A consumer with their own orchestrator can build their own attempts trail
    and emit on the same OTel vocabulary — no keel-llm-reliability dep at the
    consumption point.
    """
    from dataclasses import dataclass

    from keel_llm_otel import AttemptLike, ErrorLike, Signals

    reader, meter, _, _ = otel_env

    # A consumer's own attempt shape — *not* keel_llm_reliability.Attempt.
    @dataclass
    class _ConsumerError:
        category: str  # satisfies ErrorLike structurally

    @dataclass
    class _ConsumerAttempt:
        model_key: str
        outcome: str
        latency_ms: int
        error: _ConsumerError | None = None

    sample: _ConsumerAttempt = _ConsumerAttempt("gpt-4o", "success", 120)
    assert isinstance(sample, AttemptLike)  # structural conformance at runtime

    signals = Signals(meter=meter)
    signals.emit(
        strategy="my_orchestrator",
        attempts=[
            _ConsumerAttempt("gpt-4o", "success", 120),
            _ConsumerAttempt("claude-sonnet", "deferred_backpressure", 45,
                             error=_ConsumerError(category="backpressure")),
        ],
        succeeded=True,
        degraded=True,
    )

    metrics_data = _collect(reader)
    attempts = metrics_data["keel.llm.reliability.attempts"]
    outcomes = {p["labels"]["outcome"] for p in attempts}
    models = {p["labels"]["gen_ai.request.model"] for p in attempts}
    strategies = {p["labels"]["strategy"] for p in attempts}
    assert outcomes == {"success", "deferred_backpressure"}
    assert models == {"gpt-4o", "claude-sonnet"}
    assert strategies == {"my_orchestrator"}     # consumer's strategy name passes through
