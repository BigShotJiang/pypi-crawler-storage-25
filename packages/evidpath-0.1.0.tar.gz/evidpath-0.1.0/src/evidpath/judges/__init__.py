"""Judge implementations and interfaces."""
