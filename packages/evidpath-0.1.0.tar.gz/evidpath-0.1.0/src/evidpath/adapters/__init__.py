"""Adapter implementations and interfaces."""
