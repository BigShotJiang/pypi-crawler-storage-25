"""Recommender-domain plug-in definition and owned seams."""

from __future__ import annotations

from dataclasses import replace

from ...regression_policy import default_regression_policy
from ...schema import RegressionPolicyOverride, RunConfig, RunResult, ScenarioConfig
from ..base import (
    DomainDefinition,
    DomainGenerationHooks,
    ResolvedRuntimeInputs,
    StandardDomainRunner,
)
from .adapters import HttpRecommenderAdapter
from .analyzer import RecommenderAnalyzer
from .generation import (
    build_fixture_recommender_population_candidates,
    build_fixture_recommender_scenarios,
    build_recommender_population_brief_clarification,
    build_recommender_population_generation_prompt,
    build_recommender_scenario_brief_clarification,
    build_recommender_scenario_generation_prompt,
    select_recommender_population_personas,
)
from .inputs import resolve_recommender_inputs
from .judge import RecommenderJudge
from .policy import RecommenderAgentPolicy
from .reference_recommender import run_reference_recommender_service
from .reporting import (
    RECOMMENDER_REPORTING_HOOKS,
    build_recommender_regression_important_changes,
    build_recommender_regression_summary,
    build_recommender_run_executive_summary,
    select_recommender_representative_cohorts,
)
from .services import (
    build_recommender_target_audit_kwargs,
    build_recommender_target_identity,
    check_recommender_target,
    open_recommender_service_context,
)

_AUDIT_TITLE = "Evidpath Recommender Audit"
_REGRESSION_TITLE = "Evidpath Regression Audit"
_SUMMARY_METRICS = (
    "mean_session_utility",
    "abandonment_rate",
    "mean_engagement",
    "mean_frustration",
    "mean_trust_delta",
    "mean_skip_rate",
    "mean_first_impression_score",
    "mean_exploration_acceptance_rate",
    "mean_abandonment_pressure",
    "mean_cold_start_quality",
    "high_risk_cohort_count",
)


def build_recommender_domain_definition() -> DomainDefinition:
    """Build the in-repo plug-in definition for the recommender wedge."""
    definition = DomainDefinition(
        name="recommender",
        audit_report_title=_AUDIT_TITLE,
        regression_report_title=_REGRESSION_TITLE,
        resolve_inputs=resolve_recommender_inputs,
        build_run_config=build_recommender_run_config,
        build_target_identity=build_recommender_target_identity,
        build_target_audit_kwargs=build_recommender_target_audit_kwargs,
        check_target=check_recommender_target,
        build_runtime_scenarios=build_recommender_runtime_scenarios,
        open_service_context=open_recommender_service_context,
        build_adapter=build_recommender_adapter,
        build_policy=RecommenderAgentPolicy,
        build_judge=RecommenderJudge,
        build_analyzer=RecommenderAnalyzer,
        summary_metric_names=_SUMMARY_METRICS,
        summarize_run_metrics=summarize_recommender_run_metrics,
        build_default_regression_policy=build_recommender_default_regression_policy,
        generation_hooks=DomainGenerationHooks(
            build_scenario_brief_clarification=build_recommender_scenario_brief_clarification,
            build_fixture_scenarios=build_fixture_recommender_scenarios,
            build_scenario_prompt=build_recommender_scenario_generation_prompt,
            build_population_brief_clarification=build_recommender_population_brief_clarification,
            build_fixture_population_candidates=build_fixture_recommender_population_candidates,
            build_population_prompt=build_recommender_population_generation_prompt,
            select_population_personas=select_recommender_population_personas,
        ),
        run_reference_service=run_reference_recommender_service,
        reporting_hooks=RECOMMENDER_REPORTING_HOOKS,
        build_run_executive_summary=build_recommender_run_executive_summary,
        select_representative_cohorts=select_recommender_representative_cohorts,
        build_regression_summary=build_recommender_regression_summary,
        build_regression_important_changes=build_recommender_regression_important_changes,
        runner=None,
    )
    return replace(definition, runner=StandardDomainRunner(definition=definition))


def build_recommender_run_config(
    *,
    seed: int = 0,
    output_dir: str | None = None,
    scenario_names: tuple[str, ...] | None = None,
    scenario_pack_path: str | None = None,
    population_pack_path: str | None = None,
    service_mode: str = "reference",
    service_artifact_dir: str | None = None,
    adapter_base_url: str | None = None,
    run_name: str | None = None,
) -> tuple[RunConfig, ResolvedRuntimeInputs]:
    """Resolve recommender runtime inputs, then build a run config from them."""
    from ...config import build_run_config
    from .reference_artifacts import DEFAULT_REFERENCE_ARTIFACT_DIR

    resolved_inputs = resolve_recommender_inputs(
        scenario_names=scenario_names,
        scenario_pack_path=scenario_pack_path,
        population_pack_path=population_pack_path,
    )
    resolved_service_artifact_dir = service_artifact_dir
    if service_mode == "reference" and service_artifact_dir is None:
        resolved_service_artifact_dir = str(DEFAULT_REFERENCE_ARTIFACT_DIR)
    run_config = build_run_config(
        seed=seed,
        output_dir=output_dir,
        scenarios=resolved_inputs.scenarios,
        agent_seeds=resolved_inputs.agent_seeds,
        service_mode=service_mode,
        service_artifact_dir=resolved_service_artifact_dir,
        adapter_base_url=adapter_base_url,
        run_name=run_name,
    )
    return run_config, resolved_inputs


def build_recommender_runtime_scenarios(
    scenario_configs: tuple[ScenarioConfig, ...]
) -> tuple:
    """Build runtime recommender scenarios from saved or built-in configs."""
    from .scenarios import build_scenarios

    return build_scenarios(scenario_configs)


def build_recommender_adapter(base_url: str, timeout_seconds: float) -> HttpRecommenderAdapter:
    """Build the recommender adapter for one running target endpoint."""
    return HttpRecommenderAdapter(base_url, timeout_seconds=timeout_seconds)


def summarize_recommender_run_metrics(run_result: RunResult) -> dict[str, float]:
    """Extract the recommender summary metrics used by reruns and diffs."""
    trace_scores = run_result.trace_scores
    cohort_summaries = run_result.cohort_summaries
    return {
        "mean_session_utility": _mean(score.session_utility for score in trace_scores),
        "abandonment_rate": _mean(1.0 if score.abandoned else 0.0 for score in trace_scores),
        "mean_engagement": _mean(score.engagement for score in trace_scores),
        "mean_frustration": _mean(score.frustration for score in trace_scores),
        "mean_trust_delta": _mean(score.trust_delta for score in trace_scores),
        "mean_skip_rate": _mean(score.skip_rate for score in trace_scores),
        "mean_first_impression_score": _mean(
            score.first_impression_score for score in trace_scores
        ),
        "mean_exploration_acceptance_rate": _mean(
            score.exploration_acceptance_rate for score in trace_scores
        ),
        "mean_abandonment_pressure": _mean(
            score.abandonment_pressure for score in trace_scores
        ),
        "mean_cold_start_quality": _mean(score.cold_start_quality for score in trace_scores),
        "high_risk_cohort_count": float(
            sum(1 for cohort in cohort_summaries if cohort.risk_level == "high")
        ),
    }


def build_recommender_default_regression_policy(
    metric_overrides: tuple[RegressionPolicyOverride, ...] = (),
    cohort_overrides: tuple[RegressionPolicyOverride, ...] = (),
):
    """Return the recommender-owned default regression policy."""
    return default_regression_policy(
        metric_overrides=metric_overrides,
        cohort_overrides=cohort_overrides,
    )


def _mean(values) -> float:
    values = tuple(values)
    if not values:
        return 0.0
    return sum(values) / len(values)
