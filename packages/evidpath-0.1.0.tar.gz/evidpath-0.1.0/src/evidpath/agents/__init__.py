"""Agent implementations and interfaces."""
