"""Scenario implementations and interfaces."""
