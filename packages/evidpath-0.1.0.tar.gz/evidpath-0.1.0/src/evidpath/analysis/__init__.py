"""Analysis implementations and interfaces."""
