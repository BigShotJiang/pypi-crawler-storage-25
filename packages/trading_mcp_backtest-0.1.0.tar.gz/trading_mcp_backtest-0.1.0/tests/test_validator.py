"""Tests for the AST-based security validator.

This is the most security-critical component. Every blocked pattern
must be tested to ensure the validator catches it.
"""

import pytest

from trading_mcp_shared.errors import SandboxError

from backtest_server.validator import (
    assert_safe,
    validate_strategy_code,
)


# ═══════════════════════════════════════════════════════════════════
# Safe code — should pass validation
# ═══════════════════════════════════════════════════════════════════


class TestSafeCode:
    def test_allowed_imports(self):
        code = """
import pandas as pd
import numpy as np
import vectorbt as vbt
import math
import datetime
import json
"""
        assert validate_strategy_code(code) == []

    def test_allowed_from_imports(self):
        code = """
from pandas import DataFrame
from numpy import array
from datetime import datetime, timedelta
from math import sqrt
from collections import defaultdict
"""
        assert validate_strategy_code(code) == []

    def test_basic_strategy(self):
        code = """
import pandas as pd
import numpy as np

def strategy(prices):
    sma_20 = prices.rolling(20).mean()
    sma_50 = prices.rolling(50).mean()
    signal = (sma_20 > sma_50).astype(int)
    return signal
"""
        assert validate_strategy_code(code) == []

    def test_vectorbt_strategy(self):
        code = """
import vectorbt as vbt
import pandas as pd

close = pd.Series([100, 102, 101, 105, 103])
portfolio = vbt.Portfolio.from_signals(close, entries=[True, False, True, False, False],
                                        exits=[False, True, False, True, False])
result = portfolio.total_return()
"""
        assert validate_strategy_code(code) == []

    def test_empty_code(self):
        assert validate_strategy_code("") == []

    def test_pure_math(self):
        code = """
x = 42
y = x * 2 + 10
result = [i ** 2 for i in range(10)]
"""
        assert validate_strategy_code(code) == []

    def test_allowed_ta_library(self):
        code = "import ta"
        assert validate_strategy_code(code) == []

    def test_typing_imports(self):
        code = "from typing import List, Dict, Optional"
        assert validate_strategy_code(code) == []


# ═══════════════════════════════════════════════════════════════════
# Blocked imports — must be rejected
# ═══════════════════════════════════════════════════════════════════


class TestBlockedImports:
    def test_os_import(self):
        violations = validate_strategy_code("import os")
        assert len(violations) == 1
        assert "os" in violations[0]

    def test_sys_import(self):
        violations = validate_strategy_code("import sys")
        assert len(violations) == 1

    def test_subprocess_import(self):
        violations = validate_strategy_code("import subprocess")
        assert len(violations) == 1

    def test_socket_import(self):
        violations = validate_strategy_code("import socket")
        assert len(violations) == 1

    def test_requests_import(self):
        violations = validate_strategy_code("import requests")
        assert len(violations) == 1

    def test_urllib_import(self):
        violations = validate_strategy_code("import urllib")
        assert len(violations) == 1

    def test_http_import(self):
        violations = validate_strategy_code("import http")
        assert len(violations) == 1

    def test_pickle_import(self):
        violations = validate_strategy_code("import pickle")
        assert len(violations) == 1

    def test_ctypes_import(self):
        violations = validate_strategy_code("import ctypes")
        assert len(violations) == 1

    def test_importlib_import(self):
        violations = validate_strategy_code("import importlib")
        assert len(violations) == 1

    def test_builtins_import(self):
        violations = validate_strategy_code("import builtins")
        assert len(violations) == 1

    def test_from_os_import(self):
        violations = validate_strategy_code("from os import system")
        assert len(violations) == 1

    def test_from_subprocess_import(self):
        violations = validate_strategy_code("from subprocess import run")
        assert len(violations) == 1

    def test_multiple_blocked_imports(self):
        code = """
import os
import sys
import subprocess
"""
        violations = validate_strategy_code(code)
        assert len(violations) == 3

    def test_blocked_submodule(self):
        violations = validate_strategy_code("import os.path")
        assert len(violations) == 1
        assert "os" in violations[0]


# ═══════════════════════════════════════════════════════════════════
# Blocked builtins — must be rejected
# ═══════════════════════════════════════════════════════════════════


class TestBlockedBuiltins:
    def test_eval(self):
        violations = validate_strategy_code("eval('1+1')")
        assert len(violations) == 1
        assert "eval" in violations[0]

    def test_exec(self):
        violations = validate_strategy_code("exec('x = 1')")
        assert len(violations) == 1
        assert "exec" in violations[0]

    def test_compile(self):
        violations = validate_strategy_code("compile('x=1', '<string>', 'exec')")
        assert len(violations) == 1

    def test_dunder_import(self):
        violations = validate_strategy_code("__import__('os')")
        assert len(violations) == 1

    def test_open(self):
        violations = validate_strategy_code("open('/etc/passwd')")
        assert len(violations) == 1
        assert "open" in violations[0]

    def test_input(self):
        violations = validate_strategy_code("input('prompt')")
        assert len(violations) == 1

    def test_breakpoint(self):
        violations = validate_strategy_code("breakpoint()")
        assert len(violations) == 1

    def test_globals_call(self):
        violations = validate_strategy_code("globals()")
        assert len(violations) == 1

    def test_locals_call(self):
        violations = validate_strategy_code("locals()")
        assert len(violations) == 1


# ═══════════════════════════════════════════════════════════════════
# Blocked attribute access — must be rejected
# ═══════════════════════════════════════════════════════════════════


class TestBlockedAttributes:
    def test_subclasses(self):
        violations = validate_strategy_code("x.__subclasses__()")
        assert len(violations) >= 1

    def test_bases(self):
        violations = validate_strategy_code("x.__bases__")
        assert len(violations) >= 1

    def test_globals_attr(self):
        violations = validate_strategy_code("func.__globals__")
        assert len(violations) >= 1

    def test_code_attr(self):
        violations = validate_strategy_code("func.__code__")
        assert len(violations) >= 1

    def test_builtins_attr(self):
        violations = validate_strategy_code("x.__builtins__")
        assert len(violations) >= 1


# ═══════════════════════════════════════════════════════════════════
# Syntax errors
# ═══════════════════════════════════════════════════════════════════


class TestSyntaxErrors:
    def test_invalid_syntax(self):
        with pytest.raises(SandboxError, match="Syntax error"):
            validate_strategy_code("def foo(:")

    def test_syntax_error_in_assert_safe(self):
        with pytest.raises(SandboxError, match="Syntax error"):
            assert_safe("if while for:")


# ═══════════════════════════════════════════════════════════════════
# assert_safe integration
# ═══════════════════════════════════════════════════════════════════


class TestAssertSafe:
    def test_safe_code_passes(self):
        assert_safe("import pandas as pd\nx = 1 + 2")

    def test_unsafe_code_raises(self):
        with pytest.raises(SandboxError, match="rejected"):
            assert_safe("import os")

    def test_multiple_violations(self):
        with pytest.raises(SandboxError, match="rejected"):
            assert_safe("import os\nimport sys\neval('x')")


# ═══════════════════════════════════════════════════════════════════
# Edge cases
# ═══════════════════════════════════════════════════════════════════


class TestEdgeCases:
    def test_allowed_module_as_variable(self):
        # Using 'os' as a variable name is fine — only imports are blocked
        code = "os = 42"
        assert validate_strategy_code(code) == []

    def test_string_containing_blocked_import(self):
        # Blocked import inside a string literal is fine
        code = "x = 'import os'"
        assert validate_strategy_code(code) == []

    def test_comment_containing_blocked_import(self):
        code = "# import os\nx = 1"
        assert validate_strategy_code(code) == []

    def test_nested_function_with_blocked_call(self):
        code = """
def sneaky():
    return eval("1+1")
"""
        violations = validate_strategy_code(code)
        assert len(violations) == 1
