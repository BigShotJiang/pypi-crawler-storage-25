"""Tests for the Docker sandbox module.

These tests mock Docker subprocess calls — no actual Docker required.
"""

import asyncio
import json

import pytest

from trading_mcp_shared.errors import SandboxError

from backtest_server.sandbox import check_docker, check_sandbox_image, run_in_sandbox


class TestCheckDocker:
    @pytest.mark.asyncio
    async def test_docker_available(self, monkeypatch):
        monkeypatch.setattr(
            "backtest_server.sandbox.shutil.which", lambda x: "/usr/bin/docker"
        )

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def wait(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_docker() is True

    @pytest.mark.asyncio
    async def test_docker_not_installed(self, monkeypatch):
        monkeypatch.setattr("backtest_server.sandbox.shutil.which", lambda x: None)
        assert await check_docker() is False

    @pytest.mark.asyncio
    async def test_docker_not_running(self, monkeypatch):
        monkeypatch.setattr(
            "backtest_server.sandbox.shutil.which", lambda x: "/usr/bin/docker"
        )

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 1

                async def wait(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_docker() is False


class TestCheckSandboxImage:
    @pytest.mark.asyncio
    async def test_image_exists(self, monkeypatch):
        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def wait(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_sandbox_image() is True

    @pytest.mark.asyncio
    async def test_image_missing(self, monkeypatch):
        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 1

                async def wait(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_sandbox_image() is False


class TestRunInSandbox:
    @pytest.mark.asyncio
    async def test_no_docker_raises(self, monkeypatch):
        monkeypatch.setattr(
            "backtest_server.sandbox.check_docker",
            lambda: asyncio.coroutine(lambda: False)(),
        )

        async def _no_docker():
            return False

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _no_docker)

        with pytest.raises(SandboxError, match="Docker is not available"):
            await run_in_sandbox(
                "x=1", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_no_image_raises(self, monkeypatch):
        async def _yes():
            return True

        async def _no():
            return False

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _no)

        with pytest.raises(SandboxError, match="Sandbox image"):
            await run_in_sandbox(
                "x=1", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_successful_execution(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        result_data = {
            "totalReturn": 15.5,
            "sharpeRatio": 1.2,
            "maxDrawdown": -8.3,
            "totalTrades": 24,
            "winRate": 58.3,
        }

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def communicate(self):
                    return json.dumps(result_data).encode(), b""

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        result = await run_in_sandbox(
            "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
        )
        assert result["totalReturn"] == 15.5
        assert result["sharpeRatio"] == 1.2

    @pytest.mark.asyncio
    async def test_container_error(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 1

                async def communicate(self):
                    return b"", b"Strategy raised ValueError: invalid data"

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        with pytest.raises(SandboxError, match="ValueError"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_timeout(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = None

                async def communicate(self):
                    await asyncio.sleep(100)  # Will be cancelled by timeout

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        # Override timeout to make test fast
        monkeypatch.setattr("backtest_server.sandbox.DOCKER_TIMEOUT", 0)

        with pytest.raises(SandboxError, match="timed out"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_invalid_json_output(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def communicate(self):
                    return b"not json at all", b""

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        with pytest.raises(SandboxError, match="not valid JSON"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_empty_output(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 0

                async def communicate(self):
                    return b"", b""

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        with pytest.raises(SandboxError, match="no output"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_docker_oserror(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            raise OSError("Docker socket not found")

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        with pytest.raises(SandboxError, match="Failed to start Docker"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_container_error_no_stderr(self, monkeypatch):
        async def _yes():
            return True

        monkeypatch.setattr("backtest_server.sandbox.check_docker", _yes)
        monkeypatch.setattr("backtest_server.sandbox.check_sandbox_image", _yes)

        async def mock_create(*args, **kwargs):
            class FakeProc:
                returncode = 137

                async def communicate(self):
                    return b"", b""

                def kill(self):
                    pass

            return FakeProc()

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )

        with pytest.raises(SandboxError, match="exited with code 137"):
            await run_in_sandbox(
                "import pandas", "AAPL", "2023-01-01", "2024-01-01", 10000, 0.001
            )

    @pytest.mark.asyncio
    async def test_check_docker_oserror(self, monkeypatch):
        monkeypatch.setattr(
            "backtest_server.sandbox.shutil.which", lambda x: "/usr/bin/docker"
        )

        async def mock_create(*args, **kwargs):
            raise OSError("connection refused")

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_docker() is False

    @pytest.mark.asyncio
    async def test_check_sandbox_image_oserror(self, monkeypatch):
        async def mock_create(*args, **kwargs):
            raise OSError("connection refused")

        monkeypatch.setattr(
            "backtest_server.sandbox.asyncio.create_subprocess_exec",
            mock_create,
        )
        assert await check_sandbox_image() is False
