"""Tests for the 3 Backtest MCP tools."""

import pytest

from trading_mcp_shared.errors import SandboxError

from backtest_server.server import (
    _backtests,
    compare_backtests,
    list_backtests,
    run_backtest,
)


# ── Helpers ──────────────────────────────────────────────────────

_SAFE_STRATEGY = """
import pandas as pd
import numpy as np

def strategy(prices):
    sma = prices.rolling(20).mean()
    return (prices > sma).astype(int)
"""

_MOCK_RESULT = {
    "totalReturn": 15.5,
    "cagr": 12.1,
    "sharpeRatio": 1.2,
    "maxDrawdown": -8.3,
    "winRate": 58.3,
    "totalTrades": 24,
    "benchmarkReturn": 10.2,
    "equityCurve": [{"date": "2023-01-01", "value": 10000}],
    "trades": [
        {"date": "2023-03-15", "action": "buy", "price": 150.0, "shares": 10, "pnl": 0}
    ],
}


@pytest.fixture()
def mock_sandbox(monkeypatch):
    """Mock the sandbox to return a successful result."""

    async def _mock_run_in_sandbox(
        strategy_code, symbol, start_date, end_date, initial_capital, commission
    ):
        return dict(_MOCK_RESULT)

    monkeypatch.setattr("backtest_server.server.run_in_sandbox", _mock_run_in_sandbox)


@pytest.fixture()
def mock_sandbox_error(monkeypatch):
    """Mock the sandbox to raise a SandboxError."""

    async def _mock_run_in_sandbox(*args, **kwargs):
        raise SandboxError("Docker is not available")

    monkeypatch.setattr("backtest_server.server.run_in_sandbox", _mock_run_in_sandbox)


# ═══════════════════════════════════════════════════════════════════
# Tool 1: run_backtest
# ═══════════════════════════════════════════════════════════════════


class TestRunBacktest:
    @pytest.mark.asyncio
    async def test_run_backtest_happy_path(self, mock_sandbox):
        result = await run_backtest("AAPL", _SAFE_STRATEGY)
        assert "id" in result
        assert result["symbol"] == "AAPL"
        assert result["totalReturn"] == 15.5
        assert result["sharpeRatio"] == 1.2
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_run_backtest_stores_in_session(self, mock_sandbox):
        result = await run_backtest("AAPL", _SAFE_STRATEGY)
        assert result["id"] in _backtests

    @pytest.mark.asyncio
    async def test_run_backtest_invalid_symbol(self):
        result = await run_backtest("", _SAFE_STRATEGY)
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_run_backtest_empty_strategy(self):
        result = await run_backtest("AAPL", "")
        assert "error" in result
        assert "required" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_run_backtest_unsafe_strategy(self):
        result = await run_backtest("AAPL", "import os; os.system('rm -rf /')")
        assert "error" in result
        assert "rejected" in result["error"]

    @pytest.mark.asyncio
    async def test_run_backtest_blocked_eval(self):
        result = await run_backtest("AAPL", "eval('1+1')")
        assert "error" in result
        assert "rejected" in result["error"]

    @pytest.mark.asyncio
    async def test_run_backtest_blocked_open(self):
        result = await run_backtest("AAPL", "open('/etc/passwd')")
        assert "error" in result
        assert "rejected" in result["error"]

    @pytest.mark.asyncio
    async def test_run_backtest_sandbox_error(self, mock_sandbox_error):
        result = await run_backtest("AAPL", _SAFE_STRATEGY)
        assert "error" in result
        assert "Docker" in result["error"]

    @pytest.mark.asyncio
    async def test_run_backtest_custom_params(self, mock_sandbox):
        result = await run_backtest(
            "MSFT",
            _SAFE_STRATEGY,
            start_date="2022-01-01",
            end_date="2023-12-31",
            initial_capital=50000,
            commission=0.002,
        )
        assert result["symbol"] == "MSFT"
        assert result["initialCapital"] == 50000
        assert result["commission"] == 0.002

    @pytest.mark.asyncio
    async def test_run_backtest_relative_dates(self, mock_sandbox):
        result = await run_backtest("AAPL", _SAFE_STRATEGY, start_date="1y")
        assert "error" not in result
        assert result["startDate"]  # Should be resolved

    @pytest.mark.asyncio
    async def test_run_backtest_syntax_error(self):
        result = await run_backtest("AAPL", "def foo(:")
        assert "error" in result


# ═══════════════════════════════════════════════════════════════════
# Tool 2: list_backtests
# ═══════════════════════════════════════════════════════════════════


class TestListBacktests:
    @pytest.mark.asyncio
    async def test_list_empty(self):
        result = await list_backtests()
        assert result["backtests"] == []
        assert result["count"] == 0

    @pytest.mark.asyncio
    async def test_list_after_runs(self, mock_sandbox):
        await run_backtest("AAPL", _SAFE_STRATEGY)
        await run_backtest("MSFT", _SAFE_STRATEGY)
        result = await list_backtests()
        assert result["count"] == 2
        assert len(result["backtests"]) == 2
        symbols = {bt["symbol"] for bt in result["backtests"]}
        assert symbols == {"AAPL", "MSFT"}

    @pytest.mark.asyncio
    async def test_list_includes_summary_fields(self, mock_sandbox):
        await run_backtest("AAPL", _SAFE_STRATEGY)
        result = await list_backtests()
        bt = result["backtests"][0]
        assert "id" in bt
        assert "symbol" in bt
        assert "strategy_desc" in bt
        assert "totalReturn" in bt
        assert "sharpeRatio" in bt
        assert "ranAt" in bt


# ═══════════════════════════════════════════════════════════════════
# Tool 3: compare_backtests
# ═══════════════════════════════════════════════════════════════════


class TestCompareBacktests:
    @pytest.mark.asyncio
    async def test_compare_happy_path(self, mock_sandbox):
        r1 = await run_backtest("AAPL", _SAFE_STRATEGY)
        r2 = await run_backtest("MSFT", _SAFE_STRATEGY)
        result = await compare_backtests([r1["id"], r2["id"]])
        assert "comparison" in result
        assert len(result["comparison"]) == 2
        assert "winner" in result
        assert "error" not in result

    @pytest.mark.asyncio
    async def test_compare_too_few_ids(self):
        result = await compare_backtests(["abc"])
        assert "error" in result
        assert "At least 2" in result["error"]

    @pytest.mark.asyncio
    async def test_compare_empty_ids(self):
        result = await compare_backtests([])
        assert "error" in result

    @pytest.mark.asyncio
    async def test_compare_too_many_ids(self):
        result = await compare_backtests(["a", "b", "c", "d", "e", "f"])
        assert "error" in result
        assert "Maximum 5" in result["error"]

    @pytest.mark.asyncio
    async def test_compare_missing_ids(self, mock_sandbox):
        r1 = await run_backtest("AAPL", _SAFE_STRATEGY)
        result = await compare_backtests([r1["id"], "nonexistent"])
        assert "error" in result
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_compare_winner_by_sharpe(self, mock_sandbox, monkeypatch):
        # Run two backtests with different Sharpe ratios
        r1 = await run_backtest("AAPL", _SAFE_STRATEGY)

        # Modify the second result to have a higher Sharpe
        better_result = dict(_MOCK_RESULT, sharpeRatio=2.5)

        async def _mock_better(*args, **kwargs):
            return dict(better_result)

        monkeypatch.setattr("backtest_server.server.run_in_sandbox", _mock_better)

        r2 = await run_backtest("MSFT", _SAFE_STRATEGY)
        result = await compare_backtests([r1["id"], r2["id"]])
        assert result["winner"]["id"] == r2["id"]
        assert result["winner"]["sharpeRatio"] == 2.5

    @pytest.mark.asyncio
    async def test_compare_includes_metrics(self, mock_sandbox):
        r1 = await run_backtest("AAPL", _SAFE_STRATEGY)
        r2 = await run_backtest("MSFT", _SAFE_STRATEGY)
        result = await compare_backtests([r1["id"], r2["id"]])
        for entry in result["comparison"]:
            assert "totalReturn" in entry
            assert "sharpeRatio" in entry
            assert "maxDrawdown" in entry
            assert "winRate" in entry
