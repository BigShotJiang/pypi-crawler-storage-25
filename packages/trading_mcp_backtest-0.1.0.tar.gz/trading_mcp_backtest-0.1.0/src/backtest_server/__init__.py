"""Backtest MCP server — Docker-sandboxed strategy backtesting."""
