"""AST-based security validator for user-provided strategy code.

Runs BEFORE any Docker execution. Rejects code that uses disallowed
imports, builtins, or patterns. This is a defense-in-depth layer —
the Docker sandbox provides the hard security boundary.

Whitelist approach: only explicitly allowed modules pass.
"""

import ast

from trading_mcp_shared.errors import SandboxError

# ── Whitelists ───────────────────────────────────────────────────

ALLOWED_MODULES = frozenset(
    {
        "vectorbt",
        "vbt",
        "pandas",
        "pd",
        "numpy",
        "np",
        "math",
        "datetime",
        "json",
        "dataclasses",
        "typing",
        "collections",
        "functools",
        "itertools",
        "decimal",
        "statistics",
        "ta",  # technical analysis library
    }
)

BLOCKED_BUILTINS = frozenset(
    {
        "eval",
        "exec",
        "compile",
        "__import__",
        "open",
        "input",
        "breakpoint",
        "globals",
        "locals",
        "vars",
        "getattr",
        "setattr",
        "delattr",
        "memoryview",
    }
)

# Blocked attribute access patterns
BLOCKED_ATTRIBUTES = frozenset(
    {
        "__subclasses__",
        "__bases__",
        "__class__",
        "__globals__",
        "__code__",
        "__builtins__",
        "__import__",
    }
)


class _Validator(ast.NodeVisitor):
    """Walk the AST and collect violations."""

    def __init__(self) -> None:
        self.violations: list[str] = []

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            module = alias.name.split(".")[0]
            if module not in ALLOWED_MODULES:
                self.violations.append(
                    f"Line {node.lineno}: blocked import '{alias.name}' "
                    f"(allowed: {', '.join(sorted(ALLOWED_MODULES))})"
                )
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module:
            module = node.module.split(".")[0]
            if module not in ALLOWED_MODULES:
                self.violations.append(
                    f"Line {node.lineno}: blocked import from '{node.module}' "
                    f"(allowed: {', '.join(sorted(ALLOWED_MODULES))})"
                )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        # Check for blocked builtin calls like eval(), exec(), open()
        if isinstance(node.func, ast.Name):
            if node.func.id in BLOCKED_BUILTINS:
                self.violations.append(
                    f"Line {node.lineno}: blocked builtin call '{node.func.id}()'"
                )
        # Check for blocked method calls like __import__()
        if isinstance(node.func, ast.Attribute):
            if node.func.attr in BLOCKED_BUILTINS:
                self.violations.append(
                    f"Line {node.lineno}: blocked call '.{node.func.attr}()'"
                )
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr in BLOCKED_ATTRIBUTES:
            self.violations.append(
                f"Line {node.lineno}: blocked attribute access '.{node.attr}'"
            )
        self.generic_visit(node)


def validate_strategy_code(code: str) -> list[str]:
    """Validate strategy code and return a list of violations.

    Returns an empty list if the code is safe to execute.
    Raises SandboxError if the code cannot be parsed.
    """
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        raise SandboxError(f"Syntax error in strategy code: {e}") from e

    validator = _Validator()
    validator.visit(tree)
    return validator.violations


def assert_safe(code: str) -> None:
    """Validate code and raise SandboxError if any violations found."""
    violations = validate_strategy_code(code)
    if violations:
        msg = "Strategy code rejected by security validator:\n"
        msg += "\n".join(f"  - {v}" for v in violations)
        raise SandboxError(msg)
