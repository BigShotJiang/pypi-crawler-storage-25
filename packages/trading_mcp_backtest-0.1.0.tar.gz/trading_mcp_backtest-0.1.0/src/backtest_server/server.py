"""Backtest MCP server — 3 tools for strategy backtesting in Docker sandbox."""

import uuid
from datetime import datetime, timedelta, timezone

from fastmcp import FastMCP

from trading_mcp_shared.errors import SandboxError

from backtest_server.sandbox import run_in_sandbox
from backtest_server.validator import assert_safe

mcp = FastMCP("Backtest")

# ── Session store (in-memory, per server session) ────────────────

_backtests: dict[str, dict] = {}


def _resolve_date(date_str: str, default_relative: str = "1y") -> str:
    """Convert relative date strings to ISO format."""
    if not date_str:
        date_str = default_relative
    now = datetime.now(timezone.utc)
    mapping = {
        "1y": timedelta(days=365),
        "2y": timedelta(days=730),
        "3y": timedelta(days=1095),
        "6m": timedelta(days=182),
        "3m": timedelta(days=90),
        "1m": timedelta(days=30),
    }
    if date_str in mapping:
        return (now - mapping[date_str]).strftime("%Y-%m-%d")
    return date_str


# ── Tool 1: run_backtest ─────────────────────────────────────────


@mcp.tool()
async def run_backtest(
    symbol: str,
    strategy: str,
    start_date: str = "",
    end_date: str = "",
    initial_capital: float = 10000,
    commission: float = 0.001,
) -> dict:
    """Run a trading strategy backtest over historical data.

    The strategy code runs inside an isolated Docker sandbox with no network
    access, read-only filesystem, 512MB memory limit, and 30-second timeout.

    Args:
        symbol: Ticker to backtest on e.g. "AAPL", "BTC-USD"
        strategy: Python code string implementing the strategy. Must use vectorbt/pandas/numpy only.
        start_date: Backtest start date ISO 8601 or relative "1y", "2y". Defaults to "1y".
        end_date: End date ISO 8601. Defaults to today.
        initial_capital: Starting capital in USD. Defaults to 10000.
        commission: Commission per trade as a fraction. Defaults to 0.001 (0.1%).
    """
    try:
        symbol = symbol.strip().upper()
        if not symbol:
            return {"error": "Symbol is required."}
        strategy = strategy.strip()
        if not strategy:
            return {"error": "Strategy code is required."}

        # Step 1: AST validation — reject unsafe code before Docker
        try:
            assert_safe(strategy)
        except SandboxError as e:
            return {"error": str(e)}

        # Step 2: Resolve dates
        resolved_start = _resolve_date(start_date, "1y")
        resolved_end = (
            _resolve_date(end_date, "")
            if end_date
            else datetime.now(timezone.utc).strftime("%Y-%m-%d")
        )

        # Step 3: Execute in Docker sandbox
        result = await run_in_sandbox(
            strategy_code=strategy,
            symbol=symbol,
            start_date=resolved_start,
            end_date=resolved_end,
            initial_capital=initial_capital,
            commission=commission,
        )

        # Step 4: Store in session
        backtest_id = str(uuid.uuid4())[:8]
        entry = {
            "id": backtest_id,
            "symbol": symbol,
            "strategy_desc": strategy[:100] + ("..." if len(strategy) > 100 else ""),
            "startDate": resolved_start,
            "endDate": resolved_end,
            "initialCapital": initial_capital,
            "commission": commission,
            "ranAt": datetime.now(timezone.utc).isoformat(),
            **result,
        }
        _backtests[backtest_id] = entry

        return entry
    except SandboxError as e:
        print(f"[backtest] sandbox error: {e}")
        return {"error": str(e)}
    except Exception as e:
        print(f"[backtest] error: {e}")
        return {"error": f"Backtest failed — {e}"}


# ── Tool 2: list_backtests ───────────────────────────────────────


@mcp.tool()
async def list_backtests() -> dict:
    """List all backtests run in the current server session."""
    try:
        summaries = []
        for bt in _backtests.values():
            summaries.append(
                {
                    "id": bt["id"],
                    "symbol": bt["symbol"],
                    "strategy_desc": bt["strategy_desc"],
                    "totalReturn": bt.get("totalReturn"),
                    "sharpeRatio": bt.get("sharpeRatio"),
                    "ranAt": bt["ranAt"],
                }
            )
        return {"backtests": summaries, "count": len(summaries)}
    except Exception as e:
        print(f"[backtest] error: {e}")
        return {"error": f"Unable to list backtests — {e}"}


# ── Tool 3: compare_backtests ────────────────────────────────────


@mcp.tool()
async def compare_backtests(ids: list[str]) -> dict:
    """Side-by-side comparison of two or more previously run backtests.

    Args:
        ids: List of 2-5 backtest IDs from list_backtests.
    """
    try:
        if not ids or len(ids) < 2:
            return {"error": "At least 2 backtest IDs are required for comparison."}
        if len(ids) > 5:
            return {"error": "Maximum 5 backtests can be compared at once."}

        comparison = []
        missing = []
        for bt_id in ids:
            bt = _backtests.get(bt_id)
            if bt is None:
                missing.append(bt_id)
                continue
            comparison.append(
                {
                    "id": bt["id"],
                    "symbol": bt["symbol"],
                    "strategy_desc": bt["strategy_desc"],
                    "totalReturn": bt.get("totalReturn"),
                    "cagr": bt.get("cagr"),
                    "sharpeRatio": bt.get("sharpeRatio"),
                    "maxDrawdown": bt.get("maxDrawdown"),
                    "winRate": bt.get("winRate"),
                    "totalTrades": bt.get("totalTrades"),
                    "benchmarkReturn": bt.get("benchmarkReturn"),
                }
            )

        if missing:
            return {
                "error": f"Backtest IDs not found: {', '.join(missing)}. Use list_backtests to see available IDs."
            }

        if len(comparison) < 2:
            return {"error": "Need at least 2 valid backtests to compare."}

        # Determine winner by Sharpe ratio
        valid = [c for c in comparison if c.get("sharpeRatio") is not None]
        winner = None
        if valid:
            best = max(valid, key=lambda c: c["sharpeRatio"])
            winner = {
                "id": best["id"],
                "symbol": best["symbol"],
                "sharpeRatio": best["sharpeRatio"],
                "reason": f"Highest risk-adjusted return (Sharpe ratio: {best['sharpeRatio']:.2f})",
            }

        return {"comparison": comparison, "winner": winner}
    except Exception as e:
        print(f"[backtest] error: {e}")
        return {"error": f"Unable to compare backtests — {e}"}


def main() -> None:
    mcp.run()
