"""Entry point: uv run python -m backtest_server"""

from backtest_server.server import mcp

mcp.run()
