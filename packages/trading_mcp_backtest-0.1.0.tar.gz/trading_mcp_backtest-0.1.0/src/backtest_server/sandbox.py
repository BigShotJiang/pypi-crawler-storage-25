"""Docker sandbox for executing backtest strategy code.

All user code runs inside an isolated Docker container with:
  - No network access (--network none)
  - Read-only filesystem (--read-only, tmpfs /tmp)
  - 512MB memory limit
  - 1 CPU core limit
  - 30-second timeout (hard kill)
  - Non-root user

The sandbox image must be pre-built. The server checks for Docker
availability and the image at startup.
"""

import asyncio
import json
import shutil
import tempfile
from pathlib import Path

from trading_mcp_shared.errors import SandboxError

SANDBOX_IMAGE = "trading-mcp-sandbox:latest"
DOCKER_TIMEOUT = 30  # seconds

# ── Docker availability check ────────────────────────────────────


async def check_docker() -> bool:
    """Check if Docker is available and running."""
    docker_path = shutil.which("docker")
    if not docker_path:
        return False
    try:
        proc = await asyncio.create_subprocess_exec(
            "docker",
            "info",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=5)
        return proc.returncode == 0
    except (asyncio.TimeoutError, OSError):
        return False


async def check_sandbox_image() -> bool:
    """Check if the sandbox Docker image exists."""
    try:
        proc = await asyncio.create_subprocess_exec(
            "docker",
            "image",
            "inspect",
            SANDBOX_IMAGE,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=5)
        return proc.returncode == 0
    except (asyncio.TimeoutError, OSError):
        return False


# ── Sandbox execution ────────────────────────────────────────────


async def run_in_sandbox(
    strategy_code: str,
    symbol: str,
    start_date: str,
    end_date: str,
    initial_capital: float,
    commission: float,
) -> dict:
    """Execute strategy code inside a Docker sandbox.

    The strategy code and parameters are written to a temp file,
    mounted into the container, and executed by the runner script.

    Returns the parsed JSON result from the container's stdout.
    Raises SandboxError on failure.
    """
    # Check Docker is available
    if not await check_docker():
        raise SandboxError(
            "Docker is not available. The backtest server requires Docker "
            "to run strategy code safely. Please install Docker Desktop "
            "and ensure it is running."
        )

    if not await check_sandbox_image():
        raise SandboxError(
            f"Sandbox image '{SANDBOX_IMAGE}' not found. "
            "Please build it with: docker build -t trading-mcp-sandbox sandbox/"
        )

    # Write strategy and params to a temp directory
    with tempfile.TemporaryDirectory() as tmpdir:
        params = {
            "strategy_code": strategy_code,
            "symbol": symbol,
            "start_date": start_date,
            "end_date": end_date,
            "initial_capital": initial_capital,
            "commission": commission,
        }
        params_path = Path(tmpdir) / "params.json"
        params_path.write_text(json.dumps(params))

        # Docker run with all security constraints
        cmd = [
            "docker",
            "run",
            "--rm",  # Auto-remove after run
            "--network",
            "none",  # No network access
            "--memory",
            "512m",  # Memory cap
            "--cpus",
            "1.0",  # CPU cap
            "--read-only",  # Read-only filesystem
            "--tmpfs",
            "/tmp:size=64m",  # Temp writes only in /tmp
            "--user",
            "1000:1000",  # Non-root user
            "-v",
            f"{params_path}:/sandbox/params.json:ro",
            SANDBOX_IMAGE,
        ]

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=DOCKER_TIMEOUT + 5
            )
        except asyncio.TimeoutError:
            # Kill the container if it exceeds timeout
            try:
                proc.kill()
            except ProcessLookupError:
                pass
            raise SandboxError("Backtest execution timed out (30 second limit).")
        except OSError as e:
            raise SandboxError(f"Failed to start Docker container: {e}")

        if proc.returncode != 0:
            error_msg = stderr.decode("utf-8", errors="replace").strip()
            if not error_msg:
                error_msg = f"Container exited with code {proc.returncode}"
            raise SandboxError(error_msg, exit_code=proc.returncode)

        # Parse JSON result from stdout
        output = stdout.decode("utf-8", errors="replace").strip()
        if not output:
            raise SandboxError("Container produced no output.")

        try:
            return json.loads(output)
        except json.JSONDecodeError as e:
            raise SandboxError(f"Container output is not valid JSON: {e}")
