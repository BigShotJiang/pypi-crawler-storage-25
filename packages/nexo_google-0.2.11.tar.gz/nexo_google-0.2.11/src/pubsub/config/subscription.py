from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar


class SubscriptionConfig(BaseModel):
    id: Annotated[str, Field(..., description="Subscription's ID")]
    enabled: Annotated[
        bool, Field(True, description="Whether to enable subscription")
    ] = True
    consume: Annotated[bool, Field(True, description="Whether to consume message")] = (
        True
    )
    max_messages: Annotated[
        int, Field(10, description="Subscription's Max messages")
    ] = 10
    ack_deadline: Annotated[
        int, Field(10, description="Subscription's ACK deadline")
    ] = 10


class SubscriptionsConfig(BaseModel):
    pass


OptSubscriptionsConfig = SubscriptionsConfig | None
SubscriptionsConfigT = TypeVar("SubscriptionsConfigT", bound=OptSubscriptionsConfig)


class SubscriptionsConfigMixin(BaseModel, Generic[SubscriptionsConfigT]):
    subscriptions: SubscriptionsConfigT = Field(..., description="Subscriptions config")
