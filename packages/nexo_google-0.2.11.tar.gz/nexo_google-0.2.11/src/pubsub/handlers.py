from pydantic import BaseModel, ConfigDict, Field
from typing import Annotated
from .config.subscription import SubscriptionConfig
from .types import MessageController


class SubscriptionHandler(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    config: Annotated[SubscriptionConfig, Field(..., description="Subscription config")]
    controller: Annotated[
        MessageController, Field(..., description="Message controller")
    ]


class SubscriptionHandlers(BaseModel):
    pass
