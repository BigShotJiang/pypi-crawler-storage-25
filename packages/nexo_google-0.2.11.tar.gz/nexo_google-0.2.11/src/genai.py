from abc import ABC, abstractmethod
from copy import deepcopy
from datetime import datetime, timezone
from google import genai
from google.genai.types import GenerateContentConfig, GenerateContentResponse
from pydantic import BaseModel, Field
from typing import Annotated, Generic, TypeVar
from uuid import UUID, uuid4
from nexo.logging.config import LogConfig
from nexo.logging.enums import LogLevel
from nexo.schemas.application import OptApplicationContext
from nexo.schemas.connection import OptConnectionContext
from nexo.schemas.error.enums import ErrorCode
from nexo.schemas.exception.factory import MaleoExceptionFactory
from nexo.schemas.google import ListOfPublisherHandlers
from nexo.schemas.operation.enums import OperationType
from nexo.schemas.operation.mixins import Timestamp
from nexo.schemas.operation.resource import (
    CreateResourceOperationAction,
    CreateSingleResourceOperation,
)
from nexo.schemas.resource import ResourceIdentifier, AggregateField
from nexo.schemas.response import SingleDataResponse
from nexo.schemas.security.authentication import OptAnyAuthentication
from nexo.schemas.security.authorization import OptAnyAuthorization
from nexo.schemas.security.impersonation import OptImpersonation
from nexo.types.misc import OptPathOrStr
from nexo.types.uuid import OptUUID
from .base import GOOGLE_RESOURCE, GoogleClientManager
from .secret import GoogleSecretManager
from .types import OptionalCredentials


GENAI_RESOURCE = deepcopy(GOOGLE_RESOURCE)
GENAI_RESOURCE.identifiers.append(
    ResourceIdentifier(key="genai", name="GenAI", slug="genai")
)


class PromptManager(ABC):
    """
    A unified manager for handling the lifecycle, storage, and generation of LLM prompts.

    This class serves two primary responsibilities:
    1. **Initialization (Manager)**: Downloading and caching raw system prompts and user
       prompt templates from an external source (e.g., Google Secret Manager) via `load()`.
    2. **Formatting (Generator)**: Providing methods to inject dynamic runtime data
       into the loaded templates to produce final prompt strings.

    ⚠️ IMPORTANT USAGE NOTE:
    The `generate_*_prompt` methods rely on templates that are populated by the `load()` method.
    Therefore, `load()` MUST be executed during the application's startup phase (specifically
    in the "before start" lifespan step). Calling any generation method before `load()`
    is called will result in missing or uninitialized template errors.
    """

    def __init__(self, google_secret_manager: GoogleSecretManager):
        self._google_secret_manager = google_secret_manager

    @abstractmethod
    def load(self, operation_id: UUID):
        """
        Downloads and initializes the system and user prompts from Google Secret Manager.

        ⚠️ IMPORTANT:
        This method MUST be called to initialize the prompts before any other operations occur.
        It is strictly required to be executed during the application's startup phase,
        specifically in the "before start" step of the application's lifespan.

        Args:
            operation_id (UUID): The unique ID for tracing the startup operation.
            google_secret_manager (GoogleSecretManager): The client used to read the secrets.
        """


PromptManagerT = TypeVar("PromptManagerT", bound=PromptManager)


class ConfigManager(ABC, Generic[PromptManagerT]):
    """
    A manager responsible for configuring the generation settings (e.g., temperature,
    response schemas, and system instructions) for the LLM models.

    This class centralizes the `GenerateContentConfig` objects so they can be reused
    efficiently across the application without needing to be re-instantiated for every request.
    """

    def __init__(self, prompt_manager: PromptManagerT):
        self._prompt_manager = prompt_manager

    @abstractmethod
    def load(self) -> None:
        """
        Initializes the generation configurations by attaching the required system
        prompts and JSON schemas.

        ⚠️ IMPORTANT:
        This method MUST be called during the application's startup phase ("before start" lifespan).
        Furthermore, it strictly requires that the `PromptManager.load()` method has already
        been executed, as it relies on the system prompts loaded by the PromptManager.

        Args:
            prompt_manager (PromptManager): The initialized PromptManager instance containing
                                            the loaded system prompts.
        """


class GenAIConfig(BaseModel):
    location: Annotated[str, Field(..., description="Model's Location")]
    model: Annotated[str, Field(..., description="Model's Name")]


OptGenAIConfig = GenAIConfig | None
OptGenAIConfigT = TypeVar("OptGenAIConfigT", bound=OptGenAIConfig)


class GenAIConfigMixin(BaseModel, Generic[OptGenAIConfigT]):
    genai: Annotated[OptGenAIConfigT, Field(..., description="GenAI Config")]


class Text(BaseModel):
    text: Annotated[str, Field(..., description="Response Text")]


class GoogleGenAI(GoogleClientManager):
    def __init__(
        self,
        config: GenAIConfig,
        log_config: LogConfig,
        *,
        application_context: OptApplicationContext = None,
        credentials: OptionalCredentials = None,
        credentials_path: OptPathOrStr = None,
        publishers: ListOfPublisherHandlers = [],
    ) -> None:
        super().__init__(
            GENAI_RESOURCE.aggregate(),
            GENAI_RESOURCE.aggregate(AggregateField.NAME),
            log_config,
            application_context,
            credentials,
            credentials_path,
        )
        self.config = config
        self.client = genai.Client(
            vertexai=True,
            credentials=self._credentials,
            project=self.project_id,
            location=self.config.location,
        )

        self._publishers = publishers

    def generate_text(
        self,
        *,
        operation_id: OptUUID = None,
        connection_context: OptConnectionContext = None,
        authentication: OptAnyAuthentication = None,
        authorization: OptAnyAuthorization = None,
        impersonation: OptImpersonation = None,
        config: GenerateContentConfig,
        contents: str,
    ) -> SingleDataResponse[Text, None]:
        operation_id = operation_id if operation_id is not None else uuid4()
        operation_action = CreateResourceOperationAction()

        resource = deepcopy(GENAI_RESOURCE)
        resource.details = {"type": "text"}

        executed_at = datetime.now(tz=timezone.utc)

        content_generation_response = self.client.models.generate_content(
            model=self.config.model, contents=contents, config=config
        )

        operation_response = SingleDataResponse[GenerateContentResponse, None].new(
            data=content_generation_response
        )
        summary = f"Successfully generated text using model '{self.config.model}' in location '{self.config.location}'."
        operation = CreateSingleResourceOperation[GenerateContentResponse, None](
            application_context=self._application_context,
            id=operation_id,
            context=self._operation_context,
            action=operation_action,
            resource=resource,
            timestamp=Timestamp.completed_now(executed_at),
            summary=summary,
            connection_context=connection_context,
            authentication=authentication,
            authorization=authorization,
            impersonation=impersonation,
            response=operation_response,
        )
        operation.log(self._logger, LogLevel.INFO)
        operation.publish(self._logger, self._publishers)

        if content_generation_response.text is None:
            summary = "Content generation response did not contains any text."
            exc = MaleoExceptionFactory.from_code(
                ErrorCode.INTERNAL_SERVER_ERROR,
                details=summary,
                operation_type=OperationType.RESOURCE,
                operation_id=operation_id,
                operation_context=self._operation_context,
                operation_action=operation_action,
                resource=GENAI_RESOURCE,
                operation_timestamp=Timestamp.completed_now(executed_at),
                operation_summary=summary,
                connection_context=connection_context,
                authentication=authentication,
                authorization=authorization,
            )
            exc.log_and_publish_operation(self._logger, self._publishers)
            raise exc

        data = Text(text=content_generation_response.text)
        response = SingleDataResponse[Text, None].new(data=data)

        return response
