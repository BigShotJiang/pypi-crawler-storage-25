from pydantic import BaseModel, Field
from typing import Annotated, Generic
from .genai import OptGenAIConfigT, GenAIConfigMixin
from .pubsub.config import PubSubConfigMixin
from .pubsub.publisher import PublisherConfigT
from .pubsub.subscriber import SubscriptionsConfigT


class GoogleConfig(
    PubSubConfigMixin[PublisherConfigT, SubscriptionsConfigT],
    GenAIConfigMixin[OptGenAIConfigT],
    Generic[OptGenAIConfigT, PublisherConfigT, SubscriptionsConfigT],
):
    pass


class GoogleConfigMixin(
    BaseModel, Generic[OptGenAIConfigT, PublisherConfigT, SubscriptionsConfigT]
):
    google: Annotated[
        GoogleConfig[OptGenAIConfigT, PublisherConfigT, SubscriptionsConfigT],
        Field(..., description="Google's Config"),
    ]
