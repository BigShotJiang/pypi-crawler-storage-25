import subprocess
from unittest.mock import patch

import pytest
import typer

from tests.utils import needs_windows

url = "http://example.com"


@pytest.mark.parametrize(
    "system, command",
    [
        ("Darwin", "open"),
        ("Linux", "xdg-open"),
        ("FreeBSD", "xdg-open"),
    ],
)
def test_launch_url_unix(system: str, command: str):
    with (
        patch("platform.system", return_value=system),
        patch("shutil.which", return_value=True),
        patch("subprocess.Popen") as mock_popen,
    ):
        typer.launch(url)

    mock_popen.assert_called_once_with(
        [command, url], stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT
    )


def test_launch_url_windows():
    with (
        patch("platform.system", return_value="Windows"),
        patch("webbrowser.open") as mock_webbrowser_open,
    ):
        typer.launch(url)

    mock_webbrowser_open.assert_called_once_with(url)


def test_launch_url_no_xdg_open():
    with (
        patch("platform.system", return_value="Linux"),
        patch("shutil.which", return_value=None),
        patch("webbrowser.open") as mock_webbrowser_open,
    ):
        typer.launch(url)

    mock_webbrowser_open.assert_called_once_with(url)


def test_calls_original_launch_when_not_passing_urls():
    with patch("typer.main.click.launch", return_value=0) as launch_mock:
        typer.launch("not a url")

    launch_mock.assert_called_once_with("not a url", wait=False, locate=False)


@needs_windows
def test_launch_file():
    with (
        patch("click._termui_impl.sys.platform", "win32"),
        patch("click._termui_impl.WIN", True),
        patch("click._termui_impl.CYGWIN", False),
        patch("subprocess.call", return_value=0) as call_mock,
    ):
        result = typer.launch("C:/tmp/file.txt", locate=True)

    assert result == 0
    call_mock.assert_called_once_with(["explorer", "/select,C:/tmp/file.txt"])
