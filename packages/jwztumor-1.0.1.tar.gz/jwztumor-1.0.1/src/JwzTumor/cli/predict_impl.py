"""Prediction implementation for JwzTumor CLI."""
import logging
from pathlib import Path
from typing import Dict, Optional

from ..utils.config import load_config
from ..utils.seed import set_seed
from ..utils.logging import setup_logging
from ..models.model_factory import create_model
from ..inference.predictor import MultiTaskPredictor
from ..data.busi_dataset import BUSIDataset
from ..data.preprocessing import BreastUSPreprocessor
from ..data.cache import DatasetCache

logger = logging.getLogger(__name__)


def run_prediction(
    config_path: str,
    data_path: str,
    output_dir: str,
    overrides: Optional[Dict] = None,
    verbose: bool = False,
) -> None:
    """Run prediction pipeline."""
    config = load_config(config_path)
    if overrides:
        config.apply_overrides(**overrides)

    set_seed(config.training.random_seed)
    setup_logging(
        level=logging.DEBUG if verbose else logging.INFO,
        log_dir=str(Path(output_dir) / "logs"),
        use_rich=True,
    )

    # Create predictor
    model = create_model(config)
    predictor = MultiTaskPredictor.from_checkpoint(
        config=config,
        checkpoint_path=config.inference.model_path,
    )

    # Create dataset
    preprocessor = BreastUSPreprocessor(
        model_input_size=config.dataset.model_input_size,
    )
    cache = DatasetCache(mode=config.dataset.cache_mode)

    dataset = BUSIDataset(
        data_root=data_path,
        classes=config.dataset.test_classes,
        ignore_classes=config.dataset.ignore_classes,
        preprocessor=preprocessor,
        cache=cache,
        label_mapping=config.dataset.label_mapping,
        is_train=False,
    )

    logger.info("Prediction dataset: %d samples from %s", len(dataset), data_path)

    # Run prediction
    use_tta = config.inference.use_tta
    tta_fn = None
    if use_tta:
        from ..inference.tta import apply_tta
        tta_fn = apply_tta

    predictions = predictor.predict_batch(
        dataset=dataset,
        output_dir=output_dir,
        use_tta=use_tta,
        tta_fn=tta_fn,
        verbose=verbose,
    )

    logger.info("Prediction complete: %d samples -> %s", len(predictions), output_dir)
