"""Rich Live display for verbose training: progress bar on top, log panel below."""

import logging
import re
import threading
from datetime import datetime
from typing import Optional, Tuple

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress import (
    BarColumn,
    Progress,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.table import Table
from rich.text import Text

# ---------------------------------------------------------------------------
# Module-level active display singleton
# ---------------------------------------------------------------------------

_active_display = None


def get_active_display():
    """Return the currently active display, if any."""
    return _active_display


def set_active_display(display):
    """Set the active display singleton."""
    global _active_display
    _active_display = display


def strip_rich_markup(text: str) -> str:
    """Remove Rich-style markup tags from a string."""
    return re.sub(r"\[/?[^\]]*\]", "", text)


# ---------------------------------------------------------------------------
# LiveDisplayLogHandler -- routes log records into the live display panel
# ---------------------------------------------------------------------------


class LiveDisplayLogHandler(logging.Handler):
    """Custom logging handler that feeds messages into a VerboseLiveDisplay."""

    def __init__(self, display: "VerboseLiveDisplay"):
        super().__init__()
        self.display = display

    def emit(self, record):
        try:
            msg = self.format(record)
            clean = strip_rich_markup(msg)
            self.display.add_log(clean)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# VerboseLiveDisplay -- two-panel: progress bar + scrollable log
# ---------------------------------------------------------------------------


class VerboseLiveDisplay:
    """Rich Live display with progress bar on top and a scrollable log panel below.

    Layout::

        +---------------------------------------------+
        | [Progress Bar - Epoch Tracking]              |  <- 3 rows
        +---------------------------------------------+
        | Training Log                                 |
        | ... log lines ...                            |  <- 25 rows
        |                                              |
        +---------------------------------------------+
    """

    def __init__(self, max_log_lines: int = 25):
        self.max_log_lines = max_log_lines
        self.log_lines: list[str] = []
        self._lock = threading.Lock()

        self.progress = Progress(
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})", justify="right"),
            "  ",
            TextColumn("{task.fields[postfix]}", style="cyan"),
            "  ",
            TimeElapsedColumn(),
            "  ",
            TimeRemainingColumn(),
            console=Console(stderr=True),
        )
        self.task_id: Optional[int] = None
        self.live: Optional[Live] = None

    # -- lifecycle --

    def start(self, total: int, initial: int = 0, description: str = "Epochs"):
        self.task_id = self.progress.add_task(
            description, total=total, completed=initial, postfix=""
        )
        self.live = Live(
            self._build_renderable(),
            refresh_per_second=4,
            console=Console(stderr=True),
            vertical_overflow="visible",
        )
        self.live.start()

    def stop(self):
        if self.live:
            self.live.stop()
            self.live = None

    # -- log panel --

    def add_log(self, message: str):
        with self._lock:
            self.log_lines.append(message)
            if len(self.log_lines) > self.max_log_lines * 3:
                self.log_lines = self.log_lines[-self.max_log_lines * 2 :]
        self._refresh()

    # -- progress bar --

    def update_progress(self, advance: int = 0, postfix: str = "", **kwargs):
        if self.task_id is not None:
            update_kwargs = {}
            if advance:
                update_kwargs["advance"] = advance
            if postfix:
                update_kwargs["postfix"] = postfix
            update_kwargs.update(kwargs)
            self.progress.update(self.task_id, **update_kwargs)
        self._refresh()

    def set_postfix(self, text: str):
        self.update_progress(postfix=text)

    # -- rendering --

    def _refresh(self):
        if self.live:
            self.live.update(self._build_renderable())

    def _build_renderable(self):
        panel = self._build_log_panel()
        return Group(self.progress, panel)

    def _build_log_panel(self):
        with self._lock:
            visible = self.log_lines[-self.max_log_lines :]
        content = Text("\n".join(visible), style="white")
        return Panel(
            content,
            title="[bold]Training Log[/]",
            border_style="blue",
            height=self.max_log_lines + 2,
            padding=(0, 1),
        )


# ---------------------------------------------------------------------------
# SimpleProgressDisplay -- progress bar only, no log panel
# ---------------------------------------------------------------------------


class SimpleProgressDisplay:
    """Progress bar only, no log panel. For non-verbose mode."""

    def __init__(self):
        self.progress = Progress(
            TextColumn("[bold blue]{task.description}", justify="right"),
            BarColumn(bar_width=None),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})", justify="right"),
            "  ",
            TextColumn("{task.fields[postfix]}", style="cyan"),
            "  ",
            TimeElapsedColumn(),
            "  ",
            TimeRemainingColumn(),
            console=Console(stderr=True),
        )
        self.task_id: Optional[int] = None

    def start(self, total: int, initial: int = 0, description: str = "Epochs"):
        self.task_id = self.progress.add_task(
            description, total=total, completed=initial, postfix=""
        )
        self.progress.start()

    def stop(self):
        self.progress.stop()

    def update_progress(self, advance: int = 0, postfix: str = "", **kwargs):
        if self.task_id is not None:
            update_kwargs = {}
            if advance:
                update_kwargs["advance"] = advance
            if postfix:
                update_kwargs["postfix"] = postfix
            update_kwargs.update(kwargs)
            self.progress.update(self.task_id, **update_kwargs)

    def set_postfix(self, text: str):
        self.update_progress(postfix=text)

    def add_log(self, message: str):
        pass  # No-op for non-verbose mode


# ---------------------------------------------------------------------------
# Prediction progress factory
# ---------------------------------------------------------------------------


def create_prediction_progress(
    total_steps: int,
    description: str = "Predicting",
) -> Tuple[Progress, int]:
    """Create a Rich progress bar for prediction batches.

    Returns:
        (progress, task_id) tuple. Caller must call progress.stop() when done.
    """
    progress = Progress(
        TextColumn("[bold blue]{task.description}", justify="right"),
        BarColumn(bar_width=None),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("({task.completed}/{step_total})", justify="right"),
        "  ",
        TextColumn("{task.fields[postfix]}", style="cyan"),
        "  ",
        TimeElapsedColumn(),
        "  ",
        TimeRemainingColumn(),
        console=Console(stderr=True),
    )
    task_id = progress.add_task(description, total=total_steps, postfix="", step_total=total_steps)
    progress.start()
    return progress, task_id


# ---------------------------------------------------------------------------
# Rich-formatted epoch summary
# ---------------------------------------------------------------------------

# Metric groups: (key, display_name, color_style)
_LOSS_METRICS = [
    ("train_loss", "Train Loss", "red"),
    ("val_loss",   "Val Loss",   "red"),
]

_CLS_METRICS = [
    ("val_auc",           "Val AUC",        "green"),
    ("val_f1",            "Val F1",         "green"),
    ("val_accuracy",      "Val Accuracy",   "cyan"),
    ("val_sensitivity",   "Val Sensitivity","cyan"),
    ("val_specificity",   "Val Specificity","cyan"),
    ("val_precision",     "Val Precision",  "cyan"),
]

_SEG_METRICS = [
    ("val_dice",          "Val Dice",       "green"),
]

_MISC_METRICS = [
    ("lr",                "LR",             "yellow"),
    ("epoch_time",        "Epoch Time",     "white"),
]


def _format_metric_value(key: str, val) -> str:
    """Format a metric value for display."""
    if key == "lr":
        return f"{val:.1e}" if val < 0.001 else f"{val:.6f}"
    if key == "epoch_time":
        return _format_duration(val)
    if isinstance(val, float):
        return f"{val:.4f}"
    return str(val)


def print_epoch_summary(
    epoch: int,
    total_epochs: int,
    stage: str,
    metrics: dict,
) -> None:
    """Print a Rich Table summarizing epoch metrics to stderr.

    Metrics are grouped into: Loss, Classification, Segmentation, Misc.
    Works in both verbose and non-verbose modes.
    """
    console = Console(stderr=True)

    table = Table(
        title=f"Epoch {epoch}/{total_epochs} [{stage}]",
        show_header=False,
        box=None,
        padding=(0, 2),
        title_style="bold",
    )
    table.add_column(style="dim", justify="right")
    table.add_column()

    # Loss section
    has_loss = any(metrics.get(k) is not None for k, _, _ in _LOSS_METRICS)
    if has_loss:
        table.add_row(Text("Loss", style="bold yellow"))
        for key, label, color in _LOSS_METRICS:
            val = metrics.get(key)
            if val is not None:
                table.add_row(f"  {label}:", f"[{color}]{_format_metric_value(key, val)}[/{color}]")

    # Classification section
    has_cls = any(metrics.get(k) is not None for k, _, _ in _CLS_METRICS)
    if has_cls:
        table.add_row()
        table.add_row(Text("Classification", style="bold yellow"))
        for key, label, color in _CLS_METRICS:
            val = metrics.get(key)
            if val is not None:
                table.add_row(f"  {label}:", f"[{color}]{_format_metric_value(key, val)}[/{color}]")

    # Segmentation section
    has_seg = any(metrics.get(k) is not None for k, _, _ in _SEG_METRICS)
    if has_seg:
        table.add_row()
        table.add_row(Text("Segmentation", style="bold yellow"))
        for key, label, color in _SEG_METRICS:
            val = metrics.get(key)
            if val is not None:
                table.add_row(f"  {label}:", f"[{color}]{_format_metric_value(key, val)}[/{color}]")

    # Misc (LR, time)
    table.add_row()
    for key, label, color in _MISC_METRICS:
        val = metrics.get(key)
        if val is not None:
            table.add_row(f"{label}:", f"[{color}]{_format_metric_value(key, val)}[/{color}]")

    console.print(table)


# ---------------------------------------------------------------------------
# Rich-formatted config & results display
# ---------------------------------------------------------------------------


def _format_duration(seconds: float) -> str:
    """Format duration as Xh Ym Zs."""
    total = int(seconds)
    hours, remainder = divmod(total, 3600)
    minutes, secs = divmod(remainder, 60)
    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    parts.append(f"{secs}s")
    return " ".join(parts)


def print_training_config(config) -> None:
    """Print Rich-formatted training configuration panel before training starts."""
    console = Console(stderr=True)

    model_cfg = config.model
    dataset_cfg = config.dataset
    training_cfg = config.training
    loss_cfg = config.loss
    experiment_cfg = config.experiment

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="cyan", justify="right")
    table.add_column()

    # Model section
    table.add_row(Text("Model", style="bold yellow"))
    table.add_row("  Name", model_cfg.name)
    table.add_row("  Input Size", str(dataset_cfg.model_input_size))
    table.add_row("  Encoder Channels", str(getattr(model_cfg, "encoder_channels", "N/A")))
    table.add_row("  Pre Channels", str(getattr(model_cfg, "pre_channels", "N/A")))
    table.add_row("  Use Mamba", str(getattr(model_cfg, "use_mamba", "N/A")))
    table.add_row()

    # Training section
    table.add_row(Text("Training", style="bold yellow"))
    table.add_row("  Stage", training_cfg.stage)
    table.add_row("  Epochs", str(training_cfg.epochs))
    table.add_row("  Batch Size", str(training_cfg.batch_size))
    table.add_row("  Learning Rate", str(training_cfg.learning_rate))
    table.add_row("  Optimizer", training_cfg.optimizer)
    table.add_row("  Scheduler", training_cfg.scheduler)
    table.add_row("  AMP", str(training_cfg.mixed_precision))
    table.add_row("  Device", training_cfg.device)
    table.add_row()

    # Dataset section
    table.add_row(Text("Dataset", style="bold yellow"))
    table.add_row("  Train", dataset_cfg.train_name)
    table.add_row("  Test", dataset_cfg.test_name)
    table.add_row("  CV File", dataset_cfg.cv_file)
    table.add_row("  Fold", str(dataset_cfg.fold))
    table.add_row("  Cache Mode", dataset_cfg.cache_mode)
    table.add_row("  Case-Level Split", str(dataset_cfg.use_case_level_split))
    table.add_row()

    # Loss section
    table.add_row(Text("Loss", style="bold yellow"))
    table.add_row("  Seg Loss", loss_cfg.seg_loss)
    table.add_row("  Cls Loss", loss_cfg.cls_loss)
    table.add_row("  AUC Loss", str(loss_cfg.use_auc_loss))
    table.add_row("  Uncertainty Weighting", str(loss_cfg.use_uncertainty_weighting))
    table.add_row()

    # Start time
    table.add_row(Text("Start Time", style="bold yellow"))
    table.add_row("  ", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    console.print(Panel(table, title="[bold]JwzTumor Training Configuration[/]", border_style="blue"))


def print_training_results(config, summary: dict, duration_seconds: float) -> None:
    """Print Rich-formatted training results panel after training completes."""
    console = Console(stderr=True)

    table = Table(show_header=False, box=None, padding=(0, 1))
    table.add_column(style="cyan", justify="right")
    table.add_column()

    # Duration
    table.add_row("Duration:", _format_duration(duration_seconds))
    table.add_row()

    # Stage & epochs
    stage = summary.get("stage", "N/A")
    total_epochs = summary.get("total_epochs", 0)
    table.add_row("Stage:", stage)
    table.add_row("Epochs Completed:", str(total_epochs))
    table.add_row()

    # Best metrics from history
    history = summary.get("history", [])
    if history:
        best_epoch_metrics = max(history, key=lambda h: h.get("val_auc", 0.0))
        best_epoch = best_epoch_metrics.get("epoch", "N/A")

        table.add_row(Text("Best Epoch Metrics", style="bold yellow"))
        table.add_row("  Best Epoch", str(best_epoch))
        for key in ("val_auc", "val_f1", "val_accuracy", "val_sensitivity",
                     "val_specificity", "val_precision", "val_dice", "val_loss",
                     "train_loss"):
            val = best_epoch_metrics.get(key)
            if val is not None and isinstance(val, float):
                table.add_row(f"  {key}", f"{val:.4f}")
        table.add_row()

    # Final LR
    if history:
        lr = history[-1].get("lr")
        if lr is not None:
            table.add_row("Final LR:", f"{lr:.1e}" if lr < 0.001 else f"{lr:.6f}")

    # End time
    table.add_row("End Time:", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    # Result directory
    exp_dir = config.experiment.save_dir + "/" + config.experiment.name
    table.add_row("Results:", exp_dir)

    console.print(Panel(table, title="[bold]Training Results[/]", border_style="green"))
