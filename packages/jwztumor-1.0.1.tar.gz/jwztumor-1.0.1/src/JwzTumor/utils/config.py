"""
Configuration Management for JwzTumor
======================================
Dataclass-based configuration with YAML loading, CLI override support,
and comprehensive settings for multi-task breast ultrasound diagnosis.
"""
import os
import yaml
import torch
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, asdict, field, fields, is_dataclass
import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Model Configuration
# ---------------------------------------------------------------------------

@dataclass
class ModelConfig:
    """LABDG_DGBC_MTLNet_MPTC model configuration."""
    name: str = "LABDG_DGBC_MTLNet_MPTC"
    raw_input_channels: int = 1
    pre_channels: int = 16
    encoder_input_channels: int = 16
    encoder_channels: list = field(default_factory=lambda: [64, 128, 256, 512])
    prompt_dim: int = 128
    challenge_dim: int = 8
    use_mamba: bool = True
    mamba_impl: str = "mamba_like"
    use_real_mamba: bool = False
    use_mpp: bool = True
    use_edge_head: bool = True
    use_sdm_head: bool = True
    use_uncertainty_head: bool = True
    use_artifact_head: bool = True
    use_center_scale_head: bool = True
    use_peritumoral_ring: bool = True
    ring_radius_min: int = 8
    ring_radius_max: int = 16
    boundary_width: int = 5
    dropout: float = 0.2

    def __post_init__(self):
        if self.encoder_input_channels == 0:
            self.encoder_input_channels = self.pre_channels


# ---------------------------------------------------------------------------
# Dataset Configuration
# ---------------------------------------------------------------------------

@dataclass
class DatasetConfig:
    """Dataset paths, formats, and preprocessing settings."""
    train_name: str = "BUSBRA"
    train_root: str = "dataset/BUSBRA"
    train_image_dir: str = "Images"
    train_mask_dir: str = "Masks"
    train_csv: str = "bus_data.csv"
    cv_file: str = "5-fold-cv.csv"
    fold: int = 1
    use_case_level_split: bool = True
    test_name: str = "BUSI"
    test_root: str = "dataset/Dataset_BUSI_with_GT"
    test_classes: list = field(default_factory=lambda: ["benign", "malignant"])
    ignore_classes: list = field(default_factory=lambda: ["normal-不使用"])
    image_mode: str = "grayscale"
    keep_original_size: bool = True
    resize_policy: str = "resize_longest_side_pad"
    pad_mode: str = "reflection"
    model_input_size: int = 512
    mask_interpolation: str = "nearest"
    image_interpolation: str = "bilinear"
    num_classes: int = 2
    label_mapping: dict = field(default_factory=lambda: {"benign": 0, "malignant": 1})
    cache_mode: str = "ram"
    cache_raw: bool = True
    cache_augmented: bool = False
    split_seed: int = 42


# ---------------------------------------------------------------------------
# Training Configuration
# ---------------------------------------------------------------------------

@dataclass
class HardExampleMiningConfig:
    enabled: bool = False
    start_epoch: int = 30
    weight_factor: float = 2.0
    update_interval: int = 10
    top_percentile: float = 80.0


@dataclass
class MixUpConfig:
    enabled: bool = False
    alpha: float = 0.2


@dataclass
class TrainingConfig:
    """Training hyperparameters and optimization settings."""
    stage: str = "finetune_all"
    epochs: int = 80
    batch_size: int = 8
    learning_rate: float = 0.0001
    weight_decay: float = 0.0001
    optimizer: str = "AdamW"
    scheduler: str = "cosine"
    warmup_epochs: int = 5
    min_lr: float = 0.000001
    random_seed: int = 42
    init_seed: int = 42
    device: str = "auto"
    num_workers: int = 4
    mixed_precision: bool = True
    gradient_clip_val: float = 0.0
    accumulate_grad_batches: int = 1
    freeze_method: str = "none"
    freeze_layers: str = ""
    freeze_ratio: float = 0.0
    hard_example_mining: Any = field(default_factory=HardExampleMiningConfig)
    mixup: Any = field(default_factory=MixUpConfig)
    balanced_sampling: bool = False
    malignant_oversample: bool = True
    small_lesion_oversample: bool = True
    device_domain_balancing: bool = True
    output_activation: str = "sigmoid"
    # Scheduler-specific parameters
    cosine_t_max: int = 0          # CosineAnnealingLR T_max (0=auto=epochs)
    cosine_eta_min: float = 0.0    # CosineAnnealingLR eta_min (0=auto=min_lr)
    warmrestart_t0: int = 10       # CosineAnnealingWarmRestarts T_0
    warmrestart_t_mult: int = 2    # CosineAnnealingWarmRestarts T_mult
    step_size: int = 0             # StepLR step_size (0=auto=epochs//3)
    step_gamma: float = 0.1        # StepLR gamma
    plateau_factor: float = 0.5    # ReduceLROnPlateau factor
    plateau_patience: int = 5      # ReduceLROnPlateau patience
    plateau_mode: str = "max"      # ReduceLROnPlateau mode: max/min

    def __post_init__(self):
        self.refresh_runtime_defaults()

    def refresh_runtime_defaults(self):
        if self.device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        elif str(self.device).startswith("cuda") and not torch.cuda.is_available():
            self.device = "cpu"
        if isinstance(self.hard_example_mining, dict):
            self.hard_example_mining = HardExampleMiningConfig(**self.hard_example_mining)
        if isinstance(self.mixup, dict):
            self.mixup = MixUpConfig(**self.mixup)


# ---------------------------------------------------------------------------
# Loss Configuration
# ---------------------------------------------------------------------------

@dataclass
class LossConfig:
    """Loss function configuration for multi-task training."""
    seg_loss: str = "dice_bce"
    edge_loss: str = "boundary_bce"
    sdm_loss: str = "smooth_l1"
    cls_loss: str = "asymmetric_focal"
    auc_loss: str = "auc_margin"
    use_auc_loss: bool = True
    consistency_loss: str = "kl_mse"
    pre_loss: str = "boundary_texture_domain"
    use_uncertainty_weighting: bool = True
    lambda_edge: float = 1.0
    lambda_sdm: float = 1.0
    lambda_cls: float = 1.0
    lambda_auc: float = 0.5
    lambda_cons: float = 0.1
    lambda_pre: float = 0.5
    lambda_unc: float = 0.1
    focal_alpha: float = 0.25
    focal_gamma: float = 2.0
    dice_weight: float = 0.5
    bce_weight: float = 0.5


# ---------------------------------------------------------------------------
# Augmentation Configuration
# ---------------------------------------------------------------------------

@dataclass
class AugmentationConfig:
    """Data augmentation pipeline configuration."""
    random_horizontal_flip: bool = True
    random_rotation_degree: int = 10
    random_scale_shift: bool = True
    random_elastic: bool = True
    speckle_noise: bool = True
    gamma_adjustment: bool = True
    contrast_adjustment: bool = True
    brightness_gain: bool = True
    frequency_amplitude_perturbation: bool = True
    posterior_shadow_simulation: bool = True
    posterior_enhancement_simulation: bool = True
    random_blur_prob: float = 0.1
    coarse_dropout_prob: float = 0.05
    foreground_constrained_crop: bool = True


# ---------------------------------------------------------------------------
# Metric Configuration
# ---------------------------------------------------------------------------

@dataclass
class MetricConfig:
    """Evaluation metrics configuration."""
    classification: list = field(default_factory=lambda: [
        "auc", "accuracy", "sensitivity", "specificity", "precision", "f1"
    ])
    segmentation: list = field(default_factory=lambda: [
        "dice", "iou", "hd95", "boundary_f1", "precision", "recall"
    ])


# ---------------------------------------------------------------------------
# Checkpoint Configuration
# ---------------------------------------------------------------------------

@dataclass
class CheckpointConfig:
    """Checkpoint saving and model selection configuration."""
    monitor: str = "val_auc"
    save_best_auc: bool = True
    save_best_f1: bool = True
    save_best_sensitivity: bool = True
    save_best_dice: bool = True
    save_last: bool = True


# ---------------------------------------------------------------------------
# Inference Configuration
# ---------------------------------------------------------------------------

@dataclass
class InferenceConfig:
    """Inference and prediction settings."""
    model_path: str = "checkpoints/best_auc.ckpt"
    output_dir: str = "outputs/busi_predictions"
    mode: str = "batch"
    use_tta: bool = True
    tta_scales: list = field(default_factory=lambda: [0.9, 1.0, 1.1])
    tta_flip: bool = True
    threshold: float = 0.5
    use_largest_component: bool = True
    restore_to_original_size: bool = True
    save_overlay: bool = True
    save_uncertainty: bool = True
    save_edge: bool = True
    save_heatmap: bool = True


# ---------------------------------------------------------------------------
# Postprocess Configuration
# ---------------------------------------------------------------------------

@dataclass
class PostprocessConfig:
    """Post-processing configuration for segmentation and classification."""
    threshold: float = 0.5
    use_largest_component: bool = True
    min_region_size: int = 100
    temperature_scaling: float = 1.0
    use_calibration: bool = False


# ---------------------------------------------------------------------------
# Experiment Configuration
# ---------------------------------------------------------------------------

@dataclass
class ExperimentConfig:
    """Experiment naming, output directories, and logging."""
    name: str = "JwzTumor"
    author: str = "SuShuheng"
    license: str = "Apache-2.0"
    save_dir: str = "experiments"
    log_dir: str = "experiments/logs"
    checkpoint_dir: str = "experiments/checkpoints"
    result_dir: str = "experiments/results"
    log_every_n_steps: int = 10
    val_check_interval: float = 1.0
    save_top_k: int = 1
    save_latest: bool = False
    runtime_stage: str = ""


# ---------------------------------------------------------------------------
# Monitoring Configuration
# ---------------------------------------------------------------------------

@dataclass
class MonitoringConfig:
    """Early stopping, model selection, and prediction thresholds."""
    early_stopping: dict = field(default_factory=lambda: {
        "enabled": True,
        "metric": "val_loss",
        "mode": "min",
        "patience": 10,
        "min_delta": 0.001,
    })
    model_selection: dict = field(default_factory=lambda: {
        "metric": "val_auc",
        "mode": "max",
    })
    predict_threshold: float = 0.5
    verbose: bool = True


# ---------------------------------------------------------------------------
# Train Split Configuration
# ---------------------------------------------------------------------------

@dataclass
class TrainSplitConfig:
    """Dataset splitting strategy and ratios."""
    method: str = "stratified"
    train_ratio: float = 0.75
    val_ratio: float = 0.15
    test_ratio: float = 0.10
    random_seed: int = 42
    export_split_info: bool = True
    split_filename: str = "train_split.csv"


# ---------------------------------------------------------------------------
# Device domain mapping
# ---------------------------------------------------------------------------

DEVICE_DOMAIN_MAP = {
    "GE Logiq 5 @10-12MHz": 0,
    "GE Logiq 7 @10-14MHz": 1,
    "Toshiba Aplio 300 @12-14MHz": 2,
    "U-Systems @10-14MHz": 3,
    "BUSI": 4,
    "unknown": -1,
}


# ---------------------------------------------------------------------------
# Top-level Config
# ---------------------------------------------------------------------------

class Config:
    """Unified configuration container.

    Loads from YAML files, supports CLI overrides,
    and provides runtime display sections for logging.

    Usage:
        config = Config("configs/train_full.yaml")
        config.apply_overrides(epochs=200, learning_rate=0.0005)
    """

    def __init__(self, config_path: Optional[str] = None):
        self.model = ModelConfig()
        self.dataset = DatasetConfig()
        self.training = TrainingConfig()
        self.loss = LossConfig()
        self.augmentation = AugmentationConfig()
        self.metrics = MetricConfig()
        self.checkpoint = CheckpointConfig()
        self.inference = InferenceConfig()
        self.postprocess = PostprocessConfig()
        self.experiment = ExperimentConfig()
        self.monitoring = MonitoringConfig()
        self.train_split = TrainSplitConfig()

        if config_path:
            self.load_from_yaml(config_path)

    def load_from_yaml(self, config_path: str):
        """Load configuration from a single YAML file."""
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        with open(config_path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f) or {}

        section_map = {
            "model": self.model,
            "dataset": self.dataset,
            "training": self.training,
            "loss": self.loss,
            "augmentation": self.augmentation,
            "metrics": self.metrics,
            "checkpoint": self.checkpoint,
            "inference": self.inference,
            "postprocess": self.postprocess,
            "experiment": self.experiment,
            "monitoring": self.monitoring,
            "train_split": self.train_split,
            "project": self.experiment,
        }
        for key, target in section_map.items():
            if key in raw:
                self._update_dataclass(target, raw[key])

        self.training.refresh_runtime_defaults()

    def apply_overrides(self, **kwargs):
        """Apply CLI-style overrides. Supports dotted keys like 'training.epochs'."""
        for key, value in kwargs.items():
            if value is None:
                continue
            parts = key.split(".", 1)
            if len(parts) == 2:
                section_name, attr = parts
                section = getattr(self, section_name, None)
                if section is not None and hasattr(section, attr):
                    setattr(section, attr, value)
            else:
                for section in [
                    self.training, self.model, self.dataset, self.loss,
                    self.augmentation, self.metrics, self.checkpoint,
                    self.inference, self.postprocess, self.experiment,
                    self.monitoring, self.train_split,
                ]:
                    if hasattr(section, key):
                        setattr(section, key, value)
                        break

    def runtime_config_display_sections(self) -> Dict[str, Dict[str, Any]]:
        """Return a dict of {section_name: {field: value}} for logging."""
        sections = {}
        for attr_name in [
            "model", "dataset", "training", "loss", "augmentation",
            "metrics", "checkpoint", "inference", "postprocess",
            "experiment", "monitoring", "train_split",
        ]:
            obj = getattr(self, attr_name)
            attrs = {}
            for fld in fields(obj):
                val = getattr(obj, fld.name)
                if is_dataclass(val):
                    attrs[fld.name] = asdict(val)
                else:
                    attrs[fld.name] = val
            sections[attr_name.upper()] = attrs
        return sections

    def save_to_yaml(self, config_path: str):
        """Save full configuration to a single YAML file."""
        config_dict = {}
        for attr_name in [
            "model", "dataset", "training", "loss", "augmentation",
            "metrics", "checkpoint", "inference", "postprocess",
            "experiment", "monitoring", "train_split",
        ]:
            obj = getattr(self, attr_name)
            config_dict[attr_name] = {
                k: (asdict(v) if is_dataclass(v) else v)
                for k, v in vars(obj).items()
                if not k.startswith("_")
            }
        os.makedirs(os.path.dirname(config_path) or ".", exist_ok=True)
        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config_dict, f, default_flow_style=False, allow_unicode=True)

    def config_snapshot(self) -> dict:
        """Return a serializable snapshot for checkpoint saving."""
        config_dict = {}
        for attr_name in [
            "model", "dataset", "training", "loss", "augmentation",
            "metrics", "checkpoint", "inference", "postprocess",
            "experiment", "monitoring", "train_split",
        ]:
            obj = getattr(self, attr_name)
            config_dict[attr_name] = {
                k: (asdict(v) if is_dataclass(v) else v)
                for k, v in vars(obj).items()
                if not k.startswith("_")
            }
        return config_dict

    @staticmethod
    def _update_dataclass(instance, data: Dict[str, Any]):
        """Recursively update dataclass fields from a dict."""
        if data is None:
            return
        for key, value in data.items():
            if not hasattr(instance, key):
                continue
            current = getattr(instance, key)
            if isinstance(value, dict) and is_dataclass(current):
                Config._update_dataclass(current, value)
            else:
                setattr(instance, key, value)

    def __str__(self) -> str:
        return (
            f"Config:\n"
            f"  Model: {self.model.name}\n"
            f"  Input Size: {self.dataset.model_input_size}\n"
            f"  Batch Size: {self.training.batch_size}\n"
            f"  Learning Rate: {self.training.learning_rate}\n"
            f"  Device: {self.training.device}\n"
            f"  Stage: {self.training.stage}"
        )


def load_config(config_path: str) -> Config:
    """Load configuration from a YAML file."""
    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found: {config_path}")
    return Config(config_path)
