from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, ConfigDict


class RenderSessionStatus(str, Enum):
    """Supported statuses for video rendering sessions."""

    INITIATED = "initiated"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class RenderSessionBase(BaseModel):
    user_id: int
    original_clip_id: int
    render_id: Optional[str] = None
    edited_clip_id: Optional[int] = None
    status: RenderSessionStatus = RenderSessionStatus.INITIATED
    failure_reason: Optional[str] = None
    expired_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class RenderSessionCreate(RenderSessionBase):
    pass


class RenderSessionUpdate(BaseModel):
    render_id: Optional[str] = None
    edited_clip_id: Optional[int] = None
    status: Optional[RenderSessionStatus] = None
    failure_reason: Optional[str] = None
    expired_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class RenderSession(RenderSessionBase):
    id: int
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True)
