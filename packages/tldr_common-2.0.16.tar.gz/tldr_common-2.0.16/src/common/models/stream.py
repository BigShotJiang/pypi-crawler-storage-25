from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class StreamBase(BaseModel):
    """Base model for stream data."""

    game_name: Optional[str] = None
    user_id: int
    stream_id: str
    stream_start_time: datetime
    stream_end_time: Optional[datetime] = None
    platform: Optional[str] = None  # New field to specify the platform


class StreamCreate(StreamBase):
    """Model for creating a new stream."""

    pass


class StreamUpdate(BaseModel):
    """Model for updating stream data."""

    game_name: Optional[str] = None
    stream_start_time: Optional[datetime] = None
    stream_end_time: Optional[datetime] = None
    platform: Optional[str] = None  # New field to specify the platform


class Stream(StreamBase):
    """Complete stream model including database ID and end time."""

    id: int

    model_config = ConfigDict(from_attributes=True)


class StreamOnlineReconcileResult(BaseModel):
    """Result from reconciling an online event into the streams table."""

    stream: Stream
    created: bool = False
    reopened: bool = False
    closed_prior_stream_ids: list[str] = Field(default_factory=list)


class StreamOfflineReconcileResult(BaseModel):
    """Result from reconciling an offline event into the streams table."""

    stream_id: Optional[str] = None
    updated: bool = False
    duplicate_or_missing: bool = False
