# QAMigrate User Guide

> Step-by-step guide for migrating Selenium Java test suites to Playwright Java.

---

## What QAMigrate is responsible for (read this first)

QAMigrate is a **translation tool, not a debugger**. The boundary is important:

**QAMigrate's responsibility:**
- Translate valid Selenium Java patterns → valid Playwright Java patterns
- Preserve your project structure, framework (TestNG / JUnit / Cucumber),
  data-driven tests, and conventions
- Generate output that compiles when your input compiles

**NOT QAMigrate's responsibility:**
- Fix logic bugs in your source code
- Make broken source code compile
- Add methods that don't exist in your original
- Be blamed for source-side defects it faithfully translated forward

**The pre-flight gate (v0.7+).** Before migrating, QAMigrate runs
`mvn compile` on your Selenium project. If your source has compile errors,
the migration is **refused by default** with a clear list of the broken
files. You then have two choices:

1. **Fix the source errors and re-run** — recommended.
2. **Run with `--ignore-source-errors`** — proceeds anyway. The migrated
   output will inherit those errors. The migration report splits errors
   into "caused by QAMigrate" vs. "inherited from source" so you can see
   what's QAMigrate's fault and what was already broken.

If you see `Pre-flight check failed: source project does not compile.` — that
is QAMigrate refusing to migrate broken code. It's working as designed.

---

## Table of Contents

1. [What QAMigrate Does](#1-what-qamigrate-does)
2. [Before You Start — Prerequisites](#2-before-you-start--prerequisites)
3. [Installation](#3-installation)
4. [Setting Up Your API Key](#4-setting-up-your-api-key)
5. [Step 1 — Inspect Your Project (analyze)](#5-step-1--inspect-your-project-analyze)
6. [Step 2 — Initialize the Project (init)](#6-step-2--initialize-the-project-init)
7. [Step 3 — Dry Run (preview without spending API credits)](#7-step-3--dry-run-preview-without-spending-api-credits)
8. [Step 4 — Run the Migration (migrate)](#8-step-4--run-the-migration-migrate)
9. [Reading the Migration Report](#9-reading-the-migration-report)
10. [Step 5 — Verify the Output Compiles](#10-step-5--verify-the-output-compiles)
11. [Migrating a Single File](#11-migrating-a-single-file)
12. [Choosing Your LLM Provider and Model](#12-choosing-your-llm-provider-and-model)
13. [Configuration File (qamigrate.yaml)](#13-configuration-file-qamigrateyaml)
14. [Cucumber BDD Projects](#14-cucumber-bdd-projects)
15. [CI / CD Integration](#15-ci--cd-integration)
16. [Common Problems and Fixes](#16-common-problems-and-fixes)
17. [Command Reference](#17-command-reference)
18. [FAQ](#18-faq)

---

## 1. What QAMigrate Does

QAMigrate reads your entire Selenium Java project, understands how it is built
(class roles, dependencies, conventions), then calls an LLM (Claude or GPT-4o)
to rewrite every file from Selenium to Playwright.

It is not a search-and-replace tool. For each file the LLM sees:

- The original source code
- The class's role (page object, base class, test class, driver manager, …)
- Every dependency it calls — with the real migrated method signatures
- Your project's conventions (method chaining style, logging pattern, assertion
  library, driver access pattern)
- An explicit checklist of every public method and constructor the output MUST
  contain

After generation, a deterministic post-processing pass fixes known patterns
(Javadoc placement, HTML-encoded angle brackets in generics, leftover Selenium
imports, etc.). Then javac compiles everything and an LLM-powered Fixer agent
iteratively repairs compile errors up to your configured retry limit.

**What stays the same:**

| What you have | What you keep |
|---|---|
| Maven or Gradle | Same build tool |
| TestNG annotations | TestNG annotations — exact same |
| JUnit 4 or JUnit 5 | Same framework |
| `@DataProvider` / `@Parameters` | Kept verbatim |
| Cucumber `.feature` files | 100% untouched |
| Step definition signatures | Frozen — Gherkin still matches |
| Package structure | Same hierarchy + `.playwright` sub-package |
| Base class inheritance | Preserved |

**What changes:**

| Selenium | Playwright |
|---|---|
| `@FindBy(id="x")` | `page.locator("#x")` stored as `Locator` field |
| `PageFactory.initElements` | Removed — constructor injection |
| `WebDriverWait` / `ExpectedConditions` | Removed — Playwright auto-waits |
| `element.sendKeys("text")` | `locator.fill("text")` |
| `element.click()` | `locator.click()` |
| `element.getText()` | `locator.textContent()` |
| `driver.findElements(By.x)` | `page.locator(x).all()` |
| `driver.get(url)` | `page.navigate(url)` |
| `JavascriptExecutor.executeScript` | `page.evaluate(script)` |
| `Assert.assertTrue(el.isDisplayed())` | `assertThat(locator).isVisible()` |

---

## 2. Before You Start — Prerequisites

| Requirement | Details |
|---|---|
| **Python 3.11 or newer** | Check: `python --version` |
| **Java 17 or newer** | Used to compile the generated Playwright code. Check: `java -version` |
| **Maven or Gradle** | Your project's existing build tool — QAMigrate uses it for classpath resolution and compile validation |
| **An API key** | Either Anthropic (`ANTHROPIC_API_KEY`) or OpenAI (`OPENAI_API_KEY`) |
| **Internet access** | QAMigrate calls the LLM API over HTTPS |

> **Can I skip Java?** Yes. Set `compiler.skip: true` in `qamigrate.yaml` or
> pass `QAMIGRATE_COMPILER__SKIP=true`. Files will be generated but not
> compile-validated. Useful when Playwright JARs are not available locally.

---

## 3. Installation

```bash
pip install qamigrate
```

Verify the installation:

```bash
qamigrate --version
```

You should see something like `qamigrate 0.6.3`.

> **Virtual environment recommended.** QAMigrate installs the Anthropic and
> OpenAI SDKs. Using a virtual environment avoids version conflicts with your
> other Python projects.
>
> ```bash
> python -m venv .venv
> source .venv/bin/activate   # Windows: .venv\Scripts\activate
> pip install qamigrate
> ```

---

## 4. Setting Up Your API Key

### Option A — Environment variable (recommended for CI)

```bash
# Anthropic
export ANTHROPIC_API_KEY=sk-ant-api03-...

# OpenAI
export OPENAI_API_KEY=sk-proj-...
```

On Windows PowerShell:

```powershell
$env:ANTHROPIC_API_KEY = "sk-ant-api03-..."
```

### Option B — `.env` file in your project root

Create a file called `.env` next to your `pom.xml`:

```
ANTHROPIC_API_KEY=sk-ant-api03-...
```

QAMigrate loads `.env` automatically on startup.

> **Which provider should I use?**
> Anthropic Claude produces better Java code and is the recommended default.
> OpenAI GPT-4o is a solid alternative. You can mix providers — use Claude for
> the Coder agent and GPT-4o-mini (cheaper) for the Fixer agent.
> See [Section 12](#12-choosing-your-llm-provider-and-model) for details.

---

## 5. Step 1 — Inspect Your Project (analyze)

Before spending any API credits, run `analyze`. It reads your entire project
using Tree-sitter (zero LLM calls, zero cost) and produces an architecture
report.

```bash
qamigrate analyze \
  --project ./my-selenium-project \
  --output ./qamigrate-analysis
```

This writes three files to `./qamigrate-analysis/`:

| File | Purpose |
|---|---|
| `architecture.html` | Visual report — open in any browser |
| `architecture.md` | Same content in Markdown |
| `project-map.json` | Machine-readable class graph |

**What to look for in the report:**

- **Classes by role** — QAMigrate must correctly identify your base classes,
  page objects, test classes, and driver manager. If something is categorized
  as `OTHER` when it should be `PAGE`, check whether the class name or
  annotations match common patterns.
- **Infrastructure** — Confirm it detected the right test framework (TestNG /
  JUnit 4 / JUnit 5), Selenium version, and build tool.
- **Conventions** — Check that `Driver access` and `Logger pattern` are
  populated. These inform the generated code style.
- **Warnings** — Any warnings listed here are things to investigate before
  migrating.

> The `analyze` step is free. Run it first, every time.

---

## 6. Step 2 — Initialize the Project (init)

`init` prepares your project's build file to accept Playwright-generated code.
It detects your test framework and injects the correct dependencies into
`pom.xml` (or `build.gradle`).

```bash
qamigrate init \
  --project ./my-selenium-project \
  --yes
```

`--yes` skips the interactive confirmation prompt and automatically injects
the dependencies.

**What it adds to `pom.xml`:**

- `com.microsoft.playwright:playwright` at the latest stable version
- Your existing test framework (TestNG / JUnit 4 / JUnit 5) if not already
  present at the correct version

> **Does `init` modify my Selenium code?** No. It only touches `pom.xml` (or
> `build.gradle`). Your existing test classes are not changed.

> **Do I have to run `init`?** No, but without it `mvn compile` on the
> generated Playwright code will fail with "package com.microsoft.playwright
> does not exist" because the dependency is missing.

---

## 7. Step 3 — Dry Run (preview without spending API credits)

A dry run analyses every file and tells you exactly what would happen — which
files would be migrated, which would be passed through verbatim, and what
patterns were detected. It makes zero LLM calls and writes nothing.

```bash
qamigrate migrate --all \
  --project ./my-selenium-project \
  --dry-run
```

Sample output:

```
QAMigrate — DRY RUN (no LLM calls, no writes)

  [1/15] Environment.java        PASSTHROUGH  (enum — no Selenium markers)
  [2/15] BaseTest.java           WOULD MIGRATE  4 patterns detected
  [3/15] LoginPage.java          WOULD MIGRATE  9 patterns detected
  [4/15] TestRunner.java         PASSTHROUGH  (Cucumber runner — copied verbatim)
  ...

  15 files total  |  11 to migrate  |  4 passthrough
```

Use the dry run to:

- Confirm the file count before committing API budget
- Spot files QAMigrate would skip that you expect to be migrated (check
  whether they contain Selenium imports)
- Identify enums, DTOs, and runner files that will be copied unchanged

---

## 8. Step 4 — Run the Migration (migrate)

```bash
qamigrate migrate --all \
  --project ./my-selenium-project \
  --provider anthropic \
  --model claude-sonnet-4-20250514 \
  --report ./qamigrate-report
```

QAMigrate prints progress as each file completes:

```
QAMigrate — Migrating 11 file(s)

  -> [1/11] BaseTest.java         OK  playwright/BaseTest.java        (22.1s, 90% confidence)
  -> [2/11] DriverManager.java    OK  playwright/DriverManager.java   (18.4s, 100% confidence)
  -> [3/11] LoginPage.java        OK  playwright/LoginPage.java       (14.2s, 100% confidence)
  -> [4/11] DashboardPage.java    OK  playwright/DashboardPage.java   (16.7s, 95% confidence)
  -> [5/11] CheckoutPage.java     OK  playwright/CheckoutPage.java    (19.3s, 90% confidence)
  -> [6/11] LoginTest.java        OK  playwright/LoginTest.java       (21.5s, 95% confidence)
  ...

  Files             11 / 11
  Patterns handled  87
  Avg confidence    95%
  Total time        193s
  Est. hours saved  ~21.8

  Report written:
    HTML:     ./qamigrate-report/report.html
    JSON:     ./qamigrate-report/report.json
    Markdown: ./qamigrate-report/report.md
    Review:   ./qamigrate-report/review.md
```

### Where do the generated files go?

Each generated file is placed **next to the original**, inside a `playwright/`
subfolder:

```
src/test/java/com/example/pages/
    LoginPage.java                  ← original (untouched)
    playwright/
        LoginPage.java              ← generated Playwright version
```

The generated file uses the package `com.example.pages.playwright` so both
versions can coexist in the same Maven project without collision.

### How long does it take?

- Roughly **15–30 seconds per file** depending on file size and provider
- A 15-file project takes roughly 5–10 minutes end-to-end
- Larger files (500+ LOC) can take up to 60 seconds per file

### What if a file fails?

QAMigrate keeps going. A single file failure does not stop the run. Failed
files are marked in the report with the compiler error and confidence score.
You can re-run on just the failed file (see [Section 11](#11-migrating-a-single-file)).

---

## 9. Reading the Migration Report

Open `./qamigrate-report/report.html` in your browser.

### Top bar

Shows the migration direction (Selenium → Playwright), start time, and finish time.

### Metric cards (top row)

| Card | What it means |
|---|---|
| **Migrated** | Files generated successfully / total files |
| **Failed** | Files where generation or compilation failed |
| **Patterns** | Total Selenium patterns QAMigrate handled |
| **Avg confidence** | Mean confidence score across all files |
| **Total time** | Wall-clock time for the whole run |
| **Hours saved** | Estimated manual developer-hours avoided |

### Review buckets

Three buckets sort your files by how much attention they need:

| Bucket | Meaning | Action |
|---|---|---|
| **Priority** (red) | Failed generation, did not compile, or confidence < 70% | Fix or re-run these first |
| **Verify** (amber) | Compiled, but has hallucinations or needed 3+ fix attempts | Skim the diff |
| **Solid** (green) | Confidence ≥ 90%, compiled clean, zero hallucinations | Spot-check a few at random |

### File cards

Click any file card to expand it:

- **Status** — ✓ Success or ✗ Failed
- **Confidence %** — color-coded bar (green ≥ 90%, amber 70–89%, red < 70%)
- **Compiler badge** — Compiled / Did not compile / Skipped
- **Fix attempts** — how many Fixer iterations were needed
- **Hallucination badge** — method calls that don't exist on the migrated classes
- **Confidence reason** — plain-English explanation of the score
- **Patterns handled** — list of Selenium patterns and how each was handled
- **Before → After diff** — side-by-side diff of original vs. generated code

### review.md

`review.md` is a Markdown checklist for your QA lead. It lists the same three
buckets with one checkbox per file, making it easy to track the manual review
process in GitHub Issues or Notion.

---

## 10. Step 5 — Verify the Output Compiles

After migration, verify everything compiles from scratch:

```bash
cd my-selenium-project
mvn clean compile
```

If this succeeds: you are done. The generated Playwright code is on the
classpath and ready for test execution.

If there are compile errors: check `./qamigrate-report/review.md` for files
in the Priority bucket — those are the most likely sources of remaining errors.

---

## 11. Migrating a Single File

To migrate one file instead of the whole project:

```bash
qamigrate migrate src/test/java/com/example/pages/LoginPage.java \
  --project ./my-selenium-project \
  --provider anthropic
```

Useful for:
- Re-running a single file that failed
- Testing QAMigrate on one file before committing to the full run
- Migrating files incrementally

### Excluding sub-projects (monorepos)

If your repository contains several Selenium sub-projects under one root and
you want to migrate them independently, use `--exclude`:

```bash
# Migrate only `frontend-tests`, skipping the other two sub-projects
qamigrate migrate --all --project ./monorepo \
  --exclude 'api-tests/**' \
  --exclude 'mobile-tests/**' \
  --provider anthropic \
  --report ./qamigrate-report
```

Patterns are evaluated relative to `--project` and use the same `fnmatch`
glob syntax as `scanner.exclude_patterns` in `qamigrate.yaml` — `**` matches
across directories, `*` matches within a single segment.

`--exclude` is repeatable: pass it once per pattern.

---

## 12. Choosing Your LLM Provider and Model

### Recommended setup

```bash
# Best quality — Claude for everything
qamigrate migrate --all --project . \
  --provider anthropic \
  --model claude-sonnet-4-20250514

# Cost-optimised — Claude for generation, GPT-4o-mini for fixing
qamigrate migrate --all --project . \
  --coder-provider anthropic --coder-model claude-sonnet-4-20250514 \
  --fixer-provider openai   --fixer-model gpt-4o-mini
```

### Provider comparison

| Provider | Model | Strength | Cost |
|---|---|---|---|
| Anthropic | `claude-sonnet-4-20250514` | Best Java code quality, API preservation | Medium |
| Anthropic | `claude-haiku-4-5-20251001` | Faster, lower cost | Low |
| OpenAI | `gpt-4o` | Good alternative | Medium |
| OpenAI | `gpt-4o-mini` | Good for Fixer (short fix loops) | Low |

### Using a config file instead of flags

```yaml
# qamigrate.yaml — place next to pom.xml
coder:
  provider: anthropic
  model: claude-sonnet-4-20250514

fixer:
  provider: openai
  model: gpt-4o-mini
```

Then just run:

```bash
qamigrate migrate --all --project .
```

---

## 13. Configuration File (qamigrate.yaml)

Place `qamigrate.yaml` in your project root (next to `pom.xml`).

```yaml
# How many times the Fixer agent retries compilation errors per file (0-10)
pipeline:
  max_retries: 3

# Coder agent — generates the initial Playwright translation
coder:
  provider: anthropic
  model: claude-sonnet-4-20250514
  max_tokens: 16384     # Increase for very large files (1000+ LOC)
  temperature: 0.1

# Fixer agent — iteratively repairs compile errors
fixer:
  provider: openai
  model: gpt-4o-mini
  max_fix_attempts: 3
  max_fix_seconds: 300  # Give up on a file after 5 minutes (prevents runaway loops)

# Compilation settings
compiler:
  build_tool: maven       # or: gradle
  java_version: "17"      # Detected from pom.xml if omitted
  timeout_seconds: 120    # Max javac time per batch compile
  skip: false             # Set true when Playwright JARs not on local classpath

# Maven classpath resolution
classpath:
  timeout_seconds: 60     # Max mvn dependency:build-classpath time
  use_cache: true         # Cache result in .qamigrate/classpath.txt

# File scanner
scanner:
  exclude_patterns:
    - "**/target/**"
    - "**/build/**"
    - "**/playwright/**"   # Exclude already-generated files on re-runs
  max_file_size_kb: 500

# Logging
logging:
  level: INFO             # DEBUG for verbose output
  format: json
```

### Environment variable overrides

Any setting can be overridden with an environment variable using the
`QAMIGRATE_` prefix and `__` as the nesting separator:

```bash
export QAMIGRATE_PIPELINE__MAX_RETRIES=5
export QAMIGRATE_COMPILER__SKIP=true
export QAMIGRATE_CODER__MODEL=gpt-4o
```

This is useful in CI when you want to keep a baseline config file but override
specific settings per environment.

---

## 14. Cucumber BDD Projects

QAMigrate automatically detects Cucumber BDD projects. No special flags are
needed.

```bash
qamigrate migrate --all \
  --project ./my-cucumber-project \
  --provider anthropic
```

### What gets migrated, what does not

| File type | Treatment |
|---|---|
| `.feature` files | **Untouched** — Gherkin is framework-neutral |
| Step definition classes | Body rewritten (Selenium → Playwright); `@Given`/`@When`/`@Then` annotations frozen |
| Cucumber Hooks (`@Before`/`@After`) | Structure preserved; WebDriver replaced with Playwright browser/page |
| `TestRunner.java` / JUnit Platform Suite | **Copied verbatim** — not LLM-migrated |
| `DriverManager.java` (ThreadLocal) | Migrated: `ThreadLocal<WebDriver>` → `ThreadLocal<Page>` + context/browser/playwright |
| Page objects | Migrated normally |

### Cucumber-specific rules QAMigrate enforces

- `@Before` / `@After` are from `io.cucumber.java` — NOT replaced with JUnit5
  lifecycle annotations
- `@ExtendWith` is never added to step definition or hooks classes
- `io.cucumber.*` imports never get a `.playwright` suffix
- Step method parameter types are never changed

---

## 15. CI / CD Integration

### Basic CI step

```yaml
# GitHub Actions example
- name: Migrate Selenium to Playwright
  env:
    ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
  run: |
    pip install qamigrate
    qamigrate migrate --all \
      --project ./selenium-project \
      --provider anthropic \
      --report ./migration-report
```

### Quality gate — fail the pipeline if confidence drops

```bash
qamigrate migrate --all \
  --project . \
  --provider anthropic \
  --confidence-threshold 80 \
  --confidence-mode avg
```

Exit codes:

| Code | Meaning |
|---|---|
| `0` | All files migrated successfully |
| `1` | One or more files failed to generate or compile |
| `2` | Confidence gate not met (quality below threshold) |

### Saving the report as a CI artifact

```yaml
- name: Upload migration report
  uses: actions/upload-artifact@v4
  with:
    name: migration-report
    path: ./migration-report/
```

### Skip compilation in CI (no Playwright JARs locally)

If the CI runner does not have `mvn dependency:build-classpath` set up:

```bash
QAMIGRATE_COMPILER__SKIP=true qamigrate migrate --all --project .
```

---

## 16. Common Problems and Fixes

### "ANTHROPIC_API_KEY not found" / "OPENAI_API_KEY not found"

The API key is not set in the environment.

**Fix:**

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# or put it in a .env file next to pom.xml
```

### "package com.microsoft.playwright does not exist" after migration

The Playwright dependency was not added to `pom.xml`.

**Fix:** Run `qamigrate init --project . --yes` and then `mvn clean compile`.

### A file shows "confidence 50%, did not compile"

The Fixer exhausted its retry limit (default: 3 attempts).

**Fix options:**

1. Re-run the file alone: `qamigrate migrate path/to/File.java --project .`
2. Increase retries: add `pipeline.max_retries: 5` to `qamigrate.yaml`
3. Open the generated file and fix manually — the compiler error is in the report

### "max_tokens truncation" warning in the logs

The LLM ran out of output tokens and produced an incomplete file. This happens
with very large classes (1000+ LOC, 30+ methods).

**Fix:** Add to `qamigrate.yaml`:

```yaml
coder:
  max_tokens: 32768
```

### Generated file has wrong package name

All generated files should declare `package com.your.original.package.playwright;`.
If the package is wrong, the Compiler stage will catch it.

**Fix:** Re-run the specific file. If it persists, check that the original file
has a valid `package` declaration at the top.

### "Usage cap exhausted" error

Your Anthropic or OpenAI account hit its monthly or per-minute quota.

**Fix:**
- Wait for the quota to reset (the error message shows when)
- Switch to the other provider temporarily:
  `--provider openai --model gpt-4o`

### Cucumber step definitions have wrong method signatures

QAMigrate freezes step definition signatures. If you see wrong signatures, the
original source file probably does not match the Gherkin step text.

**Fix:** Ensure the original source compiles and step annotations match the
feature file BEFORE running QAMigrate.

### `qamigrate analyze` shows a class as `OTHER` instead of its real role

The role inference is heuristic-based. It looks at class names, annotations,
and parent classes.

**Fix:** This does not block migration. The Coder still generates correct code.
The role affects how the class is displayed in the report, not how it is
migrated.

---

## 17. Command Reference

### `qamigrate init`

Detect your test framework and inject Playwright dependencies into `pom.xml` or
`build.gradle`.

```
Options:
  --project, -p <path>    Project root (default: current directory)
  --config, -c <path>     Path to qamigrate.yaml
  --yes, -y               Auto-inject without prompting
```

### `qamigrate scan`

Scan the project for Selenium patterns and show a summary.

```
Options:
  --project, -p <path>    Project root
  --output, -o <path>     Write results to JSON file
  --verbose, -V           Show pattern details per file
```

### `qamigrate analyze`

Build the full architecture report (zero LLM calls, zero cost).

```
Options:
  --project, -p <path>    Project root
  --output, -o <path>     Output directory (default: ./qamigrate-report)
```

### `qamigrate migrate`

Migrate Selenium Java files to Playwright Java.

```
Arguments:
  [file]                  Migrate a single file (omit to use --all)

General:
  --all, -a               Migrate all Java files in the project
  --dry-run               Analyse only — no LLM calls, no writes
  --report, -r <dir>      Write report.html, report.json, report.md, review.md
  --project, -p <path>    Project root
  --exclude <pattern>     Exclude files matching this glob, relative to --project.
                          Repeatable. Example: --exclude 'subproj-a/**'
  --ignore-source-errors  Migrate even if `mvn compile` fails on the source
                          Selenium project. By default QAMigrate refuses to
                          run on broken source.
  --no-batch-compile      Per-file compile loop (debugging only)

Quality gate:
  --confidence-threshold N    Fail (exit 2) if confidence below N%
  --confidence-mode avg|any   "any" = fail if any file below threshold
                              "avg" = fail if project average below threshold

LLM (shorthand — applies to both Coder and Fixer):
  --provider <name>       anthropic or openai
  --model <id>            Model name (e.g. claude-sonnet-4-20250514, gpt-4o)

LLM (per-agent overrides):
  --coder-provider <name>     Coder agent provider
  --coder-model <id>          Coder agent model
  --fixer-provider <name>     Fixer agent provider
  --fixer-model <id>          Fixer agent model

Exit codes:
  0    All files migrated successfully
  1    Generation or compilation failure
  2    Confidence gate not met (or LLM provider quota exhausted)
  3    Source project does not compile (pass --ignore-source-errors to override)
```

---

## 18. FAQ

**Q: Does QAMigrate modify my original Selenium files?**

No. Your Selenium source is never changed. Generated Playwright files go into
a `playwright/` subfolder alongside the originals.

---

**Q: Do I need to run `init` every time?**

No. Run it once per project. After that, just run `migrate`.

---

**Q: Can I run QAMigrate on the same project twice?**

Yes. On a second run, QAMigrate regenerates all files. The `scanner.exclude_patterns`
list already excludes `**/playwright/**` so previously generated files are not
re-scanned as input.

---

**Q: Can I migrate only some files, not the whole project?**

Yes. Pass a file path instead of `--all`:

```bash
qamigrate migrate src/test/java/com/example/pages/LoginPage.java \
  --project ./my-project
```

Or run `--all` with `scanner.exclude_patterns` configured to skip files you
want to handle manually.

---

**Q: What happens to enums, DTOs, and data classes?**

Files with no Selenium markers (no Selenium imports, no `@FindBy`, no
`WebDriver` usage) are passed through verbatim — copied to the `playwright/`
output folder without any LLM call.

---

**Q: How much does a migration cost in API credits?**

Roughly:
- **Small project (15 files):** ~$0.30–$0.80 with Claude Sonnet
- **Medium project (50 files):** ~$1.00–$3.00
- **Large project (150+ files):** ~$4.00–$12.00

Use `--dry-run` first to count files. Use `gpt-4o-mini` for the Fixer to cut
costs by 80–90% on the fix loop.

---

**Q: Can I use a local model (Ollama)?**

The Ollama provider is in the registry but experimental. Results vary widely
by model quality. Only use it if the model has strong Java code generation
ability (Code Llama 34B or better). Set in `qamigrate.yaml`:

```yaml
coder:
  provider: ollama
  model: codellama:34b

llm:
  providers:
    ollama:
      host: http://localhost:11434
```

---

**Q: My project uses a custom base class — will it be preserved?**

Yes. QAMigrate reads the inheritance hierarchy. If your test classes extend
`BaseTest` and `BaseTest` has a `protected Page getPage()` method, the
generated test classes will call `getPage()` directly instead of reaching into
`DriverManager`.

---

**Q: Can I use QAMigrate from Python code instead of the CLI?**

Yes:

```python
from pathlib import Path
from qamigrate.agents.pipeline import run_project_migration
from qamigrate.core.config import QAMigrateConfig
from qamigrate.core.report import MigrationReport

config = QAMigrateConfig.load(Path("qamigrate.yaml"))
result = run_project_migration(
    files=[Path("src/test/java/LoginPage.java")],
    project_path=Path("."),
    config=config,
)

report = MigrationReport()
for record in result.records:
    report.add(record)
report.finish()
report.write_html(Path("./report.html"))
report.write_review_markdown(Path("./review.md"))
```

---

*QAMigrate is a [QATonic Innovations](https://github.com/QATonic) product.*
*Report issues at [github.com/QATonic/QAMigrate/issues](https://github.com/QATonic/QAMigrate/issues).*
