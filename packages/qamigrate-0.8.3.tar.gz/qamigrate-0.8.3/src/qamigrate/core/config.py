"""Core configuration module for QAMigrate."""

from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, ConfigDict, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


# v0.6.1: every nested config model rejects unknown keys. A shared base
# class keeps this opt-in for any future BaseModel that should NOT forbid
# extras (none currently).
class _StrictBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

# Load .env file from current directory or project root
load_dotenv()


def _validate_provider_name(value: str, agent: str) -> str:
    """v0.6.1: cross-check a provider name against the LLM registry.

    Done lazily (import inside the function) so importing config.py doesn't
    drag the LLM stack into command-line tools that only need to validate
    a YAML file.
    """
    from qamigrate.llm.registry import list_providers
    known = list_providers()
    if value not in known:
        raise ValueError(
            f"{agent}.provider = {value!r} is not a registered LLM provider. "
            f"Known providers: {sorted(known)}"
        )
    return value


class PipelineConfig(_StrictBase):
    """Pipeline orchestration settings."""

    max_retries: int = Field(default=3, ge=0, le=10, description="Maximum fix attempts before failing (0-10)")
    batch_compile: bool = Field(
        default=True,
        description="Compile all generated files together (v0.3+). Set False "
                    "to fall back to the v0.2 per-file compile loop.",
    )


class ClasspathConfig(_StrictBase):
    """Build-system classpath resolution settings (v0.3+)."""

    timeout_seconds: int = Field(default=60, ge=10, le=600, description="Max time for `mvn dependency:build-classpath` (10-600s)")
    use_cache: bool = Field(default=True, description="Reuse .qamigrate/classpath.txt if present")


class ScannerConfig(_StrictBase):
    """Configuration for the Scanner Agent."""

    include_patterns: list[str] = Field(default=["**/*.java"])
    exclude_patterns: list[str] = Field(default=["**/target/**", "**/build/**", "**/playwright/**"])
    max_file_size_kb: int = Field(default=500, ge=1, le=10240, description="Max Java file size to scan (1-10240 KB)")


class CoderConfig(_StrictBase):
    """Configuration for the Coder Agent."""

    provider: str = Field(
        default="anthropic",
        description="LLM provider name: 'anthropic', 'openai', etc. Must be registered in qamigrate.llm.registry.",
    )
    model: str = Field(default="claude-sonnet-4-20250514")
    temperature: float = Field(default=0.1)
    # v0.6.1: bumped from 8192 -> 16384. v0.6.0's API-preservation
    # requirement keeps every overload, which means utility classes like
    # WebUI.java (1000+ LOC, 30+ public methods) need more output tokens.
    # The v0.6.1 production run hit max_tokens truncation on WebUI at
    # 8192. 16384 is the next standard step and covers the largest files
    # we've observed in real projects.
    max_tokens: int = Field(default=16384)

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        # v0.6.1: fail fast on misspelled provider names. Without this,
        # a typo like `provider: "anthropi"` only fails 20 minutes into
        # the run when build_provider() raises an unhelpful error.
        return _validate_provider_name(v, "coder")


class CompilerConfig(_StrictBase):
    """Configuration for the Compiler Agent."""

    build_tool: str = Field(default="maven")
    timeout_seconds: int = Field(default=120, ge=10, le=600, description="javac timeout in seconds (10-600)")
    java_version: str = Field(default="17")
    skip: bool = Field(default=False, description="Skip compilation validation (useful when Playwright JARs not available locally)")

    @field_validator("build_tool")
    @classmethod
    def validate_build_tool(cls, v: str) -> str:
        if v not in ("maven", "gradle"):
            raise ValueError(f"build_tool must be 'maven' or 'gradle', got {v!r}")
        return v


class FixerConfig(_StrictBase):
    """Configuration for the Fixer Agent."""

    provider: str = Field(
        default="anthropic",
        description="LLM provider name: 'anthropic', 'openai', etc. Must be registered in qamigrate.llm.registry.",
    )
    model: str = Field(default="claude-sonnet-4-20250514")
    max_fix_attempts: int = Field(default=3)
    use_rule_based_first: bool = Field(default=True)
    group_similar_errors: bool = Field(default=True)
    # v0.5.16: wall-clock budget per file in the fix loop.
    # The production run showed TestSimpleCode.java spending 7.4 hours in the
    # Fixer loop (26,614s). Iteration count alone is not enough: one iteration
    # can call the LLM many times for large files. This caps total wall-clock
    # time per file; the pipeline marks the file FAIL and moves on.
    max_fix_seconds: int = Field(
        default=300,
        ge=30,
        le=3600,
        description="Max wall-clock seconds per file in the compile-fix loop (30-3600). "
                    "Files that haven't converged after this time are marked FAIL and skipped.",
    )

    @field_validator("provider")
    @classmethod
    def validate_provider(cls, v: str) -> str:
        return _validate_provider_name(v, "fixer")


class AnthropicProviderSettings(_StrictBase):
    """Provider-specific settings for Anthropic."""

    api_key_env: str = Field(default="ANTHROPIC_API_KEY")


class OpenAIProviderSettings(_StrictBase):
    """Provider-specific settings for OpenAI (including Azure/proxy setups)."""

    api_key_env: str = Field(default="OPENAI_API_KEY")
    base_url: str | None = Field(
        default=None,
        description="Override the OpenAI base URL (e.g. for Azure OpenAI or a proxy).",
    )


class OllamaProviderSettings(_StrictBase):
    """Provider-specific settings for Ollama (local models)."""

    host: str = Field(default="http://localhost:11434")
    request_timeout_s: int = Field(default=120)


class LLMProvidersConfig(_StrictBase):
    """
    Top-level settings for each supported LLM provider.

    Users customize auth / base URL / host here; agent-level config picks
    which provider+model to use. Every provider has a sensible default
    that works out of the box for the standard setup.
    """

    anthropic: AnthropicProviderSettings = Field(default_factory=AnthropicProviderSettings)
    openai: OpenAIProviderSettings = Field(default_factory=OpenAIProviderSettings)
    ollama: OllamaProviderSettings = Field(default_factory=OllamaProviderSettings)


class LLMConfig(_StrictBase):
    """Top-level LLM settings (provider-specific auth, URLs, etc.)."""

    providers: LLMProvidersConfig = Field(default_factory=LLMProvidersConfig)


class LoggingConfig(_StrictBase):
    """Configuration for logging."""

    level: str = Field(default="INFO")
    format: str = Field(default="json")
    file: str | None = Field(default=None)


class ArtifactConfig(_StrictBase):
    """Configuration for artifact management."""

    output_dir: str = Field(default="./qamigrate-output")
    retention_days: int = Field(default=7)
    compress: bool = Field(default=True)


class QAMigrateConfig(BaseSettings):
    """Complete configuration for QAMigrate."""

    # v0.6.1: reject unknown YAML keys at load time. Previously a typo
    # like `compiler.javaversion` (instead of `java_version`) was silently
    # ignored, causing the user to wonder why their setting was not
    # respected. Note: `populate_by_name=True` so the existing
    # ANTHROPIC_API_KEY alias still works.
    model_config = SettingsConfigDict(
        env_prefix="QAMIGRATE_",
        env_nested_delimiter="__",
        extra="forbid",
        populate_by_name=True,
    )

    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)
    scanner: ScannerConfig = Field(default_factory=ScannerConfig)
    coder: CoderConfig = Field(default_factory=CoderConfig)
    compiler: CompilerConfig = Field(default_factory=CompilerConfig)
    fixer: FixerConfig = Field(default_factory=FixerConfig)
    classpath: ClasspathConfig = Field(default_factory=ClasspathConfig)
    llm: LLMConfig = Field(default_factory=LLMConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    artifacts: ArtifactConfig = Field(default_factory=ArtifactConfig)

    # API Keys (loaded from environment)
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")

    @classmethod
    def load(cls, config_path: Path | None = None) -> "QAMigrateConfig":
        """Load configuration from YAML file and environment variables."""
        config_data: dict[str, Any] = {}

        if config_path is None:
            config_path = Path.cwd() / "qamigrate.yaml"

        if config_path.exists():
            with open(config_path) as f:
                config_data = yaml.safe_load(f) or {}

        return cls(**config_data)


def get_config(config_path: Path | None = None) -> QAMigrateConfig:
    """Get configuration instance."""
    return QAMigrateConfig.load(config_path)
