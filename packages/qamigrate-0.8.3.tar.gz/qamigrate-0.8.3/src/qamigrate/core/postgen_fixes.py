"""
Deterministic post-generation fixups for known Playwright Java migration gaps.

These are rule-based, zero-LLM-cost transformations applied to every generated
file after the Coder runs but before the first compile attempt. They target
patterns the LLM consistently gets wrong regardless of provider or prompt.

v0.5.8:
  - @Listeners({X.class}) → @ExtendWith(X.class) (TestNG → JUnit5)
  - ScreenshotOptions import fix (inner class, not a top-level type)

v0.5.9:
  - @Listeners guard: only apply @ExtendWith when the listener class is
    likely to implement Extension. Otherwise remove the broken annotation
    and emit a compile-safe stub so javac can proceed.
  - Locator.WaitForOptions.setState(Locator.State.*) →
    setState(WaitForSelectorState.*)

v0.5.11:
  - Strip AssertJ imports from non-test files; replace with Playwright assertThat
  - Strip leftover Selenium imports from generated Playwright files
  - Ensure WaitForSelectorState import present when the type is referenced

v0.6.2:
  - Fix 14: Javadoc placed between method signature and `{` → move above signature.
    The LLM frequently emits `public void click(By by) /** Clicks element */ {`
    which javac rejects as a syntax error. Detected in 46/66 errors (70%) across
    3 projects in the v0.6.1 multi-project test run.
  - Fix 15: HTML entity escaping in generic types. The LLM emits
    `ThreadLocal&lt;Page&gt;` instead of `ThreadLocal<Page>` in Java source.
    A blanket decode of `&lt;` → `<`, `&gt;` → `>`, `&amp;` → `&` restores
    valid Java. Affected DriverManager.java with 18 compile errors in the run.
"""

from __future__ import annotations

import re

import structlog

logger = structlog.get_logger(__name__)


# ---------------------------------------------------------------------------
# Fix 1 — @Listeners → @ExtendWith
# ---------------------------------------------------------------------------
#
# TestNG uses @Listeners({MyListener.class}) on test classes.
# JUnit 5 equivalent: @ExtendWith(MyListener.class) (no array, no braces).
# The Coder copies the TestNG form verbatim, which javac rejects because
# org.testng.annotations.Listeners doesn't exist in the JUnit5 classpath.
#
# The import also changes:
#   import org.testng.annotations.Listeners; → REMOVE
#   ADD import org.junit.jupiter.api.extension.ExtendWith;
#
# We only rewrite the annotation form -- not arbitrary class references.

_LISTENERS_ANNOTATION_RE = re.compile(
    r"@Listeners\s*\(\s*\{([^}]+)\}\s*\)",
    re.MULTILINE,
)

# Remove these TestNG-specific imports; they have no JUnit5 equivalent.
_TESTNG_LISTENER_IMPORTS = re.compile(
    r"^\s*import\s+org\.testng\.annotations\.Listeners\s*;\s*\n?",
    re.MULTILINE,
)

_EXTENDWITH_IMPORT = "import org.junit.jupiter.api.extension.ExtendWith;"


def _fix_listeners_annotation(
    code: str,
    extension_classes: set[str] | None = None,
) -> tuple[str, bool]:
    """Rewrite @Listeners({X.class}) → @ExtendWith(X.class).

    v0.5.9 guard: @ExtendWith requires the listener to implement
    org.junit.jupiter.api.extension.Extension. If the listener implements
    ITestListener (TestNG), applying @ExtendWith blindly causes a type error:
      "Class<TestListener> cannot be converted to Class<? extends Extension>"

    We apply @ExtendWith only when the listener class name is in
    `extension_classes` (a caller-supplied set of class names known to
    implement Extension). When we can't confirm, we remove the @Listeners
    annotation and replace it with a safe no-op comment -- this eliminates
    the "cannot find symbol: @Listeners" error without introducing a new
    type error. The Fixer's LLM can then address the cross-file migration
    in a subsequent pass with full context.

    `extension_classes=None` uses the conservative path (always safe-remove)
    since we can't verify. Callers who have cross-file class info can pass
    the set of confirmed Extension implementors.

    Returns (new_code, changed).
    """
    if "@Listeners" not in code:
        return code, False

    known_extensions = extension_classes or set()
    changed = False
    result = code

    def _replace_listeners(m: re.Match) -> str:
        inner = m.group(1)  # "TestListener.class" or "A.class, B.class"
        classes = [c.strip() for c in inner.split(",") if c.strip()]
        # Extract simple names (strip ".class" suffix).
        names = [cls.replace(".class", "").strip() for cls in classes]

        if known_extensions and all(n in known_extensions for n in names):
            # All listeners confirmed as Extension implementors -- safe to rewrite.
            return "\n".join(f"@ExtendWith({cls})" for cls in classes)

        # Cannot confirm: remove the broken annotation and leave a TODO.
        # This makes javac happy (no unknown symbol) without introducing a
        # type error. The Fixer or a human can address the cross-file migration.
        todo = (
            "// TODO: @Listeners removed -- listener class(es) must implement\n"
            "// org.junit.jupiter.api.extension.Extension before @ExtendWith\n"
            "// can be used. Migrate "
            + ", ".join(names)
            + " to implement BeforeEachCallback/AfterEachCallback."
        )
        return todo

    new_result, count = _LISTENERS_ANNOTATION_RE.subn(_replace_listeners, result)
    if count:
        changed = True
        result = new_result
        # Remove old TestNG import regardless of path taken above.
        result = _TESTNG_LISTENER_IMPORTS.sub("", result)
        # Only add ExtendWith import if we actually emitted @ExtendWith.
        if "@ExtendWith(" in result and _EXTENDWITH_IMPORT not in result:
            result = _insert_import(result, _EXTENDWITH_IMPORT)

    return result, changed


# ---------------------------------------------------------------------------
# Fix 2 — ScreenshotOptions import
# ---------------------------------------------------------------------------
#
# The LLM hallucinates `import com.microsoft.playwright.options.ScreenshotOptions;`
# which does not exist. The correct type is `Page.ScreenshotOptions` (an inner
# class of Page). Fix:
#   1. Remove the non-existent import.
#   2. Replace standalone `ScreenshotOptions` type references with
#      `Page.ScreenshotOptions` so the code compiles.
#   3. Ensure `import com.microsoft.playwright.Page;` is present.
#
# We only fix the specific hallucinated path. Other options.* imports are left
# alone (AriaRole, SelectOption, etc. are legitimately in that package).

_FAKE_SCREENSHOT_IMPORT = re.compile(
    r"^\s*import\s+com\.microsoft\.playwright\.options\.ScreenshotOptions\s*;\s*\n?",
    re.MULTILINE,
)

_PAGE_IMPORT = "import com.microsoft.playwright.Page;"


def _fix_screenshot_options_import(code: str) -> tuple[str, bool]:
    """Remove the non-existent ScreenshotOptions import and fix usages.

    Returns (new_code, changed).
    """
    if "ScreenshotOptions" not in code:
        return code, False

    # Only act if the hallucinated import is present.
    if not _FAKE_SCREENSHOT_IMPORT.search(code):
        return code, False

    result = _FAKE_SCREENSHOT_IMPORT.sub("", code)
    # Replace bare `ScreenshotOptions` with `Page.ScreenshotOptions`.
    # Use word-boundary match to avoid touching `Page.ScreenshotOptions`
    # that a previous run may have already fixed.
    result = re.sub(
        r"(?<!Page\.)\bScreenshotOptions\b",
        "Page.ScreenshotOptions",
        result,
    )
    # Ensure Page is imported.
    if _PAGE_IMPORT not in result:
        result = _insert_import(result, _PAGE_IMPORT)

    # v0.6.1: report `changed` based on actual content diff, not the
    # presence of the trigger pattern. Previously this returned True even
    # when no further mutation was needed, breaking the identity-check
    # optimization in apply_all_postgen_fixes (which uses `is` to skip
    # writes when nothing changed).
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 3 — Locator.WaitForOptions.setState enum type
# ---------------------------------------------------------------------------
#
# The LLM generates:
#   .waitFor(new Locator.WaitForOptions().setState(Locator.State.HIDDEN))
#
# But setState() takes a WaitForSelectorState, not Locator.State. The correct
# Playwright Java API is:
#   import com.microsoft.playwright.options.WaitForSelectorState;
#   .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN))

_LOCATOR_STATE_RE = re.compile(
    r"\bLocator\.State\.([A-Z_]+)\b",
    re.MULTILINE,
)

_WAIT_FOR_SELECTOR_STATE_IMPORT = (
    "import com.microsoft.playwright.options.WaitForSelectorState;"
)


def _fix_locator_state_enum(code: str) -> tuple[str, bool]:
    """Replace Locator.State.X with WaitForSelectorState.X.

    Returns (new_code, changed).
    """
    if "Locator.State." not in code:
        return code, False

    result = _LOCATOR_STATE_RE.sub(r"WaitForSelectorState.\1", code)
    changed = result != code
    if changed and _WAIT_FOR_SELECTOR_STATE_IMPORT not in result:
        result = _insert_import(result, _WAIT_FOR_SELECTOR_STATE_IMPORT)
    return result, changed


# ---------------------------------------------------------------------------
# Fix 4 — AssertJ imports stripped from non-test files
# ---------------------------------------------------------------------------
#
# The LLM sometimes adds `import static org.assertj.core.api.Assertions.assertThat;`
# to utility/page-object files. AssertJ is not injected by `qamigrate init` and
# almost never a project dependency in the source tree. When it appears in
# src/main/java files, Maven fails with "package org.assertj.core.api does not exist".
#
# Fix: remove the static AssertJ import and replace any assertThat(x).isTrue()
# style calls with Playwright's assertThat(locator).isVisible() equivalent.
# Also ensures `import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;`
# is present when Playwright assertThat is used.

_ASSERTJ_STATIC_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)
_ASSERTJ_PACKAGE_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.assertj\.[^;]+;\s*\n?",
    re.MULTILINE,
)

# Playwright's assertThat import
_PW_ASSERT_IMPORT = "import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;"

# Common AssertJ boolean wrappers → Playwright equivalents.
# assertThat(locator.isVisible()).isTrue() → assertThat(locator).isVisible()
# assertThat(locator.isVisible()).isFalse() → assertThat(locator).isHidden()
_ASSERTJ_BOOL_PATTERNS = [
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isTrue\(\)"), r"assertThat(\1).isVisible()"),
    (re.compile(r"assertThat\(([^)]+)\.isVisible\(\)\)\.isFalse\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isHidden\(\)\)\.isTrue\(\)"), r"assertThat(\1).isHidden()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isTrue\(\)"), r"assertThat(\1).isEnabled()"),
    (re.compile(r"assertThat\(([^)]+)\.isEnabled\(\)\)\.isFalse\(\)"), r"assertThat(\1).isDisabled()"),
]


def _fix_assertj_imports(code: str) -> tuple[str, bool]:
    """Remove AssertJ imports and rewrite boolean assertions to Playwright form.

    Only fires when org.assertj imports are present. Does not touch test files
    that legitimately use AssertJ for non-Playwright assertions — the fix only
    replaces patterns that have a direct Playwright equivalent.

    Returns (new_code, changed).
    """
    if "org.assertj" not in code:
        return code, False

    result = code
    result = _ASSERTJ_STATIC_IMPORT_RE.sub("", result)
    result = _ASSERTJ_PACKAGE_IMPORT_RE.sub("", result)

    # Rewrite boolean wrapper patterns to Playwright assertThat.
    for pattern, replacement in _ASSERTJ_BOOL_PATTERNS:
        result = pattern.sub(replacement, result)

    # If Playwright assertThat is now used but not imported, add the import.
    if "assertThat(" in result and _PW_ASSERT_IMPORT not in result:
        result = _insert_import(result, _PW_ASSERT_IMPORT)

    return result, result != code


# ---------------------------------------------------------------------------
# Fix 5 — Strip leftover Selenium imports from generated files
# ---------------------------------------------------------------------------
#
# Generated files occasionally retain `import org.openqa.selenium.*` lines that
# were in the original source. These cause "package org.openqa.selenium does not
# exist" if selenium-java is not on the Playwright-only classpath.
#
# We remove the entire org.openqa.selenium.* import block. We also remove
# org.testng.* imports that aren't @Test/@BeforeMethod (those are already handled
# by the TestNG→JUnit5 migration; stragglers get cleaned here).

_SELENIUM_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.openqa\.selenium[^;]*;\s*\n?",
    re.MULTILINE,
)
_TESTNG_IMPORT_RE = re.compile(
    # Remove all TestNG imports. JUnit5 equivalents are added by the Coder.
    r"^\s*import\s+org\.testng(?!\.annotations\.Test\b)[^;]*;\s*\n?",
    re.MULTILINE,
)
# Also remove TestNG Assert static imports (replaced by JUnit5/Playwright assertions).
_TESTNG_ASSERT_IMPORT_RE = re.compile(
    r"^\s*import\s+static\s+org\.testng\.Assert[^;]*;\s*\n?",
    re.MULTILINE,
)


def _simple_name_from_import(import_line: str) -> str | None:
    """Extract the simple class name from a Java import line.

    'import org.testng.ITestListener;' -> 'ITestListener'
    'import static org.testng.Assert.assertEquals;' -> 'assertEquals'
    Returns None when the import ends in '.*' (wildcard).
    """
    # Strip leading whitespace and 'import [static] '
    m = re.search(r"import\s+(?:static\s+)?([\w.]+)\s*;", import_line)
    if not m:
        return None
    fq = m.group(1)
    last = fq.rsplit(".", 1)[-1]
    return None if last == "*" else last


def _import_is_still_used(import_line: str, code: str) -> bool:
    """Return True if the simple class name from `import_line` appears in
    the file body (i.e., the file still references the imported type/method).

    This guards the strip rule: we must NOT remove an import whose class is
    still referenced (e.g. `implements ITestListener` keeps the import).
    """
    name = _simple_name_from_import(import_line)
    if name is None:
        return False  # wildcard -- always safe to remove
    # Remove the import line itself before searching so we don't count the
    # import declaration as a "reference".
    body = code.replace(import_line, "", 1)
    return bool(re.search(rf"\b{re.escape(name)}\b", body))


def _fix_leftover_selenium_imports(
    code: str,
    strip_testng: bool = True,
) -> tuple[str, bool]:
    """Strip residual Selenium (and optionally TestNG) imports from a generated file.

    Args:
        strip_testng: When False (TestNG target framework), skip the TestNG
            import strip entirely. org.testng.* imports are intentional on
            the TestNG path. Selenium imports are still removed regardless.

    v0.5.12 guard: only remove an import if the imported class name is no longer
    referenced anywhere in the file body.

    Returns (new_code, changed).
    """
    result = code
    changed = False

    # Process Selenium imports line-by-line with the guard (always).
    for m in list(_SELENIUM_IMPORT_RE.finditer(code)):
        line = m.group(0)
        if not _import_is_still_used(line, result):
            result = result.replace(line, "", 1)
            changed = True

    if strip_testng:
        # On JUnit5 path: remove orphaned TestNG lifecycle/annotation imports
        # (they were replaced by JUnit5 equivalents by the Coder).
        for m in list(_TESTNG_IMPORT_RE.finditer(code)):
            line = m.group(0)
            if not _import_is_still_used(line, result):
                result = result.replace(line, "", 1)
                changed = True

        # TestNG Assert static imports are always safe to remove on the JUnit5
        # path — those calls are rewritten to JUnit5/Playwright assertions.
        for m in list(_TESTNG_ASSERT_IMPORT_RE.finditer(code)):
            line = m.group(0)
            result = result.replace(line, "", 1)
            changed = True

    return result, changed


# ---------------------------------------------------------------------------
# Fix 6 — Ensure WaitForSelectorState import when type is referenced
# ---------------------------------------------------------------------------
#
# After Fix 3 rewrites Locator.State.X → WaitForSelectorState.X, the import
# is added. But the Fixer may regenerate sections of the file without the import.
# This guard ensures the import is always present when the type appears.


def _ensure_wait_for_selector_state_import(code: str) -> tuple[str, bool]:
    """Add WaitForSelectorState import if the type is used but not imported."""
    if "WaitForSelectorState" not in code:
        return code, False
    if _WAIT_FOR_SELECTOR_STATE_IMPORT in code:
        return code, False
    return _insert_import(code, _WAIT_FOR_SELECTOR_STATE_IMPORT), True


# ---------------------------------------------------------------------------
# Shared helper
# ---------------------------------------------------------------------------


def _insert_import(code: str, import_stmt: str) -> str:
    """Insert `import_stmt` after the last existing import line.

    Falls back to inserting after the package declaration if there are no
    existing imports.
    """
    # Find the last import line.
    last_import = -1
    for m in re.finditer(r"^\s*import\s+[^;]+;\s*$", code, re.MULTILINE):
        last_import = m.end()

    if last_import != -1:
        return code[:last_import] + f"\n{import_stmt}" + code[last_import:]

    # No imports found -- insert after package declaration.
    pkg_match = re.search(r"^\s*package\s+[^;]+;\s*$", code, re.MULTILINE)
    if pkg_match:
        pos = pkg_match.end()
        return code[:pos] + f"\n\n{import_stmt}" + code[pos:]

    # Default: prepend.
    return f"{import_stmt}\n\n{code}"


# ---------------------------------------------------------------------------
# Fix 13 — Missing `{` between method signature and one-line body (v0.6.1)
# ---------------------------------------------------------------------------
#
# The LLM occasionally emits a non-abstract method as a one-liner without
# the opening brace. v0.6.1 production run on AutomationFrameworkSelenium
# had this in BrowserFactory.java:
#
#   private Browser createBrowser(BrowserType browserType) Playwright playwright = ...; return ...;
#
# Java requires:
#
#   private Browser createBrowser(BrowserType browserType) { Playwright playwright = ...; return ...; }
#
# The pattern is: <signature ending in `)`> <whitespace> <statement starting
# with a Java identifier or keyword> ... `;` ... `;` <line end>. Without the
# braces, the second `;` is a syntax error.
#
# Heuristic: if a line matches `<modifiers> <type> <name>(<args>)` followed
# by a non-`{`/`;`/`throws`/newline character, we wrap the rest of the line
# in `{ ... }`. We require the rest to contain a `;` so we don't trip on
# abstract / interface methods (Fix 11 handles those).

_NONABSTRACT_MISSING_BRACE_RE = re.compile(
    # Capture the modifier-laden signature ending at `)`.
    r"^("
    r"(?:\s*(?:public\s+|protected\s+|private\s+|static\s+|final\s+|synchronized\s+|default\s+)+)?"
    r"[\w<>\[\]\.]+\s+\w+\s*\([^)]*\)"
    r")"
    # Skip optional throws clause.
    r"(\s*(?:throws\s+[\w,\s\.]+?)?)"
    # Required: at least one space, then content that DOES NOT start with
    # `{`, `;`, or end-of-line. Must contain at least one `;` somewhere
    # before end-of-line so we don't trigger on abstract declarations.
    r"\s+([^{;\n][^\n]*;[^\n]*)$",
    re.MULTILINE,
)


def _fix_nonabstract_method_missing_brace(code: str) -> tuple[str, bool]:
    """Wrap an inline method body in `{ ... }` when the LLM omitted the braces.

    Targets:
      `<sig>) Playwright p = ...; return ...;`
    Produces:
      `<sig>) { Playwright p = ...; return ...; }`
    """
    if "(" not in code or ";" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        sig = m.group(1)
        throws = (m.group(2) or "").strip()
        body = m.group(3)
        # Don't touch lines that look like field/variable declarations.
        # The signature must contain `(` followed by `)` — we already
        # required that, but double-check that body has executable content.
        if "=" not in body and "return" not in body:
            return m.group(0)
        prefix = f"{sig}{(' ' + throws) if throws else ''}"
        return f"{prefix} {{ {body} }}"

    result = _NONABSTRACT_MISSING_BRACE_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 12 — Doubled method signature (v0.5.18 / v0.5.19)
# ---------------------------------------------------------------------------
#
# The LLM occasionally emits a method header twice in a row before the body:
#
#   synchronized public static void addAuthors(String[] authors)
#   synchronized public static void addAuthors(String[] authors) {
#       ...
#   }
#
# Production project's ExtentReportManager.java had 6 errors, all this shape.
# Java compiler rejects with "class, interface, enum, or record expected" /
# "<identifier> expected".
#
# The fix is structural and deterministic: when two byte-identical headers
# appear back-to-back (separated only by whitespace) and the second is
# followed by `{`, drop the first. We require exact textual match so we never
# collapse a real overload — overloads differ in their parameter list.

# Match a method header: at least one modifier (or annotation) + return type
# + name + (args). Requiring a modifier prevents the regex from matching
# random `funcCall(arg)` patterns inside method bodies.
#
# Modifiers accepted (any order, repeated): public/protected/private/static/
# final/abstract/synchronized/default/native/strictfp, plus @Override-style
# annotations.
_METHOD_HEADER_RE = (
    r"((?:(?:@\w+(?:\([^)]*\))?\s+)|"
    r"(?:public|protected|private|static|final|abstract|synchronized|default|native|strictfp)\s+)+"
    r"[\w.]+(?:<[^<>]*>)?(?:\[\])?"
    r"\s+\w+\s*\([^)]*\))"
)
_DOUBLED_METHOD_HEADER_RE = re.compile(
    rf"{_METHOD_HEADER_RE}\s+\1\s*(\{{)",
    re.MULTILINE,
)


def _fix_doubled_method_header(code: str) -> tuple[str, bool]:
    """Collapse `<header>  <header> {` into `<header> {` when both are identical.

    Requires textual identity, so legitimate overloads (different param lists)
    are never affected.
    """
    # Cheap early-out: we need at least one '(' and one '{'.
    if "(" not in code or "{" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        header = m.group(1)
        brace = m.group(2)
        return f"{header} {brace}"

    result = _DOUBLED_METHOD_HEADER_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 11 — Missing semicolon on abstract method declarations (v0.5.17)
# ---------------------------------------------------------------------------
#
# The LLM frequently emits abstract method declarations without the trailing
# semicolon, especially when followed by a trailing comment:
#   public abstract Foo bar(Baz baz)  // comment
# Java requires:
#   public abstract Foo bar(Baz baz);  // comment
#
# This pattern showed up in the production project's BrowserFactory.java
# (3 errors, all the same shape). Deterministic regex fix.

_ABSTRACT_METHOD_NO_SEMI_RE = re.compile(
    # Match: optional modifiers, "abstract", return type, name, args ),
    # then optional comment without a semicolon before line end.
    r"^(\s*(?:public\s+|protected\s+|private\s+)?abstract\s+[\w<>\[\]\.]+\s+\w+\s*\([^)]*\))(\s*(?://[^\n]*)?)$",
    re.MULTILINE,
)


def _fix_abstract_method_missing_semicolon(code: str) -> tuple[str, bool]:
    """Add `;` to abstract method declarations missing the terminator."""
    if "abstract" not in code:
        return code, False

    def _repl(m: re.Match) -> str:
        sig = m.group(1)
        trailing = m.group(2) or ""
        # Already has a semicolon somewhere in the trailing section? skip.
        if ";" in (sig + trailing):
            return m.group(0)
        return f"{sig};{trailing}"

    result = _ABSTRACT_METHOD_NO_SEMI_RE.sub(_repl, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 10 — TakesScreenshot import strip (v0.5.16)
# ---------------------------------------------------------------------------
#
# Selenium's TakesScreenshot is replaced by page.screenshot() in Playwright.
# When AllureManager/ExtentReportManager use the cast pattern
# `((TakesScreenshot) driver).getScreenshotAs(BYTES)`, the LLM usually rewrites
# the body but may leave the `import org.openqa.selenium.TakesScreenshot;` line
# behind. Strip it deterministically when the type is no longer used in body.

_TAKES_SCREENSHOT_IMPORT_RE = re.compile(
    r"^\s*import\s+org\.openqa\.selenium\.TakesScreenshot\s*;\s*\n?",
    re.MULTILINE,
)
_TAKES_SCREENSHOT_USAGE_RE = re.compile(r"\bTakesScreenshot\b")


def _fix_takes_screenshot_orphan(code: str) -> tuple[str, bool]:
    """Strip TakesScreenshot import when no longer used in body."""
    if "TakesScreenshot" not in code:
        return code, False
    # Strip the import temporarily and check if name still appears.
    without_import = _TAKES_SCREENSHOT_IMPORT_RE.sub("", code)
    if _TAKES_SCREENSHOT_USAGE_RE.search(without_import):
        return code, False  # Still used — leave alone
    return without_import, without_import != code


# ---------------------------------------------------------------------------
# Fix 8 — Strip N/A prose lines injected by the LLM (v0.5.16)
# ---------------------------------------------------------------------------
#
# The LLM sometimes inserts pseudo-documentation lines like:
#   N/A - Utility class with static methods only
#   N/A - No constructor needed; all methods are static
# These are NOT valid Java and cause an immediate compile error.
# This is the highest-frequency bug seen in the production project run
# (5+ files affected). A simple regex strip costs zero and eliminates the
# entire class of error.

_NA_PROSE_RE = re.compile(
    r"^\s*N/?A\s*[-–—:]\s*[^\n]*\n?",
    re.MULTILINE | re.IGNORECASE,
)


def _fix_na_prose_injection(code: str) -> tuple[str, bool]:
    """Strip N/A prose lines that the LLM injects into Java source."""
    if not re.search(r"^\s*N/?A\s*[-–—:]", code, re.MULTILINE | re.IGNORECASE):
        return code, False
    result = _NA_PROSE_RE.sub("", code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 9 — No-arg enum constant separator (v0.5.16)
# ---------------------------------------------------------------------------
#
# The existing _fix_listeners_annotation handles many enum cases but the
# comma separator postgen rule in the existing code only fires when enum
# constants have constructor arguments. No-arg enums like:
#   STOP_ON_FAILURE;
#   CONTINUE_ON_FAILURE;
# need to become:
#   STOP_ON_FAILURE,
#   CONTINUE_ON_FAILURE;   ← last one stays semicolon if methods follow
#
# This fix is conservative: only fire inside a clearly identified enum body
# (between `{` and `}`) for lines that look like UPPER_CASE_IDENTIFIER;
# with no other tokens on the line.

_ENUM_BODY_RE = re.compile(
    r"(public\s+|private\s+|protected\s+)?enum\s+\w+[^{]*\{([^}]*)\}",
    re.DOTALL,
)
_NO_ARG_CONST_RE = re.compile(
    r"^\s*([A-Z][A-Z0-9_]*);\s*$",
    re.MULTILINE,
)


def _fix_enum_separator(code: str) -> tuple[str, bool]:
    """Fix no-arg enum constants that have `;` instead of `,` as separator.

    Only rewrites inside enum body. The last constant before any method/field
    declarations keeps its `;` if followed by method/field content; otherwise
    all but the trailing semicolon become commas.
    """
    if "enum " not in code:
        return code, False

    def _fix_body(m: re.Match) -> str:
        full = m.group(0)
        body = m.group(2)
        # Find all no-arg constants
        consts = list(_NO_ARG_CONST_RE.finditer(body))
        if not consts:
            return full
        # Replace all but the last with comma
        new_body = body
        for i, cm in enumerate(consts[:-1]):
            old = cm.group(0).rstrip()
            new = old.rstrip(";") + ","
            new_body = new_body.replace(old, new, 1)
        return full.replace(body, new_body, 1)

    result = _ENUM_BODY_RE.sub(_fix_body, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 7 — Strip spurious .playwright suffix from Cucumber imports (v0.5.15)
# ---------------------------------------------------------------------------
#
# The sibling import rewrite (pipeline Phase 1.5) rewrites project class
# imports to .playwright. But Cucumber imports (io.cucumber.*) are third-party
# and must NEVER have .playwright appended. If the LLM or import rewriter
# accidentally produces `import io.cucumber.java.playwright.en.Given`, this
# rule strips the spurious suffix.

_CUCUMBER_IMPORT_BAD_RE = re.compile(
    r"^\s*import\s+(io\.cucumber[^;]*?)\.playwright([^;]*;)\s*$",
    re.MULTILINE,
)


def _fix_cucumber_import_corruption(code: str) -> tuple[str, bool]:
    """Remove any .playwright suffix that crept into Cucumber imports."""
    if "io.cucumber" not in code or ".playwright" not in code:
        return code, False
    result = _CUCUMBER_IMPORT_BAD_RE.sub(r"import \1\2", code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 15 — HTML entity escapes in Java generic types (v0.6.2)
# ---------------------------------------------------------------------------
#
# The LLM occasionally emits HTML-escaped angle brackets inside Java source:
#   ThreadLocal&lt;Page&gt; pageLocal = new ThreadLocal&lt;&gt;();
# Java requires the raw `<>` characters, not HTML entities.
#
# Root cause: the LLM internally processes text in an HTML-aware context and
# sometimes escapes < / > in generated code, especially inside generics.
# This is a NEW regression in v0.6.1 — the v0.6.0 production run on
# AutomationFrameworkSelenium did not exhibit it, but the v0.6.1 multi-project
# run showed DriverManager.java with 18 errors all from this pattern.
#
# The fix is a simple string replacement applied to the entire file source.
# We also decode &amp; → & and &quot; → " in case the LLM extends the
# pattern to other HTML entities in future runs.

_HTML_ENTITY_MAP = [
    ("&lt;", "<"),
    ("&gt;", ">"),
    ("&amp;", "&"),
    ("&quot;", '"'),
    ("&apos;", "'"),
]


def _fix_html_entity_escaping(code: str) -> tuple[str, bool]:
    """Decode HTML entity escapes that the LLM emits inside Java source.

    Only touches `&lt;`, `&gt;`, `&amp;`, `&quot;`, `&apos;`.
    Returns (new_code, changed).
    """
    # Fast early-out: none of the trigger sequences present.
    if "&" not in code:
        return code, False

    result = code
    for entity, char in _HTML_ENTITY_MAP:
        if entity in result:
            result = result.replace(entity, char)

    return result, result != code


# ---------------------------------------------------------------------------
# Fix 14 — Javadoc placed between method signature and `{` (v0.6.2)
# ---------------------------------------------------------------------------
#
# The LLM frequently places Javadoc (/** ... */) AFTER the method signature
# and BEFORE the opening brace:
#
#   public static void click(By locator) /** Clicks element */ {
#
# Java requires Javadoc to appear BEFORE the modifier line, not between
# the closing `)` and `{`. This is a syntax error in every Java version.
#
# The pattern was the dominant failure mode in the v0.6.1 multi-project
# test report: 46 of 66 total mvn errors (70%) across all 3 projects were
# this exact shape.
#
# The fix moves the Javadoc above the signature line:
#
#   /** Clicks element */
#   public static void click(By locator) {
#
# We handle both single-line (`/** ... */`) and multi-line Javadoc blocks
# that may span multiple lines between the `)` and `{`.

# Single-line Javadoc between ) and { on the same line:
#   public void foo(int x) /** doc */ {
_JAVADOC_AFTER_SIG_INLINE_RE = re.compile(
    r"^(\s*)((?:(?:@\w+(?:\([^)]*\))?\s+)|"
    r"(?:public|protected|private|static|final|abstract|synchronized|default|native|strictfp)\s+)+"
    r"[\w<>\[\].,\s]+\s+\w+\s*\([^)]*\)(?:\s*throws\s+[\w,\s.]+?)?)"
    r"\s+(/\*\*.*?\*/)\s*(\{)",
    re.MULTILINE,
)


def _fix_javadoc_after_signature(code: str) -> tuple[str, bool]:
    """Move Javadoc comments that appear between a method signature and `{` above the signature.

    Handles single-line Javadoc on the same line as the signature.
    Returns (new_code, changed).
    """
    if "/**" not in code or "{" not in code:
        return code, False

    def _repl_inline(m: re.Match) -> str:
        indent = m.group(1)
        sig = m.group(2)
        javadoc = m.group(3)
        brace = m.group(4)
        return f"{indent}{javadoc}\n{indent}{sig} {brace}"

    result = _JAVADOC_AFTER_SIG_INLINE_RE.sub(_repl_inline, code)
    return result, result != code


# ---------------------------------------------------------------------------
# Fix 17 — Constructor arity guard (v0.6.6)
# ---------------------------------------------------------------------------
#
# The LLM occasionally invents constructor overloads that don't exist in the
# original class. v0.6.5 production run on AutomationFrameworkSelenium hit
# this twice in ReportUtils.java:
#
#     new InvalidPathForExtentReportFileException(arg1, arg2);
#
# But the source class declares only:
#
#     public InvalidPathForExtentReportFileException(String message)
#
# javac fails with "constructor X cannot be applied to given types".
#
# The fix: when we know (from ProjectMap) the set of constructor arities for
# class X, and the generated code calls `new X(a, b, c)` with arity 3 but
# class X only declares arities {1}, drop extra arguments greedily until we
# match a known arity. Comment-out marker is added so the change is visible.
#
# We ONLY act when:
#   - the constructor arity set is known (class is in the ProjectMap)
#   - the called arity is strictly greater than every declared arity
#     (so dropping right-most args can land on a real signature)
#   - the args we'd drop are simple identifiers (not method calls or string
#     literals — those are more likely to be the "important" arg)
#
# Drops happen RIGHT-TO-LEFT (drop the last arg first). This works for the
# common pattern of an LLM appending a `Throwable cause` to a message-only
# constructor.

def _find_new_calls(code: str) -> list[tuple[int, int, str, str]]:
    """Find all `new ClassName(...)` calls with paren-balanced arglists.

    Returns a list of (start_index, end_index, class_name, arglist) tuples
    where `code[start_index:end_index]` is the full `new ClassName(...)`
    expression. Arglists are returned UNQUOTED — paren and string-literal
    nesting is respected so `new Foo(format(a, b), c)` correctly captures
    `format(a, b), c` as the arglist.

    A regex with `[^)]*` would mishandle nested parens; a hand-written
    scanner does it correctly with a few lines of code.
    """
    results: list[tuple[int, int, str, str]] = []
    name_re = re.compile(r"\bnew\s+([A-Z]\w*)\s*\(")
    pos = 0
    while True:
        m = name_re.search(code, pos)
        if not m:
            break
        start = m.start()
        cls = m.group(1)
        i = m.end()  # one past the opening `(`
        depth = 1
        in_str = False
        in_char = False
        while i < len(code) and depth > 0:
            ch = code[i]
            if in_str:
                if ch == "\\" and i + 1 < len(code):
                    i += 2
                    continue
                if ch == '"':
                    in_str = False
            elif in_char:
                if ch == "\\" and i + 1 < len(code):
                    i += 2
                    continue
                if ch == "'":
                    in_char = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "'":
                    in_char = True
                elif ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        arglist = code[m.end():i]
                        results.append((start, i + 1, cls, arglist))
                        i += 1
                        break
            i += 1
        pos = i
    return results


def _split_top_level_args(arglist: str) -> list[str]:
    """Split a Java argument list at top-level commas.

    Respects parentheses and string literals so calls like
        new X("a, b", foo(c, d))
    split cleanly into ['"a, b"', 'foo(c, d)'].
    """
    args: list[str] = []
    depth = 0
    in_str = False
    in_char = False
    cur: list[str] = []
    i = 0
    while i < len(arglist):
        ch = arglist[i]
        if in_str:
            cur.append(ch)
            if ch == "\\" and i + 1 < len(arglist):
                cur.append(arglist[i + 1])
                i += 2
                continue
            if ch == '"':
                in_str = False
        elif in_char:
            cur.append(ch)
            if ch == "\\" and i + 1 < len(arglist):
                cur.append(arglist[i + 1])
                i += 2
                continue
            if ch == "'":
                in_char = False
        else:
            if ch == '"':
                in_str = True
                cur.append(ch)
            elif ch == "'":
                in_char = True
                cur.append(ch)
            elif ch == "(":
                depth += 1
                cur.append(ch)
            elif ch == ")":
                depth -= 1
                cur.append(ch)
            elif ch == "," and depth == 0:
                args.append("".join(cur).strip())
                cur = []
            else:
                cur.append(ch)
        i += 1
    tail = "".join(cur).strip()
    if tail or args:
        args.append(tail)
    return args


def _fix_invented_constructor_arity(
    code: str,
    class_api: dict[str, dict] | None,
) -> tuple[str, bool]:
    """Drop extra arguments from `new X(...)` calls when no matching constructor exists.

    Args:
        class_api: optional mapping {simple_class_name: {
            "constructor_arities": set[int],
            ...
        }}. When None or empty, no rewrites are attempted.

    Returns (new_code, changed).
    """
    if not class_api:
        return code, False

    calls = _find_new_calls(code)
    if not calls:
        return code, False

    # Build a list of (start, end, replacement) edits, then splice them in
    # reverse order so earlier indices stay valid.
    edits: list[tuple[int, int, str]] = []
    for start, end, cls, arglist in calls:
        info = class_api.get(cls)
        if not info:
            continue
        arities: set[int] = info.get("constructor_arities") or set()
        if not arities:
            continue
        args = _split_top_level_args(arglist)
        # Empty arglist → arity 0; non-empty → number of top-level commas + 1.
        called_arity = len([a for a in args if a]) if args else 0
        if called_arity in arities:
            continue
        if called_arity <= max(arities):
            continue
        target = max(a for a in arities if a < called_arity)
        kept = [a for a in args if a][:target]
        new_arglist = ", ".join(kept)
        replacement = f"new {cls}({new_arglist})"
        edits.append((start, end, replacement))

    if not edits:
        return code, False

    new_code = code
    for start, end, replacement in reversed(edits):
        new_code = new_code[:start] + replacement + new_code[end:]
    return new_code, True


# ---------------------------------------------------------------------------
# Fix 18 — Hallucinated sibling method call rewrite (v0.6.6, conservative)
# ---------------------------------------------------------------------------
#
# When the LLM calls `obj.methodA(args)` but class `Obj` exposes only
# `methodB(args)` (similar name, edit distance ≤ 2, same arity), rewrite the
# call to use the real method.
#
# Conservative scope:
#   - Only acts when class_api[ClassName]["methods"] is known (sibling
#     class is in the ProjectMap).
#   - Only acts when there is EXACTLY ONE candidate within edit distance ≤ 2
#     and matching arity. Multiple candidates → leave it alone (ambiguous).
#   - Only acts when the called name is NOT in the class's known method list
#     (otherwise it's a real method, no fix needed).
#   - Logs every rewrite so users can audit them in the run output.
#
# The detector that runs at scan time already flags these as "potential
# hallucinations". Fix 18 promotes the highest-confidence subset of those
# to deterministic rewrites.
#
# Pattern matched: `IdentifierOrSnakeCase.method(` and `getterCall().method(`.
# We only rewrite when the receiver is a simple `ClassName.` (static call)
# or a known field whose declared type is `ClassName`.

_STATIC_CALL_RE = re.compile(
    r"\b([A-Z]\w*)\.([a-z]\w*)\s*\("
)


def _edit_distance(a: str, b: str) -> int:
    """Compute Levenshtein edit distance between two strings."""
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        curr = [i] + [0] * len(b)
        for j, cb in enumerate(b, 1):
            curr[j] = min(
                curr[j - 1] + 1,
                prev[j] + 1,
                prev[j - 1] + (ca != cb),
            )
        prev = curr
    return prev[-1]


_GETTER_PREFIXES = ("get", "set", "is", "has", "find", "create", "make", "build", "to")


def _shares_prefix(a: str, b: str) -> str | None:
    """If a and b start with the same recognized accessor prefix, return it."""
    for pre in _GETTER_PREFIXES:
        if a.startswith(pre) and b.startswith(pre) and a != b:
            return pre
    return None


# Foreign-package prefixes — third-party libraries and the Java stdlib.
# The list is deliberately conservative: project codebases typically use
# `com.<company>.*` for their own classes, so a blanket `com.*` ban
# would also exclude project classes. We only block prefixes that are
# **known to be third-party**.
_FOREIGN_PACKAGE_PREFIXES = (
    "java.",
    "javax.",
    "jakarta.",
    "org.junit.",
    "org.junit",   # covers `org.junit.Assert` etc. without the trailing dot
    "org.testng.",
    "org.openqa.",
    "org.slf4j.",
    "org.apache.",
    "org.hamcrest.",
    "org.mockito.",
    "org.assertj.",
    "io.cucumber.",
    "io.qameta.",
    "com.microsoft.playwright.",
    "com.google.",
    "com.fasterxml.",
    "net.bytebuddy.",
    "lombok.",
    "kotlin.",
)


def _foreign_imported_classes(code: str) -> set[str]:
    """Return simple names of classes imported from KNOWN foreign packages.

    "Foreign" means a third-party library or the Java stdlib whose full
    package path matches one of `_FOREIGN_PACKAGE_PREFIXES`. Project
    classes (`com.<company>.*`) are NOT foreign — they appear in
    `class_api` and are the intended targets of Fix 18.

    The class_api lookup is keyed by simple class name only, so without
    this guard, `java.sql.DriverManager.getConnection(...)` would resolve
    against the project's own DriverManager and Fix 18 might rewrite it.

    The v0.6.7 production run hit exactly this on `DatabaseHelpers.java`:
    `getConnection` → `getDriver` on a JDBC call.
    """
    foreign: set[str] = set()
    for m in re.finditer(
        r"^\s*import\s+(?:static\s+)?([\w.]+)\s*;",
        code,
        re.MULTILINE,
    ):
        fqn = m.group(1)
        # Wildcards `import org.junit.*;` skipped — we can't pin a
        # specific simple name. Acceptable: project class collisions
        # against wildcard foreign imports are rare in practice.
        if fqn.endswith(".*"):
            continue
        if any(fqn.startswith(p) for p in _FOREIGN_PACKAGE_PREFIXES):
            foreign.add(fqn.rsplit(".", 1)[-1])
    return foreign


def _fix_hallucinated_static_method(
    code: str,
    class_api: dict[str, dict] | None,
) -> tuple[str, bool, list[str]]:
    """Rewrite static-style calls to non-existent methods when there is a
    single close-name candidate.

    v0.6.7: two-tier matching.
      Tier 1 (loose-name): edit distance ≤ 2, single candidate. Catches typos.
      Tier 2 (prefix+arity): same accessor prefix (`get`/`set`/`is`/...),
                             single candidate of any arity. Catches renames
                             like `getPage` → `getDriver`. Strictly bounded
                             to one candidate per class.

    v0.6.7 hot-fix: skip rewrite when the class is imported from a foreign
    package (java.sql.DriverManager, etc.). class_api is keyed by simple
    name only and would otherwise resolve foreign classes against project
    classes that share a name.

    Returns (new_code, changed, rewrite_log).
    """
    if not class_api:
        return code, False, []

    foreign_classes = _foreign_imported_classes(code)

    log: list[str] = []
    changes: list[tuple[str, str]] = []

    for m in _STATIC_CALL_RE.finditer(code):
        cls, method = m.group(1), m.group(2)
        # v0.6.7 hot-fix: don't rewrite calls whose class is imported from
        # a foreign package. Same simple name as a project class is a
        # collision, not a hallucination.
        if cls in foreign_classes:
            continue
        info = class_api.get(cls)
        if not info:
            continue
        method_names: list[str] = info.get("method_names") or []
        if not method_names:
            continue
        if method in method_names:
            continue

        # Tier 1: close-name candidates (edit distance ≤ 2).
        # Skip when EITHER the called name OR the candidate is too short
        # (≤ 3 chars). Short names invite spurious matches like `set` →
        # `setX`, `get` → `gen`.
        close = [n for n in method_names if _edit_distance(method, n) <= 2]
        replacement: str | None = None
        if len(close) == 1 and len(method) > 3 and len(close[0]) > 3:
            replacement = close[0]
        else:
            # Tier 2: same accessor prefix, single candidate.
            same_prefix = [
                n for n in method_names
                if _shares_prefix(method, n) is not None
            ]
            # Avoid empty-prefix-rest matches like `set()` vs `setUp()` —
            # require the rest of the name to be at least 2 chars to keep
            # the signal high.
            same_prefix = [
                n for n in same_prefix
                if len(n) - len(_shares_prefix(method, n) or "") >= 2
            ]
            if len(same_prefix) == 1:
                replacement = same_prefix[0]

        if not replacement:
            continue

        changes.append((f"{cls}.{method}(", f"{cls}.{replacement}("))
        log.append(f"{cls}.{method}() -> {cls}.{replacement}()")

    if not changes:
        return code, False, []

    # Apply replacements (each is unique in shape `Cls.method(`).
    new_code = code
    for old, new in changes:
        new_code = new_code.replace(old, new)
    return new_code, new_code != code, log


# ---------------------------------------------------------------------------
# Fix 19 — Playwright API lint pass (v0.6.7)
# ---------------------------------------------------------------------------
#
# A small but growing list of Playwright Java API patterns the LLM gets
# wrong. Each entry is a (regex, replacement, description) tuple.
#
# These are NOT general Java fixes — they are specifically Playwright Java
# corrections. Every entry is justified by a concrete bug in a real run
# and references the official Playwright Java docs.
#
# Naming convention:
#   - "Wrong-class API": method exists on a different Playwright class
#     than the one the LLM used.
#   - "Removed API": method existed in pre-1.0 Playwright but was renamed.
#   - "Java vs JS divergence": the LLM remembered the JS API name, not Java.

# Wrong-class APIs: per-context options must go on NewContextOptions, not
# LaunchOptions. Source: docs.microsoft.com/playwright/java reference.
_PLAYWRIGHT_API_FIXES: list[tuple[re.Pattern, str, str]] = [
    # `new BrowserType.LaunchOptions().setIgnoreHTTPSErrors(...)` is wrong —
    # `setIgnoreHTTPSErrors` lives on Browser.NewContextOptions.
    (
        re.compile(
            r"\bnew\s+BrowserType\.LaunchOptions\s*\(\s*\)((?:\s*\.[^;]*)?)\s*\.setIgnoreHTTPSErrors\s*\("
        ),
        r"new Browser.NewContextOptions()\1.setIgnoreHTTPSErrors(",
        "moved setIgnoreHTTPSErrors from LaunchOptions to NewContextOptions",
    ),
    # `setUserAgent` — same: NewContextOptions.
    (
        re.compile(
            r"\bnew\s+BrowserType\.LaunchOptions\s*\(\s*\)((?:\s*\.[^;]*)?)\s*\.setUserAgent\s*\("
        ),
        r"new Browser.NewContextOptions()\1.setUserAgent(",
        "moved setUserAgent from LaunchOptions to NewContextOptions",
    ),
    # `setViewportSize` — same: NewContextOptions.
    (
        re.compile(
            r"\bnew\s+BrowserType\.LaunchOptions\s*\(\s*\)((?:\s*\.[^;]*)?)\s*\.setViewportSize\s*\("
        ),
        r"new Browser.NewContextOptions()\1.setViewportSize(",
        "moved setViewportSize from LaunchOptions to NewContextOptions",
    ),
    # `setLocale` — NewContextOptions, not LaunchOptions.
    (
        re.compile(
            r"\bnew\s+BrowserType\.LaunchOptions\s*\(\s*\)((?:\s*\.[^;]*)?)\s*\.setLocale\s*\("
        ),
        r"new Browser.NewContextOptions()\1.setLocale(",
        "moved setLocale from LaunchOptions to NewContextOptions",
    ),
    # `setTimezone` / `setTimezoneId` — NewContextOptions.
    (
        re.compile(
            r"\bnew\s+BrowserType\.LaunchOptions\s*\(\s*\)((?:\s*\.[^;]*)?)\s*\.setTimezoneId\s*\("
        ),
        r"new Browser.NewContextOptions()\1.setTimezoneId(",
        "moved setTimezoneId from LaunchOptions to NewContextOptions",
    ),
]


def _fix_playwright_api_misuse(code: str) -> tuple[str, bool, list[str]]:
    """Apply the curated Playwright Java API corrections.

    Returns (new_code, changed, log_lines).
    """
    if "BrowserType.LaunchOptions" not in code:
        # Fast path: none of our rules apply when LaunchOptions isn't
        # mentioned at all.
        return code, False, []

    log: list[str] = []
    new_code = code
    for pattern, replacement, desc in _PLAYWRIGHT_API_FIXES:
        if not pattern.search(new_code):
            continue
        replaced = pattern.sub(replacement, new_code)
        if replaced != new_code:
            new_code = replaced
            log.append(desc)
    return new_code, new_code != code, log


# ---------------------------------------------------------------------------
# Fix 16 — Orphan Selenium identifiers in code (no import, no comment) (v0.6.6)
# ---------------------------------------------------------------------------
#
# Sometimes the LLM strips the `import org.openqa.selenium.WebDriver` line but
# leaves a stray `WebDriver driver = ...` declaration in the migrated body.
# javac then reports `cannot find symbol: class WebDriver`. Fix 5 already
# strips orphan IMPORTS (when nothing references them); Fix 16 is the inverse:
# strip orphan IDENTIFIERS when no import references them.
#
# Conservative scope:
# - Only acts when the symbol appears in source code (not inside a // line
#   comment or /* ... */ block comment).
# - Only acts when there is NO matching `import org.openqa.selenium.<Name>;`
#   AND no `import org.openqa.selenium.*;`.
# - Only acts on a fixed allowlist of Selenium identifiers.
# - Comments out the offending line with a `// QAMigrate: orphan Selenium
#   symbol — review` marker rather than deleting the line, so a human
#   reviewer can decide what to do with it.
#
# Why "comment out, not delete": deleting a line can leave dangling braces
# or broken control flow. Commenting preserves structure and makes the
# decision visible in the diff.

_ORPHAN_SELENIUM_NAMES = (
    "WebDriver",
    "WebElement",
    "TakesScreenshot",
    "JavascriptExecutor",
    "Actions",
    "ExpectedConditions",
    "WebDriverWait",
)

# Strip both // line comments and /* ... */ block comments before searching.
_LINE_COMMENT_RE = re.compile(r"//[^\n]*")
_BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)


def _strip_comments(code: str) -> str:
    """Return `code` with all comments removed. For analysis only.

    Used to check whether a Selenium identifier appears in real Java code
    (vs only inside a comment, where it is harmless).
    """
    no_block = _BLOCK_COMMENT_RE.sub("", code)
    no_line = _LINE_COMMENT_RE.sub("", no_block)
    return no_line


def _fix_orphan_selenium_symbols(code: str) -> tuple[str, bool]:
    """Comment out lines that reference Selenium identifiers without an import.

    Returns (new_code, changed).
    """
    code_no_comments = _strip_comments(code)

    # Which Selenium names are actually used in CODE (not comments)?
    used_in_code: list[str] = []
    for name in _ORPHAN_SELENIUM_NAMES:
        if re.search(rf"\b{name}\b", code_no_comments):
            used_in_code.append(name)
    if not used_in_code:
        return code, False

    # Which of those have a matching import? An identifier counts as imported
    # if EITHER `import ...selenium.<Name>;` OR `import ...selenium.*;` is
    # present anywhere in the file.
    has_wildcard = bool(
        re.search(r"^\s*import\s+org\.openqa\.selenium\.\*\s*;", code, re.MULTILINE)
    )
    orphans: list[str] = []
    for name in used_in_code:
        if has_wildcard:
            continue
        # Specific import for this name?
        if re.search(
            rf"^\s*import\s+(?:static\s+)?org\.openqa\.selenium\.[\w.]*\b{name}\s*;",
            code,
            re.MULTILINE,
        ):
            continue
        orphans.append(name)
    if not orphans:
        return code, False

    # Comment out each line that contains an orphan identifier — but do NOT
    # touch lines that are already comments (avoid double-commenting) and
    # do NOT touch lines that contain a method/class opening brace `{`,
    # because commenting those would orphan the body and produce a much
    # worse parse error than the original "cannot find symbol".
    #
    # v0.6.7 hot-fix: the v0.6.6 implementation broke DriverManager.java
    # in the BDD project by commenting out
    #     `public static WebDriver getDriver() {`
    # which left the body at class scope and produced 5 cascading
    # "class, interface, or enum expected" errors.
    out_lines: list[str] = []
    changed = False
    orphan_pattern = re.compile(rf"\b(?:{'|'.join(re.escape(n) for n in orphans)})\b")
    for line in code.splitlines(keepends=True):
        stripped = line.lstrip()
        # Skip lines that are already comments or blank.
        if stripped.startswith("//") or stripped.startswith("/*") or stripped.startswith("*"):
            out_lines.append(line)
            continue
        if not orphan_pattern.search(line):
            out_lines.append(line)
            continue
        # SAFETY: if this line contains an unbalanced opening brace
        # (more `{` than `}`), commenting it out would orphan the body.
        # Leave it alone — let the Fixer LLM handle it.
        bare_line = stripped.rstrip("\r\n")
        if bare_line.count("{") > bare_line.count("}"):
            out_lines.append(line)
            continue
        # SAFETY: if this line contains an unbalanced closing brace, same
        # risk in the other direction (would close the wrong scope).
        if bare_line.count("}") > bare_line.count("{"):
            out_lines.append(line)
            continue
        # Replace this line with a commented-out copy + review marker.
        # Preserve indentation so the diff stays readable.
        indent = line[: len(line) - len(line.lstrip())]
        body = line.lstrip().rstrip("\r\n")
        newline = line[len(line.rstrip("\r\n")):]
        out_lines.append(
            f"{indent}// QAMigrate: orphan Selenium symbol — review\n"
            f"{indent}// {body}{newline}"
        )
        changed = True

    return "".join(out_lines), changed


# ---------------------------------------------------------------------------
# Fix 20 — Selenium types in method signatures (v0.8)
# ---------------------------------------------------------------------------
#
# The v0.7.0 + gpt-4o test run surfaced a new failure mode: the LLM left
# Selenium types (By, WebElement) in method parameter declarations even
# though the body uses Playwright APIs. Example from WebActions.java:
#
#     public static void click(By locator) {
#         Locator element = WaitUtils.waitForClickability(locator);
#         element.click();
#     }
#
# Every caller of `click(By...)` in the migrated codebase compiles
# against this mismatched signature. The clean fix is the Coder prompt
# (added in v0.8); this is the deterministic safety net when the LLM
# ignores the rule.
#
# Mapping:
#   By <name>         → String <name>           (use the selector string;
#                                                callers must pass strings,
#                                                which is the post-migration
#                                                style in any case)
#   WebElement <name> → Locator <name>          (Playwright equivalent)
#
# Out of scope: WebDriver in signatures. That one's structurally harder
# (the right replacement depends on context — Page, BrowserContext, or
# remove entirely) and Fix 16 already comments it out when orphaned.

# Negative lookbehind `(?<!\.)` excludes `org.openqa.selenium.By` etc.,
# where rewriting would corrupt a fully-qualified type to a malformed
# `org.openqa.selenium.String` reference.
# Lookbehind for `(` excludes (somewhat — `(By foo` is the start of a
# parameter list, no preceding char) — instead we just require a
# preceding word boundary that isn't `.`.
_SIG_BY_PARAM_RE = re.compile(
    r"(?<![\w.])(By)\s+(\w+)(?=\s*[,)])"
)
_SIG_WEBELEMENT_PARAM_RE = re.compile(
    r"(?<![\w.])(WebElement)\s+(\w+)(?=\s*[,)])"
)


def _fix_selenium_types_in_signatures(code: str) -> tuple[str, bool]:
    """Rewrite Selenium parameter types to Playwright equivalents.

    Conservative: only acts when the file already uses Playwright (has at
    least one `com.microsoft.playwright` import). Otherwise, the file
    isn't actually a migration output and we'd risk corrupting unrelated
    Java code.
    """
    if "com.microsoft.playwright" not in code:
        return code, False

    new_code = code
    new_code = _SIG_BY_PARAM_RE.sub(r"String \2", new_code)
    new_code = _SIG_WEBELEMENT_PARAM_RE.sub(r"Locator \2", new_code)
    return new_code, new_code != code


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def apply_all_postgen_fixes(
    code: str,
    file_path: str = "",
    extension_classes: set[str] | None = None,
    target_framework: str = "junit5",
    class_api: dict[str, dict] | None = None,
) -> str:
    """Apply all deterministic post-generation fixes to `code`.

    Args:
        code: Java source to fix.
        file_path: Used for logging only.
        extension_classes: Optional set of class names confirmed to implement
            org.junit.jupiter.api.extension.Extension. When provided, the
            @Listeners→@ExtendWith rewrite is applied for those classes only;
            others get a safe TODO comment. When None (default), the rewrite
            is always replaced with a TODO (conservative safe path).
            Ignored when target_framework == "testng".
        target_framework: The test framework the generated code targets.
            "testng"  — generated code uses TestNG; @Listeners must NOT be
                        rewritten, org.testng imports must NOT be stripped.
            "junit5"  — generated code uses JUnit5 (default behaviour).
            "junit4"  — generated code uses JUnit4; same as junit5 for postgen.
        class_api: v0.6.6 — optional mapping of sibling-class API used by
            Fix 17 (constructor-arity guard) and Fix 18 (hallucinated method
            rewrite). Shape:
                {simple_class_name: {
                    "constructor_arities": set[int],
                    "method_names": list[str],
                }}
            Build it once per migration run from the ProjectMap and pass it
            in unchanged for every file. None disables both fixes — postgen
            still does everything else, so v0.5.x callers continue to work.

    Returns the fixed source. If nothing changed, returns the original object
    unchanged (identity comparison safe).
    """
    is_testng = target_framework == "testng"
    result = code
    any_changed = False

    # @Listeners rewrite: JUnit5 only.
    # On TestNG, @Listeners({X.class}) is a valid TestNG annotation and MUST
    # be preserved. Rewriting it would break the TestNG listener mechanism.
    if not is_testng:
        result, changed = _fix_listeners_annotation(result, extension_classes)
        if changed:
            logger.info("postgen_fixes: rewrote @Listeners annotation", file=file_path)
            any_changed = True

    # These fixes are framework-neutral — apply on all paths.
    result, changed = _fix_screenshot_options_import(result)
    if changed:
        logger.info("postgen_fixes: fixed ScreenshotOptions import", file=file_path)
        any_changed = True

    result, changed = _fix_locator_state_enum(result)
    if changed:
        logger.info("postgen_fixes: fixed Locator.State -> WaitForSelectorState", file=file_path)
        any_changed = True

    result, changed = _ensure_wait_for_selector_state_import(result)
    if changed:
        logger.info("postgen_fixes: added missing WaitForSelectorState import", file=file_path)
        any_changed = True

    result, changed = _fix_assertj_imports(result)
    if changed:
        logger.info("postgen_fixes: removed AssertJ imports, rewrote assertions", file=file_path)
        any_changed = True

    # Selenium import strip: on TestNG, org.testng imports are intentional
    # (TestNG API is the target framework).  Only strip Selenium imports;
    # the TestNG-import strip blocks inside _fix_leftover_selenium_imports
    # are already individually guarded by _import_is_still_used, but we
    # pass a flag so the function can skip the TestNG strip pass entirely
    # when target is TestNG for a cleaner separation of concerns.
    result, changed = _fix_leftover_selenium_imports(result, strip_testng=not is_testng)
    if changed:
        logger.info("postgen_fixes: stripped leftover Selenium/TestNG imports", file=file_path)
        any_changed = True

    # v0.5.15: fix Cucumber imports that got .playwright suffix from import rewriter
    result, changed = _fix_cucumber_import_corruption(result)
    if changed:
        logger.info("postgen_fixes: removed spurious .playwright from Cucumber imports", file=file_path)
        any_changed = True

    # v0.5.16: strip N/A prose lines the LLM inserts into Java source
    result, changed = _fix_na_prose_injection(result)
    if changed:
        logger.info("postgen_fixes: stripped N/A prose injection", file=file_path)
        any_changed = True

    # v0.5.16: fix no-arg enum constant separators (STOP_ON_FAILURE; -> ,)
    result, changed = _fix_enum_separator(result)
    if changed:
        logger.info("postgen_fixes: fixed no-arg enum separators", file=file_path)
        any_changed = True

    # v0.5.16: strip orphaned TakesScreenshot import after migration
    result, changed = _fix_takes_screenshot_orphan(result)
    if changed:
        logger.info("postgen_fixes: stripped orphan TakesScreenshot import", file=file_path)
        any_changed = True

    # v0.5.17: add missing ; on abstract method declarations
    result, changed = _fix_abstract_method_missing_semicolon(result)
    if changed:
        logger.info("postgen_fixes: added missing ; on abstract methods", file=file_path)
        any_changed = True

    # v0.5.19: collapse doubled method headers
    result, changed = _fix_doubled_method_header(result)
    if changed:
        logger.info("postgen_fixes: collapsed doubled method headers", file=file_path)
        any_changed = True

    # v0.6.1: wrap inline method bodies that are missing `{ ... }`.
    # Must run AFTER Fix 11 (abstract semicolon), since the Fix 13
    # heuristic requires at least one `;` in the body — we don't want
    # to corrupt abstract declarations.
    result, changed = _fix_nonabstract_method_missing_brace(result)
    if changed:
        logger.info("postgen_fixes: wrapped inline method body in braces", file=file_path)
        any_changed = True

    # v0.6.2: decode HTML entity escapes (&lt; → <, &gt; → >) that the LLM
    # emits inside Java generic types. Must run before Fix 14 so the Javadoc
    # regex sees clean angle brackets rather than entity-encoded text.
    result, changed = _fix_html_entity_escaping(result)
    if changed:
        logger.info("postgen_fixes: decoded HTML entity escapes in Java source", file=file_path)
        any_changed = True

    # v0.6.2: move Javadoc placed between method signature and `{` above
    # the signature. The LLM emits `public void foo() /** doc */ {` which
    # javac rejects as a syntax error. This was 46/66 errors (70%) in the
    # v0.6.1 multi-project test run.
    result, changed = _fix_javadoc_after_signature(result)
    if changed:
        logger.info("postgen_fixes: moved inline Javadoc above method signature", file=file_path)
        any_changed = True

    # v0.6.6 Fix 16: comment out lines that reference Selenium identifiers
    # (WebDriver, WebElement, etc.) when no matching import remains. Runs
    # AFTER Fix 5 (import strip) so any orphan body reference is exposed.
    result, changed = _fix_orphan_selenium_symbols(result)
    if changed:
        logger.info("postgen_fixes: commented out orphan Selenium identifiers", file=file_path)
        any_changed = True

    # v0.6.6 Fix 17: when the ProjectMap-derived class_api is supplied, drop
    # extra arguments from `new X(...)` calls that exceed every declared
    # constructor arity. Fixes the InvalidPathFor*Exception(msg, cause)
    # hallucination we keep seeing.
    if class_api:
        result, changed = _fix_invented_constructor_arity(result, class_api)
        if changed:
            logger.info("postgen_fixes: corrected invented constructor arity", file=file_path)
            any_changed = True

    # v0.6.6 Fix 18: rewrite static-style calls to non-existent methods when
    # there is exactly one close-name candidate (edit distance ≤ 2, same
    # arity hint via method_names list). Conservative — won't act on
    # ambiguous matches. v0.6.7: also accepts same-prefix accessor renames
    # (getPage → getDriver) when there's a single candidate.
    if class_api:
        result, changed, rewrite_log = _fix_hallucinated_static_method(result, class_api)
        if changed:
            for line in rewrite_log:
                logger.info(
                    "postgen_fixes: rewrote hallucinated method call",
                    file=file_path, change=line,
                )
            any_changed = True

    # v0.6.7 Fix 19: Playwright-specific API lint pass. A small curated set
    # of "method exists on the wrong Playwright class" patterns. Applied
    # last so it doesn't conflict with structure-restoring fixes earlier.
    result, changed, pw_log = _fix_playwright_api_misuse(result)
    if changed:
        for line in pw_log:
            logger.info(
                "postgen_fixes: corrected Playwright API misuse",
                file=file_path, change=line,
            )
        any_changed = True

    # v0.8 Fix 20: rewrite Selenium types in method signatures. Catches
    # the "By locator" / "WebElement element" hallucination that the
    # gpt-4o test run hit. Runs LAST so other fixes get a chance at the
    # signatures first.
    result, changed = _fix_selenium_types_in_signatures(result)
    if changed:
        logger.info(
            "postgen_fixes: rewrote Selenium types in method signatures",
            file=file_path,
        )
        any_changed = True

    return result if any_changed else code
