"""
Closed-world reference verification for generated Playwright Java code.

v0.8: at generation time, before the file is written to disk, walk the
LLM's output and check that every method call resolves against a known
class API. If any call references a class.method that doesn't exist, the
verifier returns a list of `UnresolvedReference` instances; the Coder
then re-prompts the LLM with that specific feedback ("you called
`DriverManager.getPage()` but DriverManager has no `getPage` method —
its public methods are: getDriver, quitDriver").

This is the structural fix for the dominant failure mode the v0.6/v0.7
test runs surfaced: LLM hallucinations on sibling-class method names
cascading to break 7+ dependent files. Today's hallucination DETECTOR
flags these in the report; v0.8 BLOCKS them at generation time.

Scope (narrow on purpose):
  - Static-style calls: `ClassName.method(args)` where `ClassName` is
    in the project class_api OR in a foreign-package import map.
  - Field-typed calls: `field.method(args)` when `field` is declared
    earlier in the same class with a known type.

Out of scope (deferred):
  - Lambda closures.
  - Generic type-parameter resolution.
  - `var` inferred locals.
  - Method-chain return-type tracking beyond the first hop.

The narrow scope catches the common shapes (DriverManager.getPage,
LogUtils.error, etc.) and avoids the complexity of full Java type
inference.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from difflib import get_close_matches
from typing import Iterable


# A receiver type's known method set. `None` for the method names means
# "we don't know — accept any call as valid". Used to model classes
# (Page, Locator) where we don't have a full method index.
@dataclass(frozen=True)
class TypeApi:
    """Known method set for one Java class.

    `methods` is a frozenset of method names. `None` is a sentinel for
    "unknown — be permissive": when the verifier doesn't have a full
    method index for this type, it accepts any call to avoid false
    positives.
    """
    methods: frozenset[str] | None


@dataclass(frozen=True)
class UnresolvedReference:
    """A method call the verifier could not resolve.

    `receiver_class` — the class name we believe the call targets.
    `method_name` — the method name that doesn't resolve.
    `line_number` — best-effort line number in the source (1-indexed).
    `suggested` — closest method name from the receiver's known methods,
        when the verifier could find one within edit-distance bounds.
    """
    receiver_class: str
    method_name: str
    line_number: int
    suggested: str | None = None


# ---------------------------------------------------------------------------
# Bundled Playwright Java API surface (subset)
# ---------------------------------------------------------------------------
#
# This list is intentionally small. We seed it with the classes whose names
# show up most often in our generated code as static receivers OR as field
# types. When the LLM calls a method on one of these and the call doesn't
# resolve, we want to catch it.
#
# Every entry is conservative: we only list methods that ACTUALLY exist
# in the public Playwright Java API (1.40+). When in doubt, leave the
# methods set as None so the verifier is permissive.
#
# Source: docs.microsoft.com/playwright/java reference, cross-checked
# against the bundled headers in com.microsoft.playwright.

PLAYWRIGHT_JAVA_API: dict[str, TypeApi] = {
    # The big three classes are deliberately permissive — they have
    # dozens of methods each and the LLM rarely hallucinates novel
    # ones. Keep this set None unless we see a real false-negative.
    "Page": TypeApi(methods=None),
    "Locator": TypeApi(methods=None),
    "BrowserContext": TypeApi(methods=None),
    "Browser": TypeApi(methods=None),
    "Playwright": TypeApi(
        # Only the static + instance entry points we care about.
        methods=frozenset({
            "create", "chromium", "firefox", "webkit", "selectors", "close",
            "request",
        }),
    ),
    "BrowserType": TypeApi(
        methods=frozenset({
            "launch", "launchPersistentContext", "name", "executablePath",
            "connect", "connectOverCDP",
        }),
    ),
    # Assertions namespace — `assertThat(locator).isVisible()` style
    "PlaywrightAssertions": TypeApi(
        methods=frozenset({"assertThat", "setDefaultAssertionTimeout"}),
    ),
}

# Foreign-package classes whose presence in an import statement signals
# "this receiver is external — be permissive". We don't validate against
# these; we just need to know the receiver is foreign so we don't try to
# resolve it against the project class_api (which would false-positive
# because of name collisions like java.sql.DriverManager).
#
# v0.8.1: `org.openqa.selenium.*` is DELIBERATELY EXCLUDED. After
# migration the project's classpath has no selenium-java, so importing
# Selenium types is itself a hallucination — the LLM doing
# `import org.openqa.selenium.WebElement;` is the same bug shape as
# inventing a class. Postgen Fix 5 strips orphan Selenium imports, but
# the verifier should also flag them so the Coder gets a re-prompt.
_FOREIGN_PACKAGE_PREFIXES = (
    "java.", "javax.", "jakarta.",
    "org.junit.", "org.testng.", "org.slf4j.", "org.apache.",
    "org.hamcrest.", "org.mockito.", "org.assertj.",
    "io.cucumber.", "io.qameta.",
    "com.microsoft.playwright.",
    "com.google.", "com.fasterxml.",
    "net.bytebuddy.", "lombok.", "kotlin.",
)


def _foreign_imports(code: str) -> set[str]:
    """Set of simple class names imported from foreign packages."""
    foreign: set[str] = set()
    for m in re.finditer(
        r"^\s*import\s+(?:static\s+)?([\w.]+)\s*;",
        code,
        re.MULTILINE,
    ):
        fqn = m.group(1)
        if fqn.endswith(".*"):
            continue
        if any(fqn.startswith(p) for p in _FOREIGN_PACKAGE_PREFIXES):
            foreign.add(fqn.rsplit(".", 1)[-1])
    return foreign


# Match a static-style call: `ClassName.method(`. The receiver starts
# with an uppercase letter (Java convention for class names) so we don't
# match field-typed calls like `loginPage.click(`.
_STATIC_CALL_RE = re.compile(
    r"\b([A-Z]\w*)\.([a-z]\w*)\s*\("
)

# Match a `new ClassName(args)` instantiation.
_NEW_INSTANCE_RE = re.compile(
    r"\bnew\s+([A-Z]\w*)\s*\("
)

# v0.8.1: match `class X extends Y implements I1, I2 {` style declarations.
# Captures the extends clause + the entire implements list. We split the
# implements list separately on commas and strip generics.
_CLASS_DECL_INHERITANCE_RE = re.compile(
    r"\bclass\s+\w+(?:\s*<[^>]*>)?\s*"
    r"(?:extends\s+([\w.<>,\s]+?))?"
    r"(?:\s+implements\s+([\w.<>,\s]+?))?"
    r"\s*\{",
    re.MULTILINE,
)

# Same shape for `interface X extends Y, Z`.
_INTERFACE_DECL_INHERITANCE_RE = re.compile(
    r"\binterface\s+\w+(?:\s*<[^>]*>)?\s*"
    r"(?:extends\s+([\w.<>,\s]+?))?"
    r"\s*\{",
    re.MULTILINE,
)


def _split_type_list(raw: str) -> list[str]:
    """Split `Foo, Bar<X>, Baz` into ['Foo', 'Bar', 'Baz'].

    Strips generic type parameters (we only verify the raw class name)
    and discards anything inside angle brackets.
    """
    if not raw:
        return []
    out: list[str] = []
    depth = 0
    cur: list[str] = []

    def flush() -> None:
        text = "".join(cur).strip()
        if not text:
            return
        # Drop leading FQN prefix and trailing generics: `org.x.Foo<T>` → `Foo`
        if "<" in text:
            text = text.split("<", 1)[0].strip()
        if "." in text:
            text = text.rsplit(".", 1)[-1].strip()
        if text:
            out.append(text)

    for ch in raw:
        if ch == "<":
            depth += 1
            cur.append(ch)
        elif ch == ">":
            depth -= 1
            cur.append(ch)
        elif ch == "," and depth == 0:
            flush()
            cur = []
        else:
            cur.append(ch)
    flush()
    return out

# Match a field declaration: `private final LoginPage loginPage;` or
# `LoginPage loginPage = new LoginPage(page);`. Captures (Type, name).
_FIELD_DECL_RE = re.compile(
    r"\b(?:private|protected|public)?\s*(?:static\s+)?(?:final\s+)?"
    r"([A-Z]\w*)\s+([a-z]\w*)\s*[=;,)<]"
)

# Match a field-typed call: `field.method(`. The receiver is an identifier
# starting with lowercase.
_FIELD_CALL_RE = re.compile(
    r"\b([a-z]\w*)\.([a-z]\w*)\s*\("
)


def _line_of(code: str, char_index: int) -> int:
    """1-indexed line number for a character offset."""
    return code.count("\n", 0, char_index) + 1


# Common Java stdlib + third-party types `new`-instantiated all the time.
# We don't validate `new T(...)` against these — they're never the
# hallucination shape we're looking for.
_COMMON_JAVA_TYPES = frozenset({
    # java.util collections
    "ArrayList", "LinkedList", "HashMap", "LinkedHashMap", "TreeMap",
    "HashSet", "LinkedHashSet", "TreeSet", "Stack", "Vector", "Hashtable",
    "PriorityQueue", "ArrayDeque",
    # java.lang
    "String", "StringBuilder", "StringBuffer", "Boolean", "Integer", "Long",
    "Double", "Float", "Character", "Byte", "Short", "Object", "Throwable",
    "Exception", "RuntimeException", "IllegalArgumentException",
    "IllegalStateException", "NullPointerException", "UnsupportedOperationException",
    # java.io
    "File", "FileReader", "FileWriter", "BufferedReader", "BufferedWriter",
    "InputStreamReader", "OutputStreamWriter", "FileInputStream", "FileOutputStream",
    "PrintWriter", "PrintStream", "IOException",
    # java.util.concurrent + atomic
    "ThreadLocal", "AtomicInteger", "AtomicLong", "AtomicBoolean", "AtomicReference",
    "ConcurrentHashMap",
    # java.time
    "Date", "LocalDate", "LocalDateTime", "Instant", "Duration", "Period",
    # java.util misc
    "Properties", "Random", "Scanner", "Optional", "Date",
    # Common testing types
    "Properties",
})


# v0.8.1: common Java parents (interfaces + base classes) that classes
# inherit from. This is a separate allowlist from _COMMON_JAVA_TYPES
# because the inheritance use-case is structurally different from
# `new T(...)` instantiation.
_COMMON_INHERITANCE_TYPES = frozenset({
    # Standard exception parents
    "RuntimeException", "Exception", "Throwable", "Error",
    "IllegalArgumentException", "IllegalStateException",
    "UnsupportedOperationException", "IOException",
    # Standard collection parents
    "ArrayList", "LinkedList", "HashMap", "HashSet",
    # Functional / iteration interfaces
    "Comparable", "Comparator", "Iterable", "Iterator", "Runnable", "Callable",
    "Supplier", "Function", "Consumer", "Predicate", "BiFunction", "BiConsumer",
    # Common test framework parents — covered by foreign imports usually,
    # but listed here as defensive for files where the import is missing.
    "ITestListener", "TestRule", "TestWatcher", "Extension",
    # Standard interfaces
    "Serializable", "Cloneable", "AutoCloseable", "Closeable",
    # Object — every class implicitly extends it; can also appear explicitly.
    "Object",
})


# Methods we consider "trusted" regardless of receiver — they're so
# common that flagging them produces too many false positives.
_TRUSTED_METHOD_NAMES = frozenset({
    "toString", "hashCode", "equals", "getClass", "wait", "notify", "notifyAll",
    "name", "ordinal",  # enum methods
    "length", "isEmpty", "trim", "split", "substring", "contains", "replace",
    "toUpperCase", "toLowerCase", "startsWith", "endsWith", "charAt", "indexOf",
    "valueOf", "parseInt", "parseLong", "parseDouble", "parseBoolean",
    "format", "join",
    "get", "set", "add", "remove", "size", "iterator", "stream", "of", "ofEntries",
    "put", "keySet", "values", "entrySet", "containsKey", "containsValue",
    "isPresent", "orElse", "orElseGet", "orElseThrow", "ifPresent", "map", "filter",
    "println", "print", "printf", "write", "flush", "close", "read", "readLine",
})


def verify(
    code: str,
    *,
    class_api: dict[str, dict] | None,
    extra_types: dict[str, TypeApi] | None = None,
) -> list[UnresolvedReference]:
    """Walk `code` and return method calls that don't resolve in the closed world.

    Args:
        code: assembled Java source as a string.
        class_api: project's class API in the same shape used by
            `_build_class_api_from_project_map`. Each value has at minimum
            a `method_names` list. None disables project-side resolution
            (foreign and Playwright resolution still apply).
        extra_types: optional override map (TypeName -> TypeApi). Tests
            can use this to add or replace API entries.

    Returns:
        Sorted list of `UnresolvedReference` for every call that doesn't
        resolve. Empty list when the file is clean.

    The verifier is conservative: when it can't decide whether a call is
    legitimate, it accepts. A false positive would block a perfectly good
    file; a false negative just lets a hallucination through to the next
    pipeline stage (postgen + Fixer), which is the pre-v0.8 behaviour.
    """
    if not code:
        return []

    foreign = _foreign_imports(code)
    bundled = dict(PLAYWRIGHT_JAVA_API)
    if extra_types:
        bundled.update(extra_types)

    issues: list[UnresolvedReference] = []
    seen: set[tuple[str, str]] = set()

    # ---- Static-call resolution ----
    for m in _STATIC_CALL_RE.finditer(code):
        receiver = m.group(1)
        method = m.group(2)
        if (receiver, method) in seen:
            continue
        seen.add((receiver, method))
        # Skip foreign-imported receivers.
        if receiver in foreign:
            continue
        # Trusted method names always pass.
        if method in _TRUSTED_METHOD_NAMES:
            continue
        # Receiver in the bundled Playwright API?
        if receiver in bundled:
            api = bundled[receiver]
            if api.methods is None:
                continue  # permissive
            if method in api.methods:
                continue
            suggestion = _closest(method, api.methods)
            issues.append(UnresolvedReference(
                receiver_class=receiver,
                method_name=method,
                line_number=_line_of(code, m.start()),
                suggested=suggestion,
            ))
            continue
        # Receiver in the project class_api?
        if class_api and receiver in class_api:
            method_names = class_api[receiver].get("method_names") or []
            if method in method_names:
                continue
            suggestion = _closest(method, method_names)
            issues.append(UnresolvedReference(
                receiver_class=receiver,
                method_name=method,
                line_number=_line_of(code, m.start()),
                suggested=suggestion,
            ))
            continue
        # Unknown receiver — be permissive (could be a static-import
        # method or a class we just don't have an API for).
        # We deliberately don't flag here; postgen + Fixer can still
        # catch it if it really is wrong.

    # ---- new <ClassName>(...) resolution ----
    # Flag instantiations of unknown classes (LLM-invented class names
    # like `PlaywrightWebElementAdapter`). The class must resolve in
    # one of: bundled Playwright API, project class_api, foreign import.
    seen_news: set[str] = set()
    for m in _NEW_INSTANCE_RE.finditer(code):
        class_name = m.group(1)
        if class_name in seen_news:
            continue
        seen_news.add(class_name)
        # Bundled (Page, Locator, BrowserContext, etc.) — fine.
        if class_name in bundled:
            continue
        # Project class — fine.
        if class_api and class_name in class_api:
            continue
        # Foreign-imported — fine.
        if class_name in foreign:
            continue
        # Common Java stdlib types we don't bother indexing. Allowlist
        # the most common cases to avoid false positives.
        if class_name in _COMMON_JAVA_TYPES:
            continue
        # Looks like an invented class. Flag it. We use the receiver_class
        # field to carry the class name, with method_name="<init>" to
        # signal a constructor reference rather than a method call.
        suggestion: str | None = None
        if class_api:
            suggestion = _closest(class_name, class_api.keys())
        issues.append(UnresolvedReference(
            receiver_class=class_name,
            method_name="<init>",
            line_number=_line_of(code, m.start()),
            suggested=suggestion,
        ))

    # ---- Inheritance-clause resolution ----
    # v0.8.1: walk every `class X extends Y implements I1, I2` and check
    # that each parent type resolves. Catches the WaitUtils.java pattern
    # the v0.8 simple-project run hit: `WebElementAdapter implements
    # WebElement` where WebElement is a Selenium type the migrated file
    # has no business referencing.
    seen_parents: set[str] = set()
    inheritance_iter = list(_CLASS_DECL_INHERITANCE_RE.finditer(code)) + list(
        _INTERFACE_DECL_INHERITANCE_RE.finditer(code)
    )
    for m in inheritance_iter:
        # group(1) = extends clause text, group(2) = implements list (or
        # None for interfaces)
        extends_clause = m.group(1)
        implements_clause = m.group(2) if m.lastindex and m.lastindex >= 2 else None
        parents: list[tuple[str, str]] = []  # (parent_class, kind)
        for parent in _split_type_list(extends_clause or ""):
            parents.append((parent, "extends"))
        for parent in _split_type_list(implements_clause or ""):
            parents.append((parent, "implements"))
        for parent_class, kind in parents:
            if parent_class in seen_parents:
                continue
            seen_parents.add(parent_class)
            # Resolution: bundled, project class_api, foreign import,
            # common stdlib types — any one of these is fine.
            if parent_class in bundled:
                continue
            if class_api and parent_class in class_api:
                continue
            if parent_class in foreign:
                continue
            if parent_class in _COMMON_JAVA_TYPES:
                continue
            # Common Java parent types not in the stdlib allowlist (the
            # _COMMON_JAVA_TYPES set was originally for `new` calls). Add
            # the standard exception/listener parents.
            if parent_class in _COMMON_INHERITANCE_TYPES:
                continue
            # Looks like an unresolved parent type. Flag it.
            suggestion: str | None = None
            if class_api:
                suggestion = _closest(parent_class, class_api.keys())
            issues.append(UnresolvedReference(
                receiver_class=parent_class,
                method_name=f"<{kind}>",
                line_number=_line_of(code, m.start()),
                suggested=suggestion,
            ))

    # ---- Field-typed call resolution ----
    # Build (field_name -> Type) from declarations in this file.
    fields = _extract_field_types(code)
    if fields:
        for m in _FIELD_CALL_RE.finditer(code):
            field_name = m.group(1)
            method = m.group(2)
            if (field_name, method) in seen:
                continue
            seen.add((field_name, method))
            if method in _TRUSTED_METHOD_NAMES:
                continue
            ftype = fields.get(field_name)
            if not ftype:
                continue
            if ftype in foreign:
                continue
            # Is the field's type bundled or in class_api?
            if ftype in bundled:
                api = bundled[ftype]
                if api.methods is None:
                    continue
                if method in api.methods:
                    continue
                suggestion = _closest(method, api.methods)
                issues.append(UnresolvedReference(
                    receiver_class=ftype,
                    method_name=method,
                    line_number=_line_of(code, m.start()),
                    suggested=suggestion,
                ))
                continue
            if class_api and ftype in class_api:
                method_names = class_api[ftype].get("method_names") or []
                if method in method_names:
                    continue
                suggestion = _closest(method, method_names)
                issues.append(UnresolvedReference(
                    receiver_class=ftype,
                    method_name=method,
                    line_number=_line_of(code, m.start()),
                    suggested=suggestion,
                ))

    # Sort by (line, receiver, method) for stable output.
    issues.sort(key=lambda r: (r.line_number, r.receiver_class, r.method_name))
    return issues


def _closest(name: str, candidates: Iterable[str]) -> str | None:
    """Closest match within edit-distance bounds, or None.

    Cutoff 0.4: catches `getPage → getDriver` (shared `get` prefix) which
    is the canonical hallucination shape we want to suggest. Stricter
    cutoffs would suppress useful suggestions; looser cutoffs would
    suggest near-noise. 0.4 is empirically the right balance.
    """
    matches = get_close_matches(name, list(candidates), n=1, cutoff=0.4)
    return matches[0] if matches else None


def _extract_field_types(code: str) -> dict[str, str]:
    """Map field-name → Java type for declarations the verifier can resolve.

    Only catches the common shape `<modifiers> Type fieldName [= ...]`
    where Type starts with uppercase. Generic parameters and arrays
    are not preserved — `ThreadLocal<Page>` is captured as `ThreadLocal`,
    `Page[]` as `Page`. That's good enough for the static-type lookup.
    """
    fields: dict[str, str] = {}
    for m in _FIELD_DECL_RE.finditer(code):
        type_name = m.group(1)
        var_name = m.group(2)
        # Don't overwrite — the first declaration wins. This matters if
        # the regex catches something inside a method body and a later
        # field declaration shares the same name.
        fields.setdefault(var_name, type_name)
    return fields


# ---------------------------------------------------------------------------
# Feedback prompt builder
# ---------------------------------------------------------------------------


def build_feedback_prompt(
    issues: list[UnresolvedReference],
    *,
    class_api: dict[str, dict] | None = None,
) -> str:
    """Build a re-prompt for the LLM listing each unresolved reference.

    The format is meant to be appended to the original prompt, not
    replace it. The LLM sees: "Your previous output had these specific
    problems — fix them and re-emit the entire file."
    """
    lines = [
        "## ⚠️ Verification failed — re-emit the file",
        "",
        "Your previous output called methods that do not exist on the "
        "receiving classes. The migration is API-preserving; you can only "
        "call methods that ACTUALLY exist on the migrated sibling class.",
        "",
        "Unresolved references:",
        "",
    ]
    for ref in issues:
        if ref.method_name == "<init>":
            line = (
                f"- Line {ref.line_number}: class `{ref.receiver_class}` is "
                "INVENTED. It does not exist in the project, the Playwright "
                "API, or any imported package."
            )
            if ref.suggested:
                line += f" Did you mean `{ref.suggested}`?"
            line += " Either use a real class or remove this code path."
        elif ref.method_name in ("<extends>", "<implements>"):
            kind = ref.method_name.strip("<>")
            line = (
                f"- Line {ref.line_number}: `{kind} {ref.receiver_class}` "
                "references a type that does not exist in the migrated "
                "project's classpath. Selenium types (WebElement, "
                "WebDriver, etc.) are NOT available in the Playwright "
                "output — do not declare classes that implement or "
                "extend them. Either drop the inheritance or pick a "
                "Playwright equivalent (e.g. wrap a `Locator` directly "
                "without implementing WebElement)."
            )
            if ref.suggested:
                line += f" Did you mean `{ref.suggested}`?"
        else:
            line = (
                f"- Line {ref.line_number}: `{ref.receiver_class}.{ref.method_name}(...)`"
                f" does not exist on {ref.receiver_class}."
            )
            if ref.suggested:
                line += f" Did you mean `{ref.suggested}`?"
        lines.append(line)

    # Include the full method index for each receiver class so the LLM
    # can pick the right one without guessing.
    receivers_by_class: dict[str, list[UnresolvedReference]] = {}
    for ref in issues:
        receivers_by_class.setdefault(ref.receiver_class, []).append(ref)

    if class_api:
        lines.append("")
        lines.append("Available methods on each affected class:")
        lines.append("")
        for cls in receivers_by_class:
            info = class_api.get(cls)
            if not info:
                continue
            method_names = info.get("method_names") or []
            if method_names:
                lines.append(f"- `{cls}`: {', '.join(sorted(set(method_names)))}")

    lines.append("")
    lines.append(
        "Re-emit the COMPLETE file via the same tool. Either change the "
        "method names to ones from the lists above, or change the receiver "
        "to a different object. Do not invent new methods."
    )

    return "\n".join(lines)
