"""
Migration Report.

Tracks what was migrated, how, and with what confidence. Emits HTML, JSON,
and Markdown reports so users can inspect, audit, and share results.
"""

from __future__ import annotations

import difflib
import html
import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


# -----------------------------
# Data model
# -----------------------------


@dataclass
class PatternSummary:
    """A detected Selenium pattern and how QAMigrate handled it."""

    pattern_type: str
    count: int
    migration_strategy: str


@dataclass
class Hallucination:
    """A call to a method that does not exist on the referenced class."""

    called_method: str
    on_class: str
    similar_to: str | None = None  # closest real method, if we found one
    source_file: str | None = None  # the generated file where this was detected


@dataclass
class MigrationRecord:
    """A single file's migration outcome."""

    source_path: str
    output_path: str | None
    success: bool
    duration_seconds: float
    patterns: list[PatternSummary] = field(default_factory=list)
    compilation_attempts: int = 0
    compiled: bool | None = None  # None if compilation was skipped
    original_lines: int = 0
    generated_lines: int = 0
    error: str | None = None
    original_code: str = ""
    generated_code: str = ""
    hallucinations: list[Hallucination] = field(default_factory=list)

    # v0.7: error attribution. Splits the file's final compile errors
    # into two buckets:
    #   - caused_error_count: errors QAMigrate is responsible for —
    #     hallucinated calls, dropped overloads, structural breakage, etc.
    #   - inherited_error_count: errors that ALREADY existed in the
    #     user's Selenium source. The pre-flight `mvn compile` step
    #     captured these as a baseline. QAMigrate translated the bug
    #     forward but didn't introduce it.
    #
    # The contract is: QAMigrate is responsible for `caused_error_count`,
    # not the total. Users who run with --ignore-source-errors get to
    # see this attribution; users who don't override get a clean source
    # to start with so caused = total.
    caused_error_count: int = 0
    inherited_error_count: int = 0

    @property
    def confidence(self) -> int:
        base = self._base_confidence()
        if base == 0:
            return 0
        penalty = 10 * len(self.hallucinations)
        if penalty:
            return max(20, base - penalty)
        return base

    @property
    def confidence_reason(self) -> str:
        """Human-readable explanation of the confidence score.

        Shown in the HTML report and review.md so QA leads understand
        exactly WHY a file scored what it did -- not just the number.
        """
        if not self.output_path:
            return "Generation failed — no output file produced."
        if not self.success:
            err = f" Error: {self.error[:120]}..." if self.error and len(self.error) > 120 else (f" Error: {self.error}" if self.error else "")
            return f"Generation failed.{err}"
        if self.compiled is None:
            return "Generated OK; compile check skipped (Playwright not on classpath)."
        if self.compiled is True and self.compilation_attempts == 0:
            base_reason = "Compiled clean on first attempt."
        elif self.compiled is True and self.compilation_attempts <= 2:
            base_reason = f"Compiled after {self.compilation_attempts} fix attempt(s)."
        elif self.compiled is True:
            base_reason = f"Compiled but needed {self.compilation_attempts} fix attempts — verify manually."
        elif self.compilation_attempts > 0:
            base_reason = f"Compilation failed after {self.compilation_attempts} fix attempt(s)."
        else:
            base_reason = "Generation succeeded but pipeline did not reach compile step."

        if self.hallucinations:
            halluc_note = (
                f" -{10 * len(self.hallucinations)} pts: "
                f"{len(self.hallucinations)} potential hallucination(s) detected."
            )
        else:
            halluc_note = ""

        return base_reason + halluc_note

    def _base_confidence(self) -> int:
        if not self.output_path:
            return 0
        if self.compiled is None and self.success:
            return 70
        if self.compiled is True and self.compilation_attempts == 0:
            return 100
        if self.compiled is True and self.compilation_attempts <= 2:
            return 90
        if self.compiled is True:
            return 80
        if self.success or self.compilation_attempts > 0:
            return 50
        return 30

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["confidence"] = self.confidence
        # Don't bloat JSON with full source -- keep lines only
        d.pop("original_code", None)
        d.pop("generated_code", None)
        return d


@dataclass
class MigrationReport:
    """
    Aggregate report for a migration run.

    Contains per-file MigrationRecord entries plus batch-level metrics.
    """

    started_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    finished_at: str | None = None
    source_language: str = "Java (Selenium)"
    target_language: str = "Java (Playwright)"
    records: list[MigrationRecord] = field(default_factory=list)

    # -------- batch metrics --------

    @property
    def total_files(self) -> int:
        return len(self.records)

    @property
    def success_count(self) -> int:
        return sum(1 for r in self.records if r.success)

    @property
    def failed_count(self) -> int:
        return sum(1 for r in self.records if not r.success)

    @property
    def compiled_count(self) -> int:
        return sum(1 for r in self.records if r.compiled is True)

    @property
    def total_duration_seconds(self) -> float:
        return sum(r.duration_seconds for r in self.records)

    @property
    def total_patterns(self) -> int:
        return sum(sum(p.count for p in r.patterns) for r in self.records)

    @property
    def patterns_by_type(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for record in self.records:
            for p in record.patterns:
                counts[p.pattern_type] = counts.get(p.pattern_type, 0) + p.count
        return dict(sorted(counts.items(), key=lambda kv: -kv[1]))

    @property
    def average_confidence(self) -> int:
        if not self.records:
            return 0
        return sum(r.confidence for r in self.records) // len(self.records)

    @property
    def estimated_hours_saved(self) -> float:
        """
        Estimate manual migration time saved.

        Only counts patterns from files that were actually migrated (confidence
        >= 70). Failed migrations get zero credit because the user will still
        have to do that file by hand.

        Heuristic: ~15 min of developer time per detected pattern (research +
        rewrite + test). Industry anecdotes for Selenium->Playwright migration
        range from 10-30 min per pattern.
        """
        usable_patterns = sum(
            sum(p.count for p in r.patterns)
            for r in self.records
            if r.confidence >= 70
        )
        return round(usable_patterns * 0.25, 1)

    def finish(self) -> None:
        self.finished_at = datetime.now(timezone.utc).isoformat()

    def add(self, record: MigrationRecord) -> None:
        self.records.append(record)

    # -------- output formats --------

    def to_dict(self) -> dict[str, Any]:
        return {
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "source_language": self.source_language,
            "target_language": self.target_language,
            "metrics": {
                "total_files": self.total_files,
                "success_count": self.success_count,
                "failed_count": self.failed_count,
                "compiled_count": self.compiled_count,
                "total_duration_seconds": round(self.total_duration_seconds, 2),
                "total_patterns": self.total_patterns,
                "patterns_by_type": self.patterns_by_type,
                "average_confidence": self.average_confidence,
                "estimated_hours_saved": self.estimated_hours_saved,
            },
            "files": [r.to_dict() for r in self.records],
        }

    def write_json(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")
        return path

    def write_markdown(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self._render_markdown(), encoding="utf-8")
        return path

    def write_html(self, path: Path) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self._render_html(), encoding="utf-8")
        return path

    def write_review_markdown(self, path: Path) -> Path:
        """v0.5.2(d): prioritized manual-review checklist for QA leads.

        Unlike `report.md` (which is per-file diff detail), this file is
        a workflow document: three buckets that answer "which files do I
        eyeball first?". Pure additive output; safe to ignore if unused.
        """
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self._render_review_markdown(), encoding="utf-8")
        return path

    # -------- review-checklist bucketing (v0.5.2d) --------

    def _bucket_records(
        self,
    ) -> tuple[list[MigrationRecord], list[MigrationRecord], list[MigrationRecord]]:
        """
        Split records into (priority, verify, solid) for the review checklist.

        - priority: needs human attention before anything else
          (generation failed, didn't compile, or confidence < 70)
        - verify: ran successfully but has warning signs
          (hallucinations flagged, OR needed 3+ compile-fix attempts)
        - solid: confidence >= 90 AND zero hallucinations AND compiled
        """
        priority: list[MigrationRecord] = []
        verify: list[MigrationRecord] = []
        solid: list[MigrationRecord] = []

        for r in self.records:
            if not r.success or r.compiled is False or r.confidence < 70:
                priority.append(r)
                continue
            if r.hallucinations or r.compilation_attempts >= 3:
                verify.append(r)
                continue
            if r.confidence >= 90 and r.compiled is not False:
                solid.append(r)
            else:
                # Middling files (70-89 confidence, compiled, no halluc)
                # go in verify -- not dangerous but worth a glance.
                verify.append(r)

        # Lowest confidence first within priority/verify so the most
        # painful files rise to the top of each section.
        priority.sort(key=lambda r: r.confidence)
        verify.sort(key=lambda r: r.confidence)
        return priority, verify, solid

    def _reason_for_priority(self, r: MigrationRecord) -> str:
        reason = r.confidence_reason
        # Add first compile error snippet if available (helps triage instantly).
        if r.compiled is False and r.error:
            snippet = r.error.strip()[:150].replace("\n", " ")
            return f"{reason} → `{snippet}`"
        return reason

    def _reason_for_verify(self, r: MigrationRecord) -> str:
        parts: list[str] = []
        if r.hallucinations:
            names = ", ".join(h.called_method for h in r.hallucinations[:3])
            suffix = "..." if len(r.hallucinations) > 3 else ""
            parts.append(f"{len(r.hallucinations)} hallucination(s): {names}{suffix}")
        if r.compilation_attempts >= 3:
            parts.append(f"{r.compilation_attempts} fix attempts needed")
        if r.confidence < 90 and not parts:
            parts.append(r.confidence_reason)
        return "; ".join(parts) or r.confidence_reason

    def _render_review_markdown(self) -> str:
        priority, verify, solid = self._bucket_records()
        lines: list[str] = [
            "# QAMigrate Manual Review Checklist",
            "",
            f"**Source -> Target:** {self.source_language} -> {self.target_language}",
        ]
        if self.finished_at:
            lines.append(f"**Finished:** {self.finished_at}")
        lines.extend([
            "",
            "Three buckets, ordered by the attention each file deserves.",
            "Start at the top: Priority first, then Verify, then skim Solid.",
            "",
            f"- **Priority:** {len(priority)} file(s) -- fix or re-run",
            f"- **Verify:**   {len(verify)} file(s) -- glance at these",
            f"- **Solid:**    {len(solid)} file(s) -- likely ship-ready",
            "",
        ])

        lines.append("## 1. Priority -- look at these first")
        lines.append("")
        if not priority:
            lines.append("_None. No migration failures, no files below 70% confidence._")
        else:
            lines.append("Generation failed, compilation failed, or confidence < 70%.")
            lines.append("")
            for r in priority:
                lines.append(
                    f"- [ ] **{r.source_path}** -- {self._reason_for_priority(r)}"
                )
        lines.append("")

        lines.append("## 2. Verify -- compiled, but worth a glance")
        lines.append("")
        if not verify:
            lines.append("_None. Every compiled file is either solid or priority._")
        else:
            lines.append(
                "Compiled, but flagged for hallucinations, multiple fix "
                "attempts, or sub-90% confidence. Skim the diff."
            )
            lines.append("")
            for r in verify:
                lines.append(
                    f"- [ ] **{r.source_path}** -- {self._reason_for_verify(r)}"
                )
        lines.append("")

        lines.append("## 3. Solid -- likely ship-ready")
        lines.append("")
        if not solid:
            lines.append("_None yet -- run the full pipeline first._")
        else:
            lines.append(
                "Confidence >= 90%, zero hallucinations, compiled cleanly. "
                "Spot-check a few at random."
            )
            lines.append("")
            for r in solid:
                lines.append(f"- [x] {r.source_path} -- {r.confidence}%")
        lines.append("")

        return "\n".join(lines)

    # -------- rendering --------

    def _render_markdown(self) -> str:
        lines: list[str] = []
        lines.append("# QAMigrate Migration Report")
        lines.append("")
        lines.append(f"**Source -> Target:** {self.source_language} -> {self.target_language}")
        lines.append(f"**Started:** {self.started_at}")
        if self.finished_at:
            lines.append(f"**Finished:** {self.finished_at}")
        lines.append("")
        lines.append("## Summary")
        lines.append("")
        lines.append(f"- **Files migrated:** {self.success_count} / {self.total_files}")
        lines.append(f"- **Patterns handled:** {self.total_patterns}")
        lines.append(f"- **Average confidence:** {self.average_confidence}%")
        lines.append(f"- **Time taken:** {self.total_duration_seconds:.1f}s")
        lines.append(f"- **Estimated manual effort saved:** ~{self.estimated_hours_saved} hours")
        lines.append("")

        if self.patterns_by_type:
            lines.append("## Patterns handled")
            lines.append("")
            lines.append("| Pattern | Count |")
            lines.append("|---------|-------|")
            for name, count in self.patterns_by_type.items():
                lines.append(f"| `{name}` | {count} |")
            lines.append("")

        lines.append("## Files")
        lines.append("")
        lines.append("| File | Status | Confidence | Patterns | Hallucinations | Time |")
        lines.append("|------|--------|------------|----------|----------------|------|")
        for r in self.records:
            name = Path(r.source_path).name
            status = "OK" if r.success else "FAIL"
            patterns = sum(p.count for p in r.patterns)
            lines.append(
                f"| `{name}` | {status} | {r.confidence}% | {patterns} | "
                f"{len(r.hallucinations)} | {r.duration_seconds:.1f}s |"
            )
        lines.append("")

        # Hallucinations detail section
        all_halluc = [(r, h) for r in self.records for h in r.hallucinations]
        if all_halluc:
            lines.append("## Potential method hallucinations")
            lines.append("")
            lines.append(
                "These calls on sibling classes do not match any known "
                "migrated method. They will likely cause compile errors."
            )
            lines.append("")
            lines.append("| File | Called | Closest real method |")
            lines.append("|------|--------|---------------------|")
            for r, h in all_halluc:
                name = Path(r.source_path).name
                similar = h.similar_to or "-"
                lines.append(f"| `{name}` | `{h.called_method}` | `{similar}` |")
            lines.append("")

        return "\n".join(lines)

    def _render_html(self) -> str:
        # Build per-file cards and group them into buckets for the sidebar nav.
        priority, verify, solid = self._bucket_records()

        def _bucket_label(r: MigrationRecord) -> str:
            if r in priority:
                return "priority"
            if r in verify:
                return "verify"
            return "solid"

        files_html = "\n".join(
            self._render_file_card(r, _bucket_label(r)) for r in self.records
        )

        patterns_rows = "\n".join(
            f"<tr><td><code>{html.escape(name)}</code></td>"
            f"<td class='pat-count'>{count}</td></tr>"
            for name, count in self.patterns_by_type.items()
        )

        # Sidebar file index
        sidebar_items = "\n".join(
            f'<a href="#f{i}" class="nav-item nav-{_bucket_label(r)}" '
            f'title="{html.escape(Path(r.source_path).name)}">'
            f'<span class="nav-dot"></span>'
            f'<span class="nav-name">{html.escape(Path(r.source_path).name)}</span>'
            f'<span class="nav-conf">{r.confidence}%</span>'
            f'</a>'
            for i, r in enumerate(self.records)
        )

        fail_val_class = "val-fail" if self.failed_count > 0 else "val-ok"
        avg_val_class = (
            "val-ok" if self.average_confidence >= 90
            else "val-warn" if self.average_confidence >= 70
            else "val-fail"
        )

        return _HTML_TEMPLATE.format(
            started_at=html.escape(self.started_at),
            finished_at=html.escape(self.finished_at or "in progress"),
            source_lang=html.escape(self.source_language),
            target_lang=html.escape(self.target_language),
            total_files=self.total_files,
            success_count=self.success_count,
            failed_count=self.failed_count,
            fail_val_class=fail_val_class,
            total_patterns=self.total_patterns,
            avg_confidence=self.average_confidence,
            avg_val_class=avg_val_class,
            total_duration=f"{self.total_duration_seconds:.1f}",
            hours_saved=self.estimated_hours_saved,
            priority_count=len(priority),
            verify_count=len(verify),
            solid_count=len(solid),
            patterns_rows=patterns_rows or "<tr><td colspan='2'><em>No patterns detected</em></td></tr>",
            sidebar_items=sidebar_items or "<div class='nav-empty'>No files</div>",
            files_html=files_html or "<p class='empty'>No files migrated.</p>",
        )

    def _render_file_card(self, record: MigrationRecord, bucket: str = "solid") -> str:
        idx = self.records.index(record)
        name = html.escape(Path(record.source_path).name)
        full_path = html.escape(record.source_path)
        status_class = "ok" if record.success else "fail"
        status_text = "✓ Success" if record.success else "✗ Failed"

        conf = record.confidence
        conf_color = _conf_color(conf)

        patterns_list = "".join(
            f"<li>"
            f"<span class='pat-tag'>{html.escape(p.pattern_type)}</span>"
            f"<span class='pat-x'>×{p.count}</span>"
            f"<span class='pat-note'>{html.escape(p.migration_strategy)}</span>"
            f"</li>"
            for p in record.patterns
        )

        diff_html = ""
        if record.original_code and record.generated_code:
            diff_html = _render_side_by_side_diff(
                record.original_code, record.generated_code
            )

        error_html = ""
        if record.error:
            err_text = html.escape(record.error)
            error_html = (
                f'<div class="card-error">'
                f'<div class="error-label">Compiler / generation error</div>'
                f'<pre class="error-pre">{err_text}</pre>'
                f'</div>'
            )

        if record.compiled is True:
            compiled_badge = '<span class="pill pill-ok">✓ Compiled</span>'
        elif record.compiled is False:
            compiled_badge = '<span class="pill pill-fail">✗ Did not compile</span>'
        else:
            compiled_badge = '<span class="pill pill-neutral">⊘ Compile skipped</span>'

        attempts_badge = ""
        if record.compilation_attempts > 0:
            attempts_badge = (
                f'<span class="pill pill-neutral">'
                f'{record.compilation_attempts} fix attempt(s)</span>'
            )

        halluc_badge = ""
        halluc_html = ""
        if record.hallucinations:
            halluc_badge = (
                f'<span class="pill pill-warn">'
                f'⚠ {len(record.hallucinations)} hallucination(s)</span>'
            )
            items = "".join(
                (
                    "<li>"
                    f"<span class='hc-class'>{html.escape(h.on_class)}</span>"
                    f"<span class='hc-dot'>.</span>"
                    f"<code class='hc-method'>{html.escape(h.called_method.split('.')[-1])}</code>"
                    + (
                        f" <span class='hc-suggest'>→ did you mean "
                        f"<code>{html.escape(h.similar_to.split('.')[-1])}</code>?</span>"
                        if h.similar_to else ""
                    )
                    + (
                        f" <span class='hc-file'>in {html.escape(Path(h.source_file).name)}</span>"
                        if h.source_file else ""
                    )
                    + "</li>"
                )
                for h in record.hallucinations
            )
            halluc_html = (
                '<div class="halluc-block">'
                '<div class="halluc-title">⚠ Potential hallucinations</div>'
                '<p class="halluc-desc">These method calls do not match any known migrated '
                'method — likely cause compile errors or runtime failures.</p>'
                f'<ul class="halluc-list">{items}</ul>'
                '</div>'
            )

        lines_info = ""
        if record.original_lines or record.generated_lines:
            lines_info = (
                f'<span class="meta-lines">'
                f'{record.original_lines} → {record.generated_lines} lines'
                f'</span>'
            )

        return f"""
<details class="file-card fc-{bucket}" id="f{idx}">
  <summary class="card-summary">
    <div class="card-left">
      <span class="expand-arrow">▶</span>
      <span class="fc-status {status_class}">{status_text}</span>
      <div class="fc-names">
        <span class="fc-filename">{name}</span>
        <span class="fc-path">{full_path}</span>
      </div>
    </div>
    <div class="card-right">
      {lines_info}
      <div class="conf-wrap">
        <span class="conf-num" style="color:{conf_color}">{conf}%</span>
        <div class="conf-track">
          <div class="conf-fill" style="width:{conf}%;background:{conf_color}"></div>
        </div>
      </div>
      <span class="fc-dur">{record.duration_seconds:.1f}s</span>
      {compiled_badge}
      {attempts_badge}
      {halluc_badge}
    </div>
  </summary>

  <div class="card-body">
    <div class="card-reason">ℹ {html.escape(record.confidence_reason)}</div>

    {error_html}

    <div class="card-cols">
      <div class="card-col">
        <div class="col-title">Patterns handled</div>
        <ul class="pat-list">{patterns_list or '<li class="pat-none">None detected</li>'}</ul>
      </div>
      {"<div class='card-col'>" + halluc_html + "</div>" if halluc_html else ""}
    </div>

    {('<div class="diff-section"><div class="diff-title">Before → After</div>' + diff_html + '</div>') if diff_html else ''}
  </div>
</details>
"""


def _conf_color(confidence: int) -> str:
    """Return a CSS hex color for the confidence bar fill."""
    if confidence >= 90:
        return "#3fb950"
    if confidence >= 70:
        return "#d2991a"
    if confidence >= 50:
        return "#f0883e"
    return "#f85149"


def _render_side_by_side_diff(original: str, generated: str) -> str:
    """Render a side-by-side HTML diff using stdlib difflib."""
    differ = difflib.HtmlDiff(wrapcolumn=80, tabsize=4)
    return differ.make_table(
        original.splitlines(),
        generated.splitlines(),
        fromdesc="Original (Selenium)",
        todesc="Generated (Playwright)",
        context=True,
        numlines=3,
    )


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QAMigrate — Migration Report</title>
  <style>
    /* ── Reset ──────────────────────────────────────────────────────── */
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    html {{ font-size: 15px; scroll-behavior: smooth; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background: #0d1117;
      color: #c9d1d9;
      line-height: 1.6;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }}

    /* ── Top header bar ─────────────────────────────────────────────── */
    .top-bar {{
      background: linear-gradient(135deg, #161b22 0%, #0d1117 100%);
      border-bottom: 1px solid #30363d;
      padding: 1.25rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 1.5rem;
      position: sticky;
      top: 0;
      z-index: 100;
    }}
    .brand {{
      display: flex;
      align-items: center;
      gap: 0.75rem;
    }}
    .brand-name {{
      font-size: 1.25rem;
      font-weight: 800;
      color: #f0f6fc;
      letter-spacing: -0.3px;
    }}
    .brand-name span {{ color: #58a6ff; }}
    .brand-sep {{
      width: 1px;
      height: 1.2em;
      background: #30363d;
    }}
    .brand-doc {{
      font-size: 0.82rem;
      color: #8b949e;
      font-weight: 500;
    }}
    .header-meta {{
      display: flex;
      gap: 1rem;
      font-size: 0.78rem;
      color: #8b949e;
      align-items: center;
    }}
    .header-pill {{
      background: #21262d;
      border: 1px solid #30363d;
      border-radius: 20px;
      padding: 3px 10px;
      font-size: 0.75rem;
    }}
    .arrow-sep {{ color: #58a6ff; font-size: 0.9rem; }}

    /* ── Layout: sidebar + main ─────────────────────────────────────── */
    .layout {{
      display: flex;
      flex: 1;
      min-height: 0;
    }}
    .sidebar {{
      width: 260px;
      flex-shrink: 0;
      background: #161b22;
      border-right: 1px solid #30363d;
      overflow-y: auto;
      position: sticky;
      top: 57px;
      height: calc(100vh - 57px);
      padding: 1rem 0;
    }}
    .sidebar-title {{
      font-size: 0.68rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.1em;
      color: #484f58;
      padding: 0.25rem 1rem 0.6rem;
    }}
    .nav-buckets {{
      display: flex;
      gap: 0.3rem;
      padding: 0 0.75rem 0.75rem;
    }}
    .nb-pill {{
      flex: 1;
      text-align: center;
      padding: 4px 0;
      border-radius: 4px;
      font-size: 0.7rem;
      font-weight: 700;
      cursor: pointer;
    }}
    .nb-priority {{ background: rgba(248,81,73,0.15); color: #f85149; }}
    .nb-verify   {{ background: rgba(210,153,34,0.15); color: #d2991a; }}
    .nb-solid    {{ background: rgba(63,185,80,0.15);  color: #3fb950; }}
    .nav-item {{
      display: flex;
      align-items: center;
      gap: 0.5rem;
      padding: 0.35rem 1rem;
      font-size: 0.78rem;
      color: #8b949e;
      text-decoration: none;
      border-left: 2px solid transparent;
      transition: background 0.1s, border-color 0.1s;
      cursor: pointer;
    }}
    .nav-item:hover {{ background: #21262d; color: #c9d1d9; }}
    .nav-dot {{ width: 7px; height: 7px; border-radius: 50%; flex-shrink: 0; }}
    .nav-priority .nav-dot {{ background: #f85149; }}
    .nav-verify   .nav-dot {{ background: #d2991a; }}
    .nav-solid    .nav-dot {{ background: #3fb950; }}
    .nav-name {{ flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
    .nav-conf {{ font-size: 0.7rem; color: #484f58; flex-shrink: 0; }}

    /* ── Main content ───────────────────────────────────────────────── */
    .main {{
      flex: 1;
      padding: 1.5rem 2rem;
      min-width: 0;
      overflow-x: hidden;
    }}

    /* ── Metric grid ────────────────────────────────────────────────── */
    .metrics {{
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 0.75rem;
      margin-bottom: 1.75rem;
    }}
    .metric {{
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 1rem 0.9rem;
      transition: border-color 0.15s, transform 0.15s;
    }}
    .metric:hover {{ border-color: #58a6ff; transform: translateY(-2px); }}
    .metric-label {{
      font-size: 0.68rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8b949e;
    }}
    .metric-value {{
      font-size: 2rem;
      font-weight: 800;
      color: #f0f6fc;
      line-height: 1.1;
      margin-top: 0.25rem;
    }}
    .metric-sub {{
      font-size: 0.72rem;
      color: #484f58;
      margin-top: 2px;
    }}
    .val-ok   {{ color: #3fb950 !important; }}
    .val-warn {{ color: #d2991a !important; }}
    .val-fail {{ color: #f85149 !important; }}

    /* ── Bucket summary row ─────────────────────────────────────────── */
    .bucket-row {{
      display: flex;
      gap: 0.75rem;
      margin-bottom: 1.5rem;
    }}
    .bucket-card {{
      flex: 1;
      border: 1px solid #30363d;
      border-radius: 8px;
      padding: 0.75rem 1rem;
      background: #161b22;
    }}
    .bucket-card.bc-priority {{ border-color: rgba(248,81,73,0.4); }}
    .bucket-card.bc-verify   {{ border-color: rgba(210,153,34,0.4); }}
    .bucket-card.bc-solid    {{ border-color: rgba(63,185,80,0.4);  }}
    .bucket-title {{
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 0.15rem;
    }}
    .bc-priority .bucket-title {{ color: #f85149; }}
    .bc-verify   .bucket-title {{ color: #d2991a; }}
    .bc-solid    .bucket-title {{ color: #3fb950; }}
    .bucket-count {{
      font-size: 1.75rem;
      font-weight: 800;
      color: #f0f6fc;
      line-height: 1;
    }}
    .bucket-desc {{
      font-size: 0.72rem;
      color: #8b949e;
      margin-top: 2px;
    }}

    /* ── Section headings ───────────────────────────────────────────── */
    .section-head {{
      font-size: 0.78rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8b949e;
      margin-bottom: 0.6rem;
      padding-bottom: 0.5rem;
      border-bottom: 1px solid #21262d;
    }}

    /* ── Patterns table ─────────────────────────────────────────────── */
    .pat-table {{
      width: 100%;
      border-collapse: collapse;
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 1.75rem;
      font-size: 0.85rem;
    }}
    .pat-table th {{
      padding: 0.5rem 0.85rem;
      text-align: left;
      background: #1c2128;
      color: #8b949e;
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      border-bottom: 1px solid #30363d;
    }}
    .pat-table td {{
      padding: 0.45rem 0.85rem;
      border-bottom: 1px solid #21262d;
      vertical-align: middle;
    }}
    .pat-table tbody tr:last-child td {{ border-bottom: none; }}
    .pat-table tbody tr:hover {{ background: #1c2128; }}
    code {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.82em;
      background: #21262d;
      padding: 0.1em 0.45em;
      border-radius: 4px;
      color: #e6edf3;
    }}
    .pat-count {{ color: #58a6ff; font-weight: 700; }}

    /* ── File cards ─────────────────────────────────────────────────── */
    .file-card {{
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      margin-bottom: 0.6rem;
      overflow: hidden;
      transition: border-color 0.15s;
    }}
    .file-card[open] {{ border-color: #388bfd; }}
    .fc-priority {{ border-left: 3px solid #f85149; }}
    .fc-verify   {{ border-left: 3px solid #d2991a; }}
    .fc-solid    {{ border-left: 3px solid #3fb950; }}

    .card-summary {{
      cursor: pointer;
      list-style: none;
      padding: 0.85rem 1.1rem;
      display: flex;
      align-items: center;
      gap: 1rem;
      user-select: none;
    }}
    .card-summary::-webkit-details-marker {{ display: none; }}
    .card-summary:hover {{ background: #1c2128; }}

    .card-left {{
      display: flex;
      align-items: center;
      gap: 0.6rem;
      min-width: 0;
      flex: 1;
    }}
    .expand-arrow {{
      color: #484f58;
      font-size: 0.65rem;
      transition: transform 0.2s;
      flex-shrink: 0;
    }}
    .file-card[open] .expand-arrow {{ transform: rotate(90deg); }}

    .fc-status {{
      font-size: 0.72rem;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 20px;
      flex-shrink: 0;
    }}
    .fc-status.ok   {{ background: rgba(63,185,80,0.15);  color: #3fb950; }}
    .fc-status.fail {{ background: rgba(248,81,73,0.15);  color: #f85149; }}

    .fc-names {{ min-width: 0; }}
    .fc-filename {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-weight: 700;
      font-size: 0.88rem;
      color: #e6edf3;
      display: block;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}
    .fc-path {{
      font-size: 0.7rem;
      color: #484f58;
      display: block;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }}

    .card-right {{
      display: flex;
      align-items: center;
      gap: 0.6rem;
      flex-shrink: 0;
      flex-wrap: wrap;
      justify-content: flex-end;
    }}
    .meta-lines {{
      font-size: 0.72rem;
      color: #484f58;
    }}
    .conf-wrap {{
      display: flex;
      align-items: center;
      gap: 0.4rem;
    }}
    .conf-num {{
      font-size: 0.85rem;
      font-weight: 700;
      min-width: 38px;
      text-align: right;
    }}
    .conf-track {{
      width: 72px;
      height: 5px;
      background: #21262d;
      border-radius: 3px;
      overflow: hidden;
    }}
    .conf-fill {{ height: 100%; border-radius: 3px; transition: width 0.3s; }}
    .fc-dur {{ font-size: 0.72rem; color: #8b949e; }}

    /* ── Pills ──────────────────────────────────────────────────────── */
    .pill {{
      font-size: 0.7rem;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 20px;
      white-space: nowrap;
    }}
    .pill-ok      {{ background: rgba(63,185,80,0.15);  color: #3fb950; }}
    .pill-fail    {{ background: rgba(248,81,73,0.15);  color: #f85149; }}
    .pill-warn    {{ background: rgba(210,153,34,0.15); color: #d2991a; }}
    .pill-neutral {{ background: rgba(139,148,158,0.15);color: #8b949e; }}

    /* ── Card body ──────────────────────────────────────────────────── */
    .card-body {{
      border-top: 1px solid #21262d;
      padding: 1rem 1.1rem 1.1rem;
    }}
    .card-reason {{
      font-size: 0.78rem;
      color: #8b949e;
      background: #1c2128;
      border-radius: 6px;
      padding: 0.4rem 0.75rem;
      margin-bottom: 1rem;
    }}

    /* ── Error block ────────────────────────────────────────────────── */
    .card-error {{
      background: rgba(248,81,73,0.07);
      border: 1px solid rgba(248,81,73,0.3);
      border-radius: 6px;
      padding: 0.75rem;
      margin-bottom: 1rem;
    }}
    .error-label {{
      font-size: 0.72rem;
      font-weight: 700;
      color: #f85149;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-bottom: 0.4rem;
    }}
    .error-pre {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.78rem;
      color: #ffa198;
      white-space: pre-wrap;
      word-break: break-all;
      max-height: 200px;
      overflow-y: auto;
      line-height: 1.5;
    }}

    /* ── Two-col layout inside card ─────────────────────────────────── */
    .card-cols {{
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 1rem;
      margin-bottom: 0.75rem;
    }}
    .card-cols:has(> :only-child) {{ grid-template-columns: 1fr; }}
    .col-title {{
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8b949e;
      margin-bottom: 0.4rem;
    }}

    /* ── Pattern list ───────────────────────────────────────────────── */
    .pat-list {{ list-style: none; display: flex; flex-direction: column; gap: 0.2rem; }}
    .pat-list li {{
      display: flex;
      align-items: center;
      gap: 0.4rem;
      padding: 0.3rem 0;
      border-bottom: 1px solid #21262d;
      font-size: 0.82rem;
    }}
    .pat-list li:last-child {{ border-bottom: none; }}
    .pat-none {{ color: #484f58; font-style: italic; }}
    .pat-tag {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.78rem;
      background: #21262d;
      padding: 1px 6px;
      border-radius: 4px;
      color: #79c0ff;
    }}
    .pat-x {{ color: #8b949e; font-size: 0.78rem; }}
    .pat-note {{ color: #8b949e; font-size: 0.78rem; }}

    /* ── Hallucination block ────────────────────────────────────────── */
    .halluc-block {{
      background: rgba(210,153,34,0.07);
      border: 1px solid rgba(210,153,34,0.3);
      border-radius: 6px;
      padding: 0.75rem;
    }}
    .halluc-title {{
      font-size: 0.72rem;
      font-weight: 700;
      color: #d2991a;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-bottom: 0.3rem;
    }}
    .halluc-desc {{
      font-size: 0.75rem;
      color: #8b949e;
      margin-bottom: 0.5rem;
    }}
    .halluc-list {{ list-style: none; display: flex; flex-direction: column; gap: 0.25rem; }}
    .halluc-list li {{
      font-size: 0.8rem;
      background: rgba(210,153,34,0.08);
      border-left: 2px solid #d2991a;
      padding: 0.3rem 0.6rem;
      border-radius: 0 4px 4px 0;
      color: #e3b341;
    }}
    .hc-class {{ color: #f0f6fc; font-weight: 600; }}
    .hc-dot   {{ color: #8b949e; }}
    .hc-method {{ font-size: 0.82em; }}
    .hc-suggest {{ color: #8b949e; font-style: italic; font-size: 0.9em; }}
    .hc-file    {{ color: #484f58; font-size: 0.82em; }}

    /* ── Diff section ───────────────────────────────────────────────── */
    .diff-section {{ margin-top: 0.75rem; overflow-x: auto; }}
    .diff-title {{
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #8b949e;
      margin-bottom: 0.5rem;
      padding-bottom: 0.4rem;
      border-bottom: 1px solid #21262d;
    }}
    table.diff {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.76rem;
      border-collapse: collapse;
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 6px;
      overflow: hidden;
      width: 100%;
    }}
    table.diff th {{ background: #1c2128; color: #8b949e; padding: 4px 8px; font-weight: 600; }}
    table.diff td {{ padding: 2px 8px; white-space: pre; border-bottom: none; }}
    .diff_header {{ background: #1c2128 !important; color: #8b949e !important; }}
    .diff_next   {{ color: #484f58; }}
    .diff_add    {{ background: rgba(63,185,80,0.15)  !important; color: #56d364; }}
    .diff_chg    {{ background: rgba(210,153,34,0.15) !important; color: #e3b341; }}
    .diff_sub    {{ background: rgba(248,81,73,0.15)  !important; color: #ffa198; }}

    /* ── Footer ─────────────────────────────────────────────────────── */
    .page-footer {{
      text-align: center;
      color: #484f58;
      font-size: 0.78rem;
      padding: 1.5rem 2rem;
      border-top: 1px solid #21262d;
      margin-top: 2rem;
    }}
    .page-footer a {{ color: #58a6ff; text-decoration: none; }}
    .page-footer a:hover {{ text-decoration: underline; }}

    /* ── Responsive ─────────────────────────────────────────────────── */
    @media (max-width: 900px) {{
      .sidebar {{ display: none; }}
      .metrics {{ grid-template-columns: repeat(3, 1fr); }}
    }}
    @media (max-width: 640px) {{
      .top-bar {{ padding: 1rem; flex-wrap: wrap; }}
      .main {{ padding: 1rem; }}
      .metrics {{ grid-template-columns: repeat(2, 1fr); }}
      .bucket-row {{ flex-direction: column; }}
      .card-right {{ display: none; }}
      .card-cols {{ grid-template-columns: 1fr; }}
      table.diff td {{ white-space: pre-wrap; word-break: break-all; }}
    }}
  </style>
</head>
<body>

<!-- Top bar -->
<div class="top-bar">
  <div class="brand">
    <div class="brand-name">QA<span>migrate</span></div>
    <div class="brand-sep"></div>
    <div class="brand-doc">Migration Report</div>
  </div>
  <div class="header-meta">
    <span class="header-pill">{source_lang}</span>
    <span class="arrow-sep">→</span>
    <span class="header-pill">{target_lang}</span>
    <span style="color:#484f58">·</span>
    <span>Started {started_at}</span>
    <span style="color:#484f58">·</span>
    <span>Finished {finished_at}</span>
  </div>
</div>

<div class="layout">

  <!-- Sidebar nav -->
  <nav class="sidebar">
    <div class="sidebar-title">Files ({total_files})</div>
    <div class="nav-buckets">
      <span class="nb-pill nb-priority">⚠ {priority_count} priority</span>
      <span class="nb-pill nb-verify">~ {verify_count} verify</span>
      <span class="nb-pill nb-solid">✓ {solid_count} solid</span>
    </div>
    {sidebar_items}
  </nav>

  <!-- Main -->
  <main class="main">

    <!-- Metrics -->
    <div class="metrics">
      <div class="metric">
        <div class="metric-label">Migrated</div>
        <div class="metric-value val-ok">{success_count}</div>
        <div class="metric-sub">of {total_files} files</div>
      </div>
      <div class="metric">
        <div class="metric-label">Failed</div>
        <div class="metric-value {fail_val_class}">{failed_count}</div>
        <div class="metric-sub">generation errors</div>
      </div>
      <div class="metric">
        <div class="metric-label">Patterns</div>
        <div class="metric-value">{total_patterns}</div>
        <div class="metric-sub">Selenium patterns handled</div>
      </div>
      <div class="metric">
        <div class="metric-label">Avg confidence</div>
        <div class="metric-value {avg_val_class}">{avg_confidence}%</div>
        <div class="metric-sub">across all files</div>
      </div>
      <div class="metric">
        <div class="metric-label">Total time</div>
        <div class="metric-value">{total_duration}s</div>
        <div class="metric-sub">wall-clock</div>
      </div>
      <div class="metric">
        <div class="metric-label">Hours saved</div>
        <div class="metric-value val-ok">~{hours_saved}</div>
        <div class="metric-sub">est. manual effort</div>
      </div>
    </div>

    <!-- Review buckets -->
    <div class="bucket-row">
      <div class="bucket-card bc-priority">
        <div class="bucket-title">⚠ Priority</div>
        <div class="bucket-count">{priority_count}</div>
        <div class="bucket-desc">Failed or confidence &lt; 70%</div>
      </div>
      <div class="bucket-card bc-verify">
        <div class="bucket-title">~ Verify</div>
        <div class="bucket-count">{verify_count}</div>
        <div class="bucket-desc">Hallucinations or 3+ fix attempts</div>
      </div>
      <div class="bucket-card bc-solid">
        <div class="bucket-title">✓ Solid</div>
        <div class="bucket-count">{solid_count}</div>
        <div class="bucket-desc">Confidence ≥ 90%, compiled clean</div>
      </div>
    </div>

    <!-- Patterns -->
    <div class="section-head">Selenium patterns handled</div>
    <table class="pat-table">
      <thead><tr><th>Pattern</th><th>Count</th></tr></thead>
      <tbody>{patterns_rows}</tbody>
    </table>

    <!-- Files -->
    <div class="section-head">Files</div>
    {files_html}

  </main>
</div>

<footer class="page-footer">
  Generated by <strong>QAMigrate</strong> &middot;
  <a href="https://github.com/QATonic/QAMigrate">github.com/QATonic/QAMigrate</a>
</footer>

<script>
  // Smooth-highlight active sidebar link on scroll
  (function() {{
    var items = document.querySelectorAll('.nav-item');
    var cards = document.querySelectorAll('.file-card[id]');
    if (!cards.length) return;
    var obs = new IntersectionObserver(function(entries) {{
      entries.forEach(function(e) {{
        if (e.isIntersecting) {{
          var id = e.target.id;
          items.forEach(function(a) {{
            a.style.borderLeftColor = '';
            a.style.color = '';
            if (a.getAttribute('href') === '#' + id) {{
              a.style.borderLeftColor = '#58a6ff';
              a.style.color = '#c9d1d9';
            }}
          }});
        }}
      }});
    }}, {{ threshold: 0.2 }});
    cards.forEach(function(c) {{ obs.observe(c); }});
  }})();
</script>

</body>
</html>
"""

