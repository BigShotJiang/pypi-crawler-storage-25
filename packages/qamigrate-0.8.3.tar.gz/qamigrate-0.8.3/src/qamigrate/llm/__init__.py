"""
Multi-provider LLM abstraction for QAMigrate.

Agents depend on `LLMProvider`, never on a specific SDK. The provider
registry wires concrete implementations in at import time, and
`build_provider()` is the one-stop factory agents and the CLI call.
"""

from __future__ import annotations

from typing import Any

from qamigrate.llm.base import LLMProvider, StructuredResponse, ToolSchema
from qamigrate.llm.errors import (
    LLMConfigError,
    LLMError,
    LLMMalformedOutput,
    LLMRateLimitError,
    LLMUnavailable,
    LLMUsageCapExhausted,
)
from qamigrate.llm.from_config import build_provider_for_agent
from qamigrate.llm.registry import (
    get_provider_factory,
    list_providers,
    register_provider,
)


def build_provider(
    name: str,
    *,
    model: str | None = None,
    **kwargs: Any,
) -> LLMProvider:
    """
    Construct a provider by name.

    Args:
        name: Short provider name ("anthropic", "openai", "ollama", ...).
        model: Optional model identifier to pin. Defaults to the provider's
               preferred default if not given.
        **kwargs: Provider-specific options (api_key, base_url, host, ...).
                  Passed through to the provider's constructor.

    Returns:
        Ready-to-use LLMProvider instance.

    Raises:
        LLMConfigError: provider unknown or misconfigured.
    """
    factory = get_provider_factory(name)
    if model is not None:
        kwargs.setdefault("model", model)
    return factory(**kwargs)


__all__ = [
    "LLMProvider",
    "StructuredResponse",
    "ToolSchema",
    "LLMError",
    "LLMConfigError",
    "LLMUnavailable",
    "LLMMalformedOutput",
    "LLMRateLimitError",
    "LLMUsageCapExhausted",
    "build_provider",
    "build_provider_for_agent",
    "register_provider",
    "list_providers",
]
