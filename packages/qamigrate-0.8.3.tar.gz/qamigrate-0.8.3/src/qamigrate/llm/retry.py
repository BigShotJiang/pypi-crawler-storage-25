"""
Rate-limit retry helper for LLM provider calls.

v0.5.17: Production runs hit Anthropic/OpenAI rate limits regularly when
processing many files in succession. The 30K input-tokens-per-minute org
limit on Anthropic, for example, is exceeded after ~6 large files in 60s.

Previously providers raised the rate-limit error and the pipeline marked
the file as FAIL — wasting LLM budget on the rest of the run because the
rate-limit window would clear in 30-60 seconds.

This module wraps provider calls with exponential backoff that respects
`Retry-After` headers when present.
"""

from __future__ import annotations

import re
import time
from collections.abc import Callable
from typing import TypeVar

import structlog

from qamigrate.llm.errors import LLMUsageCapExhausted

logger = structlog.get_logger(__name__)

T = TypeVar("T")


# Default retry parameters. Conservative because the failure mode is "wait
# and try again", not "fail loudly" — a slow but successful run is much
# better than a fast run with 30% of files marked FAIL.
DEFAULT_MAX_RETRIES = 5
DEFAULT_INITIAL_BACKOFF_SEC = 5.0
DEFAULT_MAX_BACKOFF_SEC = 90.0
# v0.6.1: Retry-After hints from the provider can legitimately exceed the
# generic exponential-backoff cap (e.g., a soft rate limit may say "wait
# 180 seconds"). Clamping a server-supplied hint to 90s caused the next
# retry to hit the same wall and burn another attempt. We now honor hints
# up to a separate, larger cap; the exponential schedule still respects
# DEFAULT_MAX_BACKOFF_SEC for the generic case.
DEFAULT_MAX_RETRY_AFTER_SEC = 300.0


def is_rate_limit_error(exc: Exception) -> bool:
    """Detect rate-limit errors across providers from the exception text.

    Both Anthropic and OpenAI SDKs throw distinct exception classes, but
    the error message reliably mentions "rate_limit" or "429".  We use
    string detection so this module doesn't import either SDK.
    """
    msg = str(exc).lower()
    return (
        "rate_limit" in msg
        or "rate limit" in msg
        or "ratelimit" in msg
        or "429" in msg
        or "too many requests" in msg
    )


def is_overloaded_error(exc: Exception) -> bool:
    """Detect 'overloaded' errors (Anthropic returns these as 529).

    These are transient and the right thing to do is wait and retry —
    same backoff treatment as rate limits.
    """
    msg = str(exc).lower()
    return (
        "overloaded" in msg
        or " 529" in msg
        or "service_unavailable" in msg
        or "503" in msg
    )


def is_usage_cap_error(exc: Exception) -> bool:
    """Detect hard usage-cap errors — account-level monthly/daily quota.

    These are NOT transient. Retrying makes things worse: every retry burns
    more budget on a guaranteed-failing call, and floods logs with backoff
    warnings that look like rate-limit issues but aren't.

    The right behaviour is to short-circuit the run with a clear "quota
    exhausted" abort so the user knows it's not a code bug — they need to
    wait until their quota resets.

    Examples seen in production:
      - Anthropic: "You have reached your specified API usage limits.
        You will regain access on 2026-05-01"
      - OpenAI: "You exceeded your current quota, please check your plan
        and billing details" (insufficient_quota error code)

    NOTE: ordering matters in callers — check this BEFORE rate-limit, since
    OpenAI's quota error also surfaces as 429.
    """
    msg = str(exc).lower()
    return (
        "usage limit" in msg
        or "regain access" in msg
        or "insufficient_quota" in msg
        or "exceeded your current quota" in msg
        or ("quota" in msg and "billing" in msg)
    )


# Regex to extract Retry-After hint from error message.  Anthropic's
# error sometimes embeds a hint like "try again in 12.3 seconds".
# Capture the unit in group(2) so we can convert minutes -> seconds correctly.
# IMPORTANT: list longer alternatives FIRST in the alternation so "minutes"
# wins over "m" (regex alternation prefers leftmost match — but with greedy
# alternation in Python's re, the *first* alternative that matches at the
# current position wins).
_RETRY_AFTER_HINT_RE = re.compile(
    r"(?:retry|try)[\s\-]*after[:\s]*([0-9]+\.?[0-9]*)"
    r"\s*(minutes?|seconds?|min|sec|m|s)?",
    re.IGNORECASE,
)


def _parse_retry_after(exc: Exception) -> float | None:
    """Extract a Retry-After hint in seconds from the error text, if present."""
    msg = str(exc)
    m = _RETRY_AFTER_HINT_RE.search(msg)
    if not m:
        return None
    try:
        value = float(m.group(1))
    except (ValueError, TypeError):
        return None
    # Convert minutes -> seconds if the captured unit is m/min/minute/minutes.
    unit = (m.group(2) or "").lower()
    if unit and unit.startswith("m"):
        # "minute"/"minutes"/"min"/bare "m" all imply minutes.
        # (The Anthropic SDK doesn't emit ambiguous bare "m" — but if it did,
        # treating as minutes is the safer choice: longer wait, never fails.)
        value *= 60.0
    # v0.6.1: clamp to a separate Retry-After cap (300s by default). The
    # provider's hint takes precedence over the generic backoff schedule —
    # ignoring it just means we retry too early and burn another attempt.
    return max(1.0, min(value, DEFAULT_MAX_RETRY_AFTER_SEC))


def call_with_retry(
    fn: Callable[[], T],
    *,
    max_retries: int = DEFAULT_MAX_RETRIES,
    initial_backoff: float = DEFAULT_INITIAL_BACKOFF_SEC,
    max_backoff: float = DEFAULT_MAX_BACKOFF_SEC,
    operation_name: str = "LLM call",
) -> T:
    """Invoke `fn`, retrying with exponential backoff on rate-limit errors.

    Backoff schedule (seconds): 5, 10, 20, 40, 80 (capped at max_backoff).
    If the error includes a Retry-After hint, that overrides the schedule.

    Non-rate-limit errors propagate immediately. After max_retries failures,
    the last exception is re-raised so the caller can decide what to do.
    """
    backoff = initial_backoff
    last_exc: Exception | None = None

    for attempt in range(max_retries + 1):
        try:
            return fn()
        except LLMUsageCapExhausted:
            # Already classified by an inner caller — propagate immediately.
            raise
        except Exception as exc:
            last_exc = exc

            # Check usage-cap FIRST. OpenAI's quota error is also a 429, so
            # the rate-limit check would otherwise mask it and we'd waste
            # several minutes of backoff on a guaranteed-failing call.
            if is_usage_cap_error(exc):
                logger.error(
                    f"{operation_name}: usage cap exhausted; aborting",
                    error=str(exc)[:300],
                )
                raise LLMUsageCapExhausted(str(exc)) from exc

            is_rate_limit = is_rate_limit_error(exc)
            is_overloaded = is_overloaded_error(exc)

            if not (is_rate_limit or is_overloaded):
                # Other errors aren't ours to retry.
                raise

            if attempt >= max_retries:
                # Out of retries — let the caller see the rate-limit error.
                logger.error(
                    f"{operation_name}: rate-limit retries exhausted",
                    attempts=attempt + 1,
                    error=str(exc)[:200],
                )
                raise

            # Use Retry-After hint if available, else exponential backoff.
            # v0.6.1: a Retry-After hint is provider-issued guidance —
            # honor it up to DEFAULT_MAX_RETRY_AFTER_SEC even when it
            # exceeds the generic exponential cap. The exponential
            # fallback path still uses max_backoff.
            hint = _parse_retry_after(exc)
            if hint is not None:
                wait_sec = min(hint, DEFAULT_MAX_RETRY_AFTER_SEC)
            else:
                wait_sec = min(backoff, max_backoff)

            kind = "rate-limit" if is_rate_limit else "overloaded"
            logger.warning(
                f"{operation_name}: {kind} hit; backing off",
                attempt=attempt + 1,
                max_retries=max_retries,
                wait_seconds=round(wait_sec, 1),
            )
            time.sleep(wait_sec)
            # Exponential backoff for next iteration.
            backoff = min(backoff * 2, max_backoff)

    # Unreachable: loop either returns or raises. Defensive only.
    if last_exc is not None:
        raise last_exc
    raise RuntimeError(f"{operation_name}: retry loop exited unexpectedly")
