"""
LLM-related exceptions.

Agents catch these by base class when they need to react to an LLM
failure; concrete providers raise specific subclasses so users get
actionable error messages (especially for "Ollama isn't running",
"ANTHROPIC_API_KEY missing", etc.).
"""

from __future__ import annotations


class LLMError(Exception):
    """Base class for all LLM provider errors."""


class LLMConfigError(LLMError):
    """Raised when a provider is misconfigured (missing API key, bad URL...).

    Should be raised eagerly, ideally during `build_provider()` rather than
    at the first `generate_structured()` call, so users find out before the
    pipeline spends time on generation.
    """


class LLMUnavailable(LLMError):
    """Raised when the provider's service can't be reached.

    Wraps connection errors from underlying SDKs so callers can catch a
    single type regardless of which provider failed.
    """


class LLMMalformedOutput(LLMError):
    """Raised when the provider returned something that doesn't match the tool schema.

    Providers should retry once internally before raising this -- agents
    should treat it as fatal for a single file but not the whole run.
    """

    def __init__(self, message: str, raw_text: str | None = None) -> None:
        super().__init__(message)
        self.raw_text = raw_text


class LLMRateLimitError(LLMError):
    """Raised when the provider's rate limit is exceeded after all retries.

    v0.5.17: Providers transparently retry on rate-limit (429) errors with
    exponential backoff. This exception is only raised after the retry
    budget is exhausted, so the agent layer rarely sees it.
    """

    def __init__(self, message: str, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class LLMUsageCapExhausted(LLMError):
    """Raised when the provider account's hard usage cap is exhausted.

    v0.5.19: Distinct from rate-limit because it is NOT transient — retrying
    just burns more budget on guaranteed failures. The pipeline should abort
    the entire run on this error rather than march through the remaining
    files marking each FAIL.

    The message preserves the provider's wording (often includes a "regain
    access on YYYY-MM-DD" hint) so the user knows when to retry.
    """
