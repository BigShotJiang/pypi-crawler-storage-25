"""
Provider-agnostic cleanup for LLM output quirks.

Every provider can produce the same garbage classes -- we centralize the
fixes here so agents get consistent behavior no matter which LLM ran.

Two quirks covered today:

1. **Double-escaped strings.** Sometimes the JSON-over-tool-use round-trip
   yields strings containing literal backslash-n sequences instead of real
   newlines. We detect this heuristically and unescape.

2. **Stray markdown fences.** Models occasionally wrap code output in
   ```java ... ``` fences despite being told not to. Strip them.
"""

from __future__ import annotations

from typing import Any  # noqa: F401 — used by _coerce_list_item_to_str


def unescape_llm_string(value: Any) -> Any:
    """
    Unescape stray backslash sequences that leak through LLM tool-use output.

    The model sometimes double-escapes string fields: we see literal
    `\\n`, `\\t`, `\\"` instead of real control characters. This helper
    unescapes only when the string contains the two-char sequences *and*
    lacks the corresponding real characters, so clean strings pass
    through untouched.
    """
    if not isinstance(value, str):
        return value

    needs_unescape = False
    if "\\n" in value and "\n" not in value:
        needs_unescape = True
    # \" is never legitimate in generated Java source, so unescape it
    # whenever we see it regardless of whether real quotes are present.
    if '\\"' in value:
        needs_unescape = True

    if not needs_unescape:
        return value

    return (
        value.replace("\\n", "\n")
             .replace("\\t", "\t")
             .replace('\\"', '"')
             .replace("\\'", "'")
    )


def sanitize_fields(data: dict) -> dict:
    """
    Recursively unescape stray backslash sequences in every string leaf
    of a dict. Used on provider-returned tool-use payloads before handing
    them to agent code.

    v0.5.5: also coerces dict-valued list elements to strings for keys
    that the schema declares as `list[str]` (`fields`, `imports`). gpt-4o
    occasionally returns a structured object (e.g. {'declaration':
    'private Page page;', 'init': 'this.page = page;'}) in those lists.
    Pydantic v2 rejects this with a validation error and the whole file
    is skipped. We extract the most useful string before Pydantic runs.

    We do NOT coerce dict-valued items in `methods` -- those are
    intentionally structured objects (`MethodDefinition`).
    """
    # Keys whose list elements must be plain strings per the schema.
    _STR_LIST_KEYS = {"fields", "imports"}

    result: dict = {}
    for k, v in data.items():
        if isinstance(v, str):
            result[k] = unescape_llm_string(v)
        elif isinstance(v, list):
            if k in _STR_LIST_KEYS:
                result[k] = [_coerce_list_item_to_str(item) for item in v]
            else:
                result[k] = [
                    sanitize_fields(item) if isinstance(item, dict)
                    else unescape_llm_string(item)
                    for item in v
                ]
        elif isinstance(v, dict):
            result[k] = sanitize_fields(v)
        else:
            result[k] = v
    return result


def _coerce_list_item_to_str(item: Any) -> Any:
    """Coerce a list item to string when the LLM returned a dict instead.

    Priority order for extraction keys matches what gpt-4o / Claude most
    commonly uses when they over-structure a field declaration:
    'declaration' > 'type' > 'name' > 'value' > str(item).

    If the item is already a string (or not a dict), it passes through
    the normal unescape path unchanged.
    """
    if isinstance(item, dict):
        for key in ("declaration", "type", "name", "value"):
            if key in item and isinstance(item[key], str):
                return unescape_llm_string(item[key])
        # Last resort: stringify the whole dict -- better than a crash.
        return str(item)
    return unescape_llm_string(item)


def strip_stray_markdown(text: str) -> str:
    """
    Remove opening/closing ```  or ```java fences from text.

    Used by the Fixer when the model wraps its Java source in a code
    fence despite instructions. Non-destructive: text without fences
    passes through unchanged.
    """
    text = text.strip()
    if text.startswith("```"):
        # Drop the opening fence line entirely
        text = text.split("\n", 1)[1] if "\n" in text else ""
        # Drop the closing fence if present
        if text.rstrip().endswith("```"):
            text = text.rstrip()[:-3].rstrip()
    return text


def escape_for_code_fence(source: str) -> str:
    """
    Neutralize backticks in `source` so it can't break out of a markdown
    code-fenced region in an LLM prompt.

    The threat model is NOT attacker-controlled input -- users only
    migrate their own test suites. But a legitimate test file can have
    ``` inside a Java text block (e.g. `String md = "`\u200b``markdown";`),
    which would confuse the model and produce malformed output.

    Fix: replace every run of 3+ backticks with the same count of ` chars
    joined by zero-width spaces. The Java meaning is lost (in a Java text
    block the zero-width space is visible), but since this is only for
    the PROMPT and the model outputs a full rewrite anyway, it doesn't
    leak into the generated Playwright code.

    If the input contains no backtick sequences, returns it unchanged.
    """
    if "```" not in source:
        return source
    # Insert a zero-width space between every pair of backticks to break
    # any run of 3+ backticks without changing the visual length.
    return source.replace("```", "`\u200b`\u200b`")
