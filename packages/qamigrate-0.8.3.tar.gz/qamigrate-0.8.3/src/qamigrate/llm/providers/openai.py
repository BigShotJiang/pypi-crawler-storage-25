"""
OpenAI provider.

Uses OpenAI's chat.completions API with `tools=[...]` and forced
`tool_choice` to produce a dict matching our tool schema. This mirrors
the Anthropic path exactly: give me a system prompt, a user prompt, a
tool schema, and a dict comes back.

Supports:
- Standard OpenAI (api.openai.com)
- Azure OpenAI / LM Studio / vLLM / any OpenAI-compatible endpoint
  (via the `base_url` kwarg)
"""

from __future__ import annotations

import json
import os
from typing import Any

import structlog

from qamigrate.llm.base import LLMProvider, StructuredResponse, ToolSchema
from qamigrate.llm.errors import LLMConfigError, LLMMalformedOutput, LLMUnavailable
from qamigrate.llm.retry import call_with_retry
from qamigrate.llm.sanitize import sanitize_fields

logger = structlog.get_logger(__name__)


DEFAULT_MODEL = "gpt-4o"


class OpenAIProvider(LLMProvider):
    """OpenAI chat.completions with native tool use."""

    name = "openai"
    supports_tool_use = True

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        *,
        api_key: str | None = None,
        api_key_env: str = "OPENAI_API_KEY",
        base_url: str | None = None,
    ) -> None:
        self.model = model
        self._api_key = api_key or os.environ.get(api_key_env)

        if not self._api_key:
            raise LLMConfigError(
                f"OpenAI API key not found. Set the {api_key_env} environment "
                f"variable or pass api_key= explicitly."
            )

        try:
            from openai import OpenAI
        except ImportError as e:
            raise LLMConfigError(
                "The `openai` package is not installed. Run "
                "`pip install openai`."
            ) from e

        client_kwargs: dict[str, Any] = {"api_key": self._api_key}
        if base_url:
            client_kwargs["base_url"] = base_url

        self._client = OpenAI(**client_kwargs)
        self._base_url = base_url

    def __repr__(self) -> str:
        key_hint = f"...{self._api_key[-4:]}" if self._api_key else "NOT SET"
        return f"OpenAIProvider(model={self.model!r}, key={key_hint})"

    def generate_structured(
        self,
        system: str,
        user: str,
        tool: ToolSchema,
        *,
        max_tokens: int = 4096,
        temperature: float = 0.0,
    ) -> StructuredResponse:
        # OpenAI's tool-use API wraps the JSON schema inside
        # { "type": "function", "function": {...} }.
        tool_payload = {
            "type": "function",
            "function": {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.input_schema,
            },
        }

        # v0.5.17: rate-limit retry wrapper.
        def _call() -> Any:
            return self._client.chat.completions.create(
                model=self.model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                tools=[tool_payload],
                tool_choice={
                    "type": "function",
                    "function": {"name": tool.name},
                },
            )

        try:
            response = call_with_retry(_call, operation_name="OpenAI generate_structured")
        except Exception as e:
            # Normalize connection errors into our hierarchy.
            msg = str(e)
            if "connection" in msg.lower() or "timed out" in msg.lower():
                raise LLMUnavailable(f"OpenAI API unreachable: {msg}") from e
            raise

        # Extract the tool call from the first choice.
        try:
            choice = response.choices[0]
            # v0.6.1: detect truncation. OpenAI sets finish_reason="length"
            # when the response was cut off at max_tokens. The tool call
            # JSON will be invalid in that case — fail fast with a clear
            # "increase max_tokens" message rather than producing cryptic
            # JSON-decode errors below.
            finish_reason = getattr(choice, "finish_reason", None)
            if finish_reason == "length":
                raise LLMMalformedOutput(
                    f"OpenAI truncated the response at max_tokens={max_tokens}. "
                    f"Increase max_tokens for this agent (qamigrate.yaml: "
                    f"`coder.max_tokens` / `fixer.max_tokens`) or split the file.",
                    raw_text=None,
                )

            message = choice.message
            tool_calls = getattr(message, "tool_calls", None) or []
            if not tool_calls:
                raw = getattr(message, "content", None)
                raise LLMMalformedOutput(
                    "OpenAI response contained no tool_calls.",
                    raw_text=raw,
                )

            call = tool_calls[0]
            arguments_json = call.function.arguments
        except LLMMalformedOutput:
            raise
        except Exception as e:
            raise LLMMalformedOutput(
                f"Could not parse OpenAI tool call: {e}",
                raw_text=None,
            ) from e

        # OpenAI always returns function.arguments as a JSON STRING, not a
        # dict. Parse it here so callers get the same dict shape Anthropic
        # gives them.
        try:
            data = json.loads(arguments_json)
        except json.JSONDecodeError as e:
            raise LLMMalformedOutput(
                f"OpenAI tool arguments were not valid JSON: {e}",
                raw_text=arguments_json,
            ) from e

        if not isinstance(data, dict):
            raise LLMMalformedOutput(
                f"Expected a JSON object from tool call, got {type(data).__name__}",
                raw_text=arguments_json,
            )

        data = sanitize_fields(data)
        usage = _extract_usage(response)

        return StructuredResponse(
            data=data,
            raw_text=arguments_json,
            provider=self.name,
            model=self.model,
            usage=usage,
        )


def _extract_usage(response: Any) -> dict[str, int]:
    usage = getattr(response, "usage", None)
    if usage is None:
        return {}
    return {
        "input_tokens": int(getattr(usage, "prompt_tokens", 0) or 0),
        "output_tokens": int(getattr(usage, "completion_tokens", 0) or 0),
    }
