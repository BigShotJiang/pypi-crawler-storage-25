"""
Render a ProjectMap as a human-readable architecture report.

Three formats:

- HTML: standalone, styled; drop in a PR / share with a stakeholder
- Markdown: fits in a git commit message or GitHub issue
- JSON: machine-readable; feed into CI or another tool

Same structure as `qamigrate migrate --report`: HTML for people,
Markdown for PRs, JSON for automation.
"""

from __future__ import annotations

import html
import json
from pathlib import Path

from qamigrate.intelligence.project_map import (
    ClassRole,
    DependencyKind,
    ProjectMap,
)


# =====================================================================
# JSON
# =====================================================================


def write_json(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(pm.to_json(), encoding="utf-8")
    return path


# =====================================================================
# Markdown
# =====================================================================


def render_markdown(pm: ProjectMap) -> str:
    lines: list[str] = []

    lines.append(f"# Architecture Report -- {pm.project_name}")
    lines.append("")
    lines.append(f"**Project path:** `{pm.project_path}`")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    lines.append(f"- **Total classes:** {pm.file_count}")
    lines.append(f"- **Dependency edges:** {pm.total_edges}")
    lines.append(f"- **Base classes:** {len(pm.base_classes)}")
    lines.append(f"- **Utility classes:** {len(pm.utility_classes)}")
    lines.append(f"- **Page objects:** {len(pm.page_objects)}")
    lines.append(f"- **Test classes:** {len(pm.test_classes)}")
    lines.append(f"- **Listeners:** {len(pm.listeners)}")
    if pm.driver_manager:
        lines.append(f"- **Driver manager:** `{pm.driver_manager.simple_name}`")
    if pm.config_reader:
        lines.append(f"- **Config reader:** `{pm.config_reader.simple_name}`")
    lines.append("")

    # Infrastructure
    if pm.infrastructure:
        i = pm.infrastructure
        lines.append("## Infrastructure")
        lines.append("")
        lines.append(f"- **Build tool:** {i.build_tool}")
        lines.append(f"- **Test framework:** {i.test_framework}"
                     + (f" {i.test_framework_version}" if i.test_framework_version else ""))
        if i.selenium_version:
            lines.append(f"- **Selenium:** {i.selenium_version}")
        if i.playwright_version:
            lines.append(f"- **Playwright:** {i.playwright_version}")
        if i.logging_library:
            lines.append(f"- **Logging:** {i.logging_library}")
        if i.reporting_libraries:
            lines.append(f"- **Reporting:** {', '.join(i.reporting_libraries)}")
        if i.assertion_library:
            lines.append(f"- **Assertion library:** {i.assertion_library}")
        if i.env_profiles:
            lines.append(f"- **Env profiles:** {', '.join(i.env_profiles)}")
        if i.java_version:
            lines.append(f"- **Java:** {i.java_version}")
        if i.parallel_execution:
            lines.append("- **Parallel execution enabled**")
        lines.append("")

    # Conventions
    c = pm.conventions
    lines.append("## Project conventions")
    lines.append("")
    lines.append("| Convention | Detected |")
    lines.append("|------------|----------|")
    lines.append(f"| Method chaining (page objects return `this`) | {_yes_no(c.method_chaining)} |")
    lines.append(f"| Logs every action (BasePage.click logs first) | {_yes_no(c.logs_every_action)} |")
    lines.append(f"| Logger pattern | `{c.logger_call_pattern or '-'}` |")
    lines.append(f"| Assertion style | `{c.assertion_style or '-'}` |")
    lines.append(f"| Driver access | `{c.driver_access or '-'}` |")
    lines.append(f"| Parallel-safe | {_yes_no(c.parallel_safe)} |")
    lines.append(f"| Implicit waits used | {_yes_no(c.implicit_waits_used)} |")
    lines.append(f"| Password masking | {_yes_no(c.password_masking)} |")
    lines.append(f"| Retry analyzer | {_yes_no(c.uses_retry_analyzer)} |")
    if c.uses_listeners:
        lines.append(f"| TestNG `@Listeners` | `{', '.join(c.uses_listeners)}` |")
    if c.config_override_hierarchy:
        lines.append(f"| Config lookup order | `{' -> '.join(c.config_override_hierarchy)}` |")
    lines.append("")

    if c.explicit_wait_helpers:
        lines.append("**Explicit wait helpers:**")
        for h in c.explicit_wait_helpers:
            lines.append(f"- `{h}`")
        lines.append("")

    # Classes by role
    lines.append("## Classes by role")
    lines.append("")
    for role in (
        ClassRole.BASE, ClassRole.DRIVER_MANAGER, ClassRole.CONFIG,
        ClassRole.UTILITY, ClassRole.PAGE, ClassRole.LISTENER,
        ClassRole.TEST, ClassRole.ENUM, ClassRole.OTHER,
    ):
        in_role = pm.classes_with_role(role)
        if not in_role:
            continue
        lines.append(f"### {role.value.replace('_', ' ').title()} ({len(in_role)})")
        lines.append("")
        for c in in_role:
            line = f"- **`{c.name}`** ({c.package})"
            if c.role_summary:
                line += f" -- {c.role_summary}"
            lines.append(line)
        lines.append("")

    # Dependency graph highlights
    if pm.edges:
        lines.append("## Key dependencies")
        lines.append("")
        highlighted = [
            e for e in pm.edges
            if e.kind in {DependencyKind.EXTENDS, DependencyKind.IMPLEMENTS, DependencyKind.INSTANTIATES}
        ]
        if highlighted:
            lines.append("| Source | Kind | Target |")
            lines.append("|--------|------|--------|")
            for e in highlighted[:50]:
                src = _short_name(e.source)
                tgt = _short_name(e.target)
                lines.append(f"| `{src}` | `{e.kind.value}` | `{tgt}` |")
            lines.append("")

    # Warnings
    if pm.warnings:
        lines.append("## Warnings")
        lines.append("")
        for w in pm.warnings:
            lines.append(f"- {w}")
        lines.append("")

    return "\n".join(lines)


def write_markdown(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_markdown(pm), encoding="utf-8")
    return path


# =====================================================================
# HTML
# =====================================================================

# Role display config: (label, icon, accent-color-css-var)
_ROLE_META: dict[ClassRole, tuple[str, str]] = {
    ClassRole.BASE:           ("Base Classes",      "⬡"),
    ClassRole.DRIVER_MANAGER: ("Driver Manager",    "⬢"),
    ClassRole.CONFIG:         ("Config",            "⚙"),
    ClassRole.UTILITY:        ("Utilities",         "⚒"),
    ClassRole.PAGE:           ("Page Objects",      "⬜"),
    ClassRole.LISTENER:       ("Listeners",         "◎"),
    ClassRole.TEST:           ("Test Classes",      "✓"),
    ClassRole.ENUM:           ("Enums",             "≡"),
    ClassRole.OTHER:          ("Other",             "·"),
}

_ROLE_CSS_CLASS: dict[ClassRole, str] = {
    ClassRole.BASE:           "role-base",
    ClassRole.DRIVER_MANAGER: "role-driver",
    ClassRole.CONFIG:         "role-config",
    ClassRole.UTILITY:        "role-util",
    ClassRole.PAGE:           "role-page",
    ClassRole.LISTENER:       "role-listener",
    ClassRole.TEST:           "role-test",
    ClassRole.ENUM:           "role-enum",
    ClassRole.OTHER:          "role-other",
}

_EDGE_KIND_CSS: dict[DependencyKind, str] = {
    DependencyKind.EXTENDS:      "ek-extends",
    DependencyKind.IMPLEMENTS:   "ek-impl",
    DependencyKind.INSTANTIATES: "ek-inst",
    DependencyKind.STATIC_CALL:  "ek-call",
    DependencyKind.IMPORT:       "ek-import",
    DependencyKind.FIELD_TYPE:   "ek-field",
}


def render_html(pm: ProjectMap) -> str:
    c = pm.conventions
    i = pm.infrastructure

    def esc(x: object) -> str:
        return html.escape(str(x)) if x is not None else ""

    # ── Summary cards ──────────────────────────────────────────────────
    summary_cards = ""
    card_data = [
        ("Classes",         pm.file_count,              "ic-classes"),
        ("Edges",           pm.total_edges,             "ic-edges"),
        ("Page Objects",    len(pm.page_objects),       "ic-page"),
        ("Test Classes",    len(pm.test_classes),       "ic-test"),
        ("Utilities",       len(pm.utility_classes),    "ic-util"),
        ("Listeners",       len(pm.listeners),          "ic-listen"),
    ]
    for label, value, icon_cls in card_data:
        summary_cards += (
            f'<div class="stat-card">'
            f'<div class="stat-icon {icon_cls}"></div>'
            f'<div class="stat-body">'
            f'<div class="stat-value">{value}</div>'
            f'<div class="stat-label">{label}</div>'
            f'</div></div>'
        )

    # ── Infrastructure block ───────────────────────────────────────────
    infra_html = ""
    if i:
        rows = []
        rows.append(("Build tool", esc(i.build_tool), ""))
        tf = i.test_framework + (f" {i.test_framework_version}" if i.test_framework_version else "")
        rows.append(("Test framework", esc(tf), ""))
        if i.selenium_version:
            rows.append(("Selenium", esc(i.selenium_version), "badge-selenium"))
        if i.playwright_version:
            rows.append(("Playwright", esc(i.playwright_version), "badge-pw"))
        if i.logging_library:
            rows.append(("Logging", esc(i.logging_library), ""))
        if i.reporting_libraries:
            rows.append(("Reporting", esc(", ".join(i.reporting_libraries)), ""))
        if i.assertion_library:
            rows.append(("Assertion library", esc(i.assertion_library), ""))
        if i.env_profiles:
            rows.append(("Env profiles", esc(", ".join(i.env_profiles)), ""))
        if i.java_version:
            rows.append(("Java", esc(i.java_version), ""))
        if i.parallel_execution:
            rows.append(("Parallel execution", "enabled", "badge-parallel"))

        row_html = "".join(
            f'<tr><td class="kv-key">{label}</td>'
            f'<td><span class="kv-val{(" " + badge) if badge else ""}">{val}</span></td></tr>'
            for label, val, badge in rows
        )
        infra_html = (
            '<section class="section">'
            '<h2 class="section-title">Infrastructure</h2>'
            '<table class="kv-table"><tbody>' + row_html + '</tbody></table>'
            '</section>'
        )

    # ── Conventions ────────────────────────────────────────────────────
    def _bool_badge(v: bool) -> str:
        if v:
            return '<span class="bool-yes">✓ Yes</span>'
        return '<span class="bool-no">— No</span>'

    conv_rows = [
        ("Method chaining",        _bool_badge(c.method_chaining)),
        ("Logs every action",      _bool_badge(c.logs_every_action)),
        ("Logger pattern",         f"<code>{esc(c.logger_call_pattern or '—')}</code>"),
        ("Assertion style",        f"<code>{esc(c.assertion_style or '—')}</code>"),
        ("Driver access",          f"<code>{esc(c.driver_access or '—')}</code>"),
        ("Parallel-safe",          _bool_badge(c.parallel_safe)),
        ("Implicit waits",         _bool_badge(c.implicit_waits_used)),
        ("Password masking",       _bool_badge(c.password_masking)),
        ("Retry analyzer",         _bool_badge(c.uses_retry_analyzer)),
    ]
    if c.uses_listeners:
        conv_rows.append(("TestNG @Listeners", f"<code>{esc(', '.join(c.uses_listeners))}</code>"))
    if c.config_override_hierarchy:
        conv_rows.append(("Config lookup order", f"<code>{esc(' → '.join(c.config_override_hierarchy))}</code>"))
    conv_html = "".join(
        f'<tr><td class="kv-key">{label}</td><td>{val}</td></tr>'
        for label, val in conv_rows
    )

    # ── Classes by role ────────────────────────────────────────────────
    role_sections = ""
    for role in (
        ClassRole.BASE, ClassRole.DRIVER_MANAGER, ClassRole.CONFIG,
        ClassRole.UTILITY, ClassRole.PAGE, ClassRole.LISTENER,
        ClassRole.TEST, ClassRole.ENUM, ClassRole.OTHER,
    ):
        in_role = pm.classes_with_role(role)
        if not in_role:
            continue
        label, icon = _ROLE_META.get(role, (role.value, "·"))
        css = _ROLE_CSS_CLASS.get(role, "role-other")
        rows = "".join(
            f'<tr>'
            f'<td><span class="class-name">{esc(cl.name)}</span></td>'
            f'<td class="pkg-cell">{esc(cl.package)}</td>'
            f'<td class="summary-cell">{esc(cl.role_summary or "")}</td>'
            f'</tr>'
            for cl in in_role
        )
        role_sections += (
            f'<div class="role-group">'
            f'<div class="role-header {css}">'
            f'<span class="role-icon">{icon}</span>'
            f'<span class="role-label">{label}</span>'
            f'<span class="role-count">{len(in_role)}</span>'
            f'</div>'
            f'<table class="role-table">'
            f'<thead><tr><th>Class</th><th>Package</th><th>Summary</th></tr></thead>'
            f'<tbody>{rows}</tbody>'
            f'</table>'
            f'</div>'
        )

    # ── Dependency edges ───────────────────────────────────────────────
    deps_html = ""
    if pm.edges:
        highlighted = [
            e for e in pm.edges
            if e.kind in {
                DependencyKind.EXTENDS, DependencyKind.IMPLEMENTS,
                DependencyKind.INSTANTIATES,
            }
        ]
        if highlighted:
            edge_rows = "".join(
                f'<tr>'
                f'<td><span class="class-name">{esc(_short_name(e.source))}</span></td>'
                f'<td><span class="edge-kind {_EDGE_KIND_CSS.get(e.kind, "")}">{esc(e.kind.value)}</span></td>'
                f'<td><span class="class-name">{esc(_short_name(e.target))}</span></td>'
                f'</tr>'
                for e in highlighted[:100]
            )
            deps_html = (
                '<section class="section">'
                '<h2 class="section-title">Key Dependencies</h2>'
                '<table class="role-table">'
                '<thead><tr><th>From</th><th>Relationship</th><th>To</th></tr></thead>'
                f'<tbody>{edge_rows}</tbody>'
                '</table></section>'
            )

    # ── Warnings ───────────────────────────────────────────────────────
    warnings_html = ""
    if pm.warnings:
        items = "".join(f'<li>{esc(w)}</li>' for w in pm.warnings)
        warnings_html = (
            '<section class="section warnings-section">'
            '<h2 class="section-title">⚠ Warnings</h2>'
            f'<ul class="warn-list">{items}</ul>'
            '</section>'
        )

    body = f"""
<header class="page-header">
  <div class="header-inner">
    <div class="header-brand">
      <div class="brand-logo">QA<span>migrate</span></div>
      <div class="brand-tag">Architecture Report</div>
    </div>
    <div class="header-project">
      <div class="project-name">{esc(pm.project_name)}</div>
      <div class="project-path">{esc(pm.project_path)}</div>
    </div>
  </div>
</header>

<div class="page-body">

<section class="stat-grid">
{summary_cards}
</section>

{infra_html}

<section class="section">
  <h2 class="section-title">Project Conventions</h2>
  <table class="kv-table"><tbody>{conv_html}</tbody></table>
</section>

<section class="section">
  <h2 class="section-title">Classes by Role</h2>
  <div class="role-groups">{role_sections}</div>
</section>

{deps_html}

{warnings_html}

</div>

<footer class="page-footer">
  Generated by <strong>QAMigrate</strong> &middot;
  <a href="https://github.com/QATonic/QAMigrate">github.com/QATonic/QAMigrate</a>
</footer>
"""

    return _HTML_TEMPLATE.format(title=esc(pm.project_name), body=body)


def write_html(pm: ProjectMap, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_html(pm), encoding="utf-8")
    return path


# =====================================================================
# Helpers
# =====================================================================


def _yes_no(v: bool) -> str:
    return "YES" if v else "no"


def _short_name(fqn: str) -> str:
    return fqn.rsplit(".", 1)[-1]


_HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QAMigrate — {title}</title>
  <style>
    /* ── Reset & base ─────────────────────────────────────────────── */
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    html {{ font-size: 15px; }}
    body {{
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background: #0d1117;
      color: #c9d1d9;
      line-height: 1.6;
      min-height: 100vh;
    }}

    /* ── Header ───────────────────────────────────────────────────── */
    .page-header {{
      background: linear-gradient(135deg, #161b22 0%, #0d1117 100%);
      border-bottom: 1px solid #30363d;
      padding: 0;
    }}
    .header-inner {{
      max-width: 1180px;
      margin: 0 auto;
      padding: 1.5rem 2rem;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 2rem;
    }}
    .brand-logo {{
      font-size: 1.5rem;
      font-weight: 800;
      color: #f0f6fc;
      letter-spacing: -0.5px;
    }}
    .brand-logo span {{ color: #58a6ff; }}
    .brand-tag {{
      font-size: 0.72rem;
      color: #8b949e;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-top: 2px;
    }}
    .project-name {{
      font-size: 1.25rem;
      font-weight: 700;
      color: #f0f6fc;
      text-align: right;
    }}
    .project-path {{
      font-size: 0.8rem;
      color: #8b949e;
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      text-align: right;
      margin-top: 2px;
      word-break: break-all;
    }}

    /* ── Layout ───────────────────────────────────────────────────── */
    .page-body {{
      max-width: 1180px;
      margin: 0 auto;
      padding: 2rem;
    }}

    /* ── Stat grid ────────────────────────────────────────────────── */
    .stat-grid {{
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 1rem;
      margin-bottom: 2rem;
    }}
    .stat-card {{
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 1.25rem 1rem;
      display: flex;
      align-items: center;
      gap: 0.85rem;
      transition: border-color 0.15s, transform 0.15s;
    }}
    .stat-card:hover {{ border-color: #58a6ff; transform: translateY(-2px); }}
    .stat-icon {{
      width: 36px; height: 36px; border-radius: 8px; flex-shrink: 0;
      background: #21262d;
      display: flex; align-items: center; justify-content: center;
    }}
    /* colour accent per icon */
    .ic-classes {{ background: rgba(88, 166, 255, 0.15); }}
    .ic-edges   {{ background: rgba(139, 148, 158, 0.15); }}
    .ic-page    {{ background: rgba(63, 185, 80, 0.15); }}
    .ic-test    {{ background: rgba(210, 153, 34, 0.15); }}
    .ic-util    {{ background: rgba(188, 140, 255, 0.15); }}
    .ic-listen  {{ background: rgba(248, 81, 73, 0.15); }}
    .stat-value {{
      font-size: 1.75rem;
      font-weight: 700;
      color: #f0f6fc;
      line-height: 1;
    }}
    .stat-label {{
      font-size: 0.72rem;
      color: #8b949e;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      margin-top: 4px;
    }}

    /* ── Sections ─────────────────────────────────────────────────── */
    .section {{
      background: #161b22;
      border: 1px solid #30363d;
      border-radius: 10px;
      padding: 1.5rem;
      margin-bottom: 1.5rem;
    }}
    .section-title {{
      font-size: 0.85rem;
      font-weight: 700;
      color: #8b949e;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      margin-bottom: 1rem;
      padding-bottom: 0.6rem;
      border-bottom: 1px solid #30363d;
    }}

    /* ── KV table ─────────────────────────────────────────────────── */
    .kv-table {{
      width: 100%;
      border-collapse: collapse;
    }}
    .kv-table tr {{ border-bottom: 1px solid #21262d; }}
    .kv-table tr:last-child {{ border-bottom: none; }}
    .kv-table td {{ padding: 0.5rem 0.5rem; vertical-align: middle; }}
    .kv-key {{
      width: 38%;
      color: #8b949e;
      font-size: 0.85rem;
    }}
    .kv-val {{
      font-size: 0.88rem;
      color: #e6edf3;
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
    }}
    .badge-selenium {{ color: #f0883e; }}
    .badge-pw       {{ color: #3fb950; }}
    .badge-parallel {{ color: #58a6ff; }}

    /* ── Bool badges ──────────────────────────────────────────────── */
    .bool-yes {{
      display: inline-flex; align-items: center; gap: 4px;
      background: rgba(63, 185, 80, 0.12);
      color: #3fb950;
      font-size: 0.78rem; font-weight: 600;
      padding: 2px 8px; border-radius: 20px;
    }}
    .bool-no {{
      display: inline-flex; align-items: center; gap: 4px;
      background: rgba(139, 148, 158, 0.1);
      color: #8b949e;
      font-size: 0.78rem;
      padding: 2px 8px; border-radius: 20px;
    }}

    /* ── Role groups ──────────────────────────────────────────────── */
    .role-groups {{ display: flex; flex-direction: column; gap: 1rem; }}
    .role-group {{
      border: 1px solid #30363d;
      border-radius: 8px;
      overflow: hidden;
    }}
    .role-header {{
      display: flex;
      align-items: center;
      gap: 0.6rem;
      padding: 0.6rem 0.9rem;
      font-size: 0.8rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.07em;
      background: #21262d;
    }}
    .role-icon {{ font-size: 1rem; }}
    .role-label {{ flex: 1; }}
    .role-count {{
      background: rgba(139, 148, 158, 0.2);
      color: #8b949e;
      font-size: 0.72rem;
      padding: 1px 7px;
      border-radius: 10px;
      font-weight: 600;
    }}

    /* Role accent colors */
    .role-base     {{ border-left: 3px solid #58a6ff; color: #58a6ff; }}
    .role-driver   {{ border-left: 3px solid #3fb950; color: #3fb950; }}
    .role-config   {{ border-left: 3px solid #f0883e; color: #f0883e; }}
    .role-util     {{ border-left: 3px solid #bc8cff; color: #bc8cff; }}
    .role-page     {{ border-left: 3px solid #39d353; color: #39d353; }}
    .role-listener {{ border-left: 3px solid #f85149; color: #f85149; }}
    .role-test     {{ border-left: 3px solid #d2991a; color: #d2991a; }}
    .role-enum     {{ border-left: 3px solid #79c0ff; color: #79c0ff; }}
    .role-other    {{ border-left: 3px solid #484f58; color: #8b949e; }}

    /* ── Role / dep tables ────────────────────────────────────────── */
    .role-table {{
      width: 100%;
      border-collapse: collapse;
      font-size: 0.85rem;
    }}
    .role-table thead tr {{ background: #1c2128; }}
    .role-table th {{
      padding: 0.5rem 0.75rem;
      text-align: left;
      color: #8b949e;
      font-weight: 600;
      font-size: 0.78rem;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      border-bottom: 1px solid #30363d;
    }}
    .role-table td {{
      padding: 0.45rem 0.75rem;
      border-bottom: 1px solid #21262d;
      vertical-align: middle;
    }}
    .role-table tbody tr:last-child td {{ border-bottom: none; }}
    .role-table tbody tr:hover {{ background: #1c2128; }}
    .class-name {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      color: #79c0ff;
      font-weight: 600;
      font-size: 0.82rem;
    }}
    .pkg-cell {{
      color: #8b949e;
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.78rem;
    }}
    .summary-cell {{ color: #c9d1d9; font-size: 0.83rem; }}

    /* ── Edge kind pills ──────────────────────────────────────────── */
    .edge-kind {{
      display: inline-block;
      padding: 2px 8px;
      border-radius: 20px;
      font-size: 0.72rem;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
    }}
    .ek-extends  {{ background: rgba(88,166,255,0.15); color: #58a6ff; }}
    .ek-impl     {{ background: rgba(63,185,80,0.15);  color: #3fb950; }}
    .ek-inst     {{ background: rgba(188,140,255,0.15);color: #bc8cff; }}
    .ek-calls    {{ background: rgba(240,136,62,0.15); color: #f0883e; }}
    .ek-ref      {{ background: rgba(139,148,158,0.15);color: #8b949e; }}

    /* ── Warnings ─────────────────────────────────────────────────── */
    .warnings-section {{ border-color: rgba(248,81,73,0.35); }}
    .warn-list {{ list-style: none; display: flex; flex-direction: column; gap: 0.4rem; }}
    .warn-list li {{
      background: rgba(248,81,73,0.08);
      border-left: 3px solid #f85149;
      padding: 0.4rem 0.75rem;
      border-radius: 0 5px 5px 0;
      color: #ffa198;
      font-size: 0.85rem;
    }}

    /* ── Code inline ──────────────────────────────────────────────── */
    code {{
      font-family: "SF Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
      font-size: 0.85em;
      background: #21262d;
      padding: 0.1em 0.4em;
      border-radius: 4px;
      color: #e6edf3;
    }}

    /* ── Footer ───────────────────────────────────────────────────── */
    .page-footer {{
      text-align: center;
      color: #484f58;
      font-size: 0.8rem;
      padding: 2rem;
      border-top: 1px solid #21262d;
      margin-top: 2rem;
    }}
    .page-footer a {{ color: #58a6ff; text-decoration: none; }}
    .page-footer a:hover {{ text-decoration: underline; }}

    /* ── Responsive ───────────────────────────────────────────────── */
    @media (max-width: 960px) {{
      .stat-grid {{ grid-template-columns: repeat(3, 1fr); }}
    }}
    @media (max-width: 640px) {{
      .header-inner {{ flex-direction: column; align-items: flex-start; }}
      .project-name, .project-path {{ text-align: left; }}
      .stat-grid {{ grid-template-columns: repeat(2, 1fr); }}
      .page-body {{ padding: 1rem; }}
      .kv-key {{ width: 45%; }}
    }}
  </style>
</head>
<body>
{body}
</body>
</html>
"""
