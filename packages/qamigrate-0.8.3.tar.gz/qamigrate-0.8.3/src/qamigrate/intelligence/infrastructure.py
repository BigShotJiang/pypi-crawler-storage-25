"""
Detect libraries, versions, and runtime configuration from the project's
build file + resources.

Inputs:  project_path (Path)
Output:  Infrastructure dataclass (or None if no build file found)

Sources we read:
    - pom.xml (Maven)            -- <dependency>, <properties>, <parallel>
    - build.gradle[.kts]         -- implementation "group:artifact:version"
    - src/main/resources/*.xml   -- log4j2.xml presence, extent-config.xml
    - src/test/resources/testng.xml -- parallel= attribute
    - src/main/resources/config/ -- presence of multi-env properties files
"""

from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from qamigrate.intelligence.project_map import Infrastructure


# =====================================================================
# Public API
# =====================================================================


def detect_infrastructure(project_path: Path) -> Infrastructure | None:
    """Return an Infrastructure dataclass describing what this project uses.

    Returns None only when NEITHER pom.xml NOR build.gradle[.kts] exists.
    For unknown build tools we still return an Infrastructure with
    build_tool='unknown' so downstream code has a non-None value.
    """
    pom = project_path / "pom.xml"
    gradle = project_path / "build.gradle"
    gradle_kts = project_path / "build.gradle.kts"

    if pom.exists():
        infra = _from_pom(pom)
    elif gradle.exists():
        infra = _from_gradle(gradle, kts=False)
    elif gradle_kts.exists():
        infra = _from_gradle(gradle_kts, kts=True)
    else:
        return None

    # Enrich from resources regardless of build tool
    _enrich_from_resources(project_path, infra)
    _enrich_from_test_resources(project_path, infra)
    return infra


# =====================================================================
# Maven
# =====================================================================


def _from_pom(pom: Path) -> Infrastructure:
    infra = Infrastructure(build_tool="maven", build_file=str(pom))

    try:
        tree = ET.parse(pom)
        root = tree.getroot()
    except ET.ParseError:
        return infra

    ns = _detect_maven_ns(root)
    properties = _collect_maven_properties(root, ns)

    # Java source version: pom <maven.compiler.source>, otherwise None
    infra.java_version = properties.get("maven.compiler.source") or properties.get("java.version")

    # Iterate dependencies
    deps = _collect_maven_deps(root, ns, properties)
    for group, artifact, version in deps:
        _classify_dep(infra, group, artifact, version)

    return infra


def _detect_maven_ns(root: ET.Element) -> str:
    if root.tag.startswith("{"):
        return root.tag.split("}", 1)[0][1:]
    return ""


def _collect_maven_properties(root: ET.Element, ns: str) -> dict[str, str]:
    """Collect <properties><selenium.version>4.15</selenium.version>... into a dict."""
    props: dict[str, str] = {}
    prefix = f"{{{ns}}}" if ns else ""
    props_el = root.find(f"{prefix}properties")
    if props_el is None:
        return props
    for child in props_el:
        tag = child.tag
        if "}" in tag:
            tag = tag.split("}", 1)[1]
        props[tag] = (child.text or "").strip()
    return props


def _collect_maven_deps(
    root: ET.Element, ns: str, properties: dict[str, str],
) -> list[tuple[str, str, str | None]]:
    prefix = f"{{{ns}}}" if ns else ""
    deps = root.findall(f".//{prefix}dependency")
    # No-namespace fallback -- occasionally seen in hand-edited poms
    if not deps:
        deps = root.findall(".//dependency")

    result: list[tuple[str, str, str | None]] = []
    for dep in deps:
        # IMPORTANT: don't use `or` here. ElementTree Elements are falsy
        # when they have no child elements, so `dep.find("foo") or
        # dep.find("bar")` silently returns None for the common case of
        # a dep block with no nested elements. Use explicit None checks.
        g = dep.find(f"{prefix}groupId")
        if g is None:
            g = dep.find("groupId")
        a = dep.find(f"{prefix}artifactId")
        if a is None:
            a = dep.find("artifactId")
        v = dep.find(f"{prefix}version")
        if v is None:
            v = dep.find("version")

        if g is None or a is None:
            continue
        group = (g.text or "").strip()
        artifact = (a.text or "").strip()
        version_raw = (v.text or "").strip() if v is not None else ""

        # Resolve ${foo.version} placeholders from <properties>
        version: str | None = version_raw or None
        if version_raw.startswith("${") and version_raw.endswith("}"):
            key = version_raw[2:-1]
            version = properties.get(key, version_raw)

        result.append((group, artifact, version))
    return result


# =====================================================================
# Gradle (Groovy and .kts, same regex handles both)
# =====================================================================


# Matches common forms:
#   implementation "org.seleniumhq.selenium:selenium-java:4.15.0"
#   testImplementation 'org.testng:testng:7.8.0'
#   implementation("com.microsoft.playwright:playwright:1.48.0")
_GRADLE_DEP_RE = re.compile(
    r"""(?x)
    \b(?:api|implementation|compileOnly|runtimeOnly|
        testImplementation|testRuntimeOnly|testCompileOnly)
    \s*\(?                               # optional (
    \s*["']                              # opening quote
    ([A-Za-z0-9_.\-]+)                   # groupId
    :
    ([A-Za-z0-9_.\-]+)                   # artifactId
    (?::([A-Za-z0-9_.\-]+))?             # optional :version
    ["']                                 # closing quote
    """,
)


def _from_gradle(build_file: Path, *, kts: bool) -> Infrastructure:
    infra = Infrastructure(build_tool="gradle", build_file=str(build_file))

    try:
        text = build_file.read_text(encoding="utf-8")
    except OSError:
        return infra

    for match in _GRADLE_DEP_RE.finditer(text):
        group, artifact, version = match.group(1), match.group(2), match.group(3)
        _classify_dep(infra, group, artifact, version)

    # Java source version (sourceCompatibility = '17')
    java_match = re.search(
        r"""sourceCompatibility\s*=?\s*["']?([0-9.]+)["']?""", text
    )
    if java_match:
        infra.java_version = java_match.group(1)

    return infra


# =====================================================================
# Dep classifier (shared by Maven + Gradle)
# =====================================================================


def _classify_dep(
    infra: Infrastructure, group: str, artifact: str, version: str | None,
) -> None:
    """Route a (group, artifact, version) triple into the right Infrastructure field."""
    ga = f"{group}:{artifact}"

    # Selenium
    if group == "org.seleniumhq.selenium":
        if infra.selenium_version is None:
            infra.selenium_version = version
        return

    # Playwright
    if group == "com.microsoft.playwright":
        if infra.playwright_version is None:
            infra.playwright_version = version
        return

    # Test framework
    if ga == "org.testng:testng":
        infra.test_framework = "testng"
        infra.test_framework_version = version
        return
    if group == "org.junit.jupiter":
        infra.test_framework = "junit5"
        infra.test_framework_version = version
        return
    if group == "junit" and artifact == "junit":
        infra.test_framework = "junit4"
        infra.test_framework_version = version
        return

    # BDD framework (v0.5.15)
    if group == "io.cucumber":
        infra.bdd_framework = "cucumber"
        return

    # Logging
    if group == "org.apache.logging.log4j":
        infra.logging_library = "log4j2"
        infra.logging_library_version = version
        return
    if group == "org.slf4j":
        if infra.logging_library is None:
            infra.logging_library = "slf4j"
        return
    if group == "ch.qos.logback":
        infra.logging_library = "logback"
        return

    # Reporting
    if artifact.startswith("extentreports") or group.endswith("extentreports"):
        if "ExtentReports" not in infra.reporting_libraries:
            infra.reporting_libraries.append("ExtentReports")
        return
    if artifact.startswith("allure-"):
        if "Allure" not in infra.reporting_libraries:
            infra.reporting_libraries.append("Allure")
        return
    if artifact == "reportng":
        if "ReportNG" not in infra.reporting_libraries:
            infra.reporting_libraries.append("ReportNG")
        return

    # Assertion libraries
    if group == "org.assertj":
        infra.assertion_library = "assertj"
        return
    if group == "org.hamcrest":
        if infra.assertion_library is None:
            infra.assertion_library = "hamcrest"
        return


# =====================================================================
# Post-parse enrichment: look at resource files for clues the build
# file doesn't reveal.
# =====================================================================


def _enrich_from_resources(project_path: Path, infra: Infrastructure) -> None:
    res = project_path / "src" / "main" / "resources"
    if not res.exists():
        return

    # log4j2.xml overrides whatever the dep list suggested -- presence of
    # the config file is proof that log4j2 is the active logger.
    if (res / "log4j2.xml").exists():
        infra.logging_library = "log4j2"

    # ExtentReports config
    if (res / "extent-config.xml").exists():
        if "ExtentReports" not in infra.reporting_libraries:
            infra.reporting_libraries.append("ExtentReports")

    # Multi-env properties
    config_dir = res / "config"
    if config_dir.exists():
        envs: list[str] = []
        for f in config_dir.glob("*.properties"):
            stem = f.stem  # "dev", "qa", "prod"
            if stem and stem not in envs:
                envs.append(stem)
        infra.env_profiles = sorted(envs)
        if envs:
            infra.config_source = "properties"


def _enrich_from_test_resources(
    project_path: Path, infra: Infrastructure,
) -> None:
    test_res = project_path / "src" / "test" / "resources"
    if not test_res.exists():
        return

    # testng.xml: look for parallel=
    for candidate in ("testng.xml", "testng-regression.xml", "regression.xml"):
        path = test_res / candidate
        if path.exists():
            try:
                text = path.read_text(encoding="utf-8")
            except OSError:
                continue
            m = re.search(r"""parallel\s*=\s*["']([^"']+)["']""", text)
            if m and m.group(1) not in ("false", "none"):
                infra.parallel_execution = True
            break
