"""
ProjectAnalyzer: the single entry point that produces a ProjectMap.

Walks every .java file in the project, extracts structure via the existing
tree-sitter parser, infers each class's role, detects project-wide
conventions, builds the cross-class dependency graph, reads build-file
infrastructure -- and returns a fully populated ProjectMap ready to be
rendered (by the `analyze` CLI command) or consumed (by the Coder prompt).

Design goal: the analyzer is SIDE-EFFECT-FREE except for the optional
cache write at the end. Multiple calls on the same project produce
equivalent output.
"""

from __future__ import annotations

from pathlib import Path
from typing import Iterable

import structlog

from qamigrate.core.parser import JavaParser, get_parser
from qamigrate.intelligence.convention_detector import detect_conventions
from qamigrate.intelligence.dependency_graph import build_edges
from qamigrate.intelligence.infrastructure import detect_infrastructure
from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRef,
    ClassRole,
    FieldInfo,
    MethodInfo,
    ParameterInfo,
    ProjectMap,
)
from qamigrate.intelligence.role_inference import infer_role

logger = structlog.get_logger(__name__)


# =====================================================================
# Walk settings
# =====================================================================

# Directories we NEVER want to scan -- build output, generated Playwright
# output, dependency caches.
_EXCLUDE_PARTS = {
    "target", "build", "node_modules", "playwright", "qamigrate-output",
    ".git", ".venv", ".idea", ".qamigrate",
}


# =====================================================================
# Public API
# =====================================================================


class ProjectAnalyzer:
    """Build a ProjectMap from a filesystem path.

    Usage:
        pm = ProjectAnalyzer().build(Path("./my-selenium-project"))
    """

    def __init__(self, parser: JavaParser | None = None) -> None:
        self.parser = parser or get_parser()

    def build(self, project_path: Path) -> ProjectMap:
        project_path = project_path.resolve()
        project_map = ProjectMap(
            project_path=str(project_path),
            project_name=project_path.name,
        )

        # --- Phase 1: parse every .java file ---
        for java_file in self._discover_java_files(project_path):
            try:
                ci = self._parse_file(java_file)
            except Exception as e:  # pragma: no cover - defensive
                project_map.warnings.append(f"Could not parse {java_file}: {e}")
                continue
            if ci is None:
                continue
            project_map.classes[ci.fqn] = ci
            project_map.packages.setdefault(ci.package, []).append(ci.fqn)

        # --- Phase 2: role inference ---
        for ci in project_map.classes.values():
            ci.role = infer_role(ci)
            ci.role_summary = _summarize_role(ci)

        # --- Phase 3: pivot by role ---
        for ci in project_map.classes.values():
            ref = ci.to_ref()
            if ci.role == ClassRole.BASE:
                project_map.base_classes.append(ref)
            elif ci.role == ClassRole.UTILITY:
                project_map.utility_classes.append(ref)
            elif ci.role == ClassRole.PAGE:
                project_map.page_objects.append(ref)
            elif ci.role == ClassRole.TEST:
                project_map.test_classes.append(ref)
            elif ci.role == ClassRole.LISTENER:
                project_map.listeners.append(ref)
            elif ci.role == ClassRole.DRIVER_MANAGER and project_map.driver_manager is None:
                project_map.driver_manager = ref
            elif ci.role == ClassRole.CONFIG and project_map.config_reader is None:
                project_map.config_reader = ref

        # --- Phase 4: cross-class edges ---
        project_map.edges = build_edges(project_map.classes)

        # --- Phase 5: conventions ---
        project_map.conventions = detect_conventions(project_map.classes)

        # --- Phase 6: infrastructure ---
        project_map.infrastructure = detect_infrastructure(project_path)

        logger.info(
            "ProjectMap built",
            classes=len(project_map.classes),
            pages=len(project_map.page_objects),
            tests=len(project_map.test_classes),
            utilities=len(project_map.utility_classes),
            edges=len(project_map.edges),
        )
        return project_map

    # --- Internal ---

    def _discover_java_files(self, project_path: Path) -> Iterable[Path]:
        """Yield every .java file in the project, skipping excluded dirs."""
        for path in project_path.rglob("*.java"):
            if any(part in _EXCLUDE_PARTS for part in path.parts):
                continue
            yield path

    def _parse_file(self, file_path: Path) -> ClassInfo | None:
        """Parse one .java file into a ClassInfo. Returns None for files
        without a parseable class_declaration (rare, e.g. only package-info).
        """
        raw = self.parser.extract_class_info(file_path)
        class_name = raw.get("class_name")
        if not class_name:
            return None

        package = raw.get("package") or ""
        fqn = f"{package}.{class_name}" if package else class_name

        public_methods: list[MethodInfo] = []
        private_methods: list[MethodInfo] = []
        for m in raw.get("methods", []):
            method = _method_from_raw(m)
            if "private" in method.modifiers:
                private_methods.append(method)
            else:
                public_methods.append(method)

        fields = [
            FieldInfo(
                name=f.get("name") or "",
                type=f.get("type") or "",
                modifiers=list(f.get("modifiers", [])),
                annotations=list(f.get("annotations", [])),
                line=f.get("line", 0),
            )
            for f in raw.get("fields", [])
            if f.get("name")
        ]

        # Class-level annotations go into `modifiers` so the convention
        # detector can read them via `_class_level_annotations`.
        class_annotations = list(raw.get("annotations", []))
        class_modifiers = list(raw.get("modifiers", [])) + class_annotations

        return ClassInfo(
            name=class_name,
            fqn=fqn,
            file_path=str(file_path),
            package=package,
            extends=raw.get("extends"),
            implements=list(raw.get("implements", [])),
            modifiers=class_modifiers,
            imports=list(raw.get("imports", [])),
            public_methods=public_methods,
            private_methods=private_methods,
            fields=fields,
        )


# =====================================================================
# Helpers
# =====================================================================


def _method_from_raw(m: dict) -> MethodInfo:
    params = [
        ParameterInfo(
            name=p.get("name", ""),
            type=p.get("type", ""),
            varargs=str(p.get("varargs", "")).lower() == "true",
        )
        for p in m.get("parameters", [])
    ]
    # v0.6.0: constructors emit return_type="" (empty string, not None) —
    # preserve the empty string verbatim so MethodInfo.is_constructor works.
    # For real methods, `None` / missing means we couldn't parse it; default
    # to "void" in that case.
    raw_rt = m.get("return_type")
    return_type = raw_rt if raw_rt is not None else "void"
    return MethodInfo(
        name=m.get("name") or "",
        modifiers=list(m.get("modifiers", [])),
        return_type=return_type,
        parameters=params,
        annotations=list(m.get("annotations", [])),
        body=m.get("body"),
        line=m.get("start_line", 0),
        throws=list(m.get("throws", [])),
    )


def _summarize_role(ci: ClassInfo) -> str:
    """One-line human-readable summary of a class's role. Used in the
    architecture report AND the Coder prompt to explain sibling classes.
    """
    method_count = len(ci.public_methods)
    if ci.role == ClassRole.BASE:
        return f"Abstract base class for subclasses; exposes {method_count} helper methods."
    if ci.role == ClassRole.UTILITY:
        static_methods = [m.name for m in ci.public_methods if "static" in m.modifiers]
        sample = ", ".join(static_methods[:4])
        more = "..." if len(static_methods) > 4 else ""
        return f"Utility class (static helpers): {sample}{more}"
    if ci.role == ClassRole.PAGE:
        return f"Page Object with {method_count} public action methods."
    if ci.role == ClassRole.TEST:
        tests = [m.name for m in ci.public_methods if _has_test_annotation(m.annotations)]
        return f"Test class with {len(tests)} @Test method(s)."
    if ci.role == ClassRole.LISTENER:
        return f"TestNG/JUnit listener implementing {', '.join(ci.implements) or '(unknown hooks)'}."
    if ci.role == ClassRole.DRIVER_MANAGER:
        return "WebDriver lifecycle manager (created/destroys browser sessions)."
    if ci.role == ClassRole.CONFIG:
        return "Configuration / properties loader."
    if ci.role == ClassRole.ENUM:
        return "Enum."
    return ""


def _has_test_annotation(annotations: list[str]) -> bool:
    for a in annotations:
        head = a.split("(", 1)[0].strip()
        if head in {"@Test", "@TestTemplate", "@ParameterizedTest"}:
            return True
    return False
