"""
Format a ProjectMap as a compact "project context" section for LLM prompts.

The Coder's job is to produce migrated code that matches the project's
conventions. To do that it needs to see:

- what kind of project this is (Maven/Gradle, testng/junit, parallel-safe)
- which classes exist and what each one's role is
- the project conventions (method chaining, log-every-action, etc.) so
  generated code integrates with existing infrastructure
- for the specific file being migrated: which sibling classes it actually
  depends on, and their FULL method bodies (Q3 "deep" -- we show enough
  that the Coder knows what `Log.action()` or `WaitUtils.waitForClickability()`
  actually do and can preserve their semantics)

Keep the fragment compact enough to ship as a system-prompt addendum:
~3-5x the current prompt size is the budget we agreed to (Q3 decision).
"""

from __future__ import annotations

from collections import defaultdict

from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    DependencyKind,
    ProjectMap,
)


# =====================================================================
# Public API
# =====================================================================


def format_project_context(
    pm: ProjectMap,
    *,
    migrating_fqn: str | None = None,
    max_sibling_classes: int = 8,
    max_body_chars_per_method: int = 600,
) -> str:
    """Return a project-context block ready to embed in an LLM prompt.

    Args:
        pm: the ProjectMap built by ProjectAnalyzer.
        migrating_fqn: FQN of the class currently being migrated. When
            provided, we zoom in on its direct dependencies; otherwise we
            emit a project-wide overview.
        max_sibling_classes: cap the "sibling deep dive" at N classes so
            the prompt doesn't explode on large projects.
        max_body_chars_per_method: truncate utility method bodies that
            are huge (defensive).

    Returns an empty string when `pm` is empty / trivial.
    """
    if not pm.classes:
        return ""

    sections: list[str] = []
    sections.append(_section_project_overview(pm))
    sections.append(_section_conventions(pm))
    sections.append(_section_infrastructure(pm))

    if migrating_fqn:
        dep_section = _section_focused_dependencies(
            pm,
            migrating_fqn,
            max_sibling_classes=max_sibling_classes,
            max_body_chars_per_method=max_body_chars_per_method,
        )
        if dep_section:
            sections.append(dep_section)
    else:
        sections.append(_section_class_inventory(pm))

    # Drop empty sections
    return "\n\n".join(s for s in sections if s.strip())


# =====================================================================
# Sections
# =====================================================================


def _section_project_overview(pm: ProjectMap) -> str:
    i = pm.infrastructure
    lines = [
        "## Project overview",
        "",
        f"- Project: `{pm.project_name}` ({pm.file_count} classes, {pm.total_edges} edges)",
    ]
    if i:
        lines.append(
            f"- Stack: {i.build_tool} / {i.test_framework}"
            + (f" {i.test_framework_version}" if i.test_framework_version else "")
            + (f" / Selenium {i.selenium_version}" if i.selenium_version else "")
            + (f" / Java {i.java_version}" if i.java_version else "")
        )
        if i.logging_library:
            lines.append(f"- Logging: {i.logging_library}")
        if i.reporting_libraries:
            lines.append(f"- Reporting: {', '.join(i.reporting_libraries)}")
        if i.env_profiles:
            lines.append(f"- Env profiles: {', '.join(i.env_profiles)}")
        if i.parallel_execution:
            lines.append("- Parallel execution: ENABLED")
    return "\n".join(lines)


def _section_conventions(pm: ProjectMap) -> str:
    c = pm.conventions
    lines = ["## Project conventions (PRESERVE THESE IN MIGRATED CODE)", ""]

    if c.method_chaining:
        lines.append(
            "- **Method chaining**: Page object methods return `this` for fluent API. "
            "Migrated Playwright methods MUST also return `this` (e.g. "
            "`public LoginPage enterUsername(String u) { ... return this; }`)."
        )

    if c.logs_every_action:
        pattern = c.logger_call_pattern or "Log"
        lines.append(
            f"- **Log every action**: Base class action methods (click, type, etc.) "
            f"call `{pattern}(...)` BEFORE acting. Preserve this -- migrated code "
            f"should log via `{pattern}` first, then perform the Playwright action."
        )

    if c.driver_access == "ThreadLocal":
        lines.append(
            "- **Parallel-safe driver**: The project uses `ThreadLocal<WebDriver>` "
            "in DriverManager for test parallelism. The Playwright equivalent uses "
            "`ThreadLocal<Page>` or `ThreadLocal<BrowserContext>` -- preserve the "
            "per-thread isolation pattern."
        )

    if c.assertion_style:
        if c.assertion_style == "testng":
            lines.append(
                "- **Assertions**: project uses TestNG `org.testng.Assert`. "
                "Migrate to Playwright's `assertThat(...)` from "
                "`com.microsoft.playwright.assertions.PlaywrightAssertions` for "
                "UI state, keep `org.testng.Assert.assertEquals(...)` for plain values."
            )
        elif c.assertion_style == "junit5":
            lines.append(
                "- **Assertions**: project uses JUnit 5 `Assertions`. "
                "Migrate UI state to Playwright `assertThat(...)`, keep "
                "`org.junit.jupiter.api.Assertions` for plain values."
            )

    if c.uses_retry_analyzer:
        lines.append(
            "- **Retry analyzer**: project uses TestNG `IRetryAnalyzer`. "
            "Preserve `@Test(retryAnalyzer = RetryAnalyzer.class)` on test methods "
            "exactly as-is."
        )

    if c.uses_listeners:
        listeners = ", ".join(c.uses_listeners)
        lines.append(
            f"- **@Listeners**: The project wires up `@Listeners({listeners})` on base "
            f"test classes. Preserve this annotation -- the listener owns ExtentReports "
            f"lifecycle and failure screenshots."
        )

    if c.config_override_hierarchy:
        hierarchy = " -> ".join(c.config_override_hierarchy)
        lines.append(
            f"- **Config lookup order**: `{hierarchy}`. Preserve this precedence "
            f"(checking System.getProperty first lets CI override env at runtime)."
        )

    if c.explicit_wait_helpers:
        lines.append(
            "- **Explicit waits via utility helpers**: the project has "
            f"{', '.join(c.explicit_wait_helpers[:4])}{'...' if len(c.explicit_wait_helpers) > 4 else ''}. "
            "In Playwright these translate to auto-waiting locator actions -- "
            "the helper methods themselves can be inlined or removed, but don't "
            "silently drop the intent (visibility check, clickability, etc.)."
        )

    if c.implicit_waits_used:
        lines.append(
            "- **Implicit waits**: project calls `driver.manage().timeouts().implicitlyWait`. "
            "Playwright has built-in auto-waiting per action -- REMOVE implicit waits, "
            "don't carry them over."
        )

    if len(lines) == 2:  # Nothing detected beyond the header
        return ""
    return "\n".join(lines)


def _section_infrastructure(pm: ProjectMap) -> str:
    """Only emit when the infrastructure has something noteworthy to tell
    the Coder (e.g. ExtentReports which impacts logging output)."""
    if not pm.infrastructure or not pm.infrastructure.reporting_libraries:
        return ""
    reports = ", ".join(pm.infrastructure.reporting_libraries)
    return (
        "## Reporting infrastructure\n"
        f"\n"
        f"This project uses {reports}. Logging / step tracking calls feed into "
        f"the report. Don't silently drop `Log.step(...)`, `Log.action(...)`, "
        f"or `ExtentTest.log(...)` calls -- they are the project's test-execution "
        f"evidence trail."
    )


def _section_class_inventory(pm: ProjectMap) -> str:
    """Project-wide class list, grouped by role. Used when no specific
    file is being migrated (e.g. first pass or dry run)."""
    sections: list[str] = ["## Classes in this project"]

    for role, label in (
        (ClassRole.BASE, "Base classes"),
        (ClassRole.DRIVER_MANAGER, "Driver manager"),
        (ClassRole.CONFIG, "Config readers"),
        (ClassRole.UTILITY, "Utility classes"),
        (ClassRole.PAGE, "Page objects"),
        (ClassRole.LISTENER, "Listeners"),
        (ClassRole.TEST, "Test classes"),
    ):
        in_role = pm.classes_with_role(role)
        if not in_role:
            continue
        sections.append(f"\n### {label}")
        for c in in_role:
            sections.append(f"- `{c.fqn}` -- {c.role_summary}")

    return "\n".join(sections)


def _inherited_fields_callout(
    pm: ProjectMap,
    migrating_fqn: str,
    deps: list,
) -> str:
    """If this class extends a base class with `ThreadLocal` / static
    infrastructure fields, surface them so the Coder uses the existing
    fields instead of leaving call sites referring to undeclared symbols.

    Targets the v0.5.18 production bug: `DriverManager.java` migration
    produced 12 `cannot find symbol` errors because `context.get()` /
    `browser.get()` were called without the `ThreadLocal<...>` field
    declarations being preserved. The fields existed in the original
    class and on the parent; they just dropped out of the generated code.
    """
    parent_fqn: str | None = None
    for edge in deps:
        if edge.kind == DependencyKind.EXTENDS:
            parent_fqn = edge.target
            break
    if not parent_fqn:
        return ""

    parent = pm.lookup(parent_fqn)
    if parent is None or not parent.fields:
        return ""

    # Static infrastructure fields are the load-bearing ones — ThreadLocals,
    # singletons, shared loggers. Filter to keep the prompt focused.
    INFRA_TYPE_HINTS = (
        "ThreadLocal",
        "Logger",
        "AtomicReference",
        "AtomicInteger",
        "ConcurrentHashMap",
    )
    infra_fields = [
        f for f in parent.fields
        if any(hint in f.type for hint in INFRA_TYPE_HINTS)
        or "static" in f.modifiers
    ]
    if not infra_fields:
        return ""

    header = (
        f"**Inherited fields from `{parent.name}` -- DO NOT redeclare; "
        f"reference by name:**"
    )
    bullets = []
    for f in infra_fields[:8]:
        mods = " ".join(f.modifiers)
        bullets.append(f"- `{mods} {f.type} {f.name}`")
    return "\n".join([header, ""] + bullets)


def _inherited_helpers_callout(
    pm: ProjectMap,
    migrating_fqn: str,
    deps: list,
) -> str:
    """
    If this class extends a base class, list any inherited helpers that
    return infrastructure types (Page/Driver/Browser/Context) so the Coder
    knows to call them instead of reaching into DriverManager statically.

    This targets the concrete v0.5.0 bug: Coder used `DriverManager.getPage()`
    inside tests that extended a BaseTest already exposing `getPage()`.
    """
    # Find the parent (EXTENDS) class, if any.
    parent_fqn: str | None = None
    for edge in deps:
        if edge.kind == DependencyKind.EXTENDS:
            parent_fqn = edge.target
            break
    if not parent_fqn:
        return ""

    parent = pm.lookup(parent_fqn)
    if parent is None or not parent.public_methods:
        return ""

    # Infrastructure-returning accessors the subclass should prefer.
    _INFRA_TYPES = {
        "Page", "WebDriver", "Browser", "BrowserContext",
        "Playwright", "ChromeDriver", "FirefoxDriver",
    }
    helpers = [
        m for m in parent.public_methods
        if m.return_type in _INFRA_TYPES
        and not m.parameters
        and "private" not in m.modifiers
    ]
    if not helpers:
        return ""

    header = (
        f"**Inherited from `{parent.name}` -- PREFER these over static "
        f"`DriverManager.*` access:**"
    )
    bullets = [
        f"- `{m.signature}` -- call as `{m.name}()` (inherited from {parent.name})"
        for m in helpers
    ]
    tail = (
        f"Inside this class, write `{helpers[0].name}().locator(...)` NOT "
        f"`DriverManager.{helpers[0].name}().locator(...)`. The base class "
        "owns lifecycle; bypassing it breaks per-test isolation."
    )
    return "\n".join([header, ""] + bullets + ["", tail])


def _section_focused_dependencies(
    pm: ProjectMap,
    migrating_fqn: str,
    *,
    max_sibling_classes: int,
    max_body_chars_per_method: int,
) -> str:
    """The "deep" version (Q3 choice): for each class `migrating_fqn`
    depends on, show its role, public API, AND method bodies the Coder
    will likely need to understand.
    """
    deps = pm.dependencies_of(migrating_fqn)
    if not deps:
        return ""

    # Collect unique target classes in dependency-edge order so the most
    # architecturally significant (EXTENDS first) come first.
    ordered_kinds = [
        DependencyKind.EXTENDS,
        DependencyKind.IMPLEMENTS,
        DependencyKind.INSTANTIATES,
        DependencyKind.STATIC_CALL,
        DependencyKind.FIELD_TYPE,
        DependencyKind.IMPORT,
    ]
    ordered_targets: list[str] = []
    seen: set[str] = set()
    for kind in ordered_kinds:
        for edge in deps:
            if edge.kind == kind and edge.target not in seen:
                seen.add(edge.target)
                ordered_targets.append(edge.target)
                if len(ordered_targets) >= max_sibling_classes:
                    break
        if len(ordered_targets) >= max_sibling_classes:
            break

    if not ordered_targets:
        return ""

    # v0.5.1: surface the parent class's helpers explicitly so the Coder
    # uses them instead of reaching into DriverManager / static factories.
    inherited_callout = _inherited_helpers_callout(pm, migrating_fqn, deps)
    # v0.6.0: surface inherited ThreadLocal / static infra fields so the
    # generated subclass keeps referencing them by name and no `cannot find
    # symbol` errors slip through after migration.
    inherited_fields = _inherited_fields_callout(pm, migrating_fqn, deps)

    lines = [
        "## Sibling classes this file depends on",
        "",
        "These classes already exist in the project (or will be migrated in the "
        "same run). Use their REAL APIs; do NOT invent methods, do NOT invent "
        "constructor or method overloads -- if a method takes one argument here, "
        "you cannot call it with two. For utility classes, preserve the call "
        "patterns exactly -- they are load-bearing for the project's logging/"
        "reporting infrastructure.",
        "",
    ]
    if inherited_callout:
        lines.append(inherited_callout)
        lines.append("")
    if inherited_fields:
        lines.append(inherited_fields)
        lines.append("")

    for fqn in ordered_targets:
        ci = pm.lookup(fqn)
        if ci is None:
            continue
        lines.append(f"### `{ci.name}` -- {ci.role.value}")
        if ci.role_summary:
            lines.append(f"_{ci.role_summary}_")
        lines.append("")

        public = [m for m in ci.public_methods if "private" not in m.modifiers]
        constructors = [m for m in public if m.is_constructor]
        regular = [m for m in public if not m.is_constructor]

        # v0.6.0: constructors first, with explicit "available overloads"
        # framing so the Coder can't invent new ones.
        if constructors:
            lines.append("**Available constructors (do NOT invent additional overloads):**")
            for m in constructors:
                lines.append(f"- `{m.signature}`")
            lines.append("")

        # v0.6.0: group regular methods by name so overload sets are
        # immediately visible. Without this, the LLM sees a flat list and
        # invents overloads that don't exist (the v0.5.18 LogUtils.error
        # bug — caller wrote `LogUtils.error(String, Exception)` against a
        # 1-arg method).
        by_name: defaultdict[str, list] = defaultdict(list)
        for m in regular:
            by_name[m.name].append(m)
        overload_groups = [
            (name, ms) for name, ms in by_name.items() if len(ms) > 1
        ]

        if overload_groups:
            lines.append("**Method overload sets (these are the ONLY overloads — do not invent more):**")
            for name, ms in overload_groups:
                for m in ms:
                    lines.append(f"- `{m.signature}`")
            lines.append("")

        if ci.role in (ClassRole.UTILITY, ClassRole.BASE):
            # For utilities + base classes we show BODIES so the Coder
            # understands what each helper does -- this is the "deep"
            # context that was the point of the intelligence layer.
            shown_names: set[str] = set()
            for m in regular[:10]:
                # Avoid re-printing methods already listed under overloads.
                if m.name in {n for n, _ in overload_groups} and m.name in shown_names:
                    continue
                shown_names.add(m.name)
                sig = m.signature
                body = (m.body or "").strip()
                if len(body) > max_body_chars_per_method:
                    body = body[:max_body_chars_per_method] + "\n  // ... (truncated)\n}"
                lines.append(f"```java")
                lines.append(f"// {ci.name}.{m.name}")
                lines.append(f"{sig} {body}")
                lines.append("```")
                lines.append("")
        else:
            # For pages / driver managers / configs we show signatures only;
            # the Coder can infer what `clickLogin()` does from its name.
            for m in regular[:15]:
                lines.append(f"- `{m.signature}`")
            lines.append("")

    return "\n".join(lines)
