"""
Detect files that should pass through migration untouched.

Some Java source files are pure data/config with zero Selenium-specific
syntax -- enums, interfaces, DTOs, constants classes. Running the LLM
on them is a waste: it hallucinates output that breaks code that was
already correct.

In v0.5.0 we observed this with `Environment.java`:
    - Original: standard enum with 4 constants and a fromString helper
    - Claude:   replaced `,` separators with `;`
    - GPT-4o:   dropped the constants entirely

Both failures traced back to the `generate_playwright_code` tool schema
not fitting enum syntax. The fix is not to prompt harder -- it's to
recognize these files and copy them through.
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# Regex-based detectors. Cheap, run before any LLM call.
#
# These are intentionally loose: a false POSITIVE (we treat something as
# passthrough when it could benefit from migration) is bad, so the rules
# only fire when we're certain there's nothing Selenium-related.

_ENUM_RE = re.compile(r"^\s*(?:public\s+|private\s+|protected\s+)?enum\s+\w+", re.MULTILINE)

# Java annotation interface declarations (@interface).
# These are custom annotation types — they have no Selenium content and the
# LLM can't generate them safely (it inserts prose like "N/A - ...").
_ANNOTATION_INTERFACE_RE = re.compile(
    r"^\s*(?:public\s+)?@interface\s+\w+",
    re.MULTILINE,
)

# Non-Selenium infrastructure imports that indicate the file is not UI automation.
# Files that ONLY use these libraries should be passthroughed — migrating them
# would be wrong and produce broken output (the production project showed this
# with javax.mail, AWT Robot, and screen recording classes).
_INFRA_ONLY_MARKERS = (
    "javax.mail",           # Email sending — not UI automation
    "java.awt.Robot",       # AWT Robot — OS-level keyboard/mouse, not Selenium
    "org.monte.media",      # Monte Media screen recording library
    "com.xuggle",           # Xuggle video library
    "org.aeonbits.owner",   # Owner config library (@Config interfaces)
)

# Lombok @Config interfaces — these are configuration interfaces, not test code.
_LOMBOK_OWNER_RE = re.compile(r"@Config\s*\(", re.MULTILINE)

# A "constants class" has only static final fields and possibly a private
# constructor. No instance methods, no instance fields. Such files are pure
# data — passthrough is correct.
_INSTANCE_METHOD_RE = re.compile(
    r"^\s*(?:public|protected)\s+(?!static\b)(?!final\s+static)[\w<>\[\]]+\s+\w+\s*\([^)]*\)\s*\{",
    re.MULTILINE,
)
# Detect "looks like a constants class": has at least one `public static final`
# AND has no public/protected instance methods.
_STATIC_FINAL_RE = re.compile(
    r"^\s*public\s+static\s+final\s+",
    re.MULTILINE,
)

# Matches the package declaration line so we can rewrite it.
_PACKAGE_DECL_RE = re.compile(r"^(\s*package\s+)([\w.]+)(\s*;)", re.MULTILINE)

# A file is "Selenium-free" when none of these appear IN CODE (not comments).
# Note: "Selenium" is checked against comment-stripped source to avoid false
# positives from header comments like "Automation Framework Selenium - Author".
_SELENIUM_MARKERS = (
    "org.openqa.selenium",
    "org.openqa.support",
    "org.openqa.selenium.support",
    "WebDriver",
    "WebElement",
    "@FindBy",
    "@FindBys",
    "@FindAll",
    "PageFactory",
    "org.testng",          # test class -- always migrate
    "org.junit",           # test class -- always migrate
)

# Markers checked only in comment-stripped source to avoid false positives.
_SELENIUM_COMMENT_SENSITIVE = (
    "Selenium",            # "Automation Framework Selenium" in file headers
)

# Strip single-line and block comments for accurate marker detection.
_COMMENT_STRIP_RE = re.compile(
    r"//[^\n]*|/\*.*?\*/",
    re.DOTALL,
)


def _has_selenium_content(src: str) -> bool:
    """True if the source contains Selenium API references (not just in comments).

    v0.5.16: Headers like "// Automation Framework Selenium - Author Name"
    must NOT block passthrough. We strip comments before the bare-word check
    for Selenium-name false positives, while keeping the import/API checks
    against the raw source (since those are unambiguous tokens).
    """
    if any(marker in src for marker in _SELENIUM_MARKERS):
        return True
    # For ambiguous bare-word markers, strip comments first.
    code_only = _COMMENT_STRIP_RE.sub("", src)
    return any(marker in code_only for marker in _SELENIUM_COMMENT_SENSITIVE)


def is_passthrough(file_path: Path) -> tuple[bool, str | None]:
    """
    Return (should_passthrough, reason).

    `reason` is a short human-readable string for logging when we skip.
    None when not a passthrough candidate.
    """
    try:
        src = file_path.read_text(encoding="utf-8")
    except OSError:
        return False, None

    # Cucumber runner class: @Suite + @IncludeEngines("cucumber").
    # Checked BEFORE the Selenium markers exclusion because the runner
    # imports org.junit.platform.suite (which contains "org.junit") and
    # would otherwise be blocked. The runner has zero Selenium code — its
    # structure must remain EXACTLY as-is for Cucumber to discover tests.
    if "@Suite" in src and "@IncludeEngines" in src and "junit.platform.suite" in src:
        return True, "cucumber-runner (no Selenium; copying verbatim)"

    # v0.5.16: Infrastructure-only files — copy verbatim when no Selenium.
    # Files using javax.mail, AWT Robot, screen recording libs etc. don't
    # need WebDriver → Page migration. The LLM produces broken output for
    # these (confirmed in the production 85-file run). Check BEFORE the
    # Selenium markers exclusion so they aren't blocked by coincidental imports.
    if any(marker in src for marker in _INFRA_ONLY_MARKERS):
        if not _has_selenium_content(src):
            return True, "infrastructure-only (no Selenium; copying verbatim)"

    # v0.5.16: Owner @Config interfaces (Lombok config).
    # These are configuration interfaces generated by aOwner — copy verbatim.
    if _LOMBOK_OWNER_RE.search(src) and not _has_selenium_content(src):
        return True, "@Config interface (no Selenium; copying verbatim)"

    # Never passthrough anything that mentions Selenium / WebDriver / test
    # framework annotations -- those need migration by definition.
    # v0.5.16: comment-stripped check so headers like "Framework Selenium" pass.
    if _has_selenium_content(src):
        return False, None

    # v0.5.16: Java annotation interfaces (@interface Foo {}).
    # The LLM cannot generate @interface syntax safely — it inserts prose
    # comments instead of valid Java. Copy verbatim.
    if _ANNOTATION_INTERFACE_RE.search(src):
        return True, "@interface annotation type (no Selenium; copying verbatim)"

    # Enum: top-level `public enum Foo { ... }`. Even with no Selenium
    # content, enums deserve verbatim copy because the tool schema can't
    # represent them safely.
    if _ENUM_RE.search(src):
        return True, "enum (no Selenium markers; copying verbatim)"

    # v0.5.16: Constants-only class — has static final fields, no instance
    # methods, no Selenium content. EmailConfig-style classes that hold
    # SMTP host/port/credentials, REPORT_TITLE etc.
    if _STATIC_FINAL_RE.search(src) and not _INSTANCE_METHOD_RE.search(src):
        return True, "constants class (no Selenium; copying verbatim)"

    return False, None


def rewrite_package_for_passthrough(source: str) -> str:
    """Rewrite the package declaration to append `.playwright`.

    v0.5.4: passthrough files (enums, DTOs) are copied verbatim except for
    their package declaration. Without this rewrite they declare the same
    package as the original Selenium class and Maven sees two classes with
    identical FQNs, producing duplicate-symbol errors.

    `package com.example.config;`
    →  `package com.example.config.playwright;`

    If the source has no package declaration (default package), it is
    returned unchanged -- no `.playwright` prefix makes sense there.
    If the package already ends with `.playwright`, it is not doubled.
    """

    def _replace(m: re.Match) -> str:
        pkg = m.group(2)
        if pkg.endswith(".playwright"):
            return m.group(0)  # Already correct, leave unchanged.
        return f"{m.group(1)}{pkg}.playwright{m.group(3)}"

    rewritten, count = _PACKAGE_DECL_RE.subn(_replace, source)
    return rewritten if count else source


def build_signatures_from_class_info(class_info: dict[str, Any]) -> list[str]:
    """
    Produce a `sibling_signatures`-shaped list for a passthrough file.

    The cross-file hallucination detector keys off method-name substrings
    inside each signature line. For an enum like `Environment` we need
    the detector to recognize:
      - constants: `Environment.DEV`, `Environment.PROD`, ...
      - methods:   `Environment.fromString("dev")`, `Environment.getName()`

    We emit one line per constant (as a synthetic public static final
    field) and one line per declared method. The Coder prompt's sibling
    block renders these as-is, so the LLM sees the real API and stops
    inventing `Environment.DEVELOPMENT`.
    """
    sigs: list[str] = []

    # Enum constants -> "public static final Environment DEV"
    for field in class_info.get("fields", []):
        name = field.get("name")
        ftype = field.get("type") or ""
        mods = " ".join(field.get("modifiers") or [])
        if not name:
            continue
        sig = f"{mods} {ftype} {name}".strip()
        sigs.append(sig)

    # Methods -> full signature line
    for m in class_info.get("methods", []):
        name = m.get("name")
        if not name:
            continue
        mods = " ".join(m.get("modifiers") or [])
        ret = m.get("return_type") or "void"
        params = ", ".join(
            f"{p.get('type', '')} {p.get('name', '')}".strip()
            for p in (m.get("parameters") or [])
        )
        sig = f"{mods} {ret} {name}({params})".strip()
        sigs.append(sig)

    return sigs
