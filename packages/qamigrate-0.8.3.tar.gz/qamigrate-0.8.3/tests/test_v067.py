"""
Regression tests for v0.6.7 — four changes addressing the v0.6.6 test report.

  1. --exclude substring matching (no shell-quoting headaches on Windows).
  2. class_api builder: include both public and private members; expose
     method return types for Fix 18's prefix-match tier.
  3. Fix 18 second tier: same accessor prefix → single-candidate rewrite
     even when edit distance > 2 (catches getPage → getDriver).
  4. Fix 19: Playwright API lint pass (setIgnoreHTTPSErrors moved from
     LaunchOptions → NewContextOptions, etc.).
  5. Phase 1.7: synthesize missing constructors when the Coder dropped an
     overload from a generated exception class.
"""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from qamigrate.cli.main import app


runner = CliRunner()


# =============================================================================
# 1. --exclude substring matching
# =============================================================================


class TestExcludeSubstring:
    def test_substring_match_excludes_subpath(self, tmp_path: Path) -> None:
        # No glob characters in the pattern. Should match by substring.
        proj = tmp_path / "monorepo"
        (proj / "subA" / "src").mkdir(parents=True)
        (proj / "subB" / "src").mkdir(parents=True)
        (proj / "subA" / "src" / "A.java").write_text(
            "package a; class A {}\n", encoding="utf-8"
        )
        (proj / "subB" / "src" / "B.java").write_text(
            "package b; class B {}\n", encoding="utf-8"
        )

        result = runner.invoke(
            app,
            [
                "migrate", "--all",
                "--project", str(proj),
                "--exclude", "subB",   # substring, no glob
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "A.java" in result.stdout
        assert "B.java" not in result.stdout

    def test_glob_form_still_works(self, tmp_path: Path) -> None:
        # Backwards-compat: glob form (with *) is still supported.
        proj = tmp_path / "monorepo"
        (proj / "subA").mkdir(parents=True)
        (proj / "subB").mkdir(parents=True)
        (proj / "subA" / "A.java").write_text("class A {}\n", encoding="utf-8")
        (proj / "subB" / "B.java").write_text("class B {}\n", encoding="utf-8")

        result = runner.invoke(
            app,
            [
                "migrate", "--all",
                "--project", str(proj),
                "--exclude", "subB/*.java",
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "A.java" in result.stdout
        assert "B.java" not in result.stdout


# =============================================================================
# 2. class_api builder coverage
# =============================================================================


class TestClassApiBuilder:
    def test_includes_private_methods(self) -> None:
        from qamigrate.agents.pipeline import _build_class_api_from_project_map
        from qamigrate.intelligence.project_map import (
            ClassInfo, ClassRole, MethodInfo, ParameterInfo, ProjectMap,
        )

        # Build a minimal ProjectMap with one class that has both public
        # and private methods. The v0.6.6 builder dropped private ones,
        # which silently hid private constructors used by utility classes.
        cls = ClassInfo(
            name="Util",
            fqn="com.example.Util",
            file_path="Util.java",
            package="com.example",
            extends=None,
            implements=[],
            modifiers=["public", "final"],
            imports=[],
            role=ClassRole.UTILITY,
            public_methods=[
                MethodInfo(
                    name="run",
                    modifiers=["public", "static"],
                    return_type="void",
                    parameters=[],
                    annotations=[],
                ),
            ],
            private_methods=[
                MethodInfo(
                    name="Util",
                    modifiers=["private"],
                    return_type="",   # constructor
                    parameters=[],
                    annotations=[],
                ),
            ],
        )
        pm = ProjectMap(project_path=".", project_name="t")
        pm.classes["com.example.Util"] = cls

        api = _build_class_api_from_project_map(pm)
        assert api is not None
        info = api["Util"]
        # The private no-arg constructor MUST be in the arity set.
        assert 0 in info["constructor_arities"]
        # The public method is also captured.
        assert "run" in info["method_names"]

    def test_exposes_method_return_types(self) -> None:
        from qamigrate.agents.pipeline import _build_class_api_from_project_map
        from qamigrate.intelligence.project_map import (
            ClassInfo, ClassRole, MethodInfo, ProjectMap,
        )

        cls = ClassInfo(
            name="Holder",
            fqn="com.example.Holder",
            file_path="Holder.java",
            package="com.example",
            extends=None,
            implements=[],
            modifiers=["public"],
            imports=[],
            role=ClassRole.OTHER,
            public_methods=[
                MethodInfo(
                    name="value",
                    modifiers=["public"],
                    return_type="String",
                    parameters=[],
                    annotations=[],
                ),
            ],
        )
        pm = ProjectMap(project_path=".", project_name="t")
        pm.classes["com.example.Holder"] = cls
        api = _build_class_api_from_project_map(pm)
        rts = api["Holder"]["method_return_types"]
        assert rts == {"value": ["String"]}


# =============================================================================
# 3. Fix 18 second tier (same-prefix candidate)
# =============================================================================


class TestFix18SamePrefixTier:
    def test_get_prefix_with_single_candidate_rewritten(self) -> None:
        """The v0.6.6 BDD bug: DriverManager.getPage() should rewrite to
        getDriver() because that's the ONLY get* method on DriverManager.
        Edit distance is 4 — too far for tier 1. Tier 2 (same `get` prefix,
        single candidate) catches it.
        """
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver", "quitDriver"],
            },
        }
        src = "Page p = DriverManager.getPage();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert changed
        assert "DriverManager.getDriver()" in out
        assert "getPage" not in out

    def test_get_prefix_with_multiple_candidates_left_alone(self) -> None:
        # Tier 2 fires only when there's exactly ONE same-prefix candidate.
        # Two candidates (getElement / getRecord) both with the same prefix
        # AND both far away in edit distance → ambiguous → no rewrite.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "Holder": {
                "constructor_arities": {0},
                # `getXxxxxxxx` has multiple same-prefix candidates and
                # none is within edit distance 2.
                "method_names": ["getElement", "getRecord"],
            },
        }
        src = "Holder.getEntity();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed

    def test_set_prefix_too_short_rest_left_alone(self) -> None:
        # `set()` would have rest "" which is < 2 chars; skipped to avoid
        # spurious matches.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "Foo": {
                "constructor_arities": {0},
                "method_names": ["set"],   # rest len 0
            },
        }
        src = "Foo.setX();\n"
        # `setX` rest is "X" (len 1) — tier 2 requires len >= 2 for the
        # candidate's rest, not the call's. So `set` candidate has rest
        # "" → skipped → no rewrite.
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed

    def test_foreign_imported_class_not_rewritten(self) -> None:
        """v0.6.7 production-run regression:

        The project has `com.anhtester.driver.DriverManager` (Playwright).
        DatabaseHelpers.java imports `java.sql.DriverManager` and calls
        `DriverManager.getConnection(...)` on JDBC.

        Pre-fix: Fix 18 looked up `DriverManager` in class_api, found the
        project's Playwright DriverManager, saw `getConnection` had no
        match but `getDriver` did, and rewrote getConnection → getDriver.
        That broke a previously-correct JDBC call.

        Hot-fix: when the class name appears in a foreign-package import,
        skip the rewrite — class_api can't resolve a simple-name collision.
        """
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver", "quitDriver"],
            },
        }
        # The import statement signals java.sql.DriverManager, not the
        # project's DriverManager.
        src = (
            "import java.sql.Connection;\n"
            "import java.sql.DriverManager;\n"
            "\n"
            "public class DatabaseHelpers {\n"
            "    public Connection open(String url, String u, String p) {\n"
            "        return DriverManager.getConnection(url, u, p);\n"
            "    }\n"
            "}\n"
        )
        out, changed, log = _fix_hallucinated_static_method(src, api)
        # MUST NOT rewrite — the call is JDBC, not the project's DriverManager.
        assert not changed
        assert "DriverManager.getConnection(url, u, p)" in out

    def test_project_class_still_rewritten_when_no_foreign_collision(self) -> None:
        # Sanity: when the project's DriverManager is the only candidate
        # (no foreign import), rewrite still works as designed.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver"],
            },
        }
        src = (
            "import com.anhtester.driver.DriverManager;\n"
            "\n"
            "public class BasePage {\n"
            "    public Page page() { return DriverManager.getPage(); }\n"
            "}\n"
        )
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert changed
        assert "DriverManager.getDriver()" in out

    def test_tier1_still_works_for_typo(self) -> None:
        # Tier 1 (close-name) still wins when the names are within edit
        # distance 2. v0.6.6 behaviour preserved.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "Foo": {
                "constructor_arities": {0},
                "method_names": ["getDriver"],
            },
        }
        src = "Foo.getDriverr();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert changed
        assert "Foo.getDriver()" in out


# =============================================================================
# 4. Fix 19 — Playwright API lint pass
# =============================================================================


class TestFix19PlaywrightApiLint:
    def test_set_ignore_https_errors_moved_off_launch_options(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_playwright_api_misuse

        src = (
            "BrowserType.LaunchOptions opts = "
            "new BrowserType.LaunchOptions().setIgnoreHTTPSErrors(true);\n"
        )
        out, changed, log = _fix_playwright_api_misuse(src)
        assert changed
        assert "Browser.NewContextOptions()" in out
        assert ".setIgnoreHTTPSErrors(true)" in out
        assert "BrowserType.LaunchOptions().setIgnoreHTTPSErrors" not in out

    def test_set_user_agent_moved(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_playwright_api_misuse

        src = 'new BrowserType.LaunchOptions().setUserAgent("ua");\n'
        out, changed, log = _fix_playwright_api_misuse(src)
        assert changed
        assert "Browser.NewContextOptions()" in out

    def test_clean_launch_options_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_playwright_api_misuse

        src = "new BrowserType.LaunchOptions().setHeadless(true);\n"
        out, changed, log = _fix_playwright_api_misuse(src)
        assert not changed
        assert out == src

    def test_no_launch_options_fast_path(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_playwright_api_misuse

        src = "page.click('#x');\n"
        out, changed, log = _fix_playwright_api_misuse(src)
        assert not changed

    def test_chained_call_preserves_intermediate(self) -> None:
        # `new LaunchOptions().setHeadless(true).setIgnoreHTTPSErrors(true)`
        # → only the misplaced trailing call is rerouted; setHeadless stays.
        # NOTE: this exact regex is conservative — it only catches the
        # straight-from-LaunchOptions case. Chained-after-other-calls
        # patterns are left for a future refinement.
        from qamigrate.core.postgen_fixes import _fix_playwright_api_misuse

        src = (
            "new BrowserType.LaunchOptions()"
            ".setHeadless(true)"
            ".setIgnoreHTTPSErrors(true);\n"
        )
        out, changed, log = _fix_playwright_api_misuse(src)
        assert changed
        # The whole expression now uses NewContextOptions.
        assert "Browser.NewContextOptions()" in out
        assert ".setHeadless(true)" in out


# =============================================================================
# 6. Fix 16 brace-safety guard (v0.6.7 hot-fix)
# =============================================================================


class TestFix16BraceSafety:
    """v0.6.7: Fix 16 must NOT comment out a line with an unbalanced brace.

    The first end-to-end run of v0.6.7 on the BDD project hit this exact
    regression: Fix 16 commented out
        public static WebDriver getDriver() {
    leaving the body at class scope and producing 5 cascading parse errors.
    """

    def test_method_opening_with_orphan_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        # No `import WebDriver`, but the orphan is on a method-opening line
        # with an unbalanced `{`. The fix must NOT comment it out.
        src = (
            "public class DriverManager {\n"
            "    public static WebDriver getDriver() {\n"
            "        Page page = pageThreadLocal.get();\n"
            "        return (WebDriver) page;\n"
            "    }\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        # The standalone `(WebDriver) page` line CAN be commented (no brace
        # imbalance there). The method-opening line MUST stay intact.
        assert "public static WebDriver getDriver() {" in out
        # Body wasn't orphaned: the method's brace structure is preserved.
        assert out.count("{") == out.count("}")

    def test_closing_brace_only_line_left_alone(self) -> None:
        # A line that's only `}` shouldn't ever match an orphan, but if a
        # comment with WebDriver on the same line happened, we still
        # don't comment it out.
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "public class X {\n"
            "    void foo() {\n"
            "        return; } // WebDriver leftover comment\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        # Inline `// WebDriver` is in a comment, so _strip_comments removes
        # it before orphan detection — `WebDriver` isn't even seen as used.
        assert not changed

    def test_balanced_inline_braces_can_be_commented(self) -> None:
        # `WebDriver d = new WebDriver();` has zero net brace change, so
        # it's safe to comment out.
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "public class X {\n"
            "    void foo() {\n"
            "        WebDriver driver = null;\n"
            "        Page p = page;\n"
            "    }\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert changed
        # The standalone declaration line was commented out.
        assert "// QAMigrate: orphan Selenium symbol" in out
        # And the brace structure is still balanced.
        assert out.count("{") == out.count("}")


# =============================================================================
# 5. Phase 1.7 — missing-constructor synthesis
# =============================================================================


class TestPhase17MissingConstructor:
    def test_synthesizes_missing_2arg_constructor(self, tmp_path: Path) -> None:
        from qamigrate.agents.pipeline import _synthesize_missing_constructors

        # Simulate a generated file that has only the 1-arg constructor,
        # while the source class_api shows BOTH 1-arg and 2-arg.
        gen_file = tmp_path / "InvalidPathException.java"
        gen_file.write_text(
            "package x.playwright;\n"
            "public class InvalidPathException extends RuntimeException {\n"
            "    public InvalidPathException(String msg) { super(msg); }\n"
            "}\n",
            encoding="utf-8",
        )

        # Mock GenerationResult.
        class _Gen:
            output_path = gen_file
            generated_code = ""

        class_api = {
            "InvalidPathException": {
                "constructor_arities": {1, 2},
                "method_names": [],
            }
        }
        _synthesize_missing_constructors([_Gen()], class_api)

        new_src = gen_file.read_text(encoding="utf-8")
        # The 1-arg form is preserved.
        assert "public InvalidPathException(String msg)" in new_src
        # The 2-arg form has been synthesized.
        assert "public InvalidPathException(String message, Throwable cause)" in new_src
        assert "super(message, cause)" in new_src

    def test_no_synth_when_class_not_in_api(self, tmp_path: Path) -> None:
        from qamigrate.agents.pipeline import _synthesize_missing_constructors

        gen_file = tmp_path / "Foo.java"
        original = (
            "public class Foo extends Bar {\n"
            "    public Foo(String s) { super(s); }\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")

        class _Gen:
            output_path = gen_file
            generated_code = ""

        # Foo isn't in class_api → nothing to do.
        _synthesize_missing_constructors([_Gen()], {"Bar": {"constructor_arities": {0}, "method_names": []}})
        assert gen_file.read_text(encoding="utf-8") == original

    def test_no_synth_when_no_extends(self, tmp_path: Path) -> None:
        # We need a parent class to delegate `super(...)` to. Plain classes
        # are skipped (would need to know fields).
        from qamigrate.agents.pipeline import _synthesize_missing_constructors

        gen_file = tmp_path / "Foo.java"
        original = (
            "public class Foo {\n"
            "    public Foo(String s) {}\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")

        class _Gen:
            output_path = gen_file
            generated_code = ""

        _synthesize_missing_constructors(
            [_Gen()],
            {"Foo": {"constructor_arities": {1, 2}, "method_names": []}},
        )
        assert gen_file.read_text(encoding="utf-8") == original

    def test_no_change_when_all_arities_present(self, tmp_path: Path) -> None:
        from qamigrate.agents.pipeline import _synthesize_missing_constructors

        gen_file = tmp_path / "Foo.java"
        original = (
            "public class Foo extends Bar {\n"
            "    public Foo(String s) { super(s); }\n"
            "    public Foo(String s, Throwable c) { super(s, c); }\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")

        class _Gen:
            output_path = gen_file
            generated_code = ""

        _synthesize_missing_constructors(
            [_Gen()],
            {"Foo": {"constructor_arities": {1, 2}, "method_names": []}},
        )
        # No change.
        assert gen_file.read_text(encoding="utf-8") == original
