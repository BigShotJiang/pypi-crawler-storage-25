"""
Regression tests for v0.8.2 — two bugs that shipped through v0.8.0 and v0.8.1
because the existing test suite didn't exercise them:

1. The `@app.command()` decorator on `_find_nested_poms` was incorrectly
   placed during the v0.8 init refactor, so `init` was never registered
   as a CLI command despite being the documented Step 1 of the workflow.
2. `DependencyKind.CALLS` and `DependencyKind.REFERENCES` were referenced
   in `intelligence/report.py` but the enum has `STATIC_CALL` and `IMPORT`
   instead — making `qamigrate analyze` crash with AttributeError on every
   project.

These tests assert the CLI surface and HTML report invariants directly so
the same shape of bug cannot ship again silently.
"""

from __future__ import annotations

from pathlib import Path

import pytest
from typer.testing import CliRunner


# =============================================================================
# Bug #1 — Every documented CLI command must be registered
# =============================================================================


# These are the commands the README and PyPI page advertise as the public
# QAMigrate CLI surface. Every one of them MUST be reachable as
# `qamigrate <command> --help`. If we ever rename one (or accidentally
# strip its decorator again), this test fails immediately.
_DOCUMENTED_COMMANDS = ("init", "scan", "analyze", "migrate")


def test_all_documented_commands_are_registered() -> None:
    """v0.8.2 regression: `init` must be registered as a CLI command.

    The bug: the @app.command() decorator was pulled off `init` during a
    v0.8 refactor (it ended up on a private helper instead). The CLI
    silently lost the `init` command, breaking the documented Step 1
    workflow. This test surfaces the failure as a one-line assertion
    instead of waiting for an end-to-end test report.
    """
    from qamigrate.cli.main import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0, result.stdout
    for cmd in _DOCUMENTED_COMMANDS:
        assert f" {cmd} " in result.stdout or f" {cmd}\n" in result.stdout, (
            f"Documented command `{cmd}` is missing from CLI surface. "
            f"Output was:\n{result.stdout}"
        )


def test_internal_helpers_not_exposed_as_commands() -> None:
    """Helpers prefixed with `_` (Python convention for internal) must
    NOT be registered as Typer commands. The v0.8 bug exposed
    `_find_nested_poms` by accident.
    """
    from qamigrate.cli.main import app

    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    # Typer renders commands by their function name (or `--name` override).
    # An underscore-prefixed name leaking through means a decorator went
    # somewhere unintended.
    forbidden_substrings = ("-find-nested-poms", "_find_nested_poms")
    for forbidden in forbidden_substrings:
        assert forbidden not in result.stdout, (
            f"Internal helper `{forbidden}` is exposed as a CLI command. "
            "Move the @app.command() decorator to the right function."
        )


def test_init_command_runs_without_crashing(tmp_path: Path) -> None:
    """End-to-end smoke: `qamigrate init --project <empty-tmp> --yes`
    must complete without an unhandled exception. We don't assert on
    output details — just that the command exists and terminates cleanly.
    """
    from qamigrate.cli.main import app

    # Create a minimal valid project layout (pom.xml only — init detects it).
    proj = tmp_path / "myproj"
    proj.mkdir()
    (proj / "pom.xml").write_text(
        "<project><modelVersion>4.0.0</modelVersion>"
        "<groupId>x</groupId><artifactId>y</artifactId>"
        "<version>1</version></project>",
        encoding="utf-8",
    )

    runner = CliRunner()
    result = runner.invoke(app, ["init", "--project", str(proj), "--yes"])
    # Either exit_code 0 (success) or 1 (e.g. dependency injection
    # warned about something). Anything else (especially 2 = "no such
    # command") is a regression.
    assert result.exit_code in (0, 1), (
        f"init failed unexpectedly. exit_code={result.exit_code}\n"
        f"output:\n{result.stdout}"
    )
    # Make absolutely sure the failure mode "command not found" never recurs.
    assert "No such command" not in result.stdout
    assert "Usage:" not in result.stdout or "Initializing" in result.stdout


# =============================================================================
# Bug #2 — Architecture report must use only real DependencyKind members
# =============================================================================


def test_dependency_kind_css_map_keys_exist() -> None:
    """v0.8.2 regression: the CSS-class map in `intelligence/report.py`
    references DependencyKind members. If the enum is renamed without
    updating the map, the import alone will crash with AttributeError.

    The bug: `DependencyKind.CALLS` and `DependencyKind.REFERENCES` were
    referenced but the actual enum has `STATIC_CALL`, `IMPORT`,
    `FIELD_TYPE`. Every `qamigrate analyze` invocation crashed with
    AttributeError before producing output.

    The presence of `_EDGE_KIND_CSS` as a module-level dict means even
    importing the module triggers the lookup. So if this test imports
    cleanly, the map is well-formed.
    """
    # The import itself is the test — if `_EDGE_KIND_CSS` references a
    # non-existent enum member, this line raises AttributeError.
    from qamigrate.intelligence.report import _EDGE_KIND_CSS
    from qamigrate.intelligence.project_map import DependencyKind

    # Defensive: every key in the map must be a real DependencyKind member.
    valid_members = set(DependencyKind)
    for key in _EDGE_KIND_CSS:
        assert key in valid_members, (
            f"_EDGE_KIND_CSS key {key!r} is not a real DependencyKind. "
            f"Valid members: {sorted(m.name for m in valid_members)}"
        )


def test_render_html_smoke(tmp_path: Path) -> None:
    """Build a minimal ProjectMap and render its HTML report. This
    catches any other latent reference to a non-existent enum member,
    bad attribute access, or template substitution bug.
    """
    from qamigrate.intelligence.project_map import (
        ClassInfo, ClassRole, DependencyEdge, DependencyKind, ProjectMap,
    )
    from qamigrate.intelligence.report import render_html

    pm = ProjectMap(project_path=str(tmp_path), project_name="t")
    pm.classes["com.x.A"] = ClassInfo(
        name="A", fqn="com.x.A", file_path=str(tmp_path / "A.java"),
        package="com.x", extends=None, implements=[], modifiers=["public"],
        imports=[], role=ClassRole.OTHER,
    )
    pm.classes["com.x.B"] = ClassInfo(
        name="B", fqn="com.x.B", file_path=str(tmp_path / "B.java"),
        package="com.x", extends="A", implements=[], modifiers=["public"],
        imports=[], role=ClassRole.OTHER,
    )
    pm.edges.append(DependencyEdge(
        source="com.x.B", target="com.x.A", kind=DependencyKind.EXTENDS,
    ))

    # Should not raise.
    html = render_html(pm)
    assert "<html" in html
    assert "B" in html and "A" in html
