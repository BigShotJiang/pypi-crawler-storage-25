"""
Regression tests for v0.6.1 — production hardening pass.

v0.6.1 was a code-review-driven release that closed gaps surfaced by the
v0.6.0 production run on AutomationFrameworkSelenium and a 7-track
codebase audit. The fixes span:

- **Parser**: varargs (`String... args`) capture, throws clauses,
  static initializer blocks.
- **Coder agent**: dead `generate()` / `_build_prompt()` paths removed
  so requirement 3-bis (API preservation) cannot be bypassed; tree-sitter
  / regex constructor count replaces brittle string match;
  `validate_generated_code()` actually runs in `assemble_file()` now;
  `LLMMalformedOutput` is caught separately so schema violations are
  visible in the run log.
- **Postgen**: Fix 2 (ScreenshotOptions) reports `changed` based on
  actual diff, not on trigger-pattern presence — the identity-check
  optimization in `apply_all_postgen_fixes` is restored.
- **Config**: `extra=forbid` on every nested model so YAML typos fail
  loud; `provider` field validators cross-check against the LLM
  registry at load time.
- **LLM retry**: provider-supplied Retry-After hints honored up to 300s
  (was clamped to 90s); Anthropic `stop_reason=max_tokens` and OpenAI
  `finish_reason=length` raise `LLMMalformedOutput` with a clear
  "increase max_tokens" message.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from qamigrate.core.parser import JavaParser
from qamigrate.intelligence.project_map import (
    MethodInfo,
    ParameterInfo,
)


# =============================================================================
# Parser: varargs
# =============================================================================


class TestVarargs:
    def test_varargs_captured_as_array_type(self, tmp_path: Path) -> None:
        src = (
            "package com.example;\n"
            "public class V {\n"
            "    public void log(String... args) {}\n"
            "}\n"
        )
        p = tmp_path / "V.java"
        p.write_text(src, encoding="utf-8")
        info = JavaParser().extract_class_info(p)
        methods = info["methods"]
        assert len(methods) == 1
        params = methods[0]["parameters"]
        assert len(params) == 1
        # Type is normalized to array form so call sites generate
        # invocation-compatible code.
        assert params[0]["type"] == "String[]"
        assert params[0]["name"] == "args"
        # The varargs flag is preserved so signature rendering can use
        # the source-form `Type...` syntax.
        assert params[0].get("varargs") == "true"

    def test_signature_renders_varargs_with_ellipsis(self) -> None:
        m = MethodInfo(
            name="log",
            modifiers=["public"],
            return_type="void",
            parameters=[ParameterInfo(name="args", type="String[]", varargs=True)],
            annotations=[],
            body="{}",
            line=1,
        )
        # The signature uses `String...` even though storage is `String[]`,
        # so the prompt shows the LLM the source-form declaration.
        assert m.signature == "public void log(String... args)"

    def test_signature_renders_normal_array_when_not_varargs(self) -> None:
        m = MethodInfo(
            name="log",
            modifiers=["public"],
            return_type="void",
            parameters=[ParameterInfo(name="args", type="String[]", varargs=False)],
            annotations=[],
            body="{}",
            line=1,
        )
        assert m.signature == "public void log(String[] args)"


# =============================================================================
# Parser: throws clauses
# =============================================================================


class TestThrows:
    def test_single_throws_clause_captured(self, tmp_path: Path) -> None:
        src = (
            "package com.example;\n"
            "import java.io.IOException;\n"
            "public class T {\n"
            "    public void read() throws IOException {}\n"
            "}\n"
        )
        p = tmp_path / "T.java"
        p.write_text(src, encoding="utf-8")
        info = JavaParser().extract_class_info(p)
        methods = info["methods"]
        assert len(methods) == 1
        assert methods[0]["throws"] == ["IOException"]

    def test_multiple_throws_captured(self, tmp_path: Path) -> None:
        src = (
            "package com.example;\n"
            "public class T {\n"
            "    public void run() throws IOException, SQLException {}\n"
            "}\n"
        )
        p = tmp_path / "T.java"
        p.write_text(src, encoding="utf-8")
        info = JavaParser().extract_class_info(p)
        throws = info["methods"][0]["throws"]
        assert "IOException" in throws
        assert "SQLException" in throws

    def test_signature_appends_throws(self) -> None:
        m = MethodInfo(
            name="read",
            modifiers=["public"],
            return_type="void",
            parameters=[],
            annotations=[],
            body="{}",
            line=1,
            throws=["IOException"],
        )
        assert m.signature == "public void read() throws IOException"

    def test_no_throws_keeps_signature_clean(self) -> None:
        m = MethodInfo(
            name="read",
            modifiers=["public"],
            return_type="void",
            parameters=[],
            annotations=[],
            body="{}",
            line=1,
        )
        assert m.signature == "public void read()"


# =============================================================================
# Parser: static initializer
# =============================================================================


class TestStaticInitializer:
    def test_static_block_captured_as_clinit(self, tmp_path: Path) -> None:
        src = (
            "package com.example;\n"
            "public class C {\n"
            "    static final String NAME;\n"
            "    static {\n"
            "        NAME = \"foo\";\n"
            "    }\n"
            "}\n"
        )
        p = tmp_path / "C.java"
        p.write_text(src, encoding="utf-8")
        info = JavaParser().extract_class_info(p)
        # The static block surfaces as a synthetic method named <clinit>.
        clinit = [m for m in info["methods"] if m["name"] == "<clinit>"]
        assert len(clinit) == 1
        assert "static" in clinit[0]["modifiers"]
        assert clinit[0]["body"] is not None
        assert "NAME" in clinit[0]["body"]


# =============================================================================
# Postgen: Fix 2 idempotency
# =============================================================================


class TestRequiredSignaturesChecklist:
    """v0.6.1: explicit per-file signatures checklist in the Coder prompt.

    The plain prose Requirement 3-bis from v0.6.0 wasn't enough — the LLM
    still dropped 3 of 4 LogUtils.error overloads on the production run.
    A numbered checklist of required signatures is much harder to skip.
    """

    def test_all_overloads_listed(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        class_info = {
            "methods": [
                {
                    "name": "error",
                    "return_type": "void",
                    "parameters": [{"type": "String", "name": "m"}],
                    "modifiers": ["public", "static"],
                },
                {
                    "name": "error",
                    "return_type": "void",
                    "parameters": [
                        {"type": "String", "name": "m"},
                        {"type": "Throwable", "name": "t"},
                    ],
                    "modifiers": ["public", "static"],
                },
            ]
        }
        out = CoderAgent._build_required_signatures(class_info)
        assert "Required output signatures" in out
        assert "Overload set `error`" in out
        assert "2 variants" in out
        # Both signatures should be in the output.
        assert "void error(String m)" in out
        assert "void error(String m, Throwable t)" in out

    def test_constructor_listed_without_return_type(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        class_info = {
            "methods": [
                {
                    "name": "FrameworkException",
                    "return_type": "",  # constructor
                    "parameters": [
                        {"type": "String", "name": "msg"},
                        {"type": "Throwable", "name": "cause"},
                    ],
                    "modifiers": ["public"],
                },
            ]
        }
        out = CoderAgent._build_required_signatures(class_info)
        assert "FrameworkException(String msg, Throwable cause)" in out
        # Constructor must NOT be prefixed by `void`.
        assert "void FrameworkException" not in out

    def test_throws_clause_appears_in_checklist(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        class_info = {
            "methods": [
                {
                    "name": "read",
                    "return_type": "String",
                    "parameters": [{"type": "String", "name": "path"}],
                    "modifiers": ["public"],
                    "throws": ["IOException"],
                },
            ]
        }
        out = CoderAgent._build_required_signatures(class_info)
        assert "throws IOException" in out

    def test_no_methods_returns_empty(self) -> None:
        from qamigrate.agents.coder import CoderAgent

        out = CoderAgent._build_required_signatures({"methods": []})
        assert out == ""

    def test_private_methods_excluded(self) -> None:
        # Private internals don't round-trip; the prompt only tracks the
        # public API surface.
        from qamigrate.agents.coder import CoderAgent

        class_info = {
            "methods": [
                {
                    "name": "internalHelper",
                    "return_type": "void",
                    "parameters": [],
                    "modifiers": ["private"],
                },
                {
                    "name": "publicApi",
                    "return_type": "void",
                    "parameters": [],
                    "modifiers": ["public"],
                },
            ]
        }
        out = CoderAgent._build_required_signatures(class_info)
        assert "publicApi" in out
        assert "internalHelper" not in out


class TestFix13MissingBrace:
    """v0.6.1 Fix 13 — non-abstract method missing `{ ... }` around body.

    Production v0.6.1 run on AutomationFrameworkSelenium had this in
    BrowserFactory.java line 23:
        private Browser createBrowser(BrowserType browserType) Playwright p = ...; return ...;
    The whole body was on one line with no braces, producing 4 cascading
    parse errors.
    """

    def test_wraps_inline_body_in_braces(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_nonabstract_method_missing_brace

        src = (
            "    private Browser createBrowser(BrowserType bt) "
            "Playwright p = Playwright.create(); return bt.launch(getOptions());\n"
        )
        out, changed = _fix_nonabstract_method_missing_brace(src)
        assert changed
        assert "{" in out and "}" in out
        # Body content preserved.
        assert "Playwright p = Playwright.create();" in out
        assert "return bt.launch(getOptions());" in out

    def test_already_braced_method_unchanged(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_nonabstract_method_missing_brace

        src = (
            "    private void foo() { x = 1; return; }\n"
            "    public void bar() {\n"
            "        y = 2;\n"
            "    }\n"
        )
        out, changed = _fix_nonabstract_method_missing_brace(src)
        assert not changed
        assert out == src

    def test_abstract_method_not_touched(self) -> None:
        # Fix 13 must NOT collide with Fix 11 (abstract method missing `;`).
        # Abstract methods have no body and no `;` in the test input, so the
        # heuristic's "at least one `;`" requirement filters them out.
        from qamigrate.core.postgen_fixes import _fix_nonabstract_method_missing_brace

        src = "    public abstract Browser create(Playwright p)\n"
        out, changed = _fix_nonabstract_method_missing_brace(src)
        assert not changed

    def test_field_declaration_not_touched(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_nonabstract_method_missing_brace

        # No `(` in this line, so the regex doesn't even consider it.
        src = "    private static final String NAME = \"foo\";\n"
        out, changed = _fix_nonabstract_method_missing_brace(src)
        assert not changed
        assert out == src

    def test_apply_all_includes_fix_13(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "public class B {\n"
            "    private int doIt(int x) int y = x * 2; return y;\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="B.java")
        assert "{ int y = x * 2; return y; }" in out


class TestFix2Idempotency:
    def test_no_change_reported_when_already_qualified(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_screenshot_options_import

        src = (
            "import com.microsoft.playwright.Page;\n"
            "Page.ScreenshotOptions opts = ...;\n"
        )
        out, changed = _fix_screenshot_options_import(src)
        # No fake import, but ScreenshotOptions is in the body. Without
        # the v0.6.1 fix this returned `(out, True)` because of the early
        # return path; we now correctly report no change.
        assert not changed
        assert out == src

    def test_change_reported_when_fake_import_replaced(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_screenshot_options_import

        src = (
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "ScreenshotOptions opts = ...;\n"
        )
        out, changed = _fix_screenshot_options_import(src)
        assert changed
        assert "Page.ScreenshotOptions" in out


# =============================================================================
# Config: extra=forbid
# =============================================================================


class TestConfigExtraForbid:
    def test_unknown_top_level_field_rejected(self) -> None:
        from pydantic import ValidationError

        from qamigrate.core.config import QAMigrateConfig

        with pytest.raises(ValidationError) as exc_info:
            QAMigrateConfig(unknown_section={"foo": "bar"})  # type: ignore[arg-type]
        # The error mentions `extra` so users know to check for typos.
        assert "extra" in str(exc_info.value).lower() or "unknown" in str(
            exc_info.value
        ).lower()

    def test_unknown_nested_field_rejected(self) -> None:
        from pydantic import ValidationError

        from qamigrate.core.config import CompilerConfig

        with pytest.raises(ValidationError):
            # `javaversion` is the typo, real field is `java_version`.
            CompilerConfig(javaversion="17")  # type: ignore[arg-type]

    def test_known_fields_still_load(self) -> None:
        from qamigrate.core.config import QAMigrateConfig

        cfg = QAMigrateConfig(
            compiler={"build_tool": "maven", "java_version": "17"}
        )
        assert cfg.compiler.java_version == "17"


# =============================================================================
# Config: provider validation at load time
# =============================================================================


class TestProviderValidation:
    def test_unknown_provider_rejected_at_load(self) -> None:
        from pydantic import ValidationError

        from qamigrate.core.config import CoderConfig

        with pytest.raises(ValidationError) as exc_info:
            CoderConfig(provider="anthropi")  # typo
        # The error message lists known providers so the user can self-correct.
        assert "anthropi" in str(exc_info.value)

    def test_known_providers_accepted(self) -> None:
        from qamigrate.core.config import CoderConfig, FixerConfig

        for name in ("anthropic", "openai"):
            CoderConfig(provider=name)
            FixerConfig(provider=name)


# =============================================================================
# Retry: longer Retry-After cap
# =============================================================================


class TestRetryAfterCap:
    def test_180s_hint_honored_not_clamped_to_90(self) -> None:
        from qamigrate.llm.retry import _parse_retry_after

        e = Exception("rate limit; try after 180 seconds")
        # v0.6.1: was clamped to 90s. Now honored up to 300s.
        assert _parse_retry_after(e) == 180.0

    def test_3_minutes_honored(self) -> None:
        from qamigrate.llm.retry import _parse_retry_after

        e = Exception("retry after 3 minutes")
        assert _parse_retry_after(e) == 180.0

    def test_above_max_clamped_to_300(self) -> None:
        from qamigrate.llm.retry import _parse_retry_after

        e = Exception("retry after 600 seconds")
        # 600s exceeds the 300s cap.
        assert _parse_retry_after(e) == 300.0


# =============================================================================
# Coder: validate_generated_code with overload-aware duplicate check
# =============================================================================


class TestValidateGeneratedCode:
    def _make_code(self, methods: list, ctor: str = "    public Foo() {}", class_name: str = "Foo") -> object:
        from qamigrate.agents.coder import MethodDefinition, PlaywrightCode

        return PlaywrightCode(
            package_name="com.example.playwright",
            imports=[],
            class_declaration=f"public class {class_name} extends Bar implements I1, I2 {{",
            fields=[],
            constructor=ctor,
            methods=[
                MethodDefinition(
                    name=m["name"],
                    signature=m["signature"],
                    implementation=m.get("impl", "{}"),
                )
                for m in methods
            ],
        )

    def test_overloads_not_flagged_as_duplicates(self) -> None:
        # v0.6.1: keying duplicate detection on (name, arity) so genuine
        # overloads (different param counts) don't false-positive.
        from qamigrate.agents.coder import CoderAgent
        from qamigrate.core.config import CoderConfig

        code = self._make_code([
            {"name": "info", "signature": "public void info(String m)", "impl": "{ }"},
            {"name": "info", "signature": "public void info(String m, Throwable t)", "impl": "{ }"},
        ])
        # Use a stub provider — we only need the agent's instance method.
        agent = CoderAgent.__new__(CoderAgent)  # type: ignore[call-arg]
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(code)
        duplicate_errors = [e for e in errors if "Duplicate method" in e]
        assert duplicate_errors == []

    def test_true_duplicates_flagged(self) -> None:
        from qamigrate.agents.coder import CoderAgent
        from qamigrate.core.config import CoderConfig

        # Same name + same arity = real duplicate
        code = self._make_code([
            {"name": "info", "signature": "public void info(String m)"},
            {"name": "info", "signature": "public void info(String x)"},
        ])
        agent = CoderAgent.__new__(CoderAgent)
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(code)
        duplicate_errors = [e for e in errors if "Duplicate method" in e]
        assert len(duplicate_errors) == 1

    def test_constructor_count_robust_to_complex_class_declaration(self) -> None:
        # The legacy code split class_declaration on whitespace and used
        # the LAST token to find the constructor. For
        # `class Foo extends Bar implements I1, I2 {` the last token is
        # `{`, so the count was always 0 and duplicates were missed.
        from qamigrate.agents.coder import CoderAgent
        from qamigrate.core.config import CoderConfig

        ctor_with_dupe = (
            "    public Foo(String s) { this.s = s; }\n"
            "    public Foo(String s) { this.s = s; }\n"
        )
        code = self._make_code([], ctor=ctor_with_dupe, class_name="Foo")
        agent = CoderAgent.__new__(CoderAgent)
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(code)
        ctor_errors = [e for e in errors if "Multiple constructor" in e]
        assert len(ctor_errors) == 1
