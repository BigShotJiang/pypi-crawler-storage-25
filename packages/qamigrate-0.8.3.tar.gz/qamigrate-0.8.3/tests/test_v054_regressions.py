"""
Regression tests for v0.5.4 bugs found in the v0.5.3 real-project test report.

P0 #1: Passthrough files (enums) still emitted with wrong package declaration.
P0 #2: JUnit5 dep still had <scope>test</scope>, blocking BaseTest.java compile.
"""

from __future__ import annotations

import re
from pathlib import Path

from qamigrate.agents.dependency_injector import DependencyInjector
from qamigrate.intelligence.passthrough import rewrite_package_for_passthrough

# =============================================================================
# P0 #1 -- passthrough files must get .playwright package suffix
# =============================================================================


class TestPassthroughPackageRewrite:
    """rewrite_package_for_passthrough() must update the package declaration
    so copied enums/DTOs don't collide with their originals in Maven."""

    def test_rewrites_simple_package(self) -> None:
        src = "package com.example.config;\npublic enum Env { DEV; }"
        out = rewrite_package_for_passthrough(src)
        assert "package com.example.config.playwright;" in out

    def test_does_not_double_playwright_suffix(self) -> None:
        src = "package com.example.config.playwright;\npublic enum Env { DEV; }"
        out = rewrite_package_for_passthrough(src)
        assert out.count("package com.example.config.playwright;") == 1
        assert "playwright.playwright" not in out

    def test_no_package_declaration_unchanged(self) -> None:
        src = "public enum Env { DEV; }"
        out = rewrite_package_for_passthrough(src)
        assert out == src

    def test_preserves_rest_of_file_verbatim(self) -> None:
        src = (
            "package com.qastarter.config;\n"
            "\n"
            "public enum Environment {\n"
            "    DEV(\"dev\"),\n"
            "    QA(\"qa\");\n"
            "\n"
            "    private final String name;\n"
            "\n"
            "    public String getName() { return name; }\n"
            "}\n"
        )
        out = rewrite_package_for_passthrough(src)
        # Package line changed.
        assert "package com.qastarter.config.playwright;" in out
        # Everything else identical.
        assert "DEV(\"dev\")," in out
        assert "public String getName()" in out

    def test_deep_package_is_rewritten(self) -> None:
        src = "package com.company.project.core.config;\npublic enum Status { OK; }"
        out = rewrite_package_for_passthrough(src)
        assert "package com.company.project.core.config.playwright;" in out

    def test_real_environment_java(self) -> None:
        """End-to-end: the actual Environment.java that triggered the v0.5.3
        bug must get the correct package after rewrite."""
        env_path = Path(
            "samples/selenium-java-project/src/main/java"
            "/com/qastarter/config/Environment.java"
        )
        if not env_path.exists():
            import pytest
            pytest.skip("Sample project not present")

        src = env_path.read_text(encoding="utf-8")
        out = rewrite_package_for_passthrough(src)
        assert re.search(r"package com\.qastarter\.config\.playwright\s*;", out), (
            f"Expected 'package com.qastarter.config.playwright;' in output.\n"
            f"First 3 lines:\n{chr(10).join(out.splitlines()[:3])}"
        )


# =============================================================================
# P0 #2 -- JUnit5 must also have no scope (BaseTest.java in src/main/java)
# =============================================================================


class TestJUnit5ScopeFix:
    """Both Playwright and JUnit5 must be injected without <scope>test</scope>.

    BaseTest.java (and similar lifecycle classes) are generated into
    src/main/java and use JUnit5 annotations (@BeforeAll etc.). Restricting
    JUnit5 to test scope makes it invisible to the Maven compiler for
    main-scope sources, causing 10+ errors in BaseTest.java alone.
    """

    _POM = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""

    def test_junit5_injected_without_scope(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(self._POM)
        DependencyInjector(tmp_path).ensure_playwright_deps("maven")
        content = pom.read_text()

        block = re.search(
            r"<groupId>org\.junit\.jupiter</groupId>.*?</dependency>",
            content, re.DOTALL,
        )
        assert block, "JUnit5 not found in injected pom.xml"
        assert "<scope>" not in block.group(0), (
            "JUnit5 must be compile-scope (no <scope> element). "
            f"Got:\n{block.group(0)}"
        )

    def test_playwright_injected_without_scope(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(self._POM)
        DependencyInjector(tmp_path).ensure_playwright_deps("maven")
        content = pom.read_text()

        block = re.search(
            r"<groupId>com\.microsoft\.playwright</groupId>.*?</dependency>",
            content, re.DOTALL,
        )
        assert block, "Playwright not found in injected pom.xml"
        assert "<scope>" not in block.group(0)

    def test_both_deps_compile_scope_in_needed_deps(self) -> None:
        inj = DependencyInjector(Path("."))
        for dep in inj._needed_deps():
            assert "scope" not in dep, (
                f"{dep['artifact']} must have no 'scope' key. Got: {dep}"
            )
