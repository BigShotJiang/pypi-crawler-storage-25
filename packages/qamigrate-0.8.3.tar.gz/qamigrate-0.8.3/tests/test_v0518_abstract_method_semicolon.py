"""
Regression tests for v0.5.18 — abstract method missing-semicolon postgen fix.

Production project's BrowserFactory.java had 3 compile errors of the form:

    public abstract Browser createBrowser(Playwright playwright)  // comment

Java requires a `;` before the comment. Fix 11 in postgen_fixes adds it.
"""

from __future__ import annotations

from qamigrate.core.postgen_fixes import (
    _fix_abstract_method_missing_semicolon,
    apply_all_postgen_fixes,
)


class TestAbstractMethodSemicolonFix:
    def test_adds_semicolon_when_missing(self) -> None:
        src = "    public abstract Browser createBrowser(Playwright playwright)\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        assert "createBrowser(Playwright playwright);" in out

    def test_adds_semicolon_with_trailing_comment(self) -> None:
        src = "    public abstract Browser createBrowser(Playwright playwright)  // factory\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        # ; comes before the comment, not at end of line
        assert "createBrowser(Playwright playwright);  // factory" in out

    def test_already_has_semicolon_unchanged(self) -> None:
        src = "    public abstract Browser createBrowser(Playwright playwright);\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert not changed
        assert out == src

    def test_already_has_semicolon_with_comment_unchanged(self) -> None:
        src = "    public abstract Browser createBrowser(Playwright playwright);  // ok\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert not changed
        assert out == src

    def test_no_abstract_keyword_short_circuits(self) -> None:
        src = "public Browser createBrowser(Playwright p) { return null; }\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert not changed
        assert out == src

    def test_protected_abstract(self) -> None:
        src = "    protected abstract void run(int x)\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        assert "run(int x);" in out

    def test_concrete_method_body_untouched(self) -> None:
        src = (
            "abstract class Foo {\n"
            "    public abstract void bar()\n"
            "    public void baz() { return; }\n"
            "}\n"
        )
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        assert "public abstract void bar();" in out
        # baz body not touched
        assert "public void baz() { return; }" in out

    def test_generic_return_type(self) -> None:
        src = "    public abstract List<String> names()\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        assert "names();" in out

    def test_qualified_return_type(self) -> None:
        src = "    public abstract com.foo.Bar make()\n"
        out, changed = _fix_abstract_method_missing_semicolon(src)
        assert changed
        assert "make();" in out

    def test_apply_all_includes_abstract_fix(self) -> None:
        src = "    public abstract Browser createBrowser(Playwright p)\n"
        out = apply_all_postgen_fixes(src, file_path="BrowserFactory.java")
        assert "createBrowser(Playwright p);" in out
