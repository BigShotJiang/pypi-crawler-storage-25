"""
Regression tests for v0.8.1 — closed-world verifier now walks
`implements` and `extends` clauses for unresolved type references.

The v0.8 simple-project run hit this exact failure mode:
WaitUtils.java declared an inner `WebElementAdapter implements WebElement`
to maintain Selenium API compatibility — but `WebElement` is a Selenium
type that doesn't exist in the migrated Playwright classpath. javac
emits "WebElementAdapter is not abstract and does not override abstract
method findElement" plus "method does not override or implement a method
from a supertype" for every @Override in the body.

v0.8 caught only `new InventedClass(...)` and method calls. v0.8.1 also
catches `class Foo implements UnknownType` and `class Foo extends
UnknownType`, re-prompting the LLM with a specific feedback message.
"""

from __future__ import annotations


# =============================================================================
# Inheritance-clause resolution
# =============================================================================


class TestInheritanceClauseVerification:
    def test_implements_unresolved_type_flagged(self) -> None:
        """The exact WaitUtils.java pattern from the v0.8 run.

        WebElement is a Selenium type. After migration, the file should
        not import or reference it. Declaring `class Adapter implements
        WebElement` produces cascading override errors.
        """
        from qamigrate.core.closed_world import verify

        code = (
            "import com.microsoft.playwright.Locator;\n"
            "public class WaitUtils {\n"
            "    private static class WebElementAdapter implements WebElement {\n"
            "        private final Locator locator;\n"
            "        public WebElementAdapter(Locator l) { this.locator = l; }\n"
            "    }\n"
            "}\n"
        )
        api = {"WaitUtils": {"method_names": []}}
        issues = verify(code, class_api=api)
        # Only the `implements WebElement` should be flagged.
        impl_issues = [i for i in issues if i.method_name == "<implements>"]
        assert len(impl_issues) == 1
        assert impl_issues[0].receiver_class == "WebElement"

    def test_extends_unresolved_type_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "public class Foo extends UnknownBase {\n"
            "}\n"
        )
        api = {"Foo": {"method_names": []}}
        issues = verify(code, class_api=api)
        ext_issues = [i for i in issues if i.method_name == "<extends>"]
        assert len(ext_issues) == 1
        assert ext_issues[0].receiver_class == "UnknownBase"

    def test_extends_known_class_passes(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "public class LoginPage extends BasePage {\n"
            "    public void click() {}\n"
            "}\n"
        )
        api = {
            "BasePage": {"method_names": ["doSomething"]},
            "LoginPage": {"method_names": ["click"]},
        }
        issues = verify(code, class_api=api)
        # No `<extends>` issues — BasePage is in the project class_api.
        assert not any(i.method_name == "<extends>" for i in issues)

    def test_implements_runtime_exception_passes(self) -> None:
        # RuntimeException is in _COMMON_INHERITANCE_TYPES.
        from qamigrate.core.closed_world import verify

        code = (
            "public class FrameworkException extends RuntimeException {\n"
            "    public FrameworkException(String m) { super(m); }\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        assert not any(i.method_name in ("<extends>", "<implements>") for i in issues)

    def test_multiple_implements_each_checked(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "public class X implements Comparable, UnknownIface, AutoCloseable {\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        # Comparable and AutoCloseable are in the allowlist; UnknownIface is not.
        impl_issues = [i for i in issues if i.method_name == "<implements>"]
        assert len(impl_issues) == 1
        assert impl_issues[0].receiver_class == "UnknownIface"

    def test_generic_type_parameters_stripped(self) -> None:
        # `extends ArrayList<String>` should be checked as `ArrayList`, not
        # `ArrayList<String>`.
        from qamigrate.core.closed_world import verify

        code = (
            "public class StringList extends ArrayList<String> {\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        # ArrayList is in _COMMON_INHERITANCE_TYPES.
        assert not any(i.method_name == "<extends>" for i in issues)

    def test_fqn_inheritance_stripped_to_simple_name(self) -> None:
        # `extends org.junit.runner.notification.RunListener` should be
        # checked as `RunListener` — and skip if it's foreign-imported.
        from qamigrate.core.closed_world import verify

        code = (
            "import org.junit.runner.notification.RunListener;\n"
            "public class MyListener extends RunListener {\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        # RunListener resolves through the foreign import (`org.junit.*`).
        assert not any(i.method_name == "<extends>" for i in issues)

    def test_interface_extending_known_interface_passes(self) -> None:
        # `interface Foo extends Comparable` (interface, not class).
        from qamigrate.core.closed_world import verify

        code = (
            "public interface Foo extends Comparable {\n"
            "    void doIt();\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        assert issues == []

    def test_selenium_import_does_not_excuse_implements(self) -> None:
        """The exact production bug. Even when the LLM `import`s the Selenium
        type, the verifier must STILL flag `implements WebElement` because
        the migrated classpath has no selenium-java jar.
        """
        from qamigrate.core.closed_world import verify

        code = (
            "import org.openqa.selenium.WebElement;\n"
            "import com.microsoft.playwright.Locator;\n"
            "public class WaitUtils {\n"
            "    private static class Adapter implements WebElement {\n"
            "        private final Locator locator;\n"
            "        public Adapter(Locator l) { this.locator = l; }\n"
            "    }\n"
            "}\n"
        )
        api = {"WaitUtils": {"method_names": []}}
        issues = verify(code, class_api=api)
        impl_issues = [i for i in issues if i.method_name == "<implements>"]
        assert len(impl_issues) == 1
        assert impl_issues[0].receiver_class == "WebElement"

    def test_feedback_prompt_renders_implements_message(self) -> None:
        from qamigrate.core.closed_world import (
            UnresolvedReference,
            build_feedback_prompt,
        )

        issues = [
            UnresolvedReference(
                receiver_class="WebElement",
                method_name="<implements>",
                line_number=10,
                suggested=None,
            ),
        ]
        feedback = build_feedback_prompt(issues, class_api={})
        # Mention the inheritance-clause specifically and tell the LLM
        # NOT to declare Selenium-implementing classes.
        assert "implements WebElement" in feedback
        assert "Selenium types" in feedback
        # And the verifier-level header is present.
        assert "Verification failed" in feedback


# =============================================================================
# Regression: existing v0.8 behaviour preserved
# =============================================================================


class TestV08RegressionStillPasses:
    def test_static_call_to_invented_method_still_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = "public class X { void f() { DriverManager.getPage(); } }"
        api = {"DriverManager": {"method_names": ["getDriver"]}}
        issues = verify(code, class_api=api)
        method_issues = [i for i in issues if i.method_name == "getPage"]
        assert len(method_issues) == 1

    def test_invented_class_new_still_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "import com.microsoft.playwright.Locator;\n"
            "public class WaitUtils { Object f(Locator l) "
            "{ return new InventedAdapter(l); } }"
        )
        issues = verify(code, class_api={})
        init_issues = [i for i in issues if i.method_name == "<init>"]
        assert len(init_issues) == 1
        assert init_issues[0].receiver_class == "InventedAdapter"
