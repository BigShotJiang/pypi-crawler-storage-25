"""
Tests for v0.5.13 framework preservation.

QAMigrate now preserves the source project's test framework:
- TestNG project → Playwright + TestNG (not JUnit5)
- JUnit5 project → Playwright + JUnit5 (existing behaviour)
- JUnit4 project → Playwright + JUnit4
"""

from __future__ import annotations

import re
from pathlib import Path

from qamigrate.agents.coder import _build_system_prompt
from qamigrate.agents.dependency_injector import DependencyInjector
from qamigrate.core.postgen_fixes import apply_all_postgen_fixes


# =============================================================================
# Coder prompt: framework-specific lifecycle section
# =============================================================================


class TestCoderPromptFrameworkAware:
    def test_testng_prompt_keeps_before_method(self) -> None:
        p = _build_system_prompt("testng")
        assert "@BeforeMethod stays @BeforeMethod" in p
        assert "@DataProvider" in p
        assert "@Parameters" in p
        assert "@Listeners" in p

    def test_testng_prompt_prohibits_junit5_annotations(self) -> None:
        p = _build_system_prompt("testng")
        # Positive uses of JUnit5 lifecycle annotations must not appear.
        assert "@BeforeAll" not in p
        assert "@AfterAll" not in p
        # The "Do NOT" instruction is correct -- it should be there.
        assert "Do NOT convert to @BeforeEach" in p

    def test_testng_prompt_has_datadriven_scaffold(self) -> None:
        p = _build_system_prompt("testng")
        assert "dataProvider" in p
        assert "@DataProvider" in p

    def test_junit5_prompt_uses_before_each(self) -> None:
        p = _build_system_prompt("junit5")
        assert "@BeforeEach" in p
        assert "@AfterEach" in p
        assert "@BeforeAll" in p
        assert "@AfterAll" in p

    def test_junit4_prompt_has_before_annotation(self) -> None:
        p = _build_system_prompt("junit4")
        assert "@Before" in p
        assert "@After" in p

    def test_unknown_framework_defaults_to_junit5(self) -> None:
        p = _build_system_prompt("unknown_fw")
        p5 = _build_system_prompt("junit5")
        assert p == p5

    def test_system_prompt_module_constant_is_junit5(self) -> None:
        from qamigrate.agents.coder import SYSTEM_PROMPT
        assert "@BeforeEach" in SYSTEM_PROMPT


# =============================================================================
# Postgen fixes: framework-gated rules
# =============================================================================


class TestPostgenFrameworkGating:
    def test_testng_listeners_annotation_preserved(self) -> None:
        src = "@Listeners({TestListener.class})\npublic class T {}"
        out = apply_all_postgen_fixes(src, target_framework="testng")
        assert "@Listeners({TestListener.class})" in out
        assert not re.search(r"@ExtendWith\s*\(", out)

    def test_testng_imports_preserved_on_testng_path(self) -> None:
        src = (
            "import org.testng.ITestListener;\n"
            "import org.testng.annotations.Test;\n"
            "public class T implements ITestListener {}\n"
        )
        out = apply_all_postgen_fixes(src, target_framework="testng")
        assert "import org.testng.ITestListener;" in out
        assert "import org.testng.annotations.Test;" in out

    def test_testng_orphan_imports_still_stripped_on_junit5_path(self) -> None:
        src = (
            "import org.testng.annotations.BeforeMethod;\n"
            "public class T {}\n"  # BeforeMethod not used in body
        )
        out = apply_all_postgen_fixes(src, target_framework="junit5")
        assert "import org.testng.annotations.BeforeMethod;" not in out

    def test_selenium_imports_stripped_on_both_paths(self) -> None:
        src = "import org.openqa.selenium.WebDriver;\npublic class Foo {}\n"
        for fw in ("testng", "junit5"):
            out = apply_all_postgen_fixes(src, target_framework=fw)
            assert "org.openqa.selenium.WebDriver" not in out

    def test_framework_neutral_fixes_run_on_testng_path(self) -> None:
        src = (
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "ScreenshotOptions opts;\n"
        )
        out = apply_all_postgen_fixes(src, target_framework="testng")
        assert "import com.microsoft.playwright.options.ScreenshotOptions" not in out
        assert "Page.ScreenshotOptions" in out


# =============================================================================
# Dependency injector: framework-specific dep
# =============================================================================


class TestDependencyInjectorFrameworkAware:
    def test_testng_project_gets_testng_dep(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(_minimal_pom())
        inj = DependencyInjector(
            tmp_path, test_framework="testng", test_framework_version="7.9.0"
        )
        inj.ensure_playwright_deps("maven")
        content = pom.read_text()
        assert "<groupId>org.testng</groupId>" in content
        assert "<version>7.9.0</version>" in content
        assert "<groupId>org.junit.jupiter</groupId>" not in content

    def test_junit5_project_gets_junit5_dep(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(_minimal_pom())
        DependencyInjector(tmp_path, test_framework="junit5").ensure_playwright_deps("maven")
        content = pom.read_text()
        assert "<groupId>org.junit.jupiter</groupId>" in content
        assert "<groupId>org.testng</groupId>" not in content

    def test_junit4_project_gets_junit4_dep(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(_minimal_pom())
        DependencyInjector(tmp_path, test_framework="junit4").ensure_playwright_deps("maven")
        content = pom.read_text()
        assert "<groupId>junit</groupId>" in content
        assert "<artifactId>junit</artifactId>" in content

    def test_playwright_always_injected(self, tmp_path: Path) -> None:
        pom = tmp_path / "pom.xml"
        pom.write_text(_minimal_pom())
        for fw in ("testng", "junit4", "junit5"):
            pom.write_text(_minimal_pom())
            DependencyInjector(tmp_path, test_framework=fw).ensure_playwright_deps("maven")
            assert "com.microsoft.playwright" in pom.read_text(), f"Playwright missing for {fw}"

    def test_testng_fallback_version_when_none_given(self) -> None:
        from qamigrate.agents.dependency_injector import TESTNG_FALLBACK_VERSION
        inj = DependencyInjector(Path("."), test_framework="testng")
        deps = inj._needed_deps()
        fw = next(d for d in deps if d["artifact"] == "testng")
        assert fw["version"] == TESTNG_FALLBACK_VERSION

    def test_needed_deps_returns_playwright_plus_framework(self) -> None:
        for fw in ("testng", "junit4", "junit5"):
            inj = DependencyInjector(Path("."), test_framework=fw)
            deps = inj._needed_deps()
            assert len(deps) == 2
            artifacts = {d["artifact"] for d in deps}
            assert "playwright" in artifacts


def _minimal_pom() -> str:
    return """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.seleniumhq.selenium</groupId>
            <artifactId>selenium-java</artifactId>
            <version>4.15.0</version>
        </dependency>
    </dependencies>
</project>
"""
