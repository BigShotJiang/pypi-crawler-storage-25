"""
Regression tests for v0.5.16 production-grade fixes.

Based on the 85-file AutomationFrameworkSelenium enterprise project run.

Fix 1: N/A prose injection stripped from generated Java source.
Fix 2: Wall-clock Fixer timeout (max_fix_seconds config).
Fix 3+4: @interface annotation types + Lombok @Config passthrough.
Fix 5: Non-Selenium infrastructure passthrough (javax.mail, AWT Robot, screen recording).
Fix 6: No-arg enum constant separator (STOP_ON_FAILURE; -> ,).
Fix 7: Failed-file sibling imports stay at original package (already correct by design).
"""

from __future__ import annotations

from pathlib import Path

import pytest

from qamigrate.core.postgen_fixes import (
    _fix_enum_separator,
    _fix_na_prose_injection,
    apply_all_postgen_fixes,
)
from qamigrate.intelligence.passthrough import is_passthrough


# =============================================================================
# Fix 1 -- N/A prose line injection
# =============================================================================


class TestNAProseFix:
    def test_strips_na_dash_line(self) -> None:
        src = "public class Foo {\n    N/A - Utility class with static methods\n}\n"
        out, changed = _fix_na_prose_injection(src)
        assert changed
        assert "N/A" not in out

    def test_strips_na_with_em_dash(self) -> None:
        src = "public class Foo {\n    N/A — No constructor needed\n}\n"
        out, changed = _fix_na_prose_injection(src)
        assert changed
        assert "N/A" not in out

    def test_strips_na_colon_form(self) -> None:
        src = "N/A: This file has no Selenium code\npublic class Foo {}\n"
        out, changed = _fix_na_prose_injection(src)
        assert changed
        assert "N/A" not in out

    def test_case_insensitive(self) -> None:
        src = "n/a - not applicable\npublic class Foo {}\n"
        out, changed = _fix_na_prose_injection(src)
        assert changed
        assert "n/a" not in out

    def test_normal_java_unchanged(self) -> None:
        src = "package com.example;\npublic class Foo { void bar() {} }\n"
        out, changed = _fix_na_prose_injection(src)
        assert not changed

    def test_apply_all_includes_na_fix(self) -> None:
        src = (
            "package com.example.playwright;\n"
            "N/A - Utility class with static methods only\n"
            "public class Log { public static void info(String msg) {} }\n"
        )
        out = apply_all_postgen_fixes(src)
        assert "N/A" not in out
        assert "public class Log" in out


# =============================================================================
# Fix 2 -- wall-clock Fixer timeout config
# =============================================================================


class TestFixerTimeout:
    def test_max_fix_seconds_in_config(self) -> None:
        from qamigrate.core.config import FixerConfig
        cfg = FixerConfig()
        assert hasattr(cfg, "max_fix_seconds")
        assert cfg.max_fix_seconds == 300  # default

    def test_max_fix_seconds_bounded(self) -> None:
        from pydantic import ValidationError
        from qamigrate.core.config import FixerConfig
        with pytest.raises(ValidationError):
            FixerConfig(max_fix_seconds=10)  # below minimum of 30
        with pytest.raises(ValidationError):
            FixerConfig(max_fix_seconds=9999)  # above maximum of 3600

    def test_custom_max_fix_seconds(self) -> None:
        from qamigrate.core.config import FixerConfig
        cfg = FixerConfig(max_fix_seconds=60)
        assert cfg.max_fix_seconds == 60


# =============================================================================
# Fix 3+4 -- @interface and Lombok @Config passthrough
# =============================================================================


class TestAnnotationInterfacePassthrough:
    def test_annotation_interface_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "FrameworkAnnotation.java"
        f.write_text(
            "package com.example;\n"
            "import java.lang.annotation.*;\n"
            "@Retention(RetentionPolicy.RUNTIME)\n"
            "@Target(ElementType.METHOD)\n"
            "public @interface FrameworkAnnotation {\n"
            "    String author() default \"\";\n"
            "    String category() default \"\";\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True
        assert "@interface" in (reason or "")

    def test_lombok_config_interface_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "Configuration.java"
        f.write_text(
            "package com.example;\n"
            "import org.aeonbits.owner.Config;\n"
            "@Config.Sources({\"system:properties\", \"classpath:config.properties\"})\n"
            "public interface Configuration extends Config {\n"
            "    String browser();\n"
            "    String baseUrl();\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True

    def test_owner_aeonbits_marker_triggers_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "AppConfig.java"
        f.write_text(
            "package com.example;\n"
            "import org.aeonbits.owner.Config;\n"
            "public interface AppConfig extends Config {\n"
            "    String env();\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True

    def test_annotation_interface_with_selenium_still_migrated(self, tmp_path: Path) -> None:
        # If somehow Selenium appears inside an @interface, don't passthrough.
        f = tmp_path / "WeirdAnnotation.java"
        f.write_text(
            "package com.example;\n"
            "import org.openqa.selenium.WebDriver;\n"
            "public @interface WeirdAnnotation { }\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is False  # Selenium present -> must migrate


# =============================================================================
# Fix 5 -- Infrastructure-only passthrough
# =============================================================================


class TestInfrastructurePassthrough:
    def test_javax_mail_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "EmailUtils.java"
        f.write_text(
            "package com.example;\n"
            "import javax.mail.Session;\n"
            "import javax.mail.Transport;\n"
            "public class EmailUtils {\n"
            "    public static void sendEmail(String to, String subject) {\n"
            "        // send email\n"
            "    }\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True
        assert "infrastructure" in (reason or "")

    def test_awt_robot_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "ScreenRecorder.java"
        f.write_text(
            "package com.example;\n"
            "import java.awt.Robot;\n"
            "import java.awt.Rectangle;\n"
            "public class ScreenRecorder {\n"
            "    public static void startRecording() { }\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True

    def test_monte_media_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "CaptureHelpers.java"
        f.write_text(
            "package com.example;\n"
            "import org.monte.media.Format;\n"
            "import org.monte.screenrecorder.ScreenRecorder;\n"
            "public class CaptureHelpers { }\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True

    def test_javax_mail_with_selenium_still_migrated(self, tmp_path: Path) -> None:
        # If Selenium also appears, migration is needed.
        f = tmp_path / "Mixed.java"
        f.write_text(
            "package com.example;\n"
            "import javax.mail.Transport;\n"
            "import org.openqa.selenium.WebDriver;\n"
            "public class Mixed { }\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is False  # Selenium present -> migrate


# =============================================================================
# v0.5.16: Comment-stripped Selenium check (false-positive fix)
# =============================================================================


class TestSeleniumCommentFalsePositive:
    def test_selenium_in_header_comment_does_not_block_passthrough(
        self, tmp_path: Path
    ) -> None:
        # Header comment mentions "Selenium" but file has no Selenium API.
        # This is a constants-only class — should passthrough.
        f = tmp_path / "EmailConfig.java"
        f.write_text(
            "/*\n"
            " * Automation Framework Selenium - Author Name\n"
            " */\n"
            "package com.example.mail;\n"
            "public class EmailConfig {\n"
            "    public static final String SERVER = \"smtp.gmail.com\";\n"
            "    public static final String PORT = \"587\";\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True
        assert reason is not None

    def test_selenium_in_javadoc_does_not_block_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "MailConstants.java"
        f.write_text(
            "package com.example;\n"
            "/** Email constants for our Selenium test framework. */\n"
            "public class MailConstants {\n"
            "    public static final String HOST = \"localhost\";\n"
            "}\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is True

    def test_selenium_in_actual_code_still_blocks_passthrough(self, tmp_path: Path) -> None:
        # If "Selenium" appears in actual code (rare, e.g. a string literal
        # that uses the bare word), the safer choice is still to migrate.
        f = tmp_path / "RealSeleniumUser.java"
        f.write_text(
            "package com.example;\n"
            "public class RealSeleniumUser {\n"
            "    String tool = \"Selenium\";\n"
            "    public void doStuff() {}\n"
            "}\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is False


# =============================================================================
# v0.5.16: Constants-class passthrough
# =============================================================================


class TestConstantsClassPassthrough:
    def test_pure_constants_class_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "AppConstants.java"
        f.write_text(
            "package com.example;\n"
            "public class AppConstants {\n"
            "    public static final String API_URL = \"https://api.example.com\";\n"
            "    public static final int TIMEOUT = 30;\n"
            "}\n"
        )
        pt, reason = is_passthrough(f)
        assert pt is True
        assert "constants" in (reason or "")

    def test_class_with_instance_method_not_constants(self, tmp_path: Path) -> None:
        f = tmp_path / "Greeter.java"
        f.write_text(
            "package com.example;\n"
            "public class Greeter {\n"
            "    public static final String PREFIX = \"Hello\";\n"
            "    public String greet(String name) { return PREFIX + name; }\n"
            "}\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is False  # has instance method

    def test_constants_class_with_selenium_not_passthrough(self, tmp_path: Path) -> None:
        f = tmp_path / "TestConstants.java"
        f.write_text(
            "package com.example;\n"
            "import org.openqa.selenium.WebDriver;\n"
            "public class TestConstants {\n"
            "    public static final WebDriver DRIVER = null;\n"
            "}\n"
        )
        pt, _ = is_passthrough(f)
        assert pt is False  # Selenium present


# =============================================================================
# Fix 6 -- No-arg enum separator
# =============================================================================


class TestNoArgEnumSeparator:
    def test_fixes_semicolons_to_commas(self) -> None:
        src = (
            "public enum FailureHandling {\n"
            "    STOP_ON_FAILURE;\n"
            "    CONTINUE_ON_FAILURE;\n"
            "    OPTIONAL;\n"
            "}\n"
        )
        out, changed = _fix_enum_separator(src)
        assert changed
        assert "STOP_ON_FAILURE," in out
        assert "CONTINUE_ON_FAILURE," in out
        # Last constant keeps semicolon (or the closing brace is enough)
        assert "OPTIONAL" in out

    def test_enum_with_args_unchanged(self) -> None:
        # Enums with constructor args should not be touched by this rule.
        src = (
            "public enum Browser {\n"
            "    CHROME(\"chrome\"),\n"
            "    FIREFOX(\"firefox\");\n"
            "    Browser(String name) {}\n"
            "}\n"
        )
        out, changed = _fix_enum_separator(src)
        # The existing commas mean this may or may not fire, but it must not corrupt
        assert "CHROME(\"chrome\")" in out
        assert "FIREFOX(\"firefox\")" in out

    def test_non_enum_unchanged(self) -> None:
        src = "public class Foo { void bar(); }\n"
        out, changed = _fix_enum_separator(src)
        assert not changed

    def test_apply_all_includes_enum_fix(self) -> None:
        src = (
            "package com.example.playwright;\n"
            "public enum Status {\n"
            "    ACTIVE;\n"
            "    INACTIVE;\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src)
        assert "ACTIVE," in out
