"""
Regression tests for v0.6.0 — ProjectMap-driven coder context enhancements.

Three improvements driven by the v0.5.18 production run on
`AutomationFrameworkSelenium`:

1. **Constructor capture in parser.** Tree-sitter `constructor_declaration`
   nodes were being silently skipped. The LLM had no idea what
   `FrameworkException` / `InvalidPathForExtentReportFileException`
   constructors actually accepted, so it invented `(String, Throwable)`
   overloads against single-arg classes.

2. **Overload set surfacing in prompt context.** Even when methods were
   captured, the prompt listed them flat. The LLM produced
   `LogUtils.error(String, Exception)` calls against a 1-arg method
   because nothing told it those were the ONLY overloads.

3. **Inherited ThreadLocal / static field callout.** When a subclass
   inherits `private static ThreadLocal<WebDriver> driver` from its
   base, generated subclasses sometimes omitted the field declaration
   while still calling `driver.get()` — producing 12+ `cannot find
   symbol` errors per file.
"""

from __future__ import annotations

from qamigrate.core.parser import JavaParser
from qamigrate.intelligence.project_map import (
    ClassInfo,
    ClassRole,
    DependencyEdge,
    DependencyKind,
    FieldInfo,
    MethodInfo,
    ParameterInfo,
    ProjectMap,
)
from qamigrate.intelligence.prompt_context import format_project_context


# =============================================================================
# Helpers
# =============================================================================


def _ctor(name: str, params: list[tuple[str, str]], modifiers: list[str] | None = None) -> MethodInfo:
    """Build a constructor MethodInfo (return_type='')."""
    return MethodInfo(
        name=name,
        modifiers=modifiers or ["public"],
        return_type="",
        parameters=[ParameterInfo(name=n, type=t) for t, n in params],
        annotations=[],
        body="{ super(message); }",
        line=1,
    )


def _method(
    name: str,
    return_type: str,
    params: list[tuple[str, str]] | None = None,
    modifiers: list[str] | None = None,
) -> MethodInfo:
    return MethodInfo(
        name=name,
        modifiers=modifiers or ["public", "static"],
        return_type=return_type,
        parameters=[ParameterInfo(name=n, type=t) for t, n in (params or [])],
        annotations=[],
        body="{ return; }",
        line=1,
    )


def _class(
    *,
    fqn: str,
    role: ClassRole = ClassRole.OTHER,
    extends: str | None = None,
    public_methods: list[MethodInfo] | None = None,
    fields: list[FieldInfo] | None = None,
) -> ClassInfo:
    name = fqn.rsplit(".", 1)[-1]
    package = fqn.rsplit(".", 1)[0] if "." in fqn else ""
    return ClassInfo(
        name=name,
        fqn=fqn,
        file_path=f"src/{name}.java",
        package=package,
        extends=extends,
        implements=[],
        modifiers=["public"],
        imports=[],
        role=role,
        public_methods=public_methods or [],
        fields=fields or [],
        role_summary=f"{name} role summary",
    )


# =============================================================================
# 1. Constructor signature capture (parser + MethodInfo.signature)
# =============================================================================


class TestConstructorCapture:
    def test_signature_omits_void_for_constructor(self) -> None:
        ctor = _ctor("FrameworkException", [("String", "message")])
        assert ctor.is_constructor is True
        assert ctor.signature == "public FrameworkException(String message)"

    def test_signature_handles_multi_arg_constructor(self) -> None:
        ctor = _ctor(
            "FrameworkException",
            [("String", "message"), ("Throwable", "cause")],
        )
        assert ctor.signature == "public FrameworkException(String message, Throwable cause)"

    def test_regular_method_still_renders_return_type(self) -> None:
        m = _method("getName", "String", [], ["public"])
        assert m.is_constructor is False
        assert m.signature == "public String getName()"

    def test_parser_extracts_constructor(self, tmp_path) -> None:
        # End-to-end: real Java source through tree-sitter.
        src = """\
package com.example;

public class FrameworkException extends RuntimeException {
    public FrameworkException(String message) {
        super(message);
    }
}
"""
        p = tmp_path / "FrameworkException.java"
        p.write_text(src, encoding="utf-8")
        parser = JavaParser()
        info = parser.extract_class_info(p)
        # The flat methods list should contain exactly one entry — the constructor.
        assert len(info["methods"]) == 1
        ctor = info["methods"][0]
        assert ctor["name"] == "FrameworkException"
        assert ctor["return_type"] == ""
        assert len(ctor["parameters"]) == 1
        assert ctor["parameters"][0]["type"] == "String"

    def test_parser_distinguishes_constructor_from_method(self, tmp_path) -> None:
        src = """\
package com.example;

public class Mixed {
    public Mixed(String s) { this.s = s; }
    public String getS() { return s; }
}
"""
        p = tmp_path / "Mixed.java"
        p.write_text(src, encoding="utf-8")
        parser = JavaParser()
        info = parser.extract_class_info(p)
        methods = info["methods"]
        assert len(methods) == 2
        names_and_returns = {(m["name"], m["return_type"]) for m in methods}
        assert ("Mixed", "") in names_and_returns
        assert ("getS", "String") in names_and_returns


# =============================================================================
# 2. Overload set surfacing in prompt context
# =============================================================================


class TestOverloadSurfacing:
    def _pm_with_log_util(self, *log_methods: MethodInfo) -> ProjectMap:
        pm = ProjectMap(project_path=".", project_name="t")
        # Migrating class — has a STATIC_CALL into LogUtils.
        pm.classes["com.example.MyTest"] = _class(
            fqn="com.example.MyTest",
            role=ClassRole.TEST,
            public_methods=[_method("test1", "void")],
        )
        pm.classes["com.example.utils.LogUtils"] = _class(
            fqn="com.example.utils.LogUtils",
            role=ClassRole.UTILITY,
            public_methods=list(log_methods),
        )
        pm.edges.append(
            DependencyEdge(
                source="com.example.MyTest",
                target="com.example.utils.LogUtils",
                kind=DependencyKind.STATIC_CALL,
                symbol="error",
            )
        )
        return pm

    def test_single_method_no_overload_section(self) -> None:
        # Only one `error` method — no overload framing needed.
        pm = self._pm_with_log_util(
            _method("error", "void", [("String", "msg")])
        )
        ctx = format_project_context(pm, migrating_fqn="com.example.MyTest")
        assert "Method overload sets" not in ctx
        # Signature still shown.
        assert "void error(String msg)" in ctx

    def test_two_overloads_get_explicit_overload_callout(self) -> None:
        # The exact production case: 1-arg vs 2-arg `error` overloads.
        pm = self._pm_with_log_util(
            _method("error", "void", [("String", "msg")]),
            _method("error", "void", [("String", "msg"), ("Throwable", "t")]),
        )
        ctx = format_project_context(pm, migrating_fqn="com.example.MyTest")
        assert "Method overload sets" in ctx
        assert "ONLY overloads" in ctx
        assert "void error(String msg)" in ctx
        assert "void error(String msg, Throwable t)" in ctx

    def test_constructors_listed_first_with_no_invent_warning(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        pm.classes["com.example.MyClass"] = _class(
            fqn="com.example.MyClass",
            role=ClassRole.TEST,
            public_methods=[_method("doIt", "void")],
        )
        pm.classes["com.example.errors.FrameworkException"] = _class(
            fqn="com.example.errors.FrameworkException",
            role=ClassRole.OTHER,
            public_methods=[_ctor("FrameworkException", [("String", "msg")])],
        )
        pm.edges.append(
            DependencyEdge(
                source="com.example.MyClass",
                target="com.example.errors.FrameworkException",
                kind=DependencyKind.INSTANTIATES,
                symbol="FrameworkException",
            )
        )
        ctx = format_project_context(pm, migrating_fqn="com.example.MyClass")
        assert "Available constructors" in ctx
        assert "do NOT invent additional overloads" in ctx
        assert "public FrameworkException(String msg)" in ctx


# =============================================================================
# 3. Inherited ThreadLocal / static field callout
# =============================================================================


class TestInheritedFieldsCallout:
    def test_threadlocal_field_surfaced(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        base = _class(
            fqn="com.example.BaseTest",
            role=ClassRole.BASE,
            fields=[
                FieldInfo(
                    name="driver",
                    type="ThreadLocal<WebDriver>",
                    modifiers=["private", "static", "final"],
                    annotations=[],
                    line=1,
                )
            ],
        )
        child = _class(
            fqn="com.example.LoginTest",
            role=ClassRole.TEST,
            extends="com.example.BaseTest",
        )
        pm.classes[base.fqn] = base
        pm.classes[child.fqn] = child
        pm.edges.append(
            DependencyEdge(
                source=child.fqn,
                target=base.fqn,
                kind=DependencyKind.EXTENDS,
            )
        )
        ctx = format_project_context(pm, migrating_fqn=child.fqn)
        assert "Inherited fields from `BaseTest`" in ctx
        assert "DO NOT redeclare" in ctx
        assert "ThreadLocal<WebDriver> driver" in ctx

    def test_no_callout_when_no_threadlocal_or_static(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        base = _class(
            fqn="com.example.BaseTest",
            role=ClassRole.BASE,
            fields=[
                FieldInfo(
                    name="instanceVar",
                    type="String",
                    modifiers=["private"],  # not static, not infra-typed
                    annotations=[],
                    line=1,
                )
            ],
        )
        child = _class(
            fqn="com.example.LoginTest",
            role=ClassRole.TEST,
            extends="com.example.BaseTest",
        )
        pm.classes[base.fqn] = base
        pm.classes[child.fqn] = child
        pm.edges.append(
            DependencyEdge(
                source=child.fqn,
                target=base.fqn,
                kind=DependencyKind.EXTENDS,
            )
        )
        ctx = format_project_context(pm, migrating_fqn=child.fqn)
        assert "Inherited fields from" not in ctx

    def test_no_callout_when_no_parent(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        standalone = _class(
            fqn="com.example.MyTest",
            role=ClassRole.TEST,
            extends=None,
        )
        pm.classes[standalone.fqn] = standalone
        ctx = format_project_context(pm, migrating_fqn=standalone.fqn)
        assert "Inherited fields from" not in ctx

    def test_static_logger_field_surfaced(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        base = _class(
            fqn="com.example.BaseTest",
            role=ClassRole.BASE,
            fields=[
                FieldInfo(
                    name="LOGGER",
                    type="Logger",
                    modifiers=["protected", "static", "final"],
                    annotations=[],
                    line=1,
                )
            ],
        )
        child = _class(
            fqn="com.example.LoginTest",
            role=ClassRole.TEST,
            extends="com.example.BaseTest",
        )
        pm.classes[base.fqn] = base
        pm.classes[child.fqn] = child
        pm.edges.append(
            DependencyEdge(
                source=child.fqn,
                target=base.fqn,
                kind=DependencyKind.EXTENDS,
            )
        )
        ctx = format_project_context(pm, migrating_fqn=child.fqn)
        assert "Logger LOGGER" in ctx


# =============================================================================
# 4. Don't-invent guidance text
# =============================================================================


class TestDoNotInventGuidance:
    def test_anti_invention_phrasing_present(self) -> None:
        pm = ProjectMap(project_path=".", project_name="t")
        pm.classes["com.example.MyTest"] = _class(
            fqn="com.example.MyTest",
            role=ClassRole.TEST,
            public_methods=[_method("test1", "void")],
        )
        pm.classes["com.example.utils.LogUtils"] = _class(
            fqn="com.example.utils.LogUtils",
            role=ClassRole.UTILITY,
            public_methods=[_method("info", "void", [("String", "m")])],
        )
        pm.edges.append(
            DependencyEdge(
                source="com.example.MyTest",
                target="com.example.utils.LogUtils",
                kind=DependencyKind.STATIC_CALL,
                symbol="info",
            )
        )
        ctx = format_project_context(pm, migrating_fqn="com.example.MyTest")
        # The header phrasing tells the Coder explicitly NOT to invent overloads.
        assert "do NOT invent constructor or method overloads" in ctx
