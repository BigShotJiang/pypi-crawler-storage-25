"""
Regression tests for v0.5.19.

Two fixes shipped:

1. **Fix 12 — doubled method header** (`postgen_fixes.py`).
   Production project's ExtentReportManager.java had 6 errors of the form:
       synchronized public static void addAuthors(String[] authors)
       synchronized public static void addAuthors(String[] authors) {
           ...
       }
   The header repeats verbatim before the body opens. Postgen rule collapses
   the duplicate while leaving genuine overloads (different param lists) alone.

2. **Hard usage-cap detection** (`llm/retry.py`).
   Anthropic / OpenAI account-level quota errors are NOT transient — every
   retry burns more budget on calls that are guaranteed to fail. The retry
   helper now raises `LLMUsageCapExhausted` immediately so the pipeline
   short-circuits with a clear message.
"""

from __future__ import annotations

import pytest

from qamigrate.core.postgen_fixes import (
    _fix_doubled_method_header,
    apply_all_postgen_fixes,
)
from qamigrate.llm.errors import LLMUsageCapExhausted
from qamigrate.llm.retry import (
    call_with_retry,
    is_rate_limit_error,
    is_usage_cap_error,
)


# =============================================================================
# Fix 12 — doubled method header
# =============================================================================


class TestDoubledMethodHeader:
    def test_collapses_simple_doubled_header(self) -> None:
        src = (
            "    public static void foo(String x)\n"
            "    public static void foo(String x) {\n"
            "        System.out.println(x);\n"
            "    }\n"
        )
        out, changed = _fix_doubled_method_header(src)
        assert changed
        # Only one header should remain.
        assert out.count("public static void foo(String x)") == 1
        assert "{\n        System.out.println(x);" in out

    def test_collapses_synchronized_modifier_chain(self) -> None:
        # The exact pattern from ExtentReportManager.java.
        src = (
            "    synchronized public static void addAuthors(String[] authors)\n"
            "    synchronized public static void addAuthors(String[] authors) {\n"
            "        for (String a : authors) {}\n"
            "    }\n"
        )
        out, changed = _fix_doubled_method_header(src)
        assert changed
        assert out.count("synchronized public static void addAuthors") == 1

    def test_preserves_real_overloads(self) -> None:
        # Two methods with different param lists — must NOT be collapsed.
        src = (
            "    public void foo(String x) { }\n"
            "    public void foo(int x) { }\n"
        )
        out, changed = _fix_doubled_method_header(src)
        assert not changed
        assert out == src

    def test_preserves_methods_with_different_modifiers(self) -> None:
        # Same name and args, but `static` vs not — different signatures
        # textually, so left alone.
        src = (
            "    public static void foo(String x) { }\n"
            "    public void foo(String x) { }\n"
        )
        out, changed = _fix_doubled_method_header(src)
        assert not changed
        assert out == src

    def test_no_method_unchanged(self) -> None:
        src = "public class Foo {\n    int x;\n}\n"
        out, changed = _fix_doubled_method_header(src)
        assert not changed
        assert out == src

    def test_already_correct_unchanged(self) -> None:
        src = (
            "    public static void foo(String x) {\n"
            "        return;\n"
            "    }\n"
        )
        out, changed = _fix_doubled_method_header(src)
        assert not changed
        assert out == src

    def test_apply_all_includes_doubled_header_fix(self) -> None:
        src = (
            "public class Bar {\n"
            "    public void run()\n"
            "    public void run() {\n"
            "        return;\n"
            "    }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="Bar.java")
        assert out.count("public void run()") == 1


# =============================================================================
# Hard usage-cap detection
# =============================================================================


class TestUsageCapClassification:
    def test_anthropic_usage_limit_message(self) -> None:
        err = Exception(
            "You have reached your specified API usage limits. "
            "You will regain access on 2026-05-01"
        )
        assert is_usage_cap_error(err)

    def test_openai_insufficient_quota(self) -> None:
        err = Exception(
            "Error code: 429 - insufficient_quota — You exceeded your current quota"
        )
        assert is_usage_cap_error(err)

    def test_regain_access_phrase_alone(self) -> None:
        err = Exception("Account suspended; will regain access shortly")
        assert is_usage_cap_error(err)

    def test_plain_rate_limit_is_not_usage_cap(self) -> None:
        # Transient 429s should NOT classify as a hard cap.
        err = Exception("rate_limit_error: please retry after 30 seconds")
        assert not is_usage_cap_error(err)
        assert is_rate_limit_error(err)

    def test_random_error_unclassified(self) -> None:
        err = Exception("connection refused")
        assert not is_usage_cap_error(err)


class TestCallWithRetryUsageCap:
    def test_usage_cap_raises_immediately_no_retry(self) -> None:
        calls = {"n": 0}

        def fail_with_cap() -> None:
            calls["n"] += 1
            raise Exception(
                "You have reached your specified API usage limits. "
                "Regain access on 2026-05-01"
            )

        with pytest.raises(LLMUsageCapExhausted):
            call_with_retry(fail_with_cap, max_retries=5, initial_backoff=0.01)

        # Critical: must not retry. Burning budget on guaranteed-failing
        # calls is exactly what this fix prevents.
        assert calls["n"] == 1

    def test_usage_cap_propagates_unchanged_when_already_typed(self) -> None:
        # If an inner caller already raised LLMUsageCapExhausted, propagate
        # without re-wrapping (idempotency).
        def fail() -> None:
            raise LLMUsageCapExhausted("already classified")

        with pytest.raises(LLMUsageCapExhausted) as exc_info:
            call_with_retry(fail, max_retries=3, initial_backoff=0.01)
        assert "already classified" in str(exc_info.value)

    def test_rate_limit_still_retries(self) -> None:
        # Sanity check: the cap path doesn't break normal rate-limit retry.
        calls = {"n": 0}

        def fail_then_succeed() -> str:
            calls["n"] += 1
            if calls["n"] < 2:
                raise Exception("rate_limit_error: too many requests")
            return "ok"

        result = call_with_retry(
            fail_then_succeed, max_retries=3, initial_backoff=0.01
        )
        assert result == "ok"
        assert calls["n"] == 2
