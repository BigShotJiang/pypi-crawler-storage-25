"""
Regression tests for v0.5.9 fixes.

Fix 1: Confidence gate uses raise typer.Exit(code=2) reliably on all platforms.
Fix 2: @Listeners guard — safe TODO comment when listener doesn't implement Extension.
Fix 3: Locator.State.X → WaitForSelectorState.X postgen rule.
"""

from __future__ import annotations

from qamigrate.core.postgen_fixes import (
    _fix_listeners_annotation,
    _fix_locator_state_enum,
    apply_all_postgen_fixes,
)


# =============================================================================
# Fix 1 -- gate exit code
# =============================================================================


class TestGateExitCode:
    def test_gate_uses_typer_exit_code_2(self) -> None:
        import inspect
        import qamigrate.cli.main as cli
        src = inspect.getsource(cli)
        # Must have the named-arg form typer.Exit(code=2).
        assert "typer.Exit(code=2)" in src, (
            "Confidence gate must use raise typer.Exit(code=2)"
        )

    def test_no_failed_count_typer_exit_1_positional(self) -> None:
        """failed_count path must also use named-arg form for clarity."""
        import inspect
        import qamigrate.cli.main as cli
        src = inspect.getsource(cli)
        # typer.Exit(code=1) or typer.Exit(1) for failed_count -- either fine,
        # but we specifically check typer.Exit(2) uses code= form.
        assert "typer.Exit(code=2)" in src


# =============================================================================
# Fix 2 -- @Listeners guard
# =============================================================================


class TestListenersGuard:
    def test_unknown_listener_gets_todo_not_extendwith(self) -> None:
        """When extension_classes not provided, @Listeners is replaced with
        a safe TODO comment -- not a broken @ExtendWith."""
        import re
        src = "@Listeners({TestListener.class})\npublic class T {}"
        out, changed = _fix_listeners_annotation(src)
        assert changed
        # The annotation form must be gone.
        assert not re.search(r"@Listeners\s*\(", out)
        # No @ExtendWith annotation (may appear in TODO comment, that's ok).
        assert not re.search(r"@ExtendWith\s*\(", out)
        assert "// TODO" in out
        assert "TestListener" in out  # named in the TODO for traceability

    def test_confirmed_extension_gets_extendwith(self) -> None:
        """When caller confirms listener implements Extension, apply @ExtendWith."""
        src = "@Listeners({MyExt.class})\npublic class T {}"
        out, changed = _fix_listeners_annotation(src, extension_classes={"MyExt"})
        assert changed
        assert "@ExtendWith(MyExt.class)" in out
        assert "TODO" not in out

    def test_mixed_confirmed_and_unknown_gets_todo(self) -> None:
        """If ANY listener is not confirmed, use the safe TODO path."""
        import re
        src = "@Listeners({ConfirmedExt.class, UnknownListener.class})\npublic class T {}"
        out, changed = _fix_listeners_annotation(
            src, extension_classes={"ConfirmedExt"}
        )
        assert changed
        # UnknownListener is not confirmed -> safe path for the whole annotation.
        assert "// TODO" in out
        assert not re.search(r"@ExtendWith\s*\(", out)

    def test_todo_comment_is_compile_safe(self) -> None:
        """The emitted TODO must be a Java comment, not an annotation or
        statement that would cause a compile error."""
        src = "@Listeners({X.class})\npublic class T {}"
        out, _ = _fix_listeners_annotation(src)
        # Every non-blank line before 'public class' must be a comment or empty.
        lines_before_class = out.split("public class")[0].strip().splitlines()
        for line in lines_before_class:
            line = line.strip()
            if line:
                assert line.startswith("//") or line.startswith("/*") or line.startswith("*"), (
                    f"Non-comment line before class: {line!r}"
                )


# =============================================================================
# Fix 3 -- Locator.State -> WaitForSelectorState
# =============================================================================


class TestLocatorStateEnumFix:
    def test_replaces_locator_state(self) -> None:
        src = (
            "page.locator(sel).waitFor(\n"
            "    new Locator.WaitForOptions().setState(Locator.State.HIDDEN)\n"
            ");\n"
        )
        out, changed = _fix_locator_state_enum(src)
        assert changed
        assert "WaitForSelectorState.HIDDEN" in out
        assert "Locator.State.HIDDEN" not in out
        assert "import com.microsoft.playwright.options.WaitForSelectorState;" in out

    def test_all_state_values_replaced(self) -> None:
        for state in ("HIDDEN", "VISIBLE", "ATTACHED", "DETACHED"):
            src = f"Locator.State.{state}"
            out, changed = _fix_locator_state_enum(src)
            assert changed
            assert f"WaitForSelectorState.{state}" in out

    def test_no_locator_state_unchanged(self) -> None:
        src = "page.locator(sel).click();\n"
        out, changed = _fix_locator_state_enum(src)
        assert not changed
        assert out == src

    def test_import_not_doubled(self) -> None:
        src = (
            "import com.microsoft.playwright.options.WaitForSelectorState;\n"
            "Locator.State.VISIBLE\n"
        )
        out, _ = _fix_locator_state_enum(src)
        assert out.count("import com.microsoft.playwright.options.WaitForSelectorState;") == 1

    def test_apply_all_includes_locator_fix(self) -> None:
        src = "Locator.State.HIDDEN\n"
        out = apply_all_postgen_fixes(src)
        assert "WaitForSelectorState.HIDDEN" in out
