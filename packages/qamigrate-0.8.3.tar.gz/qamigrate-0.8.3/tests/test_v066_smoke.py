"""
v0.6.6 smoke test — run the new postgen rules against the 99 generated
files from the v0.6.5 multi-project test run that live in samples/.

Goals:
  1. Verify Fixes 16-18 do not corrupt working files (regression safety).
  2. Verify each generated file still parses as Java after postgen.
  3. Surface any new behaviour change so it can be reviewed in the diff.

This is NOT a substitute for an end-to-end LLM run, but it does catch the
"my postgen broke a real file" failure mode without spending API credit.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from qamigrate.core.parser import JavaParser
from qamigrate.core.postgen_fixes import apply_all_postgen_fixes
from qamigrate.intelligence.analyzer import ProjectAnalyzer

SAMPLES = Path(__file__).parent.parent / "samples"

# The three sample projects with v0.6.5-generated playwright output on disk.
_PROJECTS = [
    SAMPLES / "AutomationFrameworkSelenium",
    SAMPLES / "selenium-java-project",
]


def _collect_generated_files() -> list[tuple[Path, Path]]:
    """Return [(project_root, generated_java_file), ...] for all v0.6.5 output."""
    out: list[tuple[Path, Path]] = []
    for proj in _PROJECTS:
        if not proj.exists():
            continue
        for f in proj.rglob("*/playwright/*.java"):
            out.append((proj, f))
    return out


@pytest.fixture(scope="module")
def java_parser() -> JavaParser:
    return JavaParser()


@pytest.mark.parametrize("project,generated_file", _collect_generated_files())
def test_postgen_keeps_file_valid_java(
    project: Path,
    generated_file: Path,
    java_parser: JavaParser,
    tmp_path: Path,
) -> None:
    """Apply v0.6.6 postgen to each existing generated file. The output must
    parse as Java (tree-sitter has_error == False).
    """
    src = generated_file.read_text(encoding="utf-8")

    # Build the class_api lookup from the source project (same as pipeline does).
    pm = ProjectAnalyzer().build(project)
    from qamigrate.agents.pipeline import _build_class_api_from_project_map
    class_api = _build_class_api_from_project_map(pm)

    fixed = apply_all_postgen_fixes(
        src,
        file_path=str(generated_file),
        target_framework="junit5",
        class_api=class_api,
    )

    # Validate parsability via tree-sitter.
    tree = java_parser.parser.parse(fixed.encode("utf-8"))
    if tree.root_node.has_error:
        # Surface the first error line so we can see what went wrong.
        msg = (
            f"Postgen broke {generated_file.name}: tree-sitter reported "
            f"parse errors. File preview (first 40 lines):\n"
            + "\n".join(fixed.splitlines()[:40])
        )
        pytest.fail(msg)


# =============================================================================
# v0.6.5 known-bug regression checks — postgen must catch these.
# =============================================================================


def test_v065_known_constructor_hallucination_is_fixed() -> None:
    """v0.6.5 production run had this exact bug in ReportUtils.java:

        new InvalidPathForExtentReportFileException(arg1, arg2);

    when source declares only the 1-arg constructor. Fix 17 must drop the
    extra arg.
    """
    api = {
        "InvalidPathForExtentReportFileException": {
            "constructor_arities": {1},
            "method_names": [],
        },
    }
    src = (
        'public class ReportUtils {\n'
        '    public void f() {\n'
        '        throw new InvalidPathForExtentReportFileException("bad", e);\n'
        '    }\n'
        '}\n'
    )
    out = apply_all_postgen_fixes(
        src, file_path="ReportUtils.java", class_api=api
    )
    assert 'new InvalidPathForExtentReportFileException("bad")' in out
    assert ', e)' not in out


def test_v065_known_method_hallucination_IS_fixed_in_v067() -> None:
    """v0.6.5 BDD project bug in BasePage.java:

        DriverManager.getPage()

    when DriverManager exposes only getDriver(). Edit distance is 4 — too
    far for Fix 18 tier 1. v0.6.7 added tier 2 (same accessor prefix +
    single candidate) which catches this exact case: `getPage` and
    `getDriver` share the `get` prefix, and `getDriver` is the only `get*`
    method on the class.
    """
    api = {
        "DriverManager": {
            "constructor_arities": {0},
            "method_names": ["getDriver", "quitDriver"],   # only ONE get*
        },
    }
    src = (
        'public class BasePage {\n'
        '    public Page page() { return DriverManager.getPage(); }\n'
        '}\n'
    )
    out = apply_all_postgen_fixes(
        src, file_path="BasePage.java", class_api=api
    )
    # v0.6.7 tier 2: rewritten because there is exactly one `get*` method
    # on DriverManager. (Was left alone in v0.6.6.)
    assert "DriverManager.getDriver()" in out
    assert "DriverManager.getPage()" not in out


def test_v065_close_method_hallucination_IS_fixed() -> None:
    """When the LLM hallucinates a method name within edit distance 2,
    Fix 18 deterministically rewrites it.

    Realistic case: typo `getDriverr` → `getDriver`.
    """
    api = {
        "DriverManager": {
            "constructor_arities": {0},
            "method_names": ["getDriver"],
        },
    }
    src = (
        'public class BasePage {\n'
        '    public Page page() { return DriverManager.getDriverr(); }\n'
        '}\n'
    )
    out = apply_all_postgen_fixes(
        src, file_path="BasePage.java", class_api=api
    )
    assert "DriverManager.getDriver()" in out
    assert "getDriverr" not in out
