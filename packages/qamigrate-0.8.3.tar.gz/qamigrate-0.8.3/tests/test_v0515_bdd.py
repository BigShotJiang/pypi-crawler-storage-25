"""
Tests for v0.5.15 Cucumber BDD support.

- Infrastructure: io.cucumber dep → bdd_framework="cucumber"
- ClassRole: STEP_DEFINITION, CUCUMBER_HOOKS, CUCUMBER_RUNNER
- Passthrough: TestRunner (JUnit Platform Suite) → copied verbatim
- Coder prompt: BDD rules injected when is_bdd=True
- Postgen: Cucumber imports not corrupted with .playwright suffix
"""

from __future__ import annotations

from pathlib import Path

import pytest

from qamigrate.agents.coder import _build_system_prompt
from qamigrate.core.postgen_fixes import (
    _fix_cucumber_import_corruption,
    apply_all_postgen_fixes,
)
from qamigrate.intelligence.passthrough import is_passthrough
from qamigrate.intelligence.project_map import ClassInfo, ClassRole
from qamigrate.intelligence.role_inference import infer_role


# =============================================================================
# Infrastructure: Cucumber detection
# =============================================================================


class TestCucumberInfraDetection:
    def test_cucumber_dep_sets_bdd_framework(self, tmp_path: Path) -> None:
        from qamigrate.intelligence.infrastructure import detect_infrastructure

        pom = tmp_path / "pom.xml"
        pom.write_text("""<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId><artifactId>bdd</artifactId><version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>io.cucumber</groupId>
            <artifactId>cucumber-java</artifactId>
            <version>7.15.0</version>
        </dependency>
        <dependency>
            <groupId>io.cucumber</groupId>
            <artifactId>cucumber-junit-platform-engine</artifactId>
            <version>7.15.0</version>
        </dependency>
    </dependencies>
</project>""")
        infra = detect_infrastructure(tmp_path)
        assert infra.bdd_framework == "cucumber"

    def test_no_cucumber_dep_leaves_bdd_framework_none(self, tmp_path: Path) -> None:
        from qamigrate.intelligence.infrastructure import detect_infrastructure

        pom = tmp_path / "pom.xml"
        pom.write_text("""<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0">
    <modelVersion>4.0.0</modelVersion>
    <groupId>com.example</groupId><artifactId>sel</artifactId><version>1.0</version>
    <dependencies>
        <dependency>
            <groupId>org.testng</groupId><artifactId>testng</artifactId><version>7.8.0</version>
        </dependency>
    </dependencies>
</project>""")
        infra = detect_infrastructure(tmp_path)
        assert infra.bdd_framework is None


# =============================================================================
# Role inference: BDD classes
# =============================================================================


def _make(
    name: str,
    imports: list[str] | None = None,
    annotations: list[str] | None = None,
) -> ClassInfo:
    return ClassInfo(
        name=name,
        fqn=f"com.example.{name}",
        file_path=f"src/{name}.java",
        package="com.example",
        extends=None,
        implements=[],
        modifiers=["public"],
        imports=imports or [],
        role=ClassRole.OTHER,
    )


class TestBDDRoleInference:
    def test_step_def_class_detected(self) -> None:
        info = _make("LoginSteps", imports=["io.cucumber.java.en.Given", "io.cucumber.java.en.When"])
        assert infer_role(info) == ClassRole.STEP_DEFINITION

    def test_hooks_class_detected_from_import(self) -> None:
        info = _make(
            "Hooks",
            imports=["io.cucumber.java.Before", "io.cucumber.java.After", "io.cucumber.java.Scenario"],
        )
        assert infer_role(info) == ClassRole.CUCUMBER_HOOKS

    def test_runner_class_detected_from_suite_import(self) -> None:
        info = _make(
            "TestRunner",
            imports=[
                "org.junit.platform.suite.api.Suite",
                "org.junit.platform.suite.api.IncludeEngines",
                "io.cucumber.junit.platform.engine.Constants",
            ],
        )
        assert infer_role(info) == ClassRole.CUCUMBER_RUNNER

    def test_regular_testng_class_not_affected(self) -> None:
        info = _make("LoginTests", imports=["org.testng.annotations.Test"])
        # Should NOT be STEP_DEFINITION — no io.cucumber import
        assert infer_role(info) != ClassRole.STEP_DEFINITION
        assert infer_role(info) != ClassRole.CUCUMBER_HOOKS

    def test_real_bdd_project_roles(self) -> None:
        bdd_root = Path("samples/selenium-java-project-bdd")
        if not bdd_root.exists():
            pytest.skip("BDD sample project not present")

        from qamigrate.intelligence import ProjectAnalyzer
        pmap = ProjectAnalyzer().build(bdd_root)

        roles = {cls.name: cls.role for cls in pmap.classes.values()}
        assert roles.get("LoginSteps") == ClassRole.STEP_DEFINITION
        assert roles.get("Hooks") == ClassRole.CUCUMBER_HOOKS
        assert pmap.infrastructure.bdd_framework == "cucumber"


# =============================================================================
# Passthrough: Cucumber runner
# =============================================================================


class TestCucumberRunnerPassthrough:
    def test_runner_with_suite_annotation_passthrough(self, tmp_path: Path) -> None:
        runner = tmp_path / "TestRunner.java"
        runner.write_text(
            "package com.example.runners;\n"
            "import org.junit.platform.suite.api.Suite;\n"
            "import org.junit.platform.suite.api.IncludeEngines;\n"
            "@Suite\n"
            "@IncludeEngines(\"cucumber\")\n"
            "public class TestRunner {}\n"
        )
        pt, reason = is_passthrough(runner)
        assert pt is True
        assert "cucumber-runner" in (reason or "")

    def test_real_runner_is_passthrough(self) -> None:
        runner = Path(
            "samples/selenium-java-project-bdd/src/test/java"
            "/com/qastarter/runners/TestRunner.java"
        )
        if not runner.exists():
            pytest.skip("BDD sample project not present")
        pt, reason = is_passthrough(runner)
        assert pt is True

    def test_regular_junit5_class_not_passthrough(self, tmp_path: Path) -> None:
        test_file = tmp_path / "LoginTests.java"
        test_file.write_text(
            "import org.junit.jupiter.api.Test;\n"
            "public class LoginTests {\n"
            "    @Test void testLogin() {}\n"
            "}\n"
        )
        pt, _ = is_passthrough(test_file)
        assert pt is False  # Regular test class — must be migrated


# =============================================================================
# Coder prompt: BDD instructions
# =============================================================================


class TestBDDCoderPrompt:
    def test_bdd_prompt_has_step_def_rule(self) -> None:
        p = _build_system_prompt("junit5", is_bdd=True)
        assert "STEP DEFINITION CLASSES" in p
        assert "FROZEN" in p

    def test_bdd_prompt_has_hooks_rule(self) -> None:
        p = _build_system_prompt("junit5", is_bdd=True)
        assert "HOOKS CLASSES" in p
        assert "playwright.close()" in p

    def test_bdd_prompt_has_no_extendwith_rule(self) -> None:
        p = _build_system_prompt("junit5", is_bdd=True)
        assert "Do NOT add" in p and "ExtendWith" in p

    def test_bdd_prompt_has_driver_manager_rule(self) -> None:
        p = _build_system_prompt("junit5", is_bdd=True)
        assert "DRIVER_MANAGER" in p
        assert "ThreadLocal" in p

    def test_non_bdd_prompt_has_no_bdd_section(self) -> None:
        p = _build_system_prompt("junit5", is_bdd=False)
        assert "STEP DEFINITION CLASSES" not in p
        assert "HOOKS CLASSES" not in p

    def test_bdd_works_with_testng_framework(self) -> None:
        # TestNG + Cucumber is a valid combination
        p = _build_system_prompt("testng", is_bdd=True)
        assert "STEP DEFINITION CLASSES" in p
        assert "@BeforeMethod stays @BeforeMethod" in p  # TestNG lifecycle preserved


# =============================================================================
# Postgen: Cucumber import corruption fix
# =============================================================================


class TestCucumberImportFix:
    def test_strips_playwright_from_cucumber_import(self) -> None:
        src = "import io.cucumber.java.playwright.en.Given;\n"
        out, changed = _fix_cucumber_import_corruption(src)
        assert changed
        assert "io.cucumber.java.en.Given" in out
        assert ".playwright" not in out

    def test_clean_cucumber_import_unchanged(self) -> None:
        src = "import io.cucumber.java.en.Given;\n"
        out, changed = _fix_cucumber_import_corruption(src)
        assert not changed

    def test_no_cucumber_import_no_change(self) -> None:
        src = "import com.example.playwright.Foo;\n"
        out, changed = _fix_cucumber_import_corruption(src)
        assert not changed

    def test_apply_all_includes_cucumber_fix(self) -> None:
        src = (
            "import io.cucumber.java.playwright.en.Given;\n"
            "import com.example.pages.playwright.LoginPage;\n"
        )
        out = apply_all_postgen_fixes(src)
        # Cucumber import: .playwright REMOVED
        assert "io.cucumber.java.en.Given" in out
        # Project sibling import: .playwright KEPT (correct)
        assert "com.example.pages.playwright.LoginPage" in out
