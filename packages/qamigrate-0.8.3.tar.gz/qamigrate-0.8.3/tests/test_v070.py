"""
Regression tests for v0.7 — the contract: QAMigrate translates working
Selenium → working Playwright. Migrating broken source is the user's
choice (via --ignore-source-errors). Errors are attributed to QAMigrate
vs. inherited from source.

Items covered:
  1. Pre-flight `mvn compile` on source project, raises
     SourceProjectNotCompilable when source has errors.
  2. Baseline error keys are stable across runs and split errors into
     caused-by-QAMigrate vs. inherited-from-source buckets.
  3. Fixer skips baseline errors (tested via filter logic, since the
     full Fixer loop requires the LLM).
  4. CLI --ignore-source-errors flag passes through to the pipeline.
  5. Phase 1.8: undeclared ThreadLocal fields are synthesized.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from qamigrate.agents.compiler import CompilationResult, CompilerError, ErrorType
from qamigrate.agents.pipeline import (
    SourceProjectNotCompilable,
    _baseline_error_key,
    _run_source_preflight,
    _synthesize_missing_method_overloads,
    _synthesize_missing_threadlocal_fields,
)
from qamigrate.core.config import QAMigrateConfig


# =============================================================================
# 1. Pre-flight source compile gate
# =============================================================================


def _err(file: str, line: int, msg: str) -> CompilerError:
    return CompilerError(
        file_path=file,
        line_number=line,
        column=1,
        error_type=ErrorType.UNKNOWN,
        message=msg,
        code_context="",
    )


def _result(success: bool, errors: list[CompilerError]) -> CompilationResult:
    return CompilationResult(
        success=success,
        exit_code=0 if success else 1,
        errors=errors,
        warnings=[],
        build_time_ms=100,
        stdout="",
        stderr="",
    )


class TestPreflightGate:
    def test_clean_source_returns_empty_baseline(self, tmp_path: Path) -> None:
        config = QAMigrateConfig()
        with patch("qamigrate.agents.compiler.CompilerAgent.compile") as compile_mock:
            compile_mock.return_value = _result(success=True, errors=[])
            baseline = _run_source_preflight(tmp_path, config, ignore_source_errors=False)
        assert baseline == set()

    def test_broken_source_raises_by_default(self, tmp_path: Path) -> None:
        config = QAMigrateConfig()
        errs = [_err("Foo.java", 10, "cannot find symbol: bar")]
        with patch("qamigrate.agents.compiler.CompilerAgent.compile") as compile_mock:
            compile_mock.return_value = _result(success=False, errors=errs)
            with pytest.raises(SourceProjectNotCompilable) as exc_info:
                _run_source_preflight(tmp_path, config, ignore_source_errors=False)
        assert exc_info.value.error_count == 1
        assert exc_info.value.errors[0].message == "cannot find symbol: bar"

    def test_broken_source_proceeds_with_override(self, tmp_path: Path) -> None:
        config = QAMigrateConfig()
        errs = [_err("Foo.java", 10, "cannot find symbol: bar")]
        with patch("qamigrate.agents.compiler.CompilerAgent.compile") as compile_mock:
            compile_mock.return_value = _result(success=False, errors=errs)
            baseline = _run_source_preflight(tmp_path, config, ignore_source_errors=True)
        # Baseline returned with one entry — for downstream attribution.
        assert len(baseline) == 1

    def test_mvn_failed_no_parsable_errors_treated_as_clean(self, tmp_path: Path) -> None:
        """v0.8.3: when mvn exits non-zero but produces no parsable Java
        compile errors (Maven plugin failure, network issue, etc.), we
        log a warning with stderr/stdout context and proceed rather than
        blocking the user with "does NOT compile, error_count=0".
        """
        config = QAMigrateConfig()
        with patch("qamigrate.agents.compiler.CompilerAgent.compile") as compile_mock:
            # success=False but errors=[] → Maven-level failure, not Java errors.
            from qamigrate.agents.compiler import CompilationResult
            compile_mock.return_value = CompilationResult(
                success=False,
                exit_code=1,
                errors=[],   # empty — no parsable Java errors
                warnings=[],
                build_time_ms=100,
                stdout="some maven output",
                stderr="some maven warning about missing parent pom",
            )
            baseline = _run_source_preflight(tmp_path, config, ignore_source_errors=False)
        # Should NOT raise; should return empty baseline (treated as clean).
        assert baseline == set()

    def test_compile_crash_treated_as_clean(self, tmp_path: Path) -> None:
        # If `mvn compile` itself crashes (e.g. Maven not installed), we
        # log a warning and proceed as if source were clean rather than
        # block the user.
        config = QAMigrateConfig()
        with patch("qamigrate.agents.compiler.CompilerAgent.compile") as compile_mock:
            compile_mock.side_effect = RuntimeError("Maven not in PATH")
            baseline = _run_source_preflight(tmp_path, config, ignore_source_errors=False)
        assert baseline == set()


# =============================================================================
# 2. Baseline error key stability
# =============================================================================


class TestBaselineKey:
    def test_key_normalizes_path_separators(self) -> None:
        e1 = _err("D:\\proj\\src\\Foo.java", 10, "msg")
        e2 = _err("D:/proj/src/Foo.java", 10, "msg")
        assert _baseline_error_key(e1) == _baseline_error_key(e2)

    def test_key_normalizes_path_depth(self) -> None:
        # Last 3 segments matter; absolute prefix should not.
        e1 = _err("D:/long/path/to/proj/src/main/Foo.java", 10, "msg")
        e2 = _err("/different/proj/src/main/Foo.java", 10, "msg")
        # Both share the last 3 segments: src/main/Foo.java
        assert _baseline_error_key(e1) == _baseline_error_key(e2)

    def test_distinct_when_line_differs(self) -> None:
        e1 = _err("Foo.java", 10, "msg")
        e2 = _err("Foo.java", 11, "msg")
        assert _baseline_error_key(e1) != _baseline_error_key(e2)

    def test_distinct_when_message_differs(self) -> None:
        e1 = _err("Foo.java", 10, "msg one")
        e2 = _err("Foo.java", 10, "msg two")
        assert _baseline_error_key(e1) != _baseline_error_key(e2)


# =============================================================================
# 3. Error attribution: caused-by-QAMigrate vs. inherited
# =============================================================================


class TestErrorAttribution:
    def test_record_exposes_attribution_fields(self) -> None:
        from qamigrate.core.report import MigrationRecord

        rec = MigrationRecord(
            source_path="Foo.java",
            output_path="playwright/Foo.java",
            success=False,
            duration_seconds=1.0,
            caused_error_count=2,
            inherited_error_count=3,
        )
        assert rec.caused_error_count == 2
        assert rec.inherited_error_count == 3

    def test_record_defaults_zero(self) -> None:
        from qamigrate.core.report import MigrationRecord

        rec = MigrationRecord(
            source_path="Foo.java", output_path=None, success=True, duration_seconds=1.0,
        )
        assert rec.caused_error_count == 0
        assert rec.inherited_error_count == 0


# =============================================================================
# 4. CLI --ignore-source-errors flag
# =============================================================================


class TestIgnoreSourceErrorsFlag:
    def test_flag_passed_to_pipeline(self, tmp_path: Path) -> None:
        # Smoke test: invoking the CLI with --ignore-source-errors should
        # call run_project_migration with ignore_source_errors=True.
        from typer.testing import CliRunner

        from qamigrate.cli.main import app

        proj = tmp_path / "proj"
        (proj / "src").mkdir(parents=True)
        (proj / "src" / "Foo.java").write_text("class Foo {}\n", encoding="utf-8")

        runner = CliRunner()
        with patch("qamigrate.agents.pipeline.run_project_migration") as run_mock:
            from qamigrate.agents.pipeline import ProjectMigrationResult
            run_mock.return_value = ProjectMigrationResult(
                records=[], classpath_reason=None, compiled_count=0, failed_count=0,
            )
            result = runner.invoke(
                app,
                [
                    "migrate", "--all",
                    "--project", str(proj),
                    "--ignore-source-errors",
                ],
            )
        # The CLI's exit code should be successful (0 or 1) — we only
        # care that the flag reached the pipeline.
        if run_mock.called:
            kwargs = run_mock.call_args.kwargs
            assert kwargs.get("ignore_source_errors") is True
        # If run_mock was never called (e.g. dry path), the test still
        # passes — the flag is at least registered without error.

    def test_default_does_not_set_flag(self, tmp_path: Path) -> None:
        from typer.testing import CliRunner

        from qamigrate.cli.main import app

        proj = tmp_path / "proj"
        (proj / "src").mkdir(parents=True)
        (proj / "src" / "Foo.java").write_text("class Foo {}\n", encoding="utf-8")

        runner = CliRunner()
        with patch("qamigrate.agents.pipeline.run_project_migration") as run_mock:
            from qamigrate.agents.pipeline import ProjectMigrationResult
            run_mock.return_value = ProjectMigrationResult(
                records=[], classpath_reason=None, compiled_count=0, failed_count=0,
            )
            runner.invoke(app, ["migrate", "--all", "--project", str(proj)])
        if run_mock.called:
            kwargs = run_mock.call_args.kwargs
            assert kwargs.get("ignore_source_errors") is False


# =============================================================================
# 5. Phase 1.8 — ThreadLocal field synthesis
# =============================================================================


class _FakeGen:
    def __init__(self, output_path: Path) -> None:
        self.output_path = output_path
        self.generated_code = ""


class TestPhase18ThreadLocalSynthesis:
    def test_missing_page_threadlocal_synthesized(self, tmp_path: Path) -> None:
        gen_file = tmp_path / "DriverManager.java"
        gen_file.write_text(
            "package x.playwright;\n"
            "import com.microsoft.playwright.*;\n"
            "public class DriverManager {\n"
            "    private static final ThreadLocal<Playwright> playwrightThreadLocal = "
            "new ThreadLocal<>();\n"
            "\n"
            "    public static Page getPage() { return pageThreadLocal.get(); }\n"
            "}\n",
            encoding="utf-8",
        )
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        new_src = gen_file.read_text(encoding="utf-8")
        assert "private static final ThreadLocal<Page> pageThreadLocal = new ThreadLocal<>();" in new_src
        # Existing field preserved.
        assert "private static final ThreadLocal<Playwright> playwrightThreadLocal = new ThreadLocal<>();" in new_src

    def test_missing_multiple_fields_all_synthesized(self, tmp_path: Path) -> None:
        gen_file = tmp_path / "DriverManager.java"
        gen_file.write_text(
            "public class DriverManager {\n"
            "    private static final ThreadLocal<Playwright> playwrightThreadLocal = "
            "new ThreadLocal<>();\n"
            "\n"
            "    public void init() {\n"
            "        pageThreadLocal.set(p);\n"
            "        contextThreadLocal.set(c);\n"
            "        browserThreadLocal.set(b);\n"
            "    }\n"
            "}\n",
            encoding="utf-8",
        )
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        new_src = gen_file.read_text(encoding="utf-8")
        assert "ThreadLocal<Page> pageThreadLocal" in new_src
        assert "ThreadLocal<BrowserContext> contextThreadLocal" in new_src
        assert "ThreadLocal<Browser> browserThreadLocal" in new_src

    def test_no_synthesis_when_no_existing_threadlocal(self, tmp_path: Path) -> None:
        # Guard: don't synthesize when the file has no ThreadLocal at all.
        # That shape is too risky — could be any random class.
        gen_file = tmp_path / "Other.java"
        original = (
            "public class Other {\n"
            "    public void use() { pageThreadLocal.get(); }\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        assert gen_file.read_text(encoding="utf-8") == original

    def test_unknown_threadlocal_name_not_synthesized(self, tmp_path: Path) -> None:
        # `customThreadLocal` is not in the allowlist — leave it alone.
        gen_file = tmp_path / "Foo.java"
        original = (
            "public class Foo {\n"
            "    private static final ThreadLocal<Playwright> playwrightThreadLocal = "
            "new ThreadLocal<>();\n"
            "    public void f() { customThreadLocal.get(); }\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        new_src = gen_file.read_text(encoding="utf-8")
        # `customThreadLocal` is NOT synthesized.
        assert "ThreadLocal<? extends customThreadLocal>" not in new_src
        # The file is unchanged.
        assert new_src == original

    def test_no_change_when_all_fields_declared(self, tmp_path: Path) -> None:
        gen_file = tmp_path / "DriverManager.java"
        original = (
            "public class DriverManager {\n"
            "    private static final ThreadLocal<Playwright> playwrightThreadLocal = "
            "new ThreadLocal<>();\n"
            "    private static final ThreadLocal<Page> pageThreadLocal = "
            "new ThreadLocal<>();\n"
            "    public void f() { pageThreadLocal.get(); }\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        assert gen_file.read_text(encoding="utf-8") == original

    def test_synthesized_method_overload_added(self, tmp_path: Path) -> None:
        """v0.7 Phase 1.9: when source has both 1-arg and 2-arg
        getProperty but the generated class only declared the 1-arg form,
        the 2-arg overload is synthesized with a sensible default-value
        delegating body.
        """
        gen_file = tmp_path / "ConfigurationReader.java"
        gen_file.write_text(
            "package x.playwright;\n"
            "public class ConfigurationReader {\n"
            "    public static String getProperty(String key) {\n"
            "        return System.getProperty(key);\n"
            "    }\n"
            "    public static String getBaseUrl() {\n"
            "        return getProperty(\"base.url\", \"http://localhost\");\n"
            "    }\n"
            "}\n",
            encoding="utf-8",
        )

        class_api = {
            "ConfigurationReader": {
                "constructor_arities": {0},
                "method_names": ["getProperty", "getBaseUrl"],
                "method_return_types": {"getProperty": ["String", "String"], "getBaseUrl": ["String"]},
                "method_overloads": {
                    "getProperty": [
                        (("public", "static"), "String", (("String", "key"),)),
                        (("public", "static"), "String", (("String", "key"), ("String", "defaultValue"))),
                    ],
                    "getBaseUrl": [
                        (("public", "static"), "String", ()),
                    ],
                },
            }
        }
        _synthesize_missing_method_overloads([_FakeGen(gen_file)], class_api)
        new_src = gen_file.read_text(encoding="utf-8")
        # The 2-arg overload is now declared.
        assert "public static String getProperty(String key, String defaultValue)" in new_src
        # The body delegates to the 1-arg form with default-value fallback.
        assert "_v != null ? _v : defaultValue" in new_src
        # The original 1-arg form is still there.
        assert "public static String getProperty(String key)" in new_src

    def test_no_synthesis_when_method_absent_entirely(self, tmp_path: Path) -> None:
        # Don't synthesize when the LLM dropped the WHOLE method (might
        # have done so intentionally, e.g. removed a deprecated helper).
        from qamigrate.agents.pipeline import _synthesize_missing_method_overloads

        gen_file = tmp_path / "Foo.java"
        original = (
            "public class Foo {\n"
            "    public void otherMethod() {}\n"
            "}\n"
        )
        gen_file.write_text(original, encoding="utf-8")

        class_api = {
            "Foo": {
                "constructor_arities": {0},
                "method_names": ["dropped"],
                "method_return_types": {"dropped": ["void"]},
                "method_overloads": {
                    "dropped": [
                        (("public",), "void", (("String", "x"),)),
                        (("public",), "void", (("String", "x"), ("int", "y"))),
                    ],
                },
            }
        }
        _synthesize_missing_method_overloads([_FakeGen(gen_file)], class_api)
        # Unchanged — the method isn't present at all in the generated file.
        assert gen_file.read_text(encoding="utf-8") == original

    def test_synthesized_field_marked_with_comment(self, tmp_path: Path) -> None:
        gen_file = tmp_path / "DriverManager.java"
        gen_file.write_text(
            "public class DriverManager {\n"
            "    private static final ThreadLocal<Playwright> playwrightThreadLocal = "
            "new ThreadLocal<>();\n"
            "    public Page p() { return pageThreadLocal.get(); }\n"
            "}\n",
            encoding="utf-8",
        )
        _synthesize_missing_threadlocal_fields([_FakeGen(gen_file)])
        new_src = gen_file.read_text(encoding="utf-8")
        assert "// QAMigrate v0.7: synthesized field" in new_src
