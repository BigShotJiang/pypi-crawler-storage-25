"""
Regression tests for v0.8.3 — overload preservation through `assemble_file`
and `validate_generated_code`.

The bug shipped in v0.8.0/v0.8.1/v0.8.2 silently dropped legitimate
method overloads. The user's v0.8.2 test report on `LogUtils.java` (13
overloads across 5 names) showed only 5 methods surviving — the assembler's
`seen_method_names` was a `set[str]` keyed on method name only, and
`validate_generated_code` had a similar (name, arity) key that flagged
same-arity-different-types overloads as "duplicates".

Java distinguishes overloads by (method_name, parameter_types), not by
arity alone. `info(String)` and `info(Object)` are distinct methods.

These tests would have caught the bug in <1 second, instead of waiting for
a multi-hour multi-project end-to-end run.
"""

from __future__ import annotations

import pytest

from qamigrate.agents.coder import (
    CoderAgent,
    MethodDefinition,
    PlaywrightCode,
)


def _code_with_methods(methods: list[MethodDefinition]) -> PlaywrightCode:
    """Build a minimal PlaywrightCode wrapper around a method list."""
    return PlaywrightCode(
        package_name="com.example",
        imports=[],
        class_declaration="public class LogUtils {",
        fields=[],
        constructor="    public LogUtils() {}",
        methods=methods,
    )


# =============================================================================
# Param-type extraction helper
# =============================================================================


class TestSignatureParamTypes:
    def test_single_string_param(self) -> None:
        sig = "public static void info(String message)"
        assert CoderAgent._signature_param_types(sig) == ("String",)

    def test_two_params_different_types(self) -> None:
        sig = "public static void error(String message, Throwable throwable)"
        assert CoderAgent._signature_param_types(sig) == ("String", "Throwable")

    def test_zero_params(self) -> None:
        sig = "public static void cleanup()"
        assert CoderAgent._signature_param_types(sig) == ()

    def test_object_param(self) -> None:
        sig = "public static void info(Object message)"
        assert CoderAgent._signature_param_types(sig) == ("Object",)

    def test_generic_type_preserved(self) -> None:
        sig = "public void store(ThreadLocal<Page> tl)"
        assert CoderAgent._signature_param_types(sig) == ("ThreadLocal<Page>",)

    def test_two_generic_params(self) -> None:
        sig = "public void merge(Map<String,Integer> a, List<String> b)"
        assert CoderAgent._signature_param_types(sig) == (
            "Map<String,Integer>", "List<String>",
        )

    def test_final_modifier_preserved(self) -> None:
        # `final String message` — the type is `final String`, the name is `message`.
        # Our algorithm strips only the LAST whitespace-separated token (the
        # parameter name), so `final` survives in the type string. That's
        # acceptable: it preserves enough signature identity that
        # `final String x` and `String x` are still treated as the same
        # method (which they are in Java; `final` in a parameter is just
        # a marker, not part of the signature).
        sig = "public void f(final String message)"
        types = CoderAgent._signature_param_types(sig)
        assert "String" in types[0]


# =============================================================================
# assemble_file: legitimate overloads must survive
# =============================================================================


class TestAssembleFilePreservesOverloads:
    def test_three_info_overloads_all_survive(self) -> None:
        """The exact LogUtils.java pattern. Pre-v0.8.3 this dropped 2 of 3."""
        methods = [
            MethodDefinition(
                name="info",
                signature="public static void info(String message)",
                implementation="{ logger.info(message); }",
            ),
            MethodDefinition(
                name="info",
                signature="public static void info(Object message)",
                implementation="{ logger.info(message); }",
            ),
            MethodDefinition(
                name="info",
                signature="public static void info(String message, Throwable t)",
                implementation="{ logger.info(message, t); }",
            ),
        ]
        agent = CoderAgent.__new__(CoderAgent)  # bypass __init__ (no LLM)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        out = agent.assemble_file(_code_with_methods(methods))

        # All three overloads must appear in the output.
        assert "info(String message)" in out
        assert "info(Object message)" in out
        assert "info(String message, Throwable t)" in out

    def test_true_duplicate_still_dedup(self) -> None:
        """Two methods with IDENTICAL name + parameter types are real
        duplicates and should still be collapsed.
        """
        methods = [
            MethodDefinition(
                name="info",
                signature="public static void info(String x)",
                implementation="{ logger.info(x); }",
            ),
            MethodDefinition(
                name="info",
                signature="public static void info(String y)",
                implementation="{ logger.info(y); }",
            ),
        ]
        agent = CoderAgent.__new__(CoderAgent)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        out = agent.assemble_file(_code_with_methods(methods))
        # Only one `info(String ...)` in the output. Count by signature
        # prefix to be robust against the dedup choosing either copy.
        info_count = out.count("public static void info(String")
        assert info_count == 1


# =============================================================================
# validate_generated_code: same name + different types is NOT a duplicate
# =============================================================================


class TestValidateGeneratedCodeOverloads:
    def test_same_name_different_types_not_flagged(self) -> None:
        """v0.6.1 keyed on (name, arity); the v0.8.2 report shows that's
        still not enough — `info(String)` and `info(Object)` are at the
        same arity (1) but distinct overloads. The validator must use
        full param-types as the key.
        """
        methods = [
            MethodDefinition(
                name="info",
                signature="public static void info(String m)",
                implementation="{}",
            ),
            MethodDefinition(
                name="info",
                signature="public static void info(Object m)",
                implementation="{}",
            ),
        ]
        agent = CoderAgent.__new__(CoderAgent)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(_code_with_methods(methods))
        duplicate_errors = [e for e in errors if "Duplicate method" in e]
        assert duplicate_errors == [], (
            f"Same-arity-different-types overloads incorrectly flagged "
            f"as duplicates: {duplicate_errors}"
        )

    def test_real_duplicate_still_flagged(self) -> None:
        """Identical name AND parameter types must still be flagged."""
        methods = [
            MethodDefinition(
                name="info",
                signature="public static void info(String m)",
                implementation="{}",
            ),
            MethodDefinition(
                name="info",
                signature="public static void info(String x)",
                implementation="{}",
            ),
        ]
        agent = CoderAgent.__new__(CoderAgent)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(_code_with_methods(methods))
        duplicate_errors = [e for e in errors if "Duplicate method" in e]
        assert len(duplicate_errors) == 1


# =============================================================================
# End-to-end: assemble + validate stay consistent on a 13-overload class
# =============================================================================


class TestLogUtilsThirteenOverloadShape:
    """The exact shape from the v0.8.2 user test report. LogUtils.java
    declares 13 overloads across 5 method names. v0.8.2 dropped 8 of them.
    """

    def _logutils_methods(self) -> list[MethodDefinition]:
        return [
            MethodDefinition(name="info", signature="public static void info(String message)", implementation="{}"),
            MethodDefinition(name="info", signature="public static void info(Object message)", implementation="{}"),
            MethodDefinition(name="info", signature="public static void info(String message, Throwable t)", implementation="{}"),
            MethodDefinition(name="warn", signature="public static void warn(String message)", implementation="{}"),
            MethodDefinition(name="warn", signature="public static void warn(Object message)", implementation="{}"),
            MethodDefinition(name="error", signature="public static void error(String message)", implementation="{}"),
            MethodDefinition(name="error", signature="public static void error(String message, Throwable t)", implementation="{}"),
            MethodDefinition(name="error", signature="public static void error(Object message)", implementation="{}"),
            MethodDefinition(name="error", signature="public static void error(Object message, Throwable t)", implementation="{}"),
            MethodDefinition(name="fatal", signature="public static void fatal(String message)", implementation="{}"),
            MethodDefinition(name="fatal", signature="public static void fatal(Object message)", implementation="{}"),
            MethodDefinition(name="debug", signature="public static void debug(String message)", implementation="{}"),
            MethodDefinition(name="debug", signature="public static void debug(Object message)", implementation="{}"),
        ]

    def test_all_thirteen_overloads_in_assembled_output(self) -> None:
        agent = CoderAgent.__new__(CoderAgent)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        out = agent.assemble_file(_code_with_methods(self._logutils_methods()))
        # Three `info(...)` overloads.
        assert "info(String message)" in out
        assert "info(Object message)" in out
        assert "info(String message, Throwable t)" in out
        # Two `warn(...)`.
        assert "warn(String message)" in out
        assert "warn(Object message)" in out
        # Four `error(...)`.
        assert "error(String message)" in out
        assert "error(String message, Throwable t)" in out
        assert "error(Object message)" in out
        assert "error(Object message, Throwable t)" in out

    def test_validator_does_not_flag_any_of_them(self) -> None:
        agent = CoderAgent.__new__(CoderAgent)
        from qamigrate.core.config import CoderConfig
        agent.config = CoderConfig()
        errors = agent.validate_generated_code(
            _code_with_methods(self._logutils_methods())
        )
        duplicate_errors = [e for e in errors if "Duplicate method" in e]
        assert duplicate_errors == [], (
            f"Validator flagged legitimate overloads as duplicates: "
            f"{duplicate_errors}"
        )
