"""
Regression tests for v0.6.5 — version string fix and --exclude flag.

v0.6.4 user testing surfaced two CLI issues:
  - Bug 1 (Low): qamigrate --version showed 0.6.1 because __version__
    in __init__.py was never bumped past v0.6.1.
  - Bug 3 (High): no --exclude option, blocking multi-project repos
    from being migrated in isolation.
"""

from __future__ import annotations

from pathlib import Path

from typer.testing import CliRunner

from qamigrate import __version__
from qamigrate.cli.main import app


runner = CliRunner()


class TestVersionString:
    def test_version_module_attr_matches_pyproject(self) -> None:
        """__version__ must match the version declared in pyproject.toml.

        The v0.6.4 ship had pyproject = 0.6.4 but __version__ = "0.6.1",
        so users running `qamigrate --version` saw the wrong number.
        """
        pyproject = Path(__file__).parent.parent / "pyproject.toml"
        text = pyproject.read_text(encoding="utf-8")
        # Find: version = "X.Y.Z"
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("version"):
                # version = "0.6.5"
                declared = stripped.split("=", 1)[1].strip().strip('"').strip("'")
                assert __version__ == declared, (
                    f"__version__={__version__!r} != pyproject={declared!r}; "
                    "bump src/qamigrate/__init__.py whenever pyproject.toml is bumped."
                )
                return
        raise AssertionError("Could not find `version = ...` in pyproject.toml")

    def test_version_flag_prints_correct_version(self) -> None:
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert __version__ in result.stdout


class TestExcludeFlag:
    """The --exclude flag uses fnmatch glob semantics relative to --project."""

    def test_exclude_pattern_filters_subdir(self, tmp_path: Path) -> None:
        # Create a fake project with two sub-projects.
        proj = tmp_path / "monorepo"
        (proj / "subproj-a" / "src").mkdir(parents=True)
        (proj / "subproj-b" / "src").mkdir(parents=True)
        (proj / "subproj-a" / "src" / "A.java").write_text(
            "package a; class A {}\n", encoding="utf-8"
        )
        (proj / "subproj-b" / "src" / "B.java").write_text(
            "package b; class B {}\n", encoding="utf-8"
        )

        # Sanity check: the dry-run finds both files when no exclude is given.
        result_all = runner.invoke(
            app, ["migrate", "--all", "--project", str(proj), "--dry-run"]
        )
        assert result_all.exit_code == 0
        assert "A.java" in result_all.stdout
        assert "B.java" in result_all.stdout

        # With --exclude 'subproj-b/**', only A.java is processed.
        result_excl = runner.invoke(
            app,
            [
                "migrate", "--all",
                "--project", str(proj),
                "--exclude", "subproj-b/**",
                "--dry-run",
            ],
        )
        assert result_excl.exit_code == 0
        assert "A.java" in result_excl.stdout
        assert "B.java" not in result_excl.stdout

    def test_exclude_repeatable(self, tmp_path: Path) -> None:
        # Three sub-projects; exclude two of them with two --exclude flags.
        proj = tmp_path / "monorepo"
        for sub in ("a", "b", "c"):
            d = proj / f"sub-{sub}"
            d.mkdir(parents=True)
            (d / f"{sub.upper()}.java").write_text(
                f"package x; class {sub.upper()} {{}}\n", encoding="utf-8"
            )

        result = runner.invoke(
            app,
            [
                "migrate", "--all",
                "--project", str(proj),
                "--exclude", "sub-a/**",
                "--exclude", "sub-c/**",
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "A.java" not in result.stdout
        assert "B.java" in result.stdout
        assert "C.java" not in result.stdout

    def test_exclude_with_backslash_pattern_works(self, tmp_path: Path) -> None:
        """v0.6.6 Bug E: Windows users / shells can pass backslash-separated
        patterns. The CLI normalizes them to forward slashes before fnmatch.
        """
        proj = tmp_path / "monorepo"
        (proj / "subproj-a" / "src").mkdir(parents=True)
        (proj / "subproj-b" / "src").mkdir(parents=True)
        (proj / "subproj-a" / "src" / "A.java").write_text(
            "package a; class A {}\n", encoding="utf-8"
        )
        (proj / "subproj-b" / "src" / "B.java").write_text(
            "package b; class B {}\n", encoding="utf-8"
        )

        # Pass a Windows-style backslash pattern. Should still exclude correctly.
        result = runner.invoke(
            app,
            [
                "migrate", "--all",
                "--project", str(proj),
                "--exclude", "subproj-b\\**",
                "--dry-run",
            ],
        )
        assert result.exit_code == 0
        assert "A.java" in result.stdout
        assert "B.java" not in result.stdout

    def test_no_exclude_keeps_all_files(self, tmp_path: Path) -> None:
        # Without --exclude, behavior is unchanged from prior versions.
        proj = tmp_path / "p"
        (proj / "src").mkdir(parents=True)
        (proj / "src" / "Foo.java").write_text(
            "package x; class Foo {}\n", encoding="utf-8"
        )
        result = runner.invoke(
            app, ["migrate", "--all", "--project", str(proj), "--dry-run"]
        )
        assert result.exit_code == 0
        assert "Foo.java" in result.stdout
