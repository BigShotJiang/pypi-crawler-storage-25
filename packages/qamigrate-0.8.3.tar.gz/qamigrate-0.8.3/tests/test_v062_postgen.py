"""
Regression tests for v0.6.2 — postgen Fix 14 (Javadoc placement) and
Fix 15 (HTML entity escaping).

Both bugs were identified from a multi-project v0.6.1 test run (117 files,
3 projects):

- Fix 14: Javadoc placed between method signature and `{` — 46/66 errors (70%)
  across all 3 projects.  Pattern: `public void foo() /** doc */ {`.
  Java requires Javadoc BEFORE the modifier line, not between `)` and `{`.

- Fix 15: HTML entity escaping in generic types — 18 errors in DriverManager.java.
  Pattern: `ThreadLocal&lt;Page&gt;` instead of `ThreadLocal<Page>`.
  NEW regression in v0.6.1 (not present in v0.5.18 run).
"""

from __future__ import annotations


# =============================================================================
# Fix 15 — HTML entity escaping in generic types
# =============================================================================


class TestFix15HtmlEntityEscaping:
    """Fix 15: decode &lt; / &gt; / &amp; / &quot; / &apos; in Java source."""

    def test_lt_gt_in_generic_field(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = (
            "    private static final ThreadLocal&lt;Page&gt; pageLocal"
            " = new ThreadLocal&lt;&gt;();\n"
        )
        out, changed = _fix_html_entity_escaping(src)
        assert changed
        assert "&lt;" not in out
        assert "&gt;" not in out
        assert "ThreadLocal<Page>" in out
        assert "new ThreadLocal<>()" in out

    def test_amp_decoded(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = '    String s = "a &amp; b";\n'
        out, changed = _fix_html_entity_escaping(src)
        assert changed
        assert '"a & b"' in out

    def test_quot_decoded(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = "    String s = &quot;hello&quot;;\n"
        out, changed = _fix_html_entity_escaping(src)
        assert changed
        assert '"hello"' in out

    def test_clean_source_unchanged(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = "    private ThreadLocal<Page> pageLocal = new ThreadLocal<>();\n"
        out, changed = _fix_html_entity_escaping(src)
        assert not changed
        assert out == src

    def test_no_ampersand_unchanged(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = "public void click(By locator) {\n    locator.click();\n}\n"
        out, changed = _fix_html_entity_escaping(src)
        assert not changed
        assert out == src

    def test_multiple_generics_in_one_file(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_html_entity_escaping

        src = (
            "    private ThreadLocal&lt;Page&gt; page;\n"
            "    private ThreadLocal&lt;Browser&gt; browser;\n"
            "    private ThreadLocal&lt;BrowserContext&gt; ctx;\n"
        )
        out, changed = _fix_html_entity_escaping(src)
        assert changed
        assert "ThreadLocal<Page>" in out
        assert "ThreadLocal<Browser>" in out
        assert "ThreadLocal<BrowserContext>" in out
        assert "&lt;" not in out

    def test_apply_all_includes_fix_15(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "public class DriverManager {\n"
            "    private static final ThreadLocal&lt;Page&gt; pageLocal"
            " = new ThreadLocal&lt;&gt;();\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="DriverManager.java")
        assert "ThreadLocal<Page>" in out
        assert "&lt;" not in out


# =============================================================================
# Fix 14 — Javadoc placed between method signature and `{`
# =============================================================================


class TestFix14JavadocAfterSignature:
    """Fix 14: move /** ... */ that the LLM places after `)` and before `{`
    to above the method signature.
    """

    def test_single_line_javadoc_moved_above_signature(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = "    public static void click(By locator) /** Clicks element */ {\n"
        out, changed = _fix_javadoc_after_signature(src)
        assert changed
        # Javadoc must now precede the method signature.
        javadoc_pos = out.index("/** Clicks element */")
        sig_pos = out.index("public static void click")
        assert javadoc_pos < sig_pos, "Javadoc must appear before the signature"
        # Brace still present and method body intact.
        assert " {" in out

    def test_javadoc_already_above_unchanged(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = (
            "    /** Clicks element */\n"
            "    public static void click(By locator) {\n"
        )
        out, changed = _fix_javadoc_after_signature(src)
        assert not changed
        assert out == src

    def test_no_javadoc_unchanged(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = "    public void doSomething() {\n        x = 1;\n    }\n"
        out, changed = _fix_javadoc_after_signature(src)
        assert not changed
        assert out == src

    def test_private_method_with_throws(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = (
            "    private void load(String path) throws IOException"
            " /** Loads resource */ {\n"
        )
        out, changed = _fix_javadoc_after_signature(src)
        assert changed
        javadoc_pos = out.index("/** Loads resource */")
        sig_pos = out.index("private void load")
        assert javadoc_pos < sig_pos

    def test_multiple_methods_all_fixed(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = (
            "    public void foo() /** First */ {\n"
            "        // body\n"
            "    }\n"
            "\n"
            "    public void bar(int x) /** Second */ {\n"
            "        // body\n"
            "    }\n"
        )
        out, changed = _fix_javadoc_after_signature(src)
        assert changed
        # Both Javadocs should appear before their respective signatures.
        first_doc = out.index("/** First */")
        first_sig = out.index("public void foo()")
        second_doc = out.index("/** Second */")
        second_sig = out.index("public void bar(int x)")
        assert first_doc < first_sig
        assert second_doc < second_sig

    def test_indentation_preserved_after_move(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_javadoc_after_signature

        src = "    public void go() /** Go! */ {\n"
        out, changed = _fix_javadoc_after_signature(src)
        assert changed
        lines = out.splitlines()
        # Both the Javadoc line and the signature line should share the same indent.
        assert lines[0].startswith("    /** Go! */")
        assert lines[1].startswith("    public void go()")

    def test_apply_all_includes_fix_14(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "public class Actions {\n"
            "    public void click(By locator) /** Clicks */ {\n"
            "        locator.click();\n"
            "    }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="Actions.java")
        javadoc_pos = out.index("/** Clicks */")
        sig_pos = out.index("public void click(By locator)")
        assert javadoc_pos < sig_pos

    def test_fix_14_and_fix_15_together(self) -> None:
        """Both fixes applied in a single pass — simulates DriverManager.java pattern."""
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "public class DriverManager {\n"
            "    private static ThreadLocal&lt;Page&gt; page = new ThreadLocal&lt;&gt;();\n"
            "\n"
            "    public static Page getPage() /** Returns the thread-local Page */ {\n"
            "        return page.get();\n"
            "    }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="DriverManager.java")
        # Fix 15: HTML entities decoded.
        assert "ThreadLocal<Page>" in out
        assert "&lt;" not in out
        # Fix 14: Javadoc above the signature.
        javadoc_pos = out.index("/** Returns the thread-local Page */")
        sig_pos = out.index("public static Page getPage()")
        assert javadoc_pos < sig_pos
