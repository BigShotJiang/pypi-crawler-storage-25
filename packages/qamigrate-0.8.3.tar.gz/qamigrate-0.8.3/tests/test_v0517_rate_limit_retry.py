"""
Regression tests for v0.5.17 rate-limit retry handling.

Production project run revealed: when Anthropic's 30K input-tokens-per-minute
org limit is exceeded, files were failing fast (3-second 429 errors) instead
of backing off and retrying. The retry helper introduces exponential backoff
with Retry-After hint support.
"""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest

from qamigrate.llm.retry import (
    DEFAULT_INITIAL_BACKOFF_SEC,
    _parse_retry_after,
    call_with_retry,
    is_overloaded_error,
    is_rate_limit_error,
)


# =============================================================================
# Error classification
# =============================================================================


class TestErrorClassification:
    def test_anthropic_429_classified_as_rate_limit(self) -> None:
        e = Exception(
            "Error code: 429 - {'type': 'error', 'error': {"
            "'type': 'rate_limit_error', 'message': 'rate limit exceeded'}}"
        )
        assert is_rate_limit_error(e)

    def test_openai_429_classified_as_rate_limit(self) -> None:
        e = Exception("Error code: 429 - rate_limit_exceeded")
        assert is_rate_limit_error(e)

    def test_too_many_requests_classified_as_rate_limit(self) -> None:
        e = Exception("HTTP 429 Too Many Requests")
        assert is_rate_limit_error(e)

    def test_anthropic_overloaded_classified_separately(self) -> None:
        e = Exception("Error code: 529 - overloaded_error")
        assert is_overloaded_error(e)
        assert not is_rate_limit_error(e)

    def test_503_classified_as_overloaded(self) -> None:
        e = Exception("Error 503 service_unavailable")
        assert is_overloaded_error(e)

    def test_unrelated_error_not_classified(self) -> None:
        e = Exception("Internal server error")
        assert not is_rate_limit_error(e)
        assert not is_overloaded_error(e)


# =============================================================================
# Retry-After parsing
# =============================================================================


class TestRetryAfterParsing:
    def test_parses_seconds_hint(self) -> None:
        e = Exception("rate limit hit; retry after 12 seconds")
        assert _parse_retry_after(e) == 12.0

    def test_parses_decimal_seconds(self) -> None:
        e = Exception("retry after 4.5s")
        assert _parse_retry_after(e) == 4.5

    def test_parses_minutes(self) -> None:
        # v0.6.1: retry-after hints are honored up to 300s (was 90s).
        # Provider-supplied hints are guidance, not generic backoff —
        # ignoring them caused retries to hit the same wall.
        e = Exception("rate limit; try after 2 minutes")
        assert _parse_retry_after(e) == 120.0  # 2 minutes, no clamp

    def test_no_hint_returns_none(self) -> None:
        e = Exception("rate limit exceeded")
        assert _parse_retry_after(e) is None

    def test_caps_to_retry_after_max(self) -> None:
        # v0.6.1: 999s clamps to DEFAULT_MAX_RETRY_AFTER_SEC (300s).
        e = Exception("retry after 999 seconds")
        result = _parse_retry_after(e)
        assert result is not None
        assert result == 300.0


# =============================================================================
# Retry behaviour
# =============================================================================


class TestCallWithRetry:
    def test_success_on_first_attempt_no_retry(self) -> None:
        calls = []
        def fn():
            calls.append(1)
            return "ok"
        result = call_with_retry(fn, max_retries=3, initial_backoff=0.01)
        assert result == "ok"
        assert len(calls) == 1

    def test_non_rate_limit_error_propagates_immediately(self) -> None:
        calls = []
        def fn():
            calls.append(1)
            raise ValueError("schema mismatch")
        with pytest.raises(ValueError):
            call_with_retry(fn, max_retries=3, initial_backoff=0.01)
        assert len(calls) == 1  # No retry

    def test_rate_limit_error_retries_then_succeeds(self) -> None:
        calls = []
        def fn():
            calls.append(1)
            if len(calls) < 3:
                raise Exception("Error 429 rate_limit_exceeded")
            return "ok"
        with patch("qamigrate.llm.retry.time.sleep"):  # skip real sleep
            result = call_with_retry(fn, max_retries=5, initial_backoff=0.01)
        assert result == "ok"
        assert len(calls) == 3

    def test_rate_limit_exhaustion_raises(self) -> None:
        calls = []
        def fn():
            calls.append(1)
            raise Exception("Error 429 rate_limit_exceeded")
        with patch("qamigrate.llm.retry.time.sleep"):
            with pytest.raises(Exception, match="429"):
                call_with_retry(fn, max_retries=2, initial_backoff=0.01)
        # 1 initial + 2 retries = 3 attempts
        assert len(calls) == 3

    def test_overloaded_treated_like_rate_limit(self) -> None:
        calls = []
        def fn():
            calls.append(1)
            if len(calls) < 2:
                raise Exception("Error 529 overloaded_error")
            return "ok"
        with patch("qamigrate.llm.retry.time.sleep"):
            result = call_with_retry(fn, max_retries=3, initial_backoff=0.01)
        assert result == "ok"
        assert len(calls) == 2

    def test_uses_retry_after_hint_when_present(self) -> None:
        calls = []
        sleeps = []
        def fn():
            calls.append(1)
            if len(calls) < 2:
                raise Exception("Error 429 rate_limit; retry after 7 seconds")
            return "ok"
        with patch(
            "qamigrate.llm.retry.time.sleep",
            side_effect=lambda s: sleeps.append(s),
        ):
            call_with_retry(fn, max_retries=3, initial_backoff=1.0)
        # Should have used the 7-second hint, not the 1-second initial backoff
        assert sleeps == [7.0]

    def test_exponential_backoff_when_no_hint(self) -> None:
        calls = []
        sleeps = []
        def fn():
            calls.append(1)
            if len(calls) < 4:
                raise Exception("Error 429 rate_limit_exceeded")
            return "ok"
        with patch(
            "qamigrate.llm.retry.time.sleep",
            side_effect=lambda s: sleeps.append(s),
        ):
            call_with_retry(fn, max_retries=5, initial_backoff=1.0, max_backoff=20.0)
        # 1, 2, 4 (then succeeds)
        assert sleeps == [1.0, 2.0, 4.0]
