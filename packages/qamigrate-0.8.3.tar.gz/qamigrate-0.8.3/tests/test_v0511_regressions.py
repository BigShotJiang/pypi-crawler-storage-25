"""
Regression tests for v0.5.11 postgen fixes:

Fix 4: AssertJ imports stripped, boolean assertions → Playwright assertThat.
Fix 5: Leftover Selenium/TestNG imports stripped.
Fix 6: WaitForSelectorState import added when type is used but not imported.
"""

from __future__ import annotations

from qamigrate.core.postgen_fixes import (
    _ensure_wait_for_selector_state_import,
    _fix_assertj_imports,
    _fix_leftover_selenium_imports,
    apply_all_postgen_fixes,
)


# =============================================================================
# Fix 4 -- AssertJ import removal
# =============================================================================


class TestAssertJFix:
    def test_removes_static_assertj_import(self) -> None:
        src = (
            "import static org.assertj.core.api.Assertions.assertThat;\n"
            "public class WaitUtils {}\n"
        )
        out, changed = _fix_assertj_imports(src)
        assert changed
        assert "org.assertj" not in out

    def test_removes_package_assertj_import(self) -> None:
        src = (
            "import org.assertj.core.api.Assertions;\n"
            "public class Foo {}\n"
        )
        out, changed = _fix_assertj_imports(src)
        assert changed
        assert "org.assertj" not in out

    def test_rewrites_isvisible_istrue_to_playwright(self) -> None:
        src = (
            "import static org.assertj.core.api.Assertions.assertThat;\n"
            "assertThat(locator.isVisible()).isTrue();\n"
        )
        out, _ = _fix_assertj_imports(src)
        assert "assertThat(locator).isVisible()" in out
        assert ".isTrue()" not in out

    def test_rewrites_isvisible_isfalse_to_hidden(self) -> None:
        src = (
            "import static org.assertj.core.api.Assertions.assertThat;\n"
            "assertThat(btn.isVisible()).isFalse();\n"
        )
        out, _ = _fix_assertj_imports(src)
        assert "assertThat(btn).isHidden()" in out

    def test_adds_playwright_assert_import_when_needed(self) -> None:
        src = (
            "import static org.assertj.core.api.Assertions.assertThat;\n"
            "assertThat(locator.isVisible()).isTrue();\n"
        )
        out, _ = _fix_assertj_imports(src)
        assert "PlaywrightAssertions.assertThat" in out

    def test_no_assertj_no_change(self) -> None:
        src = "import com.microsoft.playwright.Page;\npublic class Foo {}\n"
        out, changed = _fix_assertj_imports(src)
        assert not changed
        assert out is src


# =============================================================================
# Fix 5 -- Leftover Selenium/TestNG imports stripped
# =============================================================================


class TestSeleniumImportStrip:
    def test_removes_selenium_import(self) -> None:
        src = (
            "import org.openqa.selenium.WebDriver;\n"
            "import com.microsoft.playwright.Page;\n"
            "public class Foo {}\n"
        )
        out, changed = _fix_leftover_selenium_imports(src)
        assert changed
        assert "org.openqa.selenium" not in out
        assert "com.microsoft.playwright.Page" in out

    def test_removes_multiple_selenium_imports(self) -> None:
        src = (
            "import org.openqa.selenium.WebDriver;\n"
            "import org.openqa.selenium.By;\n"
            "import org.openqa.selenium.support.FindBy;\n"
            "public class Foo {}\n"
        )
        out, changed = _fix_leftover_selenium_imports(src)
        assert changed
        assert "org.openqa.selenium" not in out

    def test_removes_testng_imports_except_test(self) -> None:
        src = (
            "import org.testng.annotations.BeforeMethod;\n"
            "import org.testng.annotations.AfterMethod;\n"
            "public class T {}\n"
        )
        out, changed = _fix_leftover_selenium_imports(src)
        assert changed
        assert "BeforeMethod" not in out
        assert "AfterMethod" not in out

    def test_removes_testng_assert_static_import(self) -> None:
        src = "import static org.testng.Assert.assertEquals;\npublic class T {}\n"
        out, changed = _fix_leftover_selenium_imports(src)
        assert changed
        assert "org.testng.Assert" not in out

    def test_no_selenium_no_change(self) -> None:
        src = "import com.microsoft.playwright.Page;\npublic class Foo {}\n"
        out, changed = _fix_leftover_selenium_imports(src)
        assert not changed
        assert out is src


# =============================================================================
# Fix 6 -- WaitForSelectorState import guard
# =============================================================================


class TestWaitForSelectorStateImportGuard:
    def test_adds_import_when_missing(self) -> None:
        src = (
            "import com.microsoft.playwright.Locator;\n"
            "locator.waitFor(new Locator.WaitForOptions()"
            ".setState(WaitForSelectorState.HIDDEN));\n"
        )
        out, changed = _ensure_wait_for_selector_state_import(src)
        assert changed
        assert "import com.microsoft.playwright.options.WaitForSelectorState;" in out

    def test_no_change_when_already_present(self) -> None:
        src = (
            "import com.microsoft.playwright.options.WaitForSelectorState;\n"
            "WaitForSelectorState.HIDDEN\n"
        )
        out, changed = _ensure_wait_for_selector_state_import(src)
        assert not changed

    def test_no_change_when_type_not_used(self) -> None:
        src = "public class Foo {}\n"
        out, changed = _ensure_wait_for_selector_state_import(src)
        assert not changed


# =============================================================================
# Integration: apply_all_postgen_fixes with all new rules
# =============================================================================


class TestAllFixesIntegration:
    def test_waitutils_scenario(self) -> None:
        """Simulates the WaitUtils.java failure from v0.5.10 test report."""
        src = (
            "package com.qastarter.utils.playwright;\n"
            "import static org.assertj.core.api.Assertions.assertThat;\n"
            "import org.openqa.selenium.WebDriver;\n"
            "import com.microsoft.playwright.Locator;\n"
            "public class WaitUtils {\n"
            "    public void waitForVisible(Locator loc) {\n"
            "        assertThat(loc.isVisible()).isTrue();\n"
            "    }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src)
        # AssertJ import gone, Selenium import gone.
        assert "org.assertj" not in out
        assert "org.openqa.selenium" not in out
        # Playwright assertion imported and used.
        assert "PlaywrightAssertions.assertThat" in out
        assert "assertThat(loc).isVisible()" in out

    def test_basepage_scenario(self) -> None:
        """Simulates BasePage.java with Selenium stubs + Locator.State."""
        src = (
            "package com.example.playwright;\n"
            "import org.openqa.selenium.support.PageFactory;\n"
            "import com.microsoft.playwright.Locator;\n"
            "public class BasePage {\n"
            "    locator.waitFor(new Locator.WaitForOptions()"
            ".setState(Locator.State.HIDDEN));\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src)
        assert "org.openqa.selenium" not in out
        assert "WaitForSelectorState.HIDDEN" in out
        assert "import com.microsoft.playwright.options.WaitForSelectorState;" in out
