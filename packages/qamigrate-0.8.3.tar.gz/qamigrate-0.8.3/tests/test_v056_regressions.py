"""
Regression tests for v0.5.6 fixes from the v0.5.5 real-project test report.

P0 #1: --confidence-threshold exits code 0 instead of 2 when gate breaches.
P0 #2: Fixer replaces getPage() with getDriver() causing type mismatch.
"""

from __future__ import annotations

from pathlib import Path

from qamigrate.core.confidence_gate import evaluate_confidence_gate
from qamigrate.core.report import Hallucination, MigrationRecord, MigrationReport


# =============================================================================
# P0 #1 -- confidence gate exit-code ordering
# =============================================================================


def _record(source: str, *, success: bool = True, compiled: bool | None = True,
            hallucinations: int = 0) -> MigrationRecord:
    return MigrationRecord(
        source_path=source,
        output_path=f"{source}.out" if success else None,
        success=success,
        duration_seconds=1.0,
        compilation_attempts=0,
        compiled=compiled,
        hallucinations=[
            Hallucination(called_method="X.foo()", on_class="X")
            for _ in range(hallucinations)
        ],
    )


def _make_report(records: list[MigrationRecord]) -> MigrationReport:
    r = MigrationReport()
    for rec in records:
        r.add(rec)
    r.finish()
    return r


class TestConfidenceGateOrdering:
    """The confidence gate must be evaluated even when failed_count > 0.

    In v0.5.5 the gate was placed AFTER `if failed_count > 0: raise Exit(1)`,
    so any run with a failed file (exit 1) would never reach the gate (exit 2).
    The fix: evaluate the gate first, then check failed_count.

    We test the gate logic directly (not the CLI wiring) to keep these fast,
    but also verify the gate evaluates correctly with mixed-success reports.
    """

    def test_gate_evaluates_even_when_failed_records_present(self) -> None:
        # One failed file + one low-confidence file. Gate must still fire.
        report = _make_report([
            _record("ok.java"),
            _record("fail.java", success=False, compiled=None),
            _record("low.java", hallucinations=4),  # confidence = 60
        ])
        result = evaluate_confidence_gate(report, threshold=80, mode="any")
        assert result.passed is False
        assert any(r.source_path == "low.java" for r in result.offending_records)

    def test_gate_passes_when_all_successful_above_threshold(self) -> None:
        report = _make_report([
            _record("a.java"),
            _record("b.java"),
        ])
        result = evaluate_confidence_gate(report, threshold=80, mode="any")
        assert result.passed is True

    def test_gate_any_mode_ignores_failed_records(self) -> None:
        # Failed records shouldn't be penalised by the gate -- they already
        # trigger exit(1) on the failed_count path.
        report = _make_report([
            _record("fail.java", success=False, compiled=None),
        ])
        result = evaluate_confidence_gate(report, threshold=80, mode="any")
        assert result.passed is True  # no successful-but-low records

    def test_gate_avg_mode_uses_all_records_for_average(self) -> None:
        # avg mode uses MigrationReport.average_confidence which includes
        # ALL records (failed ones have confidence=0). Two files: one at
        # 100, one failed at 0 → avg = 50, below threshold 80.
        report = _make_report([
            _record("solid.java"),                             # confidence=100
            _record("fail.java", success=False, compiled=None),  # confidence=0
        ])
        result = evaluate_confidence_gate(report, threshold=80, mode="avg")
        # avg = (100 + 0) / 2 = 50 < 80 → gate fails.
        assert result.passed is False

    def test_gate_any_mode_does_not_flag_failed_records(self) -> None:
        # "any" mode only flags files where success=True but confidence < threshold.
        # A success=False file is already counted as a hard failure -- gate skips it.
        report = _make_report([
            _record("solid.java"),                             # success, high confidence
            _record("fail.java", success=False, compiled=None),  # failure, not gated
        ])
        result = evaluate_confidence_gate(report, threshold=80, mode="any")
        # Only solid.java is success=True and it's above threshold → passes.
        assert result.passed is True


# =============================================================================
# P0 #2 -- fixer must not rename getPage() to getDriver()
# =============================================================================


class TestFixerDoesNotRenameGetPage:
    """FIXER_SYSTEM_PROMPT must contain explicit rules preventing the
    getPage() → getDriver() substitution that caused BaseTest.java to fail."""

    def test_fixer_prompt_warns_against_getdriver_substitution(self) -> None:
        from qamigrate.agents.fixer import FIXER_SYSTEM_PROMPT
        prompt_lower = FIXER_SYSTEM_PROMPT.lower()
        # Must mention both the wrong substitution and the correct fix.
        assert "getdriver" in prompt_lower, (
            "Prompt must explicitly warn against getDriver() substitution"
        )
        assert "getpage" in prompt_lower, (
            "Prompt must mention getPage() to guide the fixer"
        )

    def test_fixer_prompt_warns_about_playwright_import_path_fix(self) -> None:
        from qamigrate.agents.fixer import FIXER_SYSTEM_PROMPT
        # The real fix for 'cannot find symbol' on sibling classes is a
        # .playwright import path fix, not a method rename.
        assert ".playwright" in FIXER_SYSTEM_PROMPT

    def test_fixer_prompt_has_do_not_rename_rule(self) -> None:
        from qamigrate.agents.fixer import FIXER_SYSTEM_PROMPT
        # Must have a "do NOT change the method name" instruction.
        lower = FIXER_SYSTEM_PROMPT.lower()
        assert "do not" in lower or "don't" in lower or "not change" in lower
