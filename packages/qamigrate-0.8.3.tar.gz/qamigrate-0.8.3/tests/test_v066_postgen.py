"""
Regression tests for v0.6.6 — three new postgen rules driven by the
v0.6.5 multi-project test report (3 projects, 117 files, 20 mvn errors).

Fix 16 (Bug C) — orphan Selenium identifiers in code.
Fix 17 (Bug B) — constructor-arity guard against invented overloads.
Fix 18 (Bug A) — hallucinated sibling-method rewrite (conservative).

Plus a Bug E (Windows --exclude) regression test in test_v065_cli.py
gets reinforced by passing backslash-form patterns through.
"""

from __future__ import annotations


# =============================================================================
# Fix 16 — orphan Selenium identifiers
# =============================================================================


class TestFix16OrphanSeleniumSymbols:
    def test_orphan_webdriver_in_body_is_commented(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        # No `import` for WebDriver, but a body reference exists.
        src = (
            "package com.example.playwright;\n"
            "\n"
            "public class Foo {\n"
            "    private WebDriver driver;\n"
            "    public void init() { driver = null; }\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert changed
        # The line is preserved as a comment with a review marker.
        assert "// QAMigrate: orphan Selenium symbol — review" in out
        assert "// private WebDriver driver;" in out
        # And the original uncommented line is gone.
        assert "    private WebDriver driver;\n" not in out

    def test_webdriver_with_matching_import_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "import org.openqa.selenium.WebDriver;\n"
            "public class Foo {\n"
            "    private WebDriver driver;\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert not changed
        assert out == src

    def test_wildcard_import_protects_body_reference(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "import org.openqa.selenium.*;\n"
            "public class Foo {\n"
            "    private WebDriver driver;\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert not changed

    def test_webdriver_in_comment_only_is_left_alone(self) -> None:
        # The v0.6.5 test report flagged this as a bug, but it isn't:
        # a Java comment containing "WebDriver" is harmless.
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "public class Foo {\n"
            "    // Migration: Replaced WebDriver.get() with Page.navigate()\n"
            "    public void open() { page.navigate(url); }\n"
            "}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert not changed

    def test_block_comment_with_webdriver_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_orphan_selenium_symbols

        src = (
            "/**\n"
            " * Migrates from WebDriver to Playwright.\n"
            " */\n"
            "public class Foo {}\n"
        )
        out, changed = _fix_orphan_selenium_symbols(src)
        assert not changed

    def test_apply_all_invokes_fix_16(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "public class Foo {\n"
            "    private WebDriver driver;\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="Foo.java")
        assert "// QAMigrate: orphan Selenium symbol" in out


# =============================================================================
# Fix 17 — constructor-arity guard
# =============================================================================


class TestFix17ConstructorArityGuard:
    def test_invented_2_arg_constructor_dropped_to_1_arg(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        class_api = {
            "InvalidPathException": {
                "constructor_arities": {1},
                "method_names": [],
            }
        }
        src = 'throw new InvalidPathException("bad path", e);\n'
        out, changed = _fix_invented_constructor_arity(src, class_api)
        assert changed
        assert 'new InvalidPathException("bad path")' in out
        # The dropped `e` argument should not appear in the new constructor call.
        assert 'new InvalidPathException("bad path", e)' not in out

    def test_known_arity_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        class_api = {
            "Foo": {"constructor_arities": {1, 2}, "method_names": []}
        }
        src = "Foo f = new Foo(\"a\", \"b\");\n"
        out, changed = _fix_invented_constructor_arity(src, class_api)
        assert not changed

    def test_unknown_class_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        # Foo is NOT in the class_api → not a project-defined class → leave alone.
        class_api = {
            "Bar": {"constructor_arities": {1}, "method_names": []}
        }
        src = "new Foo(a, b, c, d);\n"
        out, changed = _fix_invented_constructor_arity(src, class_api)
        assert not changed

    def test_args_with_commas_inside_parens(self) -> None:
        # The arg-splitter must respect nested parens.
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        class_api = {
            "Foo": {"constructor_arities": {1}, "method_names": []}
        }
        src = "new Foo(formatMessage(a, b), e);\n"
        out, changed = _fix_invented_constructor_arity(src, class_api)
        assert changed
        # The first arg (with its inner `,`) is preserved; the trailing `e` is dropped.
        assert "new Foo(formatMessage(a, b))" in out

    def test_args_with_commas_inside_string_literal(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        class_api = {
            "Foo": {"constructor_arities": {1}, "method_names": []}
        }
        src = 'new Foo("a, b, c", extra);\n'
        out, changed = _fix_invented_constructor_arity(src, class_api)
        assert changed
        assert 'new Foo("a, b, c")' in out

    def test_no_class_api_disables_fix(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_invented_constructor_arity

        src = "new Anything(a, b, c);\n"
        out, changed = _fix_invented_constructor_arity(src, None)
        assert not changed
        assert out == src

    def test_apply_all_invokes_fix_17_when_class_api_supplied(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        api = {
            "MyError": {"constructor_arities": {1}, "method_names": []}
        }
        src = 'throw new MyError("oops", cause);\n'
        out = apply_all_postgen_fixes(src, file_path="t.java", class_api=api)
        assert 'new MyError("oops")' in out


# =============================================================================
# Fix 18 — hallucinated sibling method rewrite
# =============================================================================


class TestFix18HallucinatedMethodRewrite:
    def test_close_name_single_candidate_rewritten(self) -> None:
        # `getDriver` exists; `getDriverr` does not. Edit distance = 1, exactly
        # one candidate within distance 2 → rewrite.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver", "quitDriver"],
            }
        }
        src = "Page p = DriverManager.getDriverr();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert changed
        assert "DriverManager.getDriver()" in out
        assert any("getDriverr" in line and "getDriver" in line for line in log)

    def test_real_method_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver"],
            }
        }
        src = "Page p = DriverManager.getDriver();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed
        assert log == []

    def test_ambiguous_match_left_alone(self) -> None:
        # Two equally-close candidates → don't guess.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {
            "Foo": {
                "constructor_arities": {0},
                "method_names": ["info", "warn"],   # both edit distance 4 from "logs"
            }
        }
        src = "Foo.logs(msg);\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        # `logs` -> `info` distance is 4, `logs` -> `warn` distance is 4.
        # Both > 2, so no candidates survive — no rewrite. (Different reason
        # than ambiguity, but the *outcome* is the same: don't touch it.)
        assert not changed

    def test_ambiguous_match_within_distance_2_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        # Two candidates BOTH within edit distance 2 → ambiguous → no fix.
        api = {
            "Foo": {
                "constructor_arities": {0},
                "method_names": ["loga", "logb"],   # both distance 1 from "logc"
            }
        }
        src = "Foo.logc();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed

    def test_unknown_class_left_alone(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {"Other": {"constructor_arities": {0}, "method_names": ["x"]}}
        src = "Foo.bar();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed

    def test_short_method_name_not_rewritten(self) -> None:
        # Names ≤ 3 chars are too easy to spuriously match; we skip them.
        from qamigrate.core.postgen_fixes import _fix_hallucinated_static_method

        api = {"Foo": {"constructor_arities": {0}, "method_names": ["get"]}}
        src = "Foo.set();\n"
        out, changed, log = _fix_hallucinated_static_method(src, api)
        assert not changed

    def test_apply_all_invokes_fix_18(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        api = {
            "DriverManager": {
                "constructor_arities": {0},
                "method_names": ["getDriver"],
            }
        }
        src = (
            "public class B {\n"
            "    public Page getPage() { return DriverManager.getDriverr(); }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="B.java", class_api=api)
        assert "DriverManager.getDriver()" in out


# =============================================================================
# Helper coverage
# =============================================================================


class TestSplitTopLevelArgs:
    def test_simple(self) -> None:
        from qamigrate.core.postgen_fixes import _split_top_level_args

        assert _split_top_level_args("a, b, c") == ["a", "b", "c"]

    def test_nested_parens(self) -> None:
        from qamigrate.core.postgen_fixes import _split_top_level_args

        assert _split_top_level_args("foo(a, b), c") == ["foo(a, b)", "c"]

    def test_string_with_comma(self) -> None:
        from qamigrate.core.postgen_fixes import _split_top_level_args

        assert _split_top_level_args('"a, b", c') == ['"a, b"', "c"]

    def test_empty_arglist(self) -> None:
        from qamigrate.core.postgen_fixes import _split_top_level_args

        # An empty arglist returns an empty list — `_fix_invented_constructor_arity`
        # treats this as arity 0.
        assert _split_top_level_args("") == []


class TestEditDistance:
    def test_identical(self) -> None:
        from qamigrate.core.postgen_fixes import _edit_distance
        assert _edit_distance("foo", "foo") == 0

    def test_single_substitution(self) -> None:
        from qamigrate.core.postgen_fixes import _edit_distance
        assert _edit_distance("foo", "fop") == 1

    def test_insertion(self) -> None:
        from qamigrate.core.postgen_fixes import _edit_distance
        assert _edit_distance("getDriver", "getDriverr") == 1
