"""
Regression tests for v0.5.8 fixes from the v0.5.7 real-project test report.

Fix 1: os._exit(2) for confidence gate (sys.exit can still be caught on Windows).
Fix 2: @Listeners({X.class}) → @ExtendWith(X.class) + correct import.
Fix 3: ScreenshotOptions hallucinated import fix.
"""

from __future__ import annotations

from qamigrate.core.postgen_fixes import (
    apply_all_postgen_fixes,
    _fix_listeners_annotation,
    _fix_screenshot_options_import,
)


# =============================================================================
# Fix 1 -- os._exit(2) in gate
# =============================================================================


class TestGateUsesOsExit:
    def test_gate_uses_typer_exit_or_os_exit(self) -> None:
        """v0.5.9: gate uses raise typer.Exit(code=2) as primary mechanism,
        which works correctly in all environments including Windows .exe."""
        import inspect
        import qamigrate.cli.main as cli
        src = inspect.getsource(cli)
        # Must have either typer.Exit(code=2) or os._exit(2).
        assert ("typer.Exit(code=2)" in src or "os._exit(2)" in src), (
            "Gate must use typer.Exit(code=2) or os._exit(2)"
        )
        # Must NOT use the old uncoded form typer.Exit(2) without 'code='.
        # (typer.Exit(code=2) is fine; typer.Exit(2) positionally is also fine
        # but we prefer the named form for clarity)
        assert "raise typer.Exit(2)" not in src or "raise typer.Exit(code=2)" in src


# =============================================================================
# Fix 2 -- @Listeners → @ExtendWith
# =============================================================================


class TestListenersAnnotationFix:
    def test_single_listener_safe_remove_when_no_extension_classes(self) -> None:
        # v0.5.9: without extension_classes, @Listeners is replaced with
        # a TODO comment (safe path -- avoids broken @ExtendWith).
        src = """package com.example.playwright;
import org.testng.annotations.Listeners;
@Listeners({TestListener.class})
public class BaseTest {}
"""
        out, changed = _fix_listeners_annotation(src)
        assert changed
        assert "// TODO" in out  # safe TODO comment emitted
        assert "import org.testng.annotations.Listeners" not in out
        # The annotation form @Listeners({...}) must not remain.
        import re
        assert not re.search(r"@Listeners\s*\(", out)
        # @ExtendWith annotation must not be present (only in comments is ok).
        assert not re.search(r"@ExtendWith\s*\(", out)

    def test_single_listener_rewritten_when_confirmed_extension(self) -> None:
        # When caller confirms TestListener implements Extension, rewrite applies.
        src = "@Listeners({TestListener.class})\npublic class T {}"
        out, changed = _fix_listeners_annotation(src, extension_classes={"TestListener"})
        assert changed
        assert "@ExtendWith(TestListener.class)" in out
        assert "@Listeners" not in out

    def test_multiple_listeners_safe_remove(self) -> None:
        import re
        src = "@Listeners({ListenerA.class, ListenerB.class})\npublic class T {}"
        out, changed = _fix_listeners_annotation(src)
        assert changed
        assert "TODO" in out
        assert not re.search(r"@Listeners\s*\(", out)
        assert not re.search(r"@ExtendWith\s*\(", out)

    def test_no_listeners_unchanged(self) -> None:
        src = "@Test\npublic class T {}"
        out, changed = _fix_listeners_annotation(src)
        assert not changed
        assert out == src

    def test_already_extendwith_unchanged(self) -> None:
        src = "@ExtendWith(TestListener.class)\npublic class T {}"
        out, changed = _fix_listeners_annotation(src)
        assert not changed

    def test_extendwith_import_not_doubled(self) -> None:
        src = (
            "import org.junit.jupiter.api.extension.ExtendWith;\n"
            "@Listeners({X.class})\npublic class T {}"
        )
        out, _ = _fix_listeners_annotation(src)
        assert out.count("import org.junit.jupiter.api.extension.ExtendWith;") == 1


# =============================================================================
# Fix 3 -- ScreenshotOptions import fix
# =============================================================================


class TestScreenshotOptionsImportFix:
    def test_removes_fake_import_and_qualifies_usage(self) -> None:
        src = (
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "ScreenshotOptions opts = new ScreenshotOptions();\n"
        )
        out, changed = _fix_screenshot_options_import(src)
        assert changed
        assert "import com.microsoft.playwright.options.ScreenshotOptions" not in out
        assert "Page.ScreenshotOptions" in out
        assert "import com.microsoft.playwright.Page;" in out

    def test_no_fake_import_unchanged(self) -> None:
        src = "Page page;\n"
        out, changed = _fix_screenshot_options_import(src)
        assert not changed

    def test_already_qualified_not_doubled(self) -> None:
        # If code already uses Page.ScreenshotOptions, don't double-qualify.
        src = (
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "Page.ScreenshotOptions opts = new Page.ScreenshotOptions();\n"
        )
        out, changed = _fix_screenshot_options_import(src)
        assert changed  # import was still removed
        assert "Page.Page.ScreenshotOptions" not in out

    def test_page_import_not_doubled(self) -> None:
        src = (
            "import com.microsoft.playwright.Page;\n"
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "ScreenshotOptions opts;\n"
        )
        out, _ = _fix_screenshot_options_import(src)
        assert out.count("import com.microsoft.playwright.Page;") == 1


# =============================================================================
# apply_all_postgen_fixes -- integration
# =============================================================================


class TestApplyAllPostgenFixes:
    def test_applies_all_fixes(self) -> None:
        import re
        src = (
            "import org.testng.annotations.Listeners;\n"
            "import com.microsoft.playwright.options.ScreenshotOptions;\n"
            "@Listeners({TestListener.class})\n"
            "public class BaseTest {\n"
            "    ScreenshotOptions opts;\n"
            "}\n"
        )
        # Without extension_classes: @Listeners becomes a TODO (safe).
        out = apply_all_postgen_fixes(src)
        assert not re.search(r"@Listeners\s*\(", out)
        assert "// TODO" in out
        assert "Page.ScreenshotOptions" in out
        assert "import com.microsoft.playwright.options.ScreenshotOptions" not in out

    def test_applies_extendwith_when_confirmed(self) -> None:
        src = (
            "import org.testng.annotations.Listeners;\n"
            "@Listeners({TestListener.class})\n"
            "public class BaseTest {}\n"
        )
        out = apply_all_postgen_fixes(src, extension_classes={"TestListener"})
        assert "@ExtendWith(TestListener.class)" in out
        assert "@Listeners" not in out

    def test_unchanged_source_returns_same_object(self) -> None:
        src = "public class Foo {}\n"
        out = apply_all_postgen_fixes(src)
        assert out is src  # identity: no copy when nothing changed
