"""
Regression tests for v0.5.5 fixes from the v0.5.4 real-project test report.

Fix 1: Sibling imports rewritten to .playwright package path.
Fix 2: Dict-valued elements in fields[] list coerced to string.
Fix 3: Coder prompt contains explicit .playwright import instruction.
"""

from __future__ import annotations

import pytest

# =============================================================================
# Fix 1 -- sibling import rewrite
# =============================================================================


class TestApplyImportRewrite:
    """_apply_import_rewrite rewrites imports of migrated siblings to use
    the .playwright sub-package path, leaving all other imports untouched."""

    def _rewrite(self, src: str, mapping: dict[str, str]) -> str:
        from qamigrate.agents.pipeline import _apply_import_rewrite
        return _apply_import_rewrite(src, mapping)

    def test_rewrites_matching_sibling_import(self) -> None:
        src = "import com.qastarter.browser.BrowserFactory;\n"
        out = self._rewrite(src, {"BrowserFactory": "com.qastarter.browser"})
        assert "import com.qastarter.browser.playwright.BrowserFactory;" in out

    def test_rewrites_multiple_sibling_imports(self) -> None:
        src = (
            "import com.qastarter.browser.BrowserFactory;\n"
            "import com.qastarter.config.Environment;\n"
            "import com.microsoft.playwright.Page;\n"
        )
        out = self._rewrite(src, {
            "BrowserFactory": "com.qastarter.browser",
            "Environment": "com.qastarter.config",
        })
        assert "import com.qastarter.browser.playwright.BrowserFactory;" in out
        assert "import com.qastarter.config.playwright.Environment;" in out
        # Playwright API import must be untouched.
        assert "import com.microsoft.playwright.Page;" in out

    def test_non_sibling_import_unchanged(self) -> None:
        src = "import org.junit.jupiter.api.Test;\n"
        out = self._rewrite(src, {"BrowserFactory": "com.qastarter.browser"})
        assert out == src

    def test_does_not_double_playwright_suffix(self) -> None:
        # If import already has .playwright, leave it alone.
        src = "import com.qastarter.browser.playwright.BrowserFactory;\n"
        out = self._rewrite(src, {"BrowserFactory": "com.qastarter.browser"})
        assert out == src
        assert "playwright.playwright" not in out

    def test_wrong_package_prefix_unchanged(self) -> None:
        # Same simple name but different package -- must NOT be rewritten.
        src = "import com.thirdparty.utils.BrowserFactory;\n"
        out = self._rewrite(src, {"BrowserFactory": "com.qastarter.browser"})
        assert out == src

    def test_non_import_lines_untouched(self) -> None:
        src = (
            "package com.qastarter.core.playwright;\n"
            "import com.qastarter.browser.BrowserFactory;\n"
            "// com.qastarter.browser.BrowserFactory in a comment\n"
            "public class BaseTest {\n"
            "    BrowserFactory factory = new BrowserFactory();\n"
            "}\n"
        )
        out = self._rewrite(src, {"BrowserFactory": "com.qastarter.browser"})
        # Only the import line should change.
        assert "import com.qastarter.browser.playwright.BrowserFactory;" in out
        # Comment and body lines unchanged.
        assert "// com.qastarter.browser.BrowserFactory in a comment" in out
        assert "BrowserFactory factory = new BrowserFactory();" in out

    def test_empty_mapping_returns_src_unchanged(self) -> None:
        src = "import com.example.Foo;\n"
        assert self._rewrite(src, {}) == src


# =============================================================================
# Fix 2 -- dict in fields[] coerced to string
# =============================================================================


class TestSanitizeDictFields:
    """When gpt-4o returns a dict in fields[], sanitize_fields() must extract
    a string rather than letting Pydantic crash with a validation error."""

    def _sanitize(self, data: dict) -> dict:
        from qamigrate.llm.sanitize import sanitize_fields
        return sanitize_fields(data)

    def test_dict_in_fields_extracted_to_string(self) -> None:
        raw = {
            "fields": [
                {"declaration": "private final Page page;", "init": "this.page = page;"},
                "private final Locator username;",
            ]
        }
        clean = self._sanitize(raw)
        assert isinstance(clean["fields"][0], str)
        assert "private final Page page;" in clean["fields"][0]
        assert isinstance(clean["fields"][1], str)

    def test_dict_fallback_priority_order(self) -> None:
        # 'declaration' is checked first.
        raw = {"fields": [{"declaration": "private Page page;", "type": "Page", "name": "page"}]}
        clean = self._sanitize(raw)
        assert clean["fields"][0] == "private Page page;"

    def test_dict_fallback_type_key(self) -> None:
        raw = {"fields": [{"type": "Page", "name": "page"}]}
        clean = self._sanitize(raw)
        assert clean["fields"][0] == "Page"

    def test_methods_list_still_returns_dicts(self) -> None:
        # methods[] items are MethodDefinition objects -- must stay as dicts.
        raw = {
            "methods": [
                {"name": "click", "signature": "public void click()", "implementation": "click();"}
            ]
        }
        clean = self._sanitize(raw)
        assert isinstance(clean["methods"][0], dict)
        assert clean["methods"][0]["name"] == "click"

    def test_string_fields_still_unescaped(self) -> None:
        raw = {"fields": ['private final Page page = \\"x\\";']}
        clean = self._sanitize(raw)
        assert '\\"' not in clean["fields"][0]
        assert '"x"' in clean["fields"][0]

    def test_dict_last_resort_stringified(self) -> None:
        # No known key -- falls back to str().
        raw = {"fields": [{"unknown_key": "something"}]}
        clean = self._sanitize(raw)
        assert isinstance(clean["fields"][0], str)

    def test_imports_list_also_coerces(self) -> None:
        # imports[] is also list[str] in the schema.
        raw = {"imports": [{"import": "com.example.Foo"}, "com.example.Bar"]}
        clean = self._sanitize(raw)
        assert isinstance(clean["imports"][0], str)
        assert isinstance(clean["imports"][1], str)


# =============================================================================
# Fix 3 -- coder prompt contains .playwright import instruction
# =============================================================================


class TestCoderPromptImportInstruction:
    """The coder prompt and sibling block must tell the LLM to append
    .playwright when importing sibling classes."""

    def test_system_prompt_has_playwright_import_rule(self) -> None:
        from qamigrate.agents.coder import SYSTEM_PROMPT
        # Requirement 7 added in v0.5.5.
        assert ".playwright" in SYSTEM_PROMPT
        # The rule number 7 must reference imports.
        assert "import" in SYSTEM_PROMPT.lower()

    def test_sibling_block_contains_import_warning(self) -> None:
        from unittest.mock import MagicMock

        from qamigrate.agents.coder import CoderAgent
        from qamigrate.core.config import CoderConfig

        agent = CoderAgent(CoderConfig(), llm_provider=MagicMock())
        # Call generate_from_class_info with a minimal class_info and one sibling.
        # We want to capture the prompt string -- monkey-patch the provider.
        captured: list[str] = []

        def fake_generate(system, user, tool, **kwargs):
            captured.append(user)
            raise RuntimeError("stop")

        agent.provider.generate_structured = fake_generate  # type: ignore[attr-defined]
        with pytest.raises(RuntimeError):
            agent.generate_from_class_info(
                class_info={"class_name": "BaseTest", "package": "com.example.core"},
                original_code="public class BaseTest {}",
                patterns=[],
                sibling_signatures={"LoginPage": ["public void login(String u, String p)"]},
            )

        assert captured, "Provider was never called"
        prompt = captured[0]
        assert ".playwright" in prompt
        assert "import" in prompt.lower()
