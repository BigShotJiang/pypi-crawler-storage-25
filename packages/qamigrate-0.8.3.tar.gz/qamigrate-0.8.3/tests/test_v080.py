"""
Regression tests for v0.8 — three structural changes:

  1. Closed-world AST reference verification (Coder re-prompts when
     calls don't resolve in the closed world).
  2. `init` recurses into nested pom.xml sub-projects.
  3. Postgen Fix 20: Selenium types in method signatures rewritten to
     Playwright equivalents (By → String, WebElement → Locator). Plus
     the matching prompt addition (system-prompt only — no test, but
     covered by end-to-end runs).
"""

from __future__ import annotations

from pathlib import Path

import pytest


# =============================================================================
# 1. Closed-world reference verification
# =============================================================================


class TestClosedWorldVerifier:
    def test_clean_file_has_no_unresolved_references(self) -> None:
        from qamigrate.core.closed_world import verify

        # All calls resolve: Page is bundled (permissive), and the field
        # `loginPage` declared with type `LoginPage` matches the
        # class_api entry whose method_names contain `click`.
        code = (
            "import com.microsoft.playwright.Page;\n"
            "public class Test {\n"
            "    private LoginPage loginPage;\n"
            "    public void run(Page page) {\n"
            "        page.navigate(\"/\");\n"
            "        loginPage.click();\n"
            "    }\n"
            "}\n"
        )
        api = {"LoginPage": {"method_names": ["click", "fill"]}}
        issues = verify(code, class_api=api)
        assert issues == []

    def test_static_call_to_known_class_unknown_method_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "public class Test {\n"
            "    public void run() {\n"
            "        DriverManager.getPage();\n"
            "    }\n"
            "}\n"
        )
        api = {"DriverManager": {"method_names": ["getDriver", "quitDriver"]}}
        issues = verify(code, class_api=api)
        assert len(issues) == 1
        assert issues[0].receiver_class == "DriverManager"
        assert issues[0].method_name == "getPage"
        # Suggestion should be the closest real method.
        assert issues[0].suggested == "getDriver"

    def test_foreign_imported_class_not_flagged(self) -> None:
        # java.sql.DriverManager: foreign import. Even though the project's
        # DriverManager has no `getConnection`, this call must not be flagged
        # because the receiver is the JDBC class, not the project class.
        from qamigrate.core.closed_world import verify

        code = (
            "import java.sql.DriverManager;\n"
            "import java.sql.Connection;\n"
            "public class DatabaseHelpers {\n"
            "    public Connection open(String url, String u, String p) {\n"
            "        return DriverManager.getConnection(url, u, p);\n"
            "    }\n"
            "}\n"
        )
        api = {"DriverManager": {"method_names": ["getDriver"]}}
        issues = verify(code, class_api=api)
        assert issues == []

    def test_unknown_receiver_passes_silently(self) -> None:
        from qamigrate.core.closed_world import verify

        # `SomeUnknownClass` isn't in class_api or bundled APIs. Verifier
        # is permissive: doesn't flag it.
        code = "public class Test { void f() { SomeUnknownClass.whatever(); } }\n"
        issues = verify(code, class_api={})
        assert issues == []

    def test_field_typed_call_resolved_against_class_api(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "public class Test {\n"
            "    private Helper helper;\n"
            "    public void run() {\n"
            "        helper.unknownMethod();\n"
            "    }\n"
            "}\n"
        )
        api = {"Helper": {"method_names": ["realMethod"]}}
        issues = verify(code, class_api=api)
        assert len(issues) == 1
        assert issues[0].receiver_class == "Helper"
        assert issues[0].method_name == "unknownMethod"

    def test_field_typed_call_to_permissive_playwright_class(self) -> None:
        # Page is in PLAYWRIGHT_JAVA_API with methods=None — permissive.
        # Don't flag arbitrary calls on a Page-typed field.
        from qamigrate.core.closed_world import verify

        code = (
            "public class Test {\n"
            "    private Page page;\n"
            "    public void run() {\n"
            "        page.completelyMadeUpMethod();\n"
            "    }\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        assert issues == []

    def test_trusted_methods_skipped(self) -> None:
        # toString, hashCode, etc. are common across all Java types. We
        # don't validate them.
        from qamigrate.core.closed_world import verify

        code = (
            "public class Test {\n"
            "    public void run() {\n"
            "        SomeClass.toString();\n"
            "    }\n"
            "}\n"
        )
        api = {"SomeClass": {"method_names": []}}
        issues = verify(code, class_api=api)
        assert issues == []

    def test_invented_class_instantiation_flagged(self) -> None:
        """v0.8 production-run regression: WaitUtils referenced
        `new PlaywrightWebElementAdapter(element)` — a class the LLM
        invented to maintain API compatibility. Verifier must catch this.
        """
        from qamigrate.core.closed_world import verify

        code = (
            "import com.microsoft.playwright.Locator;\n"
            "public class WaitUtils {\n"
            "    public Object wait(Locator l) {\n"
            "        return new PlaywrightWebElementAdapter(l);\n"
            "    }\n"
            "}\n"
        )
        api = {"WaitUtils": {"method_names": ["wait"]}}
        issues = verify(code, class_api=api)
        assert any(
            i.receiver_class == "PlaywrightWebElementAdapter"
            and i.method_name == "<init>"
            for i in issues
        )

    def test_common_stdlib_new_not_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "import com.microsoft.playwright.Page;\n"
            "public class Foo {\n"
            "    public void f() {\n"
            "        new ArrayList<>();\n"
            "        new HashMap<>();\n"
            "        new RuntimeException(\"x\");\n"
            "        new ThreadLocal<>();\n"
            "    }\n"
            "}\n"
        )
        issues = verify(code, class_api={})
        assert issues == []

    def test_project_class_new_not_flagged(self) -> None:
        from qamigrate.core.closed_world import verify

        code = (
            "import com.microsoft.playwright.Page;\n"
            "public class TestClass {\n"
            "    public void f() {\n"
            "        LoginPage p = new LoginPage(page);\n"
            "    }\n"
            "}\n"
        )
        api = {"LoginPage": {"method_names": ["click"]}}
        issues = verify(code, class_api=api)
        assert issues == []

    def test_feedback_prompt_lists_each_unresolved_call(self) -> None:
        from qamigrate.core.closed_world import (
            UnresolvedReference,
            build_feedback_prompt,
        )

        issues = [
            UnresolvedReference(
                receiver_class="DriverManager",
                method_name="getPage",
                line_number=14,
                suggested="getDriver",
            ),
        ]
        api = {"DriverManager": {"method_names": ["getDriver", "quitDriver"]}}
        feedback = build_feedback_prompt(issues, class_api=api)
        assert "Verification failed" in feedback
        assert "DriverManager.getPage" in feedback
        assert "Did you mean `getDriver`?" in feedback
        # Method index for the receiver is included.
        assert "getDriver" in feedback
        assert "quitDriver" in feedback


# =============================================================================
# 2. init recursion into nested poms
# =============================================================================


class TestInitNestedPomDetection:
    def test_finds_nested_poms(self, tmp_path: Path) -> None:
        from qamigrate.cli.main import _find_nested_poms

        root = tmp_path / "monorepo"
        root.mkdir()
        (root / "pom.xml").write_text("<project/>", encoding="utf-8")
        (root / "subA").mkdir()
        (root / "subA" / "pom.xml").write_text("<project/>", encoding="utf-8")
        (root / "subB" / "subC").mkdir(parents=True)
        (root / "subB" / "subC" / "pom.xml").write_text("<project/>", encoding="utf-8")

        nested = _find_nested_poms(root)
        # Root pom is excluded; both nested ones are returned.
        assert root / "pom.xml" not in nested
        assert (root / "subA" / "pom.xml") in nested
        assert (root / "subB" / "subC" / "pom.xml") in nested
        assert len(nested) == 2

    def test_excludes_target_directory(self, tmp_path: Path) -> None:
        # poms inside target/ are Maven build output — ignore.
        from qamigrate.cli.main import _find_nested_poms

        root = tmp_path / "monorepo"
        root.mkdir()
        (root / "target" / "dependency").mkdir(parents=True)
        (root / "target" / "dependency" / "pom.xml").write_text("<project/>", encoding="utf-8")
        (root / "subA").mkdir()
        (root / "subA" / "pom.xml").write_text("<project/>", encoding="utf-8")

        nested = _find_nested_poms(root)
        assert (root / "subA" / "pom.xml") in nested
        assert (root / "target" / "dependency" / "pom.xml") not in nested

    def test_no_nested_poms_returns_empty(self, tmp_path: Path) -> None:
        from qamigrate.cli.main import _find_nested_poms

        root = tmp_path / "monorepo"
        root.mkdir()
        (root / "pom.xml").write_text("<project/>", encoding="utf-8")
        assert _find_nested_poms(root) == []


# =============================================================================
# 3. Postgen Fix 20: Selenium types in signatures
# =============================================================================


class TestFix20SeleniumTypesInSignatures:
    def test_by_in_parameter_rewritten_to_string(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_selenium_types_in_signatures

        src = (
            "import com.microsoft.playwright.Page;\n"
            "public class WebActions {\n"
            "    public static void click(By locator) {\n"
            "        page.locator(locator).click();\n"
            "    }\n"
            "}\n"
        )
        out, changed = _fix_selenium_types_in_signatures(src)
        assert changed
        assert "click(String locator)" in out
        assert "By locator)" not in out

    def test_webelement_in_parameter_rewritten_to_locator(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_selenium_types_in_signatures

        src = (
            "import com.microsoft.playwright.Page;\n"
            "public class WaitUtils {\n"
            "    public static void waitFor(WebElement element) {\n"
            "        element.waitFor();\n"
            "    }\n"
            "}\n"
        )
        out, changed = _fix_selenium_types_in_signatures(src)
        assert changed
        assert "waitFor(Locator element)" in out

    def test_no_playwright_import_means_no_rewrite(self) -> None:
        # Conservative: only act when the file has Playwright imports.
        # An unrelated Java file with `By name` shouldn't be touched.
        from qamigrate.core.postgen_fixes import _fix_selenium_types_in_signatures

        src = "public class Foo { public void f(By bar) {} }\n"
        out, changed = _fix_selenium_types_in_signatures(src)
        assert not changed
        assert out == src

    def test_multi_param_signature_rewritten(self) -> None:
        from qamigrate.core.postgen_fixes import _fix_selenium_types_in_signatures

        src = (
            "import com.microsoft.playwright.Page;\n"
            "public class Foo {\n"
            "    public void f(By locator, WebElement el, String s) {}\n"
            "}\n"
        )
        out, changed = _fix_selenium_types_in_signatures(src)
        assert changed
        assert "f(String locator, Locator el, String s)" in out

    def test_fqn_paths_not_corrupted(self) -> None:
        """v0.8 regression: Fix 20 must NOT rewrite `By` inside a fully
        qualified type like `org.openqa.selenium.By by`. Doing so produces
        a malformed `org.openqa.selenium.String by` reference.
        """
        from qamigrate.core.postgen_fixes import _fix_selenium_types_in_signatures

        src = (
            "import com.microsoft.playwright.Page;\n"
            "public class Adapter {\n"
            "    public Object find(org.openqa.selenium.By by) { return null; }\n"
            "}\n"
        )
        out, changed = _fix_selenium_types_in_signatures(src)
        assert not changed
        # FQN preserved.
        assert "org.openqa.selenium.By by" in out

    def test_apply_all_invokes_fix_20(self) -> None:
        from qamigrate.core.postgen_fixes import apply_all_postgen_fixes

        src = (
            "import com.microsoft.playwright.Page;\n"
            "public class WebActions {\n"
            "    public static void click(By locator) {\n"
            "        page.locator(locator).click();\n"
            "    }\n"
            "}\n"
        )
        out = apply_all_postgen_fixes(src, file_path="WebActions.java")
        assert "click(String locator)" in out
