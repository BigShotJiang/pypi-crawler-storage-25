"""
Login Tests - SauceDemo login flow using Selenium + pytest.

Run with: pytest tests/test_login.py -v
"""
import pytest
from pages.login_page import LoginPage
from utils.logger import log
from config.config_reader import config
import allure


@allure.feature("Login")
@allure.story("Authentication")
class TestLogin:
    """Login test cases."""

    @allure.title("Valid Login Test")
    @allure.severity(allure.severity_level.CRITICAL)
    @pytest.mark.smoke
    def test_valid_login(self, driver):
        """Verify successful login with valid credentials."""
        log.step("Testing valid login")

        login_page = LoginPage(driver)
        login_page.navigate_to_login()
        login_page.login(config.username, config.password)

        assert login_page.is_login_successful(), "Login should be successful"
        log.info("Valid login test passed")

    @allure.title("Invalid Login Test")
    @allure.severity(allure.severity_level.NORMAL)
    @pytest.mark.regression
    def test_invalid_login(self, driver):
        """Verify error message with invalid credentials."""
        log.step("Testing invalid login")

        login_page = LoginPage(driver)
        login_page.navigate_to_login()
        login_page.login("invalid_user", "wrong_password")

        assert login_page.is_error_displayed(), "Error message should be displayed"
        log.info("Invalid login test passed - error displayed as expected")

