"""
Logger - Consistent logging across the framework.

Usage:
    from utils.logger import log
    
    log.info("Message")
    log.step("Test step description")
    log.error("Error occurred")
"""
import logging
import os
from datetime import datetime
from pathlib import Path


class Logger:
    """Custom logger with test-focused methods."""
    
    _instance = None
    _logger = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._setup_logger()
        return cls._instance
    
    def _setup_logger(self):
        """Configure logger with file and console handlers."""
        self._logger = logging.getLogger("TestFramework")
        self._logger.setLevel(logging.DEBUG)
        
        # Clear existing handlers
        self._logger.handlers.clear()
        
        # Create logs directory
        logs_dir = Path("logs")
        logs_dir.mkdir(exist_ok=True)
        
        # File handler
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        file_handler = logging.FileHandler(logs_dir / f"test_{timestamp}.log")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s"
        ))
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(levelname)-8s | %(message)s",
            datefmt="%H:%M:%S"
        ))
        
        self._logger.addHandler(file_handler)
        self._logger.addHandler(console_handler)
    
    def info(self, message: str):
        self._logger.info(message)
    
    def debug(self, message: str):
        self._logger.debug(message)
    
    def warning(self, message: str):
        self._logger.warning(message)
    
    def error(self, message: str):
        self._logger.error(message)
    
    def step(self, message: str):
        """Log a test step."""
        self._logger.info(f"STEP: {message}")
    
    def action(self, message: str):
        """Log an action (click, type, etc.)."""
        self._logger.info(f"ACTION: {message}")
    
    def test_start(self, test_name: str):
        """Log test start."""
        self._logger.info("=" * 60)
        self._logger.info(f"TEST START: {test_name}")
        self._logger.info("=" * 60)
    
    def test_end(self, test_name: str, status: str):
        """Log test end."""
        self._logger.info(f"TEST END: {test_name} - {status}")
        self._logger.info("=" * 60)


# Singleton instance
log = Logger()