"""
Base Page - parent class for all Selenium page objects.

The `driver` fixture (provided by conftest.py) is injected into each
page object via the constructor. Tests look like:

    login_page = LoginPage(driver)
    login_page.navigate_to_login()
"""
from typing import Tuple
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    NoSuchElementException,
    StaleElementReferenceException,
    TimeoutException,
)
from utils.logger import log

Locator = Tuple[str, str]


class BasePage:
    """Base class for all page objects."""

    def __init__(self, driver: WebDriver, default_timeout: int = 30):
        self.driver = driver
        self.default_timeout = default_timeout

    # Waits -------------------------------------------------------------

    def _wait(self, timeout: int = None) -> WebDriverWait:
        return WebDriverWait(self.driver, timeout or self.default_timeout)

    def wait_for_element_visible(self, locator: Locator, timeout: int = None) -> WebElement:
        return self._wait(timeout).until(EC.visibility_of_element_located(locator))

    def wait_for_element_clickable(self, locator: Locator, timeout: int = None) -> WebElement:
        return self._wait(timeout).until(EC.element_to_be_clickable(locator))

    # Interactions ------------------------------------------------------

    def click(self, locator: Locator) -> None:
        log.action(f"Click: {locator}")
        self.wait_for_element_clickable(locator).click()

    def type_text(self, locator: Locator, text: str) -> None:
        log.action(f"Type into: {locator}")
        element = self.wait_for_element_visible(locator)
        element.clear()
        element.send_keys(text)

    def get_text(self, locator: Locator) -> str:
        return self.wait_for_element_visible(locator).text

    def is_displayed(self, locator: Locator) -> bool:
        try:
            return self.driver.find_element(*locator).is_displayed()
        except (NoSuchElementException, StaleElementReferenceException, TimeoutException):
            return False

    # Navigation --------------------------------------------------------

    def get_title(self) -> str:
        return self.driver.title

    def get_current_url(self) -> str:
        return self.driver.current_url

    def navigate_to(self, url: str) -> None:
        log.step(f"Navigating to: {url}")
        self.driver.get(url)

    def log_action(self, message: str) -> None:
        log.step(f"[{self.__class__.__name__}] {message}")
