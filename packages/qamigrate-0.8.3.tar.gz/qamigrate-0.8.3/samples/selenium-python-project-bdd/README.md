# selenium-python-project-bdd

Production-ready Selenium WebDriver automation framework built with Python and Pytest.

## 🚀 Features

- **Page Object Model (POM)** - Maintainable test architecture
- **Pytest Framework** - Powerful test execution and reporting
- **Allure Reports** - Beautiful and comprehensive test reports
- **Selenium Manager** - Automatic browser driver management (Selenium 4+)
- **Parallel Execution** - Run tests in parallel for faster feedback
- **GitHub Actions** - CI/CD workflow included
- **Multiple Environments** - Dev, QA, and Prod configurations
- **Screenshot on Failure** - Automatic screenshots for debugging
- **Logging** - Detailed logging with file and console output
- **Data-Driven Testing** - CSV and JSON data reader utilities
- **BDD Support** - pytest-bdd for Gherkin feature files

## 📋 Prerequisites

- Python 3.11 or higher
- pip package manager
- Chrome or Firefox browser

## 🛠️ Setup

1. **Clone the repository**
```bash
cd selenium-python-project-bdd
```

2. **Create virtual environment**
```bash
python -m venv venv
source venv/bin/activate # On Windows: venv\Scripts\activate
```

3. **Install dependencies**
```bash
pip install -r requirements.txt
```

4. **Configure environment**
```bash
cp .env.example .env
# Edit .env with your configuration
```

## 🧪 Running Tests

### Run all tests
```bash
pytest
```

### Run specific test suite
```bash
pytest -m regression # Regression tests
pytest tests/test_login.py # Specific test file
```

### Run tests in parallel
```bash
pytest -n auto # Auto-detect CPU cores
pytest -n 4 # Run on 4 cores
```

### Generate Allure report
```bash
pytest --alluredir=allure-results
allure serve allure-results
```

## 📂 Project Structure

```
selenium-python-project-bdd/
├── config/ # Configuration files
│ ├── config.py # Configuration manager
│ └── settings.py # Global settings
├── pages/ # Page Object Model
│ ├── base_page.py # Base page class
│ ├── login_page.py # Login page
│ └── home_page.py # Home page
├── utils/ # Utility modules
│ ├── driver_factory.py # WebDriver factory
│ ├── wait_helpers.py # Wait utilities
│ ├── web_actions.py # Web action helpers
│ ├── logger.py # Logging utility
│ ├── screenshot_util.py # Screenshot utility
│ └── data_reader.py # Data reader
├── tests/ # Test cases
│ ├── conftest.py # Pytest fixtures
│ ├── test_login.py # Login tests
│ └── test_smoke.py # Smoke tests
├── data/ # Test data
│ ├── dev.json # Dev environment data
│ ├── qa.json # QA environment data
│ └── users.csv # User test data
├── .github/workflows/ # CI/CD
│ └── tests.yml # GitHub Actions
├── requirements.txt # Dependencies
└── pytest.ini # Pytest configuration
```

## 🔧 Configuration

Environment-specific settings are managed in `config/config.py`:

- `DEV` - Development environment
- `QA` - QA/Testing environment
- `PROD` - Production environment

Set environment via:
```bash
export TEST_ENV=qa # Linux/Mac
set TEST_ENV=qa # Windows
```

## 📊 Reporting

### HTML Report
Generated automatically at `reports/report.html`

### Allure Report
```bash
# Generate results
pytest --alluredir=allure-results

# Serve report
allure serve allure-results
```

### CI/CD Reports
Test reports are automatically generated and uploaded as artifacts in GitHub Actions

## 🔄 CI/CD

GitHub Actions workflow (`.github/workflows/tests.yml`) automatically:
- Runs tests on push/PR
- Generates test reports
- Uploads artifacts
- Supports parallel execution

## 🐛 Debugging

- **Screenshots**: Captured on test failure in `screenshots/`
- **Logs**: Detailed logs in `logs/test.log`
- **Verbose mode**: Run with `-v` or `-vv` for more details

## 📝 Writing Tests

```python
import pytest
from pages.login_page import LoginPage

@pytest.mark.regression
def test_valid_login(driver):
login_page = LoginPage(driver)
login_page.navigate()
login_page.login("user@example.com", "password123")
assert login_page.is_login_successful()
```

## 🤝 Contributing

1. Follow PEP 8 style guide
2. Add tests for new features
3. Update documentation
4. Ensure all tests pass

## 📄 License

This project is licensed under the MIT License.