# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-04-29T06:26:52.431730+00:00
**Finished:** 2026-04-29T06:32:10.847662+00:00

## Summary

- **Files migrated:** 9 / 17
- **Patterns handled:** 56
- **Average confidence:** 75%
- **Time taken:** 217.7s
- **Estimated manual effort saved:** ~3.0 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `ExpectedConditions` | 10 |
| `By_id` | 6 |
| `WebDriver` | 6 |
| `assertTrue` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `WebDriverWait` | 2 |
| `JavascriptExecutor` | 2 |
| `Cucumber_Scenario_Inject` | 2 |
| `Cucumber_When` | 2 |
| `Cucumber_Then` | 2 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |
| `Cucumber_Given` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | FAIL | 50% | 0 | 0 | 13.7s |
| `BasePage.java` | FAIL | 50% | 3 | 0 | 19.3s |
| `LoginPage.java` | FAIL | 50% | 13 | 0 | 13.6s |
| `ConfigurationReader.java` | OK | 100% | 0 | 0 | 15.2s |
| `Environment.java` | OK | 100% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | FAIL | 50% | 3 | 0 | 11.9s |
| `DriverManager.java` | FAIL | 50% | 3 | 0 | 15.4s |
| `TestWatcher.java` | OK | 100% | 0 | 0 | 9.3s |
| `AllureManager.java` | OK | 100% | 0 | 0 | 10.0s |
| `Log.java` | OK | 100% | 0 | 0 | 12.7s |
| `ScreenshotUtils.java` | FAIL | 50% | 2 | 0 | 10.0s |
| `WaitUtils.java` | FAIL | 50% | 12 | 0 | 27.6s |
| `WebActions.java` | FAIL | 50% | 8 | 0 | 24.5s |
| `TestRunner.java` | OK | 100% | 0 | 0 | 0.1s |
| `Hooks.java` | OK | 100% | 2 | 0 | 8.9s |
| `LoginSteps.java` | OK | 100% | 8 | 0 | 13.0s |
| `LoginTests.java` | OK | 90% | 2 | 0 | 12.4s |
