# QAMigrate Manual Review Checklist

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Finished:** 2026-04-29T06:32:10.847662+00:00

Three buckets, ordered by the attention each file deserves.
Start at the top: Priority first, then Verify, then skim Solid.

- **Priority:** 8 file(s) -- fix or re-run
- **Verify:**   0 file(s) -- glance at these
- **Solid:**    9 file(s) -- likely ship-ready

## 1. Priority -- look at these first

Generation failed, compilation failed, or confidence < 70%.

- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\BaseTest.java** -- Generation failed. Error: 2 compile error(s) after 2 fix attempt(s) → `2 compile error(s) after 2 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\pages\BasePage.java** -- Generation failed. Error: 5 compile error(s) after 3 fix attempt(s) → `5 compile error(s) after 3 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\pages\LoginPage.java** -- Generation failed. Error: 8 compile error(s) after 2 fix attempt(s) → `8 compile error(s) after 2 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\BrowserFactory.java** -- Generation failed. Error: 2 compile error(s) after 3 fix attempt(s) → `2 compile error(s) after 3 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\DriverManager.java** -- Generation failed. Error: 6 compile error(s) after 2 fix attempt(s) → `6 compile error(s) after 2 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\ScreenshotUtils.java** -- Generation failed. Error: 1 compile error(s) after 2 fix attempt(s) → `1 compile error(s) after 2 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\WaitUtils.java** -- Generation failed. Error: 4 compile error(s) after 2 fix attempt(s) → `4 compile error(s) after 2 fix attempt(s)`
- [ ] **D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\WebActions.java** -- Generation failed. Error: 3 compile error(s) after 3 fix attempt(s) → `3 compile error(s) after 3 fix attempt(s)`

## 2. Verify -- compiled, but worth a glance

_None. Every compiled file is either solid or priority._

## 3. Solid -- likely ship-ready

Confidence >= 90%, zero hallucinations, compiled cleanly. Spot-check a few at random.

- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\config\ConfigurationReader.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\config\Environment.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\core\TestWatcher.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\AllureManager.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\main\java\com\qastarter\utils\Log.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\runners\TestRunner.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\stepdefinitions\Hooks.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\stepdefinitions\LoginSteps.java -- 100%
- [x] D:\TestFlux\samples\selenium-java-project-bdd\src\test\java\com\qastarter\tests\LoginTests.java -- 90%
