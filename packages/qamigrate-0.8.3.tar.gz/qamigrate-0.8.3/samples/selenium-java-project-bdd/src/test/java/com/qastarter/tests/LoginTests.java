package com.qastarter.tests;

import com.qastarter.config.ConfigurationReader;
import com.qastarter.core.BaseTest;
import com.qastarter.pages.LoginPage;
import com.qastarter.utils.Log;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import static org.junit.jupiter.api.Assertions.*;

/**
* Login Tests - Example test class for SauceDemo.
* Demonstrates both configuration-based and data-driven testing.
*/
class LoginTests extends BaseTest {

@Test
@Order(1)
@Tag("smoke")
@DisplayName("Verify successful login with valid credentials")
void testValidLogin() {
Log.step("Testing valid login");
LoginPage loginPage = new LoginPage();

String username = ConfigurationReader.getProperty("username");
String password = ConfigurationReader.getProperty("password");

loginPage.login(username, password);

assertTrue(loginPage.isLoginSuccessful(), "Login should be successful");
Log.info("Valid login test passed");
}

@Test
@Order(2)
@Tag("regression")
@DisplayName("Verify error message with invalid credentials")
void testInvalidLogin() {
Log.step("Testing invalid login");
LoginPage loginPage = new LoginPage();

loginPage.login("invalid_user", "wrong_password");

assertTrue(loginPage.isErrorDisplayed(), "Error message should be displayed");
Log.info("Invalid login test passed - error displayed as expected");
}

}