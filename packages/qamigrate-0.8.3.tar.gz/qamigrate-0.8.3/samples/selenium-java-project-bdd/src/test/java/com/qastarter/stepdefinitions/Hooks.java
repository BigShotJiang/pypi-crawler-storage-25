package com.qastarter.stepdefinitions;

import com.qastarter.core.DriverManager;
import com.qastarter.utils.Log;
import com.qastarter.utils.ScreenshotUtils;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

/**
 * Cucumber Hooks - Setup and teardown for BDD scenarios.
 */
public class Hooks {

    @Before
    public void setUp(Scenario scenario) {
        Log.info("================================================================================");
        Log.info("SCENARIO: " + scenario.getName());
        Log.info("================================================================================");
        DriverManager.initializeDriver();
        Log.info("Browser initialized for scenario");
    }

    @After
    public void tearDown(Scenario scenario) {
        try {
            if (scenario.isFailed()) {
                Log.error("Scenario FAILED: " + scenario.getName());

                if (DriverManager.isDriverInitialized()) {
                    byte[] screenshot = ScreenshotUtils.captureAsBytes();
                    if (screenshot != null) {
                        scenario.attach(screenshot, "image/png", "Screenshot on Failure");
                    }
                    ScreenshotUtils.capture("FAILED_" + scenario.getName().replaceAll(" ", "_"));
                }
            } else {
                Log.info("Scenario PASSED: " + scenario.getName());
            }
        } finally {
            DriverManager.quitDriver();
            Log.info("Browser closed");
        }
    }
}