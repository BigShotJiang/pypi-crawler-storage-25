package com.qastarter.core;

import com.qastarter.utils.Log;
import com.qastarter.utils.ScreenshotUtils;
import com.qastarter.utils.AllureManager;
import org.junit.jupiter.api.extension.ExtensionContext;

import java.util.Optional;

/**
 * JUnit5 TestWatcher - Handles test lifecycle events.
 */
public class TestWatcher implements org.junit.jupiter.api.extension.TestWatcher {

    @Override
    public void testSuccessful(ExtensionContext context) {
        Log.testEnd(context.getDisplayName(), "PASSED");
    }

    @Override
    public void testFailed(ExtensionContext context, Throwable cause) {
        Log.error("TEST FAILED: " + context.getDisplayName());
        Log.error("Reason: " + cause.getMessage());

        String screenshotPath = ScreenshotUtils.capture("FAILED_" + context.getDisplayName());

        byte[] screenshot = ScreenshotUtils.captureAsBytes();
        if (screenshot != null) {
            AllureManager.attachScreenshot("Screenshot on Failure", screenshot);
        }
    }

    @Override
    public void testAborted(ExtensionContext context, Throwable cause) {
        Log.warn("TEST ABORTED: " + context.getDisplayName());
    }

    @Override
    public void testDisabled(ExtensionContext context, Optional<String> reason) {
        Log.warn("TEST DISABLED: " + context.getDisplayName() + " - " + reason.orElse("No reason"));
    }
}