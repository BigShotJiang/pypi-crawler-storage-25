package com.qastarter.core;

import com.qastarter.config.ConfigurationReader;
import com.qastarter.utils.Log;
import org.openqa.selenium.WebDriver;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;

/**
 * Base Test - Extend this in all your test classes.
 * 
 * JUnit5 version with @BeforeEach/@AfterEach lifecycle.
 */
@ExtendWith(TestWatcher.class)
public class BaseTest {

    @BeforeAll
    static void beforeAll() {
        Log.info("========================================");
        Log.info(" TEST SUITE STARTED");
        Log.info("========================================");
        Log.info("Environment: " + ConfigurationReader.getCurrentEnvironment());
        Log.info("Browser: " + ConfigurationReader.getBrowser());
        Log.info("Base URL: " + ConfigurationReader.getBaseUrl());
    }

    @AfterAll
    static void afterAll() {
        Log.info("========================================");
        Log.info(" TEST SUITE COMPLETED");
        Log.info("========================================");
    }

    @BeforeEach
    void setUp() {
        Log.info("--- Test Setup Started ---");
        DriverManager.initializeDriver();

        String baseUrl = ConfigurationReader.getBaseUrl();
        if (baseUrl != null && !baseUrl.isEmpty()) {
            getDriver().get(baseUrl);
            Log.info("Navigated to: " + baseUrl);
        }
        Log.info("--- Test Setup Completed ---");
    }

    @AfterEach
    void tearDown() {
        Log.info("--- Test Teardown Started ---");
        DriverManager.quitDriver();
        Log.info("--- Test Teardown Completed ---");
    }

    protected WebDriver getDriver() {
        return DriverManager.getDriver();
    }

    protected void navigateTo(String url) {
        Log.step("Navigating to: " + url);
        getDriver().get(url);
    }
}