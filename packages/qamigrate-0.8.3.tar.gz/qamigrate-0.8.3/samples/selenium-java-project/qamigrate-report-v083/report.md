# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-05-02T15:19:02.197209+00:00
**Finished:** 2026-05-02T15:24:19.327518+00:00

## Summary

- **Files migrated:** 14 / 15
- **Patterns handled:** 44
- **Average confidence:** 96%
- **Time taken:** 272.9s
- **Estimated manual effort saved:** ~9.5 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `By_id` | 6 |
| `WebDriver` | 6 |
| `ExpectedConditions` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `JavascriptExecutor` | 2 |
| `assertTrue` | 2 |
| `JUnit4_Test` | 2 |
| `TestNG_BeforeMethod` | 1 |
| `TestNG_AfterMethod` | 1 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `WebDriverWait` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | OK | 100% | 2 | 0 | 12.5s |
| `BasePage.java` | OK | 100% | 3 | 0 | 15.6s |
| `LoginPage.java` | OK | 100% | 13 | 0 | 13.0s |
| `ConfigurationReader.java` | OK | 100% | 0 | 0 | 14.2s |
| `Environment.java` | OK | 100% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | OK | 100% | 3 | 0 | 11.8s |
| `DriverManager.java` | OK | 100% | 3 | 0 | 17.8s |
| `RetryAnalyzer.java` | OK | 100% | 0 | 0 | 5.7s |
| `TestListener.java` | OK | 100% | 0 | 0 | 14.5s |
| `ExtentManager.java` | OK | 100% | 0 | 0 | 38.1s |
| `Log.java` | OK | 100% | 0 | 0 | 12.7s |
| `ScreenshotUtils.java` | OK | 100% | 2 | 0 | 9.4s |
| `WaitUtils.java` | FAIL | 50% | 6 | 0 | 76.2s |
| `WebActions.java` | OK | 100% | 8 | 0 | 22.2s |
| `LoginTests.java` | OK | 100% | 4 | 0 | 9.2s |
