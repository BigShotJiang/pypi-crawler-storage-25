# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-04-30T09:57:44.782785+00:00
**Finished:** 2026-04-30T10:02:04.070028+00:00

## Summary

- **Files migrated:** 15 / 15
- **Patterns handled:** 44
- **Average confidence:** 100%
- **Time taken:** 247.1s
- **Estimated manual effort saved:** ~11.0 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `By_id` | 6 |
| `WebDriver` | 6 |
| `ExpectedConditions` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `JavascriptExecutor` | 2 |
| `assertTrue` | 2 |
| `JUnit4_Test` | 2 |
| `TestNG_BeforeMethod` | 1 |
| `TestNG_AfterMethod` | 1 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `WebDriverWait` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | OK | 100% | 2 | 0 | 14.0s |
| `BasePage.java` | OK | 100% | 3 | 0 | 16.6s |
| `LoginPage.java` | OK | 100% | 13 | 0 | 12.2s |
| `ConfigurationReader.java` | OK | 100% | 0 | 0 | 41.4s |
| `Environment.java` | OK | 100% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | OK | 100% | 3 | 0 | 12.0s |
| `DriverManager.java` | OK | 100% | 3 | 0 | 16.2s |
| `RetryAnalyzer.java` | OK | 100% | 0 | 0 | 5.9s |
| `TestListener.java` | OK | 100% | 0 | 0 | 14.5s |
| `ExtentManager.java` | OK | 100% | 0 | 0 | 39.2s |
| `Log.java` | OK | 100% | 0 | 0 | 13.6s |
| `ScreenshotUtils.java` | OK | 100% | 2 | 0 | 9.7s |
| `WaitUtils.java` | OK | 100% | 6 | 0 | 16.2s |
| `WebActions.java` | OK | 100% | 8 | 0 | 25.3s |
| `LoginTests.java` | OK | 100% | 4 | 0 | 10.2s |
