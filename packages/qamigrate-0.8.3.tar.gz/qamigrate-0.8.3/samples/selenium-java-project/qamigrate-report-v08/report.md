# QAMigrate Migration Report

**Source -> Target:** Java (Selenium) -> Java (Playwright)
**Started:** 2026-04-29T19:01:30.198029+00:00
**Finished:** 2026-04-29T19:06:20.792384+00:00

## Summary

- **Files migrated:** 14 / 15
- **Patterns handled:** 44
- **Average confidence:** 96%
- **Time taken:** 244.9s
- **Estimated manual effort saved:** ~9.5 hours

## Patterns handled

| Pattern | Count |
|---------|-------|
| `By_id` | 6 |
| `WebDriver` | 6 |
| `ExpectedConditions` | 5 |
| `By_field` | 4 |
| `click` | 3 |
| `sendKeys` | 2 |
| `clear` | 2 |
| `By_cssSelector` | 2 |
| `JavascriptExecutor` | 2 |
| `assertTrue` | 2 |
| `JUnit4_Test` | 2 |
| `TestNG_BeforeMethod` | 1 |
| `TestNG_AfterMethod` | 1 |
| `ChromeDriver` | 1 |
| `FirefoxDriver` | 1 |
| `WebDriverWait` | 1 |
| `Actions` | 1 |
| `Select` | 1 |
| `hover` | 1 |

## Files

| File | Status | Confidence | Patterns | Hallucinations | Time |
|------|--------|------------|----------|----------------|------|
| `BaseTest.java` | OK | 100% | 2 | 0 | 12.8s |
| `BasePage.java` | OK | 100% | 3 | 0 | 20.8s |
| `LoginPage.java` | OK | 100% | 13 | 0 | 14.3s |
| `ConfigurationReader.java` | OK | 100% | 0 | 0 | 13.6s |
| `Environment.java` | OK | 100% | 0 | 0 | 0.1s |
| `BrowserFactory.java` | OK | 100% | 3 | 0 | 12.4s |
| `DriverManager.java` | OK | 100% | 3 | 0 | 16.2s |
| `RetryAnalyzer.java` | OK | 100% | 0 | 0 | 5.5s |
| `TestListener.java` | OK | 100% | 0 | 0 | 14.2s |
| `ExtentManager.java` | OK | 100% | 0 | 0 | 26.4s |
| `Log.java` | OK | 100% | 0 | 0 | 13.4s |
| `ScreenshotUtils.java` | OK | 100% | 2 | 0 | 9.4s |
| `WaitUtils.java` | FAIL | 50% | 6 | 0 | 54.3s |
| `WebActions.java` | OK | 100% | 8 | 0 | 22.3s |
| `LoginTests.java` | OK | 100% | 4 | 0 | 9.3s |
