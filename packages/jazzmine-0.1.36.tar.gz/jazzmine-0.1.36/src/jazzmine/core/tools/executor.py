"""
script_executor.py
──────────────────
Sends a script to a ManagedContainer and streams events back.

In PLAN mode:
  - Waits for final_result or error. script_done is ignored.

In INTERACTIVE mode:
  - Waits for final_result, error, OR script_done.
  - script_done with no prior final_result means the step emitted only
    intermediates and has finished — the orchestrator will record those
    intermediates and generate the next step.
  - script_done after a final_result is a no-op (already returned).
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Coroutine, Dict, List, Optional

from jazzmine.core.tools.sandbox.pool import DockerLineReader, ManagedContainer
from jazzmine.core.tools.sandbox.config import ExecutionMode, ResourceLimits

log = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    success:       bool
    execution_id:  str
    final_data:    Optional[Any]            = None
    intermediates: List[Dict[str, Any]]     = field(default_factory=list)
    logs:          List[Dict[str, str]]     = field(default_factory=list)
    error:         Optional[str]            = None
    traceback:     Optional[str]            = None
    duration_ms:   int                      = 0
    output_bytes:  int                      = 0

    @property
    def failed(self) -> bool:
        return not self.success

    def __repr__(self) -> str:
        if self.success:
            return f"<ExecutionResult OK  data={str(self.final_data)[:80]}>"
        return f"<ExecutionResult ERR error={self.error!r}>"


IntermediateCallback = Callable[[Dict[str, Any]], Coroutine[Any, Any, None]]


class ScriptExecutor:

    def __init__(
        self,
        limits:          Optional[ResourceLimits]       = None,
        mode:            ExecutionMode                   = ExecutionMode.PLAN,
        on_intermediate: Optional[IntermediateCallback] = None,
    ) -> None:
        self._limits          = limits or ResourceLimits()
        self._mode            = mode
        self._on_intermediate = on_intermediate

    async def run(
        self,
        container:        ManagedContainer,
        script:           str,
        required_secrets: Optional[List[str]] = None,
        execution_id:     Optional[str]       = None,
    ) -> ExecutionResult:
        eid     = execution_id or str(uuid.uuid4())
        t_start = time.monotonic()
        timeout = self._limits.execution_timeout_sec + 5

        request = {
            "execution_id":     eid,
            "script":           script,
            "mode":             self._mode.value,
            "timeout":          self._limits.execution_timeout_sec,
            "required_secrets": required_secrets or [],
        }

        try:
            line = json.dumps(request) + "\n"
            container.stdin_pipe.write(line.encode("utf-8"))
            await container.stdin_pipe.drain()
        except Exception as exc:
            return ExecutionResult(
                success=False, execution_id=eid,
                error=f"Failed to write script to container: {exc}",
                duration_ms=_ms(t_start),
            )

        return await self._collect_events(
            container=container, execution_id=eid,
            timeout=timeout, t_start=t_start,
        )

    async def _collect_events(
        self,
        container:    ManagedContainer,
        execution_id: str,
        timeout:      float,
        t_start:      float,
    ) -> ExecutionResult:
        intermediates: List[Dict[str, Any]] = []
        logs:          List[Dict[str, str]] = []
        bytes_read = 0
        max_bytes  = self._limits.max_output_bytes
        deadline   = asyncio.get_event_loop().time() + timeout

        while True:
            remaining = deadline - asyncio.get_event_loop().time()
            if remaining <= 0:
                return ExecutionResult(
                    success=False, execution_id=execution_id,
                    intermediates=intermediates, logs=logs,
                    error=f"Timed out waiting for container response after {timeout}s",
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )

            try:
                raw_str = await container.stdout_pipe.readline(timeout=min(remaining, 1.0))
            except asyncio.TimeoutError:
                continue
            except (asyncio.IncompleteReadError, EOFError):
                return ExecutionResult(
                    success=False, execution_id=execution_id,
                    intermediates=intermediates, logs=logs,
                    error="Container stdout closed unexpectedly (crash or OOM kill)",
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )
            except Exception as exc:
                return ExecutionResult(
                    success=False, execution_id=execution_id,
                    intermediates=intermediates, logs=logs,
                    error=f"Container stdout pipe error: {exc}",
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )

            if not raw_str:
                continue

            bytes_read += len(raw_str.encode("utf-8"))
            if bytes_read > max_bytes:
                log.warning(f"Output truncated at {max_bytes:,} bytes for {execution_id}")
                return ExecutionResult(
                    success=False, execution_id=execution_id,
                    intermediates=intermediates, logs=logs,
                    error=f"Script output exceeded {max_bytes:,} byte limit",
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )

            try:
                event = json.loads(raw_str)
            except json.JSONDecodeError:
                log.debug(f"Non-JSON line from container: {raw_str!r}")
                continue

            if event.get("execution_id") not in (execution_id, None):
                continue

            etype = event.get("type")

            if etype == "final_result":
                return ExecutionResult(
                    success=True, execution_id=execution_id,
                    final_data=event.get("data"),
                    intermediates=intermediates, logs=logs,
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )

            elif etype == "error":
                return ExecutionResult(
                    success=False, execution_id=execution_id,
                    intermediates=intermediates, logs=logs,
                    error=event.get("message", "Unknown error"),
                    traceback=event.get("traceback", ""),
                    duration_ms=_ms(t_start),
                    output_bytes=bytes_read,
                )

            elif etype == "script_done":
                # In INTERACTIVE mode: the step script has finished executing.
                # If it only emitted intermediates (no final_result), return
                # success=True with final_data=None so the orchestrator knows
                # to record the intermediates and generate the next step.
                # In PLAN mode: script_done is not expected (scripts must always
                # call emit_result); ignore and keep waiting.
                if self._mode == ExecutionMode.INTERACTIVE:
                    return ExecutionResult(
                        success=True, execution_id=execution_id,
                        final_data=None,        # None signals "step done, not finished"
                        intermediates=intermediates, logs=logs,
                        duration_ms=_ms(t_start),
                        output_bytes=bytes_read,
                    )

            elif etype == "intermediate":
                entry = {"label": event.get("label"), "data": event.get("data")}
                intermediates.append(entry)
                if self._on_intermediate:
                    try:
                        await self._on_intermediate(entry)
                    except Exception as exc:
                        log.warning(f"Intermediate callback raised: {exc}")

            elif etype == "log":
                logs.append({
                    "level":   event.get("level", "info"),
                    "message": event.get("message", ""),
                })

            elif etype == "tool_call":
                log.debug(f"Tool call: {event.get('tool')}({event.get('args')})")

            elif etype == "tool_result":
                log.debug(f"Tool result: call_id={event.get('call_id')} success={event.get('success')}")


def _ms(t_start: float) -> int:
    return int((time.monotonic() - t_start) * 1000)