"""
sandbox_config.py
─────────────────
Pure configuration dataclasses. No Docker dependency.

A SandboxConfig describes everything needed to build a container image and
run tool scripts inside it: Python version, dependencies, network allowlist,
resource limits, file mounts, and secrets.

Multiple sandboxes per agent are supported. Tools are assigned to a sandbox
by name. If a tool has no explicit sandbox assignment it goes to "default".

DooD note (Docker-out-of-Docker)
─────────────────────────────────
When the agent itself runs inside a container (DooD mode) the Docker daemon
that receives containers.run() calls is the HOST daemon.  Volume bind-mounts
use HOST filesystem paths, not paths that exist inside the agent container.

Use FileResource.docker_host_path to supply the real host path explicitly,
or pass host_path_map to SandboxPool for a prefix-translation approach.
See SandboxPool.__init__ docstring for the full workflow.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


# ── Execution modes ────────────────────────────────────────────────────────────

class ExecutionMode(str, Enum):
    PLAN        = "plan"         # Agent writes full script upfront, runs to completion.
    INTERACTIVE = "interactive"  # Agent writes one step at a time, sees results between steps.


# ── Resource limits ────────────────────────────────────────────────────────────

@dataclass
class ResourceLimits:
    """Hard limits enforced by Docker at the cgroup level."""

    cpu_quota:             float = 0.5
    memory_mb:             int   = 256
    memory_swap_mb:        int   = -1        # -1 = unlimited. If positive, must be > memory_mb.
    pids_limit:            int   = 64
    execution_timeout_sec: int   = 30
    max_output_bytes:      int   = 1_048_576

    def __post_init__(self):
        """Perform validation of hardware constraints."""
        if self.memory_mb <= 0:
            raise ValueError("memory_mb must be a positive integer.")
            
        if self.memory_swap_mb != -1 and self.memory_swap_mb <= self.memory_mb:
            # In Docker, memswap_limit represents the total limit (Memory + Swap).
            # Therefore, the swap limit must be greater than the memory limit.
            raise ValueError(
                f"memory_swap_mb ({self.memory_swap_mb}) must be greater than "
                f"memory_mb ({self.memory_mb}) or set to -1 for unlimited swap."
            )

    def docker_flags(self) -> Dict[str, object]:
        memswap = self.memory_swap_mb if self.memory_swap_mb == -1 else f"{self.memory_swap_mb}m"
        return {
            "nano_cpus":     int(self.cpu_quota * 1e9),
            "mem_limit":     f"{self.memory_mb}m",
            "memswap_limit": memswap,
            "pids_limit":    self.pids_limit,
        }


# ── Network policy ─────────────────────────────────────────────────────────────

@dataclass
class NetworkPolicy:
    """
    Egress-only allowlist enforced by a sidecar proxy container.

    The tool container is started with --network=<sandbox_net> where the only
    reachable host is the proxy. The proxy enforces this allowlist.
    DNS lookups are handled by the proxy — the container never resolves DNS
    directly, preventing host:port bypass via raw IP.

    allowed_hosts:  ["api.stripe.com", "1.2.3.4"]
                    Accepts Fully Qualified Domain Names (FQDN) or specific 
                    IP addresses for testing. 
    
    allowed_ports:  {"api.stripe.com": [443], "1.2.3.4": [8080]}
                    Omit a host to use default_port for all its ports.

    Security Note: 
    While explicit IP addresses are allowed in this config, the proxy sidecar
    will reject any IP literal that is NOT explicitly present in this set.
    This prevents scripts from bypassing domain-level filtering by using 
    raw IP addresses of unauthorized servers.
    """
    allowed_hosts: List[str]                   = field(default_factory=list)
    allowed_ports: Dict[str, List[int]]        = field(default_factory=dict)
    default_port:  int                         = 443

    def allowlist_env(self) -> str:
        """
        Serialise to the PROXY_ALLOWLIST env var format consumed by proxy_server.py.
        Format: "host:port,host:port,..."
        """
        pairs: List[str] = []
        for host in self.allowed_hosts:
            ports = self.allowed_ports.get(host, [self.default_port])
            for port in ports:
                pairs.append(f"{host}:{port}")
        return ",".join(pairs)

    @property
    def is_isolated(self) -> bool:
        """True when the container must have zero network access."""
        return len(self.allowed_hosts) == 0


# ── File resources ─────────────────────────────────────────────────────────────

@dataclass
class FileResource:
    """
    A host filesystem path bind-mounted read-only into the sandbox container.

    host_path       — path as seen by the agent process. On a bare host this IS
                      the Docker host path. Inside a DooD container it is the
                      agent-container path, which differs from the host path.

    container_path  — where the resource appears inside the sandbox container.

    read_only       — almost always True; set False only for an explicit output sink.

    docker_host_path — override for DooD mode. When set, this value is passed to
                       the Docker daemon instead of host_path, because the daemon
                       resolves paths on the HOST filesystem, not inside the agent
                       container.
    """
    host_path:        str
    container_path:   str
    read_only:        bool            = True
    docker_host_path: Optional[str]  = None

    def to_docker_mount(
        self,
        resolved_host_path: Optional[str] = None,
    ) -> Dict[str, object]:
        """Return the dict format expected by docker-py's volumes parameter."""
        actual = resolved_host_path or self.docker_host_path or self.host_path
        return {
            actual: {
                "bind": self.container_path,
                "mode": "ro" if self.read_only else "rw",
            }
        }


# ── Sandbox configuration ──────────────────────────────────────────────────────

@dataclass
class SandboxConfig:
    """
    Complete specification for one sandbox environment.

    name            — unique identifier; tools reference this by name
    python_version  — used to select the base image (python:<version>-slim)
    dependencies    — pip packages baked into the image at build time
    resources       — host files to bind-mount read-only into the container
    network_policy  — egress allowlist (empty = fully isolated)
    resource_limits — cgroup-level CPU/memory/pid caps
    secrets         — env var names the sandbox needs (validated at startup)
    execution_mode  — PLAN or INTERACTIVE (default: PLAN)
    pool_size       — how many warm containers to keep ready
    scratch_size_mb — writable tmpfs size inside the container (for temp files)
    """
    name:             str
    python_version:   str                = "3.11"
    dependencies:     List[str]          = field(default_factory=list)
    resources:        List[FileResource] = field(default_factory=list)
    network_policy:   NetworkPolicy      = field(default_factory=NetworkPolicy)
    resource_limits:  ResourceLimits     = field(default_factory=ResourceLimits)
    secrets:          List[str]          = field(default_factory=list)
    execution_mode:   ExecutionMode      = ExecutionMode.PLAN
    pool_size:        int                = 2
    scratch_size_mb:  int                = 64

    def with_tool_dependencies(self, extra: List[str]) -> "SandboxConfig":
        """Return a copy of this config with additional tool-level deps merged in."""
        merged = list(dict.fromkeys(self.dependencies + extra))
        import dataclasses
        clone = dataclasses.replace(self, dependencies=merged)
        return clone

    @classmethod
    def default(cls, name: str = "default") -> "SandboxConfig":
        """Sensible defaults for a general-purpose sandbox."""
        return cls(name=name)