"""
executor_harness.py
───────────────────
Runs INSIDE the Docker container. Self-contained — no outer jazzmine imports.

Lifecycle:
  1. Load all tool .py files from /tools/
  2. Emit {"type": "ready"}
  3. Loop: read one JSON request → execute → emit events → emit script_done → repeat

Wire protocol — stdout events:
  {"type": "ready"}
  {"type": "script_done",  "execution_id": "..."}          emitted after every script run
  {"type": "intermediate", "execution_id": "...", "label": "...", "data": ...}
  {"type": "final_result", "execution_id": "...", "data": ...}
  {"type": "error",        "execution_id": "...", "message": "...", "traceback": "..."}
  {"type": "log",          "execution_id": "...", "level": "...", "message": "..."}

script_done is emitted unconditionally after _run_script() returns, whether
the script called emit_result(), emit_intermediate(), raised an exception, or
timed out.  It lets the executor know the script has finished executing so it
can stop waiting for events that will never arrive (e.g. in interactive mode
when a step only calls emit_intermediate and then exits).
"""

import sys
import os
import json
import signal
import traceback
import time
import threading
import uuid
import asyncio
import inspect
import functools
from typing import Any, Dict, Optional, List

# ── Inlined ToolResponse ──────────────────────────────────────────────────────
class ToolResponse:
    def __init__(self, success: bool, message=None, data=None):
        self.success = success
        self.message = message
        self.data    = data

    def to_dict(self):
        return {"success": self.success, "message": self.message, "data": self.data}

    def build_prompt(self):
        parts = [f'<tool_response success="{self.success}">']
        if self.message:
            parts += ["  <message>", f"    {self.message}", "  </message>", ""]
        if self.data:
            parts += ["  <data>", f"    {self.data}", "  </data>", ""]
        parts.append("</tool_response>")
        return "\n".join(parts)

# ── Dedicated event loop for async tools ──────────────────────────────────────
_tool_loop   = asyncio.new_event_loop()
_tool_thread = threading.Thread(
    target=_tool_loop.run_forever, name="tool-loop", daemon=True
)
_tool_thread.start()

# ── stdout serialisation ──────────────────────────────────────────────────────
_stdout_lock = threading.Lock()

def _emit(event: dict) -> None:
    with _stdout_lock:
        try:
            sys.stdout.write(json.dumps(event, default=str) + "\n")
            sys.stdout.flush()
        except Exception:
            pass

# ── Execution globals ─────────────────────────────────────────────────────────
_base_globals: Dict[str, Any] = {
    "__builtins__": __builtins__,
    "json":     __import__("json"),
    "os":       __import__("os"),
    "time":     __import__("time"),
    "math":     __import__("math"),
    "re":       __import__("re"),
    "uuid":     __import__("uuid"),
    "datetime": __import__("datetime"),
    "asyncio":  __import__("asyncio"),
    "ToolResponse": ToolResponse,
}
_interactive_globals: Dict[str, Any] = dict(_base_globals)
_current_exec_id: Optional[str] = None

# ── Script-callable helpers ───────────────────────────────────────────────────
def emit_intermediate(label: str, data: Any) -> None:
    _emit({"type": "intermediate", "execution_id": _current_exec_id,
           "label": label, "data": data, "ts": time.time()})

def emit_result(data: Any) -> None:
    _emit({"type": "final_result", "execution_id": _current_exec_id,
           "data": data, "ts": time.time()})

def emit_log(message: str, level: str = "info") -> None:
    _emit({"type": "log", "execution_id": _current_exec_id,
           "level": level, "message": message, "ts": time.time()})

# ── Timeout ───────────────────────────────────────────────────────────────────
class _ScriptTimeout(Exception):
    pass

def _sigalrm_handler(signum, frame):
    raise _ScriptTimeout()

signal.signal(signal.SIGALRM, _sigalrm_handler)

# ── Async → sync wrapper ──────────────────────────────────────────────────────
def _wrap_async_tools() -> None:
    def _make_sync(fn):
        @functools.wraps(fn)
        def sync_wrapper(*args, **kwargs):
            future = asyncio.run_coroutine_threadsafe(fn(*args, **kwargs), _tool_loop)
            return future.result()
        return sync_wrapper

    wrapped = []
    for name, obj in list(_base_globals.items()):
        if inspect.iscoroutinefunction(obj):
            _base_globals[name] = _make_sync(obj)
            wrapped.append(name)

    _interactive_globals.update(_base_globals)

    if wrapped:
        _emit({"type": "log", "execution_id": None, "level": "info",
               "message": f"Wrapped {len(wrapped)} async tool(s) as sync: {wrapped}"})

# ── Tool loader ───────────────────────────────────────────────────────────────
def _load_tools() -> None:
    tools_dir = "/tools"
    if not os.path.isdir(tools_dir):
        _emit({"type": "log", "execution_id": None, "level": "warning",
               "message": "/tools/ directory not found — no tools loaded"})
        return

    for filename in sorted(os.listdir(tools_dir)):
        if not filename.endswith(".py"):
            continue
        filepath = os.path.join(tools_dir, filename)
        try:
            with open(filepath) as f:
                source = f.read()
            exec(compile(source, filepath, "exec"), _base_globals)  # noqa: S102
            _emit({"type": "log", "execution_id": None, "level": "info",
                   "message": f"Loaded tool file: {filename}"})
        except Exception as exc:
            _emit({"type": "log", "execution_id": None, "level": "warning",
                   "message": f"Failed to load {filename}: {exc}\n{traceback.format_exc()}"})

    _wrap_async_tools()
    _interactive_globals.update(_base_globals)

# ── Secret validation ─────────────────────────────────────────────────────────
def _check_secrets(required: list, execution_id: str) -> bool:
    missing = [s for s in required if not os.environ.get(s)]
    if missing:
        _emit({"type": "error", "execution_id": execution_id,
               "message": f"Missing required environment variables: {missing}",
               "traceback": ""})
        return False
    return True

# ── Script execution ──────────────────────────────────────────────────────────
def _run_script(script: str, execution_id: str, timeout: int, mode: str) -> None:
    global _current_exec_id
    _current_exec_id = execution_id

    if mode == "interactive_step":
        ctx = _interactive_globals
        ctx.update({"emit_intermediate": emit_intermediate,
                    "emit_result": emit_result, "emit_log": emit_log})
    else:
        ctx = dict(_base_globals)
        ctx.update({"emit_intermediate": emit_intermediate,
                    "emit_result": emit_result, "emit_log": emit_log})

    signal.alarm(timeout)
    t_start = time.monotonic()
    try:
        exec(compile(script, "<agent_script>", "exec"), ctx)  # noqa: S102
        signal.alarm(0)
    except _ScriptTimeout:
        signal.alarm(0)
        _emit({"type": "error", "execution_id": execution_id,
               "message": f"Script timed out after {timeout}s", "traceback": "",
               "duration_ms": int((time.monotonic() - t_start) * 1000)})
    except SystemExit as exc:
        signal.alarm(0)
        _emit({"type": "error", "execution_id": execution_id,
               "message": f"Script called sys.exit({exc.code})", "traceback": ""})
    except Exception:
        signal.alarm(0)
        _emit({"type": "error", "execution_id": execution_id,
               "message": str(sys.exc_info()[1]),
               "traceback": traceback.format_exc(),
               "duration_ms": int((time.monotonic() - t_start) * 1000)})
    finally:
        signal.alarm(0)
        _current_exec_id = None

# ── Main loop ─────────────────────────────────────────────────────────────────
def main() -> None:
    _load_tools()
    _emit({"type": "ready"})

    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue

        try:
            req = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            _emit({"type": "error", "execution_id": None,
                   "message": f"Invalid JSON in request: {exc}", "traceback": ""})
            continue

        execution_id     = req.get("execution_id") or str(uuid.uuid4())
        script           = req.get("script", "").strip()
        timeout          = min(int(req.get("timeout", 30)), 120)
        mode             = req.get("mode", "plan")
        required_secrets = req.get("required_secrets", [])

        if not _check_secrets(required_secrets, execution_id):
            _emit({"type": "script_done", "execution_id": execution_id})
            continue

        if not script:
            _emit({"type": "error", "execution_id": execution_id,
                   "message": "Empty script received", "traceback": ""})
            _emit({"type": "script_done", "execution_id": execution_id})
            continue

        _run_script(script, execution_id, timeout, mode)

        # Always emitted after the script finishes, regardless of outcome.
        # Lets the executor stop waiting for events in interactive mode when
        # the script called emit_intermediate but not emit_result.
        _emit({"type": "script_done", "execution_id": execution_id})


if __name__ == "__main__":
    main()