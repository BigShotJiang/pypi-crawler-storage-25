from motor.motor_asyncio import AsyncIOMotorClient

from jazzmine.core.message_store.base import MessageStore
from jazzmine.core.message_store.models import (
    Conversation, Message, MessageRole,
    TurnTrace,
)


# ── Row ↔ model helpers ───────────────────────────────────────────────────────

def _doc_to_message(d: dict) -> Message:
    d.pop("_id", None)
    d["role"] = MessageRole(d["role"])
    return Message.model_validate(d)


def _doc_to_conversation(d: dict) -> Conversation:
    d.pop("_id", None)
    return Conversation.model_validate(d)


def _doc_to_turn_trace(d: dict) -> TurnTrace:
    d.pop("_id", None)
    return TurnTrace.model_validate(d)


# ── Store ─────────────────────────────────────────────────────────────────────

class MongoDBMessageStore(MessageStore):
    """
    MongoDB-backed message store.

    Collections:
      conversations  — one document per conversation
      messages       — one document per message
      turn_traces    — one document per agent turn (linked to assistant message)

    Index strategy:
      Conversations and messages use the same indexes as the Postgres store.
      Turn traces use compound indexes on (conversation_id, turn_number) for
      conversation audit queries and (agent_id, started_at_ms) for time-range
      cost/latency dashboards.  A separate index on message_id supports O(1)
      lookup by assistant message.  No aggregation pipeline is needed for the
      primary audit queries because all queryable scalar fields are top-level
      document fields.
    """

    def __init__(self, config: dict):
        self._uri     = config["uri"]
        self._db_name = config.get("db", "chatbot")
        self._client: AsyncIOMotorClient | None = None

    async def _init(self) -> None:
        self._client = AsyncIOMotorClient(self._uri)
        db = self._client[self._db_name]

        # ── conversations ──────────────────────────────────────────────────────
        self._convs = db["conversations"]
        await self._convs.create_index("id",         unique=True, background=True)
        await self._convs.create_index(
            [("user_id", 1), ("last_updated_at", -1)], background=True
        )
        await self._convs.create_index(
            [("agent_id", 1), ("last_updated_at", -1)], background=True
        )

        # ── messages ───────────────────────────────────────────────────────────
        self._msgs = db["messages"]
        await self._msgs.create_index("id",           unique=True, background=True)
        await self._msgs.create_index(
            [("conversation_id", 1), ("timestamp", 1)], background=True
        )
        await self._msgs.create_index(
            [("user_id", 1), ("timestamp", 1)], background=True
        )
        await self._msgs.create_index("is_flagged",   background=True, sparse=True)

        # ── turn_traces ────────────────────────────────────────────────────────
        self._traces = db["turn_traces"]
        # Primary key
        await self._traces.create_index("id",         unique=True, background=True)
        # FK lookup: one trace per assistant message
        await self._traces.create_index("message_id", unique=True, background=True)
        # Conversation audit trail (ordered by step)
        await self._traces.create_index(
            [("conversation_id", 1), ("turn_number", 1)], background=True
        )
        # Agent-level cost / latency dashboards
        await self._traces.create_index(
            [("agent_id", 1), ("started_at_ms", -1)], background=True
        )
        # User-level audit queries
        await self._traces.create_index(
            [("user_id", 1), ("started_at_ms", -1)], background=True
        )
        # Cost analysis
        await self._traces.create_index("total_tokens",     background=True)
        await self._traces.create_index("total_latency_ms", background=True)
        await self._traces.create_index("detected_intent",  background=True)

    async def close(self) -> None:
        if self._client:
            self._client.close()

    # ── conversations ─────────────────────────────────────────────────────────

    async def store_conversation(self, conversation: Conversation) -> None:
        doc = conversation.model_dump(mode="json")
        await self._convs.replace_one({"id": conversation.id}, doc, upsert=True)

    async def get_conversation_by_id(self, conversation_id: str) -> Conversation | None:
        doc = await self._convs.find_one({"id": conversation_id}, {"_id": 0})
        return _doc_to_conversation(doc) if doc else None

    async def get_conversations_by_user_id(self, user_id: str) -> list[Conversation]:
        cursor = self._convs.find(
            {"user_id": user_id}, {"_id": 0}, sort=[("last_updated_at", -1)]
        )
        return [_doc_to_conversation(d) async for d in cursor]

    async def get_conversations_by_agent_id(self, agent_id: str) -> list[Conversation]:
        cursor = self._convs.find(
            {"agent_id": agent_id}, {"_id": 0}, sort=[("last_updated_at", -1)]
        )
        return [_doc_to_conversation(d) async for d in cursor]

    async def update_conversation(self, conversation: Conversation) -> None:
        await self.store_conversation(conversation)

    async def delete_conversation(self, conversation_id: str) -> None:
        # Manually cascade: delete traces → delete messages → delete conversation.
        # MongoDB has no referential integrity, so we cascade explicitly in the
        # correct order to keep turn_traces consistent.
        msg_ids = [
            d["id"]
            async for d in self._msgs.find(
                {"conversation_id": conversation_id}, {"id": 1, "_id": 0}
            )
        ]
        if msg_ids:
            await self._traces.delete_many({"message_id": {"$in": msg_ids}})
        await self._msgs.delete_many({"conversation_id": conversation_id})
        await self._convs.delete_one({"id": conversation_id})

    # ── messages ──────────────────────────────────────────────────────────────

    async def store_message(self, message: Message) -> None:
        doc = message.model_dump(mode="json")
        await self._msgs.replace_one({"id": message.id}, doc, upsert=True)

    async def store_messages(self, messages: list[Message]) -> None:
        if not messages:
            return
        from pymongo import ReplaceOne
        ops = [
            ReplaceOne({"id": m.id}, m.model_dump(mode="json"), upsert=True)
            for m in messages
        ]
        await self._msgs.bulk_write(ops, ordered=False)

    async def update_message(self, message: Message) -> None:
        await self.store_message(message)

    async def delete_message(self, message_id: str) -> None:
        # Delete the linked turn trace first to keep things consistent.
        await self._traces.delete_one({"message_id": message_id})
        await self._msgs.delete_one({"id": message_id})

    async def flag_message(self, message_id: str) -> None:
        await self._msgs.update_one(
            {"id": message_id}, {"$set": {"is_flagged": True}}
        )

    async def get_message_by_id(self, message_id: str) -> Message | None:
        doc = await self._msgs.find_one({"id": message_id}, {"_id": 0})
        return _doc_to_message(doc) if doc else None

    async def get_messages_by_ids(self, message_ids: list[str]) -> list[Message]:
        cursor = self._msgs.find(
            {"id": {"$in": message_ids}}, {"_id": 0}, sort=[("timestamp", 1)]
        )
        return [_doc_to_message(d) async for d in cursor]

    async def get_messages_by_conversation_id(self, conversation_id: str) -> list[Message]:
        cursor = self._msgs.find(
            {"conversation_id": conversation_id}, {"_id": 0}, sort=[("timestamp", 1)]
        )
        return [_doc_to_message(d) async for d in cursor]

    async def get_messages_by_user_id(self, user_id: str) -> list[Message]:
        cursor = self._msgs.find(
            {"user_id": user_id}, {"_id": 0}, sort=[("timestamp", 1)]
        )
        return [_doc_to_message(d) async for d in cursor]

    async def get_immediate_context(self, conversation_id: str, n: int) -> list[Message]:
        cursor = self._msgs.find(
            {
                "conversation_id": conversation_id,
                "is_flagged": {"$ne": True},
            },
            {"_id": 0},
            sort=[("timestamp", -1)],
        ).limit(n)
        docs = [d async for d in cursor]
        docs.reverse()
        return [_doc_to_message(d) for d in docs]

    # ── turn traces ───────────────────────────────────────────────────────────

    async def store_turn_trace(self, trace: TurnTrace) -> None:
        doc = trace.model_dump(mode="json")
        await self._traces.replace_one({"id": trace.id}, doc, upsert=True)

    async def get_turn_trace_by_id(self, trace_id: str) -> TurnTrace | None:
        doc = await self._traces.find_one({"id": trace_id}, {"_id": 0})
        return _doc_to_turn_trace(doc) if doc else None

    async def get_turn_trace_by_message_id(self, message_id: str) -> TurnTrace | None:
        doc = await self._traces.find_one({"message_id": message_id}, {"_id": 0})
        return _doc_to_turn_trace(doc) if doc else None

    async def get_turn_traces_by_conversation_id(
        self, conversation_id: str
    ) -> list[TurnTrace]:
        cursor = self._traces.find(
            {"conversation_id": conversation_id},
            {"_id": 0},
            sort=[("turn_number", 1)],
        )
        return [_doc_to_turn_trace(d) async for d in cursor]

    async def get_turn_traces_by_agent_id(
        self,
        agent_id: str,
        limit:    int = 100,
        offset:   int = 0,
    ) -> list[TurnTrace]:
        cursor = (
            self._traces.find(
                {"agent_id": agent_id},
                {"_id": 0},
                sort=[("started_at_ms", -1)],
            )
            .skip(offset)
            .limit(limit)
        )
        return [_doc_to_turn_trace(d) async for d in cursor]