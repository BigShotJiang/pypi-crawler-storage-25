from enum import Enum
from typing import Any, Literal, Optional
from uuid import uuid4

from pydantic import BaseModel, Field


class MessageRole(Enum):
    USER                = "user"
    ASSISTANT           = "assistant"
    COLLEAGUE_ASSISTANT = "colleague_assistant"
    SYSTEM              = "system"


class Entity(BaseModel):
    name:       str
    attributes: list[str] = Field(default_factory=list)


class Conversation(BaseModel):
    id:              str
    user_id:         str
    agent_id:        str
    title:           str
    created_at:      int
    last_updated_at: int


class Message(BaseModel):
    id:               str
    conversation_id:  str
    user_id:          str
    role:             MessageRole
    original_content: str
    enhanced_message: str                  = ""
    explicit_context: Optional[list[str]]  = None
    episode_id:       int                  = 0
    sentiment_score:  float                = Field(default=0.0, ge=-1.0, le=1.0)
    intent:           str                  = "unknown"
    entities:         list[Entity]         = Field(default_factory=list)
    is_cancellation:  bool                 = False
    is_continuation:  bool                 = True
    is_flagged:       bool                 = False
    timestamp:        int
    invoked_flows:    Optional[list[str]]  = None
    invoked_tools:    Optional[list[str]]  = None
    reasoning_steps:  Optional[list[str]]  = None
    errors:           Optional[list[str]]  = None


# ══════════════════════════════════════════════════════════════════════════════
# Turn-trace sub-models
# ══════════════════════════════════════════════════════════════════════════════

class LLMCallRecord(BaseModel):
    """
    One LLM API call within a turn.

    purpose values:
      "agent_loop"       — main agent reasoning / response generation
      "script_generation"— ToolOrchestrator asking the LLM to write a script
      "flow_selection"   — FlowSelector asking the LLM to pick a flow id
      "slot_extraction"  — extracting slot values from user message
      "enhancement"      — MessageEnhancer (intent, entities, sentiment)
      "other"            — catch-all for future purposes
    """
    call_id:           str = Field(default_factory=lambda: str(uuid4()))
    purpose:           Literal[
                           "agent_loop",
                           "script_generation",
                           "flow_selection",
                           "slot_extraction",
                           "enhancement",
                           "other",
                       ]
    model:             str
    prompt_tokens:     int   = 0
    completion_tokens: int   = 0
    total_tokens:      int   = 0
    latency_ms:        int   = 0
    timestamp_ms:      int
    success:           bool  = True
    error:             Optional[str] = None


class ScriptGenAttempt(BaseModel):
    """
    One script-generation attempt within a task delegation.
    Retries appear as multiple records with attempt=1,2,3,…
    """
    attempt:           int           # 1-based
    prompt_tokens:     int   = 0
    completion_tokens: int   = 0
    latency_ms:        int   = 0
    success:           bool
    parse_error:       Optional[str] = None   # validation / parse failure, not exec failure


class TaskEmission(BaseModel):
    """
    A <task sandbox="…" mode="…">…</task> emitted by the agent LLM.
    Recorded in order; task_index is 1-based within the turn.
    """
    task_index:   int
    sandbox:      str
    mode:         Literal["plan", "interactive"]
    description:  str
    timestamp_ms: int


class ToolTrace(BaseModel):
    """
    Full execution trace for one task delegation (one <task> emission).

    Covers the entire lifecycle:
      1. Script generation (possibly multiple retry attempts)
      2. Container execution
      3. Result or failure

    final_script is the last generated script — populated only when the
    orchestrator ultimately accepts a script (even if prior attempts failed).
    Set to None if all generation attempts failed before execution.

    output_bytes reflects the total stdout bytes read from the container —
    useful for detecting unexpectedly large tool outputs.

    peak_memory_bytes is Optional because collecting it requires an additional
    Docker stats API call; populate it only when resource profiling is enabled.
    """
    task_index:              int
    sandbox:                 str
    mode:                    str

    # Human-readable task description as emitted in the <task> tag
    description:             str

    # Script generation across retries
    generation_attempts:     list[ScriptGenAttempt] = Field(default_factory=list)
    final_script:            Optional[str]          = None
    generation_total_tokens: int                    = 0
    generation_latency_ms:   int                    = 0

    # Container execution
    execution_id:            Optional[str]  = None
    success:                 bool           = False
    final_data:              Optional[Any]  = None
    intermediates:           list[dict]     = Field(default_factory=list)
    error:                   Optional[str]  = None
    traceback:               Optional[str]  = None
    execution_latency_ms:    int            = 0
    output_bytes:            int            = 0
    peak_memory_bytes:       Optional[int]  = None   # Docker stats, if collected

    # Total wall-clock time for this task (generation + execution)
    total_latency_ms:        int            = 0


class SlotEvent(BaseModel):
    """
    Snapshot of one slot's state at the end of the turn in which it was
    first requested or updated.  Collected_at_turn is None until the user
    provides the value.
    """
    flow_name:         str
    slot_name:         str
    slot_type:         str
    required:          bool
    value:             Optional[Any]  = None
    collected:         bool           = False
    collected_at_turn: Optional[int]  = None
    validation_error:  Optional[str]  = None


class ConfirmationEvent(BaseModel):
    """
    Resolution of a pending confirmation gate.

    question         — the text the agent asked the user to confirm
    outcome          — what the user's reply resolved to
    resolved_at_turn — the turn number in which the gate was resolved
    """
    question:         str
    outcome:          Literal["confirmed", "cancelled", "expired"]
    resolved_at_turn: int


class FlowEvent(BaseModel):
    """
    One lifecycle transition for a flow during this turn.

    Multiple events can occur in a single turn (e.g. topic_shifted + started).
    """
    flow_id:   str
    flow_name: str
    flow_type: str
    event:     Literal["started", "completed", "cancelled", "failed", "topic_shifted"]


class TurnTrace(BaseModel):
    """
    Complete observability record for one agent turn.

    Stored separately from Message; linked via message_id (the assistant
    Message that ended the turn).  One TurnTrace per assistant Message.

    Token accounting covers EVERY LLM call made during the turn — agent loop,
    script generation, flow selection, slot extraction, and enhancement.
    The per-call breakdown lives in llm_calls; the totals here are for fast
    aggregate queries (cost dashboards, rate-limit monitoring).

    Designed for:
      • Human-readable audit review (all decisions in one record)
      • Automated cost and latency analysis
      • Failure post-mortems (full script + traceback preserved)
      • Slot-collection and confirmation funnel analytics
    """
    id:              str = Field(default_factory=lambda: str(uuid4()))
    message_id:      str          # FK → Message.id  (assistant reply)
    conversation_id: str
    user_id:         str
    agent_id:        str
    turn_number:     int

    # ── Timing ────────────────────────────────────────────────────────────────
    started_at_ms:   int          # Unix ms when chat() was entered
    ended_at_ms:     int          # Unix ms when chat() returned
    total_latency_ms: int

    # ── Aggregated token usage (all LLM calls this turn) ─────────────────────
    total_prompt_tokens:     int = 0
    total_completion_tokens: int = 0
    total_tokens:            int = 0

    # ── Detailed records ──────────────────────────────────────────────────────
    llm_calls:           list[LLMCallRecord]    = Field(default_factory=list)
    task_emissions:      list[TaskEmission]     = Field(default_factory=list)
    tool_traces:         list[ToolTrace]        = Field(default_factory=list)
    slot_events:         list[SlotEvent]        = Field(default_factory=list)
    confirmation_events: list[ConfirmationEvent] = Field(default_factory=list)
    flow_events:         list[FlowEvent]        = Field(default_factory=list)
    reasoning_steps:     list[str]              = Field(default_factory=list)
    errors:              list[str]              = Field(default_factory=list)

    # ── Enhancement summary (from MessageEnhancer) ────────────────────────────
    detected_intent:   str        = "unknown"
    detected_entities: list[str]  = Field(default_factory=list)  # entity names only
    sentiment_score:   float      = 0.0
    is_continuation:   bool       = True
    is_cancellation:   bool       = False