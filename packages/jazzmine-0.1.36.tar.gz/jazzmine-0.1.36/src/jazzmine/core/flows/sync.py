"""
flow_sync.py
────────────
Startup synchronisation between BaseFlow.registry and the Qdrant flows collection.

Call once at startup AFTER all flows are constructed (and therefore registered):

    from jazzmine.core.flow_sync import sync_registry

    flows = build_flows()                  # constructs and registers all flows
    report = await sync_registry(proc_mem, agent_id=AGENT_ID)
    print(report)

The sync performs three operations:

  CREATE  — flow is in the registry but has no Qdrant entry (new flow).
  UPDATE  — flow is in both but checksums differ (definition changed).
  DELETE  — flow is in Qdrant but not in the registry (flow was removed from code).
  SKIP    — checksums match, nothing to do.

No operation touches Qdrant unless something actually changed.
"""

import logging
from dataclasses import dataclass, field

from jazzmine.core.flows import BaseFlow

logger = logging.getLogger(__name__)


# ── Result dataclass ───────────────────────────────────────────────────────────

@dataclass
class SyncReport:
    created:  list[str] = field(default_factory=list)   # flow names created
    updated:  list[str] = field(default_factory=list)   # flow names updated
    deleted:  list[str] = field(default_factory=list)   # flow names deleted
    skipped:  list[str] = field(default_factory=list)   # flow names unchanged

    def __str__(self) -> str:
        lines = ["── Flow sync report ──────────────────────────────────────"]
        if self.created:
            lines += [f"  CREATE  ({len(self.created)}): " + ", ".join(self.created)]
        if self.updated:
            lines += [f"  UPDATE  ({len(self.updated)}): " + ", ".join(self.updated)]
        if self.deleted:
            lines += [f"  DELETE  ({len(self.deleted)}): " + ", ".join(self.deleted)]
        if self.skipped:
            lines += [f"  SKIP    ({len(self.skipped)}): " + ", ".join(self.skipped)]
        total = len(self.created) + len(self.updated) + len(self.deleted)
        lines += [f"  ─────────────────────────────────────────────────────"]
        lines += [f"  {total} change(s), {len(self.skipped)} unchanged"]
        return "\n".join(lines)


# ── Main sync function ─────────────────────────────────────────────────────────

async def sync_registry(
    proc_mem,           # ProceduralMemory instance
    agent_id:  str,
    verbose:   bool = True,
) -> SyncReport:
    """
    Diff BaseFlow.registry against the Qdrant flows collection and apply
    the minimum set of changes to bring Qdrant in sync.

    Must be called while all flow objects are still alive (held by strong
    references in your build_flows() return list or similar). Flows only
    exist in BaseFlow.registry as weak references — if they've been GC'd
    before this call they won't be synced.
    """
    report = SyncReport()

    # ── 1. Snapshot of what's currently in Qdrant for this agent ──────────────
    stored_list = await proc_mem.list_flows(agent_id)
    # Keyed by flow_name for O(1) lookup
    stored: dict[str, dict] = {s["flow_name"]: s for s in stored_list}

    # ── 2. Snapshot of what's currently live in the registry ──────────────────
    live: dict[str, BaseFlow] = dict(BaseFlow.registry)  # strong-ref snapshot

    # ── 3. CREATE and UPDATE ───────────────────────────────────────────────────
    for flow_id, flow in live.items():
        d        = flow.to_dict()
        checksum = flow.compute_checksum()
        name     = flow.name

        kwargs = dict(
            embedding_text  = flow.build_embedding_text(),
            flow_id         = flow.id,
            flow_name       = name,
            flow_type       = d["type"],
            description     = flow.description,
            condition       = flow.condition,
            agent_id        = agent_id,
            desired_effects = flow.desired_effects,
            checksum        = checksum,
        )

        if name not in stored:
            # New flow — never been stored
            await proc_mem.memorize(**kwargs)
            report.created.append(name)
            if verbose:
                logger.info("CREATE  %s  (checksum=%s)", name, checksum)

        elif stored[name]["checksum"] != checksum:
            # Definition changed — re-embed and update payload
            # Use the existing Qdrant point UUID so we update in place
            kwargs["flow_id"] = stored[name]["flow_id"]
            await proc_mem.update_memory(**kwargs)
            report.updated.append(name)
            if verbose:
                logger.info(
                    "UPDATE  %s  (%s → %s)",
                    name, stored[name]["checksum"], checksum,
                )

        else:
            # Unchanged — skip
            report.skipped.append(name)
            if verbose:
                logger.debug("SKIP    %s  (checksum=%s unchanged)", name, checksum)

    # ── 4. DELETE orphaned flows ───────────────────────────────────────────────
    live_names = {flow.name for flow in live.values()}
    for name, stored_flow in stored.items():
        if name not in live_names:
            await proc_mem.delete_flow(stored_flow["flow_id"])
            report.deleted.append(name)
            if verbose:
                logger.info("DELETE  %s  (no longer in registry)", name)

    return report