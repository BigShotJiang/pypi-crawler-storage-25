from abc import ABC, abstractmethod
import hashlib
import json
import weakref
from uuid import uuid4, uuid5, NAMESPACE_DNS


class BaseFlow(ABC):

    # Class-level registry: flow_id → flow instance (weak references).
    # WeakValueDictionary won't prevent GC — entries vanish automatically when
    # the last strong reference to a flow is dropped.
    registry: "weakref.WeakValueDictionary[str, BaseFlow]" = weakref.WeakValueDictionary()

    def __init__(self, name: str, description: str, condition: str, desired_effects: list[str],
                 examples: list[str], flow_id: str | None = None):
        # uuid5 is deterministic: same name → same UUID every restart.
        # This keeps Qdrant point IDs stable so sync and recall work correctly
        # across process restarts without re-embedding unchanged flows.
        self.id          = flow_id or str(uuid5(NAMESPACE_DNS, name))
        self.name        = name
        self.description = description
        self.condition   = condition
        self.examples    = examples
        self.desired_effects = desired_effects

        if len(examples) < 5 :
            raise ValueError("At least 5 examples are required to ensure robust flow triggering.")  
        # Only enforce desired_effects for non-CompositeFlow
        if type(self).__name__ not in ("CompositeFlow", "SequentialFlow", "ParallelFlow", "ConditionalFlow"):
            if len(desired_effects) < 1:
                raise ValueError("At least 1 desired effect is required to ensure clear flow objectives.")

        # Register immediately — WeakValueDictionary won't keep this alive
        BaseFlow.registry[self.id] = self

    @abstractmethod
    def to_dict(self) -> dict:
        pass

    @abstractmethod
    def build_prompt(self, verbose: bool = True) -> str:
        pass

    @abstractmethod
    def build_embedding_text(self) -> str:
        """
        Produce a short, dense text for embedding and semantic recall.
        This is what gets stored in Qdrant — NOT the full prompt.
        """
        pass

    def compute_checksum(self) -> str:
        """
        SHA-256 (first 16 hex chars) over the flow's canonical content.

        Covers every field in to_dict() except 'id' (identity, not content)
        and 'subflows' ids (each subflow checksums itself independently).
        Used by sync_registry() at startup to skip unchanged flows and avoid
        unnecessary re-embedding.
        """
        d = self.to_dict()
        # Remove identity and structural fields that change without content changing
        for key in ("id", "subflows"):
            d.pop(key, None)
        canonical = json.dumps(d, sort_keys=True, ensure_ascii=True)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def _escape_xml(self, text: str) -> str:
        return (text
                .replace('&', '&amp;')
                .replace('<', '&lt;')
                .replace('>', '&gt;')
                .replace('"', '&quot;')
                .replace("'", '&apos;'))


class Flow(BaseFlow):

    def __init__(
        self,
        name: str,
        description: str,
        condition: str,
        desired_effects: list[str],
        examples: list[str],
        tools: list[str] | None = None,
        priority: tuple[int, int] = (0, 0),
        flow_id: str | None = None,
    ):
        super().__init__(name, description, condition, desired_effects, examples, flow_id)
        self.desired_effects = desired_effects
        self.tools           = tools or []
        self.priority        = priority

    def to_dict(self) -> dict:
        return {
            "id":              self.id,
            "type":            "flow",
            "name":            self.name,
            "description":     self.description,
            "condition":       self.condition,
            "desired_effects": self.desired_effects,
            "examples":        self.examples,
            "tools":           self.tools,
            "priority":        list(self.priority),
        }

    def build_embedding_text(self) -> str:
        """
        Compact semantic fingerprint used for Qdrant embedding.
        Includes the most signal-rich fields only.
        """
        parts = [
            self.description,
            self.condition,
            *self.examples,
            *self.desired_effects,
        ]
        return " | ".join(p.strip() for p in parts if p.strip())

    def build_prompt(self, verbose: bool = True) -> str:
        p = []
        p.append(f'<flow id="{self.id}" priority="{self.priority[0]}.{self.priority[1]}">')
        p.append(f'  <name>{self._escape_xml(self.name)}</name>')
        p.append('')

        p.append('  <purpose>')
        if verbose:
            p.append('    <!-- What this flow does -->')
        p.append(f'    {self._escape_xml(self.description)}')
        p.append('  </purpose>')
        p.append('')

        p.append('  <trigger_condition>')
        if verbose:
            p.append('    <!-- IMPORTANT: Trigger ONLY when this condition is met -->')
        p.append(f'    {self._escape_xml(self.condition)}')
        p.append('  </trigger_condition>')
        p.append('')

        if self.examples:
            p.append('  <example_triggers>')
            if verbose:
                p.append('    <!-- Representative user messages that activate this flow -->')
            for i, ex in enumerate(self.examples, 1):
                p.append(f'    <example index="{i}">{self._escape_xml(ex)}</example>')
            p.append('  </example_triggers>')
            p.append('')

        if self.desired_effects:
            p.append('  <desired_effects>')
            if verbose:
                p.append('    <!-- The agent MUST accomplish ALL of the following -->')
            for i, effect in enumerate(self.desired_effects, 1):
                p.append(f'    <effect index="{i}">{self._escape_xml(effect)}</effect>')
            p.append('  </desired_effects>')
            p.append('')

        if self.tools:
            p.append('  <required_tools>')
            if verbose:
                p.append('    <!-- The agent MUST use these tools -->')
            for tool in self.tools:
                p.append(f'    <tool>{self._escape_xml(tool)}</tool>')
            p.append('  </required_tools>')
            p.append('')

        p.append('</flow>')
        return '\n'.join(p)


class CompositeFlow(BaseFlow):
    """
    Base for flows composed of multiple sub-flows.
    Carries its own top-level identity (id, name, description, condition, examples)
    so it can be stored and recalled from procedural memory as a single unit.
    """

    def __init__(
        self,
        name: str,
        description: str,
        condition: str,
        examples: list[str],
        subflows: list[BaseFlow],
        priority: tuple[int, int] = (0, 0),
        flow_id: str | None = None,
    ):
        super().__init__(name, description, condition, [], examples, flow_id)
        self.subflows = subflows
        self.priority = priority


    def build_embedding_text(self) -> str:
        """
        Use only the composite's own identity — NOT leaf signals.

        Aggregating leaf signals makes composite flows match almost any query
        that touches any of their sub-steps, turning them into catch-alls that
        crowd out the more specific leaf flows in recall.

        Composites should only surface when the query explicitly describes the
        multi-step, high-level intent (e.g. "guide me through the full checkout").
        """
        parts = [self.description, self.condition, *self.examples]
        return " | ".join(p.strip() for p in parts if p.strip())

    def to_dict(self) -> dict:
        return {
            "id":          self.id,
            "type":        self.__class__.__name__.lower(),
            "name":        self.name,
            "description": self.description,
            "condition":   self.condition,
            "examples":    self.examples,
            "priority":    list(self.priority),
            "subflows":    [sf.to_dict() for sf in self.subflows],
        }


class SequentialFlow(CompositeFlow):

    def build_prompt(self, verbose: bool = True) -> str:
        p = [
            f'<sequential_flow id="{self.id}" priority="{self.priority[0]}.{self.priority[1]}">',
            f'  <name>{self._escape_xml(self.name)}</name>',
            '',
            '  <execution_model>',
        ]
        if verbose:
            p += [
                '    <!-- EXECUTE STEPS IN ORDER: complete step N before starting N+1 -->',
                '    <!-- If ANY step fails, STOP and report which step failed -->',
            ]
        p += ['  </execution_model>', '']

        for i, sf in enumerate(self.subflows, 1):
            p.append(f'  <step number="{i}">')
            for line in sf.build_prompt(verbose).split('\n'):
                p.append(f'    {line}')
            p.append('  </step>')
            p.append('')

        p.append('</sequential_flow>')
        return '\n'.join(p)


class ParallelFlow(CompositeFlow):

    def build_prompt(self, verbose: bool = True) -> str:
        p = [
            f'<parallel_flow id="{self.id}" priority="{self.priority[0]}.{self.priority[1]}">',
            f'  <name>{self._escape_xml(self.name)}</name>',
            '',
            '  <execution_model>',
        ]
        if verbose:
            p += [
                '    <!-- EXECUTE ALL BRANCHES CONCURRENTLY -->',
                '    <!-- Branches are INDEPENDENT: one can succeed while another fails -->',
                '    <!-- Aggregate results from ALL branches before proceeding -->',
            ]
        p += ['  </execution_model>', '']

        for i, sf in enumerate(self.subflows, 1):
            p.append(f'  <branch id="branch_{i}" independence="true">')
            for line in sf.build_prompt(verbose).split('\n'):
                p.append(f'    {line}')
            p.append('  </branch>')
            p.append('')

        if verbose:
            p += [
                '  <completion_criteria>',
                '    <!-- Wait for ALL branches to complete before proceeding -->',
                '  </completion_criteria>',
            ]

        p.append('</parallel_flow>')
        return '\n'.join(p)


class ConditionalFlow(CompositeFlow):

    def __init__(
        self,
        name: str,
        description: str,
        condition: str,
        examples: list[str],
        condition_expr: str,
        true_flow: BaseFlow,
        false_flow: BaseFlow | None = None,
        priority: tuple[int, int] = (0, 0),
        flow_id: str | None = None,
    ):
        subflows = [true_flow, false_flow] if false_flow else [true_flow]
        super().__init__(name, description, condition, examples, subflows, priority, flow_id)
        self.condition_expr = condition_expr
        self.true_flow      = true_flow
        self.false_flow     = false_flow

    def to_dict(self) -> dict:
        d = super().to_dict()
        d["condition_expr"] = self.condition_expr
        return d

    def build_prompt(self, verbose: bool = True) -> str:
        p = [
            f'<conditional_flow id="{self.id}" priority="{self.priority[0]}.{self.priority[1]}">',
            f'  <name>{self._escape_xml(self.name)}</name>',
            '',
        ]
        if verbose:
            p += [
                '  <decision_logic>',
                '    <!-- Evaluate the condition ONCE, then execute the matching branch only -->',
                '  </decision_logic>',
                '',
            ]

        p += [
            '  <condition>',
            f'    <expression>{self._escape_xml(self.condition_expr)}</expression>',
        ]
        if verbose:
            p.append('    <!-- Evaluate as boolean. State what info is needed if ambiguous. -->')
        p += ['  </condition>', '']

        p.append('  <true_branch>')
        if verbose:
            p.append('    <!-- Execute ONLY if condition is TRUE -->')
        for line in self.true_flow.build_prompt(verbose).split('\n'):
            p.append(f'    {line}')
        p.append('  </true_branch>')
        p.append('')

        p.append('  <false_branch>')
        if self.false_flow:
            if verbose:
                p.append('    <!-- Execute ONLY if condition is FALSE -->')
            for line in self.false_flow.build_prompt(verbose).split('\n'):
                p.append(f'    {line}')
        elif verbose:
            p.append('    <!-- NO ACTION if condition is false -->')
        p.append('  </false_branch>')
        p.append('')

        p.append('</conditional_flow>')
        return '\n'.join(p)


class FlowBuilder:

    @staticmethod
    def sequential(
        name: str, description: str, condition: str,
        examples: list[str], *flows: BaseFlow,
        priority: tuple[int, int] = (0, 0),
    ) -> SequentialFlow:
        return SequentialFlow(name, description, condition, examples,
                              list(flows), priority)

    @staticmethod
    def parallel(
        name: str, description: str, condition: str,
        examples: list[str], *flows: BaseFlow,
        priority: tuple[int, int] = (0, 0),
    ) -> ParallelFlow:
        return ParallelFlow(name, description, condition, examples,
                            list(flows), priority)

    @staticmethod
    def conditional(
        name: str, description: str, condition: str,
        examples: list[str], condition_expr: str,
        true_flow: BaseFlow, false_flow: BaseFlow | None = None,
        priority: tuple[int, int] = (0, 0),
    ) -> ConditionalFlow:
        return ConditionalFlow(name, description, condition, examples,
                               condition_expr, true_flow, false_flow, priority)