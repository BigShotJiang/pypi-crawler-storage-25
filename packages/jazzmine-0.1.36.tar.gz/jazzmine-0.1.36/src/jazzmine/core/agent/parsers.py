from __future__ import annotations

import re

_TASK_RE = re.compile(
    r'<task(?:\s+sandbox=["\']([^"\']*)["\'])?(?:\s+mode=["\']([^"\']*)["\'])?[^>]*>'
    r'(.*?)</task>',
    re.DOTALL | re.IGNORECASE,
)
_RESPONSE_RE = re.compile(r'<response>(.*?)</response>', re.DOTALL)
_CONFIRM_RE = re.compile(r'<confirm\s*/?>', re.IGNORECASE)
_CANCEL_RE = re.compile(r'<cancel\s*/?>', re.IGNORECASE)
_FLOW_COMPLETE_RE = re.compile(r'<flow_complete\s*/?>', re.IGNORECASE)


def parse_task_request(text: str) -> tuple[str, str, str] | None:
    match = _TASK_RE.search(text)
    if not match:
        return None
    sandbox = (match.group(1) or "").strip()
    mode = (match.group(2) or "").strip()
    task = match.group(3).strip()
    return sandbox, mode, task


def extract_response(text: str) -> str:
    match = _RESPONSE_RE.search(text)
    if match:
        return match.group(1).strip()
    clean = _TASK_RE.sub("", text)
    clean = re.sub(r'<(confirm|cancel|flow_complete)\s*/?>', "", clean, flags=re.IGNORECASE)
    return clean.strip()
