from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from jazzmine.core.working_memory.enums import ConversationStatus, FlowStatus
from jazzmine.core.working_memory.records import (
    FlowRecord,
    PendingConfirmation,
    Slot,
    ToolCallRecord,
    TopicShift,
    WorkspaceEntity,
)


@dataclass
class ActiveFlowState:
    flow_id: str
    flow_name: str
    flow_type: str
    status: FlowStatus = FlowStatus.ACTIVE
    started_at_turn: int = 0
    started_at: float = field(default_factory=time.time)

    priority: list[int] = field(default_factory=lambda: [0, 0])
    tools_required: list[str] = field(default_factory=list)

    current_step: int = 0
    total_steps: int = 0
    step_results: list[dict] = field(default_factory=list)

    branch_results: dict[str, Any] = field(default_factory=dict)

    condition_expr: str | None = None
    condition_branch_taken: str | None = None

    tool_call_history: list[ToolCallRecord] = field(default_factory=list)
    slots: dict[str, Slot] = field(default_factory=dict)

    @property
    def pending_slots(self) -> list[Slot]:
        return [s for s in self.slots.values() if s.is_pending]

    @property
    def all_slots_collected(self) -> bool:
        return all(not s.is_pending for s in self.slots.values())

    @property
    def collected_slot_values(self) -> dict[str, Any]:
        return {n: s.value for n, s in self.slots.items() if s.collected}

    @property
    def completed_branches(self) -> int:
        return sum(1 for v in self.branch_results.values() if v is not None)

    @property
    def all_branches_done(self) -> bool:
        return bool(self.branch_results) and all(v is not None for v in self.branch_results.values())

    @property
    def is_sequential_complete(self) -> bool:
        return self.total_steps > 0 and self.current_step >= self.total_steps

    @property
    def priority_tuple(self) -> tuple[int, int]:
        return (self.priority[0], self.priority[1]) if len(self.priority) >= 2 else (0, 0)

    @property
    def last_tool_result(self) -> ToolCallRecord | None:
        return self.tool_call_history[-1] if self.tool_call_history else None

    @property
    def failed_tool_calls(self) -> list[ToolCallRecord]:
        return [c for c in self.tool_call_history if not c.success]

    @property
    def tool_calls_for_step(self) -> list[ToolCallRecord]:
        return [c for c in self.tool_call_history if c.step == self.current_step]

    def build_tool_history_prompt(self) -> str:
        if not self.tool_call_history:
            return ""
        inner = "\n".join(c.to_prompt_xml() for c in self.tool_call_history)
        return f"<completed_tool_calls>\n{inner}\n</completed_tool_calls>"

    @classmethod
    def from_flow(cls, flow, turn_number: int) -> "ActiveFlowState":
        flow_type = type(flow).__name__.lower()

        branch_results: dict[str, Any] = {}
        if flow_type == "parallelflow":
            for i in range(1, len(getattr(flow, "subflows", [])) + 1):
                branch_results[f"branch_{i}"] = None

        return cls(
            flow_id=flow.id,
            flow_name=flow.name,
            flow_type=flow_type,
            started_at_turn=turn_number,
            priority=list(getattr(flow, "priority", (0, 0))),
            tools_required=list(getattr(flow, "tools", [])),
            total_steps=len(getattr(flow, "subflows", [])),
            branch_results=branch_results,
            condition_expr=getattr(flow, "condition_expr", None),
        )

    def to_dict(self) -> dict:
        return {
            "flow_id": self.flow_id,
            "flow_name": self.flow_name,
            "flow_type": self.flow_type,
            "status": self.status.value,
            "started_at_turn": self.started_at_turn,
            "started_at": self.started_at,
            "priority": self.priority,
            "tools_required": self.tools_required,
            "current_step": self.current_step,
            "total_steps": self.total_steps,
            "step_results": self.step_results,
            "branch_results": self.branch_results,
            "condition_expr": self.condition_expr,
            "condition_branch_taken": self.condition_branch_taken,
            "tool_call_history": [c.to_dict() for c in self.tool_call_history],
            "slots": {k: s.to_dict() for k, s in self.slots.items()},
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ActiveFlowState":
        d = dict(d)
        d["status"] = FlowStatus(d["status"])
        d["tool_call_history"] = [ToolCallRecord.from_dict(c) for c in d.get("tool_call_history", [])]
        d["slots"] = {k: Slot.from_dict(v) for k, v in d.get("slots", {}).items()}
        return cls(**d)


@dataclass
class TurnCache:
    turn_number: int

    enhanced_query: str = ""
    intent: str = "unknown"
    sentiment_score: float = 0.0
    is_continuation: bool = True
    is_cancellation: bool = False
    raw_entities: list[dict] = field(default_factory=list)

    retrieved_same_conv_episodes: list[dict] = field(default_factory=list)
    retrieved_prev_conv_episodes: list[dict] = field(default_factory=list)

    retrieved_semantic_terms: list[dict] = field(default_factory=list)

    combined_flow_prompt: str = ""
    selected_flow_ids: list[str] = field(default_factory=list)
    unresolved_flow_ids: list[str] = field(default_factory=list)
    flow_candidates: list[dict] = field(default_factory=list)

    tool_calls: list[ToolCallRecord] = field(default_factory=list)

    @property
    def episode_short_summaries(self) -> list[str]:
        same = [ep["short_summary"] for ep in self.retrieved_same_conv_episodes if ep.get("short_summary")]
        prev = [ep["short_summary"] for ep in self.retrieved_prev_conv_episodes if ep.get("short_summary")]
        return same + prev

    @property
    def has_flow_selected(self) -> bool:
        return bool(self.selected_flow_ids)

    @property
    def last_tool_result(self) -> ToolCallRecord | None:
        return self.tool_calls[-1] if self.tool_calls else None

    @property
    def has_failed_tool_call(self) -> bool:
        return any(not c.success for c in self.tool_calls)

    def build_turn_tool_calls_prompt(self) -> str:
        if not self.tool_calls:
            return ""
        inner = "\n".join(c.to_prompt_xml() for c in self.tool_calls)
        return f"<current_turn_tool_calls>\n{inner}\n</current_turn_tool_calls>"

    def to_dict(self) -> dict:
        return {
            "turn_number": self.turn_number,
            "enhanced_query": self.enhanced_query,
            "intent": self.intent,
            "sentiment_score": self.sentiment_score,
            "is_continuation": self.is_continuation,
            "is_cancellation": self.is_cancellation,
            "raw_entities": self.raw_entities,
            "retrieved_same_conv_episodes": self.retrieved_same_conv_episodes,
            "retrieved_prev_conv_episodes": self.retrieved_prev_conv_episodes,
            "retrieved_semantic_terms": self.retrieved_semantic_terms,
            "combined_flow_prompt": self.combined_flow_prompt,
            "selected_flow_ids": self.selected_flow_ids,
            "unresolved_flow_ids": self.unresolved_flow_ids,
            "flow_candidates": self.flow_candidates,
            "tool_calls": [c.to_dict() for c in self.tool_calls],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "TurnCache":
        d = dict(d)
        d["tool_calls"] = [ToolCallRecord.from_dict(c) for c in d.get("tool_calls", [])]
        return cls(**d)

    @classmethod
    def from_enhancer_and_selector(
        cls,
        turn_number: int,
        enhanced_msg,
        same_episodes: list[dict],
        prev_episodes: list[dict],
        semantic_terms: list[dict],
        selection,
    ) -> "TurnCache":
        raw_entities = [{"name": e.name, "attributes": list(e.attributes)} for e in (enhanced_msg.entities or [])]

        combined_prompt = ""
        selected_flow_ids: list[str] = []
        unresolved_ids: list[str] = []
        candidates: list[dict] = []

        if selection is not None:
            combined_prompt = selection.combined_prompt
            selected_flow_ids = [f.id for f in selection.chosen_flows]
            unresolved_ids = selection.unresolved_ids
            candidates = selection.candidates

        return cls(
            turn_number=turn_number,
            enhanced_query=enhanced_msg.enhanced_message or enhanced_msg.original_content,
            intent=enhanced_msg.intent or "unknown",
            sentiment_score=enhanced_msg.sentiment_score,
            is_continuation=enhanced_msg.is_continuation,
            is_cancellation=enhanced_msg.is_cancellation,
            raw_entities=raw_entities,
            retrieved_same_conv_episodes=same_episodes,
            retrieved_prev_conv_episodes=prev_episodes,
            retrieved_semantic_terms=semantic_terms,
            combined_flow_prompt=combined_prompt,
            selected_flow_ids=selected_flow_ids,
            unresolved_flow_ids=unresolved_ids,
            flow_candidates=candidates,
        )


@dataclass
class WorkingMemory:
    conversation_id: str
    user_id: str
    agent_id: str
    created_at: float = field(default_factory=time.time)
    last_updated: float = field(default_factory=time.time)

    status: ConversationStatus = ConversationStatus.IDLE
    turn_number: int = 0

    active_flow: ActiveFlowState | None = None
    flow_history: list[FlowRecord] = field(default_factory=list)

    pending_confirmation: PendingConfirmation | None = None

    entity_workspace: dict[str, WorkspaceEntity] = field(default_factory=dict)
    entity_max_age_turns: int = 5

    topic_history: list[TopicShift] = field(default_factory=list)

    last_agent_response: str | None = None
    last_agent_intent: str | None = None

    current_turn: TurnCache | None = None

    @property
    def is_in_flow(self) -> bool:
        return self.active_flow is not None and self.active_flow.status in (
            FlowStatus.ACTIVE,
            FlowStatus.COLLECTING_SLOTS,
            FlowStatus.AWAITING_CONFIRMATION,
        )

    @property
    def has_pending_confirmation(self) -> bool:
        return self.pending_confirmation is not None

    @property
    def pending_slots(self) -> list[Slot]:
        if self.active_flow is None:
            return []
        return self.active_flow.pending_slots

    @property
    def current_flow_can_be_interrupted(self) -> bool:
        if self.active_flow is None:
            return True
        return self.active_flow.status == FlowStatus.COLLECTING_SLOTS

    @property
    def last_tool_result(self) -> ToolCallRecord | None:
        if self.current_turn and self.current_turn.tool_calls:
            return self.current_turn.tool_calls[-1]
        if self.active_flow and self.active_flow.tool_call_history:
            return self.active_flow.tool_call_history[-1]
        return None

    def build_prompt_tool_sections(self) -> str:
        flow_block = self.active_flow.build_tool_history_prompt() if self.active_flow else ""
        turn_block = self.current_turn.build_turn_tool_calls_prompt() if self.current_turn else ""

        if flow_block and turn_block and flow_block == turn_block.replace(
            "current_turn_tool_calls", "completed_tool_calls"
        ):
            return turn_block

        return "\n\n".join(s for s in (flow_block, turn_block) if s)

    @property
    def salient_entities(self) -> list[WorkspaceEntity]:
        return sorted(self.entity_workspace.values(), key=lambda e: e.last_seen_turn, reverse=True)

    @property
    def topic_count(self) -> int:
        return len(self.topic_history)

    @property
    def flows_completed_names(self) -> list[str]:
        return [r.flow_name for r in self.flow_history if r.status == FlowStatus.COMPLETED.value]

    def to_dict(self) -> dict:
        return {
            "conversation_id": self.conversation_id,
            "user_id": self.user_id,
            "agent_id": self.agent_id,
            "created_at": self.created_at,
            "last_updated": self.last_updated,
            "status": self.status.value,
            "turn_number": self.turn_number,
            "active_flow": self.active_flow.to_dict() if self.active_flow else None,
            "flow_history": [f.to_dict() for f in self.flow_history],
            "pending_confirmation": self.pending_confirmation.to_dict() if self.pending_confirmation else None,
            "entity_workspace": {k: e.to_dict() for k, e in self.entity_workspace.items()},
            "entity_max_age_turns": self.entity_max_age_turns,
            "topic_history": [t.to_dict() for t in self.topic_history],
            "last_agent_response": self.last_agent_response,
            "last_agent_intent": self.last_agent_intent,
            "current_turn": self.current_turn.to_dict() if self.current_turn else None,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WorkingMemory":
        d = dict(d)
        d["status"] = ConversationStatus(d["status"])
        d["active_flow"] = ActiveFlowState.from_dict(d["active_flow"]) if d.get("active_flow") else None
        d["flow_history"] = [FlowRecord.from_dict(f) for f in d.get("flow_history", [])]
        d["pending_confirmation"] = (
            PendingConfirmation.from_dict(d["pending_confirmation"]) if d.get("pending_confirmation") else None
        )
        d["entity_workspace"] = {k: WorkspaceEntity.from_dict(v) for k, v in d.get("entity_workspace", {}).items()}
        d["topic_history"] = [TopicShift.from_dict(t) for t in d.get("topic_history", [])]
        d["current_turn"] = TurnCache.from_dict(d["current_turn"]) if d.get("current_turn") else None
        return cls(**d)
