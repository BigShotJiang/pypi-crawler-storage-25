from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class ToolCallRecord:
    tool_name: str
    arguments: dict[str, Any]
    result: Any = None
    result_summary: str = ""
    success: bool = True
    error: str = ""
    turn_number: int = 0
    call_index: int = 0
    called_at: float = field(default_factory=time.time)
    step: int | None = None
    branch: str | None = None

    def to_dict(self) -> dict:
        return {
            "tool_name": self.tool_name,
            "arguments": self.arguments,
            "result": self.result,
            "result_summary": self.result_summary,
            "success": self.success,
            "error": self.error,
            "turn_number": self.turn_number,
            "call_index": self.call_index,
            "called_at": self.called_at,
            "step": self.step,
            "branch": self.branch,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ToolCallRecord":
        return cls(**d)

    def to_prompt_xml(self) -> str:
        attrs = [
            f'index="{self.call_index}"',
            f'tool="{self.tool_name}"',
            f'success="{str(self.success).lower()}"',
        ]
        if self.step is not None:
            attrs.append(f'step="{self.step}"')
        if self.branch is not None:
            attrs.append(f'branch="{self.branch}"')

        args_str = json.dumps(self.arguments, ensure_ascii=False)
        lines = [f'  <call {" ".join(attrs)}>']
        lines.append(f'    <args>{args_str}</args>')
        if self.success:
            lines.append(f'    <summary>{self.result_summary or "(no summary provided)"}</summary>')
        else:
            lines.append(f'    <error>{self.error}</error>')
        lines.append("  </call>")
        return "\n".join(lines)


@dataclass
class Slot:
    name: str
    description: str
    type: str
    required: bool = True
    collected: bool = False
    value: Any = None
    collected_at_turn: int = 0
    validation_error: str = ""

    @property
    def is_pending(self) -> bool:
        return self.required and not self.collected

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "required": self.required,
            "collected": self.collected,
            "value": self.value,
            "collected_at_turn": self.collected_at_turn,
            "validation_error": self.validation_error,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Slot":
        return cls(**d)


@dataclass
class PendingConfirmation:
    flow_id: str
    action_description: str
    action_payload: dict
    requested_at_turn: int
    requested_at: float = field(default_factory=time.time)
    timeout_turns: int = 3

    def is_expired(self, current_turn: int) -> bool:
        return (current_turn - self.requested_at_turn) >= self.timeout_turns

    def to_dict(self) -> dict:
        return {
            "flow_id": self.flow_id,
            "action_description": self.action_description,
            "action_payload": self.action_payload,
            "requested_at_turn": self.requested_at_turn,
            "requested_at": self.requested_at,
            "timeout_turns": self.timeout_turns,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "PendingConfirmation":
        return cls(**d)


@dataclass
class WorkspaceEntity:
    name: str
    attributes: list[str] = field(default_factory=list)
    first_seen_turn: int = 0
    last_seen_turn: int = 0
    mention_count: int = 1

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "attributes": self.attributes,
            "first_seen_turn": self.first_seen_turn,
            "last_seen_turn": self.last_seen_turn,
            "mention_count": self.mention_count,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "WorkspaceEntity":
        return cls(**d)


@dataclass
class TopicShift:
    turn_number: int
    intent: str
    summary: str = ""

    def to_dict(self) -> dict:
        return {"turn_number": self.turn_number, "intent": self.intent, "summary": self.summary}

    @classmethod
    def from_dict(cls, d: dict) -> "TopicShift":
        return cls(**d)


@dataclass
class FlowRecord:
    flow_id: str
    flow_name: str
    flow_type: str
    status: str
    started_at_turn: int
    ended_at_turn: int
    slot_values: dict[str, Any] = field(default_factory=dict)
    tool_summaries: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "flow_id": self.flow_id,
            "flow_name": self.flow_name,
            "flow_type": self.flow_type,
            "status": self.status,
            "started_at_turn": self.started_at_turn,
            "ended_at_turn": self.ended_at_turn,
            "slot_values": self.slot_values,
            "tool_summaries": self.tool_summaries,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "FlowRecord":
        d = dict(d)
        d.setdefault("tool_summaries", [])
        return cls(**d)
