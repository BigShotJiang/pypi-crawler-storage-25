from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable, Coroutine

log = logging.getLogger(__name__)

@dataclass
class Teardown:
    """
    Collected cleanup callbacks — called in reverse registration order (LIFO).

    Teardown order guarantees:
      1. agent.drain()      — background summarisation tasks complete first
      2. pool.shutdown()    — containers stopped while LLM is still alive
      3. llm(s).close()     — HTTP connections closed
      4. msg_store.close()  — DB connection pools released
      5. tmp file deleted   — JSON temp file cleaned up last

    Usage: `await teardown()` or `await teardown.run()`
    """
    _callbacks: list[Callable[[], Coroutine]] = field(default_factory=list)

    def register(self, fn: Callable[[], Coroutine]) -> None:
        self._callbacks.append(fn)

    async def run(self) -> None:
        for cb in reversed(self._callbacks):
            try:
                await cb()
            except Exception as exc:
                log.warning("Teardown callback raised: %s", exc)

    async def __call__(self) -> None:
        await self.run()


# ══════════════════════════════════════════════════════════════════════════════
