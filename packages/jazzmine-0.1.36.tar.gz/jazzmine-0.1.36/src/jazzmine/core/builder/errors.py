from __future__ import annotations

class ConfigError(ValueError):
    """Raised by AgentBuilder._validate() before any I/O is attempted."""
