"""
startup.py
──────────
Professional startup / teardown display for Jazzmine agents.

Renders the ASCII logo, slogan, live build events as they happen,
a clear "agent is ready" signal, and a graceful teardown sequence.

Usage
──────

Startup/teardown display is automatic by default in AgentBuilder.
Set the version tag with .version(...):

    agent, teardown = await (
        AgentBuilder(name="Aria", agent_id="...", personality="...")
        .version("1.0.0")
        .llm(...)
        .build()
    )

No explicit StartupDisplay wiring is required.

Integration with AgentBuilder
──────────────────────────────
AgentBuilder constructs StartupDisplay internally and emits startup, ready,
teardown, and build lifecycle events automatically.
"""

from __future__ import annotations

import sys
import time
from typing import Optional

# ── ANSI colour palette ────────────────────────────────────────────────────────
# 256-colour codes for a distinctive purple-teal brand theme.

_R      = "\033[0m"           # reset
_BOLD   = "\033[1m"
_DIM    = "\033[2m"

_PURPLE = "\033[38;5;135m"    # jazzmine brand purple
_MINT   = "\033[38;5;84m"     # success / checkmark
_CYAN   = "\033[38;5;81m"     # values / detail text
_GOLD   = "\033[38;5;221m"    # timing in ms
_GREY   = "\033[38;5;242m"    # dim structural chrome
_WHITE  = "\033[38;5;255m"    # bright white labels
_ORANGE = "\033[38;5;208m"    # warnings
_RED    = "\033[38;5;203m"    # errors
_TEAL   = "\033[38;5;50m"     # "ready" accent


def _purple(s: str)  -> str: return f"{_PURPLE}{s}{_R}"
def _mint(s: str)    -> str: return f"{_MINT}{s}{_R}"
def _cyan(s: str)    -> str: return f"{_CYAN}{s}{_R}"
def _gold(s: str)    -> str: return f"{_GOLD}{s}{_R}"
def _grey(s: str)    -> str: return f"{_GREY}{s}{_R}"
def _white(s: str)   -> str: return f"{_WHITE}{s}{_R}"
def _orange(s: str)  -> str: return f"{_ORANGE}{s}{_R}"
def _teal(s: str)    -> str: return f"{_TEAL}{s}{_R}"
def _bold(s: str)    -> str: return f"{_BOLD}{s}{_R}"
def _dim(s: str)     -> str: return f"{_DIM}{s}{_R}"
def _b_purple(s: str)-> str: return f"{_PURPLE}{_BOLD}{s}{_R}"


# ── Logo & layout constants ────────────────────────────────────────────────────

_LOGO_LINES = [
    r"       __                            _           ",
    r"      / /___ _____  ____  ____ ___  (_)___  ___  ",
    r" __  / / __ `/_  / /_  / / __ `__ \/ / __ \/ _ \ ",
    r"/ /_/ / /_/ / / /_  / /_/ / / / / / / / / /  __/ ",
    r"\____/\__,_/ /___/ /___/_/ /_/ /_/_/_/ /_/\___/  ",
]

_SLOGAN  = "Redefining Conversational AI"

# Render width — wide enough that the logo never wraps on a standard 130-col
# terminal but still readable at default 80-col.
_W       = 72           # inner content width (excluding left margin)
_INDENT  = "  "         # 2-space left margin on every line
_LABEL_W = 22           # fixed width for the component label column
_TAG     = f"{_PURPLE}{_BOLD}[Jazzmine]{_R}"

# Divider styles
_DIV_HEAVY = f"{_GREY}{'━' * (_W + len(_INDENT))}{_R}"
_DIV_LIGHT = f"{_GREY}{'─' * (_W + len(_INDENT))}{_R}"


# ── Symbols ────────────────────────────────────────────────────────────────────

_CHECK   = _mint("✓")
_DIAMOND = _teal("◆")
_BULLET  = _purple("◉")
_WARN    = _orange("⚠")
_CROSS   = f"{_RED}✗{_R}"
_ARROW   = _grey("›")


# ══════════════════════════════════════════════════════════════════════════════
# StartupDisplay
# ══════════════════════════════════════════════════════════════════════════════

class StartupDisplay:
    """
    Renders the Jazzmine startup banner and streams build events to stdout
    as they happen, giving operators a clear view of what is initialising.

    AgentBuilder creates and uses this internally by default.
    You generally don't instantiate StartupDisplay directly unless you are
    building custom startup/teardown UX outside AgentBuilder.

    Thread / async safety: all output is synchronous writes to sys.stdout.
    The GIL and the sequential nature of build() mean no locking is needed.
    """

    def __init__(
        self,
        agent_name: str  = "Agent",
        version:    str  = "",
        quiet:      bool = False,   # True = suppress all output (e.g. in tests)
    ) -> None:
        self._name      = agent_name
        self._version   = version
        self._quiet     = quiet
        self._t_build   = time.monotonic()   # wall time since banner was printed
        self._teardown_events: list[tuple[str, str]] = []

    # ── Public: banner ─────────────────────────────────────────────────────────

    def print_banner(self) -> None:
        """
        Print the ASCII logo, slogan, and open the build event section.
        Call this BEFORE AgentBuilder.build().
        """
        if self._quiet:
            return
        self._t_build = time.monotonic()
        w = sys.stdout

        w.write("\n\n")

        # ── Logo (purple gradient: top lines lighter, bottom darker) ──────────
        shades = [
            "\033[38;5;147m",   # lightest purple
            "\033[38;5;141m",
            "\033[38;5;135m",   # brand purple
            "\033[38;5;129m",
            "\033[38;5;93m",    # darkest purple
        ]
        for i, line in enumerate(_LOGO_LINES):
            shade = shades[min(i, len(shades) - 1)]
            w.write(f"{shade}{_BOLD}{line.center(76)}{_R}\n")

        w.write("\n")

        # ── Slogan ────────────────────────────────────────────────────────────
        slogan_line = _dim("·  ") + _cyan(_SLOGAN) + _dim("  ·")
        # manual centering: strip ANSI for width calc
        visible_len = len("·  " + _SLOGAN + "  ·")
        padding     = (76 - visible_len) // 2
        w.write(" " * padding + slogan_line + "\n\n")

        # ── Version / agent name badge ────────────────────────────────────────
        parts = [_b_purple("Jazzmine")]
        if self._version:
            parts.append(_grey(f"v{self._version}"))
        parts.append(_grey("·"))
        parts.append(_white(self._name))
        badge_visible = "Jazzmine"
        if self._version:
            badge_visible += f" v{self._version} · "
        else:
            badge_visible += " · "
        badge_visible += self._name
        pad = (76 - len(badge_visible)) // 2
        w.write(" " * pad + "  ".join(parts) + "\n")

        w.write("\n" + _DIV_LIGHT + "\n\n")

        w.flush()

    # ── Public: build events ───────────────────────────────────────────────────

    def event(
        self,
        label:   str,
        value:   str,
        ms:      Optional[int] = None,
        warning: bool          = False,
    ) -> None:
        """
        Emit one build event line.

            [Jazzmine]  ✓  Primary LLM          meta/llama-3.3-70b     12ms

        label   — component name, padded to _LABEL_W
        value   — detail string (model, count, URL, …)
        ms      — optional elapsed ms shown in gold on the right
        warning — use orange ⚠ instead of green ✓
        """
        if self._quiet:
            return

        symbol = _WARN if warning else _CHECK
        label_col = _white(label.ljust(_LABEL_W))
        value_col = _cyan(value)
        timing    = f"  {_gold(str(ms) + 'ms')}" if ms is not None else ""

        line = (
            f"{_INDENT}{_TAG}  {symbol}  {label_col}  {value_col}{timing}\n"
        )
        sys.stdout.write(line)
        sys.stdout.flush()

    def section(self, title: str) -> None:
        """
        Print a lightweight section separator (used between major build phases).
        """
        if self._quiet:
            return
        sys.stdout.write(
            f"\n{_INDENT}{_grey('┄' * 4)}  {_dim(title)}\n\n"
        )
        sys.stdout.flush()

    # ── Public: agent ready ────────────────────────────────────────────────────

    def print_ready(self, hint: str = "Ctrl+C to stop") -> None:
        """
        Print the "agent is ready" footer after all build events.
        Call this after AgentBuilder.build() returns.
        """
        if self._quiet:
            return

        elapsed = int((time.monotonic() - self._t_build) * 1000)

        sys.stdout.write("\n" + _DIV_HEAVY + "\n\n")

        ready_text = (
            f"{_INDENT}{_DIAMOND}  "
            f"{_b_purple(self._name)}"
            f"  {_grey('is ready')}  "
            f"{_grey('·')}  "
            f"{_dim(hint)}"
            f"  {_grey('·')}  "
            f"{_gold(str(elapsed) + 'ms')}\n"
        )
        sys.stdout.write(ready_text)
        sys.stdout.write("\n")
        sys.stdout.flush()

    # ── Public: teardown ───────────────────────────────────────────────────────

    def print_teardown_start(self) -> None:
        """
        Print the teardown header. Call this immediately before await teardown().
        """
        if self._quiet:
            return

        sys.stdout.write("\n" + _DIV_LIGHT + "\n\n")
        sys.stdout.write(
            f"{_INDENT}{_BULLET}  {_b_purple('Shutting down')}  {_grey(self._name + ' ...')}\n\n"
        )
        sys.stdout.flush()

    def teardown_event(self, label: str, value: str = "done") -> None:
        """
        Emit one teardown event line. Called by agent_builder during teardown
        wiring when a StartupDisplay is registered.
        """
        if self._quiet:
            return
        label_col = _white(label.ljust(_LABEL_W))
        sys.stdout.write(
            f"{_INDENT}{_TAG}  {_CHECK}  {label_col}  {_dim(value)}\n"
        )
        sys.stdout.flush()

    def print_teardown_done(self) -> None:
        """
        Print the final teardown footer. Call this after await teardown() returns.
        """
        if self._quiet:
            return

        sys.stdout.write("\n" + _DIV_HEAVY + "\n\n")
        sys.stdout.write(
            f"{_INDENT}{_grey('◆')}  {_dim('Goodbye.')}\n\n"
        )
        sys.stdout.flush()

    # ── Internal: called by AgentBuilder ──────────────────────────────────────

    def _on_build_start(self) -> None:
        """Called by AgentBuilder at the very start of build(), after validation."""
        if self._quiet:
            return
        sys.stdout.write(
            f"{_INDENT}{_BULLET}  "
            f"{_grey('Initializing')}  "
            f"{_b_purple(self._name)}"
            f"{_grey(' ...')}\n\n"
        )
        sys.stdout.flush()

    def _on_build_done(self) -> None:
        """Called by AgentBuilder after the agent object is constructed."""
        pass  # print_ready() is the user-facing call