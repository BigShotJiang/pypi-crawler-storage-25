import time
import httpx
import json
from typing import Iterator, AsyncIterator, List

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import LLMRateLimitError, LLMConnectionError, LLMInternalError, LLMTimeoutError

class CohereLLM(BaseLLM):
    def __init__(self, api_key: str, model: str = "command-r-plus", **kwargs):
        super().__init__(model=model, **kwargs)
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        base_url = "https://api.cohere.com/v2"
        self.client = httpx.Client(base_url=base_url, headers=headers, timeout=self.timeout)
        self.aclient = httpx.AsyncClient(base_url=base_url, headers=headers, timeout=self.timeout)

    def _prepare_payload(self, messages: List[MessagePart], stream: bool) -> dict:
        payload = {
            "model": self.model,
            "messages":[{"role": m.role, "content": m.content} for m in messages],
            "stream": stream,
        }
        if self.temperature is not None:
            payload["temperature"] = self.temperature
        if self.max_tokens is not None:
            payload["max_tokens"] = self.max_tokens
        return payload

    def _handle_error(self, e: Exception):
        if isinstance(e, httpx.TimeoutException):
            raise LLMTimeoutError(str(e))
        raise LLMConnectionError(str(e))

    def _parse_response(self, data: dict, start_time: float) -> LLMResponse:
        text = data.get("MessagePart", {}).get("content", [{}])[0].get("text", "")
        usage_data = data.get("usage", {}).get("tokens", {})
        usage = normalize_usage("", text, {
            "prompt_tokens": usage_data.get("input_tokens", 0),
            "completion_tokens": usage_data.get("output_tokens", 0)
        })
        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start_time) * 1000), raw=data
        )

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        try:
            r = self.client.post("/chat", json=self._prepare_payload(messages, False))
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429: raise LLMRateLimitError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        return self._parse_response(r.json(), start)

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        try:
            with self.client.stream("POST", "/chat", json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                for line in r.iter_lines():
                    if not line: continue
                    try:
                        event = json.loads(line)
                        if event.get("type") == "content-delta":
                            yield event.get("delta", {}).get("MessagePart", {}).get("content", {}).get("text", "")
                    except json.JSONDecodeError:
                        pass
        except httpx.RequestError as e:
            self._handle_error(e)

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        try:
            r = await self.aclient.post("/chat", json=self._prepare_payload(messages, False))
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 429: raise LLMRateLimitError(e.response.text)
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        return self._parse_response(r.json(), start)

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        try:
            async with self.aclient.stream("POST", "/chat", json=self._prepare_payload(messages, True)) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if not line: continue
                    try:
                        event = json.loads(line)
                        if event.get("type") == "content-delta":
                            yield event.get("delta", {}).get("MessagePart", {}).get("content", {}).get("text", "")
                    except json.JSONDecodeError:
                        pass
        except httpx.RequestError as e:
            self._handle_error(e)