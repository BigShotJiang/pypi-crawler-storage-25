import time
import httpx
import json
from typing import Iterator, AsyncIterator, List

from jazzmine.core.llm.base import BaseLLM
from jazzmine.core.llm.types import LLMResponse, MessagePart
from jazzmine.core.llm.utils import normalize_usage
from jazzmine.core.llm.errors import (
    LLMConnectionError, LLMInternalError,
    LLMInvalidRequestError, LLMTimeoutError
)

class GeminiLLM(BaseLLM):
    def __init__(self, api_key: str, model: str, base_url: str = "https://generativelanguage.googleapis.com", **kwargs):
        super().__init__(model=model, **kwargs)
        self.api_key = api_key
        self.base_url = base_url
        self.client = httpx.Client(timeout=self.timeout)
        self.aclient = httpx.AsyncClient(timeout=self.timeout)

    def _url(self, stream: bool = False) -> str:
        suffix = ":streamGenerateContent?alt=sse" if stream else ":generateContent"
        separator = "&" if "?" in suffix else "?"
        return f"{self.base_url}/v1beta/models/{self.model}{suffix}{separator}key={self.api_key}"

    def _prepare_payload(self, messages: List[MessagePart]) -> dict:
        gemini_msgs =[]
        system_text = ""
        for m in messages:
            if m.role == "system":
                system_text += m.content + "\n"
            else:
                role = "model" if m.role == "assistant" else "user"
                gemini_msgs.append({"role": role, "parts":[{"text": m.content}]})
                
        payload = {"contents": gemini_msgs}
        if system_text:
            payload["systemInstruction"] = {"parts":[{"text": system_text.strip()}]}
            
        config = {}
        if self.temperature is not None:
            config["temperature"] = self.temperature
        if self.max_tokens is not None:
            config["maxOutputTokens"] = self.max_tokens
            
        if config:
            payload["generationConfig"] = config
            
        return payload

    def _parse_response(self, data: dict, start_time: float) -> LLMResponse:
        candidates = data.get("candidates",[])
        if not candidates:
            feedback = data.get("promptFeedback", {})
            raise LLMInvalidRequestError(f"Blocked by Gemini Filters. Feedback: {feedback}")
            
        candidate = candidates[0]
        if candidate.get("finishReason") == "SAFETY":
            raise LLMInvalidRequestError("Blocked by Gemini safety filters")
            
        text = candidate.get("content", {}).get("parts", [{}])[0].get("text", "")
        usage = normalize_usage("", text, None)
        
        return LLMResponse(
            text=text, usage=usage, model=self.model,
            latency_ms=int((time.time() - start_time) * 1000), raw=data,
            finish_reason=candidate.get("finishReason"),
        )

    def _handle_error(self, e: Exception):
        if isinstance(e, httpx.TimeoutException):
            raise LLMTimeoutError(str(e))
        raise LLMConnectionError(str(e))

    def generate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        try:
            r = self.client.post(self._url(), json=self._prepare_payload(messages))
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        return self._parse_response(r.json(), start)

    def stream(self, messages: List[MessagePart], **kwargs) -> Iterator[str]:
        try:
            with self.client.stream("POST", self._url(stream=True), json=self._prepare_payload(messages)) as r:
                r.raise_for_status()
                for line in r.iter_lines():
                    if line.startswith("data: "):
                        payload = line[6:].strip()
                        if not payload: continue
                        try:
                            data = json.loads(payload)
                            for candidate in data.get("candidates", []):
                                for part in candidate.get("content", {}).get("parts",[]):
                                    if "text" in part: yield part["text"]
                        except json.JSONDecodeError:
                            pass
        except httpx.RequestError as e:
            self._handle_error(e)

    async def agenerate(self, messages: List[MessagePart], **kwargs) -> LLMResponse:
        start = time.time()
        try:
            r = await self.aclient.post(self._url(), json=self._prepare_payload(messages))
            r.raise_for_status()
        except httpx.HTTPStatusError as e:
            raise LLMInternalError(e.response.text)
        except httpx.RequestError as e:
            self._handle_error(e)
        return self._parse_response(r.json(), start)

    async def astream(self, messages: List[MessagePart], **kwargs) -> AsyncIterator[str]:
        try:
            async with self.aclient.stream("POST", self._url(stream=True), json=self._prepare_payload(messages)) as r:
                r.raise_for_status()
                async for line in r.aiter_lines():
                    if line.startswith("data: "):
                        payload = line[6:].strip()
                        if not payload: continue
                        try:
                            data = json.loads(payload)
                            for candidate in data.get("candidates",[]):
                                for part in candidate.get("content", {}).get("parts", []):
                                    if "text" in part: yield part["text"]
                        except json.JSONDecodeError:
                            pass
        except httpx.RequestError as e:
            self._handle_error(e)