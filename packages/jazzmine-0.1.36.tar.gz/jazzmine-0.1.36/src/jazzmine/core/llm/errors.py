class LLMError(Exception):
    """Base class for all LLM errors."""

class LLMTimeoutError(LLMError):
    pass

class LLMRateLimitError(LLMError):
    pass

class LLMConnectionError(LLMError):
    pass

class LLMInvalidRequestError(LLMError):
    pass

class LLMInternalError(LLMError):
    pass