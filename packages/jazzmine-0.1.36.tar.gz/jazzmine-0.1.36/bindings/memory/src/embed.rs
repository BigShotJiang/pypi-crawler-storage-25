use std::{
    cell::RefCell,
    collections::HashMap,
    fs,
    path::PathBuf,
    sync::{
        Arc, Mutex,
        atomic::{AtomicU64, Ordering},
    },
    time::Duration,
    num::NonZeroUsize,
};
use ndarray::{Array1, Array2, Array3, Axis};
use ort::{session::Session, value::Value};
use tokenizers::Tokenizer;
use tokio::sync::{mpsc, oneshot};
use lru::LruCache;
use serde_json::json;

thread_local! {
    static SCRATCH: RefCell<Vec<f32>> = RefCell::new(Vec::new());
}

// ── Priority ──────────────────────────────────────────────────────────────────

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Priority {
    High,
    Normal,
}

// ── Internal request type ─────────────────────────────────────────────────────

struct EmbedRequest {
    text: String,
    priority: Priority,
    sender: oneshot::Sender<Result<Vec<f32>, String>>,
}

// ── Lock-free metrics ─────────────────────────────────────────────────────────

pub struct EmbedderMetrics {
    pub total_requests: AtomicU64,
    pub total_batches:  AtomicU64,
    pub total_errors:   AtomicU64,
    pub cache_hits:     AtomicU64,
    pub cache_misses:   AtomicU64,
}

/// Plain snapshot returned to callers (Clone-able, Send + Sync).
#[derive(Clone, Debug)]
pub struct MetricsSnapshot {
    pub total_requests: u64,
    pub total_batches:  u64,
    pub total_errors:   u64,
    pub cache_hits:     u64,
    pub cache_misses:   u64,
}

impl EmbedderMetrics {
    fn new() -> Self {
        Self {
            total_requests: AtomicU64::new(0),
            total_batches:  AtomicU64::new(0),
            total_errors:   AtomicU64::new(0),
            cache_hits:     AtomicU64::new(0),
            cache_misses:   AtomicU64::new(0),
        }
    }

    pub fn snapshot(&self) -> MetricsSnapshot {
        MetricsSnapshot {
            total_requests: self.total_requests.load(Ordering::Relaxed),
            total_batches:  self.total_batches.load(Ordering::Relaxed),
            total_errors:   self.total_errors.load(Ordering::Relaxed),
            cache_hits:     self.cache_hits.load(Ordering::Relaxed),
            cache_misses:   self.cache_misses.load(Ordering::Relaxed),
        }
    }
}

// ── Provider ──────────────────────────────────────────────────────────────────

#[derive(Clone, Debug, PartialEq)]
pub enum Provider {
    OpenAI,
    AzureOpenAI,
    Gemini,
    Cohere,
    HuggingFace,
    Mistral,
    Together,
    VoyageAI,
    JinaAI,
    Nomic,
    OpenRouter,
    DeepInfra,
}

impl Provider {
    pub fn from_str(s: &str) -> Self {
        match s.to_lowercase().as_str() {
            "azure" | "azure_openai" | "azure-openai"                   => Provider::AzureOpenAI,
            "gemini" | "google" | "google_gemini" | "google-gemini"     => Provider::Gemini,
            "cohere"                                                     => Provider::Cohere,
            "huggingface" | "hf"                                        => Provider::HuggingFace,
            "mistral"                                                    => Provider::Mistral,
            "together" | "togetherai" | "together-ai"                   => Provider::Together,
            "voyage" | "voyageai" | "voyage-ai"                         => Provider::VoyageAI,
            "jina" | "jinaai" | "jina-ai"                               => Provider::JinaAI,
            "nomic"                                                      => Provider::Nomic,
            "openrouter" | "open_router" | "open-router"                => Provider::OpenRouter,
            "deepinfra" | "deep_infra" | "deep-infra"                   => Provider::DeepInfra,
            _                                                            => Provider::OpenAI,
        }
    }

    fn is_openai_compatible(&self) -> bool {
        matches!(
            self,
            Provider::OpenAI
                | Provider::Mistral
                | Provider::Together
                | Provider::VoyageAI
                | Provider::JinaAI
                | Provider::Nomic
                | Provider::OpenRouter
                | Provider::DeepInfra
        )
    }
}

// ── Local / Remote configs ────────────────────────────────────────────────────

#[derive(Clone, Debug)]
pub struct LocalConfig {
    pub model_dir: String,
    pub quantized:  bool,
}

#[derive(Clone, Debug)]
pub struct RemoteConfig {
    pub provider:   Provider,
    pub api_key:    String,
    pub base_url:   String,
    pub model_name: String,
}

// ── Backend ───────────────────────────────────────────────────────────────────

enum Backend {
    Uninitialized,
    LocalOnnx(Session),
    RemoteHttp {
        // FIX: async reqwest::Client — no internal blocking runtime, smaller binary.
        client: reqwest::Client,
        config: RemoteConfig,
    },
}

// ── Embedder ──────────────────────────────────────────────────────────────────

pub struct Embedder {
    tokenizer:   Arc<Tokenizer>,
    backend:     Arc<Mutex<Backend>>,
    hidden_size: usize,
    max_batch:   usize,
    // Dropping this sender signals the batcher to exit cleanly — no separate shutdown flag needed.
    batch_queue: mpsc::UnboundedSender<EmbedRequest>,
    cache:       Arc<Mutex<LruCache<String, Vec<f32>>>>,
    // FIX: AtomicU64 counters — completely lock-free, no Mutex<EmbedderMetrics>.
    metrics:     Arc<EmbedderMetrics>,
}

impl Embedder {
    pub fn new(
        tokenizer_path: String,
        hidden_size: usize,
        max_batch: usize,
    ) -> Result<Self, String> {
        if hidden_size == 0 || hidden_size > 4096 {
            return Err("hidden_size must be between 1 and 4096".to_string());
        }
        if max_batch < 2 {
            return Err("max_batch must be at least 2".to_string());
        }

        let tokenizer = Tokenizer::from_file(&tokenizer_path)
            .map_err(|e| format!("Failed to load tokenizer from {}: {}", tokenizer_path, e))?;

        let (tx, rx) = mpsc::unbounded_channel::<EmbedRequest>();
        let cache   = Arc::new(Mutex::new(LruCache::new(NonZeroUsize::new(1000).unwrap())));
        let metrics = Arc::new(EmbedderMetrics::new());

        let embedder = Self {
            tokenizer:   Arc::new(tokenizer),
            backend:     Arc::new(Mutex::new(Backend::Uninitialized)),
            hidden_size,
            max_batch,
            batch_queue: tx,
            cache:       Arc::clone(&cache),
            metrics:     Arc::clone(&metrics),
        };

        embedder.spawn_batcher_thread(rx);
        Ok(embedder)
    }

    // ── Backend setup ──────────────────────────────────────────────────────

    pub fn setup_local(&self, config: LocalConfig) -> Result<(), String> {
        let model_path = Self::resolve_local_model_path(&config.model_dir, config.quantized)?;

        // FIX (ORT memory-pattern reuse crash): Disable ORT's memory-pattern optimiser.
        //
        // Root cause: ORT reuses pre-allocated buffers whose shapes were recorded during the
        // first inference call (batch=1 warm-up below).  When the batcher subsequently submits
        // a larger batch (batch=2+) the shapes no longer match those recorded buffers, which
        // triggers an InvalidArgument / buffer-reuse shape conflict — most reproducibly on
        // Windows with INT8-quantized (DequantizeLinear) ONNX models.
        //
        // with_disable_mem_pattern() opts this session out of that optimisation entirely.
        // The small memory / throughput trade-off is negligible for embedding workloads
        // (inference is memory-bandwidth-bound, not allocation-bound).
        let mut session = Session::builder()
            .map_err(|e| format!("Builder error: {}", e))?
            .with_memory_pattern(false)
            .map_err(|e| format!("Failed to disable ORT memory-pattern reuse: {}", e))?
            .commit_from_file(&model_path)
            .map_err(|e| format!("Load error: {}", e))?;

        // Warm-up inference validates the model and primes the ONNX memory allocator.
        // Two items: ensures the allocator sees a multi-item batch on first use, matching
        // the shape the batcher will submit in production and avoiding any residual
        // single-vs-multi shape divergence even if mem-pattern reuse is later re-enabled.
        let _ = embed_onnx(
            &mut session,
            &self.tokenizer,
            &["warm".to_string(), "up".to_string()],
            self.hidden_size,
        )
        .map_err(|e| format!("Validation failed: {}", e))?;

        *self.backend.lock().unwrap() = Backend::LocalOnnx(session);
        Ok(())
    }

    fn resolve_local_model_path(model_dir: &str, quantized: bool) -> Result<PathBuf, String> {
        let suffix = if quantized { "_int8_qdq.onnx" } else { "_fp32.onnx" };
        let dir = PathBuf::from(model_dir);

        if !dir.exists() {
            return Err(format!("Model directory not found: {:?}", dir));
        }

        let entries = fs::read_dir(&dir)
            .map_err(|e| format!("Failed to read model directory {:?}: {}", dir, e))?;

        let mut candidates: Vec<PathBuf> = entries
            .filter_map(|e| e.ok().map(|e| e.path()))
            .filter(|p| {
                p.is_file()
                    && p.file_name()
                        .and_then(|n| n.to_str())
                        .map(|n| n.ends_with(suffix))
                        .unwrap_or(false)
            })
            .collect();

        if candidates.is_empty() {
            let mut available: Vec<String> = fs::read_dir(&dir)
                .ok()
                .into_iter()
                .flat_map(|it| it.filter_map(|e| e.ok()))
                .map(|e| e.path())
                .filter(|p| p.is_file())
                .filter_map(|p| p.file_name().and_then(|n| n.to_str()).map(|s| s.to_string()))
                .filter(|n| n.ends_with(".onnx"))
                .collect();
            available.sort();
            return Err(format!(
                "Model file not found in {:?}. Expected suffix '{}'; found: {:?}",
                dir, suffix, available
            ));
        }

        candidates.sort();
        Ok(candidates[0].clone())
    }

    pub fn setup_remote(&self, config: RemoteConfig) -> Result<(), String> {
        // FIX: Use async reqwest::Client instead of reqwest::blocking::Client.
        //      No extra internal runtime, no "blocking" feature, smaller binary.
        let client = reqwest::Client::builder()
            .timeout(Duration::from_secs(30))
            .build()
            .map_err(|e| format!("Client build error: {}", e))?;

        *self.backend.lock().unwrap() = Backend::RemoteHttp { client, config };
        Ok(())
    }

    // ── Public embedding API ───────────────────────────────────────────────

    pub fn compute_sparse_vector(&self, text: &str) -> Result<(Vec<u32>, Vec<f32>), String> {
        let encoding = self.tokenizer.encode(text, true)
            .map_err(|e| format!("Tokenization failed: {}", e))?;

        let ids = encoding.get_ids();
        let mut counts: HashMap<u32, f32> = HashMap::new();
        for &id in ids { *counts.entry(id).or_insert(0.0) += 1.0; }

        let mut pairs: Vec<(u32, f32)> = counts.into_iter().collect();
        pairs.sort_by_key(|(id, _)| *id);
        let (indices, values): (Vec<u32>, Vec<f32>) = pairs.into_iter().unzip();
        Ok((indices, values))
    }

    pub async fn embed(&self, text: &str) -> Result<Vec<f32>, String> {
        self.embed_with_priority(text, Priority::Normal).await
    }

    pub async fn embed_high_priority(&self, text: &str) -> Result<Vec<f32>, String> {
        self.embed_with_priority(text, Priority::High).await
    }

    pub async fn embed_batch(&self, texts: Vec<String>) -> Result<Vec<Vec<f32>>, String> {
        self.embed_batch_with_priority(texts, Priority::Normal).await
    }

    pub async fn embed_batch_high_priority(&self, texts: Vec<String>) -> Result<Vec<Vec<f32>>, String> {
        self.embed_batch_with_priority(texts, Priority::High).await
    }

    // ── Core: single embed ─────────────────────────────────────────────────

    async fn embed_with_priority(&self, text: &str, priority: Priority) -> Result<Vec<f32>, String> {
        // FIX: Single cache lock covers both the get AND the miss counter update.
        //      Previously: 3 separate Mutex acquisitions (cache, metrics, metrics again).
        {
            let mut cache = self.cache.lock().unwrap();
            if let Some(cached) = cache.get(text) {
                self.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
                return Ok(cached.clone());
            }
            self.metrics.cache_misses.fetch_add(1, Ordering::Relaxed);
        }
        self.metrics.total_requests.fetch_add(1, Ordering::Relaxed);

        let (tx, rx) = oneshot::channel();
        self.batch_queue
            .send(EmbedRequest { text: text.to_string(), priority, sender: tx })
            .map_err(|_| "Embedder is shut down".to_string())?;

        let result = tokio::time::timeout(Duration::from_secs(60), rx)
            .await
            .map_err(|_| "Embedding timed out".to_string())?
            .map_err(|_| "Batcher dropped sender".to_string())??;

        self.cache.lock().unwrap().put(text.to_string(), result.clone());
        Ok(result)
    }

    // ── Core: batch embed ──────────────────────────────────────────────────

    async fn embed_batch_with_priority(
        &self,
        texts: Vec<String>,
        priority: Priority,
    ) -> Result<Vec<Vec<f32>>, String> {
        if texts.is_empty() { return Ok(vec![]); }

        let len = texts.len();
        let mut out: Vec<Option<Vec<f32>>> = vec![None; len];
        let mut pending: Vec<usize> = Vec::with_capacity(len);

        // FIX: One cache-lock pass for all items instead of N individual lock acquisitions.
        {
            let mut cache = self.cache.lock().unwrap();
            for (i, text) in texts.iter().enumerate() {
                if let Some(v) = cache.get(text.as_str()) {
                    self.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
                    out[i] = Some(v.clone());
                } else {
                    self.metrics.cache_misses.fetch_add(1, Ordering::Relaxed);
                    pending.push(i);
                }
            }
        }

        if pending.is_empty() {
            return Ok(out.into_iter().map(|v| v.unwrap()).collect());
        }

        self.metrics.total_requests.fetch_add(pending.len() as u64, Ordering::Relaxed);

        // FIX: Bulk-enqueue all uncached items at once.  Because they're sent in rapid
        //      succession they naturally land in the same batcher window — no task spawning.
        let mut receivers = Vec::with_capacity(pending.len());
        for &i in &pending {
            let (tx, rx) = oneshot::channel();
            self.batch_queue
                .send(EmbedRequest { text: texts[i].clone(), priority, sender: tx })
                .map_err(|_| "Embedder is shut down".to_string())?;
            receivers.push(rx);
        }

        // Await results and store in output + cache with a single final lock.
        let mut cache_batch: Vec<(String, Vec<f32>)> = Vec::with_capacity(pending.len());
        for (pos, rx) in receivers.into_iter().enumerate() {
            let emb = tokio::time::timeout(Duration::from_secs(60), rx)
                .await
                .map_err(|_| "Embedding timed out".to_string())?
                .map_err(|_| "Batcher dropped sender".to_string())??;
            let idx = pending[pos];
            cache_batch.push((texts[idx].clone(), emb.clone()));
            out[idx] = Some(emb);
        }
        {
            let mut cache = self.cache.lock().unwrap();
            for (key, val) in cache_batch { cache.put(key, val); }
        }

        Ok(out.into_iter().map(|v| v.unwrap()).collect())
    }

    // ── Misc ───────────────────────────────────────────────────────────────

    pub fn clear_cache(&self)            { self.cache.lock().unwrap().clear(); }
    pub fn get_metrics(&self) -> MetricsSnapshot { self.metrics.snapshot() }

    // Shallow clone that shares all Arc internals — used when you need an owned Embedder
    // to move into an async closure.
    fn clone_for_task(&self) -> Self {
        Self {
            tokenizer:   Arc::clone(&self.tokenizer),
            backend:     Arc::clone(&self.backend),
            hidden_size: self.hidden_size,
            max_batch:   self.max_batch,
            batch_queue: self.batch_queue.clone(),
            cache:       Arc::clone(&self.cache),
            metrics:     Arc::clone(&self.metrics),
        }
    }

    // ── Batcher thread ─────────────────────────────────────────────────────

    fn spawn_batcher_thread(&self, rx: mpsc::UnboundedReceiver<EmbedRequest>) {
        let backend   = Arc::clone(&self.backend);
        let tokenizer = Arc::clone(&self.tokenizer);
        let hidden    = self.hidden_size;
        let max_batch = self.max_batch;
        let metrics   = Arc::clone(&self.metrics);

        // FIX: Dedicated single-thread async runtime on its own OS thread.
        //      — recv().await gives zero-CPU idle (no spin, no sleep).
        //      — try_recv drain adds zero latency for single requests.
        //      — tokio::time is available for timeouts without needing the main runtime.
        //      — ONNX inference offloaded to spawn_blocking so the event loop stays free.
        std::thread::Builder::new()
            .name("embedder-batcher".into())
            .spawn(move || {
                let rt = tokio::runtime::Builder::new_current_thread()
                    .enable_time()
                    .build()
                    .expect("Failed to build batcher tokio runtime");
                rt.block_on(batcher_loop(rx, backend, tokenizer, hidden, max_batch, metrics));
            })
            .expect("Failed to spawn batcher thread");
    }
}

// ── Batcher loop (module-level async fn) ──────────────────────────────────────

async fn batcher_loop(
    mut rx: mpsc::UnboundedReceiver<EmbedRequest>,
    backend:   Arc<Mutex<Backend>>,
    tokenizer: Arc<Tokenizer>,
    hidden:    usize,
    max_batch: usize,
    metrics:   Arc<EmbedderMetrics>,
) {
    let mut batch_high: Vec<String> = Vec::new();
    let mut txs_high:   Vec<oneshot::Sender<Result<Vec<f32>, String>>> = Vec::new();
    let mut batch_norm: Vec<String> = Vec::new();
    let mut txs_norm:   Vec<oneshot::Sender<Result<Vec<f32>, String>>> = Vec::new();

    loop {
        // FIX: Block-wait with zero CPU until the first item arrives.
        //      Old code: 5 ms spin + 1 ms sleep = minimum 1 ms latency per request.
        //      New code: 0 ms overhead for single requests.
        match rx.recv().await {
            Some(req) => push_req(req, &mut batch_high, &mut txs_high, &mut batch_norm, &mut txs_norm),
            None      => return, // All senders dropped — clean exit.
        }

        // FIX: Drain any items that are *already* in the channel (sent concurrently,
        //      e.g. tokio::join! in memorize()).  try_recv is non-blocking so single
        //      requests pay zero extra latency; concurrent requests get naturally batched.
        //      Old code: 5 ms collect window added 5 ms to every single-item request.
        while batch_high.len() + batch_norm.len() < max_batch {
            match rx.try_recv() {
                Ok(req) => push_req(req, &mut batch_high, &mut txs_high, &mut batch_norm, &mut txs_norm),
                Err(_)  => break,
            }
        }

        // FIX: Flush high priority first, then normal in the SAME cycle.
        //      Old bug: condition `!batch_high.is_empty()` on the normal check was
        //      evaluated *after* process_batch called batch.clear(), so it was always
        //      false — normal priority was starved for 50 ms after every high batch.
        if !batch_high.is_empty() {
            flush_batch(
                &mut batch_high, &mut txs_high,
                &backend, &tokenizer, hidden, &metrics,
            ).await;
        }
        if !batch_norm.is_empty() {
            flush_batch(
                &mut batch_norm, &mut txs_norm,
                &backend, &tokenizer, hidden, &metrics,
            ).await;
        }
    }
}

#[inline]
fn push_req(
    req: EmbedRequest,
    batch_high: &mut Vec<String>, txs_high: &mut Vec<oneshot::Sender<Result<Vec<f32>, String>>>,
    batch_norm: &mut Vec<String>, txs_norm: &mut Vec<oneshot::Sender<Result<Vec<f32>, String>>>,
) {
    if req.priority == Priority::High {
        batch_high.push(req.text); txs_high.push(req.sender);
    } else {
        batch_norm.push(req.text); txs_norm.push(req.sender);
    }
}

async fn flush_batch(
    batch:   &mut Vec<String>,
    senders: &mut Vec<oneshot::Sender<Result<Vec<f32>, String>>>,
    backend:   &Arc<Mutex<Backend>>,
    tokenizer: &Arc<Tokenizer>,
    hidden:    usize,
    metrics:   &Arc<EmbedderMetrics>,
) {
    // Take ownership without reallocating.
    let texts = std::mem::take(batch);
    let txs   = std::mem::take(senders);
    metrics.total_batches.fetch_add(1, Ordering::Relaxed);

    // FIX: Determine backend type and extract what we need while the lock is held
    //      for the *shortest possible duration* — never hold it across await points.
    enum Dispatch {
        Onnx,
        Remote(reqwest::Client, RemoteConfig),
        Error(String),
    }

    let dispatch = {
        let guard = backend.lock().unwrap();
        match &*guard {
            Backend::LocalOnnx(_)               => Dispatch::Onnx,
            Backend::RemoteHttp { client, config } => {
                // reqwest::Client is Arc-backed; clone is O(1).
                Dispatch::Remote(client.clone(), config.clone())
            }
            Backend::Uninitialized => Dispatch::Error("Backend not initialized".to_string()),
        }
    }; // Lock released here — before any await.

    let result: Result<Vec<Vec<f32>>, String> = match dispatch {
        Dispatch::Error(e) => Err(e),

        // FIX: Async HTTP — lock is free during the entire network round-trip.
        Dispatch::Remote(client, config) => {
            embed_remote_async(&client, &config, &texts).await
        }

        // FIX: ONNX inference runs in spawn_blocking so the async event loop is
        //      not stalled during potentially long CPU-bound inference.
        Dispatch::Onnx => {
            let backend_c   = Arc::clone(backend);
            let tokenizer_c = Arc::clone(tokenizer);
            tokio::task::spawn_blocking(move || {
                let mut g = backend_c.lock().unwrap();
                match &mut *g {
                    Backend::LocalOnnx(session) => embed_onnx(session, &tokenizer_c, &texts, hidden),
                    _ => Err("Backend changed during inference".to_string()),
                }
            })
            .await
            .unwrap_or_else(|e| Err(format!("ONNX thread panicked: {}", e)))
        }
    };

    match result {
        Ok(embeddings) => {
            for (tx, emb) in txs.into_iter().zip(embeddings.into_iter()) {
                let _ = tx.send(Ok(emb));
            }
        }
        Err(e) => {
            metrics.total_errors.fetch_add(1, Ordering::Relaxed);
            for tx in txs { let _ = tx.send(Err(e.clone())); }
        }
    }
}

// ── ONNX inference ─────────────────────────────────────────────────────────────

fn embed_onnx(
    session:     &mut Session,
    tokenizer:   &Tokenizer,
    texts:       &[String],
    hidden_size: usize,
) -> Result<Vec<Vec<f32>>, String> {
    let encodings = tokenizer
        .encode_batch(texts.to_vec(), true)
        .map_err(|e| e.to_string())?;

    let batch   = encodings.len();
    let seq_len = encodings.iter().map(|e| e.len()).max().unwrap_or(1);

    let mut input_ids = Array2::<i64>::zeros((batch, seq_len));
    let mut attention  = Array2::<i64>::zeros((batch, seq_len));

    for (i, enc) in encodings.iter().enumerate() {
        for j in 0..enc.len() {
            input_ids[[i, j]] = enc.get_ids()[j] as i64;
            attention[[i, j]]  = enc.get_attention_mask()[j] as i64;
        }
    }

    let inputs = vec![
        ("input_ids",      Value::from_array(input_ids).unwrap()),
        ("attention_mask", Value::from_array(attention.clone()).unwrap()),
    ];
    let outputs = session.run(inputs).map_err(|e| e.to_string())?;

    let (_, tensor) = outputs[0]
        .try_extract_tensor::<f32>()
        .map_err(|e| e.to_string())?;

    let hidden: Array3<f32> = Array3::from_shape_vec(
        (batch, seq_len, hidden_size),
        tensor.iter().copied().collect(),
    )
    .unwrap();

    let mut out = Vec::with_capacity(batch);
    for i in 0..batch {
        let h = hidden.index_axis(Axis(0), i).to_owned();
        let m = attention.index_axis(Axis(0), i).to_owned();
        out.push(mean_pool_normalize(&h, &m));
    }
    Ok(out)
}

/// Mean-pool over non-padding tokens then L2-normalize the result.
/// The thread-local scratch buffer avoids a heap allocation on every call.
fn mean_pool_normalize(hidden: &Array2<f32>, mask: &Array1<i64>) -> Vec<f32> {
    let hidden_size = hidden.len_of(Axis(1));
    SCRATCH.with(|scratch| {
        let mut buf = scratch.borrow_mut();
        buf.clear();
        buf.resize(hidden_size, 0.0);

        let mut count = 0.0_f32;
        for (token, &m) in hidden.outer_iter().zip(mask.iter()) {
            if m == 0 { continue; }
            count += 1.0;
            // Inner loop auto-vectorizes with AVX2/NEON at -O3.
            let slice = token.as_slice().expect("non-contiguous token row");
            for (acc, &val) in buf.iter_mut().zip(slice.iter()) {
                *acc += val;
            }
        }

        let inv = 1.0 / count.max(1.0);
        let mut norm_sq = 0.0_f32;
        for v in buf.iter_mut() {
            *v *= inv;
            norm_sq += *v * *v;
        }
        let inv_norm = 1.0 / norm_sq.sqrt().max(1e-12);
        for v in buf.iter_mut() { *v *= inv_norm; }

        // FIX: Return an owned copy without a redundant intermediate clone.
        buf.to_vec()
    })
}

// ── Async remote HTTP ──────────────────────────────────────────────────────────

async fn embed_remote_async(
    client: &reqwest::Client,
    config: &RemoteConfig,
    texts:  &[String],
) -> Result<Vec<Vec<f32>>, String> {
    let cleaned: Vec<String> = texts.iter().map(|t| t.replace('\n', " ")).collect();
    let url = config.base_url.trim_end_matches('/');

    let (endpoint, payload) = build_request_payload(config, url, &cleaned);

    let mut req = client
        .post(&endpoint)
        .header("Content-Type", "application/json")
        .json(&payload);

    // Auth header — applied without holding any lock.
    if !config.api_key.is_empty() {
        req = match config.provider {
            Provider::AzureOpenAI => req.header("api-key", &config.api_key),
            Provider::Gemini      => req.query(&[("key", config.api_key.as_str())]),
            _                     => req.header("Authorization", format!("Bearer {}", config.api_key)),
        };
    }

    let resp = req.send().await.map_err(|e| format!("HTTP request failed: {}", e))?;

    if !resp.status().is_success() {
        let status = resp.status();
        let body   = resp.text().await.unwrap_or_default();
        return Err(format!("API Error {}: {}", status, body));
    }

    let body: serde_json::Value = resp.json().await.map_err(|e| format!("JSON parse error: {}", e))?;
    parse_embedding_response(config, body)
}

fn build_request_payload(
    config: &RemoteConfig,
    url:    &str,
    texts:  &[String],
) -> (String, serde_json::Value) {
    if config.provider.is_openai_compatible() {
        (
            format!("{}/embeddings", url),
            json!({ "input": texts, "model": config.model_name }),
        )
    } else {
        match config.provider {
            Provider::AzureOpenAI => (
                format!("{}/embeddings", url),
                json!({ "input": texts }),
            ),
            Provider::Gemini => (
                format!("{}/models/{}:batchEmbedContents", url, config.model_name),
                json!({
                    "requests": texts.iter()
                        .map(|t| json!({ "content": { "parts": [{ "text": t }] } }))
                        .collect::<Vec<_>>()
                }),
            ),
            Provider::Cohere => (
                format!("{}/embed", url),
                json!({ "texts": texts, "model": config.model_name, "input_type": "search_query" }),
            ),
            Provider::HuggingFace => (
                format!("{}/models/{}/feature-extraction", url, config.model_name),
                json!({ "inputs": texts, "options": { "wait_for_model": true } }),
            ),
            _ => unreachable!("OpenAI-compatible providers handled above"),
        }
    }
}

fn parse_embedding_response(
    config: &RemoteConfig,
    body:   serde_json::Value,
) -> Result<Vec<Vec<f32>>, String> {
    if config.provider.is_openai_compatible() || config.provider == Provider::AzureOpenAI {
        let data = body.get("data").and_then(|v| v.as_array())
            .ok_or("Invalid OpenAI response: missing 'data'")?;
        data.iter()
            .map(|item| {
                let vec = item.get("embedding").and_then(|v| v.as_array())
                    .ok_or("Missing 'embedding' in response item")?;
                Ok(vec.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
            })
            .collect()
    } else {
        match config.provider {
            Provider::Gemini => {
                if let Some(items) = body.get("embeddings").and_then(|v| v.as_array()) {
                    return items.iter()
                        .map(|item| {
                            let vals = item.get("values").and_then(|v| v.as_array())
                                .ok_or("Invalid Gemini response: missing values")?;
                            Ok(vals.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
                        })
                        .collect();
                }
                // Fallback for single-embedding shape.
                if let Some(vals) = body.get("embedding").and_then(|v| v.get("values")).and_then(|v| v.as_array()) {
                    return Ok(vec![vals.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect()]);
                }
                Err("Invalid Gemini response: missing embeddings".to_string())
            }
            Provider::Cohere => {
                let embeddings = body.get("embeddings").and_then(|v| v.as_array())
                    .ok_or("Invalid Cohere response: missing 'embeddings'")?;
                embeddings.iter()
                    .map(|vec| {
                        Ok(vec.as_array().ok_or("Cohere embedding not an array")?
                            .iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
                    })
                    .collect()
            }
            Provider::HuggingFace => {
                let arr = body.as_array().ok_or("Invalid HF response: expected top-level array")?;
                arr.iter()
                    .map(|vec| {
                        Ok(vec.as_array().ok_or("HF embedding not an array")?
                            .iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
                    })
                    .collect()
            }
            _ => unreachable!("OpenAI-compatible providers handled above"),
        }
    }
}