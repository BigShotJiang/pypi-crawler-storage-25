#![allow(non_local_definitions)]
#![allow(unsafe_op_in_unsafe_fn)]

use pyo3::prelude::*;
use pyo3_asyncio::tokio::future_into_py;
use qdrant_client::{
    Qdrant,
    qdrant::{
        vectors_config::Config, CreateCollection, Distance, HnswConfigDiff, OptimizersConfigDiff,
        QuantizationConfig, QuantizationType, ScalarQuantization, ProductQuantization,
        VectorParams, VectorsConfig, FieldType, SparseVectorParams, SparseIndexConfig,
        Modifier, MaxOptimizationThreads
    },
};
use std::collections::HashMap;
use std::sync::Arc;

#[derive(Clone)]
pub enum QuantizationMode {
    None,
    Bit4,
    Bit8,
}

impl QuantizationMode {
    pub fn from_option(bits: Option<u8>) -> PyResult<Self> {
        match bits {
            Some(4) => Ok(QuantizationMode::Bit4),
            Some(8) => Ok(QuantizationMode::Bit8),
            Some(b) => Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                format!("Invalid quantization bits: {}. Must be 4 or 8, or None", b)
            )),
            None => Ok(QuantizationMode::None),
        }
    }

    pub fn to_qdrant_config(&self) -> Option<QuantizationConfig> {
        match self {
            QuantizationMode::None => None,
            QuantizationMode::Bit4 => Some(QuantizationConfig {
                quantization: Some(qdrant_client::qdrant::quantization_config::Quantization::Product(
                    ProductQuantization {
                        compression: qdrant_client::qdrant::CompressionRatio::X4 as i32,
                        always_ram: Some(true),
                    },
                )),
            }),
            QuantizationMode::Bit8 => Some(QuantizationConfig {
                quantization: Some(qdrant_client::qdrant::quantization_config::Quantization::Scalar(
                    ScalarQuantization {
                        r#type: QuantizationType::Int8 as i32,
                        quantile: Some(0.99),
                        always_ram: Some(true),
                    },
                )),
            }),
        }
    }
}

#[pyclass]
pub struct QdrantManager {
    pub(crate) client: Arc<qdrant_client::Qdrant>,
    use_indexing: bool,
    quantization_mode: QuantizationMode,
    on_disk: bool,
    vector_size: u64,
    distance_metric: Distance,
    collection_prefix: String,
    replication_factor: u32,
    shard_number: u32,
    indexing_threshold: u64,
    flush_interval_sec: u64,
    max_optimization_threads: usize,
    use_sparse_vectors: bool,
}

#[allow(non_local_definitions)]
#[pymethods]
impl QdrantManager {
    #[new]
    #[pyo3(signature = (
        url,
        vector_size,
        use_indexing=true,
        quantization=Some(8),
        on_disk=false,
        api_key=None,
        distance_metric="cosine",
        collection_prefix="".to_string(),
        replication_factor=1,
        shard_number=1,
        indexing_threshold=2000,
        flush_interval_sec=15,
        max_optimization_threads=1,
        use_sparse_vectors=true
    ))]
    pub fn new(
        url: String,
        vector_size: u64,
        use_indexing: bool,
        quantization: Option<u8>,
        on_disk: bool,
        api_key: Option<String>,
        distance_metric: &str,
        collection_prefix: String,
        replication_factor: u32,
        shard_number: u32,
        indexing_threshold: u64,
        flush_interval_sec: u64,
        max_optimization_threads: usize,
        use_sparse_vectors: bool,
    ) -> PyResult<Self> {
        if vector_size == 0 || vector_size > 65536 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "vector_size must be between 1 and 65536"
            ));
        }

        if replication_factor == 0 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "replication_factor must be at least 1"
            ));
        }

        if shard_number == 0 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "shard_number must be at least 1"
            ));
        }

        let distance = match distance_metric.to_lowercase().as_str() {
            "cosine" => Distance::Cosine,
            "euclidean" => Distance::Euclid,
            "dot" | "dotproduct" => Distance::Dot,
            _ => return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                format!("Invalid distance metric: {}. Must be 'cosine', 'euclidean', or 'dot'", distance_metric)
            )),
        };

        let mut client_builder = Qdrant::from_url(&url);
        
        if let Some(key) = api_key {
            client_builder = client_builder.api_key(key);
        }
        
        let client = client_builder.build().map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyConnectionError, _>(format!(
                "Failed to create Qdrant client: {}",
                e
            ))
        })?;

        Ok(QdrantManager {
            client: Arc::new(client),
            use_indexing,
            quantization_mode: QuantizationMode::from_option(quantization)?,
            on_disk,
            vector_size,
            distance_metric: distance,
            collection_prefix,
            replication_factor,
            shard_number,
            indexing_threshold,
            flush_interval_sec,
            max_optimization_threads,
            use_sparse_vectors,
        })
    }

    pub fn ensure_conversation_summaries_collection<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let client = Arc::clone(&self.client);
        let collection_name = if self.collection_prefix.is_empty() {
            "conversation_summaries".to_string()
        } else {
            format!("{}_conversation_summaries", self.collection_prefix)
        };
        let vector_size = self.vector_size;
        let distance_metric = self.distance_metric;
        let use_indexing = self.use_indexing;
        let quantization_mode = self.quantization_mode.clone();
        let on_disk = self.on_disk;
        let replication_factor = self.replication_factor;
        let shard_number = self.shard_number;
        let indexing_threshold = self.indexing_threshold;
        let flush_interval_sec = self.flush_interval_sec;
        let max_optimization_threads = self.max_optimization_threads;
        let use_sparse_vectors = self.use_sparse_vectors;

        future_into_py(py, async move {
            let exists = client
                .collection_exists(&collection_name)
                .await
                .map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                        "Failed to check collection existence: {}",
                        e
                    ))
                })?;

            if exists {
                let info = client.collection_info(&collection_name).await.map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                        "Failed to get collection info: {}",
                        e
                    ))
                })?;

                if let Some(config) = &info.result {
                    if let Some(collection_config) = &config.config {
                        if let Some(vectors_config) = &collection_config.params {
                            if let Some(vectors_config_inner) = &vectors_config.vectors_config {
                                if let Some(Config::ParamsMap(params_map)) = &vectors_config_inner.config {
                                    if let Some(long_vec) = params_map.map.get("long_summary") {
                                        if long_vec.size != vector_size {
                                            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                                                format!(
                                                    "Collection exists but has wrong vector size. Expected {}, found {}",
                                                    vector_size, long_vec.size
                                                )
                                            ));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return Ok(());
            }

            let mut vectors_map = HashMap::new();

            let long_summary_config = VectorParams {
                size: vector_size,
                distance: distance_metric.into(),
                hnsw_config: if use_indexing {
                    Some(HnswConfigDiff {
                        m: Some(16),
                        ef_construct: Some(100),
                        full_scan_threshold: Some(indexing_threshold),
                        max_indexing_threads: Some(0),
                        on_disk: Some(on_disk),
                        payload_m: None,
                        inline_storage: None,
                    })
                } else {
                    None
                },
                quantization_config: quantization_mode.to_qdrant_config(),
                on_disk: Some(on_disk),
                datatype: None,
                multivector_config: None,
            };

            let short_summary_config = VectorParams {
                size: vector_size,
                distance: distance_metric.into(),
                hnsw_config: if use_indexing {
                    Some(HnswConfigDiff {
                        m: Some(16),
                        ef_construct: Some(100),
                        full_scan_threshold: Some(indexing_threshold),
                        max_indexing_threads: Some(0),
                        on_disk: Some(on_disk),
                        payload_m: None,
                        inline_storage: None,
                    })
                } else {
                    None
                },
                quantization_config: quantization_mode.to_qdrant_config(),
                on_disk: Some(on_disk),
                datatype: None,
                multivector_config: None,
            };

            vectors_map.insert("long_summary".to_string(), long_summary_config);
            vectors_map.insert("short_summary".to_string(), short_summary_config);

            let mut sparse_vectors_config = HashMap::new();
            if use_sparse_vectors {
                let bm25_config = SparseVectorParams {
                    index: Some(SparseIndexConfig {
                        full_scan_threshold: Some(indexing_threshold),
                        on_disk: Some(on_disk),
                        datatype: None,
                    }),
                    modifier: Some(Modifier::Idf as i32),
                };

                sparse_vectors_config.insert("bm25".to_string(), bm25_config);
            }

            let sparse_vectors_config_option = if use_sparse_vectors {
                Some(qdrant_client::qdrant::SparseVectorConfig {
                    map: sparse_vectors_config,
                })
            } else {
                None
            };

            client
                .create_collection(CreateCollection {
                    collection_name: collection_name.clone(),
                    vectors_config: Some(VectorsConfig {
                        config: Some(Config::ParamsMap(
                            qdrant_client::qdrant::VectorParamsMap {
                                map: vectors_map,
                            },
                        )),
                    }),
                    sparse_vectors_config: sparse_vectors_config_option,
                    shard_number: Some(shard_number),
                    replication_factor: Some(replication_factor),
                    write_consistency_factor: Some(1),
                    on_disk_payload: Some(on_disk),
                    optimizers_config: Some(OptimizersConfigDiff {
                        deleted_threshold: Some(0.2),
                        vacuum_min_vector_number: Some(500),
                        default_segment_number: Some(0),
                        max_segment_size: None,
                        memmap_threshold: None,
                        indexing_threshold: Some(indexing_threshold),
                        flush_interval_sec: Some(flush_interval_sec),
                        max_optimization_threads: Some(MaxOptimizationThreads {
                            variant: Some(qdrant_client::qdrant::max_optimization_threads::Variant::Value(
                                max_optimization_threads as u64,
                            )),
                        }),
                        deprecated_max_optimization_threads: None,
                    }),
                    ..Default::default()
                })
                .await
                .map_err(|e| {
                    PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                        "Failed to create collection: {}",
                        e
                    ))
                })?;

            let payload_indexes = vec![
                ("user_id", FieldType::Keyword),
                ("agent_id", FieldType::Keyword),
                ("conversation_id", FieldType::Keyword),
                ("timestamp_begin", FieldType::Integer),
                ("timestamp_end", FieldType::Integer),
                ("flows_activated", FieldType::Keyword),
                ("tools_invoked", FieldType::Keyword),
            ];

            for (field_name, field_type) in payload_indexes {
                client
                    .create_field_index(
                        qdrant_client::qdrant::CreateFieldIndexCollection {
                            collection_name: collection_name.clone(),
                            field_name: field_name.to_string(),
                            field_type: Some(field_type as i32),
                            field_index_params: None,
                            ordering: None,
                            wait: None,
                        }
                    )
                    .await
                    .map_err(|e| {
                        PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                            "Failed to create payload index for {}: {}",
                            field_name, e
                        ))
                    })?;
            }

            Ok(())
        })
    }

    /// Ensure the `flows` collection exists in Qdrant.
    ///
    /// Single dense vector `"flow"` + sparse `"bm25"`.
    /// Payload indexes: flow_id, agent_id, flow_name, flow_type.

    /// Ensure the `semantic_memory` collection exists in Qdrant.
    ///
    /// Sparse BM25 vectors only — no dense embedding needed for keyword lookup.
    /// Payload indexes: agent_id, key, category.
    pub fn ensure_semantic_collection<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let client = Arc::clone(&self.client);
        let collection_name = if self.collection_prefix.is_empty() {
            "semantic_memory".to_string()
        } else {
            format!("{}_semantic_memory", self.collection_prefix)
        };
        let _use_indexing         = self.use_indexing;
        let on_disk               = self.on_disk;
        let replication_factor    = self.replication_factor;
        let shard_number          = self.shard_number;
        let indexing_threshold    = self.indexing_threshold;
        let flush_interval_sec    = self.flush_interval_sec;
        let max_optimization_threads = self.max_optimization_threads;

        future_into_py(py, async move {
            // ── already exists? ──────────────────────────────────────────────
            let exists = client.collection_exists(&collection_name).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Failed to check collection existence: {}", e)
                ))?;

            if exists {
                return Ok(());
            }

            // ── create sparse-only collection ─────────────────────────────────
            // vectors_config: empty map — no dense vectors at all.
            // sparse_vectors_config: "bm25" with IDF modifier (same as flows collection).
            let bm25_params = SparseVectorParams {
                index: Some(SparseIndexConfig {
                    full_scan_threshold: Some(indexing_threshold),
                    on_disk: Some(on_disk),
                    datatype: None,
                }),
                modifier: Some(Modifier::Idf as i32),
            };
            let mut sparse_map = HashMap::new();
            sparse_map.insert("bm25".to_string(), bm25_params);

            client.create_collection(CreateCollection {
                collection_name: collection_name.clone(),
                // Empty dense vectors config — sparse-only collection.
                vectors_config: Some(VectorsConfig {
                    config: Some(Config::ParamsMap(
                        qdrant_client::qdrant::VectorParamsMap { map: HashMap::new() }
                    )),
                }),
                sparse_vectors_config: Some(qdrant_client::qdrant::SparseVectorConfig {
                    map: sparse_map,
                }),
                shard_number:             Some(shard_number),
                replication_factor:       Some(replication_factor),
                write_consistency_factor: Some(1),
                on_disk_payload:          Some(on_disk),
                optimizers_config: Some(OptimizersConfigDiff {
                    deleted_threshold:        Some(0.2),
                    vacuum_min_vector_number: Some(500),
                    default_segment_number:   Some(0),
                    max_segment_size:         None,
                    memmap_threshold:         None,
                    indexing_threshold:       Some(indexing_threshold),
                    flush_interval_sec:       Some(flush_interval_sec),
                    max_optimization_threads: Some(MaxOptimizationThreads {
                        variant: Some(
                            qdrant_client::qdrant::max_optimization_threads::Variant::Value(
                                max_optimization_threads as u64,
                            )
                        ),
                    }),
                    deprecated_max_optimization_threads: None,
                }),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Failed to create semantic_memory collection: {}", e)
            ))?;

            // ── payload indexes ───────────────────────────────────────────────
            for (field, ftype) in &[
                ("agent_id", FieldType::Keyword),
                ("key",      FieldType::Keyword),
                ("category", FieldType::Keyword),
            ] {
                client.create_field_index(
                    qdrant_client::qdrant::CreateFieldIndexCollection {
                        collection_name:    collection_name.clone(),
                        field_name:         field.to_string(),
                        field_type:         Some(*ftype as i32),
                        field_index_params: None,
                        ordering:           None,
                        wait:               None,
                    }
                )
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Failed to create payload index for {}: {}", field, e)
                ))?;
            }

            Ok(())
        })
    }

    pub fn ensure_flows_collection<'py>(&self, py: Python<'py>) -> PyResult<&'py PyAny> {
        let client = Arc::clone(&self.client);
        let collection_name = if self.collection_prefix.is_empty() {
            "flows".to_string()
        } else {
            format!("{}_flows", self.collection_prefix)
        };
        let vector_size            = self.vector_size;
        let distance_metric        = self.distance_metric;
        let use_indexing           = self.use_indexing;
        let quantization_mode      = self.quantization_mode.clone();
        let on_disk                = self.on_disk;
        let replication_factor     = self.replication_factor;
        let shard_number           = self.shard_number;
        let indexing_threshold     = self.indexing_threshold;
        let flush_interval_sec     = self.flush_interval_sec;
        let max_optimization_threads = self.max_optimization_threads;
        let use_sparse_vectors     = self.use_sparse_vectors;

        future_into_py(py, async move {
            // ── already exists? ──────────────────────────────────────────────
            let exists = client.collection_exists(&collection_name).await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Failed to check collection existence: {}", e)
                ))?;

            if exists {
                // Validate vector size matches what we expect
                let info = client.collection_info(&collection_name).await
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                        format!("Failed to get collection info: {}", e)
                    ))?;
                if let Some(cfg) = &info.result {
                    if let Some(cc) = &cfg.config {
                        if let Some(vp) = &cc.params {
                            if let Some(vc) = &vp.vectors_config {
                                if let Some(Config::ParamsMap(pm)) = &vc.config {
                                    if let Some(fv) = pm.map.get("flow") {
                                        if fv.size != vector_size {
                                            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                                                format!(
                                                    "Flows collection exists with wrong vector size. Expected {}, found {}",
                                                    vector_size, fv.size
                                                )
                                            ));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                return Ok(());
            }

            // ── create ───────────────────────────────────────────────────────
            let hnsw = if use_indexing {
                Some(HnswConfigDiff {
                    m: Some(16),
                    ef_construct: Some(100),
                    full_scan_threshold: Some(indexing_threshold),
                    max_indexing_threads: Some(0),
                    on_disk: Some(on_disk),
                    payload_m: None,
                    inline_storage: None,
                })
            } else {
                None
            };

            let flow_vec = VectorParams {
                size:                 vector_size,
                distance:             distance_metric.into(),
                hnsw_config:          hnsw,
                quantization_config:  quantization_mode.to_qdrant_config(),
                on_disk:              Some(on_disk),
                datatype:             None,
                multivector_config:   None,
            };

            let mut vectors_map = HashMap::new();
            vectors_map.insert("flow".to_string(), flow_vec);

            let sparse_config = if use_sparse_vectors {
                let bm25 = SparseVectorParams {
                    index: Some(SparseIndexConfig {
                        full_scan_threshold: Some(indexing_threshold),
                        on_disk: Some(on_disk),
                        datatype: None,
                    }),
                    modifier: Some(Modifier::Idf as i32),
                };
                let mut m = HashMap::new();
                m.insert("bm25".to_string(), bm25);
                Some(qdrant_client::qdrant::SparseVectorConfig { map: m })
            } else {
                None
            };

            client.create_collection(CreateCollection {
                collection_name: collection_name.clone(),
                vectors_config: Some(VectorsConfig {
                    config: Some(Config::ParamsMap(
                        qdrant_client::qdrant::VectorParamsMap { map: vectors_map },
                    )),
                }),
                sparse_vectors_config: sparse_config,
                shard_number:            Some(shard_number),
                replication_factor:      Some(replication_factor),
                write_consistency_factor: Some(1),
                on_disk_payload:         Some(on_disk),
                optimizers_config: Some(OptimizersConfigDiff {
                    deleted_threshold:       Some(0.2),
                    vacuum_min_vector_number: Some(500),
                    default_segment_number:  Some(0),
                    max_segment_size:        None,
                    memmap_threshold:        None,
                    indexing_threshold:      Some(indexing_threshold),
                    flush_interval_sec:      Some(flush_interval_sec),
                    max_optimization_threads: Some(MaxOptimizationThreads {
                        variant: Some(
                            qdrant_client::qdrant::max_optimization_threads::Variant::Value(
                                max_optimization_threads as u64,
                            )
                        ),
                    }),
                    deprecated_max_optimization_threads: None,
                }),
                ..Default::default()
            })
            .await
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                format!("Failed to create flows collection: {}", e)
            ))?;

            // ── payload indexes ───────────────────────────────────────────────
            let indexes = vec![
                ("flow_id",        FieldType::Keyword),
                ("agent_id",       FieldType::Keyword),
                ("flow_name",      FieldType::Keyword),
                ("flow_type",      FieldType::Keyword),
            ];
            for (field, ftype) in indexes {
                client.create_field_index(
                    qdrant_client::qdrant::CreateFieldIndexCollection {
                        collection_name:    collection_name.clone(),
                        field_name:         field.to_string(),
                        field_type:         Some(ftype as i32),
                        field_index_params: None,
                        ordering:           None,
                        wait:               None,
                    }
                )
                .await
                .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(
                    format!("Failed to create payload index for {}: {}", field, e)
                ))?;
            }

            Ok(())
        })
    }
}

impl QdrantManager {
    pub(crate) fn client(&self) -> Arc<Qdrant> {
        Arc::clone(&self.client)
    }

    pub(crate) fn conversation_summaries_collection_name(&self) -> String {
        if self.collection_prefix.is_empty() {
            "conversation_summaries".to_string()
        } else {
            format!("{}_conversation_summaries", self.collection_prefix)
        }
    }


    pub(crate) fn semantic_collection_name(&self) -> String {
        if self.collection_prefix.is_empty() {
            "semantic_memory".to_string()
        } else {
            format!("{}_semantic_memory", self.collection_prefix)
        }
    }

    pub(crate) fn flows_collection_name(&self) -> String {
        if self.collection_prefix.is_empty() {
            "flows".to_string()
        } else {
            format!("{}_flows", self.collection_prefix)
        }
    }
}