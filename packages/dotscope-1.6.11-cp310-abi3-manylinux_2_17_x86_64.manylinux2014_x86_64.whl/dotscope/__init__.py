"""dotscope — Directory-scoped context boundaries for AI coding agents."""

__version__ = "1.6.11"
