"""Tier-based model routing for Claw-ED.

Tasks map to tiers (fast/work/deep). Each tier has a default model.
Teachers configure which model serves each tier via AppConfig.tier_models.

Resolution order for a given task:
  1. config.task_models[task]    -- per-task override (legacy, highest priority)
  2. config.tier_models[tier]    -- teacher's tier preference
  3. DEFAULT_TIER_MODELS[tier]   -- built-in defaults
"""
from __future__ import annotations

from enum import Enum

from clawed.models import AppConfig


class ModelTier(str, Enum):
    """The three model tiers. Fast is cheap, deep is powerful."""

    FAST = "fast"
    WORK = "work"
    DEEP = "deep"


TASK_TIERS: dict[str, ModelTier] = {
    # Fast tier
    "intent_detection": ModelTier.FAST,
    "quick_answer": ModelTier.FAST,
    "search": ModelTier.FAST,
    "bellringer": ModelTier.FAST,
    "formatting": ModelTier.FAST,

    # Work tier
    "lesson_plan": ModelTier.WORK,
    "unit_plan": ModelTier.WORK,
    "materials": ModelTier.WORK,
    "differentiation": ModelTier.WORK,
    "iep_modification": ModelTier.WORK,
    "assessment": ModelTier.WORK,
    "year_map": ModelTier.WORK,
    "pacing_guide": ModelTier.WORK,
    "curriculum_gaps": ModelTier.WORK,

    # Deep tier
    "persona_extract": ModelTier.DEEP,
    "evaluation": ModelTier.DEEP,
    "master_content": ModelTier.DEEP,
}

DEFAULT_TIER_MODELS: dict[str, str] = {
    "fast": "qwen3.5:cloud",
    "work": "minimax-m2.7:cloud",
    "deep": "minimax-m2.7:cloud",
}

# Per-provider tier defaults (used when the teacher selects a provider).
PROVIDER_TIER_MODELS: dict[str, dict[str, str]] = {
    "ollama": DEFAULT_TIER_MODELS,
    "anthropic": {
        "fast": "claude-haiku-4-5-20251001",
        "work": "claude-sonnet-4-6-20250514",
        "deep": "claude-opus-4-6-20250514",
    },
    "openai": {
        "fast": "gpt-4o-mini",
        "work": "gpt-4o",
        "deep": "gpt-4o",
    },
    "google": {
        "fast": "gemini-2.5-flash",
        "work": "gemini-2.5-flash",
        "deep": "gemini-2.5-pro",
    },
}


def resolve_tier(task_type: str) -> ModelTier:
    """Get the tier for a task. Unknown tasks default to WORK."""
    return TASK_TIERS.get(task_type, ModelTier.WORK)


def resolve_model(tier: ModelTier, config: AppConfig) -> str:
    """Get the model for a tier, respecting teacher overrides."""
    teacher_tiers = config.tier_models or {}
    return teacher_tiers.get(tier.value) or DEFAULT_TIER_MODELS[tier.value]


def route(task_type: str, config: AppConfig) -> AppConfig:
    """Return a config copy with the optimal model for this task type.

    Resolution order:
      1. config.task_models[task]    -- per-task override (legacy compat)
      2. config.tier_models[tier]    -- teacher's tier preference
      3. DEFAULT_TIER_MODELS[tier]   -- built-in defaults
    """
    user_task_overrides = config.task_models or {}
    if task_type in user_task_overrides:
        model = user_task_overrides[task_type]
    else:
        tier = resolve_tier(task_type)
        model = resolve_model(tier, config)

    routed = config.model_copy()
    routed.ollama_model = model
    return routed
