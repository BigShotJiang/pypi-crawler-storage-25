"""
Parameter factories with pre-defined probability distributions.
"""

from typing import Sequence

import jax.numpy as jnp
import distreqx.distributions as dist

from parax.core.parameter import Parameter

def Uniform(low: float | Sequence[float], high: float | Sequence[float], value=None, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` with a uniform distribution.

    Parameters
    ----------
    low : float | Sequence[float]
        The lower value of the distribution. Can be a sequence for a multi-valued Parameter.
    high : float | Sequence[float]
        The upper value of the distribution. Can be a sequence for a multi-valued Parameter.
    value : optional
        The initial value. If None, the midpoint of the distribution is used. Defaults to None.
    **kwargs
        Additional keyword arguments passed to the `Parameter` constructor.

    Returns
    -------
    Parameter
        The created Parameter object.
    """
    low, high = jnp.array(low), jnp.array(high)
    dists = dist.Uniform(low, high)
    values = (low + high) / 2.0 if value is None else value
    return Parameter(value=values, distribution=dists, **kwargs)

def RelativeUniform(mean: float | Sequence[float], deviation_fraction: float | Sequence[float], *args, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` with a uniform distribution defined by a fractional deviation.

    The bounds are calculated as: `mean * (1 +/- deviation_fraction)`

    Parameters
    ----------
    mean : float | Sequence[float]
        The center (mean) of the distribution.
    deviation_fraction : float | Sequence[float]
        The relative radius of the distribution bounds as a fraction of the mean.
        e.g., 0.1 results in bounds of [0.9 * mean, 1.1 * mean].
    **kwargs
        Additional keyword arguments passed to [`parax.Uniform`][].

    Returns
    -------
    Parameter
    """
    mean_arr = jnp.array(mean)
    frac_arr = jnp.array(deviation_fraction)
    
    # Calculate the absolute deviation (radius)
    delta = jnp.abs(mean_arr * frac_arr)
    
    return Uniform(mean_arr - delta, mean_arr + delta, *args, **kwargs)

def CenteredUniform(mean: float | Sequence[float], half_width: float | Sequence[float], *args, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` with a uniform distribution.

    Parameters
    ----------
    mean : float | Sequence[float]
        The mean value of the distribution. Can be a sequence for a multi-valued Parameter.
    half_width : float | Sequence[float]
        The half-width value of the distribution. Can be a sequence for a multi-valued Parameter.
    **kwargs
        Additional keyword arguments passed to [`parax.Uniform`][].

    Returns
    -------
    Parameter
        The created Parameter object.
    """
    low = mean - half_width
    high = mean + half_width
    
    return Uniform(low, high, *args, **kwargs)

def Normal(mean: float | Sequence[float], std: float | Sequence[float], value=None, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` with a normal (Gaussian) distribution.

    Parameters
    ----------
    mean : float | Sequence[float]
        The mean of the distribution. Can be a sequence for a multi-valued Parameter.
    std : float | Sequence[float]
        The standard deviation of the distribution. Can be a sequence for a multi-valued Parameter.
    value : optional
        The initial value. If None, the mean of the distribution is used. Defaults to None.
    **kwargs
        Additional keyword arguments forward to the `Parameter` constructor.

    Returns
    -------
    Parameter
        The created Parameter object.
    """
    mean, std = jnp.array(mean), jnp.array(std)
    dists = dist.Normal(mean, std)
    values = mean if value is None else value
    return Parameter(value=values, distribution=dists, **kwargs)

def RelativeNormal(mean: float | Sequence[float], std_fraction: float | Sequence[float], **kwargs) -> Parameter:
    r"""
    Create a `Parameter` with a normal distribution defined by a relative standard deviation.

    The scale (sigma) is calculated as: `mean * std_fraction`

    Parameters
    ----------
    mean : float | Sequence[float]
        The center (mean) of the distribution.
    std_fraction : float | Sequence[float]
        The standard deviation expressed as a fraction of the mean 
        (also known as the coefficient of variation).
        e.g., 0.1 results in a distribution with sigma = 0.1 * mean.
    **kwargs
        Additional keyword arguments passed to [`parax.Normal`][].

    Returns
    -------
    Parameter
    """
    mean_arr = jnp.array(mean)
    frac_arr = jnp.array(std_fraction)
    
    # Calculate absolute standard deviation
    sigma = jnp.abs(mean_arr * frac_arr)
    
    return Normal(mean=mean_arr, std=sigma, **kwargs)

def Fixed(value, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` that is marked as fixed.
    
    This sets the `fixed` flag of the parameter to `True`.

    Parameters
    ----------
    value
        The value of the parameter.
    **kwargs
        Additional keyword arguments passed to the `Parameter` constructor.

    Returns
    -------
    Parameter
        The created fixed Parameter object.
    """
    value = jnp.array(value)
    return Parameter(value=value, fixed=True, **kwargs)

def Free(value, **kwargs) -> Parameter:
    r"""
    Create a `Parameter` that is marked as free (i.e., free to vary).
    
    This sets the `fixed` flag of the parameter to `False`.

    Parameters
    ----------
    value
        The value of the parameter.
    n : int, optional
        The number of identical parameters to create in an array. Defaults to None.
    **kwargs
        Additional keyword arguments passed to the `Parameter` constructor.

    Returns
    -------
    Parameter
        The created free Parameter object.
    """
    value = jnp.array(value)
    return Parameter(value=value, fixed=False, **kwargs)