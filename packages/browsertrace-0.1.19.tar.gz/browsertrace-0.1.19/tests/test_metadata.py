"""Package metadata consistency tests."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tomllib
import xml.etree.ElementTree as ET
from fractions import Fraction
from pathlib import Path

import pytest

import browsertrace


def test_package_version_matches_module_version():
    project_root = Path(__file__).resolve().parents[1]
    pyproject = tomllib.loads((project_root / "pyproject.toml").read_text())

    assert pyproject["project"]["version"] == "0.1.19"
    assert pyproject["project"]["version"] == browsertrace.__version__


def test_public_docs_do_not_reference_stale_v011_release():
    project_root = Path(__file__).resolve().parents[1]
    public_docs = [
        project_root / "llms.txt",
        project_root / "README.md",
        project_root / "LAUNCH.md",
        *sorted((project_root / "docs").rglob("*.md")),
        *sorted((project_root / "docs").rglob("*.html")),
        project_root / "docs" / "llms.txt",
    ]

    stale_release = re.compile(r"v0\.1\.1(?!\d)")
    stale_mentions = [
        str(path.relative_to(project_root))
        for path in public_docs
        if stale_release.search(path.read_text())
    ]

    assert stale_mentions == []


def test_pyproject_has_launch_discovery_metadata():
    project_root = Path(__file__).resolve().parents[1]
    pyproject = tomllib.loads((project_root / "pyproject.toml").read_text())
    project = pyproject["project"]

    assert (
        project["description"]
        == "Replay failed Browser Use runs locally with screenshots, model I/O, failed-step timelines, and public-safe exports."
    )
    assert "Browser Use" in project["description"]
    assert "AI browser agent" not in project["description"]

    keywords = set(project["keywords"])
    assert {
        "ai-agent-debugging",
        "browser-agent",
        "browser-agents",
        "computer-use",
        "llm-observability",
    } <= keywords

    classifiers = set(project["classifiers"])
    assert "Topic :: Scientific/Engineering :: Artificial Intelligence" in classifiers
    assert "Topic :: Software Development :: Testing" in classifiers

    urls = project["urls"]
    assert urls["Debugging Guide"] == "https://aaronlab.github.io/browsertrace/debug-browser-agent-failure.html"
    assert urls["Computer Use Guide"] == "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html"
    assert urls["Browser Use Guide"] == "https://aaronlab.github.io/browsertrace/browser-use-debugging.html"
    assert urls["Stagehand Guide"] == "https://aaronlab.github.io/browsertrace/stagehand-debugging.html"
    assert urls["Skyvern Guide"] == "https://aaronlab.github.io/browsertrace/skyvern-debugging.html"
    assert urls["Playwright + LLM Guide"] == "https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html"
    assert urls["Changelog"] == "https://github.com/aaronlab/browsertrace/blob/main/CHANGELOG.md"
    assert urls["Roadmap"] == "https://github.com/aaronlab/browsertrace/blob/main/ROADMAP.md"
    assert urls["Discussions"] == "https://github.com/aaronlab/browsertrace/discussions/6"


def test_readme_intro_is_browser_use_first_for_pypi_description():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    intro = readme.split("## See a failure trace in 60 seconds", 1)[0]

    assert "> Local replay debugger for Browser Use failures." in intro
    assert "Your Browser Use agent failed." in intro
    assert "Browser Use is the primary path." in intro
    assert "Local flight recorder" not in intro
    assert "AI browser agents" not in intro


def test_social_preview_source_uses_browser_use_first_positioning():
    project_root = Path(__file__).resolve().parents[1]
    svg = (project_root / "docs" / "social-preview.svg").read_text()

    assert "Local replay debugger for Browser Use failures" in svg
    assert "Replay failed Browser Use runs locally" in svg
    assert "Local flight recorder" not in svg
    assert "AI browser agents" not in svg


def test_publish_workflow_is_ready_for_trusted_publishing():
    project_root = Path(__file__).resolve().parents[1]
    workflow = (project_root / ".github" / "workflows" / "publish.yml").read_text()

    assert "workflow_dispatch:" in workflow
    assert re.search(r"publish:\n(?: {4}.*\n)* {4}environment: pypi", workflow)
    assert re.search(
        r"publish:\n(?: {4}.*\n)* {4}permissions:\n"
        r"(?: {6}.*\n)* {6}contents: read\n"
        r"(?: {6}.*\n)* {6}id-token: write",
        workflow,
    )
    assert "pypa/gh-action-pypi-publish@release/v1" in workflow


def test_readme_uses_pypi_install_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert 'pip install "browsertrace[ui]"' in install_section
    assert "pip install browsertrace" in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "@ git+https://github.com/aaronlab/browsertrace" not in install_section
    assert "PyPI publishing is not enabled yet" not in readme


def test_launch_plan_uses_pypi_install_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    plan = (
        project_root
        / "docs"
        / "superpowers"
        / "plans"
        / "2026-05-09-browsertrace-launch-readiness.md"
    ).read_text()

    assert "pip install browsertrace" in plan
    assert 'pip install "browsertrace[ui]"' in plan
    assert "pip install git+https://github.com/aaronlab/browsertrace" not in plan
    assert "@ git+https://github.com/aaronlab/browsertrace" not in plan


def test_readme_shows_pypi_badge_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    header = readme.split("(docs/demo.gif)", 1)[0]

    assert "[![PyPI]" in header
    assert "https://img.shields.io/pypi/v/browsertrace.svg" in header
    assert "https://pypi.org/project/browsertrace/" in header


def test_readme_demo_gif_has_descriptive_alt_text():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "![demo](docs/demo.gif)" not in readme
    assert (
        "![BrowserTrace failed browser-agent trace timeline showing the first red step]"
        "(docs/demo.gif)"
        in readme
    )


def test_readme_surfaces_first_awesome_list_inclusion_near_intro():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    intro = readme.split("## See a failure trace in 60 seconds", 1)[0]
    normalized_intro = re.sub(r"\s+", " ", intro)

    assert (
        "Listed in [Jenqyang/Awesome-AI-Agents]"
        "(https://github.com/Jenqyang/Awesome-AI-Agents) under"
        " `Applications` -> `Tools`."
        in normalized_intro
    )


def test_homepage_has_software_source_code_json_ld():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    match = re.search(
        r'<script type="application/ld\+json">\s*(.*?)\s*</script>',
        homepage,
        re.S,
    )

    assert match is not None
    metadata = json.loads(match.group(1))
    assert metadata["@context"] == "https://schema.org"
    assert metadata["@type"] == "SoftwareSourceCode"
    assert metadata["name"] == "BrowserTrace"
    assert metadata["codeRepository"] == "https://github.com/aaronlab/browsertrace"
    assert metadata["programmingLanguage"] == "Python"
    assert metadata["license"] == "https://opensource.org/license/mit"


def test_core_guides_have_tech_article_json_ld():
    project_root = Path(__file__).resolve().parents[1]
    guide_pages = [
        ("debug-browser-agent-failure.html", "How to debug a Browser Use failure"),
        ("browser-use-debugging.html", "Debug Browser Use failures with BrowserTrace"),
        ("stagehand-debugging.html", "Debug Stagehand runs with BrowserTrace"),
        ("skyvern-debugging.html", "Debug Skyvern task failures with BrowserTrace"),
        (
            "playwright-llm-debugging.html",
            "Debug Playwright + LLM browser-agent failures with BrowserTrace",
        ),
        (
            "computer-use-agent-debugging.html",
            "Debug custom computer-use agent failures with BrowserTrace",
        ),
    ]

    for filename, headline in guide_pages:
        page = (project_root / "docs" / filename).read_text()
        match = re.search(
            r'<script type="application/ld\+json">\s*(.*?)\s*</script>',
            page,
            re.S,
        )

        assert match is not None, filename
        metadata = json.loads(match.group(1))
        assert metadata["@context"] == "https://schema.org", filename
        assert metadata["@type"] == "TechArticle", filename
        assert metadata["headline"] == headline, filename
        assert metadata["isPartOf"]["name"] == "BrowserTrace", filename
        assert metadata["codeRepository"] == "https://github.com/aaronlab/browsertrace", filename


def test_windows_powershell_first_run_docs_cover_env_vars():
    project_root = Path(__file__).resolve().parents[1]
    docs_text = "\n".join(
        [
            (project_root / "README.md").read_text(),
            (project_root / "examples" / "README.md").read_text(),
        ]
    )

    assert 'powershell' in docs_text.lower()
    assert '$env:BROWSERTRACE_HOME = "$env:TEMP\\browsertrace-demo"' in docs_text
    assert '$env:BROWSERTRACE_PORT = "4000"' in docs_text
    assert "BROWSERTRACE_HOME=/tmp/browsertrace-demo" in docs_text
    assert "BROWSERTRACE_PORT=4000 browsertrace" in docs_text


def test_readme_browsertrace_home_note_links_isolated_storage_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    first_run_notes = readme.split(
        "`BROWSERTRACE_PORT=3001 browsertrace` starts the local UI", 1
    )[1].split("If install or demo startup fails", 1)[0]

    assert "`BROWSERTRACE_HOME` to use an isolated trace store" in first_run_notes
    assert (
        "[isolated trace storage recipe](examples/#testing-with-isolated-trace-storage)"
        in first_run_notes
    )
    assert '$env:BROWSERTRACE_HOME = "$env:TEMP\\browsertrace-demo"' in first_run_notes


def test_examples_readme_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    examples = (project_root / "examples" / "README.md").read_text()

    assert "First PR Recipe" in examples
    assert "CONTRIBUTING.md#first-pr-recipe" in examples
    assert "first contribution small and reviewable" in examples
    assert "stars" not in examples.lower()
    assert "upvotes" not in examples.lower()
    assert "reposts" not in examples.lower()


def test_issue_chooser_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    config = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "config.yml"
    ).read_text()

    assert "name: First PR Recipe" in config
    assert (
        "url: https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in config
    )
    assert "first contribution small and reviewable" in config
    assert "stars" not in config.lower()
    assert "upvotes" not in config.lower()
    assert "reposts" not in config.lower()


def test_issue_chooser_links_code_of_conduct_for_issue_expectations():
    project_root = Path(__file__).resolve().parents[1]
    config = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "config.yml"
    ).read_text()

    assert "name: Code of Conduct" in config
    assert (
        "url: https://github.com/aaronlab/browsertrace/blob/main/CODE_OF_CONDUCT.md"
        in config
    )
    assert "constructive issues, discussions, reviews, and pull requests" in config


def test_issue_chooser_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    config = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "config.yml"
    ).read_text()

    assert "name: Security Policy" in config
    assert (
        "url: https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md"
        in config
    )
    assert "sensitive issues" in config
    assert "private trace data" in config


def test_homepage_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "First PR Recipe" in homepage
    assert (
        "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue"
        in homepage
    )
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in homepage
    )
    assert "Good first issues" in homepage
    assert "first contribution small and reviewable" in homepage
    assert "stars" not in homepage.lower()
    assert "upvotes" not in homepage.lower()
    assert "reposts" not in homepage.lower()


def test_homepage_surfaces_first_awesome_list_inclusion_near_intro():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()
    intro = homepage.split('<section class="trace"', 1)[0]
    normalized_intro = re.sub(r"\s+", " ", intro)

    assert (
        'Listed in <a href="https://github.com/Jenqyang/Awesome-AI-Agents">'
        "Awesome-AI-Agents</a> under Applications -&gt; Tools."
        in normalized_intro
    )
    assert "stars" not in normalized_intro.lower()
    assert "upvotes" not in normalized_intro.lower()
    assert "reposts" not in normalized_intro.lower()


def test_homepage_names_current_adapter_surfaces():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "Browser Use run hooks" in homepage
    assert (
        "Also supports Stagehand, Skyvern, Playwright + LLM, and custom computer-use workflows "
        "as secondary integrations."
        in homepage
    )


def test_homepage_and_readme_link_failure_patterns_page():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()
    readme = (project_root / "README.md").read_text()

    assert 'href="./browser-agent-failure-patterns.html">Failure patterns</a>' in homepage
    assert (
        "[Failure patterns](https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html)"
        in readme
    )
    assert "browser-agent-failure-patterns.html" in readme
    assert "Concrete Browser Use failure patterns" in readme
    assert "new-tab desync" in readme
    assert "local HTML upload navigation mistakes" in readme
    assert "remote CDP hangs" in readme
    assert "icon-only target" in readme
    assert "Stagehand semantic verification boundary" in readme
    assert "Skyvern multi-session VNC control drift" in readme
    assert "stars" not in homepage.lower()
    assert "upvotes" not in homepage.lower()
    assert "reposts" not in homepage.lower()


def test_homepage_intro_uses_mobile_friendly_copy():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "Debug Browser Use failures" in homepage
    assert "Replay an AI browser-agent failure</h1>" not in homepage
    assert "Replay what a Browser Use agent saw, clicked, and returned" in homepage
    assert (
        'aria-label="Primary Browser Use run hooks" title="Primary Browser Use run hooks">Browser Use-first</span>'
        in homepage
    )
    intro = homepage.split('<section class="trace"', 1)[0]
    assert "Stagehand</span>" not in intro
    assert "Skyvern</span>" not in intro
    assert "Playwright + LLM</span>" not in intro
    assert "Also supports Stagehand, Skyvern, Playwright + LLM" in intro
    assert "font-size: clamp(34px, 6vw, 60px)" not in homepage
    assert "@media (max-width: 620px)" in homepage
    assert "@media (max-width: 420px)" in homepage
    assert "text-wrap: wrap" in homepage


def test_homepage_download_links_use_current_release():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "releases/download/v0.1.19/browsertrace-demo.html" in homepage
    assert "releases/download/v0.1.19/browsertrace-demo-public.html" in homepage
    assert "releases/download/v0.1.18/browsertrace-demo.html" not in homepage
    assert "releases/download/v0.1.18/browsertrace-demo-public.html" not in homepage


def test_homepage_intro_grid_can_shrink_on_mobile():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "grid-template-columns: minmax(0, 1fr)" in homepage
    assert ".intro > *" in homepage
    assert "min-width: 0" in homepage
    assert "max-width: 16ch" not in homepage


def test_homepage_intro_uses_natural_title_wrapping():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()
    h1_css = re.search(r"h1\s*\{(?P<body>.*?)\n    \}", homepage, re.S)
    dek_html = re.search(r'<p class="dek">(?P<body>.*?)</p>', homepage, re.S)

    assert h1_css is not None
    assert dek_html is not None
    assert '<h1 id="title">Debug Browser Use failures</h1>' in homepage
    assert "text-wrap: balance" in h1_css.group("body")
    assert "Playwright&nbsp;+&nbsp;LLM" in dek_html.group("body")
    assert "and computer-use&nbsp;workflows" in dek_html.group("body")
    assert "custom&nbsp;computer-use&nbsp;agents" not in dek_html.group("body")
    assert 'class="title-line"' not in homepage
    assert ".title-line" not in homepage


def test_homepage_mobile_title_has_line_length_guard():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()
    mobile_css = re.search(
        r"@media \(max-width: 620px\) \{(?P<body>.*?)\n    \}\n\n    @media \(max-width: 420px\)",
        homepage,
        re.S,
    )
    small_phone_css = re.search(
        r"@media \(max-width: 420px\) \{(?P<body>.*?)\n    \}\n  </style>",
        homepage,
        re.S,
    )

    assert mobile_css is not None
    assert small_phone_css is not None
    assert re.search(
        r"h1\s*\{[^}]*font-size: 32px;[^}]*max-width: 100%;[^}]*text-wrap: wrap;",
        mobile_css.group("body"),
        re.S,
    )
    assert re.search(
        r"h1\s*\{[^}]*font-size: 30px;",
        small_phone_css.group("body"),
        re.S,
    )
    assert "max-width: min(100%, 20ch);" not in homepage
    assert "max-width: 16ch;" not in homepage


def test_homepage_intro_actions_do_not_squeeze_copy_column():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    intro_css = re.search(r"\.intro\s*\{(?P<body>.*?)\n    \}", homepage, re.S)
    actions_css = re.search(r"\.actions\s*\{(?P<body>.*?)\n    \}", homepage, re.S)

    assert intro_css is not None
    assert actions_css is not None
    assert "grid-template-columns: minmax(0, 1fr)" in intro_css.group("body")
    assert ".intro > *" in homepage
    assert "min-width: 0" in homepage
    assert "minmax(260px, 320px)" not in intro_css.group("body")
    assert "justify-content: flex-start" in actions_css.group("body")
    assert "justify-self: start" in actions_css.group("body")
    assert "width: 100%" in actions_css.group("body")


def test_homepage_mobile_nav_stays_scrollable_and_actions_wrap_compactly():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()
    mobile_css = re.search(
        r"@media \(max-width: 620px\) \{(?P<body>.*?)\n    \}\n\n    @media \(max-width: 420px\)",
        homepage,
        re.S,
    )

    assert mobile_css is not None
    mobile_body = mobile_css.group("body")
    assert re.search(
        r"\.topbar\s*\{[^}]*flex-wrap: nowrap;[^}]*align-items: center;",
        mobile_body,
        re.S,
    )
    assert re.search(
        r"nav\s*\{[^}]*flex-wrap: nowrap;[^}]*overflow-x: auto;[^}]*min-width: 0;",
        mobile_body,
        re.S,
    )
    assert re.search(r"nav a\s*\{[^}]*white-space: nowrap;", mobile_body, re.S)
    assert re.search(
        r"\.actions\s*\{[^}]*flex-wrap: wrap;[^}]*overflow-x: visible;",
        mobile_body,
        re.S,
    )
    assert re.search(
        r"\.actions \.button\s*\{[^}]*flex: 1 1 148px;",
        mobile_body,
        re.S,
    )
    assert ".actions::-webkit-scrollbar" not in mobile_body


def test_homepage_intro_no_longer_needs_tablet_sidebar_override():
    project_root = Path(__file__).resolve().parents[1]
    homepage = (project_root / "docs" / "index.html").read_text()

    assert "@media (max-width: 980px)" not in homepage


def test_integrations_page_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    integrations = (project_root / "docs" / "integrations.html").read_text()

    assert "First PR Recipe" in integrations
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in integrations
    )
    assert "first contribution small and reviewable" in integrations
    assert "stars" not in integrations.lower()
    assert "upvotes" not in integrations.lower()
    assert "reposts" not in integrations.lower()


def test_integrations_page_has_discovery_metadata():
    project_root = Path(__file__).resolve().parents[1]
    integrations = (project_root / "docs" / "integrations.html").read_text()

    assert (
        '<link rel="alternate" type="text/plain" title="llms.txt" href="./llms.txt">'
        in integrations
    )

    match = re.search(
        r'<script type="application/ld\+json">\s*(.*?)\s*</script>',
        integrations,
        re.S,
    )

    assert match is not None
    metadata = json.loads(match.group(1))
    assert metadata["@context"] == "https://schema.org"
    assert metadata["@type"] == "CollectionPage"
    assert metadata["name"] == "BrowserTrace integrations"
    assert metadata["url"] == "https://aaronlab.github.io/browsertrace/integrations.html"
    assert metadata["isPartOf"]["name"] == "BrowserTrace"
    assert metadata["isPartOf"]["codeRepository"] == "https://github.com/aaronlab/browsertrace"


def test_integrations_page_includes_aos_mapping_research_table():
    project_root = Path(__file__).resolve().parents[1]
    integrations = (project_root / "docs" / "integrations.html").read_text()
    section = integrations.split('<h2 id="aos-mapping">AOS mapping research</h2>', 1)[
        1
    ].split('<section class="band" aria-labelledby="browser-use">', 1)[0]
    rows = {
        cells[0]: cells
        for cells in re.findall(
            r"<tr>\s*((?:<td(?:\s+[^>]*)?>.*?</td>\s*){4})</tr>",
            section,
            re.S,
        )
        for cells in [
            [
                re.sub(r"<.*?>", "", cell).strip()
                for cell in re.findall(r"<td(?:\s+[^>]*)?>(.*?)</td>", cells, re.S)
            ]
        ]
    }

    assert "not an AOS compliance claim" in section
    assert "https://github.com/aaronlab/browsertrace/issues/237" in section
    assert 'data-label="BrowserTrace field"' in section
    assert ".mapping-table td::before" in integrations
    assert rows["Run id and step id"][2] == "partially mapped"
    assert rows["Action label or tool call"][1] == "steps/toolCallRequest"
    assert rows["Action label or tool call"][2] == "partially mapped"
    assert rows["Status and error"][1] == "steps/toolCallResult with isError"
    assert rows["Status and error"][2] == "partially mapped"
    assert "research-only toolCallResult result shape" in rows["Status and error"][3]
    assert "run status" in rows["Status and error"][3]
    assert "step status" in rows["Status and error"][3]
    assert "error message/type" in rows["Status and error"][3]
    assert "action/tool label" in rows["Status and error"][3]
    assert "step id" in rows["Status and error"][3]
    assert "public export/redaction state" in rows["Status and error"][3]
    assert "not an AOS compliance claim" in rows["Status and error"][3]
    assert rows["Screenshot or future video artifact"][1] == (
        "FileWithUri preferred over inline FileWithBytes"
    )
    assert rows["Screenshot or future video artifact"][2] == "research gap"
    assert rows["Current browser URL"][2] == "research gap"
    assert "redact each field independently" in rows["Current browser URL"][3]
    assert rows["Model input and output"][2] == "research gap"
    assert "do not force full prompt or model I/O" in rows["Model input and output"][3]
    assert rows["Public export redaction state"][2] == "research gap"
    assert "explicit omitted or redacted markers" in rows["Public export redaction state"][3]
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_browser_use_guide_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_browser_use_guide_covers_local_html_upload_navigation_boundary():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert 'id="debug-local-html-upload-navigation"' in guide
    assert "local HTML upload" in guide
    assert "misread as a navigation target" in guide
    assert "browser-use/browser-use/issues/4794" in guide

    section = guide.split('id="debug-local-html-upload-navigation"', 1)[1].split(
        "</section>",
        1,
    )[0]

    for expected in [
        "task prompt",
        "model-visible file or attachment context",
        "local filename",
        "extension",
        "MIME type",
        "raw model action before validation",
        "parsed action type",
        "bad URL",
        "security/watchdog block reason",
        "allowed-domains",
    ]:
        assert expected in section

    assert "future adapter boundary" in section
    assert "does not mean BrowserTrace already captures every internal Browser Use field" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_browser_use_guide_covers_action_schema_validation_boundary():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert 'id="debug-action-schema-validation"' in guide
    assert "action schema" in guide
    assert "schema coercion" in guide
    assert "browser-use/browser-use/issues/4796" in guide

    section = guide.split('id="debug-action-schema-validation"', 1)[1].split(
        "</section>",
        1,
    )[0]

    for expected in [
        "raw model action",
        "validated or normalized action",
        "schema or normalization warning",
        "selected element metadata",
        "final executed target",
    ]:
        assert expected in section

    assert "future adapter boundary" in section
    assert "does not mean BrowserTrace already captures every internal Browser Use field" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_stagehand_guide_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "stagehand-debugging.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_skyvern_guide_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "skyvern-debugging.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_playwright_llm_guide_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "playwright-llm-debugging.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_integration_guides_link_share_safe_export_recipe():
    project_root = Path(__file__).resolve().parents[1]
    recipe_url = (
        "https://github.com/aaronlab/browsertrace/blob/main/examples/README.md"
        "#creating-a-share-safe-export"
    )

    for filename in [
        "playwright-llm-debugging.html",
        "stagehand-debugging.html",
        "skyvern-debugging.html",
    ]:
        guide = (project_root / "docs" / filename).read_text()
        share_section = guide.split("<h2>Share only what is safe</h2>", 1)[1].split(
            "</section>", 1
        )[0]

        assert recipe_url in share_section, filename
        assert "share-safe export recipe" in share_section, filename


def test_playwright_llm_guide_mentions_sync_snapshot_helper():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "playwright-llm-debugging.html").read_text()

    assert "run.snapshot_sync(page, action=...)" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/examples/README.md"
        "#playwright-sync-api-snapshot"
    ) in guide
    assert "Playwright's sync API" in guide


def test_computer_use_guide_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "computer-use-agent-debugging.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_failure_walkthrough_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "debug-browser-agent-failure.html").read_text()

    assert "First PR Recipe" in guide
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in guide
    )
    assert "first contribution small and reviewable" in guide
    assert "stars" not in guide.lower()
    assert "upvotes" not in guide.lower()
    assert "reposts" not in guide.lower()


def test_failure_walkthrough_demo_video_has_accessible_context():
    project_root = Path(__file__).resolve().parents[1]
    guide = (project_root / "docs" / "debug-browser-agent-failure.html").read_text()
    video_block = re.search(r"<figure.*?</figure>", guide, re.S)

    assert video_block is not None
    block = video_block.group(0)
    assert '<video controls muted playsinline poster="./demo-poster.png"' in block
    assert "<figcaption>" in block
    assert "BrowserTrace" in block
    assert "failed browser-agent trace timeline" in block
    assert "first red step" in block


def test_demo_mp4_uses_social_upload_safe_frame_rate():
    if shutil.which("ffprobe") is None:
        pytest.skip("ffprobe is required to inspect demo.mp4 frame rate")

    project_root = Path(__file__).resolve().parents[1]
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-select_streams",
            "v:0",
            "-show_entries",
            "stream=avg_frame_rate",
            "-of",
            "json",
            str(project_root / "docs" / "demo.mp4"),
        ],
        check=True,
        capture_output=True,
        text=True,
    )
    payload = json.loads(completed.stdout)
    frame_rate = Fraction(payload["streams"][0]["avg_frame_rate"])

    assert frame_rate >= 10


def test_comparison_page_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "compare-browser-agent-debugging.html").read_text()

    assert "First PR Recipe" in page
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in page
    )
    assert "first contribution small and reviewable" in page
    assert "stars" not in page.lower()
    assert "upvotes" not in page.lower()
    assert "reposts" not in page.lower()


def test_trace_demo_page_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "trace.html").read_text()

    assert "First PR Recipe" in page
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in page
    )
    assert "first contribution small and reviewable" in page
    assert "stars" not in page.lower()
    assert "upvotes" not in page.lower()
    assert "reposts" not in page.lower()


def test_trace_demo_page_has_mobile_export_metadata():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "trace.html").read_text()

    assert "<html lang='en'>" in page
    assert "<meta name='viewport' content='width=device-width, initial-scale=1'>" in page
    assert "@media(max-width:720px){body{padding:14px}.step{grid-template-columns:1fr}}" in page


def test_trace_demo_page_has_discovery_metadata():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "trace.html").read_text()

    assert "<link rel='canonical' href='https://aaronlab.github.io/browsertrace/trace.html'>" in page
    assert "<link rel='alternate' type='text/plain' title='llms.txt' href='./llms.txt'>" in page

    match = re.search(
        r"<script type='application/ld\+json'>\s*(.*?)\s*</script>",
        page,
        re.S,
    )

    assert match is not None
    metadata = json.loads(match.group(1))
    assert metadata["@context"] == "https://schema.org"
    assert metadata["@type"] == "TechArticle"
    assert metadata["headline"] == "BrowserTrace exported failure trace"
    assert metadata["url"] == "https://aaronlab.github.io/browsertrace/trace.html"
    assert metadata["isPartOf"]["name"] == "BrowserTrace"
    assert metadata["isPartOf"]["codeRepository"] == "https://github.com/aaronlab/browsertrace"


def test_trace_demo_page_uses_browser_use_first_failure_story():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "trace.html").read_text()

    assert "demo: Browser Use local HTML upload navigation failure" in page
    assert "Browser Use navigated away from the upload page" in page
    assert "file:///tmp/browsertrace-report.html" in page
    assert "assert uploaded file preview" in page
    assert "demo: checkout agent fails on disabled button" not in page
    assert "click disabled checkout button" not in page


def test_failure_patterns_page_has_discovery_metadata_and_examples():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-agent-failure-patterns.html").read_text()

    assert '<link rel="canonical" href="https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html">' in page
    assert '<link rel="alternate" type="text/plain" title="llms.txt" href="./llms.txt">' in page
    assert "Browser agent failure patterns" in page
    assert "icon-only target mismatch" in page
    assert "remote CDP hang" in page
    assert "new-tab desync" in page
    assert "screenshot blob" in page
    assert "custom-tool replay gap" in page
    assert "semantic verification boundary" in page
    assert "action confidence gap" in page
    assert "VNC/CDP debug integration" in page
    assert "multi-session VNC control drift" in page
    assert "persistent browser recovery" in page
    assert "browser-use/browser-use#4801" in page
    assert "browser-use/browser-use#4758" in page
    assert "browser-use/browser-use#4579" in page
    assert "browserbase/stagehand#1558" in page
    assert "browserbase/stagehand#1880" in page
    assert "Skyvern-AI/skyvern#3260" in page
    assert "Skyvern-AI/skyvern#4392" in page
    assert "stars" not in page.lower()
    assert "upvotes" not in page.lower()
    assert "reposts" not in page.lower()

    match = re.search(
        r'<script type="application/ld\+json">\s*(.*?)\s*</script>',
        page,
        re.S,
    )

    assert match is not None
    metadata = json.loads(match.group(1))
    assert metadata["@context"] == "https://schema.org"
    assert metadata["@type"] == "TechArticle"
    assert metadata["headline"] == "Browser agent failure patterns"
    assert metadata["url"] == "https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html"
    assert metadata["isPartOf"]["name"] == "BrowserTrace"
    assert metadata["isPartOf"]["codeRepository"] == "https://github.com/aaronlab/browsertrace"


def test_failure_patterns_page_guide_fragment_links_have_targets():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-agent-failure-patterns.html").read_text()
    fragment_links = re.findall(r'href="(?P<href>\./(?P<path>[^"#]+)#(?P<fragment>[^"]+))"', page)

    assert fragment_links
    for href, path, fragment in fragment_links:
        target = (project_root / "docs" / path).read_text()
        assert f'id="{fragment}"' in target, href


def test_failure_patterns_page_h2_headings_have_stable_id_anchors():
    """Issue #353: all <h2> headings in the failure patterns page must have stable id attributes."""
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-agent-failure-patterns.html").read_text()

    # The 11 failure pattern headings must each carry a stable id anchor
    expected_ids = [
        "debug-icon-only-click-targets",
        "debug-new-tab-desync",
        "debug-local-html-upload-navigation",
        "debug-remote-cdp-hangs",
        "debug-screenshot-blob-context",
        "debug-custom-tool-replay-gaps",
        "debug-semantic-verification-boundaries",
        "debug-action-confidence-and-authorization",
        "debug-vnc-and-cdp-evidence-together",
        "debug-multi-session-vnc-control-drift",
        "debug-persistent-browser-recovery",
        "debug-public-safe-sharing",
    ]

    for anchor_id in expected_ids:
        assert f'id="{anchor_id}"' in page, f"Missing id=\"{anchor_id}\" in browser-agent-failure-patterns.html"


def test_failure_patterns_page_includes_local_html_upload_navigation_pattern():
    """Issue #352: the high-level page should include the local HTML upload navigation pattern."""
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-agent-failure-patterns.html").read_text()

    assert "Browser Use local HTML upload navigation" in page
    assert "https://github.com/browser-use/browser-use/issues/4794" in page
    assert "./browser-use-debugging.html#debug-local-html-upload-navigation" in page
    assert "Raw model action before validation" in page


def test_launch_kit_page_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "launch" / "index.html").read_text()

    assert "First PR Recipe" in page
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in page
    )
    assert "first contribution small and reviewable" in page
    assert "stars" not in page.lower()
    assert "upvotes" not in page.lower()
    assert "reposts" not in page.lower()


def test_launch_kit_page_has_discovery_metadata():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "launch" / "index.html").read_text()

    assert (
        '<link rel="alternate" type="text/plain" title="llms.txt" href="../llms.txt">'
        in page
    )

    match = re.search(
        r'<script type="application/ld\+json">\s*(.*?)\s*</script>',
        page,
        re.S,
    )

    assert match is not None
    metadata = json.loads(match.group(1))
    assert metadata["@context"] == "https://schema.org"
    assert metadata["@type"] == "WebPage"
    assert metadata["name"] == "BrowserTrace launch kit"
    assert metadata["url"] == "https://aaronlab.github.io/browsertrace/launch/"
    assert metadata["isPartOf"]["name"] == "BrowserTrace"
    assert metadata["isPartOf"]["codeRepository"] == "https://github.com/aaronlab/browsertrace"


def test_launch_kit_page_links_owner_short_packets():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "launch" / "index.html").read_text()

    assert "Owner packets" in page
    owner_packets = page.split('<h2 id="owner-packets">Owner packets</h2>', 1)[1].split(
        '<h2 id="links">Links</h2>',
        1,
    )[0]

    for href in [
        "owner-social-post-packet.md",
        "owner-email-send-packet.md",
        "owner-launch-submission-packet.md",
        "monitoring-runbook.md",
    ]:
        assert f'href="{href}"' in owner_packets, href

    assert "X, LinkedIn, WeChat, and Jike" in owner_packets
    assert "console.dev and AgDex" in owner_packets
    assert "Show HN and Product Hunt" in owner_packets
    assert "Post-launch checks" in owner_packets
    assert "stars" not in owner_packets.lower()
    assert "votes" not in owner_packets.lower()
    assert "reposts" not in owner_packets.lower()


def test_launch_kit_page_surfaces_current_x_single_post_unblock():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "launch" / "index.html").read_text()
    current_unblock = page.split('id="current-owner-unblock"', 1)[1].split(
        '<section class="band" aria-labelledby="copy">',
        1,
    )[0]

    assert "Current owner unblock" in current_unblock
    assert "one-minute X post" in current_unblock
    assert "docs/demo.mp4" in current_unblock
    assert "owner-social-post-packet.md" in current_unblock
    assert "Browser Use failed but logs do not show what the agent saw?" in current_unblock
    assert "What should it capture?" in current_unblock
    assert "https://github.com/aaronlab/browsertrace" in current_unblock
    assert "post URL back" in current_unblock
    assert "stars" not in current_unblock.lower()
    assert "upvotes" not in current_unblock.lower()
    assert "reposts" not in current_unblock.lower()


def test_docs_include_pypi_quickstart_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    docs_text = "\n".join(
        [
            (project_root / "README.md").read_text(),
            (project_root / "docs" / "llms.txt").read_text(),
        ]
    )

    pypi_spec = "browsertrace[ui]"
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in docs_text
    assert f'uvx --from "{pypi_spec}" browsertrace list' in docs_text
    assert 'pip install "browsertrace[ui]"' in docs_text


def test_owner_launch_checklists_include_pypi_trial_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"

    for relpath in [
        "LAUNCH.md",
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
    ]:
        text = (project_root / relpath).read_text()
        assert f'uvx --from "{pypi_spec}" browsertrace doctor' in text, relpath
        assert f'uvx --from "{pypi_spec}" browsertrace demo' in text, relpath
        assert "pypi" in text.lower(), relpath


def test_pypi_publishing_notes_link_first_pr_recipe_for_small_docs_fixes():
    project_root = Path(__file__).resolve().parents[1]
    notes = (project_root / "docs" / "release" / "pypi-publishing.md").read_text()

    assert "First PR Recipe" in notes
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in notes
    )
    assert "first contribution small and reviewable" in notes
    assert "owner-only" in notes.lower()
    assert "stars" not in notes.lower()
    assert "upvotes" not in notes.lower()
    assert "reposts" not in notes.lower()


def test_changelog_links_first_pr_recipe_for_small_docs_fixes():
    project_root = Path(__file__).resolve().parents[1]
    changelog = (project_root / "CHANGELOG.md").read_text()

    assert "First PR Recipe" in changelog
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in changelog
    )
    assert "first contribution small and reviewable" in changelog
    assert "stars" not in changelog.lower()
    assert "upvotes" not in changelog.lower()
    assert "reposts" not in changelog.lower()


def test_changelog_tracks_018_browser_use_first_metadata_refresh():
    project_root = Path(__file__).resolve().parents[1]
    changelog = (project_root / "CHANGELOG.md").read_text()
    release_notes = changelog.split("## 0.1.18", 1)[1].split("## 0.1.17", 1)[0]
    normalized_notes = re.sub(r"\s+", " ", release_notes)

    assert "Browser Use-first failure replay/debugging story" in normalized_notes
    assert "PyPI long description" in normalized_notes
    assert "`v0.1.18` patch release" in release_notes


def test_changelog_tracks_019_compare_cli_release():
    project_root = Path(__file__).resolve().parents[1]
    changelog = (project_root / "CHANGELOG.md").read_text()
    release_notes = changelog.split("## 0.1.19", 1)[1].split("## 0.1.18", 1)[0]
    normalized_notes = re.sub(r"\s+", " ", release_notes)

    assert "`browsertrace compare <failed_run_id> <success_run_id>`" in release_notes
    assert "first divergent action, URL, status, or error" in normalized_notes
    assert "Browser Use guide" in release_notes
    assert "`v0.1.19` patch release" in release_notes


def test_code_of_conduct_links_first_pr_recipe_for_small_docs_fixes():
    project_root = Path(__file__).resolve().parents[1]
    code_of_conduct = (project_root / "CODE_OF_CONDUCT.md").read_text()

    assert "First PR Recipe" in code_of_conduct
    assert (
        "https://github.com/aaronlab/browsertrace/blob/main/CONTRIBUTING.md#first-pr-recipe"
        in code_of_conduct
    )
    assert "first contribution small and reviewable" in code_of_conduct
    assert "stars, upvotes, vote swaps" in code_of_conduct
    assert "fake engagement" in code_of_conduct


def test_code_of_conduct_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    code_of_conduct = (project_root / "CODE_OF_CONDUCT.md").read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in code_of_conduct
    assert "reposts" not in code_of_conduct.lower()


def test_github_profile_draft_links_current_trial_and_contribution_paths():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"
    profile_draft = (
        project_root / "docs" / "launch" / "github-profile-readme.md"
    ).read_text()

    assert "https://github.com/aaronlab/browsertrace" in profile_draft
    assert "Local replay debugger for Browser Use failures." in profile_draft
    assert "BrowserTrace helps Browser Use builders debug failed runs" in profile_draft
    assert "Local replay debugger for Browser Use failures" in profile_draft
    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in profile_draft
    assert "https://aaronlab.github.io/browsertrace/stagehand-debugging.html" in profile_draft
    assert "https://aaronlab.github.io/browsertrace/skyvern-debugging.html" in profile_draft
    assert "https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html" in profile_draft
    assert "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html" in profile_draft
    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in profile_draft
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in profile_draft
    assert f'uvx --from "{pypi_spec}" browsertrace' in profile_draft
    assert 'pip install "browsertrace[ui]"' in profile_draft
    assert "Browser Use run hooks" in profile_draft
    assert "Stagehand wrapper" in profile_draft
    assert "Skyvern task/workflow wrapper" in profile_draft
    assert "Playwright + LLM examples" in profile_draft
    assert "Listed in Awesome-AI-Agents under Applications -> Tools." in profile_draft
    assert "https://github.com/aaronlab/browsertrace/issues/3" in profile_draft
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in profile_draft
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in profile_draft
    assert "First PR Recipe" in profile_draft
    assert "CONTRIBUTING.md#first-pr-recipe" in profile_draft
    assert "first contribution small and reviewable" in profile_draft
    assert "stars" not in profile_draft.lower()
    assert "upvotes" not in profile_draft.lower()
    assert "reposts" not in profile_draft.lower()


def test_github_profile_draft_includes_json_cli_troubleshooting_note():
    project_root = Path(__file__).resolve().parents[1]
    profile_draft = (
        project_root / "docs" / "launch" / "github-profile-readme.md"
    ).read_text()
    assert "## Troubleshooting" in profile_draft
    note = profile_draft.split("## Troubleshooting", 1)[1].split(
        "## Current Focus", 1
    )[0]

    assert (
        "profile-reader follow-up, local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in note
    )
    assert "browsertrace doctor --json" in note
    assert "browsertrace list --status failed --json" in note
    assert "browsertrace show <run_id> --json" in note
    assert "debugging/workflow details" in note
    assert "stars" not in note.lower()
    assert "upvotes" not in note.lower()
    assert "reposts" not in note.lower()


def test_github_profile_draft_links_stack_guides_from_troubleshooting_note():
    project_root = Path(__file__).resolve().parents[1]
    profile_draft = (
        project_root / "docs" / "launch" / "github-profile-readme.md"
    ).read_text()
    assert "## Troubleshooting" in profile_draft
    note = profile_draft.split("## Troubleshooting", 1)[1].split(
        "## Current Focus", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "Stack-Specific Reply Links" in note
    for guide in stack_guides:
        assert guide in note
    assert "stars" not in note.lower()
    assert "upvotes" not in note.lower()
    assert "reposts" not in note.lower()


def test_show_hn_contribution_reply_points_to_current_good_first_queue():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "day-2-show-hn-packet.md"
    ).read_text()
    reply = packet.split("Can I contribute a small fix?", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "Chinese owner next-actions" not in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_readme_has_public_safe_export_sharing_example():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "## Share A Public-Safe Trace" in readme
    assert "browsertrace demo" in readme
    assert "browsertrace list" in readme
    assert "browsertrace export <run_id> --public -o public.html" in readme
    assert "prompts/model I/O, screenshots, and URLs" in readme
    assert "hosted upload" in readme


def test_readme_has_browser_agent_feedback_checklist():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "## Report A Browser-Agent Failure" in readme
    assert "Browser Use, Stagehand, Skyvern, Playwright + LLM, or custom computer-use" in readme
    assert "agent framework" in readme
    assert "failure symptom" in readme
    assert "browsertrace show <run_id>" in readme
    assert "public-safe export" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_launch_discussion_near_feedback():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    feedback_section = readme.split("## Report A Browser-Agent Failure", 1)[1].split(
        "## Why not just use ___?", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/discussions/6" in feedback_section
    assert "browser-agent workflow feedback" in feedback_section
    assert "stars" not in feedback_section.lower()
    assert "upvotes" not in feedback_section.lower()
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_private_reports_near_feedback():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    feedback_section = readme.split("## Report A Browser-Agent Failure", 1)[1].split(
        "## Why not just use ___?", 1
    )[0]

    assert "[SECURITY.md](SECURITY.md)" in feedback_section
    assert "ordinary workflow feedback" in feedback_section
    assert "private or sensitive reports" in feedback_section
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_includes_aos_mapping_research_note_near_feedback():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    feedback_section = readme.split("## Report A Browser-Agent Failure", 1)[1].split(
        "## Why not just use ___?", 1
    )[0]

    assert "### AOS Mapping Research" in feedback_section
    assert "not an AOS compliance claim" in feedback_section
    assert "tool request/result" in feedback_section
    assert "step correlation" in feedback_section
    assert "URI-style screenshot/video artifacts" in feedback_section
    assert "URL metadata" in feedback_section
    assert "model I/O summaries" in feedback_section
    assert "explicit redaction state" in feedback_section
    assert (
        "https://aaronlab.github.io/browsertrace/integrations.html#aos-mapping"
        in feedback_section
    )
    assert "https://github.com/aaronlab/browsertrace/issues/237" in feedback_section
    assert "stars" not in feedback_section.lower()
    assert "upvotes" not in feedback_section.lower()
    assert "reposts" not in feedback_section.lower()


def test_support_page_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    support = (project_root / "SUPPORT.md").read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in support
    assert "stars" not in support.lower()
    assert "upvotes" not in support.lower()
    assert "reposts" not in support.lower()


def test_support_page_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    support = (project_root / "SUPPORT.md").read_text()

    assert "## AOS Mapping Research" in support
    research_note = support.split("## AOS Mapping Research", 1)[1].split(
        "## Bugs", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_readme_clarifies_cloud_features_are_not_required_for_local_oss():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    cloud_section = readme.split("## Cloud / Team (coming soon)", 1)[1].split(
        "## Roadmap", 1
    )[0]

    assert (
        "None of these hosted features are required for the current local OSS "
        "workflow"
    ) in cloud_section
    assert "Local BrowserTrace will always be free OSS" in cloud_section
    assert "open a cloud/team interest issue" in cloud_section
    assert "stars" not in cloud_section.lower()
    assert "upvotes" not in cloud_section.lower()


def test_roadmap_contribution_guidelines_link_first_pr_recipe():
    project_root = Path(__file__).resolve().parents[1]
    roadmap = (project_root / "ROADMAP.md").read_text()
    guidelines = roadmap.split("## Contribution Guidelines", 1)[1].split(
        "## Success Signals", 1
    )[0]

    assert "Good roadmap PRs are narrow and testable" in guidelines
    assert "CONTRIBUTING.md#first-pr-recipe" in guidelines
    assert "first contribution small and reviewable" in guidelines
    assert "stars" not in guidelines.lower()
    assert "upvotes" not in guidelines.lower()


def test_roadmap_links_stack_debugging_guides_for_contributors():
    project_root = Path(__file__).resolve().parents[1]
    roadmap = (project_root / "ROADMAP.md").read_text()
    guidelines = roadmap.split("## Contribution Guidelines", 1)[1].split(
        "## Success Signals", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "Stack-specific guide context" in guidelines
    for guide in stack_guides:
        assert guide in guidelines
    assert "stars" not in guidelines.lower()
    assert "upvotes" not in guidelines.lower()
    assert "reposts" not in guidelines.lower()


def test_roadmap_records_current_launch_state():
    project_root = Path(__file__).resolve().parents[1]
    roadmap = (project_root / "ROADMAP.md").read_text()

    assert "`v0.1.19` is the current launch release." in roadmap
    assert "explicit `browsertrace compare` CLI path" in roadmap
    assert 'pip install "browsertrace[ui]"' in roadmap
    assert "One focused PR is merged/listed" in roadmap
    assert "Jenqyang/Awesome-AI-Agents#220" in roadmap
    assert "remaining focused PRs are open" in roadmap
    assert "E2B CLA check has passed" in roadmap
    assert "Sixteen focused PRs are open" not in roadmap
    assert "`v0.1.18` is the current launch release." not in roadmap
    assert "`v0.1.15` is the current launch release." not in roadmap
    assert "Three focused PRs are open" not in roadmap
    assert "pre-PyPI UI dependency guidance" not in roadmap


def test_readme_links_contributor_guide_near_contributing():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    contributing_section = readme.split("## Contributing", 1)[1].split(
        "## License", 1
    )[0]
    good_first_issue_url = (
        "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue"
    )

    assert "[CONTRIBUTING.md](CONTRIBUTING.md)" in contributing_section
    assert "[First PR Recipe](CONTRIBUTING.md#first-pr-recipe)" in contributing_section
    assert "small, issue-based contribution path" in contributing_section
    assert "First PR Recipe" in contributing_section
    assert "first contribution small and reviewable" in contributing_section
    assert "Before starting a good first issue" in contributing_section
    assert "comment on it first" in contributing_section
    assert "maintainers can treat it as claimed" in contributing_section
    assert "[good first issue queue]" in contributing_section
    assert good_first_issue_url in contributing_section
    assert contributing_section.count(good_first_issue_url) == 1
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contributing_section
    assert "good first issue" in contributing_section
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_contributing_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    contributing_section = readme.split("## Contributing", 1)[1].split(
        "## License", 1
    )[0]

    assert "[SECURITY.md](SECURITY.md)" in contributing_section
    assert "security-sensitive reports" in contributing_section
    assert "private trace data" in contributing_section


def test_contributing_includes_json_cli_troubleshooting_checks():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    local_checks = contributing.split("## Useful Local Checks", 1)[1].split(
        "## Contribution Areas", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert "issue reports, CI, or AI/coding-agent troubleshooting" in local_checks
    assert recipe in local_checks
    assert "stars" not in local_checks.lower()
    assert "upvotes" not in local_checks.lower()


def test_contributing_links_stack_guides_for_adapter_context():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    contribution_areas = contributing.split("## Contribution Areas", 1)[1].split(
        "## Adapter Contribution Checklist", 1
    )[0]
    adapter_checklist = contributing.split("## Adapter Contribution Checklist", 1)[1].split(
        "## Design Principles", 1
    )[0]
    stack_guides = """- Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html
- Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html
- Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html
- Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html
- Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html"""

    assert "Framework guide context:" in contribution_areas
    assert stack_guides in contribution_areas
    assert "Browser Use, Stagehand, Skyvern, Playwright + LLM, or custom computer-use" in adapter_checklist
    assert "stars" not in contribution_areas.lower()
    assert "upvotes" not in contribution_areas.lower()
    assert "reposts" not in contribution_areas.lower()


def test_contributing_includes_first_pr_recipe():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    assert "## First PR Recipe" in contributing
    recipe = contributing.split("## First PR Recipe", 1)[1].split(
        "## Useful Local Checks", 1
    )[0]

    assert "docs fix or small example" in recipe
    assert "Comment on the good first issue" in recipe
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in recipe
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in recipe
    assert "Create a branch" in recipe
    assert "uv run --python 3.11 --extra dev pytest -q" in recipe
    assert "git diff --check" in recipe
    assert "git diff --stat" in recipe
    assert "git diff --summary" in recipe
    assert "unexpected deleted or renamed files" in recipe
    assert "Fixes #<issue>" in recipe
    assert "small enough to review in one pass" in recipe
    assert "stars" not in recipe.lower()
    assert "upvotes" not in recipe.lower()
    assert "reposts" not in recipe.lower()


def test_contributing_includes_browser_use_no_service_demo_checks():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    local_checks = contributing.split("## Useful Local Checks", 1)[1].split(
        "## Contribution Areas", 1
    )[0]

    assert "python examples/browser_use_callback_demo.py" in local_checks
    assert "python examples/browser_use_run_hooks_demo.py" in local_checks
    assert "browsertrace list --limit 5" in local_checks
    assert "browsertrace show <run_id>" in local_checks
    assert "demo: browser-use callback flow" in local_checks
    assert "demo: browser-use run hooks flow" in local_checks
    assert "search_google(query=BrowserTrace)" in local_checks
    assert "click(selector=#result-1)" in local_checks
    assert "stars" not in local_checks.lower()
    assert "upvotes" not in local_checks.lower()


def test_contributing_sets_good_first_issue_claim_window():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    recipe = contributing.split("## First PR Recipe", 1)[1].split(
        "## Useful Local Checks", 1
    )[0]

    assert "active claim" in recipe
    assert "short claim window" in recipe
    assert "before maintainers take the same issue directly" in recipe


def test_first_pr_recipe_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    recipe = contributing.split("## First PR Recipe", 1)[1].split(
        "## Useful Local Checks", 1
    )[0]

    assert "[SECURITY.md](SECURITY.md)" in recipe
    assert "security-sensitive reports" in recipe
    assert "private trace data" in recipe


def test_contributing_links_public_safe_export_attachment_recipe():
    project_root = Path(__file__).resolve().parents[1]
    contributing = (project_root / "CONTRIBUTING.md").read_text()
    pull_requests = contributing.split("## Pull Requests", 1)[1]

    assert "browsertrace export <run_id> --public -o public.html" in pull_requests
    assert (
        "examples/README.md#attach-a-public-safe-export-to-an-issue"
        in pull_requests
    )
    assert "real trace publicly" in pull_requests
    assert "stars" not in pull_requests.lower()
    assert "upvotes" not in pull_requests.lower()
    assert "reposts" not in pull_requests.lower()


def test_readme_links_code_of_conduct_near_contributing():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    contributing_section = readme.split("## Contributing", 1)[1].split(
        "## License", 1
    )[0]

    assert "[CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)" in contributing_section
    assert "concise contributor expectations" in contributing_section
    assert "welcoming baseline" in contributing_section
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_issue_template_chooser_near_contributing():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    contributing_section = readme.split("## Contributing", 1)[1].split(
        "## License", 1
    )[0]

    assert (
        "https://github.com/aaronlab/browsertrace/issues/new/choose"
        in contributing_section
    )
    assert "bug, feature, integration, or cloud/team template" in contributing_section
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_pull_request_template_near_contributing():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    contributing_section = readme.split("## Contributing", 1)[1].split(
        "## License", 1
    )[0]

    assert (
        "[pull request template](.github/PULL_REQUEST_TEMPLATE.md)"
        in contributing_section
    )
    assert "linked issue and test commands" in contributing_section
    assert "git diff --stat" in contributing_section
    assert "git diff --summary" in contributing_section
    assert "unexpected deleted or renamed files" in contributing_section
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_release_notes_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "https://github.com/aaronlab/browsertrace/releases/tag/v0.1.19"
        in install_section
    )
    assert "v0.1.19 release notes" in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_release_notes_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "https://github.com/aaronlab/browsertrace/releases/tag/v0.1.19"
        in install_section
    )
    assert (
        "The v0.1.19 release notes summarize what changed in the current release"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_pypi_package_near_install():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "PyPI package" in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_pypi_package_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The PyPI package page is the canonical package listing after publishing"
    ) in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_uvx_trial_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`uvx` can run the PyPI package without a persistent install, and "
        "`pip install` is the persistent install path"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_ui_extra_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "Install `[ui]` for the local web UI" in install_section
    assert "SDK-only installs are enough for trace capture integrations" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_sdk_only_terminal_commands_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "SDK-only installs are enough for trace capture integrations and terminal "
        "commands like `browsertrace list`, `browsertrace show`, and "
        "`browsertrace export`"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_mentions_python_version_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "Requires Python 3.11+" in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_python_version_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The PyPI install path requires Python 3.11+"
        in install_section
    )
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_links_first_run_troubleshooting_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#first-run-troubleshooting-checklist" in install_section
    assert "first-run troubleshooting checklist" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_first_run_troubleshooting_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#first-run-troubleshooting-checklist" in install_section
    assert "first-run troubleshooting checklist walks through" in install_section
    for command in [
        "`browsertrace doctor`",
        "`browsertrace demo`",
        "`browsertrace list`",
        "`browsertrace show`",
        "public-safe export",
    ]:
        assert command in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_static_demo_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "https://aaronlab.github.io/browsertrace/" in install_section
    assert (
        "https://github.com/aaronlab/browsertrace/releases/download/v0.1.19/"
        "browsertrace-demo-public.html"
    ) in install_section
    assert (
        "The live static demo and public-safe demo export let you inspect a trace "
        "before installing anything"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_command_cheat_sheet_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#browsertrace-command-cheat-sheet" in install_section
    assert "The command cheat sheet summarizes" in install_section
    for command in [
        "`browsertrace doctor`",
        "`browsertrace demo`",
        "`browsertrace list`",
        "`browsertrace show`",
        "public-safe export commands",
    ]:
        assert command in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_doctor_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace doctor` is a safe local status check" in install_section
    assert "install and trace-store status" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_healthy_doctor_output_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#check-a-healthy-local-install" in install_section
    assert "healthy doctor output recipe shows expected" in install_section
    for status_line in ["`Home:`", "`Database:`", "`Runs:`", "`UI dependencies:`"]:
        assert status_line in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_list_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace list` shows demo run IDs" in install_section
    assert "`browsertrace demo`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_list_output_fields_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace list` shows demo run IDs with timestamps and status"
    ) in install_section
    assert "`browsertrace demo`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_list_json_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace list --json` prints recent runs as JSON" in install_section
    assert "id, name, status, and created timestamp" in install_section
    assert (
        "`browsertrace list` shows demo run IDs with timestamps and status"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_list_status_filter_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace list --status failed` filters recent runs by status" in install_section
    assert "`browsertrace list --status completed --json`" in install_section
    assert "`browsertrace list --json`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_compare_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace compare <failed_run_id> <success_run_id>`" in install_section
    assert "finds the first step divergence" in install_section
    assert "`browsertrace compare <failed_run_id> <success_run_id> --json`" in install_section
    assert "`browsertrace show <run_id> --json`" in install_section
    assert "hosted sharing" not in readme


def test_readme_includes_json_cli_automation_recipe_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert "For scripts, CI, or AI/coding-agent troubleshooting" in install_section
    assert recipe in install_section
    assert (
        "[JSON CLI checks for automation](examples/#json-cli-checks-for-automation)"
        in install_section
    )
    assert "hosted sharing" not in readme


def test_readme_links_llms_troubleshooting_context_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "[`llms.txt`](llms.txt)" in install_section
    assert "[`docs/llms.txt`](docs/llms.txt)" in install_section
    assert "AI/coding-agent troubleshooting context" in install_section
    assert "JSON CLI checks" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_demo_run_id_output_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace demo` prints a `Run ID:` line you can copy into "
        "`browsertrace show` or `browsertrace export`"
    ) in install_section
    assert "`browsertrace list` shows demo run IDs" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_merges_demo_list_local_check_bullets():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "- After `browsertrace demo`, `browsertrace list` shows demo run IDs "
        "with timestamps and status, so you can choose a run to open or export."
    ) in install_section
    assert install_section.count("`browsertrace list` shows") == 1
    assert "hosted sharing" not in readme


def test_readme_explains_demo_needs_no_api_keys_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace demo` runs without API keys or external services" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_no_api_demo_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The deterministic no-API demo creates a trace without a browser, "
        "network, or API key"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_no_signup_trial_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The local trial requires no signup, cloud account, or hosted browser "
        "service"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_links_first_run_feedback_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "First-run feedback after `browsertrace demo`" in install_section
    assert "https://github.com/aaronlab/browsertrace/issues/3" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_launch_discussion_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "Workflow discussion after `browsertrace demo`" in install_section
    assert "https://github.com/aaronlab/browsertrace/discussions/6" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_example_matrix_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#example-matrix" in install_section
    assert "choose another runnable demo after `browsertrace demo`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_no_service_examples_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "The example matrix lists no-service examples" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_includes_browser_use_no_service_demo_expected_output():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "python examples/browser_use_callback_demo.py" in install_section
    assert "python examples/browser_use_run_hooks_demo.py" in install_section
    assert "demo: browser-use callback flow" in install_section
    assert "demo: browser-use run hooks flow" in install_section
    assert "browsertrace show <run_id>" in install_section
    assert "search_google(query=BrowserTrace)" in install_section
    assert "click(selector=#result-1)" in install_section
    assert "stars" not in install_section.lower()
    assert "upvotes" not in install_section.lower()


def test_readme_links_recent_runs_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#show-only-recent-runs" in install_section
    assert "`browsertrace list --limit 5` narrows recent runs" in install_section
    assert "before choosing one to inspect or export" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_run_id_prefix_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "examples/#run-id-prefixes-for-export" in install_section
    assert "A longer run ID prefix fixes ambiguous" in install_section
    assert "`browsertrace show` or `browsertrace export` matches" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_show_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace show <run_id>` inspects a listed run" in install_section
    assert "from the terminal" in install_section
    assert "action labels, status, and errors" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_show_json_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace show <run_id> --json` prints one run as JSON" in install_section
    assert "run details and step actions" in install_section
    assert "`browsertrace list --json`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_public_safe_export_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace export <run_id> --public -o public.html` creates a "
        "public-safe, self-contained HTML report"
    ) in install_section
    assert "from a listed run" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_public_safe_export_privacy_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "Public-safe export omits model I/O, screenshots, and URLs" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_redact_export_distinction_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`--redact` only omits model I/O, while `--public` also omits "
        "screenshots and URLs"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_self_contained_export_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace export <run_id> --public -o public.html` creates a "
        "public-safe, self-contained HTML report"
    ) in install_section
    assert "you can attach to a bug report or issue" in install_section
    assert "Public-safe export omits model I/O, screenshots, and URLs" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_export_output_path_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`-o public.html` chooses the export filename; without `-o`, "
        "`browsertrace export` writes `<run_id>.html`"
    ) in install_section
    assert "`browsertrace export <run_id> --public -o public.html`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_export_success_output_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace export` prints `Wrote <path>` after writing the HTML file"
    ) in install_section
    assert "`browsertrace export <run_id> --public -o public.html`" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_port_override_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`BROWSERTRACE_PORT=3001 browsertrace` starts the local UI on another port"
        in install_section
    )
    assert "when 3000 is busy" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_localhost_ui_binding_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The local UI binds to `127.0.0.1` by default; `BROWSERTRACE_PORT` "
        "changes only the port"
    ) in install_section
    assert "http://127.0.0.1:3000" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_local_ui_url_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "After `browsertrace` starts the local UI, open "
        "`http://127.0.0.1:3000` and inspect the demo run"
    ) in install_section
    assert (
        "`browsertrace` prints `BrowserTrace UI: http://127.0.0.1:<port>` "
        "when the local server starts"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_demo_run_title_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "The demo run is named "
        "`demo: Browser Use local HTML upload navigation failure` "
        "in the local UI"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_isolated_trace_storage_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`BROWSERTRACE_HOME=/tmp/browsertrace-demo browsertrace demo` writes "
        "demo traces to an isolated trace store"
    ) in install_section
    assert (
        "By default, BrowserTrace stores local traces under `~/.browsertrace/`; "
        "set `BROWSERTRACE_HOME` to use an isolated trace store"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_windows_trace_home_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        'Windows PowerShell users can set `$env:BROWSERTRACE_HOME = '
        '"$env:TEMP\\browsertrace-demo"` before running BrowserTrace commands'
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "https://pypi.org/project/browsertrace/" in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_cli_help_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace --help` lists local CLI commands and options" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_explains_export_help_near_install_tag():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert (
        "`browsertrace export --help` lists export options before creating a "
        "public-safe HTML report"
    ) in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_groups_install_tips_as_compact_list():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "Useful local checks:" in install_section
    for tip in [
        "- `browsertrace doctor` is a safe local status check",
        "- `browsertrace doctor --json` prints install and trace-store status as JSON",
        "- The healthy doctor output recipe shows expected `Home:`, `Database:`, `Runs:`, and `UI dependencies:` status lines",
        "- `browsertrace demo` runs without API keys or external services",
        "- After `browsertrace demo`, `browsertrace list` shows demo run IDs with timestamps and status",
        "- `browsertrace list --json` prints recent runs as JSON",
        "- `browsertrace list --status failed` filters recent runs by status",
        "- `browsertrace demo` prints a `Run ID:` line",
        "- `browsertrace compare <failed_run_id> <success_run_id>` finds the first step divergence between a failed Browser Use run and a known-good run",
        "- The first-run troubleshooting checklist walks through `browsertrace doctor`, `browsertrace demo`, `browsertrace list`, `browsertrace show`, and public-safe export",
        "- The live static demo and public-safe demo export let you inspect a trace before installing anything",
        "- The command cheat sheet summarizes `browsertrace doctor`, `browsertrace demo`, `browsertrace list`, `browsertrace show`, and public-safe export commands",
        "- The v0.1.19 release notes summarize what changed in the current release",
        "- The PyPI package page is the canonical package listing after publishing",
        "- `uvx` can run the PyPI package without a persistent install, and `pip install` is the persistent install path",
        "- Install `[ui]` for the local web UI; SDK-only installs are enough for trace capture integrations and terminal commands like `browsertrace list`, `browsertrace show`, and `browsertrace export",
        "- The PyPI install path requires Python 3.11+",
        "- The deterministic no-API demo creates a trace without a browser, network, or API key",
        "- The local trial requires no signup, cloud account, or hosted browser service",
        "- First-run feedback after `browsertrace demo`: https://github.com/aaronlab/browsertrace/issues/3",
        "- Workflow discussion after `browsertrace demo`: https://github.com/aaronlab/browsertrace/discussions/6",
        "- Use the [example matrix](examples/#example-matrix) to choose another runnable demo after `browsertrace demo`",
        "- The example matrix lists no-service examples",
        "- `browsertrace list --limit 5` narrows recent runs before choosing one to inspect or export",
        "- A longer run ID prefix fixes ambiguous `browsertrace show` or `browsertrace export` matches",
        "- `browsertrace show <run_id>` inspects a listed run from the terminal and prints its step timeline with action labels, status, and errors",
        "- `browsertrace show <run_id> --json` prints one run as JSON",
        "- `browsertrace export <run_id> --public -o public.html` creates a public-safe, self-contained HTML report",
        "- `-o public.html` chooses the export filename",
        "- `browsertrace export` prints `Wrote <path>`",
        "- Public-safe export omits model I/O, screenshots, and URLs",
        "- `--redact` only omits model I/O, while `--public` also omits screenshots and URLs",
        "- `BROWSERTRACE_PORT=3001 browsertrace` starts the local UI on another port",
        "- The local UI binds to `127.0.0.1` by default",
        "- After `browsertrace` starts the local UI, open `http://127.0.0.1:3000` and inspect the demo run",
        "- `browsertrace` prints `BrowserTrace UI: http://127.0.0.1:<port>` when the local server starts",
        "- The demo run is named `demo: Browser Use local HTML upload navigation failure` in the local UI",
        "- `BROWSERTRACE_HOME=/tmp/browsertrace-demo browsertrace demo` writes demo traces to an isolated trace store",
        "- By default, BrowserTrace stores local traces under `~/.browsertrace/`; set `BROWSERTRACE_HOME` to use an isolated trace store",
        '- Windows PowerShell users can set `$env:BROWSERTRACE_HOME = "$env:TEMP\\browsertrace-demo"` before running BrowserTrace commands',
        "- `browsertrace --help` lists local CLI commands and options",
        "- `browsertrace export --help` lists export options before creating a public-safe HTML report",
    ]:
        assert tip in install_section

    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_links_browser_use_debugging_guide():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in readme
    assert "Browser Use callback compatibility" in readme
    assert "register_new_step_callback" in readme
    assert "create_run_hooks" in readme
    assert "agent.run(on_step_start=hooks.on_step_start" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_stagehand_debugging_guide():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "https://aaronlab.github.io/browsertrace/stagehand-debugging.html" in readme
    assert "Stagehand `act` and `extract` debugging" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_skyvern_debugging_guide():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "https://aaronlab.github.io/browsertrace/skyvern-debugging.html" in readme
    assert "Skyvern task and workflow debugging" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_playwright_llm_debugging_guide():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html" in readme
    assert "prompt, DOM, selector, retry, and error fields" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_integrations_overview():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "https://aaronlab.github.io/browsertrace/integrations.html" in readme
    assert "Browser Use, Stagehand, Skyvern, and Playwright guide paths" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_try_it_row_links_direct_integration_guides():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    match = re.search(
        r"\*\*Try it:\*\* (?P<links>.*?)\n\nFor AI/coding agents",
        readme,
        re.S,
    )

    assert match is not None
    try_it_links = match.group("links")
    assert (
        "[Browser Use guide](https://aaronlab.github.io/browsertrace/browser-use-debugging.html)"
        in try_it_links
    )
    assert (
        "[Stagehand guide](https://aaronlab.github.io/browsertrace/stagehand-debugging.html)"
        in try_it_links
    )
    assert (
        "[Skyvern guide](https://aaronlab.github.io/browsertrace/skyvern-debugging.html)"
        in try_it_links
    )
    assert (
        "[Playwright + LLM guide](https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html)"
        in try_it_links
    )
    assert "[live demo](https://aaronlab.github.io/browsertrace/)" in try_it_links
    assert (
        "[integrations](https://aaronlab.github.io/browsertrace/integrations.html)"
        in try_it_links
    )
    assert "stars" not in try_it_links.lower()
    assert "upvotes" not in try_it_links.lower()
    assert "reposts" not in try_it_links.lower()


def test_readme_links_adapter_request_near_integrations():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert (
        "https://github.com/aaronlab/browsertrace/issues/new?template=integration_request.yml"
        in readme
    )
    assert "Browser Use, Stagehand, Skyvern, or Playwright adapter requests" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_comparison_guide_with_named_text():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert (
        "[browser-agent debugging comparison](https://aaronlab.github.io/browsertrace/compare-browser-agent-debugging.html)"
        in readme
    )
    assert "LLM tracing" in readme
    assert "hosted browser/runtime tools" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_llms_txt_for_ai_coding_agents():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "[`llms.txt`](llms.txt)" in readme
    assert "[`docs/llms.txt`](docs/llms.txt)" in readme
    assert "AI/coding agents" in readme
    assert "concise project context" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_examples_command_cheat_sheet():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#browsertrace-command-cheat-sheet" in readme
    assert "command cheat sheet" in readme
    assert "browsertrace doctor" in readme
    assert "browsertrace demo" in readme
    assert "browsertrace list" in readme
    assert "browsertrace show" in readme
    assert "public-safe export" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_example_matrix():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#example-matrix" in readme
    assert "no-service examples" in readme
    assert "commands" in readme
    assert "runnable demo" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_first_run_troubleshooting_checklist():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#first-run-troubleshooting-checklist" in readme
    assert "first-run troubleshooting checklist" in readme
    assert "browsertrace doctor" in readme
    assert "browsertrace demo" in readme
    assert "browsertrace list" in readme
    assert "browsertrace show" in readme
    assert "public-safe export" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_doctor_output_example():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#check-a-healthy-local-install" in readme
    assert "healthy `browsertrace doctor` output" in readme
    assert "Home:" in readme
    assert "Database:" in readme
    assert "Runs:" in readme
    assert "UI dependencies:" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_public_safe_attachment_note():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#attach-a-public-safe-export-to-an-issue" in readme
    assert "public-safe export" in readme
    assert "omits prompt/model I/O, screenshots, and URLs" in readme
    assert "GitHub issue or PR comment" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_share_safe_export_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#creating-a-share-safe-export" in readme
    assert "browsertrace export <run_id> --public -o public.html" in readme
    assert "omits prompt/model I/O, screenshots, and URLs" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_github_actions_public_export_artifact_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#github-actions-artifact-for-public-safe-exports" in readme
    assert "GitHub Actions artifact" in readme
    assert "public.html" in readme
    assert "BrowserTrace does not upload traces by itself" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_gitlab_ci_public_export_artifact_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#gitlab-ci-artifact-for-public-safe-exports" in readme
    assert "GitLab CI artifact" in readme
    assert "public.html" in readme
    assert "BrowserTrace does not upload traces by itself" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_isolated_trace_storage_testing_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#testing-with-isolated-trace-storage" in readme
    assert "isolated trace storage" in readme
    assert "BROWSERTRACE_HOME" in readme
    assert "temp directory" in readme
    assert "pytest" in readme
    assert "no browser, network, or API key" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_trace_storage_location_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#where-traces-are-stored" in readme
    assert "~/.browsertrace/" in readme
    assert "BROWSERTRACE_HOME" in readme
    assert "local traces" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_playwright_sync_snapshot_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#playwright-sync-api-snapshot" in readme
    assert "snapshot_sync" in readme
    assert "sync Playwright" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_environment_variable_quick_reference():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#environment-variable-quick-reference" in readme
    assert "environment variable quick reference" in readme
    assert "BROWSERTRACE_HOME" in readme
    assert "BROWSERTRACE_PORT" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_cli_help_discovery_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#discover-cli-options" in readme
    assert "CLI help" in readme
    assert "browsertrace --help" in readme
    assert "browsertrace export --help" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_run_id_prefix_troubleshooting_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#run-id-prefixes-for-export" in readme
    assert "run ID prefix" in readme
    assert "browsertrace export <run_id>" in readme
    assert "longer unique prefix" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_failed_run_terminal_inspection_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#inspect-a-failed-run-in-the-terminal" in readme
    assert "failed step timeline" in readme
    assert "browsertrace show <run_id>" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_recent_runs_list_limit_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#show-only-recent-runs" in readme
    assert "recent runs" in readme
    assert "browsertrace list --limit 5" in readme
    assert "inspect or export" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_demo_run_lookup_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#finding-your-demo-run" in readme
    assert "browsertrace list" in readme
    assert "run IDs" in readme
    assert "timestamps" in readme
    assert "status" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_readme_links_port_already_in_use_recipe():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()

    assert "examples/#port-already-in-use" in readme
    assert "port already in use" in readme
    assert "local UI port" in readme
    assert "BROWSERTRACE_PORT" in readme
    assert 'pip install "browsertrace[ui]"' in readme
    assert "hosted sharing" not in readme


def test_examples_readme_includes_windows_public_safe_export_flow():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "## Public Export Flow" in examples_readme
    assert (
        "```powershell\n"
        "browsertrace demo\n"
        "browsertrace list\n"
        "browsertrace export <run_id> --public -o public.html\n"
        "```"
    ) in examples_readme
    assert "`--public` omits prompts/model I/O, screenshots, and URLs" in examples_readme
    assert "BrowserTrace does not upload" in examples_readme


def test_examples_readme_includes_export_run_id_prefix_troubleshooting():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Run ID Prefixes For Export" in examples_readme
    assert "browsertrace list" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert "unique prefix" in examples_readme
    assert "copy more characters" in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_browsertrace_show_failed_run_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Inspect a failed run in the terminal" in examples_readme
    assert "browsertrace show <run_id>" in examples_readme
    assert "browsertrace list" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert "failed step" in examples_readme


def test_examples_readme_includes_list_limit_recent_runs_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Show only recent runs" in examples_readme
    assert "browsertrace list --limit 5" in examples_readme
    assert "most recent runs" in examples_readme
    assert "browsertrace show <run_id>" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_doctor_output_example():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Check a healthy local install" in examples_readme
    assert "browsertrace doctor" in examples_readme
    assert "BrowserTrace doctor" in examples_readme
    assert "Home:" in examples_readme
    assert "Database:" in examples_readme
    assert "Runs:" in examples_readme
    assert "UI dependencies:" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_cli_help_discovery_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Discover CLI options" in examples_readme
    assert "browsertrace --help" in examples_readme
    assert "browsertrace export --help" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "### Stack-specific debugging guides" in examples_readme
    for guide in stack_guides:
        assert guide in examples_readme
    assert "stars" not in examples_readme.lower()
    assert "upvotes" not in examples_readme.lower()
    assert "reposts" not in examples_readme.lower()


def test_examples_readme_includes_environment_variable_quick_reference():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Environment variable quick reference" in examples_readme
    assert "`BROWSERTRACE_HOME`" in examples_readme
    assert "`BROWSERTRACE_PORT`" in examples_readme
    assert "changes the trace store" in examples_readme
    assert "changes the local UI port" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_public_safe_attachment_note():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Attach a public-safe export to an issue" in examples_readme
    assert "public.html" in examples_readme
    assert "GitHub issue or PR comment" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert "prompt/model I/O, screenshots, and URLs" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_first_run_troubleshooting_checklist():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### First-run troubleshooting checklist" in examples_readme
    assert "browsertrace doctor" in examples_readme
    assert "browsertrace demo" in examples_readme
    assert "browsertrace list" in examples_readme
    assert "browsertrace show <run_id>" in examples_readme
    assert "browsertrace export <run_id> --public -o public.html" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_json_cli_checks_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    troubleshooting_section = examples_readme.split("## Troubleshooting", 1)[1].split(
        "### Environment variable quick reference", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert "### JSON CLI checks for automation" in troubleshooting_section
    assert "scripts, CI, or AI/coding-agent troubleshooting" in troubleshooting_section
    assert recipe in troubleshooting_section
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_links_llms_troubleshooting_context():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    troubleshooting_section = examples_readme.split("## Troubleshooting", 1)[1].split(
        "### Environment variable quick reference", 1
    )[0]

    assert "[`docs/llms.txt`](../docs/llms.txt)" in troubleshooting_section
    assert "AI/coding-agent troubleshooting context" in troubleshooting_section
    assert "JSON CLI checks" in troubleshooting_section
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_command_cheat_sheet():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### BrowserTrace command cheat sheet" in examples_readme
    assert "| Command | Use when |" in examples_readme
    assert "`browsertrace doctor`" in examples_readme
    assert "`browsertrace demo`" in examples_readme
    assert "`browsertrace list`" in examples_readme
    assert "`browsertrace show <run_id>`" in examples_readme
    assert "`browsertrace compare <failed_run_id> <success_run_id>`" in examples_readme
    assert "`browsertrace export <run_id> --public -o public.html`" in examples_readme
    assert 'pip install "browsertrace[ui]"' in examples_readme
    assert "hosted sharing" not in examples_readme


def test_examples_readme_includes_pytest_isolated_storage_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Testing with isolated trace storage" in examples_readme
    assert "def test_browsertrace_trace_uses_temp_store" in examples_readme
    assert 'monkeypatch.setenv("BROWSERTRACE_HOME", str(tmp_path))' in examples_readme
    assert "Tracer()" in examples_readme
    assert "no browser, network, or API key" in " ".join(examples_readme.split())


def test_examples_readme_includes_github_actions_public_export_artifact_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### GitHub Actions artifact for public-safe exports" in examples_readme
    assert "actions/upload-artifact@v4" in examples_readme
    assert (
        "RUN_ID=$(browsertrace demo | awk -F': ' '/Run ID:/ {print $2}')"
        in examples_readme
    )
    assert 'browsertrace export "$RUN_ID" --public -o public.html' in examples_readme
    assert "BrowserTrace does not upload traces by itself" in examples_readme
    assert (
        "browsertrace[ui]"
        in examples_readme
    )


def test_examples_readme_includes_gitlab_ci_public_export_artifact_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### GitLab CI artifact for public-safe exports" in examples_readme
    assert "browsertrace-public-export:" in examples_readme
    assert (
        "RUN_ID=$(browsertrace demo | awk -F': ' '/Run ID:/ {print $2}')"
        in examples_readme
    )
    assert 'browsertrace export "$RUN_ID" --public -o public.html' in examples_readme
    assert "artifacts:" in examples_readme
    assert "public.html" in examples_readme
    assert "BrowserTrace does not upload traces by itself" in examples_readme


def test_examples_readme_includes_playwright_sync_snapshot_recipe():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()

    assert "### Playwright sync API snapshot" in examples_readme
    assert "from playwright.sync_api import sync_playwright" in examples_readme
    assert "run.snapshot_sync(page, action=\"opened example.com\")" in examples_readme
    assert "sync Playwright" in examples_readme


def test_examples_readme_links_browser_use_run_hooks_guide():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    example_matrix = examples_readme.split("## Example Matrix", 1)[1].split(
        "For Playwright examples", 1
    )[0]

    assert "`browser_use_callback_demo.py`" in example_matrix
    assert "`browseruse_example.py`" in example_matrix
    assert "`agent.run(on_step_start=..., on_step_end=...)`" in example_matrix
    assert "`create_run_hooks`" in example_matrix
    assert (
        "[Browser Use debugging guide](https://aaronlab.github.io/browsertrace/browser-use-debugging.html)"
        in example_matrix
    )
    assert "Browser Use + LLM" in example_matrix


def test_examples_readme_documents_browser_use_run_hooks_expected_output():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    verification_section = examples_readme.split(
        "### Quick local verification for a no-service wrapper example", 1
    )[1].split("For Playwright examples", 1)[0]

    assert "python examples/browser_use_run_hooks_demo.py" in verification_section
    assert "no-service Browser Use-shaped run-hook demo" in verification_section
    assert "demo: browser-use run hooks flow" in verification_section
    assert "search_google(query=BrowserTrace)" in verification_section
    assert "click(selector=#result-1)" in verification_section
    assert "browsertrace list --limit 5" in verification_section
    assert "browsertrace show <run_id>" in verification_section


def test_examples_readme_documents_browser_use_callback_expected_output():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    verification_section = examples_readme.split(
        "### Quick local verification for a no-service wrapper example", 1
    )[1].split("For Playwright examples", 1)[0]

    assert "python examples/browser_use_callback_demo.py" in verification_section
    assert "no-service Browser Use-shaped callback demo" in verification_section
    assert "demo: browser-use callback flow" in verification_section
    assert "search_google(query=BrowserTrace)" in verification_section
    assert "click(selector=#result-1)" in verification_section
    assert "browsertrace list --limit 5" in verification_section
    assert "browsertrace show <run_id>" in verification_section


def test_examples_readme_links_stagehand_and_skyvern_guides_near_matrix():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    example_matrix = examples_readme.split("## Example Matrix", 1)[1].split(
        "For Playwright examples", 1
    )[0]

    assert (
        "| `stagehand_wrapper_example.py` | You want to see Stagehand-style `act` and `extract` calls recorded | None |"
        in example_matrix
    )
    assert (
        "| `skyvern_wrapper_example.py` | You want to see Skyvern-style task calls recorded | None |"
        in example_matrix
    )
    assert (
        "[Stagehand debugging guide](https://aaronlab.github.io/browsertrace/stagehand-debugging.html)"
        in example_matrix
    )
    assert (
        "[Skyvern debugging guide](https://aaronlab.github.io/browsertrace/skyvern-debugging.html)"
        in example_matrix
    )


def test_examples_readme_links_playwright_llm_and_computer_use_guides_near_matrix():
    project_root = Path(__file__).resolve().parents[1]
    examples_readme = (project_root / "examples" / "README.md").read_text()
    example_matrix = examples_readme.split("## Example Matrix", 1)[1].split(
        "For Playwright examples", 1
    )[0]

    assert (
        "| `playwright_llm_loop_example.py` | You want Playwright + LLM-shaped prompt, DOM, selector, retry, and failure fields without a browser | None |"
        in example_matrix
    )
    assert (
        "| `computer_use_loop_example.py` | You want a generic observe-decide-act computer-use trace | None |"
        in example_matrix
    )
    assert (
        "[Playwright + LLM debugging guide](https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html)"
        in example_matrix
    )
    assert (
        "[computer-use debugging guide](https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html)"
        in example_matrix
    )


def test_owner_profile_actions_mark_browsertrace_pin_complete():
    project_root = Path(__file__).resolve().parents[1]
    owner_docs = {
        "docs/launch/owner-next-actions.md": "Profile pin: completed",
        "docs/launch/owner-next-actions.zh-CN.md": "Profile pin：已完成",
        "docs/launch/owner-publish-queue.md": "Profile pin: completed",
    }

    for relpath, phrase in owner_docs.items():
        text = (project_root / relpath).read_text()
        assert phrase in text, relpath
        assert "aaronlab/browsertrace" in text, relpath
        assert "https://github.com/aaronlab/browsertrace/issues/24" not in text, relpath


def test_first_run_docs_include_doctor_command():
    project_root = Path(__file__).resolve().parents[1]
    docs_text = "\n".join(
        [
            (project_root / "README.md").read_text(),
            (project_root / "docs" / "llms.txt").read_text(),
        ]
    )

    assert "browsertrace doctor" in docs_text
    assert "Print local install and trace-store status" in docs_text


def test_readme_explains_doctor_json_near_install_checks():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    install_section = readme.split("## Install From PyPI", 1)[1].split(
        "For a walkthrough", 1
    )[0]

    assert "`browsertrace doctor --json` prints install and trace-store status as JSON" in install_section
    assert "database, run, step, and UI dependency fields" in install_section
    assert "`browsertrace doctor` is a safe local status check" in install_section
    assert 'pip install "browsertrace[ui]"' in install_section
    assert "hosted sharing" not in readme


def test_readme_first_run_notes_have_single_browsertrace_show_bullet():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    first_run_notes = readme.split("## Install From PyPI", 1)[1].split(
        "If install or demo startup fails", 1
    )[0]

    assert first_run_notes.count("- `browsertrace show <run_id>`") == 1
    assert "inspects a listed run from the terminal" in first_run_notes
    assert "prints its step timeline with action labels, status, and errors" in first_run_notes
    assert "- `browsertrace show <run_id> --json`" in first_run_notes


def test_readme_first_run_notes_have_single_public_export_bullet():
    project_root = Path(__file__).resolve().parents[1]
    readme = (project_root / "README.md").read_text()
    first_run_notes = readme.split("## Install From PyPI", 1)[1].split(
        "If install or demo startup fails", 1
    )[0]

    command = "`browsertrace export <run_id> --public -o public.html`"
    assert first_run_notes.count(f"- {command}") == 1
    assert "public-safe, self-contained HTML report" in first_run_notes
    assert "from a listed run that you can attach to a bug report or issue" in first_run_notes
    assert "- Public-safe export omits model I/O, screenshots, and URLs." in first_run_notes
    assert "- `--redact` only omits model I/O" in first_run_notes


def test_llms_txt_points_to_current_contribution_path():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Good first issue: https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in llms
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in llms
    assert "First PR Recipe" in llms
    assert "CONTRIBUTING.md#first-pr-recipe" in llms
    assert "first contribution small and reviewable" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()
    assert "reposts" not in llms.lower()
    assert (
        "Integration request: https://github.com/aaronlab/browsertrace/issues/new?template=integration_request.yml"
        in llms
    )


def test_root_llms_txt_matches_hosted_llms_txt():
    project_root = Path(__file__).resolve().parents[1]

    assert (project_root / "llms.txt").read_text() == (
        project_root / "docs" / "llms.txt"
    ).read_text()


def test_llms_txt_leads_with_browser_use_first_positioning():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    intro = llms.split("## Important Links", 1)[0]
    positioning = llms.split("## Positioning", 1)[1]

    assert "local replay debugger for Browser Use failures" in intro
    assert "Use BrowserTrace first when a Browser Use agent fails" in intro
    assert "what the agent saw, clicked, returned" in intro
    assert "secondary integrations" in intro
    assert "Browser Use-first" in positioning
    assert "MIT-licensed local flight recorder for AI browser agents" not in intro
    assert "Use BrowserTrace when debugging Browser Use, Stagehand" not in intro
    assert "stars" not in intro.lower()
    assert "upvotes" not in intro.lower()
    assert "reposts" not in intro.lower()


def test_llms_txt_includes_troubleshooting_prompt_snippet():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "## Troubleshooting Prompt" in llms
    assert "browsertrace doctor" in llms
    assert "browsertrace demo" in llms
    assert "browsertrace list" in llms
    assert "browsertrace show <run_id>" in llms
    assert "browsertrace export <run_id> --public -o public.html" in llms
    assert "Good first issue: https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in llms
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in llms
    assert 'pip install "browsertrace[ui]"' in llms
    assert "hosted sharing" not in llms


def test_llms_txt_includes_browser_use_no_service_demo_expected_output():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "## Browser Use No-Service Demo Checks" in llms
    assert "python examples/browser_use_callback_demo.py" in llms
    assert "python examples/browser_use_run_hooks_demo.py" in llms
    assert "demo: browser-use callback flow" in llms
    assert "demo: browser-use run hooks flow" in llms
    assert "browsertrace show <run_id>" in llms
    assert "search_google(query=BrowserTrace)" in llms
    assert "click(selector=#result-1)" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_browser_use_icon_only_failure_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "## Known Failure Shapes" in llms
    assert (
        "Failure patterns page: https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html"
        in llms
    )
    assert "Browser Use icon-only target mismatch" in llms
    assert "tooltip text is not" in llms
    assert "candidate bounding boxes" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_browser_use_remote_cdp_failure_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Browser Use remote CDP hang" in llms
    assert "websocket still appears open" in llms
    assert "event-bus lock timing" in llms
    assert "CDP method, request id, start/end/duration" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_browser_use_new_tab_desync_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Browser Use new-tab desync" in llms
    assert "stale page context" in llms
    assert "`pages_before`" in llms
    assert "`pages_after`" in llms
    assert "`new_pages`" in llms
    assert "`recommended_next_action`" in llms
    assert "`switch_tab`" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_browser_use_local_html_upload_navigation_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Browser Use local HTML upload navigation" in llms
    assert "model-visible attachment" in llms
    assert "local filename/extension/MIME type" in llms
    assert "watchdog block reason" in llms
    assert "allowed-domains state" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_stagehand_custom_tool_replay_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Stagehand custom tool replay gap" in llms
    assert "replay contract" in llms
    assert "diagnostic trace contract" in llms
    assert "replay-safe" in llms
    assert "raw credentials" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_stagehand_semantic_verification_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Stagehand semantic verification boundary" in llms
    assert "inspectable action record" in llms
    assert "action proposal" in llms
    assert "candidate elements" in llms
    assert "verifier type" in llms
    assert "verification status/reason" in llms
    assert "executed, blocked, or escalated" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_skyvern_action_confidence_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Skyvern action confidence gap" in llms
    assert "confidence is diagnostic" in llms
    assert "authorized execution" in llms
    assert "action proposal" in llms
    assert "authorization decision" in llms
    assert "execution result" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_skyvern_vnc_cdp_debug_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Skyvern VNC/CDP debug integration" in llms
    assert "task, workflow, and step ids" in llms
    assert "VNC screenshot or" in llms
    assert "CDP DOM snapshot" in llms
    assert "frame/page id" in llms
    assert "retry or recovery decision" in llms
    assert "connection lifecycle events" in llms
    assert "redaction state" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_skyvern_multi_session_vnc_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Skyvern multi-session VNC control drift" in llms
    assert "VNC stream identity" in llms
    assert "CDP target identity" in llms
    assert "manual-control lease" in llms
    assert "display conflict" in llms
    assert "Take Control" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_playwright_artifact_boundary_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Playwright + LLM artifact boundary" in llms
    assert "base64 screenshots" in llms
    assert "typed image content block" in llms
    assert "artifact id, dimensions, digest, status, and error" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_computer_use_persistent_browser_recovery_shape():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "Computer-use persistent browser recovery" in llms
    assert "profile lock" in llms
    assert "CDP attach/probe" in llms
    assert "session_mode" in llms
    assert "recovery action" in llms
    assert "redacted profile id" in llms
    assert "stars" not in llms.lower()
    assert "upvotes" not in llms.lower()


def test_llms_txt_includes_json_cli_troubleshooting_snippet():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()
    troubleshooting_prompt = llms.split("## Troubleshooting Prompt", 1)[1].split(
        "## Positioning", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert "For scripts, CI, or AI/coding-agent troubleshooting" in troubleshooting_prompt
    assert recipe in troubleshooting_prompt
    assert "Good first issue: https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in llms
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in llms
    assert 'pip install "browsertrace[ui]"' in llms
    assert "hosted sharing" not in llms


def test_llms_txt_links_stack_guides_from_troubleshooting_prompt():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()
    troubleshooting_prompt = llms.split("## Troubleshooting Prompt", 1)[1].split(
        "## Positioning", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "Stack-specific troubleshooting links" in troubleshooting_prompt
    for guide in stack_guides:
        assert guide in troubleshooting_prompt
    assert "stars" not in troubleshooting_prompt.lower()
    assert "upvotes" not in troubleshooting_prompt.lower()
    assert "reposts" not in troubleshooting_prompt.lower()


def test_llms_txt_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    llms = (project_root / "docs" / "llms.txt").read_text()

    assert "## AOS Mapping Research" in llms
    research_note = llms.split("## AOS Mapping Research", 1)[1].split(
        "## Positioning", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_press_kit_includes_current_trial_and_contribution_paths():
    project_root = Path(__file__).resolve().parents[1]
    press_kit = (project_root / "docs" / "launch" / "press-kit.md").read_text()
    pypi_spec = (
        "browsertrace[ui]"
    )
    contribution_links = press_kit.split("## Contribution Links", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in press_kit
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in press_kit
    assert "Good first issue: https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in press_kit
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in press_kit
    assert "First PR Recipe" in contribution_links
    assert "first contribution small and reviewable" in contribution_links
    assert "stars" not in contribution_links.lower()
    assert "upvotes" not in contribution_links.lower()
    assert "reposts" not in contribution_links.lower()


def test_press_kit_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    press_kit = (project_root / "docs" / "launch" / "press-kit.md").read_text()
    guide_section = press_kit.split("## Stack-Specific Guides", 1)[1].split(
        "## Short Description", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "## Stack-Specific Guides" in press_kit
    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_press_kit_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    press_kit = (project_root / "docs" / "launch" / "press-kit.md").read_text()

    assert "## AOS Mapping Research" in press_kit
    research_note = press_kit.split("## AOS Mapping Research", 1)[1].split(
        "## Short Description", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_press_kit_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    press_kit = (project_root / "docs" / "launch" / "press-kit.md").read_text()
    assert "## Troubleshooting Reply" in press_kit
    reply = press_kit.split("## Troubleshooting Reply", 1)[1].split(
        "## Safe Ask", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "press/editorial follow-up, local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_core_guides_advertise_llms_txt():
    project_root = Path(__file__).resolve().parents[1]

    for filename in [
        "debug-browser-agent-failure.html",
        "browser-agent-failure-patterns.html",
        "browser-use-debugging.html",
        "stagehand-debugging.html",
        "skyvern-debugging.html",
        "playwright-llm-debugging.html",
        "computer-use-agent-debugging.html",
    ]:
        page = (project_root / "docs" / filename).read_text()
        assert (
            '<link rel="alternate" type="text/plain" title="llms.txt" href="./llms.txt">'
            in page
        ), filename


def test_browser_use_guide_has_troubleshooting_section():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Troubleshooting Browser Use traces" in page
    assert "Could not attach to this Agent" in page
    assert "register_new_step_callback" in page
    assert "No screenshots appear" in page
    assert "browsertrace export &lt;run_id&gt; --public -o public.html" in page


def test_browser_use_guide_documents_callback_compatibility():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Callback compatibility" in page
    assert "on_step_start" in page
    assert "on_step_end" in page
    assert "register_new_step_callback" in page
    assert "run-hook-only" in page
    assert "create_run_hooks" in page
    assert "agent.run(on_step_start=hooks.on_step_start" in page
    assert "examples/browser_use_run_hooks_demo.py" in page
    assert "without installing Browser Use" in page


def test_browser_use_guide_documents_no_service_demo_expected_output():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "examples/browser_use_callback_demo.py" in page
    assert "examples/browser_use_run_hooks_demo.py" in page
    assert "demo: browser-use callback flow" in page
    assert "demo: browser-use run hooks flow" in page
    assert "browsertrace list --limit 5" in page
    assert "browsertrace show &lt;run_id&gt;" in page
    assert "search_google(query=BrowserTrace)" in page
    assert "click(selector=#result-1)" in page


def test_browser_use_guide_documents_icon_only_click_targets():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Debug icon-only click targets" in page
    assert "visible-target versus accessible-target mismatch" in page
    assert "candidate bounding boxes" in page
    assert "aria-label=&quot;Create Test&quot;" in page
    assert "browser-use/browser-use#4801" in page


def test_browser_use_guide_documents_new_tab_desync():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Debug new-tab desync" in page
    assert "stale page context" in page
    assert "<code>pages_before</code>" in page
    assert "<code>pages_after</code>" in page
    assert "<code>new_pages</code>" in page
    assert "<code>switch_tab</code>" in page
    assert "browser topology change" in page
    assert "browser-use/browser-use#4758" in page


def test_browser_use_guide_documents_remote_cdp_hangs():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Debug remote CDP hangs" in page
    assert "websocket still looks connected" in page
    assert "event-bus lock timing" in page
    assert "CDP method, request id, start/end/duration" in page
    assert "browser-use/browser-use#4579" in page


def test_browser_use_guide_documents_empty_model_responses():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert "Debug empty model responses" in page
    assert "parser received no assistant JSON content at all" in page
    assert "finish_reason" in page
    assert "Raw assistant content length" in page
    assert "browser-use/browser-use#4786" in page


def test_browser_use_guide_documents_compare_run_metadata_checklist():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "browser-use-debugging.html").read_text()

    assert 'id="compare-run-metadata-checklist"' in page
    assert "Compare failed and successful Browser Use runs" in page
    assert "aaronlab/browsertrace/issues/369" in page

    section = page.split('id="compare-run-metadata-checklist"', 1)[1].split(
        "</section>",
        1,
    )[0]
    assert "browsertrace compare &lt;failed_run_id&gt; &lt;success_run_id&gt;" in section
    assert "first divergent step" in section

    for expected in [
        "stable task or run id",
        "Browser Use version",
        "BrowserTrace version",
        "model/provider",
        "prompt/template version",
        "URL/title/action summary",
        "selected element or target summary",
        "extracted content or final result summary",
        "error boundary for the first failed step",
    ]:
        assert expected in section

    assert "does not replace the local UI" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_stagehand_guide_documents_custom_tool_replay_gaps():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "stagehand-debugging.html").read_text()

    assert "Debug custom tool replay gaps" in page
    assert "replay contract" in page
    assert "diagnostic trace contract" in page
    assert "replay-safe" in page
    assert "raw credentials" in page
    assert "browserbase/stagehand#1558" in page


def test_stagehand_guide_documents_semantic_verification_boundaries():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "stagehand-debugging.html").read_text()

    assert "Debug semantic verification boundaries" in page
    assert "inspectable action boundary" in page
    assert "action proposal" in page
    assert "target evidence" in page
    assert "semantic endpoint evidence" in page
    assert "verification result" in page
    assert "executed, blocked, escalated" in page
    assert "browserbase/stagehand#1880" in page


def test_skyvern_guide_documents_action_confidence_authorization():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "skyvern-debugging.html").read_text()

    assert "Debug action confidence and authorization" in page
    assert "confidence is diagnostic" in page
    assert "authorized execution" in page
    assert "action proposal" in page
    assert "authorization decision" in page
    assert "execution result" in page
    assert "Skyvern-AI/skyvern#5637" in page


def test_skyvern_guide_documents_vnc_cdp_debug_integration():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "skyvern-debugging.html").read_text()

    assert "Debug VNC and CDP evidence together" in page
    assert "VNC visual debugging" in page
    assert "CDP browser-state capture" in page
    assert "connect/probe start" in page
    assert "VNC screenshot or recording artifact ids" in page
    assert "CDP DOM snapshot" in page
    assert "retry or recovery decision" in page
    assert "Skyvern-AI/skyvern#3260" in page


def test_skyvern_guide_documents_multi_session_vnc_control():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "skyvern-debugging.html").read_text()

    assert "Debug multi-session VNC and Take Control drift" in page
    assert "VNC stream identity" in page
    assert "CDP target identity" in page
    assert "manual-control lease" in page
    assert "display conflict" in page
    assert "Skyvern-AI/skyvern#4392" in page


def test_playwright_guide_documents_artifact_boundary():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "playwright-llm-debugging.html").read_text()

    assert "Keep browser artifacts out of long-term model context" in page
    assert "base64 screenshots" in page
    assert "typed image content block" in page
    assert "artifact id, dimensions, digest, status, and error" in page
    assert "browser artifact boundary" in page


def test_computer_use_guide_documents_persistent_browser_recovery():
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "docs" / "computer-use-agent-debugging.html").read_text()

    assert "Debug persistent browser session recovery" in page
    assert "profile lock" in page
    assert "CDP attach/probe" in page
    assert "session_mode" in page
    assert "recovery action" in page
    assert "redacted profile id" in page


def test_sitemap_exposes_llms_txt_and_core_discovery_pages():
    project_root = Path(__file__).resolve().parents[1]
    sitemap = (project_root / "docs" / "sitemap.xml").read_text()

    for path in [
        "",
        "llms.txt",
        "debug-browser-agent-failure.html",
        "browser-agent-failure-patterns.html",
        "browser-use-debugging.html",
        "stagehand-debugging.html",
        "skyvern-debugging.html",
        "playwright-llm-debugging.html",
        "computer-use-agent-debugging.html",
        "integrations.html",
        "launch/",
    ]:
        assert f"https://aaronlab.github.io/browsertrace/{path}" in sitemap, path


def test_public_html_pages_have_open_graph_urls():
    project_root = Path(__file__).resolve().parents[1]
    public_pages = {
        "docs/index.html": "https://aaronlab.github.io/browsertrace/",
        "docs/debug-browser-agent-failure.html": "https://aaronlab.github.io/browsertrace/debug-browser-agent-failure.html",
        "docs/integrations.html": "https://aaronlab.github.io/browsertrace/integrations.html",
        "docs/compare-browser-agent-debugging.html": "https://aaronlab.github.io/browsertrace/compare-browser-agent-debugging.html",
        "docs/browser-agent-failure-patterns.html": "https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html",
        "docs/browser-use-debugging.html": "https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "docs/stagehand-debugging.html": "https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "docs/skyvern-debugging.html": "https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "docs/playwright-llm-debugging.html": "https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "docs/computer-use-agent-debugging.html": "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
        "docs/trace.html": "https://aaronlab.github.io/browsertrace/trace.html",
        "docs/launch/index.html": "https://aaronlab.github.io/browsertrace/launch/",
    }

    for relpath, url in public_pages.items():
        page = (project_root / relpath).read_text()
        assert re.search(
            rf"<meta property=['\"]og:url['\"] content=['\"]{re.escape(url)}['\"]>",
            page,
        ), relpath


def test_sitemap_lastmod_matches_current_launch_refresh():
    project_root = Path(__file__).resolve().parents[1]
    sitemap = (project_root / "docs" / "sitemap.xml").read_text()
    root = ET.fromstring(sitemap)
    namespace = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    lastmod_by_url = {
        url.find("sm:loc", namespace).text: url.find("sm:lastmod", namespace).text
        for url in root.findall("sm:url", namespace)
    }

    for path in [
        "launch/",
        "launch/channel-copy.md",
        "launch/day-1-publish-packet.md",
        "launch/day-2-show-hn-packet.md",
        "launch/day-4-product-hunt-packet.md",
        "launch/owner-social-post-packet.md",
        "launch/owner-email-send-packet.md",
        "launch/owner-launch-submission-packet.md",
    ]:
        url = f"https://aaronlab.github.io/browsertrace/{path}"
        assert lastmod_by_url[url] == "2026-05-12", path

    assert "<lastmod>2026-05-09</lastmod>" not in sitemap


def test_sitemap_lastmod_tracks_recent_public_page_refreshes():
    project_root = Path(__file__).resolve().parents[1]
    sitemap = (project_root / "docs" / "sitemap.xml").read_text()
    root = ET.fromstring(sitemap)
    namespace = {"sm": "http://www.sitemaps.org/schemas/sitemap/0.9"}
    lastmod_by_url = {
        url.find("sm:loc", namespace).text: url.find("sm:lastmod", namespace).text
        for url in root.findall("sm:url", namespace)
    }

    for path in [
        "",
        "browser-use-debugging.html",
        "integrations.html",
    ]:
        url = f"https://aaronlab.github.io/browsertrace/{path}"
        assert lastmod_by_url[url] == "2026-05-12", path or "homepage"


def test_launch_copy_includes_pypi_trial_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"

    for relpath in [
        "docs/launch/channel-copy.md",
        "docs/launch/day-1-publish-packet.md",
        "docs/launch/day-2-show-hn-packet.md",
    ]:
        text = (project_root / relpath).read_text()
        assert f'uvx --from "{pypi_spec}" browsertrace doctor' in text, relpath
        assert f'uvx --from "{pypi_spec}" browsertrace demo' in text, relpath
        assert "pypi" in text.lower(), relpath


def test_owner_launch_copy_surfaces_failure_patterns_page():
    project_root = Path(__file__).resolve().parents[1]
    failure_patterns_url = (
        "https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html"
    )

    for relpath in [
        "docs/launch/channel-copy.md",
        "docs/launch/day-1-publish-packet.md",
        "docs/launch/day-2-show-hn-packet.md",
        "docs/launch/day-4-product-hunt-packet.md",
        "docs/launch/directory-submission-sheet.md",
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
        "docs/launch/owner-publish-queue.md",
    ]:
        text = (project_root / relpath).read_text()
        assert failure_patterns_url in text, relpath


def test_secondary_launch_materials_surface_failure_patterns_page():
    project_root = Path(__file__).resolve().parents[1]
    failure_patterns_url = (
        "https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html"
    )

    for relpath in [
        "docs/launch/press-kit.md",
        "docs/launch/outreach-targets.md",
        "docs/launch/day-3-targeted-communities-packet.md",
        "docs/launch/tutorial-post.md",
        "docs/launch/chinese-tutorial-post.md",
    ]:
        text = (project_root / relpath).read_text()
        assert failure_patterns_url in text, relpath


def test_x_launch_copy_fits_non_premium_post_limit():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()

    def text_blocks_between(start_heading: str, end_heading: str) -> list[str]:
        section = copy.split(start_heading, 1)[1].split(end_heading, 1)[0]
        return re.findall(r"```text\n(.*?)\n```", section, re.S)

    x_blocks = [
        *text_blocks_between("## X", "## X Follow-Up"),
        *text_blocks_between("## X Follow-Up", "## LinkedIn"),
    ]

    assert len(x_blocks) >= 2
    for block in x_blocks:
        assert len(block) <= 280, block


def test_product_hunt_launch_share_copy_fits_non_premium_post_limit():
    project_root = Path(__file__).resolve().parents[1]
    docs = [
        project_root / "docs" / "launch" / "channel-copy.md",
        project_root / "docs" / "launch" / "day-4-product-hunt-packet.md",
    ]

    for path in docs:
        copy = path.read_text()
        section = copy.split("Launch share post:", 1)[-1]
        section = section.split("## Reddit", 1)[0].split("## Reply Notes", 1)[0]
        blocks = re.findall(r"```text\n(.*?)\n```", section, re.S)

        assert blocks, path
        for block in blocks:
            if "Product Hunt" in block and "[Product Hunt link]" in block:
                assert len(block) <= 280, (path, block)


def test_longform_launch_posts_include_pypi_trial_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"

    for relpath in [
        "docs/launch/tutorial-post.md",
        "docs/launch/chinese-tutorial-post.md",
        "docs/launch/response-templates.md",
    ]:
        text = (project_root / relpath).read_text()
        assert f'uvx --from "{pypi_spec}" browsertrace doctor' in text, relpath
        assert f'uvx --from "{pypi_spec}" browsertrace demo' in text, relpath
        assert "pypi" in text.lower(), relpath


def test_response_templates_include_json_cli_diagnostics_reply():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert "local first-run issues, CI failures, or AI/coding-agent troubleshooting" in templates
    assert recipe in templates
    assert "workflow/debugging details" in templates
    assert "stars" not in templates.lower()
    assert "upvotes" not in templates.lower()
    assert "reposts" not in templates.lower()


def test_response_templates_include_listing_fit_reply():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Maintainer asks whether it fits this list" in templates
    reply = templates.split("## Maintainer asks whether it fits this list", 1)[
        1
    ].split("## Does it work with Browser Use?", 1)[0]

    assert "developer tools for Browser Use debugging" in reply
    assert "not an autonomous agent" in reply
    assert "not a hosted browser runtime" in reply
    assert "debugging, observability, browser automation tooling" in reply
    assert "Repo: https://github.com/aaronlab/browsertrace" in reply
    assert "Live demo: https://aaronlab.github.io/browsertrace/" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_include_stagehand_custom_tool_replay_reply():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Stagehand custom tools are skipped during replay" in templates
    reply = templates.split(
        "## Stagehand custom tools are skipped during replay", 1
    )[1].split("## Can I contribute a small fix?", 1)[0]

    assert "replay contract" in reply
    assert "diagnostic trace contract" in reply
    assert "replay-safe" in reply
    assert "redacted argument summary" in reply
    assert "raw credentials" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_link_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Stack-Specific Reply Links" in templates
    guide_section = templates.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Can I share traces with a teammate?", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_response_templates_include_aos_mapping_reply_note():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Does this map to OWASP AOS?" in templates
    reply = templates.split("## Does this map to OWASP AOS?", 1)[1].split(
        "## Can I share traces with a teammate?", 1
    )[0]

    assert "not an AOS compliance claim" in reply
    assert "tool request/result" in reply
    assert "step correlation" in reply
    assert "URI-style screenshot/video artifacts" in reply
    assert "URL metadata" in reply
    assert "model I/O summaries" in reply
    assert "explicit redaction state" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/237" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_include_skyvern_vnc_cdp_debug_reply():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Skyvern VNC and CDP debug integration" in templates
    reply = templates.split(
        "## Skyvern VNC and CDP debug integration", 1
    )[1].split("## Can I contribute a small fix?", 1)[0]

    assert "linked artifacts for the same step" in reply
    assert "VNC screenshot or recording artifact id" in reply
    assert "CDP DOM snapshot" in reply
    assert "connect/probe result" in reply
    assert "redaction state" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_include_persistent_browser_recovery_reply():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()

    assert "## Persistent browser recovery fails before screenshots" in templates
    reply = templates.split(
        "## Persistent browser recovery fails before screenshots", 1
    )[1].split("## Stack-Specific Reply Links", 1)[0]

    assert "session_mode" in reply
    assert "redacted profile id" in reply
    assert "profile lock" in reply
    assert "CDP attach/probe timing" in reply
    assert "recovery action" in reply
    assert "final connection state" in reply
    assert "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_link_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()
    assert "## Can I contribute a small fix?" in templates
    reply = templates.split("## Can I contribute a small fix?", 1)[1].split(
        "## Can you share JSON diagnostics?", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply
    assert "First PR Recipe" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_response_templates_link_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    templates = (
        project_root / "docs" / "launch" / "response-templates.md"
    ).read_text()
    reply = templates.split("## Can I contribute a small fix?", 1)[1].split(
        "## Can you share JSON diagnostics?", 1
    )[0]

    assert "SECURITY.md" in reply
    assert "security-sensitive reports" in reply
    assert "private trace data" in reply


def test_owner_publish_queue_includes_json_cli_reply_workflow():
    project_root = Path(__file__).resolve().parents[1]
    queue = (project_root / "docs" / "launch" / "owner-publish-queue.md").read_text()
    reply_workflow = queue.split("## Reply Workflow", 1)[1].split(
        "## Metrics Check", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply_workflow
    )
    assert recipe in reply_workflow
    assert "debugging/workflow details" in reply_workflow
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply_workflow
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply_workflow
    assert "First PR Recipe" in reply_workflow
    assert "CONTRIBUTING.md#first-pr-recipe" in reply_workflow
    assert "first contribution small and reviewable" in reply_workflow
    assert "stars" not in reply_workflow.lower()
    assert "upvotes" not in reply_workflow.lower()
    assert "reposts" not in reply_workflow.lower()


def test_owner_publish_queue_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    queue = (project_root / "docs" / "launch" / "owner-publish-queue.md").read_text()
    reply_workflow = queue.split("## Reply Workflow", 1)[1].split(
        "## Metrics Check", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply_workflow
    assert "security-sensitive reports or changes" in reply_workflow
    assert "private trace data" in reply_workflow


def test_owner_publish_queue_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    queue = (project_root / "docs" / "launch" / "owner-publish-queue.md").read_text()
    reply_workflow = queue.split("## Reply Workflow", 1)[1].split(
        "## Metrics Check", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "workflow-specific guide" in reply_workflow
    for guide in stack_guides:
        assert guide in reply_workflow
    assert "stars" not in reply_workflow.lower()
    assert "upvotes" not in reply_workflow.lower()
    assert "reposts" not in reply_workflow.lower()


def test_owner_publish_queue_includes_aos_mapping_reply_note():
    project_root = Path(__file__).resolve().parents[1]
    queue = (project_root / "docs" / "launch" / "owner-publish-queue.md").read_text()
    reply_workflow = queue.split("## Reply Workflow", 1)[1].split(
        "## Metrics Check", 1
    )[0]

    assert "AOS mapping research" in reply_workflow
    assert "not an AOS compliance claim" in reply_workflow
    assert "tool request/result" in reply_workflow
    assert "step correlation" in reply_workflow
    assert "URI-style screenshot/video artifacts" in reply_workflow
    assert "URL metadata" in reply_workflow
    assert "model I/O summaries" in reply_workflow
    assert "explicit redaction state" in reply_workflow
    assert "https://github.com/aaronlab/browsertrace/issues/237" in reply_workflow
    assert "stars" not in reply_workflow.lower()
    assert "upvotes" not in reply_workflow.lower()
    assert "reposts" not in reply_workflow.lower()


def test_owner_publish_queue_records_current_awesome_list_pr_count():
    project_root = Path(__file__).resolve().parents[1]
    queue = (project_root / "docs" / "launch" / "owner-publish-queue.md").read_text()
    queue_inline = " ".join(queue.split())

    assert "one focused PR is merged/listed" in queue_inline
    assert "Jenqyang/Awesome-AI-Agents#220" in queue
    assert "remaining focused PRs are open" in queue_inline
    assert "sixteen focused PRs are open" not in queue
    assert "the three prepared PRs" not in queue
    assert "ai-boost/awesome-harness-engineering#23" in queue
    assert "Agent-Tools/awesome-autonomous-web#21" in queue
    assert "e2b-dev/awesome-ai-sdks#187" in queue
    assert "jim-schwoebel/awesome_ai_agents#266" in queue
    assert "ranpox/awesome-computer-use#24" in queue
    assert "trycua/acu#26" in queue
    assert "Scottcjn/awesome-agents#16" in queue
    assert "browser-use/awesome-projects#6" in queue
    assert "danielrosehill/AI-Browser-Tools#1" in queue
    assert "clihub-ai/clihub#1" in queue
    assert "E2B CLA check has passed" in queue
    assert "steel-dev/awesome-web-agents#56" in queue


def test_owner_docs_mark_pypi_publish_complete():
    project_root = Path(__file__).resolve().parents[1]
    docs = [
        project_root / "docs" / "release" / "pypi-publishing.md",
        project_root / "docs" / "launch" / "owner-next-actions.md",
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md",
        project_root / "docs" / "launch" / "owner-publish-queue.md",
    ]

    for path in docs:
        text = path.read_text()
        assert "https://pypi.org/project/browsertrace/" in text
        assert "https://pypi.org/pypi/browsertrace/json" in text
        assert "HTTP 200" in text or "已发布" in text
        assert "0.1.19" in text


def test_day_1_publish_packet_includes_json_cli_reply_shortcut():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-1-publish-packet.md").read_text()
    reply_shortcuts = packet.split("## Reply Shortcuts", 1)[1].split(
        "## Day 1 Log", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply_shortcuts
    )
    assert recipe in reply_shortcuts
    assert "debugging/workflow details" in reply_shortcuts
    assert "`demo: Browser Use local HTML upload navigation failure`" in reply_shortcuts
    assert "failed checkout demo" not in reply_shortcuts
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply_shortcuts
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply_shortcuts
    assert "First PR Recipe" in reply_shortcuts
    assert "CONTRIBUTING.md#first-pr-recipe" in reply_shortcuts
    assert "first contribution small and reviewable" in reply_shortcuts
    assert "stars" not in reply_shortcuts.lower()
    assert "upvotes" not in reply_shortcuts.lower()
    assert "reposts" not in reply_shortcuts.lower()


def test_day_1_publish_packet_prioritizes_x_single_post_fallback():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-1-publish-packet.md").read_text()
    publish_order = packet.split("## Publish Order", 1)[1].split(
        "After each post", 1
    )[0]

    assert "X single-post fallback" in publish_order
    assert "docs/launch/owner-social-post-packet.md#single-post" in publish_order
    assert "only if you can stay online for replies" in publish_order
    assert "stars" not in publish_order.lower()
    assert "upvotes" not in publish_order.lower()
    assert "reposts" not in publish_order.lower()


def test_day_1_publish_packet_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-1-publish-packet.md").read_text()

    assert "## Stack-Specific Reply Links" in packet
    guide_section = packet.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Day 1 Log", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_day_1_publish_packet_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-1-publish-packet.md").read_text()
    reply_shortcuts = packet.split("## Reply Shortcuts", 1)[1].split(
        "## Day 1 Log", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply_shortcuts
    assert "security-sensitive reports or changes" in reply_shortcuts
    assert "private trace data" in reply_shortcuts


def test_day_3_targeted_communities_include_json_cli_reply_note():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "day-3-targeted-communities-packet.md"
    ).read_text()
    triage = packet.split("## Triage After Posting", 1)[1].split("## Stop Rules", 1)[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in triage
    )
    assert recipe in triage
    assert "debugging/workflow details" in triage
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in triage
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in triage
    assert "First PR Recipe" in triage
    assert "CONTRIBUTING.md#first-pr-recipe" in triage
    assert "first contribution small and reviewable" in triage
    assert "stars" not in triage.lower()
    assert "upvotes" not in triage.lower()
    assert "reposts" not in triage.lower()


def test_day_3_targeted_communities_link_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "day-3-targeted-communities-packet.md"
    ).read_text()

    assert "## Stack-Specific Reply Links" in packet
    guide_section = packet.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Stop Rules", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_day_3_targeted_communities_include_computer_use_recovery_angle():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "day-3-targeted-communities-packet.md"
    ).read_text()

    assert "## Custom Computer-Use Agents" in packet
    section = packet.split("## Custom Computer-Use Agents", 1)[1].split(
        "## Directories And Newsletters", 1
    )[0]

    assert "session_mode" in section
    assert "redacted profile id" in section
    assert "profile lock" in section
    assert "CDP attach/probe timing" in section
    assert "recovery action" in section
    assert "final connection state" in section
    assert "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_day_3_targeted_communities_tracks_directory_submission_queue():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "day-3-targeted-communities-packet.md"
    ).read_text()
    directories = packet.split("## Directories And Newsletters", 1)[1].split(
        "Pitch:", 1
    )[0]

    for target in [
        "AgentKart",
        "OSS AI Hub",
        "FOSSHUNTER",
        "AgentsTide",
        "AgentsIndex",
        "BuilderAI Tools",
        "CLIHunt",
        "DeepYard",
        "OpenAgent.bot",
        "ForgeIndex",
        "AgentShelf",
        "CLIs.dev",
        "DevTool Center",
        "ToolHunter",
        "ToolShelf",
        "AgDex",
        "console.dev",
    ]:
        assert target in directories

    assert "docs/launch/directory-submission-sheet.md" in directories
    assert "hello@agentstide.com" in directories
    assert "Observability and Monitoring" in directories
    assert "AI Observability & Evaluation" in directories
    assert "self-service live demo/PyPI trial" in directories
    assert "stars" not in directories.lower()
    assert "upvotes" not in directories.lower()
    assert "reposts" not in directories.lower()


def test_directory_submission_sheet_includes_pypi_trial_after_publish():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "pypi" in sheet.lower()
    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in sheet
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in sheet


def test_directory_submission_sheet_uses_browser_use_first_positioning():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "local replay debugger for Browser Use failures" in sheet
    assert "Replay failed Browser Use runs" in sheet
    assert "BrowserTrace: replay failed Browser Use runs locally" in sheet
    assert (
        "Stagehand, Skyvern, Playwright + LLM, and computer-use workflows are secondary integrations"
        in sheet
    )

    stale_phrases = [
        "Local flight recorder",
        "Replay failed AI browser-agent",
        "AI browser-agent failures",
        "AI browser-agent runs",
        "failed AI browser-agent runs",
        "local debugger for AI browser-agent",
        "local trace viewer for failed AI browser-agent",
    ]
    for phrase in stale_phrases:
        assert phrase not in sheet, phrase


def test_directory_submission_sheet_records_agentfirst_pr_submission():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "agentfirst.directory" in sheet
    assert "https://github.com/bradvin/agentfirst.directory/pull/30" in sheet
    assert "Submitted PR" in sheet


def test_directory_submission_sheet_records_agentsindex_owner_submission():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "AgentsIndex" in sheet
    assert "https://agentsindex.ai/submit" in sheet
    assert "owner sign-in" in sheet
    assert "Observability and Monitoring" in sheet
    assert "public-safe export" in sheet
    assert "stars" not in sheet.split("AgentsIndex:", 1)[1].split(
        "AgentKart:", 1
    )[0].lower()


def test_directory_submission_sheet_avoids_stale_awesome_list_pr_count():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "Jenqyang/Awesome-AI-Agents#220 is merged/listed" in sheet
    assert "remaining tracked PRs are open, including browser-use/awesome-projects#6" in sheet
    assert "e2b CLA passed" in sheet
    assert "12 PRs open" not in sheet
    assert "3 PRs open" not in sheet
    assert "github-awesome-list-submissions.md" in sheet


def test_directory_submission_sheet_records_current_directory_submission_blockers():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()

    for text in [sheet, targets]:
        assert "AgentKart" in text
        assert "Owner login likely required" in text
        assert "Submit Agent form asks for agent name, description, and GitHub repository" in text
        assert "skip if only runnable autonomous agents are accepted" in text
        assert "Agent Hub" in text
        assert "no visible submit/contact route" in text
        assert "AgDex" in text
        assert "owner-email pitch" in text
        if text == targets:
            assert "self-service live demo/PyPI trial" in text
        assert "agdex.ai@gmail.com" in text
        assert "OSS AI Hub" in text
        assert "JavaScript submission page" in text
        assert "quality, relevance, and community value" in text
        assert "AgentsTide" in text
        assert "Submit Free Listing" in text
        assert "hello@agentstide.com" in text
        assert "BuilderAI Tools" in text
        assert "Submit Tool for Review" in text
        assert "3 submissions per day" in text
        assert "AI Observability & Evaluation" in text
        assert "CLIHunt" in text
        assert "Other" in text
        assert "DeepYard" in text
        assert "Dev Tools" in text
        assert "OpenAgent.bot" in text
        assert "Tools" in text
        assert "ForgeIndex" in text
        assert "Local Agents & Automation" in text
        assert "AgentShelf" in text
        assert "Coding & Development" in text
        assert "CLIs.dev" in text
        assert "AI agents and automation" in text
        assert "DevTool Center" in text
        assert "Developer Tools" in text
        assert "ToolHunter" in text
        assert "open-source CLI" in text
        assert "ToolShelf" in text
        assert "Developer Productivity" in text


def test_directory_submission_sheet_includes_agdex_email_template():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "## AgDex Email Draft" in sheet
    agdex = sheet.split("## AgDex Email Draft", 1)[1].split(
        "## Contribution Reply", 1
    )[0]

    assert "To: agdex.ai@gmail.com" in agdex
    assert "Tool name: BrowserTrace" in agdex
    assert "Website URL: https://aaronlab.github.io/browsertrace/" in agdex
    assert "Category: Developer tools / observability" in agdex
    assert "Short description:" in agdex
    assert "Browser Use failures" in agdex
    assert "screenshot shows the" in agdex
    assert "tooltip" in agdex
    assert "remote-CDP Browser Use run" in agdex
    assert "secondary integrations" in agdex
    assert "Do not ask for stars" in agdex


def test_directory_submission_sheet_includes_console_dev_email_template():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "## console.dev Email Draft" in sheet
    console = sheet.split("## console.dev Email Draft", 1)[1].split(
        "## AgDex Email Draft", 1
    )[0]

    assert "To: hello@console.dev" in console
    assert "Subject: Devtools suggestion: BrowserTrace" in console
    assert "interesting and useful to developers" in console
    assert "regular-use developer tool" in console
    assert "self-service" in console
    assert "no signup or sales call" in console
    assert "not a sponsored review request" in console
    assert "BrowserTrace is an MIT-licensed local debugger" in console
    assert "A concrete failure case" in console
    assert "Browser Use agent can see the right plus icon" in console
    assert "failed-step evidence" in console
    assert "remote CDP" in console
    assert "Browser Use workflows" in console
    assert "secondary integrations" in console
    assert "Do not ask for stars" in console


def test_owner_short_checklists_surface_ready_email_submissions():
    project_root = Path(__file__).resolve().parents[1]

    for relpath, next_heading in [
        ("docs/launch/owner-next-actions.md", "## 1. PyPI Published"),
        ("docs/launch/owner-next-actions.zh-CN.md", "## 1. PyPI 已发布"),
    ]:
        text = (project_root / relpath).read_text()
        unblock = text.split("## 10", 1)[1].split(next_heading, 1)[0]

        assert "docs/launch/directory-submission-sheet.md" in unblock, relpath
        assert "docs/launch/owner-launch-submission-packet.md" in unblock, relpath
        assert "Show HN" in unblock, relpath
        assert "console.dev" in unblock, relpath
        assert "hello@console.dev" in unblock, relpath
        assert "AgDex" in unblock, relpath
        assert "agdex.ai@gmail.com" in unblock, relpath
        assert "AgentKart" in unblock, relpath
        assert "OSS AI Hub" in unblock, relpath
        assert "FOSSHUNTER" in unblock, relpath
        assert "AgentsTide" in unblock, relpath
        assert "BuilderAI Tools" in unblock, relpath
        assert "AI Observability & Evaluation" in unblock, relpath
        assert "hello@agentstide.com" in unblock, relpath
        assert "fresh-browser-use-debugging-angle" in unblock, relpath
        assert "fresh-chinese-computer-use-recovery-angle" in unblock, relpath
        assert "Browser Use" in unblock, relpath
        assert unblock.index("Show HN") < unblock.index("console.dev"), relpath
        assert "stars" not in unblock.lower(), relpath
        assert "upvotes" not in unblock.lower(), relpath


def test_owner_email_send_packet_is_short_and_linked():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "owner-email-send-packet.md"
    ).read_text()

    assert "To: hello@console.dev" in packet
    assert "Subject: Devtools suggestion: BrowserTrace" in packet
    assert "To: agdex.ai@gmail.com" in packet
    assert "Subject: Tool submission: BrowserTrace" in packet
    assert "https://github.com/aaronlab/browsertrace" in packet
    assert "https://aaronlab.github.io/browsertrace/" in packet
    assert "browser-agent-failure-patterns.html" in packet
    assert "Browser Use new-tab desync" in packet
    assert "Browser Use local HTML upload navigation" in packet
    assert "live demo now replays the local HTML upload navigation failure" in packet
    assert "file:///tmp/browsertrace-report.html" in packet
    assert "upload preview never appeared" in packet
    assert "secondary integrations" in packet
    assert "Stagehand" in packet
    assert "Skyvern" in packet
    assert "browsertrace-demo-public.html" in packet
    assert "Do not ask for stars" in packet
    assert "upvotes" not in packet.lower()

    for relpath in [
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
        "docs/launch/owner-publish-queue.md",
    ]:
        text = (project_root / relpath).read_text()
        assert "docs/launch/owner-email-send-packet.md" in text, relpath


def test_owner_social_post_packet_is_short_and_linked():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "owner-social-post-packet.md"
    ).read_text()

    assert "## X" in packet
    assert "### Single Post" in packet
    assert "Use this if you only have one minute" in packet
    assert "## LinkedIn" in packet
    assert "## WeChat Group" in packet
    assert "## Jike" in packet
    assert "docs/demo.mp4" in packet
    assert "https://github.com/aaronlab/browsertrace" in packet
    assert "https://aaronlab.github.io/browsertrace/" in packet
    assert "browser-agent-failure-patterns.html" in packet
    assert "Browser Use new-tab desync" in packet
    assert "Browser Use local HTML upload navigation" in packet
    assert "live demo now replays the local HTML upload navigation failure" in packet
    assert "file:///tmp/browsertrace-report.html" in packet
    assert "upload preview never appeared" in packet
    assert "secondary integrations" in packet
    assert "Stagehand" in packet
    assert "Skyvern" in packet
    assert "Do not ask for stars" in packet
    assert "upvotes" not in packet.lower()

    for relpath in [
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
        "docs/launch/owner-publish-queue.md",
    ]:
        text = (project_root / relpath).read_text()
        assert "docs/launch/owner-social-post-packet.md" in text, relpath


def test_owner_social_x_thread_fits_non_premium_post_limit():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "owner-social-post-packet.md"
    ).read_text()
    x_section = packet.split("## X", 1)[1].split("## LinkedIn", 1)[0]
    x_blocks = re.findall(r"```text\n(.*?)\n```", x_section, re.S)

    assert len(x_blocks) >= 2
    for block in x_blocks:
        assert len(block) <= 280, block


def test_owner_next_actions_surfaces_x_single_post_fallback():
    project_root = Path(__file__).resolve().parents[1]
    text = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    zh_text = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    normalized = re.sub(r"\s+", " ", text)
    zh_normalized = re.sub(r"\s+", " ", zh_text)

    assert "X single-post fallback" in text
    assert "Use the thread only if you have a few more minutes" in normalized
    assert "X single-post fallback" in zh_text
    assert "有多几分钟再发 thread" in zh_normalized


def test_owner_launch_submission_packet_is_short_and_linked():
    project_root = Path(__file__).resolve().parents[1]
    packet = (
        project_root / "docs" / "launch" / "owner-launch-submission-packet.md"
    ).read_text()

    assert "## Show HN" in packet
    assert "Show HN: BrowserTrace - replay Browser Use failures locally" in packet
    assert "## Product Hunt" in packet
    assert "Tagline:" in packet
    assert "Replay failed Browser Use runs" in packet
    assert "Maker comment:" in packet
    assert "https://github.com/aaronlab/browsertrace" in packet
    assert "https://aaronlab.github.io/browsertrace/" in packet
    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in packet
    assert "browser-agent-failure-patterns.html" in packet
    assert "Browser Use new-tab desync" in packet
    assert "local HTML upload navigation" in packet
    assert "remote CDP hangs" in packet
    assert "icon-only target mismatch" in packet
    assert "secondary integrations" in packet
    assert "Do not ask for votes" in packet
    assert "upvotes" not in packet.lower()

    for relpath in [
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
        "docs/launch/owner-publish-queue.md",
    ]:
        text = (project_root / relpath).read_text()
        assert "docs/launch/owner-launch-submission-packet.md" in text, relpath


def test_launch_monitoring_runbook_covers_current_targets():
    project_root = Path(__file__).resolve().parents[1]
    runbook = (project_root / "docs" / "launch" / "monitoring-runbook.md").read_text()
    launch = (project_root / "LAUNCH.md").read_text()

    assert "gh repo view aaronlab/browsertrace --json stargazerCount,forkCount,watchers,url,homepageUrl" in runbook
    assert "git status --short --branch" in runbook
    assert "gh run list --repo aaronlab/browsertrace --branch main --limit 8" in runbook
    assert "scripts/launch_metrics.py --append" in runbook
    assert "docs/launch/metrics-log.md" in runbook
    assert "jq null-safe" in runbook
    assert "SINCE_UTC" in runbook
    assert "fromdateiso8601" in runbook
    assert "gh search issues 'BrowserTrace'" in runbook
    assert "gh search prs 'BrowserTrace'" in runbook
    assert "gh search issues 'aaronlab/browsertrace'" in runbook
    assert '"\\\\bBrowserTrace\\\\b"' in runbook
    assert "--json repository,title,body,number,state,url,author,updatedAt,commentsCount,isPullRequest" in runbook
    assert "Do not use public search results as a reason to promote BrowserTrace" in runbook
    assert "2026-05-11T17:00:00Z" not in runbook

    for target in [
        "bradvin/agentfirst.directory#30",
        "e2b-dev/awesome-ai-sdks#187",
        "clihub-ai/clihub#1",
        "victorcheeney/clis#3",
        "browser-use/browser-use#4816",
        "browser-use/awesome-projects#6",
        "danielrosehill/AI-Browser-Tools#1",
        "browserbase/stagehand#2102",
        "Skyvern-AI/skyvern#5931",
        "Scottcjn/awesome-agents#16",
        "OWASP/www-project-agent-observability-standard#74",
        "tosin2013/helmdeck#117",
    ]:
        assert target in runbook

    assert "Do not hard-code a current good-first issue number" in runbook
    assert '--label "good first issue"' in runbook
    assert "pinnedIssues(first:6)" in runbook
    assert "agent-observability-standard|helmdeck" in runbook
    assert "## 5. Secondary Technical Threads" in runbook
    assert "closed good-first issue" in runbook
    assert "good%20first%20issue" in runbook
    assert "stale replacement issue" in runbook
    assert "aaronlab/browsertrace#345" not in runbook
    assert "aaronlab/browsertrace#349" not in runbook
    assert "aaronlab/browsertrace#350" not in runbook
    assert "aaronlab/browsertrace#335" not in runbook
    assert "aaronlab/browsertrace#333" not in runbook
    assert "aaronlab/browsertrace#331" not in runbook
    assert "aaronlab/browsertrace#329" not in runbook
    assert "aaronlab/browsertrace#322" not in runbook
    assert "aaronlab/browsertrace#324" not in runbook
    assert "aaronlab/browsertrace#326" not in runbook
    assert "aaronlab/browsertrace#328" not in runbook
    assert "aaronlab/browsertrace#320" not in runbook
    assert "aaronlab/browsertrace#316" not in runbook
    assert "aaronlab/browsertrace#317" not in runbook
    assert "aaronlab/browsertrace#319" not in runbook
    assert "aaronlab/browsertrace#270" not in runbook
    assert "aaronlab/browsertrace#307" not in runbook
    assert "aaronlab/browsertrace#344" not in runbook
    assert "docs/launch/monitoring-runbook.md" in launch


def test_directory_submission_sheet_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()
    assert "## Contribution Reply" in sheet
    contribution_reply = sheet.split("## Contribution Reply", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in contribution_reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contribution_reply
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "short claim window" in contribution_reply
    assert "`claimed` label" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_product_hunt_packet_includes_current_trial_and_contribution_paths():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = "browsertrace[ui]"
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()
    contributor_block = packet.split("Good first issue queue for contributors:", 1)[
        1
    ].split("Description:", 1)[0]

    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in packet
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in packet
    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in packet
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in packet
    assert "First PR Recipe" in contributor_block
    assert "CONTRIBUTING.md#first-pr-recipe" in contributor_block
    assert "first contribution small and reviewable" in contributor_block
    assert "stars" not in contributor_block.lower()
    assert "upvotes" not in contributor_block.lower()
    assert "reposts" not in contributor_block.lower()


def test_show_hn_packet_links_current_good_first_issue():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()
    contribution_reply = packet.split("Can I contribute a small fix?", 1)[
        1
    ].split("## Troubleshooting Reply", 1)[0]

    assert "good first issue queue" in packet
    assert "#213" not in packet
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_show_hn_packet_uses_concrete_browser_use_failure_shape():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()
    first_comment = packet.split("## First Comment Draft", 1)[1].split(
        "## Response Rules", 1
    )[0]

    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in packet
    assert "screenshot shows the right plus icon" in first_comment
    assert "tooltip text is not an" in first_comment
    assert "target evidence" in first_comment
    assert "local HTML" in first_comment
    assert "attachment context" in first_comment
    assert "watchdog block reason" in first_comment
    assert "Browser Use workflows" in first_comment
    assert "secondary integrations" in first_comment
    assert "stars" not in first_comment.lower()
    assert "upvotes" not in first_comment.lower()
    assert "reposts" not in first_comment.lower()


def test_show_hn_packet_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()

    assert "## Stack-Specific Reply Links" in packet
    guide_section = packet.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Likely Questions", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_show_hn_packet_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()

    assert "## AOS Mapping Research" in packet
    research_note = packet.split("## AOS Mapping Research", 1)[1].split(
        "## Likely Questions", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_product_hunt_packet_includes_json_cli_reply_note():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()
    reply_notes = packet.split("## Reply Notes", 1)[1].split("## Metrics", 1)[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply_notes
    )
    assert recipe in reply_notes
    assert "debugging/workflow details" in reply_notes
    assert "upvotes" not in reply_notes.lower()
    assert "reposts" not in reply_notes.lower()


def test_product_hunt_packet_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()

    assert "## Stack-Specific Reply Links" in packet
    guide_section = packet.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Metrics", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_product_hunt_packet_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()

    assert "## AOS Mapping Research" in packet
    research_note = packet.split("## AOS Mapping Research", 1)[1].split(
        "## Metrics", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_product_hunt_packet_uses_concrete_browser_use_failure_shape():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()
    maker_comment = packet.split("## Maker Comment", 1)[1].split(
        "## Launch Share Copy", 1
    )[0]

    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in packet
    assert "Browser Use agent saw the right plus icon" in maker_comment
    assert "tooltip text was not" in maker_comment
    assert "target evidence" in maker_comment
    assert "local HTML" in maker_comment
    assert "attachment metadata" in maker_comment
    assert "watchdog block reason" in maker_comment
    assert "Browser Use is the primary path" in maker_comment
    assert "secondary" in maker_comment
    assert "stars" not in maker_comment.lower()
    assert "upvotes" not in maker_comment.lower()
    assert "reposts" not in maker_comment.lower()


def test_product_hunt_packet_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-4-product-hunt-packet.md").read_text()
    reply_notes = packet.split("## Reply Notes", 1)[1].split("## Metrics", 1)[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply_notes
    assert "security-sensitive reports or changes" in reply_notes
    assert "private trace data" in reply_notes


def test_owner_launch_packets_include_media_alt_text():
    project_root = Path(__file__).resolve().parents[1]
    day_1 = (
        project_root / "docs" / "launch" / "day-1-publish-packet.md"
    ).read_text()
    owner_social = (
        project_root / "docs" / "launch" / "owner-social-post-packet.md"
    ).read_text()
    product_hunt = (
        project_root / "docs" / "launch" / "day-4-product-hunt-packet.md"
    ).read_text()

    for packet in [day_1, owner_social, product_hunt]:
        assert "## Media Alt Text" in packet
        section = packet.split("## Media Alt Text", 1)[1].split("##", 1)[0]
        assert "BrowserTrace timeline" in section
        assert "failed Browser Use run" in section
        assert "screenshot" in section
        assert "failed step" in section
        assert "stars" not in section.lower()
        assert "upvotes" not in section.lower()
        assert "reposts" not in section.lower()


def test_show_hn_packet_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()
    assert "## Troubleshooting Reply" in packet
    reply = packet.split("## Troubleshooting Reply", 1)[1].split("## Metrics", 1)[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "Show HN technical follow-up, local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "human-written" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_show_hn_packet_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    packet = (project_root / "docs" / "launch" / "day-2-show-hn-packet.md").read_text()
    reply = packet.split("## Troubleshooting Reply", 1)[1].split("## Metrics", 1)[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_channel_copy_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    assert "## Troubleshooting Reply" in copy
    reply = copy.split("## Troubleshooting Reply", 1)[1].split("## X", 1)[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_channel_copy_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()

    assert "## Stack-Specific Reply Links" in copy
    guide_section = copy.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Artifact Boundary Reply", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_channel_copy_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()

    assert "## AOS Mapping Research" in copy
    research_note = copy.split("## AOS Mapping Research", 1)[1].split(
        "## Artifact Boundary Reply", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_channel_copy_includes_fresh_browser_use_debugging_angle():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    section = copy.split("## Fresh Browser Use Debugging Angle", 1)[1].split(
        "## X", 1
    )[0]

    assert "visible-target vs accessible-target mismatch" in section
    assert "https://aaronlab.github.io/browsertrace/browser-use-debugging.html" in section
    assert 'aria-label="Create Test"' in section
    assert "candidate boxes" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_channel_copy_includes_fresh_computer_use_recovery_angle():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    section = copy.split(
        "## Fresh Computer-Use Persistent Browser Recovery Angle", 1
    )[1].split("## X", 1)[0]

    assert "Persistent browser failures often happen before any screenshot exists" in section
    assert "profile lock" in section
    assert "CDP attach/probe timing" in section
    assert "session_mode" in section
    assert "recovery action" in section
    assert (
        "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html"
        in section
    )
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_channel_copy_includes_fresh_chinese_computer_use_recovery_angle():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    section = copy.split(
        "## Fresh Chinese Computer-Use Recovery Angle", 1
    )[1].split("## X", 1)[0]

    assert "第一张截图之前" in section
    assert "profile lock" in section
    assert "session_mode" in section
    assert "redacted profile id" in section
    assert "CDP attach/probe timing" in section
    assert "recovery action" in section
    assert "final connection state" in section
    assert "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_channel_copy_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    reply = copy.split("## Troubleshooting Reply", 1)[1].split("## X", 1)[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_channel_copy_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    copy = (project_root / "docs" / "launch" / "channel-copy.md").read_text()
    assert "## Contribution Reply" in copy
    contribution_reply = copy.split("## Contribution Reply", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in contribution_reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contribution_reply
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_tutorial_post_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()
    assert "## Reply To Troubleshooting Questions" in tutorial
    reply = tutorial.split("## Reply To Troubleshooting Questions", 1)[1].split(
        "## Try it", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_tutorial_post_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()
    reply = tutorial.split("## Reply To Troubleshooting Questions", 1)[1].split(
        "## Try it", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_tutorial_post_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()

    assert "## Stack-Specific Reply Links" in tutorial
    guide_section = tutorial.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Try it", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_tutorial_post_includes_persistent_browser_recovery_section():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()

    assert "## When failure happens before screenshots" in tutorial
    section = tutorial.split("## When failure happens before screenshots", 1)[
        1
    ].split("## Record your own run", 1)[0]

    assert "profile lock" in section
    assert "session_mode" in section
    assert "redacted profile id" in section
    assert "CDP attach/probe timing" in section
    assert "recovery action" in section
    assert "final connection state" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_tutorial_post_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()

    assert "## AOS Mapping Research" in tutorial
    research_note = tutorial.split("## AOS Mapping Research", 1)[1].split(
        "## Try it", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_tutorial_post_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (project_root / "docs" / "launch" / "tutorial-post.md").read_text()
    assert "## Reply To Contribution Questions" in tutorial
    reply = tutorial.split("## Reply To Contribution Questions", 1)[1].split(
        "## Reply To Troubleshooting Questions", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply
    assert "First PR Recipe" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_tutorial_post_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()
    assert "## 回复本地首跑 / CI / agent 调试问题" in tutorial
    reply = tutorial.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## Links", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_tutorial_post_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()
    reply = tutorial.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## Links", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_chinese_tutorial_post_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()

    assert "## Stack 调试指南链接" in tutorial
    guide_section = tutorial.split("## Stack 调试指南链接", 1)[1].split(
        "## Links", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_chinese_tutorial_post_includes_persistent_browser_recovery_section():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()

    assert "## 有些失败发生在第一张截图之前" in tutorial
    section = tutorial.split("## 有些失败发生在第一张截图之前", 1)[1].split(
        "## 60 秒试一下", 1
    )[0]

    assert "profile lock" in section
    assert "session_mode" in section
    assert "redacted profile id" in section
    assert "CDP attach/probe timing" in section
    assert "recovery action" in section
    assert "final connection state" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_chinese_tutorial_post_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()

    assert "## AOS mapping research 回复" in tutorial
    research_note = tutorial.split("## AOS mapping research 回复", 1)[1].split(
        "## Links", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_chinese_tutorial_post_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    tutorial = (
        project_root / "docs" / "launch" / "chinese-tutorial-post.md"
    ).read_text()
    assert "## 回复小贡献问题" in tutorial
    reply = tutorial.split("## 回复小贡献问题", 1)[1].split(
        "## 回复本地首跑 / CI / agent 调试问题", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply
    assert "First PR Recipe" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_owner_next_actions_include_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    assert "## Reply To Troubleshooting Questions" in checklist
    reply = checklist.split("## Reply To Troubleshooting Questions", 1)[1].split(
        "## 8. Record Metrics After Each Action", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_owner_next_actions_link_stack_debugging_guides_for_owner_replies():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    fast_copy = checklist.split("Fast copy/paste blocks:", 1)[1].split(
        "## 1. PyPI Published", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "Stack-specific guide links" in fast_copy
    for guide in stack_guides:
        assert guide in fast_copy
    assert "stars" not in fast_copy.lower()
    assert "upvotes" not in fast_copy.lower()
    assert "reposts" not in fast_copy.lower()


def test_owner_next_actions_link_listing_fit_reply_template():
    project_root = Path(__file__).resolve().parents[1]
    expected = [
        ("docs/launch/owner-next-actions.md", "Fast copy/paste blocks:"),
        ("docs/launch/owner-next-actions.zh-CN.md", "快速复制入口："),
    ]

    for relpath, section_header in expected:
        checklist = (project_root / relpath).read_text(encoding="utf-8")
        fast_copy = checklist.split(section_header, 1)[1].split("## 1.", 1)[0]

        assert "docs/launch/response-templates.md#maintainer-asks-whether-it-fits-this-list" in fast_copy
        assert "stars" not in fast_copy.lower()
        assert "upvotes" not in fast_copy.lower()
        assert "reposts" not in fast_copy.lower()


def test_owner_next_actions_preserves_external_awesome_list_pr_numbers():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    awesome_prs = checklist.split(
        "## 7. Monitor High-Fit GitHub Awesome List PRs", 1
    )[1].split("## Reply To Contribution Questions", 1)[0]

    assert "angrykoala/awesome-browser-automation#112" in awesome_prs
    assert "mxschmitt/awesome-playwright#136" in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents#220" in awesome_prs
    assert "wjhou/awesome-computer-use-agents#2" in awesome_prs
    assert "cdxeve/awesome-computer-use-agents#2" in awesome_prs
    assert "steel-dev/awesome-web-agents#56" in awesome_prs
    assert "ai-boost/awesome-harness-engineering#23" in awesome_prs
    assert "Agent-Tools/awesome-autonomous-web#21" in awesome_prs
    assert "e2b-dev/awesome-ai-sdks#187" in awesome_prs
    assert "jim-schwoebel/awesome_ai_agents#266" in awesome_prs
    assert "ranpox/awesome-computer-use#24" in awesome_prs
    assert "trycua/acu#26" in awesome_prs
    assert "Scottcjn/awesome-agents#16" in awesome_prs
    assert "browser-use/awesome-projects#6" in awesome_prs
    assert "danielrosehill/AI-Browser-Tools#1" in awesome_prs
    assert "clihub-ai/clihub#1" in awesome_prs
    assert "victorcheeney/clis#3" in awesome_prs
    assert "E2B CLA check has passed" in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents#221" not in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents#222" not in awesome_prs


def test_chinese_owner_next_actions_preserves_external_awesome_list_pr_numbers():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    awesome_prs = checklist.split("已打开/已合并的 PR：", 1)[1].split(
        "目录/newsletter 跟踪 issue", 1
    )[0]

    assert "angrykoala/awesome-browser-automation/pull/112" in awesome_prs
    assert "mxschmitt/awesome-playwright/pull/136" in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents/pull/220" in awesome_prs
    assert "wjhou/awesome-computer-use-agents/pull/2" in awesome_prs
    assert "cdxeve/awesome-computer-use-agents/pull/2" in awesome_prs
    assert "steel-dev/awesome-web-agents/pull/56" in awesome_prs
    assert "ai-boost/awesome-harness-engineering/pull/23" in awesome_prs
    assert "Agent-Tools/awesome-autonomous-web/pull/21" in awesome_prs
    assert "e2b-dev/awesome-ai-sdks/pull/187" in awesome_prs
    assert "jim-schwoebel/awesome_ai_agents/pull/266" in awesome_prs
    assert "ranpox/awesome-computer-use/pull/24" in awesome_prs
    assert "trycua/acu/pull/26" in awesome_prs
    assert "Scottcjn/awesome-agents/pull/16" in awesome_prs
    assert "browser-use/awesome-projects/pull/6" in awesome_prs
    assert "danielrosehill/AI-Browser-Tools/pull/1" in awesome_prs
    assert "clihub-ai/clihub/pull/1" in awesome_prs
    assert "victorcheeney/clis/issues/3" in awesome_prs
    assert "CLA 已通过" in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents/pull/221" not in awesome_prs
    assert "Jenqyang/Awesome-AI-Agents/pull/222" not in awesome_prs


def test_chinese_owner_next_actions_summary_mentions_first_merged_listing():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    summary = checklist.split("最快的一条技术帖：", 1)[0]

    assert "Jenqyang/Awesome-AI-Agents#220" in summary
    assert "已合并" in summary
    assert "已收录" in summary
    assert "都还在 open" not in summary
    assert "还没有正式收录 BrowserTrace" not in summary


def test_owner_next_actions_link_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    reply = checklist.split("## Reply To Troubleshooting Questions", 1)[1].split(
        "## 8. Record Metrics After Each Action", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_owner_next_actions_link_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    assert "## Reply To Contribution Questions" in checklist
    reply = checklist.split("## Reply To Contribution Questions", 1)[1].split(
        "## Reply To Troubleshooting Questions", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply
    assert "First PR Recipe" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_owner_next_actions_set_good_first_issue_claim_window():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (project_root / "docs" / "launch" / "owner-next-actions.md").read_text()
    reply = checklist.split("## Reply To Contribution Questions", 1)[1].split(
        "## Reply To Troubleshooting Questions", 1
    )[0]

    assert "short claim window" in reply
    assert "before implementing it yourself" in reply
    assert "`claimed` label" in reply
    assert "already finished" in reply
    assert "good first issue label" in reply


def test_active_contribution_copy_uses_good_first_queue_after_claim():
    project_root = Path(__file__).resolve().parents[1]
    queue_url = "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue"

    for relpath in [
        "docs/launch/channel-copy.md",
        "docs/launch/day-1-publish-packet.md",
        "docs/launch/day-2-show-hn-packet.md",
        "docs/launch/day-4-product-hunt-packet.md",
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
        "docs/launch/response-templates.md",
    ]:
        text = (project_root / relpath).read_text()
        assert queue_url in text, relpath
        assert "https://github.com/aaronlab/browsertrace/issues/248" not in text, relpath
        assert "#248: Docs: add environment variable example values" not in text, relpath


def test_chinese_owner_next_actions_include_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    assert "## 回复本地首跑 / CI / agent 调试问题" in checklist
    reply = checklist.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## 7. 每做完一个动作就记录指标", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_owner_next_actions_link_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    reply = checklist.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## 7. 每做完一个动作就记录指标", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply


def test_chinese_owner_next_actions_link_stack_guides_for_troubleshooting_replies():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    reply = checklist.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## 7. 每做完一个动作就记录指标", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "Stack 调试指南链接" in reply
    for guide in stack_guides:
        assert guide in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_owner_next_actions_include_aos_mapping_reply_note():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    reply = checklist.split("## 回复本地首跑 / CI / agent 调试问题", 1)[1].split(
        "## 7. 每做完一个动作就记录指标", 1
    )[0]

    assert "AOS mapping research" in reply
    assert "not an AOS compliance claim" in reply
    assert "tool request/result" in reply
    assert "step correlation" in reply
    assert "URI-style screenshot/video artifacts" in reply
    assert "URL metadata" in reply
    assert "model I/O summaries" in reply
    assert "explicit redaction state" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/237" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_owner_next_actions_link_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    assert "## 回复小贡献问题" in checklist
    reply = checklist.split("## 回复小贡献问题", 1)[1].split(
        "## 回复本地首跑 / CI / agent 调试问题", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in reply
    assert "First PR Recipe" in reply
    assert "CONTRIBUTING.md#first-pr-recipe" in reply
    assert "first contribution small and reviewable" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_chinese_owner_next_actions_set_good_first_issue_claim_window():
    project_root = Path(__file__).resolve().parents[1]
    checklist = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    reply = checklist.split("## 回复小贡献问题", 1)[1].split(
        "## 回复本地首跑 / CI / agent 调试问题", 1
    )[0]

    assert "短的认领窗口" in reply
    assert "不要马上自己实现同一个 issue" in reply
    assert "`claimed` label" in reply
    assert "如果这个任务已经完成" in reply
    assert "当前 good first issue" in reply


def test_directory_submission_sheet_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()
    assert "## Troubleshooting Reply" in sheet
    reply = sheet.split("## Troubleshooting Reply", 1)[1].split("## Tracking", 1)[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_directory_submission_sheet_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "## Stack-Specific Reply Links" in sheet
    guide_section = sheet.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Tracking", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_directory_submission_sheet_includes_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    sheet = (project_root / "docs" / "launch" / "directory-submission-sheet.md").read_text()

    assert "## AOS Mapping Research" in sheet
    research_note = sheet.split("## AOS Mapping Research", 1)[1].split(
        "## Tracking", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_outreach_targets_include_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()
    assert "## Troubleshooting Reply" in targets
    reply = targets.split("## Troubleshooting Reply", 1)[1].split(
        "## First Targeted Community Posts", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_outreach_targets_link_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()

    assert "## Stack-Specific Reply Links" in targets
    guide_section = targets.split("## Stack-Specific Reply Links", 1)[1].split(
        "## First Targeted Community Posts", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_outreach_targets_include_aos_mapping_research_note():
    project_root = Path(__file__).resolve().parents[1]
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()

    assert "## AOS Mapping Research" in targets
    research_note = targets.split("## AOS Mapping Research", 1)[1].split(
        "## First Targeted Community Posts", 1
    )[0]

    assert "not an AOS compliance claim" in research_note
    assert "tool request/result" in research_note
    assert "step correlation" in research_note
    assert "URI-style screenshot/video artifacts" in research_note
    assert "URL metadata" in research_note
    assert "model I/O summaries" in research_note
    assert "explicit redaction state" in research_note
    assert "https://github.com/aaronlab/browsertrace/issues/237" in research_note
    assert "stars" not in research_note.lower()
    assert "upvotes" not in research_note.lower()
    assert "reposts" not in research_note.lower()


def test_outreach_targets_records_current_awesome_list_pr_count():
    project_root = Path(__file__).resolve().parents[1]
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()

    assert "One tracked PR is merged/listed" in targets
    assert "remaining focused PRs are open" in targets
    assert "Sixteen focused PRs are already open" not in targets
    assert "E2B CLA check has passed" in targets
    assert "Three focused PRs" not in targets
    assert "Do not open more list PRs unless the target is clearly high-fit" in targets


def test_outreach_targets_link_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    targets = (project_root / "docs" / "launch" / "outreach-targets.md").read_text()
    assert "## Contribution Reply" in targets
    contribution_reply = targets.split("## Contribution Reply", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in contribution_reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contribution_reply
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_search_indexing_submission_links_first_pr_recipe_for_small_contributions():
    project_root = Path(__file__).resolve().parents[1]
    submission = (
        project_root / "docs" / "launch" / "search-indexing-submission.md"
    ).read_text()
    assert "## Contribution Reply" in submission
    contribution_reply = submission.split("## Contribution Reply", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in contribution_reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contribution_reply
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_search_indexing_submission_includes_json_cli_troubleshooting_reply():
    project_root = Path(__file__).resolve().parents[1]
    submission = (
        project_root / "docs" / "launch" / "search-indexing-submission.md"
    ).read_text()
    assert "## Troubleshooting Reply" in submission
    reply = submission.split("## Troubleshooting Reply", 1)[1].split(
        "## Google Search Console", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "crawl/indexing follow-up, local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_search_indexing_submission_links_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    submission = (
        project_root / "docs" / "launch" / "search-indexing-submission.md"
    ).read_text()

    assert "## Stack-Specific Reply Links" in submission
    guide_section = submission.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Google Search Console", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_search_indexing_submission_includes_failure_patterns_url():
    project_root = Path(__file__).resolve().parents[1]
    submission = (
        project_root / "docs" / "launch" / "search-indexing-submission.md"
    ).read_text()
    url = "https://aaronlab.github.io/browsertrace/browser-agent-failure-patterns.html"

    assert f"| Failure patterns | `{url}` |" in submission
    assert f'"{url}"' in submission


def test_search_indexing_submission_includes_latest_launch_packet_urls():
    project_root = Path(__file__).resolve().parents[1]
    submission = (
        project_root / "docs" / "launch" / "search-indexing-submission.md"
    ).read_text()
    indexnow_payload = submission.split("```json", 1)[1].split("```", 1)[0]

    for path in [
        "launch/",
        "launch/channel-copy.md",
        "launch/day-1-publish-packet.md",
        "launch/day-2-show-hn-packet.md",
        "launch/day-4-product-hunt-packet.md",
        "launch/owner-social-post-packet.md",
        "launch/owner-email-send-packet.md",
        "launch/owner-launch-submission-packet.md",
    ]:
        assert f'"https://aaronlab.github.io/browsertrace/{path}"' in indexnow_payload


def test_bug_report_template_requests_json_cli_troubleshooting_checks():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "bug_report.yml"
    ).read_text()

    assert "issue reports, CI, or AI/coding-agent troubleshooting" in template
    assert "CONTRIBUTING.md#first-pr-recipe" in template
    assert "first contribution small and reviewable" in template
    assert "browsertrace doctor --json" in template
    assert "browsertrace list --status failed --json" in template
    assert "browsertrace show <run_id> --json" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()


def test_bug_report_template_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "bug_report.yml"
    ).read_text()

    assert "SECURITY.md" in template
    assert "security-sensitive reports" in template
    assert "private trace data" in template


def test_bug_report_template_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "bug_report.yml"
    ).read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_integration_request_template_requests_json_cli_troubleshooting_checks():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "integration_request.yml"
    ).read_text()

    assert "integration requests, CI, or AI/coding-agent troubleshooting" in template
    assert "CONTRIBUTING.md#first-pr-recipe" in template
    assert "first contribution small and reviewable" in template
    assert "browsertrace doctor --json" in template
    assert "browsertrace list --status failed --json" in template
    assert "browsertrace show <run_id> --json" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()


def test_integration_request_template_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "integration_request.yml"
    ).read_text()

    assert "SECURITY.md" in template
    assert "security-sensitive reports" in template
    assert "private trace data" in template


def test_integration_request_template_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "integration_request.yml"
    ).read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_integration_request_template_requests_persistent_browser_recovery_evidence():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "integration_request.yml"
    ).read_text()
    recovery_prompt = template.split(
        "Persistent browser recovery evidence, if relevant", 1
    )[1].split("Relevant hooks or API calls", 1)[0]

    assert "custom computer-use or persistent-browser failures" in recovery_prompt
    assert "before the first screenshot or URL" in recovery_prompt
    assert "session_mode" in recovery_prompt
    assert "redacted profile id or user data directory token" in recovery_prompt
    assert "browser/session/target id" in recovery_prompt
    assert "profile lock or stale process signal" in recovery_prompt
    assert "CDP attach/probe timing and timeout" in recovery_prompt
    assert "approval source" in recovery_prompt
    assert "recovery action" in recovery_prompt
    assert "final connection state" in recovery_prompt
    assert (
        "https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html"
        in recovery_prompt
    )
    assert "stars" not in recovery_prompt.lower()
    assert "upvotes" not in recovery_prompt.lower()
    assert "reposts" not in recovery_prompt.lower()


def test_feature_request_template_links_first_pr_recipe():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "feature_request.yml"
    ).read_text()

    assert "Describe the smallest useful version of the feature." in template
    assert "CONTRIBUTING.md#first-pr-recipe" in template
    assert "first contribution small and reviewable" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_feature_request_template_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "feature_request.yml"
    ).read_text()

    assert (
        "[Security Policy](https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md)"
        in template
    )
    assert "security-sensitive reports" in template
    assert "private trace data" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_feature_request_template_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "feature_request.yml"
    ).read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_cloud_interest_template_links_first_pr_recipe():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "cloud_interest.yml"
    ).read_text()

    assert "Team workflow" in template
    assert "Data and security constraints" in template
    assert "privacy, retention, customer-data, or deployment constraints" in template
    assert "CONTRIBUTING.md#first-pr-recipe" in template
    assert "first contribution small and reviewable" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()


def test_cloud_interest_template_links_security_policy_for_sensitive_reports():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "cloud_interest.yml"
    ).read_text()

    assert "SECURITY.md" in template
    assert "security-sensitive reports" in template
    assert "private trace data" in template


def test_cloud_interest_template_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    template = (
        project_root / ".github" / "ISSUE_TEMPLATE" / "cloud_interest.yml"
    ).read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_pull_request_template_requests_json_cli_troubleshooting_checks():
    project_root = Path(__file__).resolve().parents[1]
    template = (project_root / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text()

    assert "issue reports, CI, or AI/coding-agent troubleshooting" in template
    assert "browsertrace doctor --json" in template
    assert "browsertrace list --status failed --json" in template
    assert "browsertrace show <run_id> --json" in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()


def test_pull_request_template_prompts_for_real_contributor_details():
    project_root = Path(__file__).resolve().parents[1]
    template = (project_root / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text()

    assert "<summary>" not in template
    assert "Replace every placeholder before requesting review." in template
    assert "CONTRIBUTING.md#first-pr-recipe" in template
    assert "first contribution small and reviewable" in template
    assert "CODE_OF_CONDUCT.md" in template
    assert "PR discussions and reviews" in template
    assert "Fixes #123 or Refs #123" in template
    assert "I ran `uv run --python 3.11 --extra dev pytest -q`" in template
    assert "I ran `git diff --check`" in template
    assert "I checked `git diff --stat` and `git diff --summary`" in template
    assert "unexpected deleted or renamed files" in template


def test_pull_request_template_links_security_policy_for_sensitive_changes():
    project_root = Path(__file__).resolve().parents[1]
    template = (project_root / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text()

    assert "SECURITY.md" in template
    assert "security-sensitive changes" in template
    assert "private trace data" in template


def test_pull_request_template_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    template = (project_root / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text()

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in template
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_pull_request_template_has_research_only_aos_mapping_note():
    project_root = Path(__file__).resolve().parents[1]
    template = (project_root / ".github" / "PULL_REQUEST_TEMPLATE.md").read_text()
    normalized = " ".join(template.split())

    assert "AOS mapping note research-only" in normalized
    assert "not making an AOS compliance claim yet" in normalized
    assert "tool request/result records" in normalized
    assert "step correlation" in normalized
    assert "URI-style screenshot/video artifacts" in normalized
    assert "URL metadata" in normalized
    assert "model I/O summaries" in normalized
    assert "explicit redaction state" in normalized
    assert "https://github.com/aaronlab/browsertrace/issues/237" in normalized
    assert "stars" not in template.lower()
    assert "upvotes" not in template.lower()
    assert "reposts" not in template.lower()


def test_security_policy_has_private_report_path_without_email_placeholder():
    project_root = Path(__file__).resolve().parents[1]
    policy = (project_root / "SECURITY.md").read_text()
    normalized = " ".join(policy.split())

    assert "private GitHub vulnerability report" in normalized
    assert "open a minimal public issue without exploit details" in normalized
    assert "emailing the maintainer" not in policy
    assert "browsertrace export <run_id> --public -o public.html" in policy


def test_security_policy_links_non_sensitive_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]
    policy = (project_root / "SECURITY.md").read_text()
    normalized = " ".join(policy.split())

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    assert "For non-sensitive browser-agent workflow questions" in normalized
    assert "Security-sensitive details should still stay private" in normalized
    for guide in stack_guides:
        assert guide in policy
    assert "stars" not in policy.lower()
    assert "upvotes" not in policy.lower()
    assert "reposts" not in policy.lower()


def test_awesome_list_submission_notes_include_trial_and_demo_links():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = (
        "browsertrace[ui]"
    )
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "https://aaronlab.github.io/browsertrace/" in notes
    assert "browsertrace-demo-public.html" in notes
    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in notes
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in notes


def test_awesome_list_submission_notes_link_first_pr_recipe_for_contributors():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()
    assert "## Contribution Reply" in notes
    contribution_reply = notes.split("## Contribution Reply", 1)[1].split(
        "## Troubleshooting Reply", 1
    )[0]

    assert "https://github.com/aaronlab/browsertrace/labels/good%20first%20issue" in contribution_reply
    assert "https://github.com/aaronlab/browsertrace/issues/213" not in contribution_reply
    assert "First PR Recipe" in contribution_reply
    assert "CONTRIBUTING.md#first-pr-recipe" in contribution_reply
    assert "first contribution small and reviewable" in contribution_reply
    assert "stars" not in contribution_reply.lower()
    assert "upvotes" not in contribution_reply.lower()
    assert "reposts" not in contribution_reply.lower()


def test_awesome_list_submission_notes_link_listing_fit_reply_template():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "## Listing-Fit Reply" in notes
    reply = notes.split("## Listing-Fit Reply", 1)[1].split(
        "## Contribution Reply", 1
    )[0]

    assert "docs/launch/response-templates.md#maintainer-asks-whether-it-fits-this-list" in reply
    assert "accept off-topic decisions" in reply
    assert "outside the list scope" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_awesome_list_submission_notes_include_json_cli_reviewer_reply():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()
    assert "## Troubleshooting Reply" in notes
    reply = notes.split("## Troubleshooting Reply", 1)[1].split(
        "## Recommended Order", 1
    )[0]
    recipe = """```bash
browsertrace doctor --json
browsertrace list --status failed --json
browsertrace show <run_id> --json
```"""

    assert (
        "awesome-list reviewer follow-up, local first-run issues, CI failures, or AI/coding-agent troubleshooting replies"
        in reply
    )
    assert "https://github.com/aaronlab/browsertrace/blob/main/SECURITY.md" in reply
    assert "security-sensitive reports or changes" in reply
    assert "private trace data" in reply
    assert recipe in reply
    assert "debugging/workflow details" in reply
    assert "stars" not in reply.lower()
    assert "upvotes" not in reply.lower()
    assert "reposts" not in reply.lower()


def test_awesome_list_submission_notes_link_stack_debugging_guides_for_replies():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "## Stack-Specific Reply Links" in notes
    guide_section = notes.split("## Stack-Specific Reply Links", 1)[1].split(
        "## Recommended Order", 1
    )[0]
    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for guide in stack_guides:
        assert guide in guide_section
    assert "stars" not in guide_section.lower()
    assert "upvotes" not in guide_section.lower()
    assert "reposts" not in guide_section.lower()


def test_awesome_list_submission_notes_record_steel_web_agents_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "steel-dev/awesome-web-agents" in notes
    assert "https://github.com/steel-dev/awesome-web-agents/pull/56" in notes
    assert "Dev Tools" in notes
    assert "action_required" in notes
    assert "GITHUB_TOKEN=$(gh auth token) npx -y awesome-lint@2.2.3 README.md" in notes


def test_awesome_list_submission_notes_record_harness_engineering_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "ai-boost/awesome-harness-engineering" in notes
    assert "https://github.com/ai-boost/awesome-harness-engineering/pull/23" in notes
    assert "Debugging & Developer Experience" in notes
    assert "browser-agent and computer-use runs" in notes
    assert "curl -L -s -o /dev/null" in notes


def test_awesome_list_submission_notes_record_autonomous_web_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "Agent-Tools/awesome-autonomous-web" in notes
    assert "https://github.com/Agent-Tools/awesome-autonomous-web/pull/21" in notes
    assert "Debugging & Trace Viewers" in notes
    assert "Browser Use-first debugging and replay tool" in notes
    assert "awesome-lint README.md" in notes


def test_awesome_list_submission_notes_record_e2b_ai_sdks_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "e2b-dev/awesome-ai-sdks" in notes
    assert "https://github.com/e2b-dev/awesome-ai-sdks/pull/187" in notes
    assert "creating, monitoring, debugging and deploying autonomous AI agents" in notes
    assert "verification/cla-signed" in notes
    assert "SUCCESS" in notes


def test_awesome_list_submission_notes_record_ranpox_computer_use_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()

    assert "ranpox/awesome-computer-use" in notes
    assert "https://github.com/ranpox/awesome-computer-use/pull/24" in notes
    assert "Projects" in notes
    assert "computer-use resources" in notes
    assert "supernalintelligence/Awesome-Gui-Agents" in notes


def test_awesome_list_submission_notes_record_scottcjn_awesome_agents_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()
    section = notes.split("## 13. Awesome Agents", 1)[1].split(
        "## 14. Browser Use Awesome Projects", 1
    )[0]

    assert "Scottcjn/awesome-agents" in notes
    assert "https://github.com/Scottcjn/awesome-agents/pull/16" in notes
    assert "Monitoring and Observability" in section
    assert "not a duplicate" in section
    assert "npx --yes awesome-lint README.md" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_awesome_list_submission_notes_record_browser_use_awesome_projects_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()
    section = notes.split("## 14. Browser Use Awesome Projects", 1)[1].split(
        "## 15. AI Browser Tools Index", 1
    )[0]

    assert "browser-use/awesome-projects" in notes
    assert "https://github.com/browser-use/awesome-projects/pull/6" in notes
    assert "Integrations & Ease of Use" in section
    assert "built on or inspired by browser-use" in section
    assert "git diff --check" in section
    assert "stars" not in section.lower()
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_awesome_list_submission_notes_record_ai_browser_tools_pr():
    project_root = Path(__file__).resolve().parents[1]
    notes = (
        project_root / "docs" / "launch" / "github-awesome-list-submissions.md"
    ).read_text()
    section = notes.split("## 15. AI Browser Tools Index", 1)[1].split(
        "## Skip List", 1
    )[0]

    assert "danielrosehill/AI-Browser-Tools" in notes
    assert "https://github.com/danielrosehill/AI-Browser-Tools/pull/1" in notes
    assert "Developer Tools & Utilities" in section
    assert "Local replay debugger for failed Browser Use runs" in section
    assert "git diff --check" in section
    assert "upvotes" not in section.lower()
    assert "reposts" not in section.lower()


def test_targeted_outreach_copy_includes_uvx_trial_before_pypi():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = (
        "browsertrace[ui]"
    )

    for relpath in [
        "docs/launch/day-3-targeted-communities-packet.md",
        "docs/launch/outreach-targets.md",
    ]:
        text = (project_root / relpath).read_text()
        assert f'uvx --from "{pypi_spec}" browsertrace doctor' in text, relpath
        assert f'uvx --from "{pypi_spec}" browsertrace demo' in text, relpath
        assert "pypi" in text.lower(), relpath


def test_owner_next_actions_include_uvx_fallback_before_pypi():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = (
        "browsertrace[ui]"
    )

    for relpath in [
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
    ]:
        text = (project_root / relpath).read_text()
        assert f'uvx --from "{pypi_spec}" browsertrace demo' in text, relpath
        assert "pypi" in text.lower(), relpath


def test_owner_next_actions_surface_launch_media_alt_text():
    project_root = Path(__file__).resolve().parents[1]

    expected = [
        ("docs/launch/owner-next-actions.md", "Media Alt Text", "Fast copy/paste blocks"),
        ("docs/launch/owner-next-actions.zh-CN.md", "Media Alt Text", "快速复制入口"),
    ]

    for relpath, phrase, end_marker in expected:
        text = (project_root / relpath).read_text()
        unblock = text.split("10", 1)[1].split(end_marker, 1)[0]
        assert "docs/launch/day-1-publish-packet.md#media-alt-text" in unblock, relpath
        assert phrase in unblock, relpath
        assert "docs/demo.mp4" in unblock, relpath
        assert "stars" not in unblock.lower(), relpath
        assert "upvotes" not in unblock.lower(), relpath
        assert "reposts" not in unblock.lower(), relpath


def test_owner_next_actions_use_hard_success_check():
    project_root = Path(__file__).resolve().parents[1]
    expected = (
        "gh repo view aaronlab/browsertrace "
        "--json stargazerCount,forkCount,watchers,url,homepageUrl"
    )

    for relpath in [
        "LAUNCH.md",
        "docs/launch/day-2-show-hn-packet.md",
        "docs/launch/owner-next-actions.md",
        "docs/launch/owner-next-actions.zh-CN.md",
    ]:
        text = (project_root / relpath).read_text()
        assert expected in text, relpath
        assert "--json stargazerCount,url,homepageUrl,owner" not in text, relpath


def test_owner_docs_mark_social_preview_uploaded():
    project_root = Path(__file__).resolve().parents[1]
    owner_next_actions = (
        project_root / "docs" / "launch" / "owner-next-actions.md"
    ).read_text()
    owner_next_actions_zh = (
        project_root / "docs" / "launch" / "owner-next-actions.zh-CN.md"
    ).read_text()
    owner_publish_queue = (
        project_root / "docs" / "launch" / "owner-publish-queue.md"
    ).read_text()

    assert "Social preview: completed" in owner_next_actions
    assert "usesCustomOpenGraphImage=true" in owner_next_actions
    assert "Social preview：已完成" in owner_next_actions_zh
    assert "usesCustomOpenGraphImage=true" in owner_next_actions_zh
    assert "Repository social preview: completed" in owner_publish_queue
    assert "https://github.com/aaronlab/browsertrace/issues/15" not in (
        owner_next_actions + owner_next_actions_zh + owner_publish_queue
    )


def test_launch_control_room_has_current_audit_and_uvx_fallback():
    project_root = Path(__file__).resolve().parents[1]
    pypi_spec = (
        "browsertrace[ui]"
    )
    launch = (project_root / "LAUNCH.md").read_text()
    metrics_log = (project_root / "docs" / "launch" / "metrics-log.md").read_text()
    latest_metrics_row = next(
        line for line in reversed(metrics_log.splitlines()) if line.startswith("| 20")
    )
    latest_metrics_timestamp = latest_metrics_row.split("|")[1].strip()

    assert latest_metrics_timestamp in launch
    assert latest_metrics_row in launch
    assert "current monitor pass" in launch
    assert f'uvx --from "{pypi_spec}" browsertrace doctor' in launch
    assert f'uvx --from "{pypi_spec}" browsertrace demo' in launch


def test_owner_next_actions_links_stack_debugging_guides():
    project_root = Path(__file__).resolve().parents[1]

    expected = [
        ("docs/launch/owner-next-actions.md", "Stack-specific guide links:"),
        ("docs/launch/owner-next-actions.zh-CN.md", "Stack 调试指南："),
    ]

    stack_guides = [
        "Browser Use guide: https://aaronlab.github.io/browsertrace/browser-use-debugging.html",
        "Stagehand guide: https://aaronlab.github.io/browsertrace/stagehand-debugging.html",
        "Skyvern guide: https://aaronlab.github.io/browsertrace/skyvern-debugging.html",
        "Playwright + LLM guide: https://aaronlab.github.io/browsertrace/playwright-llm-debugging.html",
        "Computer-use guide: https://aaronlab.github.io/browsertrace/computer-use-agent-debugging.html",
    ]

    for relpath, section_header in expected:
        text = (project_root / relpath).read_text(encoding="utf-8")
        section = text.split(section_header, 1)[1].split("##", 1)[0]

        for guide in stack_guides:
            assert guide in section
        assert "stars" not in section.lower()
        assert "upvotes" not in section.lower()
        assert "reposts" not in section.lower()
