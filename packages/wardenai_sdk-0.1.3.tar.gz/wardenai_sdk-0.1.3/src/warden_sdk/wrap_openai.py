"""
Drop-in wrapper for the OpenAI Python SDK.

Usage:
    from openai import OpenAI
    from warden_sdk import wrap_openai

    client = wrap_openai(OpenAI(), gateway_url="https://gateway.wardenai.dev", api_key="warden_live_xxx")
    # Works exactly like before — all calls routed through Warden
"""

from __future__ import annotations

SDK_VERSION = "0.1.0"


def wrap_openai(client: object, *, gateway_url: str, api_key: str) -> object:
    """
    Wraps an OpenAI client to route through the Warden Gateway.
    Overrides base_url and injects X-Warden-SDK-Version header.
    """
    client.base_url = gateway_url.rstrip("/") + "/v1"  # type: ignore[attr-defined]
    client.api_key = api_key  # type: ignore[attr-defined]

    # Inject Warden SDK version header
    if hasattr(client, "default_headers"):
        headers = dict(client.default_headers)  # type: ignore[attr-defined]
        headers["X-Warden-SDK-Version"] = SDK_VERSION
        client.default_headers = headers  # type: ignore[attr-defined]
    else:
        client._custom_headers = {"X-Warden-SDK-Version": SDK_VERSION}  # type: ignore[attr-defined]

    return client
