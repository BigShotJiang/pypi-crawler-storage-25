"""
Context variables for per-request cost attribution.

Usage:
    from warden_sdk import warden_feature, warden_customer_id

    # Set for the current async task / thread:
    warden_feature.set("checkout")
    warden_customer_id.set("cust_001")

    # These are automatically picked up by the WardenClient and wrappers.
    result = await client.chat.completions.create(...)

    # Or use as context managers (resets on exit):
    token = warden_feature.set("checkout")
    try:
        ...
    finally:
        warden_feature.reset(token)
"""

from contextvars import ContextVar

warden_feature: ContextVar[str] = ContextVar("warden_feature", default="untagged")
warden_customer_id: ContextVar[str | None] = ContextVar("warden_customer_id", default=None)
