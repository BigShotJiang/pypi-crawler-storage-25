"""
Warden SDK client — primary integration surface for Python teams.

Routes all LLM requests through the Warden Gateway for cost tracking.
Supports both sync and async usage patterns.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx

from .circuit_breaker import CircuitBreaker
from .context import warden_feature, warden_customer_id

SDK_VERSION = "0.1.0"


@dataclass
class ChatCompletionOptions:
    feature: str | None = None
    customer_id: str | None = None
    team: str | None = None
    version: str | None = None


class _ChatCompletions:
    """Namespaced API: client.chat.completions.create(...)"""

    def __init__(self, client: WardenClient):
        self._client = client

    def create(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        options: ChatCompletionOptions | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Synchronous chat completion through the gateway."""
        return self._client._create_sync(model=model, messages=messages, options=options, **kwargs)

    async def acreate(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        options: ChatCompletionOptions | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Async chat completion through the gateway."""
        return await self._client._create_async(model=model, messages=messages, options=options, **kwargs)


class _Chat:
    def __init__(self, client: WardenClient):
        self.completions = _ChatCompletions(client)


class WardenClient:
    def __init__(
        self,
        *,
        api_key: str,
        gateway_url: str,
        debug: bool = False,
        failure_threshold: int = 3,
        window_s: float = 10.0,
        recovery_timeout_s: float = 30.0,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        if not gateway_url:
            raise ValueError("gateway_url is required")

        self._api_key = api_key
        self._gateway_url = gateway_url.rstrip("/")
        self._debug = debug
        self._headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "X-Warden-SDK-Version": SDK_VERSION,
        }

        self._circuit = CircuitBreaker(
            failure_threshold=failure_threshold,
            window_s=window_s,
            recovery_timeout_s=recovery_timeout_s,
            debug=debug,
        )

        self._sync_client = httpx.Client(
            headers=self._headers,
            timeout=30.0,
        )
        self._async_client = httpx.AsyncClient(
            headers=self._headers,
            timeout=30.0,
        )

        self.chat = _Chat(self)

    @property
    def circuit_state(self) -> str:
        return self._circuit.state

    @property
    def bypass_queue_size(self) -> int:
        return self._circuit.bypass_queue_size

    def flush(self) -> None:
        """Drain queued bypass events to the gateway (sync)."""
        events = self._circuit.flush_bypass_queue()
        if not events:
            return
        try:
            self._sync_client.post(
                f"{self._gateway_url}/api/v1/ingest/usage",
                json={"events": [e.payload for e in events]},
            )
        except Exception:
            if self._debug:
                print(f"[Warden SDK] Flush failed — {len(events)} events lost")

    async def aflush(self) -> None:
        """Drain queued bypass events to the gateway (async)."""
        events = self._circuit.flush_bypass_queue()
        if not events:
            return
        try:
            await self._async_client.post(
                f"{self._gateway_url}/api/v1/ingest/usage",
                json={"events": [e.payload for e in events]},
            )
        except Exception:
            if self._debug:
                print(f"[Warden SDK] Flush failed — {len(events)} events lost")

    def close(self) -> None:
        self._sync_client.close()

    async def aclose(self) -> None:
        await self._async_client.aclose()

    def _build_body(
        self, model: str, messages: list[dict[str, Any]], options: ChatCompletionOptions | None, **kwargs: Any
    ) -> dict[str, Any]:
        opts = options or ChatCompletionOptions()
        return {
            "model": model,
            "messages": messages,
            **kwargs,
            "warden": {
                "feature": opts.feature or warden_feature.get(),
                "customer_id": opts.customer_id or warden_customer_id.get(),
                "team": opts.team,
                "version": opts.version,
            },
        }

    def _create_sync(
        self, *, model: str, messages: list[dict[str, Any]], options: ChatCompletionOptions | None = None, **kwargs: Any
    ) -> dict[str, Any]:
        body = self._build_body(model, messages, options, **kwargs)
        bypass = {"model": model, "feature": body["warden"]["feature"]}

        def call_gateway() -> dict[str, Any]:
            resp = self._sync_client.post(f"{self._gateway_url}/v1/chat/completions", json=body)
            resp.raise_for_status()
            return resp.json()

        return self._circuit.execute(call_gateway, call_gateway, bypass)

    async def _create_async(
        self, *, model: str, messages: list[dict[str, Any]], options: ChatCompletionOptions | None = None, **kwargs: Any
    ) -> dict[str, Any]:
        body = self._build_body(model, messages, options, **kwargs)
        bypass = {"model": model, "feature": body["warden"]["feature"]}

        async def call_gateway() -> dict[str, Any]:
            resp = await self._async_client.post(f"{self._gateway_url}/v1/chat/completions", json=body)
            resp.raise_for_status()
            return resp.json()

        return await self._circuit.execute_async(call_gateway, call_gateway, bypass)
