"""
Wrapper for the Google Generative AI SDK — routes generate_content() through the Warden Gateway.

Usage:
    import google.generativeai as genai
    from warden_sdk import wrap_gemini

    model = genai.GenerativeModel("gemini-1.5-pro")
    model = wrap_gemini(model, gateway_url="https://gateway.wardenai.dev", api_key="warden_live_xxx")
"""

from __future__ import annotations

from typing import Any

import httpx

SDK_VERSION = "0.1.0"


def wrap_gemini(
    model: object,
    *,
    gateway_url: str,
    api_key: str,
    model_name: str | None = None,
    debug: bool = False,
) -> object:
    """
    Wraps a Gemini GenerativeModel so generate_content() routes through the gateway.
    Translates Gemini request/response format to/from OpenAI-compatible gateway format.
    Falls back to direct provider on gateway failure.
    """
    gw_url = gateway_url.rstrip("/")
    resolved_model = model_name or getattr(model, "model_name", "gemini-1.5-pro")
    original_generate = model.generate_content  # type: ignore[attr-defined]

    def wrapped_generate(contents: Any, **kwargs: Any) -> Any:
        if kwargs.get("stream"):
            return original_generate(contents, **kwargs)

        messages = _extract_messages(contents)
        body = {"model": resolved_model, "messages": messages, "stream": False}

        if debug:
            print("[Warden SDK] Routing Gemini generate_content through gateway")

        try:
            resp = httpx.post(
                f"{gw_url}/v1/chat/completions",
                json=body,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "X-Warden-SDK-Version": SDK_VERSION,
                    "Content-Type": "application/json",
                },
                timeout=30.0,
            )
            resp.raise_for_status()
            return _translate_response(resp.json())
        except Exception as e:
            if debug:
                print(f"[Warden SDK] Gateway failed, falling back to direct: {e}")
            return original_generate(contents, **kwargs)

    model.generate_content = wrapped_generate  # type: ignore[attr-defined]
    return model


def _extract_messages(contents: Any) -> list[dict[str, str]]:
    if isinstance(contents, str):
        return [{"role": "user", "content": contents}]
    if isinstance(contents, list):
        text = " ".join(c if isinstance(c, str) else getattr(c, "text", str(c)) for c in contents)
        return [{"role": "user", "content": text}]
    return [{"role": "user", "content": str(contents)}]


class _GeminiResponse:
    """Mimics the Gemini GenerateContentResponse shape."""

    def __init__(self, data: dict[str, Any]):
        choice = (data.get("choices") or [{}])[0]
        self._text = (choice.get("message") or {}).get("content", "")
        usage = data.get("usage") or {}

        self.candidates = [_Candidate(self._text)]
        self.usage_metadata = _UsageMetadata(
            prompt_token_count=usage.get("prompt_tokens", 0),
            candidates_token_count=usage.get("completion_tokens", 0),
            total_token_count=usage.get("total_tokens", 0),
        )

    @property
    def text(self) -> str:
        return self._text


class _Candidate:
    def __init__(self, text: str):
        self.content = _Content(text)
        self.index = 0
        self.finish_reason = "STOP"
        self.safety_ratings: list[Any] = []


class _Content:
    def __init__(self, text: str):
        self.role = "model"
        self.parts = [_Part(text)]


class _Part:
    def __init__(self, text: str):
        self.text = text


class _UsageMetadata:
    def __init__(self, prompt_token_count: int, candidates_token_count: int, total_token_count: int):
        self.prompt_token_count = prompt_token_count
        self.candidates_token_count = candidates_token_count
        self.total_token_count = total_token_count


def _translate_response(data: dict[str, Any]) -> _GeminiResponse:
    return _GeminiResponse(data)
