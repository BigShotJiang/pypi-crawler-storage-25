"""
Wrapper for the Anthropic Python SDK — routes messages.create() through the Warden Gateway.

Usage:
    from anthropic import Anthropic
    from warden_sdk import wrap_anthropic

    client = wrap_anthropic(Anthropic(), gateway_url="https://gateway.wardenai.dev", api_key="warden_live_xxx")
"""

from __future__ import annotations

from typing import Any

import httpx

SDK_VERSION = "0.1.0"


def wrap_anthropic(client: object, *, gateway_url: str, api_key: str, debug: bool = False) -> object:
    """
    Wraps an Anthropic client so messages.create() routes through the gateway.
    Translates Anthropic request/response format to/from OpenAI-compatible gateway format.
    Falls back to direct provider on gateway failure.
    """
    gw_url = gateway_url.rstrip("/")
    messages_ns = getattr(client, "messages", None)
    if messages_ns is None:
        raise ValueError("Client does not have a messages attribute — is this an Anthropic client?")

    original_create = messages_ns.create

    def wrapped_create(**kwargs: Any) -> Any:
        if kwargs.get("stream"):
            return original_create(**kwargs)

        body = _translate_request(kwargs)

        if debug:
            print("[Warden SDK] Routing Anthropic messages.create through gateway")

        try:
            resp = httpx.post(
                f"{gw_url}/v1/chat/completions",
                json=body,
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "X-Warden-SDK-Version": SDK_VERSION,
                    "Content-Type": "application/json",
                },
                timeout=30.0,
            )
            resp.raise_for_status()
            return _translate_response(resp.json(), kwargs.get("model", ""))
        except Exception as e:
            if debug:
                print(f"[Warden SDK] Gateway failed, falling back to direct: {e}")
            return original_create(**kwargs)

    messages_ns.create = wrapped_create
    return client


def _translate_request(kwargs: dict[str, Any]) -> dict[str, Any]:
    messages: list[dict[str, str]] = []

    system = kwargs.get("system")
    if system:
        text = system if isinstance(system, str) else " ".join(b.get("text", "") for b in system)
        messages.append({"role": "system", "content": text})

    for msg in kwargs.get("messages", []):
        content = msg.get("content", "")
        if isinstance(content, list):
            content = " ".join(b.get("text", "") for b in content)
        messages.append({"role": msg["role"], "content": content})

    return {
        "model": kwargs.get("model", ""),
        "messages": messages,
        "max_tokens": kwargs.get("max_tokens"),
        "temperature": kwargs.get("temperature"),
        "stream": False,
    }


class _AnthropicResponse:
    """Mimics the Anthropic Message response shape."""

    def __init__(self, data: dict[str, Any], model: str):
        choice = (data.get("choices") or [{}])[0]
        content_text = (choice.get("message") or {}).get("content", "")
        usage = data.get("usage") or {}

        self.id = data.get("id", f"msg_{id(self)}")
        self.type = "message"
        self.role = "assistant"
        self.content = [_TextBlock(content_text)]
        self.model = model
        self.stop_reason = "end_turn" if choice.get("finish_reason") == "stop" else (choice.get("finish_reason") or "end_turn")
        self.stop_sequence = None
        self.usage = _Usage(
            input_tokens=usage.get("prompt_tokens", 0),
            output_tokens=usage.get("completion_tokens", 0),
        )


class _TextBlock:
    def __init__(self, text: str):
        self.type = "text"
        self.text = text


class _Usage:
    def __init__(self, input_tokens: int, output_tokens: int):
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens
        self.cache_creation_input_tokens = 0
        self.cache_read_input_tokens = 0


def _translate_response(data: dict[str, Any], model: str) -> _AnthropicResponse:
    return _AnthropicResponse(data, model)
