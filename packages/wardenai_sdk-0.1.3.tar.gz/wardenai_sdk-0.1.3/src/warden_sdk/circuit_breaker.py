"""
Gateway circuit breaker — closed / open / half-open state machine.

Thread-safe for sync usage (via threading.Lock).
Asyncio-safe for async usage (lock-free — single-threaded event loop).

Trip: failure_threshold consecutive failures within window_s.
Recovery: recovery_timeout_s after opening, one probe request.
Flush: bypass queue passed to on_recovery callback when circuit closes.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar, Awaitable

T = TypeVar("T")


@dataclass
class BypassEvent:
    payload: Any
    enqueued_at: float = field(default_factory=time.time)


class CircuitBreaker:
    def __init__(
        self,
        failure_threshold: int = 3,
        window_s: float = 10.0,
        recovery_timeout_s: float = 30.0,
        max_bypass_queue: int = 500,
        debug: bool = False,
        on_recovery: Callable[[list[BypassEvent]], Any] | None = None,
    ):
        self._failure_threshold = failure_threshold
        self._window_s = window_s
        self._recovery_timeout_s = recovery_timeout_s
        self._max_bypass_queue = max_bypass_queue
        self._debug = debug
        self._on_recovery = on_recovery

        self._state: str = "closed"  # closed | open | half-open
        self._consecutive_failures = 0
        self._first_failure_at = 0.0
        self._opened_at = 0.0
        self._bypass_queue: list[BypassEvent] = []
        self._lock = threading.Lock()

    @property
    def state(self) -> str:
        return self._state

    @property
    def bypass_queue_size(self) -> int:
        return len(self._bypass_queue)

    def execute(
        self,
        fn: Callable[[], T],
        fallback: Callable[[], T],
        bypass_event: Any = None,
    ) -> T:
        """Synchronous circuit breaker execution."""
        with self._lock:
            if self._state == "open":
                if time.time() - self._opened_at >= self._recovery_timeout_s:
                    self._transition("half-open")
                else:
                    self._log("Circuit open — bypassing to fallback")
                    if bypass_event is not None:
                        self._enqueue(bypass_event)
                    return fallback()

        try:
            result = fn()
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            self._log("Gateway call failed — falling back to direct provider")
            with self._lock:
                if bypass_event is not None:
                    self._enqueue(bypass_event)
            return fallback()

    async def execute_async(
        self,
        fn: Callable[[], Awaitable[T]],
        fallback: Callable[[], Awaitable[T]],
        bypass_event: Any = None,
    ) -> T:
        """Async circuit breaker execution (asyncio-safe)."""
        if self._state == "open":
            if time.time() - self._opened_at >= self._recovery_timeout_s:
                self._transition("half-open")
            else:
                self._log("Circuit open — bypassing to fallback")
                if bypass_event is not None:
                    self._enqueue(bypass_event)
                return await fallback()

        try:
            result = await fn()
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            self._log("Gateway call failed — falling back to direct provider")
            if bypass_event is not None:
                self._enqueue(bypass_event)
            return await fallback()

    def flush_bypass_queue(self) -> list[BypassEvent]:
        with self._lock:
            events = list(self._bypass_queue)
            self._bypass_queue.clear()
            return events

    def _enqueue(self, payload: Any) -> None:
        if len(self._bypass_queue) < self._max_bypass_queue:
            self._bypass_queue.append(BypassEvent(payload=payload))
        else:
            self._log("Bypass queue full — event dropped")

    def _on_success(self) -> None:
        with self._lock:
            if self._state == "half-open":
                self._log("Probe succeeded — closing circuit")
                events = list(self._bypass_queue)
                self._bypass_queue.clear()
                self._transition("closed")

                if self._on_recovery and events:
                    self._log(f"Flushing {len(events)} queued bypass event(s)")
                    try:
                        self._on_recovery(events)
                    except Exception:
                        pass  # fire-and-forget
                return

            self._consecutive_failures = 0
            self._first_failure_at = 0.0

    def _on_failure(self) -> None:
        with self._lock:
            if self._state == "half-open":
                self._log("Probe failed — reopening circuit")
                self._transition("open")
                return

            now = time.time()
            if self._consecutive_failures > 0 and now - self._first_failure_at > self._window_s:
                self._consecutive_failures = 0
                self._first_failure_at = 0.0

            if self._consecutive_failures == 0:
                self._first_failure_at = now

            self._consecutive_failures += 1
            self._log(f"Failure {self._consecutive_failures}/{self._failure_threshold}")

            if self._consecutive_failures >= self._failure_threshold:
                self._transition("open")

    def _transition(self, to: str) -> None:
        frm = self._state
        self._state = to
        if to == "open":
            self._opened_at = time.time()
            self._consecutive_failures = 0
            self._first_failure_at = 0.0
        elif to == "closed":
            self._consecutive_failures = 0
            self._first_failure_at = 0.0
            self._opened_at = 0.0
        self._log(f"State: {frm} → {to}")

    def _log(self, msg: str) -> None:
        if self._debug:
            print(f"[Warden] circuit={self._state} queue={len(self._bypass_queue)} — {msg}")
