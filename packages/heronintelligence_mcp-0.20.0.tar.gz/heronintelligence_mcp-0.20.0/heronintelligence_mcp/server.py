from __future__ import annotations


import json
import logging
import os
from typing import Any

import httpx
from mcp.server.auth.settings import AuthSettings, ClientRegistrationOptions
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from mcp.types import ToolAnnotations
from pydantic import AnyHttpUrl

from heronintelligence_mcp._context import (  # noqa: F401 — _request_api_key re-exported for http_app
    _request_api_key,
    _request_user_email,
)

logger = logging.getLogger(__name__)

# Generic message returned to callers when an unexpected exception occurs.
# Keeps stack traces and internal details out of the tool response while the
# real exception is logged server-side for diagnostics.
_GENERIC_ERROR = (
    "Heron Intelligence is temporarily unavailable. Please try again or "
    "contact support if the issue persists."
)

# Import provider lazily to avoid circular import at module load time.
# http_app.py calls get_oauth_provider() and passes it to FastMCP.
def _build_mcp() -> FastMCP:
    from heronintelligence_mcp.oauth_provider import get_oauth_provider  # noqa: PLC0415

    _base_url = os.environ.get(
        "MCP_BASE_URL", "https://mcp.heron-intelligence.com"
    )
    return FastMCP(
        "Heron Intelligence",
        auth_server_provider=get_oauth_provider(),
        auth=AuthSettings(
            issuer_url=AnyHttpUrl(_base_url),
            resource_server_url=AnyHttpUrl(_base_url),
            client_registration_options=ClientRegistrationOptions(
                enabled=True,
                valid_scopes=["mcp:read", "mcp:write"],
                default_scopes=["mcp:read"],
            ),
        ),
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
    instructions=(
        "Heron Intelligence provides financial research intelligence based on curated earnings call "
        "transcripts and due diligence interviews.\n\n"
        "Tool overview:\n"
        "- search_company: resolves a ticker, name, or description to a company id used by the other tools.\n"
        "- get_company_overview: returns coverage statistics (transcript counts, date range) for a company id.\n"
        "- get_recent_transcripts: lists transcript metadata for one or more company ids.\n"
        "- get_transcript_content: returns the verbatim Q&A for a specific transcript id.\n"
        "- start_research_project / define_research_brief / configure_research_project / "
        "generate_research_questions / submit_research_project / get_project_status / "
        "prepopulate_research_configuration: end-to-end research project intake flow."
    ),
    )


mcp = _build_mcp()

_API_URL: str = os.environ.get("HERON_BASE_URL", "")
_API_KEY: str = os.environ.get("HERON_API_KEY", "")
_TIMEOUT: float = float(os.environ.get("HERON_TIMEOUT", "120.0"))


def _headers() -> dict[str, str]:
    key = _request_api_key.get("") or _API_KEY
    return {"X-API-KEY": key, "Content-Type": "application/json"}


def _check_config() -> str | None:
    # In HTTP mode the api key comes from the URL / OAuth via ContextVar; the
    # env-var fallback is only used by stdio mode. The backend URL is always
    # required and supplied at deploy time.
    if not _API_URL:
        return "Heron Intelligence is not configured. Please contact support."
    if not (_API_KEY or _request_api_key.get("")):
        return "Heron Intelligence credentials are missing. Please reconnect."
    return None


class QuotaExceededError(Exception):
    """Raised when the API returns HTTP 429."""


def _quota_error_message(resp: httpx.Response) -> str:
    """Return a human-readable message for 429 quota responses."""
    reset_at = resp.headers.get("X-Quota-Reset", "")
    retry_after = resp.headers.get("Retry-After", "")
    try:
        detail = resp.json().get("detail", "Quota exceeded.")
    except Exception:
        detail = "Quota exceeded."
    msg = f"Heron Intelligence quota limit reached: {detail}"
    if reset_at:
        msg += f" Your quota resets at {reset_at}."
    elif retry_after:
        msg += f" Retry after {retry_after} seconds."
    msg += " Please contact us to upgrade your plan."
    return msg


def _api_error_message(exc: httpx.HTTPStatusError) -> str:
    """Return a clean error message from an HTTP error response."""
    status = exc.response.status_code
    if status >= 500:
        return f"Service error ({status}). Please try again."
    try:
        detail = exc.response.json().get("detail", "")
        if detail:
            first_line = str(detail).split("\n")[0]
            return f"Error {status}: {first_line}"
    except Exception:
        pass
    return f"Error {status}"


def _api_error_payload(exc: httpx.HTTPStatusError) -> dict[str, Any]:
    """Return a structured error payload from an HTTP error response.

    When the backend returns a structured 4xx body — e.g. 422 `unknown_field`
    with `valid_fields`, or 409 `wrong_step` with `expected_steps` and `hint`
    — pass the payload through intact so the caller can act on it (choose the
    canonical field name, orient to the right step, etc.). Flattening to a
    string loses the signal that lets the caller self-correct.
    """
    status = exc.response.status_code
    if status >= 500:
        return {
            "error": f"Service error ({status}). Please try again.",
            "status_code": status,
        }
    try:
        body = exc.response.json()
        detail = body.get("detail")
        if isinstance(detail, dict):
            return {**detail, "status_code": status}
        if detail:
            return {"error": str(detail), "status_code": status}
    except Exception:
        pass
    return {"error": f"Error {status}", "status_code": status}


async def _post(path: str, body: dict) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.post(f"{_API_URL}{path}", json=body, headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


async def _get(path: str) -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
        resp = await client.get(f"{_API_URL}{path}", headers=_headers())
        if resp.status_code == 429:
            raise QuotaExceededError(_quota_error_message(resp))
        resp.raise_for_status()
        return resp.json()


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get authenticated user",
        readOnlyHint=True,
    )
)
async def whoami() -> str:
    """
    Return the email of the user authenticated on this MCP session.

    Returns a JSON object: {"email": "user@example.com"} or {"email": null} if the
    session was authenticated via a legacy URL-path api_key (no user identity
    attached).
    """
    email = _request_user_email.get()
    return json.dumps({"email": email})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Search companies",
        readOnlyHint=True,
    )
)
async def search_company(query: str, limit: int = 1) -> str:
    """
    Search the Heron Intelligence catalog and return the best-matching company.

    The returned company id is the input expected by the other Heron Intelligence tools.

    Accepts:
    - An exact ticker symbol (e.g. "NU", "MELI") — fastest and most unambiguous match.
    - A company name (e.g. "Nubank", "MercadoLibre") — useful when the ticker is unknown.
    - A free-text description (e.g. "Brazilian digital bank") — least precise.

    Set limit > 1 to receive multiple candidates ranked by similarity score (best first).

    Args:
        query: Ticker symbol, company name, or description
               (e.g. "Nubank", "NU", "Mexican e-commerce")
        limit: Max number of companies to return (default: 1, max: 10)

    Returns:
        JSON with the best-matched company including enriched metadata:
        {
          "id": "uuid",
          "name": "Nu Holdings Ltd.",
          "ticker": "NU",
          "exchange": "NYSE",
          "is_public": true,
          "official_name": "Nu Holdings Ltd.",
          "description": "...",
          "website": "https://...",
          "sector_name": "Financials",
          "sector_gics_code": "40",
          "industry_name": "Consumer Finance",
          "industry_gics_code": "402020",
          "geography_name": "Brazil",
          "isin": "...",
        }

        IMPORTANT — lineage resolution:
        The tool automatically resolves subsidiaries and legacy names to their current
        root parent. Searching "MetaMap" returns Incode Technologies Inc. (its parent).
        Searching "Facebook" returns Meta Platforms Inc. Transcript coverage includes
        the full corporate family (all subsidiaries) automatically.

        Returns {"error": "..."} if no match is found or the API is unreachable.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/companies/search", {"query": query, "limit": limit})
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="List recent transcripts",
        readOnlyHint=True,
    )
)
async def get_recent_transcripts(
    company_id: str | None = None,
    company_ids: list[str] | None = None,
    quarters: int = 3,
    limit: int = 20,
    offset: int = 0,
    due_diligence_type: str | None = None,
    source_tone: str | None = None,
    call_quality: str | None = None,
    query: str | None = None,
) -> str:
    """
    List metadata for transcripts in the Heron Intelligence library.

    Either company_id or company_ids must be supplied — unscoped library searches are
    not allowed. Pass company_ids (list) to pull transcripts from multiple companies
    in one call. Returns metadata only; use get_transcript_content to read verbatim Q&A.

    See the Heron Intelligence API reference for filter semantics:
    https://docs.heron-intelligence.com/api-reference/interviews

    Supports:
    - Browsing transcripts for a known company (pass company_id)
    - Pulling transcripts from multiple companies at once (pass company_ids list)
    - Pagination for large result sets via the offset parameter
    - Free-text search via the `query` parameter

    Key fields returned per transcript:
    - due_diligence_type: type of interview ("MDD" = management DD, "BDD" = business DD)
    - call_quality: transcript reliability signal — "Good", "Fair", "Poor"
    - source_tone: interviewee sentiment — "Positive", "Negative", "Neutral"
    - sentiment: overall sentiment of the transcript
    - call_date: date of the interview or earnings call
    - company_name: name of the company discussed
    - id: identifier accepted by get_transcript_content

    Args:
        company_id:          Single company UUID from search_company (REQUIRED unless company_ids is set)
        company_ids:         List of company UUIDs to search across multiple companies at once (REQUIRED unless company_id is set)
        quarters:            Look-back window in quarters (default: 3, always enforced)
        limit:               Max transcripts to return per page (default: 20, max: 1000)
        offset:              Number of results to skip for pagination (default: 0)
        due_diligence_type:  Filter by DD type: "MDD" or "BDD" (optional)
        source_tone:         Filter by tone: "Positive", "Negative", or "Neutral" (optional)
        call_quality:        Filter by quality: "Good", "Fair", or "Poor" (optional)
        query:               Free-text search query to find relevant transcripts (optional)

    Returns:
        JSON object with a "transcripts" list. Each entry:
        {
          "id": "uuid",
          "title": "Senior Executive, Marketing (2015-2023)",
          "company_name": "Meta Platforms, Inc.",
          "call_date": "2026-03-16",
          "due_diligence_type": "MDD",
          "source_tone": "Positive",
          "call_quality": "Good",
          "sentiment": "positive",
          "summary": "AI-driven ad impression growth..."
        }
        Returns {"error": "..."} on failure.
    """
    if not company_id and not company_ids:
        return json.dumps({"error": "company_id or company_ids is required. Use search_company first to get a company UUID."})
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "quarters": quarters,
            "limit": max(1, min(limit, 1000)),
            "offset": max(0, offset),
        }
        if company_id is not None:
            body["company_id"] = company_id
        if company_ids is not None:
            body["company_ids"] = company_ids
        if due_diligence_type is not None:
            body["due_diligence_type"] = due_diligence_type
        if source_tone is not None:
            body["source_tone"] = source_tone
        if call_quality is not None:
            body["call_quality"] = call_quality
        if query is not None:
            body["query"] = query
        data = await _post("/api/v1/transcripts/search", body)
        # Strip internal field from each transcript object
        transcripts = data if isinstance(data, list) else data.get("transcripts", data.get("results", data))
        if isinstance(transcripts, list):
            for t in transcripts:
                t.pop("transcript_type", None)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get company coverage overview",
        readOnlyHint=True,
    )
)
async def get_company_overview(company_id: str) -> str:
    """
    Return a high-level summary of a company's research coverage in Heron Intelligence.

    The response includes transcript count, date range covered, breakdown by document
    type, and a recommended look-back window. It is lighter than get_recent_transcripts
    when only coverage shape is needed (no per-transcript metadata).

    Args:
        company_id: The company ID returned by search_company

    Returns:
        JSON with coverage summary:
        {
          "company_id": "uuid",
          "company_name": "Meta Platforms, Inc.",
          "ticker": "META",
          "total_transcripts": 8,
          "earliest_date": "2022-08-10",
          "latest_date": "2024-11-12",
          "quarters_available": 8,
          "recommended_quarters": 4
        }
        Returns {"error": "..."} on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        # Fetch company metadata and transcripts in parallel
        import asyncio
        company_task = asyncio.create_task(_get(f"/api/v1/companies/{company_id}"))
        transcripts_task = asyncio.create_task(
            _post("/api/v1/transcripts/search", {"company_id": company_id, "quarters": 40, "limit": 1000})
        )
        company_data_result = await asyncio.gather(company_task, transcripts_task, return_exceptions=True)
        company_meta = company_data_result[0] if not isinstance(company_data_result[0], Exception) else {}
        data = company_data_result[1] if not isinstance(company_data_result[1], Exception) else {}

        transcripts: list[dict] = data if isinstance(data, list) else data.get("transcripts", data.get("results", []))

        if not transcripts:
            return json.dumps(
                {
                    "company_id": company_id,
                    "company_name": company_meta.get("name") or company_meta.get("official_name"),
                    "ticker": company_meta.get("ticker"),
                    "total_transcripts": 0,
                    "earliest_date": None,
                    "latest_date": None,
                    "quarters_available": 0,
                    "recommended_quarters": 0,
                    "by_dd_type": {},
                    "by_transcript_type": {},
                    "by_data_provider": {},
                }
            )

        # Dates — field is call_date in the API response
        dates = sorted(t["call_date"] for t in transcripts if t.get("call_date"))

        # Distinct quarters
        quarters_set: set[str] = set()
        for t in transcripts:
            d = t.get("call_date", "")
            if len(d) >= 7:
                year, month = d[:4], int(d[5:7])
                quarter = (month - 1) // 3 + 1
                quarters_set.add(f"{year}Q{quarter}")

        n_quarters = len(quarters_set)
        recommended = min(n_quarters, 8)

        # Breakdown by DD type (BDD / MDD / null)
        by_dd_type: dict[str, int] = {}
        for t in transcripts:
            key = t.get("due_diligence_type") or "unknown"
            by_dd_type[key] = by_dd_type.get(key, 0) + 1

        # Breakdown by transcript type
        by_transcript_type: dict[str, int] = {}
        for t in transcripts:
            key = t.get("transcript_type") or "unknown"
            by_transcript_type[key] = by_transcript_type.get(key, 0) + 1

        # Breakdown by data provider (human-readable name)
        by_data_provider: dict[str, int] = {}
        for t in transcripts:
            key = t.get("data_provider_name") or "unknown"
            by_data_provider[key] = by_data_provider.get(key, 0) + 1

        summary = {
            "company_id": company_id,
            "company_name": company_meta.get("name") or company_meta.get("official_name"),
            "ticker": company_meta.get("ticker"),
            "total_transcripts": len(transcripts),
            "earliest_date": dates[0] if dates else None,
            "latest_date": dates[-1] if dates else None,
            "quarters_available": n_quarters,
            "recommended_quarters": recommended,
            "by_dd_type": by_dd_type,
            "by_transcript_type": by_transcript_type,
            "by_data_provider": by_data_provider,
        }
        return json.dumps(summary, ensure_ascii=False)

    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps({"error": f"Heron API returned an error ({exc.response.status_code}). Please try again or contact support."})
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get transcript content",
        readOnlyHint=True,
    )
)
async def get_transcript_content(transcript_id: str) -> str:
    """
    Retrieve the full verbatim content of a specific transcript.

    The response is an array of Q&A pairs, each with:
    - speaker: name of the person speaking
    - role: their role (e.g. "CEO", "Analyst", "CFO")
    - text: verbatim spoken content

    Note: transcripts can be large (10,000+ tokens). The transcript_id is obtained
    from a previous call to get_recent_transcripts.

    Args:
        transcript_id: The UUID of the transcript (from get_recent_transcripts)

    Returns:
        JSON with full transcript payload. Key metadata fields include:
        - data_provider_name: human-readable source name (e.g. "Heron AI", "Blue Heron")
        The Q&A content is in a "content" array:
        [
          {"speaker": "David Vélez", "role": "CEO", "text": "We saw record..."},
          {"speaker": "James Friedman", "role": "Analyst", "text": "Can you clarify..."},
          ...
        ]
        Returns {"error": "..."} on failure or {"found": false} if ID is not found.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _get(f"/api/v1/transcripts/{transcript_id}")
        if isinstance(data, dict):
            data.pop("transcript_type", None)
            data.pop("is_primary", None)
            data.pop("data_provider_id", None)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 404:
            return json.dumps({"found": False, "message": f"No transcript found: '{transcript_id}'"})
        return json.dumps({"error": _api_error_message(exc)})
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


# ============================================================
# Research Projects MCP Flow (Steps 1–4)
# ============================================================

@mcp.tool(
    annotations=ToolAnnotations(
        title="Start research project",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def start_research_project() -> str:
    """
    Create a new Research Project intake record and return its project_id.

    The returned project_id is the input expected by the rest of the research
    project flow tools (define_research_brief, configure_research_project,
    generate_research_questions, submit_research_project, get_project_status,
    prepopulate_research_configuration).

    Returns:
        JSON with { "project_id": "uuid" }
        or { "error": "..." } on failure.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/start-project", {})
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Define research brief (Step 1)",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def define_research_brief(
    project_id: str,
    user_message: str,
    chat_history: list[dict],
    current_artifact: dict | None = None,
    last_follow_up: str | None = None,
) -> str:
    """
    Step 1 (Scope) — Process one turn of the research brief conversation.

    Submits one user turn to the Heron Intelligence backend, persists the conversation,
    and returns the updated Research Brief artifact along with a per-element readiness
    assessment and a suggested follow-up question.

    The Research Brief artifact has five elements: Research Objective, Primary Use,
    Scope (type + context), Desired Insight, and Preferred Experts.

    The backend returns structured 4xx payloads:
    - 409 `wrong_step` includes `current_step`, `expected_steps`, and `hint`.
    - 404 `project_not_found` indicates an invalid project_id.
    Use get_project_status(project_id) to re-orient when a structured error is returned.

    Args:
        project_id:       The project_id returned by start_research_project
        user_message:     The user's latest message
        chat_history:     Full conversation so far as [{role, content}, ...]
        current_artifact: The artifact returned by the previous call (None on first turn)
        last_follow_up:   The follow_up_question from the previous call (None on first turn)

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "artifact": { research_objective, primary_use, scope, desired_insight, preferred_experts },
          "global_readiness": "Low | Medium | High",
          "element_readiness": { objective, use, scope, insight, experts },
          "follow_up_question": "string",
          "next_action": "continue_conversation"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "project_id": project_id,
            "user_message": user_message,
            "chat_history": chat_history,
        }
        if current_artifact is not None:
            body["current_artifact"] = current_artifact
        if last_follow_up is not None:
            body["last_follow_up"] = last_follow_up
        data = await _post("/api/v1/intake/research-brief", body)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Configure research project (Step 2)",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def configure_research_project(
    project_id: str,
    user_message: str,
    chat_history: list[dict],
    force_next_step: bool = False,
) -> str:
    """
    Step 2 (Setup) — Process one turn of the conversational project configuration.

    Submits the user's message to the Heron Intelligence backend, which extracts the
    relevant canonical Step 2 fields, persists them to the project, and returns:
    - `configuration_summary`: every field captured so far
    - `follow_up_question`: the next clarifying question
    - `off_topic`: true when the user's message did not address Step 2 (callers
      should treat the follow-up as a clarification, not as a new field)
    - `next_action`: "continue_collecting" or "invoke_generate_research_questions"
    - `mentioned_fields`: canonical fields updated this turn

    The backend owns the Step 2 field vocabulary; the user message is forwarded as-is.

    Structured 4xx responses include:
    - 409 `wrong_step`: project is not in Step 2 — `hint` names the tool to use.
    - 404 `project_not_found`: invalid project_id.

    Args:
        project_id:      The project_id from start_research_project.
        user_message:    The user's latest message — forwarded as-is.
        chat_history:    Step 2 conversation so far as [{role, content}, ...].
                         Step 1 messages are not required — the brief artifact
                         is already available to the extractor.
        force_next_step: Set True only when the user explicitly chose to move
                         to Step 3 with the fields captured so far.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "configuration_summary": { all fields collected },
          "missing_required_fields": [list],
          "next_question_group": { "name": "...", "fields": [...], "prompt": "..." },
          "next_action": "continue_collecting | invoke_generate_research_questions",
          "mentioned_fields": [ list of canonical fields updated this turn ],
          "off_topic": true | false,
          "follow_up_question": "string — ask this next, verbatim"
        }
        On error, JSON with status_code + the structured fields described above.
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/configure-project", {
            "project_id": project_id,
            "user_message": user_message,
            "chat_history": chat_history,
            "force_next_step": force_next_step,
        })
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Generate research questions (Step 3)",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def generate_research_questions(
    project_id: str,
    action: str = "generate_all",
    existing_items: dict | None = None,
    target_item_id: str | None = None,
) -> str:
    """
    Step 3 (Topics & Questions) — Generate, curate, and manage research topics and questions.

    Three actions are supported:
    - "generate_all": initial generation of system-proposed topics + questions from
      the Research Brief and Step 2 configuration.
    - "regenerate_all": replace all system-proposed items with a fresh batch.
    - "regenerate_single": replace one item identified by target_item_id.

    Item taxonomy in the response:
    - system_proposed_topics / system_proposed_questions: AI-suggested items
    - user_added_topics / user_added_questions: items provided by the user
    - total_items: combined count, capped at 15 by the backend
    - next_action: "continue_curating" or "invoke_submit_research_project"

    Structured 4xx responses include 409 `wrong_step` when Step 2 is incomplete or
    the project has already been submitted; the `hint` field names the next tool.

    Args:
        project_id:     The project_id from start_research_project
        action:         "generate_all" | "regenerate_all" | "regenerate_single"
        existing_items: Current item state dict with keys:
                          user_added_topics, user_added_questions,
                          item_type (for regenerate_single),
                          item_to_replace (for regenerate_single)
        target_item_id: ID of the item to replace (for regenerate_single)

    Returns:
        JSON with:
        {
          "system_proposed_topics": [...],
          "system_proposed_questions": [...],
          "user_added_topics": [...],
          "user_added_questions": [...],
          "total_items": N,
          "next_action": "continue_curating | invoke_submit_research_project"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        body: dict[str, Any] = {
            "project_id": project_id,
            "action": action,
        }
        if existing_items is not None:
            body["existing_items"] = existing_items
        if target_item_id is not None:
            body["target_item_id"] = target_item_id
        data = await _post("/api/v1/intake/topics-questions", body)
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Submit research project (Step 4)",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def submit_research_project(
    project_id: str,
    submission_type: str,
    research_brief: dict | None = None,
    configuration: dict | None = None,
    confirmed_items: list | None = None,
) -> str:
    """
    Step 4 — Submit the research project to a Heron Intelligence representative.

    The submission_type controls what content is sent to the reviewer:
      "full"           — full brief + configuration + confirmed topics/questions
      "bh_review_only" — Research Brief only (Step 1)
      "partial_step2"  — Research Brief + configuration collected so far
      "partial_step3"  — Research Brief + configuration + confirmed items so far

    The project state is preserved on partial submissions, so the flow can be resumed
    from the corresponding step.

    Returns 409 `wrong_step` if the project is already in `current_step="submitted"`.

    Args:
        project_id:      The project_id from start_research_project
        submission_type: "full" | "bh_review_only" | "partial_step2" | "partial_step3"
        research_brief:  Final brief artifact (for context / display)
        configuration:   Final configuration (for context / display)
        confirmed_items: Final confirmed topics/questions (for context / display)

    Returns:
        JSON with:
        {
          "confirmation_number": "uuid",
          "submitted_at": "ISO timestamp",
          "message": "Your research project has been submitted..."
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post("/api/v1/intake/submit-project", {
            "project_id": project_id,
            "submission_type": submission_type,
        })
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Get research project status",
        readOnlyHint=True,
    )
)
async def get_project_status(project_id: str) -> str:
    """
    Return a read-only snapshot of a Research Project's current flow state.

    The response includes:
    - `current_step`: "scope" | "setup" | "questions" | "submitted"
    - `status`: "submitted" | null
    - `completed_fields` / `missing_fields`: Step 2 field progress
    - `last_artifact`: most recent Research Brief artifact
    - `global_readiness` / `element_readiness`: brief readiness scores
    - `last_follow_up`: the last follow-up question asked, or null

    This is the canonical recovery tool when a 409 `wrong_step` or 422 response
    is received from another tool in the flow.

    Args:
        project_id: The project_id from start_research_project.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "current_step": "scope | setup | questions | submitted",
          "status": "submitted | null",
          "completed_fields": ["list of Step 2 fields already captured"],
          "missing_fields": ["Step 2 fields still required"],
          "last_artifact": { research brief artifact },
          "global_readiness": "Low | Medium | High | null",
          "element_readiness": { per-element readiness scores },
          "last_follow_up": "the last follow-up question asked, or null"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _get(f"/api/v1/intake/project-status/{project_id}")
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})


@mcp.tool(
    annotations=ToolAnnotations(
        title="Prepopulate research configuration",
        readOnlyHint=False,
        destructiveHint=False,
    )
)
async def prepopulate_research_configuration(project_id: str) -> str:
    """
    Step 1 → Step 2 transition helper.

    Reads the Research Brief artifact and Step 1 conversation history, then asks the
    backend AI to infer Step 2 configuration fields (companies, executives,
    geographies, source types, etc.) and merges them into the project. The
    `prepopulated_fields` list in the response identifies which fields were filled.

    Intended to be called once per project, after Step 1 is complete and before the
    first call to configure_research_project. The backend returns 409 `wrong_step`
    if the project has already moved beyond Step 2.

    Args:
        project_id: The project_id from start_research_project.

    Returns:
        JSON with:
        {
          "project_id": "uuid",
          "prepopulated_fields": ["list of canonical field names filled"],
          "configuration_summary": { merged configuration },
          "missing_required_fields": [...],
          "next_question_group": { ... },
          "next_action": "continue_collecting | invoke_generate_research_questions",
          "note": "optional message when nothing could be pre-populated"
        }
    """
    err = _check_config()
    if err:
        return json.dumps({"error": err})
    try:
        data = await _post(
            "/api/v1/intake/prepopulate-setup", {"project_id": project_id}
        )
        return json.dumps(data, ensure_ascii=False)
    except QuotaExceededError as exc:
        return json.dumps({"error": str(exc)})
    except httpx.HTTPStatusError as exc:
        return json.dumps(_api_error_payload(exc), ensure_ascii=False)
    except Exception:
        logger.exception("Unhandled error in Heron Intelligence MCP tool")
        return json.dumps({"error": _GENERIC_ERROR})
