"""Shared async context variables used across the MCP server."""
from __future__ import annotations

import contextvars
from typing import Optional

# Per-request API key — set by HTTP middleware before each MCP handler call.
# Empty-string default allows stdio mode to fall through to the HERON_API_KEY env var.
_request_api_key: contextvars.ContextVar[str] = contextvars.ContextVar(
    "heron_request_api_key", default=""
)

# Per-request user id (consumption_user_id UUID) — set by OAuth JWT validation.
# None = unknown (legacy hk-* URL-path mode, or stdio).
_request_user_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "heron_request_user_id", default=None
)

# Per-request user email — set by OAuth JWT validation from mcp_clients.email.
# None = unknown (legacy hk-* URL-path mode, or stdio).
_request_user_email: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "heron_request_user_email", default=None
)
