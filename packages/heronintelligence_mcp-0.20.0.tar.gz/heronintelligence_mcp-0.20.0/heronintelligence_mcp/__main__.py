"""Entry point — supports stdio (default) and HTTP transport modes.

Stdio (Claude Desktop / Claude Code):
    heronintelligence-mcp                     # uses HERON_API_KEY env var

HTTP (Claude.ai remote connector):
    MCP_TRANSPORT=http heronintelligence-mcp  # each request carries key via OAuth or URL path
"""
import os
from heronintelligence_mcp.server import mcp


def main() -> None:
    transport = os.environ.get("MCP_TRANSPORT", "stdio").lower()
    if transport == "http":
        # HTTP mode: key is extracted per-request from URL path by http_app middleware
        import uvicorn
        from heronintelligence_mcp.http_app import create_app
        uvicorn.run(
            "heronintelligence_mcp.http_app:create_app",
            factory=True,
            host="0.0.0.0",
            port=int(os.environ.get("PORT", "8080")),
            workers=int(os.environ.get("WORKERS", "2")),
            log_level="info",
            timeout_keep_alive=300,
            proxy_headers=True,
            forwarded_allow_ips="*",
        )
    else:
        # Stdio mode (default): key comes from HERON_API_KEY env var
        mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
