# Per-user OAuth for Claude Org Connectors

End-to-end design for how a Claude organization installs the Heron Intelligence MCP connector and how we identify each seat individually without any visible login UX.

## The problem

For Claude personal, we manually mint an `oauth_client_id` + `oauth_client_secret` in Sauron and hand them to the user. Each user pastes the pair into their own Claude connector config.

For Claude **org**, the admin installs a connector once at the org level. Every seat under that org shares the same credentials. We have no way to tell Ana from Bob in our server logs or tools — they all look like one client.

## The goal

Each seat in a Claude org gets its own identity in our MCP, tied to their Anthropic seat email — **without any visible login UX**. Standards used:

- RFC 7591 — Dynamic Client Registration
- RFC 8707 — Resource Indicators
- MCP authorization spec 2025-11-25

---

## Actors & data stores

| Actor | What they do |
|---|---|
| **Heron ops (internal admin)** | Pre-provisions users in Sauron |
| **Claude org admin (customer)** | Installs the connector for their org |
| **Org seats (customer users)** | Use the MCP from Claude |

| Table (in `core_data_product`) | Role |
|---|---|
| `mcp_clients` | Directory of pre-provisioned users. One row per email. Source of truth for who has access. |
| `oauth_dcr_clients` | One row per org installation. Created dynamically by Claude via `/register`. |
| `oauth_auth_codes` | Short-lived PKCE codes (10 min TTL). |
| `oauth_refresh_tokens` | SHA-256 hashed, 30-day TTL. |

---

## Step 0 — Pre-provisioning (before the org arrives)

**Who:** Heron ops via Sauron UI.

For each seat that should get access:

1. Sauron → **MCP Clients** tab → **New Client**.
2. Enter: `full_name`, `email` (must match the user's Anthropic seat email exactly), `tier`, optional `consumption_user_id`.
3. Sauron inserts a row into `mcp_clients` with `status='active'`. An `api_key` is auto-generated for this user.

**Result:** an access-control list keyed by email.

```
mcp_clients
┌──────┬──────────────────┬─────────┬─────────────────────┐
│ id   │ email            │ api_key │ consumption_user_id │
├──────┼──────────────────┼─────────┼─────────────────────┤
│ uuid │ ana@acme.com     │ hk-a1   │ uuid-ana            │
│ uuid │ bob@acme.com     │ hk-b2   │ uuid-bob            │
└──────┴──────────────────┴─────────┴─────────────────────┘
```

## Step 1 — Org admin installs the connector

**Who:** Acme's admin in the Claude org admin panel.

1. Paste URL: `https://mcp.heron-intelligence.com/mcp`.
2. Leave client_id/secret fields **empty**. (This is what makes it different from personal Claude.)
3. Install.

**What happens under the hood:**

```http
# Claude's first probe
GET https://mcp.heron-intelligence.com/mcp
→ 401 Unauthorized
  WWW-Authenticate: Bearer resource_metadata="https://mcp.heron-intelligence.com/.well-known/oauth-protected-resource"
```

Claude follows the discovery chain:

```http
GET /.well-known/oauth-protected-resource
→ { "authorization_servers": ["https://mcp.heron-intelligence.com"], ... }

GET /.well-known/oauth-authorization-server
→ { "registration_endpoint": "https://mcp.heron-intelligence.com/register", ... }
```

Claude performs Dynamic Client Registration:

```http
POST /register
{
  "redirect_uris": ["https://claude.ai/api/mcp/auth_callback"],
  "client_name": "Claude for Acme Inc"
}

→ 201
{
  "client_id": "hc-f3a9-...",
  "client_secret": "cs-7c2e-..."
}
```

Claude stores the pair internally (scoped to the Acme org connector). On our side, a row lands in `oauth_dcr_clients`:

```
oauth_dcr_clients
┌──────────────┬─────────────────────┬──────────────────────┐
│ client_id    │ client_secret_hash  │ client_name          │
├──────────────┼─────────────────────┼──────────────────────┤
│ hc-f3a9-...  │ sha256(cs-7c2e-...) │ Claude for Acme Inc  │
└──────────────┴─────────────────────┴──────────────────────┘
```

Admin is done. Zero manual work on Heron's side for the org setup.

## Step 2 — First user of the org invokes the MCP

**Who:** `ana@acme.com` opens Claude and triggers a Heron tool.

Claude notices it has no token for Ana on this connector and kicks off the OAuth flow **silently** (no visible UI — opens and closes in ~200ms):

```
GET /authorize?
    response_type=code
    &client_id=hc-f3a9-...                    ← Acme's DCR client
    &redirect_uri=https://claude.ai/api/mcp/auth_callback
    &code_challenge=<PKCE S256>
    &code_challenge_method=S256
    &resource=https%3A%2F%2Fmcp.heron-intelligence.com
    &login_hint=ana%40acme.com                ← ← THE IDENTITY
    &state=xyz
```

**Key detail:** Claude passes the seat email in `login_hint`. Claude knows this email because the seat is tied to a verified Anthropic account (SSO or email verification).

## Step 3 — Server resolves identity without UI

Logic in `oauth_provider.authorize()`:

```
1. Look up client_id = hc-f3a9-...
   → found in oauth_dcr_clients → this is a DCR client (org install)

2. DCR client → login_hint is required
   → read "ana@acme.com" from query params

3. Look up ana@acme.com in mcp_clients.email WHERE status='active'
   → match: mcp_client_id=uuid-ana, api_key=hk-a1, consumption_user_id=uuid-ana

4. Persist auth_code in oauth_auth_codes (atomic, single-use, 10min TTL)

5. 302 → https://claude.ai/api/mcp/auth_callback?code=...&state=xyz
```

Claude exchanges the code:

```http
POST /token
  grant_type=authorization_code
  code=...
  client_id=hc-f3a9-...
  client_secret=cs-7c2e-...
  code_verifier=...

→ 200
{
  "access_token": "<JWT>",
  "refresh_token": "<opaque>",
  "token_type": "Bearer",
  "expires_in": 3600
}
```

Decoded JWT claims:

```json
{
  "iss": "https://mcp.heron-intelligence.com",
  "sub": "uuid-ana",
  "aud": "https://mcp.heron-intelligence.com",
  "client_id": "hc-f3a9-...",
  "mcp_client_id": "uuid-ana",
  "scope": "mcp:read",
  "exp": 1714500000,
  "iat": 1714496400,
  "jti": "..."
}
```

- `sub` — user identity (consumption_user_id)
- `client_id` — the org connector
- `mcp_client_id` — custom claim; direct pointer to the `mcp_clients` row

Ana never sees a login screen.

## Step 4 — Every subsequent call identifies the user

```http
POST /mcp
Authorization: Bearer <Ana's JWT>
```

`load_access_token` logic:

```
1. jwt.decode(token, OAUTH_JWT_SECRET, algorithms=["HS256"],
              audience=MCP_CANONICAL_URI, issuer=OAUTH_JWT_ISSUER)
   → valid claims

2. Extract mcp_client_id=uuid-ana, sub=uuid-ana

3. Look up mcp_clients.id = uuid-ana (cached 5 min) → api_key=hk-a1, status='active'

4. Set two ContextVars for this request:
   _request_api_key = "hk-a1"      (for the Heron backend call)
   _request_user_id = "uuid-ana"   (for per-user logic in tools)

5. Pass to the MCP handler.
```

Any tool can now do:

```python
user_id = _request_user_id.get()     # "uuid-ana"
api_key = _request_api_key.get()     # "hk-a1"
# Filter, log, or authorize based on user_id
```

## Step 5 — Bob comes in

Bob opens his Claude. Same `client_id` (the Acme DCR one), **different** `login_hint=bob@acme.com`. Server resolves `bob@acme.com` → `uuid-bob`, issues a JWT with `sub=uuid-bob`. Bob and Ana now have distinct tokens with distinct identities under the same org connector.

## Step 6 — Unprovisioned user

`carlos@acme.com` tries. `login_hint=carlos@acme.com` doesn't match any `mcp_clients.email`. Server returns:

```
302 → https://claude.ai/api/mcp/auth_callback?error=access_denied&state=xyz
```

Claude surfaces an error to Carlos. Ops adds him in Sauron; next attempt succeeds.

---

## Architecture diagram

```
┌── Heron ops ───┐              ┌── Claude org ──┐        ┌── Acme users ──┐
│                │              │                │        │                │
│ Sauron UI:     │              │ Admin:         │        │ Ana, Bob, ...  │
│ INSERT row in  │              │ /register →    │        │                │
│ mcp_clients    │              │ client_id/sec  │        │                │
│ (per email)    │              │ (silent DCR)   │        │                │
└────────────────┘              └────────────────┘        └────────┬───────┘
                                                                   │
                ┌── the backend service ──┐       ┌── MCP (AS + RS) ──┐    │
                │ mcp_clients      │◄──────┤ /register          │   │
                │ oauth_dcr_clients│◄──────┤ /authorize         │◄──┘
                │ oauth_auth_codes │◄──────┤   + login_hint     │
                │ oauth_refresh_   │◄──────┤ /token → JWT       │
                │ tokens           │       │ /mcp  ← JWT        │
                │ (internal API,   │       │   → user_id +      │
                │  X-Service-Key)  │       │     api_key        │
                └──────────────────┘       └────────────────────┘
```

---

## Key answers at a glance

- **How does an org sign up?** Admin pastes our MCP URL into Claude. DCR handles everything. Zero manual work on our side per org.
- **How do we identify each user?** Via `login_hint=email` that Claude passes on every first-time `/authorize` request, matched against `mcp_clients.email`. Email = seat = identity.
- **What if the user isn't pre-provisioned?** 302 redirect with `error=access_denied`. Ops adds them in Sauron; retry succeeds.
- **Per-new-user cost:** one INSERT in `mcp_clients` from Sauron (~30s of ops time). No Claude-side work needed.
- **Revoke a user:** `UPDATE mcp_clients SET status='inactive'`. Next JWT validation fails → forced re-auth → denied.
- **Revoke an entire org:** `UPDATE oauth_dcr_clients SET status='revoked' WHERE client_id=...`. No user from that org can re-authenticate.
- **Token lifetime:** access JWT = 1h, refresh token = 30d. Refresh rotates atomically — each rotate invalidates the previous refresh token.

---

## Backward compatibility

Three populations coexist on the same endpoints. None of them require reconfiguration post-deploy.

| Group | Flow | What happens post-deploy |
|---|---|---|
| **A. Legacy URL-path** (`/hk-abc/mcp`) | api_key in the URL path | Untouched. Same middleware path-rewrite. |
| **B. Personal Claude with manual OAuth** | Ops-minted `client_id` / `secret` pasted into personal Claude | URLs preserved. `/authorize` auto-approves using the user bound to the manual `client_id` in `mcp_clients`. No `login_hint` required. Access tokens become JWT (Claude treats them as opaque strings either way). |
| **C. Org Claude (new)** | DCR + `login_hint` | Described above. |

The `/authorize` endpoint branches internally on `registration_source`:

- **Manual** client_id → user bound 1:1 to the client row; ignore `login_hint`.
- **DCR** client_id → require `login_hint`; look up email in `mcp_clients.email`.

---

## Security properties

- **PKCE S256** is mandatory on all authorize flows.
- **RFC 8707 resource parameter** is enforced — tokens are audience-bound to `https://mcp.heron-intelligence.com`. Other MCP servers can't accept our tokens.
- **JWT HS256** with a single shared secret stored in your deployment's secret store. Rotating the secret invalidates all outstanding tokens → forces reauth across the fleet.
- **DCR client secret hashing:** SHA-256 in DB. Plaintext only leaves the server once, at DCR response time.
- **Refresh token hashing:** SHA-256. Plaintext only lives in Claude's store.
- **Refresh rotation:** each rotate invalidates the previous refresh token in the same transaction. Replay of an old refresh token fails.
- **No interactive login form** means there's no surface for phishing against our domain. The trust anchor is Claude's authentication of the seat.

## Trust model

We trust Claude's assertion that `login_hint` matches the authenticated seat. This holds because:

1. Claude org requires verified email / SSO before a seat can use any connector.
2. The `login_hint` value comes from Anthropic's session state, not user input in a form.

If that assumption breaks (e.g. Claude bug sends wrong `login_hint`), a user could impersonate another seat **within the same org**. They cannot impersonate users from a different org — different `client_id`, different `oauth_dcr_clients` row, and `mcp_clients` lookups are independent.

For higher-assurance use cases (regulated customers), a future opt-in flag per `oauth_dcr_clients` row could require magic-link verification on first use per user.

---

## Environment variables

**aura-core-mcp only** (the backend service doesn't encode/decode JWTs):

| Var | Purpose | Notes |
|---|---|---|
| `OAUTH_JWT_SECRET` | HS256 signing key for JWT access tokens | Generate with `openssl rand -hex 32`. Store in your secrets manager. |
| `OAUTH_JWT_ISSUER` | JWT `iss` claim | Default: `https://mcp.heron-intelligence.com` |
| `MCP_CANONICAL_URI` | JWT `aud` claim + RFC 8707 resource | Default: `https://mcp.heron-intelligence.com` |
| `OAUTH_ACCESS_TOKEN_TTL` | Access token TTL in seconds | Default: 3600 (1 hour) |
| `MCP_SERVICE_KEY` | Shared service-to-service auth for the backend service internal endpoints | Already exists |
| `HERON_BASE_URL` | Base URL of the backend service | Already exists |

**the backend service** — no new env vars for this feature (migration adds tables; the `MCP_SERVICE_KEY` header is already there).

---

## Token lifetime & refresh

- **Access JWT:** 1h TTL, stateless (no DB lookup beyond the `mcp_clients` row).
- **Refresh token:** 30d TTL, opaque, SHA-256 hashed at rest.
- When access expires, Claude calls `POST /token` with `grant_type=refresh_token`. The server:
  1. Hashes the presented refresh, finds the row, checks `revoked_at IS NULL AND expires_at > now()`.
  2. In a single transaction: marks the old row revoked, inserts a new row with the same user/client binding.
  3. Issues a fresh JWT + the new refresh token.
- Replay of the old refresh token fails (already revoked).

## Known limitations

- **In-memory `_pending_codes` map:** the MCP caches PKCE challenge + user binding per auth_code in memory (for ~10 min). An MCP process restart loses in-flight codes; any Claude client mid-exchange will retry and succeed on the next attempt (~seconds). For multi-instance deployments, add a peek endpoint on the backend service to fetch the challenge without consuming.
- **Manual-client secrets in plaintext:** `mcp_clients.oauth_client_secret` stays plaintext for Group B backward compatibility. Timing-safe comparison is already in place (`secrets.compare_digest`). A separate migration can move these to hashes, forcing a one-time secret re-issuance for manual clients.
