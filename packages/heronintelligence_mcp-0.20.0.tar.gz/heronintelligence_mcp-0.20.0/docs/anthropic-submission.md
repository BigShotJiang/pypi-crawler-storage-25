# Anthropic Connectors Directory — Submission Worksheet

This document is the canonical source-of-truth for every field in the
[MCP Directory Submission Form](https://claude.com/docs/connectors/building/submission).
Copy each section into the form when submitting.

Fields marked **⏳ user-supplied** must be filled in by Aura Research before
submission (marketing copy, demo credentials, etc.). Everything else is final.

---

## Company information

| Field | Value |
| --- | --- |
| Company / organization name | Aura Research |
| Company / organization URL | https://auraresearch.ai |
| Primary contact name | D. Fernández |
| Primary contact email | dfernandez@heron-intelligence.com |
| Primary contact role | ⏳ user-supplied (e.g. Founder / Head of Product) |
| Anthropic point of contact | ⏳ user-supplied (if known) |

---

## Server details

| Field | Value |
| --- | --- |
| MCP server name (no "MCP" / "Server") | **Heron Intelligence** |
| Server URL type | Universal URL |
| Server URL | `https://mcp.heron-intelligence.com/mcp` |
| Tagline (48 chars) | Higher-conviction research, faster due diligence |

### Description (92 words)

> Heron Intelligence combines rigorous human research with a powerful
> technology layer — bringing institutional-grade due diligence directly
> into your AI workflow. Search a curated library of earnings call
> transcripts and management interviews, check coverage depth on any
> company (subsidiaries and legacy names auto-resolved), and filter by
> due-diligence type, sentiment, or call quality before pulling verbatim
> Q&A. When initial coverage isn't enough, launch a custom research
> project right from chat. Built for hedge funds, private equity,
> long-only investors, and quants who need to cut through market noise
> and act with conviction.

This is the version to paste into the form. It preserves the brand voice and
positioning of the marketing-approved draft (rigorous human research,
institutional-grade due diligence, audience callout, "cut through market
noise and act with conviction") while only naming capabilities the active
toolset delivers — search + coverage + transcript filtering + verbatim Q&A
(`search_company`, `get_company_overview`, `get_recent_transcripts`,
`get_transcript_content`) and the custom research project intake flow
(`start_research_project` → `submit_research_project`).

### Use cases

#### 1. Quick company coverage check

Before committing research bandwidth to a full engagement, use Heron
Intelligence to instantly check how much institutional coverage exists on
any company.

> *"How much research coverage does Heron Intelligence have on Amazon? Is
> there enough data to support a meaningful analysis?"*

Tools exercised: `search_company`, `get_company_overview`.

#### 2. Subsidiary & legacy name resolution

Heron Intelligence automatically resolves subsidiaries, spinoffs, and
rebranded entities to their current parent company, so coverage is never
missed because of a name change.

> *"Find Heron Intelligence's research coverage for Facebook and show me
> what's available under their current corporate entity."*

Tools exercised: `search_company` (auto-resolves Facebook → Meta Platforms),
`get_company_overview`, `get_recent_transcripts`.

#### 3. Management DD vs business DD filtering

Heron Intelligence tags every transcript by due diligence type — management
interviews (MDD) or business intelligence (BDD) — so the research most
relevant to the current workflow can be isolated quickly.

> *"Show me only the management due diligence transcripts available for
> Amazon from the last two quarters."*

Tools exercised: `search_company`, `get_recent_transcripts` with
`due_diligence_type="MDD"` and `quarters=2`.

### Connection requirements

> Requires a Heron Intelligence account. A 14-day free trial is available; paid
> tiers start at USD 199/month. No special infrastructure setup is required —
> users connect through Claude.ai's custom-connector flow and authorize via
> OAuth 2.1.

### Read / write capabilities

**Read + Write.**

- Read tools expose curated companies, transcripts, and project state.
- Write tools manage the conversational research-project intake flow
  (start, brief, configure, generate, submit). All writes are
  non-destructive — they create or update project records but do not delete
  user data.

### Is this an MCP App (interactive UI)?

**No.** All tool responses are JSON / text. There are no embedded UI
components. Screenshots are not required for submission.

### Third-party connections / web access

**N/A.** The server only calls Aura Research's first-party API
(`api.heron-intelligence.com`). No open-web fetching, no third-party AI model
integration exposed through the MCP, no third-party data retrieval or
modification.

### Data handling checklist

- [x] Server only accesses data explicitly requested by the user
- [x] No data is stored beyond session requirements
- [x] Data transmission is encrypted (HTTPS/TLS)
- [x] GDPR compliant — see privacy policy

### Personal health data

**No.** Heron Intelligence does not process medical records, lab results, or
health metrics.

### Categories

- Financial Services
- Data & Analytics

### Sponsored content / advertisements

**No.** Tool responses are not influenced by paid placements.

---

## Authentication details

| Field | Value |
| --- | --- |
| Authentication type | OAuth 2.0 |
| Auth client | Static OAuth Client **and** Dynamic OAuth Client (DCR / RFC 7591) |
| Static client ID | `1234` |
| Static client secret | `s9asdfiasdf` |
| Transport | Streamable HTTP (Server-Sent Events also supported as legacy) |

The OAuth flow follows RFC 6749 + RFC 8707 (resource indicators) and is fully
documented in [`oauth-org-flow.md`](./oauth-org-flow.md). Access tokens are
short-lived JWTs (HS256, 1h TTL); refresh tokens are opaque (30d TTL,
SHA-256-hashed at rest, single-use rotation).

---

## Tools

The server exposes 12 tools. Every tool includes a `title` and the
appropriate `readOnlyHint` / `destructiveHint` annotations.

| Tool name | Title | Read-only | Destructive | What it does |
| --- | --- | :-: | :-: | --- |
| `whoami` | Get authenticated user | ✅ | — | Returns the email of the user authenticated on the current MCP session. |
| `search_company` | Search companies | ✅ | — | Resolves a ticker, name, or description to a Heron Intelligence company id. |
| `get_company_overview` | Get company coverage overview | ✅ | — | Returns transcript counts, date range, and breakdown of available coverage for a company. |
| `get_recent_transcripts` | List recent transcripts | ✅ | — | Lists transcript metadata (title, date, type, sentiment) for one or more companies, with pagination and filters. |
| `get_transcript_content` | Get transcript content | ✅ | — | Returns the verbatim Q&A content of a specific transcript. |
| `get_project_status` | Get research project status | ✅ | — | Returns the current step, completed fields, and last artifact for a research project. |
| `start_research_project` | Start research project | ❌ | ❌ | Creates a new research project record and returns its `project_id`. |
| `define_research_brief` | Define research brief (Step 1) | ❌ | ❌ | Step 1 of the intake flow — processes one user turn to refine the Research Brief artifact. |
| `prepopulate_research_configuration` | Prepopulate research configuration | ❌ | ❌ | One-shot Step 1 → Step 2 transition helper that infers configuration fields from the brief. |
| `configure_research_project` | Configure research project (Step 2) | ❌ | ❌ | Step 2 — processes one user turn to fill the project's canonical configuration fields. |
| `generate_research_questions` | Generate research questions (Step 3) | ❌ | ❌ | Step 3 — generates, regenerates, or curates the project's topics and questions (15-item cap). |
| `submit_research_project` | Submit research project (Step 4) | ❌ | ❌ | Step 4 — submits the project to a Heron Intelligence representative. |

No tool accepts a freeform HTTP method or endpoint path — there is no
catch-all `api_request`-style tool.

---

## Documentation & support

| Field | Value |
| --- | --- |
| MCP server documentation | https://docs.heron-intelligence.com/mcp |
| Privacy policy | https://www.heron-intelligence.com/privacy-policy |
| Data Processing Agreement URL | ⏳ user-supplied (if applicable) |
| Support channel | mailto:dfernandez@heron-intelligence.com |

---

## Test credentials

The demo connection uses a static OAuth client; no user email/password is
required. Provide the reviewer with these credentials in the form's "Test
credentials" section:

| Credential | Value |
| --- | --- |
| OAuth client ID | `1234` |
| OAuth client secret | `s9asdfiasdf` |

### Step-by-step setup for the reviewer

1. Open Claude.ai → Settings → Connectors → "Add custom connector".
2. Enter URL: `https://mcp.heron-intelligence.com/mcp`.
3. Click "Authorize". You will be redirected to Heron Intelligence.
4. Enter the OAuth client ID and secret above when prompted. No email or
   password is required — the static client is bound to a Professional-tier
   demo account on the Heron side.
5. Approve the requested scopes (`mcp:read`, `mcp:write`).
6. Return to Claude.ai. The connector should now show `Connected`.
7. In a new conversation, paste each of the three example prompts (see Use
   cases above). Confirm each tool returns sensible data within ~10 seconds.

Estimated review time: **≤15 minutes**.

The demo account has Professional-tier quotas, sufficient to exercise every
tool multiple times during a review session.

---

## Allowed link URIs

The server does **not** call `ui/open-link`. This field can be omitted from
the form.

(If we add deep-link support in the future, the entries to declare are:
`https://app.heron-intelligence.com`, `https://docs.heron-intelligence.com`.)

---

## Branding

| Asset | Value |
| --- | --- |
| Server logo (SVG) | https://cdn.prod.website-files.com/6977893683bf78f2e332f1d7/6977acf468f7454dbd5d2dda_Blue%20Heron%20Logo%20Exploration_%201%203.svg |
| Favicon (PNG, 256px) | https://cdn.prod.website-files.com/6977893683bf78f2e332f1d7/69948c3d22c6039096288887_Heron%20Intelligence%20favicon%20A-%20256px.png |
| Promotional screenshots | Not required (server is not an MCP App) |

---

## Launch readiness

| Field | Value |
| --- | --- |
| GA date | ⏳ user-supplied |
| Surfaces tested in | Claude.ai (web), Claude Desktop, Claude Code |

---

## Pre-submission checklist (self-review)

- [x] Read tools and write tools are split into separate functions
- [x] Every tool includes `title` and `readOnlyHint` or `destructiveHint`
- [x] All tool names are ≤64 characters
- [x] No tool accepts a freeform HTTP method / endpoint path parameter
- [x] Tool descriptions describe behavior; none instruct Claude to take
      unrelated actions or call other tools the user did not request
- [x] Origin-header validation is enforced by `DualAuthMiddleware`
- [x] All HTTP traffic is TLS-terminated; the canonical MCP URL is HTTPS
- [x] OAuth 2.1 with PKCE S256 is implemented (RFC 6749, 7636, 8707)
- [x] Server only calls first-party APIs (Aura Research)
- [x] Privacy policy is publicly available
- [x] Public documentation page exists for the MCP server
- [x] Test credentials are provisioned and documented
- [x] Health endpoint (`GET /health`) responds without auth
- [x] Pytest suite passes (44/44)

---

## Update process

For changes after the initial submission, email `mcp-review@anthropic.com`
with subject `[Heron Intelligence] update: <topic>`.
