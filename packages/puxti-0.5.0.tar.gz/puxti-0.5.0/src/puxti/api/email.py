"""Transactional email via Resend — sends API keys out-of-band."""
from __future__ import annotations

import html as _html
import logging
import os

import resend

logger = logging.getLogger(__name__)

_FROM = "Puxti <hello@getpuxti.com>"
_RESEND_API_KEY: str = os.environ.get("RESEND_API_KEY", "")
_ADMIN_EMAIL: str = os.environ.get("ADMIN_EMAIL", "")
_WEB_BASE_URL: str = os.environ.get("WEB_BASE_URL", "https://getpuxti.com")

if _RESEND_API_KEY:
    resend.api_key = _RESEND_API_KEY


def send_api_key(to_email: str, name: str, api_key: str, workspace_id: str = "") -> bool:
    """Send the API key to the applicant by email.

    Returns True if the email was accepted by Resend, False otherwise.
    Never raises — callers should check the return value and decide how to handle failure.
    """
    if not _RESEND_API_KEY:
        logger.warning("RESEND_API_KEY not set — skipping email delivery for %s", to_email)
        return False

    first_name = _html.escape(name.split()[0] if name else "there")

    pitch_html = ""
    pitch_text = ""
    if workspace_id:
        safe_ws = _html.escape(workspace_id)
        pitch_url = f"{_WEB_BASE_URL}/puxti_manager_pitch_generator.html?workspace_id={safe_ws}"
        pitch_html = f"""
<p style="margin-top:20px;">
  <strong>Need to convince your manager?</strong><br/>
  We built a tool that writes the pitch for you — based on your stack and a real pain point.<br/>
  <a href="{pitch_url}" style="color:#39B4E3;">Generate your manager pitch →</a>
</p>
"""
        pitch_text = (
            f"\nNeed to convince your manager?\n"
            f"We built a tool that writes the pitch for you:\n"
            f"  {pitch_url}\n"
        )

    email_html = f"""
<p>Hi {first_name},</p>

<p>Welcome to the Puxti closed beta. Here is your API key:</p>

<p style="font-family:monospace;font-size:16px;background:#f4f4f4;padding:12px 16px;border-radius:6px;">
  {api_key}
</p>

<p>Store it somewhere safe — we will not show it again.</p>

<p>To connect the CLI:</p>

<pre style="background:#1e1e2e;color:#cdd6f4;padding:12px 16px;border-radius:6px;font-size:13px;">pip install puxti
puxti auth {api_key}</pre>
{pitch_html}
<p>Reply to this email if you have any questions.</p>

<p>— The Puxti team</p>
"""

    text = (
        f"Hi {first_name},\n\n"
        f"Welcome to the Puxti closed beta. Here is your API key:\n\n"
        f"  {api_key}\n\n"
        f"Store it somewhere safe — we will not show it again.\n\n"
        f"To connect the CLI:\n\n"
        f"  pip install puxti\n"
        f"  puxti auth {api_key}\n"
        f"{pitch_text}\n"
        f"Reply to this email if you have any questions.\n\n"
        f"— The Puxti team\n"
    )

    try:
        resend.Emails.send({
            "from": _FROM,
            "to": [to_email],
            "subject": "Your Puxti API key",
            "html": email_html,
            "text": text,
        })
        return True
    except Exception:
        logger.exception("Failed to send API key email to %s", to_email)
        return False


def send_admin_notification(entry_id: str, name: str, email: str, company: str, title: str) -> bool:
    """Notify the admin of a new waitlist signup.

    Returns True if sent, False otherwise. Never raises.
    """
    if not _RESEND_API_KEY or not _ADMIN_EMAIL:
        return False

    safe_name = _html.escape(name)
    safe_email = _html.escape(email)
    safe_company = _html.escape(company)
    safe_title = _html.escape(title)

    email_html = f"""
<p><strong>New Puxti signup</strong></p>
<table style="border-collapse:collapse;font-size:14px;">
  <tr><td style="padding:4px 12px 4px 0;color:#666;">Name</td><td>{safe_name}</td></tr>
  <tr><td style="padding:4px 12px 4px 0;color:#666;">Email</td><td>{safe_email}</td></tr>
  <tr><td style="padding:4px 12px 4px 0;color:#666;">Company</td><td>{safe_company}</td></tr>
  <tr><td style="padding:4px 12px 4px 0;color:#666;">Title</td><td>{safe_title}</td></tr>
  <tr><td style="padding:4px 12px 4px 0;color:#666;">Entry ID</td><td style="font-family:monospace;">{entry_id}</td></tr>
</table>
<p style="margin-top:16px;">To approve:<br>
<code style="background:#f4f4f4;padding:4px 8px;">puxti admin approve {entry_id}</code></p>
"""

    text = (
        f"New Puxti signup\n\n"
        f"Name:     {name}\n"
        f"Email:    {email}\n"
        f"Company:  {company}\n"
        f"Title:    {title}\n"
        f"Entry ID: {entry_id}\n\n"
        f"To approve:\n  puxti admin approve {entry_id}\n"
    )

    try:
        resend.Emails.send({
            "from": _FROM,
            "to": [_ADMIN_EMAIL],
            "subject": f"New Puxti signup — {name}, {company}",
            "html": email_html,
            "text": text,
        })
        return True
    except Exception:
        logger.exception("Failed to send admin notification for entry %s", entry_id)
        return False
