"""Shared rate limiter instance — import this everywhere instead of creating a new Limiter."""
import os

from slowapi import Limiter
from slowapi.util import get_remote_address
from starlette.requests import Request

# Set TRUSTED_PROXY=true only when the app is deployed behind a load balancer or
# reverse proxy that rewrites X-Forwarded-For to the real client IP. When false
# (the default), the socket peer address is used and X-Forwarded-For is ignored,
# so clients cannot spoof a different IP to bypass per-IP rate limits.
_TRUSTED_PROXY: bool = os.environ.get("TRUSTED_PROXY", "").lower() in ("1", "true", "yes")


def _get_client_ip(request: Request) -> str:
    """Return the IP address used as the rate-limit key.

    When TRUSTED_PROXY=true the leftmost entry in X-Forwarded-For is used
    (the real client IP as seen by the proxy). Otherwise the socket peer
    address is used directly, so X-Forwarded-For is ignored and cannot be
    spoofed to bypass rate limits.
    """
    if _TRUSTED_PROXY:
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            return forwarded_for.split(",")[0].strip()
    return get_remote_address(request)


limiter = Limiter(key_func=_get_client_ip, default_limits=["200/minute"])
