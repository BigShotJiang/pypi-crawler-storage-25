"""
SQLAlchemy async engine, table definitions, and DB initialisation.

Usage:
    from puxti.api.database import make_engine, init_db

    engine = make_engine(database_url)
    await init_db(engine)          # creates tables if they don't exist
"""
from __future__ import annotations

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Integer,
    MetaData,
    String,
    Table,
    text,
)
from sqlalchemy.ext.asyncio import AsyncEngine, create_async_engine

metadata = MetaData()

workspaces = Table(
    "workspaces",
    metadata,
    Column("id", String, primary_key=True),
    Column("name", String, nullable=False),
    Column("email", String, nullable=False, unique=True),
    Column("plan", String, nullable=False, server_default="trial"),
    Column("created_at", DateTime(timezone=True), nullable=False),
)

trials = Table(
    "trials",
    metadata,
    Column("workspace_id", String, primary_key=True),
    Column("activated_at", DateTime(timezone=True), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=False),
    Column("propagations_used", Integer, nullable=False, server_default=text("0")),
    Column("propagations_limit", Integer, nullable=False),
    Column("captures_used", Integer, nullable=False, server_default=text("0")),
    Column("captures_limit", Integer, nullable=False),
)

api_keys = Table(
    "api_keys",
    metadata,
    Column("key_hash", String, primary_key=True),
    Column("workspace_id", String, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("last_used_at", DateTime(timezone=True), nullable=True),
    Column("revoked_at", DateTime(timezone=True), nullable=True),
)

waitlist = Table(
    "waitlist",
    metadata,
    Column("id", String, primary_key=True),
    Column("name", String, nullable=False),
    Column("email", String, nullable=False, unique=True),
    Column("company", String, nullable=False),
    Column("title", String, nullable=False),
    Column("consent", Boolean, nullable=False),
    Column("submitted_at", DateTime(timezone=True), nullable=False),
    Column("status", String, nullable=False, server_default=text("'pending'")),
    Column("reviewed_at", DateTime(timezone=True), nullable=True),
)


pitch_usage = Table(
    "pitch_usage",
    metadata,
    Column("workspace_id", String, primary_key=True),
    Column("count", Integer, nullable=False, server_default=text("0")),
    Column("last_used_at", DateTime(timezone=True), nullable=True),
)


def make_engine(database_url: str) -> AsyncEngine:
    return create_async_engine(database_url, pool_pre_ping=True)


async def init_db(engine: AsyncEngine) -> None:
    """Create all tables if they don't exist (idempotent)."""
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
