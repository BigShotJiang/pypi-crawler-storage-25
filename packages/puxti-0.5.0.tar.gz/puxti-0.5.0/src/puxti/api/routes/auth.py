"""Auth and usage endpoints — /v1/auth/* and /v1/usage/*."""
from __future__ import annotations

import hashlib
import logging
import secrets
import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Header, HTTPException, Request

from puxti.api.email import send_api_key
from puxti.api.limiter import limiter
from puxti.api.models import (
    RecordUsageRequest,
    RecordUsageResponse,
    SignupRequest,
    SignupResponse,
    TrialStatus,
    ValidateRequest,
    ValidateResponse,
)
from puxti.api.store import store

logger = logging.getLogger(__name__)

router = APIRouter()

TRIAL_DAYS = 30
TRIAL_PROPAGATION_LIMIT = 10
TRIAL_CAPTURE_LIMIT = 25

# Common consumer email providers — block these at signup.
# Lower-cased for case-insensitive comparison.
_CONSUMER_DOMAINS: frozenset[str] = frozenset({
    "gmail.com", "googlemail.com",
    "hotmail.com", "hotmail.co.uk", "hotmail.fr", "hotmail.de", "hotmail.es", "hotmail.it",
    "outlook.com", "outlook.fr", "outlook.de", "outlook.es", "outlook.co.uk",
    "live.com", "live.co.uk", "live.fr", "live.de",
    "msn.com",
    "yahoo.com", "yahoo.co.uk", "yahoo.fr", "yahoo.de", "yahoo.es", "yahoo.it",
    "ymail.com",
    "icloud.com", "me.com", "mac.com",
    "aol.com",
    "protonmail.com", "proton.me",
    "mail.com",
    "zoho.com",
    "yandex.com", "yandex.ru",
    "qq.com", "163.com", "126.com",
    "gmx.com", "gmx.de", "gmx.net",
    "web.de",
    "tutanota.com",
    "fastmail.com",
    "hey.com",
})


def _is_business_email(email: str) -> bool:
    parts = email.split("@")
    if len(parts) != 2:
        return False
    domain = parts[1].lower()
    return domain not in _CONSUMER_DOMAINS


def _hash_key(raw_key: str) -> str:
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _make_api_key() -> str:
    return "pk_live_" + secrets.token_urlsafe(32)


async def _trial_status(workspace_id: str) -> TrialStatus | None:
    trial = await store.get_trial(workspace_id)
    if trial is None:
        return None
    now = datetime.now(timezone.utc)
    active = trial["expires_at"] > now
    return TrialStatus(
        active=active,
        expires_at=trial["expires_at"],
        propagations_used=trial["propagations_used"],
        propagations_limit=trial["propagations_limit"],
        captures_used=trial["captures_used"],
        captures_limit=trial["captures_limit"],
    )


@router.post("/v1/auth/validate", response_model=ValidateResponse)
@limiter.limit("30/minute")
async def validate(request: Request, body: ValidateRequest) -> ValidateResponse:
    key_hash = _hash_key(body.api_key)
    key_record = await store.get_key_by_hash(key_hash)

    if key_record is None or key_record.get("revoked_at") is not None:
        return ValidateResponse(valid=False)

    workspace = await store.get_workspace(key_record["workspace_id"])
    if workspace is None:
        return ValidateResponse(valid=False)

    await store.touch_key(key_hash)

    trial = await _trial_status(workspace["id"])

    return ValidateResponse(
        valid=True,
        workspace_id=workspace["id"],
        plan=workspace["plan"],
        trial=trial,
    )


@router.post("/v1/usage/record", response_model=RecordUsageResponse)
@limiter.limit("120/minute")
async def record_usage(request: Request, body: RecordUsageRequest) -> RecordUsageResponse:
    key_hash = _hash_key(body.api_key)
    key_record = await store.get_key_by_hash(key_hash)

    if key_record is None or key_record.get("revoked_at") is not None:
        raise HTTPException(status_code=401, detail="Invalid API key")

    workspace = await store.get_workspace(key_record["workspace_id"])
    if workspace is None:
        raise HTTPException(status_code=404, detail="Workspace not found")

    # Only count usage for trial workspaces
    if workspace["plan"] == "trial":
        trial = await store.get_trial(workspace["id"])
        if trial is not None:
            if body.event == "propagation":
                await store.increment_trial(workspace["id"], "propagations_used")
            elif body.event == "capture":
                await store.increment_trial(workspace["id"], "captures_used")
            # scan is metered but has no hard limit — record for analytics only

    trial_status = await _trial_status(workspace["id"])
    return RecordUsageResponse(recorded=True, trial=trial_status)


@router.post("/v1/auth/signup", response_model=SignupResponse)
@limiter.limit("5/hour")
async def signup(request: Request, body: SignupRequest) -> SignupResponse:
    if not _is_business_email(body.email):
        raise HTTPException(
            status_code=422,
            detail=(
                "Please use a business email address. "
                "Consumer email providers (Gmail, Outlook, etc.) are not accepted."
            ),
        )

    if await store.get_workspace_by_email(body.email):
        raise HTTPException(
            status_code=409,
            detail="An account with this email already exists. Check your inbox for your API key.",
        )

    workspace_id = "ws_" + uuid.uuid4().hex
    now = datetime.now(timezone.utc)
    raw_key = _make_api_key()
    key_hash = _hash_key(raw_key)

    # Attempt email delivery before writing anything to the database.
    # If delivery fails, the user can retry — their email is not yet consumed
    # by the uniqueness check, so the next attempt gets a fresh key.
    delivered = send_api_key(
        to_email=body.email, name=body.name, api_key=raw_key, workspace_id=workspace_id
    )
    if not delivered:
        logger.error("Email delivery failed for %s — aborting signup", body.email)
        raise HTTPException(
            status_code=502,
            detail=(
                "We could not deliver your API key by email. "
                "Please try again or contact hello@getpuxti.com."
            ),
        )

    # Write workspace + trial + key atomically. If this fails the user received
    # a key that will not authenticate. Log the key_hash (never the raw key) and
    # workspace_id so an operator can manually insert the rows to recover, or the
    # user can retry — their email is not in the DB so the uniqueness check passes.
    try:
        await store.create_account(
            workspace_id=workspace_id,
            name=body.name,
            email=body.email,
            created_at=now,
            expires_at=now + timedelta(days=TRIAL_DAYS),
            key_hash=key_hash,
            propagations_limit=TRIAL_PROPAGATION_LIMIT,
            captures_limit=TRIAL_CAPTURE_LIMIT,
        )
    except Exception:
        logger.exception(
            "DB write failed after email delivery — workspace_id=%s key_hash=%s email=%s",
            workspace_id,
            key_hash,
            body.email,
        )
        raise HTTPException(
            status_code=502,
            detail=(
                "Your API key was sent but we failed to activate your account. "
                "Please contact hello@getpuxti.com with your email address and we will resolve it."
            ),
        )

    # Provision Neo4j workspace — non-fatal if graph is unavailable
    graph_driver = getattr(request.app.state, "graph_driver", None)
    if graph_driver is not None:
        try:
            await graph_driver.provision_workspace(workspace_id)
        except Exception:
            logger.exception("Failed to provision Neo4j workspace %s — continuing", workspace_id)

    return SignupResponse(
        workspace_id=workspace_id,
        message="API key sent to your email address.",
    )


@router.get("/v1/auth/status")
@limiter.limit("30/minute")
async def status(request: Request, authorization: str = Header(..., alias="Authorization")) -> dict:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Authorization header must use Bearer scheme.")
    api_key = authorization[7:].strip()
    key_hash = _hash_key(api_key)
    key_record = await store.get_key_by_hash(key_hash)
    if key_record is None:
        raise HTTPException(status_code=401, detail="Invalid API key")

    workspace = await store.get_workspace(key_record["workspace_id"])
    if workspace is None:
        raise HTTPException(status_code=404, detail="Workspace not found")

    trial = await _trial_status(workspace["id"])
    return {
        "workspace_id": workspace["id"],
        "plan": workspace["plan"],
        "trial": trial.model_dump() if trial else None,
    }
