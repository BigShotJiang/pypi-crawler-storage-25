"""Pydantic models for the puxti auth API (request/response shapes)."""
from __future__ import annotations

from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---------------------------------------------------------------------------
# Request bodies
# ---------------------------------------------------------------------------


class ValidateRequest(BaseModel):
    api_key: str = Field(max_length=128)


class RecordUsageRequest(BaseModel):
    api_key: str = Field(max_length=128)
    event: Literal["propagation", "capture", "scan"]


class SignupRequest(BaseModel):
    email: EmailStr
    name: str = Field(min_length=1, max_length=120)


# ---------------------------------------------------------------------------
# Response shapes
# ---------------------------------------------------------------------------


class TrialStatus(BaseModel):
    active: bool
    expires_at: Optional[datetime]
    propagations_used: int
    propagations_limit: int
    captures_used: int
    captures_limit: int


class ValidateResponse(BaseModel):
    valid: bool
    workspace_id: Optional[str] = None
    plan: Optional[str] = None
    trial: Optional[TrialStatus] = None


class RecordUsageResponse(BaseModel):
    recorded: bool
    trial: Optional[TrialStatus] = None


class SignupResponse(BaseModel):
    workspace_id: str
    message: str  # "API key sent to <email>"


# ---------------------------------------------------------------------------
# Waitlist
# ---------------------------------------------------------------------------


class PitchRequest(BaseModel):
    workspace_id: str = Field(min_length=3, max_length=64, pattern=r"^ws_[0-9a-f]+$")
    role: Literal[
        "Analytics Engineer",
        "Data Engineer",
        "Lead Data Engineer",
        "Data Architect",
        "Other",
    ]
    manager_role: Literal[
        "Engineering Manager",
        "Head of Data",
        "CTO",
        "VP of Engineering",
        "Director of Analytics",
    ]
    stack: Literal[
        "dbt + BigQuery",
        "dbt + Snowflake",
        "dbt + Databricks",
        "dbt + Airflow + BigQuery",
        "dbt + Airflow + Snowflake",
        "Other",
    ]
    company_size: Literal[
        "small startup (under 50 people)",
        "mid-size (50–500 people)",
        "large (500+ people)",
    ]
    tone: Literal[
        "concise and technical",
        "warm and collaborative",
        "business-focused with ROI framing",
    ]
    pain_point: str = Field(min_length=10, max_length=1000)


class PitchResponse(BaseModel):
    pitch: str
    attempts_used: int
    attempts_remaining: int


class WaitlistRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    company: str = Field(min_length=1, max_length=200)
    title: str = Field(min_length=1, max_length=120)
    consent: bool

    @field_validator("consent")
    @classmethod
    def consent_must_be_true(cls, v: bool) -> bool:
        if not v:
            raise ValueError("Consent is required to join the waitlist.")
        return v


class WaitlistResponse(BaseModel):
    id: str
    message: str


class WaitlistEntry(BaseModel):
    id: str
    name: str
    email: str
    company: str
    title: str
    consent: bool
    submitted_at: datetime
    status: Literal["pending", "approved", "rejected"] = "pending"
    reviewed_at: Optional[datetime] = None


class WaitlistListResponse(BaseModel):
    entries: list[WaitlistEntry]
    total: int
    pending: int
    approved: int
    rejected: int


class ApproveResponse(BaseModel):
    entry_id: str
    workspace_id: str
    email_sent: bool
    message: str


class RejectResponse(BaseModel):
    entry_id: str
    message: str


# ---------------------------------------------------------------------------
# DB-style dataclasses (used by route handlers until a real ORM is wired in)
# ---------------------------------------------------------------------------


class WorkspaceRecord(BaseModel):
    id: str
    name: str
    created_at: datetime
    plan: Literal["trial", "team", "scale", "enterprise"] = "trial"


class TrialRecord(BaseModel):
    workspace_id: str
    activated_at: datetime
    expires_at: datetime
    propagations_used: int = 0
    propagations_limit: int = 10
    captures_used: int = 0
    captures_limit: int = 25


class ApiKeyRecord(BaseModel):
    workspace_id: str
    key_hash: str  # SHA-256 of the raw key
    created_at: datetime
    last_used_at: Optional[datetime] = None
    revoked_at: Optional[datetime] = None
