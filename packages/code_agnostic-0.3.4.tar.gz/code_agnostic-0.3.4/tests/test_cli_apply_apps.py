import json
from pathlib import Path

from code_agnostic.__main__ import cli

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover
    import tomli as tomllib  # type: ignore


def _escape_toml_basic_string(value: str) -> str:
    return value.replace("\\", "\\\\").replace('"', '\\"')


def test_apply_cursor_target_writes_only_cursor_config(
    minimal_shared_config: Path, tmp_path: Path, cli_runner, enable_app
) -> None:
    enable_app("cursor")

    result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])

    assert result.exit_code == 0
    assert (tmp_path / ".cursor" / "mcp.json").exists()
    assert not (tmp_path / ".config" / "opencode" / "opencode.json").exists()


def test_apply_codex_target_writes_toml_config(
    minimal_shared_config: Path, tmp_path: Path, cli_runner, enable_app
) -> None:
    enable_app("codex")

    result = cli_runner.invoke(cli, ["apply", "-a", "codex"])

    assert result.exit_code == 0
    codex_config = tmp_path / ".codex" / "config.toml"
    assert codex_config.exists()
    assert "[mcp_servers]" not in codex_config.read_text(encoding="utf-8")


def test_apply_codex_preserves_project_trust_settings(
    minimal_shared_config: Path, tmp_path: Path, cli_runner, enable_app
) -> None:
    enable_app("codex")
    codex_path = tmp_path / ".codex" / "config.toml"
    codex_path.parent.mkdir(parents=True, exist_ok=True)
    project_a = str(tmp_path / "repo-a")
    project_b = str(tmp_path / "repo-b")
    escaped_project_a = _escape_toml_basic_string(project_a)
    escaped_project_b = _escape_toml_basic_string(project_b)
    codex_path.write_text(
        "\n".join(
            [
                f'[projects."{escaped_project_a}"]',
                'trust_level = "trusted"',
                "",
                f'[projects."{escaped_project_b}"]',
                'trust_level = "trusted"',
                "",
            ]
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "codex"])

    assert result.exit_code == 0
    payload = tomllib.loads(codex_path.read_text(encoding="utf-8"))
    assert payload["projects"][project_a]["trust_level"] == "trusted"
    assert payload["projects"][project_b]["trust_level"] == "trusted"


def test_apply_codex_deep_merges_custom_config_tables(
    minimal_shared_config: Path,
    core_root: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("codex")
    codex_path = tmp_path / ".codex" / "config.toml"
    codex_path.parent.mkdir(parents=True, exist_ok=True)
    project_a = str(tmp_path / "repo-a")
    project_b = str(tmp_path / "repo-b")
    escaped_project_a = _escape_toml_basic_string(project_a)
    escaped_project_b = _escape_toml_basic_string(project_b)
    codex_path.write_text(
        "\n".join(
            [
                f'[projects."{escaped_project_a}"]',
                'trust_level = "untrusted"',
                "",
                f'[projects."{escaped_project_b}"]',
                'trust_level = "trusted"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    (core_root / "config" / "codex.base.json").write_text(
        json.dumps(
            {
                "projects": {
                    project_a: {"trust_level": "trusted"},
                }
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "codex"])

    assert result.exit_code == 0
    payload = tomllib.loads(codex_path.read_text(encoding="utf-8"))
    assert payload["projects"][project_a]["trust_level"] == "trusted"
    assert payload["projects"][project_b]["trust_level"] == "trusted"


def test_apply_all_with_cursor_and_codex_writes_both(
    minimal_shared_config: Path, tmp_path: Path, cli_runner, enable_app
) -> None:
    enable_app("cursor")
    enable_app("codex")

    result = cli_runner.invoke(cli, ["apply", "-a", "all"])

    assert result.exit_code == 0
    cursor_payload = json.loads(
        (tmp_path / ".cursor" / "mcp.json").read_text(encoding="utf-8")
    )
    assert "mcpServers" in cursor_payload
    assert (tmp_path / ".codex" / "config.toml").exists()


def test_apply_all_preserves_mcp_timeout_for_generated_app_configs(
    minimal_shared_config: Path,
    core_root: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")
    enable_app("codex")
    enable_app("opencode")
    (core_root / "config" / "mcp.base.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "demo": {
                        "command": "uvx",
                        "args": ["tool"],
                        "timeout": 900000,
                    }
                }
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "all"])

    assert result.exit_code == 0
    cursor_payload = json.loads(
        (tmp_path / ".cursor" / "mcp.json").read_text(encoding="utf-8")
    )
    opencode_payload = json.loads(
        (tmp_path / ".config" / "opencode" / "opencode.json").read_text(
            encoding="utf-8"
        )
    )
    codex_payload = tomllib.loads(
        (tmp_path / ".codex" / "config.toml").read_text(encoding="utf-8")
    )
    assert cursor_payload["mcpServers"]["demo"]["timeout"] == 900000
    assert opencode_payload["mcp"]["demo"]["timeout"] == 900000
    assert codex_payload["mcp_servers"]["demo"]["tool_timeout_sec"] == 900.0


def test_apply_all_respects_targeted_mcp_server_keys(
    minimal_shared_config: Path,
    core_root: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")
    enable_app("codex")
    enable_app("opencode")
    (core_root / "config" / "mcp.base.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "@opencode-playwright": {"command": "npx", "args": ["playwright"]},
                    "!codex-shared": {"url": "https://example.com/mcp"},
                    "all-apps": {"command": "uvx", "args": ["demo"]},
                }
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "all"])

    assert result.exit_code == 0
    cursor_payload = json.loads(
        (tmp_path / ".cursor" / "mcp.json").read_text(encoding="utf-8")
    )
    opencode_payload = json.loads(
        (tmp_path / ".config" / "opencode" / "opencode.json").read_text(
            encoding="utf-8"
        )
    )
    codex_payload = tomllib.loads(
        (tmp_path / ".codex" / "config.toml").read_text(encoding="utf-8")
    )

    assert set(cursor_payload["mcpServers"]) == {"shared", "all-apps"}
    assert set(opencode_payload["mcp"]) == {"playwright", "shared", "all-apps"}
    assert set(codex_payload["mcp_servers"]) == {"all-apps"}


def test_apply_cursor_target_does_not_apply_workspace_links(
    minimal_shared_config: Path,
    tmp_path: Path,
    core_root: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")

    workspace_root = tmp_path / "microservice-workspace"
    workspace_root.mkdir()
    (workspace_root / "service-a" / ".git").mkdir(parents=True)

    add_result = cli_runner.invoke(
        cli,
        [
            "workspaces",
            "add",
            "--name",
            "workspace-example",
            "--path",
            str(workspace_root),
        ],
    )
    assert add_result.exit_code == 0

    # Create workspace config with rules in rules/ directory
    ws_config_dir = core_root / "workspaces" / "workspace-example"
    (ws_config_dir / "rules").mkdir(parents=True, exist_ok=True)
    (ws_config_dir / "rules" / "shared.md").write_text("rules", encoding="utf-8")

    apply_result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])
    assert apply_result.exit_code == 0

    repo_rules_link = workspace_root / "service-a" / ".cursor" / "rules"
    assert not repo_rules_link.exists()


def test_apply_cursor_writes_workspace_root_mcp_json(
    minimal_shared_config: Path,
    tmp_path: Path,
    core_root: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")

    workspace_root = tmp_path / "microservice-workspace"
    workspace_root.mkdir()
    (workspace_root / "service-a" / ".git").mkdir(parents=True)

    assert (
        cli_runner.invoke(
            cli,
            [
                "workspaces",
                "add",
                "--name",
                "workspace-example",
                "--path",
                str(workspace_root),
            ],
        ).exit_code
        == 0
    )

    ws_config_dir = core_root / "workspaces" / "workspace-example"
    (ws_config_dir / "mcp.base.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "ws-only": {"url": "https://ws.example.com/mcp"},
                }
            }
        ),
        encoding="utf-8",
    )

    apply_result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])
    assert apply_result.exit_code == 0

    mcp_path = workspace_root / ".cursor" / "mcp.json"
    assert mcp_path.is_file()
    payload = json.loads(mcp_path.read_text(encoding="utf-8"))
    assert payload["mcpServers"]["ws-only"]["url"] == "https://ws.example.com/mcp"
    sub_mcp = workspace_root / "service-a" / ".cursor" / "mcp.json"
    assert sub_mcp.is_file()
    sub_payload = json.loads(sub_mcp.read_text(encoding="utf-8"))
    assert sub_payload["mcpServers"]["ws-only"]["url"] == "https://ws.example.com/mcp"


def test_apply_cursor_writes_subrepo_mcp_json(
    minimal_shared_config: Path,
    tmp_path: Path,
    core_root: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")

    workspace_root = tmp_path / "microservice-workspace"
    workspace_root.mkdir()
    (workspace_root / "service-a" / ".git").mkdir(parents=True)

    assert (
        cli_runner.invoke(
            cli,
            [
                "workspaces",
                "add",
                "--name",
                "workspace-example",
                "--path",
                str(workspace_root),
            ],
        ).exit_code
        == 0
    )

    ws_config_dir = core_root / "workspaces" / "workspace-example"
    (ws_config_dir / "mcp.base.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "ws-only": {"url": "https://ws.example.com/mcp"},
                }
            }
        ),
        encoding="utf-8",
    )

    apply_result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])
    assert apply_result.exit_code == 0

    sub_mcp = workspace_root / "service-a" / ".cursor" / "mcp.json"
    assert sub_mcp.is_file()
    payload = json.loads(sub_mcp.read_text(encoding="utf-8"))
    assert payload["mcpServers"]["ws-only"]["url"] == "https://ws.example.com/mcp"


def test_apply_cursor_does_not_write_workspace_mcp_from_global_config_only(
    minimal_shared_config: Path,
    tmp_path: Path,
    core_root: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")

    workspace_root = tmp_path / "microservice-workspace"
    workspace_root.mkdir()
    (workspace_root / "service-a" / ".git").mkdir(parents=True)

    assert (
        cli_runner.invoke(
            cli,
            [
                "workspaces",
                "add",
                "--name",
                "workspace-example",
                "--path",
                str(workspace_root),
            ],
        ).exit_code
        == 0
    )

    (core_root / "config" / "mcp.base.json").write_text(
        json.dumps(
            {
                "mcpServers": {
                    "global-only": {"command": "npx", "args": ["-y", "global-server"]},
                }
            }
        ),
        encoding="utf-8",
    )

    apply_result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])
    assert apply_result.exit_code == 0

    assert (tmp_path / ".cursor" / "mcp.json").is_file()
    assert not (workspace_root / ".cursor" / "mcp.json").exists()
    assert not (workspace_root / "service-a" / ".cursor" / "mcp.json").exists()


def test_apply_cursor_aborts_on_invalid_cursor_json(
    minimal_shared_config: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")
    cursor_path = tmp_path / ".cursor" / "mcp.json"
    cursor_path.parent.mkdir(parents=True, exist_ok=True)
    cursor_path.write_text("{oops", encoding="utf-8")

    result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])

    assert result.exit_code != 0
    assert "Apply aborted" in result.output
    assert "Invalid JSON format" in result.output


def test_apply_codex_aborts_on_invalid_toml(
    minimal_shared_config: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("codex")
    codex_path = tmp_path / ".codex" / "config.toml"
    codex_path.parent.mkdir(parents=True, exist_ok=True)
    codex_path.write_text("[mcp_servers.demo\nurl='x'", encoding="utf-8")

    result = cli_runner.invoke(cli, ["apply", "-a", "codex"])

    assert result.exit_code != 0
    assert "Apply aborted" in result.output


def test_apply_opencode_deep_merges_permission_config(
    minimal_shared_config: Path,
    core_root: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("opencode")
    opencode_path = tmp_path / ".config" / "opencode" / "opencode.json"
    opencode_path.parent.mkdir(parents=True, exist_ok=True)
    opencode_path.write_text(
        json.dumps(
            {
                "$schema": "https://opencode.ai/config.json",
                "permission": {
                    "read": "allow",
                    "glob": {"**/*.secret": "deny"},
                },
            }
        ),
        encoding="utf-8",
    )
    (core_root / "config" / "opencode.base.json").write_text(
        json.dumps(
            {
                "$schema": "https://opencode.ai/config.json",
                "permission": {"edit": "deny"},
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "opencode"])

    assert result.exit_code == 0
    payload = json.loads(opencode_path.read_text(encoding="utf-8"))
    assert payload["permission"]["read"] == "allow"
    assert payload["permission"]["edit"] == "deny"
    assert payload["permission"]["glob"] == {"**/*.secret": "deny"}


def test_apply_opencode_legacy_permission_migration_preserves_existing_permission(
    minimal_shared_config: Path,
    core_root: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("opencode")
    opencode_path = tmp_path / ".config" / "opencode" / "opencode.json"
    opencode_path.parent.mkdir(parents=True, exist_ok=True)
    opencode_path.write_text(
        json.dumps(
            {
                "$schema": "https://opencode.ai/config.json",
                "permission": {"*": "allow"},
            }
        ),
        encoding="utf-8",
    )
    (core_root / "config" / "opencode.base.json").write_text(
        json.dumps(
            {
                "$schema": "https://opencode.ai/config.json",
                "permission": [
                    {"permission": "bash", "action": "allow"},
                ],
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "opencode"])

    assert result.exit_code == 0
    payload = json.loads(opencode_path.read_text(encoding="utf-8"))
    assert payload["permission"] == {"*": "allow"}
    assert payload["tools"]["bash"] is True


def test_apply_cursor_aborts_on_invalid_schema_key(
    minimal_shared_config: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("cursor")
    cursor_path = tmp_path / ".cursor" / "mcp.json"
    cursor_path.parent.mkdir(parents=True, exist_ok=True)
    cursor_path.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "broken": {"url": "https://example.com/mcp", "badKey": True}
                }
            }
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "cursor"])

    assert result.exit_code != 0
    assert "Invalid config schema" in result.output


def test_apply_codex_aborts_on_invalid_schema_key(
    minimal_shared_config: Path,
    tmp_path: Path,
    cli_runner,
    enable_app,
) -> None:
    enable_app("codex")
    codex_path = tmp_path / ".codex" / "config.toml"
    codex_path.parent.mkdir(parents=True, exist_ok=True)
    codex_path.write_text(
        "\n".join(
            [
                "[mcp_servers.demo]",
                'url = "https://example.com/mcp"',
                'bad_key = "boom"',
                "",
            ]
        ),
        encoding="utf-8",
    )

    result = cli_runner.invoke(cli, ["apply", "-a", "codex"])

    assert result.exit_code != 0
    assert "Invalid config schema" in result.output
