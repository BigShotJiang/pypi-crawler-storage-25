# skit-lean

A simple library to list and perform deep learning experiments extracted from `DL_Experiments.ipynb`.

## Installation

```bash
pip install skit-lean
```

## Usage

```python
from skit_lean import list, perform

# List all available experiments
list()

# View the code for a specific experiment (e.g., experiment 1)
perform(1)
```
