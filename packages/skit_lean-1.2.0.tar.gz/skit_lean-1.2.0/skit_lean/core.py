"""
Core module of skit-lean.
Provides `list`, `perform`, and `perform1` functions to interact with DL_Experiments_updated.ipynb.
"""

import json
import os
import re
import tokenize
import io

# Path to the notebook (bundled inside the package)
_NOTEBOOK_PATH = os.path.join(os.path.dirname(__file__), "DL_Experiments_updated.ipynb")
_IPMB_PATH = os.path.join(os.path.dirname(__file__), "ipmb.ipynb")

_IPMB_AIMS = {
    (1, 1): "Negative Transformation",
    (1, 2): "Log Transformation",
    (1, 3): "Power Law (Gamma) Transformation",
    (2, 1): "Histogram Plotting",
    (2, 2): "Histogram Equalization",
    (3, 1): "Average Filter (5x5)",
    (3, 2): "Gaussian Filter (5x5)",
    (3, 3): "Median Filter",
    (3, 4): "Comparison of Average, Gaussian and Median Filters",
    (4, 1): "Ideal Low Pass Filter",
    (4, 2): "Butterworth Low Pass Filter",
    (4, 3): "Gaussian Low Pass Filter",
    (6, 1): "Global Thresholding",
    (6, 2): "Multiple Thresholds",
    (11, 1): "K-Fold Cross Validation",
    (11, 2): "Leave-One-Out Cross Validation",
    (11, 3): "Stratified K-Fold Cross Validation",
    (12, 1): "Convolutional Neural Network (CNN)",
    (12, 2): "CNN with Three Convolution Layers",
}


def _load_ipmb_experiments():
    path = _IPMB_PATH if os.path.exists(_IPMB_PATH) else "ipmb.ipynb"
    with open(path, "r", encoding="utf-8") as f:
        nb = json.load(f)
    pat = re.compile(r'(?:ex|exp|experiment)\s*(\d+)\s*task\s*(\d+)', re.IGNORECASE)
    experiments = {}
    for cell in nb["cells"]:
        if cell["cell_type"] == "code":
            source_lines = cell["source"]
            if not source_lines:
                continue
            full_source = "".join(source_lines)
            lines = full_source.splitlines()
            if not lines:
                continue
            first_line = lines[0].strip()
            match = pat.match(first_line)
            if match:
                exp = int(match.group(1))
                task = int(match.group(2))
                code_without_header = "\n".join(lines[1:])
                cleaned_code = _remove_comments(code_without_header)
                if (exp, task) not in experiments:
                    experiments[(exp, task)] = cleaned_code
    return experiments


def _remove_comments(source_code):
    """
    Removes comments from the given Python source code, while preserving 
    formatting and string literals.
    """
    io_obj = io.StringIO(source_code)
    out = ''
    last_lineno = -1
    last_col = 0
    
    try:
        for tok in tokenize.generate_tokens(io_obj.readline):
            token_type = tok[0]
            token_string = tok[1]
            start_line, start_col = tok[2]
            end_line, end_col = tok[3]
            
            if token_type == tokenize.COMMENT:
                continue
                
            if start_line > last_lineno:
                last_col = 0
            if start_col > last_col:
                out += ' ' * (start_col - last_col)
            out += token_string
            last_lineno = end_line
            last_col = end_col
    except tokenize.TokenError:
        # If there's a token error (e.g., EOF in multi-line string), just return the original or best effort
        pass
        
    # remove blank lines left behind by comment removal
    return '\n'.join([line for line in out.splitlines() if line.strip()])

def _load_experiments():
    """
    Parse DL_Experiments_updated.ipynb and return a tuple of two dicts:
    (primary_experiments, secondary_experiments)
    primary_experiments: dict mapping experiment number (1-8) to {'title': title, 'code': code}
    secondary_experiments: dict mapping experiment number to alternate 'zip' code
    """
    with open(_NOTEBOOK_PATH, "r", encoding="utf-8") as f:
        nb = json.load(f)

    cells = nb["cells"]
    primary = {}
    secondary = {}

    i = 0
    primary_count = 0
    while i < len(cells):
        cell = cells[i]
        if cell["cell_type"] == "markdown":
            raw_title = "".join(cell["source"]).strip()
            title_lines = raw_title.split("\n")
            title = None
            for line in title_lines:
                stripped = line.strip().lstrip("-").strip()
                if stripped.startswith("##"):
                    stripped = stripped.lstrip("#").strip()
                if stripped:
                    title = stripped
                    break
            if title is None:
                title = raw_title

            if i + 1 < len(cells) and cells[i + 1]["cell_type"] == "code":
                code = "".join(cells[i + 1]["source"])
                
                # Check if this cell contains "Deep Learning Lab" title and skip to next
                if "Deep Learning Lab" in title and primary_count == 0:
                    i += 1
                    continue
                
                if primary_count < 8:
                    primary_count += 1
                    primary[primary_count] = {'title': title, 'code': _remove_comments(code)}
                else:
                    m = re.search(r'Experiment\s+(\d+)', title, re.IGNORECASE)
                    if m:
                        n = int(m.group(1))
                        secondary[n] = _remove_comments(code)
                i += 2
                continue
        i += 1

    return primary, secondary

def list():
    """
    Print a numbered list of all experiments found in DL_Experiments_updated.ipynb.
    """
    primary, _ = _load_experiments()
    print("=" * 60)
    print("  DL Experiments")
    print("=" * 60)
    for idx in sorted(primary.keys()):
        title = primary[idx]['title']
        print(f"  {idx}. {title}")
    print("=" * 60)
    print(f"\n  Total experiments: {len(primary)}")
    print(f"  Use perform(<number>) to view the code of an experiment.")
    print(f"  Use perform1(<number>) to view the zip version of the code (available for 2-8).")
    print()

def list_ipmb():
    """
    Print a list of all experiments and tasks found in ipmb.ipynb along with their aims.
    """
    experiments = _load_ipmb_experiments()
    print("=" * 60)
    print("  IPMB Experiments & Tasks")
    print("=" * 60)
    for exp, task in sorted(experiments.keys()):
        aim = _IPMB_AIMS.get((exp, task), f"Task {task}")
        print(f"  Exp {exp} Task {task}: {aim}")
    print("=" * 60)
    print(f"\n  Total tasks: {len(experiments)}")
    print(f"  Use perform(<exp_number>, <task_number>) to view the code of a task.")
    print()


def perform(experiment_number, task_number=None):
    if task_number is not None:
        if not isinstance(experiment_number, int) or not isinstance(task_number, int):
            print(f"Error: both arguments must be integers, got {type(experiment_number).__name__} and {type(task_number).__name__}")
            return
        experiments = _load_ipmb_experiments()
        key = (experiment_number, task_number)
        if key not in experiments:
            print(f"Error: Experiment {experiment_number} Task {task_number} not found in ipmb.ipynb")
            return
        code = experiments[key]
        print(code)
        return

    primary, _ = _load_experiments()
    if not isinstance(experiment_number, int):
        print(f"Error: experiment_number must be an integer, got {type(experiment_number).__name__}")
        return
    if experiment_number not in primary:
        print(f"Error: experiment_number must be between 1 and {len(primary)}, got {experiment_number}")
        return
    title = primary[experiment_number]['title']
    code = primary[experiment_number]['code']
    print("=" * 60)
    print(f"  Experiment {experiment_number}: {title}")
    print("=" * 60)
    print()
    print(code)
    print()
    print("=" * 60)

def perform1(experiment_number):
    """
    Print the zip version code of a specific experiment.
    
    Parameters
    ----------
    experiment_number : int
        The serial number of the experiment (2-8).
    """
    primary, secondary = _load_experiments()

    if not isinstance(experiment_number, int):
        print(f"Error: experiment_number must be an integer, got {type(experiment_number).__name__}")
        return

    if experiment_number not in secondary:
        print(f"Error: No zip version available for experiment {experiment_number}.")
        return

    title = primary[experiment_number]['title'] + " (Zip Version)"
    code = secondary[experiment_number]

    print("=" * 60)
    print(f"  Experiment {experiment_number}: {title}")
    print("=" * 60)
    print()
    print(code)
    print()
    print("=" * 60)
