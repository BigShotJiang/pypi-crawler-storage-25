# Changelog

All notable changes to `keel-llm-adapter-openai` are documented here, following
[Keep a Changelog](https://keepachangelog.com/). In `0.x`; pin exact versions.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- `OpenAIAdapter` for any OpenAI-compatible chat completions endpoint (OpenAI,
  Groq, OpenRouter, Mistral, Together, Fireworks, vLLM, Ollama). Implements
  `ModelAdapter`, `StreamingModelAdapter`, and `ToolCallingModelAdapter`.
- Full status-code → `keel-llm-protocol` error-taxonomy mapping (429 → retryable
  `RateLimitError` with `retry_after`; 401/403 → `AuthenticationError`; 400 →
  `ContextLengthError` / `ContentFilterError` / `BadRequestError`; 5xx →
  `TransientError`; timeouts → `AdapterTimeoutError`; connection errors →
  `TransientError`).
- Response parsing into `AdapterResponse` (text, `model_id`, normalized
  `finish_reason`, `Usage`, `tool_calls`); SSE streaming into `StreamChunk`;
  tool serialization + tool-call parsing.
- `health_check()` via `GET /models`.
- PEP 561 `py.typed`; `mypy --strict` clean. Tested against `httpx.MockTransport`
  (real mapping logic, no live keys).

### Notes

- This package's purpose is to **ground `keel-llm-protocol` in a real
  implementation** — proving the standard's shape against an actual provider wire
  format rather than asserting it abstractly.
