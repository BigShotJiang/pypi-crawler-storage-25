"""Reference ``keel-llm-protocol`` adapter for OpenAI-compatible chat endpoints.

`OpenAIAdapter` targets the OpenAI ``POST /v1/chat/completions`` schema — the
de-facto wire standard that OpenAI, Groq, OpenRouter, Mistral, Together, Fireworks,
vLLM, and Ollama (OpenAI mode) all speak. Point ``base_url`` at any of them.

This package exists to **ground the protocol in a working implementation**: the
status-code → error-taxonomy mapping, response/usage/finish-reason parsing,
SSE streaming, and tool-call parsing here are real, so the protocol's shape is
proven against an actual provider API rather than asserted in the abstract.

It implements all three capability protocols: ``ModelAdapter``,
``StreamingModelAdapter``, ``ToolCallingModelAdapter``.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator, Sequence
from typing import Any

import httpx
from keel_llm_protocol import (
    AdapterResponse,
    AuthenticationError,
    BadRequestError,
    Capability,
    ContentFilterError,
    ContextLengthError,
    HealthStatus,
    Message,
    RateLimitError,
    ResponseFormat,
    StreamChunk,
    ToolCall,
    ToolSpec,
    TransientError,
)
from keel_llm_protocol.errors import AdapterTimeoutError, ProviderError
from keel_llm_protocol.responses import FinishReason, Usage

# OpenAI proper honors all of these; conservative default omits json_schema since
# support varies across OpenAI-compatible endpoints (Groq/OpenRouter/Mistral/local).
# Override via the `capabilities=` constructor arg for endpoints that honor more.
_DEFAULT_CAPABILITIES: frozenset[Capability] = frozenset(
    {"streaming", "tools", "json_object"}
)

__all__ = ["OpenAIAdapter"]

_DEFAULT_BASE_URL = "https://api.openai.com/v1"

# OpenAI finish_reason -> keel FinishReason
_FINISH: dict[str, FinishReason] = {
    "stop": "stop",
    "length": "length",
    "tool_calls": "tool_calls",
    "function_call": "tool_calls",  # legacy
    "content_filter": "content_filter",
}


class OpenAIAdapter:
    """Adapter for any OpenAI-compatible chat completions endpoint."""

    def __init__(
        self,
        *,
        model: str,
        api_key: str | None = None,
        base_url: str = _DEFAULT_BASE_URL,
        provider: str = "openai",
        timeout: float = 60.0,
        capabilities: frozenset[Capability] | None = None,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._model = model
        self._model_key = f"{provider}:{model}"
        self._capabilities = (
            capabilities if capabilities is not None else _DEFAULT_CAPABILITIES
        )
        if client is not None:
            self._client = client
        else:
            headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
            self._client = httpx.AsyncClient(
                base_url=base_url.rstrip("/"), timeout=timeout, headers=headers
            )

    @property
    def model_key(self) -> str:
        return self._model_key

    @property
    def capabilities(self) -> frozenset[Capability]:
        return self._capabilities

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()

    # -- ModelAdapter -------------------------------------------------------

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        body = self._body(messages, temperature, max_tokens, stop, response_format)
        resp = await self._complete(body)
        resp.structured_output_honored = self._honored(response_format)
        return resp

    def _honored(self, rf: ResponseFormat | None) -> bool | None:
        if rf is None or rf.type == "text":
            return None
        needed: Capability = "json_object" if rf.type == "json_object" else "json_schema"
        return needed in self._capabilities

    async def health_check(self) -> HealthStatus:
        t0 = time.monotonic()
        try:
            resp = await self._client.get("/models")
        except httpx.HTTPError as exc:
            return HealthStatus(self._model_key, healthy=False, error=str(exc))
        latency = int((time.monotonic() - t0) * 1000)
        ok = resp.status_code < 400
        return HealthStatus(
            self._model_key,
            healthy=ok,
            latency_ms=latency,
            error="" if ok else f"HTTP {resp.status_code}",
        )

    # -- ToolCallingModelAdapter -------------------------------------------

    async def generate_with_tools(
        self,
        messages: Sequence[Message],
        tools: Sequence[ToolSpec],
        *,
        tool_choice: str = "auto",
        temperature: float | None = None,
        max_tokens: int | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        body = self._body(messages, temperature, max_tokens, None, response_format)
        body["tools"] = [
            {
                "type": "function",
                "function": {
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.parameters,
                },
            }
            for t in tools
        ]
        if tool_choice in ("auto", "none", "required"):
            body["tool_choice"] = tool_choice
        else:
            body["tool_choice"] = {"type": "function", "function": {"name": tool_choice}}
        resp = await self._complete(body)
        resp.structured_output_honored = self._honored(response_format)
        return resp

    # -- StreamingModelAdapter ---------------------------------------------

    async def stream(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        body = self._body(messages, temperature, max_tokens, stop, None)
        body["stream"] = True
        body["stream_options"] = {"include_usage": True}
        async with self._client.stream("POST", "/chat/completions", json=body) as resp:
            if resp.status_code >= 400:
                await resp.aread()
                self._raise(resp)
            async for line in resp.aiter_lines():
                chunk = self._parse_stream_line(line)
                if chunk is not None:
                    yield chunk

    # -- internals ----------------------------------------------------------

    def _body(
        self,
        messages: Sequence[Message],
        temperature: float | None,
        max_tokens: int | None,
        stop: Sequence[str] | None,
        response_format: ResponseFormat | None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "model": self._model,
            "messages": [self._wire_message(m) for m in messages],
        }
        if temperature is not None:
            body["temperature"] = temperature
        if max_tokens is not None:
            body["max_tokens"] = max_tokens
        if stop:
            body["stop"] = list(stop)
        # Only send a structured-output request the adapter actually honors; an
        # unsupported one is reported via structured_output_honored=False, never
        # sent-and-silently-ignored.
        if response_format is not None and response_format.type != "text":
            needed: Capability = (
                "json_object" if response_format.type == "json_object" else "json_schema"
            )
            if needed in self._capabilities:
                if response_format.type == "json_object":
                    body["response_format"] = {"type": "json_object"}
                else:
                    body["response_format"] = {
                        "type": "json_schema",
                        "json_schema": response_format.json_schema or {},
                    }
        return body

    @staticmethod
    def _wire_message(m: Message) -> dict[str, Any]:
        d: dict[str, Any] = {"role": m.role, "content": m.content}
        if m.tool_calls:
            d["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {"name": tc.name, "arguments": tc.arguments},
                }
                for tc in m.tool_calls
            ]
        if m.tool_call_id is not None:
            d["tool_call_id"] = m.tool_call_id
        if m.name is not None:
            d["name"] = m.name
        return d

    async def _complete(self, body: dict[str, Any]) -> AdapterResponse:
        t0 = time.monotonic()
        try:
            resp = await self._client.post("/chat/completions", json=body)
        except httpx.TimeoutException as exc:
            raise AdapterTimeoutError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        except httpx.HTTPError as exc:
            raise TransientError(
                str(exc), model_key=self._model_key, provider_error=exc
            ) from exc
        if resp.status_code >= 400:
            self._raise(resp)
        data: dict[str, Any] = resp.json()
        return self._parse_response(data, int((time.monotonic() - t0) * 1000))

    def _parse_response(self, data: dict[str, Any], latency_ms: int) -> AdapterResponse:
        choice: dict[str, Any] = (data.get("choices") or [{}])[0]
        message: dict[str, Any] = choice.get("message") or {}
        usage_raw: dict[str, Any] = data.get("usage") or {}
        tool_calls = [
            ToolCall(
                id=tc.get("id", ""),
                name=tc.get("function", {}).get("name", ""),
                arguments=tc.get("function", {}).get("arguments", ""),
            )
            for tc in (message.get("tool_calls") or [])
        ]
        raw_finish = choice.get("finish_reason")
        # Present-but-unmapped reasons surface as "unknown", never laundered to "stop".
        finish: FinishReason = _FINISH.get(raw_finish, "unknown") if raw_finish else "stop"
        return AdapterResponse(
            text=message.get("content") or "",
            model_key=self._model_key,
            model_id=data.get("model", self._model),
            finish_reason=finish,
            usage=Usage(
                input_tokens=usage_raw.get("prompt_tokens", 0),
                output_tokens=usage_raw.get("completion_tokens", 0),
            ),
            tool_calls=tool_calls,
            latency_ms=latency_ms,
            raw_response=data,
        )

    def _parse_stream_line(self, line: str) -> StreamChunk | None:
        line = line.strip()
        if not line.startswith("data:"):
            return None
        payload = line[len("data:") :].strip()
        if payload == "[DONE]":
            return None
        data: dict[str, Any] = json.loads(payload)
        choices = data.get("choices") or []
        usage_raw = data.get("usage")
        usage = (
            Usage(
                input_tokens=usage_raw.get("prompt_tokens", 0),
                output_tokens=usage_raw.get("completion_tokens", 0),
            )
            if usage_raw
            else None
        )
        if not choices:
            # usage-only final frame (stream_options.include_usage)
            if usage is not None:
                return StreamChunk(usage=usage)
            return None
        choice: dict[str, Any] = choices[0]
        delta: dict[str, Any] = choice.get("delta") or {}
        finish_raw = choice.get("finish_reason")
        return StreamChunk(
            delta=delta.get("content") or "",
            finish_reason=_FINISH.get(finish_raw, "unknown") if finish_raw else None,
            usage=usage,
        )

    def _raise(self, resp: httpx.Response) -> None:
        status = resp.status_code
        message, code = self._error_detail(resp)
        kw: dict[str, Any] = {
            "model_key": self._model_key,
            "status_code": status,
            "provider_error": _safe_text(resp),
        }
        if status == 429:
            raise RateLimitError(message, retry_after=_retry_after(resp), **kw)
        if status in (401, 403):
            raise AuthenticationError(message, **kw)
        if status == 400:
            lowered = message.lower()
            if code in ("context_length_exceeded", "string_above_max_length") or (
                "context length" in lowered or "maximum context" in lowered
            ):
                raise ContextLengthError(message, **kw)
            if (code or "") == "content_filter" or "content_filter" in lowered:
                raise ContentFilterError(message, **kw)
            raise BadRequestError(message, **kw)
        if status >= 500:
            raise TransientError(message, **kw)
        raise ProviderError(message or f"HTTP {status}", **kw)

    @staticmethod
    def _error_detail(resp: httpx.Response) -> tuple[str, str | None]:
        try:
            body: dict[str, Any] = resp.json()
        except (ValueError, json.JSONDecodeError):
            return (_safe_text(resp), None)
        err = body.get("error")
        if isinstance(err, dict):
            msg = err.get("message") or ""
            code = err.get("code")
            return (str(msg), str(code) if code is not None else None)
        if isinstance(err, str):
            return (err, None)
        return (_safe_text(resp), None)


def _retry_after(resp: httpx.Response) -> float | None:
    raw = resp.headers.get("retry-after")
    if raw is None:
        return None
    try:
        return float(raw)
    except ValueError:
        return None


def _safe_text(resp: httpx.Response) -> str:
    try:
        return resp.text
    except Exception:  # pragma: no cover - defensive; .text on a streamed body
        return ""
