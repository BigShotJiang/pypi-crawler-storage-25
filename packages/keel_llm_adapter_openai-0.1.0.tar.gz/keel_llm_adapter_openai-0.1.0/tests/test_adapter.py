"""Tests for OpenAIAdapter — the grounding for keel-llm-protocol.

Uses httpx.MockTransport, so the real request-building, response-parsing, and
status-code -> error-taxonomy mapping logic runs against synthetic provider
responses (no live API keys). This is what proves the protocol's shape works
against an actual OpenAI-compatible wire format.
"""

from __future__ import annotations

import asyncio
import json
from collections.abc import Callable

import httpx
import pytest
from keel_llm_protocol import (
    AuthenticationError,
    BadRequestError,
    ContextLengthError,
    ModelAdapter,
    RateLimitError,
    StreamingModelAdapter,
    ToolCallingModelAdapter,
    ToolSpec,
    TransientError,
    user,
)
from keel_llm_protocol.errors import AdapterTimeoutError

from keel_llm_adapter_openai import OpenAIAdapter

Handler = Callable[[httpx.Request], httpx.Response]


def make_adapter(handler: Handler) -> OpenAIAdapter:
    transport = httpx.MockTransport(handler)
    client = httpx.AsyncClient(base_url="https://api.test/v1", transport=transport)
    return OpenAIAdapter(model="test-model", provider="testco", client=client)


def _completion(content: str = "hello", *, finish: str = "stop") -> dict[str, object]:
    return {
        "model": "test-model-0613",
        "choices": [{"message": {"role": "assistant", "content": content}, "finish_reason": finish}],
        "usage": {"prompt_tokens": 11, "completion_tokens": 4},
    }


# --------------------------------------------------------------------------- #
# Conformance — the adapter satisfies all three protocols
# --------------------------------------------------------------------------- #


def test_adapter_conforms_to_all_protocols() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion()))
    assert isinstance(a, ModelAdapter)
    assert isinstance(a, StreamingModelAdapter)
    assert isinstance(a, ToolCallingModelAdapter)


# --------------------------------------------------------------------------- #
# generate happy path + request shaping
# --------------------------------------------------------------------------- #


def test_generate_parses_response() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion("hi there")))
    resp = asyncio.run(a.generate([user("hello")], temperature=0.2, max_tokens=64))
    assert resp.text == "hi there"
    assert resp.model_key == "testco:test-model"
    assert resp.model_id == "test-model-0613"
    assert resp.finish_reason == "stop"
    assert resp.usage.input_tokens == 11
    assert resp.usage.output_tokens == 4
    assert resp.usage.total_tokens == 15


def test_generate_sends_expected_body() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_completion())

    a = make_adapter(handler)
    asyncio.run(a.generate([user("hello")], temperature=0.5, max_tokens=10, stop=["X"]))
    assert captured["model"] == "test-model"
    assert captured["temperature"] == 0.5
    assert captured["max_tokens"] == 10
    assert captured["stop"] == ["X"]
    assert captured["messages"] == [{"role": "user", "content": "hello"}]


def test_length_finish_reason_mapped() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion(finish="length")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "length"


def test_content_filter_on_200_returns_finish_reason() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion("", finish="content_filter")))
    resp = asyncio.run(a.generate([user("x")]))
    assert resp.finish_reason == "content_filter"


# --------------------------------------------------------------------------- #
# Error taxonomy mapping — the reliability core, proven against real status codes
# --------------------------------------------------------------------------- #


def _err_body(message: str, code: str | None = None) -> dict[str, object]:
    err: dict[str, object] = {"message": message, "type": "invalid_request_error"}
    if code is not None:
        err["code"] = code
    return {"error": err}


def test_429_maps_to_rate_limit_with_retry_after() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            429, headers={"retry-after": "3"}, json=_err_body("slow down")
        )
    )
    with pytest.raises(RateLimitError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is True
    assert exc.value.retry_after == 3.0
    assert exc.value.status_code == 429
    assert exc.value.model_key == "testco:test-model"


def test_401_maps_to_authentication() -> None:
    a = make_adapter(lambda req: httpx.Response(401, json=_err_body("bad key")))
    with pytest.raises(AuthenticationError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is False


def test_400_context_length_maps_to_context_length_error() -> None:
    a = make_adapter(
        lambda req: httpx.Response(
            400, json=_err_body("max context exceeded", code="context_length_exceeded")
        )
    )
    with pytest.raises(ContextLengthError):
        asyncio.run(a.generate([user("x")]))


def test_400_other_maps_to_bad_request() -> None:
    a = make_adapter(lambda req: httpx.Response(400, json=_err_body("bad param")))
    with pytest.raises(BadRequestError):
        asyncio.run(a.generate([user("x")]))


def test_500_maps_to_transient() -> None:
    a = make_adapter(lambda req: httpx.Response(503, json=_err_body("overloaded")))
    with pytest.raises(TransientError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is True


def test_timeout_maps_to_adapter_timeout() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ReadTimeout("timed out", request=req)

    a = make_adapter(handler)
    with pytest.raises(AdapterTimeoutError) as exc:
        asyncio.run(a.generate([user("x")]))
    assert exc.value.retryable is True


def test_connection_error_maps_to_transient() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused", request=req)

    a = make_adapter(handler)
    with pytest.raises(TransientError):
        asyncio.run(a.generate([user("x")]))


# --------------------------------------------------------------------------- #
# Tools
# --------------------------------------------------------------------------- #


def test_generate_with_tools_parses_tool_calls() -> None:
    tool_completion = {
        "model": "test-model",
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [
                        {
                            "id": "call_1",
                            "type": "function",
                            "function": {"name": "get_weather", "arguments": '{"city":"SF"}'},
                        }
                    ],
                },
                "finish_reason": "tool_calls",
            }
        ],
        "usage": {"prompt_tokens": 20, "completion_tokens": 9},
    }
    a = make_adapter(lambda req: httpx.Response(200, json=tool_completion))
    spec = ToolSpec(name="get_weather", description="weather", parameters={"type": "object"})
    resp = asyncio.run(a.generate_with_tools([user("weather in SF?")], [spec]))
    assert resp.finish_reason == "tool_calls"
    assert resp.text == ""
    assert resp.tool_calls[0].id == "call_1"
    assert resp.tool_calls[0].name == "get_weather"
    assert resp.tool_calls[0].arguments == '{"city":"SF"}'


def test_tools_serialized_into_request() -> None:
    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_completion("", finish="tool_calls"))

    a = make_adapter(handler)
    spec = ToolSpec(name="f", description="d", parameters={"type": "object"})
    asyncio.run(a.generate_with_tools([user("go")], [spec], tool_choice="required"))
    tools = captured["tools"]
    assert isinstance(tools, list)
    assert tools[0]["function"]["name"] == "f"
    assert captured["tool_choice"] == "required"


# --------------------------------------------------------------------------- #
# Streaming
# --------------------------------------------------------------------------- #


def _sse(*frames: dict[str, object]) -> bytes:
    lines = [f"data: {json.dumps(f)}\n\n" for f in frames]
    lines.append("data: [DONE]\n\n")
    return "".join(lines).encode()


def test_stream_assembles_deltas_and_final_usage() -> None:
    frames = [
        {"choices": [{"delta": {"content": "hel"}, "finish_reason": None}]},
        {"choices": [{"delta": {"content": "lo"}, "finish_reason": None}]},
        {"choices": [{"delta": {}, "finish_reason": "stop"}]},
        {"choices": [], "usage": {"prompt_tokens": 5, "completion_tokens": 2}},
    ]
    a = make_adapter(lambda req: httpx.Response(200, content=_sse(*frames)))

    async def collect() -> list[object]:
        return [c async for c in a.stream([user("hi")])]

    chunks = asyncio.run(collect())
    assert "".join(c.delta for c in chunks) == "hello"  # type: ignore[attr-defined]
    finishes = [c.finish_reason for c in chunks if c.finish_reason]  # type: ignore[attr-defined]
    assert finishes == ["stop"]
    usages = [c.usage for c in chunks if c.usage]  # type: ignore[attr-defined]
    assert usages[-1].total_tokens == 7


def test_stream_raises_taxonomy_on_error_status() -> None:
    a = make_adapter(lambda req: httpx.Response(429, json=_err_body("slow")))

    async def drain() -> None:
        async for _ in a.stream([user("hi")]):
            pass

    with pytest.raises(RateLimitError):
        asyncio.run(drain())


# --------------------------------------------------------------------------- #
# Health check
# --------------------------------------------------------------------------- #


def test_health_check_ok() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json={"data": []}))
    status = asyncio.run(a.health_check())
    assert status.healthy is True
    assert status.model_key == "testco:test-model"


def test_health_check_failure() -> None:
    a = make_adapter(lambda req: httpx.Response(500, json={}))
    status = asyncio.run(a.health_check())
    assert status.healthy is False
    assert "500" in status.error


# --------------------------------------------------------------------------- #
# No-silent-degradation: capabilities, structured_output_honored, unknown finish
# --------------------------------------------------------------------------- #


def test_capabilities_default() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion()))
    assert "json_object" in a.capabilities
    assert "json_schema" not in a.capabilities  # conservative default; override per endpoint


def test_structured_output_honored_when_capable() -> None:
    from keel_llm_protocol import ResponseFormat

    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_completion())

    a = make_adapter(handler)
    resp = asyncio.run(a.generate([user("x")], response_format=ResponseFormat(type="json_object")))
    assert resp.structured_output_honored is True
    assert captured["response_format"] == {"type": "json_object"}


def test_structured_output_degraded_when_not_capable() -> None:
    from keel_llm_protocol import ResponseFormat

    captured: dict[str, object] = {}

    def handler(req: httpx.Request) -> httpx.Response:
        captured.update(json.loads(req.content))
        return httpx.Response(200, json=_completion())

    a = make_adapter(handler)  # default caps lack json_schema
    resp = asyncio.run(
        a.generate(
            [user("x")],
            response_format=ResponseFormat(type="json_schema", json_schema={"type": "object"}),
        )
    )
    assert resp.structured_output_honored is False  # consumer SEES the degradation
    assert "response_format" not in captured  # and it was NOT silently sent


def test_unknown_finish_reason_surfaced_not_laundered() -> None:
    a = make_adapter(lambda req: httpx.Response(200, json=_completion(finish="some_new_reason")))
    assert asyncio.run(a.generate([user("x")])).finish_reason == "unknown"
