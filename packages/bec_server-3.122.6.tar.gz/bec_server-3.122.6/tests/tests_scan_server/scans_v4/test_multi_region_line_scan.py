import numpy as np
import pytest

from bec_server.scan_server.tests.scan_hook_tests import (
    DEFAULT_HOOK_TESTS,
    PREMOVE_HOOK_TESTS,
    STANDARD_STEP_SCAN_TESTS,
    run_scan_tests,
)


@pytest.mark.parametrize(
    ("hook_name", "hook_tests"),
    [*DEFAULT_HOOK_TESTS, *PREMOVE_HOOK_TESTS, *STANDARD_STEP_SCAN_TESTS],
)
def test_multi_region_line_scan_default_hooks(
    v4_scan_assembler, nth_done_status_mock, hook_name, hook_tests
):
    scan = v4_scan_assembler(
        "_v4_multi_region_line_scan",
        "samx",
        regions=[(-5.0, -2.0, 4), (-1.0, 6.0, 4)],
        relative=False,
    )

    run_scan_tests(scan, [(hook_name, hook_tests)], nth_done_status_mock=nth_done_status_mock)


def test_multi_region_line_scan_prepare_scan_updates_scan_info_and_queue(v4_scan_assembler):
    scan = v4_scan_assembler(
        "_v4_multi_region_line_scan",
        "samx",
        regions=[(-5.0, -2.0, 4), (-1.0, 6.0, 4)],
        relative=False,
    )

    scan.prepare_scan()

    expected_positions = np.array(
        [[-5.0], [-4.0], [-3.0], [-2.0], [-1.0], [1.33333333], [3.66666667], [6.0]]
    )
    assert np.allclose(scan.positions, expected_positions)
    assert scan.scan_info.num_points == len(expected_positions)
    assert np.allclose(scan.scan_info.positions, expected_positions)
    assert scan.scan_info.scan_report_instructions == [
        {"scan_progress": {"points": len(expected_positions), "show_table": False}}
    ]


def test_multi_region_line_scan_prepare_scan_offsets_positions_when_relative(v4_scan_assembler):
    scan = v4_scan_assembler(
        "_v4_multi_region_line_scan",
        "samx",
        regions=[(-5.0, -2.0, 4), (-1.0, 6.0, 4)],
        relative=True,
    )
    scan.components.get_start_positions = lambda motors: [2.0]

    scan.prepare_scan()

    expected_positions = np.array(
        [[-3.0], [-2.0], [-1.0], [0.0], [1.0], [3.33333333], [5.66666667], [8.0]]
    )
    assert scan.start_positions == [2.0]
    assert np.allclose(scan.positions, expected_positions)
