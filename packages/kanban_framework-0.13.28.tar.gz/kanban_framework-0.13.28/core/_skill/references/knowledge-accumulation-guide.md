# 知识积累指南

> 知识是项目最宝贵的资产。但盲目积累比不积累更糟。

## 动机

纯对话式 AI 编码的重复踩坑率很高——同一个陷阱，换个任务照样掉进去。原因是没有**跨任务的记忆**。

Kanban 知识库解决的就是这个：让每次任务的踩坑、决策、最佳实践**跨任务复用**。

## 技术方案

### 存储模型

```
.kanban/knowledge/
├── entries/KNNN.json     # 每条知识独立 JSON
├── index.json            # domain → entry_ids 索引
├── domains.json          # 领域定义（7 个预置）
└── usage-log.json        # 引用追踪
```

每条知识条目包含：domain（领域）、category（架构/流程/工具/踩坑/优化）、tags、severity、code_example（可选）、stats（引用计数）。

### 积累渠道

| 渠道 | 触发时机 | 说明 |
|------|---------|------|
| Archive 提取 | 任务归档 | Knowledge Manager Agent 从 pitfalls/decisions 自动提取 |
| Execute 新增 | 执行中遇到新坑 | Executor Agent 写入 execution_pitfalls.md → 归档时提取 |
| 主动学习 | 用户提供代码案例 | `knowledge learn --path <dir> --domain <domain>` 分析入库 |
| 手动录入 | 任意时刻 | `knowledge add` 手动写入 |

### 消费方式

| 场景 | 机制 |
|------|------|
| Plan 阶段 | 知识注入：按 domain 检索相关历史经验 → 写入 plan.md |
| Plan Review | 交叉验证：对照知识库检查 TDD 步骤是否与已知陷阱冲突 |
| Execute 阶段 | 踩坑预警：新 pitfall 与历史条目 tag 交集 >=2 时提示 |
| Execute 开始 | 硬约束注入：plan_choices.json 中已选方案强制遵守 |
| 随时查询 | `knowledge search <keyword>` / `knowledge search --domain <d>` |

## 哪些需要积累

遵循「可操作 + 有来源 + 防踩坑」三原则：

### 单一决策记录

**技术选型及理由：**
```
"选用 argparse 而非 click，因为项目已有 argparse 基础设施，
且性能要求 click 的额外开销不可接受"
→ domain: cli, category: 架构, severity: high
```

**为什么不是另一个选项：** 说清「为什么选 A 而不是 B」，比「我们用了 A」有价值 10 倍。

### 踩坑记录

**具体错误 + 根因 + 解决方案：**
```
"truncate_text 测试预期 'hello world' truncate(8) 以为结果是 'hello...'，
但 len('hello world')=11，取前 8 字符应为 'hello wo...'。
根因: 混淆了字符截取和单词截取。测试时需确认函数语义。"
→ category: 踩坑, severity: medium
```

**可复现的错误模式：** "在 Next.js 中使用 Antd Modal 组件，忘记 'use client' 指令导致 hydration mismatch"——这条知识未来所有 React 任务都能受益。

### 架构模式

**可复用的代码组织方式：**
```
"shadcn/ui 项目统一采用 components/ui/{component}.tsx 的单文件结构，
每个组件导出类型 Props interface。变体使用 cva() 而非条件 className 拼接。"
→ domain: ui, category: 架构, code_example: 包含示例代码
```

**不是「我们做了什么」，而是「为什么这样做 + 什么时候适用 + 什么时候不适用」。**

### 工具使用规范

**框架/库的正确用法：**
```
"react-hook-form 表单验证模式: 用 zod schema 定义验证规则，
在 useForm({ resolver: zodResolver(schema) }) 中集成。
不要在 JSX 中手写 validate 回调。"
→ domain: ui, category: 工具
```

### 流程经验

**开发流程中习得的效率改进：**
```
"先写 integration test 确立模块边界，再写单元测试覆盖细节。
反过来的话，单元测试容易耦合到未稳定的内部实现。"
→ domain: testing, category: 流程
```

### code_example 粒度控制

存**接口和模式**，不存实现细节。原则：code_example 是「下一次用这个模块时，我需要知道的接口签名」，不是「这个函数的所有内部逻辑」。

| 知识类型 | code_example 行数 | 示例 |
|---------|-----------------|------|
| 函数接口 | 3-8 行 | 函数签名 + docstring + 1-2 行关键逻辑 |
| 类定义 | 10-25 行 | 类声明 + 关键方法签名 + 核心属性 |
| 配置/模式 | 3-5 行 | import + 核心调用 |
| 架构模式 | 5-15 行 | 模块入口 + 依赖注入结构 |
| **用法示例** | **5-10 行** | **展示如何正确调用接口的完整代码片段** |

**上限：50 行。** 超过 50 行说明在存实现细节。

**用法示例优先于裸接口。** 接口签名告诉「有哪些方法」，用法示例告诉「怎么正确组合使用」——后者才是知识积累的核心价值。

**code_example 应包含四个维度：**

```
1. ❌ 错误签名/API   — 常见的错误写法，标注为什么错
2. ✅ 正确签名/API   — 标准的接口声明
3. ✅ 正确使用方式   — 展示如何调用和组合
4. ❌ 错误使用方式   — 常见的误用陷阱
```

示例：

```
# ❌ 错误签名: validate 接受 list，但内部逻辑用 dict 方法会崩溃
def validate(self, rules: list) -> dict:
    return rules.get("email")  # AttributeError!

# ✅ 正确签名: rules 是 dict[str, dict]
def validate(self, data: dict[str, Any]) -> dict[str, list[str]]:
    ...

# ✅ 正确使用
v = FormValidator()
v.add_rule("email", {"required": True})
errors = v.validate({"email": "test@x.com"})

# ❌ 错误使用: add_rule 第二参数必须是 dict
v.add_rule("email", ["required"])  # TypeError
```

**不需要四维度全写的场景：** 踩坑类知识只需 1-2 行修复代码；纯接口参考只需签名 + 用法。根据知识类型灵活增减。

---

## 哪些**不需要**积累 — 边界原则

### 拒绝过时信息

- 代码已被重构、替代方案已废弃——标记为 `deprecated`
- 超过 30 天未被引用的条目自动标记为 `stale`
- 依赖特定框架版本的信息——一旦升版就过时

### 拒绝通用常识

以下类型的「知识」不应该入库：

- "Python 使用缩进定义代码块" — 这是语言基础，不是项目经验
- "使用 pytest 写测试" — 这是测试框架文档内容，不是项目资产
- "函数名应该清晰描述功能" — 通用编码规范

**判断标准：** 如果一条知识在任何项目中都能用，那它不该进**项目知识库**。项目知识库的价值在**领域特异性**。

### 拒绝无操作性的抽象

- "架构设计很重要" — 没有具体指导
- "要注意性能" — 没说注意什么、怎么注意、怎么度量
- "测试要覆盖边界情况" — 没说具体哪些边界

**判断标准：** 读完一条知识后，能立刻用来做一个具体的编码决策。不能，就不合格。

### 拒绝无法验证的断言

- "这个方案性能更好" — 没有数据支撑
- "click 比 argparse 快" — 没有 benchmark
- "用户更喜欢这种 UI" — 没有用户调研

**判断标准：** 如果有异议，能通过实验/数据/代码证明这条知识是对的。

### 拒绝单一任务特化细节

- "TASK-001 的 snake.py 第 42 行用了 int 计数器" — 只对 TASK-001 有效
- "贪食蛇游戏的 food.py 随机生成范围是 0-19" — 只对那个游戏有效

**应该改为抽象后的经验：**
- "当测试 spec 期望累积行为时，使用 int 计数器而非 bool 标志"
- "随机位置生成需注意边界：坐标范围 = 地图尺寸 - 1（0-based）"

### 拒绝重复

入库前搜索「有没有说同一件事的条目」：
- 完全重复 → 不写
- 主题相同但视角/深度不同 → 合并为一条，补充新视角
- 旧条目的结论被新条目推翻 → 旧条目标记为 `deprecated`

### 周期性清理

| 条件 | 操作 |
|------|------|
| `status=stale` 超过 60 天 | 删除 |
| `referenced_count=0` 超过 12 个月 | 建议降级为 `deprecated` |
| 知识库条目数 > 200 | 强制 review，按 severity 和引用数排序，保留 top 200 |

---

## 何时创建新领域

`domains.json` 预置 7 个领域：cli / agent / testing / infra / workflow / dashboard / git。

创建新领域的条件：
- 该领域已积累 >= 5 条知识，且现有领域都无法合理归类
- 该领域有独立的代码目录或技术栈（如 `ui` 有自己的组件库或框架约定）

领域过多（>10）反而降低搜索效率。优先用 `tags` 而非建新领域。

## 标签前缀约定（基于 DDD Bounded Context）

用标签前缀表达**业务维度**，与已有的技术域名（cli/agent/testing...）互补：

| 前缀 | 含义 | 示例 |
|------|------|------|
| `biz:` | 业务领域 | `biz:game`, `biz:ecommerce`, `biz:saas` |
| `pattern:` | 模式类型 | `pattern:architecture`, `pattern:testing`, `pattern:error-handling` |
| `stack:` | 技术栈 | `stack:react`, `stack:fastapi`, `stack:tailwind` |

**设计原理（DDD 概念映射）：**
- **Bounded Context** → `biz:` 前缀划定业务上下文边界。"render"在 biz:game ↔ biz:web 语境下含义不同
- **Ubiquitous Language** → 业务标签随项目自然积累，形成该领域的通用词汇表
- **Shared Kernel** → 无 `biz:` 标签的知识跨所有业务共享（如 SOLID 原则）
- **Context Mapping** → 一条知识可带多个 `biz:` 标签，表达跨上下文关系

**查询示例：**
```bash
kanban knowledge search --tag biz:game render    # 游戏领域的渲染知识
kanban knowledge search --tag pattern:testing    # 测试模式
kanban knowledge search --tag stack:fastapi      # FastAPI 相关
```

**不要为每个业务域创建技术域。** `cli`/`agent`/`testing` 这 7 个技术域保持不变。业务维度完全由标签承载。

---

## 应用场景

### 场景 1: UI 代码库学习

```
用户: 分析下 src/components/，把 UI 最佳实践存到知识库
Agent: 
  1. knowledge learn --path src/components --domain ui
  2. 读取 23 个 .tsx 文件
  3. 识别: shadcn/ui + Tailwind + react-hook-form + zustand
  4. 提取 5 条架构模式 + 3 条工具规范 + 2 条踩坑记录
  5. 写入 entries/K042 ~ K051

后续 UI 任务:
  Plan 阶段自动注入 "UI 组件结构: components/ui/ 单文件模式"
  Execute 时若忘记 "use client" → 踩坑预警提示 K045
```

### 场景 2: 多项目间知识迁移

```
项目 A 积累了 30 条 CLI 开发知识
→ 开项目 B 时，将 .kanban/knowledge/ 复制到项目 B
→ 项目 B 第一次 init 自动执行 migrate
→ Plan 阶段立即注入项目 A 的 CLI 经验
```

### 场景 3: 定期审计

```bash
kanban knowledge health    # 查看 active/stale/gaps
kanban knowledge gapps     # 找出 pitfalls 多但知识少的领域
kanban knowledge stale     # 标记过期条目
```
