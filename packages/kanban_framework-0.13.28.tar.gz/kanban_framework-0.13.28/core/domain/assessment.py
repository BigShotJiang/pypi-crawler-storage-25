"""Auto-detect task complexity and recommend mode — lighter by default."""

from __future__ import annotations

# Keywords that signal "this needs full FSM with multi-role review"
_HEAVY_SIGNALS = [
    "游戏", "game", "重构", "refactor", "系统", "system", "引擎", "engine",
    "数据库", "database", "迁移", "migration", "微服务", "microservice",
    "分布式", "distributed", "机器学习", "machine learning",
    "多模块", "multi-module", "完整项目", "full project", "框架", "framework",
    "编译器", "compiler", "解析器", "parser", "编译器", "compiler",
    "前端", "frontend", "后端", "backend", "认证", "auth system",
    "实时", "realtime", "websocket", "dashboard", "web",
]

# Keywords that signal "this is a simple fix, lightweight is enough"
_LIGHT_SIGNALS = [
    "脚本", "script", "工具函数", "utility", "单文件", "single file",
    "修复", "fix", "补丁", "patch", "文档", "doc", "配置", "config",
    "拼写", "typo", "格式化", "format", "注释", "comment",
    "小改", "调整", "tweak", "换", "改一下",
]


def assess_task(title: str, description: str) -> dict:
    """Return {recommended_mode, reason, risk_factors}.

    Defaults to lightweight — only switches to full for heavy signals.
    """
    text = f"{title} {description}".lower()

    heavy = [kw for kw in _HEAVY_SIGNALS if kw in text]
    light = [kw for kw in _LIGHT_SIGNALS if kw in text]

    if heavy:
        mode = "full"
        reason = f"检测到重度信号: {', '.join(heavy[:3])} → 建议 full 模式，完整评审"
    elif light:
        mode = "lightweight"
        reason = f"检测到轻量信号: {', '.join(light[:3])} → 建议 lightweight 模式，快速迭代"
    else:
        mode = "lightweight"
        reason = "无明显重度信号 → 默认 lightweight 模式（如需要可手动指定 --mode full）"

    risk_factors = []
    if any(kw in text for kw in ["数据库", "database", "data migration"]):
        risk_factors.append("数据完整性")
    if any(kw in text for kw in ["认证", "auth", "权限", "permission", "安全", "security"]):
        risk_factors.append("安全风险")
    if any(kw in text for kw in ["性能", "performance", "优化", "optimize"]):
        risk_factors.append("性能要求")

    return {
        "recommended_mode": mode,
        "reason": reason,
        "heavy_signals": heavy,
        "risk_factors": risk_factors,
    }
