from __future__ import annotations
from datetime import datetime, timezone
from core.infra.filesystem import Filesystem

DOMAIN_KEYWORDS = {
    "testing": ["测试", "test", "pytest", "coverage", "覆盖率", "assert"],
    "cli": ["命令", "command", "CLI", "参数", "argparse", "dispatch"],
    "infra": ["性能", "数据库", "缓存", "配置", "config", "文件系统", "git"],
    "workflow": ["流程", "FSM", "阶段", "phase", "iteration", "迭代"],
    "agent": ["agent", "prompt", "模型", "role"],
}

PRIORITY_KEYWORDS = {
    "high": ["紧急", "bug", "修复", "崩溃", "失败", "报错", "错误", "严重"],
    "medium": ["补充", "优化", "改进", "增加", "新增"],
    "low": ["建议", "考虑", "美化", "文档"],
}


class InboxAnalyzer:
    def __init__(self, fs: Filesystem):
        self._fs = fs

    def read_pending_items(self, task_id: str) -> list[str]:
        task_dir = self._fs.task_dir(task_id)
        inbox_path = task_dir / "inbox.md"
        if not self._fs.file_exists(inbox_path):
            return []
        content = inbox_path.read_text(encoding="utf-8")
        items = []
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("- [ ]"):
                items.append(stripped[5:].strip())
            elif stripped and not stripped.startswith("#") and not stripped.startswith("- [x]") and not stripped.startswith("- [X]"):
                if not stripped.startswith("**") and "kanban inbox" not in stripped:
                    if len(stripped) > 5 and not stripped.startswith("---") and not stripped.startswith("可以") and not stripped.startswith("在此"):
                        items.append(stripped)
        return items

    def analyze_requirements(self, items: list[str]) -> list[dict]:
        results = []
        for item in items:
            domain = self._match_domain(item)
            priority = self._match_priority(item)
            results.append({
                "requirement": item,
                "domain": domain,
                "priority": priority,
            })
        return results

    def suggest_phase(self, task_id: str, requirements: list[dict]) -> str:
        task_dir = self._fs.task_dir(task_id)
        has_spec = self._fs.file_exists(task_dir / "spec.md")
        has_plan = self._fs.file_exists(task_dir / "plan.md")
        has_code = bool(list(task_dir.glob("**/*.py")))

        if not has_spec and not has_plan:
            return "plan"
        if has_spec and has_plan and not has_code:
            return "plan"
        if has_code and requirements:
            return "plan"
        if has_code and not requirements:
            return "execute"
        return "plan"

    def identify_affected_files(self, requirements: list[dict]) -> list[dict]:
        domain_file_map = {
            "testing": ["test/"],
            "cli": ["core/cli/"],
            "infra": ["core/infra/", "core/domain/"],
            "workflow": ["core/domain/workflow.py", "workflow.json"],
            "agent": ["agents/"],
        }
        files = []
        seen = set()
        for req in requirements:
            domain = req.get("domain", "")
            paths = domain_file_map.get(domain, ["core/"])
            for p in paths:
                if p not in seen:
                    seen.add(p)
                    files.append({
                        "path": p,
                        "action": "modify",
                        "reason": f"需求涉及 {domain} 领域",
                    })
        return files

    def detect_conflicts(self, task_id: str, requirements: list[dict]) -> list[dict]:
        conflicts = []
        task_dir = self._fs.task_dir(task_id)
        spec_path = task_dir / "spec.md"
        if not self._fs.file_exists(spec_path):
            return conflicts
        spec_content = spec_path.read_text(encoding="utf-8").lower()
        for req in requirements:
            req_text = req["requirement"].lower()
            words = [w for w in req_text.split() if len(w) > 2]
            if words:
                found = any(w.lower() in spec_content for w in words)
                if not found:
                    conflicts.append({
                        "type": "spec_deviation",
                        "inbox_item": req["requirement"],
                        "conflicts_with": "spec.md 中未找到相关关键词",
                        "resolution": "需评估是否在 scope 内，或更新 spec.md",
                    })
        return conflicts

    def generate_analysis(self, task_id: str) -> dict:
        task_dir = self._fs.task_dir(task_id)
        pending = self.read_pending_items(task_id)
        if not pending:
            return {
                "task_id": task_id,
                "archived_count": 0,
                "pending_after_analyze": 0,
                "extracted_requirements": [],
                "suggested_phase": None,
            }
        requirements = self.analyze_requirements(pending)
        suggested_phase = self.suggest_phase(task_id, requirements)
        affected_files = self.identify_affected_files(requirements)
        conflicts = self.detect_conflicts(task_id, requirements)
        now = datetime.now(timezone.utc).isoformat()
        self._archive_analyzed(task_dir, pending, requirements)
        analysis_path = task_dir / "inbox_analysis.json"
        analysis = {
            "task_id": task_id,
            "analyzed_at": now,
            "source_inbox_items": pending,
            "extracted_requirements": requirements,
            "suggested_phase": suggested_phase,
            "phase_reason": self._phase_reason(suggested_phase),
            "affected_files": affected_files,
            "conflicts": conflicts,
            "pending_after_analyze": 0,
            "archived_count": len(pending),
        }
        self._fs.write_json(analysis_path, analysis)
        self._append_to_spec(task_dir, requirements, conflicts, now)
        return analysis

    def _archive_analyzed(self, task_dir, items, requirements):
        inbox_path = task_dir / "inbox.md"
        if not self._fs.file_exists(inbox_path):
            return
        content = inbox_path.read_text(encoding="utf-8")
        lines = content.splitlines()
        new_lines = []
        archive_lines = []
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        archive_lines.append(f"\n## Analysis — {now}\n")
        for i, item in enumerate(items):
            req = requirements[i] if i < len(requirements) else {}
            archive_lines.append(f"- [x] {item}")
            archive_lines.append(f"  - **分析**: 涉及 {req.get('domain', 'N/A')} 领域, 优先级 {req.get('priority', 'medium')}")
        for line in lines:
            stripped = line.strip()
            matched = False
            for item in items:
                if stripped.endswith(item):
                    new_lines.append(stripped.replace("- [ ]", "- [x]", 1))
                    matched = True
                    break
            if not matched:
                new_lines.append(line)
        inbox_path.write_text("\n".join(new_lines), encoding="utf-8")
        archive_path = task_dir / "inbox-archive.md"
        existing = archive_path.read_text(encoding="utf-8") if self._fs.file_exists(archive_path) else ""
        archive_path.write_text(existing + "\n".join(archive_lines) + "\n", encoding="utf-8")

    def _append_to_spec(self, task_dir, requirements, conflicts, timestamp):
        spec_path = task_dir / "spec.md"
        header = "\n## 来自 Inbox 的需求分析\n"
        if self._fs.file_exists(spec_path):
            existing = spec_path.read_text(encoding="utf-8")
            if header in existing:
                parts = existing.split(header, 1)
                existing = parts[0]
        else:
            existing = "# Spec (Draft)\n\n需求待补充。\n"
        lines = [header, f"> 分析时间: {timestamp}\n"]
        for req in requirements:
            lines.append(f"- [{req['domain']}] [{req['priority']}] {req['requirement']}")
        if conflicts:
            lines.append(f"\n### 冲突与风险评估\n")
            for c in conflicts:
                lines.append(f"- **{c['type']}**: {c['inbox_item']} — {c['resolution']}")
        spec_path.write_text(existing + "\n".join(lines), encoding="utf-8")

    def _match_domain(self, text: str) -> str:
        text_lower = text.lower()
        scores = {}
        for domain, keywords in DOMAIN_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw.lower() in text_lower)
            if score > 0:
                scores[domain] = score
        return max(scores, key=scores.get) if scores else "infra"

    def _match_priority(self, text: str) -> str:
        text_lower = text.lower()
        for priority in ("high", "medium", "low"):
            for kw in PRIORITY_KEYWORDS[priority]:
                if kw in text_lower:
                    return priority
        return "medium"

    def _phase_reason(self, phase: str) -> str:
        reasons = {
            "plan": "存在新需求或 spec.md 未完整，建议从 Plan 阶段开始",
            "execute": "spec.md 和 plan.md 已就绪，可直接进入执行",
            "evaluate": "代码已完成，进入评估阶段",
        }
        return reasons.get(phase, "建议从 Plan 阶段开始")
