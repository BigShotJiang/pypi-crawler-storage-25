"""Audience Analysis — workflow from audience-analysis.md

Audience efficiency scoring:
  Profitability (50-60%): ROAS/target or target/CPA
  Quality (20-25%): CVR + CTR vs benchmark
  Scale (20-25%): spend share * conversion share

Classification:
  90%+ & 10%+ conversions → "Scale & efficient" → split + raise budget
  90%+ & <10% conversions → "Efficient but small" → loosen constraints
  60-89% & <10% spend → "Scale but inefficient" → cut spend
  <60% → "Inefficient" → pause/exclude

Reads: all via GAQL ✅
Writes:
  - ad_group_criterion_remove_ad_group_criterion ✅ FIXED (exclude audiences)
  - ad_group_criterion_add_audience_criteria ✅ FIXED (add audiences)
  - ad_group_create_ad_group ✅ FIXED (split to dedicated ad group)
  - ad_group_bid_modifier ❌ NOT FIXED (bid adjustments per audience)
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.services.workflows.campaign_filter import resolve_campaign_filter
from src.utils import (
    format_customer_id,
    get_logger,
    run_with_timeout,
    safe_num,
    serialize_proto_message,
)


def _date_range_clause(days: int) -> str:
    """Convert days to GAQL date filter. Uses DURING for 7/14/30, explicit range otherwise."""
    if days in (7, 14, 30):
        return f"segments.date DURING LAST_{days}_DAYS"
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    return f"segments.date BETWEEN '{start}' AND '{end}'"


logger = get_logger(__name__)


class AudienceAnalysisService:
    """Audience performance analysis with efficiency scoring and recommendations."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    async def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        def _execute() -> List[Dict[str, Any]]:
            response = self.service.search(customer_id=customer_id, query=query)
            return [serialize_proto_message(row) for row in response]

        return await run_with_timeout(_execute)

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    async def _get_audience_performance(
        self,
        customer_id: str,
        days: int = 30,
        filter_clause: str = "",
    ) -> List[Dict[str, Any]]:
        """Audience-level metrics with observation/targeting distinction."""
        return await self._query(
            customer_id,
            f"""
            SELECT
                ad_group.id,
                ad_group.name,
                ad_group_criterion.criterion_id,
                ad_group_criterion.type,
                ad_group_criterion.status,
                ad_group_criterion.bid_modifier,
                ad_group_criterion.user_list.user_list,
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.advertising_channel_sub_type,
                campaign.bidding_strategy_type,
                campaign.target_cpa.target_cpa_micros,
                campaign.maximize_conversions.target_cpa_micros,
                campaign.maximize_conversion_value.target_roas,
                campaign.target_roas.target_roas,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.conversions,
                metrics.conversions_value
            FROM ad_group_audience_view
            WHERE campaign.status != 'REMOVED'
                AND {_date_range_clause(days)}
                {filter_clause}
            """,
        )

    async def _get_campaign_baselines(
        self,
        customer_id: str,
        days: int = 30,
        filter_clause: str = "",
    ) -> List[Dict[str, Any]]:
        """Campaign-level metrics for baseline comparison."""
        return await self._query(
            customer_id,
            f"""
            SELECT
                campaign.id,
                campaign.status,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.conversions,
                metrics.conversions_value
            FROM campaign
            WHERE campaign.status != 'REMOVED'
                AND {_date_range_clause(days)}
                {filter_clause}
            """,
        )

    async def _get_ad_group_baselines(
        self,
        customer_id: str,
        days: int = 30,
        filter_clause: str = "",
    ) -> List[Dict[str, Any]]:
        """Ad group-level metrics for baseline comparison."""
        return await self._query(
            customer_id,
            f"""
            SELECT
                ad_group.id,
                ad_group.status,
                campaign.id,
                campaign.status,
                metrics.impressions,
                metrics.clicks,
                metrics.cost_micros,
                metrics.conversions,
                metrics.conversions_value
            FROM ad_group
            WHERE campaign.status != 'REMOVED'
                AND ad_group.status != 'REMOVED'
                AND {_date_range_clause(days)}
                {filter_clause}
            """,
        )

    # ------------------------------------------------------------------
    # Scoring logic
    # ------------------------------------------------------------------

    def _compute_efficiency_score(
        self,
        audience: Dict[str, float],
        target_cpa: float,
        target_roas: float,
        uses_roas: bool,
        campaign_baseline: Dict[str, float],
        ad_group_baseline: Dict[str, float],
        total_spend: float,
        total_conversions: float,
    ) -> Dict[str, Any]:
        """Compute audience efficiency score = profitability + quality + scale."""
        # Profitability (55%)
        if uses_roas and target_roas > 0:
            actual_roas = (
                audience["conv_value"] / audience["spend"]
                if audience["spend"] > 0
                else 0
            )
            profitability = actual_roas / target_roas
        elif target_cpa > 0 and audience["conversions"] > 0:
            actual_cpa = audience["spend"] / audience["conversions"]
            profitability = target_cpa / actual_cpa
        else:
            profitability = 0.5

        # Quality (22.5%): CVR + CTR indexed to ad group
        aud_cvr = (
            audience["conversions"] / audience["clicks"]
            if audience["clicks"] > 0
            else 0
        )
        aud_ctr = (
            audience["clicks"] / audience["impressions"]
            if audience["impressions"] > 0
            else 0
        )
        ag_cvr = ad_group_baseline.get("cvr", 0)
        ag_ctr = ad_group_baseline.get("ctr", 0)

        cvr_index = aud_cvr / ag_cvr if ag_cvr > 0 else 1.0
        ctr_index = aud_ctr / ag_ctr if ag_ctr > 0 else 1.0
        quality = (cvr_index + ctr_index) / 2

        # Scale (22.5%): spend share * conversion share
        spend_share = audience["spend"] / total_spend if total_spend > 0 else 0
        conv_share = (
            audience["conversions"] / total_conversions if total_conversions > 0 else 0
        )
        scale = (spend_share + conv_share) / 2 * 10  # Normalize to ~0-1 range

        # Weighted score
        raw_score = profitability * 0.55 + quality * 0.225 + scale * 0.225
        score_pct = min(round(raw_score * 100, 1), 200)  # Cap at 200%

        return {
            "score_pct": score_pct,
            "profitability": round(profitability, 3),
            "quality": round(quality, 3),
            "scale": round(scale, 3),
            "spend_share_pct": round(spend_share * 100, 1),
            "conv_share_pct": round(conv_share * 100, 1),
            "cvr_index": round(cvr_index, 2),
            "ctr_index": round(ctr_index, 2),
        }

    def _classify_audience(
        self, score_pct: float, conv_share: float, spend_share: float
    ) -> Dict[str, str]:
        """Apply Matthias's 4-label classification."""
        if score_pct >= 90 and conv_share >= 10:
            return {
                "label": "SCALE_EFFICIENT",
                "action": "Split to dedicated ad group(s) and raise budget. Test similar signals.",
            }
        if score_pct >= 90 and conv_share < 10:
            return {
                "label": "EFFICIENT_SMALL",
                "action": "Loosen constraints (geo, time window, channels, placements).",
            }
        if 60 <= score_pct < 90 and spend_share < 10:
            return {
                "label": "SCALE_INEFFICIENT",
                "action": "Cut spend. If strategic, tighten placements/definitions or move to Observation.",
            }
        if score_pct < 60:
            # Harder threshold: >20% spend share with <10% conv share
            if spend_share > 20 and conv_share < 10:
                return {
                    "label": "INEFFICIENT_HIGH_SPEND",
                    "action": "URGENT — Pause/exclude. Over 20% spend, under 10% conversions.",
                }
            return {
                "label": "INEFFICIENT",
                "action": "Pause/exclude. If strategic, run 2-week low-budget holdout as Targeting first.",
            }
        return {
            "label": "MODERATE",
            "action": "Monitor. Consider testing as dedicated Targeting.",
        }

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def analyze_audiences(
        self,
        ctx: Context,
        customer_id: str,
        days: int = 30,
        campaign_type: Optional[str] = None,
        campaign_id: Optional[str] = None,
        campaign_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run full audience analysis with efficiency scoring and classification.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID
            days: Lookback window (default 30, also pulls 90d for benchmarks)
            campaign_type: Optional campaign type filter (SEARCH, DISPLAY, VIDEO, SHOPPING, PERFORMANCE_MAX, DEMAND_GEN)
            campaign_id: Optional campaign ID filter to analyze a single campaign
            campaign_name: Optional partial campaign name filter (uses LIKE '%name%' matching)

        Returns:
            Audience analysis with scores, indexes, classifications, and additional checks.
        """
        customer_id = format_customer_id(customer_id)

        try:
            filter_clause = await resolve_campaign_filter(
                customer_id, campaign_type, campaign_id, campaign_name
            )
            audiences_30d = await self._get_audience_performance(
                customer_id, 30, filter_clause
            )
            audiences_90d = await self._get_audience_performance(
                customer_id, 90, filter_clause
            )
            campaign_baselines = await self._get_campaign_baselines(
                customer_id, 30, filter_clause
            )
            ad_group_baselines = await self._get_ad_group_baselines(
                customer_id, 30, filter_clause
            )

            # Build baseline lookups
            camp_bl: Dict[str, Dict[str, float]] = {}
            for row in campaign_baselines:
                cid = str(row.get("campaign", {}).get("id", ""))
                m = row.get("metrics", {})
                impr = safe_num(m.get("impressions", 0))
                clicks = safe_num(m.get("clicks", 0))
                camp_bl[cid] = {
                    "spend": safe_num(m.get("cost_micros", 0)) / 1_000_000,
                    "conversions": safe_num(m.get("conversions", 0)),
                    "ctr": clicks / impr if impr > 0 else 0,
                    "cvr": safe_num(m.get("conversions", 0)) / clicks
                    if clicks > 0
                    else 0,
                }

            ag_bl: Dict[str, Dict[str, float]] = {}
            for row in ad_group_baselines:
                agid = str(row.get("ad_group", {}).get("id", ""))
                m = row.get("metrics", {})
                impr = safe_num(m.get("impressions", 0))
                clicks = safe_num(m.get("clicks", 0))
                ag_bl[agid] = {
                    "spend": safe_num(m.get("cost_micros", 0)) / 1_000_000,
                    "conversions": safe_num(m.get("conversions", 0)),
                    "ctr": clicks / impr if impr > 0 else 0,
                    "cvr": safe_num(m.get("conversions", 0)) / clicks
                    if clicks > 0
                    else 0,
                }

            # Total spend/conversions for share calculations
            total_spend = sum(b["spend"] for b in camp_bl.values())
            total_conv = sum(b["conversions"] for b in camp_bl.values())

            # 90d lookup for stability
            aud_90d: Dict[str, Dict[str, float]] = {}
            for row in audiences_90d:
                key = str(row.get("ad_group_criterion", {}).get("criterion_id", ""))
                m = row.get("metrics", {})
                aud_90d[key] = {
                    "impressions": safe_num(m.get("impressions", 0)),
                    "clicks": safe_num(m.get("clicks", 0)),
                    "conversions": safe_num(m.get("conversions", 0)),
                    "spend": safe_num(m.get("cost_micros", 0)) / 1_000_000,
                    "conv_value": safe_num(m.get("conversions_value", 0)),
                }

            # Score each audience
            scored: List[Dict[str, Any]] = []
            filtered: List[Dict[str, Any]] = []

            for row in audiences_30d:
                criterion = row.get("ad_group_criterion", {})
                m = row.get("metrics", {})
                camp = row.get("campaign", {})
                ag = row.get("ad_group", {})
                cid = str(camp.get("id", ""))
                agid = str(ag.get("id", ""))
                criterion_id = str(criterion.get("criterion_id", ""))

                # Observation vs Targeting
                bid_modifier = safe_num(criterion.get("bid_modifier", 0))
                # In GAQL, bid_only distinction comes from criterion type context
                # Simplified: if bid_modifier is set, it's likely observation
                is_observation = (
                    bid_modifier != 0 and criterion.get("status") != "ENABLED"
                )

                audience_metrics = {
                    "impressions": safe_num(m.get("impressions", 0)),
                    "clicks": safe_num(m.get("clicks", 0)),
                    "conversions": safe_num(m.get("conversions", 0)),
                    "spend": safe_num(m.get("cost_micros", 0)) / 1_000_000,
                    "conv_value": safe_num(m.get("conversions_value", 0)),
                }

                # Minimum volume threshold
                channel = camp.get("advertising_channel_type", "")
                is_display_video = channel in ("DISPLAY", "VIDEO")
                target_cpa_micros = safe_num(
                    camp.get("target_cpa", {}).get("target_cpa_micros", 0)
                ) or safe_num(
                    camp.get("maximize_conversions", {}).get("target_cpa_micros", 0)
                )
                target_cpa = target_cpa_micros / 1_000_000 if target_cpa_micros else 0
                min_spend = target_cpa * (2 if is_display_video else 1)

                if audience_metrics["clicks"] < 100 and (
                    min_spend == 0 or audience_metrics["spend"] < min_spend
                ):
                    filtered.append(
                        {
                            "criterion_id": criterion_id,
                            "reason": "INSUFFICIENT_DATA",
                        }
                    )
                    continue

                # Target metrics
                target_roas = safe_num(
                    camp.get("target_roas", {}).get("target_roas", 0)
                ) or safe_num(
                    camp.get("maximize_conversion_value", {}).get("target_roas", 0)
                )
                uses_roas = camp.get("bidding_strategy_type", "") in (
                    "TARGET_ROAS",
                    "MAXIMIZE_CONVERSION_VALUE",
                )

                # Compute score
                scoring = self._compute_efficiency_score(
                    audience_metrics,
                    target_cpa,
                    target_roas,
                    uses_roas,
                    camp_bl.get(cid, {}),
                    ag_bl.get(agid, {}),
                    total_spend,
                    total_conv,
                )

                classification = self._classify_audience(
                    scoring["score_pct"],
                    scoring["conv_share_pct"],
                    scoring["spend_share_pct"],
                )

                # Indexes
                camp_baseline = camp_bl.get(cid, {})
                camp_roas = camp_baseline.get("conversions", 0)  # simplified
                aud_cpa = (
                    audience_metrics["spend"] / audience_metrics["conversions"]
                    if audience_metrics["conversions"] > 0
                    else 0
                )
                aud_roas = (
                    audience_metrics["conv_value"] / audience_metrics["spend"]
                    if audience_metrics["spend"] > 0
                    else 0
                )

                scored.append(
                    {
                        "criterion_id": criterion_id,
                        "criterion_type": criterion.get("type", ""),
                        "ad_group_id": agid,
                        "ad_group_name": ag.get("name", ""),
                        "campaign_id": cid,
                        "campaign_name": camp.get("name", ""),
                        "channel": channel,
                        "is_observation": is_observation,
                        "metrics_30d": audience_metrics,
                        "metrics_90d": aud_90d.get(criterion_id),
                        "scoring": scoring,
                        "classification": classification,
                        "cpa": round(aud_cpa, 2),
                        "roas": round(aud_roas, 2),
                        "ctr_index": scoring["ctr_index"],
                        "cvr_index": scoring["cvr_index"],
                    }
                )

            # Sort by score descending
            scored.sort(key=lambda a: a["scoring"]["score_pct"], reverse=True)

            # Additional checks
            alerts: List[str] = []
            observation_audiences = [a for a in scored if a["is_observation"]]
            if observation_audiences:
                alerts.append(
                    f"{len(observation_audiences)} audiences set as Observation — data is directional only, not conclusive. "
                    "To get clear performance data, run a short-window test with Targeting."
                )

            await ctx.log(
                level="info",
                message=f"Analyzed {len(scored)} audiences ({len(filtered)} filtered for insufficient data)",
            )

            return {
                "total_audiences": len(scored),
                "filtered": len(filtered),
                "audiences": scored,
                "alerts": alerts,
                "write_actions_available": {
                    "exclude_audience": True,
                    "add_audience": True,
                    "adjust_bid_modifier": False,
                    "adjust_bid_modifier_reason": "ad_group_bid_modifier_service NOT FIXED",
                    "create_ad_group": True,
                },
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_audience_analysis_tools(mcp: FastMCP[Any]) -> AudienceAnalysisService:
    """Register audience analysis workflow tools with the MCP server."""
    service = AudienceAnalysisService()

    @mcp.tool()
    async def analyze_audiences(
        ctx: Context,
        customer_id: str,
        days: int = 30,
        campaign_type: str | None = None,
        campaign_id: str | None = None,
        campaign_name: str | None = None,
    ) -> Dict[str, Any]:
        """Analyze audience performance with efficiency scoring and classification.

        Scores audiences on profitability (55%), quality (22.5%), and scale (22.5%).
        Classifies into: Scale & Efficient, Efficient but Small, Scale but Inefficient, Inefficient.
        Distinguishes Observation vs Targeting audiences (Observation data is directional only).

        Args:
            customer_id: Google Ads customer ID
            days: Lookback window (default 30, also pulls 90d for benchmarks)
            campaign_type: Optional filter by campaign type (SEARCH, DISPLAY, VIDEO, SHOPPING, PERFORMANCE_MAX, DEMAND_GEN)
            campaign_id: Optional filter by campaign ID to analyze a single campaign
            campaign_name: Optional partial campaign name filter (uses LIKE '%name%' matching)
        """
        return await service.analyze_audiences(
            ctx, customer_id, days, campaign_type, campaign_id, campaign_name
        )

    return service
