"""Creative Analysis — workflow from creative-analysis.md

Scores creatives using weighted formula:
  50% Efficiency (CPA or ROAS)
  30% Quality (CVR or VPC)
  20% Engagement (CTR)

Thresholds & alerts, then classify into bottom/middle/top 20%.

Reads: all via GAQL execute_query ✅
Writes needed:
  - ad_group_ad_update_ad_group_ad_status ❌ NOT FIXED (pause bottom 20%)
  - recommendation_get_recommendations ❌ NOT FIXED (Google's ad suggestions)
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.services.workflows.campaign_filter import resolve_campaign_filter
from src.utils import (
    format_customer_id,
    get_logger,
    run_with_timeout,
    safe_num,
    serialize_proto_message,
)


def _date_range_clause(days: int) -> str:
    """Convert days to GAQL date filter. Uses DURING for 7/14/30, explicit range otherwise."""
    if days in (7, 14, 30):
        return f"segments.date DURING LAST_{days}_DAYS"
    end = datetime.now().strftime("%Y-%m-%d")
    start = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    return f"segments.date BETWEEN '{start}' AND '{end}'"


logger = get_logger(__name__)


class CreativeAnalysisService:
    """Scores and classifies ad creatives with actionable recommendations."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    async def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        def _execute() -> List[Dict[str, Any]]:
            response = self.service.search(customer_id=customer_id, query=query)
            return [serialize_proto_message(row) for row in response]

        return await run_with_timeout(_execute)

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    async def _get_ad_performance(
        self,
        customer_id: str,
        days: int = 30,
        filter_clause: str = "",
    ) -> List[Dict[str, Any]]:
        """Pull ad-level performance metrics."""
        return await self._query(
            customer_id,
            f"""
            SELECT
                ad_group_ad.ad.id,
                ad_group_ad.ad.name,
                ad_group_ad.ad.type,
                ad_group_ad.ad_strength,
                ad_group_ad.ad.final_urls,
                ad_group_ad.status,
                ad_group.id,
                ad_group.name,
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.bidding_strategy_type,
                campaign.target_cpa.target_cpa_micros,
                campaign.maximize_conversions.target_cpa_micros,
                campaign.maximize_conversion_value.target_roas,
                campaign.target_roas.target_roas,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions,
                metrics.cost_micros,
                metrics.conversions_value
            FROM ad_group_ad
            WHERE ad_group_ad.status != 'REMOVED'
                AND campaign.status != 'REMOVED'
                AND {_date_range_clause(days)}
                {filter_clause}
            """,
        )

    # ------------------------------------------------------------------
    # Scoring logic
    # ------------------------------------------------------------------

    def _compute_metrics(self, ad: Dict[str, Any]) -> Dict[str, float]:
        """Compute derived metrics for a single ad."""
        m = ad.get("metrics", {})
        impressions = safe_num(m.get("impressions", 0))
        clicks = safe_num(m.get("clicks", 0))
        conversions = safe_num(m.get("conversions", 0))
        cost = safe_num(m.get("cost_micros", 0)) / 1_000_000
        conv_value = safe_num(m.get("conversions_value", 0))

        ctr = clicks / impressions if impressions > 0 else 0
        cvr = conversions / clicks if clicks > 0 else 0
        vpc = conv_value / clicks if clicks > 0 else 0
        cpa = cost / conversions if conversions > 0 else 0
        roas = conv_value / cost if cost > 0 else 0

        return {
            "impressions": impressions,
            "clicks": clicks,
            "conversions": conversions,
            "spend": round(cost, 2),
            "conversion_value": round(conv_value, 2),
            "ctr": round(ctr, 4),
            "cvr": round(cvr, 4),
            "vpc": round(vpc, 2),
            "cpa": round(cpa, 2),
            "roas": round(roas, 2),
        }

    def _check_thresholds(
        self,
        computed: Dict[str, float],
        target_cpa: float,
        channel_type: str,
    ) -> Optional[str]:
        """Apply Matthias's threshold filters. Returns status label or None if OK."""
        impressions = computed["impressions"]
        clicks = computed["clicks"]
        spend = computed["spend"]
        conversions = computed["conversions"]
        ctr = computed["ctr"]
        cvr = computed["cvr"]

        # Insufficient data filters
        if impressions < 500 or clicks < 100 or (target_cpa > 0 and spend < target_cpa):
            return "INSUFFICIENT_DATA"

        if conversions == 0 and target_cpa > 0 and spend < 2 * target_cpa:
            return "INSUFFICIENT_DATA"

        if conversions == 0 and target_cpa > 0 and spend >= 2 * target_cpa:
            return "TO_PAUSE — $0 conversions after spending 2x target CPA"

        # CTR alerts
        is_search = channel_type in ("SEARCH",)
        is_display = channel_type in ("DISPLAY", "MULTI_CHANNEL")
        if is_search and ctr < 0.005:
            return "ENGAGEMENT_ALERT — CTR < 0.5% for Search. Creative needs changing."
        if is_display and ctr < 0.0005:
            return (
                "ENGAGEMENT_ALERT — CTR < 0.05% for Display. Creative needs changing."
            )

        # Quality alert
        if ctr >= 0.005 and cvr == 0:
            return "QUALITY_ALERT — CTR OK but CVR = 0. Copy may be misleading or LP misaligned."

        return None

    def _score_creative(
        self,
        computed: Dict[str, float],
        target_cpa: float,
        target_roas: float,
        uses_roas_bidding: bool,
        campaign_avg_cvr: float,
        campaign_avg_ctr: float,
    ) -> float:
        """Weighted creative score: 50% efficiency, 30% quality, 20% engagement.

        Each component is normalized 0-1 relative to target/campaign avg."""
        # Efficiency (50%)
        if uses_roas_bidding and target_roas > 0:
            efficiency = min(computed["roas"] / target_roas, 2.0) / 2.0
        elif target_cpa > 0 and computed["cpa"] > 0:
            efficiency = min(target_cpa / computed["cpa"], 2.0) / 2.0
        else:
            efficiency = 0.5  # No target, neutral score

        # Quality (30%) — CVR index vs campaign average
        if campaign_avg_cvr > 0:
            quality = min(computed["cvr"] / campaign_avg_cvr, 2.0) / 2.0
        else:
            quality = 0.5

        # Engagement (20%) — CTR index vs campaign average
        if campaign_avg_ctr > 0:
            engagement = min(computed["ctr"] / campaign_avg_ctr, 2.0) / 2.0
        else:
            engagement = 0.5

        score = efficiency * 0.50 + quality * 0.30 + engagement * 0.20
        return round(score * 100, 1)  # 0-100 scale

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def analyze_creatives(
        self,
        ctx: Context,
        customer_id: str,
        days: int = 30,
        campaign_type: Optional[str] = None,
        campaign_id: Optional[str] = None,
        campaign_name: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run full creative analysis with scoring, thresholds, and recommendations.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID
            days: Lookback window (default 30, also runs 90d for stability)
            campaign_type: Optional campaign type filter (SEARCH, DISPLAY, VIDEO, SHOPPING, PERFORMANCE_MAX, DEMAND_GEN)
            campaign_id: Optional campaign ID filter to analyze a single campaign
            campaign_name: Optional partial campaign name filter (uses LIKE '%name%' matching)

        Returns:
            Analysis with scored/classified creatives and campaign-level flags.
        """
        customer_id = format_customer_id(customer_id)

        try:
            filter_clause = await resolve_campaign_filter(
                customer_id, campaign_type, campaign_id, campaign_name
            )
            ads_30d = await self._get_ad_performance(customer_id, days, filter_clause)
            ads_90d = await self._get_ad_performance(customer_id, 90, filter_clause)

            # Build 90d lookup for stability
            ad_90d_metrics: Dict[str, Dict[str, float]] = {}
            for ad in ads_90d:
                ad_id = str(ad.get("ad_group_ad", {}).get("ad", {}).get("id", ""))
                ad_90d_metrics[ad_id] = self._compute_metrics(ad)

            # Compute campaign-level averages for normalization
            campaign_totals: Dict[str, Dict[str, float]] = {}
            for ad in ads_30d:
                cid = str(ad.get("campaign", {}).get("id", ""))
                m = ad.get("metrics", {})
                totals = campaign_totals.setdefault(
                    cid, {"clicks": 0, "impressions": 0, "conversions": 0}
                )
                totals["clicks"] += safe_num(m.get("clicks", 0))
                totals["impressions"] += safe_num(m.get("impressions", 0))
                totals["conversions"] += safe_num(m.get("conversions", 0))

            campaign_avgs: Dict[str, Dict[str, float]] = {}
            for cid, totals in campaign_totals.items():
                campaign_avgs[cid] = {
                    "avg_ctr": totals["clicks"] / totals["impressions"]
                    if totals["impressions"] > 0
                    else 0,
                    "avg_cvr": totals["conversions"] / totals["clicks"]
                    if totals["clicks"] > 0
                    else 0,
                }

            # Score each ad
            scored_ads: List[Dict[str, Any]] = []
            for ad in ads_30d:
                ad_data = ad.get("ad_group_ad", {}).get("ad", {})
                ad_id = str(ad_data.get("id", ""))
                ad_group = ad.get("ad_group", {})
                campaign = ad.get("campaign", {})
                cid = str(campaign.get("id", ""))
                channel = campaign.get("advertising_channel_type", "")

                # Target metrics
                target_cpa_micros = safe_num(
                    campaign.get("target_cpa", {}).get("target_cpa_micros", 0)
                ) or safe_num(
                    campaign.get("maximize_conversions", {}).get("target_cpa_micros", 0)
                )
                target_cpa = target_cpa_micros / 1_000_000 if target_cpa_micros else 0
                target_roas = safe_num(
                    campaign.get("target_roas", {}).get("target_roas", 0)
                ) or safe_num(
                    campaign.get("maximize_conversion_value", {}).get("target_roas", 0)
                )
                uses_roas = campaign.get("bidding_strategy_type", "") in (
                    "TARGET_ROAS",
                    "MAXIMIZE_CONVERSION_VALUE",
                )

                computed = self._compute_metrics(ad)
                threshold_status = self._check_thresholds(computed, target_cpa, channel)

                if threshold_status:
                    scored_ads.append(
                        {
                            "ad_id": ad_id,
                            "ad_group_id": str(ad_group.get("id", "")),
                            "ad_group_name": ad_group.get("name", ""),
                            "campaign_id": cid,
                            "campaign_name": campaign.get("name", ""),
                            "status": threshold_status,
                            "metrics_30d": computed,
                            "metrics_90d": ad_90d_metrics.get(ad_id),
                            "score": None,
                            "tier": None,
                            "recommendation": threshold_status,
                        }
                    )
                    continue

                avgs = campaign_avgs.get(cid, {"avg_ctr": 0, "avg_cvr": 0})
                score = self._score_creative(
                    computed,
                    target_cpa,
                    target_roas,
                    uses_roas,
                    avgs["avg_cvr"],
                    avgs["avg_ctr"],
                )

                scored_ads.append(
                    {
                        "ad_id": ad_id,
                        "ad_group_id": str(ad_group.get("id", "")),
                        "ad_group_name": ad_group.get("name", ""),
                        "campaign_id": cid,
                        "campaign_name": campaign.get("name", ""),
                        "ad_type": ad_data.get("type", ""),
                        "ad_strength": ad.get("ad_group_ad", {}).get("ad_strength", ""),
                        "final_url": (ad_data.get("final_urls", []) or [""])[0]
                        if ad_data.get("final_urls")
                        else "",
                        "metrics_30d": computed,
                        "metrics_90d": ad_90d_metrics.get(ad_id),
                        "score": score,
                        "tier": None,  # Set after ranking
                        "recommendation": None,
                    }
                )

            # Rank scored ads into tiers (bottom/middle/top 20%)
            scoreable = [a for a in scored_ads if a["score"] is not None]
            scoreable.sort(key=lambda a: a["score"])
            n = len(scoreable)
            bottom_cutoff = int(n * 0.2)
            top_cutoff = int(n * 0.8)

            for i, ad in enumerate(scoreable):
                if i < bottom_cutoff:
                    ad["tier"] = "BOTTOM_20"
                    ad["recommendation"] = (
                        "PAUSE_OR_IMPROVE — Check GAds ad strength for basic improvements. Unpin, use more keywords in copy, fill all headline/description slots."
                    )
                elif i >= top_cutoff:
                    ad["tier"] = "TOP_20"
                    ad["recommendation"] = (
                        "EXPAND — Use with more keywords/placements. Add to higher-spend ad groups. A/B test small variations (headlines, CTA, image)."
                    )
                else:
                    ad["tier"] = "MIDDLE_60"
                    ad["recommendation"] = (
                        "TEST_VARIATIONS — Create 1-2 variations. If still middle after 2 rounds, suggest pausing."
                    )

            # Campaign-level flags
            campaign_flags: List[Dict[str, str]] = []
            # Flag: many bottom 20% in same campaign
            campaign_bottom_counts: Dict[str, int] = {}
            campaign_total_counts: Dict[str, int] = {}
            for ad in scoreable:
                cid = ad["campaign_id"]
                campaign_total_counts[cid] = campaign_total_counts.get(cid, 0) + 1
                if ad["tier"] == "BOTTOM_20":
                    campaign_bottom_counts[cid] = campaign_bottom_counts.get(cid, 0) + 1

            for cid, bottom_count in campaign_bottom_counts.items():
                total = campaign_total_counts.get(cid, 1)
                if bottom_count / total >= 0.5:
                    campaign_flags.append(
                        {
                            "campaign_id": cid,
                            "flag": f"CAMPAIGN_ISSUE — {bottom_count}/{total} creatives in bottom 20%. Likely audience, LP, or offer problem, not creative.",
                        }
                    )

            # Flag: bottom 20% ad in same ad group as top 20% → LP mismatch
            ad_group_tiers: Dict[str, List[str]] = {}
            for ad in scoreable:
                agid = ad["ad_group_id"]
                ad_group_tiers.setdefault(agid, []).append(ad["tier"])

            for agid, tiers in ad_group_tiers.items():
                if "BOTTOM_20" in tiers and "TOP_20" in tiers:
                    campaign_flags.append(
                        {
                            "ad_group_id": agid,
                            "flag": "LP_MISMATCH — Bottom 20% ad coexists with top 20% in same ad group. Check landing page alignment.",
                        }
                    )

            await ctx.log(
                level="info",
                message=f"Analyzed {len(scored_ads)} creatives ({len(scoreable)} scored, {len(scored_ads) - len(scoreable)} filtered)",
            )

            return {
                "total_ads": len(scored_ads),
                "scored_ads": len(scoreable),
                "filtered_ads": len(scored_ads) - len(scoreable),
                "creatives": scored_ads,
                "campaign_flags": campaign_flags,
                "write_actions_available": {
                    "pause_ad": False,
                    "pause_ad_reason": "ad_group_ad_service NOT FIXED — needs v20→get_type() migration",
                    "get_recommendations": False,
                    "get_recommendations_reason": "recommendation_service NOT FIXED — needs v20→get_type() migration",
                },
            }

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_creative_analysis_tools(mcp: FastMCP[Any]) -> CreativeAnalysisService:
    """Register creative analysis workflow tools with the MCP server."""
    service = CreativeAnalysisService()

    @mcp.tool()
    async def analyze_creatives(
        ctx: Context,
        customer_id: str,
        days: int = 30,
        campaign_type: str | None = None,
        campaign_id: str | None = None,
        campaign_name: str | None = None,
    ) -> Dict[str, Any]:
        """Score and classify ad creatives. Weighted: 50% efficiency, 30% quality, 20% engagement.

        Filters out ads with insufficient data, then ranks into bottom/middle/top 20%.
        Bottom 20% get pause/improve suggestions. Top 20% get expansion suggestions.
        Flags campaigns where most creatives are underperforming (audience/LP issue, not creative).

        Args:
            customer_id: Google Ads customer ID
            days: Lookback window (default 30, always also pulls 90d for stability)
            campaign_type: Optional filter by campaign type (SEARCH, DISPLAY, VIDEO, SHOPPING, PERFORMANCE_MAX, DEMAND_GEN)
            campaign_id: Optional filter by campaign ID to analyze a single campaign
            campaign_name: Optional partial campaign name filter (uses LIKE '%name%' matching)
        """
        return await service.analyze_creatives(
            ctx, customer_id, days, campaign_type, campaign_id, campaign_name
        )

    return service
