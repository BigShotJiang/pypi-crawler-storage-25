"""Underspend Diagnosis — workflow from understand-vs-budget.md

5-layer diagnostic for campaigns that are underspending:
  Layer 1: Hard issues (status, disapprovals, end date, spending cap, shared budget)
  Layer 2: Limited reach (geo, scheduling, demographics, keywords, placements)
  Layer 3: Bidding competitiveness (impression share lost to rank, target misalignment)
  Layer 4: Quality (ad strength, expected CTR, LP relevance)
  Layer 5: Other (purchase window / conversion lag)

Reads: all via GAQL ✅
Writes: most actions via fixed services ✅
  - ad_group_ad_update_ad_group_ad_status ❌ NOT FIXED (re-enable ads)

Guardrails:
  - Minimum data: 100+ clicks OR spend >= 1x target CPA in last 30d
  - Don't change budget/targets by > 30% in one decision cycle
"""

from typing import Any, Dict, List

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client
from src.utils import (
    format_customer_id,
    get_logger,
    run_with_timeout,
    safe_num,
    serialize_proto_message,
)

logger = get_logger(__name__)


class UnderspendDiagnosisService:
    """5-layer diagnostic for underspending campaigns."""

    def __init__(self) -> None:
        self._service: Any = None

    @property
    def service(self) -> Any:
        if self._service is None:
            self._service = get_sdk_client().client.get_service("GoogleAdsService")
        return self._service

    async def _query(self, customer_id: str, query: str) -> List[Dict[str, Any]]:
        def _execute() -> List[Dict[str, Any]]:
            response = self.service.search(customer_id=customer_id, query=query)
            return [serialize_proto_message(row) for row in response]

        return await run_with_timeout(_execute)

    # ------------------------------------------------------------------
    # GAQL queries
    # ------------------------------------------------------------------

    async def _get_campaign_spend_vs_budget(
        self, customer_id: str
    ) -> List[Dict[str, Any]]:
        """Daily spend vs budget for underspend detection."""
        return await self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.name,
                campaign.status,
                campaign.advertising_channel_type,
                campaign.bidding_strategy_type,
                campaign.target_cpa.target_cpa_micros,
                campaign.maximize_conversions.target_cpa_micros,
                campaign.network_settings.target_search_network,
                campaign_budget.amount_micros,
                campaign_budget.explicitly_shared,
                metrics.cost_micros,
                metrics.impressions,
                metrics.clicks,
                metrics.conversions,
                metrics.search_impression_share,
                metrics.search_budget_lost_impression_share,
                metrics.search_rank_lost_impression_share
            FROM campaign
            WHERE campaign.status != 'REMOVED'
                AND segments.date DURING LAST_7_DAYS
            """,
        )

    async def _get_ad_statuses(self, customer_id: str) -> List[Dict[str, Any]]:
        """Ad-level status and approval info."""
        return await self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                ad_group.id,
                ad_group.status,
                ad_group_ad.ad.id,
                ad_group_ad.status,
                ad_group_ad.policy_summary.approval_status,
                ad_group_ad.ad_strength
            FROM ad_group_ad
            WHERE campaign.status != 'REMOVED'
                AND ad_group_ad.status != 'REMOVED'
            """,
        )

    async def _get_targeting_constraints(
        self, customer_id: str
    ) -> List[Dict[str, Any]]:
        """Campaign-level targeting criteria (geo, scheduling, language)."""
        return await self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                campaign_criterion.type,
                campaign_criterion.location.geo_target_constant,
                campaign_criterion.ad_schedule.day_of_week,
                campaign_criterion.negative
            FROM campaign_criterion
            WHERE campaign.status != 'REMOVED'
            """,
        )

    async def _get_keyword_analysis(self, customer_id: str) -> List[Dict[str, Any]]:
        """Keyword match types, negative counts, and quality info."""
        return await self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                ad_group.id,
                ad_group_criterion.keyword.text,
                ad_group_criterion.keyword.match_type,
                ad_group_criterion.negative,
                ad_group_criterion.status,
                ad_group_criterion.quality_info.quality_score,
                ad_group_criterion.quality_info.creative_quality_score,
                ad_group_criterion.quality_info.post_click_quality_score,
                ad_group_criterion.quality_info.search_predicted_ctr
            FROM ad_group_criterion
            WHERE ad_group_criterion.type = 'KEYWORD'
                AND campaign.status != 'REMOVED'
            """,
        )

    async def _get_demographic_criteria(self, customer_id: str) -> List[Dict[str, Any]]:
        """Ad group demographic targeting."""
        return await self._query(
            customer_id,
            """
            SELECT
                campaign.id,
                campaign.status,
                ad_group.id,
                ad_group_criterion.type,
                ad_group_criterion.age_range.type,
                ad_group_criterion.gender.type,
                ad_group_criterion.status
            FROM ad_group_criterion
            WHERE ad_group_criterion.type IN ('AGE_RANGE', 'GENDER')
                AND campaign.status != 'REMOVED'
            """,
        )

    # ------------------------------------------------------------------
    # Layer checks
    # ------------------------------------------------------------------

    def _check_layer1_hard_issues(
        self,
        campaign: Dict[str, Any],
        ad_statuses: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Layer 1: Status, disapprovals, end date, shared budget."""
        issues: List[Dict[str, Any]] = []
        camp = campaign.get("campaign", {})
        cid = str(camp.get("id", ""))

        # Campaign not active
        if camp.get("status") != "ENABLED":
            issues.append(
                {
                    "layer": 1,
                    "check": "CAMPAIGN_STATUS",
                    "severity": "CRITICAL",
                    "detail": f"Campaign status is {camp.get('status')} — activate it",
                    "action": "campaign_update_campaign (status=ENABLED) ✅ FIXED",
                }
            )

        # Ad group / ad status
        campaign_ads = [
            a for a in ad_statuses if str(a.get("campaign", {}).get("id", "")) == cid
        ]
        active_ads = [
            a
            for a in campaign_ads
            if a.get("ad_group_ad", {}).get("status") == "ENABLED"
            and a.get("ad_group", {}).get("status") == "ENABLED"
        ]
        if not active_ads and campaign_ads:
            issues.append(
                {
                    "layer": 1,
                    "check": "NO_ACTIVE_ADS",
                    "severity": "CRITICAL",
                    "detail": f"{len(campaign_ads)} ads in campaign but 0 active — enable at least one per ad group",
                    "action": "ad_group_ad_update_ad_group_ad_status ❌ NOT FIXED",
                }
            )

        # Disapprovals
        disapproved = [
            a
            for a in campaign_ads
            if a.get("ad_group_ad", {}).get("policy_summary", {}).get("approval_status")
            == "DISAPPROVED"
        ]
        total_ads = len(campaign_ads) or 1
        if len(disapproved) / total_ads > 0.20:
            issues.append(
                {
                    "layer": 1,
                    "check": "HIGH_DISAPPROVALS",
                    "severity": "HIGH",
                    "detail": f"{len(disapproved)}/{total_ads} ads disapproved (>{20}%) — replace or fix and re-submit",
                    "action": "Manual — fix ad copy/policy violations",
                }
            )

        # End date in the past
        end_date = camp.get("end_date", "")
        if end_date and end_date < "2026-03-23":  # Today
            issues.append(
                {
                    "layer": 1,
                    "check": "PAST_END_DATE",
                    "severity": "CRITICAL",
                    "detail": f"Campaign end date {end_date} is in the past — update it",
                    "action": "campaign_update_campaign ✅ FIXED",
                }
            )

        # Shared budget
        shared = campaign.get("campaign_budget", {}).get("explicitly_shared", False)
        if shared:
            issues.append(
                {
                    "layer": 1,
                    "check": "SHARED_BUDGET",
                    "severity": "MEDIUM",
                    "detail": "Campaign uses shared budget — split to own budget or raise shared by up to 30%",
                    "action": "budget_update_campaign_budget ✅ FIXED",
                }
            )

        return issues

    def _check_layer2_limited_reach(
        self,
        campaign: Dict[str, Any],
        targeting: List[Dict[str, Any]],
        keywords: List[Dict[str, Any]],
        demographics: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Layer 2: Targeting constraints that limit reach."""
        issues: List[Dict[str, Any]] = []
        camp = campaign.get("campaign", {})
        cid = str(camp.get("id", ""))

        camp_targeting = [
            t for t in targeting if str(t.get("campaign", {}).get("id", "")) == cid
        ]
        camp_keywords = [
            k for k in keywords if str(k.get("campaign", {}).get("id", "")) == cid
        ]
        camp_demographics = [
            d for d in demographics if str(d.get("campaign", {}).get("id", "")) == cid
        ]

        # Ad scheduling
        schedules = [
            t
            for t in camp_targeting
            if t.get("campaign_criterion", {}).get("type") == "AD_SCHEDULE"
        ]
        if schedules:
            issues.append(
                {
                    "layer": 2,
                    "check": "AD_SCHEDULING",
                    "severity": "MEDIUM",
                    "detail": f"{len(schedules)} ad schedule restrictions — consider removing time limits",
                    "action": "campaign_criterion_remove_campaign_criterion ✅ FIXED",
                }
            )

        # Demographics
        excluded_demos = [
            d
            for d in camp_demographics
            if d.get("ad_group_criterion", {}).get("status") == "EXCLUDED"
        ]
        if len(excluded_demos) > 3:
            issues.append(
                {
                    "layer": 2,
                    "check": "DEMOGRAPHIC_FILTERS",
                    "severity": "MEDIUM",
                    "detail": f"{len(excluded_demos)} demographic exclusions — consider removing",
                    "action": "ad_group_criterion_remove_ad_group_criterion ✅ FIXED",
                }
            )

        # Keywords analysis
        positive_kws = [
            k
            for k in camp_keywords
            if not k.get("ad_group_criterion", {}).get("negative", False)
        ]
        negative_kws = [
            k
            for k in camp_keywords
            if k.get("ad_group_criterion", {}).get("negative", False)
        ]
        exact_kws = [
            k
            for k in positive_kws
            if k.get("ad_group_criterion", {}).get("keyword", {}).get("match_type")
            == "EXACT"
        ]
        paused_kws = [
            k
            for k in positive_kws
            if k.get("ad_group_criterion", {}).get("status") in ("PAUSED", "LIMITED")
        ]

        if len(positive_kws) < 10:
            issues.append(
                {
                    "layer": 2,
                    "check": "TOO_FEW_KEYWORDS",
                    "severity": "HIGH",
                    "detail": f"Only {len(positive_kws)} positive keywords — add more",
                    "action": "ad_group_criterion_add_keywords ✅ FIXED",
                }
            )

        if positive_kws and len(exact_kws) / len(positive_kws) > 0.8:
            issues.append(
                {
                    "layer": 2,
                    "check": "MOSTLY_EXACT_MATCH",
                    "severity": "MEDIUM",
                    "detail": f"{len(exact_kws)}/{len(positive_kws)} keywords are exact match — expand with phrase/broad",
                    "action": "ad_group_criterion_add_keywords ✅ FIXED",
                }
            )

        if len(negative_kws) > 50:
            issues.append(
                {
                    "layer": 2,
                    "check": "HEAVY_NEGATIVES",
                    "severity": "LOW",
                    "detail": f"{len(negative_kws)} negative keywords — review and prune if too restrictive",
                    "action": "Manual review needed",
                }
            )

        if len(paused_kws) > len(positive_kws) * 0.5:
            issues.append(
                {
                    "layer": 2,
                    "check": "MANY_PAUSED_KEYWORDS",
                    "severity": "MEDIUM",
                    "detail": f"{len(paused_kws)}/{len(positive_kws)} keywords paused/limited — add fresh keywords",
                    "action": "ad_group_criterion_add_keywords ✅ FIXED",
                }
            )

        # Search partners
        search_partners = camp.get("network_settings", {}).get(
            "target_search_network", False
        )
        if not search_partners:
            issues.append(
                {
                    "layer": 2,
                    "check": "SEARCH_PARTNERS_OFF",
                    "severity": "LOW",
                    "detail": "Search partners disabled — consider enabling",
                    "action": "campaign_update_campaign ✅ FIXED",
                }
            )

        return issues

    def _check_layer3_bidding(self, campaign: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Layer 3: Bidding competitiveness."""
        issues: List[Dict[str, Any]] = []
        camp = campaign.get("campaign", {})
        metrics = campaign.get("metrics", {})

        lost_rank = safe_num(metrics.get("search_rank_lost_impression_share", 0))
        lost_budget = safe_num(metrics.get("search_budget_lost_impression_share", 0))

        if lost_rank >= 0.30 and lost_budget < 0.10:
            issues.append(
                {
                    "layer": 3,
                    "check": "RANK_LIMITED",
                    "severity": "HIGH",
                    "detail": f"Search lost IS (rank) = {lost_rank * 100:.0f}% with lost IS (budget) = {lost_budget * 100:.0f}% — bids or ad rank limiting, not budget",
                    "action": "campaign_update_campaign (raise bids/loosen tCPA up to 30%) ✅ FIXED",
                }
            )

        # Target vs performance alignment
        strategy = camp.get("bidding_strategy_type", "")
        cost = safe_num(metrics.get("cost_micros", 0)) / 1_000_000
        conversions = safe_num(metrics.get("conversions", 0))
        target_cpa_micros = safe_num(
            camp.get("target_cpa", {}).get("target_cpa_micros", 0)
        ) or safe_num(camp.get("maximize_conversions", {}).get("target_cpa_micros", 0))
        target_cpa = target_cpa_micros / 1_000_000 if target_cpa_micros else 0
        actual_cpa = cost / conversions if conversions > 0 else 0

        if strategy == "TARGET_CPA" and target_cpa > 0 and actual_cpa > 0:
            if target_cpa < actual_cpa * 0.7:
                issues.append(
                    {
                        "layer": 3,
                        "check": "TCPA_TOO_LOW",
                        "severity": "HIGH",
                        "detail": f"tCPA ${target_cpa:.2f} is < 70% of actual CPA ${actual_cpa:.2f} — raise tCPA up to 30%",
                        "action": "campaign_update_campaign ✅ FIXED",
                    }
                )

        return issues

    def _check_layer4_quality(
        self,
        campaign: Dict[str, Any],
        ad_statuses: List[Dict[str, Any]],
        keywords: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Layer 4: Quality competitiveness (ad strength, CTR, LP relevance)."""
        issues: List[Dict[str, Any]] = []
        cid = str(campaign.get("campaign", {}).get("id", ""))

        # Ad strength
        campaign_ads = [
            a
            for a in ad_statuses
            if str(a.get("campaign", {}).get("id", "")) == cid
            and a.get("ad_group_ad", {}).get("status") == "ENABLED"
        ]
        low_strength = [
            a
            for a in campaign_ads
            if a.get("ad_group_ad", {}).get("ad_strength", "") in ("POOR", "AVERAGE")
        ]
        if low_strength:
            issues.append(
                {
                    "layer": 4,
                    "check": "LOW_AD_STRENGTH",
                    "severity": "MEDIUM",
                    "detail": f"{len(low_strength)}/{len(campaign_ads)} ads have poor/average ad strength — improve copy, add more headlines/descriptions",
                    "action": "Manual — improve ad creative",
                }
            )

        # Quality score from keywords
        camp_keywords = [
            k
            for k in keywords
            if str(k.get("campaign", {}).get("id", "")) == cid
            and not k.get("ad_group_criterion", {}).get("negative", False)
        ]
        low_qs = [
            k
            for k in camp_keywords
            if (
                k.get("ad_group_criterion", {})
                .get("quality_info", {})
                .get("quality_score")
                or 10
            )
            < 5
        ]
        if len(low_qs) > len(camp_keywords) * 0.3:
            issues.append(
                {
                    "layer": 4,
                    "check": "LOW_QUALITY_SCORES",
                    "severity": "HIGH",
                    "detail": f"{len(low_qs)}/{len(camp_keywords)} keywords have QS < 5 — improve ads and landing pages",
                    "action": "Manual — creative/LP improvement",
                }
            )

        return issues

    # ------------------------------------------------------------------
    # Main orchestrator
    # ------------------------------------------------------------------

    async def diagnose_underspend(
        self,
        ctx: Context,
        customer_id: str,
    ) -> List[Dict[str, Any]]:
        """Run 5-layer underspend diagnosis on campaigns spending < 75% of budget.

        Args:
            ctx: FastMCP context
            customer_id: Google Ads customer ID

        Returns:
            List of underspending campaigns with layered diagnosis and fix actions.
        """
        customer_id = format_customer_id(customer_id)

        try:
            campaigns = await self._get_campaign_spend_vs_budget(customer_id)
            ad_statuses = await self._get_ad_statuses(customer_id)
            targeting = await self._get_targeting_constraints(customer_id)
            keywords = await self._get_keyword_analysis(customer_id)
            demographics = await self._get_demographic_criteria(customer_id)

            results: List[Dict[str, Any]] = []
            for campaign in campaigns:
                camp = campaign.get("campaign", {})
                metrics = campaign.get("metrics", {})
                budget_micros = safe_num(
                    campaign.get("campaign_budget", {}).get("amount_micros", 0)
                )
                daily_budget = budget_micros / 1_000_000
                spend_7d = safe_num(metrics.get("cost_micros", 0)) / 1_000_000
                daily_spend = spend_7d / 7

                # Underspend trigger: >= 25% gap between budget and spend
                if (
                    daily_budget > 0
                    and (daily_budget - daily_spend) / daily_budget < 0.25
                ):
                    continue  # Not underspending

                # Also trigger on impression share drop (would need WoW comparison)
                lost_budget = safe_num(
                    metrics.get("search_budget_lost_impression_share", 0)
                )

                all_issues: List[Dict[str, Any]] = []
                all_issues.extend(self._check_layer1_hard_issues(campaign, ad_statuses))
                all_issues.extend(
                    self._check_layer2_limited_reach(
                        campaign, targeting, keywords, demographics
                    )
                )
                all_issues.extend(self._check_layer3_bidding(campaign))
                all_issues.extend(
                    self._check_layer4_quality(campaign, ad_statuses, keywords)
                )

                # Group by severity
                critical = [i for i in all_issues if i["severity"] == "CRITICAL"]
                high = [i for i in all_issues if i["severity"] == "HIGH"]
                medium = [i for i in all_issues if i["severity"] == "MEDIUM"]
                low = [i for i in all_issues if i["severity"] == "LOW"]

                results.append(
                    {
                        "campaign_id": str(camp.get("id", "")),
                        "campaign_name": camp.get("name", ""),
                        "daily_budget": round(daily_budget, 2),
                        "avg_daily_spend": round(daily_spend, 2),
                        "underspend_pct": round(
                            (1 - daily_spend / daily_budget) * 100, 1
                        )
                        if daily_budget > 0
                        else 0,
                        "total_issues": len(all_issues),
                        "issues_by_severity": {
                            "critical": len(critical),
                            "high": len(high),
                            "medium": len(medium),
                            "low": len(low),
                        },
                        "issues": all_issues,
                        "recommendation": (
                            "FIX CRITICAL FIRST — " + critical[0]["detail"]
                            if critical
                            else "ADDRESS HIGH PRIORITY — " + high[0]["detail"]
                            if high
                            else "REVIEW MEDIUM ISSUES"
                            if medium
                            else "MINOR ISSUES ONLY"
                            if low
                            else "NO ISSUES FOUND — underspend may be normal (seasonal, low demand)"
                        ),
                    }
                )

            results.sort(key=lambda r: r["total_issues"], reverse=True)

            await ctx.log(
                level="info",
                message=f"Found {len(results)} underspending campaigns with {sum(r['total_issues'] for r in results)} total issues",
            )
            return results

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e


def register_underspend_diagnosis_tools(
    mcp: FastMCP[Any],
) -> UnderspendDiagnosisService:
    """Register underspend diagnosis workflow tools with the MCP server."""
    service = UnderspendDiagnosisService()

    @mcp.tool()
    async def diagnose_underspend(
        ctx: Context,
        customer_id: str,
    ) -> List[Dict[str, Any]]:
        """5-layer diagnostic for underspending campaigns.

        Checks: (1) hard issues — status, disapprovals, end dates, shared budgets;
        (2) limited reach — geo, scheduling, demographics, keyword match types;
        (3) bidding — impression share lost to rank, target misalignment;
        (4) quality — ad strength, quality scores, LP relevance;
        (5) other — conversion lag.

        Returns layered issues with severity and specific fix actions.

        Args:
            customer_id: Google Ads customer ID
        """
        return await service.diagnose_underspend(ctx, customer_id)

    return service
