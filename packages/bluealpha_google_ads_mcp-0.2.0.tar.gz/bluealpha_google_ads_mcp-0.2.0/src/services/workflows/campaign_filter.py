"""Shared campaign filtering for workflow tools."""

from typing import Any, Dict, List, Optional

from src.sdk_client import get_sdk_client
from src.utils import format_customer_id, get_logger

logger = get_logger(__name__)


def build_campaign_filter_clause(
    campaign_type: Optional[str] = None,
    campaign_id: Optional[str] = None,
) -> str:
    """Build GAQL WHERE clause fragments for campaign filtering.

    Returns a string like "AND campaign.advertising_channel_type = 'SEARCH' AND campaign.id = 123"
    or empty string if no filters.
    """
    clauses = []
    if campaign_type:
        clauses.append(
            f"AND campaign.advertising_channel_type = '{campaign_type.upper()}'"
        )
    if campaign_id:
        clauses.append(f"AND campaign.id = {campaign_id}")
    return " ".join(clauses)


async def resolve_campaign_name(
    customer_id: str,
    campaign_name: str,
) -> List[Dict[str, Any]]:
    """Resolve a campaign name (or partial name) to campaign IDs.

    Uses GAQL LIKE for partial matching. Returns list of dicts with id, name, type, status.
    """
    ga_service = get_sdk_client().client.get_service("GoogleAdsService")
    cid = format_customer_id(customer_id)

    query = f"""
        SELECT
            campaign.id,
            campaign.name,
            campaign.advertising_channel_type,
            campaign.status
        FROM campaign
        WHERE campaign.name LIKE '%{campaign_name}%'
        AND campaign.status != 'REMOVED'
    """

    results = []
    response = ga_service.search(customer_id=cid, query=query)
    for row in response:
        results.append(
            {
                "id": str(row.campaign.id),
                "name": row.campaign.name,
                "type": row.campaign.advertising_channel_type.name,
                "status": row.campaign.status.name,
            }
        )
    return results


async def resolve_campaign_filter(
    customer_id: str,
    campaign_type: Optional[str] = None,
    campaign_id: Optional[str] = None,
    campaign_name: Optional[str] = None,
) -> str:
    """Resolve campaign filters into a GAQL WHERE clause fragment.

    Priority: campaign_id > campaign_name > campaign_type
    If campaign_name is provided, resolves to matching IDs and builds an IN clause.
    Returns a string to append to GAQL WHERE clauses.
    """
    if campaign_id:
        # Direct ID takes precedence
        clause = f"AND campaign.id = {campaign_id}"
        if campaign_type:
            clause += (
                f" AND campaign.advertising_channel_type = '{campaign_type.upper()}'"
            )
        return clause

    if campaign_name:
        matches = await resolve_campaign_name(customer_id, campaign_name)
        if not matches:
            raise ValueError(f"No campaigns found matching '{campaign_name}'")

        # If also filtering by type, narrow down
        if campaign_type:
            matches = [m for m in matches if m["type"] == campaign_type.upper()]
            if not matches:
                raise ValueError(
                    f"No {campaign_type} campaigns found matching '{campaign_name}'"
                )

        if len(matches) == 1:
            return f"AND campaign.id = {matches[0]['id']}"
        else:
            ids = ", ".join(m["id"] for m in matches)
            return f"AND campaign.id IN ({ids})"

    if campaign_type:
        return f"AND campaign.advertising_channel_type = '{campaign_type.upper()}'"

    return ""
