"""Customer service implementation using Google Ads SDK."""

from typing import Any, Dict, List, Optional

from fastmcp import Context
from google.ads.googleads.errors import GoogleAdsException
from google.ads.googleads.v23.services.services.customer_service import (
    CustomerServiceClient,
)

from src.sdk_client import get_sdk_client, get_type
from src.utils import format_customer_id, get_logger, serialize_proto_message

logger = get_logger(__name__)


class CustomerService:
    """Customer service for managing Google Ads customers."""

    def __init__(self) -> None:
        """Initialize the customer service."""
        self._client: Optional[CustomerServiceClient] = None

    @property
    def client(self) -> CustomerServiceClient:
        """Get the customer service client."""
        if self._client is None:
            sdk_client = get_sdk_client()
            self._client = sdk_client.client.get_service("CustomerService")
        assert self._client is not None
        return self._client

    async def create_customer_client(
        self,
        ctx: Context,
        manager_customer_id: str,
        descriptive_name: str,
        currency_code: str = "USD",
        time_zone: str = "America/New_York",
    ) -> Dict[str, Any]:
        """Create a new client customer under a manager account.

        Args:
            ctx: FastMCP context
            manager_customer_id: The manager customer ID
            descriptive_name: Name of the new client
            currency_code: Currency code (e.g. USD, EUR)
            time_zone: Time zone ID

        Returns:
            Created customer details
        """
        try:
            manager_customer_id = format_customer_id(manager_customer_id)

            # Create a new customer object
            customer = get_type("Customer")
            customer.descriptive_name = descriptive_name
            customer.currency_code = currency_code
            customer.time_zone = time_zone

            # Make the API call
            response = self.client.create_customer_client(
                customer_id=manager_customer_id,
                customer_client=customer,
            )

            # Extract customer ID from resource name
            customer_resource = response.resource_name
            customer_id = customer_resource.split("/")[-1] if customer_resource else ""

            await ctx.log(
                level="info",
                message=f"Created customer client {customer_id} under manager {manager_customer_id}",
            )

            # Return serialized response
            return serialize_proto_message(response)

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to create customer client: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e

    async def list_accessible_customers(self, ctx: Context) -> List[Dict[str, Any]]:
        """List all accessible customers for the authenticated user.

        Args:
            ctx: FastMCP context

        Returns:
            List of dicts with customer id, name, and whether it's a manager account
        """
        try:
            # Make the API call
            response = self.client.list_accessible_customers(
                request=get_type("ListAccessibleCustomersRequest")
            )

            customer_ids = [
                resource_name.split("/")[-1]
                for resource_name in response.resource_names
                if resource_name
            ]

            await ctx.log(
                level="info",
                message=f"Found {len(customer_ids)} accessible customers",
            )

            # Enrich with names and activity status by querying each customer
            ga_service = get_sdk_client().client.get_service("GoogleAdsService")
            info_query = "SELECT customer.id, customer.descriptive_name, customer.manager, customer.status FROM customer LIMIT 1"
            activity_query = "SELECT metrics.impressions FROM customer WHERE segments.date DURING LAST_30_DAYS"
            results: List[Dict[str, Any]] = []

            for cid in customer_ids:
                try:
                    rows = ga_service.search(customer_id=cid, query=info_query)
                    for row in rows:
                        entry: Dict[str, Any] = {
                            "id": str(row.customer.id),
                            "name": row.customer.descriptive_name,
                            "is_manager": row.customer.manager,
                            "status": row.customer.status.name
                            if row.customer.status
                            else "UNKNOWN",
                        }
                        # Check for recent activity (non-manager accounts only)
                        if not row.customer.manager:
                            try:
                                activity_rows = ga_service.search(
                                    customer_id=cid, query=activity_query
                                )
                                total_impressions = sum(
                                    r.metrics.impressions for r in activity_rows
                                )
                                entry["impressions_last_30d"] = total_impressions
                                entry["active"] = total_impressions > 0
                            except Exception:
                                entry["impressions_last_30d"] = None
                                entry["active"] = None
                        results.append(entry)
                except Exception:
                    # Permission denied or other error — include ID without name
                    results.append(
                        {
                            "id": cid,
                            "name": "(inaccessible)",
                            "is_manager": None,
                            "status": None,
                            "active": None,
                        }
                    )

            return results

        except GoogleAdsException as e:
            error_msg = f"Google Ads API error: {e.failure}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
        except Exception as e:
            error_msg = f"Failed to list accessible customers: {str(e)}"
            await ctx.log(level="error", message=error_msg)
            raise Exception(error_msg) from e
