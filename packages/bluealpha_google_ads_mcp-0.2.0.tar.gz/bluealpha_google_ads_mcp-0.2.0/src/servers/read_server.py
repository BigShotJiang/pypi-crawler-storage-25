"""Read server -- 8 read-only tools for querying Google Ads data.

Tools:
  execute_query          Paginated GAQL execution (the universal read tool)
  execute_query_stream   Streaming GAQL for large result sets
  list_accessible_customers  MCC account discovery (no customer ID needed)
  generate_keyword_ideas     Search volume, competition, bid estimates
  suggest_geo_targets        Location name -> geo target ID resolution
  get_field_metadata         Field schema for GAQL query building
  validate_query_fields      Check field compatibility before querying
  get_recommendations        Optimization suggestions (structured GAQL wrapper)
"""

from typing import Any, Dict, List, Optional

from fastmcp import Context, FastMCP
from google.ads.googleads.errors import GoogleAdsException

from src.sdk_client import get_sdk_client, get_type
from src.services.account.customer_service import CustomerService
from src.services.metadata.google_ads_field_service import GoogleAdsFieldService
from src.services.metadata.google_ads_service import GoogleAdsService
from src.services.planning.recommendation_service import RecommendationService
from src.services.targeting.geo_target_constant_service import GeoTargetConstantService
from src.utils import format_customer_id, serialize_proto_message

read_server = FastMCP(name="read-service")

_google_ads = GoogleAdsService()
_field = GoogleAdsFieldService()
_customer = CustomerService()
_geo = GeoTargetConstantService()
_recommendation = RecommendationService()


# ---------------------------------------------------------------------------
# GAQL execution
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def execute_query(
    ctx: Context,
    customer_id: str,
    query: str,
) -> Dict[str, Any]:
    """Execute a GAQL (Google Ads Query Language) query with pagination.

    This is the universal read tool -- any Google Ads data accessible via GAQL
    can be queried here. Use get_field_metadata to discover available fields.

    Args:
        customer_id: The customer ID (hyphens are stripped automatically)
        query: The GAQL query (e.g. "SELECT campaign.id, campaign.name FROM campaign")
    """
    return await _google_ads.search(ctx=ctx, customer_id=customer_id, query=query)


@read_server.tool(annotations={"readOnlyHint": True})
async def execute_query_stream(
    ctx: Context,
    customer_id: str,
    query: str,
) -> List[Dict[str, Any]]:
    """Execute a GAQL query and stream all results. Use for large result sets.

    Unlike execute_query, this returns all rows without pagination tokens.
    More efficient for queries that return thousands of rows.

    Args:
        customer_id: The customer ID
        query: The GAQL query
    """
    return await _google_ads.search_stream(
        ctx=ctx, customer_id=customer_id, query=query
    )


# ---------------------------------------------------------------------------
# Account discovery
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def list_accessible_customers(ctx: Context) -> list:
    """List all Google Ads accounts accessible with current credentials.

    Returns each account's ID, name, and whether it's a manager (MCC) account.
    This is the bootstrap call -- it does not require a customer ID.
    Use this first to discover which accounts you can query.
    """
    return await _customer.list_accessible_customers(ctx=ctx)


# ---------------------------------------------------------------------------
# Keyword ideas
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def generate_keyword_ideas(
    ctx: Context,
    customer_id: str,
    keywords: Optional[List[str]] = None,
    url: Optional[str] = None,
    location_ids: Optional[List[str]] = None,
    language_id: Optional[str] = None,
    limit: int = 100,
) -> list:
    """Get keyword ideas from Google's Keyword Planner.

    Provide either seed keywords or a URL (not both).
    Returns search volume, competition level, and bid estimates.

    Args:
        customer_id: The customer ID
        keywords: Seed keywords (e.g. ["marketing automation", "crm software"])
        url: Seed URL to extract keyword ideas from
        location_ids: Geo target IDs (default: ["2840"] = US)
        language_id: Language constant ID (default: "1000" = English)
        limit: Max results to return
    """
    try:
        cid = format_customer_id(customer_id)
        sdk_client = get_sdk_client()
        idea_service = sdk_client.client.get_service("KeywordPlanIdeaService")

        request = get_type("GenerateKeywordIdeasRequest")
        request.customer_id = cid
        request.include_adult_keywords = False
        request.language = f"languageConstants/{language_id or '1000'}"

        if location_ids:
            request.geo_target_constants.extend(
                [f"geoTargetConstants/{loc_id}" for loc_id in location_ids]
            )
        else:
            request.geo_target_constants.append("geoTargetConstants/2840")

        if keywords:
            request.keyword_seed.keywords.extend(keywords)
        elif url:
            request.url_seed.url = url
        else:
            raise ValueError("Provide either keywords or url")

        response = idea_service.generate_keyword_ideas(request=request)

        ideas = []
        count = 0
        for idea in response:
            if count >= limit:
                break
            ideas.append(serialize_proto_message(idea))
            count += 1

        return ideas

    except GoogleAdsException as e:
        raise Exception(f"Google Ads API error: {e.failure}") from e


# ---------------------------------------------------------------------------
# Geo target lookup
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def suggest_geo_targets(
    ctx: Context,
    location_names: Optional[List[str]] = None,
    address_text: Optional[str] = None,
    locale: str = "en",
    country_code: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Suggest geo target constants by location name or address.

    Use this to resolve human-readable locations to geo target IDs
    for use in campaign targeting. Provide either location_names or address_text.

    Args:
        location_names: Location names to search (e.g. ["San Francisco", "New York"])
        address_text: Street address to look up
        locale: Language locale for results (default: "en")
        country_code: Optional country code to filter (e.g. "US", "GB")
    """
    if location_names:
        return await _geo.suggest_geo_targets_by_location(
            ctx=ctx,
            location_names=location_names,
            locale=locale,
            country_code=country_code,
        )
    elif address_text:
        return await _geo.suggest_geo_targets_by_address(
            ctx=ctx,
            address_text=address_text,
            locale=locale,
            country_code=country_code,
        )
    raise ValueError("Provide either location_names or address_text")


# ---------------------------------------------------------------------------
# Field metadata & validation
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def get_field_metadata(
    ctx: Context,
    field_name: Optional[str] = None,
    query: Optional[str] = None,
    resource_name: Optional[str] = None,
    category_filter: Optional[str] = None,
    selectable_only: bool = False,
    include_metrics: bool = True,
    include_segments: bool = True,
    limit: int = 100,
) -> Any:
    """Get metadata about Google Ads fields for building GAQL queries.

    Three modes (provide exactly one):
      - field_name: Get metadata for a specific field (e.g. "campaign.name")
      - query: Search fields by name substring (e.g. "impression" finds all impression-related fields)
      - resource_name: Get all fields for a resource (e.g. "campaign", "ad_group")

    Args:
        field_name: Specific field name to look up
        query: Name substring to search for
        resource_name: Resource to get all fields for
        category_filter: Filter by category (RESOURCE, ATTRIBUTE, SEGMENT, METRIC)
        selectable_only: Only return selectable fields
        include_metrics: Include metrics when using resource_name mode
        include_segments: Include segments when using resource_name mode
        limit: Max results for query mode
    """
    if field_name:
        return await _field.get_field_metadata(ctx=ctx, field_name=field_name)
    elif query or category_filter:
        return await _field.search_fields(
            ctx=ctx,
            query=query,
            category_filter=category_filter,
            selectable_only=selectable_only,
            limit=limit,
        )
    elif resource_name:
        return await _field.get_resource_fields(
            ctx=ctx,
            resource_name=resource_name,
            include_metrics=include_metrics,
            include_segments=include_segments,
        )
    raise ValueError("Provide field_name, query, or resource_name")


@read_server.tool(annotations={"readOnlyHint": True})
async def validate_query_fields(
    ctx: Context,
    resource_name: str,
    field_names: List[str],
) -> Dict[str, Any]:
    """Validate if fields can be selected together in a GAQL query.

    Use this before execute_query to catch field compatibility issues.

    Args:
        resource_name: The main resource (e.g. "campaign", "ad_group")
        field_names: List of field names to validate
    """
    return await _field.validate_query_fields(
        ctx=ctx, resource_name=resource_name, field_names=field_names
    )


# ---------------------------------------------------------------------------
# Recommendations
# ---------------------------------------------------------------------------


@read_server.tool(annotations={"readOnlyHint": True})
async def get_recommendations(
    ctx: Context,
    customer_id: str,
    types: Optional[List[str]] = None,
    campaign_ids: Optional[List[str]] = None,
    dismissed: bool = False,
    limit: int = 100,
) -> List[Dict[str, Any]]:
    """Get Google's optimization recommendations for the account.

    Returns structured recommendations with type, impact, and details.
    Use apply_recommendation or dismiss_recommendation to act on them.

    Args:
        customer_id: The customer ID
        types: Filter by recommendation type (e.g. ["KEYWORD", "TARGET_CPA_OPT_IN"])
        campaign_ids: Filter to specific campaigns
        dismissed: Include dismissed recommendations
        limit: Max results
    """
    return await _recommendation.get_recommendations(
        ctx=ctx,
        customer_id=customer_id,
        types=types,
        campaign_ids=campaign_ids,
        dismissed=dismissed,
        limit=limit,
    )
