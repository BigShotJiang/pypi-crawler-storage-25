# AI Response Ops — Python SDK

Python SDK for the AI Response Ops API. Process security questionnaires through AI — KB matching + DeepSeek generation.

## Install

```bash
pip install ai-response-ops
```

## Quick start

```python
from ai_response_ops import AIResponseOps

client = AIResponseOps(api_key="your-api-key")

result = client.process([
    "Do you support SSO?",
    {"question": "How often do you run penetration tests?", "id": "q2"},
])

for a in result.results:
    print(f"[{a.source}] {a.question} -> {a.answer} (confidence: {a.confidence}%)")
```

## Async

```python
from ai_response_ops import AsyncAIResponseOps

async with AsyncAIResponseOps(api_key="your-api-key") as client:
    result = await client.process(["Do you encrypt data at rest?"])
```

## API

### `AIResponseOps(api_key, *, base_url, timeout, max_retries)`

| Param | Default | |
|-------|---------|-|
| `api_key` | — | Your workspace API key |
| `base_url` | `https://...public-api` | API base URL |
| `timeout` | `60.0` | Request timeout in seconds |
| `max_retries` | `0` | Retry on network errors (exponential backoff) |

### `.process(questions)` → `ProcessResponse`

- Max 100 questions per request
- Questions can be `str`, `dict(question, id?)`, or `Question` object

### `.health()` → `HealthResponse`

### Errors

| Error class | HTTP |
|------------|------|
| `AuthenticationError` | 401 |
| `PlanGateError` | 402 |
| `RateLimitError` | 429 |
| `ValidationError` | 400 |
| `ServerError` | 500 |
| `AIServiceError` | 502 |
