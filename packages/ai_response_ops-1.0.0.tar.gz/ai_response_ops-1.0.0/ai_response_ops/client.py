from __future__ import annotations

import time
import logging
from typing import Optional, Union
from urllib.parse import urljoin

import httpx

from .types import Question, AnswerResult, ProcessResponse, HealthResponse

logger = logging.getLogger("ai_response_ops")

DEFAULT_BASE_URL = "https://tbfxynzvprjzvoezazmj.supabase.co/functions/v1/public-api"
DEFAULT_TIMEOUT = 60.0


class AIResponseOpsError(Exception):
    """Base error for AI Response Ops SDK."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(AIResponseOpsError):
    """API key missing, invalid, or revoked (401)."""


class PlanGateError(AIResponseOpsError):
    """Workspace plan does not include API access (402)."""

    def __init__(self, message: str, current_plan: str, upgrade_url: str):
        super().__init__(message, status_code=402)
        self.current_plan = current_plan
        self.upgrade_url = upgrade_url


class RateLimitError(AIResponseOpsError):
    """Rate limit exceeded (429)."""

    def __init__(self, message: str, retry_after_seconds: int):
        super().__init__(message, status_code=429)
        self.retry_after_seconds = retry_after_seconds


class ValidationError(AIResponseOpsError):
    """Invalid request (400)."""


class ServerError(AIResponseOpsError):
    """Internal server error (500)."""


class AIServiceError(AIResponseOpsError):
    """AI provider error (502)."""


_ERROR_MAP = {
    401: AuthenticationError,
    402: PlanGateError,
    429: RateLimitError,
    400: ValidationError,
    500: ServerError,
    502: AIServiceError,
}


class AIResponseOps:
    """Client for the AI Response Ops Public API.

    Usage:
        client = AIResponseOps(api_key="your-api-key")
        result = client.process([
            {"question": "Do you support SSO?", "id": "q1"},
            {"question": "How often do you run pen tests?"},
        ])
        print(result.results[0].answer)
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 0,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: Optional[httpx.Client] = None

    @property
    def api_key(self) -> Optional[str]:
        return self._api_key

    @api_key.setter
    def api_key(self, value: str):
        self._api_key = value

    def _get_client(self) -> httpx.Client:
        if self._client is None:
            self._client = httpx.Client(
                base_url=self._base_url,
                timeout=self._timeout,
                headers={"User-Agent": f"ai-response-ops-python/1.0.0"},
            )
        return self._client

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        require_auth: bool = False,
    ) -> httpx.Response:
        client = self._get_client()
        headers = {}

        if require_auth:
            if not self._api_key:
                raise AuthenticationError(
                    "API key is required. Set client.api_key or pass api_key to constructor.",
                    status_code=401,
                )
            headers["X-API-Key"] = self._api_key

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = client.request(method, path, json=json, headers=headers)
                break
            except httpx.TimeoutException as e:
                last_error = AIResponseOpsError(f"Request timed out: {e}")
                if attempt < self._max_retries:
                    time.sleep(min(2**attempt, 30))
                    continue
                raise last_error
            except httpx.RequestError as e:
                last_error = AIResponseOpsError(f"Network error: {e}")
                if attempt < self._max_retries:
                    time.sleep(min(2**attempt, 30))
                    continue
                raise last_error

        if response.status_code < 400:
            return response

        error_cls = _ERROR_MAP.get(response.status_code, AIResponseOpsError)
        try:
            body = response.json()
            msg = body.get("error", response.text)
        except Exception:
            msg = response.text

        if response.status_code == 402:
            raise PlanGateError(
                msg,
                current_plan=body.get("current_plan", "unknown"),
                upgrade_url=body.get("upgrade_url", ""),
            )
        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 3600))
            raise RateLimitError(msg, retry_after_seconds=retry_after)

        raise error_cls(msg, status_code=response.status_code)

    def health(self) -> HealthResponse:
        """Check API health and version."""
        resp = self._request("GET", "/health")
        return HealthResponse(**resp.json())

    def process(
        self,
        questions: Union[list[str], list[dict], list[Question]],
    ) -> ProcessResponse:
        """Process up to 100 security questions and return AI-generated answers.

        Args:
            questions: List of questions. Each can be:
                - A plain string: "Do you support SSO?"
                - A dict: {"question": "Do you support SSO?", "id": "q1"}
                - A Question object

        Returns:
            ProcessResponse with results, match counts, and metadata.

        Raises:
            AuthenticationError: Invalid or missing API key (401)
            PlanGateError: Workspace plan doesn't include API access (402)
            RateLimitError: Too many requests (429)
            ValidationError: Malformed request (400)
            ServerError: Internal error (500)
            AIServiceError: DeepSeek/OpenRouter failure (502)
        """
        if not questions:
            raise ValidationError("At least one question is required.")

        if len(questions) > 100:
            raise ValidationError(f"Maximum 100 questions per request, got {len(questions)}.")

        normalized = []
        for i, q in enumerate(questions):
            if isinstance(q, str):
                normalized.append({"question": q})
            elif isinstance(q, Question):
                normalized.append(q.model_dump(exclude_none=True))
            elif isinstance(q, dict):
                if "question" not in q:
                    raise ValidationError(f"Question at index {i} missing 'question' field.")
                normalized.append({"question": q["question"], "id": q.get("id")})
            else:
                raise ValidationError(
                    f"Question at index {i} must be str, dict, or Question, got {type(q).__name__}."
                )

        resp = self._request("POST", "/api/v1/process", json={"questions": normalized}, require_auth=True)
        return ProcessResponse(**resp.json())

    def close(self):
        """Close the underlying HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()


class AsyncAIResponseOps:
    """Async client for the AI Response Ops Public API.

    Usage:
        async with AsyncAIResponseOps(api_key="your-api-key") as client:
            result = await client.process([
                {"question": "Do you support SSO?"},
            ])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = 0,
    ):
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._client: Optional[httpx.AsyncClient] = None

    @property
    def api_key(self) -> Optional[str]:
        return self._api_key

    @api_key.setter
    def api_key(self, value: str):
        self._api_key = value

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=self._timeout,
                headers={"User-Agent": f"ai-response-ops-python/1.0.0"},
            )
        return self._client

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        require_auth: bool = False,
    ) -> httpx.Response:
        client = self._get_client()
        headers = {}

        if require_auth:
            if not self._api_key:
                raise AuthenticationError(
                    "API key is required. Set client.api_key or pass api_key to constructor.",
                    status_code=401,
                )
            headers["X-API-Key"] = self._api_key

        last_error: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await client.request(method, path, json=json, headers=headers)
                break
            except httpx.TimeoutException as e:
                last_error = AIResponseOpsError(f"Request timed out: {e}")
                if attempt < self._max_retries:
                    await _asleep(min(2**attempt, 30))
                    continue
                raise last_error
            except httpx.RequestError as e:
                last_error = AIResponseOpsError(f"Network error: {e}")
                if attempt < self._max_retries:
                    await _asleep(min(2**attempt, 30))
                    continue
                raise last_error

        if response.status_code < 400:
            return response

        error_cls = _ERROR_MAP.get(response.status_code, AIResponseOpsError)
        try:
            body = response.json()
            msg = body.get("error", response.text)
        except Exception:
            msg = response.text

        if response.status_code == 402:
            raise PlanGateError(
                msg,
                current_plan=body.get("current_plan", "unknown"),
                upgrade_url=body.get("upgrade_url", ""),
            )
        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 3600))
            raise RateLimitError(msg, retry_after_seconds=retry_after)

        raise error_cls(msg, status_code=response.status_code)

    async def health(self) -> HealthResponse:
        resp = await self._request("GET", "/health")
        return HealthResponse(**resp.json())

    async def process(
        self,
        questions: Union[list[str], list[dict], list[Question]],
    ) -> ProcessResponse:
        if not questions:
            raise ValidationError("At least one question is required.")

        if len(questions) > 100:
            raise ValidationError(f"Maximum 100 questions per request, got {len(questions)}.")

        normalized = []
        for i, q in enumerate(questions):
            if isinstance(q, str):
                normalized.append({"question": q})
            elif isinstance(q, Question):
                normalized.append(q.model_dump(exclude_none=True))
            elif isinstance(q, dict):
                if "question" not in q:
                    raise ValidationError(f"Question at index {i} missing 'question' field.")
                normalized.append({"question": q["question"], "id": q.get("id")})
            else:
                raise ValidationError(
                    f"Question at index {i} must be str, dict, or Question, got {type(q).__name__}."
                )

        resp = await self._request("POST", "/api/v1/process", json={"questions": normalized}, require_auth=True)
        return ProcessResponse(**resp.json())

    async def close(self):
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()


async def _asleep(seconds: float):
    import asyncio
    await asyncio.sleep(seconds)
