from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field


class Question(BaseModel):
    """A question to process."""
    question: str = Field(..., max_length=2000)
    id: Optional[str] = None


class AnswerResult(BaseModel):
    """A single answer result."""
    question: str
    id: Optional[str] = None
    answer: str
    confidence: int = Field(..., ge=0, le=100)
    source: str


class ProcessResponse(BaseModel):
    """Response from the /process endpoint."""
    success: bool
    count: int
    kb_matched: int
    ai_generated: int
    results: list[AnswerResult]


class HealthResponse(BaseModel):
    """Response from the /health endpoint."""
    status: str
    version: str
    timestamp: str
