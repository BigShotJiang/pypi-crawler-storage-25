"""Basic tests for AI Response Ops Python SDK."""

import pytest
from ai_response_ops import AIResponseOps, AsyncAIResponseOps
from ai_response_ops.types import Question, AnswerResult, ProcessResponse, HealthResponse


class TestQuestion:
    def test_question_from_string(self):
        q = Question(question="Do you support SSO?")
        assert q.question == "Do you support SSO?"
        assert q.id is None

    def test_question_with_id(self):
        q = Question(question="Do you support SSO?", id="q1")
        assert q.id == "q1"

    def test_question_max_length(self):
        with pytest.raises(Exception):
            Question(question="x" * 2001)

    def test_question_model_dump(self):
        q = Question(question="Test", id="abc")
        d = q.model_dump(exclude_none=True)
        assert d == {"question": "Test", "id": "abc"}


class TestAnswerResult:
    def test_answer_result_fields(self):
        r = AnswerResult(
            question="Test Q",
            id="q1",
            answer="Test A",
            confidence=85,
            source="kb",
        )
        assert r.confidence == 85
        assert r.source == "kb"


class TestProcessResponse:
    def test_process_response(self):
        r = ProcessResponse(
            success=True,
            count=5,
            kb_matched=3,
            ai_generated=2,
            results=[
                AnswerResult(question="Q1", answer="A1", confidence=90, source="kb"),
                AnswerResult(question="Q2", answer="A2", confidence=70, source="ai_generated"),
            ],
        )
        assert r.success is True
        assert r.count == 5
        assert len(r.results) == 2


class TestHealthResponse:
    def test_health_response(self):
        h = HealthResponse(status="ok", version="1.0.0", timestamp="2026-01-01T00:00:00Z")
        assert h.status == "ok"
        assert h.version == "1.0.0"


class TestClientInit:
    def test_default_base_url(self):
        client = AIResponseOps(api_key="test-key")
        assert client.api_key == "test-key"
        client.close()

    def test_custom_base_url(self):
        client = AIResponseOps(api_key="test-key", base_url="https://custom.example.com/api")
        client.close()

    def test_timeout_config(self):
        client = AIResponseOps(api_key="test-key", timeout=30.0, max_retries=3)
        client.close()

    def test_no_api_key(self):
        client = AIResponseOps()
        assert client.api_key is None
        client.close()

    def test_api_key_setter(self):
        client = AIResponseOps()
        client.api_key = "new-key"
        assert client.api_key == "new-key"
        client.close()


class TestAsyncClientInit:
    @pytest.mark.asyncio
    async def test_default_init(self):
        client = AsyncAIResponseOps(api_key="test-key")
        assert client.api_key == "test-key"
        await client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager_creates_client(self):
        async with AsyncAIResponseOps(api_key="test-key") as client:
            assert client.api_key == "test-key"


class TestClientValidation:
    def test_process_empty_questions(self):
        client = AIResponseOps(api_key="test-key")
        from ai_response_ops.client import ValidationError
        with pytest.raises(ValidationError, match="At least one question"):
            client.process([])
        client.close()

    def test_process_too_many_questions(self):
        client = AIResponseOps(api_key="test-key")
        from ai_response_ops.client import ValidationError
        with pytest.raises(ValidationError, match="Maximum 100"):
            client.process(["Q"] * 101)
        client.close()

    def test_process_invalid_question_type(self):
        client = AIResponseOps(api_key="test-key")
        from ai_response_ops.client import ValidationError
        with pytest.raises(ValidationError, match="must be str, dict, or Question"):
            client.process([123])  # type: ignore
        client.close()
