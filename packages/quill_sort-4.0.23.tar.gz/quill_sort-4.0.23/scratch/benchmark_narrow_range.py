import os
import random
import sys
import time
from contextlib import contextmanager
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from statistics import mean

import numpy as np

# Ensure benchmarks run against local workspace package, not site-packages.
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from quill import quill_sort
import quill._external as ext


SEED = 20260331
random.seed(SEED)
np.random.seed(SEED)

N = 1_500_000
RANGE_MAX = 50_000
WIDE_N = 600_000
WIDE_MAX = 1_000_000_000


def is_sorted(values):
    return all(values[i] <= values[i + 1] for i in range(len(values) - 1))


@contextmanager
def patched_available_ram(bytes_value):
    old_avail = ext.get_available_ram
    old_total = ext.get_total_ram
    ext.get_available_ram = lambda: int(bytes_value)
    ext.get_total_ram = lambda: max(int(bytes_value) * 2, int(bytes_value) + 1)
    try:
        yield
    finally:
        ext.get_available_ram = old_avail
        ext.get_total_ram = old_total


def current_quill_external_forced(data):
    with patched_available_ram(8 * 1024 * 1024):
        quill_sort(data, parallel=True, high_performance_mode=True, silent=True)


def current_quill_parallel_inmem(data):
    with patched_available_ram(8 * 1024**3):
        quill_sort(data, parallel=True, high_performance_mode=True, silent=True)


def current_quill_sequential_inmem(data):
    with patched_available_ram(8 * 1024**3):
        quill_sort(data, parallel=False, high_performance_mode=True, silent=True)


def proto_seq_counting_numpy(data):
    arr = np.array(data, dtype=np.int64)
    mn = int(arr.min())
    mx = int(arr.max())
    counts = np.bincount((arr - mn).astype(np.intp), minlength=(mx - mn + 1))
    out = np.repeat(np.arange(mn, mx + 1, dtype=np.int64), counts)
    data[:] = out.tolist()


def proto_threaded_multi_counter(data):
    arr = np.array(data, dtype=np.int64)
    mn = int(arr.min())
    mx = int(arr.max())
    rng = mx - mn + 1
    n = len(arr)

    workers = min(28, os.cpu_count() or 4)
    stripe = (n + workers - 1) // workers
    spans = [
        (i * stripe, min((i + 1) * stripe, n))
        for i in range(workers)
        if i * stripe < n
    ]

    def worker(span):
        start, end = span
        return np.bincount((arr[start:end] - mn).astype(np.intp), minlength=rng)

    with ThreadPoolExecutor(max_workers=len(spans)) as pool:
        local_counts = list(pool.map(worker, spans))

    counts = np.sum(local_counts, axis=0, dtype=np.int64)
    out = np.repeat(np.arange(mn, mx + 1, dtype=np.int64), counts)
    data[:] = out.tolist()


def bench(label, fn, base, rounds=3):
    times = []
    for _ in range(rounds):
        data = list(base)
        t0 = time.perf_counter()
        try:
            fn(data)
        except MemoryError:
            print(f"{label}: skipped (MemoryError)")
            return
        except Exception as exc:
            print(f"{label}: failed ({type(exc).__name__}: {exc})")
            return
        elapsed = time.perf_counter() - t0
        assert is_sorted(data), f"sort failed: {label}"
        times.append(elapsed)
    print(f"{label}: times={[round(t, 4) for t in times]} avg={mean(times):.4f}s")


def main():
    print(f"quill module: {__import__('quill').__file__}")

    # Smoke checks across core paths.
    smoke = [5, 1, 4, 2, 3]
    quill_sort(smoke)
    assert smoke == [1, 2, 3, 4, 5]
    smoke = [0, -5, 2, -1, 2, -5]
    quill_sort(smoke, parallel=True, high_performance_mode=True, silent=True)
    assert smoke == sorted([0, -5, 2, -1, 2, -5])

    # Ensure wide-range + low-RAM still uses valid non-short-circuit path.
    smoke_wide = [random.randint(0, 1_000_000_000) for _ in range(120_000)]
    with patched_available_ram(4 * 1024 * 1024):
        quill_sort(smoke_wide, parallel=True, high_performance_mode=True, silent=True)
    assert is_sorted(smoke_wide)

    base_narrow = [random.randint(0, RANGE_MAX) for _ in range(N)]
    print(f"NARROW DATASET: N={N:,}, range=[0,{RANGE_MAX}]")
    bench("current_external_forced", current_quill_external_forced, base_narrow, rounds=3)
    bench("current_parallel_inmem", current_quill_parallel_inmem, base_narrow, rounds=3)
    bench("current_sequential_inmem", current_quill_sequential_inmem, base_narrow, rounds=3)
    bench("proto_seq_counting_numpy", proto_seq_counting_numpy, base_narrow, rounds=3)
    bench("proto_threaded_multi_counter", proto_threaded_multi_counter, base_narrow, rounds=3)

    base_wide = [random.randint(0, WIDE_MAX) for _ in range(WIDE_N)]
    print(f"\nWIDE DATASET: N={WIDE_N:,}, range=[0,{WIDE_MAX}]")
    bench("wide_current_parallel_inmem", current_quill_parallel_inmem, base_wide, rounds=2)
    bench("wide_proto_threaded_multi_counter", proto_threaded_multi_counter, base_wide, rounds=2)


if __name__ == "__main__":
    main()
