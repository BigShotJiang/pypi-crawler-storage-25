"""Morphological feature vocabulary (UniMorph tag set)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import TypedDict

import torch

FEATURE_PAD = 0
FEATURE_SPECIAL = ["<pad>"]


class FeatureVocabState(TypedDict):
    stoi: dict[str, int]
    itos: list[str]


@dataclass
class FeatureVocab:
    stoi: dict[str, int]
    itos: list[str]

    @property
    def size(self) -> int:
        return len(self.itos)

    @classmethod
    def from_tags(cls, all_tags: list[list[str]]) -> FeatureVocab:
        unique_tags = sorted({tag for tags in all_tags for tag in tags})
        itos = FEATURE_SPECIAL + unique_tags
        stoi = {tag: idx for idx, tag in enumerate(itos)}
        return cls(stoi=stoi, itos=itos)

    def encode(
        self, tags: list[str], *, max_features: int,
    ) -> tuple[list[int], list[float]]:
        """Encode *tags* into padded ``(feature_ids, feature_mask)`` lists of length *max_features*."""
        ids = [self.stoi[tag] for tag in tags if tag in self.stoi]
        ids = ids[:max_features]
        mask = [1.0] * len(ids)
        padding_length = max_features - len(ids)
        if padding_length > 0:
            ids.extend([FEATURE_PAD] * padding_length)
            mask.extend([0.0] * padding_length)
        return ids, mask

    def encode_tensor(
        self, tags: list[str], *, max_features: int, device: torch.device | None = None,
    ) -> tuple[torch.Tensor, torch.Tensor]:
        ids, mask = self.encode(tags, max_features=max_features)
        ids_tensor = torch.tensor(ids, dtype=torch.long)
        mask_tensor = torch.tensor(mask, dtype=torch.float)
        if device is not None:
            ids_tensor = ids_tensor.to(device)
            mask_tensor = mask_tensor.to(device)
        return ids_tensor, mask_tensor

    def to_dict(self) -> FeatureVocabState:
        return {"stoi": self.stoi, "itos": self.itos}

    @classmethod
    def from_dict(cls, data: FeatureVocabState) -> FeatureVocab:
        return cls(stoi=data["stoi"], itos=data["itos"])
