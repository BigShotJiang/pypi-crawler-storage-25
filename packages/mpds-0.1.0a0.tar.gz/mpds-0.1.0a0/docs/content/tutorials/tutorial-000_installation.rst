Installation
============

.. code-block:: shell

  python3 -m pip install 'mpds @ git+https://github.com/robotodo-platform/mpds-python.git'