MPDS Specification Version 1
============================

TODO