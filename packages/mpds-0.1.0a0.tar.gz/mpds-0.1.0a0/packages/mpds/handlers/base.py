# SPDX-License-Identifier: Apache-2.0

import abc
from typing import TypeVar, Generic

import av
import av.stream
import av.container
import av.frame


class UnsupportedType:
    pass


Unsupported = UnsupportedType()


MaybeAVFrame = av.Packet | av.AudioFrame | av.VideoFrame


_DataT = TypeVar("_DataT")
class ProtoHandler(Generic[_DataT], abc.ABC):
    # TODO
    supported_data_types: list[str]

    # TODO use this instead
    # @abc.abstractmethod
    # def initialize_container(
    #     self,
    #     data_type: str,
    #     container: av.container.Container | None = None,
    # ):
    #     raise NotImplementedError
    #     ...

    # TODO rm
    @abc.abstractmethod
    def resolve_codec(
        self, 
        data_type: str,
        container: av.container.Container | None = None,
        compression: float | None = None,
    ) -> tuple[str | None, dict] | UnsupportedType:
        ...

    # TODO skip encoding if already av.Packet??
    @abc.abstractmethod
    def save(self, data: _DataT, data_type: str) -> MaybeAVFrame | UnsupportedType:
        ...

    @abc.abstractmethod
    def load(self, data_encoded: MaybeAVFrame, data_type: str) -> _DataT | UnsupportedType:
        ...

    # TODO 
    # @abc.abstractmethod
    # def save_many(self, data: _DataT, data_type: str) -> list[MaybeAVFrame] | UnsupportedType:
    #     ...

    # @abc.abstractmethod
    # def load_many(self, data_encoded: list[MaybeAVFrame], data_type: str) -> _DataT | UnsupportedType:
    #     ...

