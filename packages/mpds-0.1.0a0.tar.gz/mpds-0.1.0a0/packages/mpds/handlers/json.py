# SPDX-License-Identifier: Apache-2.0

import json
import warnings
import collections

# TODO
import av
import av.container
import numpy
import mimeparse
from mpds.handlers.base import Unsupported, UnsupportedType, ProtoHandler


class JSONHandler(ProtoHandler):
    # TODO
    supported_data_types = [
        "application/json",
    ]

    def resolve_codec(self, **_):
        return None, {}
    
    def save(self, data, data_type):
        # TODO match mime
        return av.Packet(json.dumps(data, ensure_ascii=False).encode("utf-8"))
    
    def load(self, data_encoded, data_type):
        # TODO match mime
        return json.loads(bytes(data_encoded).decode("utf-8"))
    
    def save_many(self, data, data_type):
        result = []
        for item in data:
            item_encoded = self.save(item, data_type=data_type)
            match item_encoded:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item_encoded)
        return result

    def load_many(self, data_encoded, data_type):
        result = []
        for item_encoded in data_encoded:
            item = self.load(item_encoded, data_type=data_type)
            match item:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item)
        return result
