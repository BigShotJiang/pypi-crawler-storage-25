# SPDX-License-Identifier: Apache-2.0

import io
import json
import warnings
import collections

# TODO
import av
import av.container
import mimeparse
import numpy
from mpds.handlers.base import Unsupported, UnsupportedType, ProtoHandler


class TensorHandler(ProtoHandler):
    # TODO
    supported_data_types = [
        "application/x-npy",
    ]

    def resolve_codec(self, **_):
        return None, {}

    def save(self, data: ..., data_type: str):
        buffer = io.BytesIO()
        numpy.save(buffer, data)
        return av.Packet(buffer.getbuffer())
    
    def load(self, data_encoded: av.Packet, data_type: str):
        match mimeparse.parse_mime_type(data_type):
            case "application", "x-npy", params:
                match params.get("homogeneous"):
                    case "true":
                        ...
        buffer = io.BytesIO(memoryview(data_encoded))
        return numpy.load(buffer)
    
    def save_many(self, data, data_type):
        result = []
        for item in data:
            item_encoded = self.save(item, data_type=data_type)
            match item_encoded:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item_encoded)
        return result

    def load_many(self, data_encoded, data_type):
        result = []
        for item_encoded in data_encoded:
            item = self.load(item_encoded, data_type=data_type)
            match item:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item)
        return result