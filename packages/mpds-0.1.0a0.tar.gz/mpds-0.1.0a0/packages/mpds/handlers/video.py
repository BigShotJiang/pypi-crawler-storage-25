# SPDX-License-Identifier: Apache-2.0

import warnings
from typing import Literal

# TODO
import av
import av.container
import PIL.Image
import numpy
import mimeparse
from mpds.handlers.base import Unsupported, UnsupportedType, ProtoHandler


class Image:
    __slots__ = ["_av_frame"]

    def __init__(self, _av_frame: av.VideoFrame):
        self._av_frame = _av_frame

    def __array__(self, dtype=None, copy=None):
        return numpy.array(
            self._av_frame.to_ndarray(format="rgb24", channel_last=True),
            dtype=dtype,
            copy=copy if copy is not None else True,
        )


class VideoHandler(ProtoHandler):
    # TODO
    supported_data_types = [
        "video/*",
        # "image/*",
    ]

    # TODO
    def resolve_codec(
        self, 
        data_type: str, 
        container: av.container.Container | None = None,
        compression: float | None = None,
    ):
        codec_name = None
        codec_options = dict()

        match mimeparse.parse_mime_type(data_type):
            case "video", "*" | "" | None, _:
                match container:
                    case av.container.OutputContainer():
                        codec_name = container.default_video_codec
                    case _:
                        # TODO warn
                        warnings.warn(
                            f"{self}: refusing to handle generic video type {data_type!r} "
                            f"due to unsupported container passed: {container}"
                        )
                        # TODO
                        return UnsupportedType()
            case "video", "h264", _:
                codec_name = "h264"
            case "video", "h265", _:
                codec_name = "hevc"
            case "video", "ffv1", _:
                codec_name = "ffv1"
            case unknown:
                raise NotImplementedError(f"TODO {data_type}: {unknown}")
        
        modes = set[Literal["r", "w"]]()
        if container is not None:
            if container.format.is_input:
                modes.add("r")
            if container.format.is_output:
                modes.add("w")
        else:
            modes = set(["r", "w"])

        for mode in modes:
            codec = av.Codec(codec_name, mode=mode)
            if codec.id == av.Codec(name="h264", mode=mode).id:
                if compression is not None:
                    codec_options["crf"] = str(int(compression * 51))
            if codec.id == av.Codec(name="hevc", mode=mode).id:
                if compression is not None:
                    codec_options["crf"] = str(int(compression * 51))

        return codec_name, codec_options

    def save(self, data, data_type):
        frame = Unsupported
        match data:
            case PIL.Image.Image() as image:
                # TODO FIXME pyav round-trips to rgb
                frame = av.VideoFrame.from_image(image)
            case _:
                # TODO
                tensor = numpy.asarray(data)
                *_n, _height, _width, n_channels = tensor.shape
                match n_channels, tensor.dtype:
                    case 1, numpy.uint8:
                        frame = av.VideoFrame.from_ndarray(
                            data, 
                            format="gray8",
                            channel_last=True,
                        )
                    case 3, numpy.uint8:
                        frame = av.VideoFrame.from_ndarray(
                            data, 
                            format="rgb24",
                            channel_last=True,
                        )
                    case _:
                        raise NotImplementedError(
                            f"Failed to infer pixel format from image tensor, "
                            f"check shape ({tensor.shape}) and dtype ({tensor.dtype}): {tensor}"
                        )
        return frame
    
    def load(self, data_encoded: av.VideoFrame, data_type: str):
        # return Image(_av_frame=data_encoded)
        # #
        return data_encoded.to_ndarray(format="rgb24", channel_last=True)
        # # TODO FIXME perf: this is very slow
        # # TODO FIXME pyav round-trips to rgb
        # return data_encoded.to_image()
    
    def save_many(self, data, data_type):
        result = []
        for item in data:
            item_encoded = self.save(item, data_type=data_type)
            match item_encoded:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item_encoded)
        return result

    def load_many(self, data_encoded, data_type):
        result = []
        for item_encoded in data_encoded:
            item = self.load(item_encoded, data_type=data_type)
            match item:
                case UnsupportedType():
                    return Unsupported
                case _:
                    result.append(item)
        return result