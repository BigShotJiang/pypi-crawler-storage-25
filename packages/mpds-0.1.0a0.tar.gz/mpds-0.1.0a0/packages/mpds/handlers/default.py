# SPDX-License-Identifier: Apache-2.0

import functools
from typing import Iterable

import av
import av.container
import mimeparse
from mpds.handlers.base import Unsupported, UnsupportedType, ProtoHandler
from mpds.handlers.json import JSONHandler
from mpds.handlers.tensor import TensorHandler
from mpds.handlers.video import VideoHandler


class Handler(ProtoHandler):
    supported_data_types = [
        "*/*"
    ]

    def __init__(self, handlers: Iterable[ProtoHandler] | None = None):
        if handlers is None:
            handlers = list()
        self._handlers = tuple(handlers)

    def add_handler(self, handler: ProtoHandler):
        self._handlers = (*self._handlers, handler)

    @functools.cache
    def _resolve_handlers(self, data_type: str, handlers: tuple[ProtoHandler, ...]):
        handler_fitnesses = list[tuple[ProtoHandler, float]]()
        for handler in handlers:
            fitness, _ = mimeparse.quality_and_fitness_parsed(data_type, [
                mimeparse.parse_media_range(supported_data_type)
                for supported_data_type in handler.supported_data_types
            ])
            if fitness <= 0.:
                continue
            handler_fitnesses.append((handler, fitness))
            
        def _key_func(x): 
            _, fitness = x
            return fitness
        return sorted(handler_fitnesses, key=_key_func, reverse=True)
    
    def resolve_codec(
        self, 
        data_type: str, 
        container: av.container.OutputContainer | None = None,
        compression: float | None = None,
    ):
        result = Unsupported
        for handler, _ in self._resolve_handlers(
            data_type, 
            handlers=self._handlers,
        ):
            result = handler.resolve_codec(
                data_type=data_type,
                container=container,
                compression=compression,
            )
            match result:
                case UnsupportedType():
                    continue
                case _:
                    return result
        return result

    def save(self, data, data_type):
        result = Unsupported
        for handler, _ in self._resolve_handlers(
            data_type, 
            handlers=self._handlers,
        ):
            result = handler.save(data, data_type=data_type)
            match result:
                case UnsupportedType():
                    continue
                case _:
                    return result
        return result
    
    def load(self, data_encoded, data_type):
        result = Unsupported
        for handler, _ in self._resolve_handlers(
            data_type, 
            handlers=self._handlers,
        ):
            result = handler.load(data_encoded, data_type=data_type)
            match result:
                case UnsupportedType():
                    continue
                case _:
                    return result
        return result

    # TODO    
    # def save_many(self, data, data_type):
    #     result = Unsupported
    #     for handler, _ in self._resolve_handlers(
    #         data_type, 
    #         handlers=self._handlers,
    #     ):
    #         result = handler.save_many(data, data_type=data_type)
    #         match result:
    #             case UnsupportedType():
    #                 continue
    #             case _:
    #                 return result
    #     return result
    
    # def load_many(self, data_encoded, data_type):
    #     result = Unsupported
    #     for handler, _ in self._resolve_handlers(
    #         data_type, 
    #         handlers=self._handlers,
    #     ):
    #         result = handler.load_many(data_encoded, data_type=data_type)
    #         match result:
    #             case UnsupportedType():
    #                 continue
    #             case _:
    #                 return result
    #     return result
        

handler = Handler([
    JSONHandler(),
    TensorHandler(),
    VideoHandler(),
])
