# SPDX-License-Identifier: Apache-2.0

import io
import dataclasses
import fractions

from mpds.benchmarks import _requirements
with _requirements.check_imports():
    import numpy
    import prefixed
    from mpds.device import mp_use_device, mp_devices_available
    from mpds.dataset import MPDataset
    from mpds.benchmarks.utils import BenchmarkTimer


@dataclasses.dataclass
class BenchmarkConfig:
    num_frames: int = 1_000
    time_base: fractions.Fraction = fractions.Fraction(1, 30)
    image_type: str = "video/ffv1"
    image_resolution: tuple[int, int] = (224, 224)
    compression: float | None = None


@dataclasses.dataclass
class BenchmarkResult:
    timer: BenchmarkTimer
    usage_buf_nbytes: int

    def describe(self) -> str:
        with io.StringIO() as output:
            print(f"- storage: {prefixed.Float(self.usage_buf_nbytes):.2h}bytes", file=output)
            print(f"- timing:", file=output)
            for line in self.timer.describe():
                print(f"  - {line}", file=output)
            return output.getvalue()


def benchmark(config: BenchmarkConfig = BenchmarkConfig()):
    benchmark_timer = BenchmarkTimer()

    buffer = io.BytesIO()

    with MPDataset.create(
        buffer,
        metadata={
            "features": {
                "sample_image": {
                    "type": config.image_type,
                },
                "sample_json": {
                    "type": "application/json",
                },
                "sample_tensor": {
                    "type": "application/x-npy",
                }
            }
        },
        time_base=config.time_base,
        compression=config.compression,
    ) as dataset:
        for time_s in range(config.num_frames):
            noise = numpy.asarray(
                numpy.random.randint(0, 255, size=(*config.image_resolution, 3)), 
                dtype=numpy.uint8,
            )

            with benchmark_timer.mark("mpds/write_seq/per_frame"):
                dataset.add(
                    time=config.time_base * time_s,
                    data={
                        "sample_image": noise,
                        "sample_json": {"count": time_s},
                        "sample_tensor": time_s,
                    }, 
                )

    with MPDataset.open(buffer) as dataset:
        with benchmark_timer.mark("mpds/read_seq/oneshot"):
            dataset.get(time=0.)

        # TODO
        dataset.cache.enabled = True
        for time in numpy.linspace(0., float(dataset.duration or 0)):
            with benchmark_timer.mark("mpds/read_seq/per_window_10s"):
                # lookahead 100s
                dataset.cache.fetch(time=time, duration=100)
                dataset.get(time=time, duration=10.)

        iter_items = dataset.items(time=0.)
        while True:
            try: 
                with benchmark_timer.mark("mpds/read_seq/per_frame"):
                    next(iter_items)
            except StopIteration:
                break

    return BenchmarkResult(
        timer=benchmark_timer,
        usage_buf_nbytes=buffer.getbuffer().nbytes,
    )


def benchmark_cli():
    for device in mp_devices_available():
        print(f"device: {device}")
        with mp_use_device(device):
            configs = [
                BenchmarkConfig(
                    image_type="video/h264",
                    image_resolution=(224, 224),
                    # compression=0.,
                ),
                BenchmarkConfig(
                    image_type="video/h265",
                    image_resolution=(224, 224),
                    # compression=0.,
                ),
                BenchmarkConfig(
                    image_type="video/ffv1",
                    image_resolution=(224, 224),
                    # compression=0.,
                ),                
            ]

            for config in configs:
                print(f"benchmarking: {config}")
                benchmark_results = benchmark(config=config)
                print(benchmark_results.describe())


if __name__ == "__main__":
    benchmark_cli()