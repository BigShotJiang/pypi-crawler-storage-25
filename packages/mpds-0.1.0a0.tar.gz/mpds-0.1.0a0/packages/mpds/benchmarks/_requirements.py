# SPDX-License-Identifier: Apache-2.0

import sys
import contextlib


@contextlib.contextmanager
def check_imports():
    try:
        yield
    except ImportError as error:
        raise RuntimeError(
            f"Missing required dependencies for benchmarks. "
            f"Run `{sys.executable} -m pip install mpds[benchmark]`"
        ) from error
