# SPDX-License-Identifier: Apache-2.0

import contextlib
import collections
import time
import statistics
from typing import Hashable

from mpds.benchmarks import _requirements
with _requirements.check_imports():
    import prefixed


class BenchmarkTimer:
    def __init__(self):
        self._timings = collections.defaultdict[Hashable, list[float]](list)

    @contextlib.contextmanager
    def mark(self, name: Hashable):
        start_time = time.perf_counter()
        yield
        self._timings[name].append(
            time.perf_counter() - start_time
        )
        
    def describe(self, name: Hashable | None = None):
        names = []
        match name:
            case None:
                names = self._timings.keys()            
            case str():
                names = [name]
            case _:
                names = iter(name)

        results = []
        for name in names:
            timings = self._timings[name]

            count = len(timings)
            mean = statistics.mean(timings)
            stddev = statistics.stdev(timings) if len(timings) >= 2 else 0
            total = sum(timings)

            results.append(
                f"{name}: "
                f"{prefixed.Float(mean):.2h}s ± {prefixed.Float(stddev):.2h}s per iteration "
                f"(mean ± std. dev. of {count} iterations, totaling {prefixed.Float(total):.2h}s)"
            )

        return results
    