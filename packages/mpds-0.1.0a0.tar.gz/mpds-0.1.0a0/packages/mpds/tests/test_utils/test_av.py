# SPDX-License-Identifier: Apache-2.0

import io

import av
import numpy
from mpds.utils.av import av_compute_num_reordering_frames


def test_av_compute_num_reordering_frames():
    buffer = io.BytesIO()
    container = av.open(buffer, format="mp4", mode="w")
    stream = container.add_stream("libx265", options={
        "x265-params": (
            "keyint=60:"
            "min-keyint=60:"
            "scenecut=0:"
            "bframes=16:"
            "b-adapt=0:"
        )
    })
    stream.width = 480
    stream.height = 320
    for _ in range(100):
        frame = av.VideoFrame.from_ndarray(numpy.empty((stream.height, stream.width, 3), dtype=numpy.uint8), format="rgb24")
        for packet in stream.encode(frame):
            container.mux(packet)
    for packet in stream.encode():
        container.mux(packet)
    container.close()

    buffer.seek(0)
    container = av.open(buffer, mode="r")
    # TODO
    # assert av_compute_num_reordering_frames(container.streams[0]) >= 16
    assert av_compute_num_reordering_frames(container.streams[0]) > 0