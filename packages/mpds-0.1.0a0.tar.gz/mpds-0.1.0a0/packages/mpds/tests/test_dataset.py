# SPDX-License-Identifier: Apache-2.0

import io
import random
import fractions

import numpy
from mpds.dataset import MPDataset


class TestMPDataset:
    def test_todo(self):
        buffer = io.BytesIO()

        # TODO
        time_base = fractions.Fraction(1, 10)
        times_s = list(range(10))

        with MPDataset.create(
            buffer,
            metadata={
                "features": {
                    "sample_image": {
                        "type": "video/ffv1",
                    },
                    "sample_json": {
                        "type": "application/json",
                    },
                    "sample_tensor": {
                        "type": "application/x-npy",
                    }
                }
            },
            time_base=time_base,
        ) as dataset:
            items = list()

            for time_s in sorted(times_s):
                items.append((
                    time_s,
                    {
                        "sample_image": numpy.full((2, 2, 3), time_s % 255, dtype=numpy.uint8),
                        "sample_json": {"count": time_s},
                        "sample_tensor": time_s,
                    }, 
                ))

                use_partial_data = True
                if use_partial_data:
                    items.append((
                        time_s + .5,
                        {
                            "sample_image": numpy.full((2, 2, 3), time_s % 255, dtype=numpy.uint8),
                        }, 
                    ))

            for time, data in items:
                dataset.add(
                    time=time,
                    data=data, 
                )

            # TODO
            # assert min(dataset.time_bases.values()) == time_base

        with MPDataset.open(buffer) as dataset:
            assert min(dataset.time_bases.values()) == time_base
            # TODO
            # for _, time_base_actual in dataset.time_bases.items():
            #     assert time_base == time_base_actual

            for _ in range(1_000):
                random.shuffle(times_s)

                for time_s in times_s:
                    # TODO randomize durations
                    time, data = dataset.get(time=time_s, duration=.5)

                    assert time["sample_image"] == [time_s]
                    assert time["sample_json"] == [time_s]
                    assert time["sample_tensor"] == [time_s]

                    [image_data] = data["sample_image"]
                    [json_data] = data["sample_json"]
                    [tensor_data] = data["sample_tensor"]

                    numpy.testing.assert_allclose(
                        actual=numpy.asarray(image_data),
                        desired=time_s % 255,
                    )

                    numpy.testing.assert_equal(
                        actual=json_data["count"],
                        desired=time_s,
                    )

                    numpy.testing.assert_equal(
                        actual=tensor_data,
                        desired=time_s,
                    )

            # TODO random duration
            data_times, _ = dataset.get(time=time_s, duration=2)
            assert data_times["sample_image"] == sorted(data_times["sample_image"])

            # TODO
            numpy.testing.assert_equal(
                actual=list(dataset.items(time=0.)),
                desired=items,
            )
