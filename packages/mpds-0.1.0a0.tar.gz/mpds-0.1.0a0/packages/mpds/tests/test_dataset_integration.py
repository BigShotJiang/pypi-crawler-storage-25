# SPDX-License-Identifier: Apache-2.0

import gc
import weakref 
import io
import collections
import dataclasses
import fractions
from typing import Generic, Literal, NamedTuple

import pytest
import numpy
import numpy.random
import numpy.testing
from mpds.dataset import MPDataset, MPTimeLike, MPFeatureKeyT, MPFeatureDataT


class MPDatasetTester(Generic[MPFeatureKeyT, MPFeatureDataT]):
    @classmethod
    def create(
        cls,
        resource: ...,
        metadata: ...,
    ):
        return cls(
            _metadata=metadata
        )

    def __init__(self, _metadata: dict):
        self._metadata = _metadata
        self._frames = dict[MPTimeLike, dict[MPFeatureKeyT, MPFeatureDataT]]()
        self._time_curr = None

    def add(
        self, 
        data: dict[MPFeatureKeyT, MPFeatureDataT], 
        time: MPTimeLike | None = None,
    ):
        if time is None:
            # TODO
            raise NotImplementedError
        
        frame_data = self._frames.setdefault(time, dict())
        frame_data.update(data)

    @property
    def metadata(self):
        return self._metadata

    # TODO this is tricky: off-by-1 interval problem
    @property
    def duration(self):
        return max(self._frames.keys())

    def items(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        if time is None:
            time = self._time_curr or 0

        if duration is None:
            duration = float("inf")
    
        frame_times = sorted(self._frames.keys())
        for frame_time in frame_times:
            self._time_curr = frame_time

            if not (time <= frame_time and frame_time < time + duration):
                continue
            
            frames_per_feature = self._frames[frame_time]
            yield frame_time, frames_per_feature
            
    def get(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        frames_by_feature = collections.defaultdict(dict)
        feature_keys = set()

        for frame_time, frames_per_feature in self.items(
            time=time,
            duration=duration,
        ):
            for feature_key, frame in frames_per_feature.items():
                feature_keys.add(feature_key)
                frames_by_feature[feature_key][frame_time] = frame

        time_result = {
            feature_key: [
                frame_time for frame_time in frames_by_feature[feature_key].keys()
            ]
            for feature_key in self.metadata["features"].keys()
        }

        # TODO
        data_result = {
            # TODO use self._handler.load_many instead
            feature_key: [frame for frame in frames_by_feature[feature_key].values()]
            for feature_key in self.metadata["features"].keys()
        }

        return time_result, data_result


# TODO
def _generate_images_curated():
    import av.datasets
    content = av.datasets.curated("pexels/time-lapse-video-of-night-sky-857195.mp4")
    while True:
        with av.open(content) as container:
            stream = container.streams.video[0]
            for frame in container.decode(stream):
                yield frame.to_image()


def _generate_images_random(rng: ...):
    while True:
        yield rng.integers(0, 255, size=(16, 16, 3), dtype=numpy.uint8)


class DatasetFixtureParams(NamedTuple):
    num_frames: int
    time_base: int | fractions.Fraction
    image_type: str
    is_lossless: bool
    seed: int


class DatasetFixture(NamedTuple):
    dataset: MPDataset
    dataset_tester: MPDatasetTester
    params: DatasetFixtureParams


# TODO parametrize
@pytest.fixture(
    params=[
        DatasetFixtureParams(num_frames=100, time_base=fractions.Fraction(1, 24), image_type="video/ffv1", is_lossless=True, seed=0),
        DatasetFixtureParams(num_frames=100, time_base=fractions.Fraction(1, 24), image_type="video/h264", is_lossless=False, seed=0),
        DatasetFixtureParams(num_frames=100, time_base=fractions.Fraction(1, 24), image_type="video/h265", is_lossless=False, seed=0),
    ],
)
def dataset_and_tester(request):
    # TODO
    params: DatasetFixtureParams = request.param

    metadata = {
        "features": {
            "sample_image": {
                "type": params.image_type,
            },
            "sample_json": {
                "type": "application/json",
            },
            "sample_tensor": {
                "type": "application/x-npy",
            },
        }
    }

    dataset_tester = MPDatasetTester.create(resource=None, metadata=metadata)

    buffer = io.BytesIO()
        
    # NOTE "trickify" the encoded data
    def _codec_overrides(container, codec, options):
        options = dict(options or {})

        match codec:
            case "ffv1":
                # FFV1 is intra-only, so this does NOT emulate long-GOP/B-frame
                # seek overshoot. It only makes the bitstream a bit more complex.
                return "ffv1", {
                    "coder": "range_tab",
                    "context": "1",
                    "slicecrc": "1",
                    "slices": "16",
                    **options,
                }

            case "h264":
                return "libx264", {
                    **options,
                    "x264-params": (
                        "keyint=60:"
                        "min-keyint=60:"
                        "scenecut=0:"
                        "bframes=16:"
                        f"""{options.get("x264-params", "")}"""
                    ),
                }

            case "hevc":
                return "libx265", {
                    **options,
                    # NOTE seealso https://x265.readthedocs.io/en/stable/cli.html
                    "x265-params": (
                        "keyint=60:"
                        "min-keyint=60:"
                        "scenecut=0:"
                        "bframes=16:"
                        "b-adapt=0:"
                        f"""{options.get("x265-params", "")}"""
                    ),
                }

        return codec, options

    with MPDataset.create(
        buffer,
        # TODO
        time_base=params.time_base,
        compression=0,
        metadata=metadata,
        _codec_overrides=_codec_overrides,
    ) as dataset:
        # TODO param
        rng = numpy.random.default_rng(seed=params.seed)

        # TODO paramize time base
        times_n = numpy.sort(numpy.unique(rng.uniform(low=0, high=100, size=params.num_frames).astype(int)))

        # TODO
        # image_generator = _generate_images_curated()
        image_generator = _generate_images_random(rng=rng)

        for time_n in times_n:
            time_s = fractions.Fraction(time_n, params.time_base)
            data = {
                "sample_image": next(image_generator),
                "sample_json": {"count": int(time_n)},
                "sample_tensor": numpy.asarray(int(time_n), dtype=numpy.int32),
            }
            dataset.add(
                time=time_s,
                data=data, 
            )
            dataset_tester.add(
                time=time_s,
                data=data,
            )

    return DatasetFixture(
        dataset=MPDataset.open(buffer),
        dataset_tester=dataset_tester,
        params=params,
    )


def _assert_dataset_get_equal(
    dataset: MPDataset,
    dataset_tester: MPDatasetTester,
    time: MPTimeLike | None = None,
    duration: MPTimeLike | None = None,
    check_data: bool = True,
):
    frame_times, frame_data = dataset.get(time=time, duration=duration)
    frame_times_expected, frame_data_expected = dataset_tester.get(time=time, duration=duration)

    numpy.testing.assert_equal(
        actual=frame_times,
        desired=frame_times_expected,
        err_msg=f"{time=} {duration=}",
    )

    # TODO FIXME assert all close
    if check_data:
        numpy.testing.assert_equal(
            actual=frame_data,
            desired=frame_data_expected,
            err_msg=f"{time=} {duration=}",
        )


# TODO
class TestMPDatasetRef:

    # TODO test time_bases
    # TODO test counts

    def test_duration(self, dataset_and_tester: DatasetFixture):
        dataset, dataset_tester, params = dataset_and_tester
        # TODO dataset_tester currently cannot return a correct duration due to off-by-one
        # assert dataset.duration >= dataset_tester.duration
        ...

    def test_get(self, dataset_and_tester: DatasetFixture):
        dataset, dataset_tester, params = dataset_and_tester

        _assert_dataset_get_equal(
            dataset=dataset,
            dataset_tester=dataset_tester,
            check_data=params.is_lossless,
        )

        # TODO use both non-rational and rational
        for i in range(params.num_frames):
            _assert_dataset_get_equal(
                dataset=dataset,
                dataset_tester=dataset_tester,
                time=fractions.Fraction(i, params.time_base),
                check_data=params.is_lossless,
            )

    def test_items(self, dataset_and_tester: DatasetFixture):
        dataset, dataset_tester, params = dataset_and_tester

        for dataset_item, dataset_tester_item in zip(dataset.items(), dataset_tester.items()):
            frame_time, frame_data = dataset_item
            frame_time_expected, frame_data_expected = dataset_tester_item

            numpy.testing.assert_equal(
                actual=frame_time,
                desired=frame_time_expected,
            )

            # TODO
            if params.is_lossless:
                numpy.testing.assert_equal(
                    actual=frame_data,
                    desired=frame_data_expected,
                )

    # TODO
    @pytest.mark.parametrize("random_seed", [0, 42])
    @pytest.mark.parametrize("num_iterations", [100])
    @pytest.mark.parametrize("actions", [
        ["get", "items"],
        # TODO
        ["cache_enable", "cache_fetch", "cache_evict", "get", "items"],
        ["cache_fetch", "cache_evict", "get", "items"],
    ])
    def test_random_access(
        self, 
        dataset_and_tester: DatasetFixture, 
        random_seed: int,
        num_iterations: int,
        actions: list[Literal["cache_enable", "cache_disable", "cache_fetch", "cache_evict", "get", "items"]],
    ):
        dataset, dataset_tester, params = dataset_and_tester

        # TODO
        rng = numpy.random.default_rng(seed=random_seed)

        for _ in range(num_iterations):
            for action in actions:
                match action:
                    case "cache_enable":
                        dataset.cache.enabled = True
                    case "cache_disable":
                        dataset.cache.enabled = False
                    case "cache_fetch":
                        time_prefetch = rng.uniform(low=0, high=dataset_tester.duration)
                        duration_prefetch = rng.uniform(low=0, high=dataset_tester.duration)
                        dataset.cache.fetch(time=time_prefetch, duration=duration_prefetch)
                    case "cache_evict":
                        time_evict = rng.uniform(low=0, high=dataset_tester.duration)
                        duration_evict = rng.uniform(low=0, high=dataset_tester.duration)
                        dataset.cache.evict(time=time_evict, duration=duration_evict)            
                    case "get":
                        # TODO
                        time = rng.uniform(low=0, high=dataset_tester.duration)
                        # time = rng.uniform(low=-10, high=dataset_tester.duration + 10)
                        duration = rng.uniform(low=0, high=dataset_tester.duration)

                        frame_times, frame_data = dataset.get(time=time, duration=duration)
                        frame_times_expected, frame_data_expected = dataset_tester.get(time=time, duration=duration)

                        assert frame_times == frame_times_expected, f"{time=} {duration=} (total {dataset_tester.duration=})"

                        # TODO
                        # numpy.testing.assert_equal(
                        #     actual=frame_times,
                        #     desired=frame_times_expected,
                        #     err_msg=f"{time=} {duration=} {frame_times=} {frame_times_expected=}",
                        # )

                        # TODO
                        if params.is_lossless:
                            numpy.testing.assert_equal(
                                actual=frame_data,
                                desired=frame_data_expected,
                                err_msg=f"{time=} {duration=}",
                            )
                    case "items":
                        # TODO
                        time = rng.uniform(low=0, high=dataset_tester.duration)
                        # time = rng.uniform(low=-10, high=dataset_tester.duration + 10)
                        duration = rng.uniform(low=0, high=dataset_tester.duration)

                        if params.is_lossless:
                            numpy.testing.assert_equal(
                                actual=list(dataset.items(time=time, duration=duration)),
                                desired=list(dataset_tester.items(time=time, duration=duration)),
                                err_msg=f"{time=} {duration=}",
                            )


def assert_payload_collectable(
    obj: object, 
    ensure_destroyed: bool = True,
    # message: str | None = None,
):
    ref = weakref.ref(obj)
    del obj
    gc.collect()
    if ensure_destroyed:
        obj_refed = ref()
        assert obj_refed is None, gc.get_referrers(obj_refed)


@pytest.mark.limit_leaks("1 MB")
def test_mpdataset_memory():
    for _ in range(100):
        time_base = fractions.Fraction(1, 1)

        buffer = io.BytesIO()
        dataset = MPDataset.create(
            buffer,
            time_base=time_base,
            metadata={
                "features": {
                    "sample_image": {
                        "type": "video/h265",
                    },
                    "sample_json": {
                        "type": "application/json",
                    },
                    "sample_tensor": {
                        "type": "application/x-npy",
                    },
                }
            },
        )
        for i in range(10):
            dataset.add(
                time=i * time_base,
                data={
                    "sample_image": numpy.empty((16, 16, 3), dtype=numpy.uint8),
                    "sample_json": {"somekey": 10},
                    "sample_tensor": numpy.empty((1,)),
                },
            )

        dataset.close()

        # TODO ensure_destroyed cannot be True for now
        # seealso: https://pyav.basswood-io.com/docs/16.0/overview/caveats.html#garbage-collection
        assert_payload_collectable(dataset, ensure_destroyed=False)

        dataset = MPDataset.open(buffer)
        for _ in dataset.items():
            pass

        # TODO see above
        assert_payload_collectable(dataset, ensure_destroyed=False)

