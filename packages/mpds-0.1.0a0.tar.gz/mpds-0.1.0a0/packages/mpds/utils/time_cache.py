# SPDX-License-Identifier: Apache-2.0

import fractions
import dataclasses
from typing import NamedTuple, Iterator, Protocol, Generic, TypeVar, Any, Callable, Mapping, Iterable

from sortedcontainers import SortedSet
from intervaltree import Interval, IntervalTree


TimeLike = int | float | fractions.Fraction


_DataT = TypeVar("_DataT")


@dataclasses.dataclass(slots=True)
class TimeFrame(Generic[_DataT]):
    time: TimeLike
    data: _DataT

    def __hash__(self):
        return hash(self.time)


class TimeSegment(Generic[_DataT]):
    __slots__ = ["_frames", "_begin", "_end"]

    def __init__(
        self, 
        frames: Iterable[TimeFrame[_DataT]] | None = None,
        begin: TimeLike | None = None,
        end: TimeLike | None = None,
    ):
        # TODO fast path if already sorted?
        self._frames = SortedSet[TimeFrame[_DataT]](frames, key=lambda frame: frame.time)
        self._begin = begin
        self._end = end

    @property
    def begin(self):
        if self._begin is not None:
            return self._begin
        if len(self._frames) <= 0:
            return None
        return self._frames[0].time

    @property
    def end(self):
        if self._end is not None:
            return self._end
        if len(self._frames) <= 0:
            return None
        # TODO this is closed interval
        return self._frames[-1].time

    def slice(self, begin: TimeLike | None = None, end: TimeLike | None = None):
        return self.__class__(
            frames=self._frames.irange_key(
                min_key=begin, 
                max_key=end, 
                inclusive=(True, False),
                # inclusive=(True, True),
            )
        )
    
    def update(self, *segments: "TimeSegment[_DataT]"):
        self._frames.update(*(segment._frames for segment in segments))
        return self
    
    def __len__(self):
        return len(self._frames)
    
    def __iter__(self) -> Iterator[TimeFrame[_DataT]]:
        return iter(self._frames)


class TimeSegmentCache(Generic[_DataT]):
    def __init__(self):
        self._segment_intervaltree = IntervalTree()

    class _SegmentFactory(Protocol[_DataT]):
        def __call__(self, begin: TimeLike, end: TimeLike) -> TimeSegment[_DataT]:
            ...

    @property
    def begin(self):
        return self._segment_intervaltree.begin()
    
    @property
    def end(self):
        return self._segment_intervaltree.end()

    def setdefault(
        self,
        begin: TimeLike,
        end: TimeLike,
        segment_factory: _SegmentFactory[_DataT],
    ):
        missing_intervals, _ = _intervaltree_partition(
            tree=self._segment_intervaltree, 
            interval=Interval(begin=begin, end=end),
        )
        for missing_interval in missing_intervals:
            missing_interval: Interval
            missing_segment = segment_factory(
                begin=missing_interval.begin,
                end=missing_interval.end,
            )
            self._segment_intervaltree.add(
                Interval(
                    # TODO two srcs of truth not ideal
                    begin=missing_segment.begin,
                    end=missing_segment.end,
                    data=missing_segment,
                )
            )

        complete_intervals = self._segment_intervaltree.overlap(
            begin=begin, 
            end=end,
        )
        complete_segments = []
        for complete_interval in complete_intervals:
            complete_interval: Interval
            complete_segment: TimeSegment = complete_interval.data
            complete_segments.append(
                complete_segment.slice(begin=begin, end=end)
            )
        return TimeSegment().update(*complete_segments)
    
    def delete(
        self,
        begin: TimeLike | None = None,
        end: TimeLike | None = None,
    ):
        def _interval_constructor(
            begin, 
            end, 
            data: TimeSegment, 
            # is_lower
        ):
            data_n = data.slice(begin=begin, end=end)
            # TODO
            if data_n.begin == data_n.end:
                return None
            return Interval(
                begin=data_n.begin,
                end=data_n.end,
                data=data_n,
            )
        # TODO
        _intervaltree_chop(
            tree=self._segment_intervaltree,
            begin=begin,
            end=end,
            interval_constructor=_interval_constructor,
        )


def _intervaltree_partition(tree: IntervalTree, interval: Interval):
    r"""
    TODO doc

    >>> tree = IntervalTree([Interval(10, 20, data=12)])
    >>> _intervaltree_partition(tree, interval=Interval(5, 25))
    (IntervalTree([Interval(5, 10), Interval(20, 25)]), {Interval(10, 20, 12)})

    """

    existing_intervals = tree.overlap(interval.begin, interval.end)
    # TODO
    missing_intervals = IntervalTree([interval]) if not interval.is_null() else IntervalTree()

    for overlapping_interval in existing_intervals:
        overlapping_interval: Interval
        missing_intervals.chop(
            max(interval.begin, overlapping_interval.begin),
            min(interval.end, overlapping_interval.end),
        )

    return missing_intervals, existing_intervals


class _IntervalConstructor(Protocol):
    def __call__(self, begin: TimeLike, end: TimeLike) -> Interval:
        ...


def _intervaltree_chop(
    tree: IntervalTree, 
    begin: TimeLike | None, 
    end: TimeLike | None, 
    interval_constructor: _IntervalConstructor,
):
    """
    TODO doc
    """

    if begin is None:
        begin = tree.begin()
    if end is None:
        end = tree.end()

    insertions = set()
    begin_hits = [iv for iv in tree.at(begin) if iv.begin < begin]
    end_hits = [iv for iv in tree.at(end) if iv.end > end]

    for iv in begin_hits:
        interval_n = interval_constructor(
            iv.begin,
            begin,
            iv.data,
            # is_lower=True,
        )
        if interval_n is not None:
            insertions.add(interval_n)

    for iv in end_hits:
        interval_n = interval_constructor(
            end, 
            iv.end,
            iv.data,
            # is_lower=False,
        )
        if interval_n is not None:
            insertions.add(interval_n)

    tree.remove_envelop(begin, end)
    tree.difference_update(begin_hits)
    tree.difference_update(end_hits)
    tree.update(insertions)