# SPDX-License-Identifier: Apache-2.0

import queue
import fractions
from typing import Callable, Generic, TypeVar

from sortedcontainers import SortedDict


TimeFrameQueueTimeLike = int | float | fractions.Fraction

_TimeFrameQueueTimeT = TypeVar("_TimeFrameQueueTimeT", bound=TimeFrameQueueTimeLike)
_TimeFrameQueueFrameT = TypeVar("_TimeFrameQueueFrameT")


# TODO use heapq
class TimeFrameQueue(Generic[_TimeFrameQueueTimeT, _TimeFrameQueueFrameT]):
    """
    TODO doc

    A dict-like structure for time-keyed items with:

      - Approximate lookup:      map[time_approx] -> nearest item within eps
      - Approximate setdefault:  map.setdefault(time_approx, item) -> reuse near item or insert
      - Ordered draining:        map.pop() -> returns ONLY the earliest-time item *if* item.done()

    Key points:
      - Times are stored as fractions.Fraction seconds.
      - pop() is "head-of-line": if the earliest-time item is not done, pop() returns None.
        This guarantees drained items are in non-decreasing time order.
    """

    def __init__(
        self, 
        tolerance: _TimeFrameQueueTimeT | None = None,
        default_factory: Callable[[], _TimeFrameQueueFrameT] | None = None,
    ):
        self._tolerance = tolerance
        self._default_factory = default_factory
        # TODO optimize
        self._by_time = SortedDict[fractions.Fraction, _TimeFrameQueueFrameT]()

    def __len__(self) -> int:
        return len(self._by_time)

    def _get_nearest_time_key(self, target_time: fractions.Fraction) -> fractions.Fraction | None:
        """
        TODO doc

        Return the stored time key nearest to target_time within eps, else None.
        Only checks the two neighbors around the insertion point (O(log n)).
        """

        if self._tolerance is None:
            if not target_time in self._by_time.keys():
                return None
            return target_time

        insertion_index = self._by_time.bisect_left(target_time)

        best_key: fractions.Fraction | None = None
        best_distance: fractions.Fraction | None = None

        # Candidate on the right (>= target_time)
        if insertion_index < len(self._by_time):
            right_key = self._by_time.keys()[insertion_index]
            right_distance = right_key - target_time
            if right_distance <= self._tolerance:
                best_key = right_key
                best_distance = right_distance

        # Candidate on the left (< target_time)
        if insertion_index > 0:
            left_key = self._by_time.keys()[insertion_index - 1]
            left_distance = target_time - left_key
            if left_distance <= self._tolerance and (best_distance is None or left_distance < best_distance):
                best_key = left_key
                best_distance = left_distance

        return best_key

    def __getitem__(self, time_approx: _TimeFrameQueueTimeT) -> _TimeFrameQueueFrameT:
        """
        TODO doc

        If an item already exists near time_approx (within eps), return it.
        Otherwise create (using default factory) and insert item at exactly time_approx.
        """

        target_time = fractions.Fraction(time_approx)
        nearest_key = self._get_nearest_time_key(target_time)
        if nearest_key is None:
            if self._default_factory is None:
                raise KeyError(target_time)
            nearest_key = target_time
            self._by_time[nearest_key] = self._default_factory()
        return self._by_time[nearest_key]

    def pop(self, done_key: Callable[[_TimeFrameQueueTimeT, _TimeFrameQueueFrameT], bool] | None = None) -> tuple[_TimeFrameQueueTimeT, _TimeFrameQueueFrameT]:
        """
        TODO doc

        Ordered draining rule:
          - Look at the earliest-time entry.
          - If it's done(), remove+return (time, item).
          - If it's not done(), return None.
        """

        if len(self._by_time) == 0:
            raise queue.Empty()

        earliest_time, earliest_item = self._by_time.peekitem(0)

        if done_key is not None:
            if not done_key(earliest_time, earliest_item):
                return None

        self._by_time.popitem(0)
        return earliest_time, earliest_item
