# SPDX-License-Identifier: Apache-2.0

import os
import dataclasses
import fractions
import warnings
import logging
import time
from typing import Iterable

import av
import av.container
import av.error
import av.stream
import av.frame
import av.logging
from mpds.utils.time_queue import TimeFrameQueue


logger = logging.getLogger(__name__)
if logger.isEnabledFor(logging.INFO):
    logger.info("Logging enabled")


AVTimeLike = int | float | fractions.Fraction


def av_clip_time(
    time: AVTimeLike,
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None,
):
    if streams is None:
        streams = container.streams

    time_min = min(
        (
            stream.start_time * stream.time_base
            for stream in streams
            if stream.start_time is not None and stream.time_base is not None
        ),
        default=None,
    )

    time_max = max(
        (
            stream.duration * stream.time_base
            for stream in streams
            if stream.duration is not None and stream.time_base is not None
        ),
        default=None,
    )

    if time_min is not None:
        time = max(time_min, time)

    if time_max is not None:
        time = min(time_max, time)

    return time


def av_is_video_format_equal(format0: av.VideoFormat, format1: av.VideoFormat):
    return all((
        format0.name == format1.name,
        format0.width == format1.width,
        format0.height == format1.height,
    ))


def av_compute_num_reordering_frames(
    stream: av.stream.Stream,
):
    codec_context = stream.codec_context
    match codec_context:
        case av.VideoCodecContext():
            pass
        case _:
            return None
        
    num_b_frames = int(codec_context.has_b_frames or 0) + codec_context.max_b_frames
    # TODO FIXME for av<17 this is an estimate
    num_b_frames *= 16
    if hasattr(codec_context, "reorder_depth"):
        num_b_frames = codec_context.reorder_depth

    num_thread_frames = 0
    match codec_context.thread_type:
        case codec_context.thread_type.FRAME \
            | codec_context.thread_type.AUTO:
            # TODO
            if not codec_context.thread_count:
                if (cpu_count := os.cpu_count()) is not None:
                    num_thread_frames = cpu_count * 2
            else:
                num_thread_frames = codec_context.thread_count * 2

    return num_b_frames + num_thread_frames


def av_seek_and_flush(
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None,
    # TODO
    time: AVTimeLike | None = None, 
):
    if time is None:
        return

    if streams is None:
        streams = container.streams

    # # TODO not accurate??
    # # TODO NOTE not thread safe use thread lock
    container.seek(int(time * av.time_base), backward=True, any_frame=False)
    for stream in streams:
        if stream.codec_context is None:
            continue
        stream.codec_context.flush_buffers()
    if logger.isEnabledFor(logging.INFO):
        logger.info(f"{container}: Seeked to ~{time}secs")


def av_iter_frames_maybe_unordered(
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None,
    _retry_interval_secs: float | None = .1,
    _retry_interval_secs_max: float = 1.,
):
    if streams is None:
        streams = container.streams

    _retry_num_attempts: int = 0

    for packet in container.demux(*streams):
        stream = packet.stream
        match stream:
            case av.VideoStream() | av.AudioStream():
                while True:
                    try:
                        for frame in packet.decode():
                            assert isinstance(frame, (av.VideoFrame, av.AudioFrame))
                            yield stream, frame
                    except av.error.BlockingIOError as error:
                        warnings.warn(f"Packet decoding not available, retrying: {error}")
                        is_debug = logger.isEnabledFor(logging.DEBUG)
                        if is_debug:
                            logging.debug(
                                f"{container}: "
                                f"Packet decoding not available, retrying attempt {_retry_num_attempts}",
                                exc_info=is_debug,
                            )
                        if _retry_interval_secs is not None:
                            time.sleep(min(_retry_interval_secs * _retry_num_attempts, _retry_interval_secs_max))
                        _retry_num_attempts += 1
                        continue
                    except av.error.EOFError:
                        # TODO
                        pass
                    break
            case av.stream.DataStream():
                yield stream, packet


def av_iter_frames_timed_maybe_unordered(
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None,
    # TODO 
    time: AVTimeLike | None = None, 
):
    if streams is None:
        streams = container.streams

    time_cursor = time
    is_time_reachable = False

    av_seek_and_flush(
        container,
        streams=streams,
        time=time,
    )

    while not is_time_reachable:
        frame_time_overshoot_per_stream = dict[av.stream.Stream, AVTimeLike]()

        for stream, frame in av_iter_frames_maybe_unordered(container, streams=streams):
            # TODO
            if frame.pts is None:
                continue
            if frame.time_base is None:
                # TODO
                raise NotImplementedError("TODO")

            frame_time = frame.pts * frame.time_base
            if time is None:
                is_time_reachable = True
            else:
                frame_time_overshoot = frame_time - time

                # TODO
                if not is_time_reachable:
                    if stream not in frame_time_overshoot_per_stream:
                        frame_time_overshoot_per_stream[stream] = frame_time_overshoot
                        
                    if logger.isEnabledFor(logging.DEBUG):
                        logger.debug(
                            f"{stream}: "
                            f"Seeking, overshoot {frame_time_overshoot}secs "
                            f"(current time - target time = {frame_time} - {time})"
                        )

                    if frame_time_overshoot_per_stream.keys() == streams:
                        if logger.isEnabledFor(logging.INFO):
                            logger.info(
                                f"{container}: "
                                f"Seeking, periodic overshoot stats complete: "
                                f"{frame_time_overshoot_per_stream}"
                            )

                        time_backoff = max(frame_time_overshoot_per_stream.values(), default=0)

                        if time_backoff > 0: 
                            assert time_cursor is not None
                            time_cursor -= time_backoff
                            if logger.isEnabledFor(logging.INFO):
                                logger.info(
                                    f"{container}: "
                                    f"Seeking, backtrack {time_backoff}secs to {time_cursor}secs"
                                )
                            av_seek_and_flush(
                                container,
                                streams=streams,
                                time=time_cursor,
                            )
                            # NOTE retry
                            break

                        is_time_reachable = True
                        if logger.isEnabledFor(logging.INFO):
                            logger.info(
                                f"{container}: "
                                f"Seeking complete, ready to emit frames"
                            )

                if frame_time_overshoot < 0:
                    continue

            # TODO
            may_frame_repeat = not is_time_reachable

            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(f"Emitting frame from stream {stream}: {frame}")
            yield stream, frame, may_frame_repeat

            
@dataclasses.dataclass(slots=True)
class _AVIterPendingItem:
    value: dict[av.stream.Stream, av.Packet | av.frame.Frame] \
        = dataclasses.field(default_factory=dict)
    num_reordered_frames: int = 0


# TODO testing
def av_iter_frames_unbounded(
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None, 
    # TODO
    time: AVTimeLike | None = None, 
):
    match container:
        case av.container.InputContainer():
            pass
        case av.container.OutputContainer():
            raise NotImplementedError(
                f"AV container opened as write-only: {container!r}"
            )
        case unknown:
            raise ValueError(f"Impossible: {unknown}")

    if streams is None:
        streams = set(container.streams)
    streams = set(streams)

    # TODO
    num_reordered_frames_max = 0
    for stream in streams:
        num_reordered_frames_max += (
            av_compute_num_reordering_frames(stream) 
            or
            0
        )

    frame_datas_pending = TimeFrameQueue[fractions.Fraction, _AVIterPendingItem](
        default_factory=_AVIterPendingItem,
    )

    for stream, frame, may_frame_repeat in av_iter_frames_timed_maybe_unordered(container, streams=streams, time=time):
        # TODO
        if frame.pts is None:
            continue
        if frame.time_base is None:
            # TODO
            raise NotImplementedError("TODO")
        
        frame_time = frame.pts * frame.time_base
        pending_item = frame_datas_pending[frame_time]
        pending_item.value[stream] = frame
        if may_frame_repeat:
            pending_item.num_reordered_frames -= 1

        def done_key(
            pending_time: fractions.Fraction, 
            pending_data: _AVIterPendingItem,
        ):
            if pending_data.value.keys() == streams:
                return True
            if pending_data.num_reordered_frames > num_reordered_frames_max:
                return True
            if frame_time - pending_time > 0:
                pending_data.num_reordered_frames += 1
            return False
        result = frame_datas_pending.pop(done_key=done_key)
        if result is not None:
            # TODO
            result_time, result_data = result
            yield result_time, result_data.value

    # NOTE drain pending frames
    while len(frame_datas_pending) > 0:
        result_time, result_data = frame_datas_pending.pop()
        yield result_time, result_data.value


def av_iter_frames(
    container: av.container.InputContainer, 
    streams: Iterable[av.stream.Stream] | None = None, 
    time: AVTimeLike | None = None, 
    duration: AVTimeLike | None = None,
):
    initial_time = None

    for frame_time, frames_per_stream in av_iter_frames_unbounded(
        container=container,
        streams=streams,
        time=time,
    ):
        if initial_time is None:
            initial_time = (
                time
                if time is not None else
                frame_time
            )

        # TODO
        if (
            initial_time is not None
            and duration is not None
        ):
            if frame_time - initial_time >= duration:
                break

        yield frame_time, frames_per_stream


def av_ensure_codec_log_level(
    stream: av.stream.Stream,
    log_level: int | None = None,
):
    if log_level is None:
        log_level = av.logging.get_level()

    match stream:
        case av.VideoStream():
            match stream.codec.name:
                case "libx264" | "libx265" as codec_name:
                    x26x_log_level = "none"
                    match log_level:
                        case None:
                            x26x_log_level = "none"
                        case av.logging.ERROR:
                            x26x_log_level = "error"
                        case av.logging.WARNING:
                            x26x_log_level = "warning"
                        case av.logging.INFO:
                            x26x_log_level = "info"
                        case av.logging.DEBUG:
                            x26x_log_level = "debug"
                    match codec_name:
                        case "libx264":
                            stream.options["x264-params"] = str.join(
                                ":", 
                                [
                                    f"log-level={x26x_log_level}",
                                    str(stream.options.get("x264-params") or ""),
                                ],
                            )
                        case "libx265":
                            stream.options["x265-params"] = str.join(
                                ":", 
                                [
                                    f"log-level={x26x_log_level}",
                                    str(stream.options.get("x265-params") or ""),
                                ],
                            )
