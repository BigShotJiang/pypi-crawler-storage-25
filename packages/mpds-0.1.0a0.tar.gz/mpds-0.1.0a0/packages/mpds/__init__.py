# SPDX-License-Identifier: Apache-2.0

import importlib.metadata

from mpds.dataset import MPDataset, MPMetadata, MPFeatureMetadata
from mpds.device import mp_devices_available, mp_use_device


__all__ = [
    "MPDataset", 
    "MPMetadata",
    "MPFeatureMetadata",
    "mp_devices_available",
    "mp_use_device",
]


try:
    __version__ = importlib.metadata.version(__name__)
except:
    __version__ = None
