# SPDX-License-Identifier: Apache-2.0

from typing import Literal

import av.codec.hwaccel


def mp_devices_available():
    r"""
    List all hardware acceleration devices available on the system.

    :returns: A list of device names.
    """

    return [
        *av.codec.hwaccel.hwdevices_available(),
    ]


class mp_use_device:
    r"""
    Use a device for hardware acceleration within the context.

    :param device: 
        The name of the device to use, or None to disable hardware acceleration.
        See :func:`mp_devices_available` for a list of available devices.
    :param force: 
        If ``True``, force the use of the specified device even if it is not available.
    """

    _hwaccel: av.codec.hwaccel.HWAccel | None = None
    _hwaccel_orig: av.codec.hwaccel.HWAccel | None = None
    _num_threads: int | Literal["auto", "max"] | None = None

    def __init__(
        self, 
        device: str | None = None, 
        num_threads: int | Literal["auto", "max"] | None = None,
        force: bool = False,
    ):
        self.__class__._hwaccel_orig = self.__class__._hwaccel
        if device is None:
            self.__class__._hwaccel = None
        else:
            self.__class__._hwaccel = av.codec.hwaccel.HWAccel(
                device_type=device, 
                allow_software_fallback=not force,
            )
        self.__class__._num_threads = num_threads

    def __enter__(self):
        pass
    
    def __exit__(self, *_):
        self.__class__._hwaccel = self.__class__._hwaccel_orig
        self.__class__._num_threads = None