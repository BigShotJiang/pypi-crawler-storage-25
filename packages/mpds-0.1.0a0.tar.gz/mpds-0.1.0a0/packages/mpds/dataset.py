# SPDX-License-Identifier: Apache-2.0

import os
import abc
import fractions
import io
import copy
import json
import warnings
import collections
import dataclasses
import functools
import logging
from types import MappingProxyType
from typing import IO, Any, Generic, Iterable, TypeVar, Generic, Callable, cast
try:
    from typing_extensions import NotRequired, TypedDict
except ImportError:  # Python > 3.10
    from typing import NotRequired, TypedDict

import av
import av.stream
import av.container
import av.codec
# TODO
import av.logging
av.logging.set_level(logging.WARNING)
import bidict
import semver
from mpds.handlers.base import ProtoHandler, UnsupportedType
from mpds.handlers.default import handler
from mpds.device import mp_use_device
from mpds.utils.time_cache import TimeFrame, TimeSegment, TimeSegmentCache
from mpds.utils.av import av_is_video_format_equal, av_iter_frames, av_ensure_codec_log_level


MPTimeLike = int | float | fractions.Fraction

MPFeatureKeyT = TypeVar("MPFeatureKeyT", bound=str)
MPFeatureDataT = TypeVar("MPFeatureDataT")


class MPMetadata(TypedDict, Generic[MPFeatureKeyT]):
    r"""
    Motion-Picture Dataset (MPDS) metadata.
    TODO link to standard
    """

    version: NotRequired[str]
    r"""
    Semantic version string. 
    TODO link to standard
    """
    features: dict[MPFeatureKeyT, "MPFeatureMetadata"]
    r"""
    Mapping from feature keys to their corresponding metadata. 
    TODO link to standard
    """


class MPFeatureMetadata(TypedDict):
    r"""
    Metadata of a feature in Motion-Picture Dataset (MPDS).
    TODO link to standard
    """

    index: NotRequired[int]
    r"""
    Index of the feature, which corresponds 
    to the stream index in the underlying container.
    TODO link to standard
    """
    type: str
    r"""
    Type of the feature, which determines 
    how the data of the feature is encoded and decoded.
    TODO link to standard
    """


class _MPMetadataHandler:
    @classmethod
    def load(cls, metadata_encoded: str | bytes, validate: bool = True):
        metadata = MPMetadata(json.loads(metadata_encoded))
        if validate:
            cls.validate(metadata=metadata)
        return metadata

    @classmethod
    def save(cls, metadata: MPMetadata, validate: bool = True):
        if validate:
            cls.validate(metadata=metadata)
        return json.dumps(metadata)

    @classmethod
    def validate(cls, metadata: MPMetadata):
        version = metadata.get("version", None)
        if version is not None:
            if semver.Version.parse(version) > semver.Version(1):
                raise NotImplementedError("TODO")

        features = metadata.get("features", {})
        # TODO
        ...


class MPDataset(Generic[MPFeatureKeyT, MPFeatureDataT]):
    r"""
    Motion-Picture Dataset (MPDS) implementation.
    """

    default_handler = handler
    r"""
    The default handler used for 
    encoding and decoding feature data in the dataset.
    """

    @classmethod
    def create(
        cls,
        resource: str | IO,
        metadata: MPMetadata,
        time_base: MPTimeLike | dict[MPFeatureKeyT, MPTimeLike] | None = None,
        compression: float | dict[MPFeatureKeyT, float] | None = None,
        handler: ProtoHandler = default_handler,
        # TODO
        _codec_overrides: Callable[[av.container.Container, str, dict], tuple[str, dict]] | None = None,
    ):
        r"""
        Create the dataset.

        :param resource:
            URL, path, or buffer referencing the underlying storage resource
            of the created dataset.
            For example, ``"udp://localhost:1234"``,
            ``"some/path/to/dataset.mpds"``, ``io.BytesIO()``, etc.
        :param metadata:
            Metadata describing the dataset, including the features and their types.
            TODO doc
        :param time_base:
            Time base of the dataset (Unit: seconds),
            which determines the timing accuracy of the frames in the dataset;
            If unspecified, the default time base of the handler and codec will be used.
            For example, if the times passed to :obj:`add` are all multiples
            of 1/30, then a time base of 1/30 is sufficient to represent
            the timing of the frames without loss of accuracy.
        :param compression:
            Compression level of the dataset (Unit: percent),
            which determines the trade-off between the size of the dataset and
            the quality of the frames in the dataset;
            If unspecified, the default compression level of the handler will be used.
            The value should be between 0 and 1, where 0 means no compression (i.e. best quality)
            and 1 means maximum compression (i.e. worst quality).
            The statistical distribution of such value depends on the handler and codec used for each feature.
        :param handler:
            Handler to use for encoding and decoding feature data;
            If unspecified, the default handler :obj:`default_handler` is used.
        :returns:
            The created dataset.
        """

        # TODO custom resource handler for non-file resources (e.g. in-memory buffers, cloud storage, git, etc.)

        container = av.open(
            resource,
            mode="w",
            format="mp4",
            options={
                "movflags": "+use_metadata_tags",
            },
            hwaccel=mp_use_device._hwaccel,
        )

        metadata = copy.deepcopy(metadata)

        if _codec_overrides is None:
            _codec_overrides = lambda _, codec, options: (codec, options)

        # TODO
        metadata.setdefault("version", "1.0.0")
        for feature_key, feature in metadata["features"].items():
            stream_compression = None
            match compression:
                case dict():
                    stream_compression = compression.get(feature_key, None)
                case _:
                    stream_compression = compression
            # TODO warn if clipped
            if stream_compression is not None:
                stream_compression = max(0.0, min(1.0, stream_compression))

            stream_time_base = None
            match time_base:
                case dict():
                    stream_time_base = time_base.get(feature_key, None)
                case _:
                    stream_time_base = time_base

            # TODO support options? necesito? use ._av_streams[...].options directly?
            match handler.resolve_codec(
                data_type=feature["type"],
                container=container,
                compression=stream_compression,
            ):
                case UnsupportedType():
                    raise NotImplementedError(f"TODO: {feature}")
                case None, options:
                    codec_name, options = _codec_overrides(container, "bin_data", options)
                    stream = container.add_data_stream(
                        codec_name=codec_name,
                        options=options,
                    )
                    if stream_time_base is not None:
                        stream.time_base = stream_time_base
                case codec_name, options:
                    rate = (
                        fractions.Fraction(1, stream_time_base)
                        if stream_time_base is not None else
                        None
                    )
                    match rate:
                        case float():
                            if not float(rate).is_integer():
                                warnings.warn(
                                    f"Rate {rate} derived from time base "
                                    f"{stream_time_base} for feature {feature_key} is not rational. "
                                    f"Playback timing accuracy may suffer"
                                )
                            rate = int(round(rate))
                    codec_name, options = _codec_overrides(container, codec_name, options)
                    stream = container.add_stream(
                        codec_name=codec_name,
                        # TODO NOTE this only serves as a hint to the player
                        rate=rate,
                        options=options,
                    )
                    if stream_time_base is not None:
                        stream.time_base = stream_time_base
                        if stream.codec_context is not None:
                            stream.codec_context.time_base = stream_time_base
                case unknown:
                    raise ValueError(f"Invalid resolved codec and options: {unknown}")

            # TODO
            # if stream_time_base is not None:
            #     stream.time_base = stream_time_base

            feature["index"] = stream.index

        container.metadata["mpds_metadata"] = _MPMetadataHandler.save(metadata)

        # TODO
        for stream in container.streams:
            av_ensure_codec_log_level(stream)

        # TODO
        return cls(
            _av_container=container,
            _handler=handler,
            _autoclose=True,
        )

    @classmethod
    def open(
        cls,
        resource: str | IO,
        handler: ProtoHandler = default_handler,
        feature_keys: Iterable[MPFeatureKeyT] | None = None,
    ):
        r"""
        Open an existing dataset.

        :param resource:
            URL, path, or buffer referencing the underlying storage resource
            of the dataset to open (e.g. ``"some/path/to/dataset.mpds"``, ``io.BytesIO()``).
        :param handler:
            Handler to use for encoding and decoding feature data.
            The default handler :obj:`default_handler` if unspecified.
        :param feature_keys:
            Keys of the features (:obj:`metadata["features"]`) to select.
            If unspecified, all features are selected.
        :returns:
            The opened dataset.
        """

        container = av.open(
            resource,
            mode="r",
            format="mp4",
            hwaccel=mp_use_device._hwaccel,
        )

        # TODO
        for stream in container.streams:
            av_ensure_codec_log_level(stream)

        match mp_use_device._num_threads:
            case None:
                pass
            case "auto":
                for stream in container.streams:
                    if stream.codec_context is not None:
                        stream.codec_context.thread_type = "AUTO"
            case "max":
                for stream in container.streams:
                    if stream.codec_context is not None:
                        stream.codec_context.thread_type = "AUTO"
                        stream.codec_context.thread_count = os.cpu_count() or 1
            case num_threads:
                for stream in container.streams:
                    if stream.codec_context is not None:
                        stream.codec_context.thread_type = "AUTO"
                        stream.codec_context.thread_count = num_threads

        # TODO
        return cls(
            _av_container=container,
            _handler=handler,
            _feature_keys=feature_keys,
            _autoclose=True,
        )

    def __init__(
        self,
        _av_container: av.container.Container,
        _handler: ProtoHandler = handler,
        _feature_keys: Iterable[MPFeatureKeyT] | None = None,
        _autoclose: bool = False,
    ):
        self._av_container = _av_container
        self._handler = _handler
        self._feature_keys = set(_feature_keys) if _feature_keys is not None else None
        # NOTE this option is needed because pyav's container does not close automatically
        self._autoclose = _autoclose

    def __del__(self):
        if self._autoclose:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def select(
        self,
        feature_keys: Iterable[MPFeatureKeyT] | None = None,
    ):
        r"""
        Select a subset of features from this dataset.

        :param feature_keys:
            Keys of the features (:obj:`metadata["features"]`) to select.
            If unspecified, all features are selected.
        :returns:
            A dataset view with the selected features.
        """

        return self.__class__(
            _av_container=self._av_container,
            _handler=self._handler,
            _feature_keys=feature_keys,
        )
    
    # TODO
    def close(self):
        r"""
        Close the opened/created dataset
        and release any resources associated with it.
        Oftentimes this is necessary to finalize
        the writing of the dataset (and make it available for reading).
        """

        container = self._av_container
        match container:
            case av.container.OutputContainer():
                for stream in container.streams:
                    match stream:
                        case av.VideoStream() | av.AudioStream():
                            container.mux(stream.encode())
                        case av.stream.DataStream():
                            continue
                container.close()
            case av.container.InputContainer():
                container.close()
            case unknown:
                raise ValueError(f"Impossible: {unknown}")

    @functools.cached_property
    def metadata(self) -> MPMetadata:
        r"""
        Read-only metadata of this dataset.
        """

        value = _MPMetadataHandler.load(self._av_container.metadata["mpds_metadata"])
        return cast(
            MPMetadata,
            MappingProxyType(
                {
                    **value,
                    "features": {
                        feature_key: feature
                        for feature_key, feature in value["features"].items()
                        if (
                            feature_key in self._feature_keys
                            if self._feature_keys is not None else
                            True
                        )
                    },
                }
            ),
        )

    @functools.cached_property
    def _av_streams(self):
        metadata = self.metadata

        result = dict[MPFeatureKeyT, av.stream.Stream]()
        # TODO
        assert "features" in metadata
        for feature_key, feature in metadata["features"].items():
            # TODO
            assert "index" in feature
            index = feature["index"]
            stream = self._av_container.streams[index]
            result[feature_key] = stream

        return bidict.bidict(result)
    
    @property
    def time_bases(self):
        r"""
        The time base of each feature in this dataset (Unit: seconds).
        Time base refers to the smallest time step 
        that can be represented accurately in the dataset.
        """
        
        metadata = self.metadata

        result = dict[MPFeatureKeyT, fractions.Fraction]()
        for feature_key, feature in metadata["features"].items():
            index = feature["index"]
            stream = self._av_container.streams[index]
            match stream:
                case av.VideoStream() | av.AudioStream():
                    if stream.base_rate is None:
                        raise NotImplementedError(
                            f"Querying time bases on a half-written dataset "
                            f"with video/audio features is not supported, yet: "
                            f"{self._av_container}"
                        )
                    result[feature_key] = (
                        1 / stream.base_rate 
                        if stream.base_rate is not None else 
                        stream.time_base
                    )
                case av.stream.DataStream():
                    result[feature_key] = stream.time_base
                    
        return result
    
    @property
    def counts(self):
        r"""
        The number of data points of each feature in this dataset.
        """

        metadata = self.metadata

        result = dict[MPFeatureKeyT, int]()
        for feature_key, feature in metadata["features"].items():
            index = feature["index"]
            stream = self._av_container.streams[index]
            match stream:
                case av.VideoStream() | av.AudioStream() | av.stream.DataStream():
                    result[feature_key] = stream.frames
                    
        return result

    @property
    def duration(self):
        r"""
        Duration of this dataset (Unit: seconds).
        """

        container = self._av_container
        match container:
            case av.container.InputContainer():
                if container.duration is None:
                    return None
                # TODO FIXME this is wrong
                return fractions.Fraction(container.duration, av.time_base)
            case av.container.OutputContainer():
                raise NotImplementedError(
                    f"Duration is not available on the created dataset "
                    f"because the underlying container is write-only: {container!r}"
                )
            case unknown:
                raise ValueError(f"Impossible: {unknown}")

    def add(
        self, 
        time: MPTimeLike | None,
        data: dict[MPFeatureKeyT, MPFeatureDataT], 
    ):
        r"""
        Add one frame to this dataset.

        TODO examples

        :param time:
            Time in which the frame appears (Unit: seconds).
            TODO If unspecified, the time of the frame will be determined.        
        :param data:
            Data to add, mapping feature keys in
            :obj:`self.metadata["features"]` to their corresponding data.
        """

        def _compute_pts(time, time_base, warn_division: bool = True):
            pts = time / time_base
            if warn_division:
                if not float(pts).is_integer():
                    warnings.warn(
                        f"Time {time} not divisible by time base {time_base}, "
                        f"timing accuracy may suffer: {pts}. "
                        f"Create a new dataset with a compatible time base"
                    )
            return int(round(pts))

        # TODO
        container = self._av_container
        match container:
            case av.container.InputContainer():
                raise NotImplementedError(
                    f"Writing data mid reading is not "
                    f"a supported feature of {container!r}. "
                    f"Create a new dataset using {self.__class__.create} "
                    f"and transfer the frames manually"
                )
            case av.container.OutputContainer():
                pass
            case unknown:
                raise ValueError(f"Impossible: {unknown}")

        for feature_key, feature_value in data.items():
            if feature_key not in self.metadata["features"]:
                raise ValueError(
                    f"""Feature {feature_key!r} not one of features present in metadata: """
                    f"""{list(self.metadata["features"].keys())}"""
                )

            feature_metadata = self.metadata["features"][feature_key]

            if feature_key not in self._av_streams:
                raise ValueError("Impossible")

            stream = self._av_streams[feature_key]
            if stream.time_base is None:
                # TODO is this a sane default?
                stream.time_base = fractions.Fraction(1, 1_000_000)

            if stream.codec_context is not None:
                # TODO
                if stream.codec_context.time_base is None:
                    stream.codec_context.time_base = stream.time_base

            feature_value_encoded = self._handler.save(
                feature_value,
                data_type=feature_metadata["type"],
            )
            match feature_value_encoded:
                case av.Packet() as packet:
                    assert isinstance(stream, av.stream.DataStream), stream
                    packet.stream = stream
                    if time is not None:
                        packet.pts = _compute_pts(time, time_base=stream.time_base)
                        # NOTE dts must be specified or else deprecation warnings may result
                        packet.dts = packet.pts
                    # TODO NOTE required for last packet
                    packet.duration = _compute_pts(1, time_base=stream.time_base)
                    container.mux(packet)
                case av.VideoFrame() as frame:
                    assert isinstance(stream, av.VideoStream), stream
                    if not av_is_video_format_equal(stream.format, frame.format):
                        if stream.codec.video_formats is not None:
                            format_best, _ = av.codec.find_best_pix_fmt_of_list(
                                stream.codec.video_formats,
                                src_pix_fmt=frame.format,
                                has_alpha=False,
                            )
                            if format_best is None:
                                raise NotImplementedError("TODO")
                            # NOTE width and height are not filled by find_best_pix_fmt_of_list
                            stream.format = av.VideoFormat(
                                name=format_best.name,
                                width=frame.width,
                                height=frame.height,
                            )
                    # TODO
                    if time is not None:
                        frame.pts = _compute_pts(
                            time, time_base=stream.codec_context.time_base
                        )
                    # TODO
                    frame.duration = _compute_pts(1, time_base=stream.codec_context.time_base)
                    container.mux(stream.encode(frame.reformat(format=stream.format)))
                case av.AudioFrame() as frame:
                    assert isinstance(stream, av.AudioStream), stream
                    # TODO
                    if time is not None:
                        frame.pts = _compute_pts(
                            time, time_base=stream.codec_context.time_base
                        )
                    # TODO
                    frame.duration = _compute_pts(1, time_base=stream.codec_context.time_base)
                    container.mux(stream.encode(frame))
                case UnsupportedType() as error:
                    # TODO better msg
                    raise NotImplementedError(f"TODO: {error}")
                case unknown:
                    # TODO
                    raise ValueError(
                        f"Invalid encoded data {unknown!r}, "
                        f"must be of type: {av.Packet, av.VideoFrame, av.AudioFrame}"
                    )

    def _clip_time_duration(
        self, time: MPTimeLike | None = None, duration: MPTimeLike | None = None
    ):
        time_min = min(
            (
                stream.start_time
                for stream in self._av_streams.values()
                if stream.start_time is not None
            ),
            default=None,
        )

        if time is not None and time_min is not None:
            time = max(time_min, time)
        
        # TODO FIXME duration cannot be clipped bc its open
        # duration_max = self.duration
        # if duration is not None and duration_max is not None:
        #     duration = min(
        #         duration_max - time if time is not None else duration_max,
        #         duration,
        #     )

        return time, duration

    def _iter_frames(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        time, duration = self._clip_time_duration(time, duration)
        features = self.metadata["features"]
        for frame_time, frames_per_stream in av_iter_frames(
            container=self._av_container,
            streams=set(
                self._av_streams[feature_key] for feature_key in features.keys()
            ),
            time=time,
            duration=duration,
        ):
            frame_data = dict[MPFeatureKeyT, Any]()
            for stream, frame in frames_per_stream.items():
                feature_key = self._av_streams.inverse[stream]
                feature = self.metadata["features"][feature_key]
                feature_data = self._handler.load(frame, data_type=feature["type"])
                frame_data[feature_key] = feature_data
            yield frame_time, frame_data

    @functools.cached_property
    def cache(self):
        r"""
        Cache for this dataset.
        """

        return MPDatasetCacheContext(_dataset=self)

    def items(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        r"""
        Iterate over frames from this dataset in time range `[time, time + duration)`.

        :param time:
            Time at which to get the frame(s) (Unit: seconds).
            TODO If unspecified, read from the beginning of the dataset.
        :param duration:
            Duration of the frame(s) to get (Unit: seconds).
            TODO If unspecified, read until the end of the dataset.
        :returns:
            A generator of (time, data) pairs, where time maps feature keys to the corresponding
            times of the returned frames, and data maps feature keys to the corresponding data.
        """

        for frame_time, frames_per_feature in self.cache.fetch(
            time=time,
            duration=duration,
        ):
            yield frame_time, frames_per_feature

    def get(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        r"""
        Get one or more frames from this dataset in time range `[time, time + duration)`.

        :param time:
            Time at which to get the frame(s) (Unit: seconds).
            TODO If unspecified, read from the beginning of the dataset.
        :param duration:
            Duration of the frame(s) to get (Unit: seconds).
            TODO If unspecified, read until the end of the dataset.
        :returns:
            A tuple of two dicts: (time, data), where data maps feature keys to
            the corresponding data, and time maps feature keys to the corresponding
            times of the returned frames.
        """

        # TODO
        # frames_by_feature = collections.defaultdict(SortedDict)
        frames_by_feature = collections.defaultdict(dict)
        features = self.metadata["features"]

        for frame_time, frames_per_feature in self.cache.fetch(
            time=time,
            duration=duration,
        ):
            for feature_key, frame in frames_per_feature.items():
                frames_by_feature[feature_key][frame_time] = frame

        time_result = {
            feature_key: [
                frame_time for frame_time in frames_by_feature[feature_key].keys()
            ]
            for feature_key, _ in features.items()
        }

        # TODO
        data_result = {
            # TODO use self._handler.load_many instead
            feature_key: [frame for frame in frames_by_feature[feature_key].values()]
            for feature_key, _ in features.items()
        }

        # TODO 
        return time_result, data_result


class MPDatasetCacheContext(Generic[MPFeatureKeyT, MPFeatureDataT]):
    r"""
    Cache context for :obj:`MPDataset`, which can be used to cache frames in memory
    for faster subsequent access.
    """

    def __init__(self, _dataset: MPDataset[MPFeatureKeyT, MPFeatureDataT]):
        self._dataset = _dataset
        self._enabled = False

    @functools.cached_property
    def _cached_frames(self):
        return TimeSegmentCache[dict[MPFeatureKeyT, MPFeatureDataT]]()

    @property
    def enabled(self):
        r"""
        Whether the cache is enabled.
        If enabled, calling :obj:`fetch` will fetch frames into the cache.
        """

        return self._enabled

    @enabled.setter
    def enabled(self, value: bool):
        self._enabled = value
        # TODO FIXME
        self._enabled = False

    def fetch(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        r"""
        Fetch frames from this dataset in time range `[time, time + duration)`
        into the cache and return an iterator of data in the time range.
        If the cache is not enabled, this method simply returns the data
        without caching.

        :param time:
            Time at which to fetch the frame(s) (Unit: seconds).
            TODO If unspecified, fetch from the beginning of the dataset.
        :param duration:
            Duration of the frame(s) to fetch (Unit: seconds).
            TODO If unspecified, fetch until the end of the dataset.
        :returns:
            TODO A generator of (time, data) pairs.
        """

        time, duration = self._dataset._clip_time_duration(time, duration)

        if not self._enabled:
            return self._dataset._iter_frames(time=time, duration=duration)

        # TODO cache when time is known
        if time is None or duration is None:
            return self._dataset._iter_frames(time=time, duration=duration)

        def segment_factory(begin: ..., end: ...):
            # TODO cache miss callback
            # TODO logging
            # print("TODO rm cache miss", (time, duration), float(begin), 
            # float(end - begin), 
            # [(float(i.begin), float(i.end - i.begin)) for i in self._cached_frames._segment_intervaltree])
            begin, begin_duration = self._dataset._clip_time_duration(
                begin, end - begin
            )
            end = begin + begin_duration
            return TimeSegment(
                frames=(
                    TimeFrame(time=time, data=data)
                    for time, data in self._dataset._iter_frames(
                        time=begin, duration=end - begin
                    )
                ),
                begin=begin,
                end=end,
            )

        segment = self._cached_frames.setdefault(
            begin=time,
            end=time + duration,
            segment_factory=segment_factory,
        )

        return (
            (frame.time, frame.data)
            for frame in segment
            if time <= frame.time and frame.time < time + duration
        )

    def evict(
        self,
        time: MPTimeLike | None = None,
        duration: MPTimeLike | None = None,
    ):
        r"""
        Evict frames from the cache in time range `[time, time + duration)`.

        :param time:
            Time at which to evict the frame(s) (Unit: seconds).
            TODO If unspecified, evict from the beginning of the cache.
        :param duration:
            Duration of the frame(s) to evict (Unit: seconds).
            TODO If unspecified, evict until the end of the cache.
        """

        self._cached_frames.delete(
            begin=time,
            end=(None if time is None or duration is None else time + duration),
        )
