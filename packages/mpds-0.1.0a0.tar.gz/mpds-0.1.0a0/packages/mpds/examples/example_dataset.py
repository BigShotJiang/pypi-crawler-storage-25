# SPDX-License-Identifier: Apache-2.0

import io
import fractions

import PIL.Image
import numpy
from mpds.dataset import MPDataset, MPTimeLike


def create_dataset(
    resource: ... = None,
    duration: MPTimeLike = 100,
    time_base: MPTimeLike = fractions.Fraction(1, 1),
):
    if resource is None:
        resource = io.BytesIO()
    with MPDataset.create(
        resource,
        time_base=time_base,
        metadata={
            "features": {
                "sample_image": {
                    "type": "video/h265",
                },
                "sample_json": {
                    "type": "application/json",
                },
                "sample_tensor": {
                    "type": "application/x-npy",
                },
            }
        },
    ) as dataset:
        for i in range(duration):
            dataset.add(
                time=i * time_base,
                data={
                    # "sample_image": PIL.Image.new("RGB", (20, 20)),
                    "sample_json": {"somekey": i},
                    # "sample_tensor": numpy.empty((1,)),
                },
            )

    return resource
