"""Build, deploy, and iterate helpers for Pepper MCP.

Simulator resolution, xcodebuild invocation, app deployment with dylib injection,
and physical device build/install/launch.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
from collections.abc import Callable

from . import pepper_sessions
from .pepper_common import PEPPER_DIR, PORT_DIR, get_config
from .pepper_format import format_look

logger = logging.getLogger(__name__)

# Type alias for the send_command callable expected by deploy_app.
# Signature: async (port, cmd, params=None, timeout=10) -> dict
SendFn = Callable[..., "asyncio.Future[dict]"]

# Per-simulator build state: maps sim UDID -> workspace path used for last build.
# This way multiple Claude sessions building for different sims don't clobber each other.
_sim_build_state: dict[str, str] = {}


def _extract_build_errors(output: str, label: str = "BUILD FAILED") -> str:
    """Extract error details from xcodebuild output.

    For package resolution failures, includes the full block of detail lines
    that follow the error (they don't contain 'error:' themselves).
    For other failures, deduplicates lines containing 'error:'.
    """
    lines = output.split("\n")

    # Check for package resolution failure — grab the error line and all
    # subsequent non-blank lines that form the dependency detail block.
    for i, line in enumerate(lines):
        if "could not resolve package dependencies" in line.lower():
            block = [line.strip()]
            for j in range(i + 1, len(lines)):
                stripped = lines[j].strip()
                if not stripped:
                    break
                block.append(stripped)
            return f"{label}\n" + "\n".join(block[:40])

    # General case: deduplicate error: lines
    error_lines: list[str] = []
    seen: set[str] = set()
    for line in lines:
        if "error:" in line.lower():
            normalized = line.strip()
            if normalized not in seen:
                seen.add(normalized)
                error_lines.append(normalized)
    if error_lines:
        return f"{label}\n" + "\n".join(error_lines[:20])

    # Last resort: tail of output
    return f"{label}\n" + "\n".join(line.strip() for line in lines[-20:])

# Session-sticky simulator: once this MCP server process resolves a simulator,
# it remembers and reuses it for all subsequent calls. Prevents accidentally
# grabbing another Claude session's sim when auto-resolving.
_session_simulator: str | None = None

# Session-level active app context — set by deploy_sim after a successful deploy.
# Other parts of the system (preamble, scripts, adapter tools) use this to resolve
# the correct adapter without depending on .env.
_session_bundle_id: str | None = None
_session_adapter_type: str | None = None


def get_session_context() -> dict:
    """Return the active session's app context."""
    return {
        "simulator": _session_simulator,
        "bundle_id": _session_bundle_id,
        "adapter_type": _session_adapter_type,
    }


# ---------------------------------------------------------------------------
# Simulator helpers
# ---------------------------------------------------------------------------


def _clean_stale_port(simulator: str):
    """Remove stale port file before (re)launch so we wait for the fresh one."""
    port_file = os.path.join(PORT_DIR, f"{simulator}.port")
    if os.path.exists(port_file):
        try:
            os.remove(port_file)
        except OSError:
            pass


def is_sim_booted(udid: str) -> bool:
    """Check if a specific simulator is booted."""
    result = subprocess.run(["xcrun", "simctl", "list", "devices", "booted", "-j"], capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        for _runtime, devices in data.get("devices", {}).items():
            for d in devices:
                if d["udid"] == udid and d.get("state") == "Booted":
                    return True
    except (json.JSONDecodeError, KeyError):
        pass
    return False


def boot_simulator(udid: str):
    """Boot a simulator via Simulator.app (not simctl boot — that causes black screens)."""
    # open -a Simulator connects to the Simulator UI properly
    subprocess.run(["open", "-a", "Simulator", "--args", "-CurrentDeviceUDID", udid], capture_output=True, text=True)
    try:
        subprocess.run(["xcrun", "simctl", "bootstatus", udid, "-b"], capture_output=True, text=True, timeout=120)
    except subprocess.TimeoutExpired:
        pass  # Proceed anyway — bootstatus can hang even when sim is ready


def find_available_iphone() -> str | None:
    """Find the best available iPhone simulator to boot. Returns UDID or None."""
    result = subprocess.run(["xcrun", "simctl", "list", "devices", "available", "-j"], capture_output=True, text=True)
    try:
        data = json.loads(result.stdout)
        # Collect iPhones from iOS runtimes, prefer newest runtime
        iphones = []
        for runtime in sorted(data.get("devices", {}).keys(), reverse=True):
            if "iOS" not in runtime and "iphone" not in runtime.lower():
                continue
            for d in data["devices"][runtime]:
                if d.get("isAvailable") and "iPhone" in d.get("name", ""):
                    iphones.append(d)
        # Prefer Pro models, then newest
        for keyword in ["Pro Max", "Pro", "iPhone"]:
            for d in iphones:
                if keyword in d["name"]:
                    return d["udid"]
        if iphones:
            return iphones[0]["udid"]
    except (json.JSONDecodeError, KeyError):
        pass
    return None


def resolve_simulator(simulator: str | None = None) -> str:
    """Resolve simulator UDID with session awareness.

    Resolution order:
    1. Explicit param (always wins)
    2. Session affinity (reuse previously resolved sim for this process)
    3. Our existing session claim (from pepper_sessions)
    4. Unclaimed sim with Pepper running
    5. Unclaimed booted sim
    6. Boot an existing unbooted iPhone sim
    7. Error if at cap

    Updates heartbeat on every call. Sticky for this MCP server process.
    """
    global _session_simulator

    # Explicit param always wins
    if simulator:
        _session_simulator = simulator
        pepper_sessions.heartbeat(simulator)
        return simulator

    # Session affinity: reuse the sim from a previous call in this session
    if _session_simulator:
        pepper_sessions.heartbeat(_session_simulator)
        return _session_simulator

    # Check if we already own a session from a previous process lifecycle
    owned = pepper_sessions.my_session()
    if owned:
        _session_simulator = owned
        pepper_sessions.heartbeat(owned)
        return owned

    # Clean up stale sessions before searching
    pepper_sessions.cleanup_stale()

    # Find an available simulator (reuse-first, capped)
    # This covers: unclaimed Pepper sims, unclaimed booted sims, unbooted sims
    try:
        udid = pepper_sessions.find_available_simulator()
    except RuntimeError:
        raise  # Propagate cap errors and "no sims" errors

    # If the sim needs booting, boot it
    if not is_sim_booted(udid):
        boot_simulator(udid)

    _session_simulator = udid
    return udid


# ---------------------------------------------------------------------------
# Prebuilt artifact fixup (Xcode 26.3+)
# ---------------------------------------------------------------------------


def _fix_prebuilt_artifacts(derived_data: str) -> None:
    """Copy prebuilt package artifacts from standard DerivedData if missing.

    Xcode 26.3+ may not extract prebuilt modules (e.g. swift-syntax) into
    non-standard DerivedData paths set via -derivedDataPath. When empty
    artifact bundles are detected, this copies populated versions from
    ~/Library/Developer/Xcode/DerivedData/.
    """
    artifacts_dir = os.path.join(derived_data, "SourcePackages", "artifacts")
    if not os.path.isdir(artifacts_dir):
        return

    # Find artifact packages with empty directories (resolved but not extracted)
    empty_pkgs = []
    for name in os.listdir(artifacts_dir):
        pkg_path = os.path.join(artifacts_dir, name)
        if os.path.isdir(pkg_path) and not any(f for _, _, files in os.walk(pkg_path) for f in files):
            empty_pkgs.append(name)

    if not empty_pkgs:
        return

    # Search standard DerivedData for populated copies
    std_dd = os.path.expanduser("~/Library/Developer/Xcode/DerivedData")
    if not os.path.isdir(std_dd):
        return

    for entry in os.listdir(std_dd):
        std_artifacts = os.path.join(std_dd, entry, "SourcePackages", "artifacts")
        if not os.path.isdir(std_artifacts):
            continue
        for pkg_name in list(empty_pkgs):
            src = os.path.join(std_artifacts, pkg_name)
            if not os.path.isdir(src):
                continue
            if any(f for _, _, files in os.walk(src) for f in files):
                dst = os.path.join(artifacts_dir, pkg_name)
                shutil.rmtree(dst)
                shutil.copytree(src, dst)
                empty_pkgs.remove(pkg_name)
        if not empty_pkgs:
            break


# ---------------------------------------------------------------------------
# Simulator build & deploy
# ---------------------------------------------------------------------------


async def build_app(
    workspace: str | None = None, scheme: str | None = None, simulator: str | None = None
) -> tuple[bool, str]:
    """Build the app. Returns (success, message). Message includes errors on failure."""
    cfg = get_config()
    ws = workspace
    sch = scheme or cfg["scheme"]
    wrapper = cfg["xcodebuild_wrapper"]

    if not ws:
        return False, "workspace is required — pass the absolute path to the .xcworkspace"
    if not sch:
        return False, "No scheme configured. Set APP_SCHEME in pepper/.env"
    if not os.path.exists(ws):
        return False, f"Workspace not found: {ws}"

    # Resolve simulator for -destination (also auto-boots if needed)
    try:
        sim_udid = resolve_simulator(simulator)
    except RuntimeError as e:
        return False, str(e)

    # Ensure simulator is booted before building (xcodebuild needs a booted destination)
    if not is_sim_booted(sim_udid):
        boot_simulator(sim_udid)

    cmd = [
        wrapper,
        "-workspace",
        ws,
        "-scheme",
        sch,
        "-configuration",
        "Debug",
        "-destination",
        f"platform=iOS Simulator,id={sim_udid}",
        "-skipPackagePluginValidation",
        "-skipMacroValidation",
        "DEBUG_INFORMATION_FORMAT=dwarf-with-dsym",
        "build",
    ]

    # If wrapper doesn't exist, fall back to raw xcodebuild with manual DerivedData isolation
    custom_derived_data = None
    if not os.path.exists(wrapper):
        cmd[0] = "xcodebuild"
        # Add worktree-aware DerivedData path manually
        ws_dir = os.path.dirname(os.path.abspath(ws))
        worktree_name = os.path.basename(ws_dir)
        custom_derived_data = f"/tmp/DerivedData-{worktree_name}"
        cmd.extend(["-derivedDataPath", custom_derived_data])

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace")

    if proc.returncode == 0:
        _sim_build_state[sim_udid] = ws  # remember workspace per sim for deploy
        if custom_derived_data:
            _fix_prebuilt_artifacts(custom_derived_data)
        lines = output.strip().split("\n")
        summary = "\n".join(lines[-3:]) if len(lines) > 3 else output.strip()
        return True, f"BUILD SUCCEEDED\n{summary}"
    else:
        return False, _extract_build_errors(output, "BUILD FAILED")


def _get_binary_minos(binary_path: str) -> str | None:
    """Extract the minimum OS version (minos) from a Mach-O binary via otool."""
    try:
        result = subprocess.run(
            ["xcrun", "otool", "-l", binary_path],
            capture_output=True, text=True, timeout=10,
        )
        if result.returncode != 0:
            return None
        # Look for LC_BUILD_VERSION minos field: "minos 18.0"
        for match in re.finditer(r"minos\s+([\d.]+)", result.stdout):
            return match.group(1)
        # Fallback: LC_VERSION_MIN_IPHONEOS "version 17.0"
        for match in re.finditer(r"version\s+([\d.]+)", result.stdout):
            return match.group(1)
    except (subprocess.TimeoutExpired, OSError):
        pass
    return None


def _check_minos_compat(app_path: str, dylib_path: str) -> str | None:
    """Return a warning string if dylib minos < app minos, else None."""
    # Find the app's main binary
    app_name = os.path.splitext(os.path.basename(app_path))[0]
    app_binary = os.path.join(app_path, app_name)
    if not os.path.exists(app_binary):
        return None

    app_minos = _get_binary_minos(app_binary)
    dylib_binary = os.path.join(dylib_path, "Pepper") if os.path.isdir(dylib_path) else dylib_path
    dylib_minos = _get_binary_minos(dylib_binary)

    if not app_minos or not dylib_minos:
        return None

    app_parts = [int(x) for x in app_minos.split(".")]
    dylib_parts = [int(x) for x in dylib_minos.split(".")]

    if dylib_parts < app_parts:
        return (
            f"Dylib minos ({dylib_minos}) < app minos ({app_minos}). "
            f"iOS 26.3+ simulators silently reject injected dylibs with a lower minos than the host app. "
            f"Rebuild with: IOS_TARGET_VERSION={app_minos} make build"
        )
    return None


def _dylib_is_stale(dylib_path: str) -> bool:
    """Check if the dylib is older than any source file in dylib/."""
    if not os.path.exists(dylib_path):
        return True
    dylib_dir = os.path.join(PEPPER_DIR, "dylib")
    if not os.path.isdir(dylib_dir):
        return False  # Not a dev install — no source to compare
    dylib_mtime = os.path.getmtime(dylib_path)
    for root, _dirs, files in os.walk(dylib_dir):
        for f in files:
            if f.endswith((".swift", ".m", ".h", ".c")):
                src_mtime = os.path.getmtime(os.path.join(root, f))
                if src_mtime > dylib_mtime:
                    return True
    # Also check adapter source if present
    cfg = get_config()
    adapter_type = cfg.get("adapter_type", "generic")
    if adapter_type != "generic":
        from .pepper_common import resolve_adapter_dir
        adapter_dir = resolve_adapter_dir(adapter_type)
        if adapter_dir:
            for f in os.listdir(adapter_dir):
                if f.endswith(".swift"):
                    src_mtime = os.path.getmtime(os.path.join(adapter_dir, f))
                    if src_mtime > dylib_mtime:
                        return True
    return False


def _rebuild_dylib(ios_target_version: str | None = None) -> tuple[bool, str]:
    """Rebuild the Pepper dylib. Returns (success, message)."""
    build_script = os.path.join(PEPPER_DIR, "tools", "build-dylib.sh")
    if not os.path.exists(build_script):
        return False, "build-dylib.sh not found — not a dev install"
    env = os.environ.copy()
    if ios_target_version:
        env["IOS_TARGET_VERSION"] = ios_target_version
    result = subprocess.run(
        ["bash", build_script],
        capture_output=True, text=True, timeout=120,
        cwd=PEPPER_DIR, env=env,
    )
    if result.returncode == 0:
        target_msg = f" (IOS_TARGET_VERSION={ios_target_version})" if ios_target_version else ""
        return True, f"Dylib rebuilt{target_msg}"
    return False, f"Dylib rebuild failed:\n{result.stderr[-500:]}"


async def deploy_app(
    simulator: str,
    send_fn: SendFn,
    bundle_id: str | None = None,
    dylib_path: str | None = None,
    install_path: str | None = None,
    workspace: str | None = None,
    skip_privacy: bool = False,
) -> str:
    """Deploy (terminate + install + launch with Pepper). Returns status message + screen."""
    cfg = get_config()
    bid = bundle_id
    dylib = dylib_path or cfg["dylib_path"]

    # Auto-detect bundle ID from the built .app.
    if not bid:
        app_to_check = install_path
        if not app_to_check:
            ws = workspace or _sim_build_state.get(simulator)
            if ws:
                app_to_check = find_built_app(workspace=ws)
                if app_to_check:
                    install_path = app_to_check
        if app_to_check:
            bid = _bundle_id_from_app(app_to_check)

    bid = bid or cfg["bundle_id"]

    if not bid:
        return "No bundle ID configured. Set APP_BUNDLE_ID in pepper/.env"
    if not os.path.exists(dylib):
        try:
            from .dylib_fetch import ensure_dylib
            dylib = ensure_dylib()
        except Exception as e:
            return f"Pepper dylib not found at {dylib} and auto-download failed: {e}\nRun `make build` in pepper dir or check your pepper-ios version."

    # Auto-rebuild dylib if source files are newer than the binary.
    # This ensures agents in other worktrees pick up Pepper fixes without
    # having to manually run `make build`.
    if _dylib_is_stale(dylib):
        logger.info("Dylib is stale — rebuilding before deploy")
        ok, msg = _rebuild_dylib()
        if not ok:
            return f"Dylib auto-rebuild failed: {msg}"
        logger.info("Dylib rebuilt successfully")

    # Session guard: refuse to deploy if another *live* session owns this simulator.
    # If the claiming PID is dead, the session is stale even if the app port is
    # still alive — the MCP server that owned it is gone (e.g. after /mcp reconnect).
    session = pepper_sessions.is_claimed(simulator)
    if session and session.get("pid") != os.getpid():
        claiming_pid = session.get("pid", 0)
        if claiming_pid > 0 and pepper_sessions._is_pid_alive(claiming_pid):
            label = session.get("label", "")
            label_str = f" ({label})" if label else ""
            return (
                f"Simulator {simulator} is in use by another Pepper session "
                f"(PID {claiming_pid}{label_str}, claimed at {session.get('claimed_at', '?')}). "
                f"Use a different simulator or wait for that session to finish.\n"
                f"Tip: use `simulator action=list` to see all available simulators."
            )
        # Claiming PID is dead — take over the stale claim
        logger.info("Taking over stale session for %s (PID %d is dead)", simulator, claiming_pid)
        pepper_sessions._remove_session(simulator)

    # Ensure simulator is booted
    if not is_sim_booted(simulator):
        boot_simulator(simulator)

    # Clean stale port file so we wait for the fresh Pepper instance
    _clean_stale_port(simulator)

    # Terminate existing app
    subprocess.run(["xcrun", "simctl", "terminate", simulator, bid], capture_output=True, text=True)

    # Auto-find latest built app if no install_path given.
    # Use the workspace from the last build targeting this sim (handles worktrees correctly).
    if not install_path:
        ws = workspace or _sim_build_state.get(simulator)
        install_path = find_built_app(workspace=ws)

    # Install if we have an app path
    if install_path and os.path.exists(install_path):
        result = subprocess.run(["xcrun", "simctl", "install", simulator, install_path], capture_output=True, text=True)
        if result.returncode != 0:
            return f"Install failed: {result.stderr.strip()}"

    # Grant common privacy permissions (opt-out with skip_privacy=True).
    # Only grant what most apps need — bulk "grant all" triggers every iOS
    # subsystem to initialize simultaneously, causing memory spikes and crashes.
    if not skip_privacy:
        for service in ["location-always", "photos", "contacts", "camera", "microphone"]:
            subprocess.run(
                ["xcrun", "simctl", "privacy", simulator, "grant", service, bid],
                capture_output=True, text=True,
            )

    # Enable VoiceOver accessibility flag so SwiftUI apps populate labels.
    # Many apps (Ice Cubes, etc.) only compute accessibilityLabel when VoiceOver is on.
    subprocess.run(
        [
            "xcrun",
            "simctl",
            "spawn",
            simulator,
            "defaults",
            "write",
            "com.apple.Accessibility",
            "VoiceOverTouchEnabled",
            "-bool",
            "true",
        ],
        capture_output=True,
        text=True,
    )

    # Check for minos mismatch — auto-rebuild if needed
    if install_path and os.path.exists(install_path):
        dylib_for_check = dylib
        minos_warning = _check_minos_compat(install_path, dylib_for_check)
        if minos_warning:
            # Extract app minos and auto-rebuild
            app_name = os.path.splitext(os.path.basename(install_path))[0]
            app_binary = os.path.join(install_path, app_name)
            app_minos = _get_binary_minos(app_binary) if os.path.exists(app_binary) else None
            if app_minos:
                logger.info("Auto-rebuilding dylib with IOS_TARGET_VERSION=%s", app_minos)
                ok, msg = _rebuild_dylib(ios_target_version=app_minos)
                if not ok:
                    return f"Deploy blocked: {minos_warning}\nAuto-rebuild failed: {msg}"
                logger.info("Dylib auto-rebuilt for minos %s", app_minos)
            else:
                return f"Deploy blocked: {minos_warning}"

    # DYLD_INSERT_LIBRARIES must be passed via SIMCTL_CHILD_ at exec() time.
    # launchctl setenv silently drops DYLD_INSERT_LIBRARIES (restricted var) on
    # iOS 18.4+ / 26.3+ simulators — confirmed: setenv succeeds but getenv returns empty.
    # Non-DYLD_ vars work fine via launchctl setenv (PEPPER_ADAPTER, PEPPER_SIM_UDID, etc.).
    # Resolve adapter type from the bundle ID (supports multi-app).
    # Falls back to .env APP_ADAPTER_TYPE for single-app setups.
    adapter_type = cfg.get("adapter_type", "generic")
    try:
        from .pepper_common import adapter_for_bundle_id
        match = adapter_for_bundle_id(bid)
        if match:
            adapter_type = match[0]
    except (ImportError, Exception):
        pass

    pepper_vars = {
        "PEPPER_ADAPTER": adapter_type,
        "PEPPER_SIM_UDID": simulator,
    }
    if not skip_privacy:
        pepper_vars["PEPPER_SKIP_PERMISSIONS"] = "1"

    for key, val in pepper_vars.items():
        subprocess.run(
            ["xcrun", "simctl", "spawn", simulator, "launchctl", "setenv", key, val],
            capture_output=True, text=True,
        )

    # Pass all vars (including DYLD_INSERT_LIBRARIES) via SIMCTL_CHILD_ at exec time.
    # This is the only path that actually injects the dylib — launchctl-inherited
    # DYLD_INSERT_LIBRARIES is stripped by dyld's restricted-env check before it runs.
    launch_env = os.environ.copy()
    # Strip any inherited SIMCTL_CHILD_ vars — stale values from the parent process
    # (e.g. baked into launchd session or .zshrc) override what we set here and break
    # injection.  Only our explicit vars below should reach the simulator.
    for k in [k for k in launch_env if k.startswith("SIMCTL_CHILD_")]:
        del launch_env[k]
    launch_env["SIMCTL_CHILD_DYLD_INSERT_LIBRARIES"] = dylib
    for key, val in pepper_vars.items():
        launch_env[f"SIMCTL_CHILD_{key}"] = val

    result = subprocess.run(["xcrun", "simctl", "launch", simulator, bid], capture_output=True, text=True, env=launch_env)

    # Clean up non-DYLD_ vars from launchd so they don't leak to other apps
    for key in pepper_vars:
        subprocess.run(
            ["xcrun", "simctl", "spawn", simulator, "launchctl", "unsetenv", key],
            capture_output=True, text=True,
        )

    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "not booted" in stderr.lower():
            return f"Launch failed: simulator {simulator} is not booted. Try again or boot it manually."
        return f"Launch failed: {stderr}"

    pid = result.stdout.strip().split(":")[-1].strip() if ":" in result.stdout else result.stdout.strip()

    # Wait for Pepper to connect (10s timeout — cold launches need more time)
    port_file = os.path.join(PORT_DIR, f"{simulator}.port")
    for _attempt in range(20):
        await asyncio.sleep(0.5)
        if os.path.exists(port_file):
            try:
                port = int(open(port_file).read().strip())
                resp = await send_fn(port, "ping", timeout=2)
                if resp.get("status") == "ok":
                    await asyncio.sleep(1)  # let UI settle
                    look_resp = await send_fn(port, "look", {}, timeout=30)
                    screen_summary = (
                        format_look(look_resp) if look_resp.get("status") == "ok" else "(look not ready yet)"
                    )
                    # Reset monitor state so stale data from previous session doesn't leak
                    from .mcp_server import reset_monitor_state
                    reset_monitor_state()
                    # Claim this simulator for our session
                    pepper_sessions.claim_simulator(simulator, bundle_id=bid, port=port)
                    # Update session context so preamble/scripts/adapter resolve correctly
                    global _session_bundle_id, _session_adapter_type
                    _session_bundle_id = bid
                    _session_adapter_type = adapter_type
                    return f"Deployed to {simulator} (PID {pid}, port {port}). Pepper is connected.\n--- Screen ---\n{screen_summary}"
            except (TimeoutError, OSError, ValueError):
                pass

    return f"App launched (PID {pid}) but Pepper didn't respond within 10s. Check dylib injection. Port file exists: {os.path.exists(port_file)}"


def _bundle_id_from_app(app_path: str) -> str | None:
    """Read CFBundleIdentifier from an .app's Info.plist."""
    plist = os.path.join(app_path, "Info.plist")
    if not os.path.exists(plist):
        return None
    try:
        result = subprocess.run(
            ["plutil", "-extract", "CFBundleIdentifier", "raw", plist],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return None


def find_built_app(workspace: str | None = None, platform: str = "iphonesimulator") -> str | None:
    """Find the most recently built .app in DerivedData based on workspace path.
    platform: 'iphonesimulator' or 'iphoneos'"""
    ws = workspace
    if not ws:
        return None

    ws_dir = os.path.dirname(os.path.abspath(ws))
    worktree_name = os.path.basename(ws_dir)
    derived_data = f"/tmp/DerivedData-{worktree_name}"
    app_dir = os.path.join(derived_data, "Build", "Products", f"Debug-{platform}")

    if os.path.isdir(app_dir):
        apps = []
        for item in os.listdir(app_dir):
            if item.endswith(".app"):
                full_path = os.path.join(app_dir, item)
                try:
                    mtime = os.path.getmtime(full_path)
                    apps.append((mtime, full_path))
                except OSError:
                    pass
        if apps:
            # Return most recently modified .app
            apps.sort(reverse=True)
            return apps[0][1]
    return None


# ---------------------------------------------------------------------------
# Physical device build & deploy
# ---------------------------------------------------------------------------


async def verify_device_connected(devicectl_uuid: str) -> tuple[bool, str]:
    """Check if a physical device is connected via devicectl. Returns (connected, message)."""
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        result = subprocess.run(
            ["xcrun", "devicectl", "list", "devices", "-j", tmp_path], capture_output=True, text=True, timeout=15
        )
        if result.returncode != 0:
            return False, f"devicectl list failed: {result.stderr.strip()}"
        with open(tmp_path) as f:
            data = json.load(f)
        devices = data.get("result", {}).get("devices", [])
        for dev in devices:
            if dev.get("identifier") == devicectl_uuid:
                state = dev.get("connectionProperties", {}).get("transportType", "unknown")
                name = dev.get("deviceProperties", {}).get("name", "unknown")
                return True, f"Connected: {name} ({state})"
        return False, f"Device {devicectl_uuid} not found. Is it connected?"
    except (json.JSONDecodeError, KeyError) as e:
        return False, f"Failed to parse devicectl output: {e}"
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)


async def build_app_device(
    workspace: str | None = None, scheme: str | None = None, xcodebuild_id: str | None = None
) -> tuple[bool, str]:
    """Build the app for a physical device. Returns (success, message)."""
    cfg = get_config()
    ws = workspace
    sch = scheme or cfg["scheme"]
    wrapper = cfg["xcodebuild_wrapper"]
    device_id = xcodebuild_id or cfg["device_xcodebuild_id"]

    if not ws:
        return False, "workspace is required — pass the absolute path to the .xcworkspace"
    if not sch:
        return False, "No scheme configured. Set APP_SCHEME in pepper/.env"
    if not os.path.exists(ws):
        return False, f"Workspace not found: {ws}"
    if not device_id:
        return False, "No device xcodebuild ID configured. Set DEVICE_XCODEBUILD_ID in pepper/.env"

    cmd = [
        wrapper,
        "-workspace",
        ws,
        "-scheme",
        sch,
        "-configuration",
        "Debug",
        "-destination",
        f"platform=iOS,id={device_id}",
        "-skipPackagePluginValidation",
        "-skipMacroValidation",
        "DEBUG_INFORMATION_FORMAT=dwarf-with-dsym",
        "build",
    ]

    # Fall back to raw xcodebuild with manual DerivedData isolation
    custom_derived_data = None
    if not os.path.exists(wrapper):
        cmd[0] = "xcodebuild"
        ws_dir = os.path.dirname(os.path.abspath(ws))
        worktree_name = os.path.basename(ws_dir)
        custom_derived_data = f"/tmp/DerivedData-{worktree_name}"
        cmd.extend(["-derivedDataPath", custom_derived_data])

    proc = await asyncio.create_subprocess_exec(
        *cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace")

    if proc.returncode == 0:
        if custom_derived_data:
            _fix_prebuilt_artifacts(custom_derived_data)
        lines = output.strip().split("\n")
        summary = "\n".join(lines[-3:]) if len(lines) > 3 else output.strip()
        return True, f"BUILD SUCCEEDED (device)\n{summary}"
    else:
        return False, _extract_build_errors(output, "BUILD FAILED (device)")


async def install_on_device(devicectl_uuid: str, app_path: str) -> tuple[bool, str]:
    """Install app on physical device via devicectl."""
    proc = await asyncio.create_subprocess_exec(
        "xcrun",
        "devicectl",
        "device",
        "install",
        "app",
        "--device",
        devicectl_uuid,
        app_path,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace").strip()
    if proc.returncode == 0:
        return True, "Installed on device"
    return False, f"Install failed: {output}"


async def launch_on_device(devicectl_uuid: str, bundle_id: str) -> tuple[bool, str]:
    """Launch app on physical device via devicectl."""
    proc = await asyncio.create_subprocess_exec(
        "xcrun",
        "devicectl",
        "device",
        "process",
        "launch",
        "--device",
        devicectl_uuid,
        "--terminate-existing",
        bundle_id,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.STDOUT,
    )
    stdout, _ = await proc.communicate()
    output = stdout.decode("utf-8", errors="replace").strip()
    if proc.returncode == 0:
        return True, "Launched on device"
    return False, f"Launch failed: {output}"
