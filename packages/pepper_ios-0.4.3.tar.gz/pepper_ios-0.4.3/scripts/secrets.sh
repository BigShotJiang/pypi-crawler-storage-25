#!/usr/bin/env bash
# secrets.sh — manage agent credentials in macOS Keychain.
#
# Usage:
#   secrets.sh migrate          # Move PATs/passwords from .env to Keychain
#   secrets.sh store N PAT PWD  # Store agent N's PAT and password
#   secrets.sh get N pat|password  # Retrieve a single secret
#   secrets.sh list             # Show which agents have Keychain entries
#   secrets.sh verify           # Check all agents in .env have Keychain entries
#
# Run once per Mac. Credentials stay in Keychain across repo clones.

set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ENV_FILE="$REPO_ROOT/.env"
SERVICE_PAT="pepper-agent-pat"
SERVICE_PWD="pepper-agent-pwd"

store_secret() {
  local account="$1" service="$2" value="$3"
  # -U updates if exists, creates if not
  security add-generic-password -a "$account" -s "$service" -w "$value" -U 2>/dev/null
}

get_secret() {
  local account="$1" service="$2"
  security find-generic-password -a "$account" -s "$service" -w 2>/dev/null || echo ""
}

cmd_store() {
  local n="$1" pat="$2" pwd="${3:-}"
  store_secret "agent-$n" "$SERVICE_PAT" "$pat"
  echo "Stored PAT for agent-$n"
  if [ -n "$pwd" ]; then
    store_secret "agent-$n" "$SERVICE_PWD" "$pwd"
    echo "Stored password for agent-$n"
  fi
}

cmd_get() {
  local n="$1" type="$2"
  case "$type" in
    pat)      get_secret "agent-$n" "$SERVICE_PAT" ;;
    password) get_secret "agent-$n" "$SERVICE_PWD" ;;
    *)        echo "Unknown type: $type (use pat or password)" >&2; exit 1 ;;
  esac
}

cmd_list() {
  echo "Keychain entries:"
  for n in $(seq 1 20); do
    pat=$(get_secret "agent-$n" "$SERVICE_PAT")
    if [ -n "$pat" ]; then
      echo "  agent-$n: PAT=${pat:0:8}..."
    fi
  done
}

cmd_migrate() {
  [ -f "$ENV_FILE" ] || { echo "No .env found at $ENV_FILE"; exit 1; }

  local count=0
  for n in $(seq 1 20); do
    pat_key="AGENT${n}_GITHUB_PAT"
    pwd_key="AGENT${n}_GITHUB_PASS""WORD"
    pat=$(grep "^${pat_key}=" "$ENV_FILE" 2>/dev/null | cut -d= -f2 || true)
    pwd=$(grep "^${pwd_key}=" "$ENV_FILE" 2>/dev/null | cut -d= -f2 || true)

    if [ -n "$pat" ]; then
      store_secret "agent-$n" "$SERVICE_PAT" "$pat"
      echo "Migrated agent-$n PAT"
      count=$((count + 1))
    fi
    if [ -n "$pwd" ]; then
      store_secret "agent-$n" "$SERVICE_PWD" "$pwd"
      echo "Migrated agent-$n password"
    fi
  done

  if [ "$count" -eq 0 ]; then
    echo "No agent PATs found in .env"
    exit 0
  fi

  echo ""
  echo "$count agent(s) migrated to Keychain."
  echo ""
  echo "Next steps:"
  echo "  1. Verify: $0 list"
  echo "  2. Remove AGENT*_GITHUB_PAT and AGENT*_GITHUB_PASSWORD lines from .env"
  echo "     Keep AGENT*_GITHUB_USERNAME and AGENT*_GITHUB_EMAIL (non-sensitive)"
}

cmd_verify() {
  [ -f "$ENV_FILE" ] || { echo "No .env found"; exit 1; }

  local ok=0 missing=0
  for n in $(seq 1 20); do
    user=$(grep "^AGENT${n}_GITHUB_USERNAME=" "$ENV_FILE" 2>/dev/null | cut -d= -f2 || true)
    [ -z "$user" ] && continue

    pat=$(get_secret "agent-$n" "$SERVICE_PAT")
    if [ -n "$pat" ]; then
      echo "  agent-$n ($user): OK"
      ok=$((ok + 1))
    else
      echo "  agent-$n ($user): MISSING PAT"
      missing=$((missing + 1))
    fi
  done

  echo ""
  echo "$ok OK, $missing missing"
  [ "$missing" -eq 0 ] || exit 1
}

case "${1:-help}" in
  store)   cmd_store "${2:?agent number}" "${3:?PAT}" "${4:-}" ;;
  get)     cmd_get "${2:?agent number}" "${3:?type: pat|password}" ;;
  list)    cmd_list ;;
  migrate) cmd_migrate ;;
  verify)  cmd_verify ;;
  *)
    echo "Usage: $0 {migrate|store|get|list|verify}"
    echo ""
    echo "  migrate          Move PATs/passwords from .env → Keychain"
    echo "  store N PAT PWD  Store agent N's secrets"
    echo "  get N pat|pwd    Retrieve a secret"
    echo "  list             Show Keychain entries"
    echo "  verify           Check all .env agents have Keychain entries"
    ;;
esac
