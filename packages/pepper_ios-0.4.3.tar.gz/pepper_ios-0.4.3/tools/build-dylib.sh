#!/bin/bash
set -euo pipefail

# Build Pepper as a dynamic framework for iOS Simulator or device.
#
# Output: build/Pepper.framework/Pepper (Mach-O dylib)
#
# Usage:
#   ./tools/build-dylib.sh              # build for current sim arch
#   ./tools/build-dylib.sh --clean      # clean + build
#   ./tools/build-dylib.sh --device     # build for physical iOS device (arm64)
#   ./tools/build-dylib.sh --output DIR # override framework output directory

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CONTROL_DIR="$PROJECT_DIR/dylib"

# Use worktree-local build dir to avoid collisions with concurrent builds.
# git rev-parse --show-toplevel gives the worktree root (not the main repo).
WORKTREE_ROOT=$(git -C "$PROJECT_DIR" rev-parse --show-toplevel 2>/dev/null || echo "$PROJECT_DIR")
BUILD_DIR="$WORKTREE_ROOT/build/dylib"
FRAMEWORK_DIR="$WORKTREE_ROOT/build/Pepper.framework"

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
BOLD='\033[1m'
NC='\033[0m'

info()    { echo -e "${BLUE}dylib:${NC} $*"; }
success() { echo -e "${GREEN}dylib:${NC} $*"; }
error()   { echo -e "${RED}dylib:${NC} $*" >&2; }

# --- Options ---
CLEAN=""
PLATFORM="simulator"
CUSTOM_OUTPUT=""
while [[ $# -gt 0 ]]; do
    case "$1" in
        --clean)  CLEAN=1; shift ;;
        --device) PLATFORM="device"; shift ;;
        --output) CUSTOM_OUTPUT="$2"; shift 2 ;;
        *) shift ;;
    esac
done

if [ -n "$CUSTOM_OUTPUT" ]; then
    BUILD_DIR="$CUSTOM_OUTPUT/dylib"
    FRAMEWORK_DIR="$CUSTOM_OUTPUT/Pepper.framework"
fi

# --- Build lock ---
# Serialize concurrent builds sharing the same worktree to prevent
# "input file was modified during the build" Swift compiler errors.
# Uses perl flock since macOS doesn't ship flock(1).
BUILD_LOCK="/tmp/pepper-build-$(echo "$WORKTREE_ROOT" | md5 -q).lock"
exec 9>"$BUILD_LOCK"
_try_lock() { perl -e 'use Fcntl qw(:flock); open(FH, ">&=9") or die; flock(FH, LOCK_EX|LOCK_NB) or exit 1' 2>/dev/null; }
_wait_lock() { perl -e 'use Fcntl qw(:flock); open(FH, ">&=9") or die; flock(FH, LOCK_EX) or die' 2>/dev/null; }
if ! _try_lock; then
    info "Another build is running for this worktree — waiting for lock..."
    _wait_lock
fi
# Lock is held until this script exits (fd 9 closes automatically).

if [ -n "$CLEAN" ]; then
    info "Cleaning build directory..."
    rm -rf "$BUILD_DIR" "$FRAMEWORK_DIR"
fi

# --- Detect architecture ---
# Apple Silicon Macs run arm64 simulators; Intel runs x86_64
ARCH=$(uname -m)
# Auto-detect iOS SDK major version so we compile against the same APIs
# the host Xcode ships. This prevents "deprecated in iOS 26" errors from
# being discovered only on machines running a newer Xcode.
if [ -z "${IOS_TARGET_VERSION:-}" ]; then
    SDK_VER=$(xcrun --sdk iphonesimulator --show-sdk-version 2>/dev/null || echo "18.0")
    IOS_TARGET_VERSION="${SDK_VER%%.*}.0"
fi
if [ "$PLATFORM" = "device" ]; then
    TARGET="arm64-apple-ios${IOS_TARGET_VERSION}"
    SDK_NAME="iphoneos"
    ARCH="arm64"
else
    if [ "$ARCH" = "arm64" ]; then
        TARGET="arm64-apple-ios${IOS_TARGET_VERSION}-simulator"
    else
        TARGET="x86_64-apple-ios${IOS_TARGET_VERSION}-simulator"
    fi
    SDK_NAME="iphonesimulator"
fi

# --- Find SDK ---
SDK_PATH=$(xcrun --sdk "$SDK_NAME" --show-sdk-path)
info "SDK: $SDK_PATH"
info "Target: $TARGET"

# --- Load .env for adapter config ---
# Source the file in a subshell so it handles quoting, spaces, and comments natively
ENV_FILE="$PROJECT_DIR/.env"
ADAPTER_PATH=""
ADAPTER_TYPE=""
if [ -f "$ENV_FILE" ]; then
    ADAPTER_PATH=$(set -a && source "$ENV_FILE" 2>/dev/null && echo "$ADAPTER_PATH")
    ADAPTER_TYPE=$(set -a && source "$ENV_FILE" 2>/dev/null && echo "${APP_ADAPTER_TYPE:-}")
fi

# --- Resolve adapter from ~/.pepper/adapters/ (overrides ADAPTER_PATH) ---
ADAPTERS_DIR="$HOME/.pepper/adapters"
if [ -n "$ADAPTER_TYPE" ] && [ "$ADAPTER_TYPE" != "generic" ]; then
    CANDIDATE="$ADAPTERS_DIR/$ADAPTER_TYPE"
    if [ -d "$CANDIDATE" ] && [ -f "$CANDIDATE/config.json" ]; then
        ADAPTER_PATH="$CANDIDATE"
    fi
fi

# --- Gather sources ---
SOURCE_DIRS=("$CONTROL_DIR")
HAS_ADAPTER=""
if [ -n "$ADAPTER_PATH" ] && [ -d "$ADAPTER_PATH" ]; then
    SOURCE_DIRS+=("$ADAPTER_PATH")
    info "Adapter: $ADAPTER_PATH"

    # Generate registration shim — wires the adapter's bootstrap into the loader
    if [ -n "$ADAPTER_TYPE" ]; then
        BOOTSTRAP_MATCHES=$(grep -rl 'static func registerAdapter' "$ADAPTER_PATH"/*.swift 2>/dev/null)
        BOOTSTRAP_COUNT=$(echo "$BOOTSTRAP_MATCHES" | grep -c . 2>/dev/null || true)
        if [ "$BOOTSTRAP_COUNT" -gt 1 ]; then
            error "Multiple files contain registerAdapter — expected exactly one:"
            echo "$BOOTSTRAP_MATCHES" >&2
            exit 1
        fi
        BOOTSTRAP_CLASS=$(echo "$BOOTSTRAP_MATCHES" | head -1 | xargs -I{} basename {} .swift 2>/dev/null)
        if [ -n "$BOOTSTRAP_CLASS" ]; then
            HAS_ADAPTER=1
            mkdir -p "$BUILD_DIR"
            cat > "$BUILD_DIR/_AdapterShim.swift" <<SHIM
// @generated by build-dylib.sh
enum _PepperAdapterShim {
    static func register(adapterType: String) {
        switch adapterType {
        case "$ADAPTER_TYPE": $BOOTSTRAP_CLASS.registerAdapter()
        default: break
        }
    }
}
SHIM
        fi
    fi
fi

SWIFT_FILES=()
C_FILES=()
OBJC_FILES=()
for src_dir in "${SOURCE_DIRS[@]}"; do
    while IFS= read -r -d '' file; do
        SWIFT_FILES+=("$file")
    done < <(find "$src_dir" -name '*.swift' -print0)
    while IFS= read -r -d '' file; do
        C_FILES+=("$file")
    done < <(find "$src_dir" -name '*.c' -print0)
    while IFS= read -r -d '' file; do
        OBJC_FILES+=("$file")
    done < <(find "$src_dir" -name '*.m' -print0)
done

# Include build-generated adapter shim if present
if [ -f "$BUILD_DIR/_AdapterShim.swift" ]; then
    SWIFT_FILES+=("$BUILD_DIR/_AdapterShim.swift")
fi

SWIFT_COUNT=${#SWIFT_FILES[@]}
C_COUNT=$(( ${#C_FILES[@]} + ${#OBJC_FILES[@]} ))
info "Compiling $SWIFT_COUNT Swift + $C_COUNT C/ObjC files..."

# --- Create output dirs ---
mkdir -p "$BUILD_DIR" "$FRAMEWORK_DIR/Modules/Pepper.swiftmodule"

# --- Step 1: Compile C/ObjC sources to object files (parallel) ---
C_OBJECTS=()
COMPILE_PIDS=()

for c_file in "${C_FILES[@]}"; do
    basename=$(basename "$c_file" .c)
    obj="$BUILD_DIR/${basename}.o"
    xcrun -sdk "$SDK_NAME" clang \
        -target "$TARGET" \
        -isysroot "$SDK_PATH" \
        -c "$c_file" \
        -o "$obj" &
    COMPILE_PIDS+=($!)
    C_OBJECTS+=("$obj")
done

for m_file in "${OBJC_FILES[@]}"; do
    basename=$(basename "$m_file" .m)
    obj="$BUILD_DIR/${basename}_objc.o"
    xcrun -sdk "$SDK_NAME" clang \
        -target "$TARGET" \
        -isysroot "$SDK_PATH" \
        -fobjc-arc \
        -c "$m_file" \
        -o "$obj" &
    COMPILE_PIDS+=($!)
    C_OBJECTS+=("$obj")
done

# Wait for all parallel C/ObjC compilations
for pid in "${COMPILE_PIDS[@]}"; do
    wait "$pid" || { error "C/ObjC compilation failed"; exit 1; }
done

# --- Find bridging header (if any .h files exist alongside .m files) ---
BRIDGING_HEADER=""
for m_file in "${OBJC_FILES[@]}"; do
    h_file="${m_file%.m}.h"
    if [ -f "$h_file" ]; then
        # Use a combined bridging header that imports all ObjC headers
        BRIDGING_HEADER="$BUILD_DIR/Pepper-Bridging-Header.h"
        break
    fi
done
if [ -n "$BRIDGING_HEADER" ]; then
    > "$BRIDGING_HEADER"
    for m_file in "${OBJC_FILES[@]}"; do
        h_file="${m_file%.m}.h"
        if [ -f "$h_file" ]; then
            echo "#import \"$h_file\"" >> "$BRIDGING_HEADER"
        fi
    done
fi

# --- Step 2: Compile Swift + link with C objects ---
# Per-worktree module cache to prevent concurrent build corruption.
MODULE_CACHE="$BUILD_DIR/ModuleCache"
mkdir -p "$MODULE_CACHE"

xcrun -sdk "$SDK_NAME" swiftc \
    -target "$TARGET" \
    -sdk "$SDK_PATH" \
    -module-cache-path "$MODULE_CACHE" \
    -emit-library \
    -emit-module \
    -emit-module-path "$FRAMEWORK_DIR/Modules/Pepper.swiftmodule/${ARCH}.swiftmodule" \
    -module-name Pepper \
    -o "$FRAMEWORK_DIR/Pepper" \
    -Osize \
    -whole-module-optimization \
    -warnings-as-errors \
    -strict-concurrency=targeted \
    -DPEPPER_CONTROL -DPEPPER \
    ${HAS_ADAPTER:+-DPEPPER_HAS_ADAPTER} \
    -framework UIKit \
    -framework Foundation \
    -framework Network \
    -framework SwiftUI \
    -framework QuartzCore \
    -framework AVFoundation \
    -framework CoreMedia \
    -framework EventKit \
    -framework AppTrackingTransparency \
    -framework Contacts \
    -framework CoreLocation \
    -framework WebKit \
    -Xlinker -install_name -Xlinker @rpath/Pepper.framework/Pepper \
    ${BRIDGING_HEADER:+-import-objc-header "$BRIDGING_HEADER"} \
    "${SWIFT_FILES[@]}" \
    "${C_OBJECTS[@]}"

# --- Create Info.plist ---
cat > "$FRAMEWORK_DIR/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleIdentifier</key>
    <string>com.pepper.control</string>
    <key>CFBundleName</key>
    <string>Pepper</string>
    <key>CFBundleExecutable</key>
    <string>Pepper</string>
    <key>CFBundlePackageType</key>
    <string>FMWK</string>
    <key>CFBundleVersion</key>
    <string>1</string>
    <key>CFBundleShortVersionString</key>
    <string>1.0</string>
    <key>MinimumOSVersion</key>
    <string>${IOS_TARGET_VERSION}</string>
</dict>
</plist>
PLIST

# --- Ad-hoc sign ---
# Device builds need valid signatures for xcodebuild -create-xcframework.
# iOS 26.3+ simulator silently rejects DYLD_INSERT_LIBRARIES dylibs that
# only carry a linker signature, so we sign for all platforms.
codesign --force --sign - --deep "$FRAMEWORK_DIR"

# --- Report ---
DYLIB_SIZE=$(stat -f%z "$FRAMEWORK_DIR/Pepper" 2>/dev/null || stat --printf='%s' "$FRAMEWORK_DIR/Pepper" 2>/dev/null)
DYLIB_SIZE_KB=$((DYLIB_SIZE / 1024))
success "Built Pepper.framework (${DYLIB_SIZE_KB}KB)"
success "  $FRAMEWORK_DIR/Pepper"
