# Completed plans

Retrospective index of planning cycles whose scope has fully shipped. Each
entry maps plan items to the release that landed them, with a link to the
original planning artifact and the CHANGELOG section that documents the
work.

Plans are preserved verbatim on move — no in-place edits. The summaries
below are the authoritative record of what shipped; the source plans are
kept for historical context and to explain *why* the scope was chosen.

---

## v0.5.0 / v0.6.0 cycle — refinement + Prowlarr

- Planning artifacts: [v0.4-pm-review.md](v0.4-pm-review.md),
  [v0.5-v0.6-cycle-plan.md](v0.5-v0.6-cycle-plan.md)
- Span: post-v0.4.0 → v0.6.0 (2026-04-21)
- Outcome: all four phases (A housekeeping, B refinement, C narrative,
  D Prowlarr) shipped.

### Phase A — Housekeeping (shipped v0.5.0)

| Item | Deliverable | Released in |
|---|---|---|
| A1 | `.gitignore` `dist/`, purge stale wheels | v0.5.0 |
| A2 | Coverage gate enforced (`fail_under = 80`, CI gating) | v0.5.0 |
| A3 | `Any`-audit policy documented in `docs/architecture.md` | v0.5.0 |
| A4 | `_meta.action_hints` enforced on every data-returning MCP tool | v0.5.0 |
| A5 | `docs/superpowers/` archived to `docs/archive/`; `docs/architecture.md` promoted | v0.5.0 |
| A6 | `docs/roadmap.md` drafted | v0.5.0 |

### Phase B — Refinement (shipped v0.5.0)

| Item | Deliverable | Released in |
|---|---|---|
| B1 | `POLICIES.{conservative,default,aggressive,ratio_preserving}` | v0.5.0 |
| B2 | `backfill.estimate()` + `BackfillEstimate`; wired into MCP `_meta.estimate` | v0.5.0 |
| B3 | `ReleaseExplanation.advice()`; surfaced in `arr_explain_grab` | v0.5.0 |
| B4 | CLI formally frozen ("status + add only") | v0.5.0 |
| B5 | `webhooks.fastapi_router()` + `webhooks.wsgi_app()` | v0.5.0 |
| B6 | `config_sync.load(path)` YAML/JSON/TOML loader + `DesiredState` schema | v0.5.0 |
| B7 | Config-sync resource coverage: root_folders, download_clients, indexers, notifications, naming | v0.5.0 |

### Phase C — Narrative lockdown (shipped v0.5.0)

| Item | Deliverable | Released in |
|---|---|---|
| C1 | README rewrite (MCP, workflows, webhooks, CLI freeze surfaced) | v0.5.0 |
| C2 | v0.5.0 cut via PyPI trusted publisher | v0.5.0 |

### Phase D — Prowlarr support (shipped v0.6.0)

| Item | Deliverable | Released in |
|---|---|---|
| D1 | Architecture memo: [prowlarr-architecture.md](../prowlarr-architecture.md) | v0.6.0 |
| D2 | Upstream pinned to `Prowlarr v2.3.5.5327`; spec vendored | v0.6.0 |
| D3 | Codegen extended to accept `prowlarr` + `api_version` parameterized | v0.6.0 |
| D4 | Generated Prowlarr v1 models + operations | v0.6.0 |
| D5 | `ProwlarrClient` / `AsyncProwlarrClient` | v0.6.0 |
| D6 | `ProwlarrSettings` via shared factory | v0.6.0 |
| D7 | Curated facades: `indexers`, `applications`, `tags` | v0.6.0 |
| D8 | Prowlarr webhook coverage (`OnHealthRestored` added) | v0.6.0 |
| D9 | 8 Prowlarr MCP tools + uniform action_hints | v0.6.0 |
| D10 | `arr_health` extended with `app="all"` Prowlarr fan-out | v0.6.0 |
| D11 | Config-sync `applications` resource (Prowlarr-only) | v0.6.0 |
| D12 | `testing.make_fake_prowlarr()` | v0.6.0 |
| D13 | `lscr.io/linuxserver/prowlarr` integration compose service + fixtures | v0.6.0 |
| D14 | `schema-drift` CI workflow extended to Prowlarr | v0.6.0 |
| D15 | README + comparison table + CHANGELOG updates | v0.6.0 |
| D16 | v0.6.0 cut | v0.6.0 |

CHANGELOG sections:
[v0.5.0](../../../CHANGELOG.md#L281-L351),
[v0.6.0](../../../CHANGELOG.md#L215-L280).

### Items explicitly deferred by this cycle

All three remain the current backlog, tracked in
[docs/roadmap.md](../../roadmap.md):

- **Lidarr / Readarr** — deferred until Prowlarr validated the 3-brand
  abstraction. Prowlarr landed cleanly, so the remaining brands are now
  "mechanical."
- **Operator agent (`arr_py_client.agent`)** — subsequently shipped in
  v0.7.0.
- **OpenTelemetry / structured logging hooks** — still deferred; revisit
  if demand emerges.
