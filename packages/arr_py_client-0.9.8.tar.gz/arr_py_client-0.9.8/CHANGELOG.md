# Changelog

All notable changes to this project are documented here. This project adheres to
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed — MCP auth-flow audit: scope + audit gates uniform across every entry point

A code-review audit of the MCP module surfaced six gaps where the
brand-tool scope/audit pipeline didn't extend to adjacent surfaces.
Brand tools (``radarr_*`` / ``sonarr_*`` / ``prowlarr_*``) were always
wired correctly; everything else slipped through.

#### What was broken

1. **Composed `arr_*` tools bypassed scope checks entirely**. All 15
   registered via plain ``@server.tool`` and never called
   ``resolve_scopes`` — so a token with only ``mcp:arr:read`` could
   fire ``arr_sync_apply``, ``arr_grab_release``, ``arr_bulk_edit``,
   ``arr_trash_import``, ``arr_cleanup_queue``, ``arr_janitor_run``,
   ``arr_backfill``, or ``arr_add`` despite the catalog declaring
   ``mcp:arr:mutate`` for each.
2. **Composed tools emitted no audit events**. Mutating composed
   tools wrote to the optional ``Journal`` but never to the ``audit=``
   callback. Security teams wiring the audit hook saw zero
   composed-tool mutations.
3. **`make_scope_middleware` was built but never mounted**. The ASGI
   middleware that rewrites ``insufficient_scope`` envelopes into RFC
   6750 ``403 + WWW-Authenticate`` had zero non-test callers; HTTP
   clients got the JSON envelope but no spec-compliant header.
4. **Per-tenant resources skipped scope checks**. ``arr://radarr/{id}/queue``
   returned the same payload as ``radarr_queue_list`` without the
   gating the tool had — two paths to the same data, one gated, one
   open.
5. **Dead helper `_request_context_from` in composed.py** —
   refactoring footgun: hard-coded ``dev_auth=None`` and zero
   callers, sitting alongside the real ``_ctx(...)`` closure that
   threaded ``deps.dev_auth``.
6. **Contradictory `principal=None` documentation**. The provider
   docstring promised ``principal`` is populated whenever auth is
   configured, but the decorator silently fell back to anonymous on
   exotic ``build_request_context`` failures.

#### What changed

**New module-level helper**: ``arr_py_client.mcp._decorators.gated_tool(server, deps, *, name, title, annotations)``
— mirror of the brand-tool decorator's gate without the brand-client
resolution. Synthesizes a ``ctx`` parameter when missing so FastMCP
auto-injects, builds ``RequestContext`` via ``build_request_context``,
runs ``resolve_scopes`` against the principal, returns the structured
``insufficient_scope`` envelope on failure, and emits an
``AuditEvent`` (``ok`` / ``scope_denied`` / ``tool_error``) for every
outcome.

- Applied to all **15 composed `arr_*` tools** in ``mcp/tools/composed.py``
  (`arr_add`, `arr_health`, `arr_upcoming`, `arr_find_release`,
  `arr_grab_release`, `arr_cleanup_queue`, `arr_janitor_run`,
  `arr_summarize_queue`, `arr_explain_grab`, `arr_title_status`,
  `arr_backfill`, `arr_sync_plan`, `arr_sync_apply`, `arr_sync_dump`,
  `arr_bulk_edit`, `arr_trash_import`).
- Applied to **all 6 describe / journal / agent reference tools** in
  ``mcp/tools/describe.py`` (`arr_describe_fields`,
  `arr_list_resources`, `arr_list_instances`, `arr_journal_list`,
  `arr_agent_status`, `arr_agent_preview`).

**New helper**: ``arr_py_client.mcp.resources._gated_resource`` —
analogue for per-tenant MCP resources. Wraps each handler with the
same scope-check + audit pipeline; returns a JSON
``insufficient_scope`` envelope on denial. The audit ``tool_name``
field is the URI pattern (``arr://radarr/{instance_id}/queue``) so
security teams can grep across tools and resources uniformly.

- Applied to all 6 per-tenant resources (`arr://instances/{filter}`,
  `arr://{brand}/{instance_id}/queue`, `arr://prowlarr/{id}/indexers`,
  `arr://{brand}/{id}/health`).
- Tenant-independent resources (`arr://help/quickstart`,
  `arr://schemas/*`) deliberately skip the gate — they have no
  per-tenant data.

**New `build_server` kwarg**: ``resource_scope_overrides`` — per-resource
scope override map mirroring the existing ``scope_overrides``.
Defaults to ``mcp:arr:read`` for every per-tenant resource. Keys:
``"instances"``, ``"radarr_queue"``, ``"sonarr_queue"``,
``"prowlarr_indexers"``, ``"radarr_health"``, ``"sonarr_health"``.

**Auto-mounted ASGI scope-middleware**: ``build_server`` now overrides
``server.streamable_http_app`` to wrap the returned ASGI app with
``make_scope_middleware`` whenever ``auth=`` is configured. HTTP
clients now see RFC 6750 ``403 + WWW-Authenticate: Bearer
error="insufficient_scope" scope="..."`` for any
``insufficient_scope`` envelope from any gated entry point.
``resource_metadata=`` derives from ``auth.resource_server_url`` so
client agents can auto-discover the auth server.

**Schema relaxation**: every ``Arr*Out`` schema in
``arr_py_client.mcp._schemas`` now declares ``error: Any = None``
(was ``str | None``) so the gate's structured ``insufficient_scope``
dict envelope passes Pydantic validation. Tool bodies still produce
simple string errors for known failure modes; both shapes are
permitted.

**Dead helper removed**: ``_request_context_from`` in
``mcp/tools/composed.py``.

**Public rename**: ``_emit_audit`` → ``emit_audit`` in
``mcp/_decorators.py`` (the resource gate reuses it; private
prefix gone since it's a documented cross-module helper now).

**Docstring corrections**: ``RequestContext`` and ``ClientProvider``
now document the two cases where ``ctx.principal`` is ``None`` —
unauthenticated stdio AND the rare context-build failure (which
the library logs at WARN). The ``auth_required`` ``AuditStatus``
literal is documented as reserved-but-unreachable from inside the
library.

#### Tests

New module: ``tests/unit/test_mcp_gated_composed_and_resources.py``
(15 tests):

- Composed-tool scope: mutating tool blocked for read-only principal,
  read tool passes for read principal, scope-denied audit event,
  scope-passed audit event, advisory mode (no auth → ``"skipped"``).
- Describe-tool scope: success audit, custom override re-gates a
  read tool to require an elevated scope.
- Per-tenant resource scope: scopeless principal blocked,
  scope-denied audit event, read principal passes,
  scope-passed audit event, ``resource_scope_overrides=`` precedence,
  tenant-independent resources skip the gate.
- Middleware mount: ``streamable_http_app`` returns a Starlette
  without ``auth=``, returns the wrapped factory output with
  ``auth=``, and the wrapped flow rewrites composed-tool
  ``insufficient_scope`` envelopes into 403 + WWW-Authenticate.

Tests: 1107 pass (was 1092, +15); ruff + basedpyright clean.

### Added — Webhook HMAC signature verification (`hmac_sha256_verifier`)

The webhook receivers (`wsgi_app`, `fastapi_router`) now accept an
optional `verify=` callable that runs HMAC-SHA256 signature
verification against the raw request body before JSON parsing or
handler dispatch. On mismatch the receivers reply ``401 Unauthorized``
with `{"error": "invalid_signature"}` and the handler is never
invoked.

New module: `arr_py_client.webhooks.signing`

- `hmac_sha256_verifier(secret, *, header, prefix, timestamp_header,
  timestamp_tolerance_seconds, timestamp_separator, now)` — builds a
  ``Verifier`` callable. Two modes:
  - **Plain HMAC** (default): signs the raw body. Header defaults to
    ``X-Hub-Signature-256`` with ``sha256=`` prefix (GitHub-shape).
    Override ``header=`` / ``prefix=`` for ``X-Webhook-Signature: <hex>``
    or any other relay convention.
  - **Timestamped HMAC** (Stripe-shape): set ``timestamp_header=`` to
    require a separate timestamp header. The signed payload becomes
    ``f"{ts}{sep}{body}"`` and the verifier rejects timestamps further
    than ``timestamp_tolerance_seconds`` (default 5 minutes) from now.
    Prevents replay even if an attacker captured a valid signed body.
- `InvalidSignatureError` — raised by the verifier on any failure
  (missing header, malformed hex, wrong secret, expired timestamp).
  The receivers catch this and translate to ``401``.
- `Verifier` — type alias for the verifier callable shape:
  ``Callable[[bytes, Mapping[str, str]], None]``.
- `normalize_headers(raw)` — adapter for WSGI environ → lowercase
  header dict (drops non-`HTTP_` bookkeeping keys); plain header
  mappings pass through with lowercased keys.

Implementation notes:

- Constant-time compare via ``hmac.compare_digest`` defends against
  timing oracles.
- Signature check runs before JSON parsing so a forged body returns
  401 (not 400) and saves cycles on `parse_event`.
- Default backwards-compatible: omitting ``verify=`` keeps the existing
  no-verification behavior. Existing call sites need no changes.

New test: `tests/unit/test_webhooks_signing.py` (27 tests)

- ``normalize_headers`` WSGI vs. plain-dict handling
- Verifier accept/reject paths: valid, wrong secret, tampered body,
  missing header, malformed hex, custom header + prefix, ``str``
  secret encoding
- Timestamp mode: in-tolerance accepts, out-of-tolerance rejects,
  missing timestamp rejects, non-numeric rejects, body-only HMAC
  with a current timestamp rejects (no replay), custom separator
- Both receivers: signed payload accepts (204), unsigned rejects
  (401), wrong secret rejects (401), backwards-compat no-verify
  (204), forged body returns 401 not 400, timestamped happy path
  + replay rejection

Tests: 1092 pass (was 1065, +27); basedpyright + ruff clean.

### Added — MCP polish round 3: full output schemas + sampling

Two follow-on items closing the original "perfect MCP" punch list.

#### Output schemas extended to all 15 composed tools
The four high-information composed tools landed typed output schemas
in the previous round; this round extends the pattern to the
remaining eleven so every ``arr_*`` tool emits a meaningful
``outputSchema``:
- ``ArrAddOut`` — happy + no-match envelopes
- ``ArrUpcomingOut`` — per-brand calendar items
- ``ArrGrabReleaseOut`` — lean confirmation envelope
- ``ArrCleanupQueueOut`` — NukeResult-shaped (ids/blocklist/redownload)
- ``ArrJanitorRunOut`` — total_matches + per-match list with policy/action
- ``ArrBackfillOut`` — searched_count/batches/stopped_reason
- ``ArrSyncPlanOut`` — typed change list with action/existing_id
- ``ArrSyncApplyOut`` — applied + errors per change
- ``ArrSyncDumpOut`` — config-state dump
- ``ArrBulkEditOut`` — ids/count
- ``ArrTrashImportOut`` — fetched + applied counts per resource

All declare ``extra="allow"`` so the existing dict-shaped tool bodies
continue to work unchanged: FastMCP coerces returned dicts via
``model_validate``, declared fields land in ``structuredContent``
with their JSON-Schema types, and unmapped extras (``_meta`` payloads
beyond ``action_hints``) flow through.

#### MCP sampling — ``arr_summarize_queue``
New composed tool that demonstrates server-driven sampling (MCP spec
2025-06-18). The server fetches the full queue, computes a
deterministic per-status histogram + ``stalled_ids`` list, then asks
the *client's* LLM via ``ctx.session.create_message`` to produce a
3-5 sentence narrative summary. The client's host context pays for
the analysis; the server doesn't ship its own model key. When the
client doesn't advertise sampling support, ``summary=None`` and
``sampled=False`` — the histogram is still useful on its own.

New helpers:
- ``_safe_sample(ctx, system_prompt, user_message, ...)`` — same
  best-effort shape as ``_safe_info`` / ``_safe_progress`` /
  ``_safe_elicit``; catches every transport / capability error and
  returns ``None`` so callers can fall back to structured payloads.
- ``_user_text(text)`` — one-line ``SamplingMessage`` builder.

Tests: +13 new (1065 total, was 1052 after the per-tenant resources
round); basedpyright clean; ruff + format clean.

### Added — MCP follow-up: typed output schemas + per-tenant resources

Two follow-on improvements to the MCP polish pass below.

#### Typed output schemas for high-information composed tools
The four tools that answer the most-common questions now declare
Pydantic return models so MCP clients see meaningful ``outputSchema``
instead of the generic ``additionalProperties=True`` placeholder:
- ``arr_health`` → ``ArrHealthOut`` (per-brand health summaries +
  ``_meta``)
- ``arr_title_status`` → ``ArrTitleStatusOut`` (in-library +
  not-in-library + error envelopes via optional fields)
- ``arr_explain_grab`` → ``ArrExplainGrabOut`` (typed verdict list +
  advice)
- ``arr_find_release`` → ``ArrFindReleaseOut`` (typed candidate list)

All schemas use ``extra="allow"`` so existing dict-shaped tool bodies
work unchanged: FastMCP coerces returned dicts via ``model_validate``,
declared fields land in ``structuredContent`` with their JSON-Schema
types, and unmapped extras (e.g. ``_meta.action_hints`` payload) flow
through unmodeled.

New module: ``arr_py_client.mcp._schemas`` — exports ``ArrHealthOut``,
``ArrTitleStatusOut``, ``ArrExplainGrabOut``, ``ArrFindReleaseOut``,
``ToolMeta``.

New test: ``tests/unit/test_mcp_output_schemas.py`` (8 tests) — schema
shape checks + structured-content round-trip + error-envelope coverage.

#### Per-tenant resources
Six new MCP resources that route through the request's
``ClientProvider`` so multi-tenant deployments honor principal-keyed
routing and scope enforcement:

- ``arr://instances/{brand_filter}`` — instance inventory visible to
  the caller (``brand_filter`` is ``radarr|sonarr|prowlarr|all``)
- ``arr://radarr/{instance_id}/queue`` — Radarr queue snapshot (page 1)
- ``arr://sonarr/{instance_id}/queue`` — Sonarr queue snapshot
- ``arr://prowlarr/{instance_id}/indexers`` — Prowlarr indexer list
- ``arr://radarr/{instance_id}/health`` — single-instance health
- ``arr://sonarr/{instance_id}/health`` — same for Sonarr

The handlers accept a ``Context`` parameter (FastMCP auto-injects),
build a ``RequestContext`` via the same ``build_request_context``
helper used by tool decorators, and route to the matching instance
through ``provider.resolve_*``. Errors land as JSON envelopes with
``error.type`` (``client_not_configured``, ``provider_error``).

The ``"default"`` literal in the URI path translates to
``instance_id=None`` so the conventional default-instance pattern
works in URIs (e.g. ``arr://radarr/default/queue``).

Wiring: ``attach_resources(server, provider, dev_auth=...)`` now
accepts an optional ``provider`` to register the per-tenant set.
``build_server`` threads the same provider/dev_auth through.

New test: ``tests/unit/test_mcp_per_tenant_resources.py`` (10 tests) —
filtered instance lists, per-brand queue + indexer + health reads,
``client_not_configured`` envelopes, template registration, and
the provider-less fallback path.

Tests: 1057 pass (was 1039); basedpyright clean; ruff + format clean.

### Added — MCP polish pass (annotations, prompts, resources, surface, progress, elicitation)

A six-commit run that brings the MCP server up to the 2025-06-18 spec
and the published best-practice cliff (~30 tools for selection
accuracy). No breaking changes; every existing call site keeps working.

#### Tool annotations + titles (every tool)
Every one of the 64 registered tools now declares a `ToolAnnotations`
shape — `readOnlyHint` / `destructiveHint` / `idempotentHint` /
`openWorldHint` — so MCP clients can drive UI confirmation policy
without parsing names. Each tool also gets a human-readable `title`
(e.g. *"List Radarr movies"*, *"Add movie or series"*) for tool
pickers, distinct from the LLM-facing `name`.
- New module `arr_py_client.mcp._annotations` — presets:
  - `READ_ONLY` (list/get/status/lookup), `ADDITIVE` (creates new
    state), `MUTATING` (idempotent, e.g. config-sync apply),
    `DESTRUCTIVE` (delete/restore/cleanup/janitor).
  - `tool_annotations()` builder for one-off shapes.
- Brand-tool decorators (`radarr_tool` / `sonarr_tool` /
  `prowlarr_tool`) accept `title=` and `annotations=` per-tool via
  the new `@rt(title=..., annotations=...)` form (legacy `@rt` still
  works).
- Tool docstrings rewritten LLM-first: prereqs, when-to-use, examples,
  keywords, sibling tool pointers — replaces the prior dev-shorthand
  one-liners.

#### Curated `surface=` (~30 tools instead of ~64)
- New `build_server(surface="essentials" | "full")` parameter — default
  remains `"full"` for backwards compat. Pass `surface="essentials"`
  to drop the brand-CRUD surface (queue_list, history_list,
  blocklist_list, command_post, release_push, etc.) and ship just
  ping/system_status/lookup per brand. The composed `arr_*` tools
  cover most workflows already.
- `extra_tools=[...]` re-adds specific brand tools to the essentials
  surface by name. Unknown names are silently ignored.
- Internal: new `mcp/tools/_filter.py` wraps brand decorators so
  unmatched names skip registration cleanly.

#### Progress notifications on long-running tools
Composed tools that take ≥1 second now emit `notifications/progress`
checkpoints so chat UIs can render a status bar:
- `arr_sync_apply` — Resolving → Planning → Applying → Complete
- `arr_janitor_run` — Resolving → Scanning → Complete
- `arr_backfill` — Resolving → Searching → Complete
- `arr_trash_import` — Resolving → Fetching → Planning → (Applying) → Complete

New `_safe_progress(ctx, progress, total, message)` helper — same
pattern as the existing `_safe_info`, silently no-ops outside a live
request context so test harnesses that bypass FastMCP don't crash.

#### Prompts (slash commands)
Four pre-templated prompts surface as `/`-commands in MCP clients
(zero tool-budget cost):
- `triage_stuck_downloads(app=both|radarr|sonarr)`
- `audit_missing_episodes(series_title)`
- `weekly_health_check()`
- `recommend_quality_profile(title, app=radarr|sonarr)`

Each walks the LLM through a multi-step workflow with explicit
references to `arr_*` tool calls and `dry_run=True` defaults.

#### Resources (host-attachable context)
Three tenant-independent resources for hosts that want to splice
context without a tool call:
- `arr://help/quickstart` (text/markdown) — onboarding doc
- `arr://schemas/list` (application/json) — list of dotted resource ids
- `arr://schemas/{resource}` (application/json, templated) — per-resource
  field listing (mirror of `arr_describe_fields`)

Per-tenant snapshots (queue, library) remain on the tools surface where
the request context can route to the caller's instance.

#### Elicitation
`arr_add` now uses MCP elicitation (spec 2025-06-18) to ask the user
for a missing quality profile or root folder rather than erroring.
Falls back to a structured error envelope when the client declines,
cancels, or doesn't support elicitation.
- New `_safe_elicit(ctx, message, schema)` helper — accepts a Pydantic
  schema, returns the populated data on accept and `None` otherwise.
- `_elicit_quality()` and `_elicit_root_folder()` enumerate live
  options on the resolved client so the prompt lists real choices.

#### Tests
+44 new tests across:
- `test_mcp_annotations.py` — universal annotation invariants + spot checks
- `test_mcp_progress.py` — recorder for progress checkpoints
- `test_mcp_surface.py` — essentials / full / extra_tools
- `test_mcp_prompts_resources.py` — prompt expansion + resource reads
- `test_mcp_elicitation.py` — elicit accept / decline / threading

Total tests: 1039 (was 1002); basedpyright clean; ruff + format clean.

## [0.9.7] — 2026-04-25

### Added — Fleet config-sync (`fleet_plan`, `fleet_apply`, `fleet_dump`)

Closes the "first-class fleets with shared config_sync runs" half of
the multi-instance surface consolidation item that v0.9.5's
`fan_out_*` helpers opened. You can now reconcile one `desired` state
across every Radarr / Sonarr / Prowlarr instance a `ClientProvider`
owns without writing the fan-out plumbing yourself.

- **`arr_py_client.mcp.fleet.fleet_plan(provider, ctx, brand, desired,
  *, policy=..., strict=..., include=..., filter_tags=...,
  include_instances=..., exclude=...)`** — plans one shared `desired`
  document against every instance of `brand`; returns
  `FleetResult[SyncPlan]` keyed by `instance_id`. Per-instance
  planning failures (auth, network, schema) land in
  `FleetResult.errors` — a single unreachable instance never poisons
  the fleet.
- **`fleet_apply(provider, ctx, brand, plans, *, policy=...,
  dry_run=..., journal=...)`** — applies a per-instance plan map
  concurrently. `plans` is typically the `results` of a prior
  `fleet_plan` call (optionally filtered), so gating an apply on the
  plan summary is a one-liner. Empty `plans` short-circuits without
  any resolve calls.
- **`fleet_dump(provider, ctx, brand, *, include=...,
  filter_tags=..., include_instances=..., exclude=...)`** — dumps
  current state from every instance; returns
  `FleetResult[dict[str, Any]]`. Useful for cross-instance drift
  detection or seeding a shared desired-state document.
- **Policy integration**: pass
  `policy=POLICIES.config_sync.{conservative,default,aggressive}` and
  the bundle's kwargs win over explicit ones. The `journal` kwarg
  always flows through unchanged — policy bundles don't carry a
  journal.
- **Instance filters mirror `fan_out_*`**: `filter_tags` (AND
  against `InstanceInfo.tags`), `include_instances`, `exclude`, all
  AND together. Skipped instances land in `FleetResult.skipped`.

Usage recipe::

    from arr_py_client.mcp.fleet import fleet_plan, fleet_apply
    from arr_py_client import POLICIES

    pol = POLICIES.config_sync.conservative  # dry_run=True
    plans = await fleet_plan(
        provider, ctx, "radarr", desired, policy=pol,
        filter_tags=("prod",),
    )
    if not plans.ok:
        raise RuntimeError(plans.summary())
    reports = await fleet_apply(
        provider, ctx, "radarr", plans.results, policy=pol,
    )

### Added — `arr_title_status` composed MCP tool

Collapses the "how many episodes of X am I missing" chain into one
call so weak-chaining LLMs and aggressive deferred-tool surfaces can
answer the question without multi-step lookups. Mirrors the
`arr_explain_grab` lookup-then-match pattern and is read-only
(`mcp:arr:read`).

- **`arr_title_status(title, app)`** returns per-title library
  status: `in_library` flag, missing counts, size-on-disk, airing
  dates, `stats_by_season` for Sonarr and release dates / `hasFile`
  for Radarr.
- **`arr_health`** now emits an `arr_title_status` pivot hint so
  chat agents naturally chain from a fleet health summary into a
  specific title query.

### Changed — Test coverage 83% → 89% (+135 tests)

Two targeted passes over the lowest-covered modules closed gaps
introduced during v0.7.0 / v0.8.0 / v0.9.x feature flurries:

- **Core components** (v0.9.6 → v0.9.7, +71 tests): backfill
  estimates, POLICIES dataclasses, config_sync singleton path,
  operator-agent tick loop, trash-guides mappers.
- **Sonarr resources + MCP provider** (+64 tests):
  `SeriesResource`/`EpisodeResource` error paths,
  `EnvClientProvider` instance-id guards,
  `InMemoryCachedProvider` eviction + TTL.

### Fixed — Release workflow `gh release view` propagation race

`gh release create` creates the tag and the release as separate API
calls. The tag-push fires the release workflow immediately, but
`gh release view` can 404 for a few seconds until the release
propagates. Added a bounded retry around the view step so dispatched
or re-run releases don't fall into the "no release found" branch on
the first poll.

## [0.9.6] — 2026-04-23

### Changed — Release workflow hardening

The v0.9.5 cut nearly didn't ship: `gh release create` fires both
`release: published` and `push: tags: v*`, the `cancel-in-progress`
concurrency guard on `release.yml` arbitrarily killed one of the two
resulting runs, and the surviving tag-push run's follow-up jobs stalled
in the homelab-runner queue for ~20 minutes before unsticking. v0.9.5
eventually made it to PyPI/GHCR/GitHub Releases, but with auto-generated
notes (the CHANGELOG extractor couldn't find a `[0.9.5]` section because
the release was cut directly from `[Unreleased]`). This release moves
both workflows onto a design that cannot race with itself.

- **Single trigger**: `release.yml` and `docker-publish.yml` now fire
  only on `push: tags: v*`. `gh release create` still works — it creates
  the tag (fires this trigger) and the GitHub Release; `github-release`
  detects the pre-existing release and attaches wheels without touching
  the notes the operator drafted. `git tag + git push` (the path
  documented in `CONTRIBUTING.md`) remains the primary flow.
- **Idempotent PyPI publish**: `pypa/gh-action-pypi-publish` now runs
  with `skip-existing: true`. Reruns and partial-failure recoveries no
  longer 400 on already-uploaded wheels; the tag-pinned version sync in
  `build` guarantees we can't silently "succeed" with a stale wheel.
- **Always-run version bump**: `bump-main` lost its
  `github.event_name == 'release'` gate and runs on every trigger. It
  was already idempotent (no-op when main matches), and it now also
  refuses to downgrade `main`'s `__version__.py` when dispatched against
  an older tag.
- **Manual recovery hatch**: both workflows gained `workflow_dispatch`
  with a `tag` input. Dispatched replays run against the workflow file
  on `main` — not the file at the tag's commit — so a workflow bug at
  the release commit can still be recovered from. `publish` is gated on
  the push trigger (the PyPI environment's branch policy only admits
  `v*` tag refs); dispatches replay everything else.
- **Concurrency guard narrowed**: `cancel-in-progress` flipped from
  `true` to `false`. With a single trigger there is nothing to arbitrate
  between, and a replay should wait for the incumbent rather than
  aborting it mid-publish.

## [0.9.5] — 2026-04-23

### Added — Config sync `media_management` resource

Closes the last unclaimed resource on the "media_management +
release_profiles + auto_tagging" line (the other two landed in v0.4.0
and v0.7.0). Singleton endpoint at `/config/mediamanagement`, same shape
rule as `naming` (bare mapping, UPDATE-only, no create/delete). Covers
the importer + file-handling surface operators actually tune:
auto-unmonitor, recycle bin, hardlinks, propers/repacks, permissions,
free-space minimums, script-import, extra-file extensions.

- Recognized as a resource by `plan()` / `apply()` / `dump()` / the
  loader; enters the `DesiredState` schema as
  `media_management: dict[str, Any] | None`.
- Prowlarr-skip guard matches `naming`: if the client lacks
  `custom_formats`, the resource is silently dropped so the same
  desired-state file can target any brand.
- Internal refactor: hardcoded `if change.resource == "naming"` in
  `apply()` replaced by a `_SINGLETON_RESOURCES` frozenset, and
  `_plan_naming` generalized to `_plan_singleton(resource, ...)` so
  future singletons drop in with one tuple entry + one path mapping.
- Example config extended with a commented `media_management:` block
  showing the common knobs.

### Added — Named bundles beyond janitor (`POLICIES.backfill`, `POLICIES.config_sync`)

Extends the `POLICIES.*` pattern — which shipped for the queue janitor
in v0.5.0 — to two more domains. Backfill and config-sync now each ship
three named, frozen bundles (`conservative` / `default` / `aggressive`)
under nested namespaces on the same top-level `POLICIES` object. The
existing janitor bundles stay at their current flat names
(`POLICIES.default`, etc.) — no breaking change.

- **`arr_py_client.BackfillPolicy`** — frozen dataclass with fields
  mirroring `library.backfill()` kwargs (`source`, `batch_size`,
  `delay_between_batches`, `max_items`, `pause_if_queue_over`,
  `monitored_only`). `.as_kwargs()` emits the splat-ready dict;
  `batch_size=None` is omitted so the brand-specific default (5 movies /
  20 episodes) still kicks in.
- **`arr_py_client.ConfigSyncPolicy`** — frozen dataclass with fields
  matching `plan()` / `apply()` knobs (`strict`, `include`, `dry_run`).
  `.as_plan_kwargs()` / `.as_apply_kwargs()` emit the splat for each
  call site.
- **`POLICIES.backfill.conservative`** throttles hard (60 s delay,
  `pause_if_queue_over=10`, `max_items=50`) — right for nightly crons
  nibbling at a large wanted list.
- **`POLICIES.backfill.default`** matches today's hardcoded defaults.
- **`POLICIES.backfill.aggressive`** drops the delay to 10 s; the
  remaining knobs stay safe.
- **`POLICIES.config_sync.conservative`** forces `dry_run=True` +
  `strict=False` for first-run exploration.
- **`POLICIES.config_sync.default`** matches today's function defaults.
- **`POLICIES.config_sync.aggressive`** flips `strict=True` +
  `dry_run=False` for committed reconciles — only sensible after a
  dry-run pass.

Usage recipe::

    await client.library.backfill(**POLICIES.backfill.aggressive.as_kwargs())
    pol = POLICIES.config_sync.default
    p = plan(client, desired, **pol.as_plan_kwargs())
    apply(client, p, **pol.as_apply_kwargs())

### Added — Fleet fan-out helpers (`arr_py_client.mcp.fleet`)

Puts a real UX on top of v0.8.0's multi-instance `ClientProvider`: run
the same workflow (health summary, config-sync apply, janitor sweep,
anything) across every Radarr / Sonarr / Prowlarr instance the current
caller owns, concurrently, with per-instance results and errors rolled
up cleanly.

- **`FleetResult[T]`** — frozen dataclass with `results`, `errors`, and
  `skipped` keyed by `instance_id`. Convenience properties: `.ok`
  (every selected instance succeeded), `.any_ok` (at least one did),
  `.summary()` one-liner. Never raises — per-instance failures land in
  `errors` and the caller decides whether to propagate.
- **`fan_out_radarr(provider, ctx, fn, *, filter_tags=, include=, exclude=)`**
  — discovers instances via
  `provider.list_instances(brand="radarr")`, resolves each via
  `resolve_radarr`, runs `fn(client)` concurrently via
  `asyncio.gather`. Filters AND together: `filter_tags` keeps
  tag-intersecting instances, `include` / `exclude` narrow by
  `instance_id`.
- **`fan_out_sonarr`**, **`fan_out_prowlarr`** — typed twins.
- Works with any `ClientProvider` — single-instance providers (like
  the built-in `EnvClientProvider`) trivially return a `FleetResult`
  with one entry, so code written against the fleet API scales from
  local CLI to multi-tenant deployments without branching.

## [0.9.3] — 2026-04-23

Maintenance re-tag to rebuild the release pipeline after the v0.9.2
Docker Hub login hardening. No code diff vs. v0.9.2.

## [0.9.2] — 2026-04-22

Operational + public-metadata pass. Splits the compose stack so the
MCP service boots without pulling in integration-test containers,
fixes two streamable-HTTP deployment regressions surfaced during e2e
testing against live arrs, and refreshes PyPI metadata + README to
match the expanded project scope.

### Fixed

- **Prowlarr `ping` on the async client.** `AsyncProwlarrClient.ping()`
  raised `'AsyncPingResource' object is not callable` — Prowlarr wired
  only the auto-generated resource, not the curated `PingResource`
  facade Radarr/Sonarr use. Added `resources/ping.py` and wired it via
  `_CURATED_ASYNC` / `_CURATED_SYNC`; `prowlarr_ping` now returns
  `{"ok": true}` against live instances.
- **Stateless streamable-HTTP lifespan.** `build_server`'s lifespan
  called `provider.aclose()` on every request under stateless HTTP
  (the default for `arr-py-mcp`), so the first tool call after
  `initialize` surfaced `RuntimeError: Cannot send a request, as the
  client has been closed`. Skip lifespan registration when
  `stateless_http=True`; stdio and stateful HTTP still get the hook.
  Regression guard:
  `test_stateless_http_lifespan_does_not_call_aclose`.
- **Docker Hub login in CI.** Every workflow that logs into Docker
  Hub now gates the step on `DOCKERHUB_USERNAME` + `DOCKERHUB_TOKEN`
  being present, promoted to `env:` (step-level `if:` can't read
  `secrets.*`). Dependabot PRs and forks fall back to anonymous pulls
  instead of failing every downstream step.

### Changed

- **Compose split.** Root [compose.yml](compose.yml) defines only the
  `arr-py-mcp` service; integration-test fixtures (Radarr / Sonarr /
  Prowlarr) moved to
  [compose.integration.yml](compose.integration.yml). New
  `just mcp-up` / `mcp-down` drive the MCP stack; `just int-up` /
  `int-down` replace the previous integration recipes.
- **MCP host port configurable via `ARR_PY_MCP_HOST_PORT`** (compose
  env, defaults to `3000`) so the streamable-HTTP listener rebinds
  without editing `compose.yml`. Dropped the misleading
  `ARR_PY_MCP_ALLOW_DEV_AUTH` passthrough — the CLI entrypoint never
  calls `build_server(dev_auth=...)`.
- **PyPI metadata** refreshed: summary mirrors the README tagline
  (typed client + MCP server + declarative config sync across Radarr /
  Sonarr / Prowlarr); added Documentation + Changelog project URLs;
  expanded classifiers (`Intended Audience :: System Administrators`,
  `Framework :: AsyncIO`, `Framework :: Pydantic :: 2`,
  `Topic :: Multimedia :: Video`, `Topic :: System :: Systems
  Administration`, `Topic :: Internet :: WWW/HTTP`).
- **README revamp**: highlights-first layout, single consolidated
  quickstart (SDK sync/async + MCP stdio + MCP Docker), deep-dive
  examples moved below the fold, top-of-file TOC, comparison table
  relocated to the bottom. Tool-count figure harmonized to 60+.

### Added

- **Docker deployment guide** at
  [docs/guides/docker-deployment.md](docs/guides/docker-deployment.md)
  — full e2e path for hosting the MCP container (env → compose →
  JSON-RPC smoke test → teardown), including the expected 307
  redirect on `/mcp/`, internal-hostname DNS pitfalls, and the two
  auth-hardening patterns (reverse-proxy OAuth vs. embedded
  `build_server`).

## [0.9.1] — 2026-04-22

### Added — Connection diagnostics

Three small primitives in `arr_py_client` for the "user pasted a URL +
API key and the first call failed, what do we tell them" problem that
hits every app with a connection form. Factual-only: coarse error
buckets and structured metadata, never localized suggestion strings.

- **`DEFAULT_PORTS`** — immutable mapping of each arr product's default
  HTTP port (`sonarr`: 8989, `radarr`: 7878, `prowlarr`: 9696).
- **`normalize_base_url(url) -> NormalizedBaseUrl`** — pure/sync URL
  validator. Strips `/api/vN` tails, normalizes scheme casing and
  trailing slashes, preserves subpath prefixes, exposes what it changed
  via `stripped_api_path` / `had_trailing_slash` / `port`. Raises
  `ValueError` on unrecoverable input (missing scheme, missing host,
  out-of-range port). `__str__` returns the canonical URL so callers
  can pass the result straight to `base_url=`.
- **`identify_arr_server(base_url, *, api_key=None, try_both_schemes=False, timeout=2.0, http_client=None) -> ArrServerInfo`**
  — async HTTP probe. Hits `/api/v3/system/status`, falls back to
  `/api/v1` for Prowlarr, reads `appName`. Returns `ArrServerInfo` with
  `detected_kind`, `api_version`, `auth_status` (`ok`/`rejected`/
  `not_checked`), and an `error_kind` bucketed as `dns` /
  `connect_refused` / `tls` / `timeout` / `http_error` / `not_arr`.
  Never raises on transport or HTTP failures — surfaces them in the
  result. Opt-in `try_both_schemes` flips http↔https only on transport
  failures (not on a reachable 401). Supports a caller-owned
  `http_client=` for connection-pool reuse across many probes.

Use these together: `normalize_base_url` for the synchronous
form-validation pass (before any network I/O), then `identify_arr_server`
once the shape is valid. See `docs/guides/connection-diagnostics.md` for
a full "test connection" handler example.

## [0.9.0] — 2026-04-22

Release-line alignment. The Dockerfile + GHCR publish workflow
described under v0.8.0's "Added — Docker image" section landed in the
commit immediately after the v0.8.0 tag was cut, so it actually first
ships from this tag. See the v0.8.0 "Added — Docker image" section
below for the image description; no additional code or docs ship from
v0.9.0.

## [0.8.0] — 2026-04-22

**TL;DR — if you use `arr-py-mcp` via the CLI (stdio or HTTP) with env
vars, you don't need to change anything.** If you import `build_server`
or any `attach_*_tools` function directly, see the migration note at
the bottom of this section.

The MCP server is rebuilt around a `ClientProvider` abstraction so a
single process can serve many users — each with their own Radarr /
Sonarr / Prowlarr instances and (optionally) multiple instances of the
same brand. The local single-tenant CLI flow is preserved through a
built-in env-var-backed provider. New optional OAuth 2.1 plumbing,
per-tool scope enforcement, and an audit hook round out the
multi-tenant story.

### Added — Multi-tenant MCP server

- **`ClientProvider`** protocol — every tool resolves its Arr client(s)
  per request via `provider.resolve_radarr(ctx, instance_id=...)` etc.
  No more closure-bound clients; one process can serve many users.
- **`EnvClientProvider`** — env-var-backed implementation the CLI wires
  up automatically. Drop-in replacement for the old `make_clients()`.
- **`InMemoryCachedProvider`** — optional base class with bounded,
  TTL'd, per-identity client caching and an `invalidate(identity, ...)`
  hook for credential-rotation / connection-deletion events. Per-process
  only; multi-worker deployments need external invalidation
  coordination (Redis pub/sub, sticky sessions, etc.).
- **`RequestContext` + `Principal`** — library-owned boundary types
  passed to providers, so downstream code never imports from
  `mcp.server.auth.middleware.*` (SDK internals).
- **`CallbackTokenVerifier`**, **`HeaderPassthroughVerifier`**,
  **`StaticBearerVerifier`** — concrete `TokenVerifier` adapters so
  embedding apps wire bearer auth in 4 lines, not 40.
- **`DevAuth`** — test/local-dev shortcut that pre-fills every request's
  `Principal`. Mutually exclusive with `token_verifier=`. Refuses
  unless `ARR_PY_MCP_ALLOW_DEV_AUTH=1` is set, so it can never ship in
  production by accident.
- **Per-tool scope enforcement** — every tool declares a default scope
  (`mcp:arr:read` for observers, `mcp:arr:mutate` for state-changers).
  Enforcement is active iff `RequestContext.principal` is populated
  (i.e., auth is configured). Override the whole map via
  `build_server(scope_overrides=...)`. RFC 6750 §3.1 compliant
  `403 + WWW-Authenticate` returned to HTTP clients on scope failure.
- **Audit hook** — `audit=Callable[[AuditEvent], ...]` on
  `build_server` fires on every attempted invocation (including
  `auth_required`, `scope_denied`, `client_not_configured`,
  `provider_error`, `tool_error`, `ok`). `error_class` carries the
  exception type name only — never the message — so audit storage
  doesn't accumulate credential fragments.
- **`instance_id` on every brand tool**; cross-brand composed tools
  accept per-brand `{radarr,sonarr,prowlarr}_instance_id` kwargs. New
  `arr_list_instances` tool lets agents discover valid instance ids
  before passing them. `InstanceInfo` carries a `tags` tuple for
  agent-level filtering.
- **OAuth 2.1 pass-through** — `token_verifier=` and
  `auth=AuthSettings(...)` on `build_server` are forwarded to the
  SDK's bearer-auth + PRM-document machinery. Full MCP 2025-11 flow.
- **FastAPI mount** — `server.streamable_http_app()` is the
  documented mount point for embedding apps:
  `app.mount("/mcp", mcp.streamable_http_app())`.
- **Lifespan-driven shutdown** — `build_server` wires
  `provider.aclose()` into FastMCP's lifespan so httpx clients release
  cleanly on SIGTERM / uvicorn reload.
- **CLI**: new `--transport http` (streamable-http; MCP 2025-11
  preferred) plus `--host` / `--port` flags. `--transport sse` still
  works in 0.8.x with a `DeprecationWarning`; removed in 0.9.

### Added — Docker image

- **Standalone container image** published to
  `ghcr.io/allada-homelab/arr-py-client` on every tag / GitHub Release.
  Multi-stage `uv`-driven build on `python:3.13-slim-bookworm`, runs as
  non-root (UID 10001), defaults to streamable-HTTP on `0.0.0.0:3000`.
  Tags: `latest`, `{version}`, `{major}.{minor}`, `{major}`, and
  `sha-<short>` for immutable pinning. `linux/amd64` only for now.

### Breaking (internal API — alpha package)

- `build_server(radarr=, sonarr=, prowlarr=)` →
  `build_server(provider=...)`.
- `make_clients()` removed — use `EnvClientProvider(want_radarr=..., ...)`.
- `attach_radarr_tools(server, client)` →
  `attach_radarr_tools(server, provider, deps)` (same for
  sonarr/prowlarr/composed/describe).
- The "at least one client required" branch in `build_server` is gone:
  every brand's tools always register; unsupplied brands return a
  structured `client_not_configured` envelope on invocation rather
  than being hidden from `tools/list`.

### Migration

Local CLI / env-var flow — no change required. Direct API consumers:

```python
# Before (0.7.x):
from arr_py_client.mcp import build_server, make_clients
r, s, p = make_clients(want_radarr=True, want_sonarr=True)
server = build_server(radarr=r, sonarr=s, prowlarr=p)

# After (0.8.0):
from arr_py_client.mcp import build_server, EnvClientProvider
server = build_server(
    provider=EnvClientProvider(want_radarr=True, want_sonarr=True),
)
```

For multi-tenant deployments embedding the server in a FastAPI app, see
`docs/guides/mcp-multi-tenant.md`.

## [0.7.0] — 2026-04-21

Version-line normalization release. ``0.6.1`` was cut as a point-fix for
the Sonarr ``wikiUrl`` regression but inadvertently bundled the operator-
agent + TRaSH quality-size work that was staged on main, so the
``0.6.0 → 0.6.1`` PyPI diff is already the 0.7.0 feature diff in practice.
This 0.7.0 tag formally recategorizes those features under a minor-version
bump and ships the CI/infra cleanups that have landed since.

### Added — Operator agent (`arr_py_client.agent`)

- **`Agent`** — tick-driven rule runner composing the journal + dump +
  trash primitives into a declarative surface. One pass per
  `agent.tick()`; no daemon, no separate state file. Cadence
  (`rule.every`) derived from `agent.rule.<name>` journal markers so
  restarts are idempotent.
- **`Rule`** with factory classmethods: `Rule.janitor`, `Rule.backfill`,
  `Rule.config_sync`, `Rule.trash_sync`, `Rule.custom`. All wrap the
  existing typed primitives — no LLM inside.
- **`Budget`** — cross-rule caps on deletions/hour, deletions/day,
  searches/hour, plus `pause_if_error_rate_over` for error-rate
  short-circuits. Counts derived from existing journal entries.
- **`agent.status()`** and **`agent.preview(rule_name)`** — read-only
  introspection. Preview forces dry-run + bypasses cadence/budget.
- **MCP tools**: `arr_agent_status` + `arr_agent_preview` exposed when
  `build_server(agent=...)` is wired. Read-only by design (no
  `arr_agent_tick`) to limit prompt-injection blast radius.
- New guide: `docs/guides/operator-agent.md`.

### Added — TRaSH quality-size imports

- **`quality_definitions`** resource in `config_sync` — name-keyed,
  UPDATE-only (Radarr/Sonarr pre-seed these at install time; no
  create/delete even in strict mode). Wired through `plan`, `apply`,
  `dump`, and the loader.
- **`trash.fetch_quality_definition`** + **`list_quality_definitions`** +
  **`quality_definition_to_desired`** — fetch one TRaSH quality-size
  preset (`"movie"`, `"anime"`, `"series"`, etc.) and convert to the
  name-keyed desired-state shape. `fetch_desired_state(..., quality_definitions="movie")`
  bundles it alongside custom formats + release profiles.
- `arr_trash_import` MCP tool gained `quality_definitions=` kwarg.

### Fixed

- Release CI no longer promotes `PytestUnraisableExceptionWarning` to a
  hard failure. Pydantic's internal `json_schema` builder leaks sockets
  during model introspection; the narrow exemption leaves `error` strict
  for every other warning class.
- Docs build: broken cross-tree links in `architecture.md` and
  `roadmap.md` rewritten so `mkdocs --strict` passes.
- Pyright: residual errors in `tests/unit/test_config_sync_dump.py` and
  `tests/unit/test_trash.py` cleared so the full tree is 0-error.

## [0.6.1] — 2026-04-21

### Fixed

- **Sonarr `HealthResource.wikiUrl` ValidationError.** Upstream Sonarr's
  OpenAPI spec declares `wikiUrl` as the structured `HttpUri` type, but
  the live API returns a plain string — so `client.health.list_()`
  against a real Sonarr raised `pydantic.ValidationError` and callers
  using it as a liveness probe misclassified healthy instances as down.
  Patched the vendored spec + generated model to match reality, and
  added regression tests across all three brands so a spec refresh can't
  re-introduce the mismatch. Radarr and Prowlarr were already correct.

## [0.6.0] — 2026-04-21

**Prowlarr support.** Full typed client + curated indexer/applications/tags
facades, Prowlarr MCP tools, config_sync coverage for Prowlarr's
applications surface, and a live-verified end-to-end workflow.

### Added — Prowlarr

- `ProwlarrClient` / `AsyncProwlarrClient` — sync + async client for the
  Prowlarr v1 API. Pinned to upstream `v2.3.5.5327`. Auto-generated from
  the vendored OpenAPI spec, with three curated facades: `indexers`,
  `applications`, `tags`. Env vars: `PROWLARR_BASE_URL`,
  `PROWLARR_API_KEY`.
- `ProwlarrSettings` (pydantic-settings) built via the shared factory.
- `arr_py_client.testing.make_fake_prowlarr()` — respx-backed in-memory
  client mirroring the Radarr/Sonarr fakes pattern.
- **8 new MCP tools**: `prowlarr_ping`, `prowlarr_system_status`,
  `prowlarr_indexers_list`, `prowlarr_indexer_test_all`,
  `prowlarr_apps_list`, `prowlarr_app_test_all`, `prowlarr_history_list`,
  `prowlarr_logs_list`. All carry uniform `_meta.action_hints` per the
  Phase A policy.
- `arr_health` extended with a new `app="all"` mode that additionally
  reports Prowlarr's indexer + application counts.
- `arr-py-mcp` CLI: `--prowlarr-only` and `--with-prowlarr` flags.
  Default behavior auto-enables Prowlarr when `PROWLARR_BASE_URL` is set.
- Config sync: new `applications` resource (Prowlarr-only), plus silent
  skip of resources that don't apply to Prowlarr (`custom_formats`,
  `quality_profiles`, `root_folders`, `naming`) so a single desired-state
  file can target any brand. Example config extended with a `prowlarr:
  applications:` block.
- Webhook event type: `OnHealthRestored` — paired follow-up to
  `OnHealthIssue`, emitted by Radarr, Sonarr, and Prowlarr.
- Integration test suite: `lscr.io/linuxserver/prowlarr` compose service +
  `prowlarr_container` / `prowlarr_client` fixtures + three smoke tests
  under `tests/integration/prowlarr/`.
- CI: `schema-drift` workflow gained a `prowlarr` job watching upstream
  releases.

### Added — codegen parameterization

- `generate.py` / `gen_resources.py` / `resource.py.j2` now parameterize
  on `api_version` throughout (previously hardcoded to `v3`) so future
  brands or major-version bumps don't need template surgery.
- `render_models()` post-processes the datamodel-codegen output to strip
  per-class `extra='forbid'` declarations. Upstream specs routinely omit
  fields the live server returns (e.g. Prowlarr's `ApplicationResource.enable`);
  the stripped output defers to `ArrBaseModel`'s `extra="ignore"` policy.

### Added — docs

- [docs/product/prowlarr-architecture.md](docs/product/prowlarr-architecture.md)
  — memo mapping which `_common/` modules apply to Prowlarr and which
  don't.
- README gains Prowlarr across feature list, install, quickstart, and
  the comparison table (now four columns: arr-py-client, pyarr,
  Recyclarr, with separate rows for Prowlarr coverage and
  Lidarr/Readarr).

### Changed

- `build_server` and `make_clients` gained a `prowlarr=` parameter. The
  validation that at least one client is provided now accepts Prowlarr
  too.
- `justfile` `drift` recipe now takes an explicit `api_version` arg
  (``just drift prowlarr 1 v2.3.5.5327``) so it works for any brand.

## [0.5.0] — 2026-04-21

Feature + polish release. Phase A (cleanliness) + Phase B (feature
refinement) of the v0.4 PM review landed: coverage gate enforced, MCP
action-hints uniform, named janitor bundles, backfill `.estimate()`,
release-explain `.advice()`, config_sync YAML loader + expanded resource
coverage, webhook receiver helpers, and a truthful README. CLI scope is
now formally frozen.

### Added — feature refinement

- `arr_py_client.POLICIES` — named queue-janitor policy bundles:
  `POLICIES.conservative` (report-only), `.default` (current behavior),
  `.aggressive` (+size cap), `.ratio_preserving` (REMOVE_NO_BLOCKLIST to
  protect private-tracker ratio).
- `arr_py_client._common.backfill.estimate(...)` + `BackfillEstimate`
  dataclass — "128 items in 7 batches; ~3m 00s, done ~15:42:10" for
  planned runs. Wired into `arr_backfill` MCP response as
  `_meta.estimate`.
- `ReleaseExplanation.advice()` — translates rejection-reason rollups
  into plain-English next steps (raise this CF, allow that quality,
  `arr_add(...)` for unknown movies, etc.). Surfaced in
  `arr_explain_grab` MCP response as `advice`.
- `arr_py_client.config_sync.load(path)` + `DesiredState` pydantic
  schema — loads YAML (PyYAML via `[config]` extra) / JSON / TOML config
  files into the desired-state dict consumed by `plan()`. Name-keyed
  resources pivot from list form (YAML-ergonomic) to `{name: body}` form
  (planner-ready) automatically. Unknown top-level keys raise early.
- Config sync resource coverage: **root_folders** (keyed by path),
  **download_clients**, **indexers**, **notifications**,
  **naming** (singleton). All planner actions are dry-run-safe and
  per-change errors are captured in the report.
- `arr_py_client.webhooks.wsgi_app(handler)` — zero-dep WSGI receiver.
- `arr_py_client.webhooks.fastapi_router(handler)` — FastAPI
  `APIRouter` (requires `[webhooks]` extra). Both accept sync or async
  handlers; handler exceptions surface as 500s without killing the
  process.
- MCP `arr_janitor_run` gains `bundle=` kwarg
  (`default|conservative|aggressive|ratio_preserving`).

### Added — cleanliness / policy

- Coverage gate: pytest run via coverage now fails under 80%
  ([pyproject.toml](pyproject.toml) `fail_under = 80`, CI step no longer
  advisory-only).
- `_meta.action_hints` now enforced on every data-returning MCP tool via
  [tests/unit/test_mcp_action_hints_coverage.py](tests/unit/test_mcp_action_hints_coverage.py);
  reference tools (ping / delete / restore /
  `arr_describe_fields` / `arr_list_resources`) are explicitly excluded.
- Docs restructured: `docs/superpowers/` archived to `docs/archive/`;
  new [docs/architecture.md](docs/architecture.md) (current state +
  `Any`-audit policy) and [docs/roadmap.md](docs/roadmap.md) (now / next
  / later / won't).
- `docs/examples/config-sync/config.example.yaml` — canonical desired-state
  example covering every supported resource.

### Changed

- README rewritten to reflect v0.4 capstone features (MCP, workflows,
  webhooks, CLI freeze). Comparison table gained a Recyclarr column.
- CLI scope documented as frozen: status + basic add only. Workflow
  features (config-sync, release-explain, queue janitor, backfill)
  intentionally live in Python/MCP — CLI help text reflects this.
- README coverage badge corrected from 91% → 82% (matches reality).

### Fixed

- `config_sync._dump()` now handles bare dicts so planners can consume
  responses from the transport directly (needed for the `naming`
  singleton).

## [0.4.0] — 2026-04-21

Feature release — full Tier 1 + Tier 3 sweep plus MCP coverage for the new
capabilities. Radarr/Sonarr now have config sync, release explanation,
policy-based queue cleanup, and rate-limited backfill as first-class
workflows reachable from both Python and LLMs.

### Added — MCP composed tools for the new workflows

- `arr_sync_plan(app, desired, strict)` — preview config reconcile.
- `arr_sync_apply(app, desired, strict, dry_run)` — plan + apply. Defaults
  to `dry_run=True` for chat safety; per-change errors captured in report.
- `arr_explain_grab(title, app, episode_id?, season_number?)` — title →
  library id → annotated release table + `summary()` line.
- `arr_janitor_run(app, dry_run, protected_trackers)` — default policy bundle
  (manual-interaction ignore, import-blocked / stalled-6h / stuck →
  blocklist+research). Private-tracker indexers are downgraded to IGNORE.
- `arr_backfill(app, source, batch_size?, delay_between_batches, max_items,
  pause_if_queue_over, monitored_only, dry_run)` — Huntarr-shaped rate-
  limited missing-content search. `batch_size=None` picks brand-appropriate
  defaults (5 movies / 20 episodes).

### Added — new workflows (Tier 1 capstone set)

- `arr_py_client.config_sync` — brand-neutral Recyclarr/Profilarr-shaped
  declarative reconciler. `plan(client, desired)` diffs a desired-state dict
  against the live server and returns a `SyncPlan`; `apply(client, plan)` /
  `apply(..., dry_run=True)` execute (or preview) it. First cut covers
  `tags`, `custom_formats`, and `quality_profiles`; strict mode adds DELETE
  actions for items present on the server but missing from the config.
  Errors are captured per-change, so one broken item doesn't abort the run.
- `client.releases.explain(...)` (both brands) — "why didn't it grab the
  better version?" Fetches candidates + current-file state, scores and
  sorts them, and returns a `ReleaseExplanation` with accepted/rejected
  verdicts, rejection-reason rollups, and a `summary()` line suitable for
  CLI/MCP output. Accepted-first ranking uses CF score → quality weight →
  size ascending.
- `client.queue.janitor(...)` (both brands) — policy-based queue cleanup.
  Pluggable `JanitorPolicy` protocol (`StuckPolicy`, `StalledPolicy`,
  `ImportBlockedPolicy`, `ManualInteractionPolicy`, `SizeOverPolicy`,
  `StatusMessagesContainPolicy`). First-match-wins; `protected_trackers=`
  downgrades blocklist actions to IGNORE on private indexers so ratio
  isn't burned. `dry_run=True` by default.
- `client.library.backfill(...)` (both brands) — Huntarr-shaped safe
  missing-content search loop. Walks `/wanted/missing` (or `/cutoff`, or
  both), batches IDs, and posts `MoviesSearch` / `EpisodeSearch` with a
  delay between batches. Optional `pause_if_queue_over=N` short-circuits
  when the download queue is already saturated. `dry_run=True` returns
  the plan without calling the search command.

### Added — new resource facades (Tier 3 fill-ins)

- `client.parse.title("…")` (both brands) — programmatic access to the
  server's release-name parser. Useful for tests, debuggers, and MCP.
- `client.auto_tagging` (both brands) — CRUD + `schema()` over
  `/autotagging`. Auto-tagging is the "rule-based routing" surface
  (genre → tag, quality profile → tag, etc.) that custom formats don't cover.
- `client.delay_profiles` (both brands) — CRUD + `reorder(id=, after=)`
  over `/delayprofile` (the profile-order editor).
- `client.release_profiles` (both brands) — CRUD over `/releaseprofile`
  (must-contain / ignored / preferred-term scoring; complementary to CFs).
- `client.manual_import` (both brands, curated) — `candidates(...)` +
  `execute(items=, import_mode=)` for the full list → validate → execute
  manual-import workflow. The auto-generated `create()` posted an empty
  body and is superseded by `execute()`.
- `client.rename` (both brands) — `candidates(...)` previews + `execute(...)`
  fires `RenameMovie`/`RenameSeries` (or scoped `RenameFiles` with
  `movie_id=..+files=[...]` / `series_id=..+files=[...]`).

### Added — new webhook event types

- `OnMovieAdded`, `OnMovieDelete`, `OnMovieFileDelete`, `OnEpisodeFileDelete`,
  `OnManualInteractionRequired` — five permissive pydantic models to match
  the v0.3.x webhook catalog. `OnManualInteractionRequired` pairs with the
  new queue-janitor policy.

## [0.3.0] — 2026-04-21

Feature release — 22 planned items from the product-thinking plan, all landed
in one pass. Two waves: the minimum-viable set (v0.2.x → first wave) and this
broader sweep. 401 tests passing, clean basedpyright, clean ruff.

### Added — new resources

- `client.wanted` (both brands) — `missing()` / `iter_missing()` /
  `cutoff_unmet()` / `iter_cutoff_unmet()` paginated iterators over
  `/wanted/missing` and `/wanted/cutoff`.
- `client.library` (both brands) — `health_summary()` fans out to system
  status, health warnings, disk space, queue, and library count in one call
  (async uses `anyio.create_task_group` for parallelism). Also `.diff(tmdb_ids=)`
  / `.diff(tvdb_ids=)` and `.ical_url()`.
- `client.releases` (both brands) — `search()` / `grab()` / `best()` for
  manual indexer search + pick-the-best workflows.
- `client.import_lists` (both brands) — CRUD + `schema()` + `test()` + (Radarr
  only) `fetched_items()` over `/api/v3/importlist`.

### Added — new public modules

- `arr_py_client.testing` — `make_fake_radarr()` / `make_fake_sonarr()`
  context managers returning real clients backed by a preloaded respx router,
  plus `@replay("fixture.json")` decorator for record-on-miss / replay-on-hit
  tests.
- `arr_py_client.webhooks` — typed pydantic event models for Radarr/Sonarr
  webhook POSTs (`OnGrab`, `OnDownload`, `OnUpgrade`, `OnHealthIssue`,
  `OnApplicationUpdate`, `OnTest`, `UnknownEvent`) + `parse_event(payload)`.
- `arr_py_client.cli` + new `arr-py` console script — zero-dep argparse CLI
  with `health`, `config`, `radarr movies list|add`, `sonarr series list`,
  `queue stuck`. Supports `--format table|json|tsv`.

### Added — new public helpers

- `client.movies.iter_all()` / `.page(page=, size=)` / `.filter(tag=, monitored=,
  has_file=, year=, quality_profile=)` — same API on `client.series`.
- `client.movies.tag(ids=, add=[...], remove=[...], create_missing=True)` —
  bulk add/remove tags by name via the editor endpoint; same on `.series`.
- `client.queue.stuck()` / `.nuke_and_redownload(dry_run=)` / `.clear_stuck()` —
  identify warning/error/stalled queue items and optionally bulk-remove +
  blocklist + re-search.
- `client.commands.series_search` / `episode_search` / `movies_search` /
  `refresh_movie` / `rss_sync` / `backup` / `missing_*_search` /
  `cutoff_unmet_*_search` — typed wrappers with `KnownCommand` enums per brand.
- Name-based `.add()` for movies + series: accepts `title=` (uses top lookup
  match), `quality=` (name or id), `root_folder=` (path, auto-picks when sole
  configured), `tags=[...]` (labels with auto-create), `if_exists="skip"|"update"|"error"`.

### Added — new errors

- `ArrResolveError` — raised by resolvers on name/id miss, carries
  `valid_options` for actionable feedback.
- `ArrAlreadyExistsError` — raised by `.add(if_exists="error")` on duplicates.

### Added — MCP composed tools

- `arr_add` — title-based add that auto-dispatches between brands.
- `arr_health` — aggregate dashboard across both apps, with `_meta.action_hints`.
- `arr_cleanup_queue` — default `dry_run=True` for chat safety.
- `arr_upcoming` — ±N days calendar window across apps.
- `arr_find_release` — title → library → indexer search, returns sorted candidates.
- `arr_grab_release` — execute a specific release grab.
- `action_hints` pattern: every data-returning composed tool returns
  `_meta.action_hints` with likely next tool calls. Also added hints to
  `radarr_movies_get`, `sonarr_series_get`, `radarr_queue_list`,
  `sonarr_queue_list`.

### Changed

- Shared `_common/queue.py::is_stuck` helper consumed by both brand queues and
  both brand `library.health_summary()` calls (deduped three copies).
- Shared `_common/resolvers.py` (name→id helpers) consumed by both `.add()`
  implementations and both `.tag()` / `.filter()` implementations.

## [0.2.1] — 2026-04-20

### Changed
- Internal refactor: the two brand clients (Sonarr, Radarr) now share
  construction logic via `_common/client_base.py`. `__init__` bodies went
  from ~50 lines of per-brand assignment boilerplate to a
  `build_sync/async_transport` call plus two `wire_resources` calls.
- Transport sync + async retry loops share a single `_retry_delay` helper,
  deduplicating backoff / `Retry-After` handling.
- Settings factory: `RadarrSettings` / `SonarrSettings` are produced by a
  shared `_make_settings_cls(name, prefix)` and both subclass a new public
  `ArrSettings` base — public usage unchanged.
- `align_offset_to_page` moved from `mcp.server` (private `_page_args`) into
  `_common.pagination` as a public helper alongside `iter_pages` /
  `aiter_pages`.
- MCP paged tools deduplicated via a shared `_run_paged()` awaitable wrapper
  and a `_release_body()` model-build helper.
- Four duplicated `_paging()` test helpers consolidated into
  `tests/unit/_helpers.py`.

### Added
- `arr_py_client.mcp.make_clients` now re-exported from the public `mcp`
  module (previously only reachable via `arr_py_client.mcp.server`).
- 14 new unit tests covering the new shared helpers (`client_base`,
  `_retry_delay`, settings factory, pagination alignment, MCP public API).

## [0.2.0] — 2026-04-20

### Added
- `client.movies.add(tmdb_id=...)` and `client.series.add(tvdb_id=...)`: one-call
  lookup → create convenience wrappers (sync + async).
- `client.movies.delete_many` / `update_many` and `client.series.delete_many` /
  `update_many` via the `movie/editor` and `series/editor` bulk endpoints.
- New MCP tools (both apps): `blocklist_list`, `blocklist_delete`, `log_list`,
  `backup_list`, `backup_restore`, `manual_import_list`, `rename_list`,
  `release_push`, `download_clients_list`.
- `docs.yml` workflow: builds with mkdocs and auto-deploys to GitHub Pages on
  push to `main`.
- `CONTRIBUTING.md` with setup, common recipes, and release process.
- Coverage badge in `README.md`.

### Changed
- **MCP cursor pagination (breaking).** Replaced `radarr_queue_iter` /
  `sonarr_queue_iter` (which walked every page) with `radarr_queue_list` /
  `sonarr_queue_list` taking `limit` + `offset` and returning `_meta.total` and
  `_meta.next_offset`. `radarr_history_list` / new `sonarr_history_list` use
  the same shape. Offsets are aligned to the underlying page boundary.
- Async test coverage raised from 80% → 92% (257 tests).
- Sdist/wheel slimming: wheel no longer ships the `_common/codegen` tooling
  (~600K of OpenAPI specs); sdist still includes them for source consumers.
  Test fixtures excluded from sdist.

## [0.1.0] — 2026-04-20

### Added
- Initial release.
- Typed sync + async clients for Radarr v3 and Sonarr v3.
- Full endpoint coverage generated from upstream OpenAPI specs.
- Auto-generated resource wrappers per OpenAPI tag (`client.movie`, `client.queue`, ...) with
  hand-curated `client.movies` facade for the most-used Radarr resource.
- Env / `.env` fallback for credentials via `pydantic-settings`.
- Configurable retry policy (idempotent GET only by default).
- `py.typed` marker for PEP 561 compliance.
- Pinned upstream specs: Radarr v6.1.1.10360, Sonarr v4.0.17.2952.
