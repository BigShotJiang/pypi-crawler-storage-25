"""arr-py-client — typed sync + async client for Radarr and Sonarr APIs."""

from arr_py_client.__version__ import __version__
from arr_py_client._common import errors
from arr_py_client._common.backfill import BackfillPolicy
from arr_py_client._common.diagnostics import (
    DEFAULT_PORTS,
    ArrServerInfo,
    NormalizedBaseUrl,
    identify_arr_server,
    normalize_base_url,
)
from arr_py_client._common.janitor import POLICIES
from arr_py_client._common.retry import RetryPolicy
from arr_py_client._common.settings import (
    ProwlarrSettings,
    RadarrSettings,
    SonarrSettings,
)
from arr_py_client.config_sync import ConfigSyncPolicy
from arr_py_client.prowlarr import AsyncProwlarrClient, ProwlarrClient
from arr_py_client.radarr import AsyncRadarrClient, RadarrClient
from arr_py_client.sonarr import AsyncSonarrClient, SonarrClient

__all__ = [
    "DEFAULT_PORTS",
    "POLICIES",
    "ArrServerInfo",
    "AsyncProwlarrClient",
    "AsyncRadarrClient",
    "AsyncSonarrClient",
    "BackfillPolicy",
    "ConfigSyncPolicy",
    "NormalizedBaseUrl",
    "ProwlarrClient",
    "ProwlarrSettings",
    "RadarrClient",
    "RadarrSettings",
    "RetryPolicy",
    "SonarrClient",
    "SonarrSettings",
    "__version__",
    "errors",
    "identify_arr_server",
    "normalize_base_url",
]
