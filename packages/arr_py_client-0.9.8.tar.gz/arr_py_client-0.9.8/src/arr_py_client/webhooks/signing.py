"""HMAC signature verification for webhook receivers.

Radarr and Sonarr do not sign their built-in webhook payloads, so by
default the receiver helpers in :mod:`arr_py_client.webhooks.server`
accept anything that POSTs valid JSON. Users who expose a public webhook
URL almost always want defense-in-depth — typically by putting the *arr
instance behind a small relay that adds an HMAC signature, or by using
Radarr/Sonarr's "Custom Script" connection type to wrap the payload
with HMAC before forwarding.

This module provides :func:`hmac_sha256_verifier` which builds a
verifier callable. Pass that callable to ``wsgi_app(verify=...)`` or
``fastapi_router(verify=...)`` and the receiver will reject unsigned or
mis-signed requests with ``401 Unauthorized`` before the handler runs.

Two signing schemes are supported:

- **Plain HMAC** (the default; matches GitHub-style ``X-Hub-Signature-256``):
  the signature header carries an HMAC-SHA256 of the raw request body,
  optionally prefixed with ``"sha256="``. No timestamp.
- **Timestamped HMAC** (Stripe-shape; opt-in via
  ``timestamp_header=``): the signature is computed over
  ``f"{timestamp}.{body}"``. A separate header carries the Unix
  timestamp; the verifier rejects timestamps further than
  ``timestamp_tolerance_seconds`` from now (default 5 minutes), which
  prevents replay attacks against signed-but-recorded payloads.

The verifier raises :class:`InvalidSignatureError` on any failure
(missing header, malformed value, wrong secret, expired timestamp).
The receiver layer catches that and returns ``401`` to the caller.

Constant-time comparison via :func:`hmac.compare_digest` defends against
timing oracles. The verifier never logs the expected vs. provided
signature side-by-side — only the failure reason — so a partial
side-channel can't reveal the secret one byte at a time.
"""

from __future__ import annotations

import hmac
import time
from collections.abc import Callable, Mapping
from hashlib import sha256

# A verifier accepts the raw request body + a case-insensitive header
# mapping and returns ``None`` on success. It raises
# :class:`InvalidSignatureError` on any failure. ``Mapping[str, str]`` is
# the lowest-common-denominator shape; both WSGI environ helpers and
# Starlette's ``Headers`` adapt cleanly to it via
# :func:`normalize_headers`.
Verifier = Callable[[bytes, Mapping[str, str]], None]


class InvalidSignatureError(Exception):
    """Raised by a :data:`Verifier` when signature verification fails.

    The receiver layer (``wsgi_app`` / ``fastapi_router``) catches this
    and turns it into ``401 Unauthorized``. Don't catch it in handler
    code — the receivers are the right boundary.
    """


def normalize_headers(raw: Mapping[str, str]) -> dict[str, str]:
    """Flatten a header mapping to lowercase keys.

    Two input shapes are supported:

    - **WSGI environ**: when *any* key starts with ``HTTP_``, treat the
      mapping as a WSGI environ — only ``HTTP_*`` entries become
      headers (after stripping the prefix and converting underscores
      to dashes), and bookkeeping keys like ``CONTENT_LENGTH`` /
      ``REQUEST_METHOD`` are dropped. (``CONTENT_TYPE`` /
      ``CONTENT_LENGTH`` are technically the headers themselves, but
      they're handled by the receiver layer separately and don't
      participate in signature verification.)
    - **Plain header dict**: all keys are lowercased; nothing is
      dropped. Starlette ``Headers`` and any other already-headerlike
      mapping flow through unchanged.

    Lowercase keys give verifier authors one canonical shape to look
    up regardless of how the receiver collected them.
    """
    is_wsgi = any(k.startswith("HTTP_") for k in raw)
    out: dict[str, str] = {}
    for key, value in raw.items():
        if is_wsgi:
            if not key.startswith("HTTP_"):
                continue
            out[key[5:].lower().replace("_", "-")] = value
        else:
            out[key.lower()] = value
    return out


def _decode_signature(raw: str, prefix: str) -> bytes:
    """Strip the optional prefix and hex-decode the signature value.

    GitHub uses ``sha256=<hex>`` (prefix ``sha256=``); plain hex is also
    accepted. Returns the decoded bytes; raises :class:`InvalidSignatureError`
    on a malformed value rather than letting :exc:`ValueError` leak from
    ``bytes.fromhex``.
    """
    value = raw.strip()
    if prefix and value.startswith(prefix):
        value = value[len(prefix) :]
    try:
        return bytes.fromhex(value)
    except ValueError as exc:
        msg = "signature header is not valid hex"
        raise InvalidSignatureError(msg) from exc


def hmac_sha256_verifier(
    secret: bytes | str,
    *,
    header: str = "x-hub-signature-256",
    prefix: str = "sha256=",
    timestamp_header: str | None = None,
    timestamp_tolerance_seconds: float = 300.0,
    timestamp_separator: str = ".",
    now: Callable[[], float] | None = None,
) -> Verifier:
    """Build a :data:`Verifier` that checks HMAC-SHA256 against ``secret``.

    Parameters
    ----------
    secret
        Shared secret. ``str`` is encoded UTF-8.
    header
        Header carrying the signature (default ``x-hub-signature-256``,
        the GitHub convention; case-insensitive). Use
        ``x-webhook-signature`` for the more generic shape.
    prefix
        Optional prefix on the signature value (default ``"sha256="``).
        Set to ``""`` for plain hex (e.g. when the relay sends just the
        hex digest with no scheme tag).
    timestamp_header
        If set, opt into Stripe-style timestamped signing. The header
        carries a Unix timestamp (seconds, integer or float); the
        signature is computed over ``f"{timestamp}{separator}{body}"``.
        The verifier rejects requests whose timestamp is more than
        ``timestamp_tolerance_seconds`` from ``now()``.
    timestamp_tolerance_seconds
        ±window for the timestamp check. 5 minutes by default — long
        enough to absorb clock skew, short enough that an attacker who
        recorded the request can't replay it days later.
    timestamp_separator
        Joiner between timestamp and body in the signed payload
        (default ``"."``). Stripe uses ``"."``; some relays use
        ``":"``. Set to match the producer.
    now
        Override for the timestamp clock. Tests inject a fixed time
        here; production callers should leave it ``None``.

    Returns
    -------
    Verifier
        A callable usable as the ``verify=`` argument to
        :func:`arr_py_client.webhooks.server.wsgi_app` and
        :func:`arr_py_client.webhooks.server.fastapi_router`.
    """
    secret_bytes = secret if isinstance(secret, bytes) else secret.encode("utf-8")
    header_lc = header.lower()
    timestamp_header_lc = timestamp_header.lower() if timestamp_header else None
    clock = now or time.time

    def verify(body: bytes, headers: Mapping[str, str]) -> None:
        provided = headers.get(header_lc)
        if not provided:
            msg = f"missing signature header {header!r}"
            raise InvalidSignatureError(msg)

        ts_raw: str | None = None
        if timestamp_header_lc is not None:
            ts_raw = headers.get(timestamp_header_lc)
            if not ts_raw:
                msg = f"missing timestamp header {timestamp_header!r}"
                raise InvalidSignatureError(msg)
            try:
                ts = float(ts_raw)
            except ValueError as exc:
                msg = "timestamp header is not a number"
                raise InvalidSignatureError(msg) from exc
            if abs(clock() - ts) > timestamp_tolerance_seconds:
                msg = (
                    f"timestamp {ts_raw!r} outside ±{timestamp_tolerance_seconds:g}s"
                    " tolerance"
                )
                raise InvalidSignatureError(msg)
            signed_payload = f"{ts_raw}{timestamp_separator}".encode() + body
        else:
            signed_payload = body

        expected = hmac.new(secret_bytes, signed_payload, sha256).digest()
        provided_bytes = _decode_signature(provided, prefix)

        # ``compare_digest`` is constant-time over equal-length inputs;
        # for unequal lengths it short-circuits but the failure mode is
        # the same — neither leaks the expected bytes.
        if not hmac.compare_digest(expected, provided_bytes):
            msg = "signature mismatch"
            raise InvalidSignatureError(msg)

    return verify


__all__ = [
    "InvalidSignatureError",
    "Verifier",
    "hmac_sha256_verifier",
    "normalize_headers",
]
