"""MCP resources — application-driven context the host can splice into a chat.

Tools are model-driven: the LLM picks when to call them. Resources are
*application*-driven: the host (Claude desktop / VS Code / Cursor)
decides when to inject them as context. Two flavors live here:

**Tenant-independent** (work the same on any deployment, no auth):

- ``arr://help/quickstart`` — onboarding doc with tool index + workflows
- ``arr://schemas/list`` — same set as ``arr_describe_fields`` as context
- ``arr://schemas/{resource}`` — per-resource summary + all field lists

**Per-tenant** (route through the request's :class:`ClientProvider`,
honoring multi-tenant principals + scopes):

- ``arr://instances`` — every instance accessible to the caller
- ``arr://radarr/{instance_id}/queue`` — Radarr queue snapshot
- ``arr://sonarr/{instance_id}/queue`` — Sonarr queue snapshot
- ``arr://prowlarr/{instance_id}/indexers`` — Prowlarr indexer list
- ``arr://radarr/{instance_id}/health`` — one-brand health summary
- ``arr://sonarr/{instance_id}/health`` — same for Sonarr

The per-tenant resources accept a ``Context`` parameter that FastMCP
auto-injects, build a :class:`RequestContext` from it (same pattern as
tool decorators), and **enforce scopes** before routing to the matching
instance via ``provider.resolve_*``. Each read also fires an
:class:`AuditEvent` so security-conscious deployments see resource
reads in the same pipeline as tool calls. Errors land as JSON envelopes
with ``error.type`` (``insufficient_scope``, ``client_not_configured``,
``provider_error``).

The default scope for every per-tenant resource is ``mcp:arr:read``;
override via the ``resource_scope_overrides=`` kwarg on
:func:`build_server` (key shape: ``"radarr_queue"`` / ``"sonarr_queue"``
/ ``"prowlarr_indexers"`` / ``"radarr_health"`` / ``"sonarr_health"`` /
``"instances"``).

Resources mirror MCP spec 2025-06-18; FastMCP auto-generates the right
``mimeType`` from the return annotation (``str`` → ``text/plain``,
``dict`` → ``application/json``, etc.).
"""

# pyright: reportUnusedFunction=false, reportUnknownVariableType=false, reportUnknownMemberType=false, reportUnknownArgumentType=false, reportReturnType=false

from __future__ import annotations

import json
import logging
import time
from dataclasses import asdict
from typing import TYPE_CHECKING, Any

from arr_py_client.mcp.audit import AuditEvent, ScopeCheckSummary

# FastMCP needs ``Context`` importable at runtime to resolve string
# annotations on resource params (same constraint as composed tools).
from arr_py_client.mcp.context import MCPContext as Context  # noqa: TC001
from arr_py_client.mcp.scopes import SCOPE_READ

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.auth import DevAuth
    from arr_py_client.mcp.context import RequestContext
    from arr_py_client.mcp.provider import ClientProvider


_logger = logging.getLogger("arr_py_client.mcp.resources")


# Resource → required scopes. Mirror of ``DEFAULT_TOOL_SCOPES`` for the
# per-tenant resource set. Keys are the *short* resource handler names
# (``radarr_queue`` etc.) — overridable via the ``resource_scope_overrides``
# kwarg on ``build_server``. Tenant-independent resources
# (``help/quickstart``, ``schemas/*``) are NOT in this map and never
# require scope — they have no per-tenant data.
_DEFAULT_RESOURCE_SCOPES: dict[str, tuple[str, ...]] = {
    "instances": (SCOPE_READ,),
    "radarr_queue": (SCOPE_READ,),
    "sonarr_queue": (SCOPE_READ,),
    "prowlarr_indexers": (SCOPE_READ,),
    "radarr_health": (SCOPE_READ,),
    "sonarr_health": (SCOPE_READ,),
}


_QUICKSTART_DOC = """\
# arr-py-client MCP — quickstart

This server exposes the *arr stack (Radarr, Sonarr, Prowlarr) as MCP
tools, resources, and prompts.

## Tool families

- **`arr_*`** — composed cross-brand workflows. Start here:
  - `arr_health(app='all')` — fleet status dashboard
  - `arr_title_status(title=..., app=...)` — per-title library state
  - `arr_find_release(title=..., app=...)` — search indexers
  - `arr_grab_release(guid=..., indexer_id=..., app=...)` — commit a grab
  - `arr_cleanup_queue(app=..., dry_run=True)` — stuck-download cleanup
  - `arr_janitor_run(app=..., bundle=..., dry_run=True)` — policy janitor
  - `arr_backfill(app=..., dry_run=True)` — rate-limited missing-search
  - `arr_sync_plan` / `arr_sync_apply` / `arr_sync_dump` — config sync
  - `arr_bulk_edit` — bulk-edit movies or series
  - `arr_trash_import` — pull TRaSH-Guides bundles
- **`radarr_*` / `sonarr_*` / `prowlarr_*`** — brand-specific tools.
  In `surface="essentials"` mode only ping/system_status/lookup are
  exposed; pass `surface="full"` to see everything.
- **Reference** — `arr_describe_fields`, `arr_list_resources`,
  `arr_list_instances`, `arr_journal_list`.

## Workflows

- **"What's wrong with my fleet?"** → `arr_health(app='all')`.
- **"Why won't this download?"** → `arr_explain_grab(title=...)`.
- **"How many episodes of X do I have?"** → `arr_title_status(title=...)`.
- **"My queue is stuck"** → use the `triage_stuck_downloads` prompt.
- **"Audit missing episodes for X"** → use the `audit_missing_episodes`
  prompt.

## Safety defaults

Every destructive composed tool defaults to `dry_run=True`. Confirm
with the user before passing `dry_run=False`.

## More

- Schemas: see resource `arr://schemas/list` and `arr://schemas/{name}`.
- Prompts: discover via your client's `/` slash menu.
"""


def _error_payload(error_type: str, message: str, **extras: Any) -> str:
    """Standard JSON error envelope for resource handlers."""
    body: dict[str, Any] = {
        "error": {"type": error_type, "message": message, **extras},
    }
    return json.dumps(body)


def _resolve_instance_id(instance_id: str) -> str | None:
    """Map the URI template's ``{instance_id}`` to the provider's contract.

    Providers ship by the rule "``instance_id=None`` → default". URI
    templates can't carry ``None``, so the resource layer accepts
    ``"default"`` as the conventional placeholder and translates it
    back. Any other value passes through to the provider unchanged.
    """
    if instance_id == "default":
        return None
    return instance_id


def _resource_scopes(
    resource_name: str,
    overrides: dict[str, tuple[str, ...]] | None,
) -> tuple[str, ...]:
    """Resolve scopes for a per-tenant resource, mirroring tool resolution."""
    if overrides is not None and resource_name in overrides:
        return overrides[resource_name]
    return _DEFAULT_RESOURCE_SCOPES.get(resource_name, (SCOPE_READ,))


async def _emit_resource_audit(
    deps: ToolDeps | None,
    *,
    resource_name: str,
    uri: str,
    rctx: RequestContext | None,
    started_at: float,
    started_mono: float,
    status: str,
    scope_summary: ScopeCheckSummary | None,
    error_class: str | None,
    instance_id: str | None,
) -> None:
    """Emit an :class:`AuditEvent` for a resource read.

    No-op when ``deps`` is ``None`` (legacy callers that didn't thread
    a ``ToolDeps``). The event uses ``tool_name = uri`` so security
    teams can grep audit logs by URI pattern.
    """
    if deps is None:
        return
    from arr_py_client.mcp._decorators import emit_audit

    principal_id = rctx.principal.id if rctx and rctx.principal else None
    request_id = rctx.request_id if rctx else ""
    duration_ms = (time.monotonic() - started_mono) * 1000.0
    await emit_audit(
        deps.audit,
        AuditEvent(
            request_id=request_id,
            tool_name=uri,
            principal_id=principal_id,
            instance_id=instance_id,
            args_summary={"resource": resource_name},
            started_at=started_at,
            duration_ms=duration_ms,
            status=status,  # type: ignore[arg-type]  # AuditStatus literal at call sites
            scope_check=scope_summary,
            error_class=error_class,
        ),
    )


def _gated_resource(
    *,
    deps: ToolDeps | None,
    dev_auth: DevAuth | None,
    resource_name: str,
    uri: str,
    overrides: dict[str, tuple[str, ...]] | None,
) -> Callable[[Callable[..., Awaitable[str]]], Callable[..., Awaitable[str]]]:
    """Wrap a per-tenant resource handler with scope-check + audit.

    Mirror of :func:`gated_tool` for the resource surface. The handler
    keeps its FastMCP-shaped signature (``(...uri params, ctx: Context)
    -> str``); the wrapper intercepts ``ctx`` to build the request
    context, run a scope check against the principal, emit an audit
    event, and short-circuit to a JSON error envelope on denial.

    Tenant-independent resources (help, schemas) skip this gate — they
    don't take ``ctx`` and have no per-tenant data.
    """
    import functools

    required_scopes = _resource_scopes(resource_name, overrides)

    def decorator(
        fn: Callable[..., Awaitable[str]],
    ) -> Callable[..., Awaitable[str]]:
        @functools.wraps(fn)
        async def wrapper(*args: Any, **kwargs: Any) -> str:
            ctx: Context | None = kwargs.get("ctx")
            started_at = time.time()
            started_mono = time.monotonic()

            rctx: RequestContext | None = None
            if ctx is not None:
                from arr_py_client.mcp._decorators import (
                    build_request_context,
                )

                try:
                    rctx = build_request_context(ctx, dev_auth=dev_auth)
                except Exception:
                    _logger.warning(
                        (
                            "build_request_context failed for resource %s;"
                            " scope check will be skipped"
                        ),
                        uri,
                        exc_info=True,
                    )
                    rctx = None

            instance_id = kwargs.get("instance_id")

            scope_summary: ScopeCheckSummary | None = None
            if rctx and rctx.principal is not None:
                granted = rctx.principal.scopes
                if set(required_scopes).issubset(granted):
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="passed",
                    )
                else:
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="failed",
                    )
                    body = json.dumps(
                        {
                            "error": {
                                "type": "insufficient_scope",
                                "resource": uri,
                                "required": list(required_scopes),
                                "granted": sorted(granted),
                                "message": (
                                    f"{uri} requires scope(s) {list(required_scopes)} "
                                    f"but the principal has {sorted(granted)}"
                                ),
                            },
                        }
                    )
                    await _emit_resource_audit(
                        deps,
                        resource_name=resource_name,
                        uri=uri,
                        rctx=rctx,
                        started_at=started_at,
                        started_mono=started_mono,
                        status="scope_denied",
                        scope_summary=scope_summary,
                        error_class=None,
                        instance_id=instance_id,
                    )
                    return body
            else:
                scope_summary = ScopeCheckSummary(
                    required=required_scopes,
                    granted=frozenset(),
                    result="skipped",
                )

            try:
                result = await fn(*args, **kwargs)
            except Exception as exc:
                _logger.exception(
                    "resource %s handler raised %s",
                    uri,
                    type(exc).__name__,
                )
                await _emit_resource_audit(
                    deps,
                    resource_name=resource_name,
                    uri=uri,
                    rctx=rctx,
                    started_at=started_at,
                    started_mono=started_mono,
                    status="provider_error",
                    scope_summary=scope_summary,
                    error_class=type(exc).__name__,
                    instance_id=instance_id,
                )
                # Don't leak exception messages — upstream errors might
                # carry credential fragments. Mirror the brand-tool
                # provider_error envelope (which is opaque by design).
                return json.dumps(
                    {
                        "error": {
                            "type": "provider_error",
                            "resource": uri,
                            "message": (
                                "the credential provider encountered an internal error"
                            ),
                        }
                    }
                )

            # Inspect handler-returned envelopes to classify audit status.
            inferred_status = "ok"
            try:
                parsed: Any = json.loads(result)
            except (json.JSONDecodeError, ValueError, TypeError):
                parsed = None
            if isinstance(parsed, dict):
                err = parsed.get("error")
                if isinstance(err, dict):
                    err_type = err.get("type")
                    if err_type == "client_not_configured":
                        inferred_status = "client_not_configured"
                    elif err_type == "provider_error":
                        inferred_status = "provider_error"
                    elif err_type:
                        inferred_status = "tool_error"

            await _emit_resource_audit(
                deps,
                resource_name=resource_name,
                uri=uri,
                rctx=rctx,
                started_at=started_at,
                started_mono=started_mono,
                status=inferred_status,
                scope_summary=scope_summary,
                error_class=None,
                instance_id=instance_id,
            )
            return result

        return wrapper

    return decorator


def attach_resources(
    server: FastMCP,
    provider: ClientProvider | None = None,
    *,
    dev_auth: DevAuth | None = None,
    deps: ToolDeps | None = None,
    resource_scope_overrides: dict[str, tuple[str, ...]] | None = None,
) -> None:
    """Register MCP resources on ``server``.

    Tenant-independent resources (``arr://help/*``, ``arr://schemas/*``)
    are registered unconditionally and bypass scope/audit (no per-tenant
    data). When ``provider`` is supplied, per-tenant resources
    (``arr://instances``, ``arr://{brand}/{instance_id}/queue``, etc.)
    register through the same scope-check + audit pipeline brand and
    composed tools have.

    Parameters
    ----------
    provider
        Threaded into per-tenant resource handlers via
        ``provider.resolve_*``. Skip per-tenant registration when
        ``None`` — useful in test setups.
    dev_auth
        Mirror of the same ``build_server`` kwarg — synthesizes a
        principal when no live token exists. Required for stdio
        deployments that want per-tenant resources to work in
        single-user mode.
    deps
        :class:`ToolDeps` for audit emission. ``None`` skips audit
        (back-compat for callers that haven't migrated). When wired,
        every per-tenant resource read fires an :class:`AuditEvent`
        with ``tool_name=<uri>`` so security teams can correlate
        across tools and resources.
    resource_scope_overrides
        Per-resource scope override map. Keys are short handler names
        (``"radarr_queue"``, ``"sonarr_queue"``, ``"prowlarr_indexers"``,
        ``"radarr_health"``, ``"sonarr_health"``, ``"instances"``).
        Default is ``mcp:arr:read`` for every per-tenant resource.
    """
    from arr_py_client.mcp.projection import RESOURCE_REGISTRY, describe

    @server.resource(
        "arr://help/quickstart",
        title="arr-py-client quickstart",
        mime_type="text/markdown",
    )
    def quickstart() -> str:
        """Onboarding doc — tool index, workflows, safety defaults."""
        return _QUICKSTART_DOC

    @server.resource(
        "arr://schemas/list",
        title="Available resource schemas",
        mime_type="application/json",
    )
    def schemas_list() -> str:
        """JSON list of dotted-name resource identifiers.

        Mirror of ``arr_list_resources`` exposed as an attachable
        resource. Useful for hosts that want to pre-load the schema
        registry as context without burning a tool call.
        """
        return json.dumps(sorted(RESOURCE_REGISTRY.keys()))

    @server.resource(
        "arr://schemas/{resource}",
        title="Resource schema",
        mime_type="application/json",
    )
    def schema_for(resource: str) -> str:
        """Per-resource ``{resource, all, summary}`` field listing.

        Mirror of ``arr_describe_fields`` — host-attachable.
        ``resource`` follows the dotted-name convention
        (``radarr.movie``, ``sonarr.series``, etc.). Returns an empty
        JSON object for unknown resources rather than erroring, so
        clients can speculatively fetch.
        """
        try:
            payload = describe(resource)
        except (KeyError, ValueError):
            return "{}"
        return json.dumps(payload)

    if provider is None:
        _ = (quickstart, schemas_list, schema_for)
        return

    # ----------------------------------------- per-tenant resources --
    #
    # All per-tenant handlers take a ``Context`` so FastMCP treats them
    # as resource *templates*, not static resources. Templates need
    # ``{...}`` placeholders in the URI to route reads — that's why
    # there's no parameterless ``arr://instances`` here. Use the
    # ``arr_list_instances`` tool for the equivalent inventory view.

    from arr_py_client.mcp._decorators import build_request_context

    def _rctx(ctx: Context) -> RequestContext:
        return build_request_context(ctx, dev_auth=dev_auth)

    @server.resource(
        "arr://instances/{brand_filter}",
        title="Instances accessible to the caller (filterable)",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="instances",
        uri="arr://instances/{brand_filter}",
        overrides=resource_scope_overrides,
    )
    async def instances(brand_filter: str, ctx: Context) -> str:
        """JSON list of Arr instances visible to the current request principal.

        Mirror of ``arr_list_instances`` exposed as a host-attachable
        resource. ``brand_filter`` is one of ``radarr``, ``sonarr``,
        ``prowlarr``, or ``all`` (no filter). Each entry includes
        ``brand``, ``instance_id``, ``label``, ``is_default``, ``tags``.
        """
        rctx = _rctx(ctx)
        brand: Any = None if brand_filter == "all" else brand_filter
        try:
            insts = await provider.list_instances(rctx, brand=brand)
        except Exception as exc:
            return _error_payload("provider_error", str(exc))
        return json.dumps([asdict(i) for i in insts])

    @server.resource(
        "arr://radarr/{instance_id}/queue",
        title="Radarr queue snapshot",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="radarr_queue",
        uri="arr://radarr/{instance_id}/queue",
        overrides=resource_scope_overrides,
    )
    async def radarr_queue(instance_id: str, ctx: Context) -> str:
        """Top-of-queue snapshot for one Radarr instance.

        Returns the first page (20 items) of Radarr's queue with each
        item's id / title / status / size / sizeleft / progress —
        enough for "what's downloading right now?" without burning a
        tool call. Use ``radarr_queue_list`` for paginated access.
        """
        rctx = _rctx(ctx)
        try:
            client = await provider.resolve_radarr(
                rctx, instance_id=_resolve_instance_id(instance_id)
            )
            page = await client.queue.list(page=1, page_size=20)
        except Exception as exc:
            return _error_payload("client_not_configured", str(exc), brand="radarr")
        return _serialize_paged(page)

    @server.resource(
        "arr://sonarr/{instance_id}/queue",
        title="Sonarr queue snapshot",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="sonarr_queue",
        uri="arr://sonarr/{instance_id}/queue",
        overrides=resource_scope_overrides,
    )
    async def sonarr_queue(instance_id: str, ctx: Context) -> str:
        """Top-of-queue snapshot for one Sonarr instance.

        Same shape as ``arr://radarr/{instance_id}/queue`` — pair with
        ``arr_cleanup_queue(app='sonarr')`` for stuck-item triage.
        """
        rctx = _rctx(ctx)
        try:
            client = await provider.resolve_sonarr(
                rctx, instance_id=_resolve_instance_id(instance_id)
            )
            page = await client.queue.list(page=1, page_size=20)
        except Exception as exc:
            return _error_payload("client_not_configured", str(exc), brand="sonarr")
        return _serialize_paged(page)

    @server.resource(
        "arr://prowlarr/{instance_id}/indexers",
        title="Prowlarr indexer list",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="prowlarr_indexers",
        uri="arr://prowlarr/{instance_id}/indexers",
        overrides=resource_scope_overrides,
    )
    async def prowlarr_indexers(instance_id: str, ctx: Context) -> str:
        """All configured Prowlarr indexers for one instance.

        Returns ``[{id, name, protocol, enable, priority, ...}]`` —
        good context for "which indexer found this release?" or
        "which are disabled?".
        """
        rctx = _rctx(ctx)
        try:
            client = await provider.resolve_prowlarr(
                rctx, instance_id=_resolve_instance_id(instance_id)
            )
            indexers = await client.indexers.list()
        except Exception as exc:
            return _error_payload("client_not_configured", str(exc), brand="prowlarr")
        return json.dumps([_dump_model(i) for i in indexers])

    @server.resource(
        "arr://radarr/{instance_id}/health",
        title="Radarr health summary",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="radarr_health",
        uri="arr://radarr/{instance_id}/health",
        overrides=resource_scope_overrides,
    )
    async def radarr_health(instance_id: str, ctx: Context) -> str:
        """High-level health for one Radarr instance.

        Same payload as ``arr_health(app='radarr')`` for a single
        instance — version, queue counts, disk space, library size,
        ``healthy`` flag.
        """
        rctx = _rctx(ctx)
        try:
            client = await provider.resolve_radarr(
                rctx, instance_id=_resolve_instance_id(instance_id)
            )
            summary = await client.library.health_summary()
        except Exception as exc:
            return _error_payload("client_not_configured", str(exc), brand="radarr")
        return json.dumps(asdict(summary))

    @server.resource(
        "arr://sonarr/{instance_id}/health",
        title="Sonarr health summary",
        mime_type="application/json",
    )
    @_gated_resource(
        deps=deps,
        dev_auth=dev_auth,
        resource_name="sonarr_health",
        uri="arr://sonarr/{instance_id}/health",
        overrides=resource_scope_overrides,
    )
    async def sonarr_health(instance_id: str, ctx: Context) -> str:
        """High-level health for one Sonarr instance."""
        rctx = _rctx(ctx)
        try:
            client = await provider.resolve_sonarr(
                rctx, instance_id=_resolve_instance_id(instance_id)
            )
            summary = await client.library.health_summary()
        except Exception as exc:
            return _error_payload("client_not_configured", str(exc), brand="sonarr")
        return json.dumps(asdict(summary))

    # Silence unused-warnings for function scope; they're registered via decorator.
    _ = (
        quickstart,
        schemas_list,
        schema_for,
        instances,
        radarr_queue,
        sonarr_queue,
        prowlarr_indexers,
        radarr_health,
        sonarr_health,
    )


def _serialize_paged(paged: Any) -> str:
    """Serialize a ``QueueResourcePagingResource`` to JSON.

    Records → list of dicts, with the page metadata flattened into a
    top-level ``_meta`` envelope. Mirrors the shape of the brand-queue
    tools so clients can use one parser for both surfaces.
    """
    records = getattr(paged, "records", None) or []
    return json.dumps(
        {
            "data": [_dump_model(r) for r in records],
            "_meta": {
                "page": getattr(paged, "page", None),
                "page_size": getattr(paged, "page_size", None),
                "total": getattr(paged, "total_records", None),
            },
        }
    )


def _dump_model(obj: Any) -> dict[str, Any]:
    """Flatten a pydantic model (or dict) to a JSON-serializable dict.

    Used by per-tenant resource handlers — the underlying typed clients
    return generated pydantic models with snake_case field names that
    JSON-serialize cleanly via ``.model_dump()``. Falls back to ``vars``
    for non-pydantic types so the function works with the dataclass
    health summary too.
    """
    dump = getattr(obj, "model_dump", None)
    if callable(dump):
        return dump(by_alias=True, exclude_none=True, mode="json")
    if hasattr(obj, "__dict__"):
        return {k: v for k, v in vars(obj).items() if not k.startswith("_")}
    return {}
