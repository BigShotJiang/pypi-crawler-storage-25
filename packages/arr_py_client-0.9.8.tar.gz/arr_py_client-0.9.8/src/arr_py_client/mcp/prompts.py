"""Pre-templated MCP prompts surfaced as ``/slash`` commands in clients.

Prompts are user-controlled (the user picks them from a menu), unlike
tools which are model-controlled. They cost zero tool budget — the
client expands the template into a chat turn — so they're the natural
home for high-value workflows like "triage my stuck downloads" or
"audit my missing episodes".

Each prompt returns a list of MCP messages (typically a single user
message); the client can splice the result into the conversation.

These prompts intentionally reference other ``arr_*`` tools by name —
that's the point: they're an invitation for the LLM to chain the right
tools, not a separate code path. They walk the agent through a
multi-step reasoning sequence (look up → analyze → recommend → confirm).
"""

# pyright: reportUnusedFunction=false

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def attach_prompts(server: FastMCP) -> None:
    """Register slash-command prompts on ``server``.

    Always called from :func:`build_server`; surface-independent. Uses
    the ``@server.prompt`` decorator so each appears in the client's
    ``/`` menu under its title.
    """

    @server.prompt(
        title="Triage stuck downloads",
        description=(
            "Walk through stuck/failed/import-blocked items in a Radarr "
            "or Sonarr queue and recommend cleanup. Suggests tools to call."
        ),
    )
    def triage_stuck_downloads(
        app: Literal["radarr", "sonarr", "both"] = "both",
    ) -> str:
        """Prompt the LLM to triage stuck downloads end-to-end.

        ``app=both`` covers Radarr + Sonarr in one pass.
        """
        scope = (
            "both Radarr and Sonarr" if app == "both" else f"the {app.title()} queue"
        )
        return f"""Triage stuck downloads in {scope}. Step by step:

1. Call ``arr_health(app='all')`` to see what's stalled.
2. For each app with ``queue.stalled > 0``, call
   ``arr_cleanup_queue(app=..., dry_run=True)`` to see what would
   be cleaned and why.
3. For each candidate, decide:
   - **Re-search** (typical): ``arr_cleanup_queue(app=..., dry_run=False)``
     blocklists the bad release and re-searches.
   - **Just remove**: skip the blocklist if the user wants to allow
     re-grabbing the same release later.
4. After cleanup, call ``arr_health()`` again to confirm the queue
   cleared and recommend any follow-ups (``arr_backfill`` for
   missing items, ``arr_janitor_run`` if stuck items keep accumulating).

Default to **dry_run=True** for any destructive step. Confirm with the
user before flipping to ``dry_run=False``.
"""

    @server.prompt(
        title="Audit missing episodes",
        description=(
            "Look up a TV series and report missing episodes by season, "
            "with suggestions for searching."
        ),
    )
    def audit_missing_episodes(series_title: str) -> str:
        """Prompt the LLM to audit a series' completeness."""
        return f"""Audit episode completeness for the TV series "{series_title}".
Step by step:

1. Call ``arr_title_status(title="{series_title}", app='sonarr')`` for
   the per-season breakdown (it returns ``stats_by_season`` and
   ``missing_count`` / ``total_missing_count``).
2. If the series isn't in the library (``in_library=False``), suggest
   ``arr_add(title="{series_title}", app='sonarr')``. Stop here unless
   the user wants to add it.
3. If there are missing aired episodes, call
   ``arr_find_release(title="{series_title}", app='sonarr')`` to see
   what's available, then offer to grab the best candidate via
   ``arr_grab_release(...)``.
4. If the user wants to backfill in bulk, recommend
   ``arr_backfill(app='sonarr', source='missing', dry_run=True)``
   first to preview the search batches.

Format the report as Markdown. Highlight any unaired/unmonitored
seasons separately so the user doesn't think they're "missing".
"""

    @server.prompt(
        title="Weekly fleet health check",
        description=(
            "End-to-end weekly health audit: status, queue health, "
            "library gaps, indexer connectivity. Returns a concise summary."
        ),
    )
    def weekly_health_check() -> str:
        """Prompt the LLM to run a weekly fleet check."""
        return """Run a weekly health check across the whole *arr fleet.
Step by step:

1. Call ``arr_health(app='all')`` for a one-shot dashboard. Note any
   apps with ``healthy=False``, ``queue.stalled>0``, or low disk space.
2. For each Prowlarr instance: ``prowlarr_indexer_test_all()`` to
   verify indexer connectivity, then ``prowlarr_apps_list`` to confirm
   downstream Radarr/Sonarr connections.
3. If any queue has stalled items, run ``arr_cleanup_queue(...,
   dry_run=True)`` and ask the user before clearing.
4. Spot-check a few popular libraries via ``arr_title_status(title=...)``
   for any obvious gaps.
5. Summarize in 5-10 bullet points: what's healthy, what needs
   attention, recommended next actions. No long log dumps.

Default to **dry_run=True** for anything destructive.
"""

    @server.prompt(
        title="Recommend quality profile",
        description=(
            "Recommend a quality profile for a movie or series based on "
            "current library settings, disk space, and best-practice TRaSH guidance."
        ),
    )
    def recommend_quality_profile(
        title: str,
        app: Literal["radarr", "sonarr"],
    ) -> str:
        """Prompt the LLM to recommend a quality profile for a title."""
        return f"""Recommend a quality profile for "{title}" in
{app.title()}. Step by step:

1. Call ``arr_title_status(title="{title}", app='{app}')`` to see if
   the title is already in the library, and if so, its current
   ``quality_profile_id`` and ``size_on_disk``.
2. Call ``{app}_system_status`` and inspect the disk-space figures from
   ``arr_health(app='{app}')`` to estimate headroom.
3. List the configured profiles via the ``arr_sync_dump(app='{app}')``
   tool and propose either:
   - the existing profile if appropriate, or
   - importing a TRaSH-Guides profile via
     ``arr_trash_import(app='{app}', custom_formats=[...], release_profiles=[...], dry_run=True)``.
4. Return a short recommendation with reasoning: target resolution,
   approximate disk usage, and any TRaSH refs worth pinning.

Confirm with the user before applying anything destructive.
"""

    # Silence ruff/pyright unused warnings — registered via decorator.
    _ = (
        triage_stuck_downloads,
        audit_missing_episodes,
        weekly_health_check,
        recommend_quality_profile,
    )
