"""Per-brand tool decorators.

These wrap ``@server.tool()`` to inject a resolved brand client, enforce
scopes, build a library-owned :class:`RequestContext`, emit
:class:`AuditEvent`, and convert provider exceptions into MCP-shaped
error envelopes.

Tool bodies see one extra kwarg (``client``) that the decorator supplies
and never see ``ctx`` directly — the FastMCP ``Context`` is consumed by
the decorator boundary. This keeps tool bodies near-identical to the
0.7.x shape and centralizes every error-mapping decision.

**Schema synthesis**: FastMCP introspects ``inspect.signature(fn)`` to
build the LLM-facing JSON schema. The wrapper sets ``__signature__``
explicitly so:

- ``client`` is hidden (decorator-supplied).
- ``instance_id: str | None = None`` is exposed (LLM-facing).
- ``ctx: Context | None = None`` is hidden (FastMCP auto-injects).

If the SDK ever changes its schema-introspection mechanism, the test
``test_decorator_schema_synthesis`` is the canary — it asserts the exact
shape FastMCP ends up registering.
"""

from __future__ import annotations

import functools
import inspect
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol, cast, overload

from arr_py_client.mcp.audit import AuditEvent, AuditStatus, ScopeCheckSummary
from arr_py_client.mcp.context import MCPContext, Principal, RequestContext, Transport
from arr_py_client.mcp.provider import Brand, ClientNotConfiguredError, ClientProvider
from arr_py_client.mcp.scopes import resolve_scopes

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from mcp.server.fastmcp import FastMCP
    from mcp.types import ToolAnnotations

    from arr_py_client.mcp.audit import AuditCallback
    from arr_py_client.mcp.auth import DevAuth
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


@dataclass(frozen=True, slots=True)
class ToolDeps:
    """Server-level configuration the decorators need at call time.

    One instance per ``build_server`` call, threaded through every
    ``attach_*_tools`` function. Keeps the decorator factories compact:
    one positional ``deps`` rather than five separate kwargs.
    """

    audit: AuditCallback | None = None
    scope_overrides: dict[str, tuple[str, ...]] | None = None
    dev_auth: DevAuth | None = None


def _summarize_args(args: dict[str, Any]) -> dict[str, Any]:
    """Make tool args safe for audit sinks.

    Containers shrink to ``<<len=N>>`` placeholders; long strings
    truncate. Avoids accumulating PII or upstream credentials in audit
    storage where retention/access controls may be looser than the tool
    inputs warranted.
    """
    out: dict[str, Any] = {}
    container_types = (dict, list, tuple, set, frozenset, bytes, bytearray)
    for k, v in args.items():
        value: Any = v
        if isinstance(value, container_types):
            container = cast("Any", value)
            type_name = type(container).__name__
            container_len: int = len(container)
            out[k] = f"<<{type_name} len={container_len}>>"
        elif isinstance(value, str) and len(value) > 100:
            out[k] = value[:100] + "..."
        else:
            out[k] = value
    return out


def _detect_transport(mcp_ctx: MCPContext) -> Transport:
    """Infer which transport the request arrived over.

    HTTP / SSE both populate ``request_context.request`` with a
    Starlette object; stdio leaves it ``None``. We treat ``http`` as the
    default for HTTP-shaped requests since streamable-http is the new
    spec preferred transport — distinguishing http vs sse on the wire is
    not currently exposed by the SDK.
    """
    try:
        request = mcp_ctx.request_context.request
    except (AttributeError, ValueError):
        return "stdio"
    if request is None:
        return "stdio"
    return "http"


def build_request_context(
    mcp_ctx: MCPContext,
    *,
    dev_auth: DevAuth | None,
) -> RequestContext:
    """Adapt FastMCP ``Context`` + access token into our boundary type.

    The single place that imports from ``mcp.server.auth.middleware.*``
    so provider code never has to. ``dev_auth`` short-circuits token
    lookup — its principal is plumbed in regardless of transport.
    """
    from mcp.server.auth.middleware.auth_context import get_access_token

    transport = _detect_transport(mcp_ctx)

    headers: dict[str, str] = {}
    try:
        request = mcp_ctx.request_context.request
        if request is not None:
            # Starlette Headers behaves like a multidict; flatten to a plain
            # dict for the boundary type. Last value wins on duplicates,
            # which matches how upstream auth typically reads them.
            for k, v in request.headers.items():
                headers[k.lower()] = v
    except (AttributeError, ValueError):
        pass

    principal: Principal | None
    if dev_auth is not None:
        principal = dev_auth.principal
    else:
        access_token = get_access_token()
        if access_token is None:
            principal = None
        else:
            principal = Principal(
                id=access_token.client_id,
                scopes=frozenset(access_token.scopes),
                claims={},
                raw_token=access_token.token,
            )

    # ``ctx.request_id`` reads ``self.request_context.request_id``, which
    # raises ``ValueError`` when called outside a live request (e.g. when
    # composed tools build their own context from a synthetic FastMCP
    # ``Context``). Guard it.
    try:
        request_id = str(mcp_ctx.request_id or "")
    except (AttributeError, ValueError):
        request_id = ""

    return RequestContext(
        transport=transport,
        request_id=request_id,
        principal=principal,
        headers=headers,
        mcp_context=mcp_ctx,
    )


def _scope_envelope(
    *, tool_name: str, required: tuple[str, ...], granted: frozenset[str]
) -> dict[str, Any]:
    """Build the structured insufficient-scope error envelope.

    The shape is what the HTTP scope-middleware looks for to rewrite the
    response into RFC 6750 §3.1 ``403 + WWW-Authenticate``. On stdio,
    the body alone is the entire response.
    """
    out: dict[str, Any] = {
        "error": {
            "type": "insufficient_scope",
            "tool": tool_name,
            "required": list(required),
            "granted": sorted(granted),
            "message": (
                f"{tool_name} requires scope(s) {list(required)} but "
                f"the principal has {sorted(granted)}"
            ),
        },
        "_meta": {
            "action_hints": [
                "arr_list_resources()",
                f"# Re-authenticate with required scope(s): {list(required)}",
            ],
        },
    }
    return out


def _client_not_configured_envelope(message: str, *, brand: str) -> dict[str, Any]:
    return {
        "error": {
            "type": "client_not_configured",
            "brand": brand,
            "message": message,
        },
        "_meta": {
            "action_hints": [
                "arr_list_instances()",
                f"arr_health(app='{brand}')",
            ],
        },
    }


def _provider_error_envelope(*, brand: str) -> dict[str, Any]:
    """Generic envelope for unexpected provider exceptions.

    Deliberately does NOT include the exception message in the response —
    upstream / DB errors might leak credentials or internal URLs. The
    audit event carries the exception class name for ops correlation;
    the response is opaque.
    """
    return {
        "error": {
            "type": "provider_error",
            "brand": brand,
            "message": "the credential provider encountered an internal error",
        },
        "_meta": {
            "action_hints": [
                f"arr_health(app='{brand}')",
            ],
        },
    }


# NOTE: ``auth_required`` is a reserved :class:`AuditStatus` value but no
# code path emits it. The SDK's bearer middleware handles unauthenticated
# HTTP requests with a 401 + ``WWW-Authenticate`` header before any tool
# dispatches, so a tool body returning an ``auth_required`` envelope would
# be unreachable. The status value remains in the enum so downstream sinks
# can synthesize one from a 401 captured at a different layer if they want
# uniform classification across HTTP and stdio.


async def emit_audit(audit: AuditCallback | None, event: AuditEvent) -> None:
    """Call the audit sink, awaiting if it returned a coroutine.

    Errors from the sink are caught and logged WARN — a broken audit
    pipeline must not take down the MCP server.

    Public so adjacent layers (e.g. resource gating in
    :mod:`arr_py_client.mcp.resources`) can reuse the same fail-soft
    audit path without re-implementing it.
    """
    import logging

    if audit is None:
        from arr_py_client.mcp.audit import default_log_sink

        sink: AuditCallback = default_log_sink
    else:
        sink = audit

    try:
        result = sink(event)
        if inspect.isawaitable(result):
            await result
    except Exception:
        logging.getLogger("arr_py_client.mcp.audit").warning(
            "audit sink raised; event dropped (request_id=%s tool=%s)",
            event.request_id,
            event.tool_name,
            exc_info=True,
        )


def _classify_status_from_envelope(envelope: Any) -> AuditStatus:
    """Map a tool's structured response to an audit status.

    Tools deliberately return error envelopes (not raise) so FastMCP's
    generic ``-32603`` doesn't strip our ``action_hints``. We detect the
    error shape here for accurate audit classification.
    """
    if not isinstance(envelope, dict):
        return "ok"
    body = cast("dict[str, Any]", envelope)
    err = body.get("error")
    if isinstance(err, dict):
        err_dict = cast("dict[str, Any]", err)
        err_type = err_dict.get("type")
        if err_type == "insufficient_scope":
            return "scope_denied"
        if err_type == "client_not_configured":
            return "client_not_configured"
        if err_type == "provider_error":
            return "provider_error"
        if err_type == "auth_required":
            return "auth_required"
        return "tool_error"
    if body.get("ok") is False:
        return "tool_error"
    return "ok"


class _BoundBrandDecorator(Protocol):
    """Type for the per-brand decorator after binding ``(server, provider, deps)``.

    Supports two call shapes:

    - As a plain decorator: ``@rt`` — accepts the tool function directly.
    - As a kwargs binder: ``@rt(title=..., annotations=...)`` — returns a
      decorator parameterized by the per-tool metadata.

    Implemented in :func:`_make_brand_decorator` via a single
    ``callable_or_kwargs`` closure with overloaded behavior.
    """

    @overload
    def __call__(
        self, fn: Callable[..., Awaitable[Any]], /
    ) -> Callable[..., Awaitable[Any]]: ...

    @overload
    def __call__(
        self,
        *,
        name: str | None = None,
        title: str | None = None,
        annotations: ToolAnnotations | None = None,
    ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]: ...


class _BrandDecoratorFactory(Protocol):
    """Type for the brand decorator factory itself."""

    def __call__(
        self,
        server: FastMCP,
        provider: ClientProvider,
        deps: ToolDeps,
        *,
        name: str | None = None,
        title: str | None = None,
        annotations: ToolAnnotations | None = None,
    ) -> _BoundBrandDecorator: ...


def _make_brand_decorator(
    brand: Brand,
    expected_type_loader: Callable[[], type[Any]],
    resolver_attr: str,
) -> _BrandDecoratorFactory:
    """Factory that produces ``radarr_tool`` / ``sonarr_tool`` / ``prowlarr_tool``.

    Lifts the per-brand variation (which client class to expect, which
    provider method to call) into closures so the decorator body stays
    single-source-of-truth.
    """

    def brand_tool(
        server: FastMCP,
        provider: ClientProvider,
        deps: ToolDeps,
        *,
        name: str | None = None,
        title: str | None = None,
        annotations: ToolAnnotations | None = None,
    ) -> _BoundBrandDecorator:
        """Bind the brand decorator factory.

        Two call shapes are supported (both register a tool with FastMCP):

        - ``@brand_tool(server, provider, deps)`` followed by ``@rt`` —
          legacy bind-then-decorate. ``rt`` is a function-eating decorator.
        - ``rt = brand_tool(server, provider, deps); @rt(title=..., annotations=...)``
          — bind once, decorate per tool with kwargs. The returned ``rt``
          is callable both as a decorator (when given a function) and as
          a per-tool kwargs binder (when given keyword args only).
        """

        def make(
            *,
            name_: str | None,
            title_: str | None,
            annotations_: ToolAnnotations | None,
        ) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
            return _build_brand_decorator(
                server=server,
                provider=provider,
                deps=deps,
                brand=brand,
                expected_type_loader=expected_type_loader,
                resolver_attr=resolver_attr,
                name=name_,
                title=title_,
                annotations=annotations_,
            )

        default_decorator = make(name_=name, title_=title, annotations_=annotations)

        def callable_or_kwargs(
            fn: Callable[..., Awaitable[Any]] | None = None,
            *,
            name: str | None = None,
            title: str | None = None,
            annotations: ToolAnnotations | None = None,
        ) -> Any:
            if fn is not None:
                return default_decorator(fn)
            return make(name_=name, title_=title, annotations_=annotations)

        return cast("_BoundBrandDecorator", callable_or_kwargs)

    return brand_tool


def _build_brand_decorator(
    *,
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    brand: Brand,
    expected_type_loader: Callable[[], type[Any]],
    resolver_attr: str,
    name: str | None = None,
    title: str | None = None,
    annotations: ToolAnnotations | None = None,
) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
    """Build the actual decorator that wraps a single tool function.

    Pulled out of ``_make_brand_decorator`` so the per-tool kwargs path
    (``@rt(title=...)``) reuses the same body as the bind-then-decorate
    path (``rt = radarr_tool(...); @rt``).
    """

    def decorator(
        fn: Callable[..., Awaitable[Any]],
    ) -> Callable[..., Awaitable[Any]]:
        tool_name = name or fn.__name__
        required_scopes = resolve_scopes(tool_name, deps.scope_overrides)

        # ---- Synthesize the LLM-facing signature ----
        # Resolve PEP 563 string annotations per-parameter so FastMCP's
        # return-type introspection sees concrete generic types (e.g.
        # ``dict[str, Any]`` → RootModel, not ``{"result": ...}``). The
        # ``client`` parameter's annotation is a TYPE_CHECKING-only brand
        # class — we skip it entirely since it's stripped from the wrapper.
        raw_annotations: dict[str, Any] = getattr(fn, "__annotations__", {})
        fn_globalns: dict[str, Any] = getattr(fn, "__globals__", {})
        hints: dict[str, Any] = {}
        for ann_name, ann_value in raw_annotations.items():
            if ann_name == "client":
                continue
            if not isinstance(ann_value, str):
                hints[ann_name] = ann_value
                continue
            try:
                hints[ann_name] = eval(  # noqa: S307 — resolving our own annotations
                    ann_value, fn_globalns, None
                )
            except Exception:
                # Keep the string and let FastMCP fall back to its own
                # behavior rather than fail the whole decoration.
                hints[ann_name] = ann_value

        sig = inspect.signature(fn)
        params: list[inspect.Parameter] = []
        for n, p in sig.parameters.items():
            if n == "client":
                continue
            annot = hints.get(n, p.annotation)
            params.append(p.replace(annotation=annot))
        param_names = {p.name for p in params}
        if "instance_id" not in param_names:
            params.append(
                inspect.Parameter(
                    "instance_id",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=None,
                    annotation=str | None,
                )
            )
        # FastMCP auto-injects parameters typed as Context; appearing in
        # the wrapper signature is what triggers that injection. The
        # parameter is excluded from the JSON schema by the SDK because
        # of the type annotation.
        if "ctx" not in param_names:
            from mcp.server.fastmcp import Context as _SDKContext

            # Must be exactly ``Context`` (not ``Context | None``) for
            # FastMCP's schema-synthesis code to recognize it as the
            # injection slot and strip it from the LLM-facing schema.
            # Use the un-parametrized class so issubclass checks pass.
            params.append(
                inspect.Parameter(
                    "ctx",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=None,
                    annotation=_SDKContext,
                )
            )
        return_annot = hints.get("return", sig.return_annotation)
        wrapper_sig = sig.replace(parameters=params, return_annotation=return_annot)

        @functools.wraps(fn)
        async def wrapper(**kwargs: Any) -> Any:
            mcp_ctx: MCPContext | None = kwargs.pop("ctx", None)
            instance_id: str | None = kwargs.pop("instance_id", None)

            started_at = time.time()
            started_mono = time.monotonic()

            # ---- Build RequestContext ----
            request_context: RequestContext | None = None
            if mcp_ctx is not None:
                try:
                    request_context = build_request_context(
                        mcp_ctx, dev_auth=deps.dev_auth
                    )
                except Exception:
                    # If we can't build a context, pretend stdio anon —
                    # this is exotic but should not crash the tool.
                    request_context = RequestContext(
                        transport="stdio",
                        request_id="",
                        principal=None,
                        headers={},
                        mcp_context=mcp_ctx,
                    )

            principal_id = (
                request_context.principal.id
                if request_context and request_context.principal
                else None
            )

            # ---- Auth required check (only when token_verifier was set) ----
            # The presence of dev_auth pre-fills principal so it always passes.
            # We can't easily know "was token_verifier= set" from inside the
            # decorator, so we treat "principal is None AND scope is required
            # AND no dev_auth" as advisory: scope check is skipped for stdio.
            # The auth_required signal comes from the SDK's own bearer
            # middleware (401) before we get here for HTTP transports.

            # ---- Scope check ----
            scope_summary: ScopeCheckSummary | None = None
            if request_context and request_context.principal is not None:
                granted = request_context.principal.scopes
                required_set = set(required_scopes)
                if required_set.issubset(granted):
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="passed",
                    )
                else:
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="failed",
                    )
                    envelope = _scope_envelope(
                        tool_name=tool_name,
                        required=required_scopes,
                        granted=granted,
                    )
                    await emit_audit(
                        deps.audit,
                        AuditEvent(
                            request_id=(request_context.request_id or ""),
                            tool_name=tool_name,
                            principal_id=principal_id,
                            instance_id=instance_id,
                            args_summary=_summarize_args(kwargs),
                            started_at=started_at,
                            duration_ms=((time.monotonic() - started_mono) * 1000.0),
                            status="scope_denied",
                            scope_check=scope_summary,
                            error_class=None,
                        ),
                    )
                    return envelope
            else:
                scope_summary = ScopeCheckSummary(
                    required=required_scopes,
                    granted=frozenset(),
                    result="skipped",
                )

            # ---- Resolve client ----
            resolver = getattr(provider, resolver_attr)
            if request_context is None:
                # Synthesize a minimal one for tests that bypass FastMCP.
                # mcp_ctx may legitimately be None in such harnesses; cast
                # to MCPContext to satisfy the dataclass type — provider
                # code that touches mcp_context in synthetic flows will
                # see the consequence loudly there, not here.
                request_context = RequestContext(
                    transport="stdio",
                    request_id="",
                    principal=None,
                    headers={},
                    mcp_context=cast("MCPContext", mcp_ctx),
                )
            try:
                client = await resolver(request_context, instance_id=instance_id)
            except ClientNotConfiguredError as exc:
                envelope = _client_not_configured_envelope(str(exc), brand=brand)
                await emit_audit(
                    deps.audit,
                    AuditEvent(
                        request_id=request_context.request_id,
                        tool_name=tool_name,
                        principal_id=principal_id,
                        instance_id=instance_id,
                        args_summary=_summarize_args(kwargs),
                        started_at=started_at,
                        duration_ms=((time.monotonic() - started_mono) * 1000.0),
                        status="client_not_configured",
                        scope_check=scope_summary,
                        error_class=type(exc).__name__,
                    ),
                )
                return envelope
            except Exception as exc:
                import logging as _logging

                _logging.getLogger("arr_py_client.mcp").warning(
                    "provider raised %s for %s.resolve_%s",
                    type(exc).__name__,
                    type(provider).__name__,
                    brand,
                    exc_info=True,
                )
                envelope = _provider_error_envelope(brand=brand)
                await emit_audit(
                    deps.audit,
                    AuditEvent(
                        request_id=request_context.request_id,
                        tool_name=tool_name,
                        principal_id=principal_id,
                        instance_id=instance_id,
                        args_summary=_summarize_args(kwargs),
                        started_at=started_at,
                        duration_ms=((time.monotonic() - started_mono) * 1000.0),
                        status="provider_error",
                        scope_check=scope_summary,
                        error_class=type(exc).__name__,
                    ),
                )
                return envelope

            # ---- Wrong-brand guard ----
            expected_type = expected_type_loader()
            if not isinstance(client, expected_type):
                import logging

                logging.getLogger("arr_py_client.mcp").warning(
                    (
                        "provider returned wrong client type for"
                        " %s.resolve_%s: got %s, expected %s"
                    ),
                    type(provider).__name__,
                    brand,
                    type(client).__name__,
                    expected_type.__name__,
                )
                envelope = _provider_error_envelope(brand=brand)
                await emit_audit(
                    deps.audit,
                    AuditEvent(
                        request_id=request_context.request_id,
                        tool_name=tool_name,
                        principal_id=principal_id,
                        instance_id=instance_id,
                        args_summary=_summarize_args(kwargs),
                        started_at=started_at,
                        duration_ms=((time.monotonic() - started_mono) * 1000.0),
                        status="provider_error",
                        scope_check=scope_summary,
                        error_class="WrongBrandClient",
                    ),
                )
                return envelope

            # ---- Invoke the body ----
            try:
                result = await fn(client=client, **kwargs)
            except Exception as exc:
                import logging as _logging

                _logging.getLogger("arr_py_client.mcp").exception(
                    "tool %s body raised %s", tool_name, type(exc).__name__
                )
                envelope: dict[str, Any] = {
                    "error": {
                        "type": "tool_exception",
                        "tool": tool_name,
                        "message": ("tool body raised an unexpected exception"),
                    },
                    "_meta": {"action_hints": []},
                }
                await emit_audit(
                    deps.audit,
                    AuditEvent(
                        request_id=request_context.request_id,
                        tool_name=tool_name,
                        principal_id=principal_id,
                        instance_id=instance_id,
                        args_summary=_summarize_args(kwargs),
                        started_at=started_at,
                        duration_ms=((time.monotonic() - started_mono) * 1000.0),
                        status="tool_error",
                        scope_check=scope_summary,
                        error_class=type(exc).__name__,
                    ),
                )
                return envelope

            status = _classify_status_from_envelope(result)
            await emit_audit(
                deps.audit,
                AuditEvent(
                    request_id=request_context.request_id,
                    tool_name=tool_name,
                    principal_id=principal_id,
                    instance_id=instance_id,
                    args_summary=_summarize_args(kwargs),
                    started_at=started_at,
                    duration_ms=((time.monotonic() - started_mono) * 1000.0),
                    status=status,
                    scope_check=scope_summary,
                    error_class=None,
                ),
            )
            return result

        wrapper.__signature__ = wrapper_sig  # type: ignore[attr-defined]
        wrapper.__doc__ = fn.__doc__
        # FastMCP's ``find_context_parameter`` uses ``typing.get_type_hints``
        # which reads ``__annotations__`` — not ``__signature__`` — so we
        # must publish the synthesized annotations explicitly. The return
        # annotation comes from the inner function.
        synthesized_annotations: dict[str, Any] = {
            p.name: p.annotation
            for p in wrapper_sig.parameters.values()
            if p.annotation is not inspect.Parameter.empty
        }
        if wrapper_sig.return_annotation is not inspect.Signature.empty:
            synthesized_annotations["return"] = wrapper_sig.return_annotation
        wrapper.__annotations__ = synthesized_annotations
        return server.tool(
            name=tool_name,
            title=title,
            annotations=annotations,
        )(wrapper)

    return decorator


def _radarr_type() -> type[AsyncRadarrClientV3]:
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3

    return AsyncRadarrClientV3


def _sonarr_type() -> type[AsyncSonarrClientV3]:
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3

    return AsyncSonarrClientV3


def _prowlarr_type() -> type[AsyncProwlarrClientV1]:
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1

    return AsyncProwlarrClientV1


radarr_tool = _make_brand_decorator("radarr", _radarr_type, "resolve_radarr")
sonarr_tool = _make_brand_decorator("sonarr", _sonarr_type, "resolve_sonarr")
prowlarr_tool = _make_brand_decorator("prowlarr", _prowlarr_type, "resolve_prowlarr")


def gated_tool(
    server: FastMCP,
    deps: ToolDeps,
    *,
    name: str | None = None,
    title: str | None = None,
    annotations: ToolAnnotations | None = None,
) -> Callable[[Callable[..., Awaitable[Any]]], Callable[..., Awaitable[Any]]]:
    """Wrap a non-brand tool with the same scope + audit gate brand tools get.

    The brand decorators bind ``radarr_tool`` / ``sonarr_tool`` /
    ``prowlarr_tool`` to one provider resolver. This factory is for tools
    that don't have a single brand client to resolve — composed ``arr_*``
    tools (which resolve their own clients per-call) and describe /
    journal / agent reference tools.

    What the wrapper adds, identical to the brand decorator:

    - Builds :class:`RequestContext` from the FastMCP ``Context`` so
      ``deps.dev_auth`` and OAuth principals flow through.
    - Looks up the tool's required scopes via :func:`resolve_scopes` and
      enforces them against the principal's granted set. Returns the
      :func:`_scope_envelope` on a mismatch (which the ASGI middleware
      will rewrite to RFC 6750 ``WWW-Authenticate`` for HTTP transports).
    - Emits an :class:`AuditEvent` for every outcome — ``ok``,
      ``scope_denied``, ``tool_error`` — carrying the principal id,
      instance id, args summary, and duration.
    - Synthesizes a ``ctx`` parameter when the wrapped function doesn't
      declare one, so reference tools that have no use for ``Context``
      still trigger FastMCP auto-injection (otherwise the wrapper has no
      handle on the principal). The synthesized ``ctx`` is stripped from
      ``kwargs`` before calling the body.

    The wrapper does NOT resolve any provider client — composed tools
    do that themselves via :func:`resolve_or_error`. Brand-client
    resolution belongs in the brand decorator.

    Two call shapes are supported:

    - ``@gated_tool(server, deps, title=..., annotations=...)`` — used
      directly per-tool (the common case in
      :func:`attach_composed_tools`).
    - ``rt = gated_tool(server, deps); @rt(title=...)`` — bind once,
      decorate per tool. Mirrors the brand-tool ergonomics.
    """

    def decorator(
        fn: Callable[..., Awaitable[Any]],
    ) -> Callable[..., Awaitable[Any]]:
        tool_name = name or fn.__name__
        required_scopes = resolve_scopes(tool_name, deps.scope_overrides)

        # ---- Resolve PEP 563 string annotations ----
        # FastMCP's schema synthesis evaluates annotations at decorator-
        # time; we resolve here so wrapped tools that use forward refs
        # (e.g. ``"ArrAddOut"``) get concrete types in the registered
        # schema instead of opaque strings.
        raw_annotations: dict[str, Any] = getattr(fn, "__annotations__", {})
        fn_globalns: dict[str, Any] = getattr(fn, "__globals__", {})
        resolved: dict[str, Any] = {}
        for ann_name, ann_value in raw_annotations.items():
            if not isinstance(ann_value, str):
                resolved[ann_name] = ann_value
                continue
            try:
                resolved[ann_name] = eval(  # noqa: S307 — resolving our own annotations
                    ann_value, fn_globalns, None
                )
            except Exception:
                resolved[ann_name] = ann_value

        sig = inspect.signature(fn)
        params: list[inspect.Parameter] = []
        for n, p in sig.parameters.items():
            params.append(p.replace(annotation=resolved.get(n, p.annotation)))

        had_ctx_param = "ctx" in sig.parameters
        if not had_ctx_param:
            from mcp.server.fastmcp import Context as _SDKContext

            params.append(
                inspect.Parameter(
                    "ctx",
                    inspect.Parameter.KEYWORD_ONLY,
                    default=None,
                    annotation=_SDKContext,
                )
            )
        return_annot = resolved.get("return", sig.return_annotation)
        wrapper_sig = sig.replace(parameters=params, return_annotation=return_annot)

        @functools.wraps(fn)
        async def wrapper(**kwargs: Any) -> Any:
            mcp_ctx: MCPContext | None = (
                kwargs.get("ctx") if had_ctx_param else kwargs.pop("ctx", None)
            )

            started_at = time.time()
            started_mono = time.monotonic()

            request_context: RequestContext | None = None
            if mcp_ctx is not None:
                try:
                    request_context = build_request_context(
                        mcp_ctx, dev_auth=deps.dev_auth
                    )
                except Exception:
                    # Same fallback as the brand decorator. Logged loud
                    # so the gap between protocol promise and reality
                    # surfaces in ops logs rather than silently skipping
                    # the scope check.
                    import logging as _logging

                    _logging.getLogger("arr_py_client.mcp").warning(
                        (
                            "build_request_context failed for tool %s; "
                            "scope check will be skipped"
                        ),
                        tool_name,
                        exc_info=True,
                    )
                    request_context = None

            principal_id = (
                request_context.principal.id
                if request_context and request_context.principal
                else None
            )
            request_id = request_context.request_id if request_context else ""
            # Composed cross-brand tools take per-brand instance ids; pick
            # whichever is present so the audit event still carries one.
            instance_id: str | None = (
                kwargs.get("instance_id")
                or kwargs.get("radarr_instance_id")
                or kwargs.get("sonarr_instance_id")
                or kwargs.get("prowlarr_instance_id")
            )

            # ---- Scope check ----
            scope_summary: ScopeCheckSummary
            if request_context and request_context.principal is not None:
                granted = request_context.principal.scopes
                if set(required_scopes).issubset(granted):
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="passed",
                    )
                else:
                    scope_summary = ScopeCheckSummary(
                        required=required_scopes,
                        granted=granted,
                        result="failed",
                    )
                    envelope = _scope_envelope(
                        tool_name=tool_name,
                        required=required_scopes,
                        granted=granted,
                    )
                    await emit_audit(
                        deps.audit,
                        AuditEvent(
                            request_id=request_id,
                            tool_name=tool_name,
                            principal_id=principal_id,
                            instance_id=instance_id,
                            args_summary=_summarize_args(kwargs),
                            started_at=started_at,
                            duration_ms=((time.monotonic() - started_mono) * 1000.0),
                            status="scope_denied",
                            scope_check=scope_summary,
                            error_class=None,
                        ),
                    )
                    return envelope
            else:
                scope_summary = ScopeCheckSummary(
                    required=required_scopes,
                    granted=frozenset(),
                    result="skipped",
                )

            # ---- Invoke the body ----
            try:
                result = await fn(**kwargs)
            except Exception as exc:
                import logging as _logging

                _logging.getLogger("arr_py_client.mcp").exception(
                    "tool %s body raised %s", tool_name, type(exc).__name__
                )
                err_envelope: dict[str, Any] = {
                    "error": {
                        "type": "tool_exception",
                        "tool": tool_name,
                        "message": "tool body raised an unexpected exception",
                    },
                    "_meta": {"action_hints": []},
                }
                await emit_audit(
                    deps.audit,
                    AuditEvent(
                        request_id=request_id,
                        tool_name=tool_name,
                        principal_id=principal_id,
                        instance_id=instance_id,
                        args_summary=_summarize_args(kwargs),
                        started_at=started_at,
                        duration_ms=((time.monotonic() - started_mono) * 1000.0),
                        status="tool_error",
                        scope_check=scope_summary,
                        error_class=type(exc).__name__,
                    ),
                )
                return err_envelope

            status = _classify_status_from_envelope(result)
            await emit_audit(
                deps.audit,
                AuditEvent(
                    request_id=request_id,
                    tool_name=tool_name,
                    principal_id=principal_id,
                    instance_id=instance_id,
                    args_summary=_summarize_args(kwargs),
                    started_at=started_at,
                    duration_ms=((time.monotonic() - started_mono) * 1000.0),
                    status=status,
                    scope_check=scope_summary,
                    error_class=None,
                ),
            )
            return result

        wrapper.__signature__ = wrapper_sig  # type: ignore[attr-defined]
        wrapper.__doc__ = fn.__doc__
        synthesized_annotations: dict[str, Any] = {
            p.name: p.annotation
            for p in wrapper_sig.parameters.values()
            if p.annotation is not inspect.Parameter.empty
        }
        if wrapper_sig.return_annotation is not inspect.Signature.empty:
            synthesized_annotations["return"] = wrapper_sig.return_annotation
        wrapper.__annotations__ = synthesized_annotations
        return server.tool(
            name=tool_name,
            title=title,
            annotations=annotations,
        )(wrapper)

    return decorator
