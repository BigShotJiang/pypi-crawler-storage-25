"""Fleet fan-out helpers over :class:`ClientProvider`.

Typical use: run the same workflow — health summary, config-sync apply,
janitor sweep — across every Radarr (or Sonarr, or Prowlarr) instance the
current caller owns, with per-instance results and errors rolled up
cleanly.

The plumbing already exists in v0.8.0's
:class:`~arr_py_client.mcp.provider.ClientProvider`: ``list_instances``
discovers what's reachable, ``resolve_*(instance_id=...)`` hands back the
typed client. This module composes them into a concurrent fan-out with
partial-return semantics — a single instance going down never poisons
the rest of the run.

Example (MCP composed tool)::

    from arr_py_client.mcp.fleet import fan_out_radarr

    async def tool_fleet_health(ctx, provider):
        return await fan_out_radarr(
            provider,
            ctx,
            lambda client: client.library.health_summary(),
            filter_tags=("hd",),
        )

Filtering: ``filter_tags`` keeps only instances whose
:attr:`InstanceInfo.tags` intersect the given set; ``include`` /
``exclude`` narrow by ``instance_id``. All filters AND together.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Generic, TypeVar

from arr_py_client.config_sync import apply_async, dump_async, plan_async

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable, Collection, Mapping, Sequence

    from arr_py_client.config_sync import ConfigSyncPolicy, SyncPlan, SyncReport
    from arr_py_client.config_sync.core import Resource
    from arr_py_client.mcp.context import RequestContext
    from arr_py_client.mcp.provider import Brand, ClientProvider, InstanceInfo
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3

T = TypeVar("T")


@dataclass(frozen=True)
class FleetResult(Generic[T]):
    """Per-instance outcome of a fleet fan-out call.

    ``results`` holds successful returns keyed by ``instance_id``;
    ``errors`` holds per-instance exceptions keyed the same way;
    ``skipped`` is the tuple of ``instance_id`` values filtered out
    before ``fn`` ran (by ``filter_tags`` / ``include`` / ``exclude``).
    The three keysets are disjoint and cover every instance the provider
    reported via :meth:`ClientProvider.list_instances`.

    The fan-out never raises — a single instance failure lands in
    ``errors``, and the caller decides whether to propagate.
    """

    results: dict[str, T] = field(default_factory=dict)
    errors: dict[str, Exception] = field(default_factory=dict)
    skipped: tuple[str, ...] = ()

    @property
    def ok(self) -> bool:
        """True iff every selected instance returned a result (no errors)."""
        return not self.errors

    @property
    def any_ok(self) -> bool:
        """True iff at least one selected instance returned a result."""
        return bool(self.results)

    def summary(self) -> str:
        """One-line ``FleetResult: N ok, N failed, N skipped`` string."""
        parts = [f"{len(self.results)} ok"]
        if self.errors:
            parts.append(f"{len(self.errors)} failed")
        if self.skipped:
            parts.append(f"{len(self.skipped)} skipped")
        return "FleetResult: " + ", ".join(parts)


def _select(
    infos: list[InstanceInfo],
    *,
    filter_tags: Collection[str] | None,
    include: Collection[str] | None,
    exclude: Collection[str] | None,
) -> tuple[list[InstanceInfo], tuple[str, ...]]:
    """Partition ``infos`` into (selected, skipped) per the filter args."""
    filter_tags_set = set(filter_tags) if filter_tags else None
    include_set = set(include) if include else None
    exclude_set = set(exclude) if exclude else None

    selected: list[InstanceInfo] = []
    skipped: list[str] = []
    for info in infos:
        if include_set is not None and info.instance_id not in include_set:
            skipped.append(info.instance_id)
            continue
        if exclude_set is not None and info.instance_id in exclude_set:
            skipped.append(info.instance_id)
            continue
        if filter_tags_set is not None and not set(info.tags) & filter_tags_set:
            skipped.append(info.instance_id)
            continue
        selected.append(info)
    return selected, tuple(skipped)


async def _run_one(
    resolve: Callable[..., Awaitable[Any]],
    fn: Callable[[Any], Awaitable[T]],
    ctx: RequestContext,
    info: InstanceInfo,
) -> tuple[str, T | Exception]:
    """Resolve one instance and run ``fn`` against it, capturing any exception."""
    try:
        client = await resolve(ctx, instance_id=info.instance_id)
        result = await fn(client)
    except Exception as exc:
        return (info.instance_id, exc)
    return (info.instance_id, result)


async def _fan_out(
    infos: list[InstanceInfo],
    resolve: Callable[..., Awaitable[Any]],
    fn: Callable[[Any], Awaitable[T]],
    ctx: RequestContext,
    *,
    filter_tags: Collection[str] | None,
    include: Collection[str] | None,
    exclude: Collection[str] | None,
) -> FleetResult[T]:
    """Shared fan-out body — filter, spawn, collect."""
    selected, skipped = _select(
        infos, filter_tags=filter_tags, include=include, exclude=exclude
    )
    if not selected:
        return FleetResult(skipped=skipped)
    pairs = await asyncio.gather(
        *(_run_one(resolve, fn, ctx, info) for info in selected),
    )
    results: dict[str, T] = {}
    errors: dict[str, Exception] = {}
    for instance_id, res in pairs:
        if isinstance(res, Exception):
            errors[instance_id] = res
        else:
            results[instance_id] = res
    return FleetResult(results=results, errors=errors, skipped=skipped)


async def fan_out_radarr(
    provider: ClientProvider,
    ctx: RequestContext,
    fn: Callable[[AsyncRadarrClientV3], Awaitable[T]],
    *,
    filter_tags: Collection[str] | None = None,
    include: Collection[str] | None = None,
    exclude: Collection[str] | None = None,
) -> FleetResult[T]:
    """Run ``fn`` across every accessible Radarr instance concurrently.

    Discovers instances via
    :meth:`ClientProvider.list_instances(brand="radarr")`, resolves each
    via :meth:`resolve_radarr`, and runs ``fn(client)`` on each.
    Exceptions are captured per-instance in :attr:`FleetResult.errors`.

    :param filter_tags: Keep only instances whose
        :attr:`InstanceInfo.tags` intersect this collection.
    :param include: Keep only these specific ``instance_id`` values.
    :param exclude: Skip these specific ``instance_id`` values.
    """
    infos = await provider.list_instances(ctx, brand="radarr")
    return await _fan_out(
        infos,
        provider.resolve_radarr,
        fn,
        ctx,
        filter_tags=filter_tags,
        include=include,
        exclude=exclude,
    )


async def fan_out_sonarr(
    provider: ClientProvider,
    ctx: RequestContext,
    fn: Callable[[AsyncSonarrClientV3], Awaitable[T]],
    *,
    filter_tags: Collection[str] | None = None,
    include: Collection[str] | None = None,
    exclude: Collection[str] | None = None,
) -> FleetResult[T]:
    """Sonarr twin of :func:`fan_out_radarr`."""
    infos = await provider.list_instances(ctx, brand="sonarr")
    return await _fan_out(
        infos,
        provider.resolve_sonarr,
        fn,
        ctx,
        filter_tags=filter_tags,
        include=include,
        exclude=exclude,
    )


async def fan_out_prowlarr(
    provider: ClientProvider,
    ctx: RequestContext,
    fn: Callable[[AsyncProwlarrClientV1], Awaitable[T]],
    *,
    filter_tags: Collection[str] | None = None,
    include: Collection[str] | None = None,
    exclude: Collection[str] | None = None,
) -> FleetResult[T]:
    """Prowlarr twin of :func:`fan_out_radarr`."""
    infos = await provider.list_instances(ctx, brand="prowlarr")
    return await _fan_out(
        infos,
        provider.resolve_prowlarr,
        fn,
        ctx,
        filter_tags=filter_tags,
        include=include,
        exclude=exclude,
    )


def _resolver_for(
    provider: ClientProvider, brand: Brand
) -> Callable[..., Awaitable[Any]]:
    """Return the provider's ``resolve_*`` coroutine for ``brand``."""
    if brand == "radarr":
        return provider.resolve_radarr
    if brand == "sonarr":
        return provider.resolve_sonarr
    if brand == "prowlarr":
        return provider.resolve_prowlarr
    raise ValueError(f"Unknown brand: {brand!r}")


async def fleet_plan(
    provider: ClientProvider,
    ctx: RequestContext,
    brand: Brand,
    desired: Mapping[str, Any],
    *,
    policy: ConfigSyncPolicy | None = None,
    strict: bool = False,
    include: Sequence[Resource] | None = None,
    filter_tags: Collection[str] | None = None,
    include_instances: Collection[str] | None = None,
    exclude: Collection[str] | None = None,
) -> FleetResult[SyncPlan]:
    """Plan a config-sync reconcile against every instance of ``brand``.

    Shares one ``desired`` document across the fleet and returns a
    :class:`FleetResult` whose ``results`` map ``instance_id`` →
    :class:`~arr_py_client.config_sync.SyncPlan`. Pass the returned map
    (or a subset) to :func:`fleet_apply` to execute. Per-instance
    planning failures land in :attr:`FleetResult.errors`; a single
    unreachable instance never poisons the rest of the fleet.

    Pass ``policy=POLICIES.config_sync.<bundle>`` for the named
    bundles; ``strict`` / ``include`` are ignored when ``policy`` is
    passed. Use ``filter_tags`` / ``include_instances`` / ``exclude``
    to narrow the target set — same AND semantics as
    :func:`fan_out_radarr`.
    """
    if policy is not None:
        plan_kwargs = policy.as_plan_kwargs()
    else:
        plan_kwargs = {"strict": strict}
        if include is not None:
            plan_kwargs["include"] = list(include)

    async def fn(client: Any) -> SyncPlan:
        return await plan_async(client, desired, **plan_kwargs)

    infos = await provider.list_instances(ctx, brand=brand)
    return await _fan_out(
        infos,
        _resolver_for(provider, brand),
        fn,
        ctx,
        filter_tags=filter_tags,
        include=include_instances,
        exclude=exclude,
    )


async def fleet_apply(
    provider: ClientProvider,
    ctx: RequestContext,
    brand: Brand,
    plans: Mapping[str, SyncPlan],
    *,
    policy: ConfigSyncPolicy | None = None,
    dry_run: bool = True,
    journal: Any | None = None,
) -> FleetResult[SyncReport]:
    """Apply a per-instance plan map concurrently; collect per-instance reports.

    ``plans`` is keyed by ``instance_id`` — typically the ``results``
    of a prior :func:`fleet_plan` call, optionally filtered. Instances
    not present in the map are simply not visited (there is no implicit
    re-planning). Each plan runs against its own resolved client; a
    resolve failure or an exception inside ``apply_async`` lands in
    :attr:`FleetResult.errors` under the matching ``instance_id``.

    Pass ``policy=POLICIES.config_sync.<bundle>`` for the named
    bundles; ``dry_run`` is ignored when ``policy`` is passed. The
    ``journal`` kwarg always flows through unchanged — the policy
    bundles don't carry a journal.
    """
    if policy is not None:
        apply_kwargs = policy.as_apply_kwargs()
    else:
        apply_kwargs = {"dry_run": dry_run}
    apply_kwargs["journal"] = journal

    if not plans:
        return FleetResult()

    resolve = _resolver_for(provider, brand)

    async def _apply_one(
        instance_id: str, pl: SyncPlan
    ) -> tuple[str, SyncReport | Exception]:
        try:
            client = await resolve(ctx, instance_id=instance_id)
            report = await apply_async(client, pl, **apply_kwargs)
        except Exception as exc:
            return (instance_id, exc)
        return (instance_id, report)

    pairs = await asyncio.gather(
        *(_apply_one(iid, pl) for iid, pl in plans.items()),
    )
    results: dict[str, SyncReport] = {}
    errors: dict[str, Exception] = {}
    for instance_id, res in pairs:
        if isinstance(res, Exception):
            errors[instance_id] = res
        else:
            results[instance_id] = res
    return FleetResult(results=results, errors=errors, skipped=())


async def fleet_dump(
    provider: ClientProvider,
    ctx: RequestContext,
    brand: Brand,
    *,
    include: Sequence[Resource] | None = None,
    filter_tags: Collection[str] | None = None,
    include_instances: Collection[str] | None = None,
    exclude: Collection[str] | None = None,
) -> FleetResult[dict[str, Any]]:
    """Dump current config state from every instance of ``brand``.

    Returns a :class:`FleetResult` whose ``results`` map
    ``instance_id`` → the desired-state dict each instance would
    produce. Useful for fleet-level diffing, drift detection, or
    seeding a shared ``desired`` document. Filtering follows the same
    rules as :func:`fleet_plan`.
    """
    dump_kwargs: dict[str, Any] = {}
    if include is not None:
        dump_kwargs["include"] = list(include)

    async def fn(client: Any) -> dict[str, Any]:
        return await dump_async(client, **dump_kwargs)

    infos = await provider.list_instances(ctx, brand=brand)
    return await _fan_out(
        infos,
        _resolver_for(provider, brand),
        fn,
        ctx,
        filter_tags=filter_tags,
        include=include_instances,
        exclude=exclude,
    )


__all__ = [
    "FleetResult",
    "fan_out_prowlarr",
    "fan_out_radarr",
    "fan_out_sonarr",
    "fleet_apply",
    "fleet_dump",
    "fleet_plan",
]
