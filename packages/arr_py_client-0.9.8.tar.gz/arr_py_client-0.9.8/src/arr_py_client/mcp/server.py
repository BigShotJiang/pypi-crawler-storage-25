"""Build an MCP server exposing curated Radarr/Sonarr/Prowlarr operations as tools.

Every list/get tool returns ``{"data": ..., "_meta": {fields_mode, resource[, hint]}}``.
``fields`` accepts ``"summary"`` (default for lists) | ``"all"`` (default for
single-record gets) | comma-separated subset like ``"id,title,year"``.

When ``fields="summary"``, the ``_meta.hint`` tells the calling LLM how to ask
for more — either ``fields='all'`` or via :func:`arr_describe_fields`.

Paged tools take ``limit`` (max records to return, default 20) and ``offset``
(records to skip, default 0). They return ``_meta.total`` and
``_meta.next_offset`` (``None`` when there are no more rows). ``offset`` is
rounded down to the nearest ``limit`` boundary because the upstream API is
page-based.

Clients are resolved per-request through a :class:`ClientProvider`. For local
single-tenant use pass :class:`EnvClientProvider`; for multi-tenant
deployments supply your own credential-store-backed provider and the
``token_verifier=`` / ``auth=`` kwargs to plumb OAuth 2.1.

Tool implementations live in :mod:`arr_py_client.mcp.tools`, split by group:
one module per brand (``radarr``, ``sonarr``, ``prowlarr``) plus ``composed``
(cross-brand ``arr_*`` tools) and ``describe`` (reference/metadata tools).
"""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, Literal

from mcp.server.fastmcp import FastMCP

from arr_py_client.mcp._decorators import ToolDeps
from arr_py_client.mcp.auth import DevAuth, assert_dev_auth_allowed
from arr_py_client.mcp.prompts import attach_prompts
from arr_py_client.mcp.resources import attach_resources
from arr_py_client.mcp.tools import (
    attach_composed_tools,
    attach_describe_tool,
    attach_prowlarr_tools,
    attach_radarr_tools,
    attach_sonarr_tools,
)

ToolSurface = Literal["essentials", "full"]
"""Which slice of brand tools to register.

- ``"essentials"`` (curated): the high-leverage handful per brand
  (ping, system_status, lookup) plus the prowlarr indexer list. Total
  surface ~30 tools — keeps LLM tool-selection accuracy high while
  still covering 90% of normal workflows via the composed ``arr_*``
  tools.
- ``"full"`` (default): every brand tool plus composed/reference. ~64
  tools total. Recommended when an operator drives the surface
  directly (CLI, scripted automation) rather than via an LLM.
"""

# Tools registered when ``surface="essentials"``. Composed + reference
# tools always register regardless. Per-brand attachers consult this set
# to decide what to skip.
_ESSENTIAL_BRAND_TOOLS: frozenset[str] = frozenset(
    {
        # Radarr essentials
        "radarr_ping",
        "radarr_system_status",
        "radarr_movies_lookup",
        # Sonarr essentials
        "sonarr_ping",
        "sonarr_system_status",
        "sonarr_series_lookup",
        # Prowlarr essentials (smaller surface, indexers list earns its slot)
        "prowlarr_ping",
        "prowlarr_system_status",
        "prowlarr_indexers_list",
    }
)

if TYPE_CHECKING:
    from collections.abc import AsyncGenerator, Mapping, Sequence

    from mcp.server.auth.provider import TokenVerifier
    from mcp.server.auth.settings import AuthSettings

    from arr_py_client.agent import Agent
    from arr_py_client.mcp.audit import AuditCallback
    from arr_py_client.mcp.provider import ClientProvider


logger = logging.getLogger("arr_py_client.mcp")


def build_server(
    *,
    provider: ClientProvider,
    name: str = "arr-py-client",
    journal: Any | None = None,
    agent: Agent | None = None,
    token_verifier: TokenVerifier | None = None,
    auth: AuthSettings | None = None,
    dev_auth: DevAuth | None = None,
    scope_overrides: Mapping[str, Sequence[str]] | None = None,
    resource_scope_overrides: Mapping[str, Sequence[str]] | None = None,
    audit: AuditCallback | None = None,
    surface: ToolSurface = "full",
    extra_tools: Sequence[str] | None = None,
    stateless_http: bool = True,
    json_response: bool = True,
    debug: bool = False,
) -> FastMCP:
    """Build a FastMCP server backed by ``provider``.

    ``provider``
        Resolves clients per-request. Use
        :class:`~arr_py_client.mcp.provider.EnvClientProvider` for local
        single-tenant setups or implement :class:`ClientProvider` for
        multi-tenant deployments.

    ``token_verifier`` / ``auth``
        Optional MCP 2025-11 OAuth 2.1 plumbing. When set, the SDK
        enforces bearer validation before any tool runs; the decorator
        layer then reads :func:`get_access_token` to build
        :class:`Principal`. Required for any remote HTTP deployment.

    ``dev_auth``
        Test / local-dev shortcut — pre-fills every request's
        :class:`Principal`. Mutually exclusive with ``token_verifier``.
        Refuses unless ``ARR_PY_MCP_ALLOW_DEV_AUTH=1`` is set in env so
        it can't accidentally ship in production.

    ``scope_overrides``
        Override the library's default tool-to-scopes map. Keys are
        tool names; values are scopes required. Only enforced when the
        caller's :class:`Principal` is populated (i.e., auth or
        ``dev_auth`` is configured). Unauthenticated stdio treats
        scope declarations as advisory metadata. Composed ``arr_*``
        tools and describe / journal / agent reference tools enforce
        the same way as brand tools, via the shared scope+audit gate.

    ``resource_scope_overrides``
        Per-resource scope override map for per-tenant MCP resources
        (``arr://radarr/{id}/queue``, ``arr://sonarr/{id}/health``,
        etc.). Keys are short handler names — see
        :mod:`arr_py_client.mcp.resources` for the catalog. Defaults
        require ``mcp:arr:read``. Tenant-independent resources
        (``arr://help/quickstart``, ``arr://schemas/*``) bypass the
        scope check.

    ``audit``
        Callback invoked after every tool invocation with an
        :class:`AuditEvent`. Fires on every outcome (success, scope
        denial, provider error, etc.). If omitted, a default logger-
        backed sink still emits INFO records so baseline observability
        works out-of-the-box.

    ``surface`` / ``extra_tools``
        Selects which brand tools to register. Defaults to ``"full"``
        (all 64 tools, the historical surface). Pass
        ``surface="essentials"`` to expose only the high-leverage
        handful per brand (ping/status/lookup) plus the full composed
        ``arr_*`` and reference surface — total ~30 tools.
        Recommended for LLM-driven clients where tool-selection
        accuracy degrades past ~30. Use ``extra_tools=[...]`` to
        selectively re-add specific brand tools to the essentials
        surface (names match the registered tool names, e.g.
        ``"radarr_movies_list"``).

    ``stateless_http`` / ``json_response``
        Recommended production defaults for streamable-http. Ignored
        for stdio.

    Pass ``journal=`` (:class:`arr_py_client.journal.Journal`) to enable
    persistent audit logging of every mutating composed tool
    (``arr_sync_apply``, ``arr_janitor_run``, ``arr_bulk_edit``, etc.).

    Pass ``agent=`` (:class:`arr_py_client.agent.Agent`) to expose
    read-only agent-introspection tools (``arr_agent_status``,
    ``arr_agent_preview``).
    """
    if dev_auth is not None and token_verifier is not None:
        msg = "dev_auth= is mutually exclusive with token_verifier="
        raise ValueError(msg)
    if dev_auth is not None:
        assert_dev_auth_allowed()

    # Normalize scope_overrides into the tuple-of-str shape the decorator expects.
    normalized_overrides: dict[str, tuple[str, ...]] | None = (
        {k: tuple(v) for k, v in scope_overrides.items()}
        if scope_overrides is not None
        else None
    )
    normalized_resource_overrides: dict[str, tuple[str, ...]] | None = (
        {k: tuple(v) for k, v in resource_scope_overrides.items()}
        if resource_scope_overrides is not None
        else None
    )

    @asynccontextmanager
    async def _lifespan(_server: FastMCP) -> AsyncGenerator[dict[str, Any]]:
        try:
            yield {}
        finally:
            aclose = getattr(provider, "aclose", None)
            if aclose is not None:
                try:
                    await aclose()
                except Exception:
                    logger.warning("provider.aclose raised", exc_info=True)

    fastmcp_kwargs: dict[str, Any] = {
        "name": name,
        "stateless_http": stateless_http,
        "json_response": json_response,
        "debug": debug,
    }
    # Under stateless streamable-http the MCP SDK invokes the session lifespan
    # per request, which would aclose the provider's httpx clients between
    # tool calls and break every subsequent request with "client has been
    # closed". Only wire the shutdown hook for transports where the lifespan
    # actually represents server lifetime (stdio + stateful HTTP); in
    # stateless HTTP the container exit cleans up on its own.
    if not stateless_http:
        fastmcp_kwargs["lifespan"] = _lifespan
    if token_verifier is not None:
        fastmcp_kwargs["token_verifier"] = token_verifier
    if auth is not None:
        fastmcp_kwargs["auth"] = auth

    server = FastMCP(**fastmcp_kwargs)

    deps = ToolDeps(
        audit=audit,
        scope_overrides=normalized_overrides,
        dev_auth=dev_auth,
    )

    # Compute which brand tools to register. ``"full"`` registers
    # everything; ``"essentials"`` registers only the curated set plus
    # any names listed in ``extra_tools``.
    expose: frozenset[str] | None
    if surface == "full":
        expose = None  # sentinel: register everything
    else:
        expose = _ESSENTIAL_BRAND_TOOLS | frozenset(extra_tools or ())

    attach_radarr_tools(server, provider, deps, expose=expose)
    attach_sonarr_tools(server, provider, deps, expose=expose)
    attach_prowlarr_tools(server, provider, deps, expose=expose)
    # Composed + describe always register — they're the curated surface.
    attach_composed_tools(server, provider, deps, journal=journal)
    attach_describe_tool(server, provider, deps, journal=journal, agent=agent)
    # Resources + prompts. Resources include both tenant-independent
    # (help, schemas) and per-tenant (instances, queue, indexers) — the
    # latter route through ``provider`` + ``dev_auth`` AND go through
    # the same scope-check + audit gate as tools (deps wires both).
    # Prompts are tenant-independent and never gated.
    attach_resources(
        server,
        provider,
        dev_auth=dev_auth,
        deps=deps,
        resource_scope_overrides=normalized_resource_overrides,
    )
    attach_prompts(server)

    # Mount the ASGI scope-middleware so HTTP transports rewrite
    # ``insufficient_scope`` envelopes into RFC 6750 ``403 +
    # WWW-Authenticate`` responses. Stdio doesn't have an HTTP layer so
    # the middleware is a no-op there. We only mount when ``auth=`` is
    # configured — without auth, no scope check ever fires anyway.
    if auth is not None:
        _mount_scope_middleware(server, auth)

    return server


def _mount_scope_middleware(server: FastMCP, auth: AuthSettings) -> None:
    """Wrap ``server.streamable_http_app`` to apply the scope middleware.

    FastMCP doesn't expose a hook for adding middleware between the
    bearer-auth layer and the dispatcher, so we override the instance
    method to wrap the returned ASGI app. The wrapped result is still
    ASGI-callable; embedders that mount it via ``app.mount("/mcp",
    server.streamable_http_app())`` see no change.

    The middleware reads ``auth.resource_server_url`` to build the
    ``resource_metadata=`` parameter of the ``WWW-Authenticate``
    challenge so MCP clients can auto-discover the auth server.
    """
    from arr_py_client.mcp._scope_middleware import make_scope_middleware

    rmu = (
        str(auth.resource_server_url)
        if getattr(auth, "resource_server_url", None) is not None
        else None
    )
    factory = make_scope_middleware(resource_metadata_url=rmu)
    original = server.streamable_http_app

    def wrapped() -> Any:
        return factory(original())

    # Override the bound method on this instance only — sibling FastMCP
    # instances (other servers in the same process) are unaffected.
    server.streamable_http_app = wrapped  # type: ignore[method-assign]
