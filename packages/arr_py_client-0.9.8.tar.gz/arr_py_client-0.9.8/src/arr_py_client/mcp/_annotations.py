"""Convenience presets for ``ToolAnnotations``.

The MCP spec (2025-06-18) defines four boolean annotation hints that let
clients drive UI confirmation policy + graduated trust:

- ``readOnlyHint`` — true if the tool *never* mutates state on this server
  or any system it talks to. Read-only tools are safe to call without user
  confirmation.
- ``destructiveHint`` — true if the tool may *destroy* / overwrite /
  permanently remove data. False (default) means the tool is *additive* —
  it may create or modify, but won't delete. Only meaningful when
  ``readOnlyHint=False``.
- ``idempotentHint`` — true if calling the tool twice with identical args
  produces the same end-state as calling it once. Lets clients deduplicate
  retries safely. Only meaningful when ``readOnlyHint=False``.
- ``openWorldHint`` — true if the tool reaches outside the local server
  process (talks to a remote service, hits the filesystem, etc.). All our
  tools talk to remote Radarr/Sonarr/Prowlarr instances, so this is always
  true.

The spec emphasizes annotations are **hints, not security**: clients must
not make access-control decisions from them. Real safety comes from our
scope system + ``dry_run`` defaults — annotations just communicate intent.

These four presets cover every shape we ship:

- :data:`READ_ONLY` — list / get / status / lookup / preview tools
- :data:`ADDITIVE` — adds new state but never overwrites or deletes (e.g.
  ``arr_add``, ``radarr_release_push``, ``prowlarr_indexer_test_all``)
- :data:`MUTATING` — modifies existing state, idempotent (e.g. config-sync
  apply, bulk_edit) — same args → same end-state
- :data:`DESTRUCTIVE` — may permanently remove / overwrite (queue cleanup,
  backup restore, blocklist delete, janitor sweeps)

Use :func:`tool_annotations` for one-off tweaks (e.g. flipping
``idempotentHint`` for a specific tool).
"""

from __future__ import annotations

from mcp.types import ToolAnnotations


def tool_annotations(
    *,
    title: str | None = None,
    read_only: bool = False,
    destructive: bool = False,
    idempotent: bool = False,
    open_world: bool = True,
) -> ToolAnnotations:
    """Build a :class:`ToolAnnotations` from keyword args.

    Defaults match the most-common ``additive`` shape: not read-only, not
    destructive, not idempotent, but ``open_world=True`` because every tool
    we expose talks to a remote Arr instance.
    """
    return ToolAnnotations(
        title=title,
        readOnlyHint=read_only,
        destructiveHint=destructive,
        idempotentHint=idempotent,
        openWorldHint=open_world,
    )


# ---------------------------------------------------------------- presets --

READ_ONLY: ToolAnnotations = ToolAnnotations(
    readOnlyHint=True,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)
"""Tools that only read remote state. Safe to call without confirmation."""


ADDITIVE: ToolAnnotations = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=False,
    openWorldHint=True,
)
"""Tools that add new state but never overwrite or delete.

Examples: ``arr_add`` (adds a movie), ``radarr_release_push`` (pushes a
new release to the grabber), ``radarr_command_post`` (queues a command).
"""


MUTATING: ToolAnnotations = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=False,
    idempotentHint=True,
    openWorldHint=True,
)
"""Tools that modify existing state, but the end-state is deterministic.

Examples: ``arr_sync_apply`` (reconciles to a desired state),
``arr_bulk_edit`` (sets fields on movies/series). Same args twice → same
end-state, so safe to retry.
"""


DESTRUCTIVE: ToolAnnotations = ToolAnnotations(
    readOnlyHint=False,
    destructiveHint=True,
    idempotentHint=False,
    openWorldHint=True,
)
"""Tools that may permanently remove or overwrite data.

Examples: ``radarr_blocklist_delete``, ``arr_cleanup_queue`` (when
``dry_run=False``), ``arr_janitor_run``, ``radarr_backup_restore``,
``arr_grab_release`` (commits to a download). Clients should require
explicit confirmation.
"""


__all__ = [
    "ADDITIVE",
    "DESTRUCTIVE",
    "MUTATING",
    "READ_ONLY",
    "tool_annotations",
]
