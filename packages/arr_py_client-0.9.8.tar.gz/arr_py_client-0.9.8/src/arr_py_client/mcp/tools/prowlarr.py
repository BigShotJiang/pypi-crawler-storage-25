"""Prowlarr brand-specific MCP tools (8 tools, ``prowlarr_*`` prefix).

Prowlarr is the indexer manager that fans out to Radarr/Sonarr/Lidarr.
All read tools carry :data:`READ_ONLY`; the two ``test_all`` tools are
:data:`ADDITIVE` — they kick off a server-side test sweep but don't
modify state.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp._annotations import ADDITIVE, READ_ONLY
from arr_py_client.mcp._decorators import prowlarr_tool
from arr_py_client.mcp.tools._filter import filtered_brand_decorator
from arr_py_client.mcp.tools._shared import run_paged, wrap

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.provider import ClientProvider
    from arr_py_client.prowlarr.v1.client import AsyncProwlarrClientV1


def attach_prowlarr_tools(
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    *,
    expose: frozenset[str] | None = None,
) -> None:
    """Register Prowlarr tools on ``server``.

    ``expose=None`` (default) registers every tool. Pass a frozenset of
    names to only register the named tools — driven by
    ``build_server(surface=..., extra_tools=...)``.
    """
    pt = filtered_brand_decorator(prowlarr_tool(server, provider, deps), expose)

    @pt(title="Ping Prowlarr", annotations=READ_ONLY)
    async def prowlarr_ping(*, client: AsyncProwlarrClientV1) -> dict[str, Any]:
        """Verify Prowlarr is reachable.

        Liveness check; pair with ``arr_health(app='all')`` for a
        cross-app summary that includes indexer + application counts.
        """
        await client.ping()
        return {"ok": True}

    @pt(title="Prowlarr system status", annotations=READ_ONLY)
    async def prowlarr_system_status(
        fields: str = "summary", *, client: AsyncProwlarrClientV1
    ) -> dict[str, Any]:
        """Return Prowlarr's ``/api/v1/system/status`` payload.

        Use to answer "what version is Prowlarr?" or to diagnose a
        broken deployment. ``fields``: ``summary`` | ``all`` |
        comma-list.
        """
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="prowlarr.system",
            hints=["arr_health()"],
        )

    @pt(title="List Prowlarr indexers", annotations=READ_ONLY)
    async def prowlarr_indexers_list(
        fields: str = "summary", *, client: AsyncProwlarrClientV1
    ) -> dict[str, Any]:
        """List every configured Prowlarr indexer.

        Returns one entry per indexer with ``name``, ``protocol``,
        ``enable``/``priority`` flags. Pair with
        ``prowlarr_indexer_test_all`` to verify connectivity, or
        ``prowlarr_apps_list`` to see which downstream Radarr/Sonarr
        instances are wired up.
        """
        return wrap(
            await client.indexers.list(),
            fields=fields,
            resource="prowlarr.indexer",
            hints=[
                "prowlarr_indexer_test_all()",
                "prowlarr_apps_list()",
            ],
        )

    @pt(title="Test all Prowlarr indexers", annotations=ADDITIVE)
    async def prowlarr_indexer_test_all(
        *, client: AsyncProwlarrClientV1
    ) -> dict[str, Any]:
        """Fire Prowlarr's "test all indexers" action and wait for completion.

        Use to diagnose "indexer X stopped returning results" —
        Prowlarr will run a server-side test against each indexer and
        update its health status. Doesn't modify config; safe to call
        but takes ~10-60s on a fleet.
        """
        await client.indexers.test_all()
        return {
            "ok": True,
            "_meta": {"action_hints": ["prowlarr_indexers_list()"]},
        }

    @pt(title="List Prowlarr applications", annotations=READ_ONLY)
    async def prowlarr_apps_list(
        fields: str = "summary", *, client: AsyncProwlarrClientV1
    ) -> dict[str, Any]:
        """List downstream applications wired into Prowlarr (Radarr/Sonarr/Lidarr/…).

        Each entry is one Arr app Prowlarr forwards releases to. Use
        ``prowlarr_app_test_all`` to verify connectivity, or
        ``arr_health(app='all')`` for a fleet-wide health view.
        """
        return wrap(
            await client.applications.list(),
            fields=fields,
            resource="prowlarr.application",
            hints=["prowlarr_app_test_all()"],
        )

    @pt(title="Test all Prowlarr applications", annotations=ADDITIVE)
    async def prowlarr_app_test_all(*, client: AsyncProwlarrClientV1) -> dict[str, Any]:
        """Test connectivity/auth to every registered downstream application.

        Use after rotating Radarr/Sonarr API keys to confirm Prowlarr
        can still push releases. Doesn't modify state.
        """
        await client.applications.test_all()
        return {
            "ok": True,
            "_meta": {"action_hints": ["prowlarr_apps_list()"]},
        }

    @pt(title="List Prowlarr history", annotations=READ_ONLY)
    async def prowlarr_history_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncProwlarrClientV1,
    ) -> dict[str, Any]:
        """One page of Prowlarr history (search + grab events).

        Use to answer "which indexer found this release?" or "how often
        is this indexer queried?". Paged; ``offset`` rounds to page
        boundary.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="prowlarr.history",
            hints=["prowlarr_system_status()"],
        )

    @pt(title="List Prowlarr log entries", annotations=READ_ONLY)
    async def prowlarr_logs_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
        *,
        client: AsyncProwlarrClientV1,
    ) -> dict[str, Any]:
        """One page of Prowlarr's system log.

        ``level``: ``Info|Warn|Error|Fatal|Debug|Trace``. Filter to
        ``Error`` when debugging an indexer that's failing silently.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="prowlarr.log",
            hints=["prowlarr_system_status()"],
        )
