"""Surface-aware decorator filter for brand tools.

Wraps the per-brand decorators (``radarr_tool`` / ``sonarr_tool`` /
``prowlarr_tool``) so a single attach function can register a curated
subset by name. Used by ``build_server(surface="essentials")``.
"""

# pyright: reportPrivateUsage=false
from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from mcp.types import ToolAnnotations

    from arr_py_client.mcp._decorators import _BoundBrandDecorator


def filtered_brand_decorator(
    base: _BoundBrandDecorator,
    expose: frozenset[str] | None,
) -> Any:
    """Wrap ``base`` so unmatched tool names are skipped silently.

    ``expose=None`` is a sentinel meaning "register everything" — the
    wrapper is transparent and behaves identically to ``base``. When
    ``expose`` is a set, only tools whose ``__name__`` is in the set get
    registered; the rest are returned unwrapped (so tests that import
    them by attribute still work).

    Returns a callable with the same dual-shape contract as ``base``:
    ``@rt`` and ``@rt(title=..., annotations=...)`` both work.
    """

    def filtered(
        fn: Callable[..., Awaitable[Any]] | None = None,
        *,
        name: str | None = None,
        title: str | None = None,
        annotations: ToolAnnotations | None = None,
    ) -> Any:
        # Direct ``@rt`` form: register or skip immediately.
        if fn is not None:
            if expose is not None and fn.__name__ not in expose:
                return fn
            return base(fn)

        # Kwargs form: return a per-tool decorator that checks the name.
        def per_tool(inner_fn: Callable[..., Awaitable[Any]]) -> Any:
            if expose is not None and inner_fn.__name__ not in expose:
                return inner_fn
            registered_decorator = base(name=name, title=title, annotations=annotations)
            return registered_decorator(inner_fn)

        return per_tool

    return filtered
