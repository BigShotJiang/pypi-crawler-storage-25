"""Sonarr brand-specific MCP tools (17 tools, ``sonarr_*`` prefix).

Mirrors the Radarr surface (see ``tools/radarr.py``) for TV. Every tool
carries ``ToolAnnotations`` so MCP clients can drive UI confirmation
policy: read-only tools (lookups, lists, status) get :data:`READ_ONLY`,
mutators that add new state get :data:`ADDITIVE`, destructive tools
(``sonarr_backup_restore``) get :data:`DESTRUCTIVE`.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp._annotations import ADDITIVE, DESTRUCTIVE, READ_ONLY
from arr_py_client.mcp._decorators import sonarr_tool
from arr_py_client.mcp.tools._filter import filtered_brand_decorator
from arr_py_client.mcp.tools._shared import (
    release_body,
    run_paged,
    wrap,
)

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.provider import ClientProvider
    from arr_py_client.sonarr.v3.client import AsyncSonarrClientV3


def attach_sonarr_tools(
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    *,
    expose: frozenset[str] | None = None,
) -> None:
    """Register Sonarr tools on ``server``.

    ``expose=None`` (default) registers every tool. Pass a frozenset of
    names to only register the named tools — driven by
    ``build_server(surface=..., extra_tools=...)``.
    """
    st = filtered_brand_decorator(sonarr_tool(server, provider, deps), expose)

    @st(title="Ping Sonarr", annotations=READ_ONLY)
    async def sonarr_ping(*, client: AsyncSonarrClientV3) -> dict[str, Any]:
        """Verify Sonarr is reachable.

        Liveness check; pair with ``arr_health()`` for a richer cross-app
        status. Returns ``{"ok": true}`` on success.
        """
        await client.ping()
        return {"ok": True}

    @st(title="Sonarr system status", annotations=READ_ONLY)
    async def sonarr_system_status(
        fields: str = "summary", *, client: AsyncSonarrClientV3
    ) -> dict[str, Any]:
        """Return Sonarr's ``/api/v3/system/status`` payload (version, branch, paths).

        Use to answer "what version is Sonarr?" or to diagnose a broken
        deployment. ``fields``: ``summary`` | ``all`` | comma-list.
        """
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="sonarr.system",
            hints=["arr_health()", "sonarr_log_list(level='Error')"],
        )

    @st(title="List Sonarr series", annotations=READ_ONLY)
    async def sonarr_series_list(
        fields: str = "summary", *, client: AsyncSonarrClientV3
    ) -> dict[str, Any]:
        """List every TV series in Sonarr's library.

        For very large libraries prefer ``arr_title_status(title=...)`` or
        ``sonarr_series_get(series_id=...)``. ``fields=summary`` keeps the
        payload small; ``fields=all`` may exceed context.
        """
        return wrap(
            await client.series.list(),
            fields=fields,
            resource="sonarr.series",
            hints=[
                "sonarr_series_get(series_id=...)",
                "arr_find_release(title=..., app='sonarr')",
            ],
        )

    @st(title="Get one Sonarr series", annotations=READ_ONLY)
    async def sonarr_series_get(
        series_id: int,
        fields: str = "all",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """Get one series by Sonarr id (the integer id, not TVDB).

        Pair with ``sonarr_series_lookup`` if you only have a title — its
        results are *candidates* (id is always 0). Use
        ``arr_title_status(title=...)`` to wrap the lookup → match flow
        in one call.
        """
        return wrap(
            await client.series.get(id=series_id),
            fields=fields,
            resource="sonarr.series",
            hints=[
                f"sonarr_episodes_list(series_id={series_id})",
                "arr_find_release(title=..., app='sonarr')",
            ],
        )

    @st(title="TVDB lookup via Sonarr", annotations=READ_ONLY)
    async def sonarr_series_lookup(
        term: str,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """Search/find a TV series by title via Sonarr's TVDB lookup proxy.

        Use to locate a show (e.g. ``"The Pitt"``) before adding it with
        ``arr_add`` or checking library completeness with
        ``arr_title_status``. Returns TVDB metadata (titles, year,
        tvdbId, imdbId, tmdbId) — does *not* tell you whether the
        series is in your library. Keywords: search, find, lookup, show,
        title.
        """
        return wrap(
            await client.series.lookup(term=term),
            fields=fields,
            resource="sonarr.series",
            hints=["arr_add(title=..., app='sonarr')"],
        )

    @st(title="List Sonarr episodes", annotations=READ_ONLY)
    async def sonarr_episodes_list(
        series_id: int,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """List every episode for a series, with ``hasFile`` / ``monitored`` per row.

        Use to enumerate missing episodes (``hasFile=False``) or
        per-episode monitoring state. For an aggregate "how many
        episodes do I not have" answer prefer ``arr_title_status`` —
        one call instead of lookup + list. Keywords: episodes, missing
        episodes, unaired, aired, hasFile.
        """
        return wrap(
            await client.episodes.list(series_id=series_id),
            fields=fields,
            resource="sonarr.episode",
            hints=[
                "arr_find_release(title=..., app='sonarr', episode_id=...)",
                "arr_explain_grab(title=..., app='sonarr', episode_id=...)",
            ],
        )

    @st(title="List Sonarr queue", annotations=READ_ONLY)
    async def sonarr_queue_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """One page of Sonarr's active download queue.

        For *cleanup* of stuck items prefer ``arr_cleanup_queue`` or
        ``arr_janitor_run`` (both default to ``dry_run=True``).
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='sonarr', dry_run=True)",
            "sonarr_blocklist_list()",
        ]
        return result

    @st(title="List Sonarr history", annotations=READ_ONLY)
    async def sonarr_history_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """One page of Sonarr history (grab/import/delete events, paged).

        Use to answer "why did this download happen?" or "when was this
        last imported?". Pair with ``arr_explain_grab`` for a per-release
        verdict explanation.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.history",
            hints=[
                "sonarr_blocklist_list()",
                "arr_cleanup_queue(app='sonarr', dry_run=True)",
            ],
        )

    @st(title="Send Sonarr command", annotations=ADDITIVE)
    async def sonarr_command_post(
        name: str,
        body: dict[str, Any] | None = None,
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """Queue a Sonarr command (``SeriesSearch``, ``RefreshSeries``, …).

        Use sparingly — prefer ``arr_find_release``, ``arr_backfill``, or
        ``arr_explain_grab`` which orchestrate the right command for the
        situation.
        """
        result = await client.commands.post(name=name, **(body or {}))
        return wrap(
            result,
            fields="all",
            resource="sonarr.command",
            hints=["sonarr_system_status()", "sonarr_log_list(level='Error')"],
        )

    @st(title="List Sonarr blocklist", annotations=READ_ONLY)
    async def sonarr_blocklist_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """One page of Sonarr's blocklist (releases marked never-grab-again).

        Use to answer "why isn't this episode being grabbed?". Sonarr
        does not expose per-entry blocklist deletion via API; use
        ``sonarr_command_post(name='ClearBlocklist')`` to wipe the
        whole list.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.blocklist",
            hints=["sonarr_command_post(name='ClearBlocklist')"],
        )

    @st(title="List Sonarr log entries", annotations=READ_ONLY)
    async def sonarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """One page of Sonarr's system log.

        ``level``: ``Info|Warn|Error|Fatal|Debug|Trace`` (Sonarr's
        capitalization). Filter to ``Error`` when debugging a misbehaving
        instance.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="sonarr.log",
            hints=["sonarr_system_status()", "arr_health()"],
        )

    @st(title="List Sonarr backups", annotations=READ_ONLY)
    async def sonarr_backup_list(
        fields: str = "summary", *, client: AsyncSonarrClientV3
    ) -> dict[str, Any]:
        """List available Sonarr backup files (auto + manual).

        Pair with ``sonarr_backup_restore`` to roll back. Backups
        include config + database — restore is destructive.
        """
        return wrap(
            await client.backup.list_(),
            fields=fields,
            resource="sonarr.backup",
            hints=["sonarr_backup_restore(backup_id=...)"],
        )

    @st(title="Restore Sonarr backup", annotations=DESTRUCTIVE)
    async def sonarr_backup_restore(
        backup_id: int, *, client: AsyncSonarrClientV3
    ) -> dict[str, Any]:
        """Restore a Sonarr backup. **Sonarr will restart and overwrite current state.**

        Run ``sonarr_backup_list`` first to pick a ``backup_id``. The
        operator should confirm — this is non-trivial to undo.
        """
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @st(title="Inspect Sonarr manual-import folder", annotations=READ_ONLY)
    async def sonarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        series_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """List importable files at a folder or download id (manual-import flow).

        Use when an automatic import failed. Pass either ``folder``
        (path) *or* ``download_id`` (queue-item id). Each candidate
        carries the proposed series/episode/quality and rejection
        reasons if any.
        """
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            series_id=series_id,
            filter_existing_files=filter_existing_files,
        )
        return wrap(
            result,
            fields=fields,
            resource="sonarr.manual_import",
            hints=["sonarr_command_post(name='DownloadedEpisodesScan')"],
        )

    @st(title="Preview Sonarr rename", annotations=READ_ONLY)
    async def sonarr_rename_list(
        series_id: int,
        season_number: int | None = None,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """Preview rename suggestions per current naming policy.

        ``season_number`` scopes to one season; omit for whole series.
        The actual rename is a destructive command — fire via
        ``sonarr_command_post(name='RenameSeries', body={'seriesIds': [...]})``
        once you've reviewed the suggestions.
        """
        result = await client.rename_episode.list_(
            series_id=series_id, season_number=season_number
        )
        return wrap(
            result,
            fields=fields,
            resource="sonarr.rename",
            hints=[
                f"sonarr_command_post(name='RenameSeries', body={{'seriesIds':[{series_id}]}})",
            ],
        )

    @st(title="Push Sonarr release", annotations=ADDITIVE)
    async def sonarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
        *,
        client: AsyncSonarrClientV3,
    ) -> dict[str, Any]:
        """Push a release to Sonarr's grabber pipeline.

        Use when a release isn't surfaced by Sonarr's normal indexers but
        you have its metadata. ``protocol``: ``torrent`` or ``usenet``.
        Sonarr will run its parser + scoring; the release lands in the
        normal queue if accepted.
        """
        from arr_py_client.sonarr.v3._generated import models as s_models

        body = release_body(
            s_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="sonarr.release",
            hints=["sonarr_queue_list()", "sonarr_history_list()"],
        )

    @st(title="List Sonarr download clients", annotations=READ_ONLY)
    async def sonarr_download_clients_list(
        fields: str = "summary", *, client: AsyncSonarrClientV3
    ) -> dict[str, Any]:
        """List configured Sonarr download clients (sabnzbd, qbittorrent, …).

        Use to answer "where do my Sonarr downloads land?" or to confirm
        a download client is enabled before triggering grabs.
        """
        return wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="sonarr.download_client",
            hints=["arr_health()"],
        )
