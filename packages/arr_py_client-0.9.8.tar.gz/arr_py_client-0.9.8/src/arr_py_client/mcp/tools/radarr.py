"""Radarr brand-specific MCP tools (18 tools, ``radarr_*`` prefix).

Every tool carries ``ToolAnnotations`` so clients can drive UI confirmation
policy without parsing names. Read-only tools (lookups, lists, status) get
:data:`READ_ONLY`; mutators that add new state (``radarr_command_post``,
``radarr_release_push``) get :data:`ADDITIVE`; destructive tools
(``radarr_blocklist_delete``, ``radarr_backup_restore``) get
:data:`DESTRUCTIVE`. The ``title`` field gives a human-readable label that
clients show in tool pickers.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from arr_py_client._common.pagination import align_offset_to_page
from arr_py_client.mcp._annotations import ADDITIVE, DESTRUCTIVE, READ_ONLY
from arr_py_client.mcp._decorators import radarr_tool
from arr_py_client.mcp.tools._filter import filtered_brand_decorator
from arr_py_client.mcp.tools._shared import (
    release_body,
    run_paged,
    wrap,
)

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.provider import ClientProvider
    from arr_py_client.radarr.v3.client import AsyncRadarrClientV3


def attach_radarr_tools(
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    *,
    expose: frozenset[str] | None = None,
) -> None:
    """Register Radarr tools on ``server``.

    ``expose=None`` (default) registers every tool. Pass a frozenset of
    names to only register the named tools — driven by
    ``build_server(surface=..., extra_tools=...)``.
    """
    rt = filtered_brand_decorator(radarr_tool(server, provider, deps), expose)

    @rt(title="Ping Radarr", annotations=READ_ONLY)
    async def radarr_ping(*, client: AsyncRadarrClientV3) -> dict[str, Any]:
        """Verify Radarr is reachable.

        Use as a quick liveness check before chaining other tools or as a
        first step when the user asks "is Radarr up?". Returns
        ``{"ok": true}`` on success; the wrapper turns connectivity
        failures into a structured error envelope so the LLM can recover.
        """
        await client.ping()
        return {"ok": True}

    @rt(title="Radarr system status", annotations=READ_ONLY)
    async def radarr_system_status(
        fields: str = "summary", *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """Return Radarr's ``/api/v3/system/status`` payload (version, branch, paths).

        Use when the user asks about Radarr's version, build, OS, or
        database backend. ``fields``: ``summary`` (curated handful) |
        ``all`` (full payload) | comma-list (specific keys). Discover
        valid field names via ``arr_describe_fields("radarr.system")``.
        """
        return wrap(
            await client.system.list_status(),
            fields=fields,
            resource="radarr.system",
            hints=["arr_health()", "radarr_log_list(level='Error')"],
        )

    @rt(title="List Radarr movies", annotations=READ_ONLY)
    async def radarr_movies_list(
        fields: str = "summary", *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """List every movie in the Radarr library.

        For very large libraries prefer ``arr_title_status(title=...)`` or
        ``radarr_movies_get(movie_id=...)``. ``fields=summary`` keeps the
        payload small; ``fields=all`` may exceed context for libraries
        with thousands of movies.
        """
        return wrap(
            await client.movies.list(),
            fields=fields,
            resource="radarr.movie",
            hints=[
                "radarr_movies_get(movie_id=...)",
                "arr_find_release(title=..., app='radarr')",
            ],
        )

    @rt(title="Get one Radarr movie", annotations=READ_ONLY)
    async def radarr_movies_get(
        movie_id: int,
        fields: str = "all",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """Get one movie by Radarr id (the integer id, not TMDB).

        Pair with ``radarr_movies_lookup`` if you only have a title — its
        results are *candidates* (id is always 0 in lookups); you need to
        cross-reference against ``radarr_movies_list`` to find the
        library's actual id, or use ``arr_title_status(title=...)`` which
        wraps that lookup.
        """
        return wrap(
            await client.movies.get(id=movie_id),
            fields=fields,
            resource="radarr.movie",
            hints=[
                "arr_find_release(title=..., app='radarr')",
                f"radarr_command_post(name='MoviesSearch', body={{'movieIds':[{movie_id}]}})",
            ],
        )

    @rt(title="TMDB lookup via Radarr", annotations=READ_ONLY)
    async def radarr_movies_lookup(
        term: str,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """Search TMDB via Radarr's lookup proxy. Returns *candidates*, not library entries.

        Use when adding a new movie or resolving an ambiguous title. The
        returned ``id`` is always 0 — it's TMDB's view, not Radarr's. To
        add: pass the chosen title to ``arr_add(app='radarr', ...)``.
        """
        return wrap(
            await client.movies.lookup(term=term),
            fields=fields,
            resource="radarr.movie",
            hints=["arr_add(title=..., app='radarr')"],
        )

    @rt(title="List Radarr queue", annotations=READ_ONLY)
    async def radarr_queue_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """One page of Radarr's active download queue.

        For *cleanup* of stuck items prefer ``arr_cleanup_queue`` or
        ``arr_janitor_run`` (both default to ``dry_run=True``). ``offset``
        is rounded to a page boundary; ``_meta.next_offset`` is ``None``
        at the end.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        result = await run_paged(
            client.queue.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.queue",
        )
        result["_meta"]["action_hints"] = [
            "arr_cleanup_queue(app='radarr', dry_run=True)",
            "radarr_blocklist_list()",
        ]
        return result

    @rt(title="List Radarr history", annotations=READ_ONLY)
    async def radarr_history_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """One page of Radarr's history (grab/import/delete events, paged).

        Use to answer "why did this download happen?" or "when was this
        last imported?". Pair with ``arr_explain_grab`` for a deeper
        per-release verdict explanation.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.history.list(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.history",
            hints=[
                "radarr_blocklist_list()",
                "arr_cleanup_queue(app='radarr', dry_run=True)",
            ],
        )

    @rt(
        title="Send Radarr command",
        annotations=ADDITIVE,
    )
    async def radarr_command_post(
        name: str,
        body: dict[str, Any] | None = None,
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """Queue a Radarr command (``MoviesSearch``, ``RefreshMovie``, ``RescanMovie``, …).

        Use sparingly — prefer the higher-level composed tools
        (``arr_find_release``, ``arr_backfill``) which orchestrate the
        right command for the situation. ``body`` is the command-specific
        kwargs (``{"movieIds": [...]}`` etc.). Returns the queued
        :class:`CommandResource`.
        """
        result = await client.commands.post(name=name, **(body or {}))
        return wrap(
            result,
            fields="all",
            resource="radarr.command",
            hints=["radarr_system_status()", "radarr_log_list(level='Error')"],
        )

    @rt(title="List Radarr tags", annotations=READ_ONLY)
    async def radarr_tags_list(
        fields: str = "summary", *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """List Radarr tags (id + label).

        Use to resolve tag names to ids before bulk-editing. Most callers
        should use ``arr_bulk_edit`` instead, which accepts tag *names*
        and resolves them automatically.
        """
        return wrap(
            await client.tags.list(),
            fields=fields,
            resource="radarr.tag",
            hints=["radarr_movies_list(fields='id,title,tags')"],
        )

    @rt(title="List Radarr blocklist", annotations=READ_ONLY)
    async def radarr_blocklist_list(
        limit: int = 20,
        offset: int = 0,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """One page of Radarr's blocklist (releases marked never-grab-again).

        Use to answer "why isn't this release being grabbed?". Items can
        be unblocked individually via ``radarr_blocklist_delete``.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.blocklist.list_(page=page, page_size=size),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.blocklist",
            hints=["radarr_blocklist_delete(blocklist_id=...)"],
        )

    @rt(
        title="Remove Radarr blocklist entry",
        annotations=DESTRUCTIVE,
    )
    async def radarr_blocklist_delete(
        blocklist_id: int, *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """Permanently remove one blocklist entry. **Cannot be undone.**

        After unblocking, Radarr may re-grab the release on the next
        search if no other rules block it. Run ``radarr_blocklist_list``
        first to find the right ``blocklist_id`` (not the release id).
        """
        await client.blocklist.delete_by_id(blocklist_id)
        return {"ok": True}

    @rt(
        title="List Radarr log entries",
        annotations=READ_ONLY,
    )
    async def radarr_log_list(
        limit: int = 20,
        offset: int = 0,
        level: str | None = None,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """One page of Radarr's system log.

        ``level``: ``Info|Warn|Error|Fatal|Debug|Trace`` (Radarr's
        capitalization). Most useful filtered to ``Error`` when debugging
        a misbehaving instance.
        """
        page, size, aligned = align_offset_to_page(offset, limit)
        return await run_paged(
            client.log.list_(page=page, page_size=size, level=level),
            aligned=aligned,
            size=size,
            fields=fields,
            resource="radarr.log",
            hints=["radarr_system_status()", "arr_health()"],
        )

    @rt(title="List Radarr backups", annotations=READ_ONLY)
    async def radarr_backup_list(
        fields: str = "summary", *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """List available Radarr backup files (auto + manual).

        Pair with ``radarr_backup_restore`` to roll back. Backups include
        config + database — restore is destructive.
        """
        return wrap(
            await client.backup.list_(),
            fields=fields,
            resource="radarr.backup",
            hints=["radarr_backup_restore(backup_id=...)"],
        )

    @rt(
        title="Restore Radarr backup",
        annotations=DESTRUCTIVE,
    )
    async def radarr_backup_restore(
        backup_id: int, *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """Restore a Radarr backup. **Radarr will restart and overwrite current state.**

        Run ``radarr_backup_list`` first to pick a ``backup_id``. The
        operator should confirm — this is non-trivial to undo.
        """
        await client.backup.post_restore_by_id(backup_id)
        return {"ok": True}

    @rt(
        title="Inspect Radarr manual-import folder",
        annotations=READ_ONLY,
    )
    async def radarr_manual_import_list(
        folder: str | None = None,
        download_id: str | None = None,
        movie_id: int | None = None,
        filter_existing_files: bool | None = None,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """List importable files at a folder or download id (manual-import flow).

        Use when an automatic import failed. Pass either ``folder`` (path)
        *or* ``download_id`` (the queue-item id). Each candidate carries
        the proposed movie/quality and rejection reasons if any.
        """
        result = await client.manual_import.list_(
            folder=folder,
            download_id=download_id,
            movie_id=movie_id,
            filter_existing_files=filter_existing_files,
        )
        return wrap(
            result,
            fields=fields,
            resource="radarr.manual_import",
            hints=["radarr_command_post(name='DownloadedMoviesScan')"],
        )

    @rt(
        title="Preview Radarr rename",
        annotations=READ_ONLY,
    )
    async def radarr_rename_list(
        movie_ids: list[int] | None = None,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """Preview rename suggestions per current naming policy.

        ``movie_ids=None`` means the entire library. The actual rename is
        a destructive command — fire via
        ``radarr_command_post(name='RenameMovie', body={'movieIds': [...]})``
        once you've reviewed the suggestions.
        """
        result = await client.rename_movie.list_(movie_id=movie_ids)
        return wrap(
            result,
            fields=fields,
            resource="radarr.rename",
            hints=["radarr_command_post(name='RenameMovie', body={'movieIds':[...]})"],
        )

    @rt(
        title="Push Radarr release",
        annotations=ADDITIVE,
    )
    async def radarr_release_push(
        title: str,
        download_url: str,
        protocol: str = "torrent",
        publish_date: str | None = None,
        size: int | None = None,
        indexer: str | None = None,
        fields: str = "summary",
        *,
        client: AsyncRadarrClientV3,
    ) -> dict[str, Any]:
        """Push a release to Radarr's grabber pipeline.

        Use when a release isn't surfaced by Radarr's normal indexers but
        you have its metadata. ``protocol``: ``torrent`` or ``usenet``.
        Radarr will run its parser + scoring; the release ends up in the
        normal queue if accepted.
        """
        from arr_py_client.radarr.v3._generated import models as r_models

        body = release_body(
            r_models,
            title=title,
            downloadUrl=download_url,
            protocol=protocol,
            publishDate=publish_date,
            size=size,
            indexer=indexer,
        )
        return wrap(
            await client.release_push.create(body=body),
            fields=fields,
            resource="radarr.release",
            hints=["radarr_queue_list()", "radarr_history_list()"],
        )

    @rt(
        title="List Radarr download clients",
        annotations=READ_ONLY,
    )
    async def radarr_download_clients_list(
        fields: str = "summary", *, client: AsyncRadarrClientV3
    ) -> dict[str, Any]:
        """List configured Radarr download clients (sabnzbd, qbittorrent, …).

        Use to answer "where do my Radarr downloads land?" or to confirm
        a download client is enabled before triggering grabs.
        """
        return wrap(
            await client.download_clients.list(),
            fields=fields,
            resource="radarr.download_client",
            hints=["arr_health()"],
        )
