"""Cross-brand composed MCP tools (``arr_*`` prefix).

These collapse multi-step workflows into one tool call and return structured
payloads with ``_meta.action_hints`` — the next most useful tool calls from
here — so LLMs can chain operations without guessing.

Each tool resolves its Arr client(s) via the ``ClientProvider`` per request.
Single-brand tools take one ``instance_id``; cross-brand tools take
per-brand ``{brand}_instance_id`` kwargs. ``ctx`` is FastMCP-injected and
used for progress / log messages on long-running tools.
"""

# pyright: reportUnusedFunction=false, reportUnknownMemberType=false, reportReturnType=false

from __future__ import annotations

import contextlib
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, Literal, cast

# ``MCPContext`` must be importable at runtime — FastMCP evaluates tool-param
# annotations via ``inspect.signature(eval_str=True)`` to build schemas. We
# import the pre-parametrized alias so tool signatures don't need explicit
# generic args (which basedpyright would otherwise complain about).
from arr_py_client.mcp._annotations import (
    ADDITIVE,
    DESTRUCTIVE,
    MUTATING,
    READ_ONLY,
)
from arr_py_client.mcp._schemas import (  # noqa: TC001 — runtime introspection
    ArrAddOut,
    ArrBackfillOut,
    ArrBulkEditOut,
    ArrCleanupQueueOut,
    ArrExplainGrabOut,
    ArrFindReleaseOut,
    ArrGrabReleaseOut,
    ArrHealthOut,
    ArrJanitorRunOut,
    ArrSummarizeQueueOut,
    ArrSyncApplyOut,
    ArrSyncDumpOut,
    ArrSyncPlanOut,
    ArrTitleStatusOut,
    ArrTrashImportOut,
    ArrUpcomingOut,
)
from arr_py_client.mcp.context import MCPContext as Context  # noqa: TC001
from arr_py_client.mcp.projection import project
from arr_py_client.mcp.tools._shared import error, resolve_or_error

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

    from arr_py_client.mcp._decorators import ToolDeps
    from arr_py_client.mcp.provider import ClientProvider


def _library_health_dict(summary: Any) -> dict[str, Any]:
    """Flatten a ``LibraryHealth`` into a JSON-ready dict for MCP payloads."""
    out = asdict(summary)
    out["disks"] = [
        {
            **d,
            "free_percent": (
                round(100.0 * d["free_bytes"] / d["total_bytes"], 2)
                if d.get("free_bytes") is not None
                and d.get("total_bytes")
                and d["total_bytes"] > 0
                else None
            ),
        }
        for d in out.get("disks", [])
    ]
    return out


async def _safe_info(mcp_ctx: Context, message: str) -> None:
    """Call ``ctx.info`` without failing when there's no live request.

    ``Context.info`` requires a live request context (has a session to
    send log messages to). Tests call tools directly via
    ``server.call_tool`` which doesn't set one up, so we silently
    no-op rather than propagate. In real request flow the message
    reaches the MCP client as a log notification.
    """
    with contextlib.suppress(ValueError, AttributeError, RuntimeError):
        await mcp_ctx.info(message)


async def _safe_progress(
    mcp_ctx: Context,
    progress: float,
    total: float | None = None,
    message: str | None = None,
) -> None:
    """Call ``ctx.report_progress`` without failing when there's no live request.

    Mirrors :func:`_safe_info` for the
    ``notifications/progress`` channel. Long-running composed tools
    (``arr_backfill``, ``arr_sync_apply``, ``arr_janitor_run``,
    ``arr_trash_import``) emit progress at meaningful checkpoints so
    chat UIs can render a status bar and the user can cancel.

    ``total`` is optional but recommended when known — without it the
    UI can only show "in progress", not a percentage.
    """
    with contextlib.suppress(ValueError, AttributeError, RuntimeError):
        await mcp_ctx.report_progress(progress=progress, total=total, message=message)


async def _safe_sample(
    mcp_ctx: Context,
    *,
    system_prompt: str,
    user_message: str,
    max_tokens: int = 800,
    temperature: float = 0.2,
) -> str | None:
    """Ask the client's LLM to generate text via MCP sampling.

    Server-driven sampling lets the server delegate analysis to the
    client's model — useful when the server has a big payload (a 200-row
    queue, a long history list) and the user wants a tight summary
    without burning host context on raw rows. Per the spec the client
    must opt in to sampling support; this helper returns ``None`` when
    sampling isn't available, so callers fall back to a structured
    payload without analysis.

    Catches the same exception triad as :func:`_safe_info` plus
    ``McpError`` (raised when the client doesn't advertise sampling).
    """
    try:
        result = await mcp_ctx.session.create_message(
            messages=[
                _user_text(user_message),
            ],
            system_prompt=system_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
        )
    except Exception:
        return None
    text = getattr(getattr(result, "content", None), "text", None)
    if isinstance(text, str) and text.strip():
        return text.strip()
    return None


def _user_text(text: str) -> Any:
    """Build a ``SamplingMessage`` user turn with the given plain text."""
    from mcp.types import SamplingMessage, TextContent

    return SamplingMessage(
        role="user",
        content=TextContent(type="text", text=text),
    )


async def _safe_elicit(
    mcp_ctx: Context,
    message: str,
    schema: type[Any],
) -> Any | None:
    """Call ``ctx.elicit`` and return ``data`` on accept, ``None`` otherwise.

    Catches the same exception triad as :func:`_safe_info` so test
    harnesses that bypass FastMCP's request loop don't crash; treats
    decline/cancel + transport errors uniformly as "user said no" so
    callers can fall back to an error envelope without branching on
    transport state.

    The returned ``data`` is the populated Pydantic model from
    :class:`AcceptedElicitation` (callers know its concrete type from
    the ``schema`` they passed).
    """
    from mcp.server.elicitation import AcceptedElicitation

    try:
        result = await mcp_ctx.elicit(message, schema=schema)
    except (ValueError, AttributeError, RuntimeError):
        return None
    if isinstance(result, AcceptedElicitation):
        return result.data
    return None


async def _elicit_quality(
    mcp_ctx: Context,
    client: Any,
    *,
    brand: str,
) -> str | None:
    """Ask the user to pick a quality profile name; return ``None`` on decline.

    Looks up the live profiles on the resolved ``client`` so the prompt
    can list them. Falls back to a free-text input when the client list
    can't be fetched.
    """
    from pydantic import BaseModel, Field

    available: list[str] = []
    try:
        profiles = await client.quality_profiles.list()
        for p in profiles:
            name = getattr(p, "name", None)
            if isinstance(name, str) and name:
                available.append(name)
    except Exception:  # noqa: S110 — elicitation is best-effort UX
        pass
    options_str = ", ".join(available) if available else "(no profiles fetched)"

    class _QualityPick(BaseModel):
        quality_profile: str = Field(
            description=(
                f"Pick a {brand} quality profile by name. Available: {options_str}."
            ),
        )

    data = await _safe_elicit(
        mcp_ctx,
        f"Which {brand} quality profile should I use?",
        _QualityPick,
    )
    if data is None:
        return None
    return getattr(data, "quality_profile", None)


async def _elicit_root_folder(
    mcp_ctx: Context,
    client: Any,
    *,
    brand: str,
) -> str | None:
    """Ask the user to pick a root-folder path; return ``None`` on decline."""
    from pydantic import BaseModel, Field

    available: list[str] = []
    try:
        folders = await client.root_folders.list()
        for f in folders:
            path = getattr(f, "path", None)
            if isinstance(path, str) and path:
                available.append(path)
    except Exception:  # noqa: S110 — elicitation is best-effort UX
        pass
    options_str = ", ".join(available) if available else "(no root folders fetched)"

    class _FolderPick(BaseModel):
        root_folder: str = Field(
            description=(f"Pick a {brand} root folder. Available: {options_str}."),
        )

    data = await _safe_elicit(
        mcp_ctx,
        f"Which {brand} root folder should I use?",
        _FolderPick,
    )
    if data is None:
        return None
    return getattr(data, "root_folder", None)


def attach_composed_tools(
    server: FastMCP,
    provider: ClientProvider,
    deps: ToolDeps,
    *,
    journal: Any | None = None,
) -> None:
    """Register the high-level, chat-friendly composed tools.

    Each tool is wrapped via :func:`gated_tool` so it gets the same
    scope-check + audit pipeline brand tools have:

    - ``deps.scope_overrides`` flow through :func:`resolve_scopes` so
      mutating tools (``arr_sync_apply``, ``arr_grab_release``,
      ``arr_bulk_edit``, ``arr_trash_import``, ``arr_cleanup_queue``,
      ``arr_janitor_run``, ``arr_backfill``, ``arr_add``) reject
      principals lacking ``mcp:arr:mutate`` with the structured
      ``insufficient_scope`` envelope (rewritten to RFC 6750 by the ASGI
      middleware).
    - ``deps.audit`` fires on every outcome — success, scope denial,
      tool exception. Mutations that reach the body also write to the
      ``Journal`` if one was wired (separate sink, finer detail).
    - ``deps.dev_auth`` is threaded into the per-call ``_ctx`` builder
      so composed tools that resolve their own clients see the same
      principal the gate checked.
    """
    from arr_py_client.mcp._decorators import build_request_context, gated_tool

    def gate(
        *,
        title: str | None = None,
        annotations: Any | None = None,
        name: str | None = None,
    ):
        """Per-tool decorator binder — sugar over :func:`gated_tool`."""
        return gated_tool(server, deps, name=name, title=title, annotations=annotations)

    def _ctx(mcp_ctx: Context):
        """Build the RequestContext threaded to provider.resolve_*.

        Carries dev_auth principal through so scope metadata is
        consistent with what brand tools see.
        """
        return build_request_context(mcp_ctx, dev_auth=deps.dev_auth)

    @gate(title="Add movie or series", annotations=ADDITIVE)
    async def arr_add(
        title: str,
        app: Literal["auto", "radarr", "sonarr"] = "auto",
        quality: str | None = None,
        folder: str | None = None,
        tags: list[str] | None = None,
        monitored: bool = True,
        search_on_add: bool = True,
        if_exists: Literal["skip", "update", "error"] = "skip",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrAddOut:
        """Add a movie or series to Radarr/Sonarr by title, with name-based options.

        ``app="auto"`` uses whichever brand's lookup returns a match (Radarr
        first). ``quality`` accepts a profile name like ``"HD-1080p"`` or
        ``"4K-HDR"``. ``folder`` is a root-folder path; if omitted and only
        one is configured, it's auto-picked. ``tags`` accepts labels; missing
        ones are created. ``if_exists`` defaults to ``"skip"`` for chat safety
        — re-running the tool won't 409.

        **Elicitation**: when ``quality=`` or ``folder=`` is missing and
        the client supports MCP elicitation (spec 2025-06-18), the tool
        will pause to ask the user for the missing value rather than
        erroring. Falls through to a structured error envelope if the
        client declines, cancels, or doesn't support elicitation.
        """
        rctx = _ctx(ctx)
        chosen_app: str | None = None
        resource: dict[str, Any] | None = None
        already_existed = False

        # Local mutable copies so elicitation can fill them in.
        eff_quality = quality
        eff_folder = folder

        async def try_radarr() -> tuple[bool, dict[str, Any] | None]:
            nonlocal eff_quality, eff_folder
            radarr, err = await resolve_or_error(
                provider.resolve_radarr,
                rctx,
                radarr_instance_id,
                brand="radarr",
            )
            if err is not None:
                return False, None
            results = await radarr.movies.lookup(term=title)
            if not results:
                return False, None
            if eff_quality is None:
                eff_quality = await _elicit_quality(ctx, radarr, brand="radarr")
                if eff_quality is None:
                    return False, None
            if eff_folder is None:
                eff_folder = await _elicit_root_folder(ctx, radarr, brand="radarr")
                if eff_folder is None:
                    return False, None
            movie = await radarr.movies.add(
                title=title,
                quality=eff_quality,
                root_folder=eff_folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(movie, "all")

        async def try_sonarr() -> tuple[bool, dict[str, Any] | None]:
            nonlocal eff_quality, eff_folder
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr,
                rctx,
                sonarr_instance_id,
                brand="sonarr",
            )
            if err is not None:
                return False, None
            results = await sonarr.series.lookup(term=title)
            if not results:
                return False, None
            if eff_quality is None:
                eff_quality = await _elicit_quality(ctx, sonarr, brand="sonarr")
                if eff_quality is None:
                    return False, None
            if eff_folder is None:
                eff_folder = await _elicit_root_folder(ctx, sonarr, brand="sonarr")
                if eff_folder is None:
                    return False, None
            series = await sonarr.series.add(
                title=title,
                quality=eff_quality,
                root_folder=eff_folder,
                tags=list(tags) if tags is not None else None,
                monitored=monitored,
                search_on_add=search_on_add,
                if_exists=if_exists,
            )
            return True, project(series, "all")

        attempts: list[tuple[str, Any]] = []
        if app in ("auto", "radarr"):
            attempts.append(("radarr", try_radarr))
        if app in ("auto", "sonarr"):
            attempts.append(("sonarr", try_sonarr))

        errors: list[str] = []
        for brand, fn in attempts:
            try:
                hit, data = await fn()
            except Exception as exc:
                errors.append(f"{brand}: {exc}")
                continue
            if hit:
                chosen_app = brand
                resource = data
                break

        if chosen_app is None:
            return {
                "ok": False,
                "error": f"no lookup match for {title!r}",
                "errors": errors,
                "_meta": {
                    "action_hints": [
                        "arr_list_instances()",
                        "arr_list_resources()",
                        "radarr_movies_lookup(term=...)",
                        "sonarr_series_lookup(term=...)",
                    ]
                },
            }

        return {
            "ok": True,
            "app": chosen_app,
            "already_existed": already_existed,
            "data": resource,
            "_meta": {
                "action_hints": [
                    f"{chosen_app}_command_post(name='RescanMovie' | 'RescanSeries')",
                    "arr_health()",
                ],
            },
        }

    @gate(title="Cross-app health dashboard", annotations=READ_ONLY)
    async def arr_health(
        app: Literal["both", "radarr", "sonarr", "all"] = "both",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        prowlarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrHealthOut:
        """One-shot cross-app health dashboard.

        Brands the caller can't resolve are silently skipped — this is a
        health check, not an error condition. ``app="all"`` also includes
        Prowlarr (indexer + application test summary). Per-brand
        ``instance_id`` kwargs select a specific instance when the caller
        has multiple.
        """
        rctx = _ctx(ctx)
        out: dict[str, Any] = {}
        hints: list[str] = []
        include_radarr = app in ("both", "all", "radarr")
        include_sonarr = app in ("both", "all", "sonarr")
        include_prowlarr = app == "all"

        if include_radarr:
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, radarr_instance_id, brand="radarr"
            )
            if err is None:
                summary = await radarr.library.health_summary()
                out["radarr"] = _library_health_dict(summary)
                if summary.queue.stalled > 0:
                    hints.append("arr_cleanup_queue(app='radarr', dry_run=True)")
                if not summary.healthy:
                    hints.append("radarr_system_status(fields='all')")
                hints.append("arr_title_status(title=..., app='radarr')")
        if include_sonarr:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, sonarr_instance_id, brand="sonarr"
            )
            if err is None:
                summary = await sonarr.library.health_summary()
                out["sonarr"] = _library_health_dict(summary)
                if summary.queue.stalled > 0:
                    hints.append("arr_cleanup_queue(app='sonarr', dry_run=True)")
                if not summary.healthy:
                    hints.append("sonarr_system_status(fields='all')")
                hints.append("arr_title_status(title=..., app='sonarr')")
        if include_prowlarr:
            prowlarr, err = await resolve_or_error(
                provider.resolve_prowlarr,
                rctx,
                prowlarr_instance_id,
                brand="prowlarr",
            )
            if err is None:
                status = await prowlarr.system.list_status()
                indexers = await prowlarr.indexers.list()
                apps = await prowlarr.applications.list()
                out["prowlarr"] = {
                    "version": getattr(status, "version", None),
                    "indexer_count": len(indexers),
                    "application_count": len(apps),
                }
                hints.append("prowlarr_indexer_test_all()")
        out["_meta"] = {"action_hints": hints}
        return out

    @gate(title="Upcoming calendar items", annotations=READ_ONLY)
    async def arr_upcoming(
        days: int = 7,
        app: Literal["both", "radarr", "sonarr"] = "both",
        radarr_instance_id: str | None = None,
        sonarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrUpcomingOut:
        """Upcoming (or recently aired) calendar items across one or both apps."""
        from datetime import UTC, datetime, timedelta

        rctx = _ctx(ctx)
        now = datetime.now(UTC)
        start = now if days > 0 else now + timedelta(days=days)
        end = now + timedelta(days=days) if days > 0 else now
        items: dict[str, Any] = {}
        if app in ("both", "radarr"):
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, radarr_instance_id, brand="radarr"
            )
            if err is None:
                radarr_items = await radarr.calendar.list(start=start, end=end)
                items["radarr"] = [project(m, "summary") for m in radarr_items]
        if app in ("both", "sonarr"):
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, sonarr_instance_id, brand="sonarr"
            )
            if err is None:
                sonarr_items = await sonarr.calendar.list(start=start, end=end)
                items["sonarr"] = [project(e, "summary") for e in sonarr_items]
        return {
            "data": items,
            "_meta": {
                "window_days": days,
                "action_hints": [
                    "arr_health()",
                    "arr_find_release(title=..., app=...)",
                ],
            },
        }

    @gate(title="Find candidate releases", annotations=READ_ONLY)
    async def arr_find_release(
        title: str,
        app: Literal["radarr", "sonarr"],
        min_seeders: int | None = None,
        prefer_codec: str | None = None,
        limit: int = 10,
        indexers: list[int] | None = None,
        include_prowlarr: bool = False,
        instance_id: str | None = None,
        prowlarr_instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrFindReleaseOut:
        """Look up a title, then query indexers for candidate releases.

        ``instance_id`` selects which Radarr or Sonarr instance to query
        (based on ``app``); ``prowlarr_instance_id`` picks the Prowlarr
        for fan-out when ``include_prowlarr=True``.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            candidates: list[Any] = list(
                await radarr.releases.search(movie_id=target.id)
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            candidates = list(await sonarr.releases.search(series_id=target_s.id))

        if indexers is not None:
            indexer_ids = set(indexers)
            candidates = [
                c for c in candidates if getattr(c, "indexer_id", None) in indexer_ids
            ]

        prowlarr_added = 0
        if include_prowlarr:
            prowlarr, err = await resolve_or_error(
                provider.resolve_prowlarr,
                rctx,
                prowlarr_instance_id,
                brand="prowlarr",
            )
            if err is None:
                prowlarr_raw = await prowlarr.search.list_(
                    query=title, indexer_ids=list(indexers) if indexers else None
                )
                known_guids = {
                    str(getattr(c, "guid", "") or "") for c in candidates
                } - {""}
                for item in prowlarr_raw:
                    guid = str(getattr(item, "guid", "") or "")
                    if guid and guid in known_guids:
                        continue
                    candidates.append(item)
                    if guid:
                        known_guids.add(guid)
                    prowlarr_added += 1

        if min_seeders is not None:
            candidates = [
                c
                for c in candidates
                if (getattr(c, "seeders", None) or 0) >= min_seeders
            ]

        def _k(r: Any) -> tuple[int, int, int]:
            seeders = int(getattr(r, "seeders", None) or 0)
            title_str = str(getattr(r, "title", "") or "").lower()
            codec = 1 if prefer_codec and prefer_codec.lower() in title_str else 0
            size = int(getattr(r, "size", None) or 0)
            return (-seeders, -codec, size)

        candidates.sort(key=_k)
        trimmed = candidates[:limit]
        return {
            "ok": True,
            "app": app,
            "candidates": [project(c, "summary") for c in trimmed],
            "_meta": {
                "count": len(trimmed),
                "prowlarr_added": prowlarr_added,
                "indexers_filter": list(indexers) if indexers else None,
                "action_hints": [
                    "arr_grab_release(guid=..., indexer_id=..., app=...)",
                ],
            },
        }

    @gate(title="Grab a specific release", annotations=ADDITIVE)
    async def arr_grab_release(
        guid: str,
        indexer_id: int,
        app: Literal["radarr", "sonarr"],
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrGrabReleaseOut:
        """Grab a specific release from :func:`arr_find_release`'s candidates."""
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await radarr.releases.grab(guid=guid, indexer_id=indexer_id)
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await sonarr.releases.grab(guid=guid, indexer_id=indexer_id)
        return {
            "ok": True,
            "app": app,
            "_meta": {
                "action_hints": [
                    f"{app}_queue_list()",
                    "arr_health()",
                ]
            },
        }

    @gate(title="Clean up stuck downloads", annotations=DESTRUCTIVE)
    async def arr_cleanup_queue(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        blocklist: bool = True,
        search: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrCleanupQueueOut:
        """Find stuck downloads and (optionally) nuke + blocklist + re-search.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            result = await radarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            result = await sonarr.queue.clear_stuck(
                blocklist=blocklist, search=search, dry_run=dry_run
            )
        hints: list[str] = []
        if dry_run and result.ids:
            hints.append(f"arr_cleanup_queue(app={app!r}, dry_run=False)")
        if not result.ids:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": result.dry_run,
            "ids": result.ids,
            "count": len(result.ids),
            "blocklisted": result.blocklisted,
            "redownload": result.redownload,
            "_meta": {"action_hints": hints},
        }

    @gate(title="Policy-based queue cleanup", annotations=DESTRUCTIVE)
    async def arr_janitor_run(
        app: Literal["radarr", "sonarr"],
        dry_run: bool = True,
        protected_trackers: list[str] | None = None,
        bundle: Literal[
            "default", "conservative", "aggressive", "ratio_preserving"
        ] = "default",
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrJanitorRunOut:
        """Policy-based queue cleanup. More flexible than :func:`arr_cleanup_queue`.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client import POLICIES

        rctx = _ctx(ctx)
        protected = tuple(protected_trackers or ())
        policies = getattr(POLICIES, bundle)
        await _safe_progress(ctx, 0.0, 2.0, f"Resolving {app}...")
        await _safe_info(ctx, f"arr_janitor_run: resolving {app} (dry_run={dry_run})")
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await _safe_progress(
                ctx, 1.0, 2.0, f"Scanning radarr queue (bundle={bundle})..."
            )
            await _safe_info(
                ctx, f"arr_janitor_run: scanning radarr queue with bundle={bundle}"
            )
            report = await radarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await _safe_progress(
                ctx, 1.0, 2.0, f"Scanning sonarr queue (bundle={bundle})..."
            )
            await _safe_info(
                ctx, f"arr_janitor_run: scanning sonarr queue with bundle={bundle}"
            )
            report = await sonarr.queue.janitor(
                policies=policies,
                dry_run=dry_run,
                protected_trackers=protected,
                journal=journal,
            )
        await _safe_progress(ctx, 2.0, 2.0, "Complete")
        hints: list[str] = []
        if dry_run and report.total_matches:
            hints.append(f"arr_janitor_run(app={app!r}, dry_run=False)")
        if not report.total_matches:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "dry_run": report.dry_run,
            "total_matches": report.total_matches,
            "protected_skips": report.protected_skips,
            "executed_blocklist_ids": report.executed_blocklist_ids,
            "executed_remove_ids": report.executed_remove_ids,
            "matches": [
                {
                    "id": m.item_id,
                    "title": m.item_title,
                    "policy": m.policy_name,
                    "action": m.action.value,
                    "indexer": m.indexer,
                }
                for m in report.matches
            ],
            "_meta": {"action_hints": hints},
        }

    @gate(title="Summarize queue (LLM-narrated)", annotations=READ_ONLY)
    async def arr_summarize_queue(
        app: Literal["radarr", "sonarr"],
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrSummarizeQueueOut:
        """Return a server-computed status histogram + LLM-generated narrative.

        Server-driven sampling (MCP spec 2025-06-18) lets the server
        delegate analysis to the *client's* LLM. The server fetches the
        full queue (potentially hundreds of rows), computes a
        deterministic per-status histogram + the list of stalled ids,
        then asks the client's LLM to produce a tight narrative summary
        (3-5 sentences). Net result: the user sees one short paragraph
        instead of a 200-row dump, and the host context bill is paid by
        the client (whose context window is presumably what we're
        trying to save).

        When the client doesn't advertise sampling support, the
        ``summary`` field is ``None`` and ``sampled=False`` — the
        deterministic histogram + ``stalled_ids`` are still useful and
        the caller can route through ``arr_cleanup_queue`` directly.

        Use when the queue is large and the user asks "what's
        happening in my queue?" — the deterministic part covers
        triage; the narrative explains *why*.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err

        # Walk the full queue (paged) so the histogram is global, not
        # capped at one page.
        items: list[Any] = []
        async for item in client.queue.aiter_all(page_size=100):
            items.append(item)

        buckets: dict[str, int] = {
            "downloading": 0,
            "queued": 0,
            "completed": 0,
            "failed": 0,
            "warning": 0,
            "paused": 0,
            "delay": 0,
            "other": 0,
        }
        stalled_ids: list[int] = []
        rows_for_prompt: list[str] = []
        for item in items:
            status = (getattr(item, "status", None) or "other").lower()
            if status in buckets:
                buckets[status] += 1
            else:
                buckets["other"] += 1
            tracked_state = getattr(item, "tracked_download_state", None)
            if status in ("failed", "warning") or tracked_state == "importBlocked":
                iid = getattr(item, "id", None)
                if isinstance(iid, int):
                    stalled_ids.append(iid)
            # Compact one-liner for the prompt: id, title, status, state, indexer.
            rows_for_prompt.append(
                f"id={getattr(item, 'id', None)} "
                f"title={(getattr(item, 'title', None) or '')[:80]!r} "
                f"status={status} "
                f"state={tracked_state} "
                f"indexer={getattr(item, 'indexer', None)}"
            )

        summary: str | None = None
        sampled = False
        if items:
            sample_text = await _safe_sample(
                ctx,
                system_prompt=(
                    "You are an Arr-stack triage assistant. Given a "
                    "compact queue listing, write a 3-5 sentence "
                    "narrative covering: total items, what's healthy "
                    "vs. stuck, the most common failure mode if any, "
                    "and one concrete recommended next action. Be "
                    "specific about counts. Don't list every row."
                ),
                user_message=(
                    f"{app.title()} queue ({len(items)} items):\n"
                    + "\n".join(rows_for_prompt)
                ),
            )
            if sample_text is not None:
                summary = sample_text
                sampled = True

        hints: list[str] = []
        if stalled_ids:
            hints.append(f"arr_cleanup_queue(app={app!r}, dry_run=True)")
        if not items:
            hints.append("arr_health()")

        return {
            "ok": True,
            "app": app,
            "total": len(items),
            "by_status": buckets,
            "stalled_ids": stalled_ids,
            "summary": summary,
            "sampled": sampled,
            "_meta": {"action_hints": hints},
        }

    @gate(title="Explain why a release wasn't grabbed", annotations=READ_ONLY)
    async def arr_explain_grab(
        title: str,
        app: Literal["radarr", "sonarr"],
        episode_id: int | None = None,
        season_number: int | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrExplainGrabOut:
        """Answer "why didn't it grab the better version?" for a library item."""
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == hits[0].tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return error(
                    "movie not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='radarr')"],
                )
            explanation = await radarr.releases.explain(movie_id=target.id)
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            hits_s = await sonarr.series.lookup(term=title)
            if not hits_s or not hits_s[0].tvdb_id:
                return error(
                    f"no series lookup match for {title!r}",
                    hints=["sonarr_series_lookup(term=...)"],
                )
            resolved_s = await sonarr.series.list()
            target_s = next(
                (s for s in resolved_s if s.tvdb_id == hits_s[0].tvdb_id and s.id),
                None,
            )
            if target_s is None or target_s.id is None:
                return error(
                    "series not in library; add it first via arr_add(...)",
                    hints=[f"arr_add(title={title!r}, app='sonarr')"],
                )
            explanation = await sonarr.releases.explain(
                series_id=target_s.id,
                episode_id=episode_id,
                season_number=season_number,
            )
        hints = (
            [f"arr_grab_release(guid=..., indexer_id=..., app={app!r})"]
            if explanation.accepted
            else ["arr_health()"]
        )
        return {
            "ok": True,
            "app": app,
            "item_id": explanation.item_id,
            "item_title": explanation.item_title,
            "current_quality": explanation.current_quality,
            "current_custom_format_score": explanation.current_custom_format_score,
            "summary": explanation.summary(),
            "advice": explanation.advice(),
            "verdicts": [
                {
                    "title": v.title,
                    "indexer": v.indexer,
                    "quality": v.quality,
                    "quality_weight": v.quality_weight,
                    "custom_format_score": v.custom_format_score,
                    "size": v.size,
                    "seeders": v.seeders,
                    "age_hours": v.age_hours,
                    "languages": v.languages,
                    "release_group": v.release_group,
                    "status": v.status,
                    "rejections": v.rejections,
                    "guid": v.guid,
                    "indexer_id": v.indexer_id,
                }
                for v in explanation.verdicts
            ],
            "_meta": {
                "accepted_count": len(explanation.accepted),
                "rejected_count": len(explanation.rejected),
                "action_hints": hints,
            },
        }

    @gate(title="Per-title library status", annotations=READ_ONLY)
    async def arr_title_status(
        title: str,
        app: Literal["radarr", "sonarr"],
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrTitleStatusOut:
        """Per-title library status: how complete is this movie/series?

        Looks up ``title``, matches it to your library, and returns
        download / missing counts with key metadata in one call — the
        natural answer to "how many episodes of X do I not have?",
        "do I have X?", or "what's missing for X?".

        Keywords: title status, library gaps, missing episodes,
        missing movies, series progress, completeness, downloaded.

        Not in library → ``in_library=False`` + lookup metadata and
        an ``arr_add(...)`` hint. For Sonarr, ``missing_count`` is
        monitored/aired episodes without files; ``total_missing_count``
        includes unaired/unmonitored episodes. Per-season breakdown is
        in ``stats_by_season``.
        """
        rctx = _ctx(ctx)
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            hits = await radarr.movies.lookup(term=title)
            if not hits or not hits[0].tmdb_id:
                return error(
                    f"no movie lookup match for {title!r}",
                    hints=["radarr_movies_lookup(term=...)"],
                )
            lookup = hits[0]
            resolved = await radarr.movies.list()
            target = next(
                (m for m in resolved if m.tmdb_id == lookup.tmdb_id and m.id),
                None,
            )
            if target is None or target.id is None:
                return {
                    "ok": True,
                    "app": "radarr",
                    "in_library": False,
                    "title": lookup.title or title,
                    "year": getattr(lookup, "year", None),
                    "tmdb_id": lookup.tmdb_id,
                    "imdb_id": getattr(lookup, "imdb_id", None),
                    "_meta": {
                        "action_hints": [
                            f"arr_add(title={title!r}, app='radarr')",
                        ],
                    },
                }
            stats = target.statistics
            has_file = target.has_file
            monitored = target.monitored
            missing = (
                (monitored is True and has_file is False)
                if monitored is not None and has_file is not None
                else None
            )
            hints = (
                [f"arr_find_release(title={target.title!r}, app='radarr')"]
                if missing
                else [f"arr_explain_grab(title={target.title!r}, app='radarr')"]
            )
            return {
                "ok": True,
                "app": "radarr",
                "in_library": True,
                "movie_id": target.id,
                "title": target.title,
                "year": target.year,
                "tmdb_id": target.tmdb_id,
                "imdb_id": target.imdb_id,
                "status": target.status.value if target.status is not None else None,
                "monitored": monitored,
                "has_file": has_file,
                "missing": missing,
                "is_available": target.is_available,
                "movie_file_count": (
                    (stats.movie_file_count or 0) if stats is not None else 0
                ),
                "size_on_disk": target.size_on_disk or 0,
                "quality_profile_id": target.quality_profile_id,
                "quality_profile": None,
                "root_folder_path": target.root_folder_path,
                "in_cinemas": (
                    target.in_cinemas.isoformat() if target.in_cinemas else None
                ),
                "digital_release": (
                    target.digital_release.isoformat()
                    if target.digital_release
                    else None
                ),
                "physical_release": (
                    target.physical_release.isoformat()
                    if target.physical_release
                    else None
                ),
                "release_date": (
                    target.release_date.isoformat() if target.release_date else None
                ),
                "_meta": {"action_hints": hints},
            }

        sonarr, err = await resolve_or_error(
            provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
        )
        if err is not None:
            return err
        hits_s = await sonarr.series.lookup(term=title)
        if not hits_s or not hits_s[0].tvdb_id:
            return error(
                f"no series lookup match for {title!r}",
                hints=["sonarr_series_lookup(term=...)"],
            )
        lookup_s = hits_s[0]
        resolved_s = await sonarr.series.list()
        target_s = next(
            (s for s in resolved_s if s.tvdb_id == lookup_s.tvdb_id and s.id),
            None,
        )
        if target_s is None or target_s.id is None:
            return {
                "ok": True,
                "app": "sonarr",
                "in_library": False,
                "title": lookup_s.title or title,
                "year": getattr(lookup_s, "year", None),
                "tvdb_id": lookup_s.tvdb_id,
                "imdb_id": getattr(lookup_s, "imdb_id", None),
                "_meta": {
                    "action_hints": [
                        f"arr_add(title={title!r}, app='sonarr')",
                    ],
                },
            }
        stats_s = target_s.statistics
        ep_count = (stats_s.episode_count or 0) if stats_s is not None else 0
        file_count = (stats_s.episode_file_count or 0) if stats_s is not None else 0
        total_ep = (stats_s.total_episode_count or 0) if stats_s is not None else 0
        missing_count = max(0, ep_count - file_count)
        total_missing = max(0, total_ep - file_count)
        stats_by_season: list[dict[str, Any]] = []
        seasons_iter: list[Any] = list(target_s.seasons or [])
        for season in seasons_iter:
            sstats: Any = season.statistics
            s_ep: int = int((sstats.episode_count or 0) if sstats is not None else 0)
            s_file: int = int(
                (sstats.episode_file_count or 0) if sstats is not None else 0
            )
            s_total: int = int(
                (sstats.total_episode_count or 0) if sstats is not None else 0
            )
            stats_by_season.append(
                {
                    "season_number": season.season_number,
                    "monitored": season.monitored,
                    "episode_count": s_ep,
                    "episode_file_count": s_file,
                    "missing_count": max(0, s_ep - s_file),
                    "total_episode_count": s_total,
                    "total_missing_count": max(0, s_total - s_file),
                    "size_on_disk": (
                        (sstats.size_on_disk or 0) if sstats is not None else 0
                    ),
                    "next_airing": (
                        sstats.next_airing.isoformat()
                        if sstats is not None and sstats.next_airing is not None
                        else None
                    ),
                    "previous_airing": (
                        sstats.previous_airing.isoformat()
                        if sstats is not None and sstats.previous_airing is not None
                        else None
                    ),
                    "percent_of_episodes": (
                        sstats.percent_of_episodes if sstats is not None else None
                    ),
                }
            )
        s_hints: list[str] = []
        if missing_count > 0:
            s_hints.append(f"arr_find_release(title={target_s.title!r}, app='sonarr')")
            s_hints.append("arr_backfill(app='sonarr', dry_run=True)")
        else:
            s_hints.append("arr_health()")
        return {
            "ok": True,
            "app": "sonarr",
            "in_library": True,
            "series_id": target_s.id,
            "title": target_s.title,
            "year": target_s.year,
            "tvdb_id": target_s.tvdb_id,
            "imdb_id": target_s.imdb_id,
            "status": (target_s.status.value if target_s.status is not None else None),
            "ended": target_s.ended,
            "monitored": target_s.monitored,
            "network": target_s.network,
            "quality_profile_id": target_s.quality_profile_id,
            "quality_profile": target_s.profile_name,
            "root_folder_path": target_s.root_folder_path,
            "episode_count": ep_count,
            "episode_file_count": file_count,
            "missing_count": missing_count,
            "total_episode_count": total_ep,
            "total_missing_count": total_missing,
            "percent_of_episodes": (
                stats_s.percent_of_episodes if stats_s is not None else None
            ),
            "size_on_disk": ((stats_s.size_on_disk or 0) if stats_s is not None else 0),
            "next_airing": (
                target_s.next_airing.isoformat()
                if target_s.next_airing is not None
                else None
            ),
            "previous_airing": (
                target_s.previous_airing.isoformat()
                if target_s.previous_airing is not None
                else None
            ),
            "first_aired": (
                target_s.first_aired.isoformat()
                if target_s.first_aired is not None
                else None
            ),
            "last_aired": (
                target_s.last_aired.isoformat()
                if target_s.last_aired is not None
                else None
            ),
            "stats_by_season": stats_by_season,
            "_meta": {"action_hints": s_hints},
        }

    @gate(title="Search for missing/cutoff-unmet items", annotations=ADDITIVE)
    async def arr_backfill(
        app: Literal["radarr", "sonarr"],
        source: Literal["missing", "cutoff_unmet", "both"] = "missing",
        batch_size: int | None = None,
        delay_between_batches: float = 30.0,
        max_items: int | None = None,
        pause_if_queue_over: int | None = None,
        monitored_only: bool = True,
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrBackfillOut:
        """Rate-limited safe missing-content search loop (Huntarr-shaped).

        **Defaults to ``dry_run=True``** for chat safety.
        """
        rctx = _ctx(ctx)
        effective_batch = (
            batch_size if batch_size is not None else (5 if app == "radarr" else 20)
        )
        await _safe_progress(ctx, 0.0, 2.0, f"Resolving {app}...")
        await _safe_info(ctx, f"arr_backfill: resolving {app} (dry_run={dry_run})")
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await _safe_progress(
                ctx,
                1.0,
                2.0,
                f"Searching missing items (batch_size={effective_batch})...",
            )
            await _safe_info(
                ctx,
                (
                    f"arr_backfill: searching {app} (source={source}, "
                    f"batch_size={effective_batch}, dry_run={dry_run})"
                ),
            )
            report = await radarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await _safe_progress(
                ctx,
                1.0,
                2.0,
                f"Searching missing items (batch_size={effective_batch})...",
            )
            await _safe_info(
                ctx,
                (
                    f"arr_backfill: searching {app} (source={source}, "
                    f"batch_size={effective_batch}, dry_run={dry_run})"
                ),
            )
            report = await sonarr.library.backfill(
                source=source,
                batch_size=effective_batch,
                delay_between_batches=delay_between_batches,
                max_items=max_items,
                pause_if_queue_over=pause_if_queue_over,
                monitored_only=monitored_only,
                dry_run=dry_run,
                journal=journal,
            )
        await _safe_progress(ctx, 2.0, 2.0, "Complete")
        from arr_py_client._common.backfill import estimate as _estimate

        hints: list[str] = []
        if dry_run and report.searched_count:
            hints.append(f"arr_backfill(app={app!r}, dry_run=False)")
        if report.stopped_reason == "queue_saturated":
            hints.append(f"{app}_queue_list()")
        est = _estimate(
            report.searched_count,
            batch_size=effective_batch,
            delay_between_batches=delay_between_batches,
        )
        return {
            "ok": True,
            "app": app,
            "source": report.source,
            "dry_run": report.dry_run,
            "searched_count": report.searched_count,
            "batches_sent": report.batches_sent,
            "stopped_reason": cast("Any", report.stopped_reason).value,
            "queue_checks": report.queue_checks,
            "searched_ids": report.searched_ids,
            "_meta": {
                "action_hints": hints,
                "estimate": {
                    "batches": est.batches,
                    "duration_seconds": int(est.duration.total_seconds()),
                    "eta_iso": est.eta.isoformat(),
                    "summary": est.summary(),
                },
            },
        }

    @gate(title="Plan config sync (preview)", annotations=READ_ONLY)
    async def arr_sync_plan(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrSyncPlanOut:
        """Preview config-sync changes: diff ``desired`` against the live server."""
        from arr_py_client.config_sync import plan_async as _plan_async

        rctx = _ctx(ctx)
        await _safe_info(ctx, f"arr_sync_plan: resolving {app}")
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        await _safe_info(ctx, f"arr_sync_plan: diffing desired against {app}")
        plan_ = await _plan_async(client, desired, strict=strict)
        hints: list[str] = []
        if plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        else:
            hints.append("arr_health()")
        return {
            "ok": True,
            "app": app,
            "strict": plan_.strict,
            "is_noop": plan_.is_noop,
            "summary": plan_.summary(),
            "changes": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "existing_id": c.existing_id,
                    "detail": c.detail,
                }
                for c in plan_.changes
            ],
            "_meta": {"action_hints": hints},
        }

    @gate(title="Apply config sync", annotations=MUTATING)
    async def arr_sync_apply(
        app: Literal["radarr", "sonarr"],
        desired: dict[str, Any],
        strict: bool = False,
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrSyncApplyOut:
        """Plan + apply a config-sync desired state. **Defaults to ``dry_run=True``.**"""
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async

        rctx = _ctx(ctx)
        await _safe_progress(ctx, 0.0, 3.0, f"Resolving {app}...")
        await _safe_info(ctx, f"arr_sync_apply: resolving {app} (dry_run={dry_run})")
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        await _safe_progress(ctx, 1.0, 3.0, f"Planning against {app}...")
        await _safe_info(ctx, f"arr_sync_apply: planning against {app}")
        plan_ = await _plan_async(client, desired, strict=strict)
        await _safe_progress(
            ctx,
            2.0,
            3.0,
            f"Applying {len(plan_.changes)} changes (dry_run={dry_run})...",
        )
        await _safe_info(
            ctx,
            f"arr_sync_apply: applying {len(plan_.changes)} changes (dry_run={dry_run})",
        )
        report = await _apply_async(client, plan_, dry_run=dry_run, journal=journal)
        await _safe_progress(ctx, 3.0, 3.0, "Complete")
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(f"arr_sync_apply(app={app!r}, desired=..., dry_run=False)")
        if report.errors:
            hints.append("arr_list_resources()")
        return {
            "ok": not report.errors,
            "app": app,
            "dry_run": report.dry_run,
            "summary": plan_.summary(),
            "applied_count": len(report.applied),
            "skipped_count": len(report.skipped),
            "error_count": len(report.errors),
            "applied": [
                {"resource": c.resource, "name": c.name, "action": c.action}
                for c in report.applied
            ],
            "errors": [
                {
                    "resource": c.resource,
                    "name": c.name,
                    "action": c.action,
                    "error": err,
                }
                for c, err in report.errors
            ],
            "_meta": {"action_hints": hints},
        }

    @gate(title="Dump live config-sync state", annotations=READ_ONLY)
    async def arr_sync_dump(
        app: Literal["radarr", "sonarr", "prowlarr"],
        include: list[str] | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrSyncDumpOut:
        """Serialize live server state into the dict shape ``arr_sync_plan`` consumes."""
        from arr_py_client.config_sync import dump_async as _dump_async

        rctx = _ctx(ctx)
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        elif app == "sonarr":
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_prowlarr, rctx, instance_id, brand="prowlarr"
            )
        if err is not None:
            return err
        scope = cast("list[Any] | None", list(include) if include else None)
        dumped = await _dump_async(client, include=scope)
        counts: dict[str, int] = {}
        for k, v in dumped.items():
            if isinstance(v, list):
                counts[k] = len(cast("list[Any]", v))
            elif isinstance(v, dict):
                counts[k] = len(cast("dict[str, Any]", v))
            else:
                counts[k] = 1
        return {
            "ok": True,
            "app": app,
            "data": dumped,
            "_meta": {
                "resource_counts": counts,
                "action_hints": [
                    f"arr_sync_plan(app={app!r}, desired=<dumped>)",
                ],
            },
        }

    @gate(title="Bulk-edit movies or series", annotations=MUTATING)
    async def arr_bulk_edit(
        app: Literal["radarr", "sonarr"],
        ids: list[int],
        monitored: bool | None = None,
        quality: str | None = None,
        root_folder: str | None = None,
        tags: list[str] | None = None,
        apply_tags: Literal["add", "remove", "replace"] = "add",
        move_files: bool | None = None,
        season_folder: bool | None = None,
        series_type: Literal["standard", "daily", "anime"] | None = None,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrBulkEditOut:
        """Bulk-edit many movies/series in one call."""
        rctx = _ctx(ctx)
        if not ids:
            return error(
                "ids must be non-empty",
                hints=[f"{app}_{'movies' if app == 'radarr' else 'series'}_list()"],
            )
        if app == "radarr":
            radarr, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
            if err is not None:
                return err
            await radarr.movies.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                journal=journal,
            )
        else:
            sonarr, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
            if err is not None:
                return err
            await sonarr.series.bulk_edit(
                ids=list(ids),
                monitored=monitored,
                quality=quality,
                root_folder=root_folder,
                tags=list(tags) if tags is not None else None,
                apply_tags=apply_tags,
                move_files=move_files,
                season_folder=season_folder,
                series_type=series_type,
                journal=journal,
            )
        return {
            "ok": True,
            "app": app,
            "ids": list(ids),
            "count": len(ids),
            "_meta": {
                "action_hints": [
                    f"{app}_{'movies' if app == 'radarr' else 'series'}_list(fields='id,title,tags,monitored')",
                ],
            },
        }

    @gate(title="Import TRaSH-Guides bundles", annotations=MUTATING)
    async def arr_trash_import(
        app: Literal["radarr", "sonarr"],
        custom_formats: list[str] | None = None,
        release_profiles: list[str] | None = None,
        quality_definitions: str | None = None,
        ref: str = "master",
        dry_run: bool = True,
        instance_id: str | None = None,
        *,
        ctx: Context,
    ) -> ArrTrashImportOut:
        """Pull TRaSH-Guides custom formats, release profiles, and/or quality sizes.

        **Defaults to ``dry_run=True``** for chat safety.
        """
        from arr_py_client.config_sync import apply_async as _apply_async
        from arr_py_client.config_sync import plan_async as _plan_async
        from arr_py_client.trash import fetch_desired_state

        rctx = _ctx(ctx)
        await _safe_progress(ctx, 0.0, 4.0, f"Resolving {app}...")
        if app == "radarr":
            client, err = await resolve_or_error(
                provider.resolve_radarr, rctx, instance_id, brand="radarr"
            )
        else:
            client, err = await resolve_or_error(
                provider.resolve_sonarr, rctx, instance_id, brand="sonarr"
            )
        if err is not None:
            return err
        if not custom_formats and not release_profiles and not quality_definitions:
            return error(
                "pass at least one of custom_formats=, release_profiles=, or quality_definitions=",
                hints=[
                    f"arr_trash_import(app={app!r}, custom_formats=[...])",
                    f"arr_trash_import(app={app!r}, release_profiles=[...])",
                    f"arr_trash_import(app={app!r}, quality_definitions='movie')",
                ],
            )
        await _safe_progress(ctx, 1.0, 4.0, f"Fetching TRaSH bundle ({ref})...")
        await _safe_info(ctx, f"arr_trash_import: fetching ref={ref}")
        try:
            desired = fetch_desired_state(
                app,
                custom_formats=custom_formats,
                release_profiles=release_profiles,
                quality_definitions=quality_definitions,
                ref=ref,
            )
        except Exception as exc:
            return error(
                f"trash fetch failed: {exc}",
                hints=[f"arr_trash_import(app={app!r}, custom_formats=[...])"],
            )
        await _safe_progress(ctx, 2.0, 4.0, "Planning changes...")
        plan_ = await _plan_async(client, desired)
        hints: list[str] = []
        if dry_run and plan_.changes:
            hints.append(
                f"arr_trash_import(app={app!r}, custom_formats={custom_formats!r}, release_profiles={release_profiles!r}, quality_definitions={quality_definitions!r}, ref={ref!r}, dry_run=False)"
            )
        if not plan_.changes:
            hints.append("arr_health()")
        applied_count = 0
        error_count = 0
        if not dry_run and plan_.changes:
            await _safe_progress(
                ctx, 3.0, 4.0, f"Applying {len(plan_.changes)} changes..."
            )
            report = await _apply_async(client, plan_, dry_run=False, journal=journal)
            applied_count = len(report.applied)
            error_count = len(report.errors)
        await _safe_progress(ctx, 4.0, 4.0, "Complete")
        return {
            "ok": error_count == 0,
            "app": app,
            "ref": ref,
            "dry_run": dry_run,
            "fetched_custom_formats": len(desired.get("custom_formats") or {}),
            "fetched_release_profiles": len(desired.get("release_profiles") or {}),
            "fetched_quality_definitions": len(
                desired.get("quality_definitions") or {}
            ),
            "plan_summary": plan_.summary(),
            "applied_count": applied_count,
            "error_count": error_count,
            "_meta": {"action_hints": hints},
        }

    # Silence unused-warnings for function scope; they're registered via decorator.
    _ = (
        arr_add,
        arr_health,
        arr_upcoming,
        arr_find_release,
        arr_grab_release,
        arr_cleanup_queue,
        arr_janitor_run,
        arr_summarize_queue,
        arr_explain_grab,
        arr_title_status,
        arr_backfill,
        arr_sync_plan,
        arr_sync_apply,
        arr_sync_dump,
        arr_bulk_edit,
        arr_trash_import,
    )
