"""Pydantic output schemas for the high-information composed MCP tools.

The MCP spec lets servers declare an ``outputSchema`` per tool; clients
+ LLMs use it to validate, type-check, and reliably parse responses
without inferring shapes from examples. FastMCP auto-generates the
schema from the tool's return-type annotation.

For most brand tools, ``dict[str, Any]`` is fine — the data they return
is dynamic and the LLM uses ``arr_describe_fields`` for shape discovery.
But the four high-information *composed* tools answer common questions
where a tight schema noticeably improves agent behavior:

- ``arr_health`` — fleet-status dashboard
- ``arr_title_status`` — per-title library state
- ``arr_explain_grab`` — release-verdict explanation
- ``arr_find_release`` — candidate-release listing

Each model uses ``extra="allow"`` so the existing dict-shaped tool
bodies continue to work unchanged: FastMCP coerces the returned dict
via ``model_validate``, declared fields appear in ``structuredContent``
with their JSON-Schema types, and any unmapped extras flow through
unmodeled (e.g. ``ok: False`` error envelopes route through the same
schema with the optional fields absent).

The ``error`` field is typed ``Any`` rather than ``str`` so the
:func:`gated_tool` scope-check + audit pipeline can return a structured
error dict (``{"type": "insufficient_scope", ...}``) without breaking
schema validation. Tool bodies still produce simple string errors for
known failure modes; the schema permits both.

Field aliases handle ``_meta`` (underscore-leading attribute names
aren't valid Python identifiers; the alias rewrites the JSON key).
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ToolMeta(BaseModel):
    """Shape of the ``_meta`` envelope shared by every composed-tool response.

    ``action_hints`` is a list of next-tool-call strings the LLM should
    consider; other keys carry tool-specific metadata (resource id,
    pagination cursor, instance id, etc.).
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    action_hints: list[str] = Field(default_factory=list)


# ---------------------------------------------------------- arr_health --


class _DiskInfo(BaseModel):
    """One row from a brand's disk-space report."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    path: str | None = None
    free_bytes: int | None = None
    total_bytes: int | None = None
    free_percent: float | None = None
    label: str | None = None


class _QueueSummary(BaseModel):
    """Per-brand queue health aggregated from the queue listing."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    pending: int = 0
    stalled: int = 0
    completed: int = 0


class _LibraryHealth(BaseModel):
    """Per-brand health summary returned by ``library.health_summary()``.

    Mirror of :class:`arr_py_client._common.diagnostics.LibraryHealth`,
    flattened for JSON transport.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    healthy: bool = True
    version: str | None = None
    library_count: int = 0
    disks: list[_DiskInfo] = Field(default_factory=list)
    queue: _QueueSummary = Field(default_factory=_QueueSummary)
    errors: list[str] = Field(default_factory=list)


class _ProwlarrSummary(BaseModel):
    """Reduced Prowlarr summary used by ``arr_health(app='all')``."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    version: str | None = None
    indexer_count: int = 0
    application_count: int = 0


class ArrHealthOut(BaseModel):
    """Output schema for :func:`arr_health`.

    All three brand keys are optional — ``arr_health`` silently skips
    unconfigured brands so clients shouldn't assume any of them is
    present.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    radarr: _LibraryHealth | None = None
    sonarr: _LibraryHealth | None = None
    prowlarr: _ProwlarrSummary | None = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ---------------------------------------------------- arr_title_status --


class ArrTitleStatusOut(BaseModel):
    """Output schema for :func:`arr_title_status`.

    Wraps both the in-library and not-in-library shapes plus the error
    envelope (``ok=False`` + ``error``). Most fields are optional so
    Pydantic accepts every code path.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    in_library: bool | None = None
    error: Any = None

    # Common metadata (both library + lookup paths)
    title: str | None = None
    year: int | None = None
    tmdb_id: int | None = None
    tvdb_id: int | None = None
    imdb_id: str | None = None

    # Library-only fields
    movie_id: int | None = None
    series_id: int | None = None
    status: str | None = None
    monitored: bool | None = None
    has_file: bool | None = None
    missing: bool | None = None
    is_available: bool | None = None
    movie_file_count: int | None = None
    size_on_disk: int | None = None
    quality_profile_id: int | None = None
    root_folder_path: str | None = None

    # Sonarr-only
    episode_count: int | None = None
    episode_file_count: int | None = None
    total_episode_count: int | None = None
    missing_count: int | None = None
    total_missing_count: int | None = None
    stats_by_season: list[dict[str, Any]] = Field(default_factory=list)

    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ---------------------------------------------------- arr_explain_grab --


class _Verdict(BaseModel):
    """One annotated release from ``releases.explain()``."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    title: str | None = None
    indexer: str | None = None
    quality: str | None = None
    quality_weight: int | None = None
    custom_format_score: int | None = None
    size: int | None = None
    seeders: int | None = None
    age_hours: float | None = None
    languages: list[str] = Field(default_factory=list)
    release_group: str | None = None
    status: str | None = None
    rejections: list[str] = Field(default_factory=list)
    guid: str | None = None
    indexer_id: int | None = None


class ArrExplainGrabOut(BaseModel):
    """Output schema for :func:`arr_explain_grab`."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    error: Any = None

    item_id: int | None = None
    item_title: str | None = None
    current_quality: str | None = None
    current_custom_format_score: int | None = None
    summary: str | None = None
    advice: list[str] = Field(default_factory=list)
    verdicts: list[_Verdict] = Field(default_factory=list)

    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------- arr_find_release --


class _ReleaseCandidate(BaseModel):
    """Compact summary of one candidate release from ``arr_find_release``.

    Fields mirror the projection from
    :func:`arr_py_client.mcp.projection.project` with ``"summary"``.
    Extras pass through.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    title: str | None = None
    indexer: str | None = None
    indexer_id: int | None = None
    guid: str | None = None
    seeders: int | None = None
    leechers: int | None = None
    size: int | None = None
    quality: dict[str, Any] | None = None
    age_hours: float | None = None
    protocol: str | None = None


class ArrFindReleaseOut(BaseModel):
    """Output schema for :func:`arr_find_release`."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    error: Any = None

    candidates: list[_ReleaseCandidate] = Field(default_factory=list)
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------------------- arr_add --


class ArrAddOut(BaseModel):
    """Output schema for :func:`arr_add`.

    On success: ``ok=True`` + ``app`` chosen + the added resource's
    full payload under ``data``. On no-match across both lookups:
    ``ok=False`` + a human-readable ``error`` plus per-brand
    ``errors[]``.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    already_existed: bool | None = None
    data: dict[str, Any] | None = None

    error: Any = None
    errors: list[str] = Field(default_factory=list)

    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ------------------------------------------------------------- arr_upcoming --


class ArrUpcomingOut(BaseModel):
    """Output schema for :func:`arr_upcoming`.

    The ``data`` map holds per-brand calendar items keyed by ``radarr``
    / ``sonarr``. Each list element is a projected calendar entry —
    contents follow the brand's ``calendar`` resource model.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: dict[str, list[dict[str, Any]]] = Field(default_factory=dict)
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# --------------------------------------------------------- arr_grab_release --


class ArrGrabReleaseOut(BaseModel):
    """Output schema for :func:`arr_grab_release`.

    Lean envelope: the brand confirms the grab queued, surface tells
    the caller where to look next via ``_meta.action_hints``.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# -------------------------------------------------------- arr_cleanup_queue --


class ArrCleanupQueueOut(BaseModel):
    """Output schema for :func:`arr_cleanup_queue`.

    Mirrors :class:`NukeResult` from the queue resource: which queue ids
    were targeted, whether they were blocklisted, whether re-search
    fired, plus the dry-run flag for chat-safe runs.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    dry_run: bool = True
    ids: list[int] = Field(default_factory=list)
    count: int = 0
    blocklisted: bool | None = None
    redownload: bool | None = None
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ---------------------------------------------------------- arr_janitor_run --


class _JanitorMatch(BaseModel):
    """One match from the policy janitor run."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: int | None = None
    title: str | None = None
    policy: str | None = None
    action: str | None = None
    indexer: str | None = None


class ArrJanitorRunOut(BaseModel):
    """Output schema for :func:`arr_janitor_run`."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    dry_run: bool = True
    total_matches: int = 0
    protected_skips: int = 0
    executed_blocklist_ids: list[int] = Field(default_factory=list)
    executed_remove_ids: list[int] = Field(default_factory=list)
    matches: list[_JanitorMatch] = Field(default_factory=list)
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ------------------------------------------------------------- arr_backfill --


class ArrBackfillOut(BaseModel):
    """Output schema for :func:`arr_backfill`.

    ``stopped_reason`` is the StrEnum value (e.g. ``completed`` /
    ``queue_saturated`` / ``max_items_reached`` / ``dry_run``). The
    ``_meta.estimate`` block carries an ETA forecast — that's an extra
    field declared on :class:`ToolMeta` (``extra="allow"``) so it
    flows through unmodeled.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    source: str | None = None
    dry_run: bool = True
    searched_count: int = 0
    batches_sent: int = 0
    stopped_reason: str | None = None
    queue_checks: int = 0
    searched_ids: list[int] = Field(default_factory=list)
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------------- arr_sync_plan --


class _SyncChange(BaseModel):
    """One config-sync change as planned (no apply yet)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    resource: str | None = None
    name: str | None = None
    action: str | None = None  # create / update / delete
    existing_id: int | None = None
    detail: str | None = None


class ArrSyncPlanOut(BaseModel):
    """Output schema for :func:`arr_sync_plan`.

    A plan is purely descriptive — no state changes here. ``is_noop``
    short-circuits the next-step decision (``arr_health()`` vs.
    ``arr_sync_apply``).
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    strict: bool = False
    is_noop: bool = True
    summary: str | None = None
    changes: list[_SyncChange] = Field(default_factory=list)
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ---------------------------------------------------------- arr_sync_apply --


class _SyncApplied(BaseModel):
    """One successfully-applied change."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    resource: str | None = None
    name: str | None = None
    action: str | None = None


class _SyncError(BaseModel):
    """One change that failed during apply."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    resource: str | None = None
    name: str | None = None
    action: str | None = None
    error: Any = None


class ArrSyncApplyOut(BaseModel):
    """Output schema for :func:`arr_sync_apply`.

    ``ok=False`` when ``error_count > 0``. Per-change failures are
    captured in ``errors[]`` so the LLM can decide which to retry
    without re-planning.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    dry_run: bool = True
    summary: str | None = None
    applied_count: int = 0
    skipped_count: int = 0
    error_count: int = 0
    applied: list[_SyncApplied] = Field(default_factory=list)
    errors: list[_SyncError] = Field(default_factory=list)
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------------- arr_sync_dump --


class ArrSyncDumpOut(BaseModel):
    """Output schema for :func:`arr_sync_dump`.

    ``data`` is the full dumped state as a free-form dict (each top-level
    key is a config-sync resource id like ``custom_formats``,
    ``quality_profiles``). The ``_meta.resource_counts`` extra carries
    per-resource counts for quick scanning.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr", "prowlarr"] | None = None
    data: dict[str, Any] = Field(default_factory=dict)
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------------- arr_bulk_edit --


class ArrBulkEditOut(BaseModel):
    """Output schema for :func:`arr_bulk_edit`.

    Compact: ``ids`` are the items the call targeted, ``count`` is the
    cardinality. Error envelopes (``ok=False`` + ``error``) cover the
    "no ids" guard and provider failures.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    ids: list[int] = Field(default_factory=list)
    count: int = 0
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# --------------------------------------------------------- arr_trash_import --


class ArrTrashImportOut(BaseModel):
    """Output schema for :func:`arr_trash_import`.

    ``fetched_*`` counts reflect what came down from the TRaSH bundle;
    ``applied_count`` / ``error_count`` reflect what landed in the
    target Arr once dry_run flipped to ``False``.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    ref: str | None = None
    dry_run: bool = True
    fetched_custom_formats: int = 0
    fetched_release_profiles: int = 0
    fetched_quality_definitions: int = 0
    plan_summary: str | None = None
    applied_count: int = 0
    error_count: int = 0
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


# ----------------------------------------------------- arr_summarize_queue --


class _QueueStatusBucket(BaseModel):
    """Per-status counts derived from the raw queue listing."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    downloading: int = 0
    queued: int = 0
    completed: int = 0
    failed: int = 0
    warning: int = 0
    paused: int = 0
    delay: int = 0
    other: int = 0


class ArrSummarizeQueueOut(BaseModel):
    """Output schema for :func:`arr_summarize_queue`.

    Combines a server-computed status histogram (the deterministic part
    every client can rely on) with a client-LLM-generated narrative
    summary via MCP sampling. When the client doesn't support sampling
    the ``summary`` field is ``None`` — the histogram + ``stalled_ids``
    list is still useful on its own.
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    ok: bool = True
    app: Literal["radarr", "sonarr"] | None = None
    total: int = 0
    by_status: _QueueStatusBucket = Field(default_factory=_QueueStatusBucket)
    stalled_ids: list[int] = Field(default_factory=list)
    summary: str | None = None
    sampled: bool = False
    error: Any = None
    meta: ToolMeta = Field(default_factory=ToolMeta, alias="_meta")


__all__ = [
    "ArrAddOut",
    "ArrBackfillOut",
    "ArrBulkEditOut",
    "ArrCleanupQueueOut",
    "ArrExplainGrabOut",
    "ArrFindReleaseOut",
    "ArrGrabReleaseOut",
    "ArrHealthOut",
    "ArrJanitorRunOut",
    "ArrSummarizeQueueOut",
    "ArrSyncApplyOut",
    "ArrSyncDumpOut",
    "ArrSyncPlanOut",
    "ArrTitleStatusOut",
    "ArrTrashImportOut",
    "ArrUpcomingOut",
    "ToolMeta",
]
