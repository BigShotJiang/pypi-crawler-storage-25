"""Brand-neutral planner/applier for declarative config sync.

This module never imports from ``radarr.v3`` or ``sonarr.v3`` directly — it
relies on the duck-typed surface exposed by both curated clients:

- ``client.tags.list()`` -> list[TagResource]
- ``client.tags.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``
- ``client.custom_formats.list()`` -> list[CustomFormatResource]
- ``client.custom_formats.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``
- ``client.quality_profiles.list()`` -> list[QualityProfileResource]
- ``client.quality_profiles.create(body=...)``, ``.update(id=, body=)``, ``.delete(id=)``

The diff strategy is "explicitly-listed reconciles, not-listed stays" by
default. Passing ``strict=True`` adds DELETE actions for items present on
the server but missing from the config. Strict mode is destructive — callers
should always dry-run before applying.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Literal, cast

if TYPE_CHECKING:
    from collections.abc import Mapping, Sequence

Action = Literal["create", "update", "delete"]
Resource = Literal[
    "tags",
    "custom_formats",
    "quality_profiles",
    "quality_definitions",
    "root_folders",
    "download_clients",
    "indexers",
    "notifications",
    "naming",
    "media_management",
    "applications",
    "release_profiles",
    "auto_tagging",
]
SUPPORTED_RESOURCES: tuple[Resource, ...] = (
    "tags",
    "custom_formats",
    "quality_profiles",
    "quality_definitions",
    "root_folders",
    "download_clients",
    "indexers",
    "notifications",
    "naming",
    "media_management",
    "applications",
    "release_profiles",
    "auto_tagging",
)
# Singleton endpoints are GET + PUT only — no list, no id segment, no
# create/delete path. ``apply`` routes these directly to ``PUT <base_path>``.
_SINGLETON_RESOURCES: frozenset[Resource] = frozenset({"naming", "media_management"})


@dataclass(frozen=True)
class ConfigSyncPolicy:
    """Named bundle of :func:`plan` / :func:`apply` knobs.

    Use via :attr:`arr_py_client.POLICIES.config_sync` (``.conservative`` /
    ``.default`` / ``.aggressive``) and splat into the sync surface with
    :meth:`as_plan_kwargs` / :meth:`as_apply_kwargs`::

        pol = POLICIES.config_sync.aggressive
        plan_ = plan(client, desired, **pol.as_plan_kwargs())
        report = apply(client, plan_, **pol.as_apply_kwargs())

    Field names line up with the respective function signatures. Per-call
    kwargs always override policy values — write the splat first, then pass
    the per-call kwarg.
    """

    strict: bool = False
    include: tuple[Resource, ...] | None = None
    dry_run: bool = True

    def as_plan_kwargs(self) -> dict[str, Any]:
        """Render the :func:`plan`-relevant knobs (``strict``, ``include``)."""
        out: dict[str, Any] = {"strict": self.strict}
        if self.include is not None:
            out["include"] = list(self.include)
        return out

    def as_apply_kwargs(self) -> dict[str, Any]:
        """Render the :func:`apply`-relevant knobs (``dry_run``)."""
        return {"dry_run": self.dry_run}


@dataclass(frozen=True)
class SyncChange:
    """One planned change against one resource item (by ``name``)."""

    resource: Resource
    name: str
    action: Action
    # ``body`` is the pydantic body the applier will POST/PUT, or ``None`` for
    # deletes. ``detail`` is a short human string used by :meth:`SyncPlan.summary`.
    body: object | None = None
    detail: str = ""
    existing_id: int | None = None


@dataclass
class SyncPlan:
    """Ordered list of :class:`SyncChange` actions to reach the desired state."""

    changes: list[SyncChange] = field(default_factory=list)
    strict: bool = False

    @property
    def is_noop(self) -> bool:
        return not self.changes

    def by_action(self, action: Action) -> list[SyncChange]:
        return [c for c in self.changes if c.action == action]

    def summary(self) -> str:
        if self.is_noop:
            return "SyncPlan: no changes (already in desired state)."
        counts: dict[tuple[Resource, Action], int] = {}
        for c in self.changes:
            counts[(c.resource, c.action)] = counts.get((c.resource, c.action), 0) + 1
        parts = [
            f"{n}x {resource}.{action}"
            for (resource, action), n in sorted(counts.items())
        ]
        strict_suffix = " [strict]" if self.strict else ""
        return f"SyncPlan{strict_suffix}: " + ", ".join(parts)


@dataclass
class SyncReport:
    """What actually happened when :func:`apply` ran the plan."""

    applied: list[SyncChange] = field(default_factory=list)
    skipped: list[SyncChange] = field(default_factory=list)
    errors: list[tuple[SyncChange, str]] = field(default_factory=list)
    dry_run: bool = True


# ---------------------------------------------------------------------------
# Name-based indexing helpers
# ---------------------------------------------------------------------------


def _name_of(obj: object) -> str | None:
    n = getattr(obj, "name", None)
    return str(n) if n is not None else None


def _id_of(obj: object) -> int | None:
    value = getattr(obj, "id", None)
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _dump(obj: object) -> dict[str, Any]:
    """Best-effort pydantic-or-dict dump → dict (alias keys)."""
    if isinstance(obj, dict):
        return dict(cast("dict[str, Any]", obj))
    dump_fn = getattr(obj, "model_dump", None)
    if callable(dump_fn):
        result = cast("dict[str, Any]", dump_fn(by_alias=True, exclude_none=True))
        return dict(result)
    return dict(vars(obj))


def _merge(existing: object, desired: Mapping[str, Any]) -> dict[str, Any]:
    """Merge desired-keys over an existing-resource dump. ``id`` is preserved."""
    base = _dump(existing)
    base.update(dict(desired))
    eid = _id_of(existing)
    if eid is not None:
        base["id"] = eid
    return base


def _same(existing: object, desired: Mapping[str, Any]) -> bool:
    """Do the desired-keys already match what's on the server?

    Partial equality: only the keys in ``desired`` are compared against
    ``existing`` — keys not present in ``desired`` are not touched, so a sparse
    config doesn't generate spurious updates.
    """
    base = _dump(existing)
    for key, want in desired.items():
        have = base.get(key)
        if _normalize(have) != _normalize(want):
            return False
    return True


def _normalize(value: object) -> object:
    """Normalize so ``[a,b] == [b,a]`` when comparing unordered resource lists.

    For the config-sync use case we treat lists of dicts keyed by ``name`` as
    sets: order shouldn't cause false diffs on ``format_items`` and similar.
    """
    if not isinstance(value, list):
        return value
    items = cast("list[object]", value)
    if items and all(isinstance(x, dict) and "name" in x for x in items):
        dicts = cast("list[dict[str, Any]]", items)
        return sorted(dicts, key=lambda x: str(x["name"]))
    return items


# ---------------------------------------------------------------------------
# Resource-specific planners
# ---------------------------------------------------------------------------


def _plan_tags(
    client: Any,
    desired: Sequence[str] | Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Tags are names-only. Accepts either ``["anime","4k"]`` or mapping form."""
    desired_names: list[str] = [
        t if isinstance(t, str) else str(t.get("label") or t.get("name") or "")
        for t in desired
    ]
    existing_raw = cast("list[object]", list(client.tags.list()))
    existing: dict[str, object] = {}
    for item in existing_raw:
        label = getattr(item, "label", None) or getattr(item, "name", None)
        if label:
            existing[str(label)] = item

    changes: list[SyncChange] = []
    for name in desired_names:
        if not name or name in existing:
            continue
        changes.append(
            SyncChange(
                resource="tags",
                name=name,
                action="create",
                body={"label": name},
                detail=f"create tag '{name}'",
            )
        )
    if strict:
        want = {n for n in desired_names if n}
        for name, item in existing.items():
            if name not in want:
                changes.append(
                    SyncChange(
                        resource="tags",
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete tag '{name}'",
                    )
                )
    return changes


def _plan_root_folders(
    existing: Sequence[object],
    desired: Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Root folders are keyed by absolute ``path``, not by ``name``.

    Each desired entry is either a string path or a mapping with a ``path``
    key. Creating a root folder requires the directory to already exist on
    the server filesystem — the server rejects unknown paths. Apply errors
    end up in ``SyncReport.errors`` so one missing directory doesn't block
    other changes.
    """
    existing_by_path: dict[str, object] = {}
    for item in existing:
        path = getattr(item, "path", None)
        if path is not None:
            existing_by_path[str(path)] = item

    changes: list[SyncChange] = []
    desired_paths: set[str] = set()
    for spec in desired:
        path = str(spec.get("path") or "")
        if not path:
            continue
        desired_paths.add(path)
        match = existing_by_path.get(path)
        payload = dict(spec)
        if match is None:
            changes.append(
                SyncChange(
                    resource="root_folders",
                    name=path,
                    action="create",
                    body=payload,
                    detail=f"create root folder '{path}'",
                )
            )
    if strict:
        for path, item in existing_by_path.items():
            if path not in desired_paths:
                changes.append(
                    SyncChange(
                        resource="root_folders",
                        name=path,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete root folder '{path}'",
                    )
                )
    return changes


def _plan_singleton(
    resource: Resource,
    existing: object,
    desired: Mapping[str, Any],
) -> list[SyncChange]:
    """Singleton endpoints — one object, GET/PUT, no id needed.

    Emits at most one ``update`` change, with body merged over the existing
    config. ``apply`` special-cases singleton paths to PUT without an id.
    Shared by ``naming`` and ``media_management``; both follow the same
    upstream shape (single resource at a fixed path).
    """
    if _same(existing, desired):
        return []
    merged = _merge(existing, desired)
    return [
        SyncChange(
            resource=resource,
            name=resource,
            action="update",
            body=merged,
            detail=f"update {resource} config",
            existing_id=_id_of(existing),
        )
    ]


def _plan_resource_by_name(
    *,
    resource: Resource,
    existing: Sequence[object],
    desired_by_name: Mapping[str, Mapping[str, Any]],
    strict: bool,
) -> list[SyncChange]:
    """Generic name-keyed reconciler for resources that share ``{id, name, ...}``."""
    existing_by_name: dict[str, object] = {}
    for item in existing:
        name = _name_of(item)
        if name is not None:
            existing_by_name[name] = item

    changes: list[SyncChange] = []
    for name, spec in desired_by_name.items():
        payload = dict(spec)
        payload.setdefault("name", name)
        match = existing_by_name.get(name)
        if match is None:
            changes.append(
                SyncChange(
                    resource=resource,
                    name=name,
                    action="create",
                    body=payload,
                    detail=f"create {resource} '{name}'",
                )
            )
            continue
        if _same(match, payload):
            continue
        changes.append(
            SyncChange(
                resource=resource,
                name=name,
                action="update",
                body=_merge(match, payload),
                detail=f"update {resource} '{name}'",
                existing_id=_id_of(match),
            )
        )
    if strict:
        for name, item in existing_by_name.items():
            if name not in desired_by_name:
                changes.append(
                    SyncChange(
                        resource=resource,
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete {resource} '{name}'",
                    )
                )
    return changes


def _quality_name(item: object) -> str | None:
    """Return the quality name for a QualityDefinition (``quality.name`` or ``title``).

    Server-side QualityDefinitionResources are keyed by ``quality.name`` (the
    stable identifier like ``"Bluray-2160p"``). ``title`` is the editable
    human label and usually matches but can drift, so we prefer
    ``quality.name`` and fall back to ``title``.
    """
    quality = getattr(item, "quality", None)
    if quality is not None:
        name = getattr(quality, "name", None)
        if name is not None:
            return str(name)
    title = getattr(item, "title", None)
    return str(title) if title is not None else None


def _plan_quality_definitions(
    existing: Sequence[object],
    desired_by_name: Mapping[str, Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Quality definitions are UPDATE-only — server seeds them at install time.

    Unlike other name-keyed resources, you can't create or delete quality
    definitions via the API. So ``strict=True`` doesn't emit deletes, and
    items present in ``desired`` but absent on the server are reported as
    errors (typo in the quality name).
    """
    existing_by_name: dict[str, object] = {}
    for item in existing:
        name = _quality_name(item)
        if name is not None:
            existing_by_name[name] = item

    changes: list[SyncChange] = []
    for name, spec in desired_by_name.items():
        payload = dict(spec)
        # The loader pivots list-form YAML into ``{name: {name: ..., ...}}``,
        # but QualityDefinitionResource has no top-level ``name`` field
        # (extra="forbid" would reject it). Drop the pivot key.
        payload.pop("name", None)
        match = existing_by_name.get(name)
        if match is None:
            # No create path — surface the mismatch in the plan so the caller
            # sees it. ``apply`` will see existing_id=None and error out.
            changes.append(
                SyncChange(
                    resource="quality_definitions",
                    name=name,
                    action="update",
                    body=payload,
                    detail=f"quality '{name}' not found on server",
                )
            )
            continue
        if _same(match, payload):
            continue
        merged = _merge(match, payload)
        # Same rationale as above — scrub any ``name`` key that snuck in via
        # the pydantic dump of the existing item.
        merged.pop("name", None)
        changes.append(
            SyncChange(
                resource="quality_definitions",
                name=name,
                action="update",
                body=merged,
                detail=f"update quality_definitions '{name}'",
                existing_id=_id_of(match),
            )
        )
    _ = strict  # quality_definitions are PUT-only; strict doesn't add deletes
    return changes


async def _plan_tags_async(
    client: Any,
    desired: Sequence[str] | Sequence[Mapping[str, Any]],
    *,
    strict: bool,
) -> list[SyncChange]:
    """Async twin of :func:`_plan_tags`."""
    desired_names: list[str] = [
        t if isinstance(t, str) else str(t.get("label") or t.get("name") or "")
        for t in desired
    ]
    raw = await client.tags.list()
    existing_raw = cast("list[object]", list(raw))
    existing: dict[str, object] = {}
    for item in existing_raw:
        label = getattr(item, "label", None) or getattr(item, "name", None)
        if label:
            existing[str(label)] = item

    changes: list[SyncChange] = []
    for name in desired_names:
        if not name or name in existing:
            continue
        changes.append(
            SyncChange(
                resource="tags",
                name=name,
                action="create",
                body={"label": name},
                detail=f"create tag '{name}'",
            )
        )
    if strict:
        want = {n for n in desired_names if n}
        for name, item in existing.items():
            if name not in want:
                changes.append(
                    SyncChange(
                        resource="tags",
                        name=name,
                        action="delete",
                        existing_id=_id_of(item),
                        detail=f"delete tag '{name}'",
                    )
                )
    return changes


def plan(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
    include: Sequence[Resource] | None = None,
) -> SyncPlan:
    """Diff ``desired`` against the live server. Returns a :class:`SyncPlan`.

    ``desired`` shape (all keys optional)::

        {
            "tags": ["anime", "4k-only"],
            "custom_formats": {
                "HDR10+": {"specifications": [...]},
            },
            "quality_profiles": {
                "Best Movies": {
                    "upgradeAllowed": True,
                    "cutoff": 2160,
                    "formatItems": [{"name": "HDR10+", "score": 300}],
                },
            },
        }

    ``strict=True`` emits DELETE actions for items on the server but not in
    ``desired``. ``include`` narrows the scope (defaults to every supported
    resource).
    """
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: list[SyncChange] = []

    if "tags" in scope and "tags" in desired and hasattr(client, "tags"):
        out.extend(_plan_tags(client, desired["tags"], strict=strict))

    if (
        "custom_formats" in scope
        and "custom_formats" in desired
        and hasattr(client, "custom_formats")
    ):
        desired_cf: Mapping[str, Mapping[str, Any]] = desired["custom_formats"]
        existing_cf = cast("list[object]", list(client.custom_formats.list()))
        out.extend(
            _plan_resource_by_name(
                resource="custom_formats",
                existing=existing_cf,
                desired_by_name=desired_cf,
                strict=strict,
            )
        )

    if (
        "quality_profiles" in scope
        and "quality_profiles" in desired
        and hasattr(client, "quality_profiles")
    ):
        desired_qp: Mapping[str, Mapping[str, Any]] = desired["quality_profiles"]
        existing_qp = cast("list[object]", list(client.quality_profiles.list()))
        out.extend(
            _plan_resource_by_name(
                resource="quality_profiles",
                existing=existing_qp,
                desired_by_name=desired_qp,
                strict=strict,
            )
        )

    if (
        "quality_definitions" in scope
        and "quality_definitions" in desired
        and hasattr(client, "quality_definition")
    ):
        desired_qd: Mapping[str, Mapping[str, Any]] = desired["quality_definitions"]
        existing_qd = cast("list[object]", list(client.quality_definition.list_()))
        out.extend(
            _plan_quality_definitions(
                existing=existing_qd,
                desired_by_name=desired_qd,
                strict=strict,
            )
        )

    if (
        "root_folders" in scope
        and "root_folders" in desired
        and hasattr(client, "root_folders")
    ):
        existing_rf = cast("list[object]", list(client.root_folders.list()))
        out.extend(
            _plan_root_folders(
                existing=existing_rf,
                desired=desired["root_folders"],
                strict=strict,
            )
        )

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and key in desired and hasattr(client, key):
            desired_map: Mapping[str, Mapping[str, Any]] = desired[key]
            existing_items = cast("list[object]", list(getattr(client, key).list()))
            out.extend(
                _plan_resource_by_name(
                    resource=cast("Resource", key),
                    existing=existing_items,
                    desired_by_name=desired_map,
                    strict=strict,
                )
            )

    for singleton in ("naming", "media_management"):
        if (
            singleton in scope
            and singleton in desired
            and hasattr(client, "custom_formats")  # Prowlarr has neither endpoint
        ):
            existing_s = client.transport.request(
                "GET", _PATH_BY_RESOURCE[cast("Resource", singleton)]
            ).json()
            out.extend(
                _plan_singleton(
                    cast("Resource", singleton), existing_s, desired[singleton]
                )
            )

    return SyncPlan(changes=out, strict=strict)


# ---------------------------------------------------------------------------
# Apply
# ---------------------------------------------------------------------------


_PATH_BY_RESOURCE: dict[Resource, str] = {
    "tags": "/tag",
    "custom_formats": "/customformat",
    "quality_profiles": "/qualityprofile",
    "quality_definitions": "/qualitydefinition",
    "root_folders": "/rootfolder",
    "download_clients": "/downloadclient",
    "indexers": "/indexer",
    "notifications": "/notification",
    "naming": "/config/naming",
    "media_management": "/config/mediamanagement",
    "applications": "/applications",
    "release_profiles": "/releaseprofile",
    "auto_tagging": "/autotagging",
}


def apply(
    client: Any,
    plan_: SyncPlan,
    *,
    dry_run: bool = True,
    journal: Any | None = None,
) -> SyncReport:
    """Execute (or ``dry_run``) a :class:`SyncPlan` against the live server.

    Each change is tried independently; errors are captured in the report so
    one broken change doesn't block the others. HTTP calls go through the
    client's :attr:`transport` directly — we bypass the typed facade so the
    config-sync layer stays brand-neutral and accepts raw dicts.

    Pass ``journal=`` to opt into persistent audit logging (see
    :class:`arr_py_client.journal.Journal`). A single summary entry is
    appended after the apply loop finishes; ``dry_run`` calls are not
    journaled.
    """
    report = SyncReport(dry_run=dry_run)
    if dry_run:
        report.skipped = list(plan_.changes)
        return report

    transport = client.transport
    for change in plan_.changes:
        base_path = _PATH_BY_RESOURCE.get(change.resource)
        if base_path is None:
            report.errors.append((change, f"unknown resource: {change.resource}"))
            continue
        try:
            if change.resource in _SINGLETON_RESOURCES:
                # Singleton endpoint — no id segment, no create/delete.
                transport.request("PUT", base_path, json=change.body)
            elif change.action == "create":
                transport.request("POST", base_path, json=change.body)
            elif change.action == "update":
                if change.existing_id is None:
                    msg = "update change missing existing_id"
                    raise ValueError(msg)
                transport.request(
                    "PUT",
                    f"{base_path}/{change.existing_id}",
                    json=change.body,
                )
            elif change.action == "delete":
                if change.existing_id is None:
                    msg = "delete change missing existing_id"
                    raise ValueError(msg)
                transport.request("DELETE", f"{base_path}/{change.existing_id}")
            report.applied.append(change)
        except Exception as exc:
            report.errors.append((change, str(exc)))
    if journal is not None:
        journal.append(
            "config_sync.apply",
            ok=not report.errors,
            details={
                "applied_count": len(report.applied),
                "error_count": len(report.errors),
                "applied": [
                    {"resource": c.resource, "name": c.name, "action": c.action}
                    for c in report.applied
                ],
                "errors": [
                    {"resource": c.resource, "name": c.name, "error": err}
                    for c, err in report.errors
                ],
                "strict": plan_.strict,
            },
        )
    return report


# ---------------------------------------------------------------------------
# Async twins — mirror ``plan`` / ``apply`` for ``AsyncRadarrClient`` /
# ``AsyncSonarrClient``. Kept as a separate surface so sync callers don't pay
# an anyio/asyncio import cost.
# ---------------------------------------------------------------------------


async def plan_async(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
    include: Sequence[Resource] | None = None,
) -> SyncPlan:
    """Async twin of :func:`plan`."""
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: list[SyncChange] = []

    if "tags" in scope and "tags" in desired and hasattr(client, "tags"):
        out.extend(await _plan_tags_async(client, desired["tags"], strict=strict))

    if (
        "custom_formats" in scope
        and "custom_formats" in desired
        and hasattr(client, "custom_formats")
    ):
        desired_cf: Mapping[str, Mapping[str, Any]] = desired["custom_formats"]
        raw_cf = await client.custom_formats.list()
        existing_cf = cast("list[object]", list(raw_cf))
        out.extend(
            _plan_resource_by_name(
                resource="custom_formats",
                existing=existing_cf,
                desired_by_name=desired_cf,
                strict=strict,
            )
        )

    if (
        "quality_profiles" in scope
        and "quality_profiles" in desired
        and hasattr(client, "quality_profiles")
    ):
        desired_qp: Mapping[str, Mapping[str, Any]] = desired["quality_profiles"]
        raw_qp = await client.quality_profiles.list()
        existing_qp = cast("list[object]", list(raw_qp))
        out.extend(
            _plan_resource_by_name(
                resource="quality_profiles",
                existing=existing_qp,
                desired_by_name=desired_qp,
                strict=strict,
            )
        )

    if (
        "quality_definitions" in scope
        and "quality_definitions" in desired
        and hasattr(client, "quality_definition")
    ):
        desired_qd_a: Mapping[str, Mapping[str, Any]] = desired["quality_definitions"]
        raw_qd = await client.quality_definition.list_()
        out.extend(
            _plan_quality_definitions(
                existing=cast("list[object]", list(raw_qd)),
                desired_by_name=desired_qd_a,
                strict=strict,
            )
        )

    if (
        "root_folders" in scope
        and "root_folders" in desired
        and hasattr(client, "root_folders")
    ):
        raw_rf = await client.root_folders.list()
        out.extend(
            _plan_root_folders(
                existing=cast("list[object]", list(raw_rf)),
                desired=desired["root_folders"],
                strict=strict,
            )
        )

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and key in desired and hasattr(client, key):
            desired_map_a: Mapping[str, Mapping[str, Any]] = desired[key]
            raw_items = await getattr(client, key).list()
            out.extend(
                _plan_resource_by_name(
                    resource=cast("Resource", key),
                    existing=cast("list[object]", list(raw_items)),
                    desired_by_name=desired_map_a,
                    strict=strict,
                )
            )

    for singleton in ("naming", "media_management"):
        if (
            singleton in scope
            and singleton in desired
            and hasattr(client, "custom_formats")  # Prowlarr has neither endpoint
        ):
            resp = await client.transport.request(
                "GET", _PATH_BY_RESOURCE[cast("Resource", singleton)]
            )
            existing_s = resp.json()
            out.extend(
                _plan_singleton(
                    cast("Resource", singleton), existing_s, desired[singleton]
                )
            )

    return SyncPlan(changes=out, strict=strict)


async def apply_async(
    client: Any,
    plan_: SyncPlan,
    *,
    dry_run: bool = True,
    journal: Any | None = None,
) -> SyncReport:
    """Async twin of :func:`apply`."""
    report = SyncReport(dry_run=dry_run)
    if dry_run:
        report.skipped = list(plan_.changes)
        return report

    transport = client.transport
    for change in plan_.changes:
        base_path = _PATH_BY_RESOURCE.get(change.resource)
        if base_path is None:
            report.errors.append((change, f"unknown resource: {change.resource}"))
            continue
        try:
            if change.resource in _SINGLETON_RESOURCES:
                await transport.request("PUT", base_path, json=change.body)
            elif change.action == "create":
                await transport.request("POST", base_path, json=change.body)
            elif change.action == "update":
                if change.existing_id is None:
                    msg = "update change missing existing_id"
                    raise ValueError(msg)
                await transport.request(
                    "PUT",
                    f"{base_path}/{change.existing_id}",
                    json=change.body,
                )
            elif change.action == "delete":
                if change.existing_id is None:
                    msg = "delete change missing existing_id"
                    raise ValueError(msg)
                await transport.request("DELETE", f"{base_path}/{change.existing_id}")
            report.applied.append(change)
        except Exception as exc:
            report.errors.append((change, str(exc)))
    if journal is not None:
        journal.append(
            "config_sync.apply",
            ok=not report.errors,
            details={
                "applied_count": len(report.applied),
                "error_count": len(report.errors),
                "applied": [
                    {"resource": c.resource, "name": c.name, "action": c.action}
                    for c in report.applied
                ],
                "errors": [
                    {"resource": c.resource, "name": c.name, "error": err}
                    for c, err in report.errors
                ],
                "strict": plan_.strict,
            },
        )
    return report


# ---------------------------------------------------------------------------
# Dump + diff
# ---------------------------------------------------------------------------


# Fields that are server-side metadata and should be stripped from a dumped
# resource body so the output round-trips cleanly through :func:`plan`.
_STRIP_FIELDS: frozenset[str] = frozenset(
    {
        "id",
        # `_meta.lastExecution` / `lastExecutionTime` style fields on
        # notifications/indexers that describe server state, not config.
        "lastExecution",
        "lastExecutionTime",
        "lastTestedDate",
    }
)


def _dump_body(obj: object) -> dict[str, Any]:
    """Dump one resource for the sync surface (strip server metadata)."""
    body = _dump(obj)
    for field_name in _STRIP_FIELDS:
        body.pop(field_name, None)
    return body


def _dump_name_keyed(items: Sequence[object]) -> dict[str, dict[str, Any]]:
    """Map each item to ``{name: body}`` with server metadata stripped."""
    out: dict[str, dict[str, Any]] = {}
    for item in items:
        name = _name_of(item)
        if name is None:
            continue
        out[name] = _dump_body(item)
    return out


_QD_EDITABLE_FIELDS: frozenset[str] = frozenset(
    {"minSize", "maxSize", "preferredSize", "title", "weight"}
)


def _dump_quality_definitions(items: Sequence[object]) -> dict[str, dict[str, Any]]:
    """Key each QualityDefinition by ``quality.name`` with only editable fields.

    The bulk of a QD payload is server-managed (the nested ``quality`` Quality
    object with id/source/resolution/modifier). Emitting only the editable
    fields keeps dumped configs short and portable across instances.
    """
    out: dict[str, dict[str, Any]] = {}
    for item in items:
        name = _quality_name(item)
        if name is None:
            continue
        body = _dump(item)
        trimmed: dict[str, Any] = {
            k: v for k, v in body.items() if k in _QD_EDITABLE_FIELDS
        }
        if trimmed:
            out[name] = trimmed
    return out


def dump(
    client: Any,
    *,
    include: Sequence[Resource] | None = None,
) -> dict[str, Any]:
    """Serialize live server state into the dict shape :func:`plan` consumes.

    Round-trip pattern::

        desired = dump(client)
        assert plan(client, desired).is_noop  # nothing to change

    Useful for bootstrapping a ``config.yaml`` from a prod server: edit to
    taste, then ``yaml.safe_dump(dump(client))``. Resources the client
    doesn't expose are silently skipped, so one ``dump()`` call can target
    Radarr, Sonarr, or Prowlarr interchangeably.

    ``id`` and a few server-metadata fields are stripped from bodies so the
    output is portable across instances.
    """
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: dict[str, Any] = {}

    if "tags" in scope and hasattr(client, "tags"):
        existing_tags = cast("list[object]", list(client.tags.list()))
        labels: list[str] = []
        for t in existing_tags:
            label = getattr(t, "label", None) or getattr(t, "name", None)
            if label:
                labels.append(str(label))
        if labels:
            out["tags"] = labels

    for key in ("custom_formats", "quality_profiles"):
        if key in scope and hasattr(client, key):
            items = cast("list[object]", list(getattr(client, key).list()))
            mapped = _dump_name_keyed(items)
            if mapped:
                out[key] = mapped

    if "quality_definitions" in scope and hasattr(client, "quality_definition"):
        existing_qd = cast("list[object]", list(client.quality_definition.list_()))
        qd_mapped = _dump_quality_definitions(existing_qd)
        if qd_mapped:
            out["quality_definitions"] = qd_mapped

    if "root_folders" in scope and hasattr(client, "root_folders"):
        existing_rf = cast("list[object]", list(client.root_folders.list()))
        paths: list[dict[str, Any]] = []
        for item in existing_rf:
            path = getattr(item, "path", None)
            if path is not None:
                paths.append({"path": str(path)})
        if paths:
            out["root_folders"] = paths

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and hasattr(client, key):
            items = cast("list[object]", list(getattr(client, key).list()))
            mapped = _dump_name_keyed(items)
            if mapped:
                out[key] = mapped

    for singleton in ("naming", "media_management"):
        if (
            singleton in scope
            and hasattr(client, "transport")
            and hasattr(client, "custom_formats")  # Prowlarr has neither endpoint
        ):
            raw = client.transport.request(
                "GET", _PATH_BY_RESOURCE[cast("Resource", singleton)]
            ).json()
            if isinstance(raw, dict):
                body = dict(cast("dict[str, Any]", raw))
                for f in _STRIP_FIELDS:
                    body.pop(f, None)
                if body:
                    out[singleton] = body

    return out


def diff(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
) -> str:
    """Plain-text summary of the plan: one line per change with +/~/- prefix.

    Not a unified diff — it's a human-readable audit log, suitable for CLI,
    chat, or review. For structured access use :func:`plan` and inspect
    ``plan_.changes`` directly.
    """
    plan_ = plan(client, desired, strict=strict)
    prefix = {"create": "+", "update": "~", "delete": "-"}
    lines = [plan_.summary()]
    for change in plan_.changes:
        lines.append(
            f"  {prefix[change.action]} {change.resource}.{change.name}  — {change.detail}"
        )
    return "\n".join(lines)


async def dump_async(
    client: Any,
    *,
    include: Sequence[Resource] | None = None,
) -> dict[str, Any]:
    """Async twin of :func:`dump`."""
    scope: Sequence[Resource] = include if include is not None else SUPPORTED_RESOURCES
    out: dict[str, Any] = {}

    if "tags" in scope and hasattr(client, "tags"):
        raw = await client.tags.list()
        labels: list[str] = []
        for t in cast("list[object]", list(raw)):
            label = getattr(t, "label", None) or getattr(t, "name", None)
            if label:
                labels.append(str(label))
        if labels:
            out["tags"] = labels

    for key in ("custom_formats", "quality_profiles"):
        if key in scope and hasattr(client, key):
            raw = await getattr(client, key).list()
            mapped = _dump_name_keyed(cast("list[object]", list(raw)))
            if mapped:
                out[key] = mapped

    if "quality_definitions" in scope and hasattr(client, "quality_definition"):
        raw_qd = await client.quality_definition.list_()
        qd_mapped = _dump_quality_definitions(cast("list[object]", list(raw_qd)))
        if qd_mapped:
            out["quality_definitions"] = qd_mapped

    if "root_folders" in scope and hasattr(client, "root_folders"):
        raw_rf = await client.root_folders.list()
        paths: list[dict[str, Any]] = []
        for item in cast("list[object]", list(raw_rf)):
            path = getattr(item, "path", None)
            if path is not None:
                paths.append({"path": str(path)})
        if paths:
            out["root_folders"] = paths

    for key in (
        "download_clients",
        "indexers",
        "notifications",
        "applications",
        "release_profiles",
        "auto_tagging",
    ):
        if key in scope and hasattr(client, key):
            raw = await getattr(client, key).list()
            mapped = _dump_name_keyed(cast("list[object]", list(raw)))
            if mapped:
                out[key] = mapped

    for singleton in ("naming", "media_management"):
        if (
            singleton in scope
            and hasattr(client, "transport")
            and hasattr(client, "custom_formats")  # Prowlarr has neither endpoint
        ):
            resp = await client.transport.request(
                "GET", _PATH_BY_RESOURCE[cast("Resource", singleton)]
            )
            raw = resp.json()
            if isinstance(raw, dict):
                body = dict(cast("dict[str, Any]", raw))
                for f in _STRIP_FIELDS:
                    body.pop(f, None)
                if body:
                    out[singleton] = body

    return out


async def diff_async(
    client: Any,
    desired: Mapping[str, Any],
    *,
    strict: bool = False,
) -> str:
    """Async twin of :func:`diff`."""
    plan_ = await plan_async(client, desired, strict=strict)
    prefix = {"create": "+", "update": "~", "delete": "-"}
    lines = [plan_.summary()]
    for change in plan_.changes:
        lines.append(
            f"  {prefix[change.action]} {change.resource}.{change.name}  — {change.detail}"
        )
    return "\n".join(lines)
