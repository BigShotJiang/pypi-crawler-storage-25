from setuptools import setup, find_packages

setup(
    name='proly',
    version='1.0.1',
    description='Proly Agent SDK — build marketplace agents that call platform tools securely from E2B sandboxes',
    long_description=open('README.md').read() if __import__('os').path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://proly.co.uk/developers',
    project_urls={
        'Source': 'https://github.com/proly/proly-runtime/tree/main/pkg/sdk/python',
    },
    packages=find_packages(),
    python_requires='>=3.10',
    license='MIT',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
)
