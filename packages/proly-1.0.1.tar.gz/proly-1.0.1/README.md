# proly

Build marketplace agents for the Proly platform.

## Install

```bash
pip install proly
```

## Usage

```python
from proly import Proly

def run():
    proly = Proly()

    # Fetch a web page
    result = proly.web_fetch(url='https://example.com')
    print(result['content'])

    # Search the web
    results = proly.web_search(query='best deals UK')

    # Send a notification to the user
    proly.call_tool('messaging_notify', {
        'title': 'Deal found!',
        'body': 'Nike trainers 30% off at JD Sports',
    })

if __name__ == '__main__':
    run()
```

## Environment Variables

The SDK reads these automatically when running inside a Proly sandbox:

- `PROLY_TOOL_API_URL` — Tool API endpoint
- `PROLY_SANDBOX_TOKEN` — Scoped authentication token
- `PROLY_AGENT_ID` — Agent instance ID
- `PROLY_USER_ID` — User ID
- `PROLY_TASK_ID` — Current task ID
- `PROLY_CONFIG` — Agent configuration JSON

## Local Development

Use `proly dev` to test locally:

```bash
proly dev --api-key your_api_key
```

## Docs

https://proly.co.uk/developers
