"""
Proly SDK for marketplace agent developers.

Usage:
    from proly import Proly

    platform = Proly()
    emails = platform.read_emails(unread_only=True)

The SDK reads environment variables injected by the Proly runtime
automatically. Developer code never manages tokens or URLs directly.
"""

import json
import os
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

__version__ = "0.1.0"
__all__ = ["Proly"]


class Proly:
    """Client for the Proly Tool API.

    Reads connection details from environment variables injected by the
    runtime into E2B sandboxes. Does NOT raise if env vars are missing;
    fails gracefully on the first tool call with a clear error message.
    """

    def __init__(self):
        self._tool_api_url = os.environ.get("PROLY_TOOL_API_URL")
        self._token = os.environ.get("PROLY_SANDBOX_TOKEN")
        self._agent_id = os.environ.get("PROLY_AGENT_ID")
        self._user_id = os.environ.get("PROLY_USER_ID")
        self._task_id = os.environ.get("PROLY_TASK_ID")
        self._goal = os.environ.get("PROLY_GOAL")

        config_raw = os.environ.get("PROLY_CONFIG", "{}")
        try:
            self._config = json.loads(config_raw)
        except (json.JSONDecodeError, TypeError):
            self._config = {}

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def agent_id(self):
        """The agent UUID, or None if not set."""
        return self._agent_id

    @property
    def user_id(self):
        """The user UUID, or None if not set."""
        return self._user_id

    @property
    def task_id(self):
        """The task UUID, or None if not set."""
        return self._task_id

    @property
    def goal(self):
        """The task goal string, or None if not set."""
        return self._goal

    @property
    def config(self):
        """User-provided agent configuration dict."""
        return self._config

    # ------------------------------------------------------------------
    # Core tool execution
    # ------------------------------------------------------------------

    def call_tool(self, tool_name, input_data=None):
        """Execute any platform tool by name.

        Args:
            tool_name: The tool identifier (e.g. 'email_read', 'web_search').
            input_data: Tool-specific input parameters as a dict.

        Returns:
            The tool's output payload (parsed from JSON).

        Raises:
            RuntimeError: If env vars are missing, the request fails, or
                the Tool API returns an error.
        """
        if input_data is None:
            input_data = {}

        if not self._tool_api_url:
            raise RuntimeError(
                "Proly SDK: PROLY_TOOL_API_URL is not set. "
                "This SDK must run inside a Proly sandbox."
            )
        if not self._token:
            raise RuntimeError(
                "Proly SDK: PROLY_SANDBOX_TOKEN is not set. "
                "This SDK must run inside a Proly sandbox."
            )

        url = self._tool_api_url.rstrip("/") + "/tools/execute"
        payload = json.dumps({"tool": tool_name, "input": input_data}).encode("utf-8")

        req = Request(
            url,
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": "Bearer " + self._token,
            },
            method="POST",
        )

        try:
            with urlopen(req) as resp:
                body = resp.read().decode("utf-8")
        except HTTPError as exc:
            # The Tool API returns JSON error bodies on 4xx/5xx
            try:
                body = exc.read().decode("utf-8")
            except Exception:
                raise RuntimeError(
                    "Proly SDK: Tool API returned HTTP %d for tool '%s'"
                    % (exc.code, tool_name)
                ) from exc
        except URLError as exc:
            raise RuntimeError(
                "Proly SDK: failed to reach Tool API at %s: %s"
                % (url, exc.reason)
            ) from exc

        try:
            data = json.loads(body)
        except (json.JSONDecodeError, TypeError) as exc:
            raise RuntimeError(
                "Proly SDK: Tool API returned non-JSON response"
            ) from exc

        if not data.get("success"):
            error_msg = data.get("error", "unknown error")
            raise RuntimeError(
                "Proly SDK: tool '%s' failed: %s" % (tool_name, error_msg)
            )

        return data.get("output")

    # ------------------------------------------------------------------
    # Convenience methods
    # ------------------------------------------------------------------

    def read_emails(self, **options):
        """Read emails from the user's inbox.

        Keyword Args:
            unread_only (bool): Only return unread emails.
            max_results (int): Maximum number of emails to return.
            labels (list): Gmail labels to filter by.
        """
        return self.call_tool("email_read", options)

    def send_email(self, to, subject, body, **options):
        """Send an email.

        Args:
            to: Recipient email address.
            subject: Email subject line.
            body: Email body (plain text or HTML).

        Keyword Args:
            cc (str): CC recipients.
            bcc (str): BCC recipients.
            reply_to (str): Message ID to reply to.
        """
        return self.call_tool("email_send", {"to": to, "subject": subject, "body": body, **options})

    def delete_email(self, message_id, **options):
        """Delete an email by message ID.

        Args:
            message_id: The email message ID to delete.
        """
        return self.call_tool("email_delete", {"message_id": message_id, **options})

    def read_calendar(self, **options):
        """Read calendar events.

        Keyword Args:
            start_date (str): Start of date range (e.g. '2026-03-25').
            end_date (str): End of date range.
            max_results (int): Maximum number of events to return.
        """
        return self.call_tool("calendar_read", options)

    def create_event(self, title, date, start_time, **options):
        """Create a calendar event.

        Args:
            title: Event title.
            date: Event date (e.g. '2026-03-25').
            start_time: Start time (e.g. '09:00').

        Keyword Args:
            end_time (str): End time.
            description (str): Event description.
            location (str): Event location.
        """
        return self.call_tool("calendar_write", {
            "title": title, "date": date, "start_time": start_time, **options
        })

    def send_whatsapp(self, to, message):
        """Send a WhatsApp message.

        Args:
            to: Recipient phone number (with country code, e.g. '+447700900000').
            message: Message text.
        """
        return self.call_tool("whatsapp_send", {"to": to, "message": message})

    def web_search(self, query, **options):
        """Perform a web search.

        Args:
            query: Search query string.

        Keyword Args:
            max_results (int): Maximum number of results to return.
        """
        return self.call_tool("web_search", {"query": query, **options})

    def use_browser(self, action, **options):
        """Interact with a cloud browser session.

        Args:
            action: Browser action ('navigate', 'click', 'fill', 'read', 'screenshot').

        Keyword Args:
            Varies by action (e.g. url, selector, text).
        """
        return self.call_tool("browser_use", {"action": action, **options})

    def http_fetch(self, url, **options):
        """Fetch a URL via HTTP.

        Args:
            url: The URL to fetch.

        Keyword Args:
            method (str): HTTP method (default 'GET').
            headers (dict): Request headers.
            body (str): Request body.
        """
        return self.call_tool("http_fetch", {"url": url, **options})
