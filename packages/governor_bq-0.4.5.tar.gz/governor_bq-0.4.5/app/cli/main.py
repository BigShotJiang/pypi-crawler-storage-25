"""Governor CLI — developer onboarding and instance management."""

from __future__ import annotations

import os
import signal
import socket
import sys
import time
from typing import Optional

import typer
from sqlalchemy.exc import SQLAlchemyError

from app.cli import config as cli_config
from app.cli import display

app = typer.Typer(
    name="governor",
    help="Governor — BigQuery Cost Optimizer",
    no_args_is_help=True,
    add_completion=False,
)

auth_app = typer.Typer(help="Authentication management")
app.add_typer(auth_app, name="auth")


def _ensure_admin_user(database_url: str, *, yes: bool = False) -> None:
    """Create an admin user if none exists in the database."""
    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session

    from app.auth import hashing, models

    engine = create_engine(database_url, pool_pre_ping=True)
    with Session(engine) as db:
        # Check if a real admin user exists (not just a system sentinel)
        admin_role = db.query(models.Role).filter(models.Role.name == "admin").first()
        if admin_role:
            admin_user = (
                db.query(models.User)
                .filter(models.User.roles.any(models.Role.id == admin_role.id))
                .first()
            )
            if admin_user:
                display.success(f"Admin user exists: {admin_user.email}")
                return

        display.info("No admin user found — let's create one")
        if yes:
            email = "admin@governor.local"
            password = "governor"
        else:
            email = display.ask("Admin email", default="admin@governor.local")
            password = display.ask("Admin password", default="governor")

        # Ensure admin role
        role = db.query(models.Role).filter(models.Role.name == "admin").one_or_none()
        if not role:
            role = models.Role(name="admin")
            db.add(role)
            db.commit()
            db.refresh(role)

        user = models.User(
            email=email,
            display_name="Admin",
            password_hash=hashing.hash_password(password),
            status="active",
        )
        db.add(user)
        db.commit()
        db.refresh(user)

        if role not in user.roles:
            user.roles.append(role)
            db.commit()

        display.success(f"Admin user created: {email}")


def _auto_setup_local_project(
    db_url: str,
    db,
    *,
    project_path: str | None = None,
) -> None:
    """Auto-detect dbt project and create configuration + mark setup complete.

    In local mode, this replaces the setup wizard entirely:
    - Scans the selected path or CWD for dbt_project.yml
    - Reads target/manifest.json
    - Auto-creates a ManifestConfiguration
    - Marks setup as complete
    No GitHub, no GCS, no manual steps.
    """
    import os

    try:
        from app.workspace.detection import detect_workspace, read_local_manifest

        search_path = project_path or os.getcwd()
        workspace = detect_workspace(search_path)
        if not workspace or not workspace.project_path:
            display.dim(f"No dbt project detected at {search_path}")
            return

        display.step_header(2, 3, "Project Detection")
        display.success(
            f"dbt project: {workspace.dbt_project_name or workspace.project_path}"
        )
        if workspace.git_branch:
            display.info(f"  Branch: {workspace.git_branch}")
        if workspace.git_repo:
            display.info(f"  Repository: {workspace.git_repo}")

        if not workspace.has_manifest:
            display.warn("No target/manifest.json found. Run 'dbt compile' first.")
            return

        # Check if config already exists for this project path
        from app.configurations.models import ManifestConfiguration

        existing = (
            db.query(ManifestConfiguration)
            .filter(ManifestConfiguration.local_project_path == workspace.project_path)
            .first()
        )
        if existing:
            display.success(f"Configuration exists: {existing.name}")
        else:
            # Read manifest and create configuration
            manifest_bytes = read_local_manifest(workspace.project_path)
            if not manifest_bytes:
                display.warn("Could not read manifest file")
                return

            # Detect GCP project from manifest
            import json

            manifest_data = json.loads(manifest_bytes)
            gcp_project_id = _detect_gcp_project_from_manifest(manifest_data)

            from app.auth.models import User

            admin = db.query(User).first()
            admin_id = admin.id if admin else "cli-setup"

            config_name = workspace.dbt_project_name or "local-project"
            config = ManifestConfiguration(
                name=config_name,
                gcp_project_id=gcp_project_id or "local",
                github_repo=workspace.git_repo or "",
                manifest_source="manual_upload",
                local_project_path=workspace.project_path,
                created_by_id=admin_id,
                updated_by_id=admin_id,
                status="active",
            )
            db.add(config)
            db.commit()
            db.refresh(config)
            display.success(f"Configuration created: {config_name}")

            # Upload manifest
            from app.configurations.service import ManifestConfigurationService

            svc = ManifestConfigurationService(db)
            svc.store_uploaded_manifest(
                config_id=config.id,
                manifest_bytes=manifest_bytes,
                user_id=admin_id,
            )
            display.success("Manifest loaded")

            # Read run_results if available
            if workspace.has_run_results:
                from app.workspace.detection import read_local_run_results

                run_results = read_local_run_results(workspace.project_path)
                if run_results:
                    display.success("Run results loaded")

        # Mark setup as complete
        from app.setup.service import SetupService

        setup_svc = SetupService(db)
        state = setup_svc.get_state()
        if state and not state.is_complete:
            state.is_complete = True
            state.step_reached = 7
            db.commit()
            display.success("Setup complete")

    except Exception as exc:
        display.warn(f"Auto-detection failed: {exc}")
        display.dim("You can complete setup in the browser")


def _detect_gcp_project_from_manifest(manifest: dict) -> str | None:
    """Extract GCP project ID from manifest node metadata."""
    nodes = manifest.get("nodes", {})
    for node in nodes.values():
        database = node.get("database")
        if database and database != "None":
            return database
    return None


def _is_tcp_port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.2):
            return True
    except OSError:
        return False


def _is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _wait_for_background_server(
    proc,
    *,
    port: int,
    timeout_seconds: float = 10.0,
) -> tuple[bool, int | None]:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        exit_code = proc.poll()
        if exit_code is not None:
            return False, exit_code
        if _is_tcp_port_open("127.0.0.1", port):
            return True, None
        time.sleep(0.2)

    return False, None


def _run_pending_migrations() -> None:
    from app.cli.steps import database

    database._run_migrations()


# ---------------------------------------------------------------------------
# governor init
# ---------------------------------------------------------------------------


@app.command()
def init(
    database_url: Optional[str] = typer.Option(
        None, help="PostgreSQL connection string"
    ),
    port: int = typer.Option(8000, help="Server port"),
    project_path: Optional[str] = typer.Option(
        None,
        "--project-path",
        "-p",
        help="Path to the dbt project folder",
    ),
    no_browser: bool = typer.Option(False, help="Don't open browser"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Accept defaults"),
) -> None:
    """Set up Governor: database, admin user, then open the setup wizard in your browser."""
    display.banner()

    # Check for existing setup
    saved = cli_config.load_config()
    if saved.get("database_url") and not yes:
        display.info("Existing Governor installation detected")
        if not display.confirm("Reconfigure?", default=False):
            display.info("Run [bold]governor start[/] to start the server")
            raise typer.Exit()

    # Step 1: Database + Admin user
    from app.cli.steps import database

    display.step_header(1, 3, "Database")
    db_url = database.run(database_url=database_url, yes=yes)

    # Create admin user so the setup wizard can skip step 1
    _ensure_admin_user(db_url, yes=yes)

    # Save config and load env vars
    cli_config.update_config(server_port=port, local_mode=True)
    cli_config.load_env_from_config()

    # Step 2: Auto-detect dbt project and create configuration (spec 084)
    import webbrowser

    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session

    url = f"http://localhost:{port}"
    engine = create_engine(db_url, pool_pre_ping=True)

    with Session(engine) as db:
        from app.setup.service import SetupService

        svc = SetupService(db)
        setup_complete = svc.is_setup_complete()

        # If admin user exists but setup isn't complete, create step1
        # state so the wizard starts at step 2 (skip account creation)
        if not setup_complete:
            from app.auth.models import User

            admin = db.query(User).first()
            if admin:
                state = svc.get_state()
                if state is None:
                    svc.create_step1(admin.id)

        # Auto-detect dbt project and create config (local mode only)
        _auto_setup_local_project(db_url, db, project_path=project_path)

    # Re-check setup state after auto-setup
    with Session(engine) as db:
        svc = SetupService(db)
        setup_complete = svc.is_setup_complete()

    if setup_complete:
        open_url = f"{url}/dashboard"
        display.step_header(3, 3, "Launch")
        display.success(f"Starting Governor on {url}")
        display.info(f"Opening [bold]{open_url}[/]")
    else:
        # Fallback to setup wizard if auto-detect failed
        open_url = f"{url}/setup/2"
        display.step_header(3, 3, "Launch")
        display.success(f"Starting Governor on {url}")
        display.info(f"Opening setup wizard at [bold]{open_url}[/]")
        display.dim("Complete the setup in your browser")

    display.dim("Press Ctrl+C to stop the server")
    display.console.print()

    if not no_browser:
        try:
            webbrowser.open(open_url)
        except OSError:
            pass

    # Run server in foreground
    os.environ.setdefault("DATABASE_URL", db_url)
    try:
        import uvicorn

        uvicorn.run(
            "app.main:create_app",
            host="0.0.0.0",
            port=port,
            factory=True,
        )
    except KeyboardInterrupt:
        display.info("\nServer stopped")


# ---------------------------------------------------------------------------
# governor start
# ---------------------------------------------------------------------------


@app.command()
def start(
    port: Optional[int] = typer.Option(None, help="Server port"),
    fg: bool = typer.Option(False, "--fg", help="Run in foreground"),
) -> None:
    """Start the Governor server."""
    cli_config.load_env_from_config()
    cfg = cli_config.load_config()
    db_url = cfg.get("database_url")
    if not db_url:
        display.error("No database configured. Run [bold]governor init[/] first.")
        raise typer.Exit(1)

    server_port = port or cfg.get("server_port", 8000)
    os.environ["DATABASE_URL"] = db_url

    existing_pid = cli_config.read_pid()
    if existing_pid and _is_process_running(existing_pid):
        if _is_tcp_port_open("127.0.0.1", server_port):
            display.success(
                f"Server already running on http://localhost:{server_port} "
                f"(PID {existing_pid})"
            )
            return
    elif existing_pid:
        cli_config.clear_pid()

    # Start Docker container if managed
    if cfg.get("docker_managed"):
        from app.cli import docker

        status = docker.container_status()
        if status == "exited":
            display.info("Starting database container...")
            docker.start_existing_container()
            db_port = docker.get_container_port() or docker.DEFAULT_PORT
            if not docker.wait_for_ready(db_port):
                display.error("Database failed to start")
                raise typer.Exit(1)
            display.success("Database running")
        elif status == "running":
            display.success("Database already running")
        else:
            display.error(
                "Database container not found. Run [bold]governor init[/] again."
            )
            raise typer.Exit(1)

    _run_pending_migrations()

    if fg:
        display.success(f"Starting server on http://localhost:{server_port}")
        import uvicorn

        uvicorn.run(
            "app.main:create_app",
            host="0.0.0.0",
            port=server_port,
            factory=True,
        )
    else:
        import subprocess

        log_path = cli_config.ensure_config_dir() / "server.log"
        log_file = log_path.open("ab")
        try:
            proc = subprocess.Popen(
                [
                    sys.executable,
                    "-m",
                    "uvicorn",
                    "app.main:create_app",
                    "--host",
                    "0.0.0.0",
                    "--port",
                    str(server_port),
                    "--factory",
                ],
                env={**os.environ, "DATABASE_URL": db_url},
                stdout=log_file,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        finally:
            log_file.close()

        ready, exit_code = _wait_for_background_server(proc, port=server_port)
        if not ready:
            cli_config.clear_pid()
            if exit_code is None:
                proc.terminate()
                reason = "did not become ready within 10 seconds"
            else:
                reason = f"exited with code {exit_code}"
            display.error(f"Server failed to start: {reason}")
            display.dim(f"See logs: {log_path}")
            raise typer.Exit(1)

        cli_config.write_pid(proc.pid)
        display.success(
            f"Server started on http://localhost:{server_port} (PID {proc.pid})"
        )
        display.dim(f"Logs: {log_path}")


# ---------------------------------------------------------------------------
# governor stop
# ---------------------------------------------------------------------------


@app.command()
def stop(
    all_services: bool = typer.Option(
        False, "--all", help="Also stop database container"
    ),
) -> None:
    """Stop the Governor server."""
    pid = cli_config.read_pid()
    if pid:
        try:
            os.kill(pid, signal.SIGTERM)
            display.success(f"Server stopped (PID {pid})")
        except ProcessLookupError:
            display.dim("Server was not running")
        cli_config.clear_pid()
    else:
        display.dim("No server PID found")

    if all_services:
        cfg = cli_config.load_config()
        if cfg.get("docker_managed"):
            from app.cli import docker

            docker.stop_container()
            display.success("Database container stopped")


# ---------------------------------------------------------------------------
# governor status
# ---------------------------------------------------------------------------


@app.command()
def status() -> None:
    """Show Governor instance status."""
    cli_config.load_env_from_config()
    cfg = cli_config.load_config()

    # Server
    pid = cli_config.read_pid()
    if pid:
        try:
            os.kill(pid, 0)
            port = cfg.get("server_port", 8000)
            display.info(f"Server:   [green]Running[/] (PID {pid}, port {port})")
        except ProcessLookupError:
            display.info("Server:   [dim]Stopped[/] (stale PID)")
            cli_config.clear_pid()
    else:
        display.info("Server:   [dim]Not running[/]")

    # Database
    if cfg.get("docker_managed"):
        from app.cli import docker

        ds = docker.container_status()
        if ds == "running":
            port = docker.get_container_port() or docker.DEFAULT_PORT
            display.info(f"Database: [green]Running[/] (Docker, port {port})")
        elif ds:
            display.info(f"Database: [yellow]{ds}[/] (Docker)")
        else:
            display.info("Database: [red]Container not found[/]")
    elif cfg.get("database_url"):
        display.info("Database: [green]Configured[/] (external)")
    else:
        display.info("Database: [dim]Not configured[/]")

    # Configs
    if cfg.get("database_url"):
        try:
            os.environ.setdefault("DATABASE_URL", cfg["database_url"])
            from sqlalchemy.orm import Session

            from app.configurations.models import ManifestConfiguration
            from sqlalchemy import create_engine

            engine = create_engine(cfg["database_url"], pool_pre_ping=True)
            with Session(engine) as db:
                count = db.query(ManifestConfiguration).count()
                display.info(f"Projects: {count} configuration(s)")
        except SQLAlchemyError, OSError:
            display.info("Projects: [dim]Unable to query[/]")


# ---------------------------------------------------------------------------
# governor sync
# ---------------------------------------------------------------------------


@app.command()
def sync(
    name: Optional[str] = typer.Argument(
        None, help="Configuration name (default: all)"
    ),
) -> None:
    """Trigger a manual sync."""
    cli_config.load_env_from_config()
    cfg = cli_config.load_config()
    db_url = cfg.get("database_url")
    if not db_url:
        display.error("No database configured. Run [bold]governor init[/] first.")
        raise typer.Exit(1)

    os.environ.setdefault("DATABASE_URL", db_url)

    from sqlalchemy import create_engine
    from sqlalchemy.orm import Session

    from app.configurations.models import ManifestConfiguration
    from app.sync.service import DuplicateSyncError, SyncService

    engine = create_engine(db_url, pool_pre_ping=True)
    with Session(engine) as db:
        query = db.query(ManifestConfiguration).filter(
            ManifestConfiguration.status == "active"
        )
        if name:
            query = query.filter(ManifestConfiguration.name == name)
        configs = query.all()

        if not configs:
            display.warn("No matching configurations found")
            raise typer.Exit(1)

        sync_service = SyncService(db)
        for config in configs:
            try:
                sync_service.create_sync_operation(config.id, config.created_by_id)
                display.success(f"Sync queued: {config.name}")
            except DuplicateSyncError:
                display.dim(f"Sync already queued or running: {config.name}")


# ---------------------------------------------------------------------------
# governor auth refresh
# ---------------------------------------------------------------------------


@auth_app.command("refresh")
def auth_refresh(
    service: Optional[str] = typer.Argument(None, help="google or github"),
) -> None:
    """Re-run authentication for Google or GitHub."""
    cli_config.load_env_from_config()
    cfg = cli_config.load_config()
    db_url = cfg.get("database_url")
    if not db_url:
        display.error("No database configured. Run [bold]governor init[/] first.")
        raise typer.Exit(1)

    os.environ.setdefault("DATABASE_URL", db_url)

    if not service:
        service = display.choose("Which service?", ["google", "github"])

    if service == "google":
        from app.cli.steps import google_auth

        gcp_result = google_auth.run()
        # Update setup state
        from sqlalchemy import create_engine
        from sqlalchemy.orm import Session

        from app.setup.service import SetupService

        engine = create_engine(db_url, pool_pre_ping=True)
        with Session(engine) as db:
            svc = SetupService(db)
            svc.save_step2(
                gcp_credentials_json=gcp_result.get("credentials_json"),
                auth_method=gcp_result.get("auth_method", "adc"),
                installation_mode="local_dev",
            )
            svc.save_step3(gcp_result.get("region", "us"))
        display.success("Google Cloud credentials updated")

    elif service == "github":
        from app.cli.steps import github_auth

        github_result = github_auth.run()
        if not github_result.get("skipped"):
            from sqlalchemy import create_engine
            from sqlalchemy.orm import Session

            from app.setup.service import SetupService

            engine = create_engine(db_url, pool_pre_ping=True)
            with Session(engine) as db:
                svc = SetupService(db)
                svc.save_step4_personal_token(github_result["token"])
            display.success("GitHub credentials updated")
    else:
        display.error("Unknown service. Use 'google' or 'github'.")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
