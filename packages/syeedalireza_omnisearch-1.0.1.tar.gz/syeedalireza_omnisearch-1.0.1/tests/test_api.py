import pytest
from httpx import AsyncClient, ASGITransport
from src.main import app
import pytest_asyncio
from unittest.mock import patch

@pytest_asyncio.fixture
async def async_client():
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as client:
        yield client

@pytest.mark.asyncio
async def test_health_check(async_client):
    response = await async_client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "healthy"

@pytest.mark.asyncio
@patch("src.main.qdrant_service.search")
async def test_search_endpoint(mock_search, async_client):
    # Mocking the Qdrant service response
    mock_search.return_value = [
        {"product_id": "1", "score": 0.95, "name": "Red Shoes", "description": "Running shoes", "price": 99.99}
    ]
    
    response = await async_client.post("/api/v1/search", json={"query": "red running shoes", "limit": 1})
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 1
    assert data[0]["product_id"] == "1"
    assert data[0]["score"] == 0.95