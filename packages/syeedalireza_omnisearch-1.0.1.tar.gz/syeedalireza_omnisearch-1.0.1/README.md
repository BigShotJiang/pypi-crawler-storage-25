# OmniSearch: Semantic & Visual Product Discovery

**OmniSearch** is an AI-powered e-commerce search engine using Vector Databases (Qdrant/Milvus) and HuggingFace Transformers to allow users to search via natural language or images.

Developed by **Alireza Aminzadeh** ([@syeedalireza](https://github.com/syeedalireza)).

## Architecture
- **API:** FastAPI
- **Vector DB:** Qdrant / Milvus
- **AI Models:** HuggingFace Transformers (Sentence-BERT, CLIP)
- **Caching:** Redis

*(Technical implementation pending in next iteration)*
