from fastapi import FastAPI, HTTPException, status, Depends
from pydantic import BaseModel
from typing import List
from src.infrastructure.qdrant_db import QdrantService
from src.domain.models import Product, SearchResult

app = FastAPI(
    title="OmniSearch API",
    description="Semantic Product Discovery using Vector DB",
    version="1.0.0"
)

qdrant_service = QdrantService()

class SearchRequest(BaseModel):
    query: str
    limit: int = 5

@app.on_event("startup")
async def startup_event():
    """Initialize Qdrant collection on startup."""
    qdrant_service.initialize_collection()

@app.get("/health", tags=["System"])
async def health_check():
    return {"status": "healthy"}

@app.post("/api/v1/products", status_code=status.HTTP_201_CREATED, tags=["Catalog"])
async def index_product(product: Product):
    """Index a new product into the Vector Database."""
    try:
        qdrant_service.index_product(product)
        return {"status": "success", "message": f"Product {product.id} indexed."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/v1/search", response_model=List[SearchResult], tags=["Search"])
async def search_products(request: SearchRequest):
    """Semantic search using natural language."""
    try:
        results = qdrant_service.search(request.query, request.limit)
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))