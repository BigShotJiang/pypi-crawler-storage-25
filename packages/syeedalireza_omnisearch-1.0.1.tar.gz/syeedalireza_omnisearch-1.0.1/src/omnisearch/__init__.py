"""OmniSearch package"""
