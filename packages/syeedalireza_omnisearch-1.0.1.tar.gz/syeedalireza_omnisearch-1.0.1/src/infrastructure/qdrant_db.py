from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct
from sentence_transformers import SentenceTransformer
from src.domain.models import Product, SearchResult
import os
import uuid

class QdrantService:
    def __init__(self):
        host = os.getenv("QDRANT_HOST", "localhost")
        port = int(os.getenv("QDRANT_PORT", "6333"))
        self.client = QdrantClient(host=host, port=port)
        self.collection_name = "products"
        # Using a lightweight model for fast semantic search
        self.model = SentenceTransformer(os.getenv("MODEL_NAME", "all-MiniLM-L6-v2"))
        self.vector_size = self.model.get_sentence_embedding_dimension()

    def initialize_collection(self):
        """Create the collection if it doesn't exist."""
        collections = self.client.get_collections().collections
        exists = any(c.name == self.collection_name for c in collections)
        
        if not exists:
            self.client.create_collection(
                collection_name=self.collection_name,
                vectors_config=VectorParams(size=self.vector_size, distance=Distance.COSINE),
            )

    def index_product(self, product: Product):
        """Convert product text to vector and store in Qdrant."""
        text_to_embed = f"{product.name}. {product.description}. Category: {product.category}"
        vector = self.model.encode(text_to_embed).tolist()
        
        point_id = str(uuid.uuid5(uuid.NAMESPACE_DNS, product.id))
        
        self.client.upsert(
            collection_name=self.collection_name,
            points=[
                PointStruct(
                    id=point_id,
                    vector=vector,
                    payload={
                        "product_id": product.id,
                        "name": product.name,
                        "description": product.description,
                        "price": product.price
                    }
                )
            ]
        )

    def search(self, query: str, limit: int = 5) -> list[SearchResult]:
        """Search products using semantic similarity."""
        query_vector = self.model.encode(query).tolist()
        
        search_result = self.client.search(
            collection_name=self.collection_name,
            query_vector=query_vector,
            limit=limit
        )
        
        results = []
        for hit in search_result:
            results.append(SearchResult(
                product_id=hit.payload["product_id"],
                score=hit.score,
                name=hit.payload["name"],
                description=hit.payload["description"],
                price=hit.payload["price"]
            ))
            
        return results