from pydantic import BaseModel
from typing import Dict, Any, Optional

class Product(BaseModel):
    id: str
    name: str
    description: str
    price: float
    category: str
    metadata: Optional[Dict[str, Any]] = None

class SearchResult(BaseModel):
    product_id: str
    score: float
    name: str
    description: str
    price: float