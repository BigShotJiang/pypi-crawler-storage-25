# version: 1.1.0
# 운영 가이드: Ingest, Lint, 카테고리, 판단 기준, Co-Evolve

> SKILL.md에서 `Read("ref-operations.md")`로 참조.

## Ingest 워크플로우 (새 소스 통합)

### MUST (반드시 수행)

- [ ] `ai-wiki search "관련 키워드"` -- 기존 문서 존재 여부 확인
- [ ] 기존 문서가 있으면 내용 비교, 중복 여부 판단
- [ ] 새 문서 생성 시 `content`에 `type` 필드 포함
- [ ] `--source` 플래그로 출처를 반드시 1개 이상 지정
- [ ] `--confidence` 값을 자료 품질에 따라 정확히 설정 (티어 분류표 참조)
- [ ] create가 `auto_linked` 결과를 반환하면 확인. 누락된 관련 문서가 있으면 추가
- [ ] 기존 문서의 content가 불완전하면 함께 보완 (`ai-wiki update`)
- [ ] `_meta` 블록 포함 (maturity, completeness, missing_fields)

### SHOULD (강력히 권장)

- [ ] `--tags`에 3개 이상 태그 지정
- [ ] content 내에 해당 type 템플릿의 모든 필드를 가능한 한 채움
- [ ] 관련 문서가 3개 이상이면 synthesis 문서 생성 고려
- [ ] `_changelog` 포함

---

## Knowledge Compounds (synthesis 타입)

여러 위키 문서를 조합하여 새로운 통찰을 만들었다면, 새 문서로 저장한다.

### synthesis 생성 조건

- 2개 이상 위키 문서를 조합하여 새 통찰을 생성했으면 저장 대상
- 사용자 질문이 기존 문서 단독으로 답변 불가하고, 교차 분석이 필요했던 경우

### MUST

- [ ] `--tags`에 `synthesis,derived` 추가
- [ ] `--related`에 참조한 모든 원본 문서 ID 포함
- [ ] content의 `type`을 `synthesis`로 지정
- [ ] `derived_from`에 원본 문서 ID를 전부 나열
- [ ] `insight` 필드에 원본 문서에는 없는 새로운 통찰을 명시

---

## Lint 후 자동 수정 워크플로우

```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki lint
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki lint --fix
```

### 자동 수정 (--fix)

- **one_way_links**: 역방향 링크 자동 추가
- **broken_references**: 존재하지 않는 참조 자동 제거

### 수동 수정

#### orphan_articles
```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki search "<문서 키워드>"
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki update <orphan_id> --related "찾은문서id"
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki update <찾은문서id> --related "orphan_id"
```

#### no_sources
```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki update <id> --source "https://찾은출처"
```

#### low_confidence
```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki update <id> --source "검증출처" --confidence 0.85
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki verify <id>
```

#### potential_conflicts
```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki get <id1>
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki get <id2>
# 중복이면 하나 삭제+병합 / 모순이면 disputes 추가 / 정상 공존이면 무시
```

### 자동화 규칙

- 5개 이하 이슈 → 즉시 자동+수동 수정
- 6개 이상 → 유형별 요약 보고 후 사용자 확인 대기

---

## 카테고리 체계

**핵심: category = 주제 도메인, content.type = 문서 유형. 혼합 금지.**

### 대분류 10개

| 대분류 | ID prefix | 중분류 예시 |
|--------|-----------|------------|
| `history` | `hist` | `history/korea`, `history/europe` |
| `politics` | `poli` | `politics/korea`, `politics/us` |
| `military` | `mili` | `military/us`, `military/strategy` |
| `economics` | `econ` | `economics/korea`, `economics/theory` |
| `science` | `scie` | `science/physics`, `science/biology` |
| `technology` | `tech` | `technology/python`, `technology/ai` |
| `society` | `soci` | `society/korea`, `society/education` |
| `philosophy` | `phil` | `philosophy/ethics` |
| `geography` | `geog` | `geography/korea`, `geography/climate` |
| `project` | `proj` | `project/ai-wiki` |
| `law` | `law` | `law/korea`, `law/international` |

### 인물 분류

인물은 **주된 역할의 도메인**에 배치: 정치인→politics, 군인→military, 과학자→science, 기술자→technology

### 하이브리드 주제

**"주된 질문"의 주어가 속하는 도메인**에 배치.

### 깊이 규칙

- 2단계 권장: `대분류/중분류`
- 3단계 허용: 중분류에 30개+ 문서일 때
- 4단계 이상 금지

---

## 판단 기준 (저장 여부)

### 저장 O
- 조사에 5분 이상 걸린 내용
- 공식 문서를 읽고 구조화한 내용
- 트러블슈팅 해결 기록 (에러 메시지 포함)
- 여러 프로젝트에서 재사용 가능한 패턴
- 2개 이상 문서를 조합한 새 통찰 (synthesis)
- 논쟁적이거나 시간에 따라 변하는 정보
- 공식 문서에 없는 실무 노하우

### 저장 X
- 프로젝트 고유 코드 (git에 있음)
- 한 줄로 끝나는 사소한 사실
- 이미 위키에 있는 중복 내용
- 대화 맥락에서만 의미 있는 임시 정보
- 빠르게 변하는 가격/버전 정보

---

## Co-Evolve: 개선 로그

이 섹션은 AI가 위키 운영 중 발견한 패턴, 문제점, 스키마 개선 사항을 기록하는 곳이다.

### 기록 규칙

- **발견 즉시 기록**: 위키 조작 중 반복적 패턴이나 비효율 발견 시 항목 추가
- **항목 형식**: `[YYYY-MM-DD] 카테고리: 내용 (상태: pending/applied/rejected)`
- **카테고리**: `schema` | `workflow` | `template` | `quality` | `tooling`
- **반영 후 졸업**: 상위 섹션에 반영 완료된 항목은 `applied`로 변경
- **분기별 정리**: applied/rejected 항목은 분기마다 아카이브로 이동

### Co-Evolve 트리거

- 위키 조작 10회마다 또는 lint 실행 후 "개선 로그"를 검토
- 반복적으로 같은 유형의 문제가 발생하면 pending 항목으로 기록
- pending 항목이 3회 이상 관련 사례가 확인되면 상위 섹션에 반영하고 applied로 변경

### 활성 개선 항목

- [2026-04-09] tooling: 웹 UI 그래프 시각화 (applied — D3.js 네트워크 그래프 구현 완료)
- [2026-04-09] tooling: 웹 UI related 문서 클릭 링크 (applied — 제목 링크로 변경 완료)
- [2026-04-09] tooling: 웹 UI YAML 구조화 렌더링 (applied — disputes/historiography 전용 렌더링 완료)
- [2026-04-09] workflow: SKILL.md 971줄 → Core 200줄 분리 (applied — ref-*.md 4개로 분리)
- [2026-04-09] tooling: Windows 인코딩 cp949 → UTF-8 강제 (applied — output_json 수정)
- [2026-04-09] tooling: SQLite WAL 모드 (applied — PRAGMA journal_mode = WAL)
- [2026-04-09] tooling: 하드코딩 경로 → $AI_WIKI_ROOT 환경변수 (applied)
- [2026-04-09] tooling: Git 자동 커밋 on create/update/delete (applied)
- [2026-04-09] tooling: list_all_articles() DB 기반 전환 (applied)
- [2026-04-13] tooling: upgrade-skill 명령어 추가 (applied — 패키지 내 템플릿 → ~/.claude/skills/ 복사)

### 아카이브

(반영 완료 또는 기각된 항목은 분기별로 여기로 이동)
