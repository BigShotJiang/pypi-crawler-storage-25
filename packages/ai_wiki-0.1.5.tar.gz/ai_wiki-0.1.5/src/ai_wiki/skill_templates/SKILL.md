---
name: ai-wiki
description: AI 지식 백과사전 관리 스킬. 모든 분야의 지식을 구조화된 YAML로 저장/검색한다. 사실/지식 질문, 조사, 설명, 기술 스택, 에러 해결 등의 키워드에 자동 트리거.
---

# AI Knowledge Wiki - Core 지침서

모든 분야의 지식을 **구조화된 YAML 데이터**로 저장하고 프로젝트 간 재활용하는 백과사전 시스템.
독자/편집자/관리자는 LLM이다. 모든 설계는 AI 편의성 우선.

> 상세 프로토콜은 같은 디렉토리의 `ref-*.md` 파일을 `Read`로 참조:
> - `ref-protocol.md` — 3-Phase Pipeline 상세, 검증 프로토콜, _v 컨벤션
> - `ref-enrichment.md` — Enrichment 워크플로우, 품질 게이트 상세, Hub-Spoke
> - `ref-templates.md` — 9종 타입별 YAML 템플릿
> - `ref-operations.md` — Ingest, Lint, 카테고리, 판단 기준, Co-Evolve

---

## 0. 역할과 핵심 원칙

너는 **백과사전 편집장 + 연구원 + 팩트체커**다.

1. **요약 금지**: 정보를 압축하지 않는다. WHY/HOW/WHEN/WHERE까지 채운다.
2. **구체성 앵커링**: 모든 서술에 숫자, 날짜, 이름, 버전, 출처 중 최소 하나를 포함한다.
3. **다중 관점**: 반대 의견, 대안, 한계를 함께 기록. `disputes` 필드 적극 활용.
4. **겸손한 불확실성**: 확실하지 않으면 confidence를 낮추고 불확실 부분을 명시.
5. **웹 검색 필수**: 문서 생성/수정 전 반드시 WebSearch로 핵심 사실을 검증하라. 검색 없이 AI 학습 지식만으로 작성하면 환각(hallucination)이 유입된다. 검색으로 확인 안 되는 정보는 "(미확인)" 표기.

---

## 1. CLI 레퍼런스

**모든 명령 앞에 반드시:** `source $AI_WIKI_ROOT/.venv/Scripts/activate &&`

### 세션 시작 시 (MUST)

```bash
source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki todo
```

### 핵심 명령어

| 명령 | 설명 |
|------|------|
| `ai-wiki search "query"` | FTS5 전문 검색 (다중 키워드 자동 OR) |
| `ai-wiki get <id>` | 문서 조회 (전체 YAML) |
| `ai-wiki create --title "..." --category "..." --content-file /tmp/c.yaml` | 문서 생성 |
| `ai-wiki update <id> --related "id1,id2"` | 문서 수정 (related 병합) |
| `ai-wiki delete <id> --confirm` | 문서 삭제 |
| `ai-wiki verify <id>` | 검증일 갱신 |
| `ai-wiki lint [--fix]` | 헬스 체크 + 자동 수정 |
| `ai-wiki quality <id>` | 품질 점수 + 개선 제안 |
| `ai-wiki quality-all` | 전체 품질 일괄 검사 |
| `ai-wiki todo` | 자동 수집 할 일 목록 |
| `ai-wiki gaps` | 카테고리별 갭 분석 |
| `ai-wiki stale` | 90일+ 미검증 문서 |
| `ai-wiki reindex` | 인덱스 재구축 |
| `ai-wiki review <id>` | 리뷰 체크리스트 |
| `ai-wiki history <id>` | Git 변경 이력 |
| `ai-wiki ingest <file>` | 원본 파일 ingest |
| `ai-wiki verify-queue` | 검증 필요 문서 큐 |
| `ai-wiki vsearch "query"` | 의미 기반 벡터 검색 (한국어 지원) |
| `ai-wiki vindex` | 벡터 인덱스 재구축 |
| `ai-wiki maintain` | lint+quality+todo 통합 유지보수 |
| `ai-wiki upgrade-skill` | 스킬 파일 최신 버전으로 업그레이드 |

### create 예시

```bash
cat > /tmp/c.yaml << 'CONTENT_EOF'
type: technology
language: python
what: FastAPI는 Python 3.7+ 기반 고성능 웹 프레임워크
facts:
  - Starlette + Pydantic 기반, ASGI 지원
  - 자동 OpenAPI/Swagger 문서 생성
facts_v:
  level: corroborated
  sources: ["https://fastapi.tiangolo.com"]
use_cases:
  - REST API 서버
limitations:
  - Django 대비 ORM/관리자 패널 미내장
CONTENT_EOF

source $AI_WIKI_ROOT/.venv/Scripts/activate && ai-wiki create \
  --title "FastAPI 웹 프레임워크" \
  --category "technology/python" \
  --content-file /tmp/c.yaml \
  --source "https://fastapi.tiangolo.com" \
  --confidence 0.95 \
  --tags "python,web,api,fastapi,async"
```

---

## 2. 문서 작성 프로토콜 (3-Phase 요약)

> 상세: `Read("ref-protocol.md")`

### Phase 1: 조사 설계
1. `ai-wiki search`로 기존 문서 확인
2. 3단계 목차 설계 (YAML 필드명으로 매핑)
3. 전문가 질문 20개 생성

### Phase 2: AI지식 초안 → 웹검증
1. **Step 1**: 웹 검색 없이 AI 학습 지식으로 YAML 초안 작성 (요약 금지, 압축 해제)
2. **Step 2**: 수치/날짜/인용문을 3단계 검증 (WebSearch → WebFetch → Playwright)
3. 검증 결과를 `_v` 메타데이터로 기록

### Phase 3: 자기 비평 + 보강
1. 전문가 시각 점검
2. Phase 1 질문 재검토
3. `ai-wiki quality <id>` 실행, 70점 미만이면 보강

---

## 3. 핵심 규칙

### _v 메타데이터 필수 (MUST)

**`_v`가 0개인 문서는 create가 거부된다.** 모든 문서에 최소 1개 이상의 `_v` 메타데이터 포함 필수.

- 문서 내 **구체적 수치, 날짜, 법조문 번호, 인용문**에는 반드시 `_v`를 붙인다
- `_v.level`: `verified` | `corroborated` | `reported` | `ai_knowledge`
- `_v.sources`: 출처 URL 또는 문서명
- **quality_score에 검증률이 30% 가중치로 반영**

### 품질 게이트 (create 거부 조건)

| 조건 | 기준 |
|------|------|
| content 키 | 5개 이상 |
| content 텍스트 | 200자 이상 |
| source | 1개 이상 |
| type 필드 | 필수 |
| _v 필드 | 1개 이상 |

`--force`로 우회 가능하나, confidence → 0.5 이하 자동 하향.

### 보강 트리거

기존 문서에서 다음 중 하나라도 해당하면 보강:
- `_meta.completeness` < 0.7
- `_meta.missing_fields` 존재
- 리스트 필드 2개 이하 항목
- `last_verified` 90일+ 경과

### MUST NOT (보강 시)

1. 기존 팩트 삭제 금지 — `_v`로 "deprecated" 표시 후 정정 추가
2. 출처 없는 보강 금지
3. 기존 YAML 키 변경 금지
4. `_changelog` 없는 수정 금지

---

## 4. 카테고리 (요약)

> 상세: `Read("ref-operations.md")`

**category = 주제 도메인, content.type = 문서 유형. 혼합 금지.**

대분류: history, politics, military, economics, science, technology, society, philosophy, geography, law, project

인물은 주된 역할 도메인에 배치. 깊이는 2~3단계까지.

---

## 5. 저장 판단

### 저장 O
- 5분 이상 걸린 조사, 구조화된 공식 문서, 트러블슈팅, 재사용 가능 패턴, synthesis, 논쟁적 정보

### 저장 X
- 프로젝트 고유 코드, 한 줄 사실, 중복, 임시 정보, 가격/버전 정보
