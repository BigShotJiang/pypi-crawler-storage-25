# version: 1.1.0
# Enrichment + 품질 게이트 + Hub-Spoke (상세)

> SKILL.md에서 `Read("ref-enrichment.md")`로 참조.

## Enrichment 워크플로우 (기존 문서 보강)

기존 문서를 발견했을 때, 단순히 읽고 넘어가지 않는다. 보강 가능성을 항상 평가한다.

### 보강 트리거 조건 (하나라도 해당하면 보강 시작)

- `_meta.completeness` < 0.7
- `_meta.missing_fields`에 항목이 존재
- content의 리스트 필드가 2개 이하 항목만 가짐
- 마지막 검증(`last_verified`)이 90일 이상 경과
- 현재 조사 중인 자료에 문서에 없는 정보가 포함됨

### _meta 컨벤션

```yaml
_meta:
  maturity: stub | draft | complete | authoritative
  completeness: 0.0 ~ 1.0
  missing_fields:
    - "workarounds 미작성"
    - "limitations에 구체적 수치 부족"
  enrichment_hints:
    - "공식 벤치마크 데이터 추가 필요"
  last_enriched: "2026-04-08"
  enrichment_count: 3
```

| 단계 | 기준 |
|------|------|
| `stub` | 제목 + type + 기본 facts만 있음. completeness < 0.3 |
| `draft` | 주요 필드 작성됨. 출처/검증 부족. completeness 0.3 ~ 0.6 |
| `complete` | 모든 주요 필드 작성 + 출처 있음. completeness 0.7 ~ 0.9 |
| `authoritative` | 전문가 수준. 다중 출처 검증 완료. completeness 0.9+ |

### _changelog 컨벤션

```yaml
_changelog:
  - date: "2026-04-08"
    action: "enriched"
    fields: ["facts", "limitations"]
    details: "공식 문서 v3.2 반영, 벤치마크 수치 추가"
    sources_added: ["https://docs.example.com/v3.2"]
```

### MUST NOT 규칙 (보강 시 절대 하지 말 것)

1. **기존 팩트 삭제 금지**: 틀린 정보 → `_v`로 "deprecated" 표시 후 정정 추가
2. **출처 없는 보강 금지**: 새 정보에 출처 필수. 없으면 confidence 0.5 이하
3. **구조 파괴 금지**: 기존 YAML 키 변경/재구조화 금지. 키 추가만 허용
4. **묵시적 보강 금지**: 반드시 `_changelog`에 기록

---

## 품질 게이트

### create 시 자동 검증

| 거부 조건 | 이유 |
|-----------|------|
| content 키 5개 미만 | 최소 type + 3개 실질 필드 |
| 텍스트 200자 미만 | 요약 수준 부족 |
| source 0개 | 검증 불가 |
| type 필드 누락 | 템플릿 매칭 불가 |
| _v 0개 | 검증 메타데이터 필수 |

### --force 패널티

- confidence → 0.5 이하 자동 설정
- `_meta.maturity` → `stub` 강제
- `_meta.missing_fields`에 미충족 조건 자동 기록
- 다음 `lint` 실행 시 경고 노출

---

## Hub-Spoke 구조 (300줄 초과 시 분할)

### 분할 기준

- content YAML 직렬화 **300줄 초과** 시 분할 고려
- 하위 주제가 **독립적으로 검색될 가능성** 높으면 분할

### Hub-Spoke 패턴

```
[Hub 문서: tech-react-overview-xxx]
  ├── related: tech-react-hooks-yyy        (Spoke 1)
  ├── related: tech-react-server-comp-zzz  (Spoke 2)
  └── related: tech-react-performance-www  (Spoke 3)
```

Hub content에 `spokes` 필드:
```yaml
spokes:
  - id: tech-react-hooks-yyy
    summary: "React Hooks API 상세"
  - id: tech-react-server-comp-zzz
    summary: "Server Components 아키텍처"
```

### 분할 절차

1. 기존 문서를 Hub로 리팩터 (상세 내용 제거, 요약 + spokes 추가)
2. 각 하위 주제를 별도 문서로 `create`
3. Hub와 모든 Spoke에 양방향 `related` 설정
4. `ai-wiki lint`로 링크 정합성 확인
