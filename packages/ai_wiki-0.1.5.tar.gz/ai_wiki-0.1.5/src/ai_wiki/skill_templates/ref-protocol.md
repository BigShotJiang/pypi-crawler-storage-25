# version: 1.1.0
# 문서 작성 프로토콜 + 검증 (상세)

> SKILL.md에서 `Read("ref-protocol.md")`로 참조. 핵심 규칙은 SKILL.md Core에 있음.

## 3-Phase Pipeline 상세

### Phase 1: 조사 설계

**목적**: 뛰어들기 전에 지도를 그린다.

1. **기존 문서 확인**: `ai-wiki search "주제 키워드"`로 이미 존재하는 관련 문서를 모두 확인한다.
2. **3단계 목차 설계**: 문서에 들어갈 대주제 → 중주제 → 소주제를 계층적으로 설계한다. YAML 필드명으로 직접 매핑되어야 한다.
3. **질문 20개 생성**: 이 주제에 대해 전문가가 물을 법한 질문 20개를 만든다. 이 질문들이 문서의 완성도 기준이 된다. 모든 질문에 답할 수 있어야 문서가 완성된 것이다.

### Phase 2: AI지식 초안 → 웹검증 (2단계)

**이 Phase가 AI Wiki의 핵심 차별점이다. 위키백과 복사도 아니고, AI 환각도 아닌, 검증된 지식을 생산한다.**

#### Step 1: AI 학습 지식으로 초안 작성

먼저 **웹 검색 없이** AI가 알고 있는 모든 것을 YAML로 구조화한다.

- "요약하지 마라. 축약하지 마라. 압축을 해제하라."
- 학습 데이터에서 이 주제에 대해 습득한 지식의 전체 범위를 출력한다.
- 이 단계에서 수치/날짜는 정확하지 않을 수 있다 — **괜찮다. Step 2에서 검증한다.**

#### Step 2: 3단계 검증 (Level 1→2→3 에스컬레이션)

Step 1에서 작성한 내용 중 **구체적 수치, 날짜, 인용문, 고유명사**를 검증한다.

```
Level 1 (기본): WebSearch → 출처 URL 확보 + 수치 교차 확인
Level 2 (보통): WebFetch → URL 상세 내용 추출 (위키백과, 뉴스, 공식 문서)
Level 3 (심층): Playwright CLI → 1차 사료 (Google Books, Internet Archive, JS 사이트)
```

**에스컬레이션 규칙:**
- 일반 수치(가격, 영양성분 등) → Level 1~2로 충분
- 학술 논쟁/통설 검증 → Level 2 + 복수 출처 교차
- 1차 사료 원문 확인 → **Level 3 (Playwright)** 사용

```
검증 결과 기록:
1. AI 주장을 나열한다
2. 각 주장을 Level 1부터 검증한다
3. 일치하면 → 출처를 _v에 기록, level: corroborated
4. 불일치하면 → 웹 검증 결과로 수정 + _v.note에 "AI 원래 주장: X, 웹 검증: Y"
5. Level 1~2에서 못 찾으면 → Level 3 (Playwright) 시도
6. 모든 Level에서 못 찾으면 → level: ai_knowledge, note에 "웹 검증 미완"
```

**예시 (쭈꾸미 타우린 검증):**
```yaml
taurine: "100g당 약 1,300mg (코메디닷컴/농촌진흥청 기준)"
taurine_v:
  level: corroborated
  sources: ["코메디닷컴 '봄철 주꾸미가 좋은 이유'"]
  note: "AI 원래 주장 1,600mg → 웹 검증 1,305mg으로 수정. 1,300~1,600mg 범위."
```

### Phase 3: 자기 비평 + 보강

1. **전문가 시각 점검**: "이 분야 10년차 전문가가 이 문서를 읽으면 무엇이 부족하다고 느낄까?"
2. **Phase 1 질문 재검토**: 처음 생성한 20개 질문을 다시 확인. 미답변은 `_meta.missing_fields`로 명시.
3. **quality 명령 실행**: `ai-wiki quality <id>`로 품질 점수 확인. 70점 미만이면 즉시 보강.

---

## 95% 품질 표준 (Deep Research Mode)

```
필수 조건:
1. 모든 TIER 2 팩트(수치/날짜/인용문)가 웹 검증됨 → _v.level: corroborated 이상
2. 1차 사료 최소 1개 직접 확인 (법률 원문, 논문, 공식 문서)
3. 복수 출처(2개+) 교차 검증
4. _v.level: ai_knowledge인 팩트가 0개
5. 모든 _v에 출처 URL 또는 문서명 명시
```

---

## 팩트 검증 프로토콜

### 검증 티어 분류

| 티어 | 설명 | confidence 범위 | 예시 |
|------|------|-----------------|------|
| TIER 1 | 1차 자료, 공식 문서, 원저자 발언 | 0.9 ~ 1.0 | 공식 API 문서, 논문 원문, 법률 원문 |
| TIER 2 | 신뢰할 수 있는 2차 자료 | 0.7 ~ 0.89 | 교과서, 위키피디아(검증된 항목), 전문 리뷰 |
| TIER 3 | 간접 자료, 커뮤니티, 추정 | 0.5 ~ 0.69 | 블로그, Stack Overflow 답변, 포럼 의견 |
| 미검증 | 출처 없음 또는 추정 | 0.5 미만 | 기억에 의존, 출처 불명, 추론 |

### _v 메타데이터 컨벤션

```yaml
facts:
  - text: "GPT-4의 파라미터 수는 약 1.76T로 추정된다"
    _v:
      level: TIER3
      sources:
        - "https://the-decoder.com/gpt-4-architecture-datasets-costs-and-more-leaked/"
      note: "공식 미확인. 유출 정보 기반 추정치."
      verified_at: "2024-06-15"
```

### disputes 구조

```yaml
disputes:
  - claim: "Scaling law는 데이터/연산량 증가만으로 AGI에 도달할 수 있다"
    supporters: ["Ilya Sutskever (2023 이전)", "OpenAI scaling team"]
    counterclaim: "Scaling만으로는 reasoning/planning 능력에 한계가 있다"
    counter_supporters: ["Yann LeCun", "Gary Marcus"]
    status: "ongoing"  # resolved | ongoing | evolving
    evidence_for: ["GPT-4 성능 향상 추세", "Chinchilla scaling law"]
    evidence_against: ["ARC benchmark 정체", "hallucination 미해결"]
```

### historiography 구조

```yaml
historiography:
  - period: "2017-2020"
    consensus: "Transformer는 NLP 전용 아키텍처"
    key_papers: ["Attention Is All You Need (2017)"]
  - period: "2020-2023"
    consensus: "Transformer는 범용 시퀀스 모델 (Vision, Audio 포함)"
    key_papers: ["ViT (2020)", "Whisper (2022)"]
    shift_reason: "ViT의 성공으로 CV 커뮤니티가 Transformer 채택"
```

### 반-요약 지시 (Anti-Summarization Directive)

나쁜 예:
```yaml
facts:
  - Transformer는 attention 메커니즘을 사용한다
```

좋은 예:
```yaml
facts:
  - "Transformer(Vaswani et al., 2017)는 self-attention 메커니즘으로 입력 시퀀스의 모든 위치 쌍 간 관계를 O(1) 순차 연산으로 계산한다. RNN의 O(n) 순차 의존성을 제거하여 학습 병렬화가 가능해졌고, WMT 2014 EN-DE 번역에서 이전 SOTA 대비 BLEU +2.0 향상(28.4)을 달성했다."
```

### Specificity Anchoring 패턴

모든 서술에 다음 중 최소 하나를 포함:
- **숫자**: 성능 수치, 비율, 크기, 비용
- **날짜**: 출시일, 논문 발표일, 정책 시행일
- **이름**: 저자, 기관, 프로젝트명
- **버전**: 소프트웨어 버전, API 버전
- **출처**: URL, 논문 ID, 공식 문서 경로

### 깊이 체크리스트 (각 필드 작성 시)

- [ ] 이 필드에 숫자/날짜/버전이 포함되어 있는가? (Specificity Anchoring)
- [ ] WHY를 설명했는가? (원인/배경/동기)
- [ ] HOW를 설명했는가? (메커니즘/절차/방법)
- [ ] 반례/예외/한계를 언급했는가?
- [ ] 실제 사례나 예시를 포함했는가?
- [ ] **구체적 수치는 웹 검증했는가?** (Step 2)
