# version: 1.1.0
# 문서 타입별 YAML 템플릿 (9종)

> SKILL.md에서 `Read("ref-templates.md")`로 참조. 새 문서 생성 시 해당 type의 템플릿을 확인.

모든 템플릿에 `_meta`와 `_changelog`를 포함한다.

## technology (기술/프레임워크)
```yaml
type: technology
language: python
what: "한 줄 설명 (구체적으로, 비교 대상 포함)"
version: "3.2.0"
released: "2024-01-15"
facts:
  - "구체적 사실 (숫자/날짜/출처 포함)"
use_cases:
  - "사용처 + 왜 적합한지 이유"
limitations:
  - "제약사항 + 영향 범위"
workarounds:
  - "우회방법 + 적용 조건"
best_practices:
  - "권장사항 + 근거"
alternatives:
  - name: "대안 기술명"
    comparison: "이 기술 대비 장단점"
```

## troubleshooting (문제 해결)
```yaml
type: troubleshooting
error_message: "정확한 에러 메시지 (전체 복사)"
environment:
  os: "Windows 10 Pro 10.0.19045"
  language: "Python 3.13.2"
  framework: "FastAPI 0.109.0"
  dependencies: ["pydantic==2.5.3"]
root_cause: "근본 원인 (WHY까지 설명)"
diagnosis_steps:
  - "원인을 찾기까지의 디버깅 과정"
solution:
  - "해결 단계 (순서대로, 복붙 가능하게)"
prevention: "재발 방지 방법"
related_errors:
  - "비슷하지만 다른 에러와의 구분법"
```

## event (역사적 사건)
```yaml
type: event
period: "1950-06-25 ~ 1953-07-27"
location: "한반도"
participants: ["대한민국", "북한", "미국", "중국", "UN"]
facts:
  - "구체적 사실 (날짜 + 장소 + 수치 포함)"
causes:
  - immediate: "직접 원인"
    underlying: "구조적/장기적 원인"
consequences:
  - short_term: "단기적 결과"
    long_term: "장기적 영향"
common_misconceptions:
  - myth: "흔한 오해"
    reality: "실제 사실 + 출처"
historiography:
  - period: "1950s"
    consensus: "당시 해석"
  - period: "2020s"
    consensus: "현재 해석"
```

## concept (개념/이론)
```yaml
type: concept
domain: "economics"
definition: "엄밀한 정의 (학술적, 출처 포함)"
key_principles:
  - "원리 + 수식/모델 포함 가능"
examples:
  - context: "적용 맥락"
    description: "구체적 예시"
applications:
  - "실제 적용 분야 + 사례"
debates:
  - "이 개념에 대한 학술적 논쟁"
related_concepts:
  - name: "관련 개념"
    relationship: "상위/하위/대립/보완"
```

## policy (정책/법률/제도)
```yaml
type: policy
jurisdiction: "대한민국"
effective_date: "2024-01-01"
status: "active"  # active | amended | repealed | proposed
purpose: "제정 목적 + 배경"
key_provisions:
  - article: "조항 번호"
    content: "조항 내용"
    interpretation: "실무적 해석"
impact:
  - sector: "영향 받는 분야"
    description: "구체적 영향"
enforcement:
  - "집행 기관 및 방식"
disputes:
  - "위헌 소송, 해석 논쟁 등"
```

## person (인물)
```yaml
type: person
birth: "1900-01-01"
death: "1999-12-31"
nationality: "대한민국"
roles: ["정치인", "독립운동가"]
key_achievements:
  - year: 1919
    achievement: "업적 상세 (구체적 맥락 포함)"
timeline:
  - period: "1919"
    event: "3.1운동 참여"
    significance: "이 사건의 의미"
controversies:
  - "논쟁적 사항 (다중 관점 포함)"
legacy:
  - "후대에 미친 영향"
```

## api_reference (API 레퍼런스)
```yaml
type: api_reference
service: "OpenAI"
base_url: "https://api.openai.com/v1"
api_version: "2024-01-01"
auth:
  type: "Bearer token"
  header: "Authorization"
endpoints:
  - path: "/chat/completions"
    method: "POST"
    description: "채팅 완성 생성"
    params:
      model: {required: true, type: "string", example: "gpt-4"}
      messages: {required: true, type: "array"}
    response_format: "JSON (choices[].message.content)"
    error_codes:
      - code: 429
        meaning: "Rate limit 초과"
        solution: "exponential backoff 적용"
rate_limits:
  rpm: 500
  tpm: 30000
pricing:
  input: "$10/1M tokens"
  output: "$30/1M tokens"
gotchas:
  - "주의할 점 (공식 문서에 없는 실무 팁)"
```

## synthesis (통합/파생)
```yaml
type: synthesis
question: "답변한 질문 (구체적으로)"
answer: "핵심 답변 (요약 아님, 충분히 상세하게)"
derived_from:
  - "원본문서id1"
  - "원본문서id2"
insight: "원본 문서에는 없는 새로운 통찰"
methodology: "어떤 분석 과정을 거쳤는지"
confidence_note: "이 통찰의 확실성에 대한 자기 평가"
```

## comparison (비교 분석)
```yaml
type: comparison
what: "React vs Vue vs Svelte 프론트엔드 프레임워크 비교"
subjects:
  - name: "React"
    version: "18.2"
  - name: "Vue"
    version: "3.4"
  - name: "Svelte"
    version: "4.0"
criteria:
  - "학습 곡선"
  - "번들 크기"
  - "생태계 크기"
  - "성능 (렌더링 벤치마크)"
comparison_table:
  - criterion: "학습 곡선"
    React: "중간 (JSX + hooks 개념)"
    Vue: "낮음 (템플릿 기반)"
    Svelte: "낮음 (컴파일러 기반, 보일러플레이트 최소)"
winner_by_use_case:
  - use_case: "대규모 엔터프라이즈"
    winner: "React"
    reason: "생태계, 인력 풀, Meta 지원"
  - use_case: "빠른 프로토타이핑"
    winner: "Svelte"
    reason: "최소 보일러플레이트, 빌드 속도"
conclusion: "핵심 결론 (상황별 추천)"
caveats:
  - "벤치마크는 특정 시나리오에서만 유효"
```

## tutorial (단계별 튜토리얼)
```yaml
type: tutorial
what: "Docker로 Python FastAPI 앱 배포하기"
goal: "로컬 FastAPI 앱을 Docker 컨테이너로 빌드하고 실행"
difficulty: "beginner"  # beginner | intermediate | advanced
time_estimate: "30분"
prerequisites:
  - "Docker Desktop 설치 (v24+)"
  - "Python 3.11+"
  - "FastAPI 프로젝트 (main.py + requirements.txt)"
steps:
  - step: 1
    title: "Dockerfile 작성"
    action: "프로젝트 루트에 Dockerfile 생성"
    code: |
      FROM python:3.11-slim
      WORKDIR /app
      COPY requirements.txt .
      RUN pip install -r requirements.txt
      COPY . .
      CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
    explanation: "slim 이미지로 크기 최소화, requirements 먼저 복사하여 캐시 활용"
  - step: 2
    title: "빌드 및 실행"
    action: "docker build -t myapp . && docker run -p 8000:8000 myapp"
common_mistakes:
  - mistake: "COPY . . 전에 requirements.txt를 복사하지 않음"
    consequence: "코드 변경마다 pip install 재실행 (빌드 느림)"
    fix: "requirements.txt를 먼저 COPY → RUN pip install → 나머지 COPY"
next_steps:
  - "docker-compose로 DB 연동"
  - "GitHub Actions CI/CD 연동"
working_example: "https://github.com/example/fastapi-docker-template"
```

## ingested (원본 파일 ingest)
```yaml
type: ingested
original_filename: "paper.pdf"
file_type: "pdf"
file_size_bytes: 1234567
status: "pending_review"
notes: "LLM이 원본 파일을 분석하여 content를 채워야 합니다"
```
