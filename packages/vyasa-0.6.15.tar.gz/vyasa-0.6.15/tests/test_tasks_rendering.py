from fasthtml.common import to_xml
from textwrap import dedent

from vyasa.extensions_builtin.markdown.renderer import from_md


def test_tasks_block_renders_widget_payload_and_summary():
    md = """```tasks
title: Hybrid Task Rendering
foundation :: Foundation:
  - t1 :: Define graph payload
```"""

    html = to_xml(from_md(md))

    assert 'class="tasks-container' in html
    assert 'data-tasks-widget="true"' in html
    assert '"graph_id": "hybrid-task-rendering-' in html
    assert '"label": "Foundation"' in html
    assert "1 groups, 1 items, 0 edges" in html


def test_tasks_block_invalid_body_falls_back_to_empty_payload():
    md = """```tasks
id: broken
groups: [oops
```"""

    html = to_xml(from_md(md))

    assert 'class="tasks-container' in html
    assert '"groups": []' in html
    assert '"tasks": []' in html


def test_tasks_block_reads_frontmatter_options():
    md = """```tasks
---
title: Gateway Policies
default_open_depth: 2
width: 70vw
height: 60vh
---
foundation :: Foundation:
```"""

    html = to_xml(from_md(md))

    assert 'data-tasks-title="Gateway Policies"' in html
    assert 'data-tasks-default-open-depth="2"' in html
    assert 'style="width: 70vw; min-height: 85vh;' in html
    assert 'height:60vh;min-height:420px' in html


def test_tasks_block_breaks_out_for_full_width():
    md = """```tasks
---
title: Full Width Tasks
width: 100%
---
foundation :: Foundation:
```"""

    html = to_xml(from_md(md))

    assert 'style="width: 100%; min-height: 85vh; position: relative; left: 50%; transform: translateX(-50%);"' in html


def test_tasks_block_serializes_labeled_edges():
    md = dedent("""\
    ```items
    foundation :: Foundation:
      - t1 :: Parse graph
      - t2 :: Render graph
    t1 ->|feeds UI| t2
    ```
    """)

    html = to_xml(from_md(md))

    assert '"dependency_edges": [{"source": "t1", "target": "t2", "label": "feeds UI"}]' in html


def test_tasks_block_reads_frontmatter_id_and_color_palette():
    md = """```tasks
---
id: roadmap-demo
title: Roadmap
color_palette: phase
  Phase 1: "#2563eb"
  Phase 2: "#d97706"
---
foundation :: Foundation:
  - t1 :: Define graph payload | phase: Phase 1
```"""

    html = to_xml(from_md(md))

    assert '"graph_id": "roadmap-demo"' in html
    assert '"color_by": "phase"' in html
    assert '"color_palette": {"Phase 1": "#2563eb", "Phase 2": "#d97706"}' in html


def test_tasks_block_preserves_group_color_attributes():
    md = """```tasks
Foundation | color: "#8fa8d8":
  - t1 :: Define graph payload
```"""

    html = to_xml(from_md(md))

    assert '"groups": [{"id": "foundation", "label": "Foundation", "parent_group_id": null, "color": "#8fa8d8"}]' in html


def test_tasks_block_reads_quoted_boolean_palette_keys():
    md = """```tasks
---
color_by:
  critical_path:
    "true": "#e53935"
    "false": "#9e9e9e"
---
Foundation:
  - t1 :: Define graph payload | critical_path: true
```"""

    html = to_xml(from_md(md))

    assert '"color_by": "critical_path"' in html
    assert '"critical_path": {"true": "#e53935", "false": "#9e9e9e"}' in html


def test_tasks_block_reads_default_color_by():
    md = """```tasks
---
default_color_by: sprint
color_by:
  sprint:
    One: "#2563eb"
---
Foundation:
  - t1 :: Define graph payload | sprint: One
```"""

    html = to_xml(from_md(md))

    assert '"default_color_by": "sprint"' in html


def test_tasks_block_reads_edge_color_palette_and_override():
    md = """```items
---
edge_color_palette: relation
  reads: "#2563eb"
  writes: "#dc2626"
---
System:
  - api :: API
  - db :: DB
api -> db | relation: reads
db -> api | relation: writes | color: "#7c3aed"
```"""

    html = to_xml(from_md(md))

    assert '"edge_color_by": "relation"' in html
    assert '"edge_color_palette": {"reads": "#2563eb", "writes": "#dc2626"}' in html
    assert '"relation": "reads"' in html
    assert '"color": "#7c3aed"' in html


def test_tasks_block_reads_filter_attributes():
    md = """```items
---
filter_attributes: [owner, status]
---
Foundation:
  - t1 :: Define graph payload | owner: Alice | status: Active | priority: High
```"""

    html = to_xml(from_md(md))

    assert '"filter_attributes": ["owner", "status"]' in html
