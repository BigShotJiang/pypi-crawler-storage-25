from vyasa.extensions_builtin.slides.deck import (
    build_slide_reveal_units,
    inject_reveal_directives,
    resolve_slide_reveal_config,
    split_markdown_paragraph_groups,
    split_top_level_html,
)


def test_slide_reveal_config_defaults_to_staggered_paragraph_groups():
    cfg = resolve_slide_reveal_config({})

    assert cfg.enabled is True
    assert cfg.unit == "paragraph-groups"
    assert cfg.style == "slide-right"
    assert cfg.policy == "step"
    assert cfg.stagger_ms == 220
    assert cfg.duration_ms == 420
    assert cfg.distance == "1.75rem"


def test_slide_reveal_config_can_disable_feature():
    cfg = resolve_slide_reveal_config({"slide_reveal": "off"})

    assert cfg.enabled is False


def test_inject_reveal_directive_converts_comment_to_marker():
    md = "Before\n\n<!-- reveal style=fade delay=180 -->\n\nAfter"

    out = inject_reveal_directives(md)

    assert '<vyasa-reveal data-style="fade" data-delay="180"></vyasa-reveal>' in out


def test_split_top_level_html_keeps_sibling_blocks_separate():
    fragment = "<p>One</p><div><p>Two</p></div><ul><li>Three</li></ul>"

    chunks = split_top_level_html(fragment)

    assert chunks == ["<p>One</p>", "<div><p>Two</p></div>", "<ul><li>Three</li></ul>"]


def test_paragraph_group_split_is_blank_line_based():
    md = "First para\n\nSecond para\n\n- item one\n- item two"

    groups = split_markdown_paragraph_groups(md)

    assert groups == ["First para", "Second para", "- item one", "- item two"]


def test_paragraph_group_split_keeps_opening_heading_separate_from_first_body_block():
    md = "## Intro\n\nFirst para\n\nSecond para"

    groups = split_markdown_paragraph_groups(md)

    assert groups == ["## Intro", "First para", "Second para"]


def test_build_slide_reveal_units_supports_top_level_directive_override():
    md = "Alpha\n\n<!-- reveal style=fade delay=180 -->\n\nBeta"

    def fake_render_fragment(text, current_path=None, slide_mode=False):
        parts = []
        for chunk in text.split("\n\n"):
            stripped = chunk.strip()
            if not stripped:
                continue
            if stripped.startswith("<vyasa-reveal"):
                parts.append(stripped)
            else:
                parts.append(f"<p>{stripped}</p>")
        return "".join(parts)

    units = build_slide_reveal_units(
        md,
        render_fragment=fake_render_fragment,
        current_path="demo/slides",
        config=resolve_slide_reveal_config({}),
    )

    assert len(units) == 2
    assert units[0]["html"] == "<p>Alpha</p>"
    assert units[1]["html"] == "<p>Beta</p>"
    assert units[1]["style"] == "fade"
    assert units[1]["delay"] == "180"


def test_build_slide_reveal_units_marks_heading_only_groups():
    md = "## Intro\n\n### Detail\n\nBody"

    units = build_slide_reveal_units(
        md,
        render_fragment=lambda text, current_path=None, slide_mode=False: f"<p>{text}</p>",
        current_path="demo/slides",
        config=resolve_slide_reveal_config({}),
    )

    assert [unit["kind"] for unit in units] == ["heading", "heading", "content"]


def test_paragraph_group_split_attaches_list_to_leading_paragraph():
    md = "Lead in\n\n- item one\n- item two\n\nAfterward"

    groups = split_markdown_paragraph_groups(md)

    assert groups == ["Lead in", "- item one", "- item two", "Afterward"]


def test_paragraph_group_split_breaks_inline_paragraph_plus_list_into_multiple_units():
    md = "Lead in line\n- item one\n- item two"

    groups = split_markdown_paragraph_groups(md)

    assert groups == ["Lead in line", "- item one", "- item two"]


def test_paragraph_group_split_ignores_horizontal_rules_outside_fences():
    md = "First para\n\n---\n\nSecond para"

    groups = split_markdown_paragraph_groups(md)

    assert groups == ["First para", "Second para"]


def test_paragraph_group_split_preserves_mermaid_frontmatter_fences():
    md = """```mermaid
---
title: Deck flow
---
flowchart TD
    A --> B
```"""

    groups = split_markdown_paragraph_groups(md)

    assert groups == [md]


def test_paragraph_group_split_preserves_items_fences_with_frontmatter_and_lists():
    md = """```items
---
title: Vyasa Architecture
---
- cli :: CLI + Config Bootstrap
- app :: FastHTML Runtime Core

cli -> app
```"""

    groups = split_markdown_paragraph_groups(md)

    assert groups == [md]
