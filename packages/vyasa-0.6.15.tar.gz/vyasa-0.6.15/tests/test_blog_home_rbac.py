from pathlib import Path
from types import SimpleNamespace

from fasthtml.common import Div, P, to_xml

from vyasa.config import reload_config
import vyasa.content_routes as content_routes
import vyasa.core as core


def _write_post(root: Path, name: str, body: str) -> Path:
    path = root / f"{name}.md"
    path.write_text(body, encoding="utf-8")
    return path


def test_home_feed_hides_unauthorized_items_and_keeps_public_posts(monkeypatch, tmp_path):
    public = _write_post(tmp_path, "public", "# Public\n\nVisible")
    secret = _write_post(tmp_path, "secret", "# Secret\n\nHidden")

    monkeypatch.setattr(core, "iter_visible_files", lambda root, suffixes, include_hidden=False: [public, secret])
    monkeypatch.setattr(core, "content_slug_for_path", lambda path: path.stem)
    monkeypatch.setattr(core, "_rbac_rules", [])
    monkeypatch.setattr(core, "is_allowed", lambda path, roles, rules: path != "/posts/secret")

    entries = list(core.iter_blog_home_files([("", tmp_path)], roles=["reader"]))
    html = to_xml(core.render_blog_home_feed(entries, tmp_path, 0))

    assert public in [item[0] for item in entries]
    assert secret not in [item[0] for item in entries]
    assert "Secret" not in html
    assert "Visible" in html
    assert "placeholder" not in html.lower()


def test_home_feed_keeps_public_browsing_when_roles_are_absent(monkeypatch, tmp_path):
    _write_post(tmp_path, "public", "# Public\n\nVisible")

    monkeypatch.setattr(core, "iter_visible_files", lambda root, suffixes, include_hidden=False: [tmp_path / "public.md"])
    monkeypatch.setattr(core, "content_slug_for_path", lambda path: path.stem)
    monkeypatch.setattr(core, "_rbac_rules", [])

    entries = list(core.iter_blog_home_files([("", tmp_path)], roles=None))

    assert len(entries) == 1
    assert entries[0][1] == "public"


def test_preview_markdown_uses_more_marker_and_five_block_fallback():
    assert core.preview_markdown("a\n\n<!-- more -->\n\nb") == "a"
    assert core.preview_markdown("\n\n".join(f"b{i}" for i in range(1, 7))) == "\n\n".join(f"b{i}" for i in range(1, 6))


def test_preview_markdown_keeps_fenced_tasks_block_intact():
    text = "\n\n".join([
        "one",
        "```tasks\nproject Alpha\n\nteam Platform\n- ship graph\n```",
        "three",
        "four",
        "five",
        "six",
    ])
    preview = core.preview_markdown(text)
    assert "```tasks" in preview
    assert "ship graph" in preview
    assert preview.count("```") == 2
    assert "six" not in preview


def test_home_feed_renders_newest_posts_first(monkeypatch, tmp_path):
    older = _write_post(tmp_path, "older", "# Older\n\nBody")
    newer = _write_post(tmp_path, "newer", "# Newer\n\nBody")

    monkeypatch.setattr(core, "get_content_mounts", lambda: [("", tmp_path)])
    monkeypatch.setattr(core, "iter_visible_files", lambda root, suffixes, include_hidden=False: [older, newer])
    monkeypatch.setattr(core, "content_slug_for_path", lambda path: path.stem)
    monkeypatch.setattr(core, "get_file_created_ts", lambda path: {"older.md": 1.0, "newer.md": 2.0}[path.name])
    monkeypatch.setattr(core, "get_roles_from_auth", lambda *args, **kwargs: None)
    monkeypatch.setattr(core, "layout", lambda body, **kwargs: body)
    monkeypatch.setattr(core, "render_blog_home_feed", lambda entries, root, offset=0, batch_size=4, wrap=True: Div(*[P(slug) for _, slug in entries]))

    html = to_xml(core.render_blog_home(htmx=False, request=type("Req", (), {"scope": {"auth": None}})()))
    assert html.index("newer") < html.index("older")


def test_post_detail_hides_more_marker_in_normal_render(monkeypatch, tmp_path):
    post = _write_post(tmp_path, "post", "# Title\n\nAbove\n\n<!-- more -->\n\nBelow")
    request = type("Req", (), {"scope": {"auth": None}})()

    monkeypatch.setattr(content_routes, "content_root_and_relative", lambda path: (tmp_path, Path(path)))
    monkeypatch.setattr(content_routes, "content_path_for_slug", lambda path, suffix=".md": post)

    html = to_xml(content_routes.render_post_detail(
        "post",
        htmx=False,
        request=request,
        get_root_folder=lambda: tmp_path,
        effective_abbreviations=lambda root: {},
        find_folder_note_file=lambda folder: None,
        slug_to_title=lambda value, abbreviations=None: value.title(),
        layout=lambda body, **kwargs: body,
        get_blog_title=lambda: "Blog",
        not_found=lambda *args, **kwargs: "NF",
        parse_frontmatter=lambda file_path: ({}, file_path.read_text(encoding="utf-8")),
        resolve_markdown_title=lambda file_path, abbreviations=None: ("Title", file_path.read_text(encoding="utf-8")),
        from_md=core.from_md,
        logger=core.logger,
    ))

    assert "<!-- more -->" not in html
    assert "Below" in html


def test_home_feed_honors_name_sort_from_vyasa_config(monkeypatch, tmp_path):
    _write_post(tmp_path, "zephyr", "# Zephyr\n\nBody")
    _write_post(tmp_path, "aardvark", "# Aardvark\n\nBody")
    (tmp_path / ".vyasa").write_text("home_sort = \"name_asc\"\n", encoding="utf-8")
    reload_config(tmp_path / ".vyasa")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(core, "layout", lambda body, **kwargs: body)
    html = to_xml(core.render_blog_home(False, SimpleNamespace(scope={"auth": None})))
    assert html.index("Aardvark") < html.index("Zephyr")
    (tmp_path / ".vyasa").write_text("home_sort = \"name_desc\"\n", encoding="utf-8")
    reload_config(tmp_path / ".vyasa")
    html = to_xml(core.render_blog_home(False, SimpleNamespace(scope={"auth": None})))
    assert html.index("Zephyr") < html.index("Aardvark")


def test_home_feed_respects_vyasa_ignore_list(monkeypatch, tmp_path):
    keep = _write_post(tmp_path, "keep", "# Keep\n\nVisible")
    ignored = _write_post(tmp_path, "_plan", "# Plan\n\nHidden")
    skipped = _write_post(tmp_path, "LICENSE", "# License\n\nHidden")
    (tmp_path / ".vyasa").write_text('ignore = ["_plan", "LICENSE"]\n', encoding="utf-8")
    reload_config(tmp_path / ".vyasa")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(core, "layout", lambda body, **kwargs: body)
    monkeypatch.setattr(core, "get_content_mounts", lambda: [("", tmp_path)])
    html = to_xml(core.render_blog_home(False, SimpleNamespace(scope={"auth": None})))
    assert "Keep" in html
    assert "_plan" not in html
    assert "LICENSE" not in html


def test_home_feed_respects_nested_folder_ignore_list(monkeypatch, tmp_path):
    nested = tmp_path / "projects" / "drafts"
    nested.mkdir(parents=True)
    keep = _write_post(tmp_path, "visible", "# Visible\n\nBody")
    hidden = nested / "secret.md"
    hidden.write_text("# Secret\n\nHidden", encoding="utf-8")
    (tmp_path / ".vyasa").write_text('ignore = ["drafts"]\n', encoding="utf-8")
    (tmp_path / "projects" / ".vyasa").write_text('ignore = ["secret"]\n', encoding="utf-8")
    reload_config(tmp_path / ".vyasa")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(core, "layout", lambda body, **kwargs: body)
    monkeypatch.setattr(core, "get_content_mounts", lambda: [("", tmp_path)])
    html = to_xml(core.render_blog_home(False, SimpleNamespace(scope={"auth": None})))
    assert "Visible" in html
    assert "secret" not in html.lower()
