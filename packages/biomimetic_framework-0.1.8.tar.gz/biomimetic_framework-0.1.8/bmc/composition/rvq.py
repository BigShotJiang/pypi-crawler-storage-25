# bmc/composition/rvq.py
"""
SequentialRVQ — convenience wrapper for training a BMCNetwork
via Residual Vector Quantization.

This is a high-level model (like BMCClassifier) that internally
creates BMCCells and trains them using the RVQ algorithm from
bmc.core.rvq. For lower-level control, use fit_rvq() directly.
"""

import numpy as np
from typing import Optional

from bmc.core.cell import BMCCell
from bmc.core.rvq import fit_rvq, reconstruct_rvq, residual_mse_history
from bmc.core.interpolators import LinearInterpolator, Interpolator
from bmc.core.inference import normalize_distributions
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


class SequentialRVQ:
    """
    Convenience model: sequential BMC trained via RVQ.

    Internally creates a list of BMCCells, trains them with the RVQ
    algorithm (bmc.core.rvq.fit_rvq), and attaches a prediction head.

    Parameters
    ----------
    max_layers : int
        Maximum number of RVQ layers.
    k_per_layer : int
        K for each layer's BMCCells. K=2 minimum for meaningful
        interpolation.
    convergence_threshold : float
        Stop when residual MSE < this. Default 0.1.
    n_clusters_head : int or None
        K for the prediction head. Defaults to n_layers_used * k_per_layer.
    interpolator : Interpolator or None
        Template for layer interpolators. Defaults to LinearInterpolator.
    metric : SimilarityMetric, optional
    rng : np.random.Generator, optional
    """

    def __init__(
        self,
        max_layers: int = 64,
        k_per_layer: int = 2,
        convergence_threshold: float = 0.1,
        n_clusters_head: Optional[int] = None,
        interpolator: Optional[Interpolator] = None,
        metric: Optional[SimilarityMetric] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.max_layers = max_layers
        self.k_per_layer = k_per_layer
        self.convergence_threshold = convergence_threshold
        self.n_clusters_head = n_clusters_head
        self.interpolator_template = interpolator
        self.metric = metric or L2Metric()
        self.rng = rng or np.random.default_rng(42)

        self.cells_: Optional[list] = None
        self.head_: Optional[BMCCell] = None
        self.n_layers_used_: int = 0
        self.n_classes_: Optional[int] = None
        self.is_fitted_: bool = False

    def _make_cells(self):
        """Create the list of BMCCells for RVQ training."""
        cells = []
        for i in range(self.max_layers):
            interp = (LinearInterpolator() if self.interpolator_template is None
                      else type(self.interpolator_template)())
            cell = BMCCell(
                n_clusters=self.k_per_layer,
                interpolator=interp,
                metric=self.metric,
                rng=np.random.default_rng(int(self.rng.integers(0, 2**31)) + i),
            )
            cells.append(cell)
        return cells

    def _resolve_head_k(self, M):
        if self.n_clusters_head is not None:
            return min(self.n_clusters_head, M)
        return min(self.n_layers_used_ * self.k_per_layer, M)

    # ── classification ───────────────────────────────────────────────────

    def fit(self, X, y, n_classes=None):
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.int32)
        if n_classes is None:
            n_classes = int(y.max()) + 1
        self.n_classes_ = n_classes

        self.cells_ = self._make_cells()
        self.n_layers_used_ = fit_rvq(self.cells_, X, self.convergence_threshold)

        K_head = self._resolve_head_k(len(X))
        self.head_ = BMCCell(
            n_clusters=K_head, metric=self.metric,
            rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
        )
        recon = reconstruct_rvq(self.cells_[:self.n_layers_used_], X)
        self.head_.fit(recon, y, n_classes=n_classes)
        self.is_fitted_ = True
        return self

    def predict(self, X):
        self._check_fitted()
        recon = reconstruct_rvq(self.cells_[:self.n_layers_used_], np.asarray(X, dtype=np.float32))
        return self.head_.predict(recon)

    def predict_proba(self, X):
        self._check_fitted()
        recon = reconstruct_rvq(self.cells_[:self.n_layers_used_], np.asarray(X, dtype=np.float32))
        return normalize_distributions(self.head_.transform(recon))

    def transform(self, X):
        self._check_fitted()
        return reconstruct_rvq(self.cells_[:self.n_layers_used_], np.asarray(X, dtype=np.float32))

    # ── regression ───────────────────────────────────────────────────────

    def fit_regression(self, X, y):
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.float64)
        self.n_classes_ = 1

        self.cells_ = self._make_cells()
        self.n_layers_used_ = fit_rvq(self.cells_, X, self.convergence_threshold)

        K_head = self._resolve_head_k(len(X))
        interp = (LinearInterpolator() if self.interpolator_template is None
                  else type(self.interpolator_template)())
        self.head_ = BMCCell(
            n_clusters=K_head, interpolator=interp, metric=self.metric,
            rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
        )
        recon = reconstruct_rvq(self.cells_[:self.n_layers_used_], X)
        self.head_.fit_regression(recon, y)
        self.is_fitted_ = True
        return self

    def predict_regression(self, X):
        self._check_fitted()
        recon = reconstruct_rvq(self.cells_[:self.n_layers_used_], np.asarray(X, dtype=np.float32))
        return self.head_.predict_regression(recon)

    # ── diagnostics ──────────────────────────────────────────────────────

    def reconstruction_error(self, X):
        X = np.asarray(X, dtype=np.float32)
        recon = self.transform(X)
        return np.mean((X - recon) ** 2, axis=1)

    def residual_history(self, X):
        return residual_mse_history(self.cells_[:self.n_layers_used_], np.asarray(X, dtype=np.float32))

    def total_cells(self):
        if not self.is_fitted_:
            return 0
        n = sum(len(getattr(c, '_rvq_dim_cells_', [])) for c in self.cells_[:self.n_layers_used_])
        return n + (1 if self.head_ else 0)

    def total_k(self):
        if not self.is_fitted_:
            return 0
        n = sum(dc.n_clusters for c in self.cells_[:self.n_layers_used_]
                for dc in getattr(c, '_rvq_dim_cells_', []))
        return n + (self.head_.n_clusters if self.head_ else 0)

    # ── serialization ────────────────────────────────────────────────────

    def get_state(self):
        self._check_fitted()
        return {
            "model_class": "SequentialRVQ",
            "max_layers": self.max_layers,
            "k_per_layer": self.k_per_layer,
            "convergence_threshold": self.convergence_threshold,
            "n_layers_used_": self.n_layers_used_,
            "n_classes_": self.n_classes_,
            "layers_": [
                [dc.get_state() for dc in c._rvq_dim_cells_]
                for c in self.cells_[:self.n_layers_used_]
            ],
            "head_": self.head_.get_state(),
        }

    def set_state(self, state):
        self.max_layers = state["max_layers"]
        self.k_per_layer = state["k_per_layer"]
        self.convergence_threshold = state["convergence_threshold"]
        self.n_layers_used_ = state["n_layers_used_"]
        self.n_classes_ = state["n_classes_"]

        self.cells_ = []
        for layer_state in state["layers_"]:
            parent = BMCCell(n_clusters=self.k_per_layer)
            parent._rvq_dim_cells_ = []
            parent._rvq_fitted_ = True
            for dc_state in layer_state:
                dc = BMCCell(n_clusters=dc_state["n_clusters"])
                dc.set_state(dc_state)
                parent._rvq_dim_cells_.append(dc)
            self.cells_.append(parent)

        self.head_ = BMCCell(n_clusters=state["head_"]["n_clusters"])
        self.head_.set_state(state["head_"])
        self.is_fitted_ = True
        return self

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("SequentialRVQ is not fitted. Call fit() or fit_regression() first.")

    def __repr__(self):
        if self.is_fitted_:
            return (
                f"SequentialRVQ(layers={self.n_layers_used_}, k={self.k_per_layer}, "
                f"total_k={self.total_k()}, status=fitted)"
            )
        return f"SequentialRVQ(max_layers={self.max_layers}, k={self.k_per_layer}, status=unfitted)"
