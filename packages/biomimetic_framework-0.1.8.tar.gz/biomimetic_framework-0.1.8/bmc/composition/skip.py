# bmc/composition/skip.py
"""
BMCSkipConnection — adaptive mesh refinement for BMC.

When a BMCCell (Layer 1) has impure Voronoi cells — regions where the
stored value poorly represents the cell's training points — a skip
connection adds a specialist BMCCell (Layer 2) for those regions.

Works for both classification and regression via separate fit methods,
following the same pattern as BMCCell (fit / fit_regression).

Impurity is measured at the cell aggregation level:
    - Classification: entropy of P(class|cell)
    - Regression: within-cell variance normalized by global variance

Architecture:
    Layer 1 (L1): Main BMCCell, trained on all data. Frozen after fit.
    Gate:         Tiny BMCCell on L1's 1D arc-length space. Learns which
                  geodesic positions are impure and routes accordingly.
                  Always binary classification (pure=0, impure=1).
    Layer 2 (L2): Specialist BMCCell, trained only on the training points
                  that fell into L1's impure cells. Operates on the original
                  input space (skip connection — not on L1's output).

Usage (classification):
    skip = BMCSkipConnection(BMCCell(n_clusters=64), n_clusters_l2=32)
    skip.fit(X_train, y_train)
    preds = skip.predict(X_test)

Usage (regression):
    skip = BMCSkipConnection(BMCCell(n_clusters=64), n_clusters_l2=32)
    skip.fit_regression(X_train, y_train)
    preds = skip.predict_regression(X_test)
"""

import numpy as np
from typing import Optional

from bmc.core.cell import BMCCell
from bmc.core.seeding import assign_clusters
from bmc.core.inference import predict, normalize_distributions
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


def _cell_entropy(lut_row):
    """Shannon entropy of a single LUT row in bits."""
    p = lut_row[lut_row > 0]
    return -np.sum(p * np.log2(p))


class BMCSkipConnection:
    """
    Skip connection over a BMCCell: L1 + Gate + L2.

    Parameters
    ----------
    layer1 : BMCCell
        The primary cell. Can be pre-fitted or unfitted.
    n_clusters_l2 : int or None
        Number of Voronoi cells for Layer 2. If None, defaults to the
        number of training points in L1's impure cells.
    impurity_threshold : float
        Cells with impurity > threshold are considered impure.
        For classification, 0.0 means any entropy = impure.
        For regression, a small positive value (e.g., 0.05) filters
        cells where variance is < 5% of global variance.
    metric : SimilarityMetric, optional
    rng : np.random.Generator, optional

    Attributes (set after fit / fit_regression)
    ----------
    layer1_ : BMCCell
    gate_ : BMCCell or None
    layer2_ : BMCCell or None
    has_skip_ : bool
    n_impure_cells_ : int
    n_routed_points_ : int
    impure_mask_ : ndarray, (K_l1,), bool
    cell_impurity_ : ndarray, (K_l1,), float64
    is_fitted_ : bool
    """

    def __init__(
        self,
        layer1: BMCCell,
        n_clusters_l2: Optional[int] = None,
        impurity_threshold: float = 0.0,
        metric: Optional[SimilarityMetric] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.layer1 = layer1
        self.n_clusters_l2 = n_clusters_l2
        self.impurity_threshold = impurity_threshold
        self.metric = metric if metric is not None else L2Metric()
        self.rng = rng if rng is not None else np.random.default_rng(42)

        self.layer1_: Optional[BMCCell] = None
        self.gate_: Optional[BMCCell] = None
        self.layer2_: Optional[BMCCell] = None
        self.has_skip_: bool = False
        self.n_impure_cells_: int = 0
        self.n_routed_points_: int = 0
        self.impure_mask_: Optional[np.ndarray] = None
        self.cell_impurity_: Optional[np.ndarray] = None
        self.n_classes_: Optional[int] = None
        self.is_fitted_: bool = False

    # ── gate + L2 training (shared) ──────────────────────────────────────

    def _fit_gate_and_l2(self, X, y, assignments, fit_l2_fn):
        """
        Train the gate and L2 given a computed impure_mask_.

        Parameters
        ----------
        X : ndarray, (M, D)
        y : ndarray, (M,)
        assignments : ndarray, (M,), int — L1 cell assignments
        fit_l2_fn : callable — function(cell, X, y) that fits L2
        """
        self.n_impure_cells_ = int(self.impure_mask_.sum())

        if self.n_impure_cells_ == 0:
            self.has_skip_ = False
            self.gate_ = None
            self.layer2_ = None
            self.n_routed_points_ = 0
            self.is_fitted_ = True
            return

        self.has_skip_ = True

        # Collect impure points
        impure_point_mask = self.impure_mask_[assignments]
        X_impure = X[impure_point_mask]
        y_impure = y[impure_point_mask]
        self.n_routed_points_ = len(X_impure)

        if self.n_routed_points_ == 0:
            # Impure cells exist but have no training points (empty cells)
            self.has_skip_ = False
            self.gate_ = None
            self.layer2_ = None
            self.is_fitted_ = True
            return

        # Gate: binary classifier on arc-lengths
        K_l1 = len(self.layer1_.seeds_)
        gate_X = self.layer1_.arc_lengths_[assignments].reshape(-1, 1).astype(np.float32)
        gate_y = self.impure_mask_[assignments].astype(np.int32)

        self.gate_ = BMCCell(
            n_clusters=K_l1,
            metric=L2Metric(),
            rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
        )
        self.gate_.fit(gate_X, gate_y, n_classes=2)

        # L2: specialist on impure points
        K_l2 = self.n_clusters_l2
        if K_l2 is None:
            K_l2 = len(X_impure)
        K_l2 = min(K_l2, len(X_impure))

        self.layer2_ = BMCCell(
            n_clusters=K_l2,
            metric=self.metric,
            rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
        )
        fit_l2_fn(self.layer2_, X_impure, y_impure)

        self.is_fitted_ = True

    # ── routing (shared) ─────────────────────────────────────────────────

    def _route(self, X):
        """Returns (l1_mask, l2_mask) from gate."""
        assignments_l1 = assign_clusters(
            X, self.layer1_.seeds_, self.layer1_.metric
        )
        arc_positions = self.layer1_.arc_lengths_[assignments_l1]
        arc_queries = arc_positions.reshape(-1, 1).astype(np.float32)
        gate_decisions = self.gate_.predict(arc_queries)
        return (gate_decisions == 0), (gate_decisions == 1)

    # ── classification ───────────────────────────────────────────────────

    def fit(self, X, y, n_classes=None):
        """
        Fit for classification.

        Parameters
        ----------
        X : ndarray, (M, D)
        y : ndarray, (M,), int
        n_classes : int, optional
        """
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.int32)
        if n_classes is None:
            n_classes = int(y.max()) + 1
        self.n_classes_ = n_classes

        # Fit L1
        self.layer1_ = self.layer1
        if not getattr(self.layer1_, 'is_fitted_', False):
            self.layer1_.fit(X, y, n_classes=n_classes)

        # Impurity: entropy of each cell's class distribution
        K_l1 = len(self.layer1_.seeds_)
        assignments = assign_clusters(X, self.layer1_.seeds_, self.layer1_.metric)
        cell_counts = np.bincount(assignments, minlength=K_l1)
        self.cell_impurity_ = np.array([
            _cell_entropy(self.layer1_.lut_[k]) if cell_counts[k] > 0 else 0.0
            for k in range(K_l1)
        ])
        self.impure_mask_ = self.cell_impurity_ > self.impurity_threshold
        self._fit_gate_and_l2(
            X, y, assignments,
            lambda cell, Xi, yi: cell.fit(Xi, yi, n_classes=n_classes),
        )
        return self

    def predict(self, X):
        """Predict class labels."""
        self._check_fitted()
        X = np.asarray(X, dtype=np.float32)
        if not self.has_skip_:
            return self.layer1_.predict(X)
        l1_mask, l2_mask = self._route(X)
        preds = np.zeros(len(X), dtype=np.int32)
        if l1_mask.any():
            preds[l1_mask] = self.layer1_.predict(X[l1_mask])
        if l2_mask.any():
            preds[l2_mask] = self.layer2_.predict(X[l2_mask])
        return preds

    def transform(self, X):
        """Return probability distributions."""
        self._check_fitted()
        X = np.asarray(X, dtype=np.float32)
        C = self.n_classes_
        if not self.has_skip_:
            return self.layer1_.transform(X)
        l1_mask, l2_mask = self._route(X)
        dists = np.zeros((len(X), C), dtype=np.float64)
        if l1_mask.any():
            dists[l1_mask] = self.layer1_.transform(X[l1_mask])
        if l2_mask.any():
            dists[l2_mask] = self.layer2_.transform(X[l2_mask])
        return dists

    def predict_proba(self, X):
        """Return normalized probability distributions."""
        return normalize_distributions(self.transform(X))

    def predict_l1(self, X):
        """Return L1-only classification predictions (baseline)."""
        self._check_fitted()
        return self.layer1_.predict(X)

    # ── regression ───────────────────────────────────────────────────────

    def fit_regression(self, X, y):
        """
        Fit for regression.

        Parameters
        ----------
        X : ndarray, (M, D)
        y : ndarray, (M,), float
        """
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.float64)
        self.n_classes_ = 1

        # Fit L1
        self.layer1_ = self.layer1
        if not getattr(self.layer1_, 'is_fitted_', False):
            self.layer1_.fit_regression(X, y)

        # Impurity: within-cell variance normalized by global variance
        K_l1 = len(self.layer1_.seeds_)
        assignments = assign_clusters(X, self.layer1_.seeds_, self.layer1_.metric)
        global_var = np.var(y)
        self.cell_impurity_ = np.zeros(K_l1, dtype=np.float64)
        if global_var > 1e-12:
            for k in range(K_l1):
                mask = assignments == k
                if mask.sum() > 1:
                    self.cell_impurity_[k] = np.var(y[mask]) / global_var
        self.impure_mask_ = self.cell_impurity_ > self.impurity_threshold

        self._fit_gate_and_l2(
            X, y, assignments,
            lambda cell, Xi, yi: cell.fit_regression(Xi, yi),
        )
        return self

    def predict_regression(self, X):
        """Predict continuous values."""
        self._check_fitted()
        X = np.asarray(X, dtype=np.float32)
        if not self.has_skip_:
            return self.layer1_.predict_regression(X)
        l1_mask, l2_mask = self._route(X)
        preds = np.zeros(len(X), dtype=np.float64)
        if l1_mask.any():
            preds[l1_mask] = self.layer1_.predict_regression(X[l1_mask])
        if l2_mask.any():
            preds[l2_mask] = self.layer2_.predict_regression(X[l2_mask])
        return preds

    def predict_l1_regression(self, X):
        """Return L1-only regression predictions (baseline)."""
        self._check_fitted()
        return self.layer1_.predict_regression(X)

    # ── diagnostics ──────────────────────────────────────────────────────

    def entropy_per_cell(self):
        """Per-cell entropy of L1's LUT (classification)."""
        self._check_fitted()
        return np.array([
            _cell_entropy(self.layer1_.lut_[k])
            for k in range(len(self.layer1_.lut_))
        ])

    def impurity_per_cell(self):
        """Per-cell impurity (works for both classification and regression)."""
        self._check_fitted()
        return self.cell_impurity_.copy()

    def residual_entropy(self):
        """Total residual entropy across impure cells (classification)."""
        return float(self.entropy_per_cell().sum())

    def residual_impurity(self):
        """Total impurity across impure cells."""
        self._check_fitted()
        return float(self.cell_impurity_[self.impure_mask_].sum())

    # ── serialization ────────────────────────────────────────────────────

    def get_state(self):
        self._check_fitted()
        state = {
            "model_class": "BMCSkipConnection",
            "has_skip_": self.has_skip_,
            "n_impure_cells_": self.n_impure_cells_,
            "n_routed_points_": self.n_routed_points_,
            "n_classes_": self.n_classes_,
            "impure_mask_": self.impure_mask_,
            "cell_impurity_": self.cell_impurity_,
            "impurity_threshold": self.impurity_threshold,
            "layer1_": self.layer1_.get_state(),
        }
        if self.has_skip_:
            state["gate_"] = self.gate_.get_state()
            state["layer2_"] = self.layer2_.get_state()
        return state

    def set_state(self, state):
        self.has_skip_ = state["has_skip_"]
        self.n_impure_cells_ = state["n_impure_cells_"]
        self.n_routed_points_ = state["n_routed_points_"]
        self.n_classes_ = state["n_classes_"]
        self.impure_mask_ = state["impure_mask_"]
        self.cell_impurity_ = state["cell_impurity_"]
        self.impurity_threshold = state.get("impurity_threshold", 0.0)

        self.layer1_ = BMCCell(n_clusters=state["layer1_"]["n_clusters"])
        self.layer1_.set_state(state["layer1_"])

        if self.has_skip_:
            self.gate_ = BMCCell(n_clusters=state["gate_"]["n_clusters"])
            self.gate_.set_state(state["gate_"])
            self.layer2_ = BMCCell(n_clusters=state["layer2_"]["n_clusters"])
            self.layer2_.set_state(state["layer2_"])
        else:
            self.gate_ = None
            self.layer2_ = None

        self.is_fitted_ = True
        return self

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError(
                "BMCSkipConnection is not fitted. Call fit() or fit_regression() first."
            )

    def __repr__(self):
        status = "fitted" if self.is_fitted_ else "unfitted"
        skip_str = f", has_skip={self.has_skip_}" if self.is_fitted_ else ""
        l1_k = self.layer1.n_clusters
        l2_k = self.n_clusters_l2 or "auto"
        return (
            f"BMCSkipConnection("
            f"n_clusters_l1={l1_k}, "
            f"n_clusters_l2={l2_k}"
            f"{skip_str}, "
            f"status={status})"
        )
