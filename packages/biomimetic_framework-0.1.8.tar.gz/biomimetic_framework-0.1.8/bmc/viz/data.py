# bmc/viz/data.py
"""
Data perspective visualizations — what a fitted BMC learned.

    from bmc.viz.data import scatter

    scatter(cell, X, y, "cell_plot.png")
    scatter(layer, X, y, "layer_grid.png")
    scatter(network, X, y, "net.png", layer=0, zone=2)
"""

import numpy as np
from typing import Optional, List


def scatter(model, X: np.ndarray, y: np.ndarray,
            output_path: str = "bmc_scatter", fmt: str = None,
            class_names: Optional[List[str]] = None,
            layer: Optional[int] = None,
            zone: Optional[int] = None,
            method: str = "umap"):
    """
    2D scatter plot with Voronoi regions and geodesic path.

    Shows training data as small dots colored by class, seeds as large
    markers, Voronoi regions as shaded polygons, and the TSP geodesic
    path as directed arrows connecting seeds.

    Parameters
    ----------
    model : BMCCell, BMCLayer, or BMCNetwork
    X : np.ndarray
        Data to plot (training data recommended).
    y : np.ndarray
        Labels, shape (N,).
    output_path : str
    fmt : str, optional
    class_names : list of str, optional
    layer : int, optional
        Layer index for BMCNetwork. Defaults to 0.
    zone : int, optional
        Zone index for BMCLayer. If None and model is a BMCLayer,
        produces a grid of all zones.
    method : str
        Dimensionality reduction method: "umap" or "pca". Default: "umap".

    Returns
    -------
    path : str
    """
    from bmc.core.cell import BMCCell
    from bmc.composition.layer import BMCLayer
    from bmc.composition.sequential import BMCNetwork
    from bmc.model.classifier import BMCClassifier
    from bmc.model.regressor import BMCRegressor

    if method not in ("umap", "pca"):
        raise ValueError(f"method must be 'umap' or 'pca', got '{method}'")

    fmt, output_path = _resolve_format(output_path, fmt)

    # Unwrap to cell(s)
    if isinstance(model, BMCClassifier):
        model = model._model
    elif isinstance(model, BMCRegressor):
        if not model.is_fitted_:
            raise ValueError("Regressor is not fitted.")
        zone_vectors = model._obs.extract(X)
        if zone is not None:
            cell = model._zone_cells[zone]
            return _scatter_cell(cell, zone_vectors[zone], y,
                                 output_path, fmt, class_names,
                                 title=f"Zone {zone}", method=method)
        else:
            # Build a pseudo-layer for the grid renderer
            return _scatter_regressor_grid(model, zone_vectors, y,
                                           output_path, fmt, class_names, method)

    if isinstance(model, BMCNetwork):
        target_layer = model.layers[layer or 0]
        if isinstance(target_layer, BMCCell):
            return _scatter_cell(target_layer, X.reshape(len(X), -1), y,
                                 output_path, fmt, class_names, method=method)
        model = target_layer

    if isinstance(model, BMCLayer):
        if not model.is_fitted_:
            raise ValueError("Layer is not fitted.")
        zone_vectors = model.observation_space.extract(X)
        if zone is not None:
            cell = model.layers_[zone]
            return _scatter_cell(cell, zone_vectors[zone], y,
                                 output_path, fmt, class_names,
                                 title=f"Zone {zone}", method=method)
        else:
            return _scatter_layer_grid(model, zone_vectors, y,
                                       output_path, fmt, class_names,
                                       method=method)

    if isinstance(model, BMCCell):
        return _scatter_cell(model, X.reshape(len(X), -1), y,
                             output_path, fmt, class_names, method=method)

    raise TypeError(f"Cannot scatter {type(model).__name__}")


def _reduce_2d(data, seeds, method="umap"):
    """
    Project data + seeds jointly to 2D.

    Parameters
    ----------
    data : (N, D) float32
    seeds : (K, D) float32
    method : "umap" or "pca"

    Returns
    -------
    data_2d : (N, 2)
    seeds_2d : (K, 2)
    axis_labels : tuple of str
    """
    combined = np.vstack([data, seeds.astype(np.float32)])

    if method == "umap":
        try:
            import umap
        except ImportError:
            raise ImportError("umap-learn is required. Install with: pip install umap-learn")
        reducer = umap.UMAP(n_components=2, random_state=42, n_neighbors=15, min_dist=0.1)
        embedding = reducer.fit_transform(combined)
        labels = ("UMAP 1", "UMAP 2")
    elif method == "pca":
        from sklearn.decomposition import PCA
        reducer = PCA(n_components=2, random_state=42)
        embedding = reducer.fit_transform(combined)
        ev = reducer.explained_variance_ratio_
        labels = (f"PC1 ({ev[0]:.0%})", f"PC2 ({ev[1]:.0%})")
    else:
        raise ValueError(f"Unknown method: {method}")

    return embedding[:len(data)], embedding[len(data):], labels


def _scatter_cell(cell, X, y, output_path, fmt, class_names, title=None, method="umap"):
    """Single cell: 2D projection + Voronoi + geodesic path."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.spatial import Voronoi

    if not cell.is_fitted_:
        raise ValueError("Cell is not fitted.")

    seeds = cell.seeds_               # (K, D)
    lut = cell.lut_                   # (K, C)
    K, D = seeds.shape
    C = lut.shape[1]
    dominant = np.argmax(lut, axis=1)  # (K,)

    X_flat = X.reshape(len(X), -1).astype(np.float32)
    data_emb, seeds_emb, axis_labels = _reduce_2d(X_flat, seeds, method)

    # Color map
    n_classes = max(C, int(y.max()) + 1)
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    fig, ax = plt.subplots(figsize=(10, 8))

    # Voronoi regions
    if K >= 3:
        vor = Voronoi(seeds_emb)
        regions, vertices = _voronoi_finite_polygons_2d(vor, data_extent=data_emb)
        for i, region in enumerate(regions):
            polygon = vertices[region]
            ax.fill(*zip(*polygon), alpha=0.12,
                    facecolor=cmap(dominant[i] % cmap.N),
                    edgecolor="black", linewidth=0.5, zorder=0)

    # Data scatter
    ax.scatter(data_emb[:, 0], data_emb[:, 1],
               c=y, s=2, alpha=0.2, cmap=cmap, zorder=1)

    # Geodesic path with arrows
    for i in range(K):
        j = (i + 1) % K
        dx = seeds_emb[j, 0] - seeds_emb[i, 0]
        dy = seeds_emb[j, 1] - seeds_emb[i, 1]
        ax.annotate("",
                    xy=(seeds_emb[j, 0], seeds_emb[j, 1]),
                    xytext=(seeds_emb[i, 0], seeds_emb[i, 1]),
                    arrowprops=dict(arrowstyle="-|>", color="blue",
                                    lw=1.5, alpha=0.6),
                    zorder=3)

    # Seeds as markers
    ax.scatter(seeds_emb[:, 0], seeds_emb[:, 1],
               c=[cmap(dominant[k] % cmap.N) for k in range(K)],
               s=120, marker="*", edgecolors="black", linewidths=1.0,
               zorder=4)

    # Axis cleanup
    margin_x = (data_emb[:, 0].max() - data_emb[:, 0].min()) * 0.05
    margin_y = (data_emb[:, 1].max() - data_emb[:, 1].min()) * 0.05
    ax.set_xlim(data_emb[:, 0].min() - margin_x, data_emb[:, 0].max() + margin_x)
    ax.set_ylim(data_emb[:, 1].min() - margin_y, data_emb[:, 1].max() + margin_y)
    ax.set_xlabel(axis_labels[0])
    ax.set_ylabel(axis_labels[1])

    if title:
        ax.set_title(title)

    # Legend
    unique_classes = sorted(set(y))
    if len(unique_classes) <= 20:
        import matplotlib.patches as mpatches
        patches = []
        for c_idx in unique_classes:
            label = class_names[c_idx] if class_names and c_idx < len(class_names) else str(c_idx)
            patches.append(mpatches.Patch(color=cmap(c_idx % cmap.N), label=label))
        ax.legend(handles=patches, loc="best", fontsize=7,
                  ncol=min(len(patches), 5), framealpha=0.8)

    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _scatter_layer_grid(layer, zone_vectors, y, output_path, fmt, class_names,
                        method="umap"):
    """Grid of scatter plots, one per zone."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.spatial import Voronoi

    n_zones = len(layer.layers_)
    cols = min(n_zones, 5)
    rows = (n_zones + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 3.5 * rows))
    if n_zones == 1:
        axes = np.array([axes])
    axes = axes.flatten()

    n_classes = int(y.max()) + 1
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    for z in range(n_zones):
        ax = axes[z]
        cell = layer.layers_[z]
        seeds = cell.seeds_
        lut = cell.lut_
        K = len(seeds)
        dominant = np.argmax(lut, axis=1)

        X_zone = zone_vectors[z].astype(np.float32)
        data_emb, seeds_emb, _ = _reduce_2d(X_zone, seeds, method)

        # Voronoi
        if K >= 3:
            vor = Voronoi(seeds_emb)
            regions, vertices = _voronoi_finite_polygons_2d(vor, data_extent=data_emb)
            for i, region in enumerate(regions):
                polygon = vertices[region]
                ax.fill(*zip(*polygon), alpha=0.12,
                        facecolor=cmap(dominant[i] % cmap.N),
                        edgecolor="black", linewidth=0.3, zorder=0)

        # Data
        ax.scatter(data_emb[:, 0], data_emb[:, 1],
                   c=y, s=1, alpha=0.15, cmap=cmap, zorder=1)

        # Geodesic arrows
        for i in range(K):
            j = (i + 1) % K
            ax.annotate("",
                        xy=(seeds_emb[j, 0], seeds_emb[j, 1]),
                        xytext=(seeds_emb[i, 0], seeds_emb[i, 1]),
                        arrowprops=dict(arrowstyle="-|>", color="blue",
                                        lw=0.8, alpha=0.5),
                        zorder=3)

        # Seeds
        ax.scatter(seeds_emb[:, 0], seeds_emb[:, 1],
                   c=[cmap(dominant[k] % cmap.N) for k in range(K)],
                   s=40, marker="*", edgecolors="black", linewidths=0.5,
                   zorder=4)

        # Clip axes to data + seed extent
        all_pts = np.vstack([data_emb, seeds_emb])
        margin_x = (all_pts[:, 0].max() - all_pts[:, 0].min()) * 0.1 + 0.5
        margin_y = (all_pts[:, 1].max() - all_pts[:, 1].min()) * 0.1 + 0.5
        ax.set_xlim(all_pts[:, 0].min() - margin_x, all_pts[:, 0].max() + margin_x)
        ax.set_ylim(all_pts[:, 1].min() - margin_y, all_pts[:, 1].max() + margin_y)

        ax.set_title(f"Zone {z}", fontsize=9)
        ax.set_xticks([])
        ax.set_yticks([])

    # Hide unused axes
    for z in range(n_zones, len(axes)):
        axes[z].set_visible(False)

    plt.suptitle(f"BMCLayer — {n_zones} zones", fontsize=11)
    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _scatter_regressor(reg_cell, X, y, output_path, fmt, class_names, method,
                       title=None):
    """Scatter for a _RegressionCell — uses seeds_ directly, y as integer labels for color."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from scipy.spatial import Voronoi

    if not reg_cell.is_fitted_:
        raise ValueError("Regressor cell is not fitted.")

    seeds = reg_cell.seeds_
    K, D = seeds.shape

    X_flat = X.reshape(len(X), -1).astype(np.float32)
    data_emb, seeds_emb, axis_labels = _reduce_2d(X_flat, seeds, method)

    n_classes = max(int(y.max()) + 1, 2)
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    fig, ax = plt.subplots(figsize=(10, 8))

    # Voronoi
    if K >= 3:
        vor = Voronoi(seeds_emb)
        regions, vertices = _voronoi_finite_polygons_2d(vor, data_extent=data_emb)
        for i, region in enumerate(regions):
            polygon = vertices[region]
            ax.fill(*zip(*polygon), alpha=0.08,
                    facecolor="gray", edgecolor="black", linewidth=0.5, zorder=0)

    # Data
    ax.scatter(data_emb[:, 0], data_emb[:, 1],
               c=y, s=2, alpha=0.2, cmap=cmap, zorder=1)

    # Geodesic arrows
    for i in range(K):
        j = (i + 1) % K
        ax.annotate("",
                    xy=(seeds_emb[j, 0], seeds_emb[j, 1]),
                    xytext=(seeds_emb[i, 0], seeds_emb[i, 1]),
                    arrowprops=dict(arrowstyle="-|>", color="blue",
                                    lw=1.5, alpha=0.6),
                    zorder=3)

    # Seeds
    ax.scatter(seeds_emb[:, 0], seeds_emb[:, 1],
               c="red", s=120, marker="*", edgecolors="black",
               linewidths=1.0, zorder=4)

    margin_x = (data_emb[:, 0].max() - data_emb[:, 0].min()) * 0.05
    margin_y = (data_emb[:, 1].max() - data_emb[:, 1].min()) * 0.05
    ax.set_xlim(data_emb[:, 0].min() - margin_x, data_emb[:, 0].max() + margin_x)
    ax.set_ylim(data_emb[:, 1].min() - margin_y, data_emb[:, 1].max() + margin_y)
    ax.set_xlabel(axis_labels[0])
    ax.set_ylabel(axis_labels[1])

    if title:
        ax.set_title(title)

    if class_names and n_classes <= 20:
        import matplotlib.patches as mpatches
        patches = [mpatches.Patch(color=cmap(c % cmap.N), label=class_names[c])
                   for c in range(min(n_classes, len(class_names)))]
        ax.legend(handles=patches, loc="best", fontsize=7, framealpha=0.8)

    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _scatter_regressor_grid(reg, zone_vectors, y, output_path, fmt, class_names, method):
    """Grid of scatter plots for regressor zones."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    n_zones = len(reg._cells)
    cols = min(n_zones, 5)
    rows = (n_zones + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(4 * cols, 3.5 * rows))
    if n_zones == 1:
        axes = np.array([axes])
    axes = axes.flatten()

    n_classes = max(int(y.max()) + 1, 2)
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    for z in range(n_zones):
        ax = axes[z]
        cell = reg._zone_cells[z]
        seeds = cell.seeds_
        K = len(seeds)

        X_zone = zone_vectors[z].astype(np.float32)
        data_emb, seeds_emb, _ = _reduce_2d(X_zone, seeds, method)

        if K >= 3:
            from scipy.spatial import Voronoi
            vor = Voronoi(seeds_emb)
            regions, vertices = _voronoi_finite_polygons_2d(vor, data_extent=data_emb)
            for i, region in enumerate(regions):
                polygon = vertices[region]
                ax.fill(*zip(*polygon), alpha=0.08,
                        facecolor="gray", edgecolor="black", linewidth=0.3, zorder=0)

        ax.scatter(data_emb[:, 0], data_emb[:, 1],
                   c=y, s=1, alpha=0.15, cmap=cmap, zorder=1)

        for i in range(K):
            j = (i + 1) % K
            ax.annotate("",
                        xy=(seeds_emb[j, 0], seeds_emb[j, 1]),
                        xytext=(seeds_emb[i, 0], seeds_emb[i, 1]),
                        arrowprops=dict(arrowstyle="-|>", color="blue",
                                        lw=0.8, alpha=0.5),
                        zorder=3)

        ax.scatter(seeds_emb[:, 0], seeds_emb[:, 1],
                   c="red", s=40, marker="*", edgecolors="black",
                   linewidths=0.5, zorder=4)

        ax.set_title(f"Zone {z}", fontsize=9)
        ax.set_xticks([])
        ax.set_yticks([])

    for z in range(n_zones, len(axes)):
        axes[z].set_visible(False)

    plt.suptitle(f"BMCRegressor — {n_zones} zones", fontsize=11)
    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _voronoi_finite_polygons_2d(vor, radius=None, data_extent=None):
    """Reconstruct finite Voronoi regions from scipy.spatial.Voronoi.

    Parameters
    ----------
    vor : scipy.spatial.Voronoi
    radius : float or None
        Extension radius for unbounded regions. Auto-computed if None.
    data_extent : ndarray, (N, 2) or None
        If provided, the radius is computed to cover all data points,
        not just the seeds. This prevents white gaps at plot margins.
    """
    if vor.points.shape[1] != 2:
        raise ValueError("Requires 2D input")

    new_regions = []
    new_vertices = vor.vertices.tolist()

    center = vor.points.mean(axis=0)
    if radius is None:
        # Use whichever is larger: seed spread or data spread
        seed_span = np.max(np.ptp(vor.points))
        if data_extent is not None and len(data_extent) > 0:
            data_span = np.max(np.ptp(data_extent, axis=0))
            radius = max(seed_span, data_span) * 4
        else:
            radius = seed_span * 4

    all_ridges = {}
    for (p1, p2), (v1, v2) in zip(vor.ridge_points, vor.ridge_vertices):
        all_ridges.setdefault(p1, []).append((p2, v1, v2))
        all_ridges.setdefault(p2, []).append((p1, v1, v2))

    for p1, region in enumerate(vor.point_region):
        vertices = vor.regions[region]

        if all(v >= 0 for v in vertices):
            new_regions.append(vertices)
            continue

        ridges = all_ridges.get(p1, [])
        new_region = [v for v in vertices if v >= 0]

        for p2, v1, v2 in ridges:
            if v2 < 0:
                v1, v2 = v2, v1
            if v1 >= 0:
                continue

            t = vor.points[p2] - vor.points[p1]
            norm = np.linalg.norm(t)
            if norm < 1e-12:
                continue
            t /= norm
            n = np.array([-t[1], t[0]])

            midpoint = vor.points[[p1, p2]].mean(axis=0)
            direction = np.sign(np.dot(midpoint - center, n)) * n
            far_point = vor.vertices[v2] + direction * radius

            new_region.append(len(new_vertices))
            new_vertices.append(far_point.tolist())

        vs = np.asarray([new_vertices[v] for v in new_region])
        if len(vs) == 0:
            new_regions.append([])
            continue
        c = vs.mean(axis=0)
        angles = np.arctan2(vs[:, 1] - c[1], vs[:, 0] - c[0])
        new_region = [new_region[i] for i in np.argsort(angles)]

        new_regions.append(new_region)

    return new_regions, np.asarray(new_vertices)


def _resolve_format(output_path, fmt):
    if fmt is None:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                fmt = ext[1:]
                output_path = output_path[:-len(ext)]
                return fmt, output_path
        fmt = "png"
    else:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                output_path = output_path[:-len(ext)]
                break
    return fmt, output_path
