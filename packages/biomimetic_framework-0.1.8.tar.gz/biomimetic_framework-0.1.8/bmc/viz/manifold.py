# bmc/viz/manifold.py
"""
Geodesic manifold visualization.

    from bmc.viz import parametric
    parametric(cell, "geodesic.png")

Shows the geodesic as a colored strip (X = position along path) with
curvature on the Y-axis. Color = dominant class with gradient transitions
between seeds. Curvature shows where the path bends — class boundaries
have high curvature, cluster interiors are flat.
"""

import numpy as np
from typing import Optional, List


def parametric(cell, output_path: str = "bmc_parametric", fmt: str = None,
               class_names: Optional[List[str]] = None, n_samples: int = 500):
    """
    Geodesic parametric plot: curvature vs arc-length with class coloring.

    X-axis: arc-length position along the geodesic (0 to 1)
    Y-axis: curvature (bending angle at each seed, interpolated between)
    Color: dominant class at each position, with gradients at transitions

    Parameters
    ----------
    cell : BMCCell (fitted)
    output_path : str
    fmt : str, optional
    class_names : list of str, optional
    n_samples : int — sampling resolution along geodesic

    Returns
    -------
    path : str
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches

    if not cell.is_fitted_:
        raise ValueError("Cell is not fitted.")

    fmt, output_path = _resolve_format(output_path, fmt)

    seeds = cell.seeds_
    lut = cell.lut_
    arc = cell.arc_lengths_
    K, D = seeds.shape
    C = lut.shape[1]

    # ── Compute curvature at each seed ──
    # Curvature = angle between incoming and outgoing edges (0 = straight, π = reversal)
    curvature = np.zeros(K)
    for k in range(K):
        k_prev = (k - 1) % K
        k_next = (k + 1) % K
        v_in = seeds[k] - seeds[k_prev]
        v_out = seeds[k_next] - seeds[k]
        norm_in = np.linalg.norm(v_in)
        norm_out = np.linalg.norm(v_out)
        if norm_in > 1e-12 and norm_out > 1e-12:
            cos_angle = np.dot(v_in, v_out) / (norm_in * norm_out)
            cos_angle = np.clip(cos_angle, -1, 1)
            curvature[k] = np.arccos(cos_angle)  # radians, 0 to π

    # ── Color map ──
    if C > 1:
        dominant = np.argmax(lut, axis=1)
    else:
        dominant = np.zeros(K, dtype=int)

    n_classes = max(C, int(dominant.max()) + 1)
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    # ── Dense sampling along geodesic ──
    t_dense = np.linspace(0, 1, n_samples)

    # Interpolate curvature to dense positions
    # Simple: for each dense t, find which edge it falls on, lerp curvature
    sorted_idx = np.argsort(arc)
    sorted_arc = arc[sorted_idx]
    sorted_curv = curvature[sorted_idx]
    sorted_dom = dominant[sorted_idx]

    curv_dense = np.interp(t_dense, sorted_arc, sorted_curv)

    # ── Interpolated colors along geodesic ──
    # For each dense sample, compute the color as a blend between
    # adjacent seeds' class colors, weighted by interpolator output.
    # This creates smooth gradients at transitions.
    if cell.interpolator is not None and C > 1:
        from bmc.core.interpolators import RDDAInterpolator
        if not isinstance(cell.interpolator, RDDAInterpolator):
            vals = cell.interpolator.evaluate(t_dense)
            if vals.ndim == 1:
                vals = vals.reshape(-1, 1)
            vals = np.clip(vals, 0, None)
            rs = vals.sum(axis=1, keepdims=True)
            rs = np.where(rs == 0, 1, rs)
            vals = vals / rs
            # Blend colors: weighted average of class colors by probability
            dense_colors = np.zeros((n_samples, 4))  # RGBA
            for c_idx in range(C):
                c_rgba = np.array(cmap(c_idx % cmap.N))
                dense_colors += vals[:, c_idx:c_idx+1] * c_rgba[np.newaxis, :]
            dense_colors = np.clip(dense_colors, 0, 1)
        else:
            # RDDA: fall back to nearest seed coloring
            dense_colors = np.zeros((n_samples, 4))
            for s in range(n_samples):
                nearest = np.argmin(np.abs(sorted_arc - t_dense[s]))
                dense_colors[s] = cmap(sorted_dom[nearest] % cmap.N)
    elif C > 1:
        # No interpolator: hard boundaries, but still use LUT probabilities at seeds
        # Linearly blend between adjacent seed colors based on position
        dense_colors = np.zeros((n_samples, 4))
        for s in range(n_samples):
            t = t_dense[s]
            # Find the two bracketing seeds
            idx_right = np.searchsorted(sorted_arc, t)
            if idx_right == 0:
                dense_colors[s] = cmap(sorted_dom[0] % cmap.N)
            elif idx_right >= K:
                dense_colors[s] = cmap(sorted_dom[-1] % cmap.N)
            else:
                idx_left = idx_right - 1
                span = sorted_arc[idx_right] - sorted_arc[idx_left]
                if span < 1e-12:
                    frac = 0.5
                else:
                    frac = (t - sorted_arc[idx_left]) / span
                c_left = np.array(cmap(sorted_dom[idx_left] % cmap.N))
                c_right = np.array(cmap(sorted_dom[idx_right] % cmap.N))
                dense_colors[s] = (1 - frac) * c_left + frac * c_right
    else:
        # Regression: single color
        dense_colors = np.full((n_samples, 4), [0, 0, 0, 1])

    # ── Plot ──
    fig, ax = plt.subplots(figsize=(12, 4))

    # Fill area under curvature curve with blended colors
    for s in range(n_samples - 1):
        fill_color = dense_colors[s].copy()
        fill_color[3] = 0.4  # alpha for fill
        ax.fill_between(t_dense[s:s+2], 0, curv_dense[s:s+2],
                         color=fill_color, linewidth=0)

    # Curvature line on top with blended colors
    for s in range(n_samples - 1):
        ax.plot(t_dense[s:s+2], curv_dense[s:s+2],
                color=dense_colors[s], linewidth=2.0)

    # Seed markers
    for k in range(K):
        ax.plot(arc[k], curvature[k], "o",
                color=cmap(dominant[k] % cmap.N),
                markersize=8, markeredgecolor="black", markeredgewidth=0.8,
                zorder=5)

    # Seed vertical lines
    for k in range(K):
        ax.axvline(arc[k], color="gray", linewidth=0.3, linestyle=":",
                   alpha=0.4, zorder=1)

    # Legend only for small number of classes
    unique_classes = sorted(set(dominant))
    if len(unique_classes) <= 10 and class_names:
        patches = []
        for c_idx in unique_classes:
            label = class_names[c_idx] if c_idx < len(class_names) else str(c_idx)
            patches.append(mpatches.Patch(color=cmap(c_idx % cmap.N), label=label))
        ax.legend(handles=patches, fontsize=7, ncol=min(len(patches), 5),
                  loc="upper right", framealpha=0.9, edgecolor="black")

    ax.set_xlim(0, 1)
    ax.set_ylim(0, max(curvature.max() * 1.1, 0.1))
    ax.set_xlabel("Arc-length along geodesic")
    ax.set_ylabel("Curvature (radians)")
    ax.set_title(f"Geodesic Profile  (K={K})", fontsize=10)

    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def riemannian(cell, output_path: str = "bmc_riemannian", fmt: str = None,
               class_names=None,
               grid_samples: int = 50000, padding: float = 0.1):
    """
    3D Riemannian manifold: the BMC's learned function surface in (D+C) space.

    Grids the input space, predicts output via BMC at each grid point,
    concatenates [input, output] into (D+C)-dimensional points, and
    projects to 3D via UMAP. Seeds lie exactly on this surface.

    Parameters
    ----------
    cell : BMCCell (fitted)
    output_path : str
    fmt : str, optional
    class_names : list of str, optional
    grid_samples : int — total number of grid points to sample
    padding : float — fraction of range to pad beyond data extremes

    Returns
    -------
    path : str
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    if not cell.is_fitted_:
        raise ValueError("Cell is not fitted.")

    fmt, output_path = _resolve_format(output_path, fmt)

    seeds = cell.seeds_       # (K, D)
    lut = cell.lut_           # (K, C)
    K, D = seeds.shape
    C = lut.shape[1]

    # ── Grid the input space ──
    mins = seeds.min(axis=0)
    maxs = seeds.max(axis=0)
    ranges = maxs - mins
    ranges = np.where(ranges < 1e-8, 1.0, ranges)
    mins = mins - ranges * padding
    maxs = maxs + ranges * padding

    if D <= 5:
        res_per_dim = max(3, int(grid_samples ** (1.0 / D)))
        grids = [np.linspace(mins[d], maxs[d], res_per_dim) for d in range(D)]
        mesh = np.meshgrid(*grids, indexing="ij")
        grid_input = np.column_stack([m.ravel() for m in mesh]).astype(np.float32)
    else:
        rng = np.random.default_rng(42)
        grid_input = np.column_stack([
            rng.uniform(mins[d], maxs[d], grid_samples)
            for d in range(D)
        ]).astype(np.float32)

    # ── Predict output at each grid point ──
    if C > 1:
        grid_output = cell.transform(grid_input)  # (N, C) — interpolated probabilities
    else:
        grid_output = cell.predict_regression(grid_input).reshape(-1, 1)  # (N, 1)

    # ── Concatenate input + output → (D+C) points ──
    grid_joint = np.hstack([grid_input, grid_output.astype(np.float32)])  # (N, D+C)

    # ── Seed points in (D+C) space — these lie exactly on the manifold ──
    seeds_joint = np.hstack([seeds, lut.astype(np.float32)])  # (K, D+C)

    # ── Geodesic curve: dense points along edges in (D+C) space ──
    arc = cell.arc_lengths_
    n_curve = max(K * 10, 100)
    curve_joint = []
    curve_arcs = []
    for k in range(K):
        k_next = (k + 1) % K
        for frac in np.linspace(0, 1, n_curve // K, endpoint=False):
            pt_input = seeds[k] + frac * (seeds[k_next] - seeds[k])
            pt_input_2d = pt_input.reshape(1, -1).astype(np.float32)
            if C > 1:
                pt_output = cell.transform(pt_input_2d)[0]
            else:
                pt_output = np.array([cell.predict_regression(pt_input_2d)[0]])
            curve_joint.append(np.concatenate([pt_input, pt_output.astype(np.float32)]))
            curve_arcs.append(arc[k] + frac * (arc[k_next] - arc[k]))
    curve_joint = np.array(curve_joint, dtype=np.float32)
    curve_arcs = np.array(curve_arcs)

    # ── Project to 3D ──
    all_points = np.vstack([grid_joint, seeds_joint, curve_joint])
    n_grid = len(grid_input)
    joint_dim = D + C

    if joint_dim <= 3:
        # Joint space fits in 3D — use directly
        # Pad if joint_dim < 3
        if joint_dim < 3:
            pad_grid = np.zeros((n_grid, 3 - joint_dim), dtype=np.float32)
            pad_seeds = np.zeros((K, 3 - joint_dim), dtype=np.float32)
            pad_curve = np.zeros((len(curve_joint), 3 - joint_dim), dtype=np.float32)
            grid_3d = np.hstack([grid_joint, pad_grid])
            seeds_3d = np.hstack([seeds_joint, pad_seeds])
            curve_3d = np.hstack([curve_joint, pad_curve])
        else:
            grid_3d = grid_joint
            seeds_3d = seeds_joint
            curve_3d = curve_joint

        # Axis labels from input + output dims
        input_labels = [f"Input {d}" for d in range(D)]
        output_labels = [f"Output {c}" for c in range(C)]
        all_labels = input_labels + output_labels
        axis_labels = (all_labels + [""])[:3]
    else:
        # D+C > 3: UMAP projection
        try:
            import umap
        except ImportError:
            raise ImportError("umap-learn required. Install with: pip install umap-learn")
        reducer = umap.UMAP(n_components=3, random_state=42, n_neighbors=15, min_dist=0.1)
        all_3d = reducer.fit_transform(all_points)
        grid_3d = all_3d[:n_grid]
        seeds_3d = all_3d[n_grid:n_grid + K]
        curve_3d = all_3d[n_grid + K:]
        axis_labels = ["UMAP 1", "UMAP 2", "UMAP 3"]

    # ── Color maps ──
    n_classes = C
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    # Grid point colors: blend by predicted probabilities
    if C > 1:
        grid_colors = np.zeros((n_grid, 4))
        for c_idx in range(C):
            c_rgba = np.array(cmap(c_idx % cmap.N))
            grid_colors += grid_output[:, c_idx:c_idx + 1] * c_rgba[np.newaxis, :]
        grid_colors = np.clip(grid_colors, 0, 1)
    else:
        # Regression: color by output value
        vals = grid_output.ravel()
        norm_vals = (vals - vals.min()) / (vals.max() - vals.min() + 1e-12)
        grid_colors = plt.colormaps["coolwarm"](norm_vals)

    # Seed colors
    if C > 1:
        dominant = np.argmax(lut, axis=1)
        seed_colors = [cmap(dominant[k] % cmap.N) for k in range(K)]
    else:
        seed_colors = "red"

    # Curve colors
    if C > 1 and cell.interpolator is not None:
        from bmc.core.interpolators import RDDAInterpolator
        if not isinstance(cell.interpolator, RDDAInterpolator):
            vals = cell.interpolator.evaluate(curve_arcs)
            if vals.ndim == 1:
                vals = vals.reshape(-1, 1)
            vals = np.clip(vals, 0, None)
            rs = vals.sum(axis=1, keepdims=True)
            rs = np.where(rs == 0, 1, rs)
            vals = vals / rs
            curve_colors_arr = np.zeros((len(curve_arcs), 4))
            for c_idx in range(C):
                c_rgba = np.array(cmap(c_idx % cmap.N))
                curve_colors_arr += vals[:, c_idx:c_idx + 1] * c_rgba[np.newaxis, :]
            curve_colors_arr = np.clip(curve_colors_arr, 0, 1)
        else:
            curve_colors_arr = None
    else:
        curve_colors_arr = None

    # ── Render ──
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection="3d")

    # Manifold mesh: faint colored surface
    from scipy.spatial import ConvexHull, Delaunay
    try:
        if D <= 3:
            # 3D surface: use ConvexHull for surface triangles
            hull = ConvexHull(grid_3d)
            simplices = hull.simplices
        else:
            # Projected space: 2D Delaunay on first 2 dims
            tri = Delaunay(grid_3d[:, :2])
            simplices = tri.simplices

        face_colors = np.zeros((len(simplices), 4))
        for i, simplex in enumerate(simplices):
            face_colors[i] = grid_colors[simplex].mean(axis=0)
            face_colors[i, 3] = 0.15
        from mpl_toolkits.mplot3d.art3d import Poly3DCollection
        verts = grid_3d[simplices]
        mesh = Poly3DCollection(verts, facecolors=face_colors,
                                 edgecolors="gray", linewidths=0.05)
        ax.add_collection3d(mesh)
    except Exception:
        pass

    # Grid points: very small, grey, almost transparent
    ax.scatter(grid_3d[:, 0], grid_3d[:, 1], grid_3d[:, 2],
               c="gray", s=0.3, alpha=0.03, zorder=1)

    # Geodesic curve
    if curve_colors_arr is not None:
        for s in range(len(curve_3d) - 1):
            ax.plot(curve_3d[s:s+2, 0], curve_3d[s:s+2, 1], curve_3d[s:s+2, 2],
                    color=curve_colors_arr[s], linewidth=2.5, alpha=0.9, zorder=3)
    else:
        ax.plot(curve_3d[:, 0], curve_3d[:, 1], curve_3d[:, 2],
                color="black", linewidth=2.5, alpha=0.9, zorder=3)

    # Arrows between seeds
    for k in range(K):
        k_next = (k + 1) % K
        dx = seeds_3d[k_next, 0] - seeds_3d[k, 0]
        dy = seeds_3d[k_next, 1] - seeds_3d[k, 1]
        dz = seeds_3d[k_next, 2] - seeds_3d[k, 2]
        ac = seed_colors[k] if isinstance(seed_colors, list) else "black"
        ax.quiver(seeds_3d[k, 0], seeds_3d[k, 1], seeds_3d[k, 2],
                  dx, dy, dz, color=ac, arrow_length_ratio=0.06,
                  linewidth=0.8, alpha=0.6, zorder=4)

    # Seed markers
    ax.scatter(seeds_3d[:, 0], seeds_3d[:, 1], seeds_3d[:, 2],
               c=seed_colors, s=120, marker="*", edgecolors="black",
               linewidths=1.0, zorder=5)

    ax.set_xlabel(axis_labels[0], fontsize=8)
    ax.set_ylabel(axis_labels[1], fontsize=8)
    ax.set_zlabel(axis_labels[2], fontsize=8)
    ax.set_title(f"Riemannian Manifold  (K={K}, D={D}, C={C})", fontsize=10)
    ax.tick_params(labelsize=6)
    plt.tight_layout()

    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _resolve_format(output_path, fmt):
    if fmt is None:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                fmt = ext[1:]
                output_path = output_path[:-len(ext)]
                return fmt, output_path
        fmt = "png"
    else:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                output_path = output_path[:-len(ext)]
                break
    return fmt, output_path
