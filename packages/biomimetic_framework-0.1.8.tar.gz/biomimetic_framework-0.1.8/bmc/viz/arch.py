# bmc/viz/arch.py
"""
Architecture introspection — extract structural info from any BMC model.

Extracts a pure architectural description: components, connections,
parameters, and memory footprint. All computable from architecture
alone — no fitting required.
"""

from dataclasses import dataclass, field
from typing import List, Optional


def _mem_bytes(K, D, C):
    """Compute memory footprint from architecture parameters."""
    seeds_bytes = K * D * 4   # float32
    lut_bytes = K * C * 8     # float64
    return seeds_bytes + lut_bytes


def _format_bytes(n):
    if n < 1024:
        return f"{n} B"
    elif n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    else:
        return f"{n / (1024 * 1024):.1f} MB"


@dataclass
class CellInfo:
    """Architectural info for a single BMCCell."""
    K: int                          # number of address lines (clusters)
    D: Optional[int] = None         # input dimension
    C: Optional[int] = None         # output dimension
    metric: str = "L2"
    interpolator: Optional[str] = None

    @property
    def memory_bytes(self) -> Optional[int]:
        if self.D is not None and self.C is not None:
            return _mem_bytes(self.K, self.D, self.C)
        return None

    @property
    def memory_str(self) -> Optional[str]:
        b = self.memory_bytes
        return _format_bytes(b) if b is not None else None


@dataclass
class ObsSpaceInfo:
    """Architectural info for an observation space."""
    type_name: str
    input_desc: str       # uses D, not M
    n_zones: int
    feature_dim: int
    decomposition: str


@dataclass
class LayerInfo:
    """Architectural info for a BMCLayer."""
    obs_space: ObsSpaceInfo
    cell_template: CellInfo
    n_zones: int

    @property
    def output_dim_desc(self) -> str:
        C_str = str(self.cell_template.C) if self.cell_template.C else "C"
        return f"{self.n_zones} \u00d7 {C_str}"

    @property
    def total_memory_bytes(self) -> Optional[int]:
        per_cell = self.cell_template.memory_bytes
        if per_cell is not None:
            return per_cell * self.n_zones
        return None

    @property
    def total_memory_str(self) -> Optional[str]:
        b = self.total_memory_bytes
        return _format_bytes(b) if b is not None else None


@dataclass
class NetworkInfo:
    """Architectural info for a full BMC architecture."""
    stages: list            # List of LayerInfo or CellInfo
    input_desc: str         # dimensionality, no M
    output_desc: str        # dimensionality, no M

    @property
    def total_memory_bytes(self) -> Optional[int]:
        total = 0
        for s in self.stages:
            if isinstance(s, LayerInfo):
                b = s.total_memory_bytes
            else:
                b = s.memory_bytes
            if b is None:
                return None
            total += b
        return total

    @property
    def total_memory_str(self) -> Optional[str]:
        b = self.total_memory_bytes
        return _format_bytes(b) if b is not None else None


def _metric_name(metric) -> str:
    return type(metric).__name__.replace("Metric", "")


def _interpolator_name(interp) -> str:
    if interp is None:
        return None
    return type(interp).__name__.replace("Interpolator", "")


def _obs_space_info(obs) -> ObsSpaceInfo:
    type_name = type(obs).__name__.replace("ObservationSpace", "")
    n_zones = obs.n_zones
    feature_dim = obs.feature_dim

    if type_name == "Image":
        img_sz = obs.image_size
        pool_sz = obs.pool_size
        grid_n = obs.grid_n
        out_sz = obs.output_size
        input_desc = f"{img_sz}\u00d7{img_sz}"
        decomposition = (f"{grid_n}\u00d7{grid_n} grid, "
                         f"{pool_sz}\u00d7{pool_sz} patches \u2192 "
                         f"{out_sz}\u00d7{out_sz}")
    elif type_name == "Tabular":
        n_feat = obs.n_features
        input_desc = f"D={n_feat}"
        decomposition = f"{n_feat} features \u2192 {n_zones} subsets"
    elif type_name == "TimeSeries":
        input_desc = "T"
        decomposition = f"window={obs.window_size}, stride={obs.stride}"
    elif type_name == "Text":
        input_desc = "seq \u00d7 emb"
        decomposition = f"chunk={obs.chunk_size}, stride={obs.stride}"
    else:
        input_desc = "..."
        decomposition = f"{n_zones} zones"

    return ObsSpaceInfo(
        type_name=type_name,
        input_desc=input_desc,
        n_zones=n_zones,
        feature_dim=feature_dim,
        decomposition=decomposition,
    )


def _cell_info(cell) -> CellInfo:
    info = CellInfo(
        K=cell.n_clusters,
        metric=_metric_name(cell.metric),
        interpolator=_interpolator_name(cell.interpolator) if hasattr(cell, 'interpolator') else None,
    )
    if cell.is_fitted_:
        info.D = cell.seeds_.shape[1]
        info.C = cell.lut_.shape[1]
    return info


def _layer_info(layer) -> LayerInfo:
    obs = _obs_space_info(layer.observation_space)

    if layer.is_fitted_ and layer.layers_:
        rep = _cell_info(layer.layers_[0])
    else:
        rep = CellInfo(
            K=layer.n_clusters,
            metric=_metric_name(layer.metric),
        )

    return LayerInfo(
        obs_space=obs,
        cell_template=rep,
        n_zones=obs.n_zones,
    )


def extract(model) -> NetworkInfo:
    """
    Extract architecture info from any BMC model.

    Returns a pure structural description with memory footprint.
    """
    from bmc.core.cell import BMCCell
    from bmc.composition.layer import BMCLayer
    from bmc.composition.sequential import BMCNetwork, SequentialBMC
    from bmc.composition.skip import BMCSkipConnection
    from bmc.model.classifier import BMCClassifier
    from bmc.model.regressor import BMCRegressor

    if isinstance(model, (BMCClassifier, BMCRegressor)):
        if hasattr(model, '_model') and model._model is not None:
            return extract(model._model)
        else:
            stages = []
            obs_desc = "..."
            if model.observation_space is not None:
                obs = _obs_space_info(model.observation_space)
                obs_desc = obs.input_desc
                rep = CellInfo(K=model.n_clusters, metric=_metric_name(model.metric))
                stages.append(LayerInfo(obs_space=obs, cell_template=rep, n_zones=obs.n_zones))
            k_l2 = model.n_clusters_l2
            if k_l2 == "auto":
                k_l2 = model.n_clusters
            if k_l2 is not None:
                stages.append(CellInfo(K=k_l2, metric=_metric_name(model.metric)))
            return NetworkInfo(stages=stages, input_desc=obs_desc, output_desc="C")

    if isinstance(model, BMCCell):
        info = _cell_info(model)
        D_str = str(info.D) if info.D else "D"
        C_str = str(info.C) if info.C else "C"
        return NetworkInfo(
            stages=[info],
            input_desc=f"D={D_str}" if info.D else "D",
            output_desc=f"C={C_str}" if info.C else "C",
        )

    if isinstance(model, BMCLayer):
        linfo = _layer_info(model)
        return NetworkInfo(
            stages=[linfo],
            input_desc=linfo.obs_space.input_desc,
            output_desc=linfo.output_dim_desc,
        )

    if isinstance(model, BMCSkipConnection):
        stages = []
        # L1
        if model.layer1_ is not None:
            stages.append(_cell_info(model.layer1_))
        elif model.layer1 is not None:
            stages.append(_cell_info(model.layer1))
        # Gate
        if model.gate_ is not None:
            gate_info = _cell_info(model.gate_)
            gate_info.metric = "gate (1D arc-length)"
            stages.append(gate_info)
        # L2
        if model.layer2_ is not None:
            stages.append(_cell_info(model.layer2_))

        input_desc = "D"
        if stages and stages[0].D:
            input_desc = f"D={stages[0].D}"
        output_desc = "C"
        if stages and stages[0].C:
            output_desc = f"C={stages[0].C}"

        return NetworkInfo(stages=stages, input_desc=input_desc, output_desc=output_desc)

    if isinstance(model, BMCNetwork):
        stages = []
        for layer in model.layers:
            if isinstance(layer, BMCLayer):
                stages.append(_layer_info(layer))
            elif isinstance(layer, BMCCell):
                stages.append(_cell_info(layer))
            else:
                stages.append(CellInfo(K=0, metric="unknown"))

        input_desc = "..."
        if stages and isinstance(stages[0], LayerInfo):
            input_desc = stages[0].obs_space.input_desc

        output_desc = "C"
        if stages and isinstance(stages[-1], CellInfo) and stages[-1].C:
            output_desc = f"C={stages[-1].C}"

        return NetworkInfo(stages=stages, input_desc=input_desc, output_desc=output_desc)

    raise TypeError(f"Cannot extract architecture from {type(model).__name__}")
