# bmc/viz/summary.py
"""
CLI architecture summary.
"""

from bmc.viz.arch import extract, NetworkInfo, LayerInfo, CellInfo, _format_bytes

ZONE_EXPAND_THRESHOLD = 6


def summary(model, return_text=False):
    """
    Print a CLI architecture summary of any BMC model.

    Parameters
    ----------
    model : BMCCell, BMCLayer, BMCNetwork, BMCSkipConnection, BMCClassifier, or BMCRegressor
    return_text : bool
        If True, return the summary as a string instead of printing.
    """
    try:
        from rich.tree import Tree
        from rich.console import Console
        _has_rich = True
    except ImportError:
        _has_rich = False

    info = extract(model)

    if _has_rich:
        return _summary_rich(info, return_text)
    else:
        return _summary_plain(info, return_text)


def _summary_rich(info: NetworkInfo, return_text: bool):
    from rich.tree import Tree
    from rich.console import Console

    tree = Tree(f"[dim]Input:[/] {info.input_desc}")

    for stage in info.stages:
        if isinstance(stage, LayerInfo):
            _add_layer_to_tree(tree, stage)
        elif isinstance(stage, CellInfo):
            label = f"[bold]BMCCell[/]  K={stage.K}  Metric: {stage.metric}"
            if stage.D is not None:
                label += f"  Dim in: {stage.D}"
            if stage.C is not None:
                label += f"  Dim out: {stage.C}"
            branch = tree.add(label)
            if stage.memory_str:
                branch.add(f"[dim]Memory: {stage.memory_str}[/]")

    # Total memory
    if info.total_memory_str:
        tree.add(f"[dim]Total memory: {info.total_memory_str}[/]")

    tree.add(f"[dim]Output:[/] {info.output_desc}")

    console = Console(record=return_text)
    console.print(tree)
    if return_text:
        return console.export_text()


def _add_layer_to_tree(tree, layer: LayerInfo):
    obs = layer.obs_space
    cell = layer.cell_template
    n = layer.n_zones

    branch = tree.add(f"[bold]BMCLayer[/]  ({n} BMCCells)")
    branch.add(f"Observation Space: {obs.type_name}  {obs.decomposition}")
    branch.add(f"{obs.n_zones} zones \u00d7 {obs.feature_dim}D")

    if n <= ZONE_EXPAND_THRESHOLD:
        for z in range(n):
            label = f"BMCCell  K={cell.K}  Metric: {cell.metric}"
            if cell.D is not None:
                label += f"  Dim: {cell.D}"
            branch.add(label)
    else:
        label = f"BMCCell \u00d7{n}  K={cell.K}  Metric: {cell.metric}"
        if cell.D is not None:
            label += f"  Dim: {cell.D}"
        branch.add(label)

    if layer.total_memory_str:
        branch.add(f"[dim]Layer memory: {layer.total_memory_str}[/]")

    branch.add(f"Output {layer.output_dim_desc}")


def _summary_plain(info: NetworkInfo, return_text: bool):
    lines = []
    lines.append(f"Input: {info.input_desc}")

    for stage in info.stages:
        if isinstance(stage, LayerInfo):
            obs = stage.obs_space
            cell = stage.cell_template
            n = stage.n_zones
            lines.append(f"  BMCLayer ({n} BMCCells)")
            lines.append(f"    Observation Space: {obs.type_name}  {obs.decomposition}")
            lines.append(f"    {obs.n_zones} zones x {obs.feature_dim}D")
            if n <= ZONE_EXPAND_THRESHOLD:
                for z in range(n):
                    lines.append(f"    BMCCell  K={cell.K}  Metric: {cell.metric}")
            else:
                lines.append(f"    BMCCell x{n}  K={cell.K}  Metric: {cell.metric}")
            if stage.total_memory_str:
                lines.append(f"    Layer memory: {stage.total_memory_str}")
            lines.append(f"    Output {stage.output_dim_desc}")
        elif isinstance(stage, CellInfo):
            parts = f"  BMCCell  K={stage.K}  Metric: {stage.metric}"
            if stage.D: parts += f"  Dim in: {stage.D}"
            if stage.C: parts += f"  Dim out: {stage.C}"
            lines.append(parts)
            if stage.memory_str:
                lines.append(f"    Memory: {stage.memory_str}")

    if info.total_memory_str:
        lines.append(f"  Total memory: {info.total_memory_str}")
    lines.append(f"Output: {info.output_desc}")

    text = "\n".join(lines)
    if return_text:
        return text
    print(text)
