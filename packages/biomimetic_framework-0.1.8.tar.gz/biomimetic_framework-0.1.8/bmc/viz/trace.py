# bmc/viz/trace.py
"""
Prediction trace visualization.

Shows the activated Voronoi cells, geodesic edge, and parametric
position for a single query point, recursively across all cells
in a layer and all layers in a network.

    from bmc.viz import trace
    trace(model, X_train, y_train, query, "trace.png")
"""

import numpy as np
from typing import Optional, List
from bmc.viz.data import _reduce_2d, _voronoi_finite_polygons_2d


def trace(model, X: np.ndarray, y: np.ndarray, query: np.ndarray,
          output_path: str = "bmc_trace", fmt: str = None,
          class_names: Optional[List[str]] = None,
          method: str = "umap"):
    """
    Prediction trace: show which cells activate for a single query.

    For each cell the query passes through:
    - Seed i (nearest): yellow background, alpha = t
    - Seed j (geodesic neighbor): yellow background, alpha = 1-t
    - All other cells: gray
    - Geodesic edge i→j: yellow line
    - Arc-length position: purple dot on the geodesic

    Recursive across zones in a layer and layers in a network.

    Parameters
    ----------
    model : any fitted BMC model
    X : np.ndarray — training data (for UMAP/PCA fitting + background scatter)
    y : np.ndarray — integer labels for coloring
    query : np.ndarray — single query point, shape (D,) or (1, D)
    output_path : str
    fmt : str, optional
    class_names : list of str, optional
    method : str — "umap" or "pca"

    Returns
    -------
    path : str
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from bmc.core.cell import BMCCell
    from bmc.composition.layer import BMCLayer
    from bmc.composition.sequential import BMCNetwork
    from bmc.model.classifier import BMCClassifier
    from bmc.model.regressor import BMCRegressor

    fmt, output_path = _resolve_format(output_path, fmt)
    query = np.asarray(query, dtype=np.float32).ravel()

    is_regressor = isinstance(model, BMCRegressor)

    # Collect (cell, zone_data, trace_info) tuples for all cells
    cell_traces = []

    if isinstance(model, BMCClassifier):
        model = model._model

    if isinstance(model, BMCRegressor):
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        zone_vectors = model._obs.extract(X)
        query_zones = model._obs.extract(query.reshape(1, -1))
        for z, cell in enumerate(model._zone_cells):
            tr = cell.trace_query(query_zones[z][0])
            cell_traces.append((cell, zone_vectors[z], query_zones[z][0], tr, f"Zone {z}"))

        if model._head_cell is not None:
            zone_preds = np.column_stack([
                cell.predict_regression(zone_vectors[z])
                for z, cell in enumerate(model._zone_cells)
            ])
            query_zone_pred = np.array([
                cell.predict_regression(query_zones[z])[0]
                for z, cell in enumerate(model._zone_cells)
            ]).reshape(1, -1).astype(np.float32)
            tr = model._head_cell.trace_query(query_zone_pred[0])
            cell_traces.append((model._head_cell, zone_preds, query_zone_pred[0], tr, "Head"))

    elif isinstance(model, BMCNetwork):
        if not all(hasattr(l, 'is_fitted_') and l.is_fitted_ for l in model.layers):
            raise ValueError("Model is not fitted.")

        for li, layer in enumerate(model.layers):
            if isinstance(layer, BMCLayer):
                zone_vectors = layer.observation_space.extract(X)
                query_zones = layer.observation_space.extract(query.reshape(1, -1))
                for z, cell in enumerate(layer.layers_):
                    tr = cell.trace_query(query_zones[z][0])
                    cell_traces.append((cell, zone_vectors[z], query_zones[z][0], tr, f"L{li} Zone {z}"))
            elif isinstance(layer, BMCCell):
                if li == 0:
                    X_in = X.reshape(len(X), -1).astype(np.float32)
                    q_in = query
                else:
                    prev = model.layers[li - 1]
                    if isinstance(prev, BMCLayer):
                        X_in = prev.transform(X).reshape(len(X), -1).astype(np.float32)
                        q_in = prev.transform(query.reshape(1, -1)).reshape(-1).astype(np.float32)
                    else:
                        X_in = prev.transform(X).reshape(len(X), -1).astype(np.float32)
                        q_in = prev.transform(query.reshape(1, -1)).reshape(-1).astype(np.float32)
                tr = layer.trace_query(q_in)
                cell_traces.append((layer, X_in, q_in, tr, f"L{li} Head"))

    elif isinstance(model, BMCLayer):
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        zone_vectors = model.observation_space.extract(X)
        query_zones = model.observation_space.extract(query.reshape(1, -1))
        for z, cell in enumerate(model.layers_):
            tr = cell.trace_query(query_zones[z][0])
            cell_traces.append((cell, zone_vectors[z], query_zones[z][0], tr, f"Zone {z}"))

    elif isinstance(model, BMCCell):
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        X_flat = X.reshape(len(X), -1).astype(np.float32)
        tr = model.trace_query(query)
        cell_traces.append((model, X_flat, query, tr, "Cell"))

    else:
        raise TypeError(f"Cannot trace {type(model).__name__}")

    # Render
    return _render_trace(cell_traces, y, output_path, fmt, class_names, method)


def _render_trace(cell_traces, y, output_path, fmt, class_names, method):
    """Render all cell traces as a composite figure."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    n = len(cell_traces)
    cols = min(n, 5)
    rows = (n + cols - 1) // cols
    cell_size = 3.5

    fig, axes = plt.subplots(rows, cols, figsize=(cell_size * cols, cell_size * rows))
    if n == 1:
        axes = np.array([axes])
    axes = np.atleast_2d(axes).flatten()

    n_classes = max(int(y.max()) + 1, 2)
    if n_classes <= 10:
        cmap = plt.colormaps["tab10"]
    elif n_classes <= 20:
        cmap = plt.colormaps["tab20"]
    else:
        cmap = plt.colormaps["viridis"].resampled(n_classes)

    for idx, (cell, X_zone, q_vec, tr, title) in enumerate(cell_traces):
        ax = axes[idx]
        _draw_trace_cell(ax, cell, X_zone, y, q_vec, tr, cmap, method)
        ax.set_title(title, fontsize=8, pad=2)

    for idx in range(n, len(axes)):
        axes[idx].set_visible(False)

    plt.suptitle("Prediction Trace", fontsize=11, fontweight="bold")
    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _draw_trace_cell(ax, cell, X, y, query, tr, cmap, method):
    """Draw a single cell's trace with highlighted Voronoi cells and geodesic edge."""
    from scipy.spatial import Voronoi

    seeds = cell.seeds_
    K = len(seeds)
    lut = cell.lut_
    C = lut.shape[1]

    i = tr["i"]
    j = tr["j"]
    t = tr["t"]

    X_flat = X.reshape(len(X), -1).astype(np.float32)
    q_flat = query.reshape(1, -1).astype(np.float32)

    # Joint embedding: data + seeds + query
    combined = np.vstack([X_flat, seeds.astype(np.float32), q_flat])
    if method == "umap":
        try:
            import umap
        except ImportError:
            raise ImportError("umap-learn required")
        reducer = umap.UMAP(n_components=2, random_state=42, n_neighbors=15, min_dist=0.1)
        emb = reducer.fit_transform(combined)
    else:
        from sklearn.decomposition import PCA
        reducer = PCA(n_components=2, random_state=42)
        emb = reducer.fit_transform(combined)

    data_emb = emb[:len(X)]
    seeds_emb = emb[len(X):len(X) + K]
    query_emb = emb[-1]

    # Voronoi regions with trace highlighting
    if K >= 3:
        try:
            vor = Voronoi(seeds_emb)
            regions, vertices = _voronoi_finite_polygons_2d(vor, data_extent=data_emb)
            for k_idx, region in enumerate(regions):
                if len(region) == 0:
                    continue
                polygon = vertices[region]
                if k_idx == i:
                    # Seed i: yellow, alpha = t (brighter when t is small = closer to i)
                    ax.fill(*zip(*polygon), alpha=max(0.1, 1.0 - t) * 0.5,
                            facecolor="gold", edgecolor="black", linewidth=0.5, zorder=0)
                elif k_idx == j:
                    # Seed j: yellow, alpha = 1-t (brighter when t is large = closer to j)
                    ax.fill(*zip(*polygon), alpha=max(0.1, t) * 0.5,
                            facecolor="gold", edgecolor="black", linewidth=0.5, zorder=0)
                else:
                    # All other: gray
                    ax.fill(*zip(*polygon), alpha=0.08,
                            facecolor="gray", edgecolor="black", linewidth=0.3, zorder=0)
        except Exception:
            pass

    # Data scatter (dim background)
    ax.scatter(data_emb[:, 0], data_emb[:, 1],
               c=y, s=1, alpha=0.1, cmap=cmap, zorder=1)

    # Geodesic path: gray for non-active edges, yellow for active edge
    for k_idx in range(K):
        k_next = (k_idx + 1) % K
        is_active = (k_idx == i and k_next == j) or (k_idx == j and k_next == i)
        color = "gold" if is_active else "blue"
        alpha = 0.9 if is_active else 0.2
        lw = 2.5 if is_active else 0.6
        ax.annotate("",
                    xy=(seeds_emb[k_next, 0], seeds_emb[k_next, 1]),
                    xytext=(seeds_emb[k_idx, 0], seeds_emb[k_idx, 1]),
                    arrowprops=dict(arrowstyle="-|>", color=color,
                                    lw=lw, alpha=alpha),
                    zorder=3 if is_active else 2)

    # Seeds: small gray stars, except i and j
    for k_idx in range(K):
        if k_idx == i or k_idx == j:
            continue
        ax.scatter(seeds_emb[k_idx, 0], seeds_emb[k_idx, 1],
                   c="gray", s=30, marker="*", edgecolors="black",
                   linewidths=0.3, alpha=0.4, zorder=4)

    # Seeds i and j: larger, yellow
    ax.scatter(seeds_emb[i, 0], seeds_emb[i, 1],
               c="gold", s=100, marker="*", edgecolors="black",
               linewidths=1.0, zorder=5)
    ax.scatter(seeds_emb[j, 0], seeds_emb[j, 1],
               c="gold", s=100, marker="*", edgecolors="black",
               linewidths=1.0, zorder=5)

    # Purple dot at the parametric position on the active edge
    arc_x = seeds_emb[i, 0] + t * (seeds_emb[j, 0] - seeds_emb[i, 0])
    arc_y = seeds_emb[i, 1] + t * (seeds_emb[j, 1] - seeds_emb[i, 1])
    ax.scatter(arc_x, arc_y, c="purple", s=60, marker="o",
               edgecolors="black", linewidths=1.0, zorder=6)

    # Query point: red X
    ax.scatter(query_emb[0], query_emb[1], c="red", s=80, marker="X",
               edgecolors="black", linewidths=1.0, zorder=7)

    # Axis cleanup
    margin = 0.05
    x_range = data_emb[:, 0].max() - data_emb[:, 0].min()
    y_range = data_emb[:, 1].max() - data_emb[:, 1].min()
    ax.set_xlim(data_emb[:, 0].min() - margin * x_range,
                data_emb[:, 0].max() + margin * x_range)
    ax.set_ylim(data_emb[:, 1].min() - margin * y_range,
                data_emb[:, 1].max() + margin * y_range)
    ax.set_xticks([])
    ax.set_yticks([])


def _resolve_format(output_path, fmt):
    if fmt is None:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                fmt = ext[1:]
                output_path = output_path[:-len(ext)]
                return fmt, output_path
        fmt = "png"
    else:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                output_path = output_path[:-len(ext)]
                break
    return fmt, output_path
