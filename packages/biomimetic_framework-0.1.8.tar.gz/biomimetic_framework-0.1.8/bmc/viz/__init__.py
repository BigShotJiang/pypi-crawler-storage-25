# bmc/viz/__init__.py
"""
BMC architecture visualization.

    from bmc.viz import summary, diagram

    summary(model)                    # print CLI tree to terminal
    diagram(model, "architecture")    # write architecture.svg
"""

from bmc.viz.summary import summary
from bmc.viz.diagram import diagram
from bmc.viz.data import scatter
from bmc.viz.composite import architecture
from bmc.viz.trace import trace
from bmc.viz.manifold import parametric, riemannian

__all__ = ["summary", "diagram", "scatter", "architecture", "trace",
           "parametric", "riemannian"]
