# bmc/viz/diagram.py
"""
Architecture diagram — black and white, LTR horizontal layout.
Includes memory footprint. No fitted/unfitted status. No M variable.
"""

from bmc.viz.arch import extract, NetworkInfo, LayerInfo, CellInfo, _format_bytes

ZONE_EXPAND_THRESHOLD = 6


def diagram(model, output_path: str = "bmc_architecture", fmt: str = None):
    """
    Generate an architecture diagram.

    Parameters
    ----------
    model : BMCCell, BMCLayer, BMCNetwork, BMCSkipConnection, BMCClassifier, or BMCRegressor
    output_path : str
        Output file path. Format inferred from extension (.svg, .pdf, .png).
        Defaults to SVG.
    fmt : str, optional
        Override output format.

    Returns
    -------
    path : str
        Path to the generated file.
    """
    try:
        import graphviz
    except ImportError:
        raise ImportError(
            "graphviz is required for diagram generation. "
            "Install with: pip install graphviz"
        )

    if fmt is None:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                fmt = ext[1:]
                output_path = output_path[:-len(ext)]
                break
        else:
            fmt = "svg"

    info = extract(model)
    dot = _build_graph(info)
    dot.render(output_path, format=fmt, cleanup=True)
    return f"{output_path}.{fmt}"


def _build_graph(info: NetworkInfo):
    import graphviz

    dot = graphviz.Digraph(
        name="bmc_architecture",
        graph_attr={
            "rankdir": "LR",
            "fontname": "Helvetica",
            "fontsize": "10",
            "bgcolor": "white",
            "pad": "0.3",
            "nodesep": "0.4",
            "ranksep": "0.7",
        },
        node_attr={
            "fontname": "Helvetica",
            "fontsize": "9",
            "shape": "box",
            "style": "rounded",
            "color": "black",
            "fontcolor": "black",
            "penwidth": "1.0",
        },
        edge_attr={
            "fontname": "Helvetica",
            "fontsize": "8",
            "color": "black",
            "fontcolor": "black",
            "arrowsize": "0.6",
        },
    )

    # Input box
    dot.node("input", label=f"Input\\n{info.input_desc}", penwidth="1.5")

    prev_id = "input"

    for i, stage in enumerate(info.stages):
        stage_id = f"s{i}"

        if isinstance(stage, LayerInfo):
            _add_layer(dot, stage, stage_id)
            dot.edge(prev_id, f"{stage_id}_obs")
            prev_id = f"{stage_id}_out"

        elif isinstance(stage, CellInfo):
            _add_cell(dot, stage, stage_id)
            dot.edge(prev_id, stage_id)
            prev_id = stage_id

    # Output box (same style as input)
    dot.node("output", label=f"Output\\n{info.output_desc}", penwidth="1.5")
    dot.edge(prev_id, "output")

    return dot


def _cell_label(cell: CellInfo) -> str:
    lines = ["BMCCell"]
    lines.append(f"K={cell.K}")
    if cell.D is not None:
        lines.append(f"Dim in: {cell.D}")
    if cell.C is not None:
        lines.append(f"Dim out: {cell.C}")
    lines.append(f"Metric: {cell.metric}")
    if cell.interpolator:
        lines.append(f"Interpolator: {cell.interpolator}")
    if cell.memory_str:
        lines.append(f"Memory: {cell.memory_str}")
    return "\\n".join(lines)


def _add_cell(dot, cell: CellInfo, node_id: str):
    dot.node(node_id, label=_cell_label(cell))


def _add_layer(dot, layer: LayerInfo, stage_id: str):
    obs = layer.obs_space
    cell = layer.cell_template
    n = layer.n_zones

    with dot.subgraph(name=f"cluster_{stage_id}") as sub:
        sub.attr(
            label=f"BMCLayer  ({n} BMCCells)",
            labeljust="l",
            style="rounded,dashed",
            color="black",
            fontname="Helvetica",
            fontsize="9",
            penwidth="0.8",
        )

        # Observation Space
        obs_label = (
            f"Observation Space\\n"
            f"{obs.type_name}\\n"
            f"{obs.decomposition}"
        )
        sub.node(f"{stage_id}_obs", label=obs_label, style="rounded,dashed")

        # BMCCells
        if n <= ZONE_EXPAND_THRESHOLD:
            for z in range(n):
                zid = f"{stage_id}_c{z}"
                label = f"BMCCell\\nK={cell.K}"
                if cell.D is not None:
                    label += f"\\nDim: {cell.D}"
                label += f"\\nMetric: {cell.metric}"
                if cell.memory_str:
                    label += f"\\n{cell.memory_str}"
                sub.node(zid, label=label)
                sub.edge(f"{stage_id}_obs", zid)
        else:
            label = f"BMCCell \u00d7{n}\\nK={cell.K}"
            if cell.D is not None:
                label += f"\\nDim: {cell.D}"
            label += f"\\nMetric: {cell.metric}"
            if layer.total_memory_str:
                label += f"\\nTotal: {layer.total_memory_str}"
            sub.node(f"{stage_id}_cells", label=label)
            sub.edge(f"{stage_id}_obs", f"{stage_id}_cells")

        # Output of layer
        sub.node(f"{stage_id}_out",
                 label=f"Output\\n{layer.output_dim_desc}",
                 penwidth="1.0")

        if n <= ZONE_EXPAND_THRESHOLD:
            for z in range(n):
                sub.edge(f"{stage_id}_c{z}", f"{stage_id}_out")
        else:
            sub.edge(f"{stage_id}_cells", f"{stage_id}_out")
