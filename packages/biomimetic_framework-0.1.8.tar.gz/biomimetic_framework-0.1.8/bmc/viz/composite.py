# bmc/viz/composite.py
"""
Composite architecture + data visualization.

Renders the architecture pipeline with actual UMAP/PCA scatter plots
embedded inside each cell box, replacing text labels.

    from bmc.viz import architecture
    architecture(model, X, y, "arch.png")
"""

import numpy as np
from typing import Optional, List
from bmc.viz.data import _reduce_2d, _voronoi_finite_polygons_2d


ZONE_GRID_MAX = 25  # max zones to show individually


def architecture(model, X: np.ndarray, y: np.ndarray,
                 output_path: str = "bmc_architecture",
                 fmt: str = None,
                 class_names: Optional[List[str]] = None,
                 method: str = "umap"):
    """
    Architecture diagram with scatter plots embedded in cell boxes.

    Parameters
    ----------
    model : BMCCell, BMCLayer, BMCNetwork, BMCClassifier, or BMCRegressor
    X : np.ndarray — training data
    y : np.ndarray — integer labels for coloring
    output_path : str
    fmt : str, optional
    class_names : list of str, optional
    method : str — "umap" or "pca"

    Returns
    -------
    path : str
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    from bmc.core.cell import BMCCell
    from bmc.composition.layer import BMCLayer
    from bmc.composition.sequential import BMCNetwork
    from bmc.model.classifier import BMCClassifier
    from bmc.model.regressor import BMCRegressor

    fmt, output_path = _resolve_format(output_path, fmt)

    # Unwrap to get the layer/cell structure + zone vectors
    is_regressor = isinstance(model, BMCRegressor)

    if isinstance(model, BMCClassifier):
        model = model._model
    elif isinstance(model, BMCRegressor):
        # Regressor: extract zone cells and obs space
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        zone_vectors = model._obs.extract(X)
        zone_cells = model._zone_cells
        head_cell = model._head_cell
        # Build zone predictions for head cell input
        head_input = None
        if head_cell is not None:
            head_input = np.column_stack([
                cell.predict_regression(zone_vectors[z])
                for z, cell in enumerate(zone_cells)
            ])
        return _render_composite(
            zone_cells, zone_vectors, y, head_cell, head_input,
            output_path, fmt, class_names, method,
            obs_label=type(model._obs).__name__.replace("ObservationSpace", ""),
        )

    if isinstance(model, BMCNetwork):
        if not all(hasattr(l, 'is_fitted_') and l.is_fitted_ for l in model.layers):
            raise ValueError("Model is not fitted.")

        # Find the BMCLayer and subsequent BMCCells
        layer = None
        head_cells = []
        for l in model.layers:
            if isinstance(l, BMCLayer) and layer is None:
                layer = l
            elif isinstance(l, BMCCell):
                head_cells.append(l)

        if layer is None:
            raise ValueError("No BMCLayer found in network.")

        zone_vectors = layer.observation_space.extract(X)
        zone_cells = layer.layers_

        # Build chain: zone output → flatten → head cells
        head_cell = head_cells[0] if head_cells else None
        head_input = None
        if head_cell is not None:
            vote_matrix = layer.transform(X)
            head_input = vote_matrix.reshape(len(X), -1).astype(np.float32)

        return _render_composite(
            zone_cells, zone_vectors, y, head_cell, head_input,
            output_path, fmt, class_names, method,
            obs_label=type(layer.observation_space).__name__.replace("ObservationSpace", ""),
        )

    if isinstance(model, BMCLayer):
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        zone_vectors = model.observation_space.extract(X)
        return _render_composite(
            model.layers_, zone_vectors, y, None, None,
            output_path, fmt, class_names, method,
            obs_label=type(model.observation_space).__name__.replace("ObservationSpace", ""),
        )

    if isinstance(model, BMCCell):
        if not model.is_fitted_:
            raise ValueError("Model is not fitted.")
        # Single cell — just one scatter with Input/Output labels
        return _render_single_cell(model, X.reshape(len(X), -1), y,
                                   output_path, fmt, class_names, method)

    raise TypeError(f"Cannot render {type(model).__name__}")


def _render_single_cell(cell, X, y, output_path, fmt, class_names, method):
    """Single cell with Input/Output labels on sides."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(8, 6))
    _draw_cell_scatter(ax, cell, X.astype(np.float32), y, class_names, method)
    ax.set_title(f"BMCCell  K={cell.n_clusters}", fontsize=10)
    plt.tight_layout()
    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _render_composite(zone_cells, zone_vectors, y, head_cell, head_input,
                      output_path, fmt, class_names, method, obs_label=""):
    """
    Composite: Input → ObsSpace → [zone scatter grid] → head scatter → Output
    Arranged LTR with matplotlib axes.
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyArrowPatch

    n_zones = len(zone_cells)
    has_head = head_cell is not None

    # Grid layout: zones arranged in a grid within the layer column
    zone_cols = min(n_zones, 5)
    zone_rows = (n_zones + zone_cols - 1) // zone_cols

    # Total columns: obs_label | zone_grid | [head] | output
    n_stage_cols = 1 + (1 if has_head else 0)  # zone grid + optional head

    # Figure sizing
    cell_size = 2.5  # size per scatter subplot
    fig_w = 2.0 + zone_cols * cell_size + (cell_size + 1.0 if has_head else 0) + 1.5
    fig_h = max(zone_rows * cell_size + 1.5, 4)

    fig = plt.figure(figsize=(fig_w, fig_h))

    # Compute layout regions (as fractions of figure)
    left_margin = 0.08
    right_margin = 0.06
    obs_width = 0.08  # observation space label strip
    zone_width = zone_cols * cell_size / fig_w
    head_width = (cell_size + 0.5) / fig_w if has_head else 0
    arrow_gap = 0.03

    zone_left = left_margin + obs_width + arrow_gap
    head_left = zone_left + zone_width + arrow_gap
    bottom_margin = 0.08
    top_margin = 0.06
    plot_height = 1.0 - bottom_margin - top_margin

    # ── Observation Space label ──
    ax_obs = fig.add_axes([left_margin, bottom_margin, obs_width - 0.01, plot_height])
    ax_obs.set_xlim(0, 1)
    ax_obs.set_ylim(0, 1)
    ax_obs.text(0.5, 0.5, f"Observation\nSpace\n({obs_label})",
                ha="center", va="center", fontsize=8, rotation=90,
                fontstyle="italic")
    ax_obs.set_xticks([])
    ax_obs.set_yticks([])
    for spine in ax_obs.spines.values():
        spine.set_linestyle("--")
        spine.set_linewidth(0.5)

    # ── Zone cell scatter plots ──
    cell_w = zone_width / zone_cols
    cell_h = plot_height / zone_rows

    for z in range(n_zones):
        row = z // zone_cols
        col = z % zone_cols
        ax_x = zone_left + col * cell_w + 0.005
        ax_y = bottom_margin + (zone_rows - 1 - row) * cell_h + 0.005
        ax = fig.add_axes([ax_x, ax_y, cell_w - 0.01, cell_h - 0.01])

        cell = zone_cells[z]
        X_zone = zone_vectors[z].astype(np.float32)
        _draw_cell_scatter(ax, cell, X_zone, y, class_names, method, compact=True)
        ax.set_title(f"Zone {z}", fontsize=7, pad=2)

    # ── Dashed rectangle around zone grid ──
    rect = plt.Rectangle(
        (zone_left - 0.005, bottom_margin - 0.005),
        zone_width + 0.01, plot_height + 0.01,
        transform=fig.transFigure, figure=fig,
        fill=False, edgecolor="black", linewidth=1.0, linestyle="--",
    )
    fig.patches.append(rect)
    fig.text(zone_left + zone_width / 2, 1.0 - top_margin + 0.01,
             f"BMCLayer  ({n_zones} cells)", ha="center", fontsize=9,
             fontweight="bold")

    # ── Head cell scatter (if present) ──
    if has_head and head_input is not None:
        ax_head = fig.add_axes([head_left, bottom_margin + plot_height * 0.15,
                                head_width - 0.02, plot_height * 0.7])
        _draw_cell_scatter(ax_head, head_cell, head_input.astype(np.float32),
                           y, class_names, method, compact=True)
        ax_head.set_title("Prediction Head", fontsize=8, pad=2)

    # ── Input / Output labels ──
    fig.text(0.02, 0.5, "Input", ha="center", va="center", fontsize=9,
             fontweight="bold", rotation=90)
    fig.text(0.98, 0.5, "Output", ha="center", va="center", fontsize=9,
             fontweight="bold", rotation=270)

    path = f"{output_path}.{fmt}"
    fig.savefig(path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return path


def _draw_cell_scatter(ax, cell, X, y, class_names, method, compact=False):
    """Draw Voronoi + geodesic scatter on a given axes."""
    from scipy.spatial import Voronoi

    seeds = cell.seeds_
    K = len(seeds)
    lut = cell.lut_
    C = lut.shape[1]

    # Dominant class per seed (for Voronoi coloring)
    if C > 1:
        dominant = np.argmax(lut, axis=1)
    else:
        # Regression: no dominant class, use uniform gray
        dominant = np.zeros(K, dtype=int)

    n_classes = max(C, int(y.max()) + 1)
    if n_classes <= 10:
        cmap = __import__("matplotlib.pyplot", fromlist=["colormaps"]).colormaps["tab10"]
    elif n_classes <= 20:
        cmap = __import__("matplotlib.pyplot", fromlist=["colormaps"]).colormaps["tab20"]
    else:
        cmap = __import__("matplotlib.pyplot", fromlist=["colormaps"]).colormaps["viridis"].resampled(n_classes)

    data_emb, seeds_emb, axis_labels = _reduce_2d(X, seeds, method)

    # Voronoi regions
    if K >= 3:
        try:
            vor = Voronoi(seeds_emb)
            regions, vertices = _voronoi_finite_polygons_2d(vor)
            for i, region in enumerate(regions):
                if len(region) == 0:
                    continue
                polygon = vertices[region]
                ax.fill(*zip(*polygon), alpha=0.12,
                        facecolor=cmap(dominant[i] % cmap.N) if C > 1 else "gray",
                        edgecolor="black", linewidth=0.3, zorder=0)
        except Exception:
            pass  # Voronoi can fail for degenerate configs

    # Data scatter
    dot_size = 1 if compact else 2
    ax.scatter(data_emb[:, 0], data_emb[:, 1],
               c=y, s=dot_size, alpha=0.15, cmap=cmap, zorder=1)

    # Geodesic arrows
    arrow_lw = 0.8 if compact else 1.5
    for i in range(K):
        j = (i + 1) % K
        ax.annotate("",
                    xy=(seeds_emb[j, 0], seeds_emb[j, 1]),
                    xytext=(seeds_emb[i, 0], seeds_emb[i, 1]),
                    arrowprops=dict(arrowstyle="-|>", color="blue",
                                    lw=arrow_lw, alpha=0.5),
                    zorder=3)

    # Seeds
    star_size = 40 if compact else 120
    if C > 1:
        seed_colors = [cmap(dominant[k] % cmap.N) for k in range(K)]
    else:
        seed_colors = "red"
    ax.scatter(seeds_emb[:, 0], seeds_emb[:, 1],
               c=seed_colors, s=star_size, marker="*",
               edgecolors="black", linewidths=0.5, zorder=4)

    # Axis cleanup
    margin = 0.05
    x_range = data_emb[:, 0].max() - data_emb[:, 0].min()
    y_range = data_emb[:, 1].max() - data_emb[:, 1].min()
    ax.set_xlim(data_emb[:, 0].min() - margin * x_range,
                data_emb[:, 0].max() + margin * x_range)
    ax.set_ylim(data_emb[:, 1].min() - margin * y_range,
                data_emb[:, 1].max() + margin * y_range)

    if compact:
        ax.set_xticks([])
        ax.set_yticks([])
    else:
        ax.set_xlabel(axis_labels[0], fontsize=8)
        ax.set_ylabel(axis_labels[1], fontsize=8)


def _resolve_format(output_path, fmt):
    if fmt is None:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                fmt = ext[1:]
                output_path = output_path[:-len(ext)]
                return fmt, output_path
        fmt = "png"
    else:
        for ext in (".svg", ".pdf", ".png"):
            if output_path.endswith(ext):
                output_path = output_path[:-len(ext)]
                break
    return fmt, output_path
