# bmc/core/rvq.py
"""
Residual Vector Quantization — training algorithm for sequential BMC.

Trains a sequence of BMCCells on progressively refined residuals.
Each cell learns to approximate the residual left by all previous cells.
The accumulated reconstruction converges to the input X.

This is a training algorithm, not a model. It fits cells that the caller
owns and places wherever they want — in a BMCNetwork, standalone, etc.

Usage:
    from bmc.core.rvq import fit_rvq

    cells = [BMCCell(n_clusters=2) for _ in range(32)]
    n_used = fit_rvq(cells, X, convergence_threshold=0.1)
    # cells[0:n_used] are now fitted. The rest are untouched.

    # Reconstruct:
    from bmc.core.rvq import reconstruct_rvq
    recon = reconstruct_rvq(cells[:n_used], X)

Theory:
    Residual Vector Quantization (Juang & Gray, 1982).
    Successive Refinement (Equitz & Cover, 1991).
    Optimal for Gaussian sources under MSE.
"""

import numpy as np
from typing import List, Optional

from bmc.core.cell import BMCCell
from bmc.core.interpolators import LinearInterpolator, Interpolator


def fit_rvq(
    cells: List[BMCCell],
    X: np.ndarray,
    convergence_threshold: float = 0.1,
) -> int:
    """
    Train a sequence of BMCCells using Residual Vector Quantization.

    Each cell is fitted on the current residual via fit_regression
    (one pass per output dimension). The residual shrinks at each step.
    Stops when MSE < convergence_threshold or all cells are used.

    Parameters
    ----------
    cells : list of BMCCell
        Pre-constructed cells (with desired K, interpolator, metric, rng).
        Cells are fitted in place. Only the cells up to the convergence
        point are modified; the rest are left untouched.
    X : ndarray, (M, D), float32
        Training data to reconstruct.
    convergence_threshold : float
        Stop when residual MSE drops below this. Default 0.1.
        Set to 0.0 to fit all cells.

    Returns
    -------
    n_used : int
        Number of cells actually fitted (may be < len(cells)).

    Notes
    -----
    Each cell is fitted D times (once per dimension) using fit_regression.
    The cell's seeds and geodesic are determined by the residual's geometry
    at that stage. The interpolator (if set on the cell) enables smooth
    reconstruction between seeds.

    After fitting, use reconstruct_rvq() to compute the accumulated
    reconstruction for new data.
    """
    X = np.asarray(X, dtype=np.float32)
    M, D = X.shape
    residual = X.copy().astype(np.float64)
    accumulated = np.zeros_like(X, dtype=np.float64)

    n_used = 0
    for cell in cells:
        # Fit this cell on the residual: one regression per dimension.
        # We store per-dimension cells as a list in cell._rvq_dim_cells_.
        # This is the only RVQ-specific state added to the cell.
        dim_cells = []
        recon_layer = np.zeros_like(residual)

        K = min(cell.n_clusters, M)

        for d in range(D):
            dim_cell = BMCCell(
                n_clusters=K,
                interpolator=(LinearInterpolator() if cell.interpolator is None
                              else type(cell.interpolator)()
                              if isinstance(cell.interpolator, Interpolator)
                              else LinearInterpolator()),
                metric=cell.metric,
                rng=np.random.default_rng(
                    int(cell.rng.integers(0, 2**31)) + d
                ),
            )
            dim_cell.fit_regression(
                residual.astype(np.float32),
                residual[:, d],
            )
            recon_layer[:, d] = dim_cell.predict_regression(
                residual.astype(np.float32)
            )
            dim_cells.append(dim_cell)

        accumulated += recon_layer
        residual = X.astype(np.float64) - accumulated

        # Store the per-dimension cells on the parent cell
        cell._rvq_dim_cells_ = dim_cells
        cell._rvq_fitted_ = True
        n_used += 1

        mse = float(np.mean(residual ** 2))
        if mse < convergence_threshold:
            break

    return n_used


def reconstruct_rvq(
    cells: List[BMCCell],
    X: np.ndarray,
) -> np.ndarray:
    """
    Compute the accumulated RVQ reconstruction.

    Parameters
    ----------
    cells : list of BMCCell
        Cells previously fitted by fit_rvq().
    X : ndarray, (M, D), float32
        Input data (same space as training data).

    Returns
    -------
    reconstruction : ndarray, (M, D), float32
        Accumulated reconstruction from all cells.
    """
    X = np.asarray(X, dtype=np.float32)
    D = X.shape[1]
    residual = X.copy().astype(np.float64)
    accumulated = np.zeros_like(X, dtype=np.float64)

    for cell in cells:
        if not getattr(cell, '_rvq_fitted_', False):
            break
        dim_cells = cell._rvq_dim_cells_
        recon_layer = np.zeros_like(residual)
        for d, dc in enumerate(dim_cells):
            recon_layer[:, d] = dc.predict_regression(
                residual.astype(np.float32)
            )
        accumulated += recon_layer
        residual = X.astype(np.float64) - accumulated

    return accumulated.astype(np.float32)


def residual_mse_history(
    cells: List[BMCCell],
    X: np.ndarray,
) -> List[float]:
    """
    Compute the residual MSE after each RVQ layer.

    Parameters
    ----------
    cells : list of BMCCell
        Cells previously fitted by fit_rvq().
    X : ndarray, (M, D)

    Returns
    -------
    history : list of float
        MSE after each layer.
    """
    X = np.asarray(X, dtype=np.float32)
    residual = X.copy().astype(np.float64)
    accumulated = np.zeros_like(X, dtype=np.float64)
    history = []

    for cell in cells:
        if not getattr(cell, '_rvq_fitted_', False):
            break
        dim_cells = cell._rvq_dim_cells_
        recon_layer = np.zeros_like(residual)
        for d, dc in enumerate(dim_cells):
            recon_layer[:, d] = dc.predict_regression(
                residual.astype(np.float32)
            )
        accumulated += recon_layer
        residual = X.astype(np.float64) - accumulated
        history.append(float(np.mean(residual ** 2)))

    return history
