# bmc/model/regressor.py
"""
BMCRegressor — high-level fit/predict interface for regression.

Uses the same BMCCell and BMCLayer infrastructure as BMCClassifier.
The only differences:
  - Cells use fit_regression() instead of fit() (LUT stores means, not distributions)
  - Interpolation is enabled by default
  - predict() returns continuous values instead of argmax

Architecture:
- ObservationSpace → BMCLayer of N zone cells (each fit_regression)
- Optional prediction head: another BMCCell (fit_regression on zone outputs)
"""

import copy
import os
import numpy as np
from typing import Optional, Union

from bmc.model.base import BMCModel
from bmc.observation.base import ObservationSpace
from bmc.observation.tabular import TabularObservationSpace
from bmc.core.cell import BMCCell
from bmc.core.interpolators import (
    Interpolator, LinearInterpolator, SplineInterpolator, RDDAInterpolator,
)
from bmc.metrics.base import SimilarityMetric
from bmc.metrics.l2 import L2Metric


def _fit_zone_regression(args):
    """Worker for parallel zone fitting (regression mode)."""
    vectors, targets, n_clusters, metric, interpolator_template, seed_int = args
    interp = copy.deepcopy(interpolator_template)
    cell = BMCCell(
        n_clusters=n_clusters,
        metric=metric,
        interpolator=interp,
        rng=np.random.default_rng(seed_int),
    )
    cell.fit_regression(vectors, targets)
    return cell


class BMCRegressor(BMCModel):
    """
    High-level BMC regressor with sklearn-compatible interface.

    Uses the same BMCCell primitive as BMCClassifier. Each zone cell
    stores mean target values per Voronoi cell and uses geodesic
    interpolation to predict continuous values.

    Parameters
    ----------
    observation_space : ObservationSpace, optional
    n_clusters : int
        Voronoi cells per zone. Default: 128.
    n_clusters_l2 : int, str, or None
        Clusters for the prediction head. Default: "auto" (same as n_clusters).
        Set to None to disable and use raw zone averaging.
    metric : SimilarityMetric, optional
    interpolate : bool
        Default: True (regression benefits from interpolation).
    interpolator : Interpolator, optional
        Explicit strategy. Overrides interpolate flag.
    rng : np.random.Generator, optional
    """

    def __init__(
        self,
        observation_space: Optional[ObservationSpace] = None,
        n_clusters: int = 128,
        n_clusters_l2: Union[int, str, None] = "auto",
        metric: Optional[SimilarityMetric] = None,
        interpolate: bool = True,
        interpolator: Optional[Interpolator] = None,
        rng: Optional[np.random.Generator] = None,
    ):
        self.observation_space = observation_space
        self.n_clusters = n_clusters
        self.n_clusters_l2 = n_clusters_l2
        self.metric = metric if metric is not None else L2Metric()
        self.interpolate = interpolate
        self.rng = rng if rng is not None else np.random.default_rng(42)

        # Zone cells always interpolate for smooth zone outputs
        self._zone_interpolator_template = LinearInterpolator()

        if interpolator is not None:
            self._head_interpolator_template = interpolator
        elif interpolate:
            self._head_interpolator_template = LinearInterpolator()
        else:
            self._head_interpolator_template = None

        self._obs: Optional[ObservationSpace] = None
        self._zone_cells: Optional[list] = None  # List[BMCCell]
        self._head_cell: Optional[BMCCell] = None
        self._y_min: Optional[float] = None
        self._y_max: Optional[float] = None
        self.is_fitted_: bool = False

    def fit(self, X: np.ndarray, y: np.ndarray) -> "BMCRegressor":
        """
        Fit the regressor.

        Parameters
        ----------
        X : np.ndarray, shape (M, ...)
        y : np.ndarray, shape (M,), continuous

        Returns
        -------
        self
        """
        X = np.asarray(X)
        y = np.asarray(y, dtype=np.float64)

        self._y_min = float(y.min())
        self._y_max = float(y.max())

        # Resolve observation space
        if self.observation_space is None:
            if X.ndim == 2:
                n_features = X.shape[1]
                n_zones = min(n_features, 10)
                self._obs = TabularObservationSpace(n_features, n_zones=n_zones)
            else:
                raise ValueError(
                    "observation_space must be specified for non-tabular inputs."
                )
        else:
            self._obs = self.observation_space

        # Resolve n_clusters_l2
        n_clusters_l2 = self.n_clusters_l2
        if n_clusters_l2 == "auto":
            n_clusters_l2 = self.n_clusters

        # Extract zone vectors
        zone_vectors = self._obs.extract(X)  # (N_zones, M, D)
        N_zones = zone_vectors.shape[0]

        # Pre-generate per-zone seeds
        zone_seeds = [int(self.rng.integers(0, 2**31)) for _ in range(N_zones)]

        # Fit zone cells (parallel if possible)
        n_workers = min(N_zones, os.cpu_count() or 1)
        if n_workers > 1 and N_zones >= 4:
            from concurrent.futures import ThreadPoolExecutor
            args_list = [
                (zone_vectors[z], y, self.n_clusters, self.metric,
                 self._zone_interpolator_template, zone_seeds[z])
                for z in range(N_zones)
            ]
            with ThreadPoolExecutor(max_workers=n_workers) as executor:
                self._zone_cells = list(executor.map(_fit_zone_regression, args_list))
        else:
            self._zone_cells = []
            for z in range(N_zones):
                interp = copy.deepcopy(self._zone_interpolator_template)
                cell = BMCCell(
                    n_clusters=self.n_clusters,
                    metric=self.metric,
                    interpolator=interp,
                    rng=np.random.default_rng(zone_seeds[z]),
                )
                cell.fit_regression(zone_vectors[z], y)
                self._zone_cells.append(cell)

        # Optional prediction head
        if n_clusters_l2 is not None:
            # Zone predictions as input to head
            zone_preds = np.column_stack([
                cell.predict_regression(zone_vectors[z])
                for z, cell in enumerate(self._zone_cells)
            ])  # (M, N_zones)

            head_interp = copy.deepcopy(self._head_interpolator_template) \
                if self._head_interpolator_template else None
            self._head_cell = BMCCell(
                n_clusters=n_clusters_l2,
                metric=self.metric,
                interpolator=head_interp,
                rng=np.random.default_rng(int(self.rng.integers(0, 2**31))),
            )
            self._head_cell.fit_regression(zone_preds, y)

        self.is_fitted_ = True
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict continuous values.

        Parameters
        ----------
        X : np.ndarray

        Returns
        -------
        predictions : np.ndarray, shape (M,), float64
        """
        self._check_fitted()
        X = np.asarray(X)
        zone_vectors = self._obs.extract(X)

        if self._head_cell is not None:
            zone_preds = np.column_stack([
                cell.predict_regression(zone_vectors[z])
                for z, cell in enumerate(self._zone_cells)
            ])
            preds = self._head_cell.predict_regression(zone_preds)
        else:
            preds = np.zeros(len(X), dtype=np.float64)
            for z, cell in enumerate(self._zone_cells):
                preds += cell.predict_regression(zone_vectors[z])
            preds /= len(self._zone_cells)

        return np.clip(preds, self._y_min, self._y_max)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Return per-zone predictions as columns for inspection.

        Parameters
        ----------
        X : np.ndarray

        Returns
        -------
        zone_predictions : np.ndarray, shape (M, N_zones)
        """
        self._check_fitted()
        X = np.asarray(X)
        zone_vectors = self._obs.extract(X)

        return np.column_stack([
            cell.predict_regression(zone_vectors[z])
            for z, cell in enumerate(self._zone_cells)
        ])

    def _check_fitted(self):
        if not self.is_fitted_:
            raise RuntimeError("BMCRegressor is not fitted. Call fit() first.")

    def __repr__(self) -> str:
        status = "fitted" if self.is_fitted_ else "unfitted"
        interp_str = repr(self._head_interpolator_template) \
            if self._head_interpolator_template else "None"
        l2_str = f", n_clusters_l2={self.n_clusters_l2}" if self.n_clusters_l2 else ""
        return (
            f"BMCRegressor("
            f"n_clusters={self.n_clusters}{l2_str}, "
            f"interpolator={interp_str}, "
            f"status={status})"
        )
