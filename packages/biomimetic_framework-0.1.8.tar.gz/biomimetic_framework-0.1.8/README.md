# BMC — Biomimetic Cell

A gradient-free machine learning framework built on geodesic lookup tables.

Instead of learned weights, BMC stores empirical probability distributions in Voronoi cells ordered along a geodesic path through the data manifold. No backpropagation. No loss functions. No optimizer. Just geometry.

Based on three papers by Dr. Ziad Kobti:
- [Bio-mimetic approach in digital artificial neuro-science](https://ieeexplore.ieee.org/document/7560120)
- [Biomimetic Cells: A New Frontier in Brain Informatics](https://ieeexplore.ieee.org/abstract/document/8603044)
- [Advanced Biomimetic Cells Architecture for Parallel Operations in AI](https://ieeexplore.ieee.org/abstract/document/8851116)

[Available on PyPI](https://pypi.org/project/biomimetic-framework/)

---

## Installation

```bash
pip install biomimetic-framework
```

Optional extras:

```bash
pip install biomimetic-framework[image]  # image observation space (Pillow, PyTorch, OpenCV)
pip install biomimetic-framework[gpu]    # GPU-accelerated pairwise distances (PyTorch CUDA)
pip install biomimetic-framework[viz]    # visualization (Rich, Graphviz)
```

---

## Quick Start

### Classification

```python
from bmc import BMCClassifier

clf = BMCClassifier(n_clusters=128)
clf.fit(X_train, y_train)
predictions = clf.predict(X_test)
probabilities = clf.predict_proba(X_test)
```

### Regression

```python
from bmc import BMCRegressor

reg = BMCRegressor(n_clusters=128)
reg.fit(X_train, y_train)
predictions = reg.predict(X_test)
```

### Full Control

```python
from bmc import (
    ImageObservationSpace, BMCLayer, BMCNetwork, BMCCell,
    L2Metric, SplineInterpolator,
)

# Define how to decompose inputs
obs = ImageObservationSpace(image_size=28, pool_size=10, grid_n=5, output_size=5)

# Build a 2-layer network
net = BMCNetwork([
    BMCLayer(obs, n_clusters=128, metric=L2Metric()),
    BMCCell(n_clusters=128),  # prediction head
])
net.fit(X_train, y_train, n_classes=10)
predictions = net.predict(X_test)
```

---

## How It Works

```
raw input
    +-- ObservationSpace.extract()  -->  (N, M, D)  zone feature vectors
            +-- BMCLayer.fit()      -->  N independent BMCCells
                    +-- BMCLayer.transform()  -->  (M, N, C)  vote matrix
                            +-- BMCNetwork  -->  prediction head refines votes
                                    +-- argmax  -->  (M,)  predictions
```

**Training** (per BMCCell):
1. K-means++ initialization + mini-batch Lloyd's iteration --> K converged cluster centers
2. Voronoi assignment --> each sample assigned to nearest center
3. LUT construction --> `P(class | cell)` from empirical counts
4. TSP geodesic ordering --> binary addresses with geometric meaning
5. Interpolator fitting --> smooth predictions across cell boundaries

**Inference**: find nearest seed --> look up stored distribution --> done.

---

## Architecture

| Component | Role |
|---|---|
| `BMCCell` | Atomic primitive. One zone, K Voronoi cells, one LUT. |
| `BMCLayer` | N cells in parallel, one per zone. Soft voting. |
| `BMCNetwork` | Arbitrary depth. Layer 2+ acts as a prediction head. |
| `BMCSkipConnection` | Adaptive skip connection. Detects impure cells, routes via geodesic gate to specialist L2. |
| `SequentialRVQ` | Sequential BMC via Residual Vector Quantization. Auto-determines depth. |
| `fit_rvq` | Core RVQ training algorithm. Trains cells on progressively refined residuals. |
| `BMCClassifier` | sklearn-compatible classifier. Auto zones + prediction head. |
| `BMCRegressor` | sklearn-compatible regressor. Mean values at cells + interpolation. |

### Observation Spaces

| Space | Input | Zones |
|---|---|---|
| `TabularObservationSpace` | `(M, F)` flat features | Feature subsets |
| `ImageObservationSpace` | `(M, H, W)` grayscale | Overlapping patch grid |
| `TimeSeriesObservationSpace` | `(M, T)` or `(M, T, F)` | Sliding windows |
| `TextObservationSpace` | `(M, seq_len, embed_dim)` | Contiguous chunks |

### Metrics

`L2Metric`, `CosineMetric`, `FrobeniusMetric`, `SpectralMetric`, `NuclearMetric`

All metrics support CPU and CUDA backends via the `device` parameter.

### Interpolators

| Interpolator | Space | Use case |
|---|---|---|
| `LinearInterpolator` | Arc-length | Fast default for regression |
| `SplineInterpolator` | Arc-length | Smooth C2 for classification |
| `KernelInterpolator` | Arc-length | IDW or RBF |
| `RDDAInterpolator` | Feature-space | Best regression accuracy |

---

## Visualization

BMC includes built-in visualization tools for inspecting model structure, data geometry, and inference behavior. Install with `pip install biomimetic-framework[viz]`.

### Architecture Diagram

Graphviz-rendered architecture showing the composition hierarchy, zone structure, and data flow.

```python
from bmc.viz import diagram
diagram(model, "architecture.svg")
```

<p align="center"><img src="docs/figures/diagram_network.svg" width="700"></p>

### Scatter Plot

UMAP/PCA scatter of training data with Voronoi regions, seed markers, and geodesic arrows overlaid. Works with `BMCCell`, `BMCLayer`, and `BMCNetwork`.

```python
from bmc.viz import scatter
scatter(model, X, y, "scatter.png")
```

<p align="center"><img src="docs/figures/scatter_cell.png" width="550"></p>

### Architecture Composite

Combines architecture diagram with embedded scatter plots per zone — a complete view of how the network decomposes and partitions the input space.

```python
from bmc.viz import architecture
architecture(model, X, y, "composite.png")
```

<p align="center"><img src="docs/figures/architecture_network.png" width="700"></p>

### Inference Trace

Traces a single query through the geodesic across all zones and layers: highlights the active Voronoi cell (yellow), geodesic edge (gold), parametric position (purple dot), and query point (red X).

```python
from bmc.viz import trace
trace(network, X, y, query, "trace.png")
```

<p align="center"><img src="docs/figures/trace_network.png" width="700"></p>

### Parametric Curvature

Geodesic curvature vs arc-length with class-colored gradient, showing how the LUT distribution changes along the manifold path.

```python
from bmc.viz import parametric
parametric(cell, "parametric.png")
```

<p align="center"><img src="docs/figures/parametric_cell.png" width="550"></p>

### Riemannian Manifold

3D surface in joint (D+C) space showing the manifold geometry, mesh, geodesic curve, and seed markers. Uses UMAP projection when D+C > 3.

```python
from bmc.viz import riemannian
riemannian(cell, "manifold.png")
```

<p align="center"><img src="docs/figures/riemannian_cell.png" width="550"></p>

### CLI Summary

Rich-formatted architecture tree with memory footprint, printed to the terminal.

```python
from bmc.viz import summary
summary(model)
```

```
Input: D=30
+-- BMCLayer  (6 BMCCells)
|   +-- Observation Space: Tabular  30 features -> 6 subsets
|   +-- 6 zones x 5D
|   +-- BMCCell  K=64  Metric: L2  Dim: 5
|   +-- ...
|   +-- Layer memory: 19.5 KB
+-- BMCCell  K=64  Metric: L2  Dim in: 24  Dim out: 4
|   +-- Memory: 8.0 KB
+-- Total memory: 27.5 KB
+-- Output: C=4
```

---

## FPGA Deployment

BMC's inference pipeline (distance --> argmin --> LUT --> argmax) maps directly to digital logic. The `export_for_fpga` function generates parameterized Verilog, quantized ROM files, testbench, and Makefile.

```python
from bmc import BMCCell, L2Metric, export_for_fpga

cell = BMCCell(n_clusters=128, metric=L2Metric())
cell.fit(X_train, y_train, n_classes=10)

result = export_for_fpga(cell, "build/", X_test=X_test, y_test=y_test)
# result["quantized_accuracy"] --> 0.97
```

```bash
cd build/
make sim    # simulate with Icarus Verilog
make synth  # gate-level synthesis with Yosys
```

| Dataset | Accuracy | Model Size | Clusters |
|---|---|---|---|
| Digits (8x8, 10 classes) | 97% | 9.5 KB | K=128 |
| Accelerometer (4 states) | 100% | 48 B | K=4 |

See **[FPGA Guide](docs/BMC_FPGA_Guide.md)** for the full hardware deployment workflow.

---

## Benchmark Results

### Classification (sklearn datasets, 70/30 split)

| Dataset | BMC | KNN | Random Forest | SVM |
|---|---|---|---|---|
| Breast Cancer (30D, 2 classes) | 96.5% | 97.1% | 93.6% | 97.7% |
| Digits (64D, 10 classes) | 97.2% | 98.7% | 96.7% | 98.9% |
| ECG5000 (140D, 5 classes) | 95.2% | 94.9% | 95.0% | 95.1% |
| 20 Newsgroups (256D, 4 classes) | 79.6% | 67.4% | 85.3% | 87.5% |

### Regression (BMCRegressor with prediction head)

| Dataset | BMC (MAE%) | KNN | Linear Reg | GBR |
|---|---|---|---|---|
| Linear | 1.4% | 2.4% | 0.8% | 0.8% |
| Sinusoidal | 1.8% | 1.9% | 17.6% | 1.8% |
| Housing-like | 3.4% | 4.8% | 2.3% | 2.3% |

---

## Complexity Analysis

Let **M** = training samples, **D** = feature dimension, **K** = clusters per cell, **C** = classes, **N** = zones, **Q** = query samples, **T** = Lloyd iterations, **B** = `batch_k` (seed-batch size).

### Training

| Step | Time | Space |
|---|---|---|
| K-means++ init | O(K M D) | O(M D + K D) |
| Lloyd's iteration (x T) | O(T K min(M, 10K) D) | O(M D + B M) |
| LUT construction | O(M + K C) | O(K C) |
| TSP geodesic ordering | O(K² D) | O(K²) |
| **Total (single cell)** | **O(T K min(M, 10K) D + K² D)** | **O(K² + M D + B M)** |
| **Total (BMCLayer, N zones)** | **O(N (T K min(M, 10K) D + K² D))** | **O(N (K² + K C) + M D)** |
| **Total (BMCNetwork, L layers)** | **O(L N (T K min(M, 10K) D + K² D))** | **O(L N (K² + K C) + M D)** |

### Inference

| Mode | Time | Space |
|---|---|---|
| Hard lookup (batched, default) | O(ceil(K / B) Q D) | O(B Q + Q C) |
| Hard lookup (B = K, full pairwise) | O(Q K D) | O(Q K) |
| Hard lookup (B = 1, streaming) | O(Q K D) | O(Q) |
| **BMCLayer (N zones)** | **O(N Q K D)** | **O(Q N C + B Q)** |
| **BMCNetwork (L layers)** | **O(L N Q K D')** | **O(L N Q C)** |

D' = N C for layers 2+ (flattened vote matrix dimension).

### Key Scaling Properties

- **Sub-linear in M**: mini-batch Lloyd's caps per-iteration cost at O(10K) samples regardless of dataset size.
- **Space bottleneck**: K² (TSP distance matrix). At K = 4096, this is 128 MB per cell.
- **Depth-invariant memory**: no backpropagation, no activation storage. Training memory does not grow with network depth.
- **Embarrassingly parallel**: N zones are independent during both training and inference.

### Empirical Scaling

<p align="center">
<img src="docs/figures/complexity_cell_fit_vs_M.png" width="380">
<img src="docs/figures/complexity_tsp_vs_K.png" width="380">
</p>
<p align="center">
<img src="docs/figures/complexity_inference_vs_Q.png" width="380">
<img src="docs/figures/complexity_train_time_vs_M.png" width="380">
</p>

### BMC vs Traditional Neural Networks

Let **W** denote capacity per layer (W = N K for BMC, W = hidden width for NN).

| | BMC | Neural Network (SGD) |
|---|---|---|
| **Training time** | O(L W min(M, 10K) D T) | O(E M L W²) |
| **Training space** | O(L K² N + M D) | O(L W² + B L W) |
| **Inference time** | O(L W Q D) | O(Q L W²) |
| **Inference space** | O(L W D) model + O(Q) working | O(L W²) model + O(Q W) working |
| **Gradient storage** | 0 | O(L W²) |
| **Activation cache** | 0 | O(B L W) |

The per-layer cost comparison reduces to **W D vs W²**:

- **BMC wins when D < W** — common in tabular data and deeper layers where D' = N C.
- **Tied when D = W** — both do O(W²) work per layer per sample.
- **NN wins at large W** — BLAS-optimized W² matmul has smaller constants than BMC's expand trick.

Empirically validated (sklearn `MLPClassifier`, matched W = 128, single layer):

| M | BMC / NN ratio |
|---|---|
| 8,000 | 6.5x slower |
| 16,000 | 4.8x slower |
| 32,000 | 3.0x slower |
| 64,000 | 2.2x slower |

The gap narrows with M because mini-batch Lloyd's caps BMC's per-iteration cost while NN scales linearly. BMC's structural advantages (no backprop, depth-invariant memory, FPGA-exportable LUT inference) apply regardless of scale.

---

## Documentation

- **[API Reference](docs/BMC_API_Reference.md)** — full parameter and method documentation
- **[FPGA Guide](docs/BMC_FPGA_Guide.md)** — hardware deployment, Verilog architecture, simulation
- **[Conceptual Guide](https://SariItani.github.io/bmc)** — theory, architecture, design rationale

## Notebooks

| Notebook | Observation Space | Dataset |
|---|---|---|
| [01 Tabular](notebooks/01_Tabular_BreastCancer.ipynb) | `TabularObservationSpace` | Breast Cancer (569x30) |
| [02 Image](notebooks/02_Image_Digits.ipynb) | `ImageObservationSpace` | Digits (1797x8x8) |
| [03 Time Series](notebooks/03_TimeSeries_ECG.ipynb) | `TimeSeriesObservationSpace` | ECG5000 (5000x140) |
| [04 Text](notebooks/04_Text_Newsgroups.ipynb) | `TextObservationSpace` | 20 Newsgroups (3729 docs) |
| [MNIST Demo](notebooks/BMC_MNIST_Demo.ipynb) | `ImageObservationSpace` | MNIST (60K/10K, 28x28) |

## Requirements

- Python >= 3.9
- NumPy >= 1.24
- SciPy >= 1.10

Optional: Pillow, PyTorch, OpenCV (image), Rich, Graphviz (viz)

## License

MIT
