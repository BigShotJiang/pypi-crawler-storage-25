# tests/test_stress_layer.py
"""
Stress tests for BMCLayer thread-based parallel fitting.

Validates that the ThreadPoolExecutor-based zone fitting:
1. Produces correct results (accuracy, LUT invariants)
2. Matches sequential accuracy (no thread-safety issues)
3. Stays within bounded memory regardless of M and K
"""

import os
import numpy as np
import pytest
from bmc.composition.layer import BMCLayer
from bmc.observation.tabular import TabularObservationSpace
from bmc.metrics.l2 import L2Metric


# ── helpers ──────────────────────────────────────────────────────────────────

def _make_data(M, D, C, separation=5.0, seed=42):
    rng = np.random.default_rng(seed)
    per_class = M // C
    Xs, ys = [], []
    for c in range(C):
        center = np.zeros(D, dtype=np.float32)
        center[c % D] = c * separation
        Xs.append(rng.normal(0, 0.5, (per_class, D)).astype(np.float32) + center)
        ys.extend([c] * per_class)
    return np.vstack(Xs), np.array(ys, dtype=np.int32)


# ── correctness: threaded parallel vs forced sequential ──────────────────────

class TestThreadSafety:
    """Threaded parallel must match sequential accuracy."""

    def test_parity_on_medium_data(self):
        """Force sequential and compare with default threaded path."""
        M, D, C, K = 5_000, 25, 10, 64
        N_zones = 25
        X, y = _make_data(M, D, C)
        obs = TabularObservationSpace(n_features=D, n_zones=N_zones)

        # Threaded parallel path (default)
        layer_par = BMCLayer(obs, n_clusters=K, metric=L2Metric(),
                             rng=np.random.default_rng(42))
        layer_par.fit(X, y, n_classes=C)
        preds_par = layer_par.predict(X)
        acc_par = np.mean(preds_par == y)

        # Sequential path (force n_workers=1)
        orig_cpu = os.cpu_count
        os.cpu_count = lambda: 1
        layer_seq = BMCLayer(obs, n_clusters=K, metric=L2Metric(),
                             rng=np.random.default_rng(42))
        layer_seq.fit(X, y, n_classes=C)
        os.cpu_count = orig_cpu
        preds_seq = layer_seq.predict(X)
        acc_seq = np.mean(preds_seq == y)

        assert acc_par >= 0.90, f"Parallel accuracy too low: {acc_par:.3f}"
        assert acc_seq >= 0.90, f"Sequential accuracy too low: {acc_seq:.3f}"
        assert abs(acc_par - acc_seq) < 0.05

    def test_lut_invariants_threaded(self):
        """LUT invariants must hold after threaded fitting."""
        M, D, C, K = 10_000, 25, 10, 128
        X, y = _make_data(M, D, C)
        obs = TabularObservationSpace(n_features=D, n_zones=25)

        layer = BMCLayer(obs, n_clusters=K, metric=L2Metric(),
                         rng=np.random.default_rng(42))
        layer.fit(X, y, n_classes=C)

        for z, cell in enumerate(layer.layers_):
            assert np.allclose(cell.lut_.sum(axis=1), 1.0, atol=1e-10), \
                f"Zone {z}: LUT rows don't sum to 1"
            assert np.all(cell.lut_ >= 0), f"Zone {z}: negative LUT values"
            assert sorted(cell.tsp_path_.tolist()) == list(range(K)), \
                f"Zone {z}: invalid TSP path"

    def test_deterministic_across_runs(self):
        """Same seed must give same predictions across two runs."""
        M, D, C, K = 3_000, 25, 10, 32
        X, y = _make_data(M, D, C)
        obs = TabularObservationSpace(n_features=D, n_zones=25)

        layer1 = BMCLayer(obs, n_clusters=K, rng=np.random.default_rng(42))
        layer1.fit(X, y, n_classes=C)
        preds1 = layer1.predict(X)

        layer2 = BMCLayer(obs, n_clusters=K, rng=np.random.default_rng(42))
        layer2.fit(X, y, n_classes=C)
        preds2 = layer2.predict(X)

        assert np.array_equal(preds1, preds2), "Non-deterministic results"

    def test_62_classes_lut_shape(self):
        """62 classes (EMNIST-scale) produces correct LUT dimensions."""
        M, D, C, K = 6_200, 25, 62, 64
        X, y = _make_data(M, D, C, separation=8.0)
        obs = TabularObservationSpace(n_features=D, n_zones=5)

        layer = BMCLayer(obs, n_clusters=K, metric=L2Metric(),
                         rng=np.random.default_rng(42))
        layer.fit(X, y, n_classes=C)

        for cell in layer.layers_:
            assert cell.lut_.shape == (K, C)
            assert np.allclose(cell.lut_.sum(axis=1), 1.0, atol=1e-10)


# ── memory: peak allocation must stay bounded ────────────────────────────────

class TestMemoryBounded:
    """Verify that peak memory stays bounded for large inputs."""

    def test_assign_clusters_memory_bounded(self):
        """
        assign_clusters with batch_k=1 on 100K samples × K=256 must
        use O(M) memory, not O(M×K). This verifies the streaming
        fallback path still works when explicitly requested.
        """
        import tracemalloc
        M, D, K = 100_000, 25, 256

        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (M, D)).astype(np.float32)
        seeds = rng.normal(0, 1, (K, D)).astype(np.float32)
        metric = L2Metric()

        tracemalloc.start()
        from bmc.core.seeding import assign_clusters
        _ = assign_clusters(data, seeds, metric, batch_k=1)
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        peak_mb = peak / 1e6
        budget_mb = 200
        assert peak_mb < budget_mb, \
            f"Peak memory {peak_mb:.0f} MB exceeds {budget_mb} MB budget"

    def test_kmeanspp_memory_bounded(self):
        """
        Full kmeanspp_init (init + Lloyd's) on 50K samples must stay
        under a reasonable memory budget.
        """
        import tracemalloc
        from bmc.core.seeding import kmeanspp_init
        M, D, K = 50_000, 25, 128

        rng = np.random.default_rng(42)
        data = rng.normal(0, 1, (M, D)).astype(np.float32)
        metric = L2Metric()

        tracemalloc.start()
        _ = kmeanspp_init(data, k=K, rng=np.random.default_rng(42),
                          metric=metric, max_iter=5)
        _, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        peak_mb = peak / 1e6
        budget_mb = 300
        assert peak_mb < budget_mb, \
            f"Peak memory {peak_mb:.0f} MB exceeds {budget_mb} MB budget"
