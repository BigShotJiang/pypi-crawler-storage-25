# tests/test_real_world.py
"""
Real-world dataset and realistic data pattern tests.

Part 1: Sklearn benchmark datasets (Iris, Wine, Digits, Breast Cancer)
    - Skip gracefully if sklearn is not installed
    - Tests that BMC achieves competitive accuracy on standard benchmarks
    - Tests that the toolkit handles real data properties: mixed scales,
      correlated features, non-Gaussian distributions

Part 2: Synthetic-but-realistic data patterns
    - Overlapping clusters
    - Outliers
    - Noisy/irrelevant features
    - Non-Gaussian distributions (uniform, multimodal)
    - Mixed feature scales
    - Very sparse data
    - Regressor on realistic continuous targets
"""

import numpy as np
import pytest
from bmc.core.cell import BMCCell
from bmc.composition.layer import BMCLayer
from bmc.composition.sequential import BMCNetwork
from bmc.observation.tabular import TabularObservationSpace
from bmc.model.classifier import BMCClassifier
from bmc.model.regressor import BMCRegressor
from bmc.composition.skip import BMCSkipConnection
from bmc.composition.rvq import SequentialRVQ
from bmc.metrics.l2 import L2Metric
from bmc.metrics.cosine import CosineMetric

sklearn = pytest.importorskip("sklearn", reason="sklearn required for real-world dataset tests")


# ══════════════════════════════════════════════════════════════════════════════
# Part 1: Sklearn benchmark datasets
# ══════════════════════════════════════════════════════════════════════════════

from sklearn.datasets import load_iris, load_wine, load_digits, load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# ── Iris (150 samples, 4 features, 3 classes) ───────────────────────────────

class TestIris:
    @pytest.fixture(autouse=True)
    def setup(self):
        data = load_iris()
        X, y = data.data.astype(np.float32), data.target.astype(np.int32)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y,
        )

    def test_cell_accuracy(self):
        cell = BMCCell(n_clusters=16)
        cell.fit(self.X_train, self.y_train, n_classes=3)
        preds = cell.predict(self.X_test)
        acc = np.mean(preds == self.y_test)
        assert acc >= 0.80, f"Iris accuracy={acc:.3f}"

    def test_classifier_accuracy(self):
        clf = BMCClassifier(n_clusters=16)
        clf.fit(self.X_train, self.y_train)
        preds = clf.predict(self.X_test)
        acc = np.mean(preds == self.y_test)
        assert acc >= 0.80, f"Iris classifier accuracy={acc:.3f}"

    def test_proba_valid(self):
        clf = BMCClassifier(n_clusters=16)
        clf.fit(self.X_train, self.y_train)
        proba = clf.predict_proba(self.X_test)
        assert proba.shape == (len(self.X_test), 3)
        assert np.allclose(proba.sum(axis=1), 1.0, atol=1e-5)
        assert np.all(proba >= 0)

    def test_skip_connection_train_accuracy(self):
        cell = BMCCell(n_clusters=16)
        skip = BMCSkipConnection(cell, n_clusters_l2=16)
        skip.fit(self.X_train, self.y_train, n_classes=3)
        acc_l1 = np.mean(skip.predict_l1(self.X_train) == self.y_train)
        acc_skip = np.mean(skip.predict(self.X_train) == self.y_train)
        assert acc_skip >= acc_l1, f"Iris skip train: {acc_skip:.3f} < {acc_l1:.3f}"

    def test_rvq_train_accuracy(self):
        model = SequentialRVQ(max_layers=16, k_per_layer=2)
        model.fit(self.X_train, self.y_train, n_classes=3)
        acc_train = np.mean(model.predict(self.X_train) == self.y_train)
        acc_test = np.mean(model.predict(self.X_test) == self.y_test)
        assert acc_train >= 0.80, f"Iris RVQ train: {acc_train:.3f}"
        assert acc_test >= 0.70, f"Iris RVQ test: {acc_test:.3f}"


# ── Wine (178 samples, 13 features, 3 classes) ──────────────────────────────

class TestWine:
    @pytest.fixture(autouse=True)
    def setup(self):
        data = load_wine()
        X, y = data.data.astype(np.float32), data.target.astype(np.int32)
        # Wine has mixed scales — test both raw and scaled
        self.X_train_raw, self.X_test_raw, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y,
        )
        scaler = StandardScaler()
        self.X_train = scaler.fit_transform(self.X_train_raw).astype(np.float32)
        self.X_test = scaler.transform(self.X_test_raw).astype(np.float32)

    def test_accuracy_scaled(self):
        clf = BMCClassifier(n_clusters=16)
        clf.fit(self.X_train, self.y_train)
        acc = np.mean(clf.predict(self.X_test) == self.y_test)
        assert acc >= 0.75, f"Wine scaled accuracy={acc:.3f}"

    def test_accuracy_raw(self):
        """Raw (unscaled) data — mixed feature scales are realistic."""
        clf = BMCClassifier(n_clusters=16)
        clf.fit(self.X_train_raw, self.y_train)
        acc = np.mean(clf.predict(self.X_test_raw) == self.y_test)
        # Lower bar for unscaled — some features dominate
        assert acc >= 0.55, f"Wine raw accuracy={acc:.3f}"

    def test_network_accuracy(self):
        obs = TabularObservationSpace(n_features=13, n_zones=4)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=16),
            BMCCell(n_clusters=8),
        ])
        net.fit(self.X_train, self.y_train, n_classes=3)
        acc = np.mean(net.predict(self.X_test) == self.y_test)
        assert acc >= 0.65, f"Wine network accuracy={acc:.3f}"

    def test_skip_connection_train_accuracy(self):
        cell = BMCCell(n_clusters=16)
        skip = BMCSkipConnection(cell, n_clusters_l2=16)
        skip.fit(self.X_train, self.y_train, n_classes=3)
        acc_l1 = np.mean(skip.predict_l1(self.X_train) == self.y_train)
        acc_skip = np.mean(skip.predict(self.X_train) == self.y_train)
        assert acc_skip >= acc_l1, f"Wine skip train: {acc_skip:.3f} < {acc_l1:.3f}"

    def test_rvq_train_accuracy(self):
        model = SequentialRVQ(max_layers=16, k_per_layer=4)
        model.fit(self.X_train, self.y_train, n_classes=3)
        acc_train = np.mean(model.predict(self.X_train) == self.y_train)
        acc_test = np.mean(model.predict(self.X_test) == self.y_test)
        assert acc_train >= 0.75, f"Wine RVQ train: {acc_train:.3f}"
        assert acc_test >= 0.65, f"Wine RVQ test: {acc_test:.3f}"


# ── Digits (1797 samples, 64 features, 10 classes) ──────────────────────────

class TestDigits:
    @pytest.fixture(autouse=True)
    def setup(self):
        data = load_digits()
        X, y = data.data.astype(np.float32), data.target.astype(np.int32)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y,
        )

    def test_cell_accuracy(self):
        cell = BMCCell(n_clusters=128)
        cell.fit(self.X_train, self.y_train, n_classes=10)
        acc = np.mean(cell.predict(self.X_test) == self.y_test)
        assert acc >= 0.70, f"Digits cell accuracy={acc:.3f}"

    def test_layer_accuracy(self):
        obs = TabularObservationSpace(n_features=64, n_zones=8)
        layer = BMCLayer(obs, n_clusters=64)
        layer.fit(self.X_train, self.y_train, n_classes=10)
        acc = np.mean(layer.predict(self.X_test) == self.y_test)
        assert acc >= 0.70, f"Digits layer accuracy={acc:.3f}"

    def test_network_accuracy(self):
        obs = TabularObservationSpace(n_features=64, n_zones=8)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=64),
            BMCCell(n_clusters=32),
        ])
        net.fit(self.X_train, self.y_train, n_classes=10)
        acc = np.mean(net.predict(self.X_test) == self.y_test)
        assert acc >= 0.65, f"Digits network accuracy={acc:.3f}"

    def test_all_10_classes_predicted(self):
        """On digits, all 10 classes should appear in predictions."""
        cell = BMCCell(n_clusters=128)
        cell.fit(self.X_train, self.y_train, n_classes=10)
        preds = cell.predict(self.X_test)
        unique_preds = set(preds.tolist())
        assert len(unique_preds) >= 8, f"only predicted {len(unique_preds)} classes"

    def test_skip_connection_train_accuracy(self):
        cell = BMCCell(n_clusters=128)
        skip = BMCSkipConnection(cell, n_clusters_l2=128)
        skip.fit(self.X_train, self.y_train, n_classes=10)
        acc_l1 = np.mean(skip.predict_l1(self.X_train) == self.y_train)
        acc_skip = np.mean(skip.predict(self.X_train) == self.y_train)
        assert acc_skip >= acc_l1, f"Digits skip train: {acc_skip:.3f} < {acc_l1:.3f}"

    def test_rvq_train_accuracy(self):
        model = SequentialRVQ(max_layers=16, k_per_layer=4, n_clusters_head=128)
        model.fit(self.X_train, self.y_train, n_classes=10)
        acc_train = np.mean(model.predict(self.X_train) == self.y_train)
        acc_test = np.mean(model.predict(self.X_test) == self.y_test)
        assert acc_train >= 0.70, f"Digits RVQ train: {acc_train:.3f}"
        assert acc_test >= 0.60, f"Digits RVQ test: {acc_test:.3f}"


# ── Breast Cancer (569 samples, 30 features, 2 classes) ─────────────────────

class TestBreastCancer:
    @pytest.fixture(autouse=True)
    def setup(self):
        data = load_breast_cancer()
        X, y = data.data.astype(np.float32), data.target.astype(np.int32)
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X).astype(np.float32)
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            X_scaled, y, test_size=0.3, random_state=42, stratify=y,
        )

    def test_accuracy(self):
        clf = BMCClassifier(n_clusters=32)
        clf.fit(self.X_train, self.y_train)
        acc = np.mean(clf.predict(self.X_test) == self.y_test)
        assert acc >= 0.85, f"Breast cancer accuracy={acc:.3f}"

    def test_cosine_metric(self):
        """Cosine metric on normalized medical data."""
        cell = BMCCell(n_clusters=32, metric=CosineMetric())
        cell.fit(self.X_train, self.y_train, n_classes=2)
        acc = np.mean(cell.predict(self.X_test) == self.y_test)
        assert acc >= 0.75, f"Breast cancer cosine accuracy={acc:.3f}"

    def test_skip_connection_train_accuracy(self):
        cell = BMCCell(n_clusters=32)
        skip = BMCSkipConnection(cell, n_clusters_l2=32)
        skip.fit(self.X_train, self.y_train, n_classes=2)
        acc_l1 = np.mean(skip.predict_l1(self.X_train) == self.y_train)
        acc_skip = np.mean(skip.predict(self.X_train) == self.y_train)
        assert acc_skip >= acc_l1, f"Breast Cancer skip train: {acc_skip:.3f} < {acc_l1:.3f}"

    def test_rvq_train_accuracy(self):
        model = SequentialRVQ(max_layers=16, k_per_layer=2)
        model.fit(self.X_train, self.y_train, n_classes=2)
        acc_train = np.mean(model.predict(self.X_train) == self.y_train)
        acc_test = np.mean(model.predict(self.X_test) == self.y_test)
        assert acc_train >= 0.85, f"Breast Cancer RVQ train: {acc_train:.3f}"
        assert acc_test >= 0.80, f"Breast Cancer RVQ test: {acc_test:.3f}"


# ══════════════════════════════════════════════════════════════════════════════
# Part 2: Realistic data patterns
# ══════════════════════════════════════════════════════════════════════════════


class TestOverlappingClusters:
    """Classes with significant overlap — no model gets 100%."""

    def test_overlapping_binary(self):
        rng = np.random.default_rng(42)
        X0 = rng.normal(0, 1, (200, 10)).astype(np.float32)
        X1 = rng.normal(1, 1, (200, 10)).astype(np.float32)  # only 1 std apart
        X = np.vstack([X0, X1])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=32)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        # should beat chance (50%) but not by too much
        assert 0.55 <= acc <= 0.95, f"overlapping acc={acc:.3f}"

    def test_overlapping_multiclass(self):
        rng = np.random.default_rng(42)
        Xs, ys = [], []
        for c in range(5):
            Xs.append(rng.normal(c * 0.8, 1, (100, 8)).astype(np.float32))
            ys.extend([c] * 100)
        X = np.vstack(Xs)
        y = np.array(ys, dtype=np.int32)
        cell = BMCCell(n_clusters=64)
        cell.fit(X, y, n_classes=5)
        acc = np.mean(cell.predict(X) == y)
        assert acc >= 0.25, f"overlapping multiclass acc={acc:.3f}"

    def test_skip_on_overlapping_binary(self):
        rng = np.random.default_rng(42)
        X0 = rng.normal(0, 1, (200, 10)).astype(np.float32)
        X1 = rng.normal(1, 1, (200, 10)).astype(np.float32)
        X = np.vstack([X0, X1])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=32)
        skip = BMCSkipConnection(cell, n_clusters_l2=32)
        skip.fit(X, y)
        acc_l1 = np.mean(skip.predict_l1(X) == y)
        acc_skip = np.mean(skip.predict(X) == y)
        assert acc_skip >= acc_l1, f"overlapping skip: {acc_skip:.3f} < {acc_l1:.3f}"


class TestOutliers:
    """Data with outlier contamination."""

    def test_outliers_dont_crash(self):
        rng = np.random.default_rng(42)
        X = rng.normal(0, 1, (200, 10)).astype(np.float32)
        X[:100] += 5
        y = np.array([0] * 100 + [1] * 100, dtype=np.int32)
        # inject outliers: 5% of samples at extreme positions
        n_outliers = 10
        X[:n_outliers] = rng.normal(100, 10, (n_outliers, 10)).astype(np.float32)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        preds = cell.predict(X)
        assert preds.shape == (200,)
        # should still work on clean portion
        clean_acc = np.mean(preds[n_outliers:100] == y[n_outliers:100])
        assert clean_acc >= 0.70

    def test_extreme_outlier_in_test(self):
        rng = np.random.default_rng(42)
        X_train = rng.normal(0, 1, (200, 5)).astype(np.float32)
        X_train[:100] += 5
        y_train = np.array([0] * 100 + [1] * 100, dtype=np.int32)
        cell = BMCCell(n_clusters=16)
        cell.fit(X_train, y_train, n_classes=2)
        # test with extreme outlier
        X_test = np.array([[1e6, 1e6, 1e6, 1e6, 1e6]], dtype=np.float32)
        preds = cell.predict(X_test)
        assert preds.shape == (1,)
        assert preds[0] in [0, 1]


class TestNoisyFeatures:
    """Data where most features are irrelevant noise."""

    def test_signal_in_noise(self):
        rng = np.random.default_rng(42)
        M = 400
        # 2 signal features, 48 noise features
        signal = np.zeros((M, 2), dtype=np.float32)
        signal[:200, :] = rng.normal(0, 0.5, (200, 2)).astype(np.float32)
        signal[200:, :] = rng.normal(5, 0.5, (200, 2)).astype(np.float32)
        noise = rng.normal(0, 1, (M, 48)).astype(np.float32)
        X = np.hstack([signal, noise])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)

        cell = BMCCell(n_clusters=32)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        # should still beat chance despite noisy features
        assert acc >= 0.60, f"signal-in-noise acc={acc:.3f}"


class TestNonGaussian:
    """Non-Gaussian distributions."""

    def test_uniform_clusters(self):
        rng = np.random.default_rng(42)
        X0 = rng.uniform(0, 1, (200, 10)).astype(np.float32)
        X1 = rng.uniform(3, 4, (200, 10)).astype(np.float32)
        X = np.vstack([X0, X1])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        assert acc >= 0.95, f"uniform acc={acc:.3f}"

    def test_multimodal_per_class(self):
        """Each class is a mixture of 2 Gaussians — non-convex clusters."""
        rng = np.random.default_rng(42)
        # class 0: two clusters at (0,0) and (10,10)
        c0a = rng.normal([0, 0], 0.5, (100, 2)).astype(np.float32)
        c0b = rng.normal([10, 10], 0.5, (100, 2)).astype(np.float32)
        # class 1: two clusters at (0,10) and (10,0)
        c1a = rng.normal([0, 10], 0.5, (100, 2)).astype(np.float32)
        c1b = rng.normal([10, 0], 0.5, (100, 2)).astype(np.float32)
        X = np.vstack([c0a, c0b, c1a, c1b])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=32)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        # non-convex clusters — BMC with enough K should handle it
        assert acc >= 0.85, f"multimodal acc={acc:.3f}"

    def test_skip_on_multimodal(self):
        rng = np.random.default_rng(42)
        c0a = rng.normal([0, 0], 0.5, (100, 2)).astype(np.float32)
        c0b = rng.normal([10, 10], 0.5, (100, 2)).astype(np.float32)
        c1a = rng.normal([0, 10], 0.5, (100, 2)).astype(np.float32)
        c1b = rng.normal([10, 0], 0.5, (100, 2)).astype(np.float32)
        X = np.vstack([c0a, c0b, c1a, c1b])
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=16)
        skip = BMCSkipConnection(cell, n_clusters_l2=16)
        skip.fit(X, y)
        acc_l1 = np.mean(skip.predict_l1(X) == y)
        acc_skip = np.mean(skip.predict(X) == y)
        assert acc_skip >= acc_l1, f"multimodal skip: {acc_skip:.3f} < {acc_l1:.3f}"


class TestMixedScales:
    """Features with very different scales."""

    def test_mixed_scale_features(self):
        rng = np.random.default_rng(42)
        M = 300
        # feature 0: range [0, 1], feature 1: range [0, 1000], feature 2: range [0, 0.001]
        f0 = rng.uniform(0, 1, (M, 1)).astype(np.float32)
        f1 = rng.uniform(0, 1000, (M, 1)).astype(np.float32)
        f2 = rng.uniform(0, 0.001, (M, 1)).astype(np.float32)
        X = np.hstack([f0, f1, f2])
        # label based on feature 1 (the dominant scale)
        y = (f1[:, 0] > 500).astype(np.int32)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        # L2 will be dominated by f1 which is the signal — should work
        assert acc >= 0.85, f"mixed scale acc={acc:.3f}"


class TestSparseData:
    """Data where most values are zero (sparse-like)."""

    def test_sparse_binary_features(self):
        rng = np.random.default_rng(42)
        M, D = 400, 50
        X = np.zeros((M, D), dtype=np.float32)
        # class 0: random 5 features active per sample
        for i in range(200):
            active = rng.choice(D // 2, 5, replace=False)
            X[i, active] = rng.uniform(0.5, 1.0, 5).astype(np.float32)
        # class 1: random 5 features active in second half of features
        for i in range(200, 400):
            active = rng.choice(range(D // 2, D), 5, replace=False)
            X[i, active] = rng.uniform(0.5, 1.0, 5).astype(np.float32)
        y = np.array([0] * 200 + [1] * 200, dtype=np.int32)
        cell = BMCCell(n_clusters=32)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        assert acc >= 0.70, f"sparse acc={acc:.3f}"


class TestRegressorRealWorld:
    """Regressor on realistic continuous targets."""

    def test_boston_like_regression(self):
        """Synthetic housing-price-like data with mixed features."""
        rng = np.random.default_rng(42)
        M = 500
        rooms = rng.uniform(2, 10, M).astype(np.float32)
        distance = rng.uniform(1, 50, M).astype(np.float32)
        age = rng.uniform(0, 100, M).astype(np.float32)
        noise_features = rng.normal(0, 1, (M, 5)).astype(np.float32)
        X = np.column_stack([rooms, distance, age, noise_features])
        # price depends mainly on rooms and distance
        y = (rooms * 30 - distance * 2 + rng.normal(0, 10, M)).astype(np.float64)

        X_train, X_test = X[:400], X[400:]
        y_train, y_test = y[:400], y[400:]

        reg = BMCRegressor(n_clusters=32)
        reg.fit(X_train, y_train)
        preds = reg.predict(X_test)
        mae = np.mean(np.abs(preds - y_test))
        target_range = y_test.max() - y_test.min()
        assert mae < 0.35 * target_range, f"MAE={mae:.2f}, range={target_range:.2f}"

    def test_sinusoidal_regression(self):
        """Non-linear target: y = sin(x) — tests geodesic interpolation."""
        rng = np.random.default_rng(42)
        X = rng.uniform(0, 2 * np.pi, (500, 1)).astype(np.float32)
        y = np.sin(X[:, 0]).astype(np.float64) + rng.normal(0, 0.05, 500)

        reg = BMCRegressor(n_clusters=32)
        reg.fit(X, y)
        preds = reg.predict(X)
        mae = np.mean(np.abs(preds - y))
        assert mae < 0.3, f"sin regression MAE={mae:.3f}"

    def test_rvq_regression_sin(self):
        """RVQ on sinusoidal regression."""
        rng = np.random.default_rng(42)
        X = rng.uniform(0, 2 * np.pi, (500, 1)).astype(np.float32)
        y = np.sin(X[:, 0]).astype(np.float64) + rng.normal(0, 0.05, 500)
        model = SequentialRVQ(max_layers=16, k_per_layer=4)
        model.fit_regression(X, y)
        preds = model.predict_regression(X)
        mae = np.mean(np.abs(preds - y))
        assert mae < 0.3, f"RVQ sin regression MAE={mae:.3f}"

    def test_rvq_regression_housing(self):
        """RVQ on housing-like regression."""
        rng = np.random.default_rng(42)
        M = 500
        rooms = rng.uniform(2, 10, M).astype(np.float32)
        distance = rng.uniform(1, 50, M).astype(np.float32)
        age = rng.uniform(0, 100, M).astype(np.float32)
        noise_features = rng.normal(0, 1, (M, 5)).astype(np.float32)
        X = np.column_stack([rooms, distance, age, noise_features])
        y = (rooms * 30 - distance * 2 + rng.normal(0, 10, M)).astype(np.float64)
        X_train, X_test = X[:400], X[400:]
        y_train, y_test = y[:400], y[400:]
        model = SequentialRVQ(max_layers=16, k_per_layer=4)
        model.fit_regression(X_train, y_train)
        preds = model.predict_regression(X_test)
        mae = np.mean(np.abs(preds - y_test))
        target_range = y_test.max() - y_test.min()
        assert mae < 0.4 * target_range, f"RVQ housing MAE={mae:.2f}, range={target_range:.2f}"


class TestCorrelatedFeatures:
    """Features that are highly correlated with each other."""

    def test_correlated_features(self):
        rng = np.random.default_rng(42)
        M = 300
        base = rng.normal(0, 1, (M, 3)).astype(np.float32)
        # create 7 more features that are noisy copies of the first 3
        copies = np.hstack([
            base + rng.normal(0, 0.1, (M, 3)).astype(np.float32),
            base[:, :1] + rng.normal(0, 0.1, (M, 1)).astype(np.float32),
        ])
        X = np.hstack([base, copies])  # 7 features total
        # label based on first feature
        y = (base[:, 0] > 0).astype(np.int32)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        acc = np.mean(cell.predict(X) == y)
        assert acc >= 0.80, f"correlated features acc={acc:.3f}"
