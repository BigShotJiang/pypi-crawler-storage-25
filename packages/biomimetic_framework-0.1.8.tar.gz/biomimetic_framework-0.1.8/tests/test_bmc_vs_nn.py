# tests/test_bmc_vs_nn.py
"""
Empirical complexity comparison: BMC vs traditional neural network.

Trains both a BMCCell and an sklearn MLPClassifier on identical synthetic
data at varying sizes, measuring wall-clock time and peak memory.
Fits power-law exponents and compares scaling behaviour.

Run:
    pytest tests/test_bmc_vs_nn.py -v -s

With plots:
    BMC_PLOTS=1 pytest tests/test_bmc_vs_nn.py -v -s
"""

import time
import tracemalloc
import os
import numpy as np
import pytest

from sklearn.neural_network import MLPClassifier

from bmc.core.cell import BMCCell
from bmc.core.inference import lookup_single_zone
from bmc.core.seeding import assign_clusters
from bmc.metrics.l2 import L2Metric


# ── helpers ──────────────────────────────────────────────────────────────────

PLOT_DIR = "tests/complexity_plots"


@pytest.fixture(scope="session")
def save_plots():
    return os.environ.get("BMC_PLOTS", "0") == "1"


def _fit_power_law(sizes, measurements):
    log_n = np.log(np.array(sizes, dtype=np.float64))
    log_t = np.log(np.array(measurements, dtype=np.float64))
    valid = np.isfinite(log_t) & np.isfinite(log_n)
    log_n, log_t = log_n[valid], log_t[valid]
    if len(log_n) < 2:
        return float("nan")
    b, _ = np.polyfit(log_n, log_t, 1)
    return b


def _make_data(M, D, C=4, seed=42):
    rng = np.random.default_rng(seed)
    centers = rng.standard_normal((C, D)).astype(np.float32) * 5
    per_class = M // C
    vecs, labels = [], []
    for c in range(C):
        vecs.append(centers[c] + rng.standard_normal((per_class, D)).astype(np.float32) * 0.3)
        labels.extend([c] * per_class)
    return np.vstack(vecs), np.array(labels, dtype=np.int32)


def _save_comparison_plot(sizes, bmc_vals, nn_vals, title, xlabel, ylabel,
                          bmc_exp, nn_exp, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    os.makedirs(os.path.dirname(path), exist_ok=True)
    sizes = np.array(sizes, dtype=float)

    fig, ax = plt.subplots(figsize=(8, 5))

    # BMC
    ax.loglog(sizes, bmc_vals, "o-", color="tab:blue", label=f"BMC  O(n^{bmc_exp:.2f})", markersize=6)
    # NN
    ax.loglog(sizes, nn_vals, "s-", color="tab:orange", label=f"NN   O(n^{nn_exp:.2f})", markersize=6)

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    ax.grid(True, which="both", ls=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


def _print(msg):
    print(f"  [bmc-vs-nn] {msg}", flush=True)


# ── matched parameters ──────────────────────────────────────────────────────
# BMC capacity W = K (clusters in a single cell, no zones)
# NN capacity  W = hidden layer width
# We match K = W so both have comparable capacity.
# We match T (Lloyd max_iter) = E (MLP max_iter) for iteration count.
# Single layer for both (1 hidden layer MLP vs 1 BMCCell).


class TestTrainingTime:
    """Compare training time scaling."""

    def test_training_time_vs_M(self, save_plots):
        """Training time vs number of samples, matched capacity W=128."""
        W, D, C = 128, 30, 4
        T = 10  # iterations for both
        sizes = [500, 1000, 2000, 4000, 8000]

        bmc_times, nn_times = [], []

        for M in sizes:
            X, y = _make_data(M, D, C)

            # ── BMC ──
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            t0 = time.perf_counter()
            cell.fit(X, y, n_classes=C)
            bmc_times.append(time.perf_counter() - t0)

            # ── NN ──
            mlp = MLPClassifier(
                hidden_layer_sizes=(W,),
                max_iter=T,
                random_state=42,
                solver="adam",
                batch_size=min(200, M),
            )
            t0 = time.perf_counter()
            mlp.fit(X, y)
            nn_times.append(time.perf_counter() - t0)

            _print(f"M={M:,}  BMC={bmc_times[-1]:.3f}s  NN={nn_times[-1]:.3f}s  "
                   f"ratio={bmc_times[-1]/nn_times[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_times)
        nn_exp = _fit_power_law(sizes, nn_times)
        _print(f"Exponents — BMC: O(M^{bmc_exp:.2f})  NN: O(M^{nn_exp:.2f})")

        if save_plots:
            _save_comparison_plot(
                sizes, bmc_times, nn_times,
                f"Training time vs M (W={W}, D={D}, T/E={T})",
                "M (samples)", "time (s)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_train_time_M.png")

    def test_training_time_vs_W(self, save_plots):
        """Training time vs capacity W, matched M=2000."""
        M, D, C = 2000, 30, 4
        T = 10
        sizes = [32, 64, 128, 256]

        bmc_times, nn_times = [], []
        X, y = _make_data(M, D, C)

        for W in sizes:
            # ── BMC ──
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            t0 = time.perf_counter()
            cell.fit(X, y, n_classes=C)
            bmc_times.append(time.perf_counter() - t0)

            # ── NN ──
            mlp = MLPClassifier(
                hidden_layer_sizes=(W,),
                max_iter=T,
                random_state=42,
                solver="adam",
            )
            t0 = time.perf_counter()
            mlp.fit(X, y)
            nn_times.append(time.perf_counter() - t0)

            _print(f"W={W}  BMC={bmc_times[-1]:.3f}s  NN={nn_times[-1]:.3f}s  "
                   f"ratio={bmc_times[-1]/nn_times[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_times)
        nn_exp = _fit_power_law(sizes, nn_times)
        _print(f"Exponents — BMC: O(W^{bmc_exp:.2f})  NN: O(W^{nn_exp:.2f})")
        _print(f"Expected  — BMC: O(W^1) [W·D]   NN: O(W^2) [W²]")

        if save_plots:
            _save_comparison_plot(
                sizes, bmc_times, nn_times,
                f"Training time vs W (M={M}, D={D}, T/E={T})",
                "W (capacity)", "time (s)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_train_time_W.png")

    def test_training_time_vs_D(self, save_plots):
        """Training time vs input dimension D, matched capacity."""
        M, W, C = 2000, 128, 4
        T = 10
        sizes = [10, 20, 40, 80, 160]

        bmc_times, nn_times = [], []

        for D in sizes:
            X, y = _make_data(M, D, C)

            # ── BMC ──
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            t0 = time.perf_counter()
            cell.fit(X, y, n_classes=C)
            bmc_times.append(time.perf_counter() - t0)

            # ── NN ──
            mlp = MLPClassifier(
                hidden_layer_sizes=(W,),
                max_iter=T,
                random_state=42,
                solver="adam",
            )
            t0 = time.perf_counter()
            mlp.fit(X, y)
            nn_times.append(time.perf_counter() - t0)

            _print(f"D={D}  BMC={bmc_times[-1]:.3f}s  NN={nn_times[-1]:.3f}s  "
                   f"ratio={bmc_times[-1]/nn_times[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_times)
        nn_exp = _fit_power_law(sizes, nn_times)
        _print(f"Exponents — BMC: O(D^{bmc_exp:.2f})  NN: O(D^{nn_exp:.2f})")
        _print(f"Expected  — BMC: O(D^1) [W·D]   NN: O(D^1) [D·W first layer]")

        if save_plots:
            _save_comparison_plot(
                sizes, bmc_times, nn_times,
                f"Training time vs D (M={M}, W={W}, T/E={T})",
                "D (features)", "time (s)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_train_time_D.png")


class TestInferenceTime:
    """Compare inference time scaling."""

    def test_inference_time_vs_Q(self, save_plots):
        """Inference time vs query count, matched capacity W=128."""
        W, D, C = 128, 30, 4
        sizes = [500, 1000, 2000, 4000, 8000]

        # Train both once
        X_train, y_train = _make_data(2000, D, C)

        cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
        cell.fit(X_train, y_train, n_classes=C)

        mlp = MLPClassifier(
            hidden_layer_sizes=(W,), max_iter=50, random_state=42, solver="adam",
        )
        mlp.fit(X_train, y_train)

        bmc_times, nn_times = [], []
        rng = np.random.default_rng(99)

        for Q in sizes:
            queries = rng.standard_normal((Q, D)).astype(np.float32)

            t0 = time.perf_counter()
            cell.predict(queries)
            bmc_times.append(time.perf_counter() - t0)

            t0 = time.perf_counter()
            mlp.predict(queries)
            nn_times.append(time.perf_counter() - t0)

            _print(f"Q={Q:,}  BMC={bmc_times[-1]:.4f}s  NN={nn_times[-1]:.4f}s  "
                   f"ratio={bmc_times[-1]/nn_times[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_times)
        nn_exp = _fit_power_law(sizes, nn_times)
        _print(f"Exponents — BMC: O(Q^{bmc_exp:.2f})  NN: O(Q^{nn_exp:.2f})")

        if save_plots:
            _save_comparison_plot(
                sizes, bmc_times, nn_times,
                f"Inference time vs Q (W={W}, D={D})",
                "Q (queries)", "time (s)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_infer_time_Q.png")

    def test_inference_time_vs_W(self, save_plots):
        """Inference time vs capacity W. BMC: O(W·D). NN: O(W²)."""
        D, C = 30, 4
        Q = 4000
        sizes = [32, 64, 128, 256, 512]

        X_train, y_train = _make_data(2000, D, C)
        rng = np.random.default_rng(99)
        queries = rng.standard_normal((Q, D)).astype(np.float32)

        bmc_times, nn_times = [], []

        for W in sizes:
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            cell.fit(X_train, y_train, n_classes=C)

            mlp = MLPClassifier(
                hidden_layer_sizes=(W,), max_iter=50, random_state=42, solver="adam",
            )
            mlp.fit(X_train, y_train)

            t0 = time.perf_counter()
            cell.predict(queries)
            bmc_times.append(time.perf_counter() - t0)

            t0 = time.perf_counter()
            mlp.predict(queries)
            nn_times.append(time.perf_counter() - t0)

            _print(f"W={W}  BMC={bmc_times[-1]:.4f}s  NN={nn_times[-1]:.4f}s  "
                   f"ratio={bmc_times[-1]/nn_times[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_times)
        nn_exp = _fit_power_law(sizes, nn_times)
        _print(f"Exponents — BMC: O(W^{bmc_exp:.2f})  NN: O(W^{nn_exp:.2f})")
        _print(f"Expected  — BMC: O(W^1) [W·D]   NN: O(W^1–2) [W² but BLAS-optimized]")

        if save_plots:
            _save_comparison_plot(
                sizes, bmc_times, nn_times,
                f"Inference time vs W (Q={Q}, D={D})",
                "W (capacity)", "time (s)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_infer_time_W.png")


class TestTrainingMemory:
    """Compare peak training memory."""

    def test_training_memory_vs_M(self, save_plots):
        """Peak memory during training vs M."""
        W, D, C = 128, 30, 4
        sizes = [1000, 2000, 4000, 8000, 16000]

        bmc_peaks, nn_peaks = [], []

        for M in sizes:
            X, y = _make_data(M, D, C)

            # ── BMC ──
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            tracemalloc.start()
            tracemalloc.reset_peak()
            cell.fit(X, y, n_classes=C)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            bmc_peaks.append(peak)

            # ── NN ──
            mlp = MLPClassifier(
                hidden_layer_sizes=(W,), max_iter=10, random_state=42, solver="adam",
            )
            tracemalloc.start()
            tracemalloc.reset_peak()
            mlp.fit(X, y)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            nn_peaks.append(peak)

            _print(f"M={M:,}  BMC={bmc_peaks[-1]/1e6:.1f} MB  NN={nn_peaks[-1]/1e6:.1f} MB  "
                   f"ratio={bmc_peaks[-1]/nn_peaks[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_peaks)
        nn_exp = _fit_power_law(sizes, nn_peaks)
        _print(f"Exponents — BMC: O(M^{bmc_exp:.2f})  NN: O(M^{nn_exp:.2f})")

        if save_plots:
            _save_comparison_plot(
                sizes, [p / 1e6 for p in bmc_peaks], [p / 1e6 for p in nn_peaks],
                f"Training peak memory vs M (W={W}, D={D})",
                "M (samples)", "peak memory (MB)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_train_mem_M.png")

    def test_training_memory_vs_W(self, save_plots):
        """Peak memory during training vs capacity W."""
        M, D, C = 4000, 30, 4
        sizes = [32, 64, 128, 256, 512]
        X, y = _make_data(M, D, C)

        bmc_peaks, nn_peaks = [], []

        for W in sizes:
            # ── BMC ──
            cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
            tracemalloc.start()
            tracemalloc.reset_peak()
            cell.fit(X, y, n_classes=C)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            bmc_peaks.append(peak)

            # ── NN ──
            mlp = MLPClassifier(
                hidden_layer_sizes=(W,), max_iter=10, random_state=42, solver="adam",
            )
            tracemalloc.start()
            tracemalloc.reset_peak()
            mlp.fit(X, y)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            nn_peaks.append(peak)

            _print(f"W={W}  BMC={bmc_peaks[-1]/1e6:.1f} MB  NN={nn_peaks[-1]/1e6:.1f} MB  "
                   f"ratio={bmc_peaks[-1]/nn_peaks[-1]:.2f}x")

        bmc_exp = _fit_power_law(sizes, bmc_peaks)
        nn_exp = _fit_power_law(sizes, nn_peaks)
        _print(f"Exponents — BMC: O(W^{bmc_exp:.2f})  NN: O(W^{nn_exp:.2f})")
        _print(f"Expected  — BMC: O(W^2) [K² TSP]  NN: O(W^1–2) [W² weights + activations]")

        if save_plots:
            _save_comparison_plot(
                sizes, [p / 1e6 for p in bmc_peaks], [p / 1e6 for p in nn_peaks],
                f"Training peak memory vs W (M={M}, D={D})",
                "W (capacity)", "peak memory (MB)", bmc_exp, nn_exp,
                f"{PLOT_DIR}/vs_train_mem_W.png")


class TestAccuracyAtMatchedCapacity:
    """Sanity check: both achieve reasonable accuracy on easy data."""

    def test_accuracy_matched(self):
        """Both BMC and NN should get >=90% on well-separated clusters."""
        M, D, C, W = 2000, 30, 4, 128
        X, y = _make_data(M, D, C)

        idx = np.random.default_rng(99).permutation(M)
        X_train, X_test = X[idx[:1400]], X[idx[1400:]]
        y_train, y_test = y[idx[:1400]], y[idx[1400:]]

        cell = BMCCell(n_clusters=W, rng=np.random.default_rng(42))
        cell.fit(X_train, y_train, n_classes=C)
        bmc_acc = (cell.predict(X_test) == y_test).mean()

        mlp = MLPClassifier(
            hidden_layer_sizes=(W,), max_iter=100, random_state=42, solver="adam",
        )
        mlp.fit(X_train, y_train)
        nn_acc = (mlp.predict(X_test) == y_test).mean()

        _print(f"Accuracy — BMC: {bmc_acc:.3f}  NN: {nn_acc:.3f}")
        assert bmc_acc >= 0.90, f"BMC accuracy {bmc_acc:.3f} < 0.90"
        assert nn_acc >= 0.90, f"NN accuracy {nn_acc:.3f} < 0.90"
