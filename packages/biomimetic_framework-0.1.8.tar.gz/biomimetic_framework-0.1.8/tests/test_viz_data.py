# tests/test_viz_data.py
"""
Tests for bmc.viz data visualizations:
- scatter: UMAP/PCA scatter with Voronoi + geodesic
- architecture: composite with scatter plots in cell boxes
- trace: prediction trace with highlighted cells
- parametric: geodesic curvature plot
- riemannian: 3D manifold surface
"""

import numpy as np
import os
import pytest
from bmc import (
    BMCCell, BMCLayer, BMCNetwork, BMCClassifier, BMCRegressor,
    TabularObservationSpace, L2Metric, SplineInterpolator, LinearInterpolator,
)
from bmc.viz import scatter, architecture, trace, parametric, riemannian


OUTPUT_DIR = "/tmp/bmc_viz_test"


@pytest.fixture(scope="module", autouse=True)
def make_output_dir():
    os.makedirs(OUTPUT_DIR, exist_ok=True)


def _make_data(n_classes=4, n_per_class=100, D=8):
    rng = np.random.default_rng(42)
    X, y = [], []
    for c in range(n_classes):
        center = rng.uniform(-8, 8, D).astype(np.float32)
        X.append(center + rng.normal(0, 1.0, (n_per_class, D)).astype(np.float32))
        y.extend([c] * n_per_class)
    return np.vstack(X), np.array(y, dtype=np.int32)


# ── Scatter ──────────────────────────────────────────────────────────────────

class TestScatter:

    def test_cell(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16, metric=L2Metric())
        cell.fit(X, y, n_classes=4)
        path = scatter(cell, X, y, f"{OUTPUT_DIR}/scatter_cell")
        assert os.path.exists(path)

    def test_cell_pca(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=4)
        path = scatter(cell, X, y, f"{OUTPUT_DIR}/scatter_pca", method="pca")
        assert os.path.exists(path)

    def test_layer_grid(self):
        X, y = _make_data(4, 80, 16)
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        layer = BMCLayer(obs, n_clusters=8)
        layer.fit(X, y, n_classes=4)
        path = scatter(layer, X, y, f"{OUTPUT_DIR}/scatter_layer")
        assert os.path.exists(path)

    def test_layer_single_zone(self):
        X, y = _make_data(4, 80, 16)
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        layer = BMCLayer(obs, n_clusters=8)
        layer.fit(X, y, n_classes=4)
        path = scatter(layer, X, y, f"{OUTPUT_DIR}/scatter_zone1", zone=1)
        assert os.path.exists(path)

    def test_classifier(self):
        X, y = _make_data(4, 80, 16)
        clf = BMCClassifier(
            observation_space=TabularObservationSpace(n_features=16, n_zones=4),
            n_clusters=16)
        clf.fit(X, y)
        path = scatter(clf, X, y, f"{OUTPUT_DIR}/scatter_clf")
        assert os.path.exists(path)

    def test_regressor(self):
        X, y = _make_data(4, 80, 16)
        y_reg = X[:, 0].astype(np.float32)
        y_bins = np.digitize(y_reg, np.percentile(y_reg, [50])).astype(np.int32)
        reg = BMCRegressor(
            observation_space=TabularObservationSpace(n_features=16, n_zones=4),
            n_clusters=8)
        reg.fit(X, y_reg)
        path = scatter(reg, X, y_bins, f"{OUTPUT_DIR}/scatter_reg", zone=0)
        assert os.path.exists(path)

    def test_unfitted_raises(self):
        X, y = _make_data()
        cell = BMCCell(n_clusters=16)
        with pytest.raises(ValueError, match="not fitted"):
            scatter(cell, X, y)


# ── Architecture (composite) ────────────────────────────────────────────────

class TestArchitecture:

    def test_cell(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=4)
        path = architecture(cell, X, y, f"{OUTPUT_DIR}/arch_cell")
        assert os.path.exists(path)

    def test_network(self):
        X, y = _make_data(4, 80, 16)
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([BMCLayer(obs, n_clusters=8), BMCCell(n_clusters=8)])
        net.fit(X, y, n_classes=4)
        path = architecture(net, X, y, f"{OUTPUT_DIR}/arch_net")
        assert os.path.exists(path)

    def test_classifier(self):
        X, y = _make_data(4, 80, 16)
        clf = BMCClassifier(
            observation_space=TabularObservationSpace(n_features=16, n_zones=4),
            n_clusters=8)
        clf.fit(X, y)
        path = architecture(clf, X, y, f"{OUTPUT_DIR}/arch_clf")
        assert os.path.exists(path)

    def test_regressor(self):
        X, y = _make_data(4, 80, 16)
        y_reg = X[:, 0].astype(np.float32)
        y_bins = np.digitize(y_reg, np.percentile(y_reg, [50])).astype(np.int32)
        reg = BMCRegressor(
            observation_space=TabularObservationSpace(n_features=16, n_zones=4),
            n_clusters=8)
        reg.fit(X, y_reg)
        path = architecture(reg, X, y_bins, f"{OUTPUT_DIR}/arch_reg")
        assert os.path.exists(path)


# ── Trace ────────────────────────────────────────────────────────────────────

class TestTrace:

    def test_cell(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16, interpolate=True)
        cell.fit(X, y, n_classes=4)
        path = trace(cell, X, y, X[0], f"{OUTPUT_DIR}/trace_cell")
        assert os.path.exists(path)

    def test_network(self):
        X, y = _make_data(4, 80, 16)
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=8, interpolate=True),
            BMCCell(n_clusters=8, interpolate=True),
        ])
        net.fit(X, y, n_classes=4)
        path = trace(net, X, y, X[0], f"{OUTPUT_DIR}/trace_net")
        assert os.path.exists(path)

    def test_classifier(self):
        X, y = _make_data(4, 80, 16)
        clf = BMCClassifier(
            observation_space=TabularObservationSpace(n_features=16, n_zones=4),
            n_clusters=8)
        clf.fit(X, y)
        path = trace(clf, X, y, X[0], f"{OUTPUT_DIR}/trace_clf")
        assert os.path.exists(path)


# ── Parametric (geodesic curvature) ──────────────────────────────────────────

class TestParametric:

    def test_spline(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16, interpolator=SplineInterpolator())
        cell.fit(X, y, n_classes=4)
        path = parametric(cell, f"{OUTPUT_DIR}/param_spline")
        assert os.path.exists(path)

    def test_linear(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16, interpolator=LinearInterpolator())
        cell.fit(X, y, n_classes=4)
        path = parametric(cell, f"{OUTPUT_DIR}/param_linear")
        assert os.path.exists(path)

    def test_hard(self):
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=4)
        path = parametric(cell, f"{OUTPUT_DIR}/param_hard")
        assert os.path.exists(path)

    def test_unfitted_raises(self):
        cell = BMCCell(n_clusters=16)
        with pytest.raises(ValueError, match="not fitted"):
            parametric(cell)


# ── Riemannian manifold ──────────────────────────────────────────────────────

class TestRiemannian:

    def test_d2_c1_direct(self):
        """D=2, C=1 → D+C=3, plotted directly."""
        rng = np.random.default_rng(42)
        X = rng.uniform(-5, 5, (200, 2)).astype(np.float32)
        z = (X[:, 0]**2 + X[:, 1]**2).astype(np.float64)
        cell = BMCCell(n_clusters=16, interpolator=SplineInterpolator())
        cell.fit_regression(X, z)
        path = riemannian(cell, f"{OUTPUT_DIR}/riemann_d2c1", grid_samples=5000)
        assert os.path.exists(path)

    def test_high_d_umap(self):
        """D=8, C=4 → D+C=12, needs UMAP."""
        X, y = _make_data(4, 80, 8)
        cell = BMCCell(n_clusters=16, interpolator=SplineInterpolator())
        cell.fit(X, y, n_classes=4)
        path = riemannian(cell, f"{OUTPUT_DIR}/riemann_umap", grid_samples=5000)
        assert os.path.exists(path)

    def test_unfitted_raises(self):
        cell = BMCCell(n_clusters=16)
        with pytest.raises(ValueError, match="not fitted"):
            riemannian(cell)
