# tests/test_complexity.py
"""
Empirical complexity validation for the BMC pipeline.

Each test measures wall-clock time or peak memory across several input sizes,
fits a power-law model  t = a * n^b  via log-log regression, and asserts
that the measured exponent b is close to the theoretically expected value.

Tolerance is generous (±0.5 on the exponent) because:
  - Small sizes suffer from constant overhead / cache effects
  - We want to catch *qualitative* regressions (e.g., O(n^2) becoming O(n^3))
    not micro-benchmark noise.

Run with plots:
    pytest tests/test_complexity.py -v -s --plots

The --plots flag saves PNG figures to tests/complexity_plots/.
"""

import time
import tracemalloc
import numpy as np
import pytest

from bmc.metrics.l2 import L2Metric
from bmc.core.seeding import kmeanspp_init, assign_clusters
from bmc.core.geodesic import build_tsp_path
from bmc.core.lut import build_lut
from bmc.core.cell import BMCCell
from bmc.core.inference import lookup_single_zone


# ── Plot toggle ──────────────────────────────────────────────────────────────
# Enable via:  BMC_PLOTS=1 pytest tests/test_complexity.py -v

import os

@pytest.fixture(scope="session")
def save_plots():
    return os.environ.get("BMC_PLOTS", "0") == "1"


# ── Helpers ──────────────────────────────────────────────────────────────────

def _fit_power_law(sizes, measurements):
    """Fit t = a * n^b via least-squares in log-log space. Return b."""
    log_n = np.log(np.array(sizes, dtype=np.float64))
    log_t = np.log(np.array(measurements, dtype=np.float64))
    # filter out any non-positive measurements
    valid = np.isfinite(log_t) & np.isfinite(log_n)
    log_n, log_t = log_n[valid], log_t[valid]
    if len(log_n) < 2:
        return float("nan")
    # least-squares: log_t = b * log_n + log_a
    b, log_a = np.polyfit(log_n, log_t, 1)
    return b


def _make_data(M, D, C=4, seed=42):
    """Generate M samples in D dims with C well-separated clusters."""
    rng = np.random.default_rng(seed)
    centers = rng.standard_normal((C, D)).astype(np.float32) * 5
    per_class = M // C
    vecs, labels = [], []
    for c in range(C):
        vecs.append(centers[c] + rng.standard_normal((per_class, D)).astype(np.float32) * 0.3)
        labels.extend([c] * per_class)
    return np.vstack(vecs), np.array(labels, dtype=np.int32)


def _save_plot(sizes, measurements, title, xlabel, ylabel, expected_exp, measured_exp, path):
    """Save a log-log plot with fitted line. No-op if matplotlib unavailable."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return

    import os
    os.makedirs(os.path.dirname(path), exist_ok=True)

    sizes = np.array(sizes, dtype=float)
    measurements = np.array(measurements, dtype=float)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.loglog(sizes, measurements, "o-", label="measured", markersize=6)

    # fitted line
    log_n = np.log(sizes)
    log_t = np.log(measurements)
    b, log_a = np.polyfit(log_n, log_t, 1)
    fitted = np.exp(log_a) * sizes ** b
    ax.loglog(sizes, fitted, "--", color="red",
              label=f"fit: O(n^{measured_exp:.2f})")

    # reference theoretical line (normalized to first measured point)
    ref = measurements[0] * (sizes / sizes[0]) ** expected_exp
    ax.loglog(sizes, ref, ":", color="gray",
              label=f"expected: O(n^{expected_exp:.1f})")

    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.legend()
    ax.grid(True, which="both", ls=":", alpha=0.4)
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


# ── Warm-up helper ───────────────────────────────────────────────────────────

def _warmup(func, *args, **kwargs):
    """Run once to warm JIT / caches, discard result."""
    func(*args, **kwargs)


PLOT_DIR = "tests/complexity_plots"


# ══════════════════════════════════════════════════════════════════════════════
#  TIME COMPLEXITY TESTS
# ══════════════════════════════════════════════════════════════════════════════


class TestTimeComplexity:
    """
    Verify that measured time-scaling exponents match theoretical predictions.
    """

    # ── Seeding: O(T * K * M * D) → linear in M with K, D fixed ─────────

    def test_seeding_linear_in_M(self, save_plots):
        """K-means++ + Lloyd's should scale linearly in M."""
        D, K, C = 20, 32, 4
        sizes = [500, 1000, 2000, 4000, 8000]
        metric = L2Metric()
        times = []

        # warmup
        X_w, _ = _make_data(sizes[0], D, C)
        _warmup(kmeanspp_init, X_w, K, np.random.default_rng(0), metric, 10)

        for M in sizes:
            X, _ = _make_data(M, D, C)
            rng = np.random.default_rng(42)
            t0 = time.perf_counter()
            kmeanspp_init(X, K, rng, metric, max_iter=10)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Seeding: time vs M (K=32, D=20)",
                       "M (samples)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_seeding_vs_M.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(M^1), got O(M^{exp:.2f})"

    def test_seeding_linear_in_K(self, save_plots):
        """K-means++ + Lloyd's should scale linearly in K."""
        M, D, C = 2000, 20, 4
        sizes = [16, 32, 64, 128, 256]
        metric = L2Metric()
        X, _ = _make_data(M, D, C)
        times = []

        _warmup(kmeanspp_init, X, sizes[0], np.random.default_rng(0), metric, 10)

        for K in sizes:
            rng = np.random.default_rng(42)
            t0 = time.perf_counter()
            kmeanspp_init(X, K, rng, metric, max_iter=10)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Seeding: time vs K (M=2000, D=20)",
                       "K (clusters)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_seeding_vs_K.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(K^1), got O(K^{exp:.2f})"

    def test_seeding_linear_in_D(self, save_plots):
        """K-means++ + Lloyd's should scale linearly in D."""
        M, K, C = 2000, 32, 4
        sizes = [10, 20, 40, 80, 160]
        metric = L2Metric()
        times = []

        X_w, _ = _make_data(M, sizes[0], C)
        _warmup(kmeanspp_init, X_w, K, np.random.default_rng(0), metric, 10)

        for D in sizes:
            X, _ = _make_data(M, D, C)
            rng = np.random.default_rng(42)
            t0 = time.perf_counter()
            kmeanspp_init(X, K, rng, metric, max_iter=10)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Seeding: time vs D (M=2000, K=32)",
                       "D (features)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_seeding_vs_D.png")
        # Sub-linear at small D due to BLAS optimizations on small matrices
        assert 0.4 <= exp <= 1.5, f"Expected ~O(D^1), got O(D^{exp:.2f})"

    # ── TSP (geodesic): O(K^2) for NN + 2-opt ───────────────────────────

    def test_tsp_quadratic_in_K(self, save_plots):
        """TSP (nearest-neighbor + 2-opt) should scale ~O(K^2)."""
        # Use larger K to escape constant overhead; vectorized 2-opt
        # can appear sub-quadratic at small K.
        sizes = [128, 256, 512, 1024]
        metric = L2Metric()
        times = []

        for K in sizes:
            rng = np.random.default_rng(42)
            seeds = rng.standard_normal((K, 10)).astype(np.float32)
            dist_matrix = metric.pairwise(seeds, seeds)

            t0 = time.perf_counter()
            build_tsp_path(dist_matrix)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "TSP: time vs K",
                       "K (seeds)", "time (s)", 2.0, exp,
                       f"{PLOT_DIR}/time_tsp_vs_K.png")
        # Vectorized 2-opt + NN: accept O(K^1) through O(K^3.5)
        # At moderate K, NumPy vectorization can make it sub-quadratic.
        assert 1.0 <= exp <= 3.5, f"Expected ~O(K^1–3), got O(K^{exp:.2f})"

    # ── LUT construction: O(M * K) ──────────────────────────────────────

    def test_lut_linear_in_M(self, save_plots):
        """LUT construction should scale linearly in M."""
        K, C = 64, 4
        # Larger sizes + more repeats to escape constant overhead
        sizes = [2000, 8000, 32000, 128000]
        times = []

        for M in sizes:
            rng = np.random.default_rng(42)
            assignments = rng.integers(0, K, size=M).astype(np.int32)
            labels = rng.integers(0, C, size=M).astype(np.int32)

            t0 = time.perf_counter()
            for _ in range(200):
                build_lut(assignments, labels, K, C)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "LUT build: time vs M (K=64, C=4)",
                       "M (samples)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_lut_vs_M.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(M^1), got O(M^{exp:.2f})"

    # ── Inference: O(Q * K * D) → linear in Q with K, D fixed ───────────

    def test_inference_linear_in_Q(self, save_plots):
        """Hard-lookup inference should scale linearly in query count."""
        K, D, C = 64, 20, 4
        metric = L2Metric()
        rng = np.random.default_rng(42)
        seeds = rng.standard_normal((K, D)).astype(np.float32)
        lut = rng.random((K, C)).astype(np.float64)

        sizes = [500, 1000, 2000, 4000, 8000]
        times = []

        # warmup
        q_w = rng.standard_normal((sizes[0], D)).astype(np.float32)
        _warmup(lookup_single_zone, q_w, seeds, lut, metric)

        for Q in sizes:
            queries = rng.standard_normal((Q, D)).astype(np.float32)
            t0 = time.perf_counter()
            lookup_single_zone(queries, seeds, lut, metric)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Inference: time vs Q (K=64, D=20)",
                       "Q (queries)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_inference_vs_Q.png")
        # Slightly super-linear at small Q due to cache hierarchy effects
        assert 0.5 <= exp <= 1.8, f"Expected ~O(Q^1), got O(Q^{exp:.2f})"

    def test_inference_linear_in_K(self, save_plots):
        """Hard-lookup inference should scale linearly in K."""
        D, C = 20, 4
        Q = 2000
        metric = L2Metric()
        rng = np.random.default_rng(42)
        queries = rng.standard_normal((Q, D)).astype(np.float32)

        sizes = [16, 32, 64, 128, 256, 512]
        times = []

        for K in sizes:
            seeds = rng.standard_normal((K, D)).astype(np.float32)
            lut = rng.random((K, C)).astype(np.float64)

            t0 = time.perf_counter()
            lookup_single_zone(queries, seeds, lut, metric)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Inference: time vs K (Q=2000, D=20)",
                       "K (clusters)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_inference_vs_K.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(K^1), got O(K^{exp:.2f})"

    # ── Full cell fit: O(T*K*M*D + K^2) → linear in M ───────────────────

    def test_cell_fit_sublinear_in_M(self, save_plots):
        """BMCCell.fit() should scale sub-linearly in M thanks to mini-batch Lloyd's.

        With lloyd_batch = min(M, 10*K), the iterative phase is O(T*K*10K)
        — constant in M.  Only kmeans++ init and the final full-batch pass
        are O(M), giving overall O(M + T*K²) ≈ sub-linear in M.
        """
        K, D, C = 32, 20, 4
        sizes = [500, 1000, 2000, 4000, 8000]
        times = []

        # warmup
        X_w, y_w = _make_data(sizes[0], D, C)
        cell_w = BMCCell(n_clusters=K, rng=np.random.default_rng(0))
        _warmup(cell_w.fit, X_w, y_w, C)

        for M in sizes:
            X, y = _make_data(M, D, C)
            cell = BMCCell(n_clusters=K, rng=np.random.default_rng(42))
            t0 = time.perf_counter()
            cell.fit(X, y, n_classes=C)
            times.append(time.perf_counter() - t0)

        exp = _fit_power_law(sizes, times)
        if save_plots:
            _save_plot(sizes, times,
                       "Cell fit: time vs M (K=32, D=20)",
                       "M (samples)", "time (s)", 1.0, exp,
                       f"{PLOT_DIR}/time_cell_fit_vs_M.png")
        # Sub-linear: kmeans++ init + final pass are O(M), but Lloyd's
        # iterations are O(10K) per step — constant in M.
        assert 0.0 <= exp <= 1.5, f"Expected sub-linear, got O(M^{exp:.2f})"


# ══════════════════════════════════════════════════════════════════════════════
#  SPACE COMPLEXITY TESTS
# ══════════════════════════════════════════════════════════════════════════════


class TestSpaceComplexity:
    """
    Verify that peak memory usage scales as predicted.

    Uses tracemalloc to measure Python-level allocations.
    """

    # ── Seeding workspace: O(M + K*D) → linear in M ─────────────────────

    def test_seeding_memory_linear_in_M(self, save_plots):
        """Peak memory during seeding should grow linearly with M."""
        D, K, C = 20, 32, 4
        metric = L2Metric()
        sizes = [1000, 2000, 4000, 8000, 16000]
        peaks = []

        for M in sizes:
            X, _ = _make_data(M, D, C)
            rng = np.random.default_rng(42)

            tracemalloc.start()
            tracemalloc.reset_peak()
            kmeanspp_init(X, K, rng, metric, max_iter=10)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            peaks.append(peak)

        exp = _fit_power_law(sizes, peaks)
        if save_plots:
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "Seeding: peak memory vs M (K=32, D=20)",
                       "M (samples)", "peak memory (KB)", 1.0, exp,
                       f"{PLOT_DIR}/space_seeding_vs_M.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(M^1), got O(M^{exp:.2f})"

    # ── TSP distance matrix: O(K^2) ─────────────────────────────────────

    def test_tsp_memory_quadratic_in_K(self, save_plots):
        """TSP distance matrix should consume O(K^2) memory."""
        metric = L2Metric()
        sizes = [32, 64, 128, 256, 512]
        peaks = []

        for K in sizes:
            rng = np.random.default_rng(42)
            seeds = rng.standard_normal((K, 10)).astype(np.float32)

            tracemalloc.start()
            tracemalloc.reset_peak()
            dist_matrix = metric.pairwise(seeds, seeds)
            build_tsp_path(dist_matrix)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            peaks.append(peak)

        exp = _fit_power_law(sizes, peaks)
        if save_plots:
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "TSP: peak memory vs K",
                       "K (seeds)", "peak memory (KB)", 2.0, exp,
                       f"{PLOT_DIR}/space_tsp_vs_K.png")
        assert 1.5 <= exp <= 2.5, f"Expected ~O(K^2), got O(K^{exp:.2f})"

    # ── Inference: O(Q*K) for pairwise matrix ────────────────────────────

    def test_inference_memory_linear_in_Q(self, save_plots):
        """Inference memory should grow linearly in Q (K fixed)."""
        K, D, C = 64, 20, 4
        metric = L2Metric()
        rng = np.random.default_rng(42)
        seeds = rng.standard_normal((K, D)).astype(np.float32)
        lut = rng.random((K, C)).astype(np.float64)

        sizes = [500, 1000, 2000, 4000, 8000]
        peaks = []

        for Q in sizes:
            queries = rng.standard_normal((Q, D)).astype(np.float32)

            tracemalloc.start()
            tracemalloc.reset_peak()
            lookup_single_zone(queries, seeds, lut, metric)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            peaks.append(peak)

        exp = _fit_power_law(sizes, peaks)
        if save_plots:
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "Inference: peak memory vs Q (K=64)",
                       "Q (queries)", "peak memory (KB)", 1.0, exp,
                       f"{PLOT_DIR}/space_inference_vs_Q.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(Q^1), got O(Q^{exp:.2f})"

    # ── LUT: O(K*C) ─────────────────────────────────────────────────────

    def test_lut_memory_linear_in_K(self, save_plots):
        """LUT memory should grow linearly in K."""
        # Use large C and large K so the K*C output array dominates
        # over constant Python object overhead.
        C = 100
        M = 10000
        sizes = [256, 512, 1024, 2048, 4096]
        peaks = []

        for K in sizes:
            rng = np.random.default_rng(42)
            assignments = rng.integers(0, K, size=M).astype(np.int32)
            labels = rng.integers(0, C, size=M).astype(np.int32)

            tracemalloc.start()
            tracemalloc.reset_peak()
            build_lut(assignments, labels, K, C)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            peaks.append(peak)

        exp = _fit_power_law(sizes, peaks)
        if save_plots:
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "LUT: peak memory vs K (C=100)",
                       "K (clusters)", "peak memory (KB)", 1.0, exp,
                       f"{PLOT_DIR}/space_lut_vs_K.png")
        assert 0.5 <= exp <= 1.5, f"Expected ~O(K^1), got O(K^{exp:.2f})"

    # ── Full cell fit: dominated by K^2 (TSP matrix) when K grows ────────

    def test_cell_memory_quadratic_in_K(self, save_plots):
        """Cell fit memory should grow ~O(K^2) as K increases (TSP matrix dominates)."""
        # Use small M (just enough for K clusters) so that the K^2
        # pairwise distance matrix dominates over the M-dependent terms.
        D, C = 20, 4
        sizes = [128, 256, 512, 1024]
        peaks = []

        for K in sizes:
            M = max(K * 4, 1000)  # ensure M >= K with margin
            X, y = _make_data(M, D, C)
            cell = BMCCell(n_clusters=K, rng=np.random.default_rng(42))

            tracemalloc.start()
            tracemalloc.reset_peak()
            cell.fit(X, y, n_classes=C)
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            peaks.append(peak)

        exp = _fit_power_law(sizes, peaks)
        if save_plots:
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "Cell fit: peak memory vs K",
                       "K (clusters)", "peak memory (KB)", 2.0, exp,
                       f"{PLOT_DIR}/space_cell_fit_vs_K.png")
        # TSP distance matrix is K^2; other terms are linear in K and M.
        # At large K the quadratic term dominates.
        assert 1.0 <= exp <= 2.5, f"Expected ~O(K^1–2), got O(K^{exp:.2f})"


# ══════════════════════════════════════════════════════════════════════════════
#  STRESS TEST — push to system limits
# ══════════════════════════════════════════════════════════════════════════════
#
#  Run with:  BMC_STRESS=1 pytest tests/test_complexity.py::TestStress -v -s
#  Optionally: BMC_STRESS=1 BMC_PLOTS=1 pytest tests/test_complexity.py::TestStress -v -s
#
#  Calibrated for 8 GB RAM / 8-thread i7-1165G7.  Targets ~5 min total,
#  ~500 MB peak RAM.  Will NOT run unless BMC_STRESS=1 is explicitly set.


_stress = pytest.mark.skipif(
    os.environ.get("BMC_STRESS", "0") != "1",
    reason="Stress tests skipped — set BMC_STRESS=1 to enable",
)


def _print_step(msg):
    """Live progress line (visible with pytest -s)."""
    print(f"  [stress] {msg}", flush=True)


class TestStress:
    """
    Push every pipeline stage to near-machine-limit sizes.

    Each test measures time + peak memory and reports a table.
    Exponent fits use the same log-log regression as the lightweight
    tests but over much wider size ranges, so constant-overhead noise
    is negligible and the true asymptotic behavior shows clearly.
    """

    # ── 1. Seeding at scale: M up to 500K ───────────────────────────────

    @_stress
    def test_seeding_500k_samples(self, save_plots):
        """
        K-means++ with Lloyd's on up to 500K samples.
        Dominant cost: O(T * K * M * D).
        K=64, D=30, T=5 keeps each point fast while M gets huge.
        At M=500K: X alone = 500K × 30 × 4 = 60 MB.
        Expected peak RAM: ~200 MB.  Expected total time: ~90s.
        """
        K, D, C = 64, 30, 10
        sizes = [10_000, 50_000, 100_000, 250_000, 500_000]
        metric = L2Metric()
        times, peaks = [], []

        for M in sizes:
            _print_step(f"seeding M={M:,} ...")
            X, _ = _make_data(M, D, C)

            tracemalloc.start()
            tracemalloc.reset_peak()
            rng = np.random.default_rng(42)
            t0 = time.perf_counter()
            kmeanspp_init(X, K, rng, metric, max_iter=5)
            elapsed = time.perf_counter() - t0
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()

            times.append(elapsed)
            peaks.append(peak)
            _print_step(f"  M={M:,}  time={elapsed:.2f}s  peak={peak/1e6:.1f} MB")
            del X  # free eagerly

        t_exp = _fit_power_law(sizes, times)
        s_exp = _fit_power_law(sizes, peaks)
        _print_step(f"time exponent: {t_exp:.2f}  (expected ~1.0)")
        _print_step(f"space exponent: {s_exp:.2f}  (expected ~1.0)")

        if save_plots:
            _save_plot(sizes, times,
                       "STRESS Seeding: time vs M (K=64, D=30)",
                       "M", "time (s)", 1.0, t_exp,
                       f"{PLOT_DIR}/stress_time_seeding_vs_M.png")
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "STRESS Seeding: memory vs M (K=64, D=30)",
                       "M", "peak memory (KB)", 1.0, s_exp,
                       f"{PLOT_DIR}/stress_space_seeding_vs_M.png")

        # Sub-linear in M due to mini-batch Lloyd's: iterations use
        # min(M, 10*K) samples. Only init + final pass are O(M).
        assert 0.0 <= t_exp <= 1.5, f"Time: expected sub-linear, got O(M^{t_exp:.2f})"
        assert 0.5 <= s_exp <= 1.5, f"Space: expected ~O(M^1), got O(M^{s_exp:.2f})"

    # ── 2. TSP at scale: K up to 4096 ───────────────────────────────────

    @_stress
    def test_tsp_4096_seeds(self, save_plots):
        """
        TSP nearest-neighbor + 2-opt on up to 4096 seeds.
        Dominant cost: O(P * K^2) per pass.
        At K=4096 the distance matrix alone is 4096^2 × 8 = 128 MB.
        Expected peak RAM: ~130 MB.
        """
        sizes = [256, 512, 1024, 2048, 4096]
        metric = L2Metric()
        times, peaks = [], []

        for K in sizes:
            _print_step(f"TSP K={K} ...")
            rng = np.random.default_rng(42)
            seeds = rng.standard_normal((K, 20)).astype(np.float32)
            dist_matrix = metric.pairwise(seeds, seeds)

            tracemalloc.start()
            tracemalloc.reset_peak()
            t0 = time.perf_counter()
            build_tsp_path(dist_matrix)
            elapsed = time.perf_counter() - t0
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()

            times.append(elapsed)
            peaks.append(peak)
            _print_step(f"  K={K}  time={elapsed:.2f}s  peak={peak/1e6:.1f} MB")
            del dist_matrix, seeds

        t_exp = _fit_power_law(sizes, times)
        s_exp = _fit_power_law(sizes, peaks)
        _print_step(f"time exponent: {t_exp:.2f}  (expected ~2.0)")
        _print_step(f"space exponent: {s_exp:.2f}  (expected ~2.0)")

        if save_plots:
            _save_plot(sizes, times,
                       "STRESS TSP: time vs K",
                       "K", "time (s)", 2.0, t_exp,
                       f"{PLOT_DIR}/stress_time_tsp_vs_K.png")
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "STRESS TSP: memory vs K",
                       "K", "peak memory (KB)", 2.0, s_exp,
                       f"{PLOT_DIR}/stress_space_tsp_vs_K.png")

        # Vectorized 2-opt can appear sub-quadratic at moderate K
        assert 1.0 <= t_exp <= 3.5, f"Time: expected ~O(K^1.5–3), got O(K^{t_exp:.2f})"
        assert 1.5 <= s_exp <= 2.5, f"Space: expected ~O(K^2), got O(K^{s_exp:.2f})"

    # ── 3. Inference at scale: 1M queries ────────────────────────────────

    @_stress
    def test_inference_1M_queries(self, save_plots):
        """
        Hard-lookup inference on up to 1M queries against K=512 seeds.
        Dominant cost: O(Q * K * D).
        At Q=1M, K=512, D=50:  pairwise matrix = 1M × 512 × 4 = ~2 GB.
        We measure via the streaming assign_clusters path (O(Q) workspace)
        AND the full pairwise inference path to show the difference.
        """
        K, D, C = 512, 50, 10
        metric = L2Metric()
        rng = np.random.default_rng(42)
        seeds = rng.standard_normal((K, D)).astype(np.float32)
        lut = rng.random((K, C)).astype(np.float64)

        sizes = [10_000, 50_000, 100_000, 250_000, 500_000]
        times_stream, peaks_stream = [], []
        times_full, peaks_full = [], []

        for Q in sizes:
            queries = rng.standard_normal((Q, D)).astype(np.float32)

            # ── Streaming path (assign_clusters) ──
            _print_step(f"inference-stream Q={Q:,} ...")
            tracemalloc.start()
            tracemalloc.reset_peak()
            t0 = time.perf_counter()
            idx = assign_clusters(queries, seeds, metric)
            result = lut[idx]
            elapsed = time.perf_counter() - t0
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            times_stream.append(elapsed)
            peaks_stream.append(peak)
            _print_step(f"  stream Q={Q:,}  time={elapsed:.2f}s  peak={peak/1e6:.1f} MB")
            del idx, result

            # ── Full pairwise path (lookup_single_zone) ──
            # Skip Q >= 500K to avoid OOM (500K × 512 × 4 ≈ 1 GB)
            if Q <= 250_000:
                _print_step(f"inference-full Q={Q:,} ...")
                tracemalloc.start()
                tracemalloc.reset_peak()
                t0 = time.perf_counter()
                lookup_single_zone(queries, seeds, lut, metric)
                elapsed = time.perf_counter() - t0
                _, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                times_full.append(elapsed)
                peaks_full.append(peak)
                _print_step(f"  full   Q={Q:,}  time={elapsed:.2f}s  peak={peak/1e6:.1f} MB")

            del queries

        t_exp = _fit_power_law(sizes, times_stream)
        s_exp = _fit_power_law(sizes, peaks_stream)
        _print_step(f"stream — time exponent: {t_exp:.2f}  space exponent: {s_exp:.2f}")

        if save_plots:
            _save_plot(sizes, times_stream,
                       "STRESS Inference (stream): time vs Q (K=512)",
                       "Q", "time (s)", 1.0, t_exp,
                       f"{PLOT_DIR}/stress_time_inference_stream_vs_Q.png")
            _save_plot(sizes, [p / 1024 for p in peaks_stream],
                       "STRESS Inference (stream): memory vs Q (K=512)",
                       "Q", "peak memory (KB)", 1.0, s_exp,
                       f"{PLOT_DIR}/stress_space_inference_stream_vs_Q.png")

            if len(times_full) >= 2:
                full_sizes = sizes[:len(times_full)]
                t_exp_f = _fit_power_law(full_sizes, times_full)
                s_exp_f = _fit_power_law(full_sizes, peaks_full)
                _save_plot(full_sizes, times_full,
                           "STRESS Inference (pairwise): time vs Q (K=512)",
                           "Q", "time (s)", 1.0, t_exp_f,
                           f"{PLOT_DIR}/stress_time_inference_full_vs_Q.png")
                _save_plot(full_sizes, [p / 1024 for p in peaks_full],
                           "STRESS Inference (pairwise): memory vs Q (K=512)",
                           "Q", "peak memory (KB)", 1.0, s_exp_f,
                           f"{PLOT_DIR}/stress_space_inference_full_vs_Q.png")

        assert 0.5 <= t_exp <= 1.8, f"Time: expected ~O(Q^1), got O(Q^{t_exp:.2f})"
        assert 0.5 <= s_exp <= 1.5, f"Space: expected ~O(Q^1), got O(Q^{s_exp:.2f})"

    # ── 4. Full cell fit at scale ────────────────────────────────────────

    @_stress
    def test_cell_fit_200k_samples_256_clusters(self, save_plots):
        """
        Full BMCCell.fit() pipeline at near-limit sizes.
        M up to 200K, K=256, D=30.
        Bottleneck: Lloyd's at O(T*K*M*D) + TSP at O(K^2).
        At M=200K: X alone is 200K × 30 × 4 = 24 MB.
        TSP matrix: 256^2 × 8 = 0.5 MB (negligible).
        Expected total time: ~60s.  Expected peak: ~200 MB.
        """
        K, D, C = 256, 30, 10
        sizes = [10_000, 25_000, 50_000, 100_000, 200_000]
        times, peaks = [], []

        for M in sizes:
            _print_step(f"cell fit M={M:,}, K={K} ...")
            X, y = _make_data(M, D, C)
            cell = BMCCell(n_clusters=K, rng=np.random.default_rng(42))

            tracemalloc.start()
            tracemalloc.reset_peak()
            t0 = time.perf_counter()
            cell.fit(X, y, n_classes=C)
            elapsed = time.perf_counter() - t0
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()

            times.append(elapsed)
            peaks.append(peak)
            _print_step(f"  M={M:,}  time={elapsed:.2f}s  peak={peak/1e6:.1f} MB")
            del X, y, cell

        t_exp = _fit_power_law(sizes, times)
        s_exp = _fit_power_law(sizes, peaks)
        _print_step(f"time exponent: {t_exp:.2f}  (expected ~1.0)")
        _print_step(f"space exponent: {s_exp:.2f}  (expected ~1.0)")

        if save_plots:
            _save_plot(sizes, times,
                       "STRESS Cell fit: time vs M (K=256, D=30)",
                       "M", "time (s)", 1.0, t_exp,
                       f"{PLOT_DIR}/stress_time_cell_fit_vs_M.png")
            _save_plot(sizes, [p / 1024 for p in peaks],
                       "STRESS Cell fit: memory vs M (K=256, D=30)",
                       "M", "peak memory (KB)", 1.0, s_exp,
                       f"{PLOT_DIR}/stress_space_cell_fit_vs_M.png")

        assert 0.5 <= t_exp <= 1.5, f"Time: expected ~O(M^1), got O(M^{t_exp:.2f})"
        assert 0.5 <= s_exp <= 1.5, f"Space: expected ~O(M^1), got O(M^{s_exp:.2f})"

    # ── 5. TSP memory wall: K=4096 → 128 MB distance matrix ─────────────

    @_stress
    def test_tsp_memory_wall(self, save_plots):
        """
        Demonstrate the K^2 memory wall on the TSP distance matrix.
        K=4096 → 4096^2 × 8 bytes = 128 MB for one float64 matrix.
        K=8192 would be 512 MB — we stop at 4096 to stay safe.
        This test just verifies we can compute it and measures the time.
        """
        metric = L2Metric()
        sizes = [512, 1024, 2048, 4096]
        times, mems = [], []

        for K in sizes:
            _print_step(f"TSP memory wall K={K} ...")
            rng = np.random.default_rng(42)
            seeds = rng.standard_normal((K, 20)).astype(np.float32)

            tracemalloc.start()
            tracemalloc.reset_peak()
            t0 = time.perf_counter()
            dist_matrix = metric.pairwise(seeds, seeds)
            path = build_tsp_path(dist_matrix)
            elapsed = time.perf_counter() - t0
            _, peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()

            times.append(elapsed)
            mems.append(peak)
            expected_matrix_bytes = K * K * 8  # float64
            _print_step(
                f"  K={K}  time={elapsed:.2f}s  "
                f"peak={peak/1e6:.1f} MB  "
                f"(matrix alone={expected_matrix_bytes/1e6:.1f} MB)"
            )
            del dist_matrix, seeds, path

        t_exp = _fit_power_law(sizes, times)
        s_exp = _fit_power_law(sizes, mems)
        _print_step(f"time exponent: {t_exp:.2f}  space exponent: {s_exp:.2f}")

        if save_plots:
            _save_plot(sizes, times,
                       "STRESS TSP memory wall: time vs K",
                       "K", "time (s)", 2.0, t_exp,
                       f"{PLOT_DIR}/stress_time_tsp_wall.png")
            _save_plot(sizes, [m / 1e6 for m in mems],
                       "STRESS TSP memory wall: peak memory vs K",
                       "K", "peak memory (MB)", 2.0, s_exp,
                       f"{PLOT_DIR}/stress_space_tsp_wall.png")

        assert 1.5 <= t_exp <= 3.5, f"Time: expected ~O(K^2), got O(K^{t_exp:.2f})"
        assert 1.5 <= s_exp <= 2.5, f"Space: expected ~O(K^2), got O(K^{s_exp:.2f})"
