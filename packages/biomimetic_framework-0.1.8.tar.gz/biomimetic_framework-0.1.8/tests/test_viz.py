# tests/test_viz.py
"""
Tests for bmc.viz — architecture summary and diagram generation.

Verifies that visualization works for:
- All model types (Cell, Layer, Network, Classifier, Regressor)
- Small scale (4 zones, expanded) and large scale (20 zones, collapsed)
- Both CLI summary and Graphviz diagram output
"""

import numpy as np
import pytest
from bmc import (
    BMCCell, BMCLayer, BMCNetwork, SequentialBMC,
    BMCClassifier, BMCRegressor,
    TabularObservationSpace,
    L2Metric, CosineMetric,
)
from bmc.viz import summary, diagram
from bmc.viz.arch import extract, NetworkInfo, LayerInfo, CellInfo


# ── fixtures ─────────────────────────────────────────────────────────────────

@pytest.fixture
def small_data():
    rng = np.random.default_rng(42)
    X = rng.normal(0, 1, (200, 16)).astype(np.float32)
    y = (X[:, 0] > 0).astype(np.int32)
    return X, y


# ── arch extraction ──────────────────────────────────────────────────────────

class TestExtract:

    def test_cell(self):
        cell = BMCCell(n_clusters=64)
        info = extract(cell)
        assert len(info.stages) == 1
        assert info.stages[0].K == 64

    def test_fitted_cell(self, small_data):
        X, y = small_data
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        info = extract(cell)
        assert info.stages[0].D == 16
        assert info.stages[0].C == 2

    def test_layer(self):
        obs = TabularObservationSpace(n_features=20, n_zones=5)
        layer = BMCLayer(obs, n_clusters=32)
        info = extract(layer)
        assert isinstance(info.stages[0], LayerInfo)
        assert info.stages[0].n_zones == 5

    def test_network(self, small_data):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=32),
            BMCCell(n_clusters=16),
        ])
        net.fit(X, y, n_classes=2)
        info = extract(net)
        assert len(info.stages) == 2
        assert isinstance(info.stages[0], LayerInfo)
        assert isinstance(info.stages[1], CellInfo)

    def test_classifier_unwraps(self, small_data):
        X, y = small_data
        clf = BMCClassifier(n_clusters=32)
        clf.fit(X, y)
        info = extract(clf)
        # Classifier unwraps to its internal Layer + Cell
        assert len(info.stages) >= 1


# ── CLI summary ──────────────────────────────────────────────────────────────

class TestSummary:

    def test_cell_summary(self):
        cell = BMCCell(n_clusters=64, metric=CosineMetric())
        text = summary(cell, return_text=True)
        assert "BMCCell" in text
        assert "64" in text

    def test_layer_summary_few_zones(self, small_data):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        layer = BMCLayer(obs, n_clusters=16)
        layer.fit(X, y, n_classes=2)
        text = summary(layer, return_text=True)
        assert "BMCLayer" in text
        assert "4 BMCCells" in text

    def test_layer_summary_many_zones(self, small_data):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=16)
        layer = BMCLayer(obs, n_clusters=8)
        layer.fit(X, y, n_classes=2)
        text = summary(layer, return_text=True)
        assert "16" in text

    def test_network_summary(self, small_data):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=32),
            BMCCell(n_clusters=16),
        ])
        net.fit(X, y, n_classes=2)
        text = summary(net, return_text=True)
        assert "BMCLayer" in text
        assert "BMCCell" in text

    def test_no_fitted_status_in_output(self, small_data):
        X, y = small_data
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        text = summary(cell, return_text=True)
        assert "fitted" not in text.lower()
        assert "purity" not in text.lower()

    def test_memory_shown(self, small_data):
        X, y = small_data
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        text = summary(cell, return_text=True)
        assert "Memory" in text or "KB" in text or " B" in text


# ── Graphviz diagram ─────────────────────────────────────────────────────────

class TestDiagram:

    def test_cell_diagram(self, tmp_path):
        cell = BMCCell(n_clusters=64)
        path = diagram(cell, str(tmp_path / "cell"))
        assert path.endswith(".svg")
        content = open(path).read()
        assert "BMCCell" in content

    def test_layer_diagram_few_zones(self, small_data, tmp_path):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        layer = BMCLayer(obs, n_clusters=16)
        layer.fit(X, y, n_classes=2)
        path = diagram(layer, str(tmp_path / "layer_4z"))
        content = open(path).read()
        assert "BMCLayer" in content
        assert "Observation Space" in content

    def test_layer_diagram_many_zones(self, small_data, tmp_path):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=16)
        layer = BMCLayer(obs, n_clusters=8)
        layer.fit(X, y, n_classes=2)
        path = diagram(layer, str(tmp_path / "layer_16z"))
        content = open(path).read()
        assert "\u00d7" in content or "×" in content

    def test_network_diagram(self, small_data, tmp_path):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([
            BMCLayer(obs, n_clusters=32),
            BMCCell(n_clusters=16),
            BMCCell(n_clusters=8),
        ])
        net.fit(X, y, n_classes=2)
        path = diagram(net, str(tmp_path / "network"))
        content = open(path).read()
        assert "BMCLayer" in content
        assert "BMCCell" in content

    def test_classifier_diagram(self, small_data, tmp_path):
        X, y = small_data
        clf = BMCClassifier(n_clusters=32)
        clf.fit(X, y)
        path = diagram(clf, str(tmp_path / "classifier"))
        assert path.endswith(".svg")
        content = open(path).read()
        # Classifier should show as Layer + Cell, not as "BMCClassifier"
        assert "BMCLayer" in content
        assert "BMCCell" in content

    def test_pdf_output(self, tmp_path):
        cell = BMCCell(n_clusters=16)
        path = diagram(cell, str(tmp_path / "cell.pdf"))
        assert path.endswith(".pdf")

    def test_no_color_in_svg(self, tmp_path):
        cell = BMCCell(n_clusters=16)
        path = diagram(cell, str(tmp_path / "cell_bw"))
        content = open(path).read()
        # Should not have colored fills (only black/white)
        for color in ["#e3f2fd", "#e8f5e9", "#fce4ec", "#e8eaf6",
                       "#f3e5f5", "#fff3e0", "#e0f2f1"]:
            assert color not in content

    def test_no_fitted_status_in_diagram(self, small_data, tmp_path):
        X, y = small_data
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        path = diagram(cell, str(tmp_path / "cell_nostatus"))
        content = open(path).read()
        assert "fitted" not in content.lower()
        assert "purity" not in content.lower()

    def test_memory_in_diagram(self, small_data, tmp_path):
        X, y = small_data
        cell = BMCCell(n_clusters=16)
        cell.fit(X, y, n_classes=2)
        path = diagram(cell, str(tmp_path / "cell_mem"))
        content = open(path).read()
        assert "Memory" in content or "KB" in content or " B" in content

    def test_no_M_in_diagram(self, small_data, tmp_path):
        X, y = small_data
        obs = TabularObservationSpace(n_features=16, n_zones=4)
        net = BMCNetwork([BMCLayer(obs, n_clusters=16), BMCCell(n_clusters=8)])
        net.fit(X, y, n_classes=2)
        path = diagram(net, str(tmp_path / "net_noM"))
        content = open(path).read()
        # M should not appear as a dimension label
        assert "(M," not in content
