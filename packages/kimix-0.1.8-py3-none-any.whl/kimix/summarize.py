from string import Template
from kimix.base import print_warning
from kimi_agent_sdk import Session
from kimix.utils import *


async def summarize(temp_file: str | None = None, session: Session | None = None) -> None:
    from pathlib import Path
    from kimix.utils import prompt_async, get_default_session
    from kimix.base import percentage_str, print_success
    from my_tools.common import _create_temp_file_name
    if session is None:
        session = get_default_session()
    if not session or session.status.context_usage <= 1e-5:
        print_warning('Context is empty.')
        return
    if temp_file is None:
        temp_file = _create_temp_file_name()
    try:
        Path(temp_file).unlink(missing_ok=True)
    except:
        pass
    last_usage = session.status.context_usage
    from kimix.base import generate_memory
    lines = []
    def export_func(text: str, is_thinking: bool):
        if not is_thinking:
            lines.append(text) 
    await prompt_async(generate_memory, info_print=False, output_function=export_func)
    await session.clear()
    if lines:
        memory_content = '\n'.join(lines)
        await prompt_async(f'Remember this:\n```\n{memory_content}\n```\nno tool calling, no any action', info_print=False)
    else:
        print_warning('No memory generated.')
        return
    new_usage = session.status.context_usage
    print_success(
        f'Compact from {percentage_str(last_usage)} to {percentage_str(new_usage)}')

summarize_mistakes_prompt = Template('''Summarize these tool call errors concisely:
$errors
Output:
1. **Patterns**: common error types and causes
2. **Root Causes**: why they happen
3. **Fixes**: how to avoid them
4. **Key Takeaways**: brief lessons''')

def summarize_mistake(result_file: str, session = None) -> None:
    errors = get_tool_call_errors(session)
    if not errors:
        print_warning('No errors.')
        return
    from kimix.utils import prompt
    from my_tools.common import _maybe_export_output
    prompt(_maybe_export_output(summarize_mistakes_prompt.substitute(
        errors='\n'.join(str(e) for e in errors),
        result_file=result_file
    )), session=session, info_print=False)
