# -*- coding: utf-8 -*-

from __future__ import unicode_literals

from django.apps import AppConfig
from django.utils.translation import gettext_lazy as _


class RangeFilterConfig(AppConfig):
    name = 'rangefilter_jalali_django6'
    verbose_name = _('Range Filter')
