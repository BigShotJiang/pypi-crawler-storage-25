# -*- coding: utf-8 -*-

from __future__ import unicode_literals


__author__ = 'Haydar Ghasemi'
__version__ = '0.1.0'


default_app_config = 'rangefilter_jalali_django6.apps.RangeFilterConfig'


VERSION = __version__
