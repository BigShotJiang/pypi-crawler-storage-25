import time
from typing import Any, ClassVar, Dict, List

from odibi.context import EngineContext
from odibi.patterns.base import Pattern
from odibi.transformers.merge_transformer import MergeParams, merge
from odibi.utils.logging_context import get_logging_context


class MergePattern(Pattern):
    """
    Merge Pattern: Upsert/Merge logic.

    Configuration Options (via params dict):
        - **target** (str): Target table/path.
        - **keys** (list): Join keys.
        - **strategy** (str): 'upsert', 'append_only', 'delete_match'.
    """

    required_params: ClassVar[List[str]] = ["keys", "target"]
    optional_params: ClassVar[List[str]] = ["strategy"]
    param_aliases: ClassVar[Dict[str, List[str]]] = {"target": ["path"]}

    def validate(self) -> None:
        """Validate merge pattern configuration parameters.

        Ensures that all required parameters are present for merge operations. Checks that:
        - target (or path) is provided (destination table/path for merge)
        - keys are provided (columns to match source and target rows)

        Raises:
            ValueError: If target/path is missing or keys are missing.
        """
        ctx = get_logging_context()

        # Support both 'target' and 'path' for compatibility with merge transformer
        target = self.params.get("target") or self.params.get("path")

        ctx.debug(
            "MergePattern validation starting",
            pattern="MergePattern",
            target=target,
            keys=self.params.get("keys"),
            strategy=self.params.get("strategy"),
        )

        if not target:
            ctx.error(
                "MergePattern validation failed: 'target' or 'path' is required",
                pattern="MergePattern",
                node=self.config.name,
            )
            provided_params = {k: v for k, v in self.params.items() if v is not None}
            raise ValueError(
                f"MergePattern (node '{self.config.name}'): 'target' or 'path' is required. "
                f"Expected: A target table path string. "
                f"Provided params: {list(provided_params.keys())}. "
                f"Fix: Add 'target' or 'path' to your pattern configuration."
            )
        if not self.params.get("keys"):
            ctx.error(
                "MergePattern validation failed: 'keys' is required",
                pattern="MergePattern",
                node=self.config.name,
            )
            source_columns = list(self.source.columns) if hasattr(self.source, "columns") else []
            raise ValueError(
                f"MergePattern (node '{self.config.name}'): 'keys' is required. "
                f"Expected: A list of column names to match source and target rows for merge. "
                f"Available source columns: {source_columns}. "
                f"Fix: Add 'keys' with columns that uniquely identify rows (e.g., keys=['id'])."
            )

        ctx.debug(
            "MergePattern validation passed",
            pattern="MergePattern",
            target=self.params.get("target"),
            keys=self.params.get("keys"),
            strategy=self.params.get("strategy", "upsert"),
        )

    def execute(self, context: EngineContext) -> Any:
        """Execute the merge pattern to upsert data into the target table.

        Performs a merge/upsert operation by delegating to the merge transformer. The merge
        strategy determines the behavior:
        - 'upsert': Insert new rows, update matching rows
        - 'append_only': Insert new rows only, never update
        - 'delete_match': Delete rows matching the keys

        The merge transformer handles loading the target table, comparing keys, and applying
        the specified merge strategy.

        Args:
            context: Engine context containing the source DataFrame and execution environment.

        Returns:
            Source DataFrame (unchanged, as merge writes to target directly).

        Raises:
            Exception: If merge operation fails, target loading fails, or parameters are invalid.
        """
        ctx = get_logging_context()
        start_time = time.time()

        # Support both 'target' and 'path' for compatibility
        target = self.params.get("target") or self.params.get("path")
        keys = self.params.get("keys")
        strategy = self.params.get("strategy", "upsert")

        ctx.debug(
            "Merge pattern starting",
            pattern="MergePattern",
            target=target,
            keys=keys,
            strategy=strategy,
        )

        source_count = None
        try:
            if context.engine_type == "spark":
                source_count = context.df.count()
            else:
                source_count = len(context.df)
            ctx.debug(
                "Merge source data loaded",
                pattern="MergePattern",
                source_rows=source_count,
            )
        except Exception:
            ctx.debug("Merge could not determine source row count", pattern="MergePattern")

        valid_keys = MergeParams.model_fields.keys()
        filtered_params = {k: v for k, v in self.params.items() if k in valid_keys}

        try:
            merge(context, context.df, **filtered_params)
        except Exception as e:
            elapsed_ms = (time.time() - start_time) * 1000
            ctx.error(
                f"Merge pattern execution failed: {e}",
                pattern="MergePattern",
                node=self.config.name,
                error_type=type(e).__name__,
                elapsed_ms=round(elapsed_ms, 2),
                target=target,
                keys=keys,
                strategy=strategy,
            )
            raise

        elapsed_ms = (time.time() - start_time) * 1000

        ctx.info(
            "Merge pattern completed",
            pattern="MergePattern",
            elapsed_ms=round(elapsed_ms, 2),
            source_rows=source_count,
            target=target,
            keys=keys,
            strategy=strategy,
        )

        return context.df
