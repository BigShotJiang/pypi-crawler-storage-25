"""OAuth provider definitions for codrninja."""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests


@dataclass
class OAuthProviderBase:
    name: str
    auth_url: str
    token_url: str
    client_id: str
    scopes: list[str] = field(default_factory=list)
    experimental: bool = False
    extra_auth_params: Dict[str, Any] = field(default_factory=dict)
    extra_token_params: Dict[str, Any] = field(default_factory=dict)

    def build_authorization_url(self, redirect_uri: str, code_challenge: str, state: str) -> str:
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(self.scopes),
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "state": state,
        }
        params.update(self.extra_auth_params)
        return f"{self.auth_url}?{urlencode(params)}"

    def exchange_code(self, code: str, verifier: str, redirect_uri: str) -> Dict[str, Any]:
        payload = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "code": code,
            "redirect_uri": redirect_uri,
            "code_verifier": verifier,
        }
        payload.update(self.extra_token_params)
        response = requests.post(self.token_url, data=payload, timeout=30)
        response.raise_for_status()
        return self.normalize_tokens(response.json())

    def refresh_access_token(self, refresh_token: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload = {
            "grant_type": "refresh_token",
            "client_id": self.client_id,
            "refresh_token": refresh_token,
        }
        payload.update(self.extra_token_params)
        response = requests.post(self.token_url, data=payload, timeout=30)
        response.raise_for_status()
        refreshed = self.normalize_tokens(response.json())
        if metadata:
            refreshed.setdefault("metadata", {}).update(metadata)
        return refreshed

    def normalize_tokens(self, data: Dict[str, Any]) -> Dict[str, Any]:
        expires_in = data.get("expires_in")
        expires_at = None
        if expires_in is not None:
            import time
            expires_at = time.time() + float(expires_in)
        return {
            "access_token": data.get("access_token"),
            "refresh_token": data.get("refresh_token"),
            "expires_at": expires_at,
            "scope": data.get("scope"),
            "token_type": data.get("token_type", "Bearer"),
            "metadata": {
                "experimental": self.experimental,
                "provider": self.name,
            },
        }


class OpenAIOAuth(OAuthProviderBase):
    """OpenAI OAuth using the Codex CLI client ID.

    This uses the same endpoints as the official Codex CLI.
    May not work for third-party tools due to redirect URI restrictions.
    """

    def __init__(self):
        super().__init__(
            name="openai",
            auth_url="https://auth.openai.com/oauth/authorize",
            token_url="https://auth.openai.com/oauth/token",
            client_id="app_EMoamEEZ73f0CkXaXp7hrann",
            scopes=["openid", "profile", "email", "offline_access"],
            extra_auth_params={
                "id_token_add_organizations": "true",
                "codex_cli_simplified_flow": "true",
            },
        )

    def build_authorization_url(self, redirect_uri: str, code_challenge: str, state: str) -> str:
        # OpenAI Codex CLI uses PKCE but without code_challenge_method in the URL
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(self.scopes),
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "state": state,
        }
        params.update(self.extra_auth_params)
        return f"{self.auth_url}?{urlencode(params)}"


class AnthropicOAuth(OAuthProviderBase):
    """Anthropic doesn't have public OAuth. This reads Claude CLI's credentials."""

    def __init__(self):
        super().__init__(
            name="anthropic",
            auth_url="",
            token_url="",
            client_id="",
            scopes=[],
        )

    def _read_claude_cli_credentials(self) -> Optional[Dict[str, Any]]:
        """Read OAuth tokens from Claude CLI's credentials file."""
        creds_path = os.path.expanduser("~/.claude/.credentials.json")
        try:
            import json
            with open(creds_path, 'r') as f:
                data = json.load(f)
            if not data or not isinstance(data, dict):
                return None
            oauth = data.get('claudeAiOauth')
            if not oauth or not isinstance(oauth, dict):
                return None
            access_token = oauth.get('accessToken')
            if not access_token or not isinstance(access_token, str):
                return None
            return {
                'access_token': access_token,
                'refresh_token': oauth.get('refreshToken'),
                'expires_at': oauth.get('expiresAt'),
            }
        except (FileNotFoundError, json.JSONDecodeError, PermissionError):
            return None

    def build_authorization_url(self, redirect_uri: str, code_challenge: str, state: str) -> str:
        raise NotImplementedError(
            "Anthropic does not have a public OAuth flow. "
            "Please login with Claude CLI first (npm install -g @anthropic-ai/claude), "
            "then codrninja will reuse its credentials from ~/.claude/.credentials.json"
        )

    def exchange_code(self, code: str, verifier: str, redirect_uri: str) -> Dict[str, Any]:
        creds = self._read_claude_cli_credentials()
        if not creds:
            raise RuntimeError(
                "No Claude CLI credentials found. Please run 'claude login' first, "
                "then try again. Credentials are read from ~/.claude/.credentials.json"
            )
        return self.normalize_tokens(creds)

    def refresh_access_token(self, refresh_token: str, metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        # Just re-read from file — Claude CLI handles refresh
        creds = self._read_claude_cli_credentials()
        if not creds:
            raise RuntimeError("Claude CLI credentials expired or missing. Please run 'claude login'.")
        refreshed = self.normalize_tokens(creds)
        if metadata:
            refreshed.setdefault("metadata", {}).update(metadata)
        return refreshed


def get_oauth_provider(name: str) -> OAuthProviderBase:
    normalized = name.lower()
    if normalized == "openai":
        return OpenAIOAuth()
    if normalized == "anthropic":
        return AnthropicOAuth()
    raise ValueError(f"Unsupported OAuth provider: {name}")
