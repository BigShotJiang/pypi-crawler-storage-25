# z2a (Work in Progress)

**z2a** is an upcoming enterprise data platform designed to safely harness the power of AI for Google Sheets and Google Drive through a secure, Human-in-the-loop Execution Engine. 

*Currently in active development. Official v0.1.0 release coming soon.*
