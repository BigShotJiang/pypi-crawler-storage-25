"""
setup.py — builds the Mo language package:
  1. Copies cvm/mo_vm.c → mo_lang/mo_vm.c (for lazy standalone binary compilation)
  2. Builds mo_lang/_cvm.so — Python C extension wrapping the C VM
     (eliminates subprocess+JSON overhead; falls back gracefully if build fails)
"""
import os
import shutil
import sys

from setuptools import setup, Extension
from setuptools.command.build_py import build_py as _build_py
from setuptools.command.build_ext import build_ext as _build_ext

ROOT    = os.path.dirname(__file__)
CVM_SRC = os.path.join(ROOT, "cvm", "mo_vm.c")


class build_py(_build_py):
    def run(self):
        super().run()
        dest = os.path.join(self.build_lib, "mo_lang")
        os.makedirs(dest, exist_ok=True)
        # copy C source into the package so _ensure_cvm() can lazy-compile
        # the standalone binary on platforms where the extension didn't build
        shutil.copy2(CVM_SRC, os.path.join(dest, "mo_vm.c"))


class build_ext(_build_ext):
    """Soft-fail: if the C extension can't compile, skip it gracefully."""
    def run(self):
        try:
            super().run()
        except Exception as e:
            print(f"[mo] Warning: C extension build failed ({e}); "
                  "falling back to standalone binary / Python VM.")

    def build_extension(self, ext):
        try:
            super().build_extension(ext)
        except Exception as e:
            print(f"[mo] Warning: could not build {ext.name}: {e}")


cvm_extension = Extension(
    "mo_lang._cvm",
    sources=["mo_lang/_cvm_ext.c"],
    # _cvm_ext.c #includes ../cvm/mo_vm.c — no extra source needed
    define_macros=[("MO_AS_EXTENSION", "1")],
    libraries=([] if sys.platform == "win32" else ["m"]),
    extra_compile_args=(
        ["/O2"] if sys.platform == "win32" else ["-O2", "-std=c99"]
    ),
)

setup(
    ext_modules=[cvm_extension],
    cmdclass={"build_py": build_py, "build_ext": build_ext},
)
