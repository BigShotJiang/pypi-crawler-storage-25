/*
 * mo_vm.c — Mo language C virtual machine.
 * Reads JSON bytecode produced by the Python frontend and executes it.
 *
 * Build:
 *   gcc -O2 -o mo-vm mo_vm.c -lm
 *
 * Usage:
 *   mo-vm <bytecode.json> [args...]
 *
 * The Python frontend compiles .mo source to JSON bytecode and writes it to a
 * temp file, then invokes this binary.  Import statements call back to Python
 * to compile the imported module.
 */

/* When compiled as a Python extension, Python.h sets its own POSIX level. */
#ifndef MO_AS_EXTENSION
#  define _POSIX_C_SOURCE 200809L
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <unistd.h>

/* ══════════════════════════════════════════════════════════════════════════════
 * Arena allocator — bump pointer, no individual frees.  Good enough for batch
 * programs; add a proper GC later if needed.
 * ══════════════════════════════════════════════════════════════════════════════ */

#define ARENA_BLOCK (1 << 20)

typedef struct ArenaBlock {
    char             *base, *ptr, *end;
    struct ArenaBlock *prev;
} ArenaBlock;

static ArenaBlock *g_arena = NULL;

static void arena_new_block(void) {
    ArenaBlock *b = malloc(sizeof(ArenaBlock) + ARENA_BLOCK);
    b->base = (char *)(b + 1);
    b->ptr  = b->base;
    b->end  = b->base + ARENA_BLOCK;
    b->prev = g_arena;
    g_arena = b;
}

static void *arena_alloc(size_t n) {
    n = (n + 7) & ~7;
    if (!g_arena || g_arena->ptr + n > g_arena->end)
        arena_new_block();
    void *p    = g_arena->ptr;
    g_arena->ptr += n;
    return p;
}

static char *arena_strdup(const char *s) {
    size_t n = strlen(s) + 1;
    char  *d = arena_alloc(n);
    memcpy(d, s, n);
    return d;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * Mo value types
 * ══════════════════════════════════════════════════════════════════════════════ */

#define MO_NULL    0
#define MO_BOOL    1
#define MO_NUM     2
#define MO_STR     3
#define MO_LIST    4
#define MO_DICT    5
#define MO_FN      6
#define MO_CLASS   7
#define MO_INST    8
#define MO_ITER    9
#define MO_BUILTIN 10
#define MO_SUPER   11
#define MO_MODULE  12

typedef struct MoVal   MoVal;
typedef struct MoList  MoList;
typedef struct MoDict  MoDict;
typedef struct MoFn    MoFn;
typedef struct MoClass MoClass;
typedef struct MoInst  MoInst;
typedef struct MoIter  MoIter;
typedef struct MoEnv   MoEnv;
typedef struct VM      VM;
typedef struct Frame   Frame;
typedef struct Instr   Instr;

typedef MoVal (*BuiltinFn)(MoVal *args, int argc, VM *vm);

struct MoVal {
    int type;
    union {
        int      b;
        double   n;
        char    *s;
        MoList  *list;
        MoDict  *dict;
        MoFn    *fn;
        MoClass *klass;
        MoInst  *inst;
        MoIter  *iter;
        BuiltinFn builtin;
        struct { MoClass *klass; MoInst *inst; } super;  /* MO_SUPER */
        MoDict  *module;   /* MO_MODULE — same as MO_DICT internally */
    };
};

static MoVal MO_NIL   = { MO_NULL, {0} };
static MoVal MO_TRUE  = { MO_BOOL, {.b = 1} };
static MoVal MO_FALSE = { MO_BOOL, {.b = 0} };

static inline MoVal mo_num(double n) { MoVal v = {MO_NUM,  {.n=n}}; return v; }
static inline MoVal mo_str(char  *s) { MoVal v = {MO_STR,  {.s=s}}; return v; }
static inline MoVal mo_bool(int   b) { return b ? MO_TRUE : MO_FALSE; }

/* ── List ──────────────────────────────────────────────────────────────────── */
struct MoList {
    MoVal *items;
    int    len, cap;
};

static MoList *list_new(void) {
    MoList *l = arena_alloc(sizeof(MoList));
    l->cap   = 8;
    l->items = arena_alloc(l->cap * sizeof(MoVal));
    l->len   = 0;
    return l;
}

static void list_push(MoList *l, MoVal v) {
    if (l->len == l->cap) {
        int     ncap   = l->cap * 2;
        MoVal  *nitems = arena_alloc(ncap * sizeof(MoVal));
        memcpy(nitems, l->items, l->len * sizeof(MoVal));
        l->items = nitems;
        l->cap   = ncap;
    }
    l->items[l->len++] = v;
}

static MoVal mo_list_val(MoList *l) { MoVal v = {MO_LIST, {.list=l}}; return v; }

/* ── Dict ──────────────────────────────────────────────────────────────────── */
#define DICT_INIT_CAP 8

typedef struct DictEntry { char *key; MoVal val; int used; } DictEntry;

struct MoDict {
    DictEntry *entries;
    int        cap, len;
};

static MoDict *dict_new(void) {
    MoDict *d = arena_alloc(sizeof(MoDict));
    d->cap     = DICT_INIT_CAP;
    d->entries = arena_alloc(d->cap * sizeof(DictEntry));
    memset(d->entries, 0, d->cap * sizeof(DictEntry));
    d->len = 0;
    return d;
}

static unsigned int djb2(const char *s) {
    unsigned int h = 5381;
    while (*s) h = ((h << 5) + h) + (unsigned char)*s++;
    return h;
}

static void dict_grow(MoDict *d);

static MoVal *dict_get_ptr(MoDict *d, const char *key) {
    unsigned int h = djb2(key) % (unsigned int)d->cap;
    for (int i = 0; i < d->cap; i++) {
        int idx = (h + i) % d->cap;
        if (!d->entries[idx].used) return NULL;
        if (strcmp(d->entries[idx].key, key) == 0)
            return &d->entries[idx].val;
    }
    return NULL;
}

static int dict_has(MoDict *d, const char *key) { return dict_get_ptr(d,key) != NULL; }

static MoVal dict_get(MoDict *d, const char *key) {
    MoVal *p = dict_get_ptr(d, key);
    return p ? *p : MO_NIL;
}

static void dict_set(MoDict *d, const char *key, MoVal val) {
    if (d->len * 2 >= d->cap) dict_grow(d);
    unsigned int h = djb2(key) % (unsigned int)d->cap;
    for (int i = 0; i < d->cap; i++) {
        int idx = (h + i) % d->cap;
        if (!d->entries[idx].used) {
            d->entries[idx].key  = arena_strdup(key);
            d->entries[idx].val  = val;
            d->entries[idx].used = 1;
            d->len++;
            return;
        }
        if (strcmp(d->entries[idx].key, key) == 0) {
            d->entries[idx].val = val;
            return;
        }
    }
}

static void dict_grow(MoDict *d) {
    int       ocap = d->cap;
    DictEntry *old = d->entries;
    d->cap     *= 2;
    d->entries  = arena_alloc(d->cap * sizeof(DictEntry));
    memset(d->entries, 0, d->cap * sizeof(DictEntry));
    d->len      = 0;
    for (int i = 0; i < ocap; i++)
        if (old[i].used) dict_set(d, old[i].key, old[i].val);
}

static void dict_delete(MoDict *d, const char *key) {
    unsigned int h = djb2(key) % (unsigned int)d->cap;
    for (int i = 0; i < d->cap; i++) {
        int idx = (h + i) % d->cap;
        if (!d->entries[idx].used) return;
        if (strcmp(d->entries[idx].key, key) == 0) {
            d->entries[idx].used = 0;
            d->entries[idx].key  = NULL;
            d->len--;
            return;
        }
    }
}

static MoVal mo_dict_val(MoDict *d) { MoVal v = {MO_DICT, {.dict=d}}; return v; }

/* ── Function ──────────────────────────────────────────────────────────────── */
struct MoFn {
    char   *name;
    char  **params;
    int     nparams;
    Instr  *code;
    int     ncode;
    MoEnv  *closure;
};

static MoVal mo_fn_val(MoFn *fn) { MoVal v = {MO_FN, {.fn=fn}}; return v; }

/* ── Class / Instance ──────────────────────────────────────────────────────── */
struct MoClass {
    char    *name;
    MoDict  *methods;  /* name → MoVal (MO_FN or MO_BUILTIN) */
    MoClass *parent;
};

struct MoInst {
    MoClass *klass;
    MoDict  *fields;
};

static MoVal mo_class_val(MoClass *k) { MoVal v = {MO_CLASS, {.klass=k}}; return v; }
static MoVal mo_inst_val(MoInst  *i) { MoVal v = {MO_INST,  {.inst=i}};  return v; }

/* ── Iterator ──────────────────────────────────────────────────────────────── */
struct MoIter {
    int kind;   /* 0=list, 1=dict-keys, 2=string */
    int pos;
    union {
        MoList  *list;
        MoDict  *dict;
        char    *str;
    };
    int dict_scan;  /* current scan position for dict */
};

/* ═══════════════════════════════════════════════════════════════════════════
 * Opcodes  (must match Python compiler.py Op enum order)
 * ═══════════════════════════════════════════════════════════════════════════ */

#define OP_LOAD_CONST    1
#define OP_LOAD_NAME     2
#define OP_STORE_NAME    3
#define OP_DEFINE_NAME   4
#define OP_BINARY_OP     5
#define OP_UNARY_OP      6
#define OP_JUMP          7
#define OP_JUMP_IF_FALSE 8
#define OP_POP           9
#define OP_RETURN        10
#define OP_CALL          11
#define OP_MAKE_LIST     12
#define OP_MAKE_DICT     13
#define OP_NOP           0
#define OP_INDEX_GET     14
#define OP_INDEX_SET     15
#define OP_GET_ATTR      16
#define OP_SET_ATTR      17
#define OP_METHOD_CALL   18
#define OP_MAKE_FUNCTION 19
#define OP_MAKE_CLASS    20
#define OP_THROW         21
#define OP_SETUP_TRY     22
#define OP_END_TRY       23
#define OP_IMPORT        24
#define OP_MAKE_ITER     25
#define OP_FOR_ITER           26
#define OP_LINE               27
#define OP_DUP                28
#define OP_MAKE_ASYNC_FUNCTION 29   /* treated like MAKE_FUNCTION */
#define OP_ASYNC_RETURN       30    /* treated like RETURN */
#define OP_AWAIT              31    /* pass value through */
#define OP_DESTRUCTURE_LIST   32
#define OP_DESTRUCTURE_DICT   33
/* match/case markers — compiled away, treated as NOP */
#define OP_MATCH_START        34
#define OP_MATCH_CASE         35
#define OP_MATCH_BIND         36
#define OP_MATCH_END          37

/* ── Instruction ────────────────────────────────────────────────────────────*/

typedef struct ClassDef {
    char    *name;
    char    *parent;
    char   **method_names;
    MoFn   **methods;
    int      nmethod;
} ClassDef;

struct Instr {
    int   op;
    /* Only one field used per instruction */
    MoVal val;           /* LOAD_CONST */
    char *str;           /* LOAD_NAME / STORE_NAME / DEFINE_NAME / BINARY_OP /
                            UNARY_OP / GET_ATTR / SET_ATTR */
    int   ival;          /* JUMP / JUMP_IF_FALSE / CALL / MAKE_LIST /
                            MAKE_DICT / FOR_ITER / LINE */
    MoFn *fn;            /* MAKE_FUNCTION / MAKE_ASYNC_FUNCTION */
    ClassDef *cls;       /* MAKE_CLASS */
    char *method;        /* METHOD_CALL method name */
    int   method_argc;   /* METHOD_CALL argc */
    int   catch_ip;      /* SETUP_TRY */
    char *err_var;       /* SETUP_TRY */
    char *import_path;   /* IMPORT */
    char *import_alias;  /* IMPORT */
    /* DESTRUCTURE_LIST */
    char **destruct_vars;
    int    destruct_n;
    /* DESTRUCTURE_DICT */
    char **destruct_keys;    /* parallel array with destruct_vars for dict */
};

/* ═══════════════════════════════════════════════════════════════════════════
 * Environment
 * ═══════════════════════════════════════════════════════════════════════════ */

struct MoEnv {
    MoDict *vars;
    MoEnv  *parent;
};

static MoEnv *env_new(MoEnv *parent);

static MoVal env_get(MoEnv *e, const char *name);
static void  env_set(MoEnv *e, const char *name, MoVal val);
static void  env_define(MoEnv *e, const char *name, MoVal val);

static void  env_define(MoEnv *e, const char *name, MoVal val) {
    dict_set(e->vars, name, val);
}

static MoVal env_get(MoEnv *e, const char *name) {
    for (MoEnv *cur = e; cur; cur = cur->parent) {
        MoVal *p = dict_get_ptr(cur->vars, name);
        if (p) return *p;
    }
    fprintf(stderr, "[Runtime Error] Undefined variable '%s'\n", name);
    exit(1);
}

static int env_set_existing(MoEnv *e, const char *name, MoVal val) {
    for (MoEnv *cur = e; cur; cur = cur->parent) {
        MoVal *p = dict_get_ptr(cur->vars, name);
        if (p) { *p = val; return 1; }
    }
    return 0;
}

static void env_set(MoEnv *e, const char *name, MoVal val) {
    if (!env_set_existing(e, name, val)) {
        fprintf(stderr, "[Runtime Error] Undefined variable '%s' (use 'let' to declare)\n", name);
        exit(1);
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * Global error state (for Mo throw/catch)
 * ═══════════════════════════════════════════════════════════════════════════ */

static int    g_thrown = 0;
static MoVal  g_exc_val;
static char   g_exc_msg[4096];

static void mo_throw(MoVal v) {
    g_thrown  = 1;
    g_exc_val = v;
}

static void mo_error(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(g_exc_msg, sizeof(g_exc_msg), fmt, ap);
    va_end(ap);
    MoVal v = {MO_STR, {.s = g_exc_msg}};
    mo_throw(v);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * Value utilities
 * ═══════════════════════════════════════════════════════════════════════════ */

static int mo_truthy(MoVal v) {
    switch (v.type) {
        case MO_NULL:  return 0;
        case MO_BOOL:  return v.b;
        case MO_NUM:   return v.n != 0.0;
        case MO_STR:   return v.s[0] != '\0';
        case MO_LIST:  return v.list->len > 0;
        case MO_DICT:  return v.dict->len > 0;
        default:       return 1;
    }
}

static int mo_equal(MoVal a, MoVal b) {
    if (a.type != b.type) return 0;
    switch (a.type) {
        case MO_NULL:  return 1;
        case MO_BOOL:  return a.b == b.b;
        case MO_NUM:   return a.n == b.n;
        case MO_STR:   return strcmp(a.s, b.s) == 0;
        case MO_LIST: {
            if (a.list->len != b.list->len) return 0;
            for (int i = 0; i < a.list->len; i++)
                if (!mo_equal(a.list->items[i], b.list->items[i])) return 0;
            return 1;
        }
        default: return a.fn == b.fn; /* pointer equality for objects */
    }
}

/* display value as Mo string */
static char *mo_display(MoVal v, char *buf, int bufsz);

static void list_display(MoList *l, char *buf, int bufsz) {
    int pos = 0;
    buf[pos++] = '[';
    for (int i = 0; i < l->len && pos < bufsz - 4; i++) {
        if (i) { buf[pos++] = ','; buf[pos++] = ' '; }
        char tmp[256];
        mo_display(l->items[i], tmp, sizeof(tmp));
        int tl = (int)strlen(tmp);
        if (pos + tl >= bufsz - 4) { strcpy(buf + pos, "..."); pos += 3; break; }
        memcpy(buf + pos, tmp, tl); pos += tl;
    }
    buf[pos++] = ']'; buf[pos] = '\0';
}

static void dict_display(MoDict *d, char *buf, int bufsz) {
    int pos = 0, first = 1;
    buf[pos++] = '{';
    for (int i = 0; i < d->cap && pos < bufsz - 8; i++) {
        if (!d->entries[i].used) continue;
        if (!first) { buf[pos++] = ','; buf[pos++] = ' '; }
        first = 0;
        /* key */
        int kl = (int)strlen(d->entries[i].key);
        buf[pos++] = '"';
        if (pos + kl < bufsz - 8) { memcpy(buf + pos, d->entries[i].key, kl); pos += kl; }
        buf[pos++] = '"'; buf[pos++] = ':'; buf[pos++] = ' ';
        /* val */
        char tmp[256];
        mo_display(d->entries[i].val, tmp, sizeof(tmp));
        int tl = (int)strlen(tmp);
        if (pos + tl >= bufsz - 4) { strcpy(buf + pos, "..."); pos += 3; break; }
        memcpy(buf + pos, tmp, tl); pos += tl;
    }
    buf[pos++] = '}'; buf[pos] = '\0';
}

static char *mo_display(MoVal v, char *buf, int bufsz) {
    switch (v.type) {
        case MO_NULL:  snprintf(buf, bufsz, "null");  break;
        case MO_BOOL:  snprintf(buf, bufsz, "%s", v.b ? "true" : "false"); break;
        case MO_NUM: {
            double n = v.n;
            if (n == (long long)n && n > -1e15 && n < 1e15)
                snprintf(buf, bufsz, "%lld", (long long)n);
            else
                snprintf(buf, bufsz, "%.15g", n);
            break;
        }
        case MO_STR:   snprintf(buf, bufsz, "%s", v.s); break;
        case MO_LIST:  list_display(v.list, buf, bufsz); break;
        case MO_DICT:
        case MO_MODULE: dict_display(v.dict, buf, bufsz); break;
        case MO_FN:    snprintf(buf, bufsz, "<fn %s>", v.fn->name); break;
        case MO_CLASS: snprintf(buf, bufsz, "<class %s>", v.klass->name); break;
        case MO_INST:  snprintf(buf, bufsz, "<instance of %s>", v.inst->klass->name); break;
        case MO_BUILTIN: snprintf(buf, bufsz, "<builtin>"); break;
        default:       snprintf(buf, bufsz, "<?>"); break;
    }
    return buf;
}

static const char *mo_type_name(MoVal v) {
    switch (v.type) {
        case MO_NULL:    return "null";
        case MO_BOOL:    return "bool";
        case MO_NUM:     return "number";
        case MO_STR:     return "string";
        case MO_LIST:    return "list";
        case MO_DICT:
        case MO_MODULE:  return "dict";
        case MO_FN:      return "function";
        case MO_CLASS:   return "class";
        case MO_INST:    return "instance";
        case MO_BUILTIN: return "builtin";
        default:         return "unknown";
    }
}

/* ═══════════════════════════════════════════════════════════════════════════
 * Arithmetic / binary ops
 * ═══════════════════════════════════════════════════════════════════════════ */

/* string × n — optimized with memcpy instead of strcat */
static char *str_repeat(const char *s, int n) {
    size_t len = strlen(s);
    char *r = arena_alloc(len * n + 1);
    char *w = r;
    for (int i = 0; i < n; i++) {
        memcpy(w, s, len);
        w += len;
    }
    *w = '\0';
    return r;
}

static MoVal mo_binop(const char *op, MoVal l, MoVal r) {
    /* Fast path: single char op comparison for common ops */
    char first_char = op[0];

    /* string concatenation */
    if (first_char == '+' && l.type == MO_STR && r.type == MO_STR) {
        size_t ln = strlen(l.s), rn = strlen(r.s);
        char *s = arena_alloc(ln + rn + 1);
        memcpy(s, l.s, ln);
        memcpy(s + ln, r.s, rn + 1);
        return mo_str(s);
    }
    /* string × number */
    if (first_char == '*' && l.type == MO_STR && r.type == MO_NUM)
        return mo_str(str_repeat(l.s, (int)r.n));
    if (first_char == '*' && r.type == MO_STR && l.type == MO_NUM)
        return mo_str(str_repeat(r.s, (int)l.n));

    /* list + list */
    if (first_char == '+' && l.type == MO_LIST && r.type == MO_LIST) {
        MoList *nl = list_new();
        for (int i = 0; i < l.list->len; i++) list_push(nl, l.list->items[i]);
        for (int i = 0; i < r.list->len; i++) list_push(nl, r.list->items[i]);
        return mo_list_val(nl);
    }

    /* numeric */
    if (l.type != MO_NUM || r.type != MO_NUM) {
        if (first_char == '=' && op[1] == '=') return mo_bool(mo_equal(l, r));
        if (first_char == '!' && op[1] == '=') return mo_bool(!mo_equal(l, r));
        mo_error("Operator '%s' not supported between %s and %s", op,
                 mo_type_name(l), mo_type_name(r));
        return MO_NIL;
    }
    double a = l.n, b = r.n;
    if (first_char == '+')  return mo_num(a + b);
    if (first_char == '-')  return mo_num(a - b);
    if (first_char == '*')  return mo_num(a * b);
    if (first_char == '/') {
        if (b == 0.0) { mo_error("Division by zero"); return MO_NIL; }
        return mo_num(a / b);
    }
    if (op[0] == '/' && op[1] == '/') {
        if (b == 0.0) { mo_error("Division by zero"); return MO_NIL; }
        return mo_num(floor(a / b));
    }
    if (first_char == '%') {
        if (b == 0.0) { mo_error("Modulo by zero"); return MO_NIL; }
        return mo_num(fmod(a, b));
    }
    if (op[0] == '*' && op[1] == '*') return mo_num(pow(a, b));
    if (first_char == '=' && op[1] == '=') return mo_bool(a == b);
    if (first_char == '!' && op[1] == '=') return mo_bool(a != b);
    if (first_char == '<') {
        if (op[1] == '=') return mo_bool(a <= b);
        return mo_bool(a <  b);
    }
    if (first_char == '>') {
        if (op[1] == '=') return mo_bool(a >= b);
        return mo_bool(a >  b);
    }
    mo_error("Unknown binary operator '%s'", op);
    return MO_NIL;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * String methods
 * ═══════════════════════════════════════════════════════════════════════════ */

static MoVal str_method(const char *s, const char *method, MoVal *args, int argc) {
    if (strcmp(method, "upper") == 0) {
        char *r = arena_strdup(s);
        for (char *p = r; *p; p++) *p = (*p >= 'a' && *p <= 'z') ? *p - 32 : *p;
        return mo_str(r);
    }
    if (strcmp(method, "lower") == 0) {
        char *r = arena_strdup(s);
        for (char *p = r; *p; p++) *p = (*p >= 'A' && *p <= 'Z') ? *p + 32 : *p;
        return mo_str(r);
    }
    if (strcmp(method, "trim") == 0) {
        const char *start = s;
        while (*start == ' ' || *start == '\t' || *start == '\n' || *start == '\r') start++;
        const char *end = s + strlen(s) - 1;
        while (end > start && (*end == ' ' || *end == '\t' || *end == '\n' || *end == '\r')) end--;
        int n = (int)(end - start + 1);
        char *r = arena_alloc(n + 1);
        memcpy(r, start, n); r[n] = '\0';
        return mo_str(r);
    }
    if (strcmp(method, "len") == 0)
        return mo_num((double)strlen(s));
    if (strcmp(method, "contains") == 0 && argc == 1 && args[0].type == MO_STR)
        return mo_bool(strstr(s, args[0].s) != NULL);
    if (strcmp(method, "starts_with") == 0 && argc == 1 && args[0].type == MO_STR) {
        size_t n = strlen(args[0].s);
        return mo_bool(strncmp(s, args[0].s, n) == 0);
    }
    if (strcmp(method, "ends_with") == 0 && argc == 1 && args[0].type == MO_STR) {
        size_t sl = strlen(s), nl = strlen(args[0].s);
        return mo_bool(sl >= nl && strcmp(s + sl - nl, args[0].s) == 0);
    }
    if (strcmp(method, "replace") == 0 && argc == 2 && args[0].type == MO_STR && args[1].type == MO_STR) {
        const char *old = args[0].s, *rep = args[1].s;
        size_t olen = strlen(old), rlen = strlen(rep), slen = strlen(s);
        if (olen == 0) return mo_str(arena_strdup(s));
        /* count occurrences */
        int cnt = 0;
        const char *p = s;
        while ((p = strstr(p, old))) { cnt++; p += olen; }
        size_t newlen = slen + cnt * (rlen - olen);
        char *r = arena_alloc(newlen + 1);
        char *w = r;
        p = s;
        while (*p) {
            if (strncmp(p, old, olen) == 0) { memcpy(w, rep, rlen); w += rlen; p += olen; }
            else *w++ = *p++;
        }
        *w = '\0';
        return mo_str(r);
    }
    if (strcmp(method, "split") == 0 && argc == 1 && args[0].type == MO_STR) {
        const char *sep = args[0].s;
        size_t seplen = strlen(sep);
        MoList *lst = list_new();
        const char *p = s;
        if (seplen == 0) {
            while (*p) {
                char c[2] = {*p++, '\0'};
                list_push(lst, mo_str(arena_strdup(c)));
            }
        } else {
            while (1) {
                const char *f = strstr(p, sep);
                if (!f) { list_push(lst, mo_str(arena_strdup(p))); break; }
                int n = (int)(f - p);
                char *piece = arena_alloc(n + 1);
                memcpy(piece, p, n); piece[n] = '\0';
                list_push(lst, mo_str(piece));
                p = f + seplen;
            }
        }
        return mo_list_val(lst);
    }
    if (strcmp(method, "index") == 0 && argc == 1 && args[0].type == MO_STR) {
        const char *f = strstr(s, args[0].s);
        return f ? mo_num((double)(f - s)) : mo_num(-1);
    }
    mo_error("String has no method '%s'", method);
    return MO_NIL;
}

/* ── List methods ────────────────────────────────────────────────────────── */

static MoVal list_method(MoList *l, const char *method, MoVal *args, int argc) {
    if (strcmp(method, "len") == 0) return mo_num(l->len);
    if (strcmp(method, "push") == 0 && argc == 1) { list_push(l, args[0]); return MO_NIL; }
    if (strcmp(method, "pop") == 0) {
        if (l->len == 0) { mo_error("pop from empty list"); return MO_NIL; }
        return l->items[--l->len];
    }
    if (strcmp(method, "reverse") == 0) {
        for (int i = 0, j = l->len - 1; i < j; i++, j--) {
            MoVal t = l->items[i]; l->items[i] = l->items[j]; l->items[j] = t;
        }
        return MO_NIL;
    }
    if (strcmp(method, "contains") == 0 && argc == 1) {
        for (int i = 0; i < l->len; i++)
            if (mo_equal(l->items[i], args[0])) return MO_TRUE;
        return MO_FALSE;
    }
    if (strcmp(method, "join") == 0 && argc == 1 && args[0].type == MO_STR) {
        const char *sep = args[0].s;
        size_t sep_len = strlen(sep);
        size_t total = 0;
        char items_tmp[256][64];
        int items_len[256];
        int count = l->len < 256 ? l->len : 256;
        for (int i = 0; i < count; i++) {
            mo_display(l->items[i], items_tmp[i], sizeof(items_tmp[i]));
            items_len[i] = (int)strlen(items_tmp[i]);
            total += items_len[i] + (i && sep_len ? sep_len : 0);
        }
        char *r = arena_alloc(total + 1);
        char *w = r;
        for (int i = 0; i < count; i++) {
            if (i && sep_len) { memcpy(w, sep, sep_len); w += sep_len; }
            memcpy(w, items_tmp[i], items_len[i]);
            w += items_len[i];
        }
        *w = '\0';
        return mo_str(r);
    }
    mo_error("List has no method '%s'", method);
    return MO_NIL;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * VM struct
 * ═══════════════════════════════════════════════════════════════════════════ */

#define STACK_MAX  4096
#define TRY_MAX    64

typedef struct {
    int  catch_ip;
    char *err_var;
    int   stack_depth;
} TryEntry;

struct Frame {
    Instr    *code;
    int       ncode;
    int       ip;
    MoEnv    *env;
    MoVal     stack[STACK_MAX];
    int       sp;
    TryEntry  try_stack[TRY_MAX];
    int       try_top;
    MoVal     retval;
};

/* Optional import callback — set by Python extension, NULL in standalone mode.
 * Called with (mo_path, base_dir), must return a malloc'd JSON string (caller
 * frees) or NULL on error. */
typedef char *(*MoImportCb)(const char *mo_path, const char *base_dir);
static MoImportCb g_import_cb = NULL;

struct VM {
    MoEnv *globals;
    char   base_dir[4096];
    int    current_line;
    int    trace;
};

/* forward declarations */
static MoVal vm_call(VM *vm, MoVal fn, MoVal *args, int argc);
static MoVal vm_run_frame(VM *vm, Frame *f);
static void  vm_register_builtins(VM *vm);
static MoVal vm_import(VM *vm, const char *path, const char *alias);
static MoVal *icache_lookup(MoClass *k, const char *name);
static void  icache_store(MoClass *k, const char *name, MoVal *m);
static Frame *frame_pool_alloc(void);
static MoEnv *env_pool_alloc(void);
static MoList *list_pool_alloc(void);

/* ── Stack helpers ────────────────────────────────────────────────────────── */
static inline void  push(Frame *f, MoVal v) { f->stack[f->sp++] = v; }
static inline MoVal pop (Frame *f)           { return f->stack[--f->sp]; }
static inline MoVal peek(Frame *f)           { return f->stack[f->sp - 1]; }

/* ── Method lookup in class chain ────────────────────────────────────────── */
static MoVal *class_lookup(MoClass *k, const char *name) {
    MoVal *cached = icache_lookup(k, name);
    if (cached) return cached;
    while (k) {
        MoVal *p = dict_get_ptr(k->methods, name);
        if (p) { icache_store(k, name, p); return p; }
        k = k->parent;
    }
    return NULL;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * Object Pools — reduce allocation overhead for hot objects
 * ══════════════════════════════════════════════════════════════════════════════ */

#define POOL_SIZE 256

typedef struct FramePool {
    Frame pool[POOL_SIZE];
    int   used;
    struct FramePool *next;
} FramePool;

typedef struct EnvPool {
    MoEnv pool[POOL_SIZE];
    int   used;
    struct EnvPool *next;
} EnvPool;

typedef struct ListPool {
    MoList pool[POOL_SIZE];
    int    used;
    struct ListPool *next;
} ListPool;

static FramePool *g_frame_pool = NULL;
static EnvPool   *g_env_pool   = NULL;
static ListPool  *g_list_pool  = NULL;

static Frame *frame_pool_alloc(void) {
    if (!g_frame_pool || g_frame_pool->used >= POOL_SIZE) {
        FramePool *np = calloc(1, sizeof(FramePool));
        np->next = g_frame_pool;
        g_frame_pool = np;
    }
    Frame *f = &g_frame_pool->pool[g_frame_pool->used++];
    memset(f, 0, sizeof(Frame));
    return f;
}

static MoEnv *env_pool_alloc(void) {
    if (!g_env_pool || g_env_pool->used >= POOL_SIZE) {
        EnvPool *np = calloc(1, sizeof(EnvPool));
        np->next = g_env_pool;
        g_env_pool = np;
    }
    MoEnv *e = &g_env_pool->pool[g_env_pool->used++];
    e->vars = dict_new();
    e->parent = NULL;
    return e;
}

static MoList *list_pool_alloc(void) {
    if (!g_list_pool || g_list_pool->used >= POOL_SIZE) {
        ListPool *np = calloc(1, sizeof(ListPool));
        np->next = g_list_pool;
        g_list_pool = np;
    }
    MoList *l = &g_list_pool->pool[g_list_pool->used++];
    l->cap = 8;
    l->items = arena_alloc(l->cap * sizeof(MoVal));
    l->len = 0;
    return l;
}

static MoEnv *env_new(MoEnv *parent) {
    MoEnv *e  = env_pool_alloc();
    e->parent = parent;
    return e;
}

/* ══════════════════════════════════════════════════════════════════════════════
 * Inline Cache for method/attribute lookups
 * ══════════════════════════════════════════════════════════════════════════════ */

#define ICACHE_SIZE 64

typedef struct {
    unsigned int hash;
    MoClass     *klass;
    const char  *name;
    MoVal       *method;
    int          hits;
} MethodCacheEntry;

typedef struct {
    unsigned int hash;
    MoClass     *klass;
    const char  *name;
    MoVal       *field;
    int          hits;
} AttrCacheEntry;

static MethodCacheEntry g_method_cache[ICACHE_SIZE];
static AttrCacheEntry  g_attr_cache[ICACHE_SIZE];

static inline unsigned int cache_hash(MoClass *k, const char *name) {
    unsigned int h = djb2(name);
    h = (h << 5) + h + (unsigned int)(uintptr_t)k;
    return h % ICACHE_SIZE;
}

static MoVal *icache_lookup(MoClass *k, const char *name) {
    unsigned int h = cache_hash(k, name);
    MethodCacheEntry *e = &g_method_cache[h];
    if (e->klass == k && e->name == name && e->method) {
        e->hits++;
        return e->method;
    }
    return NULL;
}

static void icache_store(MoClass *k, const char *name, MoVal *m) {
    unsigned int h = cache_hash(k, name);
    MethodCacheEntry *e = &g_method_cache[h];
    e->klass = k;
    e->name = name;
    e->method = m;
}

static MoVal *icache_attr_lookup(MoClass *k, const char *name) {
    unsigned int h = cache_hash(k, name);
    AttrCacheEntry *e = &g_attr_cache[h];
    if (e->klass == k && e->name == name && e->field) {
        e->hits++;
        return e->field;
    }
    return NULL;
}

static void icache_attr_store(MoClass *k, const char *name, MoVal *f) {
    unsigned int h = cache_hash(k, name);
    AttrCacheEntry *e = &g_attr_cache[h];
    e->klass = k;
    e->name = name;
    e->field = f;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * Built-in functions
 * ═══════════════════════════════════════════════════════════════════════════ */

static MoVal bi_print(MoVal *args, int argc, VM *vm) {
    for (int i = 0; i < argc; i++) {
        if (i) putchar(' ');
        char buf[4096];
        mo_display(args[i], buf, sizeof(buf));
        fputs(buf, stdout);
    }
    putchar('\n');
    return MO_NIL;
}

static MoVal bi_len(MoVal *args, int argc, VM *vm) {
    if (argc != 1) { mo_error("len() takes 1 argument"); return MO_NIL; }
    MoVal v = args[0];
    if (v.type == MO_STR)                return mo_num(strlen(v.s));
    if (v.type == MO_LIST)               return mo_num(v.list->len);
    if (v.type == MO_DICT || v.type == MO_MODULE) return mo_num(v.dict->len);
    mo_error("len() requires string, list, or dict"); return MO_NIL;
}

static MoVal bi_str(MoVal *args, int argc, VM *vm) {
    if (argc != 1) { mo_error("str() takes 1 argument"); return MO_NIL; }
    char buf[4096]; mo_display(args[0], buf, sizeof(buf));
    return mo_str(arena_strdup(buf));
}

static MoVal bi_num(MoVal *args, int argc, VM *vm) {
    if (argc != 1) { mo_error("num() takes 1 argument"); return MO_NIL; }
    if (args[0].type == MO_NUM)  return args[0];
    if (args[0].type == MO_STR)  { double n = atof(args[0].s); return mo_num(n); }
    if (args[0].type == MO_BOOL) return mo_num(args[0].b);
    mo_error("Cannot convert to number"); return MO_NIL;
}

static MoVal bi_type(MoVal *args, int argc, VM *vm) {
    if (argc != 1) { mo_error("type() takes 1 argument"); return MO_NIL; }
    return mo_str((char *)mo_type_name(args[0]));
}

static MoVal bi_push(MoVal *args, int argc, VM *vm) {
    if (argc != 2 || args[0].type != MO_LIST) { mo_error("push(list, val)"); return MO_NIL; }
    list_push(args[0].list, args[1]); return MO_NIL;
}

static MoVal bi_pop(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_LIST) { mo_error("pop(list)"); return MO_NIL; }
    if (args[0].list->len == 0) { mo_error("pop from empty list"); return MO_NIL; }
    return args[0].list->items[--args[0].list->len];
}

static MoVal bi_keys(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || (args[0].type != MO_DICT && args[0].type != MO_MODULE)) {
        mo_error("keys() requires a dict"); return MO_NIL;
    }
    MoDict *d  = args[0].dict;
    MoList *l  = list_new();
    for (int i = 0; i < d->cap; i++)
        if (d->entries[i].used) list_push(l, mo_str(d->entries[i].key));
    return mo_list_val(l);
}

static MoVal bi_has(MoVal *args, int argc, VM *vm) {
    if (argc != 2 || (args[0].type != MO_DICT && args[0].type != MO_MODULE) || args[1].type != MO_STR)
        { mo_error("has(dict, key)"); return MO_NIL; }
    return mo_bool(dict_has(args[0].dict, args[1].s));
}

static MoVal bi_delete(MoVal *args, int argc, VM *vm) {
    if (argc != 2 || (args[0].type != MO_DICT && args[0].type != MO_MODULE) || args[1].type != MO_STR)
        { mo_error("delete(dict, key)"); return MO_NIL; }
    dict_delete(args[0].dict, args[1].s); return MO_NIL;
}

static MoVal bi_range(MoVal *args, int argc, VM *vm) {
    if (argc < 1 || argc > 3) { mo_error("range(stop) or range(start,stop[,step])"); return MO_NIL; }
    double start = 0, stop, step = 1;
    if (argc == 1) { stop = args[0].n; }
    else           { start = args[0].n; stop = args[1].n; if (argc == 3) step = args[2].n; }
    MoList *l = list_new();
    if (step > 0) for (double i = start; i < stop; i += step) list_push(l, mo_num(i));
    else          for (double i = start; i > stop; i += step) list_push(l, mo_num(i));
    return mo_list_val(l);
}

static MoVal bi_floor(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_NUM) { mo_error("floor(n)"); return MO_NIL; }
    return mo_num(floor(args[0].n));
}

static MoVal bi_ceil(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_NUM) { mo_error("ceil(n)"); return MO_NIL; }
    return mo_num(ceil(args[0].n));
}

static MoVal bi_round(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_NUM) { mo_error("round(n)"); return MO_NIL; }
    return mo_num(round(args[0].n));
}

static MoVal bi_abs(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_NUM) { mo_error("abs(n)"); return MO_NIL; }
    return mo_num(fabs(args[0].n));
}

static MoVal bi_input(MoVal *args, int argc, VM *vm) {
    if (argc > 0) {
        char buf[256]; mo_display(args[0], buf, sizeof(buf));
        fputs(buf, stdout); fflush(stdout);
    }
    char line[4096];
    if (!fgets(line, sizeof(line), stdin)) return MO_NIL;
    int n = (int)strlen(line);
    if (n > 0 && line[n-1] == '\n') line[n-1] = '\0';
    return mo_str(arena_strdup(line));
}

static MoVal bi_sqrt(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_NUM) { mo_error("sqrt(n)"); return MO_NIL; }
    return mo_num(sqrt(args[0].n));
}

static MoVal bi_pow(MoVal *args, int argc, VM *vm) {
    if (argc != 2) { mo_error("pow(a, b)"); return MO_NIL; }
    return mo_num(pow(args[0].n, args[1].n));
}

static MoVal bi_debug(MoVal *args, int argc, VM *vm) {
    fprintf(stderr, "[debug]");
    for (int i = 0; i < argc; i++) {
        char buf[512]; mo_display(args[i], buf, sizeof(buf));
        fprintf(stderr, " %s (%s)", buf, mo_type_name(args[i]));
    }
    fprintf(stderr, "\n");
    return argc == 1 ? args[0] : MO_NIL;
}

/* ── __json_parse__ / __json_stringify__ ── lightweight wrappers ─────────── */
/* (full JSON handled via Python call; here we do minimal subset for stdlib)  */
static MoVal bi_json_parse(MoVal *args, int argc, VM *vm);  /* forward */
static MoVal bi_json_stringify(MoVal *args, int argc, VM *vm);

/* ── __time_now__ etc. ───────────────────────────────────────────────────── */
static MoVal bi_time_now(MoVal *args, int argc, VM *vm) {
    return mo_num((double)time(NULL));
}
static MoVal bi_time_ms(MoVal *args, int argc, VM *vm) {
    struct timespec ts; clock_gettime(CLOCK_REALTIME, &ts);
    return mo_num(ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6);
}
static MoVal bi_time_sleep(MoVal *args, int argc, VM *vm) {
    if (argc != 1) { mo_error("sleep(seconds)"); return MO_NIL; }
    struct timespec ts;
    ts.tv_sec  = (time_t)args[0].n;
    ts.tv_nsec = (long)((args[0].n - ts.tv_sec) * 1e9);
    nanosleep(&ts, NULL);
    return MO_NIL;
}

/* ── __random_int__ / __random_float__ / __random_pick__ ─────────────────── */
static MoVal bi_random_int(MoVal *args, int argc, VM *vm) {
    if (argc != 2) { mo_error("random_int(min, max)"); return MO_NIL; }
    int lo = (int)args[0].n, hi = (int)args[1].n;
    return mo_num(lo + rand() % (hi - lo + 1));
}
static MoVal bi_random_float(MoVal *args, int argc, VM *vm) {
    return mo_num(rand() / (double)RAND_MAX);
}
static MoVal bi_random_pick(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_LIST || args[0].list->len == 0) {
        mo_error("random_pick(list)"); return MO_NIL;
    }
    int idx = rand() % args[0].list->len;
    return args[0].list->items[idx];
}

/* ── __os_* ── ───────────────────────────────────────────────────────────── */
static MoVal bi_os_name(MoVal *a, int n, VM *vm) {
#if defined(_WIN32)
    return mo_str("windows");
#elif defined(__APPLE__)
    return mo_str("darwin");
#else
    return mo_str("linux");
#endif
}
static MoVal bi_os_cwd(MoVal *a, int n, VM *vm) {
    char buf[4096]; getcwd(buf, sizeof(buf)); return mo_str(arena_strdup(buf));
}
static MoVal bi_os_home(MoVal *a, int n, VM *vm) {
    const char *h = getenv("HOME"); return mo_str(h ? arena_strdup(h) : (char*)"");
}
static MoVal bi_os_env(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("os_env(key)"); return MO_NIL; }
    const char *v = getenv(args[0].s); return v ? mo_str(arena_strdup(v)) : MO_NIL;
}

/* ── __path_join__ etc. ───────────────────────────────────────────────────── */
static MoVal bi_path_join(MoVal *args, int argc, VM *vm) {
    if (argc != 2) { mo_error("path_join(a, b)"); return MO_NIL; }
    char buf[4096];
    snprintf(buf, sizeof(buf), "%s/%s", args[0].s, args[1].s);
    return mo_str(arena_strdup(buf));
}
static MoVal bi_path_base(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("path_base(p)"); return MO_NIL; }
    const char *s = strrchr(args[0].s, '/');
    return mo_str(arena_strdup(s ? s + 1 : args[0].s));
}
static MoVal bi_path_dir(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("path_dir(p)"); return MO_NIL; }
    char *copy = arena_strdup(args[0].s);
    char *s = strrchr(copy, '/');
    if (s) { *s = '\0'; return mo_str(copy); }
    return mo_str((char*)".");
}
static MoVal bi_path_ext(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("path_ext(p)"); return MO_NIL; }
    const char *s = strrchr(args[0].s, '.'); return mo_str(arena_strdup(s ? s : ""));
}
static MoVal bi_path_abs(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("path_abs(p)"); return MO_NIL; }
    char buf[4096]; realpath(args[0].s, buf); return mo_str(arena_strdup(buf));
}

/* ── __proc_* ── ─────────────────────────────────────────────────────────── */
static int g_argc = 0; static char **g_argv = NULL;
static MoVal bi_proc_args(MoVal *a, int n, VM *vm) {
    MoList *l = list_new();
    for (int i = 0; i < g_argc; i++) list_push(l, mo_str(g_argv[i]));
    return mo_list_val(l);
}
static MoVal bi_proc_pid(MoVal *a, int n, VM *vm)  { return mo_num((double)getpid()); }
static MoVal bi_proc_exit(MoVal *args, int argc, VM *vm) {
    exit(argc > 0 && args[0].type == MO_NUM ? (int)args[0].n : 0);
}
static MoVal bi_proc_env(MoVal *args, int argc, VM *vm) { return bi_os_env(args, argc, vm); }

/* ── JSON stringify/parse (minimal) ─────────────────────────────────────── */

static void json_write(MoVal v, char *buf, int *pos, int bufsz) {
    char tmp[1024];
    if (v.type == MO_NULL)   { const char *s = "null";  int n=(int)strlen(s); memcpy(buf+*pos,s,n); *pos+=n; }
    else if (v.type == MO_BOOL) { const char *s=v.b?"true":"false"; int n=(int)strlen(s); memcpy(buf+*pos,s,n); *pos+=n; }
    else if (v.type == MO_NUM) {
        if (v.n == (long long)v.n) snprintf(tmp, sizeof(tmp), "%lld", (long long)v.n);
        else snprintf(tmp, sizeof(tmp), "%.15g", v.n);
        int n=(int)strlen(tmp); memcpy(buf+*pos,tmp,n); *pos+=n;
    }
    else if (v.type == MO_STR) {
        buf[(*pos)++]='"';
        for (const char *p=v.s; *p && *pos < bufsz-4; p++) {
            if (*p=='"') { buf[(*pos)++]='\\'; buf[(*pos)++]='"'; }
            else if (*p=='\\') { buf[(*pos)++]='\\'; buf[(*pos)++]='\\'; }
            else if (*p=='\n') { buf[(*pos)++]='\\'; buf[(*pos)++]='n'; }
            else buf[(*pos)++]=*p;
        }
        buf[(*pos)++]='"';
    }
    else if (v.type == MO_LIST) {
        buf[(*pos)++]='[';
        for (int i=0; i<v.list->len; i++) {
            if (i) { buf[(*pos)++]=','; buf[(*pos)++]=' '; }
            json_write(v.list->items[i], buf, pos, bufsz);
        }
        buf[(*pos)++]=']';
    }
    else if (v.type == MO_DICT || v.type == MO_MODULE) {
        buf[(*pos)++]='{'; int first=1;
        for (int i=0; i<v.dict->cap; i++) {
            if (!v.dict->entries[i].used) continue;
            if (!first) { buf[(*pos)++]=','; buf[(*pos)++]=' '; }
            first=0;
            MoVal ks = mo_str(v.dict->entries[i].key);
            json_write(ks, buf, pos, bufsz);
            buf[(*pos)++]=':'; buf[(*pos)++]=' ';
            json_write(v.dict->entries[i].val, buf, pos, bufsz);
        }
        buf[(*pos)++]='}';
    }
    else { const char *s="null"; int n=(int)strlen(s); memcpy(buf+*pos,s,n); *pos+=n; }
    buf[*pos]='\0';
}

static MoVal bi_json_stringify(MoVal *args, int argc, VM *vm) {
    if (argc < 1) { mo_error("json_stringify(val)"); return MO_NIL; }
    char *buf = arena_alloc(65536); int pos=0;
    json_write(args[0], buf, &pos, 65536);
    return mo_str(buf);
}

/* very minimal JSON parser for bi_json_parse */
static const char *jp_skip(const char *p) {
    while (*p==' '||*p=='\t'||*p=='\n'||*p=='\r') p++;
    return p;
}
static MoVal jp_value(const char **pp);

static MoVal jp_string(const char **pp) {
    const char *p = *pp + 1; /* skip opening " */
    char *buf = arena_alloc(4096); char *w = buf;
    while (*p && *p != '"') {
        if (*p == '\\') {
            p++;
            switch (*p) {
                case 'n': *w++='\n'; break;
                case 't': *w++='\t'; break;
                case 'r': *w++='\r'; break;
                default:  *w++=*p; break;
            }
        } else { *w++=*p; }
        p++;
    }
    *w = '\0';
    *pp = p + 1;
    return mo_str(buf);
}

static MoVal jp_array(const char **pp) {
    const char *p = jp_skip(*pp + 1);
    MoList *l = list_new();
    if (*p == ']') { *pp = p+1; return mo_list_val(l); }
    while (*p) {
        *pp = p; list_push(l, jp_value(pp)); p = jp_skip(*pp);
        if (*p == ',') p++;
        else if (*p == ']') { *pp = p+1; break; }
        p = jp_skip(p);
    }
    return mo_list_val(l);
}

static MoVal jp_object(const char **pp) {
    const char *p = jp_skip(*pp + 1);
    MoDict *d = dict_new();
    if (*p == '}') { *pp = p+1; MoVal v={MO_DICT,{.dict=d}}; return v; }
    while (*p) {
        *pp = p; MoVal k = jp_string(pp); p = jp_skip(*pp);
        if (*p == ':') p++;
        p = jp_skip(p); *pp = p;
        MoVal v = jp_value(pp); p = jp_skip(*pp);
        dict_set(d, k.s, v);
        if (*p == ',') p++;
        else if (*p == '}') { *pp = p+1; break; }
        p = jp_skip(p);
    }
    MoVal v = {MO_DICT, {.dict=d}};
    return v;
}

static MoVal jp_value(const char **pp) {
    const char *p = jp_skip(*pp);
    if (*p == '"') return jp_string(pp);
    if (*p == '[') return jp_array(pp);
    if (*p == '{') return jp_object(pp);
    if (strncmp(p,"null",4)==0)  { *pp=p+4; return MO_NIL; }
    if (strncmp(p,"true",4)==0)  { *pp=p+4; return MO_TRUE; }
    if (strncmp(p,"false",5)==0) { *pp=p+5; return MO_FALSE; }
    /* number */
    char *end; double n = strtod(p, &end);
    *pp = end; return mo_num(n);
}

static MoVal bi_json_parse(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("json_parse(str)"); return MO_NIL; }
    const char *p = args[0].s;
    return jp_value(&p);
}

/* ── File I/O ─────────────────────────────────────────────────────────────── */

static MoVal bi_file_read(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("file_read(path)"); return MO_NIL; }
    FILE *f = fopen(args[0].s, "rb");
    if (!f) { mo_error("Cannot open file '%s'", args[0].s); return MO_NIL; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char *buf = arena_alloc(sz + 1);
    fread(buf, 1, sz, f); buf[sz] = '\0'; fclose(f);
    return mo_str(buf);
}

static MoVal bi_file_write(MoVal *args, int argc, VM *vm) {
    if (argc != 2 || args[0].type != MO_STR || args[1].type != MO_STR) {
        mo_error("file_write(path, data)"); return MO_NIL;
    }
    FILE *f = fopen(args[0].s, "w");
    if (!f) { mo_error("Cannot write file '%s'", args[0].s); return MO_NIL; }
    fputs(args[1].s, f); fclose(f); return MO_NIL;
}

static MoVal bi_file_exists(MoVal *args, int argc, VM *vm) {
    if (argc != 1 || args[0].type != MO_STR) { mo_error("file_exists(path)"); return MO_NIL; }
    FILE *f = fopen(args[0].s, "r");
    if (f) { fclose(f); return MO_TRUE; } return MO_FALSE;
}

/* ════════════════════════════════════════════════════════════════════════════
 * Register builtins
 * ════════════════════════════════════════════════════════════════════════════ */

#define REG(name, fn) env_define(vm->globals, name, (MoVal){MO_BUILTIN, {.builtin=fn}})

static void vm_register_builtins(VM *vm) {
    REG("print",  bi_print);
    REG("len",    bi_len);
    REG("str",    bi_str);
    REG("num",    bi_num);
    REG("type",   bi_type);
    REG("push",   bi_push);
    REG("pop",    bi_pop);
    REG("keys",   bi_keys);
    REG("has",    bi_has);
    REG("delete", bi_delete);
    REG("range",  bi_range);
    REG("floor",  bi_floor);
    REG("ceil",   bi_ceil);
    REG("round",  bi_round);
    REG("abs",    bi_abs);
    REG("input",  bi_input);
    REG("sqrt",   bi_sqrt);
    REG("pow",    bi_pow);
    REG("debug",  bi_debug);
    REG("__json_parse__",    bi_json_parse);
    REG("__json_stringify__", bi_json_stringify);
    REG("__time_now__",  bi_time_now);
    REG("__time_ms__",   bi_time_ms);
    REG("__time_sleep__",bi_time_sleep);
    REG("__random_int__",  bi_random_int);
    REG("__random_float__",bi_random_float);
    REG("__random_pick__", bi_random_pick);
    REG("__os_name__", bi_os_name);
    REG("__os_cwd__",  bi_os_cwd);
    REG("__os_home__", bi_os_home);
    REG("__os_env__",  bi_os_env);
    REG("__path_join__", bi_path_join);
    REG("__path_base__", bi_path_base);
    REG("__path_dir__",  bi_path_dir);
    REG("__path_ext__",  bi_path_ext);
    REG("__path_abs__",  bi_path_abs);
    REG("__proc_args__", bi_proc_args);
    REG("__proc_pid__",  bi_proc_pid);
    REG("__proc_exit__", bi_proc_exit);
    REG("__proc_env__",  bi_proc_env);
    REG("__file_read__",  bi_file_read);
    REG("__file_write__", bi_file_write);
    REG("__file_exists__",bi_file_exists);
}

/* ═══════════════════════════════════════════════════════════════════════════
 * JSON bytecode loader
 * ═══════════════════════════════════════════════════════════════════════════ */

/* Parse JSON produced by mo_lang/bytecode.py into an Instr array. */

typedef struct { const char *p; } JP;

static void jp_skip_ws(JP *jp) {
    while (*jp->p == ' ' || *jp->p == '\t' || *jp->p == '\n' || *jp->p == '\r')
        jp->p++;
}

static void jp_expect(JP *jp, char c) {
    jp_skip_ws(jp);
    if (*jp->p != c) {
        fprintf(stderr, "JSON parse error: expected '%c', got '%c' near: %.20s\n", c, *jp->p, jp->p);
        exit(1);
    }
    jp->p++;
}

/* returns arena-allocated string, advances past closing " */
static char *jp_read_str(JP *jp) {
    jp_skip_ws(jp);
    jp_expect(jp, '"');
    char buf[8192]; char *w = buf;
    while (*jp->p && *jp->p != '"') {
        if (*jp->p == '\\') {
            jp->p++;
            switch (*jp->p) {
                case 'n': *w++='\n'; break; case 't': *w++='\t'; break;
                case 'r': *w++='\r'; break; case '"': *w++='"';  break;
                case '\\':*w++='\\';;break; default: *w++=*jp->p; break;
            }
        } else { *w++=*jp->p; }
        jp->p++;
    }
    jp_expect(jp, '"');
    *w = '\0';
    return arena_strdup(buf);
}

static double jp_read_num(JP *jp) {
    jp_skip_ws(jp);
    char *end; double n = strtod(jp->p, &end);
    jp->p = end; return n;
}

static int jp_read_int(JP *jp) { return (int)jp_read_num(jp); }

/* forward */
static Instr *jp_load_code(JP *jp, int *ncode);
static MoFn  *jp_load_fn(JP *jp, MoEnv *closure);

/* reads object fields as key-value pairs into a callback */
/* simplified: reads {"key": val, ...} calling cb for each pair */

static void jp_skip_value(JP *jp); /* forward */

static void jp_skip_value(JP *jp) {
    jp_skip_ws(jp);
    if (*jp->p == '"') { jp_read_str(jp); return; }
    if (*jp->p == '{') {
        jp->p++;
        jp_skip_ws(jp);
        if (*jp->p == '}') { jp->p++; return; }
        while (1) {
            jp_read_str(jp); jp_expect(jp, ':'); jp_skip_value(jp);
            jp_skip_ws(jp);
            if (*jp->p == ',') { jp->p++; continue; }
            if (*jp->p == '}') { jp->p++; break; }
        }
        return;
    }
    if (*jp->p == '[') {
        jp->p++;
        jp_skip_ws(jp);
        if (*jp->p == ']') { jp->p++; return; }
        while (1) {
            jp_skip_value(jp); jp_skip_ws(jp);
            if (*jp->p == ',') { jp->p++; continue; }
            if (*jp->p == ']') { jp->p++; break; }
        }
        return;
    }
    if (strncmp(jp->p, "null",4)==0) { jp->p+=4; return; }
    if (strncmp(jp->p, "true",4)==0) { jp->p+=4; return; }
    if (strncmp(jp->p,"false",5)==0) { jp->p+=5; return; }
    char *end; strtod(jp->p, &end); jp->p = end;
}

/* Read a "val" object: {"t": "n", "v": 42} etc. */
static MoVal jp_read_const(JP *jp) {
    jp_expect(jp, '{');
    /* expect "t" key */
    jp_read_str(jp); jp_expect(jp, ':');
    char *t = jp_read_str(jp);
    MoVal result = MO_NIL;
    if (strcmp(t, "null") == 0) {
        /* done */
    } else if (strcmp(t, "b") == 0) {
        jp_expect(jp, ','); jp_read_str(jp); jp_expect(jp, ':');
        jp_skip_ws(jp);
        if (strncmp(jp->p, "true", 4) == 0) { result = MO_TRUE; jp->p += 4; }
        else { result = MO_FALSE; jp->p += 5; }
    } else if (strcmp(t, "n") == 0) {
        jp_expect(jp, ','); jp_read_str(jp); jp_expect(jp, ':');
        result = mo_num(jp_read_num(jp));
    } else if (strcmp(t, "s") == 0) {
        jp_expect(jp, ','); jp_read_str(jp); jp_expect(jp, ':');
        result = mo_str(jp_read_str(jp));
    }
    jp_skip_ws(jp); jp_expect(jp, '}');
    return result;
}

/* Read a function def object: {"name":..., "params":[...], "code":[...]} */
static MoFn *jp_load_fn(JP *jp, MoEnv *closure) {
    MoFn *fn = arena_alloc(sizeof(MoFn));
    fn->closure = closure;
    jp_expect(jp, '{');
    while (1) {
        jp_skip_ws(jp);
        if (*jp->p == '}') { jp->p++; break; }
        char *key = jp_read_str(jp); jp_expect(jp, ':');
        if (strcmp(key, "name") == 0) {
            fn->name = jp_read_str(jp);
        } else if (strcmp(key, "params") == 0) {
            jp_expect(jp, '[');
            /* collect into temporary dynamic array */
            int cap = 8, cnt = 0;
            char **tmp = arena_alloc(cap * sizeof(char *));
            jp_skip_ws(jp);
            while (*jp->p != ']') {
                if (cnt == cap) {
                    cap *= 2;
                    char **nt = arena_alloc(cap * sizeof(char *));
                    memcpy(nt, tmp, cnt * sizeof(char *));
                    tmp = nt;
                }
                tmp[cnt++] = jp_read_str(jp);
                jp_skip_ws(jp);
                if (*jp->p == ',') jp->p++;
                jp_skip_ws(jp);
            }
            jp_expect(jp, ']');
            fn->nparams = cnt;
            fn->params  = tmp;
        } else if (strcmp(key, "code") == 0) {
            fn->code = jp_load_code(jp, &fn->ncode);
        } else {
            jp_skip_value(jp);
        }
        jp_skip_ws(jp);
        if (*jp->p == ',') jp->p++;
    }
    return fn;
}

/* Read a class def */
static ClassDef *jp_load_class(JP *jp) {
    ClassDef *cls = arena_alloc(sizeof(ClassDef));
    cls->nmethod = 0;
    jp_expect(jp, '{');
    /* two passes for methods: first count, then alloc */
    int method_cap = 8;
    cls->method_names = arena_alloc(method_cap * sizeof(char*));
    cls->methods      = arena_alloc(method_cap * sizeof(MoFn*));
    while (1) {
        jp_skip_ws(jp);
        if (*jp->p == '}') { jp->p++; break; }
        char *key = jp_read_str(jp); jp_expect(jp, ':');
        if (strcmp(key, "name") == 0) {
            cls->name = jp_read_str(jp);
        } else if (strcmp(key, "parent") == 0) {
            jp_skip_ws(jp);
            if (strncmp(jp->p, "null", 4) == 0) { jp->p += 4; cls->parent = NULL; }
            else cls->parent = jp_read_str(jp);
        } else if (strcmp(key, "methods") == 0) {
            jp_expect(jp, '{');
            jp_skip_ws(jp);
            while (*jp->p != '}') {
                char *mname = jp_read_str(jp); jp_expect(jp, ':');
                MoFn *mfn   = jp_load_fn(jp, NULL);   /* closure set at runtime */
                if (cls->nmethod == method_cap) {
                    method_cap *= 2;
                    char  **nn = arena_alloc(method_cap * sizeof(char*));
                    MoFn  **nm = arena_alloc(method_cap * sizeof(MoFn*));
                    memcpy(nn, cls->method_names, cls->nmethod * sizeof(char*));
                    memcpy(nm, cls->methods,      cls->nmethod * sizeof(MoFn*));
                    cls->method_names = nn; cls->methods = nm;
                }
                cls->method_names[cls->nmethod] = mname;
                cls->methods[cls->nmethod]      = mfn;
                cls->nmethod++;
                jp_skip_ws(jp);
                if (*jp->p == ',') jp->p++;
                jp_skip_ws(jp);
            }
            jp_expect(jp, '}');
        } else {
            jp_skip_value(jp);
        }
        jp_skip_ws(jp);
        if (*jp->p == ',') jp->p++;
    }
    return cls;
}

/* Read ["op":"LOAD_CONST", "arg": ...] instruction object */
static Instr jp_load_instr(JP *jp) {
    Instr ins; memset(&ins, 0, sizeof(ins));
    jp_expect(jp, '{');
    while (1) {
        jp_skip_ws(jp);
        if (*jp->p == '}') { jp->p++; break; }
        char *key = jp_read_str(jp); jp_expect(jp, ':');
        if (strcmp(key, "op") == 0) {
            char *opname = jp_read_str(jp);
            if      (strcmp(opname,"LOAD_CONST")==0)    ins.op = OP_LOAD_CONST;
            else if (strcmp(opname,"LOAD_NAME")==0)     ins.op = OP_LOAD_NAME;
            else if (strcmp(opname,"STORE_NAME")==0)    ins.op = OP_STORE_NAME;
            else if (strcmp(opname,"DEFINE_NAME")==0)   ins.op = OP_DEFINE_NAME;
            else if (strcmp(opname,"BINARY_OP")==0)     ins.op = OP_BINARY_OP;
            else if (strcmp(opname,"UNARY_OP")==0)      ins.op = OP_UNARY_OP;
            else if (strcmp(opname,"JUMP")==0)          ins.op = OP_JUMP;
            else if (strcmp(opname,"JUMP_IF_FALSE")==0) ins.op = OP_JUMP_IF_FALSE;
            else if (strcmp(opname,"POP")==0)           ins.op = OP_POP;
            else if (strcmp(opname,"RETURN")==0)        ins.op = OP_RETURN;
            else if (strcmp(opname,"CALL")==0)          ins.op = OP_CALL;
            else if (strcmp(opname,"MAKE_LIST")==0)     ins.op = OP_MAKE_LIST;
            else if (strcmp(opname,"MAKE_DICT")==0)     ins.op = OP_MAKE_DICT;
            else if (strcmp(opname,"INDEX_GET")==0)     ins.op = OP_INDEX_GET;
            else if (strcmp(opname,"INDEX_SET")==0)     ins.op = OP_INDEX_SET;
            else if (strcmp(opname,"GET_ATTR")==0)      ins.op = OP_GET_ATTR;
            else if (strcmp(opname,"SET_ATTR")==0)      ins.op = OP_SET_ATTR;
            else if (strcmp(opname,"METHOD_CALL")==0)   ins.op = OP_METHOD_CALL;
            else if (strcmp(opname,"MAKE_FUNCTION")==0) ins.op = OP_MAKE_FUNCTION;
            else if (strcmp(opname,"MAKE_CLASS")==0)    ins.op = OP_MAKE_CLASS;
            else if (strcmp(opname,"THROW")==0)         ins.op = OP_THROW;
            else if (strcmp(opname,"SETUP_TRY")==0)     ins.op = OP_SETUP_TRY;
            else if (strcmp(opname,"END_TRY")==0)       ins.op = OP_END_TRY;
            else if (strcmp(opname,"IMPORT")==0)        ins.op = OP_IMPORT;
            else if (strcmp(opname,"MAKE_ITER")==0)     ins.op = OP_MAKE_ITER;
            else if (strcmp(opname,"FOR_ITER")==0)      ins.op = OP_FOR_ITER;
            else if (strcmp(opname,"LINE")==0)               ins.op = OP_LINE;
            else if (strcmp(opname,"DUP")==0)                ins.op = OP_DUP;
            else if (strcmp(opname,"MAKE_ASYNC_FUNCTION")==0) ins.op = OP_MAKE_ASYNC_FUNCTION;
            else if (strcmp(opname,"ASYNC_RETURN")==0)       ins.op = OP_ASYNC_RETURN;
            else if (strcmp(opname,"AWAIT")==0)              ins.op = OP_AWAIT;
            else if (strcmp(opname,"DESTRUCTURE_LIST")==0)   ins.op = OP_DESTRUCTURE_LIST;
            else if (strcmp(opname,"DESTRUCTURE_DICT")==0)   ins.op = OP_DESTRUCTURE_DICT;
            else if (strcmp(opname,"MATCH_START")==0)        ins.op = OP_MATCH_START;
            else if (strcmp(opname,"MATCH_CASE")==0)         ins.op = OP_MATCH_CASE;
            else if (strcmp(opname,"MATCH_BIND")==0)         ins.op = OP_MATCH_BIND;
            else if (strcmp(opname,"MATCH_END")==0)          ins.op = OP_MATCH_END;
            else { fprintf(stderr, "Unknown opcode: %s\n", opname); exit(1); }
        } else if (strcmp(key, "arg") == 0) {
            jp_skip_ws(jp);
            switch (ins.op) {
                case OP_LOAD_CONST:
                    ins.val = jp_read_const(jp); break;
                case OP_LOAD_NAME: case OP_STORE_NAME: case OP_DEFINE_NAME:
                case OP_BINARY_OP: case OP_UNARY_OP:
                case OP_GET_ATTR:  case OP_SET_ATTR:
                    ins.str = jp_read_str(jp); break;
                case OP_JUMP: case OP_JUMP_IF_FALSE: case OP_CALL:
                case OP_MAKE_LIST: case OP_MAKE_DICT:
                case OP_FOR_ITER:  case OP_LINE:
                    ins.ival = jp_read_int(jp); break;
                case OP_MAKE_FUNCTION:
                case OP_MAKE_ASYNC_FUNCTION:
                    ins.fn = jp_load_fn(jp, NULL); break;
                case OP_MAKE_CLASS:
                    ins.cls = jp_load_class(jp); break;
                case OP_METHOD_CALL: {
                    jp_expect(jp, '{');
                    while (1) {
                        jp_skip_ws(jp);
                        if (*jp->p == '}') { jp->p++; break; }
                        char *k = jp_read_str(jp); jp_expect(jp, ':');
                        if (strcmp(k, "method") == 0) ins.method = jp_read_str(jp);
                        else if (strcmp(k, "argc") == 0) ins.method_argc = jp_read_int(jp);
                        else jp_skip_value(jp);
                        jp_skip_ws(jp); if (*jp->p == ',') jp->p++;
                    }
                    break;
                }
                case OP_SETUP_TRY: {
                    jp_expect(jp, '{');
                    while (1) {
                        jp_skip_ws(jp);
                        if (*jp->p == '}') { jp->p++; break; }
                        char *k = jp_read_str(jp); jp_expect(jp, ':');
                        if (strcmp(k, "catch_ip") == 0) ins.catch_ip = jp_read_int(jp);
                        else if (strcmp(k, "err_var") == 0) ins.err_var = jp_read_str(jp);
                        else jp_skip_value(jp);
                        jp_skip_ws(jp); if (*jp->p == ',') jp->p++;
                    }
                    break;
                }
                case OP_IMPORT: {
                    jp_expect(jp, '{');
                    while (1) {
                        jp_skip_ws(jp);
                        if (*jp->p == '}') { jp->p++; break; }
                        char *k = jp_read_str(jp); jp_expect(jp, ':');
                        if (strcmp(k, "path") == 0) ins.import_path = jp_read_str(jp);
                        else if (strcmp(k, "alias") == 0) {
                            jp_skip_ws(jp);
                            if (strncmp(jp->p, "null", 4) == 0) { jp->p += 4; ins.import_alias = NULL; }
                            else ins.import_alias = jp_read_str(jp);
                        } else jp_skip_value(jp);
                        jp_skip_ws(jp); if (*jp->p == ',') jp->p++;
                    }
                    break;
                }
                case OP_DESTRUCTURE_LIST: {
                    /* arg is ["var1", "var2", ...] */
                    jp_expect(jp, '[');
                    int cap = 8; ins.destruct_n = 0;
                    ins.destruct_vars = (char **)arena_alloc(cap * sizeof(char *));
                    jp_skip_ws(jp);
                    while (*jp->p != ']') {
                        if (ins.destruct_n >= cap) {
                            cap *= 2;
                            char **nv = (char **)arena_alloc(cap * sizeof(char *));
                            memcpy(nv, ins.destruct_vars, ins.destruct_n * sizeof(char *));
                            ins.destruct_vars = nv;
                        }
                        ins.destruct_vars[ins.destruct_n++] = jp_read_str(jp);
                        jp_skip_ws(jp); if (*jp->p == ',') jp->p++; jp_skip_ws(jp);
                    }
                    jp->p++; /* consume ']' */
                    break;
                }
                case OP_DESTRUCTURE_DICT: {
                    /* arg is [["key1","var1"], ["key2","var2"], ...] */
                    jp_expect(jp, '[');
                    int cap = 8; ins.destruct_n = 0;
                    ins.destruct_keys = (char **)arena_alloc(cap * sizeof(char *));
                    ins.destruct_vars = (char **)arena_alloc(cap * sizeof(char *));
                    jp_skip_ws(jp);
                    while (*jp->p != ']') {
                        if (ins.destruct_n >= cap) {
                            cap *= 2;
                            char **nk = (char **)arena_alloc(cap * sizeof(char *));
                            char **nv = (char **)arena_alloc(cap * sizeof(char *));
                            memcpy(nk, ins.destruct_keys, ins.destruct_n * sizeof(char *));
                            memcpy(nv, ins.destruct_vars, ins.destruct_n * sizeof(char *));
                            ins.destruct_keys = nk; ins.destruct_vars = nv;
                        }
                        jp_expect(jp, '[');
                        ins.destruct_keys[ins.destruct_n] = jp_read_str(jp);
                        jp_expect(jp, ',');
                        ins.destruct_vars[ins.destruct_n] = jp_read_str(jp);
                        ins.destruct_n++;
                        jp_expect(jp, ']');
                        jp_skip_ws(jp); if (*jp->p == ',') jp->p++; jp_skip_ws(jp);
                    }
                    jp->p++; /* consume ']' */
                    break;
                }
                case OP_MATCH_BIND:
                    ins.str = jp_read_str(jp); break;
                default: jp_skip_value(jp); break;
            }
        } else {
            jp_skip_value(jp);
        }
        jp_skip_ws(jp);
        if (*jp->p == ',') jp->p++;
    }
    return ins;
}

/* Load an array of instructions: [ {...}, {...}, ... ] */
static Instr *jp_load_code(JP *jp, int *ncode) {
    jp_expect(jp, '[');
    jp_skip_ws(jp);
    int cap = 64, n = 0;
    Instr *code = arena_alloc(cap * sizeof(Instr));
    while (*jp->p != ']') {
        if (n == cap) {
            cap *= 2;
            Instr *nc = arena_alloc(cap * sizeof(Instr));
            memcpy(nc, code, n * sizeof(Instr));
            code = nc;
        }
        code[n++] = jp_load_instr(jp);
        jp_skip_ws(jp);
        if (*jp->p == ',') jp->p++;
        jp_skip_ws(jp);
    }
    jp->p++; /* skip ']' */
    *ncode = n;
    return code;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * VM execution
 * ═══════════════════════════════════════════════════════════════════════════ */

static MoVal vm_call(VM *vm, MoVal callee, MoVal *args, int argc) {
    if (callee.type == MO_BUILTIN)
        return callee.builtin(args, argc, vm);

    if (callee.type == MO_FN) {
        MoFn *fn = callee.fn;
        if (argc != fn->nparams) {
            mo_error("%s() expects %d args, got %d", fn->name, fn->nparams, argc);
            return MO_NIL;
        }
        MoEnv *call_env = env_new(fn->closure);
        for (int i = 0; i < argc; i++)
            env_define(call_env, fn->params[i], args[i]);
        Frame f;
        memset(&f, 0, sizeof(f));
        f.code = fn->code; f.ncode = fn->ncode; f.env = call_env;
        return vm_run_frame(vm, &f);
    }

    if (callee.type == MO_CLASS) {
        MoClass *k   = callee.klass;
        MoInst  *ins = arena_alloc(sizeof(MoInst));
        ins->klass   = k;
        ins->fields  = dict_new();
        MoVal inst_val = mo_inst_val(ins);
        MoVal *initp = class_lookup(k, "init");
        if (initp) {
            MoVal iargs[argc + 1];
            /* call with self injected via closure, not passed as arg */
            MoFn *ifn = initp->fn;
            MoEnv *call_env = env_new(ifn->closure ? ifn->closure : vm->globals);
            env_define(call_env, "self", inst_val);
            if (k->parent)
                env_define(call_env, "super",
                    (MoVal){MO_SUPER, {.super={k->parent, ins}}});
            if (argc != ifn->nparams) {
                mo_error("%s.init() expects %d args, got %d", k->name, ifn->nparams, argc);
                return MO_NIL;
            }
            for (int i = 0; i < argc; i++)
                env_define(call_env, ifn->params[i], args[i]);
            Frame f; memset(&f, 0, sizeof(f));
            f.code = ifn->code; f.ncode = ifn->ncode; f.env = call_env;
            vm_run_frame(vm, &f);
        }
        return inst_val;
    }

    mo_error("Value is not callable (type: %s)", mo_type_name(callee));
    return MO_NIL;
}

static MoVal vm_call_method(VM *vm, MoVal obj, const char *method,
                             MoVal *args, int argc) {
    if (obj.type == MO_STR)
        return str_method(obj.s, method, args, argc);

    if (obj.type == MO_LIST)
        return list_method(obj.list, method, args, argc);

    if (obj.type == MO_INST) {
        MoInst *ins = obj.inst;
        MoVal *mp = class_lookup(ins->klass, method);
        if (!mp) { mo_error("'%s' has no method '%s'", ins->klass->name, method); return MO_NIL; }
        MoFn *fn = mp->fn;
        MoEnv *call_env = env_new(fn->closure ? fn->closure : vm->globals);
        env_define(call_env, "self", obj);
        if (ins->klass->parent)
            env_define(call_env, "super",
                (MoVal){MO_SUPER, {.super={ins->klass->parent, ins}}});
        if (argc != fn->nparams) {
            mo_error("%s.%s() expects %d args, got %d", ins->klass->name, method, fn->nparams, argc);
            return MO_NIL;
        }
        for (int i = 0; i < argc; i++)
            env_define(call_env, fn->params[i], args[i]);
        Frame f; memset(&f, 0, sizeof(f));
        f.code = fn->code; f.ncode = fn->ncode; f.env = call_env;
        return vm_run_frame(vm, &f);
    }

    if (obj.type == MO_SUPER) {
        MoClass *k   = obj.super.klass;
        MoInst  *ins = obj.super.inst;
        MoVal *mp = class_lookup(k, method);
        if (!mp) { mo_error("super has no method '%s'", method); return MO_NIL; }
        MoFn *fn = mp->fn;
        MoEnv *call_env = env_new(fn->closure ? fn->closure : vm->globals);
        env_define(call_env, "self", mo_inst_val(ins));
        if (k->parent)
            env_define(call_env, "super",
                (MoVal){MO_SUPER, {.super={k->parent, ins}}});
        for (int i = 0; i < argc; i++)
            env_define(call_env, fn->params[i], args[i]);
        Frame f; memset(&f, 0, sizeof(f));
        f.code = fn->code; f.ncode = fn->ncode; f.env = call_env;
        return vm_run_frame(vm, &f);
    }

    if (obj.type == MO_DICT || obj.type == MO_MODULE) {
        MoVal *mp = dict_get_ptr(obj.dict, method);
        if (!mp) { mo_error("Module has no function '%s'", method); return MO_NIL; }
        return vm_call(vm, *mp, args, argc);
    }

    mo_error("Cannot call method on %s", mo_type_name(obj));
    return MO_NIL;
}

static MoVal vm_get_attr(VM *vm, MoVal obj, const char *attr) {
    if (obj.type == MO_INST) {
        MoVal *fp = dict_get_ptr(obj.inst->fields, attr);
        if (fp) return *fp;
        MoVal *mp = class_lookup(obj.inst->klass, attr);
        if (mp) return *mp;
        mo_error("'%s' has no attribute '%s'", obj.inst->klass->name, attr);
        return MO_NIL;
    }
    if (obj.type == MO_SUPER) {
        MoVal *mp = class_lookup(obj.super.klass, attr);
        if (mp) return *mp;
        mo_error("super has no attribute '%s'", attr);
        return MO_NIL;
    }
    if (obj.type == MO_STR)
        return str_method(obj.s, attr, NULL, 0);
    if (obj.type == MO_DICT || obj.type == MO_MODULE) {
        MoVal *p = dict_get_ptr(obj.dict, attr);
        if (p) return *p;
        mo_error("Key '%s' not found in dict", attr);
        return MO_NIL;
    }
    mo_error("Cannot get attribute '%s' on %s", attr, mo_type_name(obj));
    return MO_NIL;
}

/* Import — calls Python frontend via subprocess to compile the module */
static MoVal vm_import(VM *vm, const char *path, const char *alias) {
    /* Build path: base_dir/path.mo or package dir */
    char full[4096];
    const char *mo_path = path;
    char tmp[4096];
    if (!strstr(path, ".mo")) { snprintf(tmp, sizeof(tmp), "%s.mo", path); mo_path = tmp; }

    snprintf(full, sizeof(full), "%s/%s", vm->base_dir, mo_path);

    char *json = NULL;  /* will point to compiled bytecode JSON */

    if (g_import_cb) {
        /* Extension mode: call Python directly — no fork, no disk I/O */
        json = g_import_cb(mo_path, vm->base_dir);
        if (!json) { mo_error("Cannot find module '%s'", path); return MO_NIL; }
    } else {
        /* Standalone mode: shell out to Python */
        char tmpfile[256];
        snprintf(tmpfile, sizeof(tmpfile), "/tmp/mo_import_%d.json", (int)getpid());
        char cmd[8192];
        snprintf(cmd, sizeof(cmd),
            "python3 -c \""
            "import sys,os; sys.path.insert(0,'%s/../');"
            "from mo_lang.lexer import Lexer; from mo_lang.parser import Parser;"
            "from mo_lang.compiler import Compiler; from mo_lang.bytecode import bytecode_to_json;"
            "mo_path='%s'; base='%s';"
            "candidates=[os.path.join(base,mo_path),"
            " os.path.join(os.path.dirname(__import__('mo_lang').__file__),'std',mo_path.replace('std/','')),"
            " os.path.expanduser('~/.mo/packages/'+mo_path)];"
            "src=next((open(p).read() for p in candidates if os.path.exists(p)),None);"
            "open('%s','w').write(bytecode_to_json(Compiler().compile(Parser(Lexer(src).tokenize()).parse())) if src else 'null')"
            "\"",
            vm->base_dir, mo_path, vm->base_dir, tmpfile);
        system(cmd);
        FILE *f = fopen(tmpfile, "r");
        if (!f) { mo_error("Cannot find module '%s'", path); return MO_NIL; }
        fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
        json = arena_alloc(sz + 1);
        fread(json, 1, sz, f); json[sz] = '\0'; fclose(f);
        remove(tmpfile);
    }

    if (strcmp(json, "null") == 0) { mo_error("Cannot find module '%s'", path); return MO_NIL; }

    JP jp; jp.p = json;
    int ncode; Instr *code = jp_load_code(&jp, &ncode);

    MoEnv *mod_env = env_new(vm->globals);
    Frame mf; memset(&mf, 0, sizeof(mf));
    mf.code = code; mf.ncode = ncode; mf.env = mod_env;
    vm_run_frame(vm, &mf);
    if (g_thrown) return MO_NIL;

    if (alias) {
        /* Export all names as-is into the namespace dict */
        MoDict *ns = dict_new();
        for (int i = 0; i < mod_env->vars->cap; i++) {
            if (!mod_env->vars->entries[i].used) continue;
            dict_set(ns, mod_env->vars->entries[i].key,
                     mod_env->vars->entries[i].val);
        }
        MoVal nsv = {MO_MODULE, {.module=ns}};
        env_define(mod_env->parent ? mod_env->parent : vm->globals, alias, nsv);
    } else {
        for (int i = 0; i < mod_env->vars->cap; i++) {
            if (!mod_env->vars->entries[i].used) continue;
            env_define(vm->globals, mod_env->vars->entries[i].key,
                       mod_env->vars->entries[i].val);
        }
    }
    return MO_NIL;
}

/* ── Main execution loop ─────────────────────────────────────────────────── */

static MoVal vm_run_frame(VM *vm, Frame *f) {
/* ── Computed-goto dispatch (GCC/Clang only) ──────────────────────────── */
#if defined(__GNUC__) || defined(__clang__)
    static const void *dtbl[] = {
        [OP_NOP]                 = &&L_NOP,
        [OP_LOAD_CONST]          = &&L_LOAD_CONST,
        [OP_LOAD_NAME]           = &&L_LOAD_NAME,
        [OP_STORE_NAME]          = &&L_STORE_NAME,
        [OP_DEFINE_NAME]         = &&L_DEFINE_NAME,
        [OP_BINARY_OP]           = &&L_BINARY_OP,
        [OP_UNARY_OP]            = &&L_UNARY_OP,
        [OP_JUMP]                = &&L_JUMP,
        [OP_JUMP_IF_FALSE]       = &&L_JUMP_IF_FALSE,
        [OP_POP]                 = &&L_POP,
        [OP_RETURN]              = &&L_RETURN,
        [OP_CALL]                = &&L_CALL,
        [OP_MAKE_LIST]           = &&L_MAKE_LIST,
        [OP_MAKE_DICT]           = &&L_MAKE_DICT,
        [OP_INDEX_GET]           = &&L_INDEX_GET,
        [OP_INDEX_SET]           = &&L_INDEX_SET,
        [OP_GET_ATTR]            = &&L_GET_ATTR,
        [OP_SET_ATTR]            = &&L_SET_ATTR,
        [OP_METHOD_CALL]         = &&L_METHOD_CALL,
        [OP_MAKE_FUNCTION]       = &&L_MAKE_FUNCTION,
        [OP_MAKE_CLASS]          = &&L_MAKE_CLASS,
        [OP_THROW]               = &&L_THROW,
        [OP_SETUP_TRY]           = &&L_SETUP_TRY,
        [OP_END_TRY]             = &&L_END_TRY,
        [OP_IMPORT]              = &&L_IMPORT,
        [OP_MAKE_ITER]           = &&L_MAKE_ITER,
        [OP_FOR_ITER]            = &&L_FOR_ITER,
        [OP_LINE]                = &&L_LINE,
        [OP_DUP]                 = &&L_DUP,
        [OP_MAKE_ASYNC_FUNCTION] = &&L_MAKE_ASYNC_FUNCTION,
        [OP_ASYNC_RETURN]        = &&L_ASYNC_RETURN,
        [OP_AWAIT]               = &&L_NOP,
        [OP_DESTRUCTURE_LIST]    = &&L_DESTRUCTURE_LIST,
        [OP_DESTRUCTURE_DICT]    = &&L_DESTRUCTURE_DICT,
        [OP_MATCH_START]         = &&L_NOP,
        [OP_MATCH_CASE]          = &&L_NOP,
        [OP_MATCH_BIND]          = &&L_MATCH_BIND,
        [OP_MATCH_END]           = &&L_NOP,
    };

    Instr *ins;

    #define NEXT do { \
        if (f->ip >= f->ncode) goto L_DONE; \
        ins = &f->code[f->ip++]; \
        if (__builtin_expect(vm->trace, 0)) \
            fprintf(stderr, "  %4d  %-20s  sp=%d\n", f->ip-1, \
                ins->op==OP_LOAD_CONST?"LOAD_CONST": \
                ins->op==OP_LOAD_NAME?ins->str: \
                ins->op==OP_BINARY_OP?ins->str:"(op)", f->sp); \
        goto *dtbl[ins->op]; \
    } while(0)

    NEXT;

L_LINE:         vm->current_line = ins->ival;                          NEXT;
L_NOP:                                                                  NEXT;
L_LOAD_CONST:   push(f, ins->val);                                     NEXT;
L_POP:          pop(f);                                                 NEXT;
L_DUP:          push(f, peek(f));                                       NEXT;

L_LOAD_NAME:
    push(f, env_get(f->env, ins->str));
    if (g_thrown) goto handle_exc;
    NEXT;

L_DEFINE_NAME:
    env_define(f->env, ins->str, pop(f));
    NEXT;

L_STORE_NAME:
    env_set(f->env, ins->str, pop(f));
    if (g_thrown) goto handle_exc;
    NEXT;

L_BINARY_OP: {
    MoVal r = pop(f), l = pop(f);
    push(f, mo_binop(ins->str, l, r));
    if (g_thrown) goto handle_exc;
    NEXT;
}

L_UNARY_OP: {
    MoVal v = pop(f);
    if (ins->str[0] == '-') push(f, mo_num(-v.n));
    else push(f, mo_bool(!mo_truthy(v)));
    NEXT;
}

L_JUMP:         f->ip = ins->ival;                                      NEXT;
L_JUMP_IF_FALSE: if (!mo_truthy(pop(f))) f->ip = ins->ival;             NEXT;

L_CALL: {
    int    argc = ins->ival;
    MoVal *args = f->stack + f->sp - argc;
    MoVal  fn   = f->stack[f->sp - argc - 1];
    MoVal  ret  = vm_call(vm, fn, args, argc);
    f->sp -= argc + 1;
    push(f, ret);
    if (g_thrown) goto handle_exc;
    NEXT;
}

L_RETURN:       f->retval = pop(f); return f->retval;
L_ASYNC_RETURN: f->retval = pop(f); return f->retval;

L_MAKE_LIST: {
    int n = ins->ival;
    MoList *ml = list_new();
    MoVal *tmp = (MoVal *)arena_alloc(n * sizeof(MoVal));
    for (int i = n-1; i >= 0; i--) tmp[i] = pop(f);
    for (int i = 0;   i < n;  i++) list_push(ml, tmp[i]);
    push(f, mo_list_val(ml));
    NEXT;
}

L_MAKE_DICT: {
    int n = ins->ival;
    MoDict *d = dict_new();
    for (int i = 0; i < n; i++) {
        MoVal v = pop(f), k = pop(f);
        dict_set(d, k.s, v);
    }
    push(f, mo_dict_val(d));
    NEXT;
}

L_INDEX_GET: {
    MoVal idx = pop(f), obj = pop(f);
    if (obj.type == MO_LIST) {
        int i = (int)idx.n;
        if (i < 0) i += obj.list->len;
        if (i < 0 || i >= obj.list->len) { mo_error("List index out of range"); goto handle_exc; }
        push(f, obj.list->items[i]);
    } else if (obj.type == MO_STR) {
        int i = (int)idx.n;
        int slen = (int)strlen(obj.s);
        if (i < 0) i += slen;
        if (i < 0 || i >= slen) { mo_error("String index out of range"); goto handle_exc; }
        char c[2] = {obj.s[i], '\0'};
        push(f, mo_str(arena_strdup(c)));
    } else if (obj.type == MO_DICT || obj.type == MO_MODULE) {
        char numbuf[64]; const char *key;
        if (idx.type == MO_STR) { key = idx.s; }
        else if (idx.type == MO_NUM) {
            double v = idx.n;
            if (v == (long long)v) snprintf(numbuf, sizeof(numbuf), "%lld", (long long)v);
            else                   snprintf(numbuf, sizeof(numbuf), "%g", v);
            key = numbuf;
        } else { mo_error("Dict key must be string or number"); goto handle_exc; }
        MoVal *p = dict_get_ptr(obj.dict, key);
        if (!p) { mo_error("Key '%s' not in dict", key); goto handle_exc; }
        push(f, *p);
    } else { mo_error("Cannot index %s", mo_type_name(obj)); goto handle_exc; }
    NEXT;
}

L_INDEX_SET: {
    MoVal val = pop(f), idx = pop(f), obj = pop(f);
    if (obj.type == MO_LIST) {
        int i = (int)idx.n;
        if (i < 0) i += obj.list->len;
        if (i < 0 || i >= obj.list->len) { mo_error("List index out of range"); goto handle_exc; }
        obj.list->items[i] = val;
    } else if (obj.type == MO_DICT || obj.type == MO_MODULE) {
        char numbuf[64]; const char *key;
        if (idx.type == MO_STR) { key = idx.s; }
        else if (idx.type == MO_NUM) {
            double v = idx.n;
            if (v == (long long)v) snprintf(numbuf, sizeof(numbuf), "%lld", (long long)v);
            else                   snprintf(numbuf, sizeof(numbuf), "%g", v);
            key = numbuf;
        } else { mo_error("Dict key must be string or number"); goto handle_exc; }
        dict_set(obj.dict, key, val);
    } else { mo_error("Cannot index-set %s", mo_type_name(obj)); goto handle_exc; }
    push(f, val);
    NEXT;
}

L_GET_ATTR: {
    MoVal obj = pop(f);
    push(f, vm_get_attr(vm, obj, ins->str));
    if (g_thrown) goto handle_exc;
    NEXT;
}

L_SET_ATTR: {
    MoVal val = pop(f), obj = pop(f);
    if (obj.type != MO_INST) { mo_error("Can only set attributes on instances"); goto handle_exc; }
    dict_set(obj.inst->fields, ins->str, val);
    push(f, val);
    NEXT;
}

L_METHOD_CALL: {
    int    argc = ins->method_argc;
    MoVal *args = f->stack + f->sp - argc;
    MoVal  obj  = f->stack[f->sp - argc - 1];
    MoVal  ret  = vm_call_method(vm, obj, ins->method, args, argc);
    f->sp -= argc + 1;
    push(f, ret);
    if (g_thrown) goto handle_exc;
    NEXT;
}

L_MAKE_FUNCTION: {
    MoFn *fn   = arena_alloc(sizeof(MoFn));
    *fn        = *ins->fn;
    fn->closure= f->env;
    push(f, mo_fn_val(fn));
    NEXT;
}

L_MAKE_ASYNC_FUNCTION: {
    MoFn *fn = ins->fn;
    fn->closure = f->env;
    push(f, mo_fn_val(fn));
    NEXT;
}

L_MAKE_CLASS: {
    ClassDef *cd = ins->cls;
    MoClass  *k  = arena_alloc(sizeof(MoClass));
    k->name      = cd->name;
    k->methods   = dict_new();
    k->parent    = NULL;
    if (cd->parent) {
        MoVal pv = env_get(f->env, cd->parent);
        if (g_thrown) goto handle_exc;
        if (pv.type != MO_CLASS) { mo_error("'%s' is not a class", cd->parent); goto handle_exc; }
        k->parent = pv.klass;
    }
    for (int i = 0; i < cd->nmethod; i++) {
        MoFn *mfn    = arena_alloc(sizeof(MoFn));
        *mfn         = *cd->methods[i];
        mfn->closure = f->env;
        dict_set(k->methods, cd->method_names[i], mo_fn_val(mfn));
    }
    push(f, mo_class_val(k));
    NEXT;
}

L_THROW:
    g_thrown  = 1;
    g_exc_val = pop(f);
    goto handle_exc;

L_SETUP_TRY:
    if (f->try_top >= TRY_MAX) { fprintf(stderr, "try stack overflow\n"); exit(1); }
    f->try_stack[f->try_top].catch_ip   = ins->catch_ip;
    f->try_stack[f->try_top].err_var    = ins->err_var;
    f->try_stack[f->try_top].stack_depth= f->sp;
    f->try_top++;
    NEXT;

L_END_TRY:
    if (f->try_top > 0) f->try_top--;
    NEXT;

L_IMPORT: {
    MoVal r = vm_import(vm, ins->import_path, ins->import_alias);
    if (g_thrown) goto handle_exc;
    (void)r;
    NEXT;
}

L_MAKE_ITER: {
    MoVal src = pop(f);
    MoIter *it = arena_alloc(sizeof(MoIter));
    it->pos = 0; it->dict_scan = 0;
    if (src.type == MO_LIST)                         { it->kind = 0; it->list = src.list; }
    else if (src.type == MO_DICT || src.type == MO_MODULE) { it->kind = 1; it->dict = src.dict; }
    else if (src.type == MO_STR)                     { it->kind = 2; it->str  = src.s; }
    else { mo_error("'for' requires a list, dict, or string"); goto handle_exc; }
    push(f, (MoVal){MO_ITER, {.iter=it}});
    NEXT;
}

L_FOR_ITER: {
    MoIter *it = peek(f).iter;
    if (it->kind == 0) {
        if (it->pos >= it->list->len) { pop(f); f->ip = ins->ival; NEXT; }
        push(f, it->list->items[it->pos++]);
    } else if (it->kind == 1) {
        while (it->dict_scan < it->dict->cap && !it->dict->entries[it->dict_scan].used)
            it->dict_scan++;
        if (it->dict_scan >= it->dict->cap) { pop(f); f->ip = ins->ival; NEXT; }
        push(f, mo_str(it->dict->entries[it->dict_scan++].key));
    } else {
        int slen = (int)strlen(it->str);
        if (it->pos >= slen) { pop(f); f->ip = ins->ival; NEXT; }
        char c[2] = {it->str[it->pos++], '\0'};
        push(f, mo_str(arena_strdup(c)));
    }
    NEXT;
}

L_DESTRUCTURE_LIST: {
    MoVal val = pop(f);
    if (val.type != MO_LIST) {
        mo_error("Cannot destructure: expected list, got %s", mo_type_name(val));
        goto handle_exc;
    }
    for (int i = 0; i < ins->destruct_n; i++) {
        MoVal elem = (i < val.list->len) ? val.list->items[i] : MO_NIL;
        env_define(f->env, ins->destruct_vars[i], elem);
    }
    NEXT;
}

L_DESTRUCTURE_DICT: {
    MoVal val = pop(f);
    if (val.type != MO_DICT && val.type != MO_MODULE) {
        mo_error("Cannot destructure: expected dict, got %s", mo_type_name(val));
        goto handle_exc;
    }
    for (int i = 0; i < ins->destruct_n; i++) {
        MoVal *p = dict_get_ptr(val.dict, ins->destruct_keys[i]);
        if (!p) {
            mo_error("Key '%s' not found in dict for destructuring", ins->destruct_keys[i]);
            goto handle_exc;
        }
        env_define(f->env, ins->destruct_vars[i], *p);
    }
    NEXT;
}

L_MATCH_BIND:
    env_define(f->env, ins->str, peek(f));
    NEXT;

handle_exc:
    if (f->try_top > 0) {
        f->try_top--;
        TryEntry *te = &f->try_stack[f->try_top];
        f->sp = te->stack_depth;
        env_define(f->env, te->err_var,
            g_thrown ? g_exc_val : mo_str((char *)"<error>"));
        g_thrown = 0;
        f->ip = te->catch_ip;
        NEXT;
    }
    return MO_NIL;

L_DONE:
    return f->retval;

    #undef NEXT

/* ── Switch-based fallback (non-GCC/Clang) ──────────────────────────────── */
#else
    while (f->ip < f->ncode) {
        Instr *ins = &f->code[f->ip++];
        if (vm->trace)
            fprintf(stderr, "  %4d  %-20s  sp=%d\n", f->ip-1,
                ins->op==OP_LOAD_CONST?"LOAD_CONST":
                ins->op==OP_LOAD_NAME?ins->str:
                ins->op==OP_BINARY_OP?ins->str:"(op)", f->sp);
        switch (ins->op) {
        case OP_LINE:   vm->current_line = ins->ival; break;
        case OP_NOP:    break;
        case OP_AWAIT:  break;
        case OP_LOAD_CONST: push(f, ins->val); break;
        case OP_POP:    pop(f); break;
        case OP_DUP:    push(f, peek(f)); break;
        case OP_LOAD_NAME:
            push(f, env_get(f->env, ins->str));
            if (g_thrown) goto handle_exc_sw;
            break;
        case OP_DEFINE_NAME: env_define(f->env, ins->str, pop(f)); break;
        case OP_STORE_NAME:
            env_set(f->env, ins->str, pop(f));
            if (g_thrown) goto handle_exc_sw;
            break;
        case OP_BINARY_OP: {
            MoVal r = pop(f), l = pop(f);
            push(f, mo_binop(ins->str, l, r));
            if (g_thrown) goto handle_exc_sw;
            break; }
        case OP_UNARY_OP: {
            MoVal v = pop(f);
            if (ins->str[0]=='-') push(f, mo_num(-v.n));
            else push(f, mo_bool(!mo_truthy(v)));
            break; }
        case OP_JUMP: f->ip = ins->ival; break;
        case OP_JUMP_IF_FALSE: if (!mo_truthy(pop(f))) f->ip = ins->ival; break;
        case OP_CALL: {
            int argc = ins->ival;
            MoVal *args = f->stack + f->sp - argc;
            MoVal fn = f->stack[f->sp - argc - 1];
            MoVal ret = vm_call(vm, fn, args, argc);
            f->sp -= argc + 1; push(f, ret);
            if (g_thrown) goto handle_exc_sw;
            break; }
        case OP_RETURN: f->retval = pop(f); return f->retval;
        case OP_ASYNC_RETURN: f->retval = pop(f); return f->retval;
        case OP_MAKE_LIST: {
            int n = ins->ival; MoList *ml = list_new();
            MoVal tmp[n];
            for (int i=n-1;i>=0;i--) tmp[i]=pop(f);
            for (int i=0;i<n;i++) list_push(ml,tmp[i]);
            push(f,mo_list_val(ml)); break; }
        case OP_MAKE_DICT: {
            int n = ins->ival; MoDict *d = dict_new();
            for (int i=0;i<n;i++){MoVal v=pop(f),k=pop(f);dict_set(d,k.s,v);}
            push(f,mo_dict_val(d)); break; }
        case OP_INDEX_GET: {
            MoVal idx=pop(f),obj=pop(f);
            if (obj.type==MO_LIST) {
                int i=(int)idx.n; if(i<0)i+=obj.list->len;
                if(i<0||i>=obj.list->len){mo_error("List index out of range");goto handle_exc_sw;}
                push(f,obj.list->items[i]);
            } else if (obj.type==MO_STR) {
                int i=(int)idx.n,slen=(int)strlen(obj.s); if(i<0)i+=slen;
                if(i<0||i>=slen){mo_error("String index out of range");goto handle_exc_sw;}
                char c[2]={obj.s[i],0}; push(f,mo_str(arena_strdup(c)));
            } else if (obj.type==MO_DICT||obj.type==MO_MODULE) {
                char nb[64]; const char *key;
                if(idx.type==MO_STR){key=idx.s;}
                else if(idx.type==MO_NUM){double v=idx.n;if(v==(long long)v)snprintf(nb,sizeof(nb),"%lld",(long long)v);else snprintf(nb,sizeof(nb),"%g",v);key=nb;}
                else{mo_error("Dict key must be string or number");goto handle_exc_sw;}
                MoVal *p=dict_get_ptr(obj.dict,key);
                if(!p){mo_error("Key '%s' not in dict",key);goto handle_exc_sw;}
                push(f,*p);
            } else {mo_error("Cannot index %s",mo_type_name(obj));goto handle_exc_sw;}
            break; }
        case OP_INDEX_SET: {
            MoVal val=pop(f),idx=pop(f),obj=pop(f);
            if(obj.type==MO_LIST){
                int i=(int)idx.n;if(i<0)i+=obj.list->len;
                if(i<0||i>=obj.list->len){mo_error("List index out of range");goto handle_exc_sw;}
                obj.list->items[i]=val;
            } else if(obj.type==MO_DICT||obj.type==MO_MODULE){
                char nb[64];const char *key;
                if(idx.type==MO_STR){key=idx.s;}
                else if(idx.type==MO_NUM){double v=idx.n;if(v==(long long)v)snprintf(nb,sizeof(nb),"%lld",(long long)v);else snprintf(nb,sizeof(nb),"%g",v);key=nb;}
                else{mo_error("Dict key must be string or number");goto handle_exc_sw;}
                dict_set(obj.dict,key,val);
            } else{mo_error("Cannot index-set %s",mo_type_name(obj));goto handle_exc_sw;}
            push(f,val); break; }
        case OP_GET_ATTR: {
            MoVal obj=pop(f); push(f,vm_get_attr(vm,obj,ins->str));
            if(g_thrown)goto handle_exc_sw; break; }
        case OP_SET_ATTR: {
            MoVal val=pop(f),obj=pop(f);
            if(obj.type!=MO_INST){mo_error("Can only set attributes on instances");goto handle_exc_sw;}
            dict_set(obj.inst->fields,ins->str,val); push(f,val); break; }
        case OP_METHOD_CALL: {
            int argc=ins->method_argc;
            MoVal *args=f->stack+f->sp-argc,obj=f->stack[f->sp-argc-1];
            MoVal ret=vm_call_method(vm,obj,ins->method,args,argc);
            f->sp-=argc+1; push(f,ret);
            if(g_thrown)goto handle_exc_sw; break; }
        case OP_MAKE_FUNCTION: {
            MoFn *fn=arena_alloc(sizeof(MoFn));*fn=*ins->fn;fn->closure=f->env;
            push(f,mo_fn_val(fn)); break; }
        case OP_MAKE_ASYNC_FUNCTION: {
            MoFn *fn=ins->fn;fn->closure=f->env;push(f,mo_fn_val(fn)); break; }
        case OP_MAKE_CLASS: {
            ClassDef *cd=ins->cls; MoClass *k=arena_alloc(sizeof(MoClass));
            k->name=cd->name;k->methods=dict_new();k->parent=NULL;
            if(cd->parent){MoVal pv=env_get(f->env,cd->parent);if(g_thrown)goto handle_exc_sw;
                if(pv.type!=MO_CLASS){mo_error("'%s' is not a class",cd->parent);goto handle_exc_sw;}
                k->parent=pv.klass;}
            for(int i=0;i<cd->nmethod;i++){
                MoFn *mfn=arena_alloc(sizeof(MoFn));*mfn=*cd->methods[i];mfn->closure=f->env;
                dict_set(k->methods,cd->method_names[i],mo_fn_val(mfn));}
            push(f,mo_class_val(k)); break; }
        case OP_THROW: g_thrown=1;g_exc_val=pop(f);goto handle_exc_sw;
        case OP_SETUP_TRY:
            if(f->try_top>=TRY_MAX){fprintf(stderr,"try stack overflow\n");exit(1);}
            f->try_stack[f->try_top].catch_ip=ins->catch_ip;
            f->try_stack[f->try_top].err_var=ins->err_var;
            f->try_stack[f->try_top].stack_depth=f->sp;
            f->try_top++; break;
        case OP_END_TRY: if(f->try_top>0)f->try_top--; break;
        case OP_IMPORT: {
            MoVal r=vm_import(vm,ins->import_path,ins->import_alias);
            if(g_thrown)goto handle_exc_sw;(void)r; break; }
        case OP_MAKE_ITER: {
            MoVal src=pop(f); MoIter *it=arena_alloc(sizeof(MoIter));
            it->pos=0;it->dict_scan=0;
            if(src.type==MO_LIST){it->kind=0;it->list=src.list;}
            else if(src.type==MO_DICT||src.type==MO_MODULE){it->kind=1;it->dict=src.dict;}
            else if(src.type==MO_STR){it->kind=2;it->str=src.s;}
            else{mo_error("'for' requires a list, dict, or string");goto handle_exc_sw;}
            push(f,(MoVal){MO_ITER,{.iter=it}}); break; }
        case OP_FOR_ITER: {
            MoIter *it=peek(f).iter;
            if(it->kind==0){
                if(it->pos>=it->list->len){pop(f);f->ip=ins->ival;break;}
                push(f,it->list->items[it->pos++]);
            } else if(it->kind==1){
                while(it->dict_scan<it->dict->cap&&!it->dict->entries[it->dict_scan].used)it->dict_scan++;
                if(it->dict_scan>=it->dict->cap){pop(f);f->ip=ins->ival;break;}
                push(f,mo_str(it->dict->entries[it->dict_scan++].key));
            } else {
                int slen=(int)strlen(it->str);
                if(it->pos>=slen){pop(f);f->ip=ins->ival;break;}
                char c[2]={it->str[it->pos++],0};push(f,mo_str(arena_strdup(c)));
            } break; }
        case OP_DESTRUCTURE_LIST: {
            MoVal val=pop(f);
            if(val.type!=MO_LIST){mo_error("Cannot destructure: expected list, got %s",mo_type_name(val));goto handle_exc_sw;}
            for(int i=0;i<ins->destruct_n;i++){
                MoVal elem=(i<val.list->len)?val.list->items[i]:MO_NIL;
                env_define(f->env,ins->destruct_vars[i],elem);} break; }
        case OP_DESTRUCTURE_DICT: {
            MoVal val=pop(f);
            if(val.type!=MO_DICT&&val.type!=MO_MODULE){mo_error("Cannot destructure: expected dict, got %s",mo_type_name(val));goto handle_exc_sw;}
            for(int i=0;i<ins->destruct_n;i++){
                MoVal *p=dict_get_ptr(val.dict,ins->destruct_keys[i]);
                if(!p){mo_error("Key '%s' not found in dict for destructuring",ins->destruct_keys[i]);goto handle_exc_sw;}
                env_define(f->env,ins->destruct_vars[i],*p);} break; }
        case OP_MATCH_START: case OP_MATCH_CASE: case OP_MATCH_END: break;
        case OP_MATCH_BIND: env_define(f->env,ins->str,peek(f)); break;
        default: fprintf(stderr,"Unknown opcode %d\n",ins->op); exit(1);
        }
        continue;
handle_exc_sw:
        if (f->try_top > 0) {
            f->try_top--;
            TryEntry *te = &f->try_stack[f->try_top];
            f->sp = te->stack_depth;
            env_define(f->env, te->err_var,
                g_thrown ? g_exc_val : mo_str((char *)"<error>"));
            g_thrown = 0;
            f->ip = te->catch_ip;
        } else {
            return MO_NIL;
        }
    }
    return f->retval;
#endif /* MO_COMPUTED_GOTO */
}

/* ═══════════════════════════════════════════════════════════════════════════
 * Bytecode Optimization Pass
 * - Constant folding: pre-compute constant expressions at load time
 * - Dead code elimination: remove unreachable JUMP targets
 * ═══════════════════════════════════════════════════════════════════════════ */

/* Constant folding: LOAD_CONST a, LOAD_CONST b, BINARY_OP op → fold to one LOAD_CONST */
static void opt_fold_constants(Instr *code, int ncode) {
    for (int i = 2; i < ncode; i++) {
        if (code[i].op   != OP_BINARY_OP)   continue;
        if (code[i-2].op != OP_LOAD_CONST)  continue;
        if (code[i-1].op != OP_LOAD_CONST)  continue;
        MoVal l = code[i-2].val, r = code[i-1].val;
        if (l.type != MO_NUM || r.type != MO_NUM) continue;
        const char *op = code[i].str;
        double res = 0; int ok = 1;
        if      (strcmp(op,"+") == 0) res = l.n + r.n;
        else if (strcmp(op,"-") == 0) res = l.n - r.n;
        else if (strcmp(op,"*") == 0) res = l.n * r.n;
        else if (strcmp(op,"/") == 0 && r.n != 0) res = l.n / r.n;
        else ok = 0;
        if (ok) {
            code[i-2].op = OP_NOP;
            code[i-1].op = OP_NOP;
            code[i].op   = OP_LOAD_CONST;
            code[i].val  = mo_num(res);
        }
    }
}

/* Dead-code elimination: proper reachability analysis via a single forward pass.
 * Back-edges (loops) are handled because the back-jump target is already reachable
 * from sequential fall-through before the loop body runs. */
static int opt_eliminate_dead_code(Instr *code, int ncode) {
    if (ncode <= 0) return 0;
    char *reachable = (char *)calloc(ncode, 1);
    if (!reachable) return 0;

    reachable[0] = 1;
    for (int i = 0; i < ncode; i++) {
        if (!reachable[i]) continue;
        int op = code[i].op;
        /* mark jump targets */
        if (op == OP_JUMP || op == OP_JUMP_IF_FALSE || op == OP_FOR_ITER ||
            op == OP_SETUP_TRY) {
            int tgt = code[i].ival;
            if (tgt >= 0 && tgt < ncode) reachable[tgt] = 1;
        }
        if (op == OP_SETUP_TRY) {
            int tgt = code[i].catch_ip;
            if (tgt >= 0 && tgt < ncode) reachable[tgt] = 1;
        }
        /* mark sequential fallthrough (all ops except unconditional JUMP / RETURN) */
        if (op != OP_JUMP && op != OP_RETURN && op != OP_ASYNC_RETURN) {
            if (i + 1 < ncode) reachable[i + 1] = 1;
        }
    }

    int changes = 0;
    for (int i = 0; i < ncode; i++) {
        if (!reachable[i] && code[i].op != OP_NOP) {
            code[i].op = OP_NOP;
            changes++;
        }
    }
    free(reachable);
    return changes;
}

/* ═══════════════════════════════════════════════════════════════════════════
 * main
 * ═══════════════════════════════════════════════════════════════════════════ */

/* ── Shared entry point used by both standalone binary and C extension ─────── */

static int vm_run_json(const char *json, const char *base_dir, int trace) {
    arena_new_block();
    g_thrown = 0;

    JP jp; jp.p = json;
    int ncode; Instr *code = jp_load_code(&jp, &ncode);

    opt_fold_constants(code, ncode);
    opt_eliminate_dead_code(code, ncode);

    VM vm; memset(&vm, 0, sizeof(vm));
    vm.trace   = trace;
    vm.globals = env_new(NULL);
    vm_register_builtins(&vm);
    strncpy(vm.base_dir, base_dir, sizeof(vm.base_dir) - 1);

    MoEnv *mod_env = env_new(vm.globals);
    Frame  frame;  memset(&frame, 0, sizeof(frame));
    frame.code = code; frame.ncode = ncode; frame.env = mod_env;
    vm_run_frame(&vm, &frame);

    return g_thrown ? 1 : 0;
}

#ifndef MO_AS_EXTENSION
int main(int argc, char **argv) {
    srand((unsigned int)time(NULL));

    int   trace     = 0;
    char *json_file = NULL;
    char *src_file  = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--trace") == 0) trace = 1;
        else if (!json_file) json_file = argv[i];
        else if (!src_file)  src_file  = argv[i];
    }

    g_argv = argv + 3;
    g_argc = argc - 3;
    if (g_argc < 0) g_argc = 0;

    if (!json_file) {
        fprintf(stderr, "Usage: mo-vm <bytecode.json> <source-dir> [args...]\n");
        return 1;
    }

    FILE *f = fopen(json_file, "rb");
    if (!f) { fprintf(stderr, "Cannot open %s\n", json_file); return 1; }
    fseek(f, 0, SEEK_END); long sz = ftell(f); rewind(f);
    char *json = malloc(sz + 1);
    fread(json, 1, sz, f); json[sz] = '\0'; fclose(f);

    /* derive base_dir from source file path */
    char base_dir[4096] = ".";
    if (src_file) {
        char tmp[4096]; strncpy(tmp, src_file, sizeof(tmp) - 1);
        char *slash = strrchr(tmp, '/');
        if (slash) { *slash = '\0'; strncpy(base_dir, tmp, sizeof(base_dir) - 1); }
    }

    int rc = vm_run_json(json, base_dir, trace);
    free(json);

    if (rc) {
        char buf[512]; mo_display(g_exc_val, buf, sizeof(buf));
        fprintf(stderr, "[Uncaught throw] %s\n", buf);
    }
    return rc;
}
#endif /* MO_AS_EXTENSION */
