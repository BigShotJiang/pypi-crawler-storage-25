"""
macro_expander.py — Macro expansion for Mo language.

Macros are compile-time functions that transform AST nodes.
They receive AST nodes as arguments and return new AST nodes.
"""
from __future__ import annotations
from typing import Dict, Callable, List, Any
from dataclasses import dataclass

from .ast_nodes import *


class MacroError(Exception):
    pass


@dataclass
class Macro:
    """A compiled macro."""
    name: str
    params: List[str]
    body: List[Any]  # AST nodes that form the macro body


class MacroExpander:
    """Expands macro calls in the AST."""

    def __init__(self):
        self.macros: Dict[str, Macro] = {}
        self._builtin_macros: Dict[str, Callable] = {
            "Quote": self._builtin_quote,
            "Quasiquote": self._builtin_quasiquote,
            "Unquote": self._builtin_unquote,
            "When": self._builtin_when,
            "Unless": self._builtin_unless,
            "Cond": self._builtin_cond,
            "Dbg": self._builtin_dbg,
            "Assert": self._builtin_assert,
        }

    def register(self, macro: MacroDef):
        """Register a user-defined macro."""
        self.macros[macro.name] = Macro(macro.name, macro.params, macro.body)

    def expand(self, stmts: List) -> List:
        """Expand all macros in the AST."""
        result = []
        for stmt in stmts:
            expanded = self._expand_stmt(stmt)
            if expanded is not None:
                result.append(expanded)
        return result

    def _expand_stmt(self, node):
        """Expand macros in a statement."""
        if node is None:
            return None

        t = type(node)

        # Handle macro definitions - register them but don't include in output
        if t is MacroDef:
            self.register(node)
            return None

        # Handle macro calls
        if t is MacroCall:
            return self._expand_macro_call(node)

        # Recursively expand child nodes
        if t is LetStmt:
            return LetStmt(node.name, self._expand_expr(node.value), node.type_hint, node.line)

        if t is DestructureLet:
            return DestructureLet(node.pattern, self._expand_expr(node.value), node.line)

        if t is AssignStmt:
            return AssignStmt(node.name, self._expand_expr(node.value), node.line)

        if t is FnDef:
            return FnDef(
                node.name, node.params,
                [self._expand_stmt(s) for s in node.body],
                node.line, node.variadic
            )

        if t is AsyncFn:
            return AsyncFn(
                node.name, node.params,
                [self._expand_stmt(s) for s in node.body],
                node.line, node.variadic
            )

        if t is ReturnStmt:
            return ReturnStmt(self._expand_expr(node.value) if node.value else None, node.line)

        if t is IfStmt:
            return IfStmt(
                self._expand_expr(node.condition),
                [self._expand_stmt(s) for s in node.then_body],
                [self._expand_stmt(s) for s in node.else_body],
                node.line
            )

        if t is WhileStmt:
            return WhileStmt(
                self._expand_expr(node.condition),
                [self._expand_stmt(s) for s in node.body],
                node.line
            )

        if t is ForStmt:
            return ForStmt(
                node.var,
                self._expand_expr(node.iter),
                [self._expand_stmt(s) for s in node.body],
                node.line
            )

        if t is TryCatch:
            return TryCatch(
                [self._expand_stmt(s) for s in node.try_body],
                node.err_var,
                [self._expand_stmt(s) for s in node.catch_body],
                node.line
            )

        if t is ThrowStmt:
            return ThrowStmt(self._expand_expr(node.value), node.line)

        if t is ExprStmt:
            return ExprStmt(self._expand_expr(node.expr), node.line)

        if t is ClassDef:
            return ClassDef(
                node.name, node.parent,
                [self._expand_stmt(m) for m in node.methods],
                node.line
            )

        if t is MatchStmt:
            return MatchStmt(
                self._expand_expr(node.expr),
                [self._expand_case(c) for c in node.cases],
                node.line
            )

        if t is BreakStmt or t is ContinueStmt or t is ImportStmt:
            return node

        return node

    def _expand_case(self, case: Case) -> Case:
        """Expand macros in a case clause."""
        return Case(case.pattern, [self._expand_stmt(s) for s in case.body], case.line)

    def _expand_expr(self, node):
        """Expand macros in an expression."""
        if node is None:
            return None

        t = type(node)

        # Handle macro calls in expression position
        if t is MacroCall:
            expanded = self._expand_macro_call(node)
            # If macro returns a statement, wrap it appropriately
            if expanded and not isinstance(expanded, (ExprStmt,)):
                if isinstance(expanded, list) and len(expanded) > 0:
                    return expanded[0]
            return expanded

        # Recursively expand sub-expressions
        if t is BinOp:
            return BinOp(node.op, self._expand_expr(node.left), self._expand_expr(node.right))

        if t is UnaryOp:
            return UnaryOp(node.op, self._expand_expr(node.right))

        if t is Call:
            return Call(node.name, [self._expand_expr(a) for a in node.args])

        if t is CallExpr:
            return CallExpr(self._expand_expr(node.callee), [self._expand_expr(a) for a in node.args])

        if t is ListLiteral:
            return ListLiteral([self._expand_expr(e) for e in node.elements])

        if t is DictLiteral:
            return DictLiteral([
                (self._expand_expr(k), self._expand_expr(v))
                for k, v in node.pairs
            ])

        if t is IndexGet:
            return IndexGet(self._expand_expr(node.obj), self._expand_expr(node.index))

        if t is IndexSet:
            return IndexSet(
                self._expand_expr(node.obj),
                self._expand_expr(node.index),
                self._expand_expr(node.value)
            )

        if t is GetAttr:
            return GetAttr(self._expand_expr(node.obj), node.attr)

        if t is SetAttr:
            return SetAttr(
                self._expand_expr(node.obj),
                node.attr,
                self._expand_expr(node.value)
            )

        if t is MethodCall:
            return MethodCall(
                self._expand_expr(node.obj),
                node.method,
                [self._expand_expr(a) for a in node.args]
            )

        if t is AnonFn:
            return AnonFn(
                node.params,
                [self._expand_stmt(s) for s in node.body],
                node.variadic
            )

        if t is AwaitExpr:
            return AwaitExpr(self._expand_expr(node.expr))

        if t is TemplateStr:
            return TemplateStr([
                self._expand_expr(p) if not isinstance(p, str) else p
                for p in node.parts
            ])

        # Literals and identifiers don't need expansion
        return node

    def _expand_macro_call(self, call: MacroCall):
        """Expand a macro call."""
        # Check built-in macros first
        if call.name in self._builtin_macros:
            return self._builtin_macros[call.name](call.args)

        # Check user-defined macros
        if call.name not in self.macros:
            raise MacroError(f"Unknown macro: {call.name}")

        macro = self.macros[call.name]

        if len(call.args) != len(macro.params):
            raise MacroError(
                f"Macro '{call.name}' expects {len(macro.params)} arguments, got {len(call.args)}"
            )

        # Create argument mapping
        arg_map = dict(zip(macro.params, call.args))

        # Substitute arguments into macro body
        expanded_body = [self._substitute(node, arg_map) for node in macro.body]

        # Handle return statements in macro body - extract the returned expression
        processed_body = []
        for stmt in expanded_body:
            if isinstance(stmt, ReturnStmt):
                # Return the expression directly (macro produces a value)
                return stmt.value
            processed_body.append(stmt)

        # Return the expanded body (unwrap if single statement)
        if len(processed_body) == 1:
            return processed_body[0]
        return processed_body

    def _substitute(self, node, arg_map: Dict[str, Any]):
        """Substitute arguments into a macro body."""
        if node is None:
            return None

        t = type(node)

        # Substitute identifiers that match macro parameters
        if t is Ident:
            if node.name in arg_map:
                return arg_map[node.name]
            return node

        # Recursively substitute in child nodes
        if t is BinOp:
            return BinOp(
                node.op,
                self._substitute(node.left, arg_map),
                self._substitute(node.right, arg_map)
            )

        if t is UnaryOp:
            return UnaryOp(node.op, self._substitute(node.right, arg_map))

        if t is Call:
            return Call(
                node.name,
                [self._substitute(a, arg_map) for a in node.args]
            )

        if t is ListLiteral:
            return ListLiteral([self._substitute(e, arg_map) for e in node.elements])

        if t is DictLiteral:
            return DictLiteral([
                (self._substitute(k, arg_map), self._substitute(v, arg_map))
                for k, v in node.pairs
            ])

        if t is ReturnStmt:
            return ReturnStmt(
                self._substitute(node.value, arg_map) if node.value else None,
                node.line
            )

        if t is IndexGet:
            return IndexGet(
                self._substitute(node.obj, arg_map),
                self._substitute(node.index, arg_map)
            )

        if t is GetAttr:
            return GetAttr(self._substitute(node.obj, arg_map), node.attr)

        if t is MethodCall:
            return MethodCall(
                self._substitute(node.obj, arg_map),
                node.method,
                [self._substitute(a, arg_map) for a in node.args]
            )

        # Most statement types don't need substitution in expression position
        return node

    # ── Built-in Macros ─────────────────────────────────────────────────────────

    def _builtin_quote(self, args):
        """(quote expr) - Return expr unevaluated."""
        if len(args) != 1:
            raise MacroError("quote expects 1 argument")
        return args[0]

    def _builtin_quasiquote(self, args):
        """(quasiquote expr) - Like quote but allows unquote."""
        if len(args) != 1:
            raise MacroError("quasiquote expects 1 argument")
        # For now, same as quote
        return args[0]

    def _builtin_unquote(self, args):
        """(unquote expr) - Evaluate expr inside quasiquote."""
        if len(args) != 1:
            raise MacroError("unquote expects 1 argument")
        # This is handled by quasiquote
        return args[0]

    def _builtin_when(self, args):
        """(when condition body...) - Execute body only if condition is true."""
        if len(args) < 2:
            raise MacroError("when expects at least 2 arguments: condition and body")
        condition = args[0]
        # Wrap expressions in ExprStmt
        body = [ExprStmt(arg, 0) for arg in args[1:]]
        return IfStmt(condition, body, [], 0)

    def _builtin_unless(self, args):
        """(unless condition body...) - Execute body only if condition is false."""
        if len(args) < 2:
            raise MacroError("unless expects at least 2 arguments: condition and body")
        condition = args[0]
        # Wrap expressions in ExprStmt
        body = [ExprStmt(arg, 0) for arg in args[1:]]
        return IfStmt(UnaryOp("!", condition), body, [], 0)

    def _builtin_cond(self, args):
        """(cond (test1 body1...) (test2 body2...) ... [(else bodyN...)])
        Chain of if-else statements.
        """
        if len(args) < 1:
            raise MacroError("cond expects at least 1 clause")

        # Build nested if statements from the end
        result = None
        for clause in reversed(args):
            if not isinstance(clause, ListLiteral) or len(clause.elements) < 2:
                raise MacroError("Each cond clause must be a list with at least 2 elements")

            test = clause.elements[0]
            body = clause.elements[1:]

            # Check for else clause
            if isinstance(test, Ident) and test.name == "else":
                result = body
            else:
                result = [IfStmt(test, body, result if result else [], 0)]

        return result[0] if isinstance(result, list) else result

    def _builtin_dbg(self, args):
        """(dbg expr) - Print expression and its value, then return value."""
        if len(args) != 1:
            raise MacroError("dbg expects 1 argument")
        expr = args[0]
        # Generate: { print("expr = " + str(expr)); expr }
        # For now, return a debug print followed by the expression
        return [
            ExprStmt(Call("print", [
                BinOp("+", String("DEBUG: "), Call("str", [expr]))
            ]), 0),
            ExprStmt(expr, 0)
        ]

    def _builtin_assert(self, args):
        """(assert condition [message]) - Throw error if condition is false."""
        if len(args) < 1 or len(args) > 2:
            raise MacroError("assert expects 1 or 2 arguments")
        condition = args[0]
        message = args[1] if len(args) == 2 else String("Assertion failed")

        # Generate: if !condition { throw message }
        return IfStmt(
            UnaryOp("!", condition),
            [ThrowStmt(message, 0)],
            [],
            0
        )


def expand_macros(stmts: List) -> List:
    """Expand all macros in the given AST."""
    expander = MacroExpander()
    return expander.expand(stmts)
