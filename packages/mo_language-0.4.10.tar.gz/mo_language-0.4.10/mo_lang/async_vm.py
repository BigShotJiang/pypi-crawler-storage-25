"""
AsyncVM - True coroutine support for Mo language.
Provides actor model communication: spawn(), send(), recv(), channel-based messaging.
"""
import asyncio
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable
from collections import deque


@dataclass
class Channel:
    """Async channel for actor model communication."""
    name: str
    _queue: asyncio.Queue = field(default_factory=asyncio.Queue)
    _closed: bool = False
    
    def send(self, value: Any):
        """Send a value to the channel (async)."""
        if self._closed:
            raise RuntimeError(f"Channel {self.name} is closed")
        self._queue.put_nowait(value)
    
    async def recv(self) -> Any:
        """Receive a value from the channel."""
        if self._closed and self._queue.empty():
            raise RuntimeError(f"Channel {self.name} is closed")
        return await self._queue.get()
    
    def close(self):
        """Close the channel."""
        self._closed = True


@dataclass
class Actor:
    """Actor with mailbox for receiving messages."""
    name: str
    mailbox: Channel = None
    _task: asyncio.Task = None
    _running: bool = False
    
    def __post_init__(self):
        if self.mailbox is None:
            self.mailbox = Channel(f"{self.name}_mailbox")


class AsyncVM:
    """Virtual Machine with true async/await coroutine support."""
    
    def __init__(self, vm=None):
        self.vm = vm
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        self.tasks: list[asyncio.Task] = []
        self.channels: dict[str, Channel] = {}
        self.actors: dict[str, Actor] = {}
        self.coroutines: dict[str, asyncio.Coroutine] = {}
        self._task_id = 0
    
    def _next_task_id(self) -> str:
        self._task_id += 1
        return f"task_{self._task_id}"
    
    async def run_async(self, fn: Callable, *args) -> Any:
        """Run an async function with true coroutine support."""
        if asyncio.iscoroutinefunction(fn):
            return await fn(*args)
        elif callable(fn):
            result = fn(*args)
            if asyncio.iscoroutine(result):
                return await result
            return result
        raise TypeError(f"Expected callable, got {type(fn)}")
    
    async def sleep(self, ms: float) -> None:
        """Async sleep for given milliseconds."""
        await asyncio.sleep(ms / 1000.0)
    
    def gather(self, *futures: Awaitable) -> list[Any]:
        """Gather multiple futures and return results."""
        async def _gather():
            return await asyncio.gather(*futures)
        return self.loop.run_until_complete(_gather())
    
    async def _execute_async_fn(self, fn: Callable, args: list, env: dict = None) -> Any:
        """Execute an async function in the VM context."""
        if env is None:
            env = {}
        if asyncio.iscoroutinefunction(fn):
            return await fn(*args)
        result = fn(*args)
        if asyncio.iscoroutine(result):
            return await result
        return result
    
    def create_channel(self, name: str) -> Channel:
        """Create a named channel for communication."""
        channel = Channel(name)
        self.channels[name] = channel
        return channel
    
    def get_channel(self, name: str) -> Channel:
        """Get a channel by name."""
        return self.channels.get(name)
    
    def spawn(self, fn: Callable, *args, name: str = None) -> str:
        """Spawn a new async task."""
        task_id = name or self._next_task_id()
        
        async def _task():
            try:
                if asyncio.iscoroutinefunction(fn):
                    await fn(*args)
                else:
                    result = fn(*args)
                    if asyncio.iscoroutine(result):
                        await result
            except Exception as e:
                print(f"[spawn] Task {task_id} error: {e}")
        
        task = self.loop.create_task(_task())
        self.tasks.append(task)
        return task_id
    
    async def spawn_actor(self, fn: Callable, name: str) -> Actor:
        """Spawn an actor that can receive messages."""
        actor = Actor(name)
        self.actors[name] = actor
        
        async def _actor_loop():
            actor._running = True
            while actor._running:
                try:
                    msg = await asyncio.wait_for(actor.mailbox.recv(), timeout=0.1)
                    if asyncio.iscoroutinefunction(fn):
                        await fn(actor, msg)
                    else:
                        fn(actor, msg)
                except asyncio.TimeoutError:
                    continue
                except RuntimeError as e:
                    if "closed" in str(e):
                        break
                    raise
                except Exception as e:
                    print(f"[actor] {name} error: {e}")
        
        actor._task = self.loop.create_task(_actor_loop())
        return actor
    
    def send(self, channel_name: str, value: Any) -> None:
        """Send a value to a channel."""
        channel = self.channels.get(channel_name)
        if channel is None:
            channel = self.create_channel(channel_name)
        channel.send(value)
    
    async def recv(self, channel_name: str) -> Any:
        """Receive from a channel."""
        channel = self.get_channel(channel_name)
        if channel is None:
            raise RuntimeError(f"Channel {channel_name} not found")
        return await channel.recv()
    
    def parallel(self, *fns: Callable) -> list[asyncio.Task]:
        """Run multiple functions in parallel."""
        results = []
        
        async def run_all():
            tasks = []
            for fn in fns:
                if asyncio.iscoroutinefunction(fn):
                    tasks.append(asyncio.create_task(fn()))
                else:
                    result = fn()
                    if asyncio.iscoroutine(result):
                        tasks.append(asyncio.create_task(result))
                    else:
                        results.append(result)
            if tasks:
                gathered = await asyncio.gather(*tasks)
                return results + list(gathered)
            return results
        
        return self.loop.run_until_complete(run_all())
    
    async def _run_parallel_async(self, *fns: Callable) -> list[Any]:
        """Internal parallel execution."""
        tasks = []
        for fn in fns:
            if asyncio.iscoroutinefunction(fn):
                tasks.append(asyncio.create_task(fn()))
            else:
                result = fn()
                if asyncio.iscoroutine(result):
                    tasks.append(asyncio.create_task(result))
                else:
                    tasks.append(result)
        
        if tasks:
            gathered = [t for t in tasks if asyncio.iscoroutine(t)]
            if gathered:
                return await asyncio.gather(*gathered)
            return tasks
        return []
    
    def run_until_complete(self, coro: Awaitable) -> Any:
        """Run an awaitable to completion."""
        return self.loop.run_until_complete(coro)
    
    def close(self):
        """Clean up the async VM."""
        for task in self.tasks:
            if not task.done():
                task.cancel()
        for actor in self.actors.values():
            actor._running = False
            if actor._task and not actor._task.done():
                actor._task.cancel()
        for channel in self.channels.values():
            channel.close()
        self.loop.run_until_complete(self.loop.shutdown_asyncgens())
        self.loop.close()


_global_vm: AsyncVM = None

def get_async_vm() -> AsyncVM:
    """Get or create the global AsyncVM instance."""
    global _global_vm
    if _global_vm is None:
        _global_vm = AsyncVM()
    return _global_vm