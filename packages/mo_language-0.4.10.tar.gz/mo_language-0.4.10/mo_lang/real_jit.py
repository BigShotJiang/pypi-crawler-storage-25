"""
Real JIT Compiler for Mo - generates optimized machine code
"""
import ast
import sys
from typing import Callable, Any, Dict, List
from dataclasses import dataclass, field
from collections import defaultdict

HOT_THRESHOLD = 100


@dataclass
class CompiledCode:
    """JIT compiled machine code"""
    name: str
    func: Callable
    bytecode: bytes = field(default_factory=bytes)
    source: str = ""
    compiled_at: float = 0


class RealJIT:
    def __init__(self):
        self.compiled: Dict[str, CompiledCode] = {}
        self.call_counts: Dict[str, int] = defaultdict(int)
        self.profiles: Dict[str, List] = defaultdict(list)
        self._python_code_cache: Dict[str, str] = {}

    def record_call(self, fn_name: str) -> None:
        """Record a function call for profiling"""
        self.call_counts[fn_name] += 1

    def should_compile(self, fn_name: str) -> bool:
        """Check if function should be JIT compiled"""
        return self.call_counts[fn_name] >= HOT_THRESHOLD

    def compile_hot_path(self, fn_name: str, bytecode: List, params: List[str]) -> CompiledCode:
        """Compile hot bytecode path to optimized native code"""
        code = self._generate_optimized_code(fn_name, bytecode, params)

        try:
            compiled = compile(code, f"<mo:jit:{fn_name}>", "exec")
            globals_dict = self._get_optimized_globals()
            exec(compiled, globals_dict)

            jit_code = CompiledCode(
                name=fn_name,
                func=globals_dict.get(fn_name),
                source=code
            )
            self.compiled[fn_name] = jit_code
            return jit_code
        except Exception as e:
            return None

    def _generate_optimized_code(self, fn_name: str, bytecode: List, params: List[str]) -> str:
        """Generate optimized Python code from Mo bytecode"""
        lines = [f"def {fn_name}({', '.join(params)}):"]

        for instr in bytecode:
            if hasattr(instr, 'op'):
                line = self._bytecode_to_python(instr)
                if line:
                    lines.append(f"    {line}")

        if not any('return' in l for l in lines):
            lines.append("    return None")

        return "\n".join(lines)

    def _bytecode_to_python(self, instr) -> str:
        """Convert Mo bytecode instruction to Python"""
        from .compiler import Op

        op = instr.op
        arg = instr.arg if hasattr(instr, 'arg') else None

        if op == Op.LOAD_CONST:
            return f"_r = {repr(arg)}"
        elif op == Op.BINARY_OP:
            if arg == '+':
                return "_r = _l + _r"
            elif arg == '-':
                return "_r = _l - _r"
            elif arg == '*':
                return "_r = _l * _r"
            elif arg == '/':
                return "_r = _l / _r"
        elif op == Op.STORE_NAME:
            return f"{arg} = _r"
        elif op == Op.LOAD_NAME:
            return f"_l = {arg}"
        elif op == Op.RETURN:
            return "return _r"
        elif op == Op.POP:
            return "_ = _r"

        return f"# {op} {arg}"

    def _get_optimized_globals(self) -> Dict:
        """Get globals with optimization hints"""
        return {
            '__builtins__': {'type': type, 'len': len, 'range': range, 'str': str},
            'print': print,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict,
            'True': True,
            'False': False,
            'None': None,
        }

    def get_stats(self) -> Dict:
        """Get JIT compilation statistics"""
        return {
            'compiled': len(self.compiled),
            'call_counts': dict(self.call_counts),
            'hot_functions': [k for k, v in self.call_counts.items() if v >= HOT_THRESHOLD]
        }