"""
Interpreter — walks the AST and executes it.

Uses an Environment (scope chain) to store variables.
Functions are first-class values stored in the same environment.
"""
from __future__ import annotations
from typing import Union
import asyncio
import threading
from .ast_nodes import *
from .async_vm import AsyncVM, Channel, Actor, get_async_vm

# Forward reference to avoid circular import
def _get_vm_async_function():
    from .vm import VMAsyncFunction
    return VMAsyncFunction


class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value

class ThrowSignal(Exception):
    def __init__(self, value):
        self.value = value

class BreakSignal(Exception):
    pass

class ContinueSignal(Exception):
    pass

class RuntimeError_(Exception):
    def __init__(self, message: str, node=None, stack_trace: "StackTrace | None" = None):
        self.message = message
        self.node = node
        self.stack_trace = stack_trace
        super().__init__(self._format_message())

    def _format_message(self) -> str:
        parts = [self.message]
        if self.stack_trace:
            trace = self.stack_trace.format()
            if trace:
                parts.append(trace)
        return "\n".join(parts)


class StackTrace:
    def __init__(self):
        self.frames = []

    def push(self, fn_name: str, line: int):
        self.frames.append({"fn": fn_name, "line": line})

    def pop(self):
        if self.frames:
            self.frames.pop()

    def format(self) -> str:
        if not self.frames:
            return ""
        lines = ["Traceback (most recent call last):"]
        for frame in reversed(self.frames):
            lines.append(f"  File line {frame['line']}, in {frame['fn']}")
        return "\n".join(lines)


class Environment:
    def __init__(self, parent: Union[Environment, None] = None, depth: int = 0):
        self.vars = {}
        self.parent = parent
        self.depth = depth
        self._depths = {}  # name -> depth where defined

    def get(self, name: str):
        if name in self.vars:
            return self.vars[name]
        if self.parent:
            return self.parent.get(name)
        raise RuntimeError_(f"Variable '{name}' is not defined", stack_trace=None)

    def set(self, name: str, value):
        if name in self.vars:
            self.vars[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        raise RuntimeError_(f"Cannot assign to undefined variable '{name}'. Use 'let' to declare it first.", stack_trace=None)

    def define(self, name: str, value):
        self.vars[name] = value
        self._depths[name] = self.depth


class Function:
    def __init__(self, name: str, params: list[tuple[str, object]], body: list, closure: Environment, variadic: tuple[str | None, str | None] = (None, None)):
        self.name    = name
        self.params  = params  # [(name, default_expr), ...] default_expr can be None
        self.body    = body
        self.closure = closure
        self.variadic = variadic  # (*args_name, **kwargs_name)

    def __repr__(self):
        param_strs = [p[0] for p in self.params]
        v = self.variadic if isinstance(self.variadic, tuple) and len(self.variadic) == 2 else (None, None)
        args_name, kwargs_name = v
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<fn {self.name}({', '.join(param_strs)})>"


class AsyncFunction:
    def __init__(self, name: str, params: list[tuple[str, object]], body: list, closure: Environment, variadic: tuple[str | None, str | None] = (None, None)):
        self.name    = name
        self.params  = params  # [(name, default_expr), ...] default_expr can be None
        self.body    = body
        self.closure = closure
        self.variadic = variadic  # (*args_name, **kwargs_name)

    def __repr__(self):
        param_strs = [p[0] for p in self.params]
        v = self.variadic if isinstance(self.variadic, tuple) and len(self.variadic) == 2 else (None, None)
        args_name, kwargs_name = v
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<async fn {self.name}({', '.join(param_strs)})>"


class Klass:
    def __init__(self, name: str, methods: dict, parent=None):
        self.name    = name
        self.methods = methods
        self.parent  = parent

    def __repr__(self):
        return f"<class {self.name}>"


class BoundSuper:
    def __init__(self, klass: Klass, instance):
        self.klass    = klass
        self.instance = instance


class Instance:
    def __init__(self, klass: Klass):
        self.klass  = klass
        self.fields = {}

    def __repr__(self):
        return f"<{self.klass.name} instance>"


class Iterator:
    """Iterator wrapper for the iterator protocol."""
    def __init__(self, iterable):
        self._iterable = iterable
        self._index = 0
        if isinstance(iterable, list):
            self._type = "list"
        elif isinstance(iterable, dict):
            self._type = "dict"
            self._keys = list(iterable.keys())
        elif isinstance(iterable, str):
            self._type = "string"
        else:
            raise RuntimeError_(f"Cannot create iterator from {type(iterable).__name__}")

    def has_next(self):
        """Check if there are more items to iterate."""
        if self._type == "list":
            return self._index < len(self._iterable)
        elif self._type == "dict":
            return self._index < len(self._keys)
        elif self._type == "string":
            return self._index < len(self._iterable)
        return False

    def next(self):
        """Get the next item and advance the iterator."""
        if not self.has_next():
            raise RuntimeError_("Iterator has no more items")
        if self._type == "list":
            val = self._iterable[self._index]
            self._index += 1
            return val
        elif self._type == "dict":
            key = self._keys[self._index]
            self._index += 1
            return key
        elif self._type == "string":
            val = self._iterable[self._index]
            self._index += 1
            return val

    def __repr__(self):
        return "<iterator>"


class Interpreter:
    def __init__(self):
        self.globals = Environment()
        self._current_line = 0
        self._stack_trace = StackTrace()
        self._register_builtins()

    def _register_builtins(self):
        self.globals.define("print",  self._builtin_print)
        self.globals.define("len",    self._builtin_len)
        self.globals.define("str",    self._builtin_str)
        self.globals.define("num",    self._builtin_num)
        self.globals.define("type",   self._builtin_type)
        self.globals.define("range",  self._builtin_range)
        self.globals.define("push",   self._builtin_push)
        self.globals.define("pop",    self._builtin_pop)
        self.globals.define("input",  self._builtin_input)
        self.globals.define("keys",   self._builtin_keys)
        self.globals.define("has",    self._builtin_has)
        self.globals.define("delete", self._builtin_delete)
        self.globals.define("floor",         self._builtin_floor)
        self.globals.define("__floor__",     self._builtin_floor)
        self.globals.define("ceil",          self._builtin_ceil)
        self.globals.define("__ceil__",      self._builtin_ceil)
        self.globals.define("round",         self._builtin_round)
        self.globals.define("__round__",     self._builtin_round)
        self.globals.define("abs",           self._builtin_abs)
        self.globals.define("is_number",      self._builtin_is_number)
        self.globals.define("is_string",       self._builtin_is_string)
        self.globals.define("is_bool",          self._builtin_is_bool)
        self.globals.define("is_list",         self._builtin_is_list)
        self.globals.define("is_dict",          self._builtin_is_dict)
        self.globals.define("cast",             self._builtin_cast)
        self.globals.define("__http_serve__",    self._builtin_http_serve)
        self.globals.define("__http_fetch__",    self._builtin_http_fetch)
        self.globals.define("__http_get__",      self._builtin_http_get)
        self.globals.define("__http_post__",     self._builtin_http_post)
        self.globals.define("__file_read__",     self._builtin_file_read)
        self.globals.define("__file_write__",    self._builtin_file_write)
        self.globals.define("__file_append__",   self._builtin_file_append)
        self.globals.define("__file_exists__",   self._builtin_file_exists)
        self.globals.define("__file_delete__",   self._builtin_file_delete)
        self.globals.define("__file_list__",     self._builtin_file_list)
        self.globals.define("__file_is_dir__",   self._builtin_file_is_dir)
        self.globals.define("__file_mkdir__",    self._builtin_file_mkdir)
        self.globals.define("__json_parse__",    self._builtin_json_parse)
        self.globals.define("__json_stringify__",self._builtin_json_stringify)
        self.globals.define("__os_name__",       self._builtin_os_name)
        self.globals.define("__os_cwd__",        self._builtin_os_cwd)
        self.globals.define("__os_home__",       self._builtin_os_home)
        self.globals.define("__os_env__",        self._builtin_os_env)
        self.globals.define("__os_cpus__",       self._builtin_os_cpus)
        self.globals.define("__path_join__",     self._builtin_path_join)
        self.globals.define("__path_dir__",      self._builtin_path_dir)
        self.globals.define("__path_base__",     self._builtin_path_base)
        self.globals.define("__path_ext__",      self._builtin_path_ext)
        self.globals.define("__path_abs__",      self._builtin_path_abs)
        self.globals.define("__url_parse__",     self._builtin_url_parse)
        self.globals.define("__url_encode__",    self._builtin_url_encode)
        self.globals.define("__url_decode__",    self._builtin_url_decode)
        self.globals.define("__url_build__",     self._builtin_url_build)
        self.globals.define("__proc_args__",     self._builtin_proc_args)
        self.globals.define("__proc_pid__",      self._builtin_proc_pid)
        self.globals.define("__proc_exit__",     self._builtin_proc_exit)
        self.globals.define("__proc_env__",      self._builtin_proc_env)
        self.globals.define("__crypto_md5__",    self._builtin_crypto_md5)
        self.globals.define("__crypto_sha1__",   self._builtin_crypto_sha1)
        self.globals.define("__crypto_sha256__", self._builtin_crypto_sha256)
        self.globals.define("__time_now__",      self._builtin_time_now)
        self.globals.define("__time_ms__",       self._builtin_time_ms)
        self.globals.define("__time_sleep__",    self._builtin_time_sleep)
        self.globals.define("__time_format__",   self._builtin_time_format)
        self.globals.define("__random_int__",    self._builtin_random_int)
        self.globals.define("__random_float__",  self._builtin_random_float)
        self.globals.define("__random_pick__",   self._builtin_random_pick)
        self.globals.define("__net_listen__",    self._builtin_net_listen)
        self.globals.define("__net_connect__",   self._builtin_net_connect)
        self.globals.define("__net_send__",      self._builtin_net_send)
        self.globals.define("__net_recv__",      self._builtin_net_recv)
        self.globals.define("__net_close__",     self._builtin_net_close)
        self.globals.define("__net_addr__",      self._builtin_net_addr)
        self.globals.define("__http_serve_bg__", self._builtin_http_serve_bg)
        self.globals.define("debug",  self._builtin_debug)
        self.globals.define("__regex_match__",   self._builtin_regex_match)
        self.globals.define("__regex_replace__", self._builtin_regex_replace)
        self.globals.define("__regex_split__",   self._builtin_regex_split)
        self.globals.define("__regex_search__",  self._builtin_regex_search)
        self.globals.define("__regex_findall__", self._builtin_regex_findall)
        self.globals.define("__sqlite_open__",    self._builtin_sqlite_open)
        self.globals.define("__sqlite_exec__",   self._builtin_sqlite_exec)
        self.globals.define("__sqlite_close__",  self._builtin_sqlite_close)
        self.globals.define("__yaml_parse__",      self._builtin_yaml_parse)
        self.globals.define("__yaml_stringify__", self._builtin_yaml_stringify)
        self.globals.define("__xml_parse__",    self._builtin_xml_parse)
        self.globals.define("__xml_to_string__", self._builtin_xml_to_string)
        self.globals.define("__csv_read__",      self._builtin_csv_read)
        self.globals.define("__csv_write__",    self._builtin_csv_write)
        self.globals.define("async_fn",     self._builtin_async_fn)
        self.globals.define("await_",       self._builtin_await)
        self.globals.define("sleep_async",     self._builtin_sleep_async)
        self.globals.define("run_async",      self._builtin_run_async)
        self.globals.define("__async_loop__", self._get_or_create_event_loop)
        self.globals.define("spawn",        self._builtin_spawn)
        self.globals.define("__log_debug__",    self._builtin_log_debug)
        self.globals.define("__log_info__",     self._builtin_log_info)
        self.globals.define("__log_warning__",  self._builtin_log_warning)
        self.globals.define("__log_error__",    self._builtin_log_error)
        self.globals.define("__log_critical__", self._builtin_log_critical)
        self.globals.define("__log_write__",    self._builtin_log_write)
        self.globals.define("__date_now__",           self._builtin_date_now)
        self.globals.define("__date_from_ts__",       self._builtin_date_from_timestamp)
        self.globals.define("__date_timestamp__",     self._builtin_date_timestamp)
        self.globals.define("__config_load__",        self._builtin_config_load)
        self.globals.define("__redis_connect__",      self._builtin_redis_connect)
        self.globals.define("__redis_set__",          self._builtin_redis_set)
        self.globals.define("__redis_get__",          self._builtin_redis_get)
        self.globals.define("__redis_delete__",       self._builtin_redis_delete)
        self.globals.define("__redis_close__",        self._builtin_redis_close)
        self.globals.define("__assert_equal__",       self._builtin_assert_equal)
        self.globals.define("__assert_throws__",      self._builtin_assert_throws)
        self.globals.define("__ws_connect__",          self._builtin_ws_connect)
        self.globals.define("__ws_send__",             self._builtin_ws_send)
        self.globals.define("__ws_recv__",             self._builtin_ws_recv)
        self.globals.define("__ws_close__",            self._builtin_ws_close)
        self.globals.define("__email_send__",          self._builtin_email_send)
        self.globals.define("__cli_args__",             self._builtin_cli_args)
        self.globals.define("__cli_has_option__",      self._builtin_cli_has_option)
        self.globals.define("__cli_get_option__",      self._builtin_cli_get_option)
        self.globals.define("__template_render__",     self._builtin_template_render)
        self.globals.define("__template_escape__",     self._builtin_template_escape)
        self.globals.define("__jwt_create__",          self._builtin_jwt_create)
        self.globals.define("__jwt_verify__",          self._builtin_jwt_verify)
        self.globals.define("__jwt_decode__",          self._builtin_jwt_decode)
        self.globals.define("__audio_play__",          self._builtin_audio_play)
        self.globals.define("__gui_window__",           self._builtin_gui_window)
        self.globals.define("__gui_label__",            self._builtin_gui_label)
        self.globals.define("__gui_label_set__",        self._builtin_gui_label_set)
        self.globals.define("__gui_button__",           self._builtin_gui_button)
        self.globals.define("__gui_run__",              self._builtin_gui_run)
        self.globals.define("__gui_entry__",            self._builtin_gui_entry)
        self.globals.define("__gui_entry_get__",        self._builtin_gui_entry_get)
        self.globals.define("__gui_entry_clear__",      self._builtin_gui_entry_clear)
        self.globals.define("__gui_listbox__",          self._builtin_gui_listbox)
        self.globals.define("__gui_listbox_add__",      self._builtin_gui_listbox_add)
        self.globals.define("__gui_listbox_selected__", self._builtin_gui_listbox_selected)
        self.globals.define("__gui_listbox_delete__",   self._builtin_gui_listbox_delete)
        self.globals.define("__gui_listbox_size__",     self._builtin_gui_listbox_size)
        self.globals.define("__gui_listbox_get__",      self._builtin_gui_listbox_get)
        self.globals.define("__gui_frame__",            self._builtin_gui_frame)
        self.globals.define("__gui_media_player__",    self._builtin_gui_media_player)
        self.globals.define("__gui_media_play__",      self._builtin_gui_media_play)
        self.globals.define("__gui_media_pause__",     self._builtin_gui_media_pause)
        self.globals.define("__gui_media_stop__",      self._builtin_gui_media_stop)
        self.globals.define("__gui_media_seek__",      self._builtin_gui_media_seek)
        self.globals.define("__gui_media_volume__",    self._builtin_gui_media_volume)
        self.globals.define("__gui_media_duration__",  self._builtin_gui_media_duration)
        self.globals.define("__gui_media_position__",  self._builtin_gui_media_position)
        self.globals.define("__gui_media_load__",      self._builtin_gui_media_load)
        self.globals.define("__gui_media_is_playing__",self._builtin_gui_media_is_playing)
        self.globals.define("__deque__",               self._builtin_deque)
        self.globals.define("__deque_append__",         self._builtin_deque_append)
        self.globals.define("__deque_popleft__",       self._builtin_deque_popleft)
        self.globals.define("__counter__",             self._builtin_counter)
        self.globals.define("__counter_increment__",    self._builtin_counter_increment)
        self.globals.define("__counter_get__",         self._builtin_counter_get)
        self.globals.define("__proc_run__",            self._builtin_proc_run)
        self.globals.define("__proc_start__",          self._builtin_proc_start)
        self.globals.define("__proc_wait__",           self._builtin_proc_wait)
        self.globals.define("__xml_parse__",           self._builtin_xml_parse)
        self.globals.define("__xml_to_string__",       self._builtin_xml_to_string)
        self.globals.define("__xml_find__",            self._builtin_xml_find)
        self.globals.define("__spawn_thread__",        self._builtin_spawn_thread)
        self.globals.define("__thread_join__",         self._builtin_thread_join)
        self.globals.define("__uuid4__",               self._builtin_uuid4)
        self.globals.define("__uuid1__",               self._builtin_uuid1)
        self.globals.define("__base64_encode__",       self._builtin_base64_encode)
        self.globals.define("__base64_decode__",       self._builtin_base64_decode)
        self.globals.define("__gzip_compress__",       self._builtin_gzip_compress)
        self.globals.define("__gzip_decompress__",     self._builtin_gzip_decompress)
        self.globals.define("__fmt__",                 self._builtin_fmt)
        self.globals.define("__printf__",              self._builtin_printf)
        self.globals.define("__cache_create__",        self._builtin_cache_create)
        self.globals.define("__cache_get__",           self._builtin_cache_get)
        self.globals.define("__cache_set__",           self._builtin_cache_set)
        self.globals.define("__decimal__",             self._builtin_decimal)
        self.globals.define("__decimal_add__",         self._builtin_decimal_add)
        self.globals.define("__decimal_mul__",         self._builtin_decimal_mul)
        self.globals.define("__validator_email__",     self._builtin_validator_email)
        self.globals.define("__validator_url__",       self._builtin_validator_url)
        self.globals.define("__validator_phone__",     self._builtin_validator_phone)
        self.globals.define("__validator_number__",    self._builtin_validator_number)
        self.globals.define("send",        self._builtin_send)
        self.globals.define("recv",        self._builtin_recv)
        self.globals.define("channel",     self._builtin_channel)
        self.globals.define("parallel",    self._builtin_parallel)
        self.globals.define("gather",     self._builtin_gather)
        # Iterator protocol
        self.globals.define("iter",       self._builtin_iter)
        self.globals.define("has_next",   self._builtin_has_next)
        self.globals.define("next",       self._builtin_next)
        self.globals.define("__get_async_vm__", self._builtin_get_async_vm)
        self.globals.define("__gui_window__", self._builtin_gui_window)
        self.globals.define("__gui_rect__", self._builtin_gui_rect)
        self.globals.define("__gui_circle__", self._builtin_gui_circle)
        self.globals.define("__gui_text__", self._builtin_gui_text)
        self.globals.define("__gui_line__", self._builtin_gui_line)
        self.globals.define("__gui_image__", self._builtin_gui_image)
        self.globals.define("__gui_on_click__", self._builtin_gui_on_click)
        self.globals.define("__gui_on_key__", self._builtin_gui_on_key)
        self.globals.define("__gui_loop__", self._builtin_gui_loop)
        self.globals.define("__audio_play__", self._builtin_audio_play)
        # Concurrency primitives
        self.globals.define("lock", self._builtin_lock)
        self.globals.define("lock_acquire", self._builtin_lock_acquire)
        self.globals.define("lock_release", self._builtin_lock_release)
        self.globals.define("semaphore", self._builtin_semaphore)
        self.globals.define("sem_acquire", self._builtin_sem_acquire)
        self.globals.define("sem_release", self._builtin_sem_release)
        # Convenience aliases
        self.globals.define("to_str",       self._builtin_str)
        self.globals.define("readFile",     self._builtin_file_read)
        self.globals.define("writeFile",    self._builtin_file_write)
        self.globals.define("csvParse",     self._builtin_csv_parse)
        self.globals.define("csvStringify", self._builtin_csv_stringify)
        self.globals.define("substr",       self._builtin_substr)
        self.globals.define("__abs__",      self._builtin_abs)
        self.globals.define("__sqrt__",     self._builtin_sqrt)
        self.globals.define("__pow__",      self._builtin_pow)
        self.globals.define("__min__",      self._builtin_min)
        self.globals.define("__max__",      self._builtin_max)
        # String utility globals (used by std modules)
        self.globals.define("split",        self._builtin_split)
        self.globals.define("trim",         self._builtin_trim)
        self.globals.define("contains",     self._builtin_contains)
        self.globals.define("replace",      self._builtin_replace)
        self.globals.define("startsWith",   self._builtin_starts_with)
        self.globals.define("endsWith",     self._builtin_ends_with)
        self.globals.define("indexOf",      self._builtin_index_of)
        self.globals.define("join",         self._builtin_join)
        self.globals.define("__slice__",    self._builtin_slice)

    def _error(self, msg: str, node=None) -> None:
        line = self._current_line
        if node and hasattr(node, 'line') and node.line:
            line = node.line
        if line:
            msg = f"{msg} (line {line})"
        raise RuntimeError_(msg, node, self._stack_trace)

    def run(self, stmts: list, env: Environment = None):
        # Expand macros before execution
        from .macro_expander import expand_macros
        stmts = expand_macros(stmts)
        if env is None:
            env = Environment(parent=self.globals)
        for stmt in stmts:
            self._exec(stmt, env)

    def _exec(self, node, env: Environment):
        if node.line:
            self._current_line = node.line
        t = type(node)
        if t is LetStmt:
            value = self._eval(node.value, env)
            type_hint = node.type_hint
            if not type_hint:
                type_hint = self._infer_type(value)
            if type_hint:
                value = self._check_type(value, type_hint, node.name)
            env.define(node.name, value)
        elif t is DestructureLet:
            value = self._eval(node.value, env)
            self._exec_destructure(node.pattern, value, env)
        elif t is AssignStmt:
            env.set(node.name, self._eval(node.value, env))
        elif t is IfStmt:
            if self._truthy(self._eval(node.condition, env)):
                self._exec_block(node.then_body, env)
            elif node.else_body:
                self._exec_block(node.else_body, env)
        elif t is WhileStmt:
            while self._truthy(self._eval(node.condition, env)):
                try:
                    self._exec_block(node.body, env)
                except BreakSignal:
                    break
                except ContinueSignal:
                    continue
        elif t is FnDef:
            env.define(node.name, Function(node.name, node.params, node.body, env, node.variadic))
        elif t is AsyncFn:
            env.define(node.name, AsyncFunction(node.name, node.params, node.body, env, node.variadic))
        elif t is ReturnStmt:
            raise ReturnSignal(self._eval(node.value, env) if node.value is not None else None)
        elif t is BreakStmt:
            raise BreakSignal()
        elif t is ContinueStmt:
            raise ContinueSignal()
        elif t is ForStmt:
            iterable = self._eval(node.iter, env)
            # Support Iterator objects directly
            if isinstance(iterable, Iterator):
                while iterable.has_next():
                    item = iterable.next()
                    local = Environment(parent=env)
                    local.define(node.var, item)
                    try:
                        for stmt in node.body:
                            self._exec(stmt, local)
                    except BreakSignal:
                        break
                    except ContinueSignal:
                        continue
                    except ReturnSignal:
                        raise
            elif isinstance(iterable, dict):
                items = list(iterable.keys())
                for item in items:
                    local = Environment(parent=env)
                    local.define(node.var, item)
                    try:
                        for stmt in node.body:
                            self._exec(stmt, local)
                    except BreakSignal:
                        break
                    except ContinueSignal:
                        continue
                    except ReturnSignal:
                        raise
            elif isinstance(iterable, str):
                items = list(iterable)
                for item in items:
                    local = Environment(parent=env)
                    local.define(node.var, item)
                    try:
                        for stmt in node.body:
                            self._exec(stmt, local)
                    except BreakSignal:
                        break
                    except ContinueSignal:
                        continue
                    except ReturnSignal:
                        raise
            elif isinstance(iterable, list):
                items = iterable
                for item in items:
                    local = Environment(parent=env)
                    local.define(node.var, item)
                    try:
                        for stmt in node.body:
                            self._exec(stmt, local)
                    except BreakSignal:
                        break
                    except ContinueSignal:
                        continue
                    except ReturnSignal:
                        raise
            else:
                raise RuntimeError_("'for' requires a list, dict, string, or iterator")
        elif t is TryCatch:
            try:
                self._exec_block(node.try_body, env)
            except ThrowSignal as e:
                local = Environment(parent=env)
                local.define(node.err_var, e.value)
                self._exec_block(node.catch_body, local)
            except RuntimeError_ as e:
                local = Environment(parent=env)
                local.define(node.err_var, str(e))
                self._exec_block(node.catch_body, local)
        elif t is ThrowStmt:
            raise ThrowSignal(self._eval(node.value, env))
        elif t is ImportStmt:
            self._import(node.path, node.alias, env)
        elif t is ClassDef:
            methods = {fn.name: Function(fn.name, fn.params, fn.body, env, fn.variadic)
                       for fn in node.methods}
            parent = env.get(node.parent) if node.parent else None
            if node.parent and not isinstance(parent, Klass):
                raise RuntimeError_(f"'{node.parent}' is not a class")
            env.define(node.name, Klass(node.name, methods, parent))
        elif t is MatchStmt:
            self._exec_match(node, env)
        elif t is ExprStmt:
            self._eval(node.expr, env)
        else:
                raise RuntimeError_(f"Unknown statement: {type(node).__name__}")

    def _exec_block(self, stmts: list, parent_env: Environment):
        local = Environment(parent=parent_env, depth=parent_env.depth + 1)
        for stmt in stmts:
            self._exec(stmt, local)

    def _exec_destructure(self, pattern, value, env: Environment):
        """Execute destructuring assignment from pattern to value."""
        if isinstance(pattern, ListPattern):
            if not isinstance(value, list):
                raise RuntimeError_(f"Cannot destructure list pattern from {self._builtin_type([value])}", stack_trace=self._stack_trace)
            if len(pattern.elements) != len(value):
                raise RuntimeError_(f"List destructuring pattern has {len(pattern.elements)} elements but value has {len(value)}", stack_trace=self._stack_trace)
            for var_name, val in zip(pattern.elements, value):
                env.define(var_name, val)
        elif isinstance(pattern, DictPattern):
            if not isinstance(value, dict):
                raise RuntimeError_(f"Cannot destructure dict pattern from {self._builtin_type([value])}", stack_trace=self._stack_trace)
            for key, var_name in pattern.pairs:
                if key not in value:
                    raise RuntimeError_(f"Key '{key}' not found in dict for destructuring", stack_trace=self._stack_trace)
                env.define(var_name, value[key])
        else:
            raise RuntimeError_(f"Unknown destructuring pattern: {type(pattern).__name__}", stack_trace=self._stack_trace)

    def _exec_match(self, node: MatchStmt, env: Environment):
        """Execute a match statement."""
        value = self._eval(node.expr, env)

        for case in node.cases:
            match_env = Environment(parent=env, depth=env.depth + 1)
            if self._match_pattern(case.pattern, value, match_env):
                # Pattern matched - execute body with bound variables
                self._exec_block(case.body, match_env)
                return

        # No case matched - this is not an error, just continues

    def _match_pattern(self, pattern, value, match_env: Environment) -> bool:
        """Try to match a pattern against a value.

        Returns True if matched, and binds variables to match_env.
        Returns False if not matched.
        """
        pt = type(pattern)

        # Literal patterns
        if pt is Number:
            return value == pattern.value

        if pt is String:
            return value == pattern.value

        if pt is Bool:
            return value == pattern.value

        if pt is Null:
            return value is None

        # Wildcard pattern (always matches)
        if pt is Ident:
            if pattern.name == "_":
                return True
            # Variable binding pattern
            match_env.define(pattern.name, value)
            return True

        # List pattern: [x, y, ...]
        if pt is ListLiteral:
            if not isinstance(value, list):
                return False
            if len(pattern.elements) != len(value):
                return False
            for elem_pat, elem_val in zip(pattern.elements, value):
                if not self._match_pattern(elem_pat, elem_val, match_env):
                    return False
            return True

        # Dict pattern: {"key": x, ...}
        if pt is DictPattern:
            if not isinstance(value, dict):
                return False
            for key_str, var_name in pattern.pairs:
                if key_str not in value:
                    return False
                match_env.define(var_name, value[key_str])
            return True

        if pt is DictLiteral:
            if not isinstance(value, dict):
                return False
            for key_expr, val_pattern in pattern.pairs:
                # Evaluate key (should be a string literal in patterns)
                if isinstance(key_expr, String):
                    key = key_expr.value
                elif isinstance(key_expr, Ident):
                    key = key_expr.name
                else:
                    key = self._eval(key_expr, match_env)

                if key not in value:
                    return False
                if not self._match_pattern(val_pattern, value[key], match_env):
                    return False
            return True

        return False

    def _eval(self, node, env: Environment):
        t = type(node)
        # Handle statement types that may be produced by macro expansion in expression context
        if t in (IfStmt, WhileStmt, ForStmt, TryCatch, MatchStmt, ThrowStmt):
            self._exec(node, env)
            return None
        if t is Number:
            return node.value
        elif t is String:
            return node.value
        elif t is Bool:
            return node.value
        elif t is Ident:
            return env.get(node.name)
        elif t is BinOp:
            if node.op == "&&":
                left = self._eval(node.left, env)
                return self._eval(node.right, env) if self._truthy(left) else left
            if node.op == "||":
                left = self._eval(node.left, env)
                return left if self._truthy(left) else self._eval(node.right, env)
            return self._binop(node.op, self._eval(node.left, env), self._eval(node.right, env))
        elif t is UnaryOp:
            val = self._eval(node.right, env)
            if node.op == "-": return -val
            if node.op == "!": return not self._truthy(val)
        elif t is Call:
            fn   = env.get(node.name)
            args = [self._eval(arg, env) for arg in node.args]
            return self._call(fn, args)
        elif t is Null:
            return None
        elif t is DictLiteral:
            return {self._eval(k, env): self._eval(v, env) for k, v in node.pairs}
        elif t is ListLiteral:
            return [self._eval(e, env) for e in node.elements]
        elif t is IndexGet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            return self._index_get(obj, idx)
        elif t is IndexSet:
            obj = self._eval(node.obj, env)
            idx = self._eval(node.index, env)
            val = self._eval(node.value, env)
            return self._index_set(obj, idx, val)
        elif t is GetAttr:
            obj = self._eval(node.obj, env)
            return self._get_attr(obj, node.attr)
        elif t is SetAttr:
            obj = self._eval(node.obj, env)
            val = self._eval(node.value, env)
            if isinstance(obj, Instance):
                obj.fields[node.attr] = val
            elif isinstance(obj, dict):
                obj[node.attr] = val
            else:
                raise RuntimeError_("Can only set attributes on class instances or dicts")
            return val
        elif t is MethodCall:
            obj  = self._eval(node.obj, env)
            args = [self._eval(a, env) for a in node.args]
            return self._call_method(obj, node.method, args)
        elif t is CallExpr:
            fn   = self._eval(node.callee, env)
            args = [self._eval(a, env) for a in node.args]
            return self._call(fn, args)
        elif t is AnonFn:
            return Function("<anon>", node.params, node.body, env, node.variadic)
        elif t is AwaitExpr:
            expr_val = self._eval(node.expr, env)
            return self._await_value(expr_val)
        elif t is TemplateStr:
            parts = []
            for part in node.parts:
                if isinstance(part, str):
                    parts.append(part)
                else:
                    parts.append(self._display(self._eval(part, env)))
            return "".join(parts)
        else:
            raise RuntimeError_(f"Unknown expression: {type(node).__name__}")

    def _await_value(self, aw):
        """Await an awaitable (coroutine or async function result)."""
        if asyncio.iscoroutine(aw):
            loop = self._get_or_create_event_loop([])
            return loop.run_until_complete(aw)
        if asyncio.isfuture(aw):
            loop = self._get_or_create_event_loop([])
            return loop.run_until_complete(aw)
        if hasattr(aw, '__await__'):
            return aw.__await__()
        return aw

    def _binop(self, op: str, left, right):
        line = self._current_line
        if op == "+":
            if isinstance(left, str) or isinstance(right, str):
                return str(left) + str(right)
            return left + right
        if op == "-":  return left - right
        if op == "*":  return left * right
        if op == "/":
            if right == 0:
                raise RuntimeError_(f"Cannot divide by zero", stack_trace=self._stack_trace)
            return left / right
        if op == "==": return left == right
        if op == "!=": return left != right
        if op == "<":  return left < right
        if op == ">":  return left > right
        if op == "<=": return left <= right
        if op == ">=": return left >= right
        if op == "&&": return right if self._truthy(left) else left
        if op == "||": return left  if self._truthy(left) else right
        if op == "//":
            if right == 0: raise RuntimeError_(f"Cannot divide by zero (integer division)", stack_trace=self._stack_trace)
            return float(int(left // right))
        if op == "%":
            if right == 0: raise RuntimeError_(f"Cannot use modulo with zero", stack_trace=self._stack_trace)
            return float(left % right)
        raise RuntimeError_(f"Unknown operator: '{op}'")

    def _lookup_method(self, klass: Klass, name: str):
        k = klass
        while k is not None:
            if name in k.methods:
                return k.methods[name]
            k = k.parent
        return None

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._str_method(obj, attr)
        if isinstance(obj, dict):
            if attr in obj:
                return obj[attr]
            raise RuntimeError_(f"Key '{attr}' not found in dict")
        raise RuntimeError_(f"Cannot get attribute '{attr}' on {self._builtin_type([obj])}")

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, Instance):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_method(fn, obj, args)
        if isinstance(obj, BoundSuper):
            fn = self._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_method(fn, obj.instance, args, super_klass=obj.klass.parent)
        if isinstance(obj, str):
            return self._call_str_method(obj, method, args)
        if isinstance(obj, list):
            return self._call_list_method(obj, method, args)
        if isinstance(obj, dict):
            fn = obj.get(method)
            if fn is None:
                raise RuntimeError_(f"Module has no function '{method}'")
            return self._call(fn, args)
        raise RuntimeError_(f"Cannot call method on {self._builtin_type([obj])}")

    def _invoke_method(self, fn, instance, args: list, super_klass=None, kwargs: dict = None):
        if kwargs is None:
            kwargs = {}
        method_name = getattr(fn, 'name', '<method>')
        self._stack_trace.push(method_name, self._current_line)
        try:
            call_env = Environment(parent=fn.closure)
            call_env.define("self", instance)
            if super_klass is not None:
                call_env.define("super", BoundSuper(super_klass, instance))
            elif isinstance(instance, Instance) and instance.klass.parent:
                call_env.define("super", BoundSuper(instance.klass.parent, instance))
            # Bind parameters with defaults
            self._bind_params(fn, args, kwargs, call_env, method_name)
            try:
                for stmt in fn.body:
                    self._exec(stmt, call_env)
            except ReturnSignal as r:
                return r.value
            return None
        finally:
            self._stack_trace.pop()

    def _call(self, fn, args: list, kwargs: dict = None):
        if kwargs is None:
            kwargs = {}
        if callable(fn):
            return fn(args)
        if isinstance(fn, Klass):
            instance = Instance(fn)
            init = self._lookup_method(fn, "init")
            if init:
                self._stack_trace.push(fn.name + ".init", self._current_line)
                try:
                    call_env = Environment(parent=init.closure)
                    call_env.define("self", instance)
                    if fn.parent:
                        call_env.define("super", BoundSuper(fn.parent, instance))
                    self._bind_params(init, args, kwargs, call_env, fn.name + ".init")
                    try:
                        for stmt in init.body:
                            self._exec(stmt, call_env)
                    except ReturnSignal:
                        pass
                finally:
                    self._stack_trace.pop()
            return instance
        if not isinstance(fn, Function):
            raise RuntimeError_(f"'{fn}' is not a callable function", stack_trace=self._stack_trace)
        self._stack_trace.push(fn.name, self._current_line)
        try:
            call_env = Environment(parent=fn.closure)
            self._bind_params(fn, args, kwargs, call_env, fn.name)
            try:
                for stmt in fn.body:
                    self._exec(stmt, call_env)
            except ReturnSignal as r:
                return r.value
            return None
        finally:
            self._stack_trace.pop()

    def _bind_params(self, fn, args: list, kwargs: dict, call_env: Environment, fn_name: str):
        """Bind parameters to the function environment, handling variadic args."""
        if hasattr(fn, 'variadic'):
            v = fn.variadic
            if not isinstance(v, tuple) or len(v) != 2:
                v = (None, None)
        else:
            v = (None, None)
        args_name, kwargs_name = v
        params = fn.params
        num_params = len(params)
        num_args = len(args)

        # Count required params (those without defaults)
        required_count = sum(1 for p in params if p[1] is None)

        # Check if we have enough args
        if num_args < required_count:
            raise RuntimeError_(f"Function '{fn_name}' takes at least {required_count} arguments but {num_args} were provided", stack_trace=self._stack_trace)

        # Calculate how many args go to regular params vs *args
        if args_name:
            # With *args, we can have more args than params
            regular_args_count = min(num_args, num_params)
        else:
            # Without *args, args must exactly match params (or be covered by defaults)
            if num_args > num_params:
                raise RuntimeError_(f"Function '{fn_name}' takes {num_params} arguments but {num_args} were provided", stack_trace=self._stack_trace)
            regular_args_count = num_args

        # Bind regular positional args
        for i in range(regular_args_count):
            param_name, default = params[i]
            call_env.define(param_name, args[i])

        # Handle remaining positional args -> *args
        if args_name:
            extra_args = args[regular_args_count:]
            call_env.define(args_name, extra_args)

        # Bind remaining params with defaults
        for i in range(regular_args_count, num_params):
            param_name, default = params[i]
            call_env.define(param_name, default)

        # Handle **kwargs
        if kwargs_name:
            call_env.define(kwargs_name, kwargs)
        elif kwargs:
            raise RuntimeError_(f"Function '{fn_name}' does not accept keyword arguments", stack_trace=self._stack_trace)

    def _truthy(self, val) -> bool:
        if val is None or val is False:
            return False
        if isinstance(val, (int, float)) and val == 0:
            return False
        if isinstance(val, str) and val == "":
            return False
        return True

    def _check_type(self, value, type_hint: str, name: str):
        actual = self._builtin_type([value])
        if type_hint == "int":
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise RuntimeError_(f"Variable '{name}' must be of type 'int' but got '{actual}'", stack_trace=self._stack_trace)
            return int(value) if isinstance(value, float) else value
        if type_hint == "float":
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise RuntimeError_(f"Variable '{name}' must be of type 'float' but got '{actual}'", stack_trace=self._stack_trace)
            return float(value)
        if type_hint == "str":
            if not isinstance(value, str):
                raise RuntimeError_(f"Variable '{name}' must be of type 'str' but got '{actual}'", stack_trace=self._stack_trace)
            return value
        if type_hint == "bool":
            if not isinstance(value, bool):
                raise RuntimeError_(f"Variable '{name}' must be of type 'bool' but got '{actual}'", stack_trace=self._stack_trace)
            return value
        if type_hint == "list":
            if not isinstance(value, list):
                raise RuntimeError_(f"Variable '{name}' must be of type 'list' but got '{actual}'", stack_trace=self._stack_trace)
            return value
        if type_hint == "dict":
            if not isinstance(value, dict):
                raise RuntimeError_(f"Variable '{name}' must be of type 'dict' but got '{actual}'", stack_trace=self._stack_trace)
            return value
        return value

    def _infer_type(self, value):
        if isinstance(value, bool):
            return "bool"
        if isinstance(value, float):
            return "float"
        if isinstance(value, int):
            return "int"
        if isinstance(value, str):
            return "str"
        if isinstance(value, list):
            return "list"
        if isinstance(value, dict):
            return "dict"
        return None

    def _builtin_print(self, args):
        print(*[self._display(a) for a in args])
        return None

    def _builtin_debug(self, args):
        import sys
        line = self._current_line
        loc = f"line {line}: " if line else ""
        parts = []
        for v in args:
            t = self._builtin_type([v])
            parts.append(f"{self._display(v)} ({t})")
        print(f"[debug] {loc}" + ", ".join(parts), file=sys.stderr)
        return args[0] if len(args) == 1 else args

    def _builtin_len(self, args):
        if len(args) != 1 or not isinstance(args[0], (str, list, dict)):
            raise RuntimeError_("len() takes a string, list, or dict")
        return float(len(args[0]))

    def _builtin_str(self, args):
        if len(args) != 1:
            raise RuntimeError_("str() takes 1 argument")
        return self._display(args[0])

    def _builtin_num(self, args):
        if len(args) != 1:
            raise RuntimeError_("num() takes 1 argument")
        try:
            return float(args[0])
        except (ValueError, TypeError):
            raise RuntimeError_(f"Cannot convert {args[0]!r} to number")

    def _builtin_type(self, args):
        if len(args) != 1:
            raise RuntimeError_("type() takes 1 argument")
        v = args[0]
        if isinstance(v, bool):     return "bool"
        if isinstance(v, float):    return "number"
        if isinstance(v, str):      return "string"
        if isinstance(v, list):     return "list"
        if isinstance(v, dict):     return "dict"
        if isinstance(v, Function): return "function"
        if isinstance(v, AsyncFunction): return "async_function"
        if isinstance(v, Klass):    return "class"
        if isinstance(v, Instance): return v.klass.name
        if v is None:               return "null"
        # VMFunction (from vm.py) and Python builtins
        if callable(v) or (hasattr(v, 'params') and hasattr(v, 'code')):
            return "function"
        return "unknown"

    def _builtin_is_number(self, args):
        if len(args) != 1:
            raise RuntimeError_("is_number() takes 1 argument")
        return isinstance(args[0], (int, float))

    def _builtin_is_string(self, args):
        if len(args) != 1:
            raise RuntimeError_("is_string() takes 1 argument")
        return isinstance(args[0], str)

    def _builtin_is_bool(self, args):
        if len(args) != 1:
            raise RuntimeError_("is_bool() takes 1 argument")
        return isinstance(args[0], bool)

    def _builtin_is_list(self, args):
        if len(args) != 1:
            raise RuntimeError_("is_list() takes 1 argument")
        return isinstance(args[0], list)

    def _builtin_is_dict(self, args):
        if len(args) != 1:
            raise RuntimeError_("is_dict() takes 1 argument")
        return isinstance(args[0], dict)

    def _builtin_cast(self, args):
        if len(args) != 2:
            raise RuntimeError_("cast() takes 2 arguments: cast(value, type)")
        value, type_name = args
        type_name = str(type_name)
        if type_name == "int":
            return int(value)
        if type_name == "float":
            return float(value)
        if type_name == "str":
            return str(value)
        if type_name == "bool":
            return bool(value)
        if type_name == "list":
            if isinstance(value, list):
                return value
            return list(value)
        if type_name == "dict":
            if isinstance(value, dict):
                return value
            return dict(value)
        raise RuntimeError_(f"Unknown type '{type_name}' in cast()")

    def _index_get(self, obj, idx):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            if key not in obj:
                raise RuntimeError_(f"Key {key!r} not found in dictionary. Available keys: {list(obj.keys())}", stack_trace=self._stack_trace)
            return obj[key]
        if not isinstance(obj, (list, str)):
            raise RuntimeError_(f"Cannot index into value of type '{type(obj).__name__}'. Expected list or string, got {self._builtin_type([obj])}", stack_trace=self._stack_trace)
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} is out of bounds for {type(obj).__name__} of length {len(obj)}. Valid range: 0 to {len(obj) - 1}", stack_trace=self._stack_trace)
        v = obj[i]
        return float(v) if isinstance(v, int) else v

    def _index_set(self, obj, idx, val):
        if isinstance(obj, dict):
            key = int(idx) if isinstance(idx, float) and idx == int(idx) else idx
            obj[key] = val
            return val
        if not isinstance(obj, list):
            raise RuntimeError_(f"Cannot assign to index on value of type '{type(obj).__name__}'. Expected list or dict", stack_trace=self._stack_trace)
        i = int(idx)
        if i < 0 or i >= len(obj):
            raise RuntimeError_(f"Index {i} is out of bounds for list of length {len(obj)}. Valid range: 0 to {len(obj) - 1}", stack_trace=self._stack_trace)
        obj[i] = val
        return val

    def _builtin_range(self, args):
        if len(args) == 1:
            start, stop, step = 0, int(args[0]), 1
        elif len(args) == 2:
            start, stop, step = int(args[0]), int(args[1]), 1
        elif len(args) == 3:
            start, stop, step = int(args[0]), int(args[1]), int(args[2])
        else:
            raise RuntimeError_("range() takes 1-3 arguments")
        return [float(i) for i in range(start, stop, step)]

    def _builtin_push(self, args):
        if len(args) != 2:
            raise RuntimeError_("push(list, value) takes 2 arguments")
        if not isinstance(args[0], list):
            raise RuntimeError_("push() first argument must be a list")
        args[0].append(args[1])
        return float(len(args[0]))

    def _builtin_pop(self, args):
        if len(args) != 1:
            raise RuntimeError_("pop(list) takes 1 argument")
        if not isinstance(args[0], list):
            raise RuntimeError_("pop() argument must be a list")
        if not args[0]:
            raise RuntimeError_("pop() on empty list")
        return args[0].pop()

    def _builtin_keys(self, args):
        if len(args) != 1 or not isinstance(args[0], dict):
            raise RuntimeError_("keys() takes a dict")
        return list(args[0].keys())

    def _builtin_has(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("has(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        return key in args[0]

    def _builtin_delete(self, args):
        if len(args) != 2 or not isinstance(args[0], dict):
            raise RuntimeError_("delete(dict, key) takes a dict and a key")
        key = int(args[1]) if isinstance(args[1], float) and args[1] == int(args[1]) else args[1]
        if key not in args[0]:
            raise RuntimeError_(f"Key {key!r} not found")
        del args[0][key]
        return None

    def _str_method(self, s: str, attr: str):
        methods = {
            "upper", "lower", "trim", "split",
            "contains", "starts_with", "ends_with", "replace", "index_of",
        }
        if attr not in methods:
            raise RuntimeError_(f"string has no attribute '{attr}'")
        def _bound(args, _s=s, _attr=attr):
            return self._call_str_method(_s, _attr, args)
        return _bound

    def _call_str_method(self, s: str, method: str, args: list):
        if method == "upper":     return s.upper()
        if method == "lower":     return s.lower()
        if method == "trim":      return s.strip()
        if method == "split":
            sep = args[0] if args else None
            return s.split(sep) if sep else s.split()
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in s
        if method == "starts_with":
            if len(args) != 1: raise RuntimeError_("starts_with() takes 1 argument")
            return s.startswith(args[0])
        if method == "ends_with":
            if len(args) != 1: raise RuntimeError_("ends_with() takes 1 argument")
            return s.endswith(args[0])
        if method == "replace":
            if len(args) != 2: raise RuntimeError_("replace() takes 2 arguments")
            return s.replace(args[0], args[1])
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            return float(s.find(args[0]))
        raise RuntimeError_(f"string has no method '{method}'")

    def _call_list_method(self, lst: list, method: str, args: list):
        if method == "contains":
            if len(args) != 1: raise RuntimeError_("contains() takes 1 argument")
            return args[0] in lst
        if method == "index_of":
            if len(args) != 1: raise RuntimeError_("index_of() takes 1 argument")
            try:
                return float(lst.index(args[0]))
            except ValueError:
                return -1.0
        if method == "join":
            sep = args[0] if args else ""
            return sep.join(self._display(v) for v in lst)
        if method == "reverse":
            lst.reverse()
            return None
        if method == "slice":
            start = int(args[0]) if len(args) > 0 else 0
            stop  = int(args[1]) if len(args) > 1 else len(lst)
            return lst[start:stop]
        raise RuntimeError_(f"list has no method '{method}'")

    def _builtin_floor(self, args):
        if len(args) != 1: raise RuntimeError_("floor() takes 1 argument")
        import math
        return float(math.floor(args[0]))

    def _builtin_ceil(self, args):
        if len(args) != 1: raise RuntimeError_("ceil() takes 1 argument")
        import math
        return float(math.ceil(args[0]))

    def _builtin_round(self, args):
        if len(args) not in (1, 2): raise RuntimeError_("round() takes 1-2 arguments")
        ndigits = int(args[1]) if len(args) == 2 else 0
        return float(round(args[0], ndigits))

    def _builtin_abs(self, args):
        if len(args) != 1: raise RuntimeError_("abs() takes 1 argument")
        return float(abs(args[0]))

    def _import(self, path: str, alias: str | None, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        mo_path = path if path.endswith('.mo') else path + '.mo'
        base = getattr(self, '_base_dir', '.')
        full = os.path.join(base, mo_path)
        if not os.path.exists(full):
            pkg_fallback = os.path.join(os.path.dirname(__file__), mo_path)
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                user_pkg = os.path.join(os.path.expanduser("~/.mo/packages"), mo_path)
                if os.path.exists(user_pkg):
                    full = user_pkg
                else:
                    raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
        except (LexError, ParseError) as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        self.run(ast, mod_env)
        if alias:
            # Build namespace dict with all exported names
            ns = {}
            for name, val in mod_env.vars.items():
                ns[name] = val
            env.define(alias, ns)
        else:
            for name, val in mod_env.vars.items():
                env.define(name, val)

    def _builtin_input(self, args):
        prompt = self._display(args[0]) if args else ""
        try:
            return input(prompt)
        except EOFError:
            return ""

    def _display(self, val) -> str:
        if val is True:  return "true"
        if val is False: return "false"
        if val is None:  return "null"
        if isinstance(val, list):
            return "[" + ", ".join(self._display(v) for v in val) + "]"
        if isinstance(val, dict):
            pairs = ", ".join(f"{self._display(k)}: {self._display(v)}" for k, v in val.items())
            return "{" + pairs + "}"
        if isinstance(val, Instance):
            fields = ", ".join(f"{k}: {self._display(v)}" for k, v in val.fields.items())
            return f"<{val.klass.name} {{{fields}}}>"
        if isinstance(val, Klass):
            return f"<class {val.name}>"
        if isinstance(val, float):
            return str(int(val)) if val == int(val) else str(val)
        return str(val)

    # ── json ──────────────────────────────────────────────────────────────────

    def _builtin_json_parse(self, args):
        if len(args) != 1: raise RuntimeError_("json_parse(str) takes 1 argument")
        import json
        try:
            return json.loads(args[0])
        except Exception as e:
            raise RuntimeError_(f"JSON parse error: {e}")

    def _builtin_json_stringify(self, args):
        if len(args) not in (1, 2): raise RuntimeError_("json_stringify(val, indent?) takes 1-2 arguments")
        import json
        indent = int(args[1]) if len(args) == 2 else None
        def _convert(v):
            if isinstance(v, bool): return v
            if isinstance(v, float): return int(v) if v == int(v) else v
            if isinstance(v, list): return [_convert(x) for x in v]
            if isinstance(v, dict): return {k: _convert(val) for k, val in v.items()}
            return v
        return json.dumps(_convert(args[0]), indent=indent, ensure_ascii=False)

    # ── os ────────────────────────────────────────────────────────────────────

    def _builtin_os_name(self, args):
        import sys
        p = sys.platform
        if p == "darwin": return "mac"
        if p == "win32":  return "windows"
        return "linux"

    def _builtin_os_cwd(self, args):
        import os
        return os.getcwd()

    def _builtin_os_home(self, args):
        import os
        return os.path.expanduser("~")

    def _builtin_os_env(self, args):
        if len(args) != 1: raise RuntimeError_("os_env(key) takes 1 argument")
        import os
        return os.environ.get(args[0], "")

    def _builtin_os_cpus(self, args):
        import os
        return float(os.cpu_count() or 1)

    # ── path ──────────────────────────────────────────────────────────────────

    def _builtin_path_join(self, args):
        if not args: raise RuntimeError_("path_join() needs at least 1 argument")
        import os.path
        return os.path.join(*args)

    def _builtin_path_dir(self, args):
        if len(args) != 1: raise RuntimeError_("path_dir(path) takes 1 argument")
        import os.path
        return os.path.dirname(args[0])

    def _builtin_path_base(self, args):
        if len(args) != 1: raise RuntimeError_("path_base(path) takes 1 argument")
        import os.path
        return os.path.basename(args[0])

    def _builtin_path_ext(self, args):
        if len(args) != 1: raise RuntimeError_("path_ext(path) takes 1 argument")
        import os.path
        return os.path.splitext(args[0])[1]

    def _builtin_path_abs(self, args):
        if len(args) != 1: raise RuntimeError_("path_abs(path) takes 1 argument")
        import os.path
        return os.path.abspath(args[0])

    # ── url ───────────────────────────────────────────────────────────────────

    def _builtin_url_parse(self, args):
        if len(args) != 1: raise RuntimeError_("url_parse(url) takes 1 argument")
        import urllib.parse
        p = urllib.parse.urlparse(args[0])
        query = dict(urllib.parse.parse_qsl(p.query))
        return {"protocol": p.scheme, "host": p.netloc,
                "path": p.path, "query": query, "hash": p.fragment}

    def _builtin_url_encode(self, args):
        if len(args) != 1: raise RuntimeError_("url_encode(dict) takes 1 argument")
        import urllib.parse
        if not isinstance(args[0], dict):
            raise RuntimeError_("url_encode() expects a dict")
        return urllib.parse.urlencode(args[0])

    def _builtin_url_decode(self, args):
        if len(args) != 1: raise RuntimeError_("url_decode(str) takes 1 argument")
        import urllib.parse
        return dict(urllib.parse.parse_qsl(args[0]))

    def _builtin_url_build(self, args):
        if len(args) != 1: raise RuntimeError_("url_build(params) takes 1 argument")
        import urllib.parse
        if not isinstance(args[0], dict): raise RuntimeError_("url_build() expects a dict")
        return urllib.parse.urlencode({k: str(v) for k, v in args[0].items()})

    # ── process ───────────────────────────────────────────────────────────────

    def _builtin_proc_args(self, args):
        import sys
        return sys.argv[1:]

    def _builtin_proc_pid(self, args):
        import os
        return float(os.getpid())

    def _builtin_proc_exit(self, args):
        import sys
        code = int(args[0]) if args else 0
        sys.exit(code)

    def _builtin_proc_env(self, args):
        if len(args) != 1: raise RuntimeError_("proc_env(key) takes 1 argument")
        import os
        return os.environ.get(args[0], "")

    # ── crypto ────────────────────────────────────────────────────────────────

    def _builtin_crypto_md5(self, args):
        if len(args) != 1: raise RuntimeError_("md5(str) takes 1 argument")
        import hashlib
        return hashlib.md5(str(args[0]).encode()).hexdigest()

    def _builtin_crypto_sha1(self, args):
        if len(args) != 1: raise RuntimeError_("sha1(str) takes 1 argument")
        import hashlib
        return hashlib.sha1(str(args[0]).encode()).hexdigest()

    def _builtin_crypto_sha256(self, args):
        if len(args) != 1: raise RuntimeError_("sha256(str) takes 1 argument")
        import hashlib
        return hashlib.sha256(str(args[0]).encode()).hexdigest()

    # ── http fetch ────────────────────────────────────────────────────────────

    def _builtin_http_fetch(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("fetch(url, options?) takes 1-2 arguments")
        import urllib.request, urllib.error, json as _json
        url     = args[0]
        options = args[1] if len(args) == 2 else {}
        method  = options.get("method", "GET") if isinstance(options, dict) else "GET"
        body    = options.get("body", None)    if isinstance(options, dict) else None
        headers = options.get("headers", {})   if isinstance(options, dict) else {}
        body_bytes = body.encode() if isinstance(body, str) else None
        req = urllib.request.Request(url, data=body_bytes, method=method)
        for k, v in (headers.items() if isinstance(headers, dict) else {}.items()):
            req.add_header(k, v)
        try:
            with urllib.request.urlopen(req) as resp:
                text = resp.read().decode('utf-8', errors='replace')
                return {"status": float(resp.status), "body": text,
                        "ok": resp.status < 400}
        except urllib.error.HTTPError as e:
            text = e.read().decode('utf-8', errors='replace')
            return {"status": float(e.code), "body": text, "ok": False}
        except Exception as e:
            raise RuntimeError_(f"fetch error: {e}")

    def _builtin_http_get(self, args):
        if len(args) < 1: raise RuntimeError_("http_get(url) takes 1 argument")
        return self._builtin_http_fetch([args[0], {"method": "GET"}])

    def _builtin_http_post(self, args):
        if len(args) < 2: raise RuntimeError_("http_post(url, body) takes 2 arguments")
        ct = args[2] if len(args) > 2 else "application/json"
        return self._builtin_http_fetch([args[0], {"method": "POST", "body": args[1],
                                                    "headers": {"Content-Type": ct}}])

    # ── time ──────────────────────────────────────────────────────────────────

    def _builtin_time_now(self, args):
        import time
        return float(int(time.time()))

    def _builtin_time_ms(self, args):
        import time
        return float(int(time.time() * 1000))

    def _builtin_time_sleep(self, args):
        if len(args) != 1: raise RuntimeError_("time_sleep(seconds) takes 1 argument")
        import time
        time.sleep(args[0])
        return None

    def _builtin_time_format(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("time_format(timestamp, fmt?) takes 1-2 arguments")
        import time
        ts  = args[0]
        fmt = args[1] if len(args) == 2 else "%Y-%m-%d %H:%M:%S"
        return time.strftime(fmt, time.localtime(int(ts)))

    # ── random ────────────────────────────────────────────────────────────────

    def _builtin_random_int(self, args):
        if len(args) != 2: raise RuntimeError_("random_int(min, max) takes 2 arguments")
        import random
        return float(random.randint(int(args[0]), int(args[1])))

    def _builtin_random_float(self, args):
        import random
        return random.random()

    def _builtin_random_pick(self, args):
        if len(args) != 1: raise RuntimeError_("random_pick(list) takes 1 argument")
        if not isinstance(args[0], list): raise RuntimeError_("random_pick() expects a list")
        if not args[0]: raise RuntimeError_("random_pick() on empty list")
        import random
        return random.choice(args[0])

    # ── file ──────────────────────────────────────────────────────────────────

    def _builtin_file_read(self, args):
        if len(args) != 1: raise RuntimeError_("read(path) takes 1 argument")
        try:
            return open(args[0], encoding='utf-8').read()
        except FileNotFoundError:
            raise RuntimeError_(f"File not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))

    def _builtin_file_write(self, args):
        if len(args) != 2: raise RuntimeError_("write(path, content) takes 2 arguments")
        try:
            open(args[0], 'w', encoding='utf-8').write(self._display(args[1]))
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_append(self, args):
        if len(args) != 2: raise RuntimeError_("append(path, content) takes 2 arguments")
        try:
            open(args[0], 'a', encoding='utf-8').write(self._display(args[1]))
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_exists(self, args):
        if len(args) != 1: raise RuntimeError_("exists(path) takes 1 argument")
        import os
        return os.path.exists(args[0])

    def _builtin_file_delete(self, args):
        if len(args) != 1: raise RuntimeError_("delete_file(path) takes 1 argument")
        import os
        try:
            os.remove(args[0])
        except FileNotFoundError:
            raise RuntimeError_(f"File not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_file_list(self, args):
        if len(args) != 1: raise RuntimeError_("list_dir(path) takes 1 argument")
        import os
        try:
            return sorted(os.listdir(args[0]))
        except FileNotFoundError:
            raise RuntimeError_(f"Directory not found: '{args[0]}'")
        except OSError as e:
            raise RuntimeError_(str(e))

    def _builtin_file_is_dir(self, args):
        if len(args) != 1: raise RuntimeError_("is_dir(path) takes 1 argument")
        import os
        return os.path.isdir(args[0])

    def _builtin_file_mkdir(self, args):
        if len(args) != 1: raise RuntimeError_("mkdir(path) takes 1 argument")
        import os
        try:
            os.makedirs(args[0], exist_ok=True)
        except OSError as e:
            raise RuntimeError_(str(e))
        return None

    def _builtin_http_serve(self, args):
        if len(args) != 2:
            raise RuntimeError_("__http_serve__(port, handler) takes 2 arguments")
        import http.server
        import urllib.parse
        import json as _json

        port       = int(args[0])
        handler_fn = args[1]
        interp     = self
        vm         = getattr(self, '_vm', None)

        def call_handler(fn, req):
            # VMFunction has .code, .params, .closure attributes
            if vm and hasattr(fn, 'code') and hasattr(fn, 'closure'):
                return vm._invoke_vm(fn, None, [req])
            return interp._call(fn, [req])

        class MoHandler(http.server.BaseHTTPRequestHandler):
            def handle_request(self, method):
                parsed = urllib.parse.urlparse(self.path)
                query  = dict(urllib.parse.parse_qsl(parsed.query))
                length = int(self.headers.get('Content-Length', 0))
                body   = self.rfile.read(length).decode('utf-8') if length else ""
                req = {"method": method, "path": parsed.path,
                       "query": query, "body": body}
                try:
                    resp = call_handler(handler_fn, req)
                except Exception as e:
                    resp = {"status": 500.0, "body": str(e), "type": "text/plain"}

                if resp is None:
                    status, body_str, ctype = 200, "", "text/plain"
                elif isinstance(resp, dict):
                    status   = int(resp.get("status", 200.0))
                    body_val = resp.get("body", "")
                    ctype    = resp.get("type", "text/plain")
                    if isinstance(body_val, (dict, list)):
                        body_str = _json.dumps(body_val)
                        ctype    = "application/json"
                    else:
                        body_str = interp._display(body_val)
                else:
                    status, body_str, ctype = 200, interp._display(resp), "text/plain"

                raw = body_str.encode('utf-8')
                self.send_response(status)
                self.send_header('Content-Type', f'{ctype}; charset=utf-8')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):    self.handle_request("GET")
            def do_POST(self):   self.handle_request("POST")
            def do_PUT(self):    self.handle_request("PUT")
            def do_DELETE(self): self.handle_request("DELETE")

            def log_message(self, fmt, *a):
                print(f"  {self.command} {self.path}  →  {a[1]}")

        server = http.server.HTTPServer(('', port), MoHandler)
        print(f"Mo server  http://localhost:{port}  (Ctrl+C to stop)")
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nServer stopped.")

    def _builtin_http_serve_bg(self, args):
        """Non-blocking serve: runs HTTP server in a background thread, returns immediately."""
        import threading
        t = threading.Thread(target=lambda: self._builtin_http_serve(args), daemon=True)
        t.start()
        return None

    # ── net ───────────────────────────────────────────────────────────────────

    def _builtin_net_listen(self, args):
        if len(args) != 2:
            raise RuntimeError_("net_listen(port, handler) takes 2 arguments")
        import socket, threading
        port       = int(args[0])
        handler_fn = args[1]
        interp     = self
        vm         = getattr(self, '_vm', None)

        def call_handler(conn_dict):
            if vm and hasattr(handler_fn, 'code'):
                vm._invoke_vm(handler_fn, None, [conn_dict])
            else:
                interp._call(handler_fn, [conn_dict])

        def client_thread(sock, addr):
            conn = {"_sock": sock, "addr": f"{addr[0]}:{addr[1]}"}
            try:
                call_handler(conn)
            except Exception as e:
                print(f"[net] handler error: {e}")
            finally:
                try: sock.close()
                except: pass

        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        srv.bind(('', port))
        srv.listen(64)
        print(f"Mo TCP server  0.0.0.0:{port}  (Ctrl+C to stop)")
        try:
            while True:
                sock, addr = srv.accept()
                threading.Thread(target=client_thread, args=(sock, addr), daemon=True).start()
        except KeyboardInterrupt:
            print("\nServer stopped.")
        finally:
            srv.close()

    def _builtin_net_connect(self, args):
        if len(args) not in (2, 3):
            raise RuntimeError_("net_connect(host, port) takes 2 arguments")
        import socket
        host    = str(args[0])
        port    = int(args[1])
        timeout = float(args[2]) if len(args) == 3 else 10.0
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        try:
            sock.connect((host, port))
        except Exception as e:
            raise RuntimeError_(f"net_connect failed: {e}")
        return {"_sock": sock, "addr": f"{host}:{port}"}

    def _builtin_net_send(self, args):
        if len(args) != 2:
            raise RuntimeError_("net_send(conn, data) takes 2 arguments")
        conn = args[0]
        if not isinstance(conn, dict) or "_sock" not in conn:
            raise RuntimeError_("net_send: invalid connection")
        data = self._display(args[1])
        try:
            conn["_sock"].sendall(data.encode("utf-8"))
        except Exception as e:
            raise RuntimeError_(f"net_send failed: {e}")
        return None

    def _builtin_net_recv(self, args):
        if len(args) not in (1, 2):
            raise RuntimeError_("net_recv(conn [, size]) takes 1-2 arguments")
        conn = args[0]
        if not isinstance(conn, dict) or "_sock" not in conn:
            raise RuntimeError_("net_recv: invalid connection")
        size = int(args[1]) if len(args) == 2 else 4096
        try:
            data = conn["_sock"].recv(size)
            return data.decode("utf-8") if data else ""
        except Exception as e:
            raise RuntimeError_(f"net_recv failed: {e}")

    def _builtin_net_close(self, args):
        if len(args) != 1:
            raise RuntimeError_("net_close(conn) takes 1 argument")
        conn = args[0]
        if isinstance(conn, dict) and "_sock" in conn:
            try: conn["_sock"].close()
            except: pass
        return None

    def _builtin_net_addr(self, args):
        if len(args) != 1:
            raise RuntimeError_("net_addr(conn) takes 1 argument")
        conn = args[0]
        if not isinstance(conn, dict):
            raise RuntimeError_("net_addr: invalid connection")
        return conn.get("addr", "")

    # ── regex ───────────────────────────────────────────────────────────────────

    def _builtin_regex_match(self, args):
        if len(args) != 2:
            raise RuntimeError_("regex_match(pattern, text) takes 2 arguments")
        import re
        m = re.search(args[0], args[1])
        if m:
            return m.group(0)
        return None

    def _builtin_regex_replace(self, args):
        if len(args) != 3:
            raise RuntimeError_("regex_replace(pattern, text, replacement) takes 3 arguments")
        import re
        return re.sub(args[0], args[2], args[1])

    def _builtin_regex_split(self, args):
        if len(args) != 2:
            raise RuntimeError_("regex_split(pattern, text) takes 2 arguments")
        import re
        return re.split(args[0], args[1])

    def _builtin_regex_search(self, args):
        if len(args) != 2:
            raise RuntimeError_("regex_search(pattern, text) takes 2 arguments")
        import re
        m = re.search(args[0], args[1])
        return m.group(0) if m else None

    def _builtin_regex_findall(self, args):
        if len(args) != 2:
            raise RuntimeError_("regex_findall(pattern, text) takes 2 arguments")
        import re
        return re.findall(args[0], args[1])

    # ── sqlite ────────────────────────────────────────────────────────────────────

    def _builtin_sqlite_open(self, args):
        if len(args) != 1:
            raise RuntimeError_("sqlite_open(path) takes 1 argument")
        import sqlite3
        try:
            conn = sqlite3.connect(args[0])
            return conn
        except Exception as e:
            raise RuntimeError_(f"sqlite_open failed: {e}")

    def _builtin_sqlite_exec(self, args):
        if len(args) != 2:
            raise RuntimeError_("sqlite_exec(db, sql) takes 2 arguments")
        db = args[0]
        if not hasattr(db, 'execute'):
            raise RuntimeError_("sqlite_exec: invalid database connection")
        try:
            cursor = db.execute(args[1])
            if cursor.description:
                rows = [list(row) for row in cursor.fetchall()]
                return rows
            db.commit()
            return None
        except Exception as e:
            raise RuntimeError_(f"sqlite_exec failed: {e}")

    def _builtin_sqlite_close(self, args):
        if len(args) != 1:
            raise RuntimeError_("sqlite_close(db) takes 1 argument")
        db = args[0]
        if hasattr(db, 'close'):
            db.close()
        return None

    # ── yaml ────────────────────────────────────────────────────────────────────

    def _builtin_yaml_parse(self, args):
        if len(args) != 1:
            raise RuntimeError_("yaml_parse(str) takes 1 argument")
        import yaml
        try:
            return yaml.safe_load(args[0])
        except Exception as e:
            raise RuntimeError_(f"YAML parse error: {e}")

    def _builtin_yaml_stringify(self, args):
        if len(args) != 1:
            raise RuntimeError_("yaml_stringify(val) takes 1 argument")
        import yaml
        return yaml.dump(args[0], default_flow_style=False, allow_unicode=True)

    # ── xml ────────────────────────────────────────────────────────────────────

    def _builtin_xml_parse(self, args):
        if len(args) != 1:
            raise RuntimeError_("xml_parse(str) takes 1 argument")
        import xml.etree.ElementTree as ET
        try:
            return ET.fromstring(args[0])
        except Exception as e:
            raise RuntimeError_(f"XML parse error: {e}")

    def _builtin_xml_to_string(self, args):
        if len(args) != 1:
            raise RuntimeError_("xml_to_string(elem) takes 1 argument")
        import xml.etree.ElementTree as ET
        return ET.tostring(args[0], encoding='unicode')

    # ── csv ────────────────────────────────────────────────────────────────────

    def _builtin_csv_read(self, args):
        if len(args) != 1:
            raise RuntimeError_("csv_read(path) takes 1 argument")
        import csv
        try:
            with open(args[0], newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                return list(reader)
        except FileNotFoundError:
            raise RuntimeError_(f"File not found: '{args[0]}'")
        except Exception as e:
            raise RuntimeError_(f"CSV read error: {e}")

    def _builtin_csv_write(self, args):
        if len(args) != 2:
            raise RuntimeError_("csv_write(path, data) takes 2 arguments")
        import csv
        data = args[1]
        if not isinstance(data, list):
            raise RuntimeError_("csv_write: data must be a list")
        if not data:
            return None
        try:
            with open(args[0], 'w', newline='', encoding='utf-8') as f:
                fieldnames = list(data[0].keys()) if isinstance(data[0], dict) else []
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(data)
        except Exception as e:
            raise RuntimeError_(f"CSV write error: {e}")
        return None

    def _builtin_substr(self, args):
        if len(args) < 2:
            raise RuntimeError_("substr(s, start, end) takes 2-3 arguments")
        s = args[0]
        start = int(args[1])
        end = int(args[2]) if len(args) > 2 else len(s)
        return s[start:end]

    def _builtin_slice(self, args):
        if len(args) < 2:
            raise RuntimeError_("__slice__(obj, start[, stop]) takes 2-3 arguments")
        obj = args[0]
        start = int(args[1])
        if len(args) > 2:
            return obj[start:int(args[2])]
        return obj[start:]

    def _builtin_split(self, args):
        if len(args) < 1: raise RuntimeError_("split(s, sep) takes 1-2 arguments")
        s = args[0]
        sep = args[1] if len(args) > 1 else None
        if not isinstance(s, str): raise RuntimeError_("split: first argument must be a string")
        return s.split(sep) if sep is not None else s.split()

    def _builtin_trim(self, args):
        if len(args) != 1: raise RuntimeError_("trim(s) takes 1 argument")
        return args[0].strip() if isinstance(args[0], str) else str(args[0]).strip()

    def _builtin_contains(self, args):
        if len(args) != 2: raise RuntimeError_("contains(s, sub) takes 2 arguments")
        return args[1] in args[0]

    def _builtin_replace(self, args):
        if len(args) != 3: raise RuntimeError_("replace(s, old, new) takes 3 arguments")
        return args[0].replace(args[1], args[2])

    def _builtin_starts_with(self, args):
        if len(args) != 2: raise RuntimeError_("startsWith(s, prefix) takes 2 arguments")
        return args[0].startswith(args[1])

    def _builtin_ends_with(self, args):
        if len(args) != 2: raise RuntimeError_("endsWith(s, suffix) takes 2 arguments")
        return args[0].endswith(args[1])

    def _builtin_index_of(self, args):
        if len(args) != 2: raise RuntimeError_("indexOf(s, sub) takes 2 arguments")
        return float(args[0].find(args[1]))

    def _builtin_join(self, args):
        if len(args) != 2: raise RuntimeError_("join(list, sep) takes 2 arguments")
        return args[1].join(self._display(v) for v in args[0])

    def _builtin_csv_parse(self, args):
        if len(args) != 1:
            raise RuntimeError_("csvParse(text) takes 1 argument")
        import csv, io
        reader = csv.reader(io.StringIO(args[0]))
        return [list(row) for row in reader if row]

    def _builtin_csv_stringify(self, args):
        if len(args) != 1:
            raise RuntimeError_("csvStringify(data) takes 1 argument")
        import csv, io
        buf = io.StringIO()
        writer = csv.writer(buf)
        for row in args[0]:
            writer.writerow(row)
        return buf.getvalue()

    def _builtin_sqrt(self, args):
        import math
        if len(args) != 1: raise RuntimeError_("sqrt(x) takes 1 argument")
        return math.sqrt(args[0])

    def _builtin_pow(self, args):
        if len(args) != 2: raise RuntimeError_("pow(b, e) takes 2 arguments")
        return args[0] ** args[1]

    def _builtin_min(self, args):
        if len(args) != 2: raise RuntimeError_("min(a, b) takes 2 arguments")
        return args[0] if args[0] < args[1] else args[1]

    def _builtin_max(self, args):
        if len(args) != 2: raise RuntimeError_("max(a, b) takes 2 arguments")
        return args[0] if args[0] > args[1] else args[1]

    # ── async ───────────────────────────────────────────────────────────────────

    def _get_or_create_event_loop(self, args):
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        return loop

    def _builtin_async_fn(self, args):
        """Create an async function from a regular function."""
        if len(args) != 1:
            raise RuntimeError_("async_fn(fn) takes 1 argument")
        fn = args[0]
        if isinstance(fn, Function):
            return AsyncFunction(fn.name, fn.params, fn.body, fn.closure, fn.variadic)
        VMAsyncFunction = _get_vm_async_function()
        if isinstance(fn, VMAsyncFunction):
            return fn
        if hasattr(fn, 'params') and hasattr(fn, 'code'):
            variadic = getattr(fn, 'variadic', (None, None))
            return AsyncFunction(fn.name, fn.params, fn.code, fn.closure, variadic)
        if callable(fn):
            return fn
        raise RuntimeError_("async_fn expects a function")

    def _builtin_await(self, args):
        """Await a coroutine or awaitable."""
        if len(args) != 1:
            raise RuntimeError_("await_(awaitable) takes 1 argument")
        aw = args[0]
        if isinstance(aw, AsyncFunction):
            async def _run_async():
                interp = self
                call_env = Environment(parent=aw.closure)
                for param, arg in zip(aw.params, []):
                    call_env.define(param, arg)
                for stmt in aw.body:
                    interp._exec(stmt, call_env)
                return None
            loop = self._get_or_create_event_loop([])
            return loop.run_until_complete(_run_async())
        if asyncio.iscoroutine(aw):
            loop = self._get_or_create_event_loop([])
            return loop.run_until_complete(aw)
        return aw

    def _builtin_sleep_async(self, args):
        """Async sleep: sleep_async(ms) - non-blocking delay."""
        if len(args) != 1:
            raise RuntimeError_("sleep_async(ms) takes 1 argument")
        ms = args[0]
        async def _sleep():
            await asyncio.sleep(ms / 1000.0)
        return _sleep()

    def _builtin_run_async(self, args):
        """Run async function and await its result."""
        if len(args) != 1:
            raise RuntimeError_("run_async(async_fn) takes 1 argument")
        fn = args[0]
        if isinstance(fn, AsyncFunction):
            return self._call_async_fn(fn, [])
        VMAsyncFunction = _get_vm_async_function()
        if isinstance(fn, VMAsyncFunction):
            return self._call_async_vm_fn(fn, [])
        raise RuntimeError_("run_async expects an async function")

    def _call_async_fn(self, fn, args: list):
        async def _run_async():
            call_env = Environment(parent=fn.closure)
            for param, arg in zip(fn.params, args):
                call_env.define(param, arg)
            try:
                for stmt in fn.body:
                    self._exec(stmt, call_env)
            except ReturnSignal as rs:
                return rs.value
            return None
        loop = self._get_or_create_event_loop([])
        return loop.run_until_complete(_run_async())

    def _builtin_get_async_vm(self, args):
        """Get the global AsyncVM instance."""
        return get_async_vm()

    def _builtin_spawn(self, args):
        """spawn(fn, *args) - Spawn a new async task."""
        if len(args) < 1:
            raise RuntimeError_("spawn(fn) takes at least 1 argument")
        fn = args[0]
        fn_args = args[1:] if len(args) > 1 else ()
        vm = get_async_vm()
        task_id = vm.spawn(fn, *fn_args)
        return task_id

    def _builtin_send(self, args):
        """send(channel_name, value) - Send to a channel."""
        if len(args) != 2:
            raise RuntimeError_("send(channel, value) takes 2 arguments")
        channel_name = args[0]
        value = args[1]
        vm = get_async_vm()
        vm.send(channel_name, value)
        return None

    def _builtin_recv(self, args):
        """recv(channel_name) - Receive from a channel."""
        if len(args) != 1:
            raise RuntimeError_("recv(channel) takes 1 argument")
        channel_name = args[0]
        vm = get_async_vm()
        channel = vm.get_channel(channel_name)
        if channel is None:
            raise RuntimeError_(f"Channel {channel_name} not found")
        return vm.loop.run_until_complete(channel.recv())

    def _builtin_channel(self, args):
        """channel(name) - Create or get a channel."""
        if len(args) != 1:
            raise RuntimeError_("channel(name) takes 1 argument")
        name = args[0]
        vm = get_async_vm()
        return vm.create_channel(name)

    def _builtin_parallel(self, args):
        """parallel(fn1, fn2, ...) - Run functions concurrently."""
        if len(args) < 1:
            raise RuntimeError_("parallel(fn, ...) takes at least 1 argument")
        fns = list(args)
        vm = get_async_vm()
        return vm.parallel(*fns)

    def _builtin_gather(self, args):
        """gather(awaitable1, awaitable2, ...) - Gather multiple awaitables."""
        if len(args) < 1:
            raise RuntimeError_("gather(...) takes at least 1 argument")
        awaitables = list(args)
        vm = get_async_vm()
        return vm.gather(*awaitables)

    def _builtin_gui_window(self, args):
        """Create a GUI window with tkinter."""
        if len(args) != 3:
            raise RuntimeError_("window(title, width, height) takes 3 arguments")
        title, width, height = args
        try:
            import tkinter as tk
            root = tk.Tk()
            root.title(title)
            canvas = tk.Canvas(root, width=int(width), height=int(height), bg="black")
            canvas.pack()
            self._gui_root = root
            self._gui_canvas = canvas
            return {"root": "tkinter", "width": int(width), "height": int(height)}
        except Exception as e:
            return {"error": str(e)}

    def _builtin_gui_rect(self, args):
        """Draw a rectangle on the GUI canvas."""
        if len(args) != 5:
            raise RuntimeError_("rectangle(x, y, w, h, color) takes 5 arguments")
        x, y, w, h, color = args
        if hasattr(self, '_gui_canvas'):
            self._gui_canvas.create_rectangle(x, y, x + w, y + h, fill=color, outline=color)
        return None

    def _builtin_gui_circle(self, args):
        """Draw a circle on the GUI canvas."""
        if len(args) != 4:
            raise RuntimeError_("circle(x, y, radius, color) takes 4 arguments")
        x, y, radius, color = args
        if hasattr(self, '_gui_canvas'):
            self._gui_canvas.create_oval(x - radius, y - radius, x + radius, y + radius, fill=color, outline=color)
        return None

    def _builtin_gui_text(self, args):
        """Draw text on the GUI canvas."""
        if len(args) != 5:
            raise RuntimeError_("text(x, y, content, size, color) takes 5 arguments")
        x, y, content, size, color = args
        if hasattr(self, '_gui_canvas'):
            self._gui_canvas.create_text(x, y, text=str(content), font=("Arial", int(size)), fill=color)
        return None

    def _builtin_gui_line(self, args):
        """Draw a line on the GUI canvas."""
        if len(args) != 5:
            raise RuntimeError_("line(x1, y1, x2, y2, color) takes 5 arguments")
        x1, y1, x2, y2, color = args
        if hasattr(self, '_gui_canvas'):
            self._gui_canvas.create_line(x1, y1, x2, y2, fill=color)
        return None

    def _builtin_gui_image(self, args):
        """Draw an image on the GUI canvas."""
        if len(args) != 5:
            raise RuntimeError_("image(path, x, y, w, h) takes 5 arguments")
        path, x, y, w, h = args
        if hasattr(self, '_gui_canvas'):
            try:
                from PIL import Image, ImageTk
                img = Image.open(path)
                img = img.resize((int(w), int(h)))
                photo = ImageTk.PhotoImage(img)
                self._gui_canvas.create_image(x, y, image=photo, anchor="nw")
                if not hasattr(self, '_gui_images'):
                    self._gui_images = []
                self._gui_images.append(photo)
            except Exception as e:
                return {"error": str(e)}
        return None

    def _builtin_gui_on_click(self, args):
        """Set click handler for GUI canvas."""
        if len(args) != 1:
            raise RuntimeError_("on_click(callback) takes 1 argument")
        callback = args[0]
        if hasattr(self, '_gui_canvas'):
            self._gui_click_callback = callback
            self._gui_canvas.bind("<Button-1>", lambda e: self._call_GUI_click(e.x, e.y))
        return None

    def _builtin_gui_on_key(self, args):
        """Set key handler for GUI window."""
        if len(args) != 1:
            raise RuntimeError_("on_key(callback) takes 1 argument")
        callback = args[0]
        if hasattr(self, '_gui_root'):
            self._gui_key_callback = callback
            self._gui_root.bind("<Key>", lambda e: self._call_GUI_key(e.keysym))
        return None

    def _call_GUI_click(self, x, y):
        """Internal: handle canvas click."""
        if hasattr(self, '_gui_click_callback'):
            fn = self._gui_click_callback
            if callable(fn):
                try:
                    fn([x, y])
                except:
                    pass

    def _call_GUI_key(self, key):
        """Internal: handle key press."""
        if hasattr(self, '_gui_key_callback'):
            fn = self._gui_key_callback
            if callable(fn):
                try:
                    fn([key])
                except:
                    pass

    def _builtin_gui_loop(self, args):
        """Start the GUI event loop."""
        if hasattr(self, '_gui_root'):
            self._gui_root.mainloop()
        return None

    def _builtin_audio_play(self, args):
        """Play an audio file."""
        if len(args) != 1:
            raise RuntimeError_("audio_play(path) takes 1 argument")
        path = args[0]
        import subprocess
        import platform
        try:
            if platform.system() == "Windows":
                import winsound
                winsound.PlaySound(path, winsound.SND_FILENAME)
            else:
                subprocess.run(["afplay", path], check=True, capture_output=True)
        except Exception as e:
            return {"error": str(e)}
        return None

    # -- iterator protocol ----------------------------------------------------

    def _builtin_iter(self, args):
        """Create an iterator from an iterable (list, dict, or string)."""
        if len(args) != 1:
            raise RuntimeError_("iter(iterable) takes 1 argument")
        iterable = args[0]
        if isinstance(iterable, (list, dict, str)):
            return Iterator(iterable)
        raise RuntimeError_(f"Cannot create iterator from {self._builtin_type([iterable])}")

    def _builtin_has_next(self, args):
        """Check if an iterator has more items."""
        if len(args) != 1:
            raise RuntimeError_("has_next(iterator) takes 1 argument")
        it = args[0]
        if isinstance(it, Iterator):
            return it.has_next()
        raise RuntimeError_("has_next() expects an iterator")

    def _builtin_next(self, args):
        """Get the next item from an iterator."""
        if len(args) != 1:
            raise RuntimeError_("next(iterator) takes 1 argument")
        it = args[0]
        if isinstance(it, Iterator):
            return it.next()
        raise RuntimeError_("next() expects an iterator")

    # -- concurrency primitives -----------------------------------------------

    def _builtin_lock(self, args):
        """lock() - Create a new mutex lock."""
        if len(args) != 0:
            raise RuntimeError_("lock() takes no arguments")
        return threading.Lock()

    def _builtin_lock_acquire(self, args):
        """lock_acquire(lock) - Acquire a lock."""
        if len(args) != 1:
            raise RuntimeError_("lock_acquire(lock) takes 1 argument")
        lock = args[0]
        # threading.Lock() returns an object with acquire/release methods
        if not hasattr(lock, 'acquire') or not hasattr(lock, 'release'):
            raise RuntimeError_("lock_acquire() expects a lock")
        lock.acquire()
        return None

    def _builtin_lock_release(self, args):
        """lock_release(lock) - Release a lock."""
        if len(args) != 1:
            raise RuntimeError_("lock_release(lock) takes 1 argument")
        lock = args[0]
        if not hasattr(lock, 'acquire') or not hasattr(lock, 'release'):
            raise RuntimeError_("lock_release() expects a lock")
        lock.release()
        return None

    def _builtin_semaphore(self, args):
        """semaphore(n) - Create a semaphore with n permits."""
        if len(args) != 1:
            raise RuntimeError_("semaphore(n) takes 1 argument")
        n = int(args[0])
        if n < 0:
            raise RuntimeError_("semaphore() value must be non-negative")
        return threading.Semaphore(n)

    def _builtin_sem_acquire(self, args):
        """sem_acquire(sem) - Acquire a semaphore permit."""
        if len(args) != 1:
            raise RuntimeError_("sem_acquire(sem) takes 1 argument")
        sem = args[0]
        # threading.Semaphore() returns an object with acquire/release methods
        if not hasattr(sem, 'acquire') or not hasattr(sem, 'release'):
            raise RuntimeError_("sem_acquire() expects a semaphore")
        sem.acquire()
        return None

    def _builtin_sem_release(self, args):
        """sem_release(sem) - Release a semaphore permit."""
        if len(args) != 1:
            raise RuntimeError_("sem_release(sem) takes 1 argument")
        sem = args[0]
        if not hasattr(sem, 'acquire') or not hasattr(sem, 'release'):
            raise RuntimeError_("sem_release() expects a semaphore")
        sem.release()
        return None

    # -- logging natives ---------------------------------------------------------

    def _builtin_log_debug(self, args):
        """log_debug(msg) - Log debug message."""
        return f"[DEBUG] {args[0] if args else ''}"

    def _builtin_log_info(self, args):
        """log_info(msg) - Log info message."""
        return f"[INFO] {args[0] if args else ''}"

    def _builtin_log_warning(self, args):
        """log_warning(msg) - Log warning message."""
        return f"[WARNING] {args[0] if args else ''}"

    def _builtin_log_error(self, args):
        """log_error(msg) - Log error message."""
        return f"[ERROR] {args[0] if args else ''}"

    def _builtin_log_critical(self, args):
        """log_critical(msg) - Log critical message."""
        return f"[CRITICAL] {args[0] if args else ''}"

    def _builtin_log_write(self, args):
        """log_write(level, msg) - Write log message to file."""
        import sys
        msg = args[1] if len(args) > 1 else ''
        print(args[0] + ": " + msg, file=sys.stderr)
        return None

    # -- datetime natives --------------------------------------------------------

    def _builtin_date_now(self, args):
        """date_now() - Get current date/time dict."""
        import datetime
        now = datetime.datetime.now()
        return {
            "year": now.year,
            "month": now.month,
            "day": now.day,
            "hour": now.hour,
            "minute": now.minute,
            "second": now.second,
            "weekday": now.weekday(),
        }

    def _builtin_date_from_timestamp(self, args):
        """date_from_timestamp(ts) - Create date dict from timestamp."""
        import datetime
        ts = float(args[0])
        now = datetime.datetime.fromtimestamp(ts)
        return {
            "year": now.year,
            "month": now.month,
            "day": now.day,
            "hour": now.hour,
            "minute": now.minute,
            "second": now.second,
            "weekday": now.weekday(),
        }

    def _builtin_date_timestamp(self, args):
        """date_timestamp(date) - Get timestamp from date dict."""
        import datetime
        d = args[0]
        dt = datetime.datetime(d["year"], d["month"], d["day"],
                               d.get("hour", 0), d.get("minute", 0), d.get("second", 0))
        return dt.timestamp()

    # -- config natives ----------------------------------------------------------

    def _builtin_config_load(self, args):
        """config_load(path) - Load config file (TOML/YAML/JSON)."""
        import os
        path = args[0]
        ext = os.path.splitext(path)[1].lower()

        if ext == ".json":
            return self._builtin_json_parse(args)
        elif ext in (".yaml", ".yml"):
            import yaml
            with open(path) as f:
                return yaml.safe_load(f) or {}
        elif ext == ".toml":
            import tomli
            with open(path, "rb") as f:
                return tomli.load(f)
        else:
            raise RuntimeError_(f"Unsupported config format: {ext}")

    # -- redis natives ----------------------------------------------------------

    def _redis_connect(self, host, port):
        """Redis connection object."""
        import socket
        class RedisConnection:
            def __init__(self, host, port):
                self.host = host
                self.port = port
                self._sock = None

            def _connect(self):
                if self._sock is None:
                    self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    self._sock.connect((self.host, self.port))

            def send(self, cmd):
                self._connect()
                self._sock.sendall(cmd.encode() if isinstance(cmd, str) else cmd)
                resp = self._sock.recv(4096)
                return resp.decode() if isinstance(resp, bytes) else resp

            def close(self):
                if self._sock:
                    self._sock.close()
                    self._sock = None
        return RedisConnection(host, port)

    def _builtin_redis_connect(self, args):
        """redis_connect(host, port) - Connect to Redis."""
        host = args[0] if len(args) > 0 else "localhost"
        port = int(args[1]) if len(args) > 1 else 6379
        return self._redis_connect(host, port)

    def _builtin_redis_set(self, args):
        """redis_set(conn, key, value) - Set a key."""
        conn = args[0]
        key = args[1]
        val = args[2]
        conn.send(f"*3\r\n$3\r\nSET\r\n${len(key)}\r\n{key}\r\n${len(str(val))}\r\n{val}\r\n")
        return True

    def _builtin_redis_get(self, args):
        """redis_get(conn, key) - Get a key."""
        conn = args[0]
        key = args[1]
        conn.send(f"*2\r\n$3\r\nGET\r\n${len(key)}\r\n{key}\r\n")
        return True

    def _builtin_redis_delete(self, args):
        """redis_delete(conn, key) - Delete a key."""
        conn = args[0]
        key = args[1]
        conn.send(f"*2\r\n$3\r\nDEL\r\n${len(key)}\r\n{key}\r\n")
        return True

    def _builtin_redis_close(self, args):
        """redis_close(conn) - Close Redis connection."""
        conn = args[0]
        conn.close()
        return None

    # -- test natives -----------------------------------------------------------

    def _builtin_assert_equal(self, args):
        """assert_equal(actual, expected) - Assert two values are equal."""
        actual = args[0]
        expected = args[1]
        if actual != expected:
            raise RuntimeError_(f"Expected {expected!r}, got {actual!r}")
        return True

    def _builtin_assert_throws(self, args):
        fn = args[0]
        try:
            self._call(fn, [])
            raise RuntimeError_("Expected function to throw, but it didn't")
        except (ThrowSignal, RuntimeError_):
            pass
        return True

    # -- websocket native --------------------------------------------------------

    def _builtin_ws_connect(self, args):
        """ws_connect(url) - Connect to WebSocket server."""
        try:
            import websocket
            ws = websocket.create_connection(args[0])
            return ws
        except ImportError:
            raise RuntimeError_("WebSocket not supported. Install: pip install websocket-client")

    def _builtin_ws_send(self, args):
        """ws_send(ws, message) - Send message."""
        ws = args[0]
        msg = args[1]
        ws.send(msg)
        return True

    def _builtin_ws_recv(self, args):
        """ws_recv(ws) - Receive message."""
        ws = args[0]
        return ws.recv()

    def _builtin_ws_close(self, args):
        """ws_close(ws) - Close WebSocket."""
        ws = args[0]
        ws.close()
        return None

    # -- email native -----------------------------------------------------------

    def _builtin_email_send(self, args):
        """email_send(options) - Send email."""
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        opts = args[0]
        msg = MIMEMultipart()
        msg['To'] = opts.get('to', '')
        msg['From'] = opts.get('from', opts.get('to', ''))
        msg['Subject'] = opts.get('subject', '')

        body = opts.get('body', '')
        msg.attach(MIMEText(body, 'plain' if not opts.get('html') else 'html'))

        smtp_host = opts.get('smtp', 'localhost')
        smtp_port = int(opts.get('port', 587))

        try:
            server = smtplib.SMTP(smtp_host, smtp_port)
            if opts.get('user'):
                server.starttls()
                server.login(opts['user'], opts.get('password', ''))
            server.send_message(msg)
            server.quit()
        except Exception as e:
            raise RuntimeError_(f"Failed to send email: {e}")
        return True

    # -- cli native -------------------------------------------------------------

    def _builtin_cli_args(self, args):
        """cli_args() - Get command line arguments."""
        import sys
        return sys.argv[1:]

    def _builtin_cli_has_option(self, args):
        """cli_has_option(args, key) - Check if option exists."""
        import sys
        args_list = args[0] if args else sys.argv[1:]
        key = args[1] if len(args) > 1 else ""
        return key in args_list or f"--{key}" in args_list

    def _builtin_cli_get_option(self, args):
        """cli_get_option(args, key, default) - Get option value."""
        import sys
        args_list = args[0] if args else sys.argv[1:]
        key = args[1] if len(args) > 1 else ""
        default = args[2] if len(args) > 2 else None

        args_list = args_list or sys.argv[1:]
        for i, arg in enumerate(args_list):
            if arg == f"--{key}" and i + 1 < len(args_list):
                return args_list[i + 1]
            elif arg.startswith(f"--{key}="):
                return arg.split("=", 1)[1]
        return default

    # -- template native --------------------------------------------------------

    def _builtin_template_render(self, args):
        """template_render(template, data) - Render template."""
        import re
        template = args[0]
        data = args[1] or {}

        def replace_var(m):
            key = m.group(1).strip()
            val = data.get(key, '')
            return str(val)

        result = re.sub(r'\{\{\s*(\w+)\s*\}\}', replace_var, template)
        return result

    def _builtin_template_escape(self, args):
        """template_escape(s) - HTML escape string."""
        import html
        return html.escape(str(args[0]) if args else '')

    # -- jwt native -------------------------------------------------------------

    def _builtin_jwt_create(self, args):
        """jwt_create(payload, secret) - Create JWT token."""
        import jwt
        import json

        payload = args[0] or {}
        secret = args[1] if len(args) > 1 else ''
        payload_str = json.dumps(payload) if isinstance(payload, dict) else str(payload)
        payload_dict = json.loads(payload_str) if isinstance(payload_str, str) else payload

        import time
        payload_dict['iat'] = int(time.time())
        if 'exp' not in payload_dict:
            payload_dict['exp'] = int(time.time()) + 3600

        return jwt.encode(payload_dict, secret, algorithm="HS256")

    def _builtin_jwt_verify(self, args):
        """jwt_verify(token, secret) - Verify JWT token."""
        import jwt
        try:
            token = args[0]
            secret = args[1] if len(args) > 1 else ''
            payload = jwt.decode(token, secret, algorithms=["HS256"])
            return payload
        except jwt.InvalidTokenError as e:
            raise RuntimeError_(f"Invalid JWT: {e}")

    def _builtin_jwt_decode(self, args):
        """jwt_decode(token) - Decode JWT without verification."""
        import jwt
        import base64

        token = args[0]
        try:
            parts = token.split('.')
            if len(parts) != 3:
                raise RuntimeError_("Invalid JWT format")
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4)
            decoded = base64.urlsafe_b64decode(payload)
            import json
            return json.loads(decoded)
        except Exception as e:
            raise RuntimeError_(f"Failed to decode JWT: {e}")

    # -- audio native -----------------------------------------------------------

    def _builtin_audio_play(self, args):
        """audio_play(path) - Play audio file."""
        if len(args) < 1:
            raise RuntimeError_("audio_play(path) takes 1 argument")
        path = args[0]
        import subprocess
        import platform
        try:
            if platform.system() == "Windows":
                import winsound
                winsound.PlaySound(path, winsound.SND_FILENAME)
            else:
                subprocess.run(["afplay" if platform.system() == "Darwin" else "aplay", path],
                              check=True, capture_output=True)
        except Exception as e:
            raise RuntimeError_(f"Failed to play audio: {e}")
        return None

    # -- gui native ------------------------------------------------------------

    def _builtin_gui_window(self, args):
        """gui_window(title, width, height) - Create window."""
        try:
            import tkinter as tk
            root = tk.Tk()
            root.title(args[0] if len(args) > 0 else "Mo GUI")
            w = int(args[1]) if len(args) > 1 else 400
            h = int(args[2]) if len(args) > 2 else 300
            root.geometry(f"{w}x{h}")
            root.configure(bg="#1e1e2e")
            return {"_type": "tk_root", "_root": root}
        except ImportError:
            raise RuntimeError_("GUI not available. Install tkinter: apt install python3-tk")

    def _builtin_gui_label(self, args):
        """gui_label(parent, text) - Create label."""
        try:
            import tkinter as tk
            parent = args[0].get("_root") or args[0].get("_frame")
            lbl = tk.Label(parent, text=args[1] if len(args) > 1 else "",
                           bg="#1e1e2e", fg="#cdd6f4",
                           font=("Helvetica", 13))
            lbl.pack(pady=(8, 2))
            return {"_type": "tk_label", "_widget": lbl}
        except Exception as e:
            raise RuntimeError_(f"Failed to create label: {e}")

    def _builtin_gui_label_set(self, args):
        """gui_label_set(label, text) - Update label text."""
        try:
            lbl = args[0].get("_widget")
            lbl.config(text=args[1] if len(args) > 1 else "")
        except Exception as e:
            raise RuntimeError_(f"Failed to set label: {e}")
        return None

    def _builtin_gui_button(self, args):
        """gui_button(parent, text, callback) - Create button with callback."""
        try:
            import tkinter as tk
            parent = args[0].get("_root") or args[0].get("_frame")
            text = args[1] if len(args) > 1 else "Click"
            callback = args[2] if len(args) > 2 else None
            cmd = None
            if callback is not None:
                interp = self
                def cmd(cb=callback):
                    try:
                        interp._call(cb, [])
                    except Exception as ex:
                        print(f"[GUI Error] {ex}")
            btn = tk.Button(parent, text=text, command=cmd,
                            bg="#89b4fa", fg="#1e1e2e",
                            activebackground="#74c7ec",
                            relief="flat", padx=10, pady=4,
                            font=("Helvetica", 11, "bold"), cursor="hand2")
            btn.pack(pady=4, padx=10, fill="x")
            return {"_type": "tk_button", "_widget": btn}
        except Exception as e:
            raise RuntimeError_(f"Failed to create button: {e}")

    def _builtin_gui_run(self, args):
        """gui_run() - Start GUI main loop."""
        try:
            import tkinter as tk
            tk.mainloop()
        except Exception as e:
            raise RuntimeError_(f"GUI error: {e}")

    def _builtin_gui_entry(self, args):
        """gui_entry(parent, placeholder) - Create text input."""
        try:
            import tkinter as tk
            parent = args[0].get("_root") or args[0].get("_frame")
            placeholder = args[1] if len(args) > 1 else ""
            entry = tk.Entry(parent, bg="#313244", fg="#cdd6f4",
                             insertbackground="#cdd6f4",
                             relief="flat", font=("Helvetica", 12),
                             width=30)
            entry.pack(pady=4, padx=10, ipady=6, fill="x")
            if placeholder:
                entry.insert(0, placeholder)
                entry.config(fg="#6c7086")
                def on_focus_in(e):
                    if entry.get() == placeholder:
                        entry.delete(0, "end")
                        entry.config(fg="#cdd6f4")
                def on_focus_out(e):
                    if entry.get() == "":
                        entry.insert(0, placeholder)
                        entry.config(fg="#6c7086")
                entry.bind("<FocusIn>", on_focus_in)
                entry.bind("<FocusOut>", on_focus_out)
            return {"_type": "tk_entry", "_widget": entry, "_placeholder": placeholder}
        except Exception as e:
            raise RuntimeError_(f"Failed to create entry: {e}")

    def _builtin_gui_entry_get(self, args):
        """gui_entry_get(entry) - Get text from entry."""
        try:
            e = args[0]
            text = e["_widget"].get()
            if text == e.get("_placeholder", ""):
                return ""
            return text
        except Exception as ex:
            raise RuntimeError_(f"Failed to get entry text: {ex}")

    def _builtin_gui_entry_clear(self, args):
        """gui_entry_clear(entry) - Clear entry text."""
        try:
            e = args[0]
            e["_widget"].delete(0, "end")
            ph = e.get("_placeholder", "")
            if ph:
                e["_widget"].insert(0, ph)
                e["_widget"].config(fg="#6c7086")
        except Exception as ex:
            raise RuntimeError_(f"Failed to clear entry: {ex}")
        return None

    def _builtin_gui_frame(self, args):
        """gui_frame(parent, orient) - Container for grouping widgets."""
        try:
            import tkinter as tk
            parent = args[0].get("_root") or args[0].get("_frame")
            orient = args[1] if len(args) > 1 else "v"
            frame = tk.Frame(parent, bg="#1e1e2e")
            if orient == "h":
                frame.pack(fill="x", padx=10, pady=2)
                return {"_type": "tk_frame", "_frame": frame, "_root": None, "_h": True}
            frame.pack(fill="both", expand=True, padx=10, pady=2)
            return {"_type": "tk_frame", "_frame": frame, "_root": None}
        except Exception as e:
            raise RuntimeError_(f"Failed to create frame: {e}")

    def _builtin_gui_listbox(self, args):
        """gui_listbox(parent) - Create scrollable listbox."""
        try:
            import tkinter as tk
            parent = args[0].get("_root") or args[0].get("_frame")
            frame = tk.Frame(parent, bg="#1e1e2e")
            frame.pack(fill="both", expand=True, padx=10, pady=4)
            scrollbar = tk.Scrollbar(frame)
            scrollbar.pack(side="right", fill="y")
            lb = tk.Listbox(frame, yscrollcommand=scrollbar.set,
                            bg="#313244", fg="#cdd6f4",
                            selectbackground="#89b4fa", selectforeground="#1e1e2e",
                            relief="flat", font=("Helvetica", 12),
                            activestyle="none", bd=0)
            lb.pack(side="left", fill="both", expand=True)
            scrollbar.config(command=lb.yview)
            return {"_type": "tk_listbox", "_widget": lb}
        except Exception as e:
            raise RuntimeError_(f"Failed to create listbox: {e}")

    def _builtin_gui_listbox_add(self, args):
        """gui_listbox_add(lb, text) - Add item to listbox."""
        try:
            args[0]["_widget"].insert("end", args[1] if len(args) > 1 else "")
        except Exception as e:
            raise RuntimeError_(f"Failed to add item: {e}")
        return None

    def _builtin_gui_listbox_selected(self, args):
        """gui_listbox_selected(lb) - Return selected index or -1."""
        try:
            sel = args[0]["_widget"].curselection()
            return int(sel[0]) if sel else -1
        except Exception:
            return -1

    def _builtin_gui_listbox_delete(self, args):
        """gui_listbox_delete(lb, index) - Delete item at index."""
        try:
            args[0]["_widget"].delete(int(args[1]))
        except Exception as e:
            raise RuntimeError_(f"Failed to delete item: {e}")
        return None

    def _builtin_gui_listbox_size(self, args):
        """gui_listbox_size(lb) - Return number of items."""
        try:
            return args[0]["_widget"].size()
        except Exception:
            return 0

    def _builtin_gui_listbox_get(self, args):
        """gui_listbox_get(lb, index) - Get item text at index."""
        try:
            return args[0]["_widget"].get(int(args[1]))
        except Exception:
            return ""

    # -- media player natives --------------------------------------------------

    _VIDEO_EXTS = {".mp4", ".avi", ".mov", ".mkv", ".webm", ".flv", ".m4v"}
    _AUDIO_EXTS = {".mp3", ".wav", ".ogg", ".flac", ".aac", ".m4a"}

    def _gui_media_is_video(self, path: str) -> bool:
        import os
        return os.path.splitext(path)[1].lower() in self._VIDEO_EXTS

    def _gui_media_fmt_time(self, seconds: float) -> str:
        s = int(seconds)
        return f"{s // 60}:{s % 60:02d}"

    def _gui_media_get_duration_cv2(self, path: str) -> float:
        try:
            import cv2
            cap = cv2.VideoCapture(path)
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)
            cap.release()
            return frames / fps if fps > 0 else 0.0
        except Exception:
            return 0.0

    def _gui_media_get_duration_pygame(self, path: str) -> float:
        try:
            import pygame
            if not pygame.mixer.get_init():
                pygame.mixer.init()
            snd = pygame.mixer.Sound(path)
            return snd.get_length()
        except Exception:
            return 0.0

    def _builtin_gui_media_player(self, args):
        """media_player(parent, path) - Embedded media player with video support."""
        import os
        try:
            import tkinter as tk
        except ImportError:
            raise RuntimeError_("GUI not available: pip install tkinter")

        parent_widget = args[0].get("_root") or args[0].get("_frame")
        path = str(args[1]) if len(args) > 1 else ""
        is_video = path and self._gui_media_is_video(path)

        # ── outer frame ────────────────────────────────────────────────────
        outer = tk.Frame(parent_widget, bg="#181825",
                         highlightbackground="#45475a", highlightthickness=1)
        outer.pack(fill="both", expand=True, padx=10, pady=8)

        # ── video canvas (video only) ───────────────────────────────────────
        canvas = None
        canvas_w, canvas_h = 640, 360
        if is_video:
            canvas = tk.Canvas(outer, width=canvas_w, height=canvas_h,
                               bg="#000000", highlightthickness=0)
            canvas.pack(fill="both", expand=True)

        # ── track title ────────────────────────────────────────────────────
        track_name = os.path.basename(path) if path else "No file loaded"
        title_lbl = tk.Label(outer, text=track_name,
                             bg="#181825", fg="#cdd6f4",
                             font=("Helvetica", 11, "bold"), anchor="w", padx=8)
        title_lbl.pack(fill="x", pady=(6, 2))

        # ── seek bar ───────────────────────────────────────────────────────
        seek_var = tk.DoubleVar(value=0.0)
        seek_bar = tk.Scale(outer, variable=seek_var, from_=0.0, to=100.0,
                            orient="horizontal", showvalue=False,
                            bg="#181825", troughcolor="#313244",
                            activebackground="#89b4fa",
                            highlightthickness=0, bd=0, sliderlength=12)
        seek_bar.pack(fill="x", padx=8)

        # ── time display ───────────────────────────────────────────────────
        time_row = tk.Frame(outer, bg="#181825")
        time_row.pack(fill="x", padx=8)
        cur_lbl = tk.Label(time_row, text="0:00", bg="#181825", fg="#6c7086",
                           font=("Helvetica", 9))
        cur_lbl.pack(side="left")
        dur_lbl = tk.Label(time_row, text="0:00", bg="#181825", fg="#6c7086",
                           font=("Helvetica", 9))
        dur_lbl.pack(side="right")

        # ── control row ────────────────────────────────────────────────────
        ctrl_row = tk.Frame(outer, bg="#181825")
        ctrl_row.pack(pady=(4, 4))

        btn_kw = dict(bg="#313244", fg="#cdd6f4", activebackground="#45475a",
                      activeforeground="#cdd6f4", relief="flat",
                      font=("Helvetica", 14), width=3, cursor="hand2", bd=0)

        # ── volume ─────────────────────────────────────────────────────────
        vol_row = tk.Frame(outer, bg="#181825")
        vol_row.pack(fill="x", padx=8, pady=(0, 8))
        tk.Label(vol_row, text="🔊", bg="#181825", fg="#6c7086",
                 font=("Helvetica", 9)).pack(side="left")
        vol_var = tk.DoubleVar(value=100.0)

        # ── shared state ───────────────────────────────────────────────────
        state = {
            "_type": "tk_media", "_path": path, "_is_video": is_video,
            "_playing": False, "_paused": False, "_duration": 0.0,
            "_seek_var": seek_var, "_cur_lbl": cur_lbl, "_dur_lbl": dur_lbl,
            "_title_lbl": title_lbl, "_frame": outer, "_seek_bar": seek_bar,
            "_canvas": canvas, "_photo": None,
            "_poll_id": None, "_cap": None, "_audio_proc": None,
            "_frame_ms": 33, "_start_time": 0.0, "_paused_pos": 0.0,
        }

        interp = self

        # ── video frame update (opencv) ────────────────────────────────────
        def _video_show_frame():
            cap = state["_cap"]
            if cap is None or canvas is None:
                return
            try:
                import cv2
                from PIL import Image, ImageTk
                ret, frame = cap.read()
                if not ret:
                    _do_stop()
                    return
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                img = Image.fromarray(frame_rgb)
                img = img.resize((canvas_w, canvas_h), Image.LANCZOS)
                photo = ImageTk.PhotoImage(image=img)
                canvas.create_image(0, 0, image=photo, anchor="nw")
                state["_photo"] = photo  # prevent GC

                # update seek bar position
                pos_s = cap.get(cv2.CAP_PROP_POS_MSEC) / 1000.0
                seek_var.set(pos_s)
                cur_lbl.config(text=interp._gui_media_fmt_time(pos_s))

                if state["_playing"]:
                    state["_poll_id"] = outer.after(state["_frame_ms"], _video_show_frame)
            except Exception as ex:
                title_lbl.config(text=f"Frame error: {ex}")

        def _start_audio_proc(pos_s: float = 0.0):
            """Launch ffplay in audio-only mode for the video file."""
            import subprocess, shutil
            ffplay = shutil.which("ffplay")
            if not ffplay:
                return
            _stop_audio_proc()
            cmd = [ffplay, "-nodisp", "-autoexit", "-loglevel", "quiet",
                   "-ss", str(pos_s), path]
            try:
                proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL)
                state["_audio_proc"] = proc
            except Exception:
                pass

        def _stop_audio_proc():
            proc = state.get("_audio_proc")
            if proc and proc.poll() is None:
                try:
                    proc.terminate()
                except Exception:
                    pass
            state["_audio_proc"] = None

        # ── audio-only helpers (pygame) ────────────────────────────────────
        def _audio_init():
            try:
                import pygame
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                return pygame
            except ImportError:
                return None

        # ── play / pause / stop ────────────────────────────────────────────
        def _do_stop():
            state["_playing"] = False
            state["_paused"] = False
            state["_paused_pos"] = 0.0
            if state["_poll_id"]:
                outer.after_cancel(state["_poll_id"])
                state["_poll_id"] = None
            if is_video:
                _stop_audio_proc()
                if state["_cap"]:
                    state["_cap"].release()
                    state["_cap"] = None
                if canvas:
                    canvas.delete("all")
            else:
                pg = _audio_init()
                if pg:
                    pg.mixer.music.stop()
            seek_var.set(0.0)
            cur_lbl.config(text="0:00")
            play_btn.config(text="▶")

        def _do_play_video(seek_s: float = 0.0):
            import cv2
            if state["_cap"]:
                state["_cap"].release()
            cap = cv2.VideoCapture(path)
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            state["_frame_ms"] = max(1, int(1000 / fps))
            if seek_s > 0:
                cap.set(cv2.CAP_PROP_POS_MSEC, seek_s * 1000)
            state["_cap"] = cap
            state["_playing"] = True
            state["_paused"] = False
            play_btn.config(text="⏸")
            _start_audio_proc(seek_s)
            _video_show_frame()

        def _do_play_audio():
            pg = _audio_init()
            if not pg:
                title_lbl.config(text="Error: pygame not available")
                return
            pg.mixer.music.load(path)
            pg.mixer.music.play()
            state["_playing"] = True
            state["_paused"] = False
            play_btn.config(text="⏸")
            _start_audio_poll(pg)

        def _start_audio_poll(pg):
            def _poll():
                if state["_playing"]:
                    if not pg.mixer.music.get_busy():
                        _do_stop()
                        return
                    ms = pg.mixer.music.get_pos()
                    if ms >= 0:
                        pos_s = state["_paused_pos"] + ms / 1000.0
                        seek_var.set(pos_s)
                        cur_lbl.config(text=interp._gui_media_fmt_time(pos_s))
                state["_poll_id"] = outer.after(200, _poll)
            if state["_poll_id"]:
                outer.after_cancel(state["_poll_id"])
            state["_poll_id"] = outer.after(200, _poll)

        def _toggle_play():
            if not state["_path"]:
                return
            if state["_playing"]:
                # pause
                state["_playing"] = False
                state["_paused"] = True
                play_btn.config(text="▶")
                if state["_poll_id"]:
                    outer.after_cancel(state["_poll_id"])
                    state["_poll_id"] = None
                if is_video:
                    _stop_audio_proc()
                    if state["_cap"]:
                        state["_paused_pos"] = state["_cap"].get(3) / 1000.0  # CAP_PROP_POS_MSEC
                else:
                    pg = _audio_init()
                    if pg:
                        state["_paused_pos"] += pg.mixer.music.get_pos() / 1000.0
                        pg.mixer.music.pause()
            elif state["_paused"]:
                # resume
                state["_playing"] = True
                state["_paused"] = False
                play_btn.config(text="⏸")
                if is_video:
                    _do_play_video(state["_paused_pos"])
                else:
                    pg = _audio_init()
                    if pg:
                        pg.mixer.music.unpause()
                        _start_audio_poll(pg)
            else:
                # fresh start
                state["_paused_pos"] = 0.0
                if is_video:
                    try:
                        dur = interp._gui_media_get_duration_cv2(path)
                        state["_duration"] = dur
                        seek_bar.config(to=max(dur, 1.0))
                        dur_lbl.config(text=interp._gui_media_fmt_time(dur))
                        _do_play_video()
                    except Exception as ex:
                        title_lbl.config(text=f"Error: {ex}")
                else:
                    try:
                        dur = interp._gui_media_get_duration_pygame(path)
                        state["_duration"] = dur
                        seek_bar.config(to=max(dur, 1.0))
                        dur_lbl.config(text=interp._gui_media_fmt_time(dur))
                        _do_play_audio()
                    except Exception as ex:
                        title_lbl.config(text=f"Error: {ex}")

        def _on_seek(val):
            pos = float(val)
            if is_video and state["_cap"]:
                import cv2
                state["_cap"].set(cv2.CAP_PROP_POS_MSEC, pos * 1000)
                cur_lbl.config(text=interp._gui_media_fmt_time(pos))
                if state["_playing"]:
                    _stop_audio_proc()
                    _start_audio_proc(pos)
            else:
                pg = _audio_init()
                if pg:
                    try:
                        pg.mixer.music.set_pos(pos)
                        cur_lbl.config(text=interp._gui_media_fmt_time(pos))
                    except Exception:
                        pass

        def _on_volume(val):
            v = float(val) / 100.0
            if is_video:
                # volume via ffplay relaunch is not practical; store for future
                pass
            else:
                pg = _audio_init()
                if pg:
                    pg.mixer.music.set_volume(v)

        seek_bar.config(command=_on_seek)

        # build buttons now that _do_stop/_toggle_play exist
        tk.Button(ctrl_row, text="⏮", command=_do_stop, **btn_kw).pack(side="left", padx=4)
        play_btn = tk.Button(ctrl_row, text="▶", command=_toggle_play, **btn_kw)
        play_btn.pack(side="left", padx=4)
        tk.Button(ctrl_row, text="⏹", command=_do_stop, **btn_kw).pack(side="left", padx=4)

        tk.Scale(vol_row, variable=vol_var, from_=0.0, to=100.0,
                 orient="horizontal", showvalue=False, command=_on_volume,
                 bg="#181825", troughcolor="#313244", activebackground="#89b4fa",
                 highlightthickness=0, bd=0, sliderlength=10, length=120).pack(side="left", padx=4)

        state["_play_btn"] = play_btn
        state["_vol_var"] = vol_var
        state["_toggle_play"] = _toggle_play
        state["_do_stop"] = _do_stop

        # pre-load duration if file exists
        if path and os.path.exists(path):
            try:
                dur = (self._gui_media_get_duration_cv2(path) if is_video
                       else self._gui_media_get_duration_pygame(path))
                if dur > 0:
                    state["_duration"] = dur
                    seek_bar.config(to=max(dur, 1.0))
                    dur_lbl.config(text=self._gui_media_fmt_time(dur))
            except Exception:
                pass

        return state

    def _builtin_gui_media_play(self, args):
        try:
            p = args[0]
            if not p["_playing"]:
                p["_toggle_play"]()
        except Exception as e:
            raise RuntimeError_(f"media_play error: {e}")
        return None

    def _builtin_gui_media_pause(self, args):
        try:
            p = args[0]
            if p["_playing"]:
                p["_toggle_play"]()
        except Exception as e:
            raise RuntimeError_(f"media_pause error: {e}")
        return None

    def _builtin_gui_media_stop(self, args):
        try:
            args[0]["_do_stop"]()
        except Exception as e:
            raise RuntimeError_(f"media_stop error: {e}")
        return None

    def _builtin_gui_media_seek(self, args):
        try:
            p = args[0]
            pos = float(args[1]) if len(args) > 1 else 0.0
            p["_seek_var"].set(pos)
            # trigger the seek callback
            if p["_is_video"] and p["_cap"]:
                import cv2
                p["_cap"].set(cv2.CAP_PROP_POS_MSEC, pos * 1000)
            p["_cur_lbl"].config(text=self._gui_media_fmt_time(pos))
        except Exception as e:
            raise RuntimeError_(f"media_seek error: {e}")
        return None

    def _builtin_gui_media_volume(self, args):
        try:
            vol = max(0.0, min(1.0, float(args[1]) if len(args) > 1 else 1.0))
            args[0]["_vol_var"].set(vol * 100.0)
            if not args[0]["_is_video"]:
                import pygame
                pygame.mixer.music.set_volume(vol)
        except Exception as e:
            raise RuntimeError_(f"media_volume error: {e}")
        return None

    def _builtin_gui_media_duration(self, args):
        return float(args[0].get("_duration", 0.0))

    def _builtin_gui_media_position(self, args):
        p = args[0]
        try:
            if p["_is_video"] and p["_cap"]:
                return p["_cap"].get(0) / 1000.0  # CAP_PROP_POS_MSEC
            import pygame
            ms = pygame.mixer.music.get_pos()
            return p["_paused_pos"] + ms / 1000.0 if ms >= 0 else 0.0
        except Exception:
            return 0.0

    def _builtin_gui_media_load(self, args):
        try:
            import os
            p = args[0]
            path = str(args[1]) if len(args) > 1 else ""
            p["_do_stop"]()
            p["_path"] = path
            p["_is_video"] = self._gui_media_is_video(path)
            track_name = os.path.basename(path) if path else "No file loaded"
            p["_title_lbl"].config(text=track_name)
            if path and os.path.exists(path):
                dur = (self._gui_media_get_duration_cv2(path) if p["_is_video"]
                       else self._gui_media_get_duration_pygame(path))
                p["_duration"] = dur
                p["_seek_bar"].config(to=max(dur, 1.0))
                p["_dur_lbl"].config(text=self._gui_media_fmt_time(dur))
        except Exception as e:
            raise RuntimeError_(f"media_load error: {e}")
        return None

    def _builtin_gui_media_is_playing(self, args):
        return bool(args[0].get("_playing", False))

    # -- collections native ----------------------------------------------------

    def _builtin_deque(self, args):
        """deque() - Create deque."""
        from collections import deque
        return {"_type": "deque", "_data": deque()}

    def _builtin_deque_append(self, args):
        """deque_append(dq, item) - Append to deque."""
        dq = args[0]
        if dq.get("_type") != "deque":
            raise RuntimeError_("Expected deque")
        dq["_data"].append(args[1])
        return None

    def _builtin_deque_popleft(self, args):
        """deque_popleft(dq) - Pop from left."""
        dq = args[0]
        if dq.get("_type") != "deque":
            raise RuntimeError_("Expected deque")
        try:
            return dq["_data"].popleft()
        except IndexError:
            return None

    def _builtin_counter(self, args):
        """counter() - Create counter."""
        from collections import Counter
        return {"_type": "counter", "_data": Counter()}

    def _builtin_counter_increment(self, args):
        """counter_increment(counter, key) - Increment count."""
        c = args[0]
        if c.get("_type") != "counter":
            raise RuntimeError_("Expected counter")
        key = args[1] if len(args) > 1 else ""
        c["_data"][key] += 1
        return None

    def _builtin_counter_get(self, args):
        """counter_get(counter, key) - Get count."""
        c = args[0]
        if c.get("_type") != "counter":
            raise RuntimeError_("Expected counter")
        key = args[1] if len(args) > 1 else ""
        return c["_data"].get(key, 0)

    # -- process native -------------------------------------------------------

    def _builtin_proc_run(self, args):
        """proc_run(cmd) - Run command, return output."""
        import subprocess
        cmd = args[0]
        try:
            result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=30)
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "exit_code": result.returncode
            }
        except Exception as e:
            return {"error": str(e)}

    def _builtin_proc_start(self, args):
        """proc_start(cmd) - Start process, return PID."""
        import subprocess
        cmd = args[0]
        try:
            proc = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            return proc.pid
        except Exception as e:
            raise RuntimeError_(f"Failed to start process: {e}")

    def _builtin_proc_wait(self, args):
        """proc_wait(pid) - Wait for process."""
        import subprocess
        pid = int(args[0])
        try:
            proc = subprocess.waitpid(pid, 0)
            return proc
        except Exception:
            return None

    # -- xml native -----------------------------------------------------------

    def _builtin_xml_parse(self, args):
        """xml_parse(content) - Parse XML string."""
        import xml.etree.ElementTree as ET
        content = args[0]
        try:
            return ET.fromstring(content)
        except ET.ParseError as e:
            raise RuntimeError_(f"XML parse error: {e}")

    def _builtin_xml_to_string(self, args):
        """xml_to_string(elem) - Convert XML element to string."""
        import xml.etree.ElementTree as ET
        elem = args[0]
        try:
            return ET.tostring(elem, encoding="unicode")
        except Exception as e:
            raise RuntimeError_(f"XML error: {e}")

    def _builtin_xml_find(self, args):
        """xml_find(elem, path) - Find element by path."""
        elem = args[0]
        path = args[1] if len(args) > 1 else ""
        try:
            return elem.find(path)
        except Exception:
            return None

    # -- concurrency native ---------------------------------------------------

    def _builtin_spawn_thread(self, args):
        """spawn_thread(fn) - Run function in thread."""
        import threading
        fn = args[0]
        t = threading.Thread(target=fn)
        t.start()
        return {"_type": "thread", "_thread": t}

    def _builtin_thread_join(self, args):
        """thread_join(thread) - Wait for thread."""
        t = args[0].get("_thread")
        if t:
            t.join()
        return None

    # -- uuid native -----------------------------------------------------------

    def _builtin_uuid4(self, args):
        """uuid4() - Generate UUID v4."""
        import uuid
        return str(uuid.uuid4())

    def _builtin_uuid1(self, args):
        """uuid1() - Generate UUID v1."""
        import uuid
        return str(uuid.uuid1())

    # -- base64 native --------------------------------------------------------

    def _builtin_base64_encode(self, args):
        """base64_encode(data) - Encode to base64."""
        import base64 as b64
        data = args[0] if args else ""
        if isinstance(data, str):
            data = data.encode()
        return b64.b64encode(data).decode()

    def _builtin_base64_decode(self, args):
        """base64_decode(data) - Decode from base64."""
        import base64 as b64
        data = args[0] if args else ""
        return b64.b64decode(data).decode()

    # -- gzip native -----------------------------------------------------------

    def _builtin_gzip_compress(self, args):
        """gzip_compress(data) - Compress data."""
        import gzip
        data = args[0] if args else ""
        if isinstance(data, str):
            data = data.encode()
        return gzip.compress(data).hex()

    def _builtin_gzip_decompress(self, args):
        import gzip
        hex_data = args[0] if args else ""
        data = bytes.fromhex(hex_data)
        return gzip.decompress(data).decode()

    # -- fmt native ------------------------------------------------------------

    def _builtin_fmt(self, args):
        """fmt(template, ...args) - Format string like printf."""
        import sys
        template = args[0] if args else ""
        values = args[1:] if len(args) > 1 else []
        
        result = template
        i = 0
        pos = 0
        while pos < len(result):
            if result[pos] == '{':
                end = result.find('}', pos)
                if end > pos:
                    idx_str = result[pos+1:end]
                    if idx_str.isdigit():
                        idx = int(idx_str)
                        if idx < len(values):
                            result = result[:pos] + str(values[idx]) + result[end+1:]
                            pos = pos + len(str(values[idx])) - 1
                        else:
                            pos = end
                    else:
                        pos = end
                else:
                    pos += 1
            else:
                pos += 1
        return result

    def _builtin_printf(self, args):
        """printf(template, ...args) - Print formatted string."""
        result = self._builtin_fmt(args)
        print(result)
        return None

    # -- cache native ----------------------------------------------------------

    def _builtin_cache_create(self, args):
        """cache_create(max_size) - Create LRU cache."""
        max_size = int(args[0]) if args else 100
        return {"_type": "lru_cache", "_data": {}, "_order": [], "_max": max_size}

    def _builtin_cache_get(self, args):
        """cache_get(cache, key) - Get value."""
        c = args[0]
        if c.get("_type") != "lru_cache":
            raise RuntimeError_("Expected cache")
        key = args[1] if len(args) > 1 else ""
        data = c["_data"]
        if key in data:
            c["_order"].remove(key)
            c["_order"].append(key)
            return data[key]
        return None

    def _builtin_cache_set(self, args):
        """cache_set(cache, key, value) - Set value."""
        c = args[0]
        if c.get("_type") != "lru_cache":
            raise RuntimeError_("Expected cache")
        key = args[1] if len(args) > 1 else ""
        value = args[2] if len(args) > 2 else None
        
        if key in c["_data"]:
            c["_order"].remove(key)
        elif len(c["_data"]) >= c["_max"]:
            oldest = c["_order"].pop(0)
            del c["_data"][oldest]
        
        c["_data"][key] = value
        c["_order"].append(key)
        return None

    # -- decimal native --------------------------------------------------------

    def _builtin_decimal(self, args):
        """decimal(value) - Create decimal number."""
        from decimal import Decimal, getcontext
        getcontext().prec = 50
        value = args[0] if args else "0"
        return str(Decimal(str(value)))

    def _builtin_decimal_add(self, args):
        """decimal_add(a, b) - Add decimals."""
        from decimal import Decimal
        a = Decimal(args[0] if len(args) > 0 else "0")
        b = Decimal(args[1] if len(args) > 1 else "0")
        return str(a + b)

    def _builtin_decimal_mul(self, args):
        """decimal_mul(a, b) - Multiply decimals."""
        from decimal import Decimal
        a = Decimal(args[0] if len(args) > 0 else "0")
        b = Decimal(args[1] if len(args) > 1 else "0")
        return str(a * b)

    # -- validator native -----------------------------------------------------

    def _builtin_validator_email(self, args):
        """validator_email(email) - Validate email."""
        import re
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, str(args[0] if args else "")))

    def _builtin_validator_url(self, args):
        """validator_url(url) - Validate URL."""
        import re
        pattern = r'^https?://[^\s/$.?#].[^\s]*$'
        return bool(re.match(pattern, str(args[0] if args else "")))

    def _builtin_validator_phone(self, args):
        """validator_phone(phone) - Validate phone."""
        import re
        pattern = r'^\+?[\d\s\-()]{10,}$'
        return bool(re.match(pattern, str(args[0] if args else "")))

    def _builtin_validator_number(self, args):
        """validator_number(val) - Check if number."""
        try:
            float(args[0] if args else "")
            return True
        except:
            return False
