"""
linter.py — Mo language linter (mo lint)

Checks for:
- Unused variables
- Undefined variables
- Duplicate variable definitions
- Unreachable code
- Style issues

Usage:
    mo lint <file.mo>
"""
from __future__ import annotations
from typing import List, Set, Dict, Optional
from dataclasses import dataclass, field
from enum import Enum

from .lexer import Lexer
from .parser import Parser
from .ast_nodes import *


class Severity(Enum):
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class LintDiagnostic:
    severity: Severity
    message: str
    line: int
    column: int = 0
    
    def __str__(self):
        prefix = {
            Severity.ERROR: "[ERROR]",
            Severity.WARNING: "[WARNING]",
            Severity.INFO: "[INFO]"
        }[self.severity]
        return f"{prefix} Line {self.line}: {self.message}"


class Linter:
    """Static analysis for Mo code."""

    def __init__(self):
        self.diagnostics: List[LintDiagnostic] = []
        self.defined_vars: Set[str] = set()
        self.used_vars: Set[str] = set()
        self.declared_vars: Dict[str, int] = {}  # name -> line
        self.scope_stack: List[Set[str]] = []
        self.in_function = False
        self.function_returns = False
        self.current_line = 0
        self.loop_depth = 0  # tracks nesting depth of while/for loops
    
    def lint(self, stmts: List) -> List[LintDiagnostic]:
        """Lint a list of statements."""
        self.diagnostics = []
        self.defined_vars = set()
        self.used_vars = set()
        self.declared_vars = {}
        self.scope_stack = [set()]  # Global scope
        
        # Add built-in functions to global scope
        self._add_builtins()
        
        # First pass: collect all global definitions
        self._collect_globals(stmts)
        
        # Second pass: analyze each statement
        for stmt in stmts:
            self._analyze_stmt(stmt)
        
        # Check for unused variables
        self._check_unused_vars()
        
        return self.diagnostics
    
    def _add_builtins(self):
        """Add built-in functions to global scope."""
        builtins = [
            # I/O
            "print", "input", "debug",
            # Type conversion
            "str", "num", "type",
            # Type checking
            "is_number", "is_string", "is_bool", "is_list", "is_dict",
            # Collection operations
            "len", "push", "pop", "keys", "has", "delete", "range",
            # Math
            "floor", "ceil", "round", "abs",
            # Cast
            "cast",
            # Async
            "async_fn", "await_", "sleep_async", "run_async", "spawn", "send", "recv", "channel", "parallel", "gather",
            "__get_async_vm__",
        ]
        for name in builtins:
            self.scope_stack[0].add(name)
    
    def _collect_globals(self, stmts: List):
        """Collect globally defined names (functions, classes)."""
        for stmt in stmts:
            t = type(stmt)
            if t is FnDef:
                self.scope_stack[0].add(stmt.name)
            elif t is AsyncFn:
                self.scope_stack[0].add(stmt.name)
            elif t is ClassDef:
                self.scope_stack[0].add(stmt.name)
            # LetStmt is handled in _analyze_stmt to detect duplicates
    
    def _push_scope(self):
        """Push a new scope."""
        self.scope_stack.append(set())
    
    def _pop_scope(self):
        """Pop the current scope."""
        if len(self.scope_stack) > 1:
            self.scope_stack.pop()
    
    def _define_var(self, name: str, line: int):
        """Define a variable in current scope."""
        # Check for redefinition in current scope
        if name in self.scope_stack[-1]:
            self.diagnostics.append(LintDiagnostic(
                Severity.WARNING,
                f"Variable '{name}' is already defined in this scope",
                line
            ))
        self.scope_stack[-1].add(name)
        self.declared_vars[name] = line
    
    def _check_var_defined(self, name: str, line: int):
        """Check if a variable is defined."""
        for scope in reversed(self.scope_stack):
            if name in scope:
                self.used_vars.add(name)
                return True
        
        # Check for common misspellings
        suggestions = self._get_suggestions(name)
        msg = f"Undefined variable '{name}'"
        if suggestions:
            msg += f". Did you mean: {', '.join(suggestions)}?"
        
        self.diagnostics.append(LintDiagnostic(
            Severity.ERROR,
            msg,
            line
        ))
        return False
    
    def _get_suggestions(self, name: str) -> List[str]:
        """Get suggestions for a misspelled variable."""
        import difflib
        all_defined = set()
        for scope in self.scope_stack:
            all_defined.update(scope)
        return difflib.get_close_matches(name, all_defined, n=3, cutoff=0.6)
    
    def _analyze_stmt(self, node):
        """Analyze a statement."""
        t = type(node)
        line = getattr(node, 'line', 0)
        if line:
            self.current_line = line
        
        if t is LetStmt:
            self._analyze_expr(node.value)
            self._define_var(node.name, line)
        
        elif t is AssignStmt:
            self._check_var_defined(node.name, line)
            self._analyze_expr(node.value)
        
        elif t is ExprStmt:
            self._analyze_expr(node.expr)
        
        elif t is FnDef:
            self._push_scope()
            old_fn, old_ret = self.in_function, self.function_returns
            self.in_function = True
            self.function_returns = False
            for param in node.params:
                p_name = param[0] if isinstance(param, (tuple, list)) else param
                self._define_var(p_name, line)
            for stmt in node.body:
                self._analyze_stmt(stmt)
            self.in_function = old_fn
            self.function_returns = old_ret
            self._pop_scope()

        elif t is AsyncFn:
            self._push_scope()
            old_fn, old_ret = self.in_function, self.function_returns
            self.in_function = True
            self.function_returns = False
            for param in node.params:
                p_name = param[0] if isinstance(param, (tuple, list)) else param
                self._define_var(p_name, line)
            for stmt in node.body:
                self._analyze_stmt(stmt)
            self.in_function = old_fn
            self.function_returns = old_ret
            self._pop_scope()
        
        elif t is ReturnStmt:
            self.function_returns = True
            if node.value:
                self._analyze_expr(node.value)
            if not self.in_function:
                self.diagnostics.append(LintDiagnostic(
                    Severity.WARNING,
                    "Return statement outside of function",
                    line
                ))
        
        elif t is IfStmt:
            self._analyze_expr(node.condition)
            self._push_scope()
            for stmt in node.then_body:
                self._analyze_stmt(stmt)
            self._pop_scope()
            
            if node.else_body:
                self._push_scope()
                for stmt in node.else_body:
                    self._analyze_stmt(stmt)
                self._pop_scope()
        
        elif t is WhileStmt:
            self._analyze_expr(node.condition)
            self._push_scope()
            self.loop_depth += 1
            for stmt in node.body:
                self._analyze_stmt(stmt)
            self.loop_depth -= 1
            self._pop_scope()

        elif t is ForStmt:
            self._analyze_expr(node.iter)
            self._push_scope()
            self._define_var(node.var, line)
            self.loop_depth += 1
            for stmt in node.body:
                self._analyze_stmt(stmt)
            self.loop_depth -= 1
            self._pop_scope()
        
        elif t is TryCatch:
            self._push_scope()
            for stmt in node.try_body:
                self._analyze_stmt(stmt)
            self._pop_scope()
            
            self._push_scope()
            self._define_var(node.err_var, line)
            for stmt in node.catch_body:
                self._analyze_stmt(stmt)
            self._pop_scope()
        
        elif t is ThrowStmt:
            self._analyze_expr(node.value)
        
        elif t is BreakStmt or t is ContinueStmt:
            if self.loop_depth == 0:
                keyword = "break" if t is BreakStmt else "continue"
                self.diagnostics.append(LintDiagnostic(
                    Severity.ERROR, f"'{keyword}' outside of loop", line
                ))
        
        elif t is ImportStmt:
            pass  # Imports are handled by the runtime
        
        elif t is MatchStmt:
            self._analyze_expr(node.expr)
            for case in node.cases:
                self._push_scope()
                self._analyze_pattern(case.pattern)
                for stmt in case.body:
                    self._analyze_stmt(stmt)
                self._pop_scope()

        elif t is DestructureLet:
            self._analyze_expr(node.value)
            if isinstance(node.pattern, ListPattern):
                for name in node.pattern.elements:
                    self._define_var(name, line)
            elif isinstance(node.pattern, DictPattern):
                for _, var_name in node.pattern.pairs:
                    self._define_var(var_name, line)

        elif t is ClassDef:
            self._define_var(node.name, line)
            self._push_scope()
            self.scope_stack[-1].add("self")
            for method in node.methods:
                self._analyze_stmt(method)
            self._pop_scope()
        
        elif t is IndexSet:
            self._analyze_expr(node.obj)
            self._analyze_expr(node.index)
            self._analyze_expr(node.value)
        
        elif t is SetAttr:
            self._analyze_expr(node.obj)
            self._analyze_expr(node.value)
    
    def _analyze_pattern(self, pattern):
        """Register variable bindings introduced by a match pattern."""
        from .ast_nodes import Ident, ListLiteral, DictLiteral, Number, String, Bool, Null
        t = type(pattern)
        if t is Ident and pattern.name != "_":
            self._define_var(pattern.name, self.current_line)
        elif t is ListLiteral:
            for elem in pattern.elements:
                self._analyze_pattern(elem)
        elif t is DictLiteral:
            for _, val_pat in pattern.pairs:
                self._analyze_pattern(val_pat)

    def _analyze_expr(self, node):
        """Analyze an expression."""
        t = type(node)
        line = getattr(node, 'line', 0)
        if line:
            self.current_line = line

        if t is Ident:
            self._check_var_defined(node.name, self.current_line)
        
        elif t is BinOp:
            self._analyze_expr(node.left)
            self._analyze_expr(node.right)
        
        elif t is UnaryOp:
            self._analyze_expr(node.right)
        
        elif t is Call:
            self._check_var_defined(node.name, 0)
            for arg in node.args:
                self._analyze_expr(arg)
        
        elif t is CallExpr:
            self._analyze_expr(node.callee)
            for arg in node.args:
                self._analyze_expr(arg)
        
        elif t is ListLiteral:
            for elem in node.elements:
                self._analyze_expr(elem)
        
        elif t is DictLiteral:
            for k, v in node.pairs:
                self._analyze_expr(k)
                self._analyze_expr(v)
        
        elif t is IndexGet:
            self._analyze_expr(node.obj)
            self._analyze_expr(node.index)
        
        elif t is GetAttr:
            self._analyze_expr(node.obj)
        
        elif t is MethodCall:
            self._analyze_expr(node.obj)
            for arg in node.args:
                self._analyze_expr(arg)
        
        elif t is AnonFn:
            self._push_scope()
            for param in node.params:
                p_name = param[0] if isinstance(param, (tuple, list)) else param
                self._define_var(p_name, 0)
            for stmt in node.body:
                self._analyze_stmt(stmt)
            self._pop_scope()
        
        elif t is AwaitExpr:
            self._analyze_expr(node.expr)
        
        elif t is TemplateStr:
            for part in node.parts:
                if not isinstance(part, str):
                    self._analyze_expr(part)
        
        # Literals don't need analysis
    
    def _check_unused_vars(self):
        """Check for declared but unused variables."""
        for name, line in self.declared_vars.items():
            if name not in self.used_vars:
                # Skip if it's a function or class name (might be exported)
                if not name.startswith('_'):
                    self.diagnostics.append(LintDiagnostic(
                        Severity.INFO,
                        f"Variable '{name}' is declared but never used",
                        line
                    ))


def lint_code(source: str) -> List[LintDiagnostic]:
    """Lint Mo source code."""
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    linter = Linter()
    return linter.lint(ast)


def lint_file(path: str) -> List[LintDiagnostic]:
    """Lint a Mo file."""
    with open(path) as f:
        source = f.read()
    return lint_code(source)
