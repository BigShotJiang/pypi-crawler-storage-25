"""
jit.py — JIT compiler for Mo bytecode using Python's compile().
Monitors call counts and compiles functions after N calls.
"""
from __future__ import annotations
import ast
import time
from typing import Callable, Any, Dict
from dataclasses import dataclass, field

from .compiler import Instr, Op
from .interpreter import Environment


JIT_COMPILE_THRESHOLD = 100


@dataclass
class JITFunction:
    name: str
    params: list[str]
    code: Callable
    call_count: int = 0


class JitCompiler:
    def __init__(self, compile_threshold: int = JIT_COMPILE_THRESHOLD):
        self._compile_threshold = compile_threshold
        self._compiled: dict[str, JITFunction] = {}
        self._call_counts: dict[str, int] = {}

    def get_call_count(self, fn_name: str) -> int:
        return self._call_counts.get(fn_name, 0)

    def record_call(self, fn_name: str) -> int:
        self._call_counts[fn_name] = self._call_counts.get(fn_name, 0) + 1
        return self._call_counts[fn_name]

    def should_compile(self, fn_name: str) -> bool:
        return self._call_counts.get(fn_name, 0) >= self._compile_threshold

    def compile_function(self, fn_name: str, params: list[str], code: list, closure: Environment) -> Callable:
        try:
            python_code = self._bytecode_to_python(fn_name, params, code, closure)
            compiled = compile(python_code, f"<mo:{fn_name}>", "exec")
            globals_dict = self._get_builtins()
            globals_dict.update(closure.vars.copy())
            local_ns: dict = {}
            exec(compiled, globals_dict, local_ns)
            result = local_ns.get(fn_name)
            if result is None:
                return None
            jit_fn = JITFunction(
                name=fn_name,
                params=params,
                code=result,
                call_count=self._call_counts.get(fn_name, 0)
            )
            self._compiled[fn_name] = jit_fn
            return result
        except Exception:
            return None

    def _get_builtins(self) -> Dict:
        return {
            'len': len,
            'range': range,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict,
            'tuple': tuple,
            'set': set,
            'type': type,
            'print': print,
            'abs': abs,
            'min': min,
            'max': max,
            'sum': sum,
            'ord': ord,
            'chr': chr,
            'round': round,
            'pow': pow,
            'sorted': sorted,
            'enumerate': enumerate,
            'zip': zip,
            'any': any,
            'all': all,
            'isinstance': isinstance,
        }

    def _bytecode_to_python(self, fn_name: str, params: list[str], code: list, closure: Environment) -> str:
        temp_decls = []
        statements = []
        stack = []
        param_set = set(params)
        
        for instr in code:
            if instr.op is Op.LINE:
                continue
            
            elif instr.op is Op.LOAD_CONST:
                const_name = f"_const_{len(temp_decls)}"
                temp_decls.append(f"{const_name} = {repr(instr.arg)}")
                stack.append(const_name)
            
            elif instr.op is Op.LOAD_NAME:
                if instr.arg in param_set:
                    stack.append(instr.arg)
                elif instr.arg in closure.vars:
                    stack.append(instr.arg)
                else:
                    raise ValueError(f"Unknown variable: {instr.arg}")
            
            elif instr.op is Op.DEFINE_NAME:
                val = stack.pop()
                statements.append(f"{instr.arg} = {val}")
            
            elif instr.op is Op.STORE_NAME:
                val = stack.pop()
                statements.append(f"{instr.arg} = {val}")
            
            elif instr.op is Op.BINARY_OP:
                right = stack.pop()
                left = stack.pop()
                result_name = f"_expr_{len(temp_decls)}"
                expr = self._binop_expr(left, right, instr.arg)
                temp_decls.append(f"{result_name} = {expr}")
                stack.append(result_name)
            
            elif instr.op is Op.UNARY_OP:
                val = stack.pop()
                result_name = f"_expr_{len(temp_decls)}"
                if instr.arg == '-':
                    temp_decls.append(f"{result_name} = (-{val})")
                else:
                    temp_decls.append(f"{result_name} = (not {val})")
                stack.append(result_name)
            
            elif instr.op is Op.POP:
                statements.append(f"_ = {stack.pop()}")
            
            elif instr.op is Op.RETURN:
                if stack:
                    statements.append(f"return {stack.pop()}")
                else:
                    statements.append("return None")
                break
            
            elif instr.op is Op.MAKE_LIST:
                items = [stack.pop() for _ in range(instr.arg)]
                items.reverse()
                result_name = f"_list_{len(temp_decls)}"
                temp_decls.append(f"{result_name} = [{', '.join(items)}]")
                stack.append(result_name)
            
            elif instr.op is Op.MAKE_DICT:
                pairs = []
                for _ in range(instr.arg):
                    v = stack.pop()
                    k = stack.pop()
                    pairs.append(f"{repr(k)}: {v}")
                pairs.reverse()
                result_name = f"_dict_{len(temp_decls)}"
                temp_decls.append(f"{result_name} = {{{', '.join(pairs)}}}")
                stack.append(result_name)
            
            elif instr.op is Op.INDEX_GET:
                idx = stack.pop()
                obj = stack.pop()
                result_name = f"_idx_{len(temp_decls)}"
                temp_decls.append(f"{result_name} = {obj}[{idx}]")
                stack.append(result_name)
            
            elif instr.op is Op.INDEX_SET:
                val = stack.pop()
                idx = stack.pop()
                obj = stack.pop()
                statements.append(f"{obj}[{idx}] = {val}")
                stack.append(val)
            
            elif instr.op is Op.JUMP:
                break
            
            elif instr.op is Op.JUMP_IF_FALSE:
                break
            
            elif instr.op is Op.CALL:
                break
            
            elif instr.op is Op.GET_ATTR:
                break
            
            elif instr.op is Op.METHOD_CALL:
                break
            
            elif instr.op is Op.MAKE_FUNCTION:
                break
            
            else:
                raise ValueError(f"Unsupported opcode: {instr.op}")

        lines = ["def " + fn_name + "(" + ", ".join(params) + "):"]
        
        for decl in temp_decls:
            lines.append(f"    {decl}")
        
        for stmt in statements:
            lines.append(f"    {stmt}")
        
        if not any(s.strip().startswith("return") for s in statements):
            lines.append("    return None")
        
        return "\n".join(lines)

    def _binop_expr(self, left: str, right: str, op: str) -> str:
        ops = {
            "+": "{left} + {right}",
            "-": "{left} - {right}",
            "*": "{left} * {right}",
            "/": "{left} / {right}",
            "%": "{left} % {right}",
            "==": "{left} == {right}",
            "!=": "{left} != {right}",
            "<": "{left} < {right}",
            ">": "{left} > {right}",
            "<=": "{left} <= {right}",
            ">=": "{left} >= {right}",
        }
        if op in ops:
            return ops[op].format(left=left, right=right)
        return f"({left} {op} {right})"

    def get_stats(self) -> dict:
        return {
            "compiled": len(self._compiled),
            "call_counts": dict(self._call_counts),
        }


class JitVM:
    def __init__(self, use_jit: bool = False, compile_threshold: int = JIT_COMPILE_THRESHOLD):
        self.use_jit = use_jit
        self._jit: JitCompiler = JitCompiler(compile_threshold=compile_threshold) if use_jit else None

    def record_call(self, fn_name: str) -> int:
        if self._jit:
            return self._jit.record_call(fn_name)
        return 0

    def should_compile(self, fn_name: str) -> bool:
        if self._jit:
            return self._jit.should_compile(fn_name)
        return False

    def compile_function(self, fn_name: str, params: list[str], code: list, closure: Environment) -> Callable:
        if self._jit:
            return self._jit.compile_function(fn_name, params, code, closure)
        return None

    def get_jit_stats(self) -> dict:
        if self._jit:
            return self._jit.get_stats()
        return {}