"""
formatter.py — Mo language code formatter (mo fmt)

Usage:
    mo fmt <file.mo>          # format file in-place
    mo fmt --check <file.mo>  # check if formatting is needed
    mo fmt --write <file.mo>  # output to stdout
"""
from __future__ import annotations
from typing import List, Optional
from dataclasses import dataclass

from .lexer import Lexer, Token
from .parser import Parser
from .ast_nodes import *


class Formatter:
    """Pretty printer for Mo AST."""
    
    def __init__(self, indent_size: int = 4):
        self.indent_size = indent_size
        self.indent_level = 0
        self.output = []
    
    def format(self, stmts: List) -> str:
        """Format a list of statements."""
        self.output = []
        self.indent_level = 0
        for i, stmt in enumerate(stmts):
            if i > 0:
                self._newline()
            self._format_stmt(stmt)
        return "".join(self.output)
    
    def _indent(self):
        """Add current indentation."""
        self.output.append(" " * (self.indent_level * self.indent_size))
    
    def _newline(self):
        """Add newline."""
        self.output.append("\n")
    
    def _increase_indent(self):
        self.indent_level += 1
    
    def _decrease_indent(self):
        self.indent_level -= 1
    
    def _format_stmt(self, node):
        """Format a statement."""
        t = type(node)
        
        if t is LetStmt:
            self._indent()
            self.output.append("let ")
            self.output.append(node.name)
            if node.type_hint:
                self.output.append(": ")
                self.output.append(node.type_hint)
            self.output.append(" = ")
            self._format_expr(node.value)
        
        elif t is AssignStmt:
            self._indent()
            self.output.append(node.name)
            self.output.append(" = ")
            self._format_expr(node.value)
        
        elif t is ExprStmt:
            self._indent()
            self._format_expr(node.expr)
        
        elif t is FnDef:
            self._indent()
            self.output.append("fn ")
            self.output.append(node.name)
            self.output.append("(")
            self._format_params(node.params)
            self.output.append(") {")
            self._increase_indent()
            for stmt in node.body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is AsyncFn:
            self._indent()
            self.output.append("async fn ")
            self.output.append(node.name)
            self.output.append("(")
            self._format_params(node.params)
            self.output.append(") {")
            self._increase_indent()
            for stmt in node.body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is ReturnStmt:
            self._indent()
            self.output.append("return")
            if node.value is not None:
                self.output.append(" ")
                self._format_expr(node.value)
        
        elif t is IfStmt:
            self._indent()
            self.output.append("if ")
            self._format_expr(node.condition)
            self.output.append(" {")
            self._increase_indent()
            for stmt in node.then_body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
            if node.else_body:
                if len(node.else_body) == 1 and type(node.else_body[0]) is IfStmt:
                    # else if
                    self.output.append(" else ")
                    self._format_stmt(node.else_body[0])
                else:
                    self.output.append(" else {")
                    self._increase_indent()
                    for stmt in node.else_body:
                        self._newline()
                        self._format_stmt(stmt)
                    self._decrease_indent()
                    self._newline()
                    self._indent()
                    self.output.append("}")
        
        elif t is WhileStmt:
            self._indent()
            self.output.append("while ")
            self._format_expr(node.condition)
            self.output.append(" {")
            self._increase_indent()
            for stmt in node.body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is ForStmt:
            self._indent()
            self.output.append("for ")
            self.output.append(node.var)
            self.output.append(" in ")
            self._format_expr(node.iter)
            self.output.append(" {")
            self._increase_indent()
            for stmt in node.body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is BreakStmt:
            self._indent()
            self.output.append("break")
        
        elif t is ContinueStmt:
            self._indent()
            self.output.append("continue")
        
        elif t is TryCatch:
            self._indent()
            self.output.append("try {")
            self._increase_indent()
            for stmt in node.try_body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("} catch ")
            self.output.append(node.err_var)
            self.output.append(" {")
            self._increase_indent()
            for stmt in node.catch_body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is ThrowStmt:
            self._indent()
            self.output.append("throw ")
            self._format_expr(node.value)
        
        elif t is ImportStmt:
            self._indent()
            self.output.append('import "')
            self.output.append(node.path)
            self.output.append('"')
            if node.alias:
                self.output.append(" as ")
                self.output.append(node.alias)
        
        elif t is ClassDef:
            self._indent()
            self.output.append("class ")
            self.output.append(node.name)
            if node.parent:
                self.output.append(" extends ")
                self.output.append(node.parent)
            self.output.append(" {")
            self._increase_indent()
            for method in node.methods:
                self._newline()
                self._format_stmt(method)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is IndexSet:
            self._indent()
            self._format_expr(node.obj)
            self.output.append("[")
            self._format_expr(node.index)
            self.output.append("] = ")
            self._format_expr(node.value)
        
        elif t is SetAttr:
            self._indent()
            self._format_expr(node.obj)
            self.output.append(".")
            self.output.append(node.attr)
            self.output.append(" = ")
            self._format_expr(node.value)
        
        else:
            # Unknown statement type
            self._indent()
            self.output.append(f"# Unknown statement: {type(node).__name__}")
    
    def _format_expr(self, node):
        """Format an expression."""
        t = type(node)
        
        if t is Number:
            if node.value == int(node.value):
                self.output.append(str(int(node.value)))
            else:
                self.output.append(str(node.value))
        
        elif t is String:
            self.output.append('"')
            self.output.append(node.value)
            self.output.append('"')
        
        elif t is Bool:
            self.output.append("true" if node.value else "false")
        
        elif t is Null:
            self.output.append("null")
        
        elif t is Ident:
            self.output.append(node.name)
        
        elif t is BinOp:
            self._format_expr(node.left)
            self.output.append(" ")
            self.output.append(node.op)
            self.output.append(" ")
            self._format_expr(node.right)
        
        elif t is UnaryOp:
            self.output.append(node.op)
            self._format_expr(node.right)
        
        elif t is Call:
            self.output.append(node.name)
            self.output.append("(")
            self._format_args(node.args)
            self.output.append(")")
        
        elif t is CallExpr:
            self._format_expr(node.callee)
            self.output.append("(")
            self._format_args(node.args)
            self.output.append(")")
        
        elif t is ListLiteral:
            self.output.append("[")
            self._format_args(node.elements)
            self.output.append("]")
        
        elif t is DictLiteral:
            self.output.append("{")
            for i, (k, v) in enumerate(node.pairs):
                if i > 0:
                    self.output.append(", ")
                self._format_expr(k)
                self.output.append(": ")
                self._format_expr(v)
            self.output.append("}")
        
        elif t is IndexGet:
            self._format_expr(node.obj)
            self.output.append("[")
            self._format_expr(node.index)
            self.output.append("]")
        
        elif t is GetAttr:
            self._format_expr(node.obj)
            self.output.append(".")
            self.output.append(node.attr)
        
        elif t is SetAttr:
            self._format_expr(node.obj)
            self.output.append(".")
            self.output.append(node.attr)
            self.output.append(" = ")
            self._format_expr(node.value)
        
        elif t is MethodCall:
            self._format_expr(node.obj)
            self.output.append(".")
            self.output.append(node.method)
            self.output.append("(")
            self._format_args(node.args)
            self.output.append(")")
        
        elif t is AnonFn:
            self.output.append("fn(")
            self._format_params(node.params)
            self.output.append(") {")
            self._increase_indent()
            for stmt in node.body:
                self._newline()
                self._format_stmt(stmt)
            self._decrease_indent()
            self._newline()
            self._indent()
            self.output.append("}")
        
        elif t is AwaitExpr:
            self.output.append("await ")
            self._format_expr(node.expr)
        
        elif t is TemplateStr:
            self.output.append('`')
            for part in node.parts:
                if isinstance(part, str):
                    self.output.append(part)
                else:
                    self.output.append('${')
                    self._format_expr(part)
                    self.output.append('}')
            self.output.append('`')
        
        else:
            self.output.append(f"/* Unknown expr: {type(node).__name__} */")
    
    def _format_params(self, params: List[str]):
        """Format parameter list."""
        for i, param in enumerate(params):
            if i > 0:
                self.output.append(", ")
            self.output.append(param)
    
    def _format_args(self, args: List):
        """Format argument list."""
        for i, arg in enumerate(args):
            if i > 0:
                self.output.append(", ")
            self._format_expr(arg)


def format_code(source: str, indent_size: int = 4) -> str:
    """Format Mo source code."""
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    formatter = Formatter(indent_size)
    return formatter.format(ast)


def format_file(path: str, indent_size: int = 4) -> str:
    """Format a Mo file."""
    with open(path) as f:
        source = f.read()
    return format_code(source, indent_size)
