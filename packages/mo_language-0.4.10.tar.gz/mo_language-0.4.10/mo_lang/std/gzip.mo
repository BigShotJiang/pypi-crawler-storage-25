# std/gzip.mo - Compression

fn compress(data) {
    return __gzip_compress__(data)
}

fn decompress(hex_data) {
    return __gzip_decompress__(hex_data)
}

fn compress_file(path) {
    let data = read(path)
    return compress(data)
}

fn decompress_to_file(hex_data, path) {
    let data = decompress(hex_data)
    write(path, data)
}