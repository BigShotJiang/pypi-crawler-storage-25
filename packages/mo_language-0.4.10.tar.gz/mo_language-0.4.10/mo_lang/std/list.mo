# std/list.my — higher-order list functions

fn map(lst, f) {
    let result = []
    for item in lst {
        push(result, f(item))
    }
    return result
}

fn filter(lst, f) {
    let result = []
    for item in lst {
        if f(item) {
            push(result, item)
        }
    }
    return result
}

fn reduce(lst, f, init) {
    let acc = init
    for item in lst {
        acc = f(acc, item)
    }
    return acc
}

fn sum(lst) {
    let acc = 0
    for item in lst {
        acc = acc + item
    }
    return acc
}

fn any(lst, f) {
    for item in lst {
        if f(item) { return true }
    }
    return false
}

fn all(lst, f) {
    for item in lst {
        if !f(item) { return false }
    }
    return true
}

fn indexOf(lst, val) {
    let i = 0
    for item in lst {
        if item == val { return i }
        i = i + 1
    }
    return -1
}

fn remove(lst, idx) {
    let result = []
    let i = 0
    for item in lst {
        if i != idx { push(result, item) }
        i = i + 1
    }
    return result
}

fn reverse(lst) {
    let result = []
    let i = len(lst) - 1
    while i >= 0 {
        push(result, lst[i])
        i = i - 1
    }
    return result
}

fn sort(lst) {
    let n = len(lst)
    let i = 0
    while i < n {
        let j = i + 1
        while j < n {
            if lst[j] < lst[i] {
                let tmp = lst[i]
                lst[i] = lst[j]
                lst[j] = tmp
            }
            j = j + 1
        }
        i = i + 1
    }
    return lst
}

fn flatten(lst) {
    let result = []
    for item in lst {
        if type(item) == "list" {
            for x in item { push(result, x) }
        } else {
            push(result, item)
        }
    }
    return result
}

fn zip(a, b) {
    let result = []
    let i = 0
    let n = len(a)
    if len(b) < n { n = len(b) }
    while i < n {
        push(result, [a[i], b[i]])
        i = i + 1
    }
    return result
}

fn take(lst, n) {
    let result = []
    let i = 0
    for item in lst {
        if i >= n { return result }
        push(result, item)
        i = i + 1
    }
    return result
}

fn drop(lst, n) {
    let result = []
    let i = 0
    for item in lst {
        if i >= n { push(result, item) }
        i = i + 1
    }
    return result
}

fn count(lst, val) {
    let n = 0
    for item in lst {
        if item == val { n = n + 1 }
    }
    return n
}

# Iterator protocol for lists
fn list_iter(lst) {
    return {"_list": lst, "_index": 0}
}

fn list_has_next(it) {
    return it._index < len(it._list)
}

fn list_next(it) {
    let val = it._list[it._index]
    it._index = it._index + 1
    return val
}
