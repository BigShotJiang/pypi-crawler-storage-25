# std/redis.mo - Redis client

fn connect(host, port) {
    return __redis_connect__(host, port)
}

fn set(redis, key, value) {
    return __redis_set__(redis, key, str(value))
}

fn get(redis, key) {
    return __redis_get__(redis, key)
}

fn delete(redis, key) {
    return __redis_delete__(redis, key)
}

fn close(redis) {
    return __redis_close__(redis)
}