# std/xml.mo — minimal XML builder

fn _escape(s) {
    let r = replace(s, "&", "&amp;")
    r = replace(r, "<", "&lt;")
    r = replace(r, ">", "&gt;")
    r = replace(r, "\"", "&quot;")
    return r
}

fn elem(tag, text) {
    return "<" + tag + ">" + _escape(to_str(text)) + "</" + tag + ">"
}

fn elem_attrs(tag, attrs, text) {
    let s = "<" + tag
    for k in keys(attrs) {
        s = s + " " + k + "=\"" + _escape(to_str(attrs[k])) + "\""
    }
    s = s + ">" + _escape(to_str(text)) + "</" + tag + ">"
    return s
}

fn attr(k, v) {
    return k + "=\"" + _escape(to_str(v)) + "\""
}

fn parse(text) {
    # Minimal: returns list of {tag, text} dicts for top-level elements
    let result = []
    let i = 0
    let n = len(text)
    while i < n {
        while i < n && text[i] != "<" { i = i + 1 }
        if i >= n { break }
        i = i + 1
        if i < n && (text[i] == "!" || text[i] == "?") {
            while i < n && text[i] != ">" { i = i + 1 }
            i = i + 1
        } else if i < n && text[i] != "/" {
            let ts = i
            while i < n && text[i] != " " && text[i] != ">" && text[i] != "/" { i = i + 1 }
            let tag = substr(text, ts, i)
            while i < n && text[i] != ">" { i = i + 1 }
            i = i + 1
            let cs = i
            while i < n && text[i] != "<" { i = i + 1 }
            let content = substr(text, cs, i)
            push(result, {"tag": tag, "text": content})
        } else {
            while i < n && text[i] != ">" { i = i + 1 }
            i = i + 1
        }
    }
    return result
}

fn stringify(nodes) {
    let out = "<?xml version=\"1.0\"?>\n"
    for node in nodes {
        out = out + elem(node["tag"], node["text"]) + "\n"
    }
    return out
}

fn to_string(nodes) { return stringify(nodes) }
