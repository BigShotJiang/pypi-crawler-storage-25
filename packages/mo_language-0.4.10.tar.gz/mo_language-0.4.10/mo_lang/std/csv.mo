# std/csv.mo — CSV read and write

fn parse(text)      { return csvParse(text) }
fn stringify(data)  { return csvStringify(data) }

fn read(path) {
    return csvParse(readFile(path))
}

fn write(path, data) {
    return writeFile(path, csvStringify(data))
}
