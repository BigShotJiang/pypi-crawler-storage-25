# std/string.mo — string utilities

fn split(s, delim) {
    let result = []
    let current = ""
    let i = 0
    let dlen = len(delim)
    while i < len(s) {
        if s[i:i+dlen] == delim {
            push(result, current)
            current = ""
            i = i + dlen
        } else {
            current = current + s[i]
            i = i + 1
        }
    }
    push(result, current)
    return result
}

fn join(lst, sep) {
    let result = ""
    let i = 0
    for item in lst {
        if i > 0 { result = result + sep }
        result = result + str(item)
        i = i + 1
    }
    return result
}

fn repeat(s, n) {
    let result = ""
    let i = 0
    while i < n {
        result = result + s
        i = i + 1
    }
    return result
}

fn startsWith(s, prefix) {
    if len(prefix) > len(s) { return false }
    return s[0:len(prefix)] == prefix
}

fn endsWith(s, suffix) {
    if len(suffix) > len(s) { return false }
    return s[len(s)-len(suffix):len(s)] == suffix
}

fn replace(s, old, new) {
    let result = ""
    let i = 0
    let olen = len(old)
    while i < len(s) {
        if s[i:i+olen] == old {
            result = result + new
            i = i + olen
        } else {
            result = result + s[i]
            i = i + 1
        }
    }
    return result
}

fn indexOf(s, sub) {
    let slen = len(s)
    let sublen = len(sub)
    let i = 0
    while i <= slen - sublen {
        if s[i:i+sublen] == sub { return i }
        i = i + 1
    }
    return -1
}

fn trim(s) {
    let start = 0
    while start < len(s) && (s[start] == " " || s[start] == "\t" || s[start] == "\n") {
        start = start + 1
    }
    let end = len(s) - 1
    while end >= start && (s[end] == " " || s[end] == "\t" || s[end] == "\n") {
        end = end - 1
    }
    if start > end { return "" }
    return s[start:end+1]
}

fn padLeft(s, width, char) {
    while len(s) < width { s = char + s }
    return s
}

fn padRight(s, width, char) {
    while len(s) < width { s = s + char }
    return s
}
