# std/template.mo - Template engine

fn render(template, data) {
    return __template_render__(template, data)
}

fn escape(s) {
    return __template_escape__(s)
}

fn for_each(items, item_name, template, data) {
    let parts = []
    for item in items {
        let item_data = { item_name: item }
        for k in item {
            item_data[k] = item[k]
        }
        push(parts, render(template, item_data))
    }
    return join(parts, "")
}