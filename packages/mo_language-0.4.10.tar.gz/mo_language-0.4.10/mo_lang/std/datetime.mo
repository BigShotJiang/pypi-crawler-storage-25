# std/datetime.mo - Date and time handling

fn now() {
    return __date_now__()
}

fn today() {
    return now()
}

fn date(timestamp) {
    if timestamp {
        return __date_from_ts__(timestamp)
    }
    return now()
}

fn format(d, fmt) {
    let s = str(d.year)
    if d.month < 10 { s = s + "-0" + str(d.month) }
    else { s = s + "-" + str(d.month) }
    if d.day < 10 { s = s + "-0" + str(d.day) }
    else { s = s + "-" + str(d.day) }
    if fmt && fmt == "datetime" {
        if d.hour < 10 { s = s + " 0" + str(d.hour) }
        else { s = s + " " + str(d.hour) }
        if d.minute < 10 { s = s + ":0" + str(d.minute) }
        else { s = s + ":" + str(d.minute) }
        if d.second < 10 { s = s + ":0" + str(d.second) }
        else { s = s + ":" + str(d.second) }
    }
    return s
}

fn weekday_name(d) {
    let names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    return names[d.weekday]
}

fn month_name(d) {
    let names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    return names[d.month - 1]
}

fn add_days(d, days) {
    let ts = __date_timestamp__(d)
    return __date_from_ts__(ts + days * 86400)
}