# std/cache.mo - LRU Cache

fn create(max_size) {
    return __cache_create__(max_size || 100)
}

fn get(cache, key) {
    return __cache_get__(cache, key)
}

fn set(cache, key, value) {
    __cache_set__(cache, key, value)
}

fn clear(cache) {
    cache._data = {}
    cache._order = []
}

fn size(cache) {
    return len(cache._data)
}

fn has(cache, key) {
    return has(cache._data, key)
}