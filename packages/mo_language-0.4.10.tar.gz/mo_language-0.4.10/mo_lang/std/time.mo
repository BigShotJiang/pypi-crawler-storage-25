# std/time.mo — time utilities

fn now()             { return __time_now__() }
fn ms()              { return __time_ms__() }
fn sleep(secs)       { return __time_sleep__(secs) }
fn format(ts, fmt)   { return __time_format__(ts, fmt) }
fn format_ts(ts)     { return __time_format__(ts) }
fn clock()           { return __time_now__() }
