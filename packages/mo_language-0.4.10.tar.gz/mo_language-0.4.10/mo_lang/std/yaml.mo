# std/yaml.mo — minimal YAML stringify (parse not supported without C extension)

fn _indent(n) {
    let s = ""
    let i = 0
    while i < n {
        s = s + "  "
        i = i + 1
    }
    return s
}

fn _val(v, depth) {
    let t = type(v)
    if t == "nil"    { return "null" }
    if t == "bool"   { if v { return "true" } return "false" }
    if t == "int" || t == "float" { return to_str(v) }
    if t == "string" {
        if contains(v, ":") || contains(v, "#") || contains(v, "\"") {
            return "\"" + v + "\""
        }
        return v
    }
    if t == "list" {
        if len(v) == 0 { return "[]" }
        let out = "\n"
        for item in v {
            out = out + _indent(depth) + "- " + _val(item, depth + 1) + "\n"
        }
        return out
    }
    if t == "dict" {
        if len(keys(v)) == 0 { return "{}" }
        let out = "\n"
        for k in keys(v) {
            out = out + _indent(depth) + k + ": " + _val(v[k], depth + 1) + "\n"
        }
        return out
    }
    return to_str(v)
}

fn stringify(obj) {
    let t = type(obj)
    if t == "dict" {
        let out = ""
        for k in keys(obj) {
            out = out + k + ": " + _val(obj[k], 1) + "\n"
        }
        return out
    }
    if t == "list" {
        let out = ""
        for item in obj {
            out = out + "- " + _val(item, 1) + "\n"
        }
        return out
    }
    return _val(obj, 0) + "\n"
}

fn parse(text) {
    # Basic key: value parser (flat only, no nested)
    let result = {}
    let lines = split(text, "\n")
    for line in lines {
        let trimmed = trim(line)
        if len(trimmed) == 0 { continue }
        if startsWith(trimmed, "#") { continue }
        let idx = indexOf(trimmed, ": ")
        if idx >= 0 {
            let k = substr(trimmed, 0, idx)
            let v = substr(trimmed, idx+2, len(trimmed))
            result[k] = v
        }
    }
    return result
}
