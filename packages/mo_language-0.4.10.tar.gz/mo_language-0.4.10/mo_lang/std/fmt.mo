# std/fmt.mo - String formatting

fn format(template, args) {
    return __fmt__(template, args)
}

fn printf(template, args) {
    __printf__(template, args)
}

fn pad_left(s, width, char) {
    char = char || " "
    while len(s) < width {
        s = char + s
    }
    return s
}

fn pad_right(s, width, char) {
    char = char || " "
    while len(s) < width {
        s = s + char
    }
    return s
}

fn center(s, width, char) {
    char = char || " "
    let padding = width - len(s)
    if padding <= 0 {
        return s
    }
    let left = repeat(" ", padding / 2)
    let right = repeat(" ", padding - len(left))
    return left + s + right
}