# std/json.mo — JSON parse and stringify

fn parse(s) {
    return __json_parse__(s)
}

fn stringify(val) {
    return __json_stringify__(val)
}
