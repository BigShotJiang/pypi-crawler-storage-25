# std/audio.mo - Audio playback

fn play(path) {
    __audio_play__(path)
}

fn stop() {
    print("audio.stop: not implemented")
}