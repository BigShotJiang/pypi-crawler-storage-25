# std/test.mo - Unit testing framework

let _test_count = 0
let _pass_count = 0
let _fail_count = 0
let _failures = []

fn describe(name, callback) {
    print("\n" + name)
    print(repeat("=", len(name)))
    _test_count = 0
    _pass_count = 0
    _fail_count = 0
    _failures = []
    callback()
    print("\nTests: " + str(_pass_count) + "/" + str(_test_count) + " passed")
    if _fail_count > 0 {
        print("Failures:")
        for f in _failures {
            print("  - " + f)
        }
    }
}

fn it(description, callback) {
    _test_count = _test_count + 1
    try {
        callback()
        _pass_count = _pass_count + 1
        print("  OK " + description)
    } catch e {
        _fail_count = _fail_count + 1
        push(_failures, description + ": " + str(e))
        print("  FAIL " + description)
    }
}

fn assert(condition) {
    if !condition {
        throw "Assertion failed"
    }
}

fn assert_equal(actual, expected) {
    __assert_equal__(actual, expected)
}

fn assert_contains(haystack, needle) {
    if !contains(str(haystack), str(needle)) {
        throw "Expected '" + str(haystack) + "' to contain '" + str(needle) + "'"
    }
}

fn assert_throws(callback) {
    __assert_throws__(callback)
}