# std/base64.mo - Base64 encoding/decoding

fn encode(data) {
    return __base64_encode__(data)
}

fn decode(data) {
    return __base64_decode__(data)
}

fn url_encode(data) {
    let encoded = encode(data)
    return replace(replace(replace(encoded, "+", "-"), "/", "_"), "=", "")
}

fn url_decode(data) {
    let fixed = data
    fixed = replace(replace(fixed, "-", "+"), "_", "/")
    while len(fixed) % 4 != 0 {
        fixed = fixed + "="
    }
    return decode(fixed)
}