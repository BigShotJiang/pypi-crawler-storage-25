# std/websocket.mo - WebSocket client

fn connect(url) {
    return __ws_connect__(url)
}

fn send(ws, message) {
    return __ws_send__(ws, message)
}

fn recv(ws) {
    return __ws_recv__(ws)
}

fn close(ws) {
    return __ws_close__(ws)
}