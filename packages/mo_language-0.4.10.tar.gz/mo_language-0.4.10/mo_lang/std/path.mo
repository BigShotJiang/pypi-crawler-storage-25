# std/path.mo — file path utilities

fn join(a, b) { return __path_join__(a, b) }
fn dir(p)     { return __path_dir__(p) }
fn base(p)    { return __path_base__(p) }
fn ext(p)     { return __path_ext__(p) }
fn abs(p)     { return __path_abs__(p) }
