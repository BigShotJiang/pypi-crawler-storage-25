# std/http.mo — HTTP client helpers
# Returns dict: {status, body, ok}

fn get(url)          { return __http_get__(url) }
fn post(url, body)   { return __http_post__(url, body) }
fn post_form(url, body) { return __http_post__(url, body, "application/x-www-form-urlencoded") }
fn fetch(url)        { return __http_get__(url) }
fn fetch_post(url, body) { return __http_post__(url, body) }

fn ok(resp)     { return resp["ok"] }
fn status(resp) { return resp["status"] }
fn body(resp)   { return resp["body"] }

fn text(b)      { return {"status": 200, "body": b, "type": "text/plain",       "ok": true} }
fn html(b)      { return {"status": 200, "body": b, "type": "text/html",        "ok": true} }
fn json_resp(d) { return {"status": 200, "body": d, "type": "application/json", "ok": true} }
fn not_found()  { return {"status": 404, "body": "Not Found",    "type": "text/plain", "ok": false} }
fn bad_request(msg) { return {"status": 400, "body": msg,        "type": "text/plain", "ok": false} }
fn error(msg)   { return {"status": 500, "body": msg,            "type": "text/plain", "ok": false} }
