# std/crypto.mo — hash functions

fn sha256(val)     { return __crypto_sha256__(val) }
fn sha256_hex(val) { return __crypto_sha256__(val) }
