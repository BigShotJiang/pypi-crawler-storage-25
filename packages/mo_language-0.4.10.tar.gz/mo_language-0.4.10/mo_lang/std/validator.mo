# std/validator.mo - Data validation

fn email(value) {
    return __validator_email__(value)
}

fn url(value) {
    return __validator_url__(value)
}

fn phone(value) {
    return __validator_phone__(value)
}

fn number(value) {
    return __validator_number__(value)
}

fn required(value) {
    return value != nil && value != ""
}

fn min_length(value, length) {
    return len(str(value)) >= length
}

fn max_length(value, length) {
    return len(str(value)) <= length
}

fn range(value, min_val, max_val) {
    let n = num(value)
    return n >= min_val && n <= max_val
}

fn is_alpha(value) {
    let s = str(value)
    for c in s {
        if c < "a" || (c > "z" && c < "A") || c > "Z" {
            return false
        }
    }
    return len(s) > 0
}

fn is_alphanumeric(value) {
    let s = str(value)
    for c in s {
        if (c < "a" || c > "z") && (c < "A" || c > "Z") && (c < "0" || c > "9") {
            return false
        }
    }
    return len(s) > 0
}