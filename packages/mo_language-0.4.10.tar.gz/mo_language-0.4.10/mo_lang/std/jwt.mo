# std/jwt.mo - JWT authentication

let _secret = ""

fn set_secret(secret) {
    _secret = secret
}

fn create(payload) {
    return __jwt_create__(payload, _secret)
}

fn verify(token) {
    return __jwt_verify__(token, _secret)
}

fn decode(token) {
    return __jwt_decode__(token)
}

fn get_payload(token) {
    return decode(token)
}

fn is_expired(token) {
    let payload = decode(token)
    if has(payload, "exp") {
        return payload.exp < time_now()
    }
    return false
}