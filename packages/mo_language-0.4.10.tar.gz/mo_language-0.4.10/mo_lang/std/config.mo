# std/config.mo - Configuration file reading (TOML/YAML/JSON)

fn load(path) {
    return __config_load__(path)
}

fn get(config, key, default) {
    if has(config, key) {
        return config[key]
    }
    return default
}

fn get_nested(config, path, default) {
    let parts = split(path, ".")
    let current = config
    for part in parts {
        if is_dict(current) && has(current, part) {
            current = current[part]
        } else {
            return default
        }
    }
    return current
}