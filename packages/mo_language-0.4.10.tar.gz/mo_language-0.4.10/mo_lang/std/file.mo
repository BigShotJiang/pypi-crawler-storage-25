# std/file.mo — file system utilities

fn read(path)           { return __file_read__(path) }
fn write(path, content) { return __file_write__(path, content) }
fn append(path, content){ return __file_append__(path, content) }
fn exists(path)         { return __file_exists__(path) }
fn delete(path)         { return __file_delete__(path) }
fn ls(path)             { return __file_list__(path) }
fn is_dir(path)         { return __file_is_dir__(path) }
fn make_dir(path)       { return __file_mkdir__(path) }
fn cwd()                { return __os_cwd__() }
