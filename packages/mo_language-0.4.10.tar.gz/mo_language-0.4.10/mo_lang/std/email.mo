# std/email.mo - Email sending

fn send(options) {
    return __email_send__(options)
}

fn send_html(options) {
    options.html = true
    return send(options)
}