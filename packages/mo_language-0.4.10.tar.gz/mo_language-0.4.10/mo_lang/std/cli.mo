# std/cli.mo - Command line argument parsing

fn args() {
    return __cli_args__()
}

fn has_option(key) {
    return __cli_has_option__(nil, key)
}

fn get_option(key, default) {
    return __cli_get_option__(nil, key, default)
}