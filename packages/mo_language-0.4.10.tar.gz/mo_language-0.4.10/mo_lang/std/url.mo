# std/url.mo — URL parsing and encoding

fn parse(u)      { return __url_parse__(u) }
fn encode(s)     { return __url_encode__(s) }
fn decode(s)     { return __url_decode__(s) }
fn build(params) { return __url_build__(params) }
