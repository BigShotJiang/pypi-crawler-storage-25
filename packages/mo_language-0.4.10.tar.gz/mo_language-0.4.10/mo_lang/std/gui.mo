# std/gui.mo - GUI framework (Tkinter)

fn window(title, width, height) {
    return __gui_window__(title, width, height)
}

fn label(parent, text) {
    return __gui_label__(parent, text)
}

fn label_set(lbl, text) {
    __gui_label_set__(lbl, text)
}

fn button(parent, text, on_click) {
    return __gui_button__(parent, text, on_click)
}

fn frame(parent, orient) {
    return __gui_frame__(parent, orient)
}

fn entry(parent, placeholder) {
    return __gui_entry__(parent, placeholder)
}

fn entry_get(e) {
    return __gui_entry_get__(e)
}

fn entry_clear(e) {
    __gui_entry_clear__(e)
}

fn listbox(parent) {
    return __gui_listbox__(parent)
}

fn listbox_add(lb, text) {
    __gui_listbox_add__(lb, text)
}

fn listbox_selected(lb) {
    return __gui_listbox_selected__(lb)
}

fn listbox_delete(lb, index) {
    __gui_listbox_delete__(lb, index)
}

fn listbox_size(lb) {
    return __gui_listbox_size__(lb)
}

fn listbox_get(lb, index) {
    return __gui_listbox_get__(lb, index)
}

fn run() {
    __gui_run__()
}

fn message(parent, title, text) {
    print("GUI Message: " + title + " - " + text)
}

# ── Media Player ──────────────────────────────────────────────────────────────

fn media_player(parent, path) {
    return __gui_media_player__(parent, path)
}

fn media_play(player) {
    __gui_media_play__(player)
}

fn media_pause(player) {
    __gui_media_pause__(player)
}

fn media_stop(player) {
    __gui_media_stop__(player)
}

fn media_seek(player, seconds) {
    __gui_media_seek__(player, seconds)
}

fn media_volume(player, vol) {
    __gui_media_volume__(player, vol)
}

fn media_duration(player) {
    return __gui_media_duration__(player)
}

fn media_position(player) {
    return __gui_media_position__(player)
}

fn media_load(player, path) {
    __gui_media_load__(player, path)
}

fn media_is_playing(player) {
    return __gui_media_is_playing__(player)
}