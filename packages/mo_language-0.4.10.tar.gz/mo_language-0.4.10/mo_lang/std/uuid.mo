# std/uuid.mo - UUID generation

fn uuid4() {
    return __uuid4__()
}

fn uuid1() {
    return __uuid1__()
}

fn is_valid(uuid_str) {
    return len(uuid_str) == 36 && count(uuid_str, "-") == 4
}