# std/process.mo - Process management

fn run(cmd) {
    return __proc_run__(cmd)
}

fn start(cmd) {
    return __proc_start__(cmd)
}

fn wait(pid) {
    return __proc_wait__(pid)
}

fn kill(pid) {
    return run("kill " + to_str(pid))
}

fn current_pid() {
    return __proc_pid__()
}

fn exit(code) {
    __proc_exit__(code)
}