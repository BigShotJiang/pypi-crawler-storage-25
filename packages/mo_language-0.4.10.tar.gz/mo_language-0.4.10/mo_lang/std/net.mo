# std/net.mo — HTTP-based networking

fn get(url)        { return __http_get__(url) }
fn post(url, body) { return __http_post__(url, body, "application/json") }
