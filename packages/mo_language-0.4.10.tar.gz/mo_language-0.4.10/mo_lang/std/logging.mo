# std/logging.mo - Logging system

# Log levels
let DEBUG = 0
let INFO = 1
let WARNING = 2
let ERROR = 3
let CRITICAL = 4

let _current_level = INFO
let _log_file = nil

fn set_level(level) {
    _current_level = level
}

fn set_file(path) {
    _log_file = path
}

fn debug(msg) {
    if _current_level <= DEBUG {
        let log_msg = __log_debug__(msg)
        if _log_file {
            __file_append__(_log_file, log_msg + "\n")
        }
        print(log_msg)
    }
}

fn info(msg) {
    if _current_level <= INFO {
        let log_msg = __log_info__(msg)
        if _log_file {
            __file_append__(_log_file, log_msg + "\n")
        }
        print(log_msg)
    }
}

fn warning(msg) {
    if _current_level <= WARNING {
        let log_msg = __log_warning__(msg)
        if _log_file {
            __file_append__(_log_file, log_msg + "\n")
        }
        print(log_msg)
    }
}

fn error(msg) {
    if _current_level <= ERROR {
        let log_msg = __log_error__(msg)
        if _log_file {
            __file_append__(_log_file, log_msg + "\n")
        }
        print(log_msg)
    }
}

fn critical(msg) {
    if _current_level <= CRITICAL {
        let log_msg = __log_critical__(msg)
        if _log_file {
            __file_append__(_log_file, log_msg + "\n")
        }
        print(log_msg)
    }
}