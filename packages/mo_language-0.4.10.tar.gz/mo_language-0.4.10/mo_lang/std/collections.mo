# std/collections.mo — common data structures (stack, queue, set, heap)

# ============================================================================
# Stack — LIFO (Last In, First Out)
# Implemented using a list; operations are O(1)
# ============================================================================

fn stack() {
    return {"_data": [], "_type": "stack"}
}

fn stack_push(s, item) {
    push(s._data, item)
}

fn stack_pop(s) {
    if len(s._data) == 0 {
        return null
    }
    return pop(s._data)
}

fn stack_peek(s) {
    let n = len(s._data)
    if n == 0 {
        return null
    }
    return s._data[n - 1]
}

fn stack_is_empty(s) {
    return len(s._data) == 0
}

fn stack_size(s) {
    return len(s._data)
}

# ============================================================================
# Queue — FIFO (First In, First Out)
# Implemented using a list with offset stored in _state[1] for O(1) dequeue
# _state[0] is the data list, _state[1] is the offset (mutable via list index)
# ============================================================================

fn queue() {
    return {"_state": [[], 0], "_type": "queue"}
}

fn queue_enqueue(q, item) {
    push(q._state[0], item)
}

fn queue_dequeue(q) {
    if queue_is_empty(q) {
        return null
    }
    let item = q._state[0][q._state[1]]
    q._state[1] = q._state[1] + 1
    return item
}

fn queue_peek(q) {
    if queue_is_empty(q) {
        return null
    }
    return q._state[0][q._state[1]]
}

fn queue_is_empty(q) {
    return q._state[1] >= len(q._state[0])
}

fn queue_size(q) {
    return len(q._state[0]) - q._state[1]
}

# ============================================================================
# Set — Unordered collection of unique elements
# Implemented using a dict for O(1) add/remove/has
# ============================================================================

fn set() {
    return {"_data": {}, "_type": "set"}
}

fn set_add(st, item) {
    st._data[item] = true
}

fn set_remove(st, item) {
    delete(st._data, item)
}

fn set_has(st, item) {
    return has(st._data, item) && st._data[item] == true
}

fn set_size(st) {
    let count = 0
    for key in keys(st._data) {
        count = count + 1
    }
    return count
}

fn set_is_empty(st) {
    return set_size(st) == 0
}

fn set_to_list(st) {
    let result = []
    for key in keys(st._data) {
        push(result, key)
    }
    return result
}

fn set_union(a, b) {
    let result = set()
    for key in keys(a._data) {
        set_add(result, key)
    }
    for key in keys(b._data) {
        set_add(result, key)
    }
    return result
}

fn set_intersection(a, b) {
    let result = set()
    # Iterate over the smaller set for efficiency
    if set_size(a) > set_size(b) {
        let temp = a
        a = b
        b = temp
    }
    for key in keys(a._data) {
        if set_has(b, key) {
            set_add(result, key)
        }
    }
    return result
}

fn set_difference(a, b) {
    let result = set()
    for key in keys(a._data) {
        if !set_has(b, key) {
            set_add(result, key)
        }
    }
    return result
}

# ============================================================================
# Heap — Min-heap for priority queue operations
# Implemented using a binary heap stored in a list
# Parent/child relationships: parent(i) = (i-1)//2, left(i) = 2*i+1, right(i) = 2*i+2
# ============================================================================

fn heap() {
    return {"_data": [], "_type": "heap"}
}

fn _heap_parent(i) {
    return (i - 1) / 2
}

fn _heap_left(i) {
    return 2 * i + 1
}

fn _heap_right(i) {
    return 2 * i + 2
}

fn _heap_swap(h, i, j) {
    let temp = h._data[i]
    h._data[i] = h._data[j]
    h._data[j] = temp
}

fn _heap_sift_up(h, i) {
    while i > 0 {
        let parent = _heap_parent(i)
        if h._data[i] < h._data[parent] {
            _heap_swap(h, i, parent)
            i = parent
        } else {
            break
        }
    }
}

fn _heap_sift_down(h, i) {
    let n = len(h._data)
    while true {
        let smallest = i
        let left = _heap_left(i)
        let right = _heap_right(i)
        
        if left < n && h._data[left] < h._data[smallest] {
            smallest = left
        }
        if right < n && h._data[right] < h._data[smallest] {
            smallest = right
        }
        
        if smallest == i {
            break
        }
        
        _heap_swap(h, i, smallest)
        i = smallest
    }
}

fn heap_push(h, item) {
    push(h._data, item)
    _heap_sift_up(h, len(h._data) - 1)
}

fn heap_pop_min(h) {
    let n = len(h._data)
    if n == 0 {
        return null
    }
    if n == 1 {
        return pop(h._data)
    }
    
    let min_val = h._data[0]
    h._data[0] = pop(h._data)
    _heap_sift_down(h, 0)
    return min_val
}

fn heap_peek_min(h) {
    if len(h._data) == 0 {
        return null
    }
    return h._data[0]
}

fn heap_is_empty(h) {
    return len(h._data) == 0
}

fn heap_size(h) {
    return len(h._data)
}

fn heap_to_list(h) {
    # Returns a sorted list (ascending order) by extracting all elements
    let result = []
    let copy = heap()
    for item in h._data {
        heap_push(copy, item)
    }
    while !heap_is_empty(copy) {
        push(result, heap_pop_min(copy))
    }
    return result
}
