# std/decimal.mo - High precision decimals

fn create(value) {
    return __decimal__(value)
}

fn add(a, b) {
    return __decimal_add__(a, b)
}

fn mul(a, b) {
    return __decimal_mul__(a, b)
}

fn div(a, b) {
    let result = create(a) + " / " + create(b)
    return result
}

fn sub(a, b) {
    return add(a, "-" + str(b))
}

fn round(value, precision) {
    precision = precision || 2
    let d = create(value)
    let parts = split(d, ".")
    if len(parts) < 2 {
        return parts[0]
    }
    let int_part = parts[0]
    let dec_part = parts[1]
    if len(dec_part) <= precision {
        return int_part + "." + dec_part
    }
    return int_part + "." + substring(dec_part, 0, precision)
}