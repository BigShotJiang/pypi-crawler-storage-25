# std/math.mo — math utilities

let PI = 3.141592653589793
let E  = 2.718281828459045

fn pi() { return 3.141592653589793 }
fn e()  { return 2.718281828459045 }

fn abs(x)        { return __abs__(x) }
fn floor(x)      { return __floor__(x) }
fn ceil(x)       { return __ceil__(x) }
fn round(x)      { return __round__(x) }
fn sqrt(x)       { return __sqrt__(x) }
fn pow(b, e)     { return __pow__(b, e) }
fn min(a, b)     { return __min__(a, b) }
fn max(a, b)     { return __max__(a, b) }

fn clamp(val, lo, hi) {
    if val < lo { return lo }
    if val > hi { return hi }
    return val
}

fn log(x) {
    if x <= 0 { throw "log of non-positive number" }
    if x == 1 { return 0 }
    let n = 0
    let xv = x
    while xv >= 2 { xv = xv / E
        n = n + 1
    }
    while xv < 0.5 { xv = xv * E
        n = n - 1
    }
    let z = (xv - 1) / (xv + 1)
    let z2 = z * z
    let result = z
    let term = z
    let i = 1
    while i < 20 {
        term = term * z2
        result = result + term / (2 * i + 1)
        i = i + 1
    }
    return 2 * result + n
}

fn sin(x) {
    let xv = x % (2 * PI)
    let term = xv
    let result = xv
    let i = 1
    while i < 10 {
        term = -term * xv * xv / ((2 * i) * (2 * i + 1))
        result = result + term
        i = i + 1
    }
    return result
}

fn cos(x) {
    let xv = x % (2 * PI)
    let term = 1
    let result = 1
    let i = 1
    while i < 10 {
        term = -term * xv * xv / ((2 * i - 1) * (2 * i))
        result = result + term
        i = i + 1
    }
    return result
}

fn tan(x) {
    let c = cos(x)
    if c == 0 { throw "tan undefined at this value" }
    return sin(x) / c
}
