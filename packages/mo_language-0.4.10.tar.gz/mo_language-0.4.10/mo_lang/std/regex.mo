# std/regex.mo — regular expression support

fn match(pattern, text)            { return __regex_match__(pattern, text) }
fn search(pattern, text)           { return __regex_search__(pattern, text) }
fn replace(pattern, text, repl)    { return __regex_replace__(pattern, text, repl) }
fn split(pattern, text)            { return __regex_split__(pattern, text) }
fn findAll(pattern, text)          { return __regex_findall__(pattern, text) }
fn regex_match(pattern, text)      { return __regex_match__(pattern, text) }
