# std/random.mo — random number generation

fn random_int(lo, hi)  { return __random_int__(lo, hi) }
fn random_float()      { return __random_float__() }
fn random_pick(lst)    { return __random_pick__(lst) }

fn rand_int(lo, hi)    { return __random_int__(lo, hi) }
fn rand_float()        { return __random_float__() }
fn pick(lst)           { return __random_pick__(lst) }
fn rand()              { return __random_float__() }
