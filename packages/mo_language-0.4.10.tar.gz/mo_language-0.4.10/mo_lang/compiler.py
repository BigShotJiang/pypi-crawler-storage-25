"""
compiler.py — compile Mo AST → bytecode (list of Instr).
"""
from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum, auto
from .ast_nodes import *


class Op(Enum):
    LOAD_CONST    = auto()   # arg: value
    LOAD_NAME     = auto()   # arg: str
    STORE_NAME    = auto()   # arg: str  (assign existing)
    DEFINE_NAME   = auto()   # arg: str  (let)
    BINARY_OP     = auto()   # arg: str
    UNARY_OP      = auto()   # arg: str
    JUMP          = auto()   # arg: int
    JUMP_IF_FALSE = auto()   # arg: int  (pops cond)
    POP           = auto()
    RETURN        = auto()
    ASYNC_RETURN  = auto()
    AWAIT        = auto()
    CALL          = auto()   # arg: int (argc); stack: fn, arg0..argN
    MAKE_LIST     = auto()   # arg: int
    MAKE_DICT     = auto()   # arg: int (n pairs)
    INDEX_GET     = auto()
    INDEX_SET     = auto()   # stack: obj idx val → val
    GET_ATTR      = auto()   # arg: str
    SET_ATTR     = auto()   # arg: str; stack: obj val → val
    METHOD_CALL   = auto()   # arg: (method, argc)
    MAKE_FUNCTION = auto()   # arg: CompiledFn
    MAKE_ASYNC_FUNCTION = auto()   # arg: CompiledFn
    MAKE_CLASS    = auto()   # arg: (name, parent|None, {name: CompiledFn})
    THROW         = auto()
    SETUP_TRY     = auto()   # arg: (catch_ip, err_var) — patched after
    END_TRY       = auto()
    IMPORT        = auto()   # arg: str
    MAKE_ITER     = auto()   # pop list, push iterator
    FOR_ITER      = auto()   # arg: end_ip; peek iter → push next or pop+jump
    LINE          = auto()   # arg: int — source line number (debug info)
    DUP           = auto()   # duplicate top of stack (used for && / ||)
    # Match opcodes
    MATCH_START   = auto()   # start match: push value to match
    MATCH_CASE    = auto()   # arg: (pattern_type, ...); check if value matches pattern
    MATCH_BIND    = auto()   # arg: var_name; bind current value to variable
    MATCH_END     = auto()   # end match block
    # Destructuring opcodes
    DESTRUCTURE_LIST = auto()  # arg: [var_names]; pop list, define each element
    DESTRUCTURE_DICT = auto()  # arg: [(key, var_name)]; pop dict, define each key's value


@dataclass
class Instr:
    op:  Op
    arg: object = None

    def __repr__(self):
        return f"{self.op.name}({self.arg!r})" if self.arg is not None else self.op.name


@dataclass
class CompiledFn:
    name:     str
    params:   list[str]
    code:     list[Instr]
    variadic: tuple[str | None, str | None] = (None, None)
    defaults: list = None  # parallel to params: None or list[Instr] (compiled default expr)  # (*args_name, **kwargs_name)


class Compiler:
    def __init__(self):
        self._code: list[Instr] = []
        self._break_patches:    list[int] = []
        self._continue_patches: list[int] = []
        self._match_counter:    int = 0

    def compile(self, stmts: list) -> list[Instr]:
        # Expand macros before compilation
        from .macro_expander import expand_macros
        stmts = expand_macros(stmts)
        self._code = []
        for stmt in stmts:
            self._stmt(stmt)
        return self._code

    # ── emit helpers ──────────────────────────────────────────────────────────

    def _emit(self, op: Op, arg=None) -> int:
        self._code.append(Instr(op, arg))
        return len(self._code) - 1

    def _patch(self, idx: int, arg):
        self._code[idx] = Instr(self._code[idx].op, arg)

    def _here(self) -> int:
        return len(self._code)

    # ── statements ────────────────────────────────────────────────────────────

    def _stmt(self, node):
        if node.line:
            self._emit(Op.LINE, node.line)
        t = type(node)
        if t is LetStmt:
            self._expr(node.value)
            self._emit(Op.DEFINE_NAME, node.name)
        elif t is DestructureLet:
            self._expr(node.value)
            if isinstance(node.pattern, ListPattern):
                self._emit(Op.DESTRUCTURE_LIST, node.pattern.elements)
            elif isinstance(node.pattern, DictPattern):
                self._emit(Op.DESTRUCTURE_DICT, node.pattern.pairs)
        elif t is AssignStmt:
            self._expr(node.value)
            self._emit(Op.STORE_NAME, node.name)
        elif t is ExprStmt:
            self._expr(node.expr)
            self._emit(Op.POP)
        elif t is IfStmt:
            self._if(node)
        elif t is WhileStmt:
            self._while(node)
        elif t is ForStmt:
            self._for(node)
        elif t is FnDef:
            fn = self._compile_fn(node.name, node.params, node.body, variadic=node.variadic)
            self._emit(Op.MAKE_FUNCTION, fn)
            self._emit(Op.DEFINE_NAME, node.name)
        elif t is AsyncFn:
            fn = self._compile_fn(node.name, node.params, node.body, is_async=True, variadic=node.variadic)
            self._emit(Op.MAKE_ASYNC_FUNCTION, fn)
            self._emit(Op.DEFINE_NAME, node.name)
        elif t is ReturnStmt:
            if node.value is not None:
                self._expr(node.value)
            else:
                self._emit(Op.LOAD_CONST, None)
            self._emit(Op.RETURN)
        elif t is TryCatch:
            self._try_catch(node)
        elif t is ThrowStmt:
            self._expr(node.value)
            self._emit(Op.THROW)
        elif t is BreakStmt:
            idx = self._emit(Op.JUMP, None)
            self._break_patches.append(idx)
        elif t is ContinueStmt:
            idx = self._emit(Op.JUMP, None)
            self._continue_patches.append(idx)
        elif t is ImportStmt:
            self._emit(Op.IMPORT, (node.path, node.alias))
        elif t is ClassDef:
            self._class(node)
        elif t is MatchStmt:
            self._match_stmt(node)
        elif t is IndexSet:
            self._expr(node.obj)
            self._expr(node.index)
            self._expr(node.value)
            self._emit(Op.INDEX_SET)
            self._emit(Op.POP)
        elif t is SetAttr:
            self._expr(node.obj)
            self._expr(node.value)
            self._emit(Op.SET_ATTR, node.attr)
            self._emit(Op.POP)
        else:
            raise ValueError(f"Unknown statement node: {type(node).__name__}")

    def _if(self, node: IfStmt):
        self._expr(node.condition)
        jf = self._emit(Op.JUMP_IF_FALSE, None)
        for s in node.then_body:
            self._stmt(s)
        if node.else_body:
            j = self._emit(Op.JUMP, None)
            self._patch(jf, self._here())
            for s in node.else_body:
                self._stmt(s)
            self._patch(j, self._here())
        else:
            self._patch(jf, self._here())

    def _while(self, node: WhileStmt):
        start = self._here()
        self._expr(node.condition)
        jf = self._emit(Op.JUMP_IF_FALSE, None)
        saved_b, saved_c = self._break_patches, self._continue_patches
        self._break_patches, self._continue_patches = [], []
        for s in node.body:
            self._stmt(s)
        for ci in self._continue_patches:
            self._patch(ci, start)
        self._emit(Op.JUMP, start)
        end = self._here()
        self._patch(jf, end)
        for bi in self._break_patches:
            self._patch(bi, end)
        self._break_patches, self._continue_patches = saved_b, saved_c

    def _for(self, node: ForStmt):
        self._expr(node.iter)
        self._emit(Op.MAKE_ITER)
        start = self._here()
        fi = self._emit(Op.FOR_ITER, None)
        self._emit(Op.DEFINE_NAME, node.var)
        saved_b, saved_c = self._break_patches, self._continue_patches
        self._break_patches, self._continue_patches = [], []
        for s in node.body:
            self._stmt(s)
        for ci in self._continue_patches:
            self._patch(ci, start)
        self._emit(Op.JUMP, start)
        end = self._here()
        self._patch(fi, end)
        for bi in self._break_patches:
            self._patch(bi, end)
        self._break_patches, self._continue_patches = saved_b, saved_c

    def _try_catch(self, node: TryCatch):
        st = self._emit(Op.SETUP_TRY, None)
        for s in node.try_body:
            self._stmt(s)
        self._emit(Op.END_TRY)
        j = self._emit(Op.JUMP, None)
        catch_ip = self._here()
        self._patch(st, (catch_ip, node.err_var))
        for s in node.catch_body:
            self._stmt(s)
        self._patch(j, self._here())

    def _class(self, node: ClassDef):
        methods = {
            fn.name: self._compile_fn(fn.name, fn.params, fn.body, variadic=fn.variadic)
            for fn in node.methods
        }
        self._emit(Op.MAKE_CLASS, (node.name, node.parent, methods))
        self._emit(Op.DEFINE_NAME, node.name)

    def _match_stmt(self, node: MatchStmt):
        """Compile a match statement into bytecode.

        We use a simple approach:
        1. Evaluate the match expression and DUP it (keep on stack for each check)
        2. For each case:
           - Emit pattern matching code
           - If match fails, jump to next case
           - If match succeeds, execute body, then jump to end
        3. Clean up value from stack
        """
        # Evaluate match expression and keep on stack
        self._expr(node.expr)

        end_jumps = []  # jumps to end after a case matches

        for i, case in enumerate(node.cases):
            # DUP the value for pattern matching (each case needs to check it)
            self._emit(Op.DUP)

            # Compile pattern matching
            if not self._compile_pattern(case.pattern):
                # Pattern compilation returned False - complex pattern, skip for now
                # For now, we emit a placeholder that always fails
                self._emit(Op.POP)  # pop the DUPed value
                self._emit(Op.POP)  # pop the test result (false)
                continue

            # Pattern match result is on stack (True/False)
            # If False, jump to next case
            next_case_jmp = self._emit(Op.JUMP_IF_FALSE, None)

            # Pattern matched - pop the original match value (keep only bindings)
            self._emit(Op.POP)

            # Execute case body
            for stmt in case.body:
                self._stmt(stmt)

            # Jump to end of match
            end_jumps.append(self._emit(Op.JUMP, None))

            # Patch jump for next case
            self._patch(next_case_jmp, self._here())

        # No case matched - pop the match value
        self._emit(Op.POP)

        # Patch all end jumps
        for jmp in end_jumps:
            self._patch(jmp, self._here())

    def _compile_pattern(self, pattern) -> bool:
        """Compile pattern matching code.

        Entry stack:  [match_val, match_val_dup]
        Exit  stack:  [match_val, True/False]

        Returns True if pattern was compiled successfully.
        """
        from .ast_nodes import Number, String, Bool, Null, Ident, ListLiteral, DictLiteral

        pt = type(pattern)

        # Literal patterns — DUP value is on TOS, compare with ==
        if pt in (Number, String, Bool, Null):
            if pt is Null:
                self._emit(Op.LOAD_CONST, None)
            else:
                self._emit(Op.LOAD_CONST, pattern.value)
            self._emit(Op.BINARY_OP, "==")
            return True

        # Wildcard _ — always matches
        if pt is Ident and pattern.name == "_":
            self._emit(Op.POP)           # discard DUPed value
            self._emit(Op.LOAD_CONST, True)
            return True

        # Variable binding — always matches, stores DUPed value
        if pt is Ident:
            self._emit(Op.DEFINE_NAME, pattern.name)
            self._emit(Op.LOAD_CONST, True)
            return True

        # List pattern [p0, p1, ...]
        if pt is ListLiteral:
            tmp = f"__match_{self._match_counter}__"
            self._match_counter += 1
            n = len(pattern.elements)

            # Store DUPed value in tmp; original match_val stays below
            self._emit(Op.DEFINE_NAME, tmp)

            fail_jumps = []

            # is_list check
            self._emit(Op.LOAD_NAME, "is_list")
            self._emit(Op.LOAD_NAME, tmp)
            self._emit(Op.CALL, 1)
            fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            # length check
            self._emit(Op.LOAD_NAME, "len")
            self._emit(Op.LOAD_NAME, tmp)
            self._emit(Op.CALL, 1)
            self._emit(Op.LOAD_CONST, float(n))
            self._emit(Op.BINARY_OP, "==")
            fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            # per-element checks
            for i, elem in enumerate(pattern.elements):
                ept = type(elem)
                if ept is Ident and elem.name == "_":
                    pass  # wildcard: skip
                elif ept is Ident:
                    # variable binding
                    self._emit(Op.LOAD_NAME, tmp)
                    self._emit(Op.LOAD_CONST, float(i))
                    self._emit(Op.INDEX_GET)
                    self._emit(Op.DEFINE_NAME, elem.name)
                else:
                    # literal or nested pattern — compare
                    self._emit(Op.LOAD_NAME, tmp)
                    self._emit(Op.LOAD_CONST, float(i))
                    self._emit(Op.INDEX_GET)
                    if ept is Null:
                        self._emit(Op.LOAD_CONST, None)
                    else:
                        self._emit(Op.LOAD_CONST, elem.value)
                    self._emit(Op.BINARY_OP, "==")
                    fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            # Success
            self._emit(Op.LOAD_CONST, True)
            success_jump = self._emit(Op.JUMP, None)

            # Fail
            fail_ip = self._here()
            for fj in fail_jumps:
                self._patch(fj, fail_ip)
            self._emit(Op.LOAD_CONST, False)

            self._patch(success_jump, self._here())
            return True

        # Dict pattern {"key": pattern, ...}
        if pt is DictLiteral:
            tmp = f"__match_{self._match_counter}__"
            self._match_counter += 1

            self._emit(Op.DEFINE_NAME, tmp)

            fail_jumps = []

            # is_dict check
            self._emit(Op.LOAD_NAME, "is_dict")
            self._emit(Op.LOAD_NAME, tmp)
            self._emit(Op.CALL, 1)
            fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            # key-existence checks first
            for key_node, _ in pattern.pairs:
                key = key_node.value if hasattr(key_node, 'value') else str(key_node)
                self._emit(Op.LOAD_NAME, "has")
                self._emit(Op.LOAD_NAME, tmp)
                self._emit(Op.LOAD_CONST, key)
                self._emit(Op.CALL, 2)
                fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            # value checks / bindings
            for key_node, val_pat in pattern.pairs:
                key = key_node.value if hasattr(key_node, 'value') else str(key_node)
                vpt = type(val_pat)
                if vpt is Ident and val_pat.name == "_":
                    pass  # wildcard
                elif vpt is Ident:
                    self._emit(Op.LOAD_NAME, tmp)
                    self._emit(Op.LOAD_CONST, key)
                    self._emit(Op.INDEX_GET)
                    self._emit(Op.DEFINE_NAME, val_pat.name)
                else:
                    self._emit(Op.LOAD_NAME, tmp)
                    self._emit(Op.LOAD_CONST, key)
                    self._emit(Op.INDEX_GET)
                    if vpt is Null:
                        self._emit(Op.LOAD_CONST, None)
                    else:
                        self._emit(Op.LOAD_CONST, val_pat.value)
                    self._emit(Op.BINARY_OP, "==")
                    fail_jumps.append(self._emit(Op.JUMP_IF_FALSE, None))

            self._emit(Op.LOAD_CONST, True)
            success_jump = self._emit(Op.JUMP, None)

            fail_ip = self._here()
            for fj in fail_jumps:
                self._patch(fj, fail_ip)
            self._emit(Op.LOAD_CONST, False)

            self._patch(success_jump, self._here())
            return True

        return False

    def _compile_fn(self, name: str, params: list, body: list, is_async: bool = False, variadic: tuple[str | None, str | None] = (None, None)) -> CompiledFn:
        sub = Compiler()
        sub._is_async = is_async
        has_return = False
        for stmt in body:
            sub._stmt(stmt)
            if isinstance(stmt, ReturnStmt):
                has_return = True
        if not has_return:
            sub._emit(Op.LOAD_CONST, None)
        if is_async:
            sub._emit(Op.ASYNC_RETURN)
        else:
            sub._emit(Op.RETURN)
        # Extract param names and compile default expressions
        param_names = []
        defaults = []
        for p_name, p_default in params:
            param_names.append(p_name)
            if p_default is not None:
                dc = Compiler()
                dc._expr(p_default)
                defaults.append(dc._code)
            else:
                defaults.append(None)
        return CompiledFn(name, param_names, sub._code, variadic, defaults)

    # ── expressions ───────────────────────────────────────────────────────────

    def _expr(self, node):
        t = type(node)
        if t is Number:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is String:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is Bool:
            self._emit(Op.LOAD_CONST, node.value)
        elif t is Null:
            self._emit(Op.LOAD_CONST, None)
        elif t is Ident:
            self._emit(Op.LOAD_NAME, node.name)
        elif t is BinOp:
            if node.op == "||":
                # a || b: evaluate a; if truthy keep it, else evaluate b
                self._expr(node.left)
                self._emit(Op.DUP)
                jf = self._emit(Op.JUMP_IF_FALSE, None)   # if falsy, go evaluate b
                j  = self._emit(Op.JUMP, None)            # truthy: skip b
                self._patch(jf, self._here())
                self._emit(Op.POP)                        # discard a, replace with b
                self._expr(node.right)
                self._patch(j, self._here())
            elif node.op == "&&":
                # a && b: evaluate a; if falsy keep it, else evaluate b
                self._expr(node.left)
                self._emit(Op.DUP)
                jf = self._emit(Op.JUMP_IF_FALSE, None)   # if falsy, keep a
                self._emit(Op.POP)                        # discard a, replace with b
                self._expr(node.right)
                self._patch(jf, self._here())
            else:
                self._expr(node.left)
                self._expr(node.right)
                self._emit(Op.BINARY_OP, node.op)
        elif t is UnaryOp:
            self._expr(node.right)
            self._emit(Op.UNARY_OP, node.op)
        elif t is Call:
            self._emit(Op.LOAD_NAME, node.name)
            for a in node.args:
                self._expr(a)
            self._emit(Op.CALL, len(node.args))
        elif t is ListLiteral:
            for e in node.elements:
                self._expr(e)
            self._emit(Op.MAKE_LIST, len(node.elements))
        elif t is DictLiteral:
            for k, v in node.pairs:
                self._expr(k)
                self._expr(v)
            self._emit(Op.MAKE_DICT, len(node.pairs))
        elif t is IndexGet:
            self._expr(node.obj)
            self._expr(node.index)
            self._emit(Op.INDEX_GET)
        elif t is IndexSet:
            self._expr(node.obj)
            self._expr(node.index)
            self._expr(node.value)
            self._emit(Op.INDEX_SET)
        elif t is GetAttr:
            self._expr(node.obj)
            self._emit(Op.GET_ATTR, node.attr)
        elif t is SetAttr:
            self._expr(node.obj)
            self._expr(node.value)
            self._emit(Op.SET_ATTR, node.attr)
        elif t is MethodCall:
            self._expr(node.obj)
            for a in node.args:
                self._expr(a)
            self._emit(Op.METHOD_CALL, (node.method, len(node.args)))
        elif t is CallExpr:
            self._expr(node.callee)
            for a in node.args:
                self._expr(a)
            self._emit(Op.CALL, len(node.args))
        elif t is AnonFn:
            fn = self._compile_fn("<anon>", node.params, node.body, variadic=node.variadic)
            self._emit(Op.MAKE_FUNCTION, fn)
        elif t is AwaitExpr:
            self._expr(node.expr)
            self._emit(Op.AWAIT)
        elif t is TemplateStr:
            if not node.parts:
                self._emit(Op.LOAD_CONST, "")
            else:
                first = True
                for part in node.parts:
                    if isinstance(part, str):
                        self._emit(Op.LOAD_CONST, part)
                    else:
                        # Wrap expression in str() to guarantee string concatenation
                        self._emit(Op.LOAD_NAME, "str")
                        self._expr(part)
                        self._emit(Op.CALL, 1)
                    if not first:
                        self._emit(Op.BINARY_OP, "+")
                    first = False
        else:
            raise ValueError(f"Unknown expression node: {type(node).__name__}")
