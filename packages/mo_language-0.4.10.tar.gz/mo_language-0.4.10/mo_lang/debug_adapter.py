"""
debug_adapter.py — Debugger support for Mo language.
"""
import sys
import os
from .lexer import Lexer
from .parser import Parser
from .compiler import Compiler
from .vm import VM, MoThrow, Frame, Frame
from .interpreter import Environment


class Debugger:
    def __init__(self, source_path: str):
        self.source_path = os.path.abspath(source_path)
        self.breakpoints = set()
        self.paused = False
        
    def set_breakpoint(self, line: int):
        self.breakpoints.add(line)
        print(f"Breakpoint set at line {line}")
        
    def remove_breakpoint(self, line: int):
        self.breakpoints.discard(line)
        print(f"Breakpoint removed from line {line}")
        
    def list_breakpoints(self):
        if not self.breakpoints:
            print("No breakpoints")
        else:
            for line in sorted(self.breakpoints):
                print(f"  line {line}")
                
    def should_break(self, line: int) -> bool:
        return line in self.breakpoints or self.paused


def start_debugger(source_path: str, break_at_start: bool = False):
    abs_path = os.path.abspath(source_path)
    abs_dir = os.path.dirname(abs_path)
    
    source = open(abs_path).read()
    tokens = Lexer(source).tokenize()
    ast = Parser(tokens).parse()
    
    code = Compiler().compile(ast)
    vm = VM(trace=False)
    vm._base_dir = abs_dir
    
    debug = Debugger(abs_path)
    debug.paused = break_at_start
    vm._debug = debug
    
    print(f"[Debug] Starting {source_path}")
    print(f"[Debug] Type 'h' for help\n")
    
    env = Environment(parent=vm.globals)
    frame = Frame(code=code, env=env)
    vm._frames.append(frame)
    
    try:
        _run_debug(vm, frame)
    except MoThrow as e:
        print(f"[Uncaught throw] {e.value}")
    except Exception as e:
        print(f"[Error] {e}")
    finally:
        vm._frames.pop()


def _run_debug(vm, frame):
    from .compiler import Op
    
    code = frame.code
    stack = frame.stack
    env = frame.env
    debug = vm._debug
    
    while frame.ip < len(code):
        instr = code[frame.ip]
        
        if instr.op is Op.LINE:
            vm._current_line = instr.arg
            if debug.should_break(instr.arg):
                _debug_prompt(vm, debug, instr.arg)
                debug.paused = False
                
        frame.ip += 1
        
        if _exec(vm, instr, frame, stack, env):
            return frame.retval
            
    return frame.retval


def _exec(vm, instr, frame, stack, env):
    from .compiler import Op, CompiledFn
    from .vm import VMFunction, VMAsyncFunction
    from .interpreter import Instance, Klass, Interpreter, RuntimeError_
    
    op, arg = instr.op, instr.arg
    interp: Interpreter = vm._interp
    
    if op is Op.LINE:
        return False
        
    if op is Op.LOAD_CONST:
        stack.append(arg)
        return False
        
    if op is Op.LOAD_NAME:
        stack.append(env.get(arg))
        return False
        
    if op is Op.DEFINE_NAME:
        env.define(arg, stack.pop())
        return False
        
    if op is Op.STORE_NAME:
        env.set(arg, stack.pop())
        return False
        
    if op is Op.POP:
        stack.pop()
        return False
        
    if op is Op.DUP:
        stack.append(stack[-1])
        return False
        
    if op is Op.BINARY_OP:
        right = stack.pop()
        left = stack.pop()
        stack.append(interp._binop(arg, left, right))
        return False
        
    if op is Op.UNARY_OP:
        val = stack.pop()
        stack.append(-val if arg == '-' else not interp._truthy(val))
        return False
        
    if op is Op.JUMP:
        frame.ip = arg
        return False
        
    if op is Op.JUMP_IF_FALSE:
        if not interp._truthy(stack.pop()):
            frame.ip = arg
        return False
        
    if op is Op.CALL:
        args = list(reversed([stack.pop() for _ in range(arg)]))
        fn = stack.pop()
        stack.append(_call(vm, fn, args))
        return False
        
    if op is Op.RETURN:
        frame.retval = stack.pop()
        return True
        
    if op is Op.MAKE_LIST:
        stack.append(list(reversed([stack.pop() for _ in range(arg)])))
        return False
        
    if op is Op.MAKE_DICT:
        pairs = [(stack.pop(), stack.pop()) for _ in range(arg)]
        stack.append(dict(reversed(pairs)))
        return False
        
    if op is Op.INDEX_GET:
        stack.append(interp._index_get(stack.pop(), stack.pop()))
        return False
        
    if op is Op.INDEX_SET:
        interp._index_set(stack.pop(), stack.pop(), stack.pop())
        return False
        
    if op is Op.GET_ATTR:
        stack.append(_get_attr(interp, stack.pop(), arg))
        return False
        
    if op is Op.SET_ATTR:
        val = stack.pop()
        obj = stack.pop()
        if not isinstance(obj, Instance):
            raise RuntimeError("Can only set attributes on class instances")
        obj.fields[arg] = val
        return False
        
    if op is Op.METHOD_CALL:
        method, argc = arg
        args = list(reversed([stack.pop() for _ in range(argc)]))
        stack.append(_call_method(interp, stack.pop(), method, args))
        return False
        
    if op is Op.MAKE_FUNCTION:
        cfn: CompiledFn = arg
        stack.append(VMFunction(cfn.name, cfn.params, cfn.code, env))
        return False
        
    if op is Op.MAKE_ASYNC_FUNCTION:
        cfn: CompiledFn = arg
        stack.append(VMAsyncFunction(cfn.name, cfn.params, cfn.code, env))
        return False
        
    if op is Op.MAKE_CLASS:
        name, parent_name, method_cfns = arg
        parent = None
        if parent_name:
            parent = env.get(parent_name)
            if not isinstance(parent, Klass):
                raise RuntimeError(f"'{parent_name}' is not a class")
        methods = {mname: VMFunction(cfn.name, cfn.params, cfn.code, env) for mname, cfn in method_cfns.items()}
        stack.append(Klass(name, methods, parent))
        return False
        
    if op is Op.THROW:
        raise MoThrow(stack.pop())
        
    if op is Op.MAKE_ITER:
        lst = stack.pop()
        if isinstance(lst, list):
            stack.append(iter(lst))
        elif isinstance(lst, dict):
            stack.append(iter(lst.keys()))
        elif isinstance(lst, str):
            stack.append(iter(lst))
        else:
            raise RuntimeError("'for' requires a list, dict, or string")
        return False
        
    if op is Op.FOR_ITER:
        try:
            stack.append(next(stack[-1]))
        except StopIteration:
            stack.pop()
            frame.ip = arg
        return False
        
    return False


def _call(vm, fn, args):
    from .vm import VMFunction, VMAsyncFunction
    from .interpreter import Klass
    
    if isinstance(fn, (VMAsyncFunction, VMFunction)):
        return _invoke_vm(vm, fn, args)
    if isinstance(fn, Klass):
        return _instantiate(vm, fn, args)
    if callable(fn):
        return fn(args)
    raise RuntimeError(f"{fn!r} is not callable")


def _invoke_vm(vm, fn, args):
    from .interpreter import Environment
    from .vm import VMFunction, VMAsyncFunction
    
    if len(args) != len(fn.params):
        raise RuntimeError(f"{fn.name}() expects {len(fn.params)} args, got {len(args)}")
    call_env = Environment(parent=fn.closure)
    for param, val in zip(fn.params, args):
        call_env.define(param, val)
    frame = Frame(code=fn.code, env=call_env)
    debug = getattr(vm, '_debug', None)
    if debug:
        return _run_debug(vm, frame)
    return vm._run_frame(frame)


def _instantiate(vm, klass, args):
    from .interpreter import Instance
    instance = Instance(klass)
    init = _lookup_method(klass, "init")
    if init:
        _invoke_callable(vm, init, args, instance=instance)
    return instance


def _call_method(interp, obj, method, args):
    from .interpreter import BoundSuper, Instance
    if isinstance(obj, Instance):
        fn = _lookup_method(obj.klass, method)
        if fn is None:
            raise RuntimeError(f"'{obj.klass.name}' has no method '{method}'")
        return _invoke_callable(interp, fn, args, instance=obj)
    if isinstance(obj, BoundSuper):
        fn = _lookup_method(obj.klass, method)
        if fn is None:
            raise RuntimeError(f"super has no method '{method}'")
        return _invoke_callable(interp, fn, args, instance=obj.instance, super_klass=obj.klass.parent)
    if isinstance(obj, dict):
        fn = obj.get(method)
        if fn is None:
            raise RuntimeError(f"Module has no function '{method}'")
        return _call(interp, fn, args)
    raise RuntimeError(f"Cannot call method on {type(obj)}")


def _invoke_callable(vm, fn, args, instance=None, super_klass=None):
    from .interpreter import Function
    from .vm import VMFunction
    from .interpreter import RuntimeError_
    if isinstance(fn, VMFunction):
        return _invoke_vm(vm, fn, args)
    if isinstance(fn, Function):
        if instance is not None:
            return vm._interp._invoke_method(fn, instance, args, super_klass)
        return vm._interp._call(fn, args)
    if callable(fn):
        return fn(args)
    raise RuntimeError(f"{fn!r} is not callable")


def _lookup_method(klass, method):
    if method in klass.methods:
        return klass.methods[method]
    if klass.parent:
        return _lookup_method(klass.parent, method)
    return None


def _get_attr(interp, obj, attr):
    from .interpreter import Instance, BoundSuper
    if isinstance(obj, Instance):
        if attr in obj.fields:
            return obj.fields[attr]
        fn = _lookup_method(obj.klass, attr)
        if fn is not None:
            return fn
        raise RuntimeError(f"'{obj.klass.name}' has no attribute '{attr}'")
    if isinstance(obj, BoundSuper):
        fn = _lookup_method(obj.klass, attr)
        if fn is not None:
            return fn
        raise RuntimeError(f"super has no attribute '{attr}'")
    if isinstance(obj, str):
        return interp._str_method(obj, attr)
    if isinstance(obj, dict):
        if attr in obj:
            return obj[attr]
        raise RuntimeError(f"Key '{attr}' not found in dict")
    raise RuntimeError(f"Cannot get attribute '{attr}' on {type(obj)}")


def _debug_prompt(vm, debug, line):
    print(f"\n[Break at line {line}]")
    print(f"Stack: {len(vm._frames)} frame(s)")
    
    while True:
        try:
            cmd = input("(debug) ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nQuitting...")
            sys.exit(0)
            
        if not cmd:
            continue
            
        parts = cmd.split()
        cmd_name = parts[0]
        args = parts[1:]
        
        if cmd_name in ("s", "step"):
            debug.paused = True
            break
        elif cmd_name in ("n", "next"):
            debug.paused = True
            break
        elif cmd_name in ("c", "continue", "cont"):
            debug.paused = False
            break
        elif cmd_name in ("b", "break"):
            if args:
                debug.set_breakpoint(int(args[0]))
            else:
                debug.list_breakpoints()
        elif cmd_name in ("r", "remove"):
            if args:
                debug.remove_breakpoint(int(args[0]))
        elif cmd_name in ("p", "print"):
            if args:
                _print_var(vm, args[0])
        elif cmd_name in ("stack", "bt", "where"):
            _print_stack(vm)
        elif cmd_name in ("q", "quit", "exit"):
            print("Quitting...")
            sys.exit(0)
        elif cmd_name in ("h", "help", "?"):
            _print_help()
        else:
            print(f"Unknown command: {cmd_name}")


def _print_var(vm, name):
    for frame in reversed(vm._frames):
        if name in frame.env.vars:
            print(f"{name} = {frame.env.vars[name]!r}")
            return
    print(f"Variable '{name}' not found")


def _print_stack(vm):
    print("Stack frames:")
    for i, frame in enumerate(reversed(vm._frames)):
        func = frame.env.vars.get("__name__", "<module>")
        print(f"  #{i} {func}")


def _print_help():
    print("""
Commands:
  s, step           Step to next line (into functions)
  n, next           Step to next line (over functions)  
  c, continue      Continue execution
  b [line]        Set breakpoint (or list)
  r [line]        Remove breakpoint
  p <name>        Print variable
  stack           Show call stack
  q, quit         Exit debugger
  h, help         Show help
""")