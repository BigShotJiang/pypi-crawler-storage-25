"""
JIT Benchmark - measures JIT compilation speedup
"""
import time
import sys
sys.path.insert(0, '/Users/qinghuaatbc/claude_project/mo')

from mo_lang.real_jit import RealJIT, HOT_THRESHOLD


def interpreter_add(a, b):
    """Interpreter implementation"""
    stack = []
    stack.append(a)
    stack.append(b)
    a = stack.pop()
    b = stack.pop()
    result = a + b
    return result


def fibonacci(n):
    """Recursive fibonacci"""
    if n < 2:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


def sum_list(items):
    """Sum list elements"""
    total = 0
    for i in items:
        total = total + i
    return total


def run_benchmark(name: str, fn, params: dict, iterations: int = 200):
    """Run benchmark for a function"""
    print(f"\n[{name}]")
    
    interp_times = []
    jit_times = []
    
    for i in range(iterations):
        start = time.perf_counter()
        result = fn(**params)
        dt = time.perf_counter() - start
        interp_times.append(dt * 1000)
    
    avg_interp = sum(interp_times) / len(interp_times)
    print(f"  Interpreter: {avg_interp:.4f}ms avg ({iterations} runs)")
    
    return avg_interp


def main():
    print("=" * 50)
    print("JIT Benchmark Results")
    print("=" * 50)
    
    jit = RealJIT()
    
    print("\n[1] add(a, b)")
    params = {'a': 5, 'b': 7}
    avg_interp = run_benchmark("add", interpreter_add, params)
    
    for i in range(200):
        jit.record_call('add')
    
    if jit.should_compile('add'):
        code = [
            type('Instr', (), {'op': 'BINARY_OP', 'arg': '+'})()
        ]
        compiled = jit.compile_hot_path('add', code, ['a', 'b'])
        if compiled and compiled.func:
            start = time.perf_counter()
            result = compiled.func(**params)
            dt = time.perf_counter() - start
            print(f"  JIT compiled: {dt*1000:.4f}ms")
            print(f"  Speedup: {avg_interp/dt:.1f}x")
    
    print("\n[2] fibonacci(n) - recursive")
    params = {'n': 10}
    avg_interp = run_benchmark("fib", fibonacci, params)
    
    print("\n[3] sum_list(items)")
    params = {'items': list(range(100))}
    avg_interp = run_benchmark("sum_list", sum_list, params)
    
    print("\n" + "=" * 50)
    print("Results Summary:")
    print(f"\n  - Basic arithmetic: Near-instant in both")
    print(f"  - Recursive fib: Interpreter is fast")
    print(f"  - List iteration: Interpreter is fast")
    print(f"\n  JIT stats: {jit.get_stats()}")


if __name__ == "__main__":
    main()