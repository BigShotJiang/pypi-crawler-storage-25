"""
Mo package manager.
"""
import os
import re
import json
import shutil
import tarfile
import zipfile
import urllib.request
import hashlib
from pathlib import Path
from typing import Optional

from .registry import PackageRegistry, get_registry


class PackageManager:
    def __init__(self):
        self.cache_dir = os.path.expanduser("~/.mo/cache")
        self.install_dir = os.path.expanduser("~/.mo/packages")
        self.config_file = os.path.expanduser("~/.mo/mo.toml")
        os.makedirs(self.cache_dir, exist_ok=True)
        os.makedirs(self.install_dir, exist_ok=True)
        self._load_config()

    def _load_config(self):
        if os.path.exists(self.config_file):
            try:
                import tomli
                self.config = tomli.loads(open(self.config_file).read())
            except ImportError:
                try:
                    import tomllib
                    self.config = tomllib.loads(open(self.config_file).read())
                except Exception:
                    self.config = {}
        else:
            self.config = {}
            self._save_config()

    def _save_config(self):
        content = "# Mo package manager config\n"
        content += "[mirror]\n  url = \"https://mo.pkg.dev\"\n"
        try:
            open(self.config_file, "w").write(content)
        except Exception:
            pass

    def _lock_path(self):
        return os.path.join(self.install_dir, "mo.lock")

    def _read_lock(self):
        p = self._lock_path()
        if os.path.exists(p):
            try:
                return json.loads(open(p).read())
            except Exception:
                pass
        return {}

    def _write_lock(self, lock):
        open(self._lock_path(), "w").write(json.dumps(lock, indent=2) + "\n")

    def _resolve_spec(self, spec: str) -> dict:
        """Parse package spec into components."""
        if spec.startswith("http://") or spec.startswith("https://"):
            filename = spec.split("/")[-1]
            if not filename:
                filename = "package.mo"
            return {"type": "url", "url": spec, "name": filename[:-3] or "package"}

        if "@" in spec:
            pkg, version = spec.rsplit("@", 1)
        else:
            pkg = spec
            version = "main"

        if "/" in pkg:
            parts = pkg.split("/")
            if len(parts) == 2:
                user, repo = parts
                name = repo
                url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{repo}.mo"
                file_path = f"{repo}.mo"
            else:
                user, repo = parts[0], parts[1]
                name = parts[-1].replace(".mo", "")
                file_path = "/".join(parts[2:])
                url = f"https://raw.githubusercontent.com/{user}/{repo}/{version}/{file_path}"
            return {"type": "github", "url": url, "name": name, "user": user, "repo": repo}

        return {"type": "name", "name": spec, "version": version}

    def _download(self, url: str, dest: str):
        """Download file from URL."""
        print(f"[mo] Downloading {url} ...")
        urllib.request.urlretrieve(url, dest)
        return dest

    def _verify_checksum(self, path: str, expected: Optional[str] = None):
        """Verify file checksum if provided."""
        if not expected:
            return True
        sha256 = hashlib.sha256(open(path, "rb").read()).hexdigest()
        return sha256 == expected

    def _extract_archive(self, archive: str, dest_dir: str):
        """Extract tar/zip archive."""
        os.makedirs(dest_dir, exist_ok=True)
        try:
            if tarfile.is_tarfile(archive):
                with tarfile.open(archive, "r:*") as tf:
                    tf.extractall(dest_dir)
            elif zipfile.is_zipfile(archive):
                with zipfile.ZipFile(archive, "r") as zf:
                    zf.extractall(dest_dir)
            else:
                raise ValueError("Unknown archive format")
            return True
        except Exception:
            return False

    def install(self, spec: str, deps: bool = True):
        """Install a package."""
        resolved = self._resolve_spec(spec)
        name = resolved["name"]

        if name in self._list_installed():
            print(f"[mo] Package {name} already installed. Use --update to reinstall.")
            return

        ext = resolved.get("url", "").split("/")[-1].split(".")[-1]
        if ext in ("tar", "gz", "bz2", "zip"):
            tmp_archive = os.path.join(self.cache_dir, f"{name}.{ext}")
            self._download(resolved["url"], tmp_archive)
            extract_dir = os.path.join(self.cache_dir, name)
            self._extract_archive(tmp_archive, extract_dir)
            mo_files = list(Path(extract_dir).rglob("*.mo"))
            if mo_files:
                dest = os.path.join(self.install_dir, mo_files[0].name)
                shutil.copy(mo_files[0], dest)
            else:
                raise ValueError("No .mo file found in archive")
        else:
            dest = os.path.join(self.install_dir, f"{name}.mo")
            self._download(resolved["url"], dest)

        lock = self._read_lock()
        lock[name] = {"url": resolved["url"], "file": f"{name}.mo", "type": resolved["type"]}
        self._write_lock(lock)
        print(f"[mo] Installed {name} → {dest}")

        if deps:
            self._install_deps(name)

    def get_info(self, package: str):
        """Get detailed package info from registry."""
        registry = get_registry()
        info = registry.get_info(package)
        if not info:
            print(f"[mo] Package {package} not found.")
            return
        
        print(f"[mo] Package: {info.get('name')}")
        print(f"[mo]   Version: {info.get('version')}")
        print(f"[mo]   Description: {info.get('description', '')}")
        print(f"[mo]   Author: {info.get('author', 'unknown')}")
        print(f"[mo]   Repo: {info.get('repo', 'N/A')}")
        
        deps = info.get('deps', [])
        if deps:
            print(f"[mo]   Dependencies: {', '.join(deps)}")

    def _install_deps(self, package: str):
        """Install dependencies from mo.toml metadata."""
        mo_toml_path = os.path.join(self.install_dir, package, "mo.toml")
        if not os.path.exists(mo_toml_path):
            return

        try:
            import tomli
            meta = tomli.loads(open(mo_toml_path).read())
        except ImportError:
            try:
                import tomllib
                meta = tomllib.loads(open(mo_toml_path).read())
            except Exception:
                return

        deps = meta.get("deps", {})
        for dep_spec in deps.values():
            try:
                self.install(dep_spec, deps=False)
            except Exception as e:
                print(f"[mo] Warning: Could not install dependency {dep_spec}: {e}")

    def update(self, package: Optional[str] = None):
        """Update packages to latest version."""
        if package:
            self._update_one(package)
        else:
            for pkg in self._list_installed():
                self._update_one(pkg)

    def _update_one(self, package: str):
        """Update a single package."""
        lock = self._read_lock()
        if package not in lock:
            print(f"[mo] Package {package} not installed.")
            return

        info = lock[package]
        url = info.get("url", "")
        if not url:
            return

        resolved = self._resolve_spec(url)
        name = package

        dest = os.path.join(self.install_dir, f"{name}.mo")
        self._download(resolved["url"], dest)

        lock[package] = {"url": resolved["url"], "file": f"{name}.mo", "type": resolved["type"]}
        self._write_lock(lock)
        print(f"[mo] Updated {name}")

    def search(self, query: str):
        """Search for packages."""
        print(f"[mo] Searching for '{query}' ...")
        registry = get_registry()
        results = registry.search(query)
        if not results:
            print("[mo] No packages found.")
            return

        for pkg in results:
            print(f"  {pkg['name']} {pkg['version']}  - {pkg.get('description', '')}")

    def depends(self, package: str):
        """List dependencies of a package."""
        lock = self._read_lock()
        if package not in lock:
            print(f"[mo] Package {package} not installed.")
            return []

        mo_toml_path = os.path.join(self.install_dir, package, "mo.toml")
        if not os.path.exists(mo_toml_path):
            print(f"[mo] No mo.toml found for {package}.")
            return []

        try:
            import tomli
            meta = tomli.loads(open(mo_toml_path).read())
        except ImportError:
            try:
                import tomllib
                meta = tomllib.loads(open(mo_toml_path).read())
            except Exception:
                return []

        deps = meta.get("deps", {})
        if not deps:
            print(f"[mo] No dependencies for {package}.")
            return []

        print(f"[mo] Dependencies for {package}:")
        for dep_name, dep_spec in deps.items():
            print(f"  {dep_name} {dep_spec}")

        return list(deps.keys())

    def _list_installed(self):
        """List all installed packages."""
        lock = self._read_lock()
        return list(lock.keys())

    def remove(self, name: str):
        """Remove an installed package."""
        filename = name if name.endswith(".mo") else name + ".mo"
        path = os.path.join(self.install_dir, filename)
        if os.path.exists(path):
            os.remove(path)
            lock = self._read_lock()
            lock.pop(name.rstrip(".mo"), None)
            self._write_lock(lock)
            print(f"[mo] Removed {name}")
        else:
            print(f"[mo] Package {name} not found.")

    def list(self):
        """List installed packages."""
        pkgs = self._list_installed()
        if not pkgs:
            print("[mo] No packages installed.")
            return

        lock = self._read_lock()
        print(f"[mo] Installed packages ({self.install_dir}):")
        for name in pkgs:
            info = lock.get(name, {})
            version = info.get("version", "unknown")
            print(f"  {name} {version}")


def resolve_version(spec: str) -> bool:
    """Resolve version spec and check if it matches."""
    patterns = [
        (r"^(\d+\.\d+\.\d+)$", "exact"),
        (r"^>=(.+)$", "min"),
        (r"^>(.+)$", "gt"),
        (r"^<=(.+)$", "max"),
        (r"^<(.+)$", "lt"),
        (r"^~=(.+)$", "compatible"),
    ]

    for pattern, op in patterns:
        if re.match(pattern, spec):
            return True
    return False