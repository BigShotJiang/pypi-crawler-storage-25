"""
bytecode.py — serialize Mo compiled bytecode to/from JSON for the C VM.
"""
from __future__ import annotations
import json
from .compiler import Op, Instr, CompiledFn


def serialize_code(code: list) -> list:
    return [_ser_instr(i) for i in code]


def _ser_fn(cfn: CompiledFn) -> dict:
    return {"name": cfn.name, "params": cfn.params, "code": serialize_code(cfn.code)}


def _ser_instr(instr: Instr) -> dict:
    op  = instr.op
    arg = instr.arg

    if op is Op.LOAD_CONST:
        if arg is None:
            return {"op": "LOAD_CONST", "arg": {"t": "null"}}
        if isinstance(arg, bool):
            return {"op": "LOAD_CONST", "arg": {"t": "b", "v": arg}}
        if isinstance(arg, (int, float)):
            return {"op": "LOAD_CONST", "arg": {"t": "n", "v": float(arg)}}
        if isinstance(arg, str):
            return {"op": "LOAD_CONST", "arg": {"t": "s", "v": arg}}

    if op in (Op.LOAD_NAME, Op.STORE_NAME, Op.DEFINE_NAME,
              Op.BINARY_OP, Op.UNARY_OP, Op.GET_ATTR, Op.SET_ATTR):
        return {"op": op.name, "arg": arg}

    if op in (Op.JUMP, Op.JUMP_IF_FALSE, Op.CALL,
              Op.MAKE_LIST, Op.MAKE_DICT, Op.FOR_ITER, Op.LINE):
        return {"op": op.name, "arg": arg}

    if op in (Op.RETURN, Op.POP, Op.DUP, Op.INDEX_GET,
              Op.INDEX_SET, Op.THROW, Op.END_TRY, Op.MAKE_ITER,
              Op.ASYNC_RETURN, Op.AWAIT):
        return {"op": op.name}

    if op is Op.METHOD_CALL:
        method, argc = arg
        return {"op": "METHOD_CALL", "arg": {"method": method, "argc": argc}}

    if op is Op.MAKE_FUNCTION:
        return {"op": "MAKE_FUNCTION", "arg": _ser_fn(arg)}

    if op is Op.MAKE_ASYNC_FUNCTION:
        return {"op": "MAKE_ASYNC_FUNCTION", "arg": _ser_fn(arg)}

    if op is Op.MAKE_CLASS:
        name, parent, methods = arg
        return {"op": "MAKE_CLASS", "arg": {
            "name": name,
            "parent": parent,
            "methods": {mn: _ser_fn(cfn) for mn, cfn in methods.items()},
        }}

    if op is Op.SETUP_TRY:
        catch_ip, err_var = arg
        return {"op": "SETUP_TRY", "arg": {"catch_ip": catch_ip, "err_var": err_var}}

    if op is Op.IMPORT:
        path, alias = arg if isinstance(arg, tuple) else (arg, None)
        return {"op": "IMPORT", "arg": {"path": path, "alias": alias}}

    if op is Op.DESTRUCTURE_LIST:
        # arg is a list of variable names
        return {"op": "DESTRUCTURE_LIST", "arg": arg}

    if op is Op.DESTRUCTURE_DICT:
        # arg is a list of (key, var_name) tuples
        return {"op": "DESTRUCTURE_DICT", "arg": arg}

    raise ValueError(f"Cannot serialize op {op}")


def bytecode_to_json(code: list) -> str:
    return json.dumps(serialize_code(code), ensure_ascii=False)
