"""
Type Inference — static type analysis for Mo.
"""
from dataclasses import dataclass
from typing import Union, Optional
import re

from .ast_nodes import *
from .lexer import TT, Token
from .parser import Parser


@dataclass
class Type:
    name: str
    nullable: bool = False
    
    def __eq__(self, other):
        if not isinstance(other, Type):
            return False
        if self.name == "any" or other.name == "any":
            return True
        return self.name == other.name
    
    def __hash__(self):
        return hash(self.name)


INT = Type("int")
FLOAT = Type("float")
STR = Type("string")
BOOL = Type("bool")
LIST = Type("list")
DICT = Type("dict")
NULL = Type("null")
UNKNOWN = Type("unknown")
ANY = Type("any")


TYPE_BUILTINS = {
    "is_number": BOOL,
    "is_string": BOOL,
    "is_bool": BOOL,
    "is_list": BOOL,
    "is_dict": BOOL,
    "is_null": BOOL,
    "is_int": BOOL,
    "is_float": BOOL,
}


class TypeInferrer:
    def __init__(self):
        self.types = {}
        self.functions = {}
        self.errors = []
        self.current_fn_return = None
        self._register_builtins()

    def _register_builtins(self):
        for name, return_type in TYPE_BUILTINS.items():
            self.functions[name] = {"return": return_type, "params": [("x", UNKNOWN)]}

    def register_function(self, name: str, return_type: Type, params: list[tuple[str, Type]] = None):
        self.functions[name] = {"return": return_type, "params": params or []}

    def infer_expr(self, expr) -> Type:
        if isinstance(expr, Number):
            return FLOAT if isinstance(expr.value, float) and expr.value != int(expr.value) else INT
        elif isinstance(expr, String):
            return STR
        elif isinstance(expr, Bool):
            return BOOL
        elif isinstance(expr, Null):
            return NULL
        elif isinstance(expr, Ident):
            return self.types.get(expr.name, UNKNOWN)
        elif isinstance(expr, ListLiteral):
            return LIST
        elif isinstance(expr, DictLiteral):
            return DICT
        elif isinstance(expr, BinOp):
            return self._infer_binop(expr)
        elif isinstance(expr, UnaryOp):
            return self._infer_unaryop(expr)
        elif isinstance(expr, (Call, CallExpr)):
            return self._infer_call(expr)
        elif isinstance(expr, MethodCall):
            return UNKNOWN
        elif isinstance(expr, IndexGet):
            return self._infer_index_get(expr)
        elif isinstance(expr, GetAttr):
            return self._infer_get_attr(expr)
        elif isinstance(expr, (AnonFn, AsyncFn)):
            return Type("fn")
        elif isinstance(expr, TemplateStr):
            return STR
        elif isinstance(expr, AwaitExpr):
            return UNKNOWN
        else:
            return UNKNOWN

    def _infer_binop(self, expr: BinOp) -> Type:
        left_type = self.infer_expr(expr.left)
        right_type = self.infer_expr(expr.right)

        if expr.op in ['+', '-', '*', '/', '%']:
            if left_type == STR or right_type == STR:
                return STR
            if left_type == FLOAT or right_type == FLOAT:
                return FLOAT
            return INT
        elif expr.op in ['==', '!=']:
            return BOOL
        elif expr.op in ['<', '>', '<=', '>=']:
            if left_type == STR or right_type == STR:
                return BOOL
            return BOOL
        elif expr.op in ['and', 'or']:
            if left_type == BOOL and right_type == BOOL:
                return BOOL
            return BOOL
        return UNKNOWN

    def _infer_unaryop(self, expr: UnaryOp) -> Type:
        if expr.op == 'not':
            return BOOL
        elif expr.op == '-':
            return INT
        return UNKNOWN

    def _infer_call(self, expr) -> Type:
        name = getattr(expr, 'name', None)
        if name and name in self.functions:
            return self.functions[name]["return"]
        return UNKNOWN

    def _infer_index_get(self, expr: IndexGet) -> Type:
        obj_type = self.infer_expr(expr.obj)
        if obj_type == LIST:
            return UNKNOWN
        elif obj_type == DICT:
            return UNKNOWN
        return UNKNOWN

    def _infer_get_attr(self, expr: GetAttr) -> Type:
        return UNKNOWN

    def infer_stmt(self, stmt) -> Optional[Type]:
        if isinstance(stmt, LetStmt):
            value_type = self.infer_expr(stmt.value)
            self.types[stmt.name] = value_type
            if stmt.type_hint:
                declared = self._parse_type_hint(stmt.type_hint)
                self.check_types(declared, value_type, f"let {stmt.name}")
            return value_type

        elif isinstance(stmt, AssignStmt):
            value_type = self.infer_expr(stmt.value)
            name = stmt.name if isinstance(stmt.name, str) else None
            if name:
                self.types[name] = value_type
            return value_type

        elif isinstance(stmt, IfStmt):
            self._infer_if_stmt(stmt)

        elif isinstance(stmt, WhileStmt):
            self._infer_while_stmt(stmt)

        elif isinstance(stmt, ForStmt):
            self._infer_for_stmt(stmt)

        elif isinstance(stmt, FnDef):
            self._infer_fn_def(stmt)

        elif isinstance(stmt, AsyncFn):
            self._infer_fn_def(stmt)

        elif isinstance(stmt, ClassDef):
            self._infer_class_def(stmt)

        elif isinstance(stmt, MatchStmt):
            self._infer_match_stmt(stmt)

        elif isinstance(stmt, ReturnStmt):
            if stmt.value:
                t = self.infer_expr(stmt.value)
                self.current_fn_return = t
                return t
            self.current_fn_return = NULL
            return NULL

        elif isinstance(stmt, TryCatch):
            for s in stmt.try_body:
                self.infer_stmt(s)
            if stmt.err_var:
                self.types[stmt.err_var] = STR
            for s in stmt.catch_body:
                self.infer_stmt(s)

        elif isinstance(stmt, (ExprStmt, ThrowStmt, ImportStmt,
                               BreakStmt, ContinueStmt, IndexSet, SetAttr,
                               DestructureLet)):
            pass  # no type-level effect to track

        return None

    def _infer_if_stmt(self, stmt: IfStmt):
        cond_type = self.infer_expr(stmt.condition)
        
        then_narrowed = self.types.copy()
        else_narrowed = self.types.copy()
        
        narrowed_types = self._narrow_from_condition(stmt.condition)
        for var, narrowed in narrowed_types.items():
            then_narrowed[var] = narrowed
        
        then_scope = TypeInferrer()
        then_scope.types = then_narrowed
        then_scope.functions = self.functions.copy()
        
        for s in stmt.then_body:
            then_scope.infer_stmt(s)

        if stmt.else_body:
            else_scope = TypeInferrer()
            else_scope.types = else_narrowed
            else_scope.functions = self.functions.copy()
            
            for s in stmt.else_body:
                else_scope.infer_stmt(s)

    def _narrow_from_condition(self, cond) -> dict[str, Type]:
        narrowed = {}
        
        if isinstance(cond, Call):
            if cond.name in TYPE_BUILTINS and len(cond.args) == 1:
                arg = cond.args[0]
                if isinstance(arg, Ident):
                    if cond.name == "is_number":
                        narrowed[arg.name] = INT
                    elif cond.name == "is_int":
                        narrowed[arg.name] = INT
                    elif cond.name == "is_float":
                        narrowed[arg.name] = FLOAT
                    elif cond.name == "is_string":
                        narrowed[arg.name] = STR
                    elif cond.name == "is_bool":
                        narrowed[arg.name] = BOOL
                    elif cond.name == "is_list":
                        narrowed[arg.name] = LIST
                    elif cond.name == "is_dict":
                        narrowed[arg.name] = DICT
                    elif cond.name == "is_null":
                        narrowed[arg.name] = NULL
        
        elif isinstance(cond, BinOp) and cond.op == "==":
            if isinstance(cond.left, Ident) and isinstance(cond.right, Null):
                narrowed[cond.left.name] = NULL
            elif isinstance(cond.right, Ident) and isinstance(cond.left, Null):
                narrowed[cond.right.name] = NULL
        
        elif isinstance(cond, UnaryOp) and cond.op == "not":
            # Negation: propagate narrowing conservatively (negate null → non-null, etc.)
            neg_narrowed = self._narrow_from_condition(cond.right)
            for var, t in neg_narrowed.items():
                if t == NULL:
                    narrowed[var] = UNKNOWN  # was null, now we know it's not null
                # Other type negations are not representable in our simple type system

        return narrowed

    def _infer_fn_def(self, stmt) -> Type:
        param_types = []
        for p in stmt.params:
            p_name = p[0] if isinstance(p, (tuple, list)) else p
            param_types.append((p_name, UNKNOWN))

        old_types = self.types.copy()
        old_return = self.current_fn_return
        self.current_fn_return = None

        for p_name, t in param_types:
            self.types[p_name] = t

        for s in stmt.body:
            self.infer_stmt(s)

        inferred_return = self.current_fn_return or UNKNOWN
        self.types = old_types
        self.current_fn_return = old_return

        self.functions[stmt.name] = {"return": inferred_return, "params": param_types}
        return Type("fn")

    def _infer_while_stmt(self, stmt: WhileStmt):
        self.infer_expr(stmt.condition)
        for s in stmt.body:
            self.infer_stmt(s)

    def _infer_for_stmt(self, stmt: ForStmt):
        self.infer_expr(stmt.iter)
        self.types[stmt.var] = UNKNOWN
        for s in stmt.body:
            self.infer_stmt(s)

    def _infer_class_def(self, stmt: ClassDef):
        for method in stmt.methods:
            self._infer_fn_def(method)
        self.types[stmt.name] = Type("class")

    def _infer_match_stmt(self, stmt: MatchStmt):
        self.infer_expr(stmt.expr)
        for case in stmt.cases:
            for s in case.body:
                self.infer_stmt(s)

    def check_types(self, expected: Type, got: Type, context: str):
        if expected.name != "unknown" and got.name != "unknown" and expected.name != "any" and got.name != "any":
            if expected.name != got.name:
                self.errors.append(f"Type mismatch in {context}: expected {expected.name}, got {got.name}")

    def _parse_type_hint(self, hint: str) -> Type:
        mapping = {
            "int": INT,
            "float": FLOAT,
            "string": STR,
            "str": STR,
            "bool": BOOL,
            "list": LIST,
            "dict": DICT,
            "null": NULL,
        }
        return mapping.get(hint, UNKNOWN)

    def infer_scope(self, stmts: list) -> dict[str, Type]:
        for stmt in stmts:
            self.infer_stmt(stmt)
        return self.types.copy()


class TypeChecker:
    def __init__(self):
        self.inferrer = TypeInferrer()
        self.errors = []

    def check(self, stmts: list) -> list[str]:
        self.errors = []
        for stmt in stmts:
            self.inferrer.infer_stmt(stmt)
        return self.errors + self.inferrer.errors


def infer_types(source: str) -> dict[str, Type]:
    from .lexer import Lexer
    
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    
    inferrer = TypeInferrer()
    inferrer.infer_scope(ast)
    return inferrer.types


def type_check(source: str) -> list[str]:
    from .lexer import Lexer
    
    lexer = Lexer(source)
    tokens = lexer.tokenize()
    parser = Parser(tokens)
    ast = parser.parse()
    
    checker = TypeChecker()
    return checker.check(ast)