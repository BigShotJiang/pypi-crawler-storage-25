/*
 * _cvm_ext.c — Python C extension that wraps the Mo C VM.
 *
 * Eliminates the subprocess+JSON-temp-file overhead of the standalone binary:
 *   - JSON is passed as a Python bytes/str object directly in memory
 *   - Import callbacks call back to Python instead of spawning a new process
 *   - No fork, no disk I/O for bytecode transfer
 *
 * Build: handled by setup.py (Extension target).
 * Usage: from mo_lang import _cvm; _cvm.run(json_str, base_dir, import_cb)
 */

#define MO_AS_EXTENSION 1
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include <stdlib.h>
#include <string.h>

/* Pull in the entire C VM (compiled as one translation unit). */
#include "../cvm/mo_vm.c"

/* ── Python import callback ─────────────────────────────────────────────────
 * Called by vm_import() when g_import_cb != NULL.
 * Calls the Python callable: import_cb(mo_path, base_dir) -> str | None
 * Returns malloc'd JSON string (caller must free), or NULL on failure.
 */
static PyObject *g_py_import_cb = NULL;

static char *py_import_callback(const char *mo_path, const char *base_dir) {
    if (!g_py_import_cb || g_py_import_cb == Py_None) return NULL;

    PyObject *result = PyObject_CallFunction(g_py_import_cb, "ss", mo_path, base_dir);
    if (!result) {
        PyErr_Clear();
        return NULL;
    }
    if (result == Py_None) {
        Py_DECREF(result);
        return NULL;
    }

    const char *s = NULL;
    Py_ssize_t len = 0;
    if (PyUnicode_Check(result)) {
        s = PyUnicode_AsUTF8AndSize(result, &len);
    } else if (PyBytes_Check(result)) {
        PyBytes_AsStringAndSize(result, (char **)&s, &len);
    }

    char *json = NULL;
    if (s) {
        json = (char *)malloc(len + 1);
        if (json) { memcpy(json, s, len); json[len] = '\0'; }
    }
    Py_DECREF(result);
    return json;
}

/* ── mo_run(json_str, base_dir, import_cb) ──────────────────────────────────
 * json_str  : str or bytes — compiled bytecode as JSON
 * base_dir  : str — directory of the source file (for relative imports)
 * import_cb : callable(mo_path: str, base_dir: str) -> str | None
 *             Called when Mo code does `import "name"`.
 *             Should return the JSON bytecode for the module, or None.
 */
static PyObject *py_mo_run(PyObject *self, PyObject *args) {
    (void)self;
    PyObject *json_obj;
    const char *base_dir = ".";
    PyObject *import_cb  = Py_None;

    if (!PyArg_ParseTuple(args, "O|sO", &json_obj, &base_dir, &import_cb))
        return NULL;

    /* Accept str or bytes for the JSON payload */
    const char *json_str = NULL;
    Py_ssize_t  json_len = 0;
    PyObject   *encoded  = NULL;

    if (PyUnicode_Check(json_obj)) {
        json_str = PyUnicode_AsUTF8AndSize(json_obj, &json_len);
        if (!json_str) return NULL;
    } else if (PyBytes_Check(json_obj)) {
        PyBytes_AsStringAndSize(json_obj, (char **)&json_str, &json_len);
    } else {
        PyErr_SetString(PyExc_TypeError, "json must be str or bytes");
        return NULL;
    }

    /* Install the Python import callback */
    g_py_import_cb = (import_cb == Py_None) ? NULL : import_cb;
    g_import_cb    = (g_py_import_cb) ? py_import_callback : NULL;

    /* Make a null-terminated copy (vm_run_json needs C string) */
    char *json_copy = (char *)malloc(json_len + 1);
    if (!json_copy) return PyErr_NoMemory();
    memcpy(json_copy, json_str, json_len);
    json_copy[json_len] = '\0';
    (void)encoded;

    int rc = vm_run_json(json_copy, base_dir, 0);
    free(json_copy);

    /* Restore globals */
    g_import_cb    = NULL;
    g_py_import_cb = NULL;

    if (rc) {
        /* Mo threw an uncaught exception — surface it as a Python RuntimeError */
        char buf[512];
        mo_display(g_exc_val, buf, sizeof(buf));
        PyErr_Format(PyExc_RuntimeError, "[Uncaught throw] %s", buf);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ── mo_run_trace(json_str, base_dir, import_cb) ────────────────────────────
 * Same as mo_run but with instruction-level tracing to stderr.
 */
static PyObject *py_mo_run_trace(PyObject *self, PyObject *args) {
    (void)self;
    PyObject *json_obj;
    const char *base_dir = ".";
    PyObject *import_cb  = Py_None;

    if (!PyArg_ParseTuple(args, "O|sO", &json_obj, &base_dir, &import_cb))
        return NULL;

    const char *json_str = NULL;
    Py_ssize_t  json_len = 0;

    if (PyUnicode_Check(json_obj)) {
        json_str = PyUnicode_AsUTF8AndSize(json_obj, &json_len);
        if (!json_str) return NULL;
    } else if (PyBytes_Check(json_obj)) {
        PyBytes_AsStringAndSize(json_obj, (char **)&json_str, &json_len);
    } else {
        PyErr_SetString(PyExc_TypeError, "json must be str or bytes");
        return NULL;
    }

    g_py_import_cb = (import_cb == Py_None) ? NULL : import_cb;
    g_import_cb    = (g_py_import_cb) ? py_import_callback : NULL;

    char *json_copy = (char *)malloc(json_len + 1);
    if (!json_copy) return PyErr_NoMemory();
    memcpy(json_copy, json_str, json_len);
    json_copy[json_len] = '\0';

    int rc = vm_run_json(json_copy, base_dir, 1 /* trace */);
    free(json_copy);

    g_import_cb    = NULL;
    g_py_import_cb = NULL;

    if (rc) {
        char buf[512];
        mo_display(g_exc_val, buf, sizeof(buf));
        PyErr_Format(PyExc_RuntimeError, "[Uncaught throw] %s", buf);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ── Module definition ──────────────────────────────────────────────────────*/

static PyMethodDef CvmMethods[] = {
    {"run",       py_mo_run,       METH_VARARGS,
     "run(json, base_dir='.', import_cb=None)\n"
     "Execute Mo bytecode JSON in the C VM.\n"
     "Raises RuntimeError on uncaught Mo throw."},
    {"run_trace", py_mo_run_trace, METH_VARARGS,
     "run_trace(json, base_dir='.', import_cb=None)\n"
     "Same as run() but prints each instruction to stderr."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef cvm_module = {
    PyModuleDef_HEAD_INIT,
    "_cvm",       /* module name */
    "Mo C VM extension module — eliminates subprocess overhead.",
    -1,
    CvmMethods
};

PyMODINIT_FUNC PyInit__cvm(void) {
    return PyModule_Create(&cvm_module);
}
