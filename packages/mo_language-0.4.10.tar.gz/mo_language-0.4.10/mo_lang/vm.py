"""
vm.py — stack-based virtual machine for Mo bytecode.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import asyncio
from .compiler import Op, CompiledFn
from .jit import JitVM, JIT_COMPILE_THRESHOLD
from .interpreter import (
    Environment, Function, Klass, Instance, BoundSuper, AsyncFunction, Iterator,
    RuntimeError_, Interpreter,
)


class MoThrow(Exception):
    def __init__(self, value):
        self.value = value


class AsyncReturnSignal(Exception):
    def __init__(self, value):
        self.value = value


class VMFunction:
    def __init__(self, name: str, params: list[str], code: list, closure: Environment,
                 variadic: tuple[str | None, str | None] = (None, None), defaults: list = None):
        self.name     = name
        self.params   = params
        self.code     = code
        self.closure  = closure
        self.variadic = variadic   # (*args_name, **kwargs_name)
        self.defaults = defaults   # parallel to params: None or list[Instr]

    def __repr__(self):
        param_strs = list(self.params)
        args_name, kwargs_name = self.variadic
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<fn {self.name}({', '.join(param_strs)})>"


class VMAsyncFunction:
    def __init__(self, name: str, params: list[str], code: list, closure: Environment, variadic: tuple[str | None, str | None] = (None, None)):
        self.name    = name
        self.params  = params
        self.code    = code
        self.closure = closure
        self.variadic = variadic  # (*args_name, **kwargs_name)

    def __repr__(self):
        param_strs = list(self.params)
        args_name, kwargs_name = self.variadic
        if args_name:
            param_strs.append(f"*{args_name}")
        if kwargs_name:
            param_strs.append(f"**{kwargs_name}")
        return f"<async fn {self.name}({', '.join(param_strs)})>"


@dataclass
class Frame:
    code:      list
    ip:        int              = 0
    env:       Environment      = field(default_factory=Environment)
    stack:     list             = field(default_factory=list)
    try_stack: list             = field(default_factory=list)
    retval:    object           = None


class VM:
    def __init__(self, trace: bool = False, use_jit: bool = False):
        self._interp = Interpreter()
        self._interp._vm = self
        self.globals = self._interp.globals
        self._base_dir = '.'
        self._current_line = 0
        self._trace = trace
        self._frames = []
        self._jit_vm = JitVM(use_jit=use_jit) if use_jit else None
        self._hot_functions: dict = {}
        self._dispatch = self._build_dispatch()

    def run(self, code: list, env: Environment = None) -> None:
        if env is None:
            env = Environment(parent=self.globals)
        frame = Frame(code=code, env=env)
        self._frames.append(frame)
        try:
            self._run_frame(frame)
        finally:
            self._frames.pop()

    def _run_frame(self, frame: Frame) -> object:
        code  = frame.code
        stack = frame.stack
        env   = frame.env

        while frame.ip < len(code):
            instr = code[frame.ip]
            if self._trace:
                import sys
                print(f"  {frame.ip:4d}  {instr!r:<30s}  stack={[repr(s)[:20] for s in stack]}", file=sys.stderr)
            frame.ip += 1
            try:
                done = self._exec(instr, frame, stack, env)
                if done:
                    return frame.retval
            except (MoThrow, RuntimeError_) as exc:
                if frame.try_stack:
                    catch_ip, err_var, depth = frame.try_stack.pop()
                    while len(stack) > depth:
                        stack.pop()
                    err_val = exc.value if isinstance(exc, MoThrow) else str(exc)
                    env.define(err_var, err_val)
                    frame.ip = catch_ip
                else:
                    raise

        return frame.retval

    def _build_dispatch(self) -> dict:
        interp = self._interp

        def _line(instr, frame, stack, env):
            self._current_line = instr.arg
            return False

        def _load_const(instr, frame, stack, env):
            stack.append(instr.arg)

        def _load_name(instr, frame, stack, env):
            stack.append(env.get(instr.arg))

        def _define_name(instr, frame, stack, env):
            env.define(instr.arg, stack.pop())

        def _store_name(instr, frame, stack, env):
            env.set(instr.arg, stack.pop())

        def _pop(instr, frame, stack, env):
            stack.pop()

        def _dup(instr, frame, stack, env):
            stack.append(stack[-1])

        def _binary_op(instr, frame, stack, env):
            right = stack.pop()
            left  = stack.pop()
            stack.append(interp._binop(instr.arg, left, right))

        def _unary_op(instr, frame, stack, env):
            val = stack.pop()
            if instr.arg == '-':
                stack.append(-val)
            else:
                stack.append(not interp._truthy(val))

        def _jump(instr, frame, stack, env):
            frame.ip = instr.arg

        def _jump_if_false(instr, frame, stack, env):
            if not interp._truthy(stack.pop()):
                frame.ip = instr.arg

        def _call(instr, frame, stack, env):
            args = list(reversed([stack.pop() for _ in range(instr.arg)]))
            fn   = stack.pop()
            stack.append(self._call(fn, args, env))

        def _return(instr, frame, stack, env):
            frame.retval = stack.pop()
            return True

        def _make_list(instr, frame, stack, env):
            stack.append(list(reversed([stack.pop() for _ in range(instr.arg)])))

        def _make_dict(instr, frame, stack, env):
            pairs = []
            for _ in range(instr.arg):
                v = stack.pop()
                k = stack.pop()
                pairs.append((k, v))
            pairs.reverse()
            stack.append(dict(pairs))

        def _index_get(instr, frame, stack, env):
            idx = stack.pop()
            obj = stack.pop()
            stack.append(interp._index_get(obj, idx))

        def _index_set(instr, frame, stack, env):
            val = stack.pop()
            idx = stack.pop()
            obj = stack.pop()
            interp._index_set(obj, idx, val)
            stack.append(val)

        def _get_attr(instr, frame, stack, env):
            stack.append(self._get_attr(stack.pop(), instr.arg))

        def _set_attr(instr, frame, stack, env):
            val = stack.pop()
            obj = stack.pop()
            if not isinstance(obj, Instance):
                raise RuntimeError_("Can only set attributes on class instances")
            obj.fields[instr.arg] = val
            stack.append(val)

        def _method_call(instr, frame, stack, env):
            method, argc = instr.arg
            args = list(reversed([stack.pop() for _ in range(argc)]))
            obj  = stack.pop()
            stack.append(self._call_method(obj, method, args))

        def _make_function(instr, frame, stack, env):
            cfn: CompiledFn = instr.arg
            stack.append(VMFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic, cfn.defaults))

        def _make_async_function(instr, frame, stack, env):
            cfn: CompiledFn = instr.arg
            stack.append(VMAsyncFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic))

        def _await(instr, frame, stack, env):
            stack.append(self._await_value(stack.pop()))

        def _async_return(instr, frame, stack, env):
            raise AsyncReturnSignal(stack.pop() if stack else None)

        def _make_class(instr, frame, stack, env):
            name, parent_name, method_cfns = instr.arg
            methods = {
                mname: VMFunction(cfn.name, cfn.params, cfn.code, env, cfn.variadic, cfn.defaults)
                for mname, cfn in method_cfns.items()
            }
            parent = None
            if parent_name:
                parent = env.get(parent_name)
                if not isinstance(parent, Klass):
                    raise RuntimeError_(f"'{parent_name}' is not a class")
            stack.append(Klass(name, methods, parent))

        def _throw(instr, frame, stack, env):
            raise MoThrow(stack.pop())

        def _setup_try(instr, frame, stack, env):
            catch_ip, err_var = instr.arg
            frame.try_stack.append((catch_ip, err_var, len(stack)))

        def _end_try(instr, frame, stack, env):
            frame.try_stack.pop()

        def _import(instr, frame, stack, env):
            self._import(instr.arg, env)
            return False

        def _make_iter(instr, frame, stack, env):
            lst = stack.pop()
            if isinstance(lst, (list, dict, str)):
                stack.append(iter(lst.keys()) if isinstance(lst, dict) else iter(lst))
            elif isinstance(lst, Iterator):
                stack.append(lst)
            else:
                raise RuntimeError_("'for' requires a list, dict, string, or iterator")

        def _for_iter(instr, frame, stack, env):
            it = stack[-1]
            if isinstance(it, Iterator):
                if it.has_next():
                    stack.append(it.next())
                else:
                    stack.pop()
                    frame.ip = instr.arg
            else:
                try:
                    stack.append(next(it))
                except StopIteration:
                    stack.pop()
                    frame.ip = instr.arg

        def _noop(instr, frame, stack, env):
            pass

        def _match_end(instr, frame, stack, env):
            if stack:
                stack.pop()

        def _match_bind(instr, frame, stack, env):
            env.define(instr.arg, stack[-1])

        def _destructure_list(instr, frame, stack, env):
            value = stack.pop()
            if not isinstance(value, list):
                raise RuntimeError_(f"Cannot destructure list pattern from {type(value).__name__}")
            var_names = instr.arg
            if len(var_names) != len(value):
                raise RuntimeError_(
                    f"List destructuring pattern has {len(var_names)} elements but value has {len(value)}"
                )
            for var_name, val in zip(var_names, value):
                env.define(var_name, val)

        def _destructure_dict(instr, frame, stack, env):
            value = stack.pop()
            if not isinstance(value, dict):
                raise RuntimeError_(f"Cannot destructure dict pattern from {type(value).__name__}")
            for key, var_name in instr.arg:
                if key not in value:
                    raise RuntimeError_(f"Key '{key}' not found in dict for destructuring")
                env.define(var_name, value[key])

        return {
            Op.LINE:             _line,
            Op.LOAD_CONST:       _load_const,
            Op.LOAD_NAME:        _load_name,
            Op.DEFINE_NAME:      _define_name,
            Op.STORE_NAME:       _store_name,
            Op.POP:              _pop,
            Op.DUP:              _dup,
            Op.BINARY_OP:        _binary_op,
            Op.UNARY_OP:         _unary_op,
            Op.JUMP:             _jump,
            Op.JUMP_IF_FALSE:    _jump_if_false,
            Op.CALL:             _call,
            Op.RETURN:           _return,
            Op.MAKE_LIST:        _make_list,
            Op.MAKE_DICT:        _make_dict,
            Op.INDEX_GET:        _index_get,
            Op.INDEX_SET:        _index_set,
            Op.GET_ATTR:         _get_attr,
            Op.SET_ATTR:         _set_attr,
            Op.METHOD_CALL:      _method_call,
            Op.MAKE_FUNCTION:    _make_function,
            Op.MAKE_ASYNC_FUNCTION: _make_async_function,
            Op.AWAIT:            _await,
            Op.ASYNC_RETURN:     _async_return,
            Op.MAKE_CLASS:       _make_class,
            Op.THROW:            _throw,
            Op.SETUP_TRY:        _setup_try,
            Op.END_TRY:          _end_try,
            Op.IMPORT:           _import,
            Op.MAKE_ITER:        _make_iter,
            Op.FOR_ITER:         _for_iter,
            Op.MATCH_START:      _noop,
            Op.MATCH_END:        _match_end,
            Op.MATCH_CASE:       _noop,
            Op.MATCH_BIND:       _match_bind,
            Op.DESTRUCTURE_LIST: _destructure_list,
            Op.DESTRUCTURE_DICT: _destructure_dict,
        }

    def _exec(self, instr, frame: Frame, stack: list, env: Environment) -> bool:
        handler = self._dispatch.get(instr.op)
        if handler is None:
            raise RuntimeError_(f"Unknown opcode: {instr.op}")
        result = handler(instr, frame, stack, env)
        return bool(result)

    def _call(self, fn, args: list, env: Environment):
        if isinstance(fn, VMAsyncFunction):
            return self._invoke_async_vm(fn, args)
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, None, args)
        if isinstance(fn, Klass):
            return self._instantiate(fn, args)
        if isinstance(fn, AsyncFunction):
            return self._interp._call_async_fn(fn, args)
        if isinstance(fn, Function):
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _invoke_async_vm(self, fn, args: list, kwargs: dict = None):
        """Invoke an async VM function (runs synchronously with await support)."""
        if kwargs is None:
            kwargs = {}
        call_env = Environment(parent=fn.closure)
        self._bind_params(fn, args, kwargs, call_env)
        try:
            self._exec_code(fn.code, call_env)
        except AsyncReturnSignal as r:
            return r.value
        return None

    def _exec_code(self, code: list, env: Environment):
        """Execute bytecode synchronously in a new frame."""
        frame = Frame(code, env=env)
        self._frames.append(frame)
        try:
            self._run_frame(frame)
        finally:
            self._frames.pop()

    def _await_value(self, aw):
        """Run an awaitable synchronously, regardless of whether a loop is running."""
        if not (asyncio.iscoroutine(aw) or asyncio.isfuture(aw)):
            return aw.__await__() if hasattr(aw, '__await__') else aw
        try:
            asyncio.get_running_loop()
            # Inside a running event loop — dispatch to a worker thread with its own loop
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                return pool.submit(asyncio.run, aw).result()
        except RuntimeError:
            # No running loop — safe to use asyncio.run()
            return asyncio.run(aw)

    def _instantiate(self, klass: Klass, args: list):
        instance = Instance(klass)
        init = self._interp._lookup_method(klass, "init")
        if init:
            self._invoke_callable(init, args, instance=instance)
        return instance

    def _call_method(self, obj, method: str, args: list):
        if isinstance(obj, (str, list)):
            return self._interp._call_method(obj, method, args)
        if isinstance(obj, Instance):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"'{obj.klass.name}' has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj)
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, method)
            if fn is None:
                raise RuntimeError_(f"super has no method '{method}'")
            return self._invoke_callable(fn, args, instance=obj.instance,
                                         super_klass=obj.klass.parent)
        if isinstance(obj, dict):
            fn = obj.get(method)
            if fn is None:
                raise RuntimeError_(f"Module has no function '{method}'")
            return self._call(fn, args, None)
        raise RuntimeError_(
            f"Cannot call method on {self._interp._builtin_type([obj])}"
        )

    def _get_attr(self, obj, attr: str):
        if isinstance(obj, Instance):
            if attr in obj.fields:
                return obj.fields[attr]
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"'{obj.klass.name}' has no attribute '{attr}'")
        if isinstance(obj, BoundSuper):
            fn = self._interp._lookup_method(obj.klass, attr)
            if fn is not None:
                return fn
            raise RuntimeError_(f"super has no attribute '{attr}'")
        if isinstance(obj, str):
            return self._interp._str_method(obj, attr)
        if isinstance(obj, dict):
            if attr in obj:
                return obj[attr]
            raise RuntimeError_(f"Key '{attr}' not found in dict")
        raise RuntimeError_(
            f"Cannot get attribute '{attr}' on {self._interp._builtin_type([obj])}"
        )

    def _invoke_callable(self, fn, args: list, instance=None, super_klass=None):
        if isinstance(fn, VMFunction):
            return self._invoke_vm(fn, instance, args, super_klass)
        if isinstance(fn, Function):
            if instance is not None:
                return self._interp._invoke_method(fn, instance, args, super_klass)
            return self._interp._call(fn, args)
        if callable(fn):
            return fn(args)
        raise RuntimeError_(f"{fn!r} is not callable")

    def _invoke_vm(self, fn: VMFunction, instance, args: list, super_klass=None, kwargs: dict = None):
        if kwargs is None:
            kwargs = {}

        jit_code = None
        if self._jit_vm:
            self._jit_vm.record_call(fn.name)
            if self._jit_vm.should_compile(fn.name):
                jit_code = self._jit_vm.compile_function(
                    fn.name, fn.params, fn.code, fn.closure
                )
                if jit_code:
                    self._hot_functions[fn.name] = -1
                    return self._invoke_jit(fn, instance, args, super_klass, jit_code)

        self._hot_functions[fn.name] = self._hot_functions.get(fn.name, 0) + 1

        call_env = Environment(parent=fn.closure)
        if instance is not None:
            call_env.define("self", instance)
            if super_klass is not None:
                call_env.define("super", BoundSuper(super_klass, instance))
            elif isinstance(instance, Instance) and instance.klass.parent:
                call_env.define("super", BoundSuper(instance.klass.parent, instance))

        # Bind parameters (including variadic)
        self._bind_params(fn, args, kwargs, call_env)

        frame = Frame(code=fn.code, env=call_env)
        return self._run_frame(frame)

    def _bind_params(self, fn, args: list, kwargs: dict, call_env: Environment):
        """Bind parameters to the function environment, handling variadic args and defaults."""
        args_name, kwargs_name = fn.variadic
        params   = fn.params
        defaults = fn.defaults if fn.defaults is not None else []
        num_params = len(params)
        num_args   = len(args)

        # Count params that have no default (required)
        required_count = sum(
            1 for i, p in enumerate(params)
            if i >= len(defaults) or defaults[i] is None
        )

        if args_name:
            regular_args_count = min(num_args, num_params)
        else:
            if num_args > num_params:
                raise RuntimeError_(f"{fn.name}() takes {num_params} args, got {num_args}")
            if num_args < required_count:
                raise RuntimeError_(f"{fn.name}() requires {required_count} args, got {num_args}")
            regular_args_count = num_args

        # Bind provided positional args
        for i in range(regular_args_count):
            call_env.define(params[i], args[i])

        # Apply defaults for remaining params
        for i in range(regular_args_count, num_params):
            if i < len(defaults) and defaults[i] is not None:
                default_frame = Frame(code=defaults[i], env=call_env)
                call_env.define(params[i], self._run_frame(default_frame))
            elif not args_name:
                raise RuntimeError_(f"{fn.name}() missing argument '{params[i]}'")

        if args_name:
            call_env.define(args_name, args[regular_args_count:])

        if kwargs_name:
            call_env.define(kwargs_name, kwargs)
        elif kwargs:
            raise RuntimeError_(f"{fn.name}() does not accept keyword arguments")

    def _invoke_jit(self, fn: VMFunction, instance, args: list, super_klass, jit_code):
        call_env = fn.closure.vars.copy()
        if instance is not None:
            call_env["self"] = instance
        param_dict = dict(zip(fn.params, args))
        call_env.update(param_dict)
        
        try:
            return jit_code(**call_env)
        except Exception as e:
            raise RuntimeError_(f"JIT execution error in {fn.name}: {e}")

    def _import(self, path_alias, env: Environment):
        import os
        from .lexer import Lexer, LexError
        from .parser import Parser, ParseError
        from .compiler import Compiler
        path, alias = path_alias if isinstance(path_alias, tuple) else (path_alias, None)
        mo_path = path if path.endswith('.mo') else path + '.mo'
        full = os.path.join(self._base_dir, mo_path)
        if not os.path.exists(full):
            pkg_fallback = os.path.join(os.path.dirname(__file__), mo_path)
            if os.path.exists(pkg_fallback):
                full = pkg_fallback
            else:
                user_pkg = os.path.join(os.path.expanduser("~/.mo/packages"), mo_path)
                if os.path.exists(user_pkg):
                    full = user_pkg
                else:
                    raise RuntimeError_(f"Cannot find module '{path}'")
        source = open(full).read()
        try:
            tokens = Lexer(source).tokenize()
            ast    = Parser(tokens).parse()
            code   = Compiler().compile(ast)
        except Exception as e:
            raise RuntimeError_(f"Error in module '{path}': {e}")
        mod_env = Environment(parent=self.globals)
        mod_frame = Frame(code=code, env=mod_env)
        self._run_frame(mod_frame)
        if alias:
            mod_name = path.split('/')[-1]
            prefix   = mod_name + "_"
            ns = {}
            for name, val in mod_env.vars.items():
                short = name[len(prefix):] if name.startswith(prefix) else name
                ns[short] = val
            env.define(alias, ns)
        else:
            for name, val in mod_env.vars.items():
                env.define(name, val)
