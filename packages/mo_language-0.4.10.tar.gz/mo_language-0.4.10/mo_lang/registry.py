"""
Mo package registry.
"""
import json
import urllib.request
from typing import Optional, List, Dict


class PackageRegistry:
    BASE_URL = "https://raw.githubusercontent.com/mo-lang/packages/main"
    FALLBACK_URL = "https://raw.githubusercontent.com/mo-lang/packages/main/packages.json"
    
    def __init__(self):
        self.cache = {}
        self._catalog_cache = None
    
    def _fetch_catalog(self) -> List[Dict]:
        """Fetch package catalog from GitHub."""
        if self._catalog_cache is not None:
            return self._catalog_cache
        
        try:
            data = urllib.request.urlopen(self.FALLBACK_URL).read().decode()
            catalog = json.loads(data)
            self._catalog_cache = catalog.get("packages", [])
            return self._catalog_cache
        except Exception:
            self._catalog_cache = []
            return []
    
    def search(self, query: str) -> List[Dict]:
        """Search packages from registry."""
        query_lower = query.lower()
        
        catalog = self._fetch_catalog()
        if catalog:
            results = [p for p in catalog if query_lower in p.get("name", "").lower() or 
                      query_lower in p.get("description", "").lower()]
            if results:
                self.cache[query] = results
                return results
        
        results = [
            {"name": "mo-redis", "description": "Redis database client", "version": "1.0.0", "author": "mo-lang", "repo": "mo-lang/mo-redis"},
            {"name": "mo-http", "description": "HTTP client/server", "version": "1.2.0", "author": "mo-lang", "repo": "mo-lang/mo-http"},
            {"name": "mo-json", "description": "JSON encode/decode", "version": "1.0.0", "author": "mo-lang", "repo": "mo-lang/mo-json"},
            {"name": "mo-math", "description": "Math utilities", "version": "1.0.0", "author": "mo-lang", "repo": "mo-lang/mo-math"},
            {"name": "mo-regex", "description": "Regular expressions", "version": "0.3.0", "author": "mo-lang", "repo": "mo-lang/mo-regex"},
            {"name": "mo-uuid", "description": "UUID generation", "version": "1.0.0", "author": "mo-lang", "repo": "mo-lang/mo-uuid"},
        ]
        
        filtered = [p for p in results if query_lower in p["name"].lower()]
        self.cache[query] = filtered
        return filtered
    
    def get_info(self, name: str) -> Optional[Dict]:
        """Get package info."""
        catalog = self._fetch_catalog()
        
        for pkg in catalog:
            if pkg.get("name") == name:
                return pkg
        
        for pkg in self.search(name):
            if pkg["name"] == name:
                return pkg
        
        return {
            "name": name,
            "version": "1.0.0",
            "description": f"{name} package",
            "deps": [],
            "author": "mo-lang",
            "repo": f"mo-lang/{name}"
        }
    
    def download(self, name: str, version: str = "main") -> str:
        """Download package source code."""
        url = f"{self.BASE_URL}/{name}/{name}.mo"
        
        try:
            content = urllib.request.urlopen(url).read().decode()
            return content
        except Exception:
            return f"# Package {name} v{version}\n# Package source not found in registry\n"


_registry = None

def get_registry() -> PackageRegistry:
    global _registry
    if _registry is None:
        _registry = PackageRegistry()
    return _registry