"""
JIT Profiler - profiles Mo code for optimization opportunities
"""
import time
from collections import defaultdict
from typing import Dict, List, Tuple


class JITProfiler:
    def __init__(self):
        self.call_graph: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.loop_counts: Dict[str, int] = defaultdict(int)
        self.type_profiles: Dict[str, set] = defaultdict(set)

    def profile_call(self, caller: str, callee: str):
        """Profile function call"""
        self.call_graph[caller][callee] += 1

    def profile_type(self, var: str, type_name: str):
        """Profile variable type"""
        self.type_profiles[var].add(type_name)

    def find_hot_paths(self) -> List[Tuple[str, int]]:
        """Find hot execution paths"""
        hot = []
        for caller, callees in self.call_graph.items():
            total = sum(callees.values())
            hot.append((caller, total))
        return sorted(hot, key=lambda x: -x[1])[:10]

    def get_type_profile(self, var: str) -> set:
        """Get known types for a variable"""
        return self.type_profiles.get(var, set())

    def get_stats(self) -> Dict:
        """Get profiler statistics"""
        return {
            'hot_paths': self.find_hot_paths(),
            'type_profiles': {k: list(v) for k, v in self.type_profiles.items()},
            'loop_counts': dict(self.loop_counts)
        }