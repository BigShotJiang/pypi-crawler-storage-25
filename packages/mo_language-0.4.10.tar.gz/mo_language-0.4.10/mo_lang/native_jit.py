"""
Native JIT - generates C code for maximum performance
"""
from typing import Dict, List, Any
from dataclasses import dataclass


@dataclass
class CCode:
    """Generated C code"""
    header: str
    source: str


class NativeJIT:
    def __init__(self):
        self.code_cache: Dict[str, str] = {}

    def generate_c(self, fn_name: str, params: List[str], ops: List) -> CCode:
        """Generate C code from Mo bytecode"""
        lines = [
            "#include <stdio.h>",
            "#include <stdlib.h>",
            "",
            "typedef enum { MO_NIL, MO_NUM, MO_STR, MO_BOOL, MO_LIST, MO_DICT } MoType;",
            "",
            "typedef struct {",
            "    MoType type;",
            "    union {",
            "        double num;",
            "        char *str;",
            "        int bool;",
            "        void *list;",
            "        void *dict;",
            "    } val;",
            "} MoVal;",
            "",
            f"MoVal mo_{fn_name}({', '.join(['MoVal'] * len(params))}) {{",
        ]

        for op in ops:
            c_code = self._to_c(op)
            if c_code:
                lines.append(f"    {c_code};")

        lines.append("    MoVal r = {MO_NIL};")
        lines.append("    return r;")
        lines.append("}")

        return CCode(header="", source="\n".join(lines))

    def _to_c(self, op) -> str:
        """Convert Mo opcode to C code"""
        from .compiler import Op

        opcode = op.op
        arg = op.arg if hasattr(op, 'arg') else None

        if opcode == Op.LOAD_CONST:
            if isinstance(arg, (int, float)):
                return f"MoVal r = {{MO_NUM, {{.num = {arg}}}}}"
            elif isinstance(arg, str):
                return f'MoVal r = {{MO_STR, {{.str = "{arg}"}}}}'
            elif arg is None:
                return "MoVal r = {MO_NIL}"
            elif isinstance(arg, bool):
                return f"MoVal r = {{MO_BOOL, {{.bool = {int(arg)}}}}}"
        elif opcode == Op.BINARY_OP:
            if arg == '+':
                return "r.val.num = l.val.num + r.val.num"
            elif arg == '-':
                return "r.val.num = l.val.num - r.val.num"
            elif arg == '*':
                return "r.val.num = l.val.num * r.val.num"
            elif arg == '/':
                return "r.val.num = l.val.num / r.val.num"
        elif opcode == Op.RETURN:
            return "return r"

        return ""

    def get_stats(self) -> Dict:
        """Get native JIT statistics"""
        return {
            'functions': len(self.code_cache),
            'cache_size': sum(len(c) for c in self.code_cache.values())
        }