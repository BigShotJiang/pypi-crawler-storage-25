# Mo Language Complete Manual
# Mo 语言完整手册
# راهنمای کامل زبان Mo

**Version 0.2.0 | April 2024**

---

## 🇺🇸 English | 🇨🇳 中文 | 🇮🇷 فارسی

---

# 1. Introduction / 简介 / مقدمه

**English:**
Mo is a modern, expressive, and fast scripting language with the following features:
- **Multiple backends**: Bytecode VM, LLVM JIT, WebAssembly
- **Modern features**: Pattern matching, macro system, destructuring
- **Concurrency support**: async/await, locks, semaphores
- **Complete toolchain**: Formatter, linter, LSP, debugger

**中文：**
Mo 是一个现代、表达力强、快速的脚本语言，具有以下特点：
- **多后端支持**：Bytecode VM、LLVM JIT、WebAssembly
- **现代特性**：模式匹配、宏系统、解构赋值
- **并发支持**：async/await、锁、信号量
- **完整工具链**：格式化、检查、LSP、调试器

**فارسی:**
Mo یک زبان اسکریپت‌نویسی مدرن، رسا و سریع با ویژگی‌های زیر است:
- **بک‌اندهای متعدد**: Bytecode VM، LLVM JIT، WebAssembly
- **ویژگی‌های مدرن**: تطبیق الگو، سیستم ماکرو، تخریب‌سازی
- **پشتیبانی از همزمانی**: async/await، قفل‌ها، سمافورها
- **زنجیره ابزار کامل**: فرمتر، لینتر، LSP، دیباگر

---

# 2. Installation / 安装 / نصب

**English:**
```bash
# Via pip (recommended)
pip install mo-language

# With LLVM support
pip install mo-language[llvm]

# Verify
mo --version
```

**中文：**
```bash
# 通过 pip 安装（推荐）
pip install mo-language

# 带 LLVM 支持
pip install mo-language[llvm]

# 验证
mo --version
```

**فارسی:**
```bash
# نصب با pip (توصیه شده)
pip install mo-language

# با پشتیبانی LLVM
pip install mo-language[llvm]

# تأیید نصب
mo --version
```

---

# 3. Basic Syntax / 基础语法 / syntax پایه

**English:**
```mo
# Variables
let x = 10
let name = "Mo"
let pi = 3.14159

# Type annotations (optional)
let count: int = 100
let message: str = "Hello"
```

**中文：**
```mo
# 变量
let x = 10
let name = "Mo"
let pi = 3.14159

# 类型注解（可选）
let count: int = 100
let message: str = "Hello"
```

**فارسی:**
```mo
# متغیرها
let x = 10
let name = "Mo"
let pi = 3.14159

# حاشیه‌نویسی نوع (اختیاری)
let count: int = 100
let message: str = "Hello"
```

---

# 4. Data Types / 数据类型 / انواع داده

**English:**
```mo
# Numbers
let integer = 42
let floating = 3.14159

# Strings
let greeting = "Hello, " + name
let template = `Hello, ${name}!`

# Lists
let numbers = [1, 2, 3, 4, 5]
push(numbers, 6)
let first = numbers[0]

# Dicts
let person = {"name": "Alice", "age": 30}
let name = person["name"]
```

**中文：**
```mo
# 数字
let integer = 42
let floating = 3.14159

# 字符串
let greeting = "Hello, " + name
let template = `Hello, ${name}!`

# 列表
let numbers = [1, 2, 3, 4, 5]
push(numbers, 6)
let first = numbers[0]

# 字典
let person = {"name": "Alice", "age": 30}
let name = person["name"]
```

**فارسی:**
```mo
# اعداد
let integer = 42
let floating = 3.14159

# رشته‌ها
let greeting = "Hello, " + name
let template = `Hello, ${name}!`

# لیست‌ها
let numbers = [1, 2, 3, 4, 5]
push(numbers, 6)
let first = numbers[0]

# دیکشنری‌ها
let person = {"name": "Alice", "age": 30}
let name = person["name"]
```

---

# 5. Control Flow / 控制流 / جریان کنترل

**English:**
```mo
# If-else
if x > 0 {
    print("Positive")
} else if x < 0 {
    print("Negative")
} else {
    print("Zero")
}

# While loop
let i = 0
while i < 10 {
    print(i)
    i = i + 1
}

# For loop
for item in [1, 2, 3] {
    print(item)
}
```

**中文：**
```mo
# If-else
if x > 0 {
    print("Positive")
} else if x < 0 {
    print("Negative")
} else {
    print("Zero")
}

# While 循环
let i = 0
while i < 10 {
    print(i)
    i = i + 1
}

# For 循环
for item in [1, 2, 3] {
    print(item)
}
```

**فارسی:**
```mo
# If-else
if x > 0 {
    print("Positive")
} else if x < 0 {
    print("Negative")
} else {
    print("Zero")
}

# حلقه While
let i = 0
while i < 10 {
    print(i)
    i = i + 1
}

# حلقه For
for item in [1, 2, 3] {
    print(item)
}
```

---

# 6. Functions / 函数 / توابع

**English:**
```mo
# Basic function
fn greet(name) {
    return "Hello, " + name
}

# Default parameters
fn greet(name, greeting = "Hello") {
    return greeting + ", " + name
}

# Variadic parameters
fn sum(*numbers) {
    let total = 0
    for n in numbers {
        total = total + n
    }
    return total
}

# Anonymous function
let multiply = fn(a, b) { return a * b }
```

**中文：**
```mo
# 基本函数
fn greet(name) {
    return "Hello, " + name
}

# 默认参数
fn greet(name, greeting = "Hello") {
    return greeting + ", " + name
}

# 可变参数
fn sum(*numbers) {
    let total = 0
    for n in numbers {
        total = total + n
    }
    return total
}

# 匿名函数
let multiply = fn(a, b) { return a * b }
```

**فارسی:**
```mo
# تابع پایه
fn greet(name) {
    return "Hello, " + name
}

# پارامترهای پیش‌فرض
fn greet(name, greeting = "Hello") {
    return greeting + ", " + name
}

# پارامترهای متغیر
fn sum(*numbers) {
    let total = 0
    for n in numbers {
        total = total + n
    }
    return total
}

# تابع ناشناس
let multiply = fn(a, b) { return a * b }
```

---

# 7. Pattern Matching / 模式匹配 / تطبیق الگو

**English:**
```mo
fn classify(value) {
    match value {
        case 0 => "zero"
        case [x, y] => "pair: " + x + ", " + y
        case {"name": n} => "name: " + n
        case n if n > 100 => "large"
        case _ => "other"
    }
}
```

**中文：**
```mo
fn classify(value) {
    match value {
        case 0 => "zero"
        case [x, y] => "pair: " + x + ", " + y
        case {"name": n} => "name: " + n
        case n if n > 100 => "large"
        case _ => "other"
    }
}
```

**فارسی:**
```mo
fn classify(value) {
    match value {
        case 0 => "zero"
        case [x, y] => "pair: " + x + ", " + y
        case {"name": n} => "name: " + n
        case n if n > 100 => "large"
        case _ => "other"
    }
}
```

---

# 8. Macros / 宏系统 / سیستم ماکرو

**English:**
```mo
# Built-in macros
!When(debug, print("Debug mode"))
!Assert(x > 0, "x must be positive")

# Custom macro
macro Double(x) {
    return x * 2
}

let result = !Double(5)  # 25
```

**中文：**
```mo
# 内置宏
!When(debug, print("Debug mode"))
!Assert(x > 0, "x must be positive")

# 自定义宏
macro Double(x) {
    return x * 2
}

let result = !Double(5)  # 25
```

**فارسی:**
```mo
# ماکروهای داخلی
!When(debug, print("Debug mode"))
!Assert(x > 0, "x must be positive")

# ماکرو سفارشی
macro Double(x) {
    return x * 2
}

let result = !Double(5)  # 25
```

---

# 9. Concurrency / 并发 / همزمانی

**English:**
```mo
# Async/await
async fn fetchData(url) {
    sleep_async(100)
    return {"data": "content"}
}

let future = fetchData("http://api.example.com")
let result = await future

# Locks
let mtx = lock()
lock_acquire(mtx)
# Critical section
lock_release(mtx)
```

**中文：**
```mo
# 异步/等待
async fn fetchData(url) {
    sleep_async(100)
    return {"data": "content"}
}

let future = fetchData("http://api.example.com")
let result = await future

# 锁
let mtx = lock()
lock_acquire(mtx)
# 临界区
lock_release(mtx)
```

**فارسی:**
```mo
# Async/await
async fn fetchData(url) {
    sleep_async(100)
    return {"data": "content"}
}

let future = fetchData("http://api.example.com")
let result = await future

# قفل‌ها
let mtx = lock()
lock_acquire(mtx)
# بخش بحرانی
lock_release(mtx)
```

---

# 10. CLI Commands / 命令行 / دستورات CLI

**English:**
- `mo file.mo` - Run program
- `mo --llvm file.mo` - Generate LLVM IR
- `mo --wasm file.mo` - Compile to WebAssembly
- `mo fmt file.mo` - Format code
- `mo lint file.mo` - Static analysis
- `mo lsp` - Start LSP server

**中文：**
- `mo file.mo` - 运行程序
- `mo --llvm file.mo` - 生成 LLVM IR
- `mo --wasm file.mo` - 编译为 WebAssembly
- `mo fmt file.mo` - 格式化代码
- `mo lint file.mo` - 静态分析
- `mo lsp` - 启动 LSP 服务器

**فارسی:**
- `mo file.mo` - اجرای برنامه
- `mo --llvm file.mo` - تولید LLVM IR
- `mo --wasm file.mo` - کامپایل به WebAssembly
- `mo fmt file.mo` - فرمت کد
- `mo lint file.mo` - تحلیل استاتیک
- `mo lsp` - راه‌اندازی سرور LSP

---

# License / 许可证 / مجوز

MIT License | MIT 许可证 | مجوز MIT

© 2024 Mo Language
