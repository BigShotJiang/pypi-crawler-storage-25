# LLVM and WebAssembly Backends

Mo now supports compilation to LLVM IR and WebAssembly!

## LLVM Backend

The LLVM backend compiles Mo code to LLVM Intermediate Representation (IR), which can then be optimized and executed using LLVM's JIT compiler.

### Usage

```bash
# Generate LLVM IR
mo --llvm file.mo

# Compile and execute with LLVM JIT
mo --llvm-run file.mo
```

### Example

```mo
# test.mo
fn add(a, b) {
    return a + b
}

fn main() {
    let x = 10
    let y = 20
    return add(x, y)
}

main()
```

```bash
$ mo --llvm test.mo
; ModuleID = "mo_program"
target triple = "unknown-unknown-unknown"

declare void @"mo_print"(...)
...
define {i8, double, i8*, i8*}* @"main"()
{
entry:
  %"var_x" = call {i8, double, i8*, i8*}* @"mo_number"(double 10.0)
  ...
}
```

### Implementation Details

The LLVM backend uses `llvmlite` to generate LLVM IR:

- **Value Representation**: Mo values are represented as a tagged union struct:
  ```llvm
  %MoValue = type { i8, double, i8*, i8* }
  ; { type_tag, number, string_ptr, object_ptr }
  ```

- **Type Tags**:
  - 0 = null
  - 1 = number
  - 2 = bool
  - 3 = string
  - 4 = list
  - 5 = dict

- **External Functions**: Runtime functions are declared as external:
  - `mo_print` - print a value
  - `mo_number` - create a number value
  - `mo_string` - create a string value
  - `mo_add`, `mo_sub`, `mo_mul`, `mo_div` - arithmetic operations

### Requirements

```bash
pip install llvmlite
```

## WebAssembly Backend

The WebAssembly backend compiles Mo code to WASM binary or WAT (WebAssembly Text) format.

### Usage

```bash
# Generate WAT (WebAssembly Text format)
mo --wat file.mo

# Generate WASM binary
mo --wasm file.mo output.wasm
```

### Example

```mo
# test.mo
fn main() {
    let x = 10
    let y = 20
    print(x + y)
    return x + y
}

main()
```

```bash
$ mo --wat test.mo
(module
  (import "env" "print" (func $print (param f64)))
  (func $main (result f64)
    f64.const 10
    f64.const 20
    f64.add
    call $print
    f64.const 30
    return
  )
  (export "main" (func $main))
)

$ mo --wasm test.mo output.wasm
Compiled to output.wasm (114 bytes)
```

### Running WASM

You can run the generated WASM using wasmtime or a web browser:

```bash
# Using wasmtime
wasmtime output.wasm

# Using Node.js
node -e "
  const fs = require('fs');
  const wasm = fs.readFileSync('output.wasm');
  WebAssembly.instantiate(wasm, {
    env: {
      print: (x) => console.log(x)
    }
  }).then(m => m.instance.exports.main());
"
```

### Implementation Details

The WebAssembly backend generates WASM binary format directly:

- **Value Types**: Mo values are represented as F64 (64-bit floats)
- **Memory Model**: Linear memory for heap allocation
- **Import/Export**: Functions can be imported from host and exported
- **Sections**: Complete WASM binary sections (Type, Import, Function, Export, Code)

### Current Limitations

#### LLVM Backend
- Runtime library (mo_print, mo_number, etc.) needs to be implemented in C
- JIT execution requires runtime library linkage
- Limited to basic arithmetic operations currently

#### WebAssembly Backend
- Strings are not yet fully supported
- Lists and dicts require memory management
- Limited standard library support in WASM

## Comparison

| Feature | Bytecode VM | LLVM JIT | WebAssembly |
|---------|------------|----------|-------------|
| Compilation | Fast | Slow | Medium |
| Execution | Medium | Fast | Fast* |
| Portability | High (needs Python) | Low (native code) | High (runs in browser/VM) |
| Startup | Fast | Slow | Fast |
| Optimization | Basic | Advanced | Basic |
| Use Case | Development | Performance | Web/Browser |

*WebAssembly execution speed depends on the host environment

## Future Improvements

### LLVM Backend
- [ ] Complete runtime library in C
- [ ] Optimizations (inlining, loop unrolling)
- [ ] Native binary generation (not just JIT)
- [ ] Debug info generation
- [ ] Profile-guided optimization

### WebAssembly Backend
- [ ] WASI support for system calls
- [ ] Memory management (malloc/free)
- [ ] String and object representation
- [ ] Exception handling
- [ ] SIMD support
- [ ] Multi-value returns

## Architecture

```
Mo Source Code
      |
      v
  Parser (AST)
      |
      +--> Bytecode VM (default)
      |
      +--> LLVM Backend
      |       |
      |       v
      |   LLVM IR
      |       |
      |       v
      |   LLVM JIT / Object File
      |
      +--> WASM Backend
              |
              v
          WASM Binary / WAT
              |
              v
          Browser / wasmtime
```
