# Mo 虚拟机详解

> Mo Language (Python) - 虚拟机技术文档

## 目录

1. [概述](#概述)
2. [整体架构](#整体架构)
3. [字节码编译](#字节码编译)
4. [字节码指令集](#字节码指令集)
5. [虚拟机实现](#虚拟机实现)
6. [执行流程](#执行流程)
7. [多后端支持](#多后端支持)
8. [附录：关键文件](#附录关键文件)

---

## 概述

Mo (Python) 是一个多后端的脚本语言，主要实现包括：

- **字节码虚拟机 (Bytecode VM)**: 基于栈的虚拟机
- **树遍历解释器 (Tree-walk Interpreter)**: 备用解释器
- **LLVM JIT**: 可选的即时编译后端
- **WebAssembly**: 实验性编译目标

---

## 整体架构

```
┌───────────────────────────────���─────────────────────────────────┐
│                        源代码 (.mo)                              │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                         Lexer (词法分析)                          │
│                  将源码转成 Token 流 (mo_lang/lexer.py)            │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Parser (语法分析)                          │
│                   将 Token 流转成 AST (mo_lang/parser.py)         │
└─────────────────────────────────────────────────────────────────┘
                                │
                                ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Compiler (编译器)                             │
│               将 AST 编译成字节码 (mo_lang/compiler.py)            │
│                        Op 枚举定义指令集                           │
└─────────────────────────────────────────────────────────────────┘
                                │
                    ┌───────────┴───────────┐
                    ▼                       ▼
        ┌─────────────────────┐   ┌─────────────────────┐
        │    Bytecode VM      │   │  LLVM JIT Backend   │
        │   (mo_lang/vm.py)   │   │ (mo_lang/llvm_*.py) │
        └─────────────────────┘   └─────────────────────┘
```

---

## 字节码编译

### 编译器流程

```python
# mo_lang/compiler.py

class Compiler:
    def compile(self, ast: AST) -> CompiledFn:
        # 1. 遍历 AST
        # 2. 生成字节码指令列表
        # 3. 返回 CompiledFn (包含 code, constants 等)
        pass
```

### 编译示例

**源程序**:
```mo
let a = 10
let b = 20
print(a + b)
```

**生成的字节码**:
```
LOAD_CONST 10      # 加载常量 10
DEFINE_NAME 'a'    # 定义变量 a
LOAD_CONST 20      # 加载常量 20
DEFINE_NAME 'b'    # 定义变量 b
LOAD_NAME 'a'      # 加载 a
LOAD_NAME 'b'      # 加载 b
BINARY_OP '+'      # 相加
CALL print, 1      # 调用 print
POP                # 弹出返回值
```

---

## 字节码指令集

Mo 的字节码指令定义在 `mo_lang/compiler.py` 的 `Op` 枚举中：

### 加载与存储

| Op | 说明 |
|----|------|
| `LOAD_CONST` | 从常量池加载常量到栈 |
| `LOAD_NAME` | 从环境加载变量值到栈 |
| `STORE_NAME` | 存储栈顶值到变量 |
| `DEFINE_NAME` | 在当前作用域定义变量 |
| `LOAD_GLOBAL` | 加载全局变量 |
| `STORE_GLOBAL` | 存储到全局变量 |

### 栈操作

| Op | 说明 |
|----|------|
| `POP` | 弹出栈顶值 |
| `DUP` | 复制栈顶值 |
| `ROT` | 旋转栈顶元素 |

### 运算

| Op | 说明 |
|----|------|
| `BINARY_OP` | 二元运算 (+, -, *, /, //, %, **, 等) |
| `UNARY_OP` | 一元运算 (-, not) |
| `COMPARE` | 比较运算 |

### 控制流

| Op | 说明 |
|----|------|
| `JUMP` | 无条件跳转 |
| `JUMP_IF_FALSE` | 条件为假时跳转 |
| `JUMP_IF_TRUE` | 条件为真时跳转 |
| `LOOP` | 循环跳转 |

### 函数调用

| Op | 说明 |
|----|------|
| `CALL` | 调用函数（操作数：参数个数） |
| `RETURN` | 函数返回 |
| `MAKE_FUNCTION` | 创建函数对象 |
| `CLOSURE` | 创建闭包 |
| `MAKE_CLASS` | 创建类 |

### 对象操作

| Op | 说明 |
|----|------|
| `BUILD_LIST` | 构建列表 |
| `BUILD_DICT` | 构建字典 |
| `SUBSCRIPT` | 索引访问 |
| `STORE_SUBSCRIPT` | 设置索引值 |
| `LOAD_METHOD` | 加载方法 |
| `CALL_METHOD` | 调用方法 |

---

## 虚拟机实现

### 核心数据结构

```python
# mo_lang/vm.py

@dataclass
class Frame:
    code:      list       # 字节码指令列表
    ip:        int = 0    # 指令指针
    env:       Environment # 环境（变量作用域）
    stack:     list = field(default_factory=list)  # 操作数栈
    try_stack: list = field(default_factory=list)  # try 块栈
    retval:    object = None  # 返回值

class VM:
    def __init__(self, trace: bool = False, use_jit: bool = False):
        self._interp = Interpreter()
        self._frames: list[Frame] = []
        self._dispatch = self._build_dispatch()  # 指令分派表
```

### 执行循环

```python
def _run_frame(self, frame: Frame) -> object:
    code  = frame.code
    stack = frame.stack
    env   = frame.env

    while frame.ip < len(code):
        instr = code[frame.ip]
        
        # 可选：跟踪执行
        if self._trace:
            print(f"  {frame.ip:4d}  {instr!r}")

        frame.ip += 1
        
        # 执行指令
        try:
            done = self._exec(instr, frame, stack, env)
            if done:
                return frame.retval
        except (MoThrow, RuntimeError_) as exc:
            # 异常处理
            if frame.try_stack:
                catch_ip, err_var, depth = frame.try_stack.pop()
                # 处理异常...
                frame.ip = catch_ip
            else:
                raise

    return frame.retval
```

### 指令分派

```python
def _build_dispatch(self) -> dict:
    def _load_const(instr, frame, stack, env):
        stack.append(instr.arg)

    def _binary_op(instr, frame, stack, env):
        right = stack.pop()
        left = stack.pop()
        result = self._interp._binary_op(instr.arg, left, right)
        stack.append(result)

    def _call(instr, frame, stack, env):
        args = [stack.pop() for _ in range(instr.arg)][::-1]
        callee = stack.pop()
        # 调用函数...

    return {
        'LOAD_CONST': _load_const,
        'BINARY_OP': _binary_op,
        'CALL': _call,
        # ...
    }
```

---

## 执行流程

### 完整执行流程

```
┌─────────────────────────────────────────────────────────────┐
│                        main.py                              │
│  mo run script.mo                                          │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  1. 读取源文件                                               │
│     with open(script) as f: source = f.read()                │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  2. 词法分析                                                  │
│     lexer = Lexer(source)                                    │
│     tokens = lexer.tokenize()                               │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  3. 语法分析                                                  │
│     parser = Parser(tokens)                                  │
│     ast = parser.parse()                                     │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  4. 编译                                                      │
│     compiler = Compiler()                                    │
│     fn = compiler.compile(ast)                              │
│     # fn.code: 字节码列表                                     │
│     # fn.constants: 常量池                                    │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌───────────────���─────────────────────────────────────────────┐
│  5. 选择后端                                                  │
│     if use_jit:                                             │
│         vm = JitVM()  # LLVM JIT                            │
│     else:                                                   │
│         vm = VM()    # Bytecode VM                          │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  6. 执行                                                      │
│     vm.run(fn.code)                                         │
│          │                                                   │
│          ├─► VM._run_frame()                               │
│          │     │                                             │
│          │     ├─► while ip < len(code):                    │
│          │     │     │                                       │
│          │     │     ├─► fetch instruction                  │
│          │     │     ├─► dispatch to handler               │
│          │     │     └─► execute & update ip               │
│          │     │                                             │
│          │     └─► return result                           │
│          │                                                   │
│          └─► JitVM.run() (可选 LLVM JIT)                    │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│  7. 返回结果或错误                                            │
└─────────────────────────────────────────────────────────────┘
```

---

## 多后端支持

### 字节码 VM (默认)

```python
# mo run script.mo
vm = VM()        # 基于栈的虚拟机
vm.run(code)
```

### Tree-walk 解释器

```python
# mo --interp script.mo
interp = Interpreter()
interp.interpret(ast)
```

### LLVM JIT (可选)

```python
# mo --jit script.mo
vm = JitVM(use_jit=True)
vm.run(code)
```

### WebAssembly (实验性)

```python
# mo --wasm script.mo
from mo_lang.wasm_backend import compile_to_wasm
wasm_bytes = compile_to_wasm(ast)
```

---

## 附录：关键文件

| 文件 | 说明 |
|------|------|
| `mo_lang/lexer.py` | 词法分析器 |
| `mo_lang/parser.py` | 语法分析器 |
| `mo_lang/compiler.py` | 字节码编译器，Op 枚举定义 |
| `mo_lang/vm.py` | 字节码虚拟机实现 |
| `mo_lang/interpreter.py` | 树遍历解释器 |
| `mo_lang/jit.py` | JIT 虚拟机 |
| `mo_lang/llvm_backend.py` | LLVM 后端 |
| `mo_lang/async_vm.py` | 异步 VM 支持 |

---

## 参考

- [Crafting Interpreters](https://craftinginterpreters.com/) - 编程语言实现经典教材
- [Python 虚拟机](https://docs.python.org/3/library/dis.html) - Python bytecode
- [Lua 5.0 论文](http://www.lua.org/doc/jss05.pdf) - 高效 VM 设计