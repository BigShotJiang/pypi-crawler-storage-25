# Mo Language C/C++ 重写方案

## 当前架构分析

### 现状
- **Lexer/Parser**: Python (约 500 LOC)
- **AST**: Python dataclasses (约 200 LOC)
- **Interpreter**: Python (约 600 LOC)
- **VM**: Python + C extension (约 600 LOC Python + 90KB C)
- **Compiler**: Python (约 800 LOC)
- **LLVM Backend**: Python wrapper (约 300 LOC)
- **WASM Backend**: Python (约 200 LOC)

### 性能瓶颈
1. Python GIL 限制多线程
2. 递归深度限制（1000）
3. 对象 boxing/unboxing 开销
4. 内存分配碎片化
5. 缺乏内联缓存

## C++ 重写架构

### 核心组件 (Tier 1 - 必须重写)

```cpp
// 1. 词法分析器 (lexer.cpp)
class Lexer {
    std::string_view source;
    size_t pos;
    
public:
    std::vector<Token> tokenize();
};

// 2. 语法分析器 (parser.cpp)
class Parser {
    std::vector<Token> tokens;
    
public:
    std::unique_ptr<AST::Program> parse();
};

// 3. AST 节点 (ast.hpp)
namespace AST {
    struct Node { virtual ~Node() = default; };
    struct Program : Node { std::vector<std::unique_ptr<Stmt>> stmts; };
    struct FnDecl : Stmt { std::string name; std::vector<Param> params; ... };
    // ... 其他节点
}

// 4. 虚拟机 (vm.cpp)
class VM {
    std::vector<Value> stack;
    std::vector<Frame> frames;
    
public:
    Value run(const Bytecode& code);
};

// 5. 字节码编译器 (compiler.cpp)
class Compiler : public AST::Visitor {
    Bytecode bytecode;
    
public:
    Bytecode compile(const AST::Program& ast);
};
```

### 内存管理

```cpp
// 垃圾回收器 (gc.cpp)
class GC {
    std::vector<Obj*> objects;
    std::vector<Obj*> worklist;
    
public:
    void collect();  // 标记-清除
    template<typename T, typename... Args>
    T* allocate(Args&&... args);
};

// 值类型 (value.hpp)
struct Value {
    union {
        int64_t i64;
        double f64;
        Obj* obj;
    };
    TypeTag type;
    
    // 零开销抽象
    bool is_int() const { return type == TypeTag::Int; }
    int64_t as_int() const { return i64; }
};
```

### 标准库 (Tier 2 - 逐步迁移)

```cpp
// 内建函数 (builtins.cpp)
namespace Builtins {
    Value print(VM& vm, const std::vector<Value>& args);
    Value len(VM& vm, const std::vector<Value>& args);
    Value push(VM& vm, const std::vector<Value>& args);
    // ...
}

// 标准库模块 (std/)
namespace Std {
    namespace io { void register_module(VM& vm); }
    namespace json { void register_module(VM& vm); }
    namespace http { void register_module(VM& vm); }
}
```

## 实施路线图

### 阶段 1: 核心 VM (2-3 周)
- [ ] 词法分析器移植
- [ ] 语法分析器移植
- [ ] AST 定义
- [ ] 基础 VM (栈机)
- [ ] 字节码编译器
- [ ] 简单测试通过

### 阶段 2: 完整语言特性 (2-3 周)
- [ ] 函数与闭包
- [ ] 类与继承
- [ ] 模式匹配
- [ ] 异常处理
- [ ] 垃圾回收
- [ ] 通过全部基础测试

### 阶段 3: 优化与 JIT (3-4 周)
- [ ] LLVM JIT 集成
- [ ] WebAssembly 后端
- [ ] 内联缓存
- [ ] 类型特化
- [ ] 性能基准测试

### 阶段 4: 工具链 (2 周)
- [ ] 包管理器
- [ ] LSP 服务器
- [ ] 调试器
- [ ] 格式化工具
- [ ] 代码检查器

## 性能预期

| 指标 | Python 版本 | C++ 版本 | 提升 |
|------|------------|----------|------|
| Fibonacci(35) | 5.2s | ~50ms | **100x** |
| 内存占用 | 45MB | ~8MB | **5.6x** |
| 启动时间 | 200ms | ~10ms | **20x** |
| 递归深度 | 1000 | 无限制 | **∞** |
| GC 暂停 | 50ms | <5ms | **10x** |

## 代码示例对比

### 当前 Python VM
```python
class VM:
    def run(self, code):
        ip = 0
        while ip < len(code):
            op = code[ip]
            if op == Op.CONST:
                self.stack.append(code[ip + 1])
                ip += 2
            elif op == Op.ADD:
                b = self.stack.pop()
                a = self.stack.pop()
                self.stack.append(a + b)  # 慢！
                ip += 1
```

### 未来 C++ VM
```cpp
class VM {
public:
    Value run(const Bytecode& code) {
        const auto* ops = code.ops.data();
        auto* stack_top = stack.data();
        
        while (true) {
            switch (*ops++) {
                case Op::CONST:
                    *stack_top++ = code.constants[*ops++];
                    break;
                case Op::ADD: {
                    auto b = *--stack_top;
                    auto a = *--stack_top;
                    *stack_top++ = Value(a.as_int() + b.as_int());  // 内联，零开销
                    break;
                }
                // ...
            }
        }
    }
};
```

## 风险与缓解

| 风险 | 缓解措施 |
|------|---------|
| 开发时间长 | 分阶段发布，Python 作为 fallback |
| 调试困难 | 保留详细日志，提供调试符号 |
| 平台兼容性 | 使用 CMake，CI 覆盖多平台 |
| 性能不达预期 | 持续基准测试，A/B 对比 |

## 保持向后兼容

```cpp
// 提供 Python 绑定 (mo_lang.cpp)
#include <pybind11/pybind11.h>

PYBIND11_MODULE(mo_lang_cpp, m) {
    m.def("run", &mo::run, "Execute Mo code");
    m.def("compile", &mo::compile, "Compile Mo code");
}
```

## 推荐的 C++ 特性

- **C++20** - concepts, coroutines for async
- **智能指针** - RAII 管理内存
- **模板** - 零开销泛型
- **constexpr** - 编译期计算
- **SIMD** - 向量化运算 (std::experimental::simd)

## 结论

C++ 重写预计能带来 **50-100x** 的性能提升，消除 Python GIL 限制，支持真正的并发和深度递归。建议采用渐进式策略，先重写核心 VM，再逐步迁移工具链。

**预估工作量**: 10-12 周（全职开发）
**团队建议**: 1-2 名 C++ 工程师 + 原项目维护者
