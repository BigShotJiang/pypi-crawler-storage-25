# PyPI 发布指南

本指南介绍如何将 Mo 语言发布到 PyPI（Python Package Index）。

## 准备工作

### 1. 注册 PyPI 账户

1. 访问 https://pypi.org/account/register/
2. 创建账户并验证邮箱
3. 启用双重验证 (2FA)
4. 创建 API Token：
   - 进入 Account Settings → API tokens
   - 点击 "Add API token"
   - 选择 Scope: "Entire account" 或项目范围
   - 复制 Token（**只显示一次！**）

### 2. 注册 TestPyPI 账户（可选但推荐）

1. 访问 https://test.pypi.org/account/register/
2. 重复上面的步骤创建 API Token

### 3. 配置本地环境

创建 `~/.pypirc` 文件：

```ini
[distutils]
index-servers =
    pypi
    testpypi

[pypi]
username = __token__
password = pypi-your-token-here

[testpypi]
repository = https://test.pypi.org/legacy/
username = __token__
password = pypi-your-test-token-here
```

**安全提示**：确保 `~/.pypirc` 文件权限正确：
```bash
chmod 600 ~/.pypirc
```

## 发布步骤

### 方法一：使用脚本（推荐）

```bash
# 1. 进入项目目录
cd /path/to/mo

# 2. 运行发布脚本
./scripts/publish.sh

# 3. 根据提示选择：
#    1) TestPyPI - 测试发布
#    2) PyPI - 正式发布
#    3) 仅构建
```

### 方法二：手动发布

#### 1. 更新版本号

编辑 `pyproject.toml`：
```toml
[project]
version = "0.2.0"  # 更新版本号
```

#### 2. 清理和构建

```bash
# 清理旧构建
rm -rf build/ dist/ *.egg-info/

# 安装构建工具
pip install build twine

# 构建包
python -m build
```

#### 3. 检查包

```bash
twine check dist/*
```

#### 4. 上传到 TestPyPI（测试）

```bash
twine upload --repository testpypi dist/*
```

测试安装：
```bash
pip install --index-url https://test.pypi.org/simple/ mo-language
```

#### 5. 上传到 PyPI（正式）

```bash
twine upload dist/*
```

## 自动发布（GitHub Actions）

项目已配置 GitHub Actions，支持自动发布：

### 自动发布到 TestPyPI

每次推送到 `main` 分支时，会自动发布到 TestPyPI。

### 自动发布到 PyPI

1. 在 GitHub 创建 Release：
   - 进入仓库 → Releases → "Create a new release"
   - 选择或创建标签（如 `v0.2.0`）
   - 填写 Release notes
   - 点击 "Publish release"

2. GitHub Actions 会自动：
   - 运行测试
   - 构建包
   - 发布到 PyPI

### 配置 GitHub Secrets

需要在仓库设置中添加以下 Secrets：

1. 进入仓库 Settings → Secrets and variables → Actions
2. 添加 Secrets：
   - `PYPI_API_TOKEN` - PyPI API Token
   - `TESTPYPI_API_TOKEN` - TestPyPI API Token（可选）

或者使用 Trusted Publishing（推荐）：

1. 在 PyPI 项目设置中配置 Trusted Publisher
2. 添加 GitHub Actions 工作流
3. 无需存储 API Token 在 GitHub

## 版本号规范

使用语义化版本（SemVer）：`MAJOR.MINOR.PATCH`

- **MAJOR**：不兼容的 API 变更
- **MINOR**：向后兼容的功能添加
- **PATCH**：向后兼容的问题修复

示例：
- `0.1.0` - 初始版本
- `0.2.0` - 新功能（LLVM 后端）
- `0.2.1` - Bug 修复
- `1.0.0` - 正式版

## 发布检查清单

发布前请确认：

- [ ] 版本号已更新
- [ ] CHANGELOG.md 已更新
- [ ] 所有测试通过
- [ ] README.md 是最新的
- [ ] 文档已更新
- [ ] 构建成功（`python -m build`）
- [ ] 包检查通过（`twine check`）

## 验证发布

### 检查 PyPI 页面

访问 https://pypi.org/project/mo-language/

### 测试安装

```bash
# 创建虚拟环境
python3 -m venv test_env
source test_env/bin/activate

# 安装
pip install mo-language

# 测试
mo --version
mo --help
echo 'print("Hello")' | mo

# 清理
deactivate
rm -rf test_env
```

### 检查不同平台

```bash
# 测试在不同 Python 版本
pyenv local 3.9.18 3.10.13 3.11.6 3.12.0
for v in 3.9 3.10 3.11 3.12; do
    echo "Testing Python $v"
    python$v -m pip install mo-language
    python$v -m mo --version
done
```

## 常见问题

### 1. 版本冲突

```
HTTPError: 400 Bad Request from https://upload.pypi.org/legacy/
File already exists
```

**解决**：PyPI 不允许重复上传相同版本。需要更新版本号。

### 2. 构建失败

```
ERROR: Could not build wheels for xxx
```

**解决**：
```bash
pip install --upgrade pip setuptools wheel build
rm -rf build/ dist/
python -m build
```

### 3. 认证失败

```
HTTPError: 403 Forbidden from https://upload.pypi.org/legacy/
Invalid or non-existent authentication information
```

**解决**：检查 `~/.pypirc` 中的 Token 是否正确，或者使用环境变量：
```bash
export TWINE_USERNAME=__token__
export TWINE_PASSWORD=pypi-your-token
twine upload dist/*
```

### 4. 包太大

PyPI 限制单个文件 100MB。

**解决**：
- 移除不必要的文件（更新 `MANIFEST.in`）
- 使用 `.pyc` 而不是源代码
- 分开发布核心包和扩展包

## 发布后

### 更新文档

- 更新官网文档
- 更新 GitHub README
- 发布 Release Notes

### 通知社区

- 在 Discord/论坛/邮件列表发布消息
- 发布到社交媒体
- 更新 Awesome Lists

### 监控

- 查看 PyPI 下载统计：https://pypistats.org/packages/mo-language
- 监控 Issues 和 Discussions
- 收集用户反馈

## 相关链接

- PyPI 项目页：https://pypi.org/project/mo-language/
- TestPyPI 项目页：https://test.pypi.org/project/mo-language/
- PyPI 文档：https://packaging.python.org/
- Twine 文档：https://twine.readthedocs.io/

---

**当前版本**: 0.2.0

**最后更新**: 2024-01-XX
