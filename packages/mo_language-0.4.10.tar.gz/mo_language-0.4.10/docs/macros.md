# Mo Language Macro System

Mo supports compile-time macros for metaprogramming.

## Syntax

Macros are defined using the `macro` keyword and invoked with the `!` prefix. Macro names must start with an uppercase letter.

```mo
# Define a macro
macro Double(x) {
    return x * 2
}

# Use the macro
let result = !Double(5)  # Expands to: 5 * 2
print(result)  # 10
```

## Built-in Macros

### When

Execute code conditionally (like if statement):

```mo
!When(condition, expr1, expr2, ...)

# Example
!When(x > 0, print("positive"))
```

### Unless

Execute code unless condition is true:

```mo
!Unless(condition, expr1, expr2, ...)

# Example
!Unless(x > 0, print("non-positive"))
```

### Assert

Throw error if condition is false:

```mo
!Assert(condition)
!Assert(condition, "custom message")

# Example
!Assert(x > 0)
!Assert(x > 0, "x must be positive")
```

### Quote

Return expression unevaluated:

```mo
!Quote(expr)

# Example
let code = !Quote(x + 5)
```

### Dbg

Debug print expression and its value:

```mo
!Dbg(expr)

# Example
!Dbg(x * 2)  # Prints: DEBUG: <value>
```

## User-Defined Macros

Define macros with the `macro` keyword:

```mo
macro Square(x) {
    return x * x
}

macro Add(a, b) {
    return a + b
}

# Usage
let a = !Square(3)  # 9
let b = !Add(2, 3)  # 5
```

### Macros with Multiple Statements

```mo
macro Greet(name) {
    print("Hello, " + name)
    print("Welcome!")
}

!Greet("World")
```

### Macros in Expressions

```mo
macro Square(x) {
    return x * x
}

let result = !Square(3) + !Square(4)  # 9 + 16 = 25
print(result)
```

## How Macros Work

1. **Parse**: Code is parsed into AST
2. **Expand**: Macros are expanded at compile time
3. **Execute**: Expanded code is executed

Example expansion:

```mo
# Before expansion
macro Double(x) { return x * 2 }
let y = !Double(5)

# After expansion
let y = 5 * 2
```

## Limitations

- Macro names must start with uppercase letter
- Macros are expanded in definition order
- No recursive macros (yet)
- Macros cannot modify the parser

## Comparison with Functions

| Feature | Functions | Macros |
|---------|-----------|--------|
| Call syntax | `foo(x)` | `!Foo(x)` |
| Evaluation | Runtime | Compile time |
| Arguments | Evaluated | Not evaluated |
| Return | Value | AST node |
| Recursion | Yes | No |

## Examples

### Swap Macro

```mo
macro Swap(a, b) {
    let temp = a
    a = b
    b = temp
}

let x = 10
let y = 20
!Swap(x, y)
print(x)  # 20
print(y)  # 10
```

### Debug Macro

```mo
macro DbgVar(x) {
    print(str(!Quote(x)) + " = " + str(x))
}

let value = 42
!DbgVar(value)  # Prints: value = 42
```

### Conditional Compilation

```mo
macro DebugPrint(msg) {
    if DEBUG {
        print(msg)
    }
}

let DEBUG = true
!DebugPrint("This is a debug message")
```
