# Mo 语言完整使用手册

**版本**: 0.2.0  
**日期**: 2024年4月  
**作者**: Mo 语言开发团队

---

## 目录

1. [简介](#简介)
2. [安装与配置](#安装与配置)
3. [基础语法](#基础语法)
4. [数据类型](#数据类型)
5. [控制流](#控制流)
6. [函数](#函数)
7. [类与面向对象](#类与面向对象)
8. [高级特性](#高级特性)
9. [标准库](#标准库)
10. [工具链](#工具链)
11. [多后端编译](#多后端编译)
12. [最佳实践](#最佳实践)

---

## 简介

Mo 是一个现代、表达力强、快速的脚本语言，具有以下特点：

- **多后端支持**: Bytecode VM、LLVM JIT、WebAssembly
- **现代特性**: 模式匹配、宏系统、解构赋值
- **并发支持**: async/await、锁、信号量
- **完整工具链**: 格式化、检查、LSP、调试器

### 设计理念

Mo 的设计遵循"够用就好，绝不多余"的原则，提供：
- 简洁清晰的语法
- 丰富的内置功能
- 优秀的开发体验
- 多平台支持

---

## 安装与配置

### 系统要求

- Python 3.9 或更高版本
- 操作系统: Linux、macOS、Windows

### 安装方式

#### 方式一：通过 pip 安装（推荐）

```bash
pip install mo-language
```

#### 方式二：从源码安装

```bash
git clone https://github.com/qinghua/mo.git
cd mo
pip install -e .
```

#### 方式三：带 LLVM 支持安装

```bash
pip install mo-language[llvm]
```

### 验证安装

```bash
mo --version
mo --help
```

---

## 基础语法

### 注释

```mo
# 单行注释

# 多行注释
# 可以连续使用
```

### 变量定义

```mo
# 使用 let 定义变量
let x = 10
let name = "Mo"
let pi = 3.14159

# 类型注解（可选）
let count: int = 100
let message: str = "Hello"
```

### 常量

```mo
# 约定使用大写字母表示常量
let MAX_SIZE = 1000
let PI = 3.14159
```

---

## 数据类型

### 基本类型

#### 数字 (Number)

```mo
let integer = 42
let negative = -10
let floating = 3.14159
let scientific = 1.5e10

# 运算
let sum = 10 + 20
let product = 5 * 8
let division = 100 / 4
let modulo = 17 % 5
```

#### 字符串 (String)

```mo
let simple = "Hello, World!"
let multiline = "第一行\n第二行"

# 字符串拼接
let greeting = "Hello, " + name

# 模板字符串
let name = "Alice"
let message = `Hello, ${name}!`
```

#### 布尔值 (Bool)

```mo
let isTrue = true
let isFalse = false

# 逻辑运算
let result = true && false  # false
let result2 = true || false  # true
let result3 = !true  # false
```

#### 空值 (Null)

```mo
let nothing = null
```

### 复合类型

#### 列表 (List)

```mo
let numbers = [1, 2, 3, 4, 5]
let mixed = [1, "two", true, null]

# 访问元素
let first = numbers[0]  # 1
let last = numbers[len(numbers) - 1]

# 修改元素
numbers[0] = 100

# 常用操作
push(numbers, 6)        # 添加元素
pop(numbers)            # 移除并返回最后一个元素
let size = len(numbers) # 获取长度
```

#### 字典 (Dict)

```mo
let person = {
    "name": "Alice",
    "age": 30,
    "email": "alice@example.com"
}

# 访问
let name = person["name"]
let age = person["age"]

# 修改
person["age"] = 31

# 添加新键
person["phone"] = "123-456-7890"

# 检查键是否存在
let hasName = has(person, "name")  # true

# 删除键
delete(person, "phone")

# 获取所有键
let keys = keys(person)
```

---

## 控制流

### 条件语句

#### if-else

```mo
let x = 10

if x > 0 {
    print("Positive")
} else if x < 0 {
    print("Negative")
} else {
    print("Zero")
}
```

#### 三元运算符

```mo
let result = x > 0 ? "positive" : "non-positive"
```

### 循环

#### while 循环

```mo
let i = 0
while i < 10 {
    print(i)
    i = i + 1
}
```

#### for 循环

```mo
# 遍历列表
let fruits = ["apple", "banana", "cherry"]
for fruit in fruits {
    print(fruit)
}

# 遍历范围
for i in range(0, 10) {
    print(i)
}

# 遍历字典
let scores = {"Alice": 95, "Bob": 87}
for name in keys(scores) {
    print(name + ": " + scores[name])
}
```

#### 循环控制

```mo
for i in range(0, 100) {
    if i == 50 {
        break  # 退出循环
    }
    if i % 2 == 0 {
        continue  # 跳过本次迭代
    }
    print(i)
}
```

---

## 函数

### 基本函数定义

```mo
fn greet(name) {
    return "Hello, " + name
}

let message = greet("World")
print(message)  # Hello, World
```

### 参数

#### 默认参数

```mo
fn greet(name, greeting = "Hello") {
    return greeting + ", " + name
}

greet("Alice")           # Hello, Alice
greet("Bob", "Hi")       # Hi, Bob
```

#### 可变参数 (*args)

```mo
fn sum(*numbers) {
    let total = 0
    for n in numbers {
        total = total + n
    }
    return total
}

sum(1, 2, 3)      # 6
sum(1, 2, 3, 4, 5)  # 15
```

#### 关键字参数 (**kwargs)

```mo
fn createUser(**data) {
    return data
}

let user = createUser(name="Alice", age=30, email="alice@example.com")
```

### 匿名函数

```mo
let multiply = fn(a, b) {
    return a * b
}

let result = multiply(3, 4)  # 12
```

### 闭包

```mo
fn makeCounter() {
    let count = 0
    fn increment() {
        count = count + 1
        return count
    }
    return increment
}

let counter = makeCounter()
print(counter())  # 1
print(counter())  # 2
print(counter())  # 3
```

---

## 类与面向对象

### 类定义

```mo
class Dog {
    fn init(name, breed) {
        self.name = name
        self.breed = breed
    }
    
    fn bark() {
        print(self.name + " says: Woof!")
    }
    
    fn getInfo() {
        return self.name + " is a " + self.breed
    }
}

let myDog = Dog("Buddy", "Golden Retriever")
myDog.bark()           # Buddy says: Woof!
print(myDog.getInfo()) # Buddy is a Golden Retriever
```

### 继承

```mo
class Animal {
    fn init(name) {
        self.name = name
    }
    
    fn speak() {
        print(self.name + " makes a sound")
    }
}

class Cat extends Animal {
    fn speak() {
        print(self.name + " says: Meow!")
    }
}

class Dog extends Animal {
    fn speak() {
        print(self.name + " says: Woof!")
    }
}

let cat = Cat("Whiskers")
let dog = Dog("Buddy")

cat.speak()  # Whiskers says: Meow!
dog.speak()  # Buddy says: Woof!
```

### 方法链

```mo
class StringBuilder {
    fn init() {
        self.parts = []
    }
    
    fn append(str) {
        push(self.parts, str)
        return self
    }
    
    fn toString() {
        return join(self.parts, "")
    }
}

let sb = StringBuilder()
let result = sb.append("Hello").append(" ").append("World").toString()
print(result)  # Hello World
```

---

## 高级特性

### 模式匹配

模式匹配是 Mo 语言最强大的特性之一：

#### 基础匹配

```mo
fn describe(value) {
    match value {
        case 0 => "zero"
        case 1 => "one"
        case _ => "other"
    }
}
```

#### 列表模式

```mo
fn getFirst(pair) {
    match pair {
        case [x, y] => x
        case _ => null
    }
}

getFirst([10, 20])  # 10
```

#### 字典模式

```mo
fn getName(person) {
    match person {
        case {"name": n} => n
        case _ => "Unknown"
    }
}

getName({"name": "Alice", "age": 30})  # Alice
```

#### 守卫子句

```mo
fn classifyNumber(n) {
    match n {
        case x if x > 0 => "positive"
        case x if x < 0 => "negative"
        case _ => "zero"
    }
}
```

### 解构赋值

#### 列表解构

```mo
let [a, b, c] = [1, 2, 3]
print(a)  # 1
print(b)  # 2
print(c)  # 3

# 嵌套解构
let [x, [y, z]] = [1, [2, 3]]
```

#### 字典解构

```mo
let user = {"name": "Alice", "age": 30, "email": "alice@example.com"}
let {"name": name, "age": age} = user

print(name)  # Alice
print(age)   # 30
```

### 宏系统

宏是编译时展开的代码生成工具：

#### 内置宏

```mo
# When - 条件执行
!When(debug, print("Debug mode"))

# Unless - 反向条件
!Unless(production, print("Development mode"))

# Assert - 断言
!Assert(x > 0, "x must be positive")

# Quote - 引用代码
let code = !Quote(x + 5)
```

#### 自定义宏

```mo
macro Square(x) {
    return x * x
}

let result = !Square(5)  # 25

macro Max(a, b) {
    if a > b {
        return a
    }
    return b
}

let max = !Max(10, 20)  # 20
```

### 迭代器协议

```mo
# 创建迭代器
let it = iter([1, 2, 3])

# 使用迭代器
while has_next(it) {
    let item = next(it)
    print(item)
}

# for 循环内部使用迭代器
for item in [1, 2, 3] {
    print(item)
}
```

### 并发编程

#### async/await

```mo
async fn fetchData(url) {
    # 模拟异步操作
    sleep_async(100)
    return {"data": "content"}
}

async fn main() {
    let future = fetchData("http://api.example.com")
    let result = await future
    print(result)
}

# 运行异步函数
run_async(main)
```

#### 锁和信号量

```mo
# 互斥锁
let mtx = lock()

fn safeIncrement(counter) {
    lock_acquire(mtx)
    counter.value = counter.value + 1
    lock_release(mtx)
}

# 信号量
let sem = semaphore(3)  # 最多3个并发

fn limitedTask() {
    sem_acquire(sem)
    # 执行任务
    sem_release(sem)
}
```

### 错误处理

```mo
fn divide(a, b) {
    if b == 0 {
        throw "Division by zero"
    }
    return a / b
}

try {
    let result = divide(10, 0)
    print(result)
} catch err {
    print("Error: " + err)
}
```

---

## 标准库

### 数学模块 (std/math)

```mo
import "std/math"

print(math_sqrt(16))      # 4
print(math_pow(2, 10))    # 1024
print(math_abs(-5))       # 5
print(math_floor(3.7))    # 3
print(math_ceil(3.2))     # 4
print(math_round(3.5))    # 4
print(math_sin(3.14159))  # ~0
print(math_pi())          # 3.14159...
```

### JSON 模块 (std/json)

```mo
import "std/json"

let data = {"name": "Alice", "age": 30}
let jsonStr = json_stringify(data)
print(jsonStr)  # {"name": "Alice", "age": 30}

let parsed = json_parse(jsonStr)
print(parsed.name)  # Alice
```

### HTTP 模块 (std/http)

```mo
import "std/http"

# 启动服务器
fn handleRequest(req) {
    return json_resp({"message": "Hello"})
}

serve(8080, handleRequest)

# HTTP 客户端
let response = fetch("https://api.example.com/data")
print(response.body)
```

### 文件模块 (std/file)

```mo
import "std/file"

# 读取文件
let content = read("data.txt")
print(content)

# 写入文件
write("output.txt", "Hello, World!")

# 检查文件是否存在
if exists("data.txt") {
    print("File exists")
}

# 列出目录
let files = list_dir("./")
for file in files {
    print(file)
}
```

### 时间模块 (std/time)

```mo
import "std/time"

let now = time_now()
print(now)

# 睡眠
sleep(1)  # 1秒

# 格式化时间
let formatted = time_format(now, "%Y-%m-%d %H:%M:%S")
```

### 随机模块 (std/random)

```mo
import "std/random"

let n = random_int(1, 100)  # 1-100之间的随机整数
let f = random_float()       # 0-1之间的随机小数
```

### 集合模块 (std/collections)

```mo
import "std/collections"

# 栈
let s = stack()
stack_push(s, 1)
stack_push(s, 2)
let top = stack_peek(s)  # 2
let item = stack_pop(s)   # 2

# 队列
let q = queue()
queue_enqueue(q, "a")
queue_enqueue(q, "b")
let first = queue_dequeue(q)  # "a"

# 集合
let st = set()
set_add(st, 1)
set_add(st, 2)
print(set_has(st, 1))  # true
```

---

## 工具链

### 代码格式化 (mo fmt)

```bash
# 格式化文件
mo fmt file.mo

# 检查格式
mo fmt --check file.mo

# 输出到标准输出
mo fmt --write file.mo
```

### 静态分析 (mo lint)

```bash
# 检查代码
mo lint file.mo

# 检查项目
mo lint src/
```

### LSP 服务器

```bash
# 标准输入输出模式
mo lsp

# TCP 模式
mo lsp --tcp --port 8765
```

支持的 LSP 功能：
- 代码补全
- 悬停提示
- 跳转到定义
- 查找引用
- 代码格式化

### 调试器

```bash
# 启动调试
mo --debug file.mo

# 在开头暂停
mo --break file.mo
```

---

## 多后端编译

Mo 语言支持三种编译后端：

### 1. Bytecode VM（默认）

```bash
# 编译并运行字节码
mo file.mo

# 查看字节码
mo --dis file.mo

# 带追踪运行
mo --trace file.mo
```

### 2. LLVM JIT

```bash
# 生成 LLVM IR
mo --llvm file.mo > output.ll

# 使用 LLVM JIT 运行
mo --llvm-run file.mo
```

要求安装 LLVM 支持：
```bash
pip install mo-language[llvm]
```

### 3. WebAssembly

```bash
# 生成 WAT (WebAssembly Text)
mo --wat file.mo

# 生成 WASM 二进制
mo --wasm file.mo output.wasm
```

运行 WASM：
```bash
# 使用 wasmtime
wasmtime output.wasm

# 使用 Node.js
node -e "
const fs = require('fs');
const wasm = fs.readFileSync('output.wasm');
WebAssembly.instantiate(wasm, {
  env: { print: (x) => console.log(x) }
}).then(m => m.instance.exports.main());
"
```

---

## 最佳实践

### 代码风格

1. **命名约定**
   - 变量和函数：小写，下划线分隔
   - 类：首字母大写，驼峰命名
   - 常量：全大写

```mo
let user_name = "Alice"      # 变量
fn calculate_total() {}      # 函数
class UserAccount {}         # 类
let MAX_RETRY_COUNT = 3      # 常量
```

2. **缩进和格式**
   - 使用 4 个空格缩进
   - 大括号不换行
   - 运算符两边加空格

3. **注释**
   - 解释"为什么"而不是"是什么"
   - 复杂逻辑添加说明
   - 公共 API 添加文档注释

### 性能优化

1. **选择合适的后端**
   - 开发阶段：Bytecode VM（启动快）
   - 生产环境：LLVM JIT（执行快）
   - Web 环境：WebAssembly

2. **避免全局变量**
```mo
# 不好
let counter = 0
fn increment() {
    counter = counter + 1
}

# 好
fn makeCounter() {
    let count = 0
    fn increment() {
        count = count + 1
        return count
    }
    return increment
}
```

3. **使用列表推导**
```mo
# 高效创建列表
let doubled = []
for x in numbers {
    push(doubled, x * 2)
}
```

### 错误处理

```mo
# 使用异常处理错误
fn safeDivide(a, b) {
    try {
        if b == 0 {
            throw "Division by zero"
        }
        return a / b
    } catch err {
        print("Error: " + err)
        return null
    }
}
```

### 测试

```mo
# test_math.mo
fn test_add() {
    assert(add(2, 3) == 5)
    assert(add(-1, 1) == 0)
    print("test_add passed")
}

fn test_multiply() {
    assert(multiply(3, 4) == 12)
    assert(multiply(0, 100) == 0)
    print("test_multiply passed")
}

# 运行测试
test_add()
test_multiply()
```

---

## 常见问题

### Q: Mo 与 Python 有什么区别？

**A:** Mo 是一个独立设计的语言，虽然当前实现基于 Python，但具有：
- 原生模式匹配支持
- 内置宏系统
- 多后端编译（LLVM、WebAssembly）
- 更简洁的语法

### Q: 可以编译为独立可执行文件吗？

**A:** 目前需要 Python 运行时。完整的自托管编译器正在开发中。

### Q: 支持哪些平台？

**A:** 支持所有 Python 3.9+ 支持的平台：
- Linux
- macOS
- Windows

### Q: 性能如何？

**A:** 
- Bytecode VM：与 Python 相当
- LLVM JIT：接近原生速度
- WebAssembly：浏览器原生性能

---

## 学习资源

- **GitHub**: https://github.com/qinghua/mo
- **PyPI**: https://pypi.org/project/mo-language/
- **文档**: https://mo-lang.dev/docs
- **社区**: https://discord.gg/molang

---

## 版本历史

### v0.2.0 (2024-04)
- ✨ 新增 LLVM JIT 后端
- ✨ 新增 WebAssembly 后端
- ✨ 新增模式匹配 (match/case)
- ✨ 新增宏系统
- ✨ 新增解构赋值
- ✨ 新增迭代器协议
- ✨ 新增并发原语
- ✨ 新增代码格式化工具
- ✨ 新增代码检查工具
- ✨ 增强 LSP 服务器

### v0.1.0 (2024-01)
- 🎉 初始版本发布
- Bytecode VM
- 基础语法
- 标准库

---

## 许可证

MIT License - 详见 LICENSE 文件

---

**感谢使用 Mo 语言！**

如有问题，请通过 GitHub Issues 反馈。
