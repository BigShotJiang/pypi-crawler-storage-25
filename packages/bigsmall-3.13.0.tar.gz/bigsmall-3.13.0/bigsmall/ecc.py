"""Reed-Solomon ECC for .bs containers (optional).

RS(255, 223) per 223-byte chunk gives ~14% size overhead and tolerates up
to 16 corrupted bytes per chunk. The sidecar file `<path>.ecc` holds the
parity bytes; the original .bs is unchanged so non-ECC-aware readers stay
compatible.

This module gracefully degrades when the `reedsolo` package is missing —
calls raise an explicit ImportError telling the user to install it.

Format of `<path>.ecc`:
    magic      8 bytes   b"BSECC1__"
    version    2 bytes   uint16 LE     (=1)
    chunk_size 4 bytes   uint32 LE     (=223)
    parity_sz  4 bytes   uint32 LE     (=32, i.e. RS(255,223))
    n_chunks   8 bytes   uint64 LE
    md5        16 bytes  md5 of the original .bs
    parity[]   n_chunks * parity_sz bytes
"""
from __future__ import annotations

import hashlib
import struct
from pathlib import Path

ECC_MAGIC = b"BSECC1__"
ECC_VERSION = 1
DEFAULT_CHUNK_SIZE = 223
DEFAULT_PARITY = 32  # RS(255, 223)


def _require_reedsolo():
    try:
        import reedsolo
        return reedsolo
    except ImportError as e:
        raise ImportError(
            "Reed-Solomon ECC requires the `reedsolo` package. Install with "
            "`pip install reedsolo` (it is an optional dependency)."
        ) from e


def write_ecc(bs_path: str | Path, ecc_path: str | Path | None = None,
              chunk_size: int = DEFAULT_CHUNK_SIZE,
              parity_size: int = DEFAULT_PARITY) -> str:
    """Compute and write a Reed-Solomon parity sidecar for `bs_path`.

    Returns the path to the sidecar file.
    """
    rs_mod = _require_reedsolo()
    bs_path = Path(bs_path)
    if ecc_path is None:
        ecc_path = bs_path.with_suffix(bs_path.suffix + ".ecc")
    ecc_path = Path(ecc_path)

    rs = rs_mod.RSCodec(parity_size)

    md5_sum = hashlib.md5()
    parity_buf = bytearray()
    n_chunks = 0
    with open(bs_path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            md5_sum.update(chunk)
            # Pad last chunk to chunk_size for RS encode; length recorded
            # implicitly via file size, so we don't need to store padding.
            if len(chunk) < chunk_size:
                chunk = chunk + b"\x00" * (chunk_size - len(chunk))
            encoded = rs.encode(chunk)
            # encoded is (chunk_size + parity_size) bytes; we only save parity.
            parity_buf.extend(encoded[chunk_size:])
            n_chunks += 1

    with open(ecc_path, "wb") as f:
        f.write(ECC_MAGIC)
        f.write(struct.pack("<H", ECC_VERSION))
        f.write(struct.pack("<I", chunk_size))
        f.write(struct.pack("<I", parity_size))
        f.write(struct.pack("<Q", n_chunks))
        f.write(md5_sum.digest())
        f.write(bytes(parity_buf))

    return str(ecc_path)


def _read_ecc_header(ecc_path: Path) -> dict:
    with open(ecc_path, "rb") as f:
        magic = f.read(8)
        if magic != ECC_MAGIC:
            raise ValueError(f"Not a BigSmall ECC file (magic={magic!r})")
        version = struct.unpack("<H", f.read(2))[0]
        chunk_size = struct.unpack("<I", f.read(4))[0]
        parity_size = struct.unpack("<I", f.read(4))[0]
        n_chunks = struct.unpack("<Q", f.read(8))[0]
        md5 = f.read(16)
        data_offset = f.tell()
    return {
        "version": version,
        "chunk_size": chunk_size,
        "parity_size": parity_size,
        "n_chunks": n_chunks,
        "md5": md5.hex(),
        "data_offset": data_offset,
    }


def repair(bs_path: str | Path, ecc_path: str | Path | None = None,
           output_path: str | Path | None = None) -> dict:
    """Repair a (potentially corrupted) .bs file using its ECC sidecar.

    Returns a report:
        {
          "chunks_total": int,
          "chunks_repaired": int,
          "chunks_unrecoverable": int,
          "md5_before": str,
          "md5_after": str,
          "md5_expected": str,
          "ok": bool,
        }

    If `output_path` is None, the repaired bytes are written to
    `<bs_path>.repaired` (the original is never overwritten).
    """
    rs_mod = _require_reedsolo()
    bs_path = Path(bs_path)
    if ecc_path is None:
        ecc_path = bs_path.with_suffix(bs_path.suffix + ".ecc")
    ecc_path = Path(ecc_path)
    if output_path is None:
        output_path = bs_path.with_suffix(bs_path.suffix + ".repaired")
    output_path = Path(output_path)

    h = _read_ecc_header(ecc_path)
    rs = rs_mod.RSCodec(h["parity_size"])

    repaired = bytearray()
    md5_before = hashlib.md5()
    md5_after = hashlib.md5()
    chunks_repaired = 0
    chunks_unrecoverable = 0
    bs_size = bs_path.stat().st_size
    bytes_consumed = 0
    with open(bs_path, "rb") as bf, open(ecc_path, "rb") as ef:
        ef.seek(h["data_offset"])
        for i in range(h["n_chunks"]):
            raw_chunk = bf.read(h["chunk_size"])
            parity = ef.read(h["parity_size"])
            # The encoder pads the last chunk to chunk_size with zeros
            # before computing RS parity. Reproduce the same padding here
            # so the decoder sees the same codeword.
            real_len = len(raw_chunk)
            if real_len < h["chunk_size"]:
                padded = raw_chunk + b"\x00" * (h["chunk_size"] - real_len)
            else:
                padded = raw_chunk
            md5_before.update(raw_chunk)
            full_codeword = padded + parity
            try:
                result = rs.decode(full_codeword)
                decoded = result[0] if isinstance(result, tuple) else result
                decoded = bytes(decoded)
                # Trim to the real chunk length for the last (possibly short) chunk.
                # Compute expected length: every chunk except the last is full;
                # the last is bs_size - bytes_consumed.
                expected_len = min(h["chunk_size"], bs_size - bytes_consumed)
                trimmed = decoded[:expected_len]
                if trimmed != raw_chunk:
                    chunks_repaired += 1
                effective = trimmed
            except Exception:
                chunks_unrecoverable += 1
                effective = raw_chunk  # best effort
            md5_after.update(effective)
            repaired.extend(effective)
            bytes_consumed += len(effective)

    # Trim repaired buffer to original file length (we don't store it; use
    # the size of bs_path as the truth source). If bs_path was truncated
    # we still produce a best-effort repair of the available bytes.
    target_len = bs_path.stat().st_size
    if len(repaired) > target_len:
        repaired = repaired[:target_len]

    output_path.write_bytes(bytes(repaired))

    return {
        "chunks_total": h["n_chunks"],
        "chunks_repaired": chunks_repaired,
        "chunks_unrecoverable": chunks_unrecoverable,
        "md5_before": md5_before.hexdigest(),
        "md5_after": md5_after.hexdigest(),
        "md5_expected": h["md5"],
        "ok": (chunks_unrecoverable == 0 and md5_after.hexdigest() == h["md5"]),
        "output_path": str(output_path),
    }
