"""BF16-native F32 detector (V7 finding S3-A07 + INV-B02, V8 P3-15).

Some models are trained in BF16 and shipped as F32 by tooling that upcasts.
When this happens, the low 16 mantissa bits of every weight are exactly zero
(or carry only ~3 bits of entropy on average — Whisper is a prime example).

This module scans an F32 tensor or an entire safetensors model and reports
the fraction of weights whose low 16 bits are zero. Above ~10% the file
would compress dramatically better by being treated as a BF16-native tensor
upcast (V7 measured Whisper-base at 41-46% of raw F32, vs ~83% for normal F32).

Usage:
    from bigsmall.bf16_native_detector import scan_safetensors
    report = scan_safetensors("path/to/model.safetensors")
    for t in report['tensors']:
        print(t['name'], t['bf16_native'], t['low16_zero_frac'])
"""
from __future__ import annotations

import json
import struct
from pathlib import Path
from typing import Iterator

import numpy as np


# Threshold above which we declare a tensor "BF16-native upcast".
# V7 finding: Whisper has ~12.5 % of weights with low16==0 and ~3 bits of
# entropy in the remaining low16 — well above the 10 % gate.
LOW16_ZERO_GATE = 0.10


def low16_zero_fraction(raw: bytes) -> float:
    """Fraction of F32 weights whose low 16 mantissa bits are exactly zero.

    BF16-native upcast produces exactly-zero low16; any other F32 source
    (full-precision training, mixed-precision intermediate) produces
    near-uniform low16 distributions where this fraction is ~0.
    """
    if len(raw) == 0:
        return 0.0
    u32 = np.frombuffer(raw, dtype=np.uint32)
    return float(((u32 & 0xFFFF) == 0).mean())


def low16_entropy_bits(raw: bytes) -> float:
    """Shannon entropy of the low-16-bit half of F32 weights (bits/symbol).

    Pure F32 weights → near 16 bits/symbol (uniform).
    BF16-native upcast → much lower (Whisper measured at ~3 bits/symbol).
    """
    if len(raw) == 0:
        return 0.0
    u32 = np.frombuffer(raw, dtype=np.uint32)
    low = (u32 & 0xFFFF).astype(np.uint16)
    counts = np.bincount(low, minlength=65536).astype(np.float64)
    total = counts.sum()
    if total == 0:
        return 0.0
    p = counts[counts > 0] / total
    return float(-(p * np.log2(p)).sum())


def classify_tensor(raw: bytes, dtype: str) -> dict:
    """Decide whether an F32 tensor is BF16-native upcast.

    Returns a dict with the diagnostic numbers and a boolean flag.
    BF16 tensors return is_bf16_native=False with no extra signal.
    """
    if dtype != "F32":
        return {"is_bf16_native": False, "dtype": dtype}
    frac = low16_zero_fraction(raw)
    # entropy is expensive — only compute when frac says it's worth it
    H_low = low16_entropy_bits(raw) if frac >= 0.01 else None
    is_native = frac >= LOW16_ZERO_GATE
    return {
        "dtype": dtype,
        "low16_zero_frac": frac,
        "low16_entropy_bits": H_low,
        "is_bf16_native": is_native,
        "gate": LOW16_ZERO_GATE,
    }


def _iter_safetensors_tensors(path: Path) -> Iterator[tuple[str, dict, bytes]]:
    """Yield (name, meta, raw_bytes) for each tensor in a .safetensors file."""
    with open(path, "rb") as f:
        hlen = struct.unpack("<Q", f.read(8))[0]
        header = json.loads(f.read(hlen).decode("utf-8"))
        data_start = 8 + hlen
        for name, meta in header.items():
            if name == "__metadata__":
                continue
            s, e = meta["data_offsets"]
            f.seek(data_start + s)
            yield name, meta, f.read(e - s)


def scan_safetensors(path: str | Path, only_f32: bool = True) -> dict:
    """Scan one .safetensors file and report which tensors are BF16-native.

    Returns a dict:
      {
        "path": str,
        "tensors_total": int,
        "tensors_f32": int,
        "tensors_bf16_native": int,
        "f32_native_frac": float,        # of all F32 tensors, how many qualify
        "model_is_bf16_native": bool,    # >= 50% of F32 mass qualifies
        "estimated_compress_ratio_pct": float,  # est. F32 compressed ratio
        "tensors": [ {name, dtype, shape, low16_zero_frac,
                      low16_entropy_bits, is_bf16_native, bytes} ]
      }
    """
    p = Path(path)
    out_tensors = []
    n_total = n_f32 = n_native = 0
    bytes_f32 = bytes_native = 0
    weighted_low16_H = 0.0

    for name, meta, raw in _iter_safetensors_tensors(p):
        n_total += 1
        dt = meta["dtype"]
        if dt != "F32":
            if not only_f32:
                out_tensors.append({"name": name, "dtype": dt,
                                    "shape": meta["shape"], "bytes": len(raw)})
            continue
        n_f32 += 1
        bytes_f32 += len(raw)
        cls = classify_tensor(raw, dt)
        is_native = cls["is_bf16_native"]
        if is_native:
            n_native += 1
            bytes_native += len(raw)
            if cls["low16_entropy_bits"] is not None:
                weighted_low16_H += cls["low16_entropy_bits"] * len(raw)
        out_tensors.append({
            "name": name,
            "dtype": dt,
            "shape": meta["shape"],
            "bytes": len(raw),
            "low16_zero_frac": cls["low16_zero_frac"],
            "low16_entropy_bits": cls["low16_entropy_bits"],
            "is_bf16_native": is_native,
        })

    # Heuristic compression-ratio estimate for BF16-native F32:
    #   high16 -> BF16 lossless codec ~ 66 % of high16 size
    #   low16 -> ~12.5 % zero + low-entropy remainder ~ 0.25 of low16 size
    # Combined: 0.5*(0.66*high16) + 0.5*(0.25*low16) ≈ 0.45 of raw F32.
    # We surface the estimate only when >50 % of F32 mass is BF16-native.
    native_frac_bytes = (bytes_native / bytes_f32) if bytes_f32 else 0.0
    model_native = native_frac_bytes >= 0.50
    if model_native and bytes_native > 0:
        avg_H_low = weighted_low16_H / bytes_native
        # Convert avg low16 H (bits) -> ratio component (relative to 16 bits raw)
        ratio_low = max(0.05, avg_H_low / 16.0)
        # BF16 production codec hits ~65-66 % on transformer weights;
        # conservatively use 0.66 for the high16 half.
        est = 0.5 * 0.66 + 0.5 * ratio_low
        est_pct = 100.0 * est
    else:
        est_pct = None

    return {
        "path": str(p),
        "tensors_total": n_total,
        "tensors_f32": n_f32,
        "tensors_bf16_native": n_native,
        "f32_native_frac": (n_native / n_f32) if n_f32 else 0.0,
        "native_frac_bytes": native_frac_bytes,
        "model_is_bf16_native": model_native,
        "estimated_compress_ratio_pct": est_pct,
        "tensors": out_tensors,
    }


def scan_model_dir(model_dir: str | Path) -> dict:
    """Scan every .safetensors shard in a directory."""
    p = Path(model_dir)
    shards = sorted(p.glob("*.safetensors"))
    per_shard = []
    n_total = n_f32 = n_native = 0
    bytes_f32 = bytes_native = 0
    for s in shards:
        r = scan_safetensors(s)
        per_shard.append({k: v for k, v in r.items() if k != "tensors"})
        n_total += r["tensors_total"]
        n_f32 += r["tensors_f32"]
        n_native += r["tensors_bf16_native"]
        for t in r["tensors"]:
            if t["dtype"] == "F32":
                bytes_f32 += t["bytes"]
                if t["is_bf16_native"]:
                    bytes_native += t["bytes"]
    native_frac = (bytes_native / bytes_f32) if bytes_f32 else 0.0
    return {
        "model_dir": str(p),
        "shards": len(shards),
        "tensors_total": n_total,
        "tensors_f32": n_f32,
        "tensors_bf16_native": n_native,
        "native_frac_bytes": native_frac,
        "model_is_bf16_native": native_frac >= 0.50,
        "per_shard": per_shard,
    }


def detect_bf16_native(tensor_or_path) -> dict:
    """Public entry point per IMPLEMENT_313 spec.

    Accepts either:
      - a path to a safetensors file or model directory, or
      - a numpy array / torch tensor / raw F32 bytes.

    Returns:
      {
        "is_bf16_native": bool,
        "low16_zero_fraction": float,
        "estimated_ratio": float | None,   # 0..1 of raw F32 (None when unknown)
        "recommendation": str,
      }
    """
    # Path?
    if isinstance(tensor_or_path, (str, Path)):
        p = Path(tensor_or_path)
        if p.is_dir():
            rep = scan_model_dir(p)
        else:
            rep = scan_safetensors(p)
        ratio = rep.get("estimated_compress_ratio_pct")
        ratio = (ratio / 100.0) if ratio is not None else None
        is_native = bool(rep.get("model_is_bf16_native"))
        return {
            "is_bf16_native": is_native,
            "low16_zero_fraction": float(rep.get("native_frac_bytes", 0.0)),
            "estimated_ratio": ratio,
            "recommendation": (
                "BF16-native upcast detected — BigSmall will compress this "
                "model as if it were native BF16 (much smaller files)."
                if is_native else
                "Standard F32 / BF16 model — BigSmall applies its default codec."
            ),
        }
    # Tensor or bytes
    raw: bytes
    if isinstance(tensor_or_path, (bytes, bytearray, memoryview)):
        raw = bytes(tensor_or_path)
        dtype = "F32"
    else:
        # numpy or torch
        try:
            import numpy as _np
            if isinstance(tensor_or_path, _np.ndarray):
                raw = tensor_or_path.astype(_np.float32, copy=False).tobytes()
                dtype = "F32"
            else:
                # Assume torch tensor
                import torch
                t = tensor_or_path
                if isinstance(t, torch.Tensor):
                    if t.dtype == torch.float32:
                        raw = t.contiguous().cpu().numpy().tobytes()
                        dtype = "F32"
                    else:
                        # not F32 — not applicable
                        return {
                            "is_bf16_native": False,
                            "low16_zero_fraction": 0.0,
                            "estimated_ratio": None,
                            "recommendation":
                                f"Tensor dtype {t.dtype} — BF16-native detector "
                                f"only applies to F32 tensors.",
                        }
                else:
                    raise TypeError(f"unsupported input type: {type(tensor_or_path)!r}")
        except ImportError:
            raise

    cls = classify_tensor(raw, dtype)
    frac = float(cls.get("low16_zero_frac", 0.0))
    is_native = bool(cls.get("is_bf16_native", False))
    return {
        "is_bf16_native": is_native,
        "low16_zero_fraction": frac,
        "estimated_ratio": 0.45 if is_native else None,
        "recommendation": (
            "BF16-native upcast detected — compress as native BF16."
            if is_native else
            "Standard F32 distribution — default codec is optimal."
        ),
    }


def scan_model(model_dir) -> dict:
    """Alias for scan_model_dir kept for IMPLEMENT_313 spec parity."""
    return scan_model_dir(model_dir)


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: python -m bigsmall.bf16_native_detector <safetensors-or-dir>")
        sys.exit(2)
    target = Path(sys.argv[1])
    if target.is_dir():
        report = scan_model_dir(target)
        print(json.dumps({k: v for k, v in report.items()
                          if k != "per_shard"}, indent=2, default=float))
    else:
        report = scan_safetensors(target)
        print(json.dumps({k: v for k, v in report.items()
                          if k != "tensors"}, indent=2, default=float))
