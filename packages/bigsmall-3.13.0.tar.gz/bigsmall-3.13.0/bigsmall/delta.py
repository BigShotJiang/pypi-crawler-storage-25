"""Delta compression utilities.

A "delta" is a compressed representation of a fine-tuned model relative to a
base model. We XOR raw weight bytes between base and fine-tune; the XOR has
many leading zero bytes when weights are similar, so it compresses far better
than the fine-tuned weights alone.

The encoder/decoder live in `encoder.compress_delta` and
`decoder.decompress_delta`. This module exposes:

- `xor_bytes` / `hash_safetensors` — low-level helpers used by the encoder.
- `compute_fingerprint` — exponent histogram for base detection.
- `detect_base` — pick the closest base from a list of candidates.
- `detect_base_from_hub` — pick the closest known base by fingerprint.
- `known_base_fingerprints` — the bundled JSON of well-known base models.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterable, Optional

import numpy as np


def xor_bytes(a: bytes, b: bytes) -> bytes:
    """XOR two equal-length byte streams."""
    if len(a) != len(b):
        raise ValueError(f"length mismatch {len(a)} vs {len(b)}")
    aa = np.frombuffer(a, dtype=np.uint8)
    bb = np.frombuffer(b, dtype=np.uint8)
    return (aa ^ bb).tobytes()


def hash_safetensors(path: str | Path) -> str:
    """Return md5 over the entire safetensors file (used as base hash)."""
    p = Path(path)
    h = hashlib.md5()
    with open(p, "rb") as f:
        while True:
            chunk = f.read(4 * 1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


def _iter_safetensors_dirs(model_dir: Path):
    """Yield shard paths under a model directory (or the file itself)."""
    if model_dir.is_file():
        yield model_dir
        return
    idx = model_dir / "model.safetensors.index.json"
    if idx.exists():
        meta = json.loads(idx.read_text(encoding="utf-8"))
        files = sorted(set(meta["weight_map"].values()))
        for f in files:
            yield model_dir / f
        return
    single = model_dir / "model.safetensors"
    if single.exists():
        yield single
        return
    for f in sorted(model_dir.glob("*.safetensors")):
        yield f


def compute_fingerprint(model_dir: str | Path, max_tensors: int = 64,
                        sample_bytes_per_tensor: int = 1 << 22) -> dict:
    """Return a stable fingerprint of a model's weight distribution.

    The fingerprint is a BF16-exponent histogram aggregated across up to
    `max_tensors` randomly chosen tensors, sampling at most
    `sample_bytes_per_tensor` bytes per tensor. The histogram is
    deterministic for a given model and survives BF16 / F32 promotion
    differences because we re-extract the exponent byte from both.

    Returned dict layout:
        {
          "format_version": 1,
          "kind": "exponent_histogram",
          "total_samples": int,
          "exp_counts": [int x 256],   # length-256 BF16 exponent histogram
          "tensor_names": [str ...],
          "name": optional human label,
        }

    The L1 distance between two fingerprints' `exp_counts` (normalised) is
    a meaningful proxy for delta compressibility: similar bases have
    similar exponent distributions, dissimilar ones differ sharply.
    """
    from safetensors import safe_open
    p = Path(model_dir)
    if not p.exists():
        raise FileNotFoundError(p)

    rng = np.random.default_rng(0xB16_5_A11)
    exp_counts = np.zeros(256, dtype=np.int64)
    tensor_names: list[str] = []
    total = 0

    chosen_tensors: list[tuple[Path, str]] = []
    for shard in _iter_safetensors_dirs(p):
        try:
            with safe_open(str(shard), framework="pt") as f:
                for k in f.keys():
                    chosen_tensors.append((shard, k))
        except Exception:
            continue

    if not chosen_tensors:
        return {
            "format_version": 1,
            "kind": "exponent_histogram",
            "total_samples": 0,
            "exp_counts": exp_counts.tolist(),
            "tensor_names": [],
        }

    if len(chosen_tensors) > max_tensors:
        idx = rng.choice(len(chosen_tensors), size=max_tensors, replace=False)
        chosen_tensors = [chosen_tensors[int(i)] for i in idx]

    for shard, name in chosen_tensors:
        try:
            with safe_open(str(shard), framework="pt") as f:
                t = f.get_tensor(name)
            dtype = str(t.dtype).replace("torch.", "")
            import torch
            raw = t.contiguous().view(torch.uint8).cpu().numpy().tobytes()
        except Exception:
            continue

        if dtype in ("bfloat16", "BF16"):
            u16 = np.frombuffer(raw, dtype=np.uint16)
            if u16.size > sample_bytes_per_tensor // 2:
                step = max(1, u16.size // (sample_bytes_per_tensor // 2))
                u16 = u16[::step]
            exp = ((u16 >> 7) & 0xFF).astype(np.int64)
        elif dtype in ("float32", "F32"):
            u32 = np.frombuffer(raw, dtype=np.uint32)
            if u32.size > sample_bytes_per_tensor // 4:
                step = max(1, u32.size // (sample_bytes_per_tensor // 4))
                u32 = u32[::step]
            exp = ((u32 >> 23) & 0xFF).astype(np.int64)
        elif dtype in ("float16", "F16"):
            u16 = np.frombuffer(raw, dtype=np.uint16)
            if u16.size > sample_bytes_per_tensor // 2:
                step = max(1, u16.size // (sample_bytes_per_tensor // 2))
                u16 = u16[::step]
            exp = ((u16 >> 10) & 0x1F).astype(np.int64)
        else:
            continue

        bins = np.bincount(exp, minlength=256)
        exp_counts[:bins.size] += bins[:256]
        total += int(exp.size)
        tensor_names.append(name)

    return {
        "format_version": 1,
        "kind": "exponent_histogram",
        "total_samples": total,
        "exp_counts": exp_counts.tolist(),
        "tensor_names": tensor_names,
    }


def _fingerprint_distance(a: dict, b: dict) -> float:
    """L1 distance between two normalised exponent histograms (0..2)."""
    if a.get("kind") != "exponent_histogram" or b.get("kind") != "exponent_histogram":
        return float("inf")
    ac = np.asarray(a["exp_counts"], dtype=np.float64)
    bc = np.asarray(b["exp_counts"], dtype=np.float64)
    sa = ac.sum() or 1.0
    sb = bc.sum() or 1.0
    return float(np.abs(ac / sa - bc / sb).sum())


def detect_base(finetune_dir: str | Path,
                candidate_dirs: Iterable[str | Path]) -> Optional[dict]:
    """Pick the best base from a list of candidate directories.

    Returns a dict `{path, distance, fingerprint}` for the candidate with
    the smallest fingerprint distance to the fine-tune. Returns None if
    `candidate_dirs` is empty.
    """
    cands = list(candidate_dirs)
    if not cands:
        return None
    ft_fp = compute_fingerprint(finetune_dir)
    scored: list[tuple[float, Path, dict]] = []
    for c in cands:
        c = Path(c)
        try:
            cf = compute_fingerprint(c)
        except Exception:
            continue
        d = _fingerprint_distance(ft_fp, cf)
        scored.append((d, c, cf))
    if not scored:
        return None
    scored.sort(key=lambda x: x[0])
    d, p, fp = scored[0]
    return {"path": str(p), "distance": d, "fingerprint": fp}


_BUNDLED_FP_PATH = Path(__file__).with_name("base_fingerprints.json")


def known_base_fingerprints() -> dict:
    """Return the bundled JSON of known-base fingerprints (repo_id -> fingerprint).

    The bundled file is shipped with the package. Empty dict if missing.
    """
    if not _BUNDLED_FP_PATH.exists():
        return {}
    try:
        return json.loads(_BUNDLED_FP_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def detect_base_from_hub(finetune_dir: str | Path) -> Optional[dict]:
    """Score a fine-tune against every known-base fingerprint and return the best.

    Returns a dict `{repo_id, distance, hint_url}` for the best match or
    None if no fingerprints are bundled.
    """
    known = known_base_fingerprints()
    if not known:
        return None
    ft_fp = compute_fingerprint(finetune_dir)
    scored: list[tuple[float, str, dict]] = []
    for repo_id, meta in known.items():
        fp = meta.get("fingerprint") if isinstance(meta, dict) else None
        if not fp:
            continue
        d = _fingerprint_distance(ft_fp, fp)
        scored.append((d, repo_id, meta))
    if not scored:
        return None
    scored.sort(key=lambda x: x[0])
    d, repo_id, meta = scored[0]
    return {
        "repo_id": repo_id,
        "distance": d,
        "hint_url": meta.get("hint_url"),
        "display_name": meta.get("display_name", repo_id),
    }
