"""Decode-speed benchmark: compare BigSmall .bs vs safetensors vs torch.load."""
from __future__ import annotations

import time
from pathlib import Path


def benchmark_decode(bs_path: str | Path,
                     safetensors_path: str | Path | None = None,
                     torch_path: str | Path | None = None) -> dict:
    """Measure decompress + load throughput on three formats.

    Returns a dict of {format: {"seconds": float, "bytes": int, "MB_per_s": float}}.
    Skips entries where the file is missing.
    """
    out: dict = {}
    bs_path = Path(bs_path)
    if bs_path.exists():
        from bigsmall import decompress
        t0 = time.perf_counter()
        _ = decompress(bs_path, progress=False)
        dt = time.perf_counter() - t0
        sz = bs_path.stat().st_size
        out["bigsmall"] = {
            "seconds": dt,
            "bytes": sz,
            "MB_per_s": sz / dt / (1024 * 1024) if dt > 0 else 0.0,
        }

    if safetensors_path is not None and Path(safetensors_path).exists():
        try:
            from safetensors import safe_open
            t0 = time.perf_counter()
            with safe_open(str(safetensors_path), framework="pt") as f:
                for k in f.keys():
                    _ = f.get_tensor(k)
            dt = time.perf_counter() - t0
            sz = Path(safetensors_path).stat().st_size
            out["safetensors"] = {
                "seconds": dt,
                "bytes": sz,
                "MB_per_s": sz / dt / (1024 * 1024) if dt > 0 else 0.0,
            }
        except Exception as e:
            out["safetensors"] = {"error": str(e)}

    if torch_path is not None and Path(torch_path).exists():
        try:
            import torch
            t0 = time.perf_counter()
            _ = torch.load(str(torch_path), map_location="cpu", weights_only=True)
            dt = time.perf_counter() - t0
            sz = Path(torch_path).stat().st_size
            out["torch"] = {
                "seconds": dt,
                "bytes": sz,
                "MB_per_s": sz / dt / (1024 * 1024) if dt > 0 else 0.0,
            }
        except Exception as e:
            out["torch"] = {"error": str(e)}

    return out


def print_report(rep: dict) -> None:
    """Pretty-print a benchmark report."""
    print("Format       | Seconds | Size (MB) | Throughput (MB/s)")
    print("-" * 60)
    for fmt, r in rep.items():
        if "error" in r:
            print(f"{fmt:<12} | (error: {r['error']})")
            continue
        size_mb = r["bytes"] / (1024 * 1024)
        print(f"{fmt:<12} | {r['seconds']:7.2f} | {size_mb:9.2f} | {r['MB_per_s']:9.2f}")


if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("usage: python -m bigsmall.benchmarks.decode_benchmark <model.bs> "
              "[model.safetensors] [model.pt]")
        sys.exit(2)
    rep = benchmark_decode(
        sys.argv[1],
        sys.argv[2] if len(sys.argv) > 2 else None,
        sys.argv[3] if len(sys.argv) > 3 else None,
    )
    print_report(rep)
