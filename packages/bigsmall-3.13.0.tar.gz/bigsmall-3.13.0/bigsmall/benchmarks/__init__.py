"""BigSmall benchmark utilities (decode speed, throughput, peak RAM)."""
from .decode_benchmark import benchmark_decode

__all__ = ["benchmark_decode"]
