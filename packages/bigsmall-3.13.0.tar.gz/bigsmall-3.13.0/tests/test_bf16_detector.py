"""BF16-native F32 detector tests."""
import struct
import tempfile
from pathlib import Path

import numpy as np
import pytest


def _bf16_native_f32_bytes(n: int, seed: int = 0) -> bytes:
    """Synthesise F32 bytes whose low 16 mantissa bits are exactly zero
    (i.e. a BF16 value upcast to F32). Used to test detection."""
    rng = np.random.default_rng(seed)
    # Pick random BF16 values, upcast to F32 by zero-padding low 16 bits.
    bf16_words = rng.integers(0x1000, 0x4F00, size=n, dtype=np.uint16)
    u32 = bf16_words.astype(np.uint32) << 16
    return u32.tobytes()


def _random_f32_bytes(n: int, seed: int = 1) -> bytes:
    rng = np.random.default_rng(seed)
    return rng.standard_normal(n).astype(np.float32).tobytes()


def test_bf16_native_detection_synthetic():
    from bigsmall.bf16_native_detector import classify_tensor
    raw = _bf16_native_f32_bytes(8192, seed=0)
    cls = classify_tensor(raw, "F32")
    assert cls["is_bf16_native"] is True
    assert cls["low16_zero_frac"] >= 0.99


def test_non_native_detection_synthetic():
    from bigsmall.bf16_native_detector import classify_tensor
    raw = _random_f32_bytes(8192, seed=1)
    cls = classify_tensor(raw, "F32")
    assert cls["is_bf16_native"] is False
    assert cls["low16_zero_frac"] < 0.01


def test_detect_bf16_native_with_numpy_array():
    from bigsmall.bf16_native_detector import detect_bf16_native
    arr_bytes = _bf16_native_f32_bytes(4096, seed=0)
    arr = np.frombuffer(arr_bytes, dtype=np.float32).copy()
    rep = detect_bf16_native(arr)
    assert rep["is_bf16_native"] is True
    assert rep["low16_zero_fraction"] >= 0.99


def test_detect_bf16_native_with_path():
    """End-to-end on a synthetic safetensors file."""
    try:
        import torch
        from safetensors.torch import save_file
    except ImportError:
        pytest.skip("torch not installed")
    from bigsmall.bf16_native_detector import detect_bf16_native

    # Build a F32 tensor whose values match a BF16 upcast
    raw = _bf16_native_f32_bytes(32_000, seed=0)
    arr = np.frombuffer(raw, dtype=np.float32).copy().reshape(160, 200)
    t = torch.from_numpy(arr)
    assert t.dtype == torch.float32

    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "m.safetensors"
        save_file({"w": t}, str(p))
        rep = detect_bf16_native(p)
        assert rep["is_bf16_native"] is True
        assert rep["estimated_ratio"] is not None


def test_scan_model_directory():
    """scan_model on a directory of safetensors files."""
    try:
        import torch
        from safetensors.torch import save_file
    except ImportError:
        pytest.skip("torch not installed")
    from bigsmall.bf16_native_detector import scan_model

    raw = _bf16_native_f32_bytes(8192, seed=0)
    arr = np.frombuffer(raw, dtype=np.float32).copy().reshape(64, 128)
    t = torch.from_numpy(arr)

    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        save_file({"layer.weight": t}, str(d / "model.safetensors"))
        rep = scan_model(d)
        assert rep["tensors_f32"] == 1
        assert rep["tensors_bf16_native"] == 1


def test_scan_cli_runs():
    """`bigsmall scan` exits 0 on a real safetensors file."""
    try:
        import torch
        from safetensors.torch import save_file
    except ImportError:
        pytest.skip("torch not installed")
    import subprocess, sys
    raw = _random_f32_bytes(4096, seed=2)
    arr = np.frombuffer(raw, dtype=np.float32).copy().reshape(64, 64)
    t = torch.from_numpy(arr)

    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / "m.safetensors"
        save_file({"w": t}, str(p))
        r = subprocess.run(
            [sys.executable, "-m", "bigsmall.cli", "scan", str(p)],
            capture_output=True, text=True
        )
        assert r.returncode == 0, r.stderr + r.stdout
        assert "scan:" in r.stdout
