"""Delta compression round-trip + auto-detect + CLI tests."""
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path

import pytest


def _md5_hex(b: bytes) -> str:
    return hashlib.md5(b).hexdigest()


def _make_synthetic_pair(td: Path):
    """Build a (base, fine-tune) safetensors pair on disk. Returns (base, ft)."""
    import torch
    from safetensors.torch import save_file

    torch.manual_seed(0)
    base = {
        "embed.weight": torch.randn(2000, 256, dtype=torch.bfloat16),
        "layer.0.weight": torch.randn(256, 512, dtype=torch.bfloat16),
        "layer.1.weight": torch.randn(512, 256, dtype=torch.bfloat16),
    }
    ft = {}
    for k, v in base.items():
        perturb = (torch.rand_like(v.float()) < 0.01).to(torch.bfloat16)
        ft[k] = v + perturb * 0.01

    base_st = td / "base.safetensors"
    ft_st = td / "ft.safetensors"
    save_file(base, str(base_st))
    save_file(ft, str(ft_st))
    return base_st, ft_st


def test_delta_roundtrip_synthetic():
    try:
        import torch
        from safetensors import safe_open
    except ImportError:
        pytest.skip("torch/safetensors not installed")
    import bigsmall

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        base_st, ft_st = _make_synthetic_pair(td_p)

        ft_bs = td_p / "ft.bs"
        bigsmall.compress(ft_st, ft_bs)
        delta_bs = td_p / "delta.bs"
        bigsmall.compress_delta(ft_st, base_st, delta_bs)
        assert delta_bs.stat().st_size < ft_bs.stat().st_size

        out = bigsmall.decompress_delta(delta_bs, base_st)
        with safe_open(str(ft_st), framework="pt") as f:
            for name in f.keys():
                t = f.get_tensor(name)
                src_md5 = _md5_hex(t.contiguous().view(torch.uint8).cpu().numpy().tobytes())
                dec_md5 = _md5_hex(out[name].tobytes())
                assert src_md5 == dec_md5, f"md5 mismatch on {name}"


def test_delta_header_has_fingerprint():
    """The delta header must embed the base fingerprint for safety checks."""
    try:
        import torch
    except ImportError:
        pytest.skip("torch not installed")
    from bigsmall import compress_delta
    from bigsmall.container import read_header

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        base_st, ft_st = _make_synthetic_pair(td_p)
        delta_bs = td_p / "delta.bs"
        compress_delta(ft_st, base_st, delta_bs)

        header, _ = read_header(delta_bs)
        assert header.get("model_type") == "delta"
        fp = header.get("base_fingerprint")
        assert fp is not None, "delta header must include base_fingerprint"
        assert fp.get("kind") == "exponent_histogram"
        # 256 bins
        assert len(fp["exp_counts"]) == 256


def test_detect_base_picks_correct():
    """detect_base should pick the actual base, not a random candidate."""
    try:
        import torch
        from safetensors.torch import save_file
    except ImportError:
        pytest.skip("torch not installed")
    from bigsmall.delta import detect_base

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        # Two distinct bases plus a fine-tune of the first.
        torch.manual_seed(0)
        base_a = {"w": torch.randn(4096, 4096, dtype=torch.bfloat16)}
        torch.manual_seed(1)
        base_b = {"w": torch.randn(4096, 4096, dtype=torch.bfloat16) * 10.0}
        ft = {"w": base_a["w"] + (torch.rand_like(base_a["w"].float()) < 0.005).to(torch.bfloat16) * 0.01}

        dir_a = td_p / "base_a"; dir_a.mkdir()
        dir_b = td_p / "base_b"; dir_b.mkdir()
        dir_ft = td_p / "ft"; dir_ft.mkdir()
        save_file(base_a, str(dir_a / "model.safetensors"))
        save_file(base_b, str(dir_b / "model.safetensors"))
        save_file(ft, str(dir_ft / "model.safetensors"))

        picked = detect_base(dir_ft, [dir_b, dir_a])
        assert picked is not None
        # base_a should be the closer match
        assert Path(picked["path"]).name == "base_a"


def test_compute_fingerprint_stable():
    """Same model → same fingerprint exponent histogram."""
    try:
        import torch
        from safetensors.torch import save_file
    except ImportError:
        pytest.skip("torch not installed")
    from bigsmall.delta import compute_fingerprint

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        torch.manual_seed(7)
        w = {"a": torch.randn(2048, 1024, dtype=torch.bfloat16)}
        d = td_p / "m"; d.mkdir()
        save_file(w, str(d / "model.safetensors"))

        fp1 = compute_fingerprint(d)
        fp2 = compute_fingerprint(d)
        assert fp1["exp_counts"] == fp2["exp_counts"]


def test_known_base_fingerprints_loads():
    """Bundled JSON loads and has expected schema."""
    from bigsmall.delta import known_base_fingerprints
    kb = known_base_fingerprints()
    assert isinstance(kb, dict)
    # Schema key present
    assert "_schema" in kb
    # At least one known repo
    repo_ids = [k for k in kb if not k.startswith("_")]
    assert len(repo_ids) >= 1


def test_cli_diff_patch_roundtrip():
    """CLI `bigsmall diff --patch` followed by `bigsmall apply` reconstructs file_b."""
    try:
        import torch
        from safetensors import safe_open
    except ImportError:
        pytest.skip("torch not installed")

    with tempfile.TemporaryDirectory() as td:
        td_p = Path(td)
        base_st, ft_st = _make_synthetic_pair(td_p)
        patch = td_p / "patch.bs"
        out = td_p / "reconstructed.safetensors"

        # diff --patch
        r1 = subprocess.run(
            [sys.executable, "-m", "bigsmall.cli", "diff",
             str(base_st), str(ft_st), "--patch", str(patch)],
            capture_output=True, text=True
        )
        assert r1.returncode == 0, r1.stderr + r1.stdout
        assert patch.exists()

        # apply
        r2 = subprocess.run(
            [sys.executable, "-m", "bigsmall.cli", "apply",
             str(base_st), str(patch), "-o", str(out), "--no-progress"],
            capture_output=True, text=True
        )
        assert r2.returncode == 0, r2.stderr + r2.stdout
        assert out.exists()

        # Compare reconstructed to ft.safetensors
        with safe_open(str(ft_st), framework="pt") as fa, \
             safe_open(str(out), framework="pt") as fb:
            for name in fa.keys():
                ta = fa.get_tensor(name)
                tb = fb.get_tensor(name)
                a_md5 = _md5_hex(ta.contiguous().view(torch.uint8).cpu().numpy().tobytes())
                b_md5 = _md5_hex(tb.contiguous().view(torch.uint8).cpu().numpy().tobytes())
                assert a_md5 == b_md5, f"mismatch on {name}"
