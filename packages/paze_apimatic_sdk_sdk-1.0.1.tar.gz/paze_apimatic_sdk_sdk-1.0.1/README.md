
# Getting Started with Paze Checkout API

## Introduction

Paze Checkout API for Merchants

## Install the Package

The package is compatible with Python versions `3.7+`.
Install the package from PyPi using the following pip command:

```bash
pip install paze-apimatic-sdk-sdk==1.0.1
```

You can also view the package at:
https://pypi.python.org/pypi/paze-apimatic-sdk-sdk/1.0.1

## Initialize the API Client

**_Note:_** Documentation for the client can be found [here.](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/client.md)

The following parameters are configurable for the API Client:

| Parameter | Type | Description |
|  --- | --- | --- |
| environment | [`Environment`](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/README.md#environments) | The API environment. <br> **Default: `Environment.PRODUCTION`** |
| http_client_instance | `Union[Session, HttpClientProvider]` | The Http Client passed from the sdk user for making requests |
| override_http_client_configuration | `bool` | The value which determines to override properties of the passed Http Client from the sdk user |
| http_call_back | `HttpCallBack` | The callback value that is invoked before and after an HTTP call is made to an endpoint |
| timeout | `float` | The value to use for connection timeout. <br> **Default: 60** |
| max_retries | `int` | The number of times to retry an endpoint call if it fails. <br> **Default: 0** |
| backoff_factor | `float` | A backoff factor to apply between attempts after the second try. <br> **Default: 2** |
| retry_statuses | `Array of int` | The http statuses on which retry is to be done. <br> **Default: [408, 413, 429, 500, 502, 503, 504, 521, 522, 524]** |
| retry_methods | `Array of string` | The http methods on which retry is to be done. <br> **Default: ["GET", "PUT"]** |
| proxy_settings | [`ProxySettings`](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/proxy-settings.md) | Optional proxy configuration to route HTTP requests through a proxy server. |
| client_credentials_auth_credentials | [`ClientCredentialsAuthCredentials`](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/auth/oauth-2-client-credentials-grant.md) | The credential object for OAuth 2 Client Credentials Grant |

The API client can be initialized as follows:

### Code-Based Client Initialization

```python
from pazecheckoutapi.configuration import Environment
from pazecheckoutapi.http.auth.o_auth_2 import ClientCredentialsAuthCredentials
from pazecheckoutapi.pazecheckoutapi_client import PazecheckoutapiClient

client = PazecheckoutapiClient(
    client_credentials_auth_credentials=ClientCredentialsAuthCredentials(
        o_auth_client_id='OAuthClientId',
        o_auth_client_secret='OAuthClientSecret'
    ),
    environment=Environment.PRODUCTION
)
```

### Environment-Based Client Initialization

```python
from pazecheckoutapi.pazecheckoutapi_client import PazecheckoutapiClient

# Specify the path to your .env file if it’s located outside the project’s root directory.
client = PazecheckoutapiClient.from_environment(dotenv_path='/path/to/.env')
```

See the [Environment-Based Client Initialization](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/environment-based-client-initialization.md) section for details.

## Environments

The SDK can be configured to use a different environment for making API calls. Available environments are:

### Fields

| Name | Description |
|  --- | --- |
| PRODUCTION | **Default** |

## Authorization

This API uses the following authentication schemes.

* [`OAuth2 (OAuth 2 Client Credentials Grant)`](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/auth/oauth-2-client-credentials-grant.md)

## List of APIs

* [Checkout Session](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/controllers/checkout-session.md)
* [Merchant Onboarding](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/controllers/merchant-onboarding.md)
* [Identity](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/controllers/identity.md)

## SDK Infrastructure

### Configuration

* [ProxySettings](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/proxy-settings.md)
* [Environment-Based Client Initialization](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/environment-based-client-initialization.md)

### HTTP

* [HttpResponse](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/http-response.md)
* [HttpRequest](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/http-request.md)

### Utilities

* [ApiHelper](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/api-helper.md)
* [HttpDateTime](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/http-date-time.md)
* [RFC3339DateTime](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/rfc3339-date-time.md)
* [UnixDateTime](https://www.github.com/sdks-io/paze-apimatic-sdk-python-sdk/tree/1.0.1/doc/unix-date-time.md)

