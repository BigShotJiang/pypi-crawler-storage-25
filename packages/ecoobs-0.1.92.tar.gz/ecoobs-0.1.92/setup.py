from setuptools import setup, find_packages

setup(
    name='ecoobs',
    version='0.1.92',
    description='A library for Species Occurence data retrieval from GBIF, iNaturalist, and SpeciesLink APIs.',
    long_description=open('USAGE.md').read(),
    long_description_content_type='text/markdown',
    author='Ane Simões',
    author_email='anes.2017@alunos.utfpr.edu.br',
    packages=find_packages(),
    install_requires=[
        "pytest",
        "pandas",
        "requests",
        "python-dotenv",
        "pygbif",
        "pyinaturalist",
        "diskcache"
    ],
    license='MIT',
    python_requires='>=3.7',
)