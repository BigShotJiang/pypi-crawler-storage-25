from __future__ import annotations

import os
from typing import Optional

from .api_client import ApiClient
from .configuration import Configuration
from .resources import (
    APIKeysResource,
    AuthResource,
    BillingResource,
    ChangelogResource,
    DataResource,
    HealthResource,
    NotificationsResource,
    PlansResource,
    RawApis,
    ReportsResource,
    TeamResource,
    UsageResource,
)


class RedAtlasClient:
    def __init__(
        self,
        *,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        access_token: Optional[str] = None,
        refresh_token: Optional[str] = None,
        admin_key: Optional[str] = None,
        timeout: Optional[float] = None,
    ) -> None:
        bearer_token = access_token or api_key
        api_key_config: dict[str, str] = {}
        if refresh_token:
            api_key_config["cookieAuth"] = f"apiRefreshToken={refresh_token}"
        if admin_key:
            api_key_config["adminKeyAuth"] = admin_key

        resolved_base_url = base_url or os.getenv("RED_ATLAS_BASE_URL") or "https://api.atlas.red/external-api"
        self.configuration = Configuration(host=resolved_base_url, access_token=bearer_token, api_key=api_key_config or None)
        self.api_client = ApiClient(self.configuration)

        if timeout is not None:
            self.api_client.rest_client.pool_manager.connection_pool_kw["timeout"] = timeout

        self._raw: RawApis | None = None
        self._health: HealthResource | None = None
        self._plans: PlansResource | None = None
        self._auth: AuthResource | None = None
        self._data: DataResource | None = None
        self._reports: ReportsResource | None = None
        self._usage: UsageResource | None = None
        self._keys: APIKeysResource | None = None
        self._team: TeamResource | None = None
        self._notifications: NotificationsResource | None = None
        self._billing: BillingResource | None = None
        self._changelog: ChangelogResource | None = None

    @property
    def raw(self) -> RawApis:
        if self._raw is None:
            self._raw = RawApis(self.api_client)
        return self._raw

    @property
    def health(self) -> HealthResource:
        if self._health is None:
            self._health = HealthResource(self.raw.health)
        return self._health

    @property
    def plans(self) -> PlansResource:
        if self._plans is None:
            self._plans = PlansResource(self.raw.plans)
        return self._plans

    @property
    def auth(self) -> AuthResource:
        if self._auth is None:
            self._auth = AuthResource(self.raw.auth)
        return self._auth

    @property
    def data(self) -> DataResource:
        if self._data is None:
            self._data = DataResource(self.raw.data)
        return self._data

    @property
    def reports(self) -> ReportsResource:
        if self._reports is None:
            self._reports = ReportsResource(self.raw.reports)
        return self._reports

    @property
    def usage(self) -> UsageResource:
        if self._usage is None:
            self._usage = UsageResource(self.raw.usage)
        return self._usage

    @property
    def keys(self) -> APIKeysResource:
        if self._keys is None:
            self._keys = APIKeysResource(self.raw.keys)
        return self._keys

    @property
    def team(self) -> TeamResource:
        if self._team is None:
            self._team = TeamResource(self.raw.team)
        return self._team

    @property
    def notifications(self) -> NotificationsResource:
        if self._notifications is None:
            self._notifications = NotificationsResource(self.raw.notifications)
        return self._notifications

    @property
    def billing(self) -> BillingResource:
        if self._billing is None:
            self._billing = BillingResource(self.raw.billing)
        return self._billing

    @property
    def changelog(self) -> ChangelogResource:
        if self._changelog is None:
            self._changelog = ChangelogResource(self.raw.changelog)
        return self._changelog

    def close(self) -> None:
        pool_manager = getattr(self.api_client.rest_client, "pool_manager", None)
        if pool_manager is not None and hasattr(pool_manager, "clear"):
            pool_manager.clear()

    def __enter__(self) -> "RedAtlasClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()
