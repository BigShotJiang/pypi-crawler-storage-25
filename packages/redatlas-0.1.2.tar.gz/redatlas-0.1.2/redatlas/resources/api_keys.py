from ..api.api_keys_api import APIKeysApi
from ..models.api_keys_response import ApiKeysResponse
from ..models.api_key_with_secret_response import ApiKeyWithSecretResponse
from ..models.create_api_key_request import CreateApiKeyRequest
from ..models.message_response import MessageResponse


class APIKeysResource:
    def __init__(self, api: APIKeysApi) -> None:
        self._api = api

    def list(self) -> ApiKeysResponse:
        return self._api.keys_list()

    def create(self, payload: CreateApiKeyRequest) -> ApiKeyWithSecretResponse:
        return self._api.keys_create(payload)

    def revoke(self, key_id: str) -> MessageResponse:
        return self._api.keys_revoke(key_id)

    def rotate(self, key_id: str) -> ApiKeyWithSecretResponse:
        return self._api.keys_rotate(key_id)
