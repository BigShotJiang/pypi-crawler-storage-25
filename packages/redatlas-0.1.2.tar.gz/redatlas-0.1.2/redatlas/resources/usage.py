from typing import Optional

from ..api.usage_api import UsageApi
from ..models.daily_usage_response import DailyUsageResponse
from ..models.usage_by_endpoint_response import UsageByEndpointResponse
from ..models.usage_by_market_response import UsageByMarketResponse
from ..models.usage_summary_response import UsageSummaryResponse


class UsageResource:
    def __init__(self, api: UsageApi) -> None:
        self._api = api

    def summary(self) -> UsageSummaryResponse:
        return self._api.usage_summary()

    def daily(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> DailyUsageResponse:
        return self._api.usage_daily(start_date=start_date, end_date=end_date)

    def by_endpoint(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> UsageByEndpointResponse:
        return self._api.usage_by_endpoint(start_date=start_date, end_date=end_date)

    def by_market(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> UsageByMarketResponse:
        return self._api.usage_by_market(start_date=start_date, end_date=end_date)
