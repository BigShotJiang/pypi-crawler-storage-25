from typing import Any, Optional

from ..api.billing_api import BillingApi
from ..models.billing_status_response import BillingStatusResponse
from ..models.cancel_subscription_response import CancelSubscriptionResponse
from ..models.change_plan_request import ChangePlanRequest
from ..models.generic_data_response import GenericDataResponse
from ..models.inline_object import InlineObject
from ..models.invoices_response import InvoicesResponse
from ..models.message_response import MessageResponse
from ..models.payment_method_response import PaymentMethodResponse
from ..models.subscribe_request import SubscribeRequest
from ..models.subscribe_response_envelope import SubscribeResponseEnvelope
from ..models.topup_request import TopupRequest
from ..models.topup_response import TopupResponse
from ..models.update_payment_method_request import UpdatePaymentMethodRequest


class BillingResource:
    def __init__(self, api: BillingApi) -> None:
        self._api = api

    def handle_webhook(self, stripe_signature: str, payload: dict[str, Any] | InlineObject) -> GenericDataResponse:
        return self._api.billing_handle_webhook(stripe_signature, payload)

    def status(self) -> BillingStatusResponse:
        return self._api.billing_status()

    def subscribe(self, payload: SubscribeRequest) -> SubscribeResponseEnvelope:
        return self._api.billing_subscribe(payload)

    def change_plan(self, payload: ChangePlanRequest) -> GenericDataResponse:
        return self._api.billing_change_plan(payload)

    def cancel_subscription(self) -> CancelSubscriptionResponse:
        return self._api.billing_cancel_subscription()

    def list_invoices(self, limit: Optional[int] = None) -> InvoicesResponse:
        return self._api.billing_list_invoices(limit=limit)

    def get_payment_method(self) -> PaymentMethodResponse:
        return self._api.billing_get_payment_method()

    def update_payment_method(self, payload: UpdatePaymentMethodRequest) -> MessageResponse:
        return self._api.billing_update_payment_method(payload)

    def purchase_topup(self, payload: TopupRequest) -> TopupResponse:
        return self._api.billing_purchase_topup(payload)
