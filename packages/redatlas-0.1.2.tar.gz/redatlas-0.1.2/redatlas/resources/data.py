from typing import Optional

from ..api.data_api import DataApi
from ..models.data_list_response import DataListResponse
from ..models.data_single_response import DataSingleResponse
from ..models.market_info_response import MarketInfoResponse


class DataResource:
    def __init__(self, api: DataApi) -> None:
        self._api = api

    def market(self, market: str) -> MarketInfoResponse:
        return self._api.data_market(market)

    def list(
        self,
        market: str,
        entity_type: str,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        sort: Optional[str] = None,
        fields: Optional[str] = None,
        indicators: Optional[str] = None,
    ) -> DataListResponse:
        return self._api.data_list(market, entity_type, page=page, limit=limit, sort=sort, fields=fields, indicators=indicators)

    def get(
        self,
        market: str,
        entity_type: str,
        record_id: str,
        fields: Optional[str] = None,
        indicators: Optional[str] = None,
    ) -> DataSingleResponse:
        return self._api.data_get(market, entity_type, record_id, fields=fields, indicators=indicators)
