from ..api.notifications_api import NotificationsApi
from ..models.message_response import MessageResponse
from ..models.notification_preferences_response import NotificationPreferencesResponse
from ..models.notifications_response import NotificationsResponse
from ..models.unread_notification_count_response import UnreadNotificationCountResponse
from ..models.update_notification_preferences_request import UpdateNotificationPreferencesRequest


class NotificationsResource:
    def __init__(self, api: NotificationsApi) -> None:
        self._api = api

    def get_preferences(self) -> NotificationPreferencesResponse:
        return self._api.notifications_get_preferences()

    def update_preferences(self, payload: UpdateNotificationPreferencesRequest) -> NotificationPreferencesResponse:
        return self._api.notifications_update_preferences(payload)

    def list(self) -> NotificationsResponse:
        return self._api.notifications_list()

    def unread_count(self) -> UnreadNotificationCountResponse:
        return self._api.notifications_unread_count()

    def mark_all_read(self) -> MessageResponse:
        return self._api.notifications_mark_all_read()

    def mark_read(self, notification_id: str) -> MessageResponse:
        return self._api.notifications_mark_read(notification_id)
