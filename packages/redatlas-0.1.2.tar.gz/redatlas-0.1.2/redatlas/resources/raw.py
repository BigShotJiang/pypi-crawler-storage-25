from ..api.api_keys_api import APIKeysApi
from ..api.auth_api import AuthApi
from ..api.billing_api import BillingApi
from ..api.changelog_api import ChangelogApi
from ..api.data_api import DataApi
from ..api.health_api import HealthApi
from ..api.notifications_api import NotificationsApi
from ..api.plans_api import PlansApi
from ..api.reports_api import ReportsApi
from ..api.team_api import TeamApi
from ..api.usage_api import UsageApi
from ..api_client import ApiClient


class RawApis:
    def __init__(self, api_client: ApiClient) -> None:
        self.health = HealthApi(api_client)
        self.plans = PlansApi(api_client)
        self.auth = AuthApi(api_client)
        self.data = DataApi(api_client)
        self.reports = ReportsApi(api_client)
        self.usage = UsageApi(api_client)
        self.keys = APIKeysApi(api_client)
        self.team = TeamApi(api_client)
        self.notifications = NotificationsApi(api_client)
        self.billing = BillingApi(api_client)
        self.changelog = ChangelogApi(api_client)
