from typing import Optional

from ..api.reports_api import ReportsApi
from ..models.avm_report_request import AvmReportRequest
from ..models.comparables_report_request import ComparablesReportRequest
from ..models.public_report_response import PublicReportResponse
from ..models.report_list_response import ReportListResponse
from ..models.report_response import ReportResponse
from ..models.unified_report_request import UnifiedReportRequest
from ..models.update_white_label_request import UpdateWhiteLabelRequest
from ..models.white_label_response import WhiteLabelResponse


class ReportsResource:
    def __init__(self, api: ReportsApi) -> None:
        self._api = api

    def list(self, page: Optional[int] = None, limit: Optional[int] = None) -> ReportListResponse:
        return self._api.reports_list(page=page, limit=limit)

    def create(self, payload: UnifiedReportRequest) -> ReportResponse:
        return self._api.reports_create(payload)

    def create_avm(self, payload: AvmReportRequest, format: Optional[str] = None) -> ReportResponse:
        return self._api.reports_create_avm(payload, format=format)

    def create_comparables(self, payload: ComparablesReportRequest) -> ReportResponse:
        return self._api.reports_create_comparables(payload)

    def get(self, report_id: str) -> ReportResponse:
        return self._api.reports_get(report_id)

    def get_public(self, report_id: str) -> PublicReportResponse:
        return self._api.reports_get_public(report_id)

    def get_white_label(self) -> WhiteLabelResponse:
        return self._api.reports_get_white_label()

    def update_white_label(self, payload: UpdateWhiteLabelRequest) -> WhiteLabelResponse:
        return self._api.reports_update_white_label(payload)
