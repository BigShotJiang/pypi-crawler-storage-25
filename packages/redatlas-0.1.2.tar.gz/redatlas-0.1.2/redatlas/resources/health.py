from ..api.health_api import HealthApi
from ..models.health_response import HealthResponse


class HealthResource:
    def __init__(self, api: HealthApi) -> None:
        self._api = api

    def get(self) -> HealthResponse:
        return self._api.health_get()
