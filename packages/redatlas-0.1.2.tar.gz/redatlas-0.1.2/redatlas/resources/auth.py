from ..api.auth_api import AuthApi
from ..models.accept_invite_request import AcceptInviteRequest
from ..models.auth_session_response import AuthSessionResponse
from ..models.change_password_request import ChangePasswordRequest
from ..models.client_profile_response import ClientProfileResponse
from ..models.forgot_password_request import ForgotPasswordRequest
from ..models.invite_info_response import InviteInfoResponse
from ..models.login_request import LoginRequest
from ..models.message_response import MessageResponse
from ..models.refresh_response import RefreshResponse
from ..models.register_request import RegisterRequest
from ..models.reset_password_request import ResetPasswordRequest
from ..models.update_client_request import UpdateClientRequest


class AuthResource:
    def __init__(self, api: AuthApi) -> None:
        self._api = api

    def register(self, payload: RegisterRequest) -> AuthSessionResponse:
        return self._api.auth_register(payload)

    def login(self, payload: LoginRequest) -> AuthSessionResponse:
        return self._api.auth_login(payload)

    def refresh(self) -> RefreshResponse:
        return self._api.auth_refresh()

    def logout(self) -> MessageResponse:
        return self._api.auth_logout()

    def me(self) -> ClientProfileResponse:
        return self._api.auth_me()

    def update_me(self, payload: UpdateClientRequest) -> ClientProfileResponse:
        return self._api.auth_update_me(payload)

    def delete_me(self) -> MessageResponse:
        return self._api.auth_delete_me()

    def change_password(self, payload: ChangePasswordRequest) -> MessageResponse:
        return self._api.auth_change_password(payload)

    def forgot_password(self, payload: ForgotPasswordRequest) -> MessageResponse:
        return self._api.auth_forgot_password(payload)

    def reset_password(self, payload: ResetPasswordRequest) -> MessageResponse:
        return self._api.auth_reset_password(payload)

    def invite_info(self, token: str) -> InviteInfoResponse:
        return self._api.auth_invite_info(token)

    def accept_invite(self, payload: AcceptInviteRequest) -> AuthSessionResponse:
        return self._api.auth_accept_invite(payload)
