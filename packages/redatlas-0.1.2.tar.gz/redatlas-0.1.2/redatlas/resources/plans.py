from ..api.plans_api import PlansApi
from ..models.plans_response import PlansResponse


class PlansResource:
    def __init__(self, api: PlansApi) -> None:
        self._api = api

    def list(self) -> PlansResponse:
        return self._api.plans_list()
