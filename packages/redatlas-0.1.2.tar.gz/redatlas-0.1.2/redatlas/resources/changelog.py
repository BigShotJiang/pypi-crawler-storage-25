from typing import Optional

from ..api.changelog_api import ChangelogApi
from ..models.changelog_entries_response import ChangelogEntriesResponse
from ..models.changelog_entry_response import ChangelogEntryResponse
from ..models.create_changelog_entry_request import CreateChangelogEntryRequest
from ..models.message_response import MessageResponse
from ..models.update_changelog_entry_request import UpdateChangelogEntryRequest


class ChangelogResource:
    def __init__(self, api: ChangelogApi) -> None:
        self._api = api

    def list(self, tag: Optional[str] = None) -> ChangelogEntriesResponse:
        return self._api.changelog_list(tag=tag)

    def create(self, payload: CreateChangelogEntryRequest) -> ChangelogEntryResponse:
        return self._api.changelog_create(payload)

    def update(self, changelog_id: str, payload: UpdateChangelogEntryRequest) -> ChangelogEntryResponse:
        return self._api.changelog_update(changelog_id, payload)

    def delete(self, changelog_id: str) -> MessageResponse:
        return self._api.changelog_delete(changelog_id)
