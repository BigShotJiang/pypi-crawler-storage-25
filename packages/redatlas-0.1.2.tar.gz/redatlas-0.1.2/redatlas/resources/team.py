from ..api.team_api import TeamApi
from ..models.invite_member_request import InviteMemberRequest
from ..models.message_response import MessageResponse
from ..models.team_invite_response import TeamInviteResponse
from ..models.team_members_response import TeamMembersResponse
from ..models.update_team_member_request import UpdateTeamMemberRequest
from ..models.update_team_member_response import UpdateTeamMemberResponse


class TeamResource:
    def __init__(self, api: TeamApi) -> None:
        self._api = api

    def list(self) -> TeamMembersResponse:
        return self._api.team_list()

    def invite(self, payload: InviteMemberRequest) -> TeamInviteResponse:
        return self._api.team_invite(payload)

    def update(self, member_id: str, payload: UpdateTeamMemberRequest) -> UpdateTeamMemberResponse:
        return self._api.team_update(member_id, payload)

    def remove(self, member_id: str) -> MessageResponse:
        return self._api.team_remove(member_id)
