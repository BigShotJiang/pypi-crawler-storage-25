# redatlas

Official Python SDK for the RED Atlas External API.

Use it to authenticate with your RED Atlas API key and call public data, plans, health, and reports endpoints with typed request and response models.

## Install

```bash
pip install redatlas
```

## Quickstart

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(
    api_key="ra_live_...",
)

health = client.health.get()
print(health.status)
```

## Authentication

The SDK is intended to be used with your RED Atlas API key.

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(api_key="ra_live_...")
plans = client.plans.list()

print(plans)
```

## Examples

```python
from redatlas import RedAtlasClient

client = RedAtlasClient(api_key="ra_live_...")

plans = client.plans.list()
market = client.data.market("col")
records = client.data.list("col", "listings", limit=3)

print(len(plans.data))
print(market.data.available_entities)
print(len(records.data))
```

## Typed Requests

```python
from redatlas import RedAtlasClient
from redatlas.models.listing_type import ListingType
from redatlas.models.report_type import ReportType
from redatlas.models.unified_report_request import UnifiedReportRequest

client = RedAtlasClient(api_key="ra_live_...")

report = client.reports.create(
    UnifiedReportRequest(
        type=ReportType("avm"),
        market="col",
        lat=6.2442,
        lon=-75.5812,
        property_type="apartment",
        listing_type=ListingType("for_sale"),
        built_area=85,
    )
)

print(report.data.id)
```

Typed request models are available under `redatlas.models`.

## Notes

- The public entrypoint is `RedAtlasClient`
- Standard usage is `RedAtlasClient(api_key="ra_live_...")`
- The SDK also exposes generated typed request and response models
- The default API host is the production RED Atlas API
- Integration tests in this repo verify that wrapper methods forward requests to the expected endpoints with the expected params
