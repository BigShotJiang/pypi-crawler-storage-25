# sheafpipeline

`sheafpipeline` is the official Python package namespace for lightweight
pipeline-stage helpers used by the SheafLab project.

This initial public release covers stage validation, ready-stage selection, and
deterministic pipeline planning for compact experimental workflows.

