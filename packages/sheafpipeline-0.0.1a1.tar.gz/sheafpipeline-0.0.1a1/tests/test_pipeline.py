import unittest

from sheafpipeline import PipelineStage, execution_plan, ready_stages


class PipelineTests(unittest.TestCase):
    def setUp(self) -> None:
        self.stages = [
            PipelineStage("collect"),
            PipelineStage("embed", ("collect",), "ml"),
            PipelineStage("report", ("embed",), "ops"),
        ]

    def test_ready_stages(self) -> None:
        self.assertEqual([stage.key for stage in ready_stages(self.stages, {"collect"})], ["embed"])

    def test_execution_plan(self) -> None:
        self.assertEqual(execution_plan(self.stages), ["collect", "embed", "report"])

