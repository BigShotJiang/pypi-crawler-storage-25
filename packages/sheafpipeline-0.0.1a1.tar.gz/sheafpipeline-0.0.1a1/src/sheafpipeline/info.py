def project_info() -> dict[str, str]:
    return {
        "name": "sheafpipeline",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheafpipeline-python",
    }

