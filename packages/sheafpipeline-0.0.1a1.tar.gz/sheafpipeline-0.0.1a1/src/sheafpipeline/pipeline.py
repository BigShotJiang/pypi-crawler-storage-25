from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class PipelineStage:
    key: str
    after: tuple[str, ...] = ()
    lane: str = "default"


def validate_stages(stages: list[PipelineStage]) -> None:
    keys = [stage.key for stage in stages]
    if len(keys) != len(set(keys)):
        raise ValueError("stage keys must be unique")
    known = set(keys)
    for stage in stages:
        missing = set(stage.after) - known
        if missing:
            raise ValueError(f"unknown prerequisites for {stage.key}: {sorted(missing)}")


def ready_stages(stages: list[PipelineStage], completed: set[str]) -> list[PipelineStage]:
    validate_stages(stages)
    return sorted(
        [stage for stage in stages if stage.key not in completed and set(stage.after).issubset(completed)],
        key=lambda stage: (stage.lane, stage.key),
    )


def execution_plan(stages: list[PipelineStage]) -> list[str]:
    completed: set[str] = set()
    order: list[str] = []
    while len(completed) < len(stages):
        ready = ready_stages(stages, completed)
        if not ready:
            raise ValueError("pipeline contains a cycle")
        stage = ready[0]
        completed.add(stage.key)
        order.append(stage.key)
    return order

