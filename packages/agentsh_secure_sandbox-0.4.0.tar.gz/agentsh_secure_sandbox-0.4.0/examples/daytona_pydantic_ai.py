"""Daytona + Pydantic AI example.

Prerequisites:
    pip install agentsh-secure-sandbox[pydantic-ai,daytona]
    export DAYTONA_API_KEY=...        # or configure via daytona CLI
"""
import asyncio

from daytona_sdk import Daytona
from pydantic_ai import Agent
from agentsh_secure_sandbox import SecureSandboxToolset
from agentsh_secure_sandbox.adapters import daytona


async def main() -> None:
    client = Daytona()
    raw = await client.create()

    toolset = SecureSandboxToolset(daytona(raw))
    agent = Agent("claude-sonnet-4-6", toolsets=[toolset])

    async with agent:
        result = await agent.run(
            "Create a Python script in /workspace/hello.py that prints "
            "'Hello from Daytona!' and then run it."
        )
        print(result.output)


if __name__ == "__main__":
    asyncio.run(main())
