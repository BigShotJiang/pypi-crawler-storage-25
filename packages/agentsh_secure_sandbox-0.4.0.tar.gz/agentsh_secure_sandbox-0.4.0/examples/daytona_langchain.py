"""Daytona + LangChain/LangGraph example.

Prerequisites:
    pip install agentsh-secure-sandbox[langchain,daytona] langchain-anthropic langgraph
    export DAYTONA_API_KEY=...
    export ANTHROPIC_API_KEY=...
"""
import asyncio

from daytona_sdk import Daytona
from langchain_anthropic import ChatAnthropic
from langgraph.prebuilt import create_react_agent
from agentsh_secure_sandbox import SecureSandboxToolkit
from agentsh_secure_sandbox.adapters import daytona


async def main() -> None:
    client = Daytona()
    raw = await client.create()

    toolkit = SecureSandboxToolkit(daytona(raw))

    async with toolkit:
        agent = create_react_agent(
            ChatAnthropic(model="claude-sonnet-4-6"),
            tools=toolkit.get_tools(),
        )
        result = await agent.ainvoke({
            "messages": [
                {"role": "user", "content": "List the files in /workspace and tell me what you see."}
            ]
        })
        for msg in result["messages"]:
            print(msg.content)


if __name__ == "__main__":
    asyncio.run(main())
