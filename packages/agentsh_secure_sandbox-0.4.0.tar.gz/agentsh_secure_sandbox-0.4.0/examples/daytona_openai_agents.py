"""Daytona + OpenAI Agents SDK example.

Prerequisites:
    pip install agentsh-secure-sandbox[openai-agents,daytona]
    export DAYTONA_API_KEY=...
    export OPENAI_API_KEY=...
"""
import asyncio

from daytona_sdk import Daytona
from agents import Agent, Runner
from agentsh_secure_sandbox import SecureSandboxAgentTools
from agentsh_secure_sandbox.adapters import daytona


async def main() -> None:
    client = Daytona()
    raw = await client.create()

    sandbox_tools = SecureSandboxAgentTools(daytona(raw))

    async with sandbox_tools:
        agent = Agent(
            name="Coder",
            instructions="You are a coding assistant with access to a secure sandbox.",
            tools=sandbox_tools.get_tools(),
        )
        result = await Runner.run(
            agent,
            "Create a hello world Express server in /workspace/app.js and test it.",
        )
        print(result.final_output)


if __name__ == "__main__":
    asyncio.run(main())
