"""Shared fixtures and helpers for e2e tests."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pytest
from dotenv import load_dotenv

# Load .env from project root
load_dotenv(Path(__file__).resolve().parents[2] / ".env")

ENV: dict[str, str] = {
    "E2B_API_KEY": os.environ.get("E2B_API_KEY", ""),
    "DAYTONA_API_KEY": os.environ.get("DAYTONA_API_KEY", ""),
    "DAYTONA_API_URL": os.environ.get("DAYTONA_API_URL", ""),
    "DAYTONA_TARGET": os.environ.get("DAYTONA_TARGET", ""),
    "VERCEL_TOKEN": os.environ.get("VERCEL_TOKEN", ""),
    "VERCEL_PROJECT_ID": os.environ.get("VERCEL_PROJECT_ID", ""),
    "VERCEL_TEAM_ID": os.environ.get("VERCEL_TEAM_ID", ""),
    "CLOUDFLARE_WORKER_URL": os.environ.get("CLOUDFLARE_WORKER_URL", ""),
    "CLOUDFLARE_API_TOKEN": os.environ.get("CLOUDFLARE_API_TOKEN", ""),
    "BLAXEL_API_KEY": os.environ.get("BLAXEL_API_KEY", ""),
    "BL_API_KEY": os.environ.get("BL_API_KEY", ""),
    "BL_WORKSPACE": os.environ.get("BL_WORKSPACE", ""),
    "SPRITES_TOKEN": os.environ.get("SPRITES_TOKEN", ""),
    "SPRITES_ORG": os.environ.get("SPRITES_ORG", ""),
    "SPRITES_NAME": os.environ.get("SPRITES_NAME", ""),
    "FLY_API_TOKEN": os.environ.get("FLY_API_TOKEN", ""),
    "MODAL_TOKEN_ID": os.environ.get("MODAL_TOKEN_ID", ""),
    "MODAL_TOKEN_SECRET": os.environ.get("MODAL_TOKEN_SECRET", ""),
    "RUNLOOP_API_KEY": os.environ.get("RUNLOOP_API_KEY", ""),
    "EXE_VM_NAME": os.environ.get("EXE_VM_NAME", ""),
    "FREESTYLE_API_KEY": os.environ.get("FREESTYLE_API_KEY", ""),
}


def _sdk_available(module_name: str) -> bool:
    """Check if a Python SDK is importable."""
    try:
        __import__(module_name)
        return True
    except ImportError:
        return False


# ─── Skip helpers ──────────────────────────────────────────

e2b_available = _sdk_available("e2b") and bool(ENV["E2B_API_KEY"])
daytona_available = _sdk_available("daytona_sdk") and bool(ENV["DAYTONA_API_KEY"])
cloudflare_available = bool(ENV["CLOUDFLARE_WORKER_URL"]) and bool(ENV["CLOUDFLARE_API_TOKEN"])
blaxel_available = (_sdk_available("blaxel_core") or _sdk_available("blaxel")) and bool(ENV["BLAXEL_API_KEY"])
# Vercel has no Python SDK — uses HTTP wrapper; skip only if no token
vercel_available = bool(ENV["VERCEL_TOKEN"]) and bool(ENV["VERCEL_PROJECT_ID"]) and bool(ENV["VERCEL_TEAM_ID"])
# Sprites: requires sprites-py SDK + either SPRITES_TOKEN or (FLY_API_TOKEN + SPRITES_ORG)
sprites_available = (
    _sdk_available("sprites")
    and bool(ENV["SPRITES_NAME"])
    and bool(ENV["SPRITES_TOKEN"] or (ENV["FLY_API_TOKEN"] and ENV["SPRITES_ORG"]))
)
modal_available = (
    _sdk_available("modal")
    and bool(ENV["MODAL_TOKEN_ID"])
    and bool(ENV["MODAL_TOKEN_SECRET"])
)
runloop_available = _sdk_available("runloop_api_client") and bool(ENV["RUNLOOP_API_KEY"])
exe_available = bool(ENV["EXE_VM_NAME"])
freestyle_available = (
    _sdk_available("httpx") and bool(ENV["FREESTYLE_API_KEY"])
)

skip_no_e2b = pytest.mark.skipif(not e2b_available, reason="e2b SDK or E2B_API_KEY missing")
skip_no_daytona = pytest.mark.skipif(
    not daytona_available, reason="daytona_sdk or DAYTONA_API_KEY missing"
)
skip_no_cloudflare = pytest.mark.skipif(
    not cloudflare_available, reason="CLOUDFLARE_WORKER_URL or CLOUDFLARE_API_TOKEN missing"
)
skip_no_vercel = pytest.mark.skipif(
    not vercel_available, reason="VERCEL_TOKEN, VERCEL_PROJECT_ID, or VERCEL_TEAM_ID missing"
)
skip_no_blaxel = pytest.mark.skipif(
    not blaxel_available, reason="blaxel SDK or BLAXEL_API_KEY missing"
)
skip_no_sprites = pytest.mark.skipif(
    not sprites_available,
    reason="sprites-py SDK or SPRITES_NAME/SPRITES_TOKEN missing",
)
skip_no_modal = pytest.mark.skipif(
    not modal_available,
    reason="modal SDK or MODAL_TOKEN_ID/MODAL_TOKEN_SECRET missing",
)
skip_no_runloop = pytest.mark.skipif(
    not runloop_available,
    reason="runloop SDK or RUNLOOP_API_KEY missing",
)
skip_no_exe = pytest.mark.skipif(
    not exe_available,
    reason="EXE_VM_NAME missing",
)
skip_no_freestyle = pytest.mark.skipif(
    not freestyle_available,
    reason="httpx missing or FREESTYLE_API_KEY unset",
)


# ─── Fixtures ──────────────────────────────────────────────


@pytest.fixture(scope="module")
def env() -> dict[str, str]:
    return ENV


@pytest.fixture(scope="module")
def secured_e2b() -> Any:
    """Placeholder — actual fixture is in test_e2b.py module-scoped setup."""
    pytest.skip("Use module-level setup")
