"""Runloop end-to-end tests — mirrors runloop-e2e-runner.ts."""

from __future__ import annotations

import time

import pytest
import pytest_asyncio

from tests.e2e.conftest import skip_no_runloop

from agentsh_secure_sandbox import SecuredSandbox, secure_sandbox
from agentsh_secure_sandbox.adapters import runloop, runloop_defaults
from agentsh_secure_sandbox.core.types import ExecOpts

pytestmark = [pytest.mark.e2e, pytest.mark.timeout(600), skip_no_runloop, pytest.mark.asyncio(loop_scope="module")]

# ─── Module-scoped setup / teardown ────────────────────────


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def runloop_devbox():  # type: ignore[misc]
    """Create a Runloop devbox for testing."""
    from runloop_api_client import AsyncRunloop  # type: ignore[import-untyped]

    client = AsyncRunloop()
    devbox = await client.devboxes.create_and_await_running(
        launch_parameters={
            "launch_commands": [
                "sudo apt-get update -qq && sudo apt-get install -y -qq fuse3 libseccomp2 > /dev/null 2>&1 || true",
            ],
        },
    )

    yield {"client": client, "id": devbox.id}

    try:
        await client.devboxes.shutdown(devbox.id)
    except Exception:
        pass


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def adapter(runloop_devbox):  # type: ignore[misc]
    """Wrap Runloop devbox in our adapter."""
    return runloop(runloop_devbox)


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def secured(adapter) -> SecuredSandbox:  # type: ignore[misc]
    """Provision a secured sandbox via the Runloop adapter."""
    sec = await secure_sandbox(adapter, runloop_defaults())

    yield sec  # type: ignore[misc]

    await sec.stop()


# ─── Adapter tests ───────────────────────────────────────────


class TestRunloopAdapter:
    async def test_exec_simple_command(self, adapter) -> None:
        result = await adapter.exec("echo", ["hello"])
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_exec_nonzero_exit(self, adapter) -> None:
        result = await adapter.exec("ls", ["/nonexistent-path-xyz"])
        assert result.exit_code != 0

    async def test_exec_with_sudo(self, adapter) -> None:
        result = await adapter.exec("whoami", opts=ExecOpts(sudo=True))
        assert result.exit_code == 0
        assert result.stdout.strip() == "root"

    async def test_exec_with_env_vars(self, adapter) -> None:
        result = await adapter.exec("sh", ["-c", "echo $TEST_VAR"],
                                    ExecOpts(env={"TEST_VAR": "runloop-e2e"}))
        assert result.exit_code == 0
        assert result.stdout.strip() == "runloop-e2e"

    async def test_exec_with_cwd(self, adapter) -> None:
        result = await adapter.exec("pwd", opts=ExecOpts(cwd="/tmp"))
        assert result.exit_code == 0
        assert result.stdout.strip() == "/tmp"

    async def test_write_read_roundtrip(self, adapter) -> None:
        await adapter.write_file("/tmp/runloop-e2e-test.txt", "hello from e2e")
        content = await adapter.read_file("/tmp/runloop-e2e-test.txt")
        assert content == "hello from e2e"

    async def test_write_read_special_chars(self, adapter) -> None:
        content = 'line1\nline2\ttab\n"quotes" & <brackets>'
        await adapter.write_file("/tmp/runloop-e2e-special.txt", content)
        read = await adapter.read_file("/tmp/runloop-e2e-special.txt")
        assert read == content

    async def test_readfile_raises_on_missing(self, adapter) -> None:
        with pytest.raises(Exception, match="readFile failed"):
            await adapter.read_file("/tmp/runloop-e2e-nonexistent-xyz.txt")

    async def test_detached_exec(self, adapter) -> None:
        start = time.time()
        result = await adapter.exec("sleep", ["10"], ExecOpts(detached=True))
        elapsed = time.time() - start
        assert result.exit_code == 0
        assert elapsed < 5.0, f"detached took too long: {elapsed:.1f}s"


# ─── Smoke tests ──────────────────────────────────────────


class TestRunloopSmoke:
    async def test_provisions_session_id(self, secured: SecuredSandbox) -> None:
        assert secured.session_id
        assert isinstance(secured.session_id, str)

    async def test_reports_valid_security_mode(self, secured: SecuredSandbox) -> None:
        assert secured.security_mode in ("full", "ptrace", "landlock", "landlock-only", "minimal")

    async def test_exec_simple_command(self, secured: SecuredSandbox) -> None:
        result = await secured.exec("echo hello")
        assert result.exit_code == 0
        assert result.stdout.strip() == "hello"

    async def test_write_read_roundtrip(self, secured: SecuredSandbox) -> None:
        path = "/workspace/e2e-test-file.txt"
        content = f"e2e-roundtrip-{int(time.time() * 1000)}"

        write_result = await secured.write_file(path, content)
        assert write_result.success is True

        read_result = await secured.read_file(path)
        assert read_result.success is True
        if read_result.success:
            assert read_result.content.strip() == content


# ─── Policy enforcement ───────────────────────────────────


class TestRunloopPolicy:
    async def test_blocks_sudo(self, secured: SecuredSandbox) -> None:
        if secured.security_mode == "full":
            result = await secured.exec("sudo whoami")
            assert result.exit_code != 0

    async def test_denies_env_write(self, secured: SecuredSandbox) -> None:
        if secured.security_mode == "full":
            result = await secured.write_file("/workspace/.env", "SECRET=leaked")
            assert result.success is False

    async def test_allows_workspace_write(self, secured: SecuredSandbox) -> None:
        result = await secured.write_file("/workspace/allowed-file.txt", "allowed")
        assert result.success is True

    async def test_allows_npm_registry(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            'curl -s -o /dev/null -w "%{http_code}" https://registry.npmjs.org/'
            ' || echo "no-curl"'
        )
        if "no-curl" not in result.stdout:
            assert result.stdout.strip() == "200"

    async def test_blocks_unauthorized_network(self, secured: SecuredSandbox) -> None:
        result = await secured.exec(
            "curl -s -o /dev/null -w '%{http_code}' --connect-timeout 5"
            " https://evil.example.com 2>&1"
        )
        assert result.stdout.strip() != "200"

    async def test_denies_ssh_keys(self, secured: SecuredSandbox) -> None:
        if secured.security_mode == "full":
            result = await secured.exec("cat ~/.ssh/id_rsa 2>&1")
            assert result.exit_code != 0

    async def test_blocks_nc(self, secured: SecuredSandbox) -> None:
        if secured.security_mode == "full":
            result = await secured.exec("nc -h 2>&1 || true")
            assert result.exit_code != 0 or "blocked" in result.stderr or "denied" in result.stderr

    async def test_blocks_kill(self, secured: SecuredSandbox) -> None:
        if secured.security_mode == "full":
            result = await secured.exec("kill -0 1 2>&1")
            assert result.exit_code != 0

    async def test_filters_sensitive_env_vars(self, secured: SecuredSandbox) -> None:
        result = await secured.exec('bash -c "echo $SECRET_KEY"')
        assert result.stdout.strip() == ""
