"""Unit tests for freestyle_defaults and configure_freestyle_spec."""

from __future__ import annotations

import pytest

from agentsh_secure_sandbox.adapters.freestyle._defaults import (
    FreestyleConfigureOptions,
    configure_freestyle_spec,
    freestyle_defaults,
)
from agentsh_secure_sandbox.adapters.freestyle._spec import FreestyleVmSpec
from agentsh_secure_sandbox.core.types import SecureConfig


class TestFreestyleDefaults:
    def test_returns_secure_config(self) -> None:
        config = freestyle_defaults()
        assert isinstance(config, SecureConfig)

    def test_workspace_is_home_user(self) -> None:
        config = freestyle_defaults()
        assert config.workspace == "/home/user"

    def test_install_strategy_is_preinstalled(self) -> None:
        config = freestyle_defaults()
        assert config.install_strategy == "preinstalled"

    def test_allow_degraded_is_true(self) -> None:
        config = freestyle_defaults()
        assert config.server_config is not None
        assert config.server_config.allow_degraded is True

    def test_fuse_deferred_mode(self) -> None:
        config = freestyle_defaults()
        assert config.server_config is not None
        assert config.server_config.fuse is not None
        assert config.server_config.fuse.deferred is True
        assert config.server_config.fuse.deferred_enable_command == [
            "sudo", "/bin/chmod", "666", "/dev/fuse",
        ]

    def test_file_monitor_disabled(self) -> None:
        config = freestyle_defaults()
        assert config.server_config is not None
        assert config.server_config.seccomp_details is not None
        fm = config.server_config.seccomp_details.file_monitor
        assert fm is not None
        assert fm.enabled is False

    def test_real_paths_is_true(self) -> None:
        config = freestyle_defaults()
        assert config.real_paths is True

    def test_policy_has_file_rules(self) -> None:
        config = freestyle_defaults()
        assert config.policy is not None
        assert config.policy.file is not None
        assert len(config.policy.file) > 0

    def test_policy_denies_env_files(self) -> None:
        """Sanity check that the policy denies writing .env."""
        config = freestyle_defaults()
        assert config.policy is not None
        # Look for a deny rule whose patterns include **/.env
        deny_patterns: list[str] = []
        for rule in config.policy.file or []:
            d = rule.model_dump()
            if "deny" in d:
                deny = d["deny"]
                if isinstance(deny, str):
                    deny_patterns.append(deny)
                else:
                    deny_patterns.extend(deny)
        assert "**/.env" in deny_patterns

    def test_policy_network_allows_npm(self) -> None:
        config = freestyle_defaults()
        assert config.policy is not None
        allow_hosts: list[str] = []
        for rule in config.policy.network or []:
            d = rule.model_dump()
            if "allow" in d:
                a = d["allow"]
                if isinstance(a, str):
                    allow_hosts.append(a)
                else:
                    allow_hosts.extend(a)
        assert "registry.npmjs.org" in allow_hosts

    def test_policy_network_denies_freestyle_events_cidr(self) -> None:
        config = freestyle_defaults()
        assert config.policy is not None
        all_deny_cidrs: list[str] = []
        for rule in config.policy.network or []:
            d = rule.model_dump()
            if "deny_cidrs" in d:
                all_deny_cidrs.extend(d["deny_cidrs"])
        assert "192.0.2.0/24" in all_deny_cidrs

    def test_resource_limits_set(self) -> None:
        config = freestyle_defaults()
        assert config.policy is not None
        assert config.policy.resource_limits is not None
        assert config.policy.resource_limits.max_memory_mb == 2048
        assert config.policy.resource_limits.cpu_quota_percent == 50
        assert config.policy.resource_limits.pids_max == 100


class TestFreestyleConfigureOptions:
    def test_defaults(self) -> None:
        opts = FreestyleConfigureOptions()
        assert opts.agentsh_version == "0.18.0"
        assert opts.server_port == 18080


class TestConfigureFreestyleSpec:
    def test_returns_the_same_spec_for_chaining(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        returned = configure_freestyle_spec(spec)
        assert returned is spec

    def test_adds_apt_deps(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.apt_deps is not None
        required = {
            "ca-certificates", "curl", "jq", "libseccomp2",
            "sudo", "fuse3", "python3", "file", "sqlite3",
        }
        assert required.issubset(set(spec.apt_deps))

    def test_adds_install_and_startup_scripts(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.additional_files is not None
        assert "/opt/install-agentsh.sh" in spec.additional_files
        assert "/opt/agentsh-startup.sh" in spec.additional_files

    def test_install_script_contains_agentsh_version(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.additional_files is not None
        content = spec.additional_files["/opt/install-agentsh.sh"].content
        assert 'AGENTSH_VERSION="0.18.0"' in content

    def test_custom_agentsh_version(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(
            spec, FreestyleConfigureOptions(agentsh_version="0.18.1")
        )
        assert spec.additional_files is not None
        content = spec.additional_files["/opt/install-agentsh.sh"].content
        assert 'AGENTSH_VERSION="0.18.1"' in content
        assert 'AGENTSH_VERSION="0.17.0"' not in content

    def test_rejects_invalid_agentsh_version(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        with pytest.raises(ValueError, match="agentsh_version"):
            configure_freestyle_spec(
                spec, FreestyleConfigureOptions(agentsh_version="not-a-semver")
            )

    def test_does_not_add_environment_file(self) -> None:
        """The VM snapshot only installs agentsh. Env injection is owned
        by provision.py at session start, not baked into /etc/environment."""
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.additional_files is not None
        assert "/etc/environment" not in spec.additional_files

    def test_adds_install_agentsh_systemd_service(self) -> None:
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.systemd is not None
        assert spec.systemd.services is not None
        names = [s.name for s in spec.systemd.services]
        assert "install-agentsh" in names

    def test_adds_agentsh_startup_service_with_dependency(self) -> None:
        """The ``agentsh`` service starts the server, installs the shim,
        and keeps the process alive after install completes.
        """
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.systemd is not None
        services = {s.name: s for s in (spec.systemd.services or [])}
        assert "agentsh" in services
        startup = services["agentsh"]
        # Before to_request_body processes the .service suffix, these are bare
        assert startup.after == ["install-agentsh"] or startup.after == ["install-agentsh.service"]
        assert startup.requires == ["install-agentsh"] or startup.requires == ["install-agentsh.service"]

    def test_accepts_dict_input(self) -> None:
        # Should wrap a dict into FreestyleVmSpec, then return as FreestyleVmSpec
        result = configure_freestyle_spec({})  # type: ignore[arg-type]
        assert isinstance(result, FreestyleVmSpec)
        assert result.systemd is not None

    def test_wire_format_install_script_rewritten_to_exec(self) -> None:
        """After configure + to_request_body, install service's exec is set."""
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        body = spec.to_request_body()
        services = body["systemd"]["services"]
        install = next(s for s in services if s["name"] == "install-agentsh")
        assert install["exec"] == ["/bin/bash /opt/install-agentsh.sh"]

    def test_startup_script_starts_server(self) -> None:
        """The startup script starts the agentsh server and installs shim."""
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.additional_files is not None
        content = spec.additional_files["/opt/agentsh-startup.sh"].content
        assert "agentsh server" in content
        assert "shim install-shell" in content
        assert "wait $SERVER_PID" in content

    def test_install_script_uses_tar_gz(self) -> None:
        """The install script uses tar.gz instead of .deb."""
        spec = FreestyleVmSpec().snapshot()
        configure_freestyle_spec(spec)
        assert spec.additional_files is not None
        content = spec.additional_files["/opt/install-agentsh.sh"].content
        assert "tar.gz" in content
        assert "tar xz" in content
        assert ".deb" not in content
        assert "dpkg" not in content
