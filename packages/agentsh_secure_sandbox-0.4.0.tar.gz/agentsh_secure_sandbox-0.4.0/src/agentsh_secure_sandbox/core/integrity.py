from __future__ import annotations

PINNED_VERSION = "0.18.0"

CHECKSUMS: dict[str, dict[str, str]] = {
    "0.18.0": {
        "linux_amd64": "da21c4009af236cd51d07649d3c2d31d947a8aa52933e35ea780dbbfa328263f",
        "linux_arm64": "52f50f5bb12f8730e832f3bf683a44178eb1db0d9b49b9ddc64740e41b0963fd",
    },
    "0.17.0": {
        "linux_amd64": "f8b710e29a45e104b93dd922540bd877762d1c68005a62c871216055b6db82b4",
        "linux_arm64": "4de3338f5d060d289dfbbf77c9172a573f4c06ca6f725fa619e408d75b17bd73",
    },
    "0.16.9": {
        "linux_amd64": "37b7be738291e90957a13653c5bb60b3cbbf9ab5abbc932e00e679a431f9064e",
        "linux_arm64": "4a8e29457241a329bca09d45830542de1c1c98976332234294a14d818c38fd72",
    },
    "0.16.2": {
        "linux_amd64": "7ff357066a61694626d4c19afa92fdf368318bced9be90391cc2f3808976f995",
        "linux_arm64": "a48b3e4a60804cca98326619a68409e8ee83556d69ee2cf5d574e4361e0c19c6",
    },
}


def get_checksum(version: str, arch: str) -> str:
    return CHECKSUMS[version][arch]


def binary_url(version: str, arch: str, override: str | None = None) -> str:
    if override:
        return override
    return (
        f"https://github.com/canyonroad/agentsh/releases/download/"
        f"v{version}/agentsh_{version}_{arch}.tar.gz"
    )


def build_verify_command(file_path: str, expected_checksum: str) -> str:
    """Build a shell command to verify SHA256 checksum of a file.

    Returns multiple commands joined with || to try different checksum tools.
    """
    import shlex

    safe_path = shlex.quote(file_path)
    safe_checksum = shlex.quote(expected_checksum)
    return (
        f"echo {safe_checksum}  {safe_path} | "
        f"sha256sum -c --status 2>/dev/null || "
        f"echo {safe_checksum}  {safe_path} | "
        f"shasum -a 256 -c --status 2>/dev/null || "
        f'test "$(openssl dgst -sha256 -r {safe_path} | cut -d\' \' -f1)" = {safe_checksum}'
    )
