from ._api import secure_sandbox
from .core.types import (
    AuditIntegrityConfig,
    AwsKmsConfig,
    AzureKeyVaultConfig,
    ExecOpts,
    ExecResult,
    GcpKmsConfig,
    HashicorpVaultConfig,
    ReadFileFailure,
    ReadFileResult,
    ReadFileSuccess,
    SandboxAdapter,
    SandboxAdapterBase,
    SecuredSandbox,
    SecureConfig,
    WriteFileFailure,
    WriteFileResult,
    WriteFileSuccess,
)
from .core.errors import (
    AgentSHError,
    PolicyValidationError,
    ProvisioningError,
    IntegrityError,
    TransportError,
    RuntimeError as RuntimeError,
)
from .policies.schema import (
    AwsSmProvider,
    AzureKvProvider,
    GcpSmProvider,
    HttpService,
    HttpServiceInject,
    HttpServiceInjectHeader,
    HttpServiceRule,
    HttpServiceSecret,
    KeyringProvider,
    OpProvider,
    PolicyDefinition,
    SecretProvider,
    VaultAuth,
    VaultProvider,
)
try:
    from .toolset.pydantic_ai import SecureSandboxToolset
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] == "pydantic_ai":

        def _missing_toolset(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxToolset requires the pydantic-ai extra. "
                "Install it with: pip install agentsh-secure-sandbox[pydantic-ai]"
            )

        SecureSandboxToolset = _missing_toolset  # type: ignore[assignment,misc]
    else:
        raise

try:
    from .toolset.langchain import SecureSandboxToolkit
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] in ("langchain", "langchain_core"):

        def _missing_toolkit(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxToolkit requires the langchain extra. "
                "Install it with: pip install agentsh-secure-sandbox[langchain]"
            )

        SecureSandboxToolkit = _missing_toolkit  # type: ignore[assignment,misc]
    else:
        raise

try:
    from .toolset.openai_agents import SecureSandboxAgentTools
except ModuleNotFoundError as _exc:
    if _exc.name and _exc.name.split(".")[0] in ("agents", "openai_agents"):

        def _missing_agent_tools(*_a: object, **_kw: object) -> object:
            raise ImportError(
                "SecureSandboxAgentTools requires the openai-agents extra. "
                "Install it with: pip install agentsh-secure-sandbox[openai-agents]"
            )

        SecureSandboxAgentTools = _missing_agent_tools  # type: ignore[assignment,misc]
    else:
        raise

__all__ = [
    "AgentSHError",
    "AuditIntegrityConfig",
    "AwsKmsConfig",
    "AwsSmProvider",
    "AzureKeyVaultConfig",
    "AzureKvProvider",
    "ExecOpts",
    "ExecResult",
    "GcpKmsConfig",
    "GcpSmProvider",
    "HashicorpVaultConfig",
    "HttpService",
    "HttpServiceInject",
    "HttpServiceInjectHeader",
    "HttpServiceRule",
    "HttpServiceSecret",
    "IntegrityError",
    "KeyringProvider",
    "OpProvider",
    "PolicyDefinition",
    "PolicyValidationError",
    "ProvisioningError",
    "ReadFileFailure",
    "ReadFileResult",
    "ReadFileSuccess",
    "RuntimeError",
    "SandboxAdapter",
    "SandboxAdapterBase",
    "SecretProvider",
    "SecureConfig",
    "SecureSandboxAgentTools",
    "SecureSandboxToolkit",
    "SecureSandboxToolset",
    "SecuredSandbox",
    "TransportError",
    "VaultAuth",
    "VaultProvider",
    "WriteFileFailure",
    "WriteFileResult",
    "WriteFileSuccess",
    "secure_sandbox",
]
