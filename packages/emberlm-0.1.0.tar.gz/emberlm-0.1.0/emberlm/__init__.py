"""Official EmberLM SDK for Python."""

from .client import Client, EmberLMError

__version__ = "0.1.0"
__all__ = ["Client", "EmberLMError", "__version__"]
