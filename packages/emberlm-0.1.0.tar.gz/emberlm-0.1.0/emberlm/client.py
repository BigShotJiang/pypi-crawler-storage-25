"""EmberLM API client. Zero third-party dependencies: uses urllib only."""

from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict, List, Optional

__all__ = ["Client", "EmberLMError"]

_DEFAULT_BASE_URL = "https://emberlm.dev"
_DEFAULT_TIMEOUT = 60
_USER_AGENT = "emberlm-python/0.1.0"


class EmberLMError(Exception):
    """Raised when the EmberLM API returns a non-2xx response."""

    def __init__(self, message: str, status: int, body: Any):
        super().__init__(message)
        self.status = status
        self.body = body


class Client:
    """EmberLM SDK client.

    Usage:
        from emberlm import Client
        client = Client(api_key="pk_live_...")
        result = client.run("summarize_docs", variables={"document": text})
        print(result["text"], result["passed_evals"], result["confidence"])
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: int = _DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def list_prompts(self) -> Dict[str, Any]:
        """GET /api/v1/prompts - list every prompt in the key's workspace."""
        return self._request("GET", "/api/v1/prompts")

    def get_prompt(self, name: str) -> Dict[str, Any]:
        """GET /api/v1/prompts/{name} - fetch a single prompt.

        Returns the `prod`-tagged version if one exists, otherwise the latest.
        """
        if not name:
            raise ValueError("name is required")
        path = "/api/v1/prompts/" + urllib.parse.quote(name, safe="")
        return self._request("GET", path)

    def run(
        self,
        prompt_name: str,
        variables: Optional[Dict[str, str]] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        """POST /api/v1/run - run a saved prompt.

        `variables` substitute into {{placeholders}}. `model` overrides the
        prompt's saved model for this call. All workspace eval rules are
        applied to the output.
        """
        if not prompt_name:
            raise ValueError("prompt_name is required")
        body: Dict[str, Any] = {
            "prompt": prompt_name,
            "variables": variables or {},
        }
        if model is not None:
            body["model"] = model
        return self._request("POST", "/api/v1/run", body=body)

    def eval(
        self,
        response: str,
        rule_ids: Optional[List[str]] = None,
        prompt: Optional[str] = None,
        variables: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        """POST /api/v1/eval - evaluate an arbitrary response.

        Useful when the response was produced by a different SDK or model.
        """
        if not response:
            raise ValueError("response is required")
        body: Dict[str, Any] = {"response": response}
        if prompt is not None:
            body["prompt"] = prompt
        if variables is not None:
            body["variables"] = variables
        if rule_ids:
            body["rule_ids"] = rule_ids
        return self._request("POST", "/api/v1/eval", body=body)

    # Alias for users who prefer a non-keyword name.
    evaluate = eval

    def _request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        url = self.base_url + path
        headers = {
            "Authorization": "Bearer " + self.api_key,
            "User-Agent": _USER_AGENT,
            "Accept": "application/json",
        }
        data: Optional[bytes] = None
        if body is not None:
            headers["Content-Type"] = "application/json"
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url=url, data=data, headers=headers, method=method)

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8")
                return self._parse_body(raw, resp.status)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8", errors="replace")
            parsed: Any
            try:
                parsed = json.loads(raw) if raw else None
            except json.JSONDecodeError:
                parsed = raw
            message = "EmberLM request failed: " + str(e.code)
            if isinstance(parsed, dict) and isinstance(parsed.get("error"), str):
                message = parsed["error"]
            raise EmberLMError(message, e.code, parsed) from None
        except urllib.error.URLError as e:
            raise EmberLMError("EmberLM network error: " + str(e.reason), 0, None) from None

    @staticmethod
    def _parse_body(raw: str, status: int) -> Dict[str, Any]:
        if not raw:
            return {}
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            raise EmberLMError("EmberLM returned non-JSON body", status, raw) from None
        if not isinstance(parsed, dict):
            raise EmberLMError("EmberLM returned unexpected body", status, parsed)
        return parsed
