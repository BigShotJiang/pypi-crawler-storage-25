# Auto-generated version file
__version__ = "1.0.12"
__version_tuple__ = (1, 0, 12)
