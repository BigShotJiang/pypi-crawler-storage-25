"""
blq CLI - Build Log Query command-line interface.

Usage:
    blq init [--mcp]                  Initialize .lq directory
    blq run <command>                 Run registered command (alias: r)
    blq exec <command>                Execute ad-hoc command (alias: e)
    blq import <file> [--name NAME]   Import existing log file
    blq capture [--name NAME]         Capture from stdin
    blq status                        Show status of all sources
    blq errors [--source S] [-n N]    Show recent errors
    blq warnings [--source S] [-n N]  Show recent warnings
    blq summary                       Aggregate summary
    blq sql <query>                   Run arbitrary SQL
    blq shell                         Interactive SQL shell
    blq history [-n N]                Show run history
    blq prune [--older-than DAYS]     Remove old logs
    blq event <ref>                   Show event details by reference (e.g., 5:3)
    blq query [options] [file...]     Query log files or stored events (alias: q)
    blq filter [expr...] [file...]    Filter with simple syntax (alias: f)
    blq sync [destination]            Sync logs to central location
    blq serve [--transport T]         Start MCP server for AI agents

Query examples:
    blq q build.log                           # all events from file
    blq q -s ref_file,message build.log      # select columns
    blq q -f "severity='error'" build.log     # filter with SQL WHERE
    blq q -f "severity='error'"               # query stored events

Filter examples:
    blq f severity=error build.log            # filter by exact match
    blq f severity=error,warning build.log    # OR within field
    blq f ref_file~main build.log            # contains (LIKE)
    blq f severity!=info build.log            # not equal
    blq f -v severity=error build.log         # invert (grep -v style)
    blq f -c severity=error build.log         # count matches only
"""

from __future__ import annotations

import argparse
import logging
import sys
from importlib.metadata import version as get_version

from blq.commands import (
    cmd_capture,
    cmd_ci_check,
    cmd_ci_comment,
    cmd_ci_generate,
    cmd_commands,
    cmd_completions,
    cmd_context,
    cmd_errors,
    cmd_event,
    cmd_events,
    cmd_exec,
    cmd_filter,
    cmd_formats,
    cmd_history,
    cmd_hooks_generate,
    cmd_hooks_install,
    cmd_hooks_remove,
    cmd_hooks_status,
    cmd_hooks_uninstall,
    cmd_import,
    cmd_info,
    cmd_init,
    cmd_inspect,
    cmd_last,
    cmd_migrate,
    cmd_output,
    cmd_prune,
    cmd_query,
    cmd_register,
    cmd_report,
    cmd_run,
    cmd_shell,
    cmd_sql,
    cmd_status,
    cmd_suggest,
    cmd_sync,
    cmd_unregister,
    cmd_warnings,
    cmd_watch,
)
from blq.commands.config_cmd import cmd_config
from blq.commands.core import (
    GLOBAL_PROJECTS_PATH,
    # Re-export commonly used items for backward compatibility
    BlqConfig,
    ConnectionFactory,
    EventRef,
    EventSummary,
    RegisteredCommand,
    RunResult,
    capture_ci_info,
    capture_environment,
    capture_git_info,
    find_executable,
    get_connection,
    get_lq_dir,
    get_next_run_id,
    parse_log_content,
    write_run_parquet,
)
from blq.commands.mcp_cmd import cmd_mcp_install, cmd_mcp_serve
from blq.commands.query_cmd import format_query_output, parse_filter_expression, query_source

# Re-export for backward compatibility
__all__ = [
    "main",
    # Commands
    "cmd_capture",
    "cmd_ci_check",
    "cmd_ci_comment",
    "cmd_ci_generate",
    "cmd_commands",
    "cmd_report",
    "cmd_completions",
    "cmd_context",
    "cmd_errors",
    "cmd_event",
    "cmd_exec",
    "cmd_filter",
    "cmd_formats",
    "cmd_history",
    "cmd_import",
    "cmd_init",
    "cmd_inspect",
    "cmd_prune",
    "cmd_query",
    "cmd_register",
    "cmd_run",
    "cmd_suggest",
    "cmd_mcp_install",
    "cmd_mcp_serve",
    "cmd_shell",
    "cmd_sql",
    "cmd_status",
    "cmd_sync",
    "cmd_unregister",
    "cmd_warnings",
    "cmd_watch",
    # Core types and utilities
    "BlqConfig",
    "ConnectionFactory",
    "EventRef",
    "EventSummary",
    "RegisteredCommand",
    "RunResult",
    "capture_ci_info",
    "capture_environment",
    "capture_git_info",
    "find_executable",
    "format_query_output",
    "get_connection",
    "get_lq_dir",
    "get_next_run_id",
    "parse_filter_expression",
    "parse_log_content",
    "query_source",
    "write_run_parquet",
]


def _setup_logging() -> None:
    """Configure the lq logger with stderr handler."""
    lq_logger = logging.getLogger("blq-cli")
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(message)s"))
    lq_logger.addHandler(handler)
    # Default level is WARNING (quiet), changed by --summary or --verbose
    lq_logger.setLevel(logging.WARNING)


def main() -> None:
    _setup_logging()

    parser = argparse.ArgumentParser(
        description="blq - Build Log Query CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        "-V",
        "--version",
        action="version",
        version=f"%(prog)s {get_version('blq-cli')}",
    )

    # Global flags
    parser.add_argument(
        "-C",
        "--dir",
        metavar="PATH",
        dest="change_dir",
        help="Change to directory before running (like git -C)",
    )
    parser.add_argument(
        "--lq-dir",
        metavar="PATH",
        dest="lq_dir",
        help="Use specific .lq directory (overrides discovery)",
    )
    parser.add_argument(
        "-F",
        "--log-format",
        default="auto",
        help="Log format for parsing (default: auto). Use 'blq formats' to list available formats.",
    )
    parser.add_argument(
        "-g",
        "--global",
        action="store_true",
        dest="global_",
        help="Query global store (~/.lq/projects/) instead of local .lq",
    )
    parser.add_argument(
        "-d",
        "--database",
        metavar="PATH",
        help="Query custom database path (local or remote, e.g., s3://bucket/lq/)",
    )

    subparsers = parser.add_subparsers(dest="command", help="Command")

    # init
    p_init = subparsers.add_parser("init", help="Initialize .lq directory")
    mcp_group = p_init.add_mutually_exclusive_group()
    mcp_group.add_argument(
        "--mcp", "-m", action="store_true", help="Create .mcp.json for MCP server discovery"
    )
    mcp_group.add_argument(
        "--no-mcp",
        action="store_true",
        dest="no_mcp",
        help="Don't create .mcp.json (overrides auto_mcp user config)",
    )
    p_init.add_argument("--project", "-p", help="Project name (overrides auto-detection)")
    p_init.add_argument("--namespace", "-n", help="Project namespace (overrides auto-detection)")
    p_init.add_argument(
        "--detect", "-d", action="store_true", help="Auto-detect and register build/test commands"
    )
    p_init.add_argument(
        "--detect-mode",
        choices=["none", "simple", "inspect", "auto"],
        default="auto",
        help="Detection mode: none, simple (build files), inspect (parse CI/Makefiles), auto",
    )
    p_init.add_argument(
        "--yes",
        "-y",
        action="store_true",
        help="Non-interactive mode (auto-confirm detected commands)",
    )
    p_init.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Reinitialize config files (schema, config) without deleting data",
    )
    p_init.add_argument(
        "--parquet",
        action="store_true",
        help="Use legacy parquet storage mode (instead of default BIRD)",
    )
    # Gitignore handling: --gitignore (default) / --no-gitignore
    gitignore_group = p_init.add_mutually_exclusive_group()
    gitignore_group.add_argument(
        "--gitignore",
        action="store_true",
        dest="gitignore",
        default=True,
        help="Add .lq/ to .gitignore (default)",
    )
    gitignore_group.add_argument(
        "--no-gitignore",
        action="store_false",
        dest="gitignore",
        help="Don't modify .gitignore",
    )
    p_init.set_defaults(func=cmd_init)

    # run
    p_run = subparsers.add_parser("run", aliases=["r"], help="Run command and capture output")
    p_run.add_argument("command", nargs=argparse.REMAINDER, help="Command name and template args")
    p_run.add_argument("--name", "-n", help="Source name (default: command name)")
    p_run.add_argument("--format", "-f", default="auto", help="Parse format hint")
    p_run.add_argument("--keep-raw", "-r", action="store_true", help="Keep raw output file")
    p_run.add_argument("--json", "-j", action="store_true", help="Output structured JSON result")
    p_run.add_argument("--markdown", "-m", action="store_true", help="Output markdown summary")
    p_run.add_argument("--quiet", "-q", action="store_true", help="Suppress streaming output")
    p_run.add_argument(
        "--summary", "-s", action="store_true", help="Show brief summary (errors/warnings count)"
    )
    p_run.add_argument("--verbose", "-v", action="store_true", help="Show all blq status messages")
    p_run.add_argument(
        "--dry-run",
        action="store_true",
        help="Show expanded command without running it",
    )
    p_run.add_argument(
        "--include-warnings",
        "-w",
        action="store_true",
        help="Include warnings in structured output",
    )
    p_run.add_argument(
        "--error-limit", type=int, default=20, help="Max errors/warnings in output (default: 20)"
    )
    p_run.add_argument(
        "--register",
        "-R",
        action="store_true",
        help="Register command if not already registered",
    )
    p_run.add_argument(
        "--positional-args",
        "-a",
        type=int,
        default=None,
        metavar="N",
        help="Use exactly N positional args for placeholders (rest are passthrough)",
    )
    p_run.add_argument(
        "--timeout",
        "-t",
        type=int,
        default=None,
        metavar="SECONDS",
        help="Timeout in seconds (default: from command config, or no timeout)",
    )
    p_run.add_argument(
        "--compact",
        choices=["never", "always", "adaptive"],
        default="adaptive",
        help="Output mode: never (always show events), always (show raw output), "
        "adaptive (show raw if shorter than events). Default: adaptive",
    )
    p_run.add_argument(
        "--no-lock",
        action="store_true",
        help="Bypass command lock (run even if lock is held)",
    )
    p_run.add_argument(
        "--wait-lock",
        type=int,
        metavar="SECONDS",
        default=None,
        help="Wait up to SECONDS for lock to be released (default: fail immediately)",
    )
    p_run.set_defaults(func=cmd_run)
    # Capture control: runtime flags override command config
    capture_group = p_run.add_mutually_exclusive_group()
    capture_group.add_argument(
        "--capture",
        "-C",
        action="store_true",
        dest="capture",
        default=None,
        help="Force log capture (override command config)",
    )
    capture_group.add_argument(
        "--no-capture",
        "-N",
        action="store_false",
        dest="capture",
        help="Skip log capture, just run command",
    )

    # exec - ad-hoc command execution (never uses registry)
    p_exec = subparsers.add_parser(
        "exec", aliases=["x"], help="Execute ad-hoc command and capture output"
    )
    p_exec.add_argument("command", nargs=argparse.REMAINDER, help="Command to execute")
    p_exec.add_argument("--name", "-n", help="Source name (default: command name)")
    p_exec.add_argument("--format", "-f", default="auto", help="Parse format hint")
    p_exec.add_argument("--keep-raw", "-r", action="store_true", help="Keep raw output file")
    p_exec.add_argument("--json", "-j", action="store_true", help="Output structured JSON result")
    p_exec.add_argument("--markdown", "-m", action="store_true", help="Output markdown summary")
    p_exec.add_argument("--quiet", "-q", action="store_true", help="Suppress streaming output")
    p_exec.add_argument(
        "--summary", "-s", action="store_true", help="Show brief summary (errors/warnings count)"
    )
    p_exec.add_argument("--verbose", "-v", action="store_true", help="Show all blq status messages")
    p_exec.add_argument(
        "--include-warnings",
        "-w",
        action="store_true",
        help="Include warnings in structured output",
    )
    p_exec.add_argument(
        "--error-limit", type=int, default=20, help="Max errors/warnings in output (default: 20)"
    )
    p_exec.add_argument(
        "--timeout",
        "-t",
        type=int,
        default=None,
        metavar="SECONDS",
        help="Timeout in seconds (default: no timeout)",
    )
    p_exec.add_argument(
        "--no-capture",
        "-N",
        action="store_true",
        help="Skip log capture, just run command",
    )
    p_exec.add_argument(
        "--compact",
        choices=["never", "always", "adaptive"],
        default="adaptive",
        help="Output mode: never (always show events), always (show raw output), "
        "adaptive (show raw if shorter than events). Default: adaptive",
    )
    p_exec.set_defaults(func=cmd_exec)

    # import
    p_import = subparsers.add_parser("import", help="Import existing log file")
    p_import.add_argument("file", help="Log file to import")
    p_import.add_argument("--name", "-n", help="Source name (default: filename)")
    p_import.add_argument("--format", "-f", default="auto", help="Parse format hint")
    p_import.set_defaults(func=cmd_import)

    # capture
    p_capture = subparsers.add_parser("capture", help="Capture from stdin")
    p_capture.add_argument("--name", "-n", default="stdin", help="Source name")
    p_capture.add_argument("--format", "-f", default="auto", help="Parse format hint")
    p_capture.set_defaults(func=cmd_capture)

    # status
    p_status = subparsers.add_parser("status", help="Show status of all sources")
    p_status.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    p_status.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_status.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_status.add_argument(
        "--include-suppressed",
        action="store_true",
        help="Include events with suppressed fingerprints in counts",
    )
    p_status.set_defaults(func=cmd_status)

    # info - detailed info about a specific run
    p_info = subparsers.add_parser("info", aliases=["I"], help="Show detailed info about a run")
    p_info.add_argument("ref", help="Run ref (e.g., 'test:5') or invocation_id (UUID)")
    p_info.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    p_info.add_argument("--details", "-d", action="store_true", help="Show all fields")
    p_info.add_argument("--head", type=int, metavar="N", help="Show first N lines of output")
    p_info.add_argument("--tail", type=int, metavar="N", help="Show last N lines of output")
    p_info.add_argument("--follow", "-f", action="store_true", help="Follow output (like tail -f)")
    p_info.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_info.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_info.set_defaults(func=cmd_info)

    # last - quick view of the most recent run
    p_last = subparsers.add_parser("last", help="Show info about the most recent run")
    p_last.add_argument("--head", type=int, metavar="N", help="Show first N lines of output")
    p_last.add_argument("--tail", type=int, metavar="N", help="Show last N lines of output")
    p_last.add_argument(
        "--output", "-o", action="store_true", help="Show output (default: tail 20)"
    )
    p_last.add_argument("--errors", "-e", action="store_true", help="Show errors")
    p_last.add_argument("--warnings", "-w", action="store_true", help="Show warnings")
    p_last.add_argument("--severity", "-S", help="Filter events by severity")
    p_last.add_argument("--limit", "-n", type=int, default=20, help="Max events to show")
    p_last.add_argument("--quiet", "-q", action="store_true", help="Don't show run info")
    p_last.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_last.set_defaults(func=cmd_last)

    # output - view raw output from a run
    p_output = subparsers.add_parser(
        "output",
        aliases=["o"],
        help="Show raw output from a run",
    )
    p_output.add_argument(
        "ref",
        nargs="?",
        default=None,
        help="Run ref (e.g., 'build:5', '+1', 'test:+1') or source name (default: +1)",
    )
    p_output.add_argument("--tail", "-t", type=int, metavar="N", help="Show last N lines")
    p_output.add_argument("--head", "-H", type=int, metavar="N", help="Show first N lines")
    p_output.add_argument(
        "--lines",
        "-l",
        type=str,
        metavar="SPEC",
        help="Line spec (e.g., '100-200', '42 +/-5'). Requires read_lines.",
    )
    p_output.add_argument(
        "--grep",
        "-g",
        type=str,
        metavar="PATTERN",
        help="Search for regex pattern in output",
    )
    p_output.add_argument(
        "--context",
        "-C",
        type=int,
        metavar="N",
        default=0,
        help="Show N lines of context around grep matches (default: 0)",
    )
    p_output.add_argument(
        "--ignore-case",
        "-i",
        action="store_true",
        help="Case insensitive grep (default: true, use --no-ignore-case for exact)",
    )
    p_output.add_argument(
        "--no-ignore-case",
        action="store_true",
        help="Case sensitive grep",
    )
    p_output.add_argument(
        "--follow", "-f", action="store_true", help="Follow output (for running commands)"
    )
    p_output.add_argument(
        "--debug-formats",
        action="store_true",
        help="Show format detection diagnosis (which formats were tried, scores)",
    )
    p_output.set_defaults(func=cmd_output)

    # events (main command for viewing events with severity filter)
    p_events = subparsers.add_parser(
        "events", aliases=["e"], help="Show events (errors, warnings, info)"
    )
    p_events.add_argument(
        "source_arg",
        nargs="?",
        default=None,
        help="Source name or run ref (e.g., 'build', 'test:+1')",
    )
    p_events.add_argument(
        "--severity",
        "-S",
        help="Filter by severity (error, warning, info, or comma-separated list)",
    )
    p_events.add_argument("--source", "-s", dest="source_flag", help="Filter by source")
    p_events.add_argument("--limit", "-n", type=int, default=20, help="Max results")
    p_events.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_events.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_events.add_argument(
        "--include-suppressed",
        action="store_true",
        help="Include events with suppressed fingerprints",
    )
    p_events.set_defaults(func=cmd_events)

    # errors (alias for events --severity error)
    p_errors = subparsers.add_parser("errors", help="Show recent errors")
    p_errors.add_argument(
        "source_arg",
        nargs="?",
        default=None,
        help="Source name or run ref (e.g., 'build', 'test:+1')",
    )
    p_errors.add_argument("--source", "-s", dest="source_flag", help="Filter by source")
    p_errors.add_argument("--limit", "-n", type=int, default=10, help="Max results")
    p_errors.add_argument("--compact", "-c", action="store_true", help="Compact format")
    p_errors.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_errors.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_errors.add_argument(
        "--include-suppressed",
        action="store_true",
        help="Include events with suppressed fingerprints",
    )
    p_errors.set_defaults(func=cmd_errors)

    # warnings (alias for events --severity warning)
    p_warnings = subparsers.add_parser("warnings", help="Show recent warnings")
    p_warnings.add_argument(
        "source_arg",
        nargs="?",
        default=None,
        help="Source name or run ref (e.g., 'build', 'test:+1')",
    )
    p_warnings.add_argument("--source", "-s", dest="source_flag", help="Filter by source")
    p_warnings.add_argument("--limit", "-n", type=int, default=10, help="Max results")
    p_warnings.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_warnings.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_warnings.add_argument(
        "--include-suppressed",
        action="store_true",
        help="Include events with suppressed fingerprints",
    )
    p_warnings.set_defaults(func=cmd_warnings)

    # history
    p_history = subparsers.add_parser("history", aliases=["h"], help="Show run history")
    p_history.add_argument(
        "ref", nargs="?", help="Filter by tag or ref (e.g., 'test' or 'test:24')"
    )
    p_history.add_argument("--tag", "-t", help="Filter by tag name")
    p_history.add_argument(
        "--status",
        "-s",
        choices=["running", "completed", "orphaned", "all"],
        help="Filter by status (running=pending, completed, orphaned, all)",
    )
    p_history.add_argument("--limit", "-n", type=int, default=20, help="Max results")
    p_history.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_history.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_history.set_defaults(func=cmd_history)

    # sql
    p_sql = subparsers.add_parser("sql", help="Run arbitrary SQL")
    p_sql.add_argument("query", nargs="+", help="SQL query")
    p_sql.set_defaults(func=cmd_sql)

    # shell
    p_shell = subparsers.add_parser("shell", help="Interactive SQL shell")
    p_shell.set_defaults(func=cmd_shell)

    # prune
    p_prune = subparsers.add_parser("prune", help="Remove old logs")
    p_prune.add_argument("--older-than", "-d", type=int, default=30, help="Days to keep")
    p_prune.add_argument("--dry-run", action="store_true", help="Show what would be removed")
    p_prune.set_defaults(func=cmd_prune)

    # formats
    p_formats = subparsers.add_parser("formats", help="List available log formats")
    p_formats.set_defaults(func=cmd_formats)

    # completions
    p_completions = subparsers.add_parser("completions", help="Generate shell completion scripts")
    p_completions.add_argument(
        "shell",
        choices=["bash", "zsh", "fish"],
        help="Shell type (bash, zsh, or fish)",
    )
    p_completions.set_defaults(func=cmd_completions)

    # event
    p_event = subparsers.add_parser("event", help="Show event details by reference")
    p_event.add_argument("ref", help="Event reference (e.g., 5:3 for run 5, event 3)")
    p_event.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_event.set_defaults(func=cmd_event)

    # context
    p_context = subparsers.add_parser(
        "context", aliases=["c"], help="Show context lines around an event"
    )
    p_context.add_argument("ref", help="Event reference (e.g., 5:3)")
    p_context.add_argument(
        "--lines", "-n", type=int, default=3, help="Context lines before/after (default: 3)"
    )
    p_context.set_defaults(func=cmd_context)

    # inspect
    p_inspect = subparsers.add_parser(
        "inspect",
        aliases=["i"],
        help="Show comprehensive event details with context and enrichment",
    )
    p_inspect.add_argument("ref", help="Event reference (e.g., test:24:1)")
    p_inspect.add_argument(
        "--lines", "-n", type=int, default=5, help="Context lines before/after (default: 5)"
    )
    p_inspect.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    # Enrichment flags
    p_inspect.add_argument(
        "--source",
        "-s",
        action="store_true",
        help="Include source file context around error location",
    )
    p_inspect.add_argument(
        "--git", "-g", action="store_true", help="Include git context (blame and recent commits)"
    )
    p_inspect.add_argument(
        "--fingerprint",
        "-f",
        action="store_true",
        help="Include fingerprint history (occurrences, regression detection)",
    )
    p_inspect.add_argument(
        "--full", action="store_true", help="Include all enrichment (source, git, fingerprint)"
    )
    p_inspect.add_argument(
        "-F",
        "--field",
        action="append",
        default=[],
        metavar="FIELD",
        help="Output only specified field(s). Can repeat: -F fingerprint -F message",
    )
    p_inspect.set_defaults(func=cmd_inspect)

    # commands (with subcommands for list, register, unregister)
    p_commands = subparsers.add_parser("commands", aliases=["C"], help="Manage registered commands")
    commands_subparsers = p_commands.add_subparsers(
        dest="commands_command", help="Commands subcommand"
    )

    # commands list (default when no subcommand)
    p_commands_list = commands_subparsers.add_parser("list", help="List registered commands")
    p_commands_list.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_commands_list.add_argument("--markdown", "-m", action="store_true", help="Output as Markdown")
    p_commands_list.set_defaults(func=cmd_commands)

    # commands register
    p_commands_register = commands_subparsers.add_parser("register", help="Register a command")
    p_commands_register.add_argument("name", help="Command name (e.g., 'build', 'test')")
    p_commands_register.add_argument(
        "cmd", nargs=argparse.REMAINDER, help="Command to run (flags like -j are preserved)"
    )
    p_commands_register.add_argument("--description", "-d", help="Command description")
    p_commands_register.add_argument(
        "--timeout", type=int, default=None, help="Timeout in seconds (default: no timeout)"
    )
    p_commands_register.add_argument(
        "--format", "-f", default=None, help="Log format hint (auto-detected if not specified)"
    )
    p_commands_register.add_argument(
        "--no-capture", "-N", action="store_true", help="Don't capture logs by default"
    )
    p_commands_register.add_argument(
        "--force", action="store_true", help="Overwrite existing command"
    )
    p_commands_register.add_argument(
        "--run", "-r", action="store_true", help="Run command immediately after registering"
    )
    # Template command support
    p_commands_register.add_argument(
        "--template",
        "-t",
        action="store_true",
        help="Register as template command with {param} placeholders",
    )
    p_commands_register.add_argument(
        "--default",
        "-D",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Default value for template parameter (can repeat)",
    )
    p_commands_register.set_defaults(func=cmd_register)

    # commands unregister
    p_commands_unregister = commands_subparsers.add_parser(
        "unregister", help="Remove a registered command"
    )
    p_commands_unregister.add_argument("name", help="Command name to remove")
    p_commands_unregister.set_defaults(func=cmd_unregister)

    # commands suggest (for Claude Code hooks)
    p_commands_suggest = commands_subparsers.add_parser(
        "suggest",
        help="Suggest a registered command matching a given command string",
    )
    p_commands_suggest.add_argument(
        "command", help="Command string to match against registered commands"
    )
    p_commands_suggest.add_argument(
        "--json", "-j", action="store_true", help="Output as JSON (for hooks)"
    )
    p_commands_suggest.set_defaults(func=cmd_suggest)

    # commands config (modify command settings including suppress)
    from blq.commands.management_cmd import cmd_commands_config

    p_commands_config = commands_subparsers.add_parser(
        "config", help="Configure a registered command's settings"
    )
    p_commands_config.add_argument("name", help="Command name to configure")
    p_commands_config.add_argument(
        "--suppress-event",
        "-e",
        action="append",
        default=[],
        metavar="REF",
        help="Add fingerprint of event ref to suppress list (e.g., build:12:1)",
    )
    p_commands_config.add_argument(
        "--suppress-fp",
        "-f",
        action="append",
        default=[],
        metavar="FINGERPRINT",
        help="Add fingerprint directly to suppress list",
    )
    p_commands_config.add_argument(
        "--unsuppress-fp",
        "-u",
        action="append",
        default=[],
        metavar="FINGERPRINT",
        help="Remove fingerprint from suppress list",
    )
    p_commands_config.add_argument(
        "--list",
        "-l",
        action="store_true",
        help="List current suppressed fingerprints",
    )
    p_commands_config.add_argument(
        "--clear-suppress",
        action="store_true",
        help="Clear all suppressed fingerprints",
    )
    p_commands_config.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_commands_config.set_defaults(func=cmd_commands_config)

    # Default: commands without subcommand shows list
    def commands_default(args: argparse.Namespace) -> None:
        """Default handler for 'blq commands' - show list."""
        cmd_commands(args)

    p_commands.set_defaults(func=commands_default)

    # sync
    p_sync = subparsers.add_parser("sync", help="Sync project logs to central location")
    p_sync.add_argument(
        "destination", nargs="?", help="Destination path", default=GLOBAL_PROJECTS_PATH
    )
    p_sync.add_argument(
        "--soft", "-s", action="store_true", default=True, help="Create symlink (default)"
    )
    p_sync.add_argument("--hard", "-H", action="store_true", help="Copy files instead of symlink")
    p_sync.add_argument("--force", "-f", action="store_true", help="Replace existing sync target")
    p_sync.add_argument(
        "--dry-run", "-n", action="store_true", help="Show what would be done without doing it"
    )
    p_sync.add_argument("--status", action="store_true", help="Show current sync status")
    p_sync.add_argument("--verbose", "-v", action="store_true", help="Verbose output")
    p_sync.set_defaults(func=cmd_sync)

    # migrate
    p_migrate = subparsers.add_parser("migrate", help="Migrate data between storage formats")
    p_migrate.add_argument(
        "--to-bird",
        action="store_true",
        help="Migrate parquet data to BIRD storage format",
    )
    p_migrate.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be migrated without making changes",
    )
    p_migrate.add_argument(
        "--keep-parquet",
        action="store_true",
        help="Keep parquet files after migration",
    )
    p_migrate.add_argument(
        "--force",
        "-f",
        action="store_true",
        help="Force migration even if already using BIRD mode",
    )
    p_migrate.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Show detailed progress",
    )
    p_migrate.set_defaults(func=cmd_migrate)

    # clean (database cleanup and maintenance)
    p_clean = subparsers.add_parser("clean", help="Database cleanup and maintenance")
    clean_subparsers = p_clean.add_subparsers(dest="clean_command", help="Cleanup mode")

    # clean data - clear run data, keep config
    p_clean_data = clean_subparsers.add_parser(
        "data", help="Clear run data, keep config and commands"
    )
    p_clean_data.add_argument(
        "--confirm", "-y", action="store_true", help="Confirm destructive operation"
    )

    # clean prune - remove old data
    p_clean_prune = clean_subparsers.add_parser("prune", help="Remove data older than N days")
    p_clean_prune.add_argument(
        "--days", "-d", type=int, default=None, help="Remove data older than N days"
    )
    p_clean_prune.add_argument(
        "--max-runs", type=int, default=None, help="Keep at most N runs per source"
    )
    p_clean_prune.add_argument(
        "--max-size", type=int, default=None, help="Keep total output under N MB"
    )
    p_clean_prune.add_argument(
        "--confirm", "-y", action="store_true", help="Confirm destructive operation"
    )
    p_clean_prune.add_argument(
        "--dry-run", "-n", action="store_true", help="Show what would be removed without removing"
    )

    # clean orphans - mark stale pending runs as orphaned
    p_clean_orphans = clean_subparsers.add_parser(
        "orphans", help="Mark stale pending runs as orphaned"
    )
    p_clean_orphans.add_argument(
        "--min-age",
        type=int,
        default=60,
        help="Minimum age in seconds before considering stale (default: 60)",
    )
    p_clean_orphans.add_argument(
        "--dry-run", "-n", action="store_true", help="Show stale runs without marking them"
    )

    # clean schema - recreate database schema
    p_clean_schema = clean_subparsers.add_parser("schema", help="Recreate database schema")
    p_clean_schema.add_argument(
        "--confirm", "-y", action="store_true", help="Confirm destructive operation"
    )

    # clean full - full reset
    p_clean_full = clean_subparsers.add_parser("full", help="Delete and recreate .lq directory")
    p_clean_full.add_argument(
        "--confirm", "-y", action="store_true", help="Confirm destructive operation"
    )

    from blq.commands.clean_cmd import cmd_clean

    p_clean.set_defaults(func=cmd_clean)

    # query (with alias 'q')
    p_query = subparsers.add_parser("query", aliases=["q"], help="Query log files or stored events")
    p_query.add_argument("files", nargs="*", help="Log file(s) to query (omit for stored data)")
    p_query.add_argument("-s", "--select", help="Columns to select (comma-separated)")
    p_query.add_argument("-f", "--filter", help="SQL WHERE clause")
    p_query.add_argument("-o", "--order", help="SQL ORDER BY clause")
    p_query.add_argument("-n", "--limit", type=int, help="Max rows to return")
    p_query.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_query.add_argument("--csv", action="store_true", help="Output as CSV")
    p_query.add_argument("--markdown", "--md", action="store_true", help="Output as Markdown table")
    p_query.set_defaults(func=cmd_query)

    # filter (with alias 'f')
    p_filter = subparsers.add_parser(
        "filter", aliases=["f"], help="Filter log files with simple syntax"
    )
    p_filter.add_argument("args", nargs="*", help="Filter expressions and/or file(s)")
    p_filter.add_argument("-v", "--invert", action="store_true", help="Invert match (like grep -v)")
    p_filter.add_argument("-c", "--count", action="store_true", help="Only print count of matches")
    p_filter.add_argument(
        "-i", "--ignore-case", action="store_true", help="Case insensitive matching"
    )
    p_filter.add_argument("-n", "--limit", type=int, help="Max rows to return")
    p_filter.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_filter.add_argument("--csv", action="store_true", help="Output as CSV")
    p_filter.add_argument(
        "--markdown", "--md", action="store_true", help="Output as Markdown table"
    )
    p_filter.set_defaults(func=cmd_filter)

    # mcp (MCP server commands)
    p_mcp = subparsers.add_parser("mcp", help="MCP server commands")
    mcp_subparsers = p_mcp.add_subparsers(dest="mcp_command", help="MCP subcommands")

    # mcp install
    p_mcp_install = mcp_subparsers.add_parser(
        "install", help="Create or update .mcp.json configuration"
    )
    p_mcp_install.add_argument(
        "--force", "-f", action="store_true", help="Overwrite existing blq config"
    )
    # Mutually exclusive hooks flags
    mcp_hooks_group = p_mcp_install.add_mutually_exclusive_group()
    mcp_hooks_group.add_argument(
        "--hooks",
        action="store_true",
        dest="hooks",
        default=None,
        help="Install Claude Code hooks (overrides hooks.auto_claude_code config)",
    )
    mcp_hooks_group.add_argument(
        "--no-hooks",
        action="store_false",
        dest="hooks",
        help="Skip Claude Code hooks (overrides hooks.auto_claude_code config)",
    )
    p_mcp_install.set_defaults(func=cmd_mcp_install)

    # mcp serve
    p_mcp_serve = mcp_subparsers.add_parser(
        "serve", help="Start MCP server for AI agent integration"
    )
    p_mcp_serve.add_argument(
        "--transport",
        "-t",
        choices=["stdio", "sse"],
        default="stdio",
        help="Transport type (default: stdio)",
    )
    p_mcp_serve.add_argument(
        "--port", "-p", type=int, default=8080, help="Port for SSE transport (default: 8080)"
    )
    p_mcp_serve.add_argument(
        "--disabled-tools",
        "-D",
        type=str,
        help="Comma-separated list of tools to disable (e.g., 'exec,clean')",
    )
    p_mcp_serve.add_argument(
        "--safe-mode",
        "-S",
        action="store_true",
        help="Disable tools that modify state (exec, clean, register_command, unregister_command)",
    )
    p_mcp_serve.set_defaults(func=cmd_mcp_serve)

    # =========================================================================
    # Config command
    # =========================================================================

    p_config = subparsers.add_parser("config", help="Manage user configuration")
    p_config.add_argument(
        "--path",
        action="store_true",
        help="Show config file path",
    )
    p_config.add_argument(
        "--edit",
        action="store_true",
        help="Open config in $EDITOR",
    )
    p_config.add_argument(
        "--all",
        action="store_true",
        help="Show all settings including defaults",
    )
    p_config.add_argument(
        "--json",
        "-j",
        action="store_true",
        help="Output as JSON",
    )

    config_subparsers = p_config.add_subparsers(dest="config_subcommand", help="Config subcommand")

    # config get
    p_config_get = config_subparsers.add_parser("get", help="Get a config value")
    p_config_get.add_argument("key", help="Config key (e.g., init.auto_mcp)")
    p_config_get.add_argument("--json", "-j", action="store_true", help="Output as JSON")

    # config set
    p_config_set = config_subparsers.add_parser("set", help="Set a config value")
    p_config_set.add_argument("key", help="Config key (e.g., init.auto_mcp)")
    p_config_set.add_argument("value", help="Value to set")

    # config unset
    p_config_unset = config_subparsers.add_parser(
        "unset", help="Unset a config value (revert to default)"
    )
    p_config_unset.add_argument("key", help="Config key to unset")

    p_config.set_defaults(func=cmd_config)

    # =========================================================================
    # Hooks commands
    # =========================================================================

    p_hooks = subparsers.add_parser("hooks", help="Hook script generation and installation")
    hooks_subparsers = p_hooks.add_subparsers(dest="hooks_command", help="Hooks subcommands")

    # hooks generate
    p_hooks_generate = hooks_subparsers.add_parser(
        "generate", help="Generate hook scripts from registered commands"
    )
    p_hooks_generate.add_argument(
        "commands", nargs="+", help="Command names to generate scripts for"
    )
    p_hooks_generate.add_argument(
        "--force", "-f", action="store_true", help="Overwrite existing scripts"
    )
    p_hooks_generate.set_defaults(func=cmd_hooks_generate)

    # hooks install
    p_hooks_install = hooks_subparsers.add_parser(
        "install", help="Install hooks to a target (git, github, gitlab, drone, claude-code)"
    )
    p_hooks_install.add_argument(
        "target",
        nargs="?",
        default="git",
        help="Installation target: git, github, gitlab, drone, claude-code (default: git)",
    )
    p_hooks_install.add_argument(
        "commands", nargs="*", help="Command names to install (required for new-style install)"
    )
    p_hooks_install.add_argument(
        "--hook", default="pre-commit", help="Git hook name (default: pre-commit)"
    )
    p_hooks_install.add_argument(
        "--force", "-f", action="store_true", help="Overwrite existing hook/workflow"
    )
    # Claude Code record hooks options
    p_hooks_install.add_argument(
        "--record",
        "-R",
        action="store_true",
        help="Install record-invocation hooks for passive command tracking (claude-code only)",
    )
    p_hooks_install.add_argument(
        "--record-hooks",
        metavar="HOOKS",
        help="Comma-separated record hooks to install: pre,post (default: both)",
    )
    p_hooks_install.set_defaults(func=cmd_hooks_install)

    # hooks uninstall (new name, was 'remove')
    p_hooks_uninstall = hooks_subparsers.add_parser(
        "uninstall", help="Remove installed hooks from a target"
    )
    p_hooks_uninstall.add_argument(
        "target",
        nargs="?",
        default="git",
        help="Target to uninstall from: git, github, gitlab, drone, claude-code (default: git)",
    )
    p_hooks_uninstall.add_argument(
        "--hook", default="pre-commit", help="Git hook name (default: pre-commit)"
    )
    p_hooks_uninstall.add_argument(
        "--record",
        "-R",
        action="store_true",
        help="Uninstall record-invocation hooks (claude-code only)",
    )
    p_hooks_uninstall.set_defaults(func=cmd_hooks_uninstall)

    # hooks remove (alias for uninstall, backward compat)
    p_hooks_remove = hooks_subparsers.add_parser("remove", help="Remove git pre-commit hook")
    p_hooks_remove.set_defaults(func=cmd_hooks_remove)

    # hooks status
    p_hooks_status = hooks_subparsers.add_parser(
        "status", help="Show hook scripts and installation status"
    )
    p_hooks_status.set_defaults(func=cmd_hooks_status)

    # =========================================================================
    # Watch command
    # =========================================================================

    p_watch = subparsers.add_parser("watch", help="Watch for changes and re-run commands")
    p_watch.add_argument("commands", nargs="*", help="Commands to run (default: all registered)")
    p_watch.add_argument(
        "--include",
        "-i",
        action="append",
        default=[],
        help="Glob patterns to watch (can be repeated)",
    )
    p_watch.add_argument(
        "--exclude",
        "-e",
        action="append",
        default=[],
        help="Glob patterns to ignore (can be repeated)",
    )
    p_watch.add_argument(
        "--debounce",
        "-d",
        type=int,
        default=None,
        help="Debounce delay in milliseconds (default: 500)",
    )
    p_watch.add_argument(
        "--quiet", "-q", action="store_true", help="Suppress command output, show only status"
    )
    p_watch.add_argument("--clear", "-c", action="store_true", help="Clear screen between runs")
    p_watch.add_argument(
        "--once", action="store_true", help="Run once on startup then exit (useful for testing)"
    )
    p_watch.set_defaults(func=cmd_watch)

    # =========================================================================
    # CI commands
    # =========================================================================

    p_ci = subparsers.add_parser("ci", help="CI integration commands")
    ci_subparsers = p_ci.add_subparsers(dest="ci_command", help="CI subcommand")

    # ci check
    p_ci_check = ci_subparsers.add_parser("check", help="Check for new errors vs baseline")
    p_ci_check.add_argument(
        "--baseline", "-b", help="Baseline (run ID, branch name, or commit SHA)"
    )
    p_ci_check.add_argument(
        "--fail-on-any", action="store_true", help="Fail if any errors (no baseline comparison)"
    )
    p_ci_check.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    p_ci_check.set_defaults(func=cmd_ci_check)

    # ci comment
    p_ci_comment = ci_subparsers.add_parser("comment", help="Post error summary as PR comment")
    p_ci_comment.add_argument(
        "--update",
        "-u",
        action="store_true",
        help="Update existing comment instead of creating new",
    )
    p_ci_comment.add_argument("--diff", "-d", action="store_true", help="Include diff vs baseline")
    p_ci_comment.add_argument(
        "--baseline", "-b", help="Baseline for diff (run ID, branch, or commit)"
    )
    p_ci_comment.set_defaults(func=cmd_ci_comment)

    # ci generate
    p_ci_generate = ci_subparsers.add_parser(
        "generate", help="Generate standalone shell scripts for CI"
    )
    p_ci_generate.add_argument(
        "commands",
        nargs="*",
        help="Commands to generate scripts for (default: all)",
    )
    p_ci_generate.add_argument(
        "--output", "-o", default=".", help="Output directory for scripts (default: .)"
    )
    p_ci_generate.add_argument(
        "--shell", "-s", default="bash", choices=["bash", "sh", "zsh"], help="Shell to use"
    )
    p_ci_generate.add_argument(
        "--force", "-f", action="store_true", help="Overwrite existing scripts"
    )
    p_ci_generate.add_argument(
        "--dry-run", "-n", action="store_true", help="Show scripts without writing"
    )
    p_ci_generate.set_defaults(func=cmd_ci_generate)

    def ci_help(args: argparse.Namespace) -> None:
        """Show help for ci command."""
        p_ci.print_help()

    p_ci.set_defaults(func=ci_help)

    # =========================================================================
    # Record invocation command (for passive tracking via hooks)
    # =========================================================================

    from blq.commands.record_cmd import (
        cmd_record_attempt,
        cmd_record_help,
        cmd_record_outcome,
    )

    p_record = subparsers.add_parser(
        "record-invocation",
        help="Record invocation metadata for passive tracking",
    )
    record_subparsers = p_record.add_subparsers(dest="record_command", help="Record subcommands")

    # record-invocation attempt
    p_record_attempt = record_subparsers.add_parser(
        "attempt", help="Record command start (returns attempt_id)"
    )
    p_record_attempt.add_argument("--command", "-c", required=True, help="Command string")
    p_record_attempt.add_argument("--tag", "-t", help="Tag for grouping")
    p_record_attempt.add_argument("--format", "-F", help="Expected log format")
    p_record_attempt.add_argument("--cwd", help="Working directory")
    p_record_attempt.add_argument("--pid", type=int, help="Process ID of the command")
    p_record_attempt.add_argument("--json", "-j", action="store_true", help="Output JSON")
    p_record_attempt.set_defaults(func=cmd_record_attempt)

    # record-invocation outcome
    p_record_outcome = record_subparsers.add_parser("outcome", help="Record command completion")
    p_record_outcome.add_argument("--attempt", "-a", help="Attempt ID to complete")
    p_record_outcome.add_argument("--command", "-c", help="Command (if no prior attempt)")
    p_record_outcome.add_argument(
        "--exit", "-e", type=int, default=0, dest="exit", help="Exit code"
    )
    p_record_outcome.add_argument("--duration", "-d", type=int, help="Duration in milliseconds")
    p_record_outcome.add_argument("--pid", type=int, help="Process ID of the command")
    p_record_outcome.add_argument(
        "--parse", "-p", action="store_true", help="Parse output for events"
    )
    p_record_outcome.add_argument("--format", "-F", help="Parser format")
    p_record_outcome.add_argument("--tag", "-t", help="Tag (if no prior attempt)")
    p_record_outcome.add_argument("--output", "-o", help="Read output from file instead of stdin")
    p_record_outcome.add_argument("--json", "-j", action="store_true", help="Output JSON")
    p_record_outcome.set_defaults(func=cmd_record_outcome)

    # Default handler for 'blq record-invocation' without subcommand
    p_record.set_defaults(func=cmd_record_help)

    # =========================================================================
    # Report command
    # =========================================================================

    p_report = subparsers.add_parser(
        "report", help="Generate markdown report of build/test results"
    )
    p_report.add_argument("--run", "-r", type=int, help="Run ID to report on (default: latest)")
    p_report.add_argument(
        "--baseline", "-b", help="Baseline for comparison (run ID or branch name)"
    )
    p_report.add_argument("--output", "-o", help="Output file (default: stdout)")
    p_report.add_argument("--warnings", "-w", action="store_true", help="Include warning details")
    p_report.add_argument(
        "--summary-only",
        "-s",
        action="store_true",
        help="Summary only, no individual error details",
    )
    p_report.add_argument(
        "--error-limit", "-n", type=int, default=20, help="Max errors to include (default: 20)"
    )
    p_report.add_argument(
        "--file-limit", "-f", type=int, default=10, help="Max files in breakdown (default: 10)"
    )
    p_report.set_defaults(func=cmd_report)

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Handle -C/--dir: change to specified directory before running command
    import os
    from pathlib import Path

    if getattr(args, "change_dir", None):
        change_dir = Path(args.change_dir).expanduser()
        if not change_dir.exists():
            print(f"Error: Directory does not exist: {change_dir}", file=sys.stderr)
            sys.exit(1)
        if not change_dir.is_dir():
            print(f"Error: Not a directory: {change_dir}", file=sys.stderr)
            sys.exit(1)
        os.chdir(change_dir)

    args.func(args)


if __name__ == "__main__":
    main()
