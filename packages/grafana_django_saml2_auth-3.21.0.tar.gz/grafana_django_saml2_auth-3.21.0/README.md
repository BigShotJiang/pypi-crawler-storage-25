# grafana-django-saml2-auth
This package name is deprecated and kept only as a compatibility shim.
Please install:
```bash
pip install django-saml2-auth-community
```
`grafana-django-saml2-auth==3.21.0` depends on `django-saml2-auth-community==3.21.0`.
