#!/usr/bin/env python3
import sys
import os

import click
from core import ui, git, config, state, network
from commands import setup as setup_mod
from commands import doctor as doctor_mod
from commands import workflow
from commands.register import manage_custom_files


def get_repo_path():
    return os.getcwd()


def _require_git_repo(repo_path):
    if not git.is_git_repo(repo_path):
        ui.error(f"Not a Git repository: {repo_path}")
        ui.info("cd into your project folder first, then run: fflow")
        sys.exit(1)


def _require_config(repo_path):
    if not config.config_exists(repo_path):
        ui.blank()
        ui.header("Welcome to fflow!")
        ui.info("fflow is not set up yet for this repository.")
        ui.blank()
        if ui.confirm("Run setup now?"):
            setup_mod.run(repo_path)
        else:
            ui.info("Run: fflow setup — when you are ready.")
        sys.exit(0)


def _handle_paused_sync(repo_path, current_state):
    ui.blank()
    ui.warning("fflow sync is currently PAUSED — waiting for conflict resolution.")
    ui.blank()
    conflicted = current_state.get("conflicted_files", [])
    if conflicted:
        ui.info("Conflicted file(s) still unresolved:")
        for f in conflicted:
            print(f"    {f}")
    ui.blank()

    idx = ui.choose(
        "What do you want to do?",
        ["Continue (conflicts resolved)", "Abort sync (go back to pre-sync state)"]
    )

    if idx == 1:
        workflow.step_sync_abort(repo_path, current_state)
        return

    still_conflicted = git.get_conflicted_files(repo_path)
    if still_conflicted:
        ui.error("Conflicts are still unresolved. Please fix them first.")
        ui.paused_notice(still_conflicted)
        return

    workflow.step_sync_continue(repo_path, current_state)


def _switch_to_existing_branch(repo_path):
    parent_branches = config.load_config(repo_path).get("parent_branches", [])
    branches = git.get_all_feature_branches(repo_path, parent_branches)

    if not branches:
        ui.error("No existing feature branches found locally or on remote.")
        return

    ui.blank()
    options = branches + ["Cancel"]
    idx = ui.choose("Select a branch to switch to:", options)
    if idx == len(branches):
        ui.aborted()
        return

    target = branches[idx]
    if not workflow._handle_dirty_working_tree(repo_path, f"switching to '{target}'"):
        return

    ok = git.checkout_branch(repo_path, target)
    if not ok:
        ui.error(f"Failed to switch to '{target}'. Check git status manually.")
        return

    ui.success(f"Switched to '{target}'.")

    jira_id, parsed_parent = workflow._parse_feature_branch(target)
    if not jira_id:
        ui.warning("Could not parse Jira ID from branch name — state not set.")
        ui.info("Run: fflow  to start a task manually.")
        return

    configured_parents = config.load_config(repo_path).get("parent_branches", [])

    # Confirm or correct the parent branch
    if parsed_parent not in configured_parents:
        ui.blank()
        ui.warning(f"Could not detect parent branch from '{target}' — please select:")
        idx = ui.choose("Select the correct parent branch:", configured_parents)
        parsed_parent = configured_parents[idx]

    baseline = git.get_remote_head_commit(repo_path, parsed_parent)
    state.save_state(repo_path, {
        "jira_id": jira_id,
        "parent_branch": parsed_parent,
        "baseline_commit": baseline,
        "phase": "ready_for_export"
    })
    ui.info(f"Task state set — Jira: {jira_id}, Parent: {parsed_parent}.")
    ui.info("Run: fflow  to continue.")


def _run_main_flow(repo_path):
    reachable, host = network.check_gitlab_reachable(repo_path)
    if not reachable:
        ui.error(f"Cannot reach GitLab ({host}) — check your network/VPN connection and try again.")
        return

    current_state = state.load_state(repo_path)
    phase = current_state.get("phase", "no_task")
    branch = git.current_branch(repo_path)

    if not git.fetch_origin(repo_path):
        ui.error("Could not reach GitLab — check your network/VPN connection and try again.")
        return

    if phase == "paused_sync" or git.is_rebase_in_progress(repo_path):
        _handle_paused_sync(repo_path, current_state)
        return


    if phase == "no_task" or not current_state:
        if not _is_on_feature_branch(repo_path, branch):
            fflow_files = {".fflow.json", ".fflow.env", ".fflow_state.json", ".fflow_registry.json", ".gitignore"}
            staged = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in fflow_files]
            unstaged = [f for f in (
                git.get_modified_unstaged_files(repo_path) + git.get_untracked_files(repo_path)
            ) if os.path.basename(f) not in fflow_files]
            all_changed = list(dict.fromkeys(staged + unstaged))

            if all_changed:
                ui.blank()
                if staged and not unstaged:
                    ui.warning(f"You have {len(staged)} staged file(s) on '{branch}' with no active task.")
                elif staged:
                    ui.warning(f"You have {len(staged)} staged + {len(unstaged)} unstaged file change(s) on '{branch}' with no active task.")
                else:
                    ui.warning(f"You have {len(unstaged)} unstaged file change(s) on '{branch}' with no active task.")
                for f in all_changed[:10]:
                    tag = " (staged)" if f in staged else " (unstaged)"
                    print(f"    {f}{tag}")
                if len(all_changed) > 10:
                    print(f"    ... and {len(all_changed) - 10} more")
                ui.blank()

                options = []
                if staged:
                    options.append("Start a new task and commit these staged files")
                options.append("Start a new task and use all these changes (skip export)")
                options.append("Start a new task (discard existing changes)")
                options.append("Switch to an existing branch")
                options.append("Manage custom files")

                idx = ui.choose("What do you want to do?", options)
                chosen = options[idx]

                if chosen == "Manage custom files":
                    manage_custom_files(repo_path)
                    return
                if chosen == "Switch to an existing branch":
                    _switch_to_existing_branch(repo_path)
                    return
                if chosen == "Start a new task and commit these staged files":
                    workflow.step_start(repo_path, skip_export=True, skip_to_push=True)
                    return
                if chosen == "Start a new task and use all these changes (skip export)":
                    workflow.step_start(repo_path, skip_export=True)
                    return
                # discard and start fresh
                if not ui.confirm("This will discard all existing changes. Are you sure?"):
                    ui.aborted()
                    return
                workflow.step_start(repo_path)
                return
            else:
                parent_branches = config.load_config(repo_path).get("parent_branches", [])
                ui.blank()
                ui.info(f"You are on '{branch}' — everything is up to date.")
                options = ["Start a new task (enter Jira ID)", "Run FlutterFlow export first, then start task", "Switch to an existing branch", "Manage custom files"]
                if len(parent_branches) > 1:
                    options.insert(2, "Switch parent branch")
                idx = ui.choose("What do you want to do?", options)
                chosen = options[idx]
                if chosen == "Manage custom files":
                    manage_custom_files(repo_path)
                    return
                if chosen == "Switch to an existing branch":
                    _switch_to_existing_branch(repo_path)
                    return
                if chosen == "Switch parent branch":
                    other = [b for b in parent_branches if b != branch]
                    pidx = ui.choose("Switch to which parent branch?", other + ["Cancel"])
                    if pidx < len(other):
                        if not workflow._handle_dirty_working_tree(repo_path, f"switching to '{other[pidx]}'"):
                            return
                        ok = git.checkout_branch(repo_path, other[pidx])
                        if ok:
                            ui.success(f"Switched to '{other[pidx]}'. Run: fflow  to start a task.")
                        else:
                            ui.error(f"Failed to switch to '{other[pidx]}'.")
                    return
                if chosen == "Run FlutterFlow export first, then start task":
                    workflow.step_start(repo_path, run_export_first=True)
                    return
                workflow.step_start(repo_path)
                return
        else:
            jira_id, parent_branch = workflow._parse_feature_branch(branch)
            if jira_id and parent_branch:
                ui.blank()
                ui.warning(f"You are on branch '{branch}' but no active fflow task found.")
                idx = ui.choose(
                    "What do you want to do?",
                    [
                        f"Resume work on this branch (Jira: {jira_id}, Parent: {parent_branch})",
                        "Switch to another existing branch",
                        "Start a new task (new Jira ID)",
                        "Abort"
                    ]
                )
                if idx == 3:
                    ui.aborted()
                    return
                if idx == 2:
                    workflow.step_start(repo_path)
                    return
                if idx == 1:
                    _switch_to_existing_branch(repo_path)
                    return
                baseline = git.get_remote_head_commit(repo_path, parent_branch)
                state.save_state(repo_path, {
                    "jira_id": jira_id,
                    "parent_branch": parent_branch,
                    "baseline_commit": baseline,
                    "phase": "ready_for_export"
                })
                current_state = state.load_state(repo_path)
                phase = "ready_for_export"
            else:
                workflow.step_start(repo_path)
                return

    jira_id = current_state.get("jira_id", "")
    parent_branch = current_state.get("parent_branch", "")
    expected_branch = workflow._expected_branch_name(jira_id, parent_branch)

    if branch != expected_branch:
        exists_local = git.branch_exists_local(repo_path, expected_branch)
        exists_remote = git.branch_exists_remote_tracking(repo_path, expected_branch)

        if not exists_local and not exists_remote and branch.startswith(jira_id + "-"):
            ui.info(f"Using branch '{branch}' for task '{jira_id}'.")
            current_state["phase"] = current_state.get("phase", "ready_for_export")
            state.save_state(repo_path, current_state)
            expected_branch = branch

        elif exists_local or exists_remote:
            idx = ui.choose(
                "What do you want to do?",
                [
                    f"Switch to '{expected_branch}' (continue existing task)",
                    f"Start a new task from '{branch}'",
                    "Abort"
                ]
            )
            if idx == 2:
                ui.aborted()
                return
            if idx == 1:
                state.clear_state(repo_path)
                workflow.step_start(repo_path)
                return
            if not exists_local:
                ui.info(f"Checking out '{expected_branch}' from remote...")
            if not workflow._handle_dirty_working_tree(repo_path, f"switching to '{expected_branch}'"):
                return
            ok = git.checkout_branch(repo_path, expected_branch)
            if not ok:
                ui.error(f"Failed to switch to '{expected_branch}'. Check git status manually.")
                return
        else:
            ui.warning(f"Branch '{expected_branch}' does not exist locally or remotely.")
            idx = ui.choose(
                "What do you want to do?",
                [
                    f"Create branch '{expected_branch}' now (continue existing task)",
                    f"Start a new task from '{branch}'",
                    "Clear saved state and start fresh",
                    "Abort"
                ]
            )
            if idx == 3:
                ui.aborted()
                return
            if idx == 1:
                state.clear_state(repo_path)
                workflow.step_start(repo_path)
                return
            if idx == 2:
                state.clear_state(repo_path)
                ui.success("State cleared. Run: fflow")
                return
            if not workflow._handle_dirty_working_tree(repo_path, f"creating branch '{expected_branch}'"):
                return
            ok = git.checkout_branch(repo_path, expected_branch, create=True, start_point=parent_branch)
            if not ok:
                ui.error(f"Failed to create '{expected_branch}'. Check git status manually.")
                return

        if branch != expected_branch:
            ui.success(f"On branch '{expected_branch}'.")
        branch = expected_branch

    if git.has_staged_files(repo_path) and phase not in ("ready_for_push", "ready_for_mine"):
        staged = git.get_staged_files(repo_path)
        ui.blank()
        ui.warning(f"You have {len(staged)} staged but uncommitted file(s).")
        idx = ui.choose(
            "What do you want to do?",
            ["Continue to push/commit these staged files", "Unstage all and continue from export", "Abort"]
        )
        if idx == 2:
            ui.aborted()
            return
        if idx == 0:
            current_state["phase"] = "ready_for_push"
            state.save_state(repo_path, current_state)
            phase = "ready_for_push"
        elif idx == 1:
            git.unstage_files(repo_path, staged)

    baseline = current_state.get("baseline_commit")
    has_new, count = git.parent_has_new_commits(repo_path, parent_branch, baseline)

    if has_new and phase == "ready_for_push":
        ui.blank()
        ui.warning(f"Parent branch '{parent_branch}' has {count} new commit(s) since you last synced.")
        if ui.confirm("Sync now before pushing? (recommended)"):
            synced = workflow.step_sync(repo_path, current_state, return_phase="ready_for_push")
            if not synced:
                return
            current_state = state.load_state(repo_path)

    if phase == "ready_for_export":
        ok = workflow.step_export(repo_path, current_state)
        if ok:
            current_state = state.load_state(repo_path)
            _try_next_step(repo_path, current_state)

    elif phase == "ready_for_mine":
        if has_new:
            ui.blank()
            ui.warning(f"Parent branch '{parent_branch}' has {count} new commit(s).")
            if ui.confirm("Sync with parent branch before selecting files?"):
                synced = workflow.step_sync(repo_path, current_state, return_phase="ready_for_mine")
                if not synced:
                    return
                current_state = state.load_state(repo_path)
        workflow.step_mine(repo_path, current_state)

    elif phase == "ready_for_push":
        workflow.step_push(repo_path, current_state)

    else:
        ui.error(f"Unknown phase: {phase}. Run: fflow doctor")


def _try_next_step(repo_path, current_state):
    phase = current_state.get("phase")
    if phase == "ready_for_mine":
        workflow.step_mine(repo_path, current_state)


def _is_on_feature_branch(repo_path, branch):
    parent_branches = config.load_config(repo_path).get("parent_branches", [])
    if branch in parent_branches:
        return False
    jira_id, _ = workflow._parse_feature_branch(branch)
    return jira_id is not None


# ─── CLI ──────────────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """fflow — FlutterFlow Git workflow automation tool.

    Run without a subcommand to continue your current task.
    """
    if ctx.invoked_subcommand is None:
        repo_path = get_repo_path()
        _require_git_repo(repo_path)
        _require_config(repo_path)
        _run_main_flow(repo_path)


@cli.command()
def setup():
    """Set up fflow for this repository."""
    repo_path = get_repo_path()
    _require_git_repo(repo_path)
    setup_mod.run(repo_path)


@cli.command()
def doctor():
    """Run diagnostics and check fflow configuration."""
    repo_path = get_repo_path()
    _require_git_repo(repo_path)
    doctor_mod.run(repo_path)


@cli.command()
def status():
    """Show current task phase and branch info."""
    repo_path = get_repo_path()
    _require_git_repo(repo_path)
    current_state = state.load_state(repo_path)
    branch = git.current_branch(repo_path)

    ui.blank()
    ui.header("fflow — Status")
    if not current_state:
        ui.warning("No active fflow task.")
        ui.info("Run: fflow setup  or  fflow run  to start.")
        return

    phase = current_state.get("phase", "unknown")
    jira_id = current_state.get("jira_id", "—")
    parent_branch = current_state.get("parent_branch", "—")

    phase_labels = {
        "ready_for_export": "Waiting for FlutterFlow export",
        "ready_for_mine":   "Waiting for file selection",
        "ready_for_push":   "Waiting for commit & push",
        "paused_sync":      "Sync paused — conflicts to resolve",
    }

    print(f"  Branch      : {branch}")
    print(f"  Jira ID     : {jira_id}")
    print(f"  Parent      : {parent_branch}")
    print(f"  Phase       : {phase_labels.get(phase, phase)}")
    ui.blank()
    ui.info("Run: fflow  to continue.")


if __name__ == "__main__":
    cli()
