import sys

DIVIDER = "━" * 50
THIN_DIVIDER = "─" * 50


def header(title):
    print(f"\n{DIVIDER}")
    print(f" {title}")
    print(f"{DIVIDER}")


def section(title):
    print(f"\n{title}")
    print(THIN_DIVIDER)


def info(msg):
    print(f"  → {msg}")


def success(msg):
    print(f"  ✔ {msg}")


def warning(msg):
    print(f"  ⚠ {msg}")


def error(msg):
    print(f"  ✖ {msg}")


def step(msg):
    print(f"\n[fflow] {msg}")


def blank():
    print()


def confirm(prompt):
    """Ask y/n. Returns True for y, False for n."""
    while True:
        answer = input(f"  {prompt} (y/n): ").strip().lower()
        if answer in ("y", "yes"):
            return True
        if answer in ("n", "no"):
            return False
        print("  Please enter y or n.")


def confirm_strong(prompt, confirm_word="CONFIRM"):
    """For dangerous actions — requires typing a specific word."""
    print(f"  ⚠ {prompt}")
    answer = input(f"  Type '{confirm_word}' to proceed, or anything else to abort: ").strip()
    return answer == confirm_word


def choose(prompt, options):
    """
    Present numbered options. Returns the index (0-based) of chosen option.
    options: list of strings
    """
    print(f"\n  {prompt}")
    for i, opt in enumerate(options, 1):
        print(f"    [{i}] {opt}")
    while True:
        answer = input("  Choice: ").strip()
        if answer.isdigit() and 1 <= int(answer) <= len(options):
            return int(answer) - 1
        print(f"  Please enter a number between 1 and {len(options)}.")


def choose_multiple(prompt, options):
    """
    Present numbered options, allow multi-select (e.g. '1,3' or 'all').
    Returns list of 0-based indices.
    """
    print(f"\n  {prompt}")
    for i, opt in enumerate(options, 1):
        print(f"    [{i}] {opt}")
    print("  (enter numbers separated by comma, or 'all')")
    while True:
        answer = input("  Selection: ").strip().lower()
        if answer == "all":
            return list(range(len(options)))
        parts = [p.strip() for p in answer.replace(",", " ").split()]
        indices = []
        valid = True
        for p in parts:
            if p.isdigit() and 1 <= int(p) <= len(options):
                indices.append(int(p) - 1)
            else:
                valid = False
                break
        if valid and indices:
            return indices
        print(f"  Please enter valid numbers between 1 and {len(options)}, or 'all'.")


def ask(prompt, validator=None, hint=None):
    """Free text input with optional validator."""
    if hint:
        print(f"  ({hint})")
    while True:
        answer = input(f"  {prompt}: ").strip()
        if not answer:
            print("  Input cannot be empty.")
            continue
        if validator:
            ok, msg = validator(answer)
            if not ok:
                error(msg)
                continue
        return answer


def print_file_list(title, files):
    if not files:
        return
    section(title)
    for f in files:
        print(f"    {f}")
    print(THIN_DIVIDER)
    print(f"  Total: {len(files)} file(s)")


def aborted(msg="Nothing changed."):
    print(f"\n  Aborted. {msg}")


def paused_notice(conflicted_files):
    print(f"\n{DIVIDER}")
    print("  ACTION REQUIRED:")
    print()
    print("  Resolve conflicts in the following file(s):")
    for f in conflicted_files:
        print(f"    {f}")
    print()
    print("  Look for and fix all <<<<<<< ======= >>>>>>> markers.")
    print()
    print("  Once done, run:   fflow")
    print("  To cancel:        fflow --abort")
    print(f"{DIVIDER}\n")
    print("  ⏳ fflow is now paused. Your terminal is free.")
    print()
