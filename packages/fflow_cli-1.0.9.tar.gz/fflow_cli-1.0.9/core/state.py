import json
import os
from .paths import fflow_dir

STATE_FILE = "state.json"


def _state_path(repo_path):
    return os.path.join(fflow_dir(repo_path), STATE_FILE)


def load_state(repo_path):
    path = _state_path(repo_path)
    if not os.path.exists(path):
        return {}
    with open(path, "r") as f:
        return json.load(f)


def save_state(repo_path, state):
    path = _state_path(repo_path)
    with open(path, "w") as f:
        json.dump(state, f, indent=2)


def clear_state(repo_path):
    path = _state_path(repo_path)
    if os.path.exists(path):
        os.remove(path)


def get(repo_path, key, default=None):
    return load_state(repo_path).get(key, default)


def set_key(repo_path, key, value):
    state = load_state(repo_path)
    state[key] = value
    save_state(repo_path, state)


def delete_key(repo_path, key):
    state = load_state(repo_path)
    if key in state:
        del state[key]
        save_state(repo_path, state)
