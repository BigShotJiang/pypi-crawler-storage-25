import subprocess
import os
import re
import tempfile


def run(args, cwd, capture=True, check=False):
    result = subprocess.run(
        args,
        cwd=cwd,
        capture_output=capture,
        text=True,
        check=check,
    )
    return result


def current_branch(cwd):
    r = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd)
    if r.returncode != 0:
        return None
    return r.stdout.strip()


def is_git_repo(cwd):
    r = run(["git", "rev-parse", "--git-dir"], cwd)
    return r.returncode == 0


def has_uncommitted_changes(cwd):
    r = run(["git", "status", "--porcelain"], cwd)
    return bool(r.stdout.strip())


def has_staged_files(cwd):
    r = run(["git", "diff", "--cached", "--name-only"], cwd)
    return bool(r.stdout.strip())


def get_staged_files(cwd):
    r = run(["git", "diff", "--cached", "--name-only"], cwd)
    files = [f.strip() for f in r.stdout.strip().splitlines() if f.strip()]
    return files



def get_modified_unstaged_files(cwd):
    """Return files that are modified on disk but NOT staged (tracked files only)."""
    r = run(["git", "diff", "--name-only"], cwd)
    return [f.strip() for f in r.stdout.strip().splitlines() if f.strip()]


def get_untracked_files(cwd):
    """Return new untracked files not yet known to git."""
    r = run(["git", "ls-files", "--others", "--exclude-standard"], cwd)
    return [f.strip() for f in r.stdout.strip().splitlines() if f.strip()]


def branch_exists_local(cwd, branch):
    r = run(["git", "branch", "--list", branch], cwd)
    return bool(r.stdout.strip())


def branch_exists_remote(cwd, branch):
    r = run(["git", "ls-remote", "--heads", "origin", branch], cwd)
    return bool(r.stdout.strip())


def branch_exists_remote_tracking(cwd, branch):
    """Check if a remote-tracking ref exists locally (after fetch). No network call."""
    r = run(["git", "branch", "-r", "--list", f"origin/{branch}"], cwd)
    return bool(r.stdout.strip())


def fetch_origin(cwd):
    r = run(["git", "fetch", "origin"], cwd, capture=True)
    return r.returncode == 0


def get_remote_head_commit(cwd, branch):
    r = run(["git", "rev-parse", f"origin/{branch}"], cwd)
    if r.returncode != 0:
        return None
    return r.stdout.strip()


def get_local_head_commit(cwd, branch=None):
    if branch:
        r = run(["git", "rev-parse", branch], cwd)
    else:
        r = run(["git", "rev-parse", "HEAD"], cwd)
    if r.returncode != 0:
        return None
    return r.stdout.strip()


def parent_has_new_commits(cwd, parent_branch, baseline_commit):
    remote_commit = get_remote_head_commit(cwd, parent_branch)
    if not remote_commit:
        return False, 0
    if remote_commit == baseline_commit:
        return False, 0
    r = run(
        ["git", "rev-list", "--count", f"{baseline_commit}..origin/{parent_branch}"],
        cwd,
    )
    count = int(r.stdout.strip()) if r.returncode == 0 else 0
    return True, count


def checkout_branch(cwd, branch, create=False, start_point=None):
    if create:
        args = ["git", "checkout", "-b", branch]
        if start_point:
            args.append(start_point)
    else:
        args = ["git", "checkout", branch]
    r = run(args, cwd, capture=True)
    return r.returncode == 0


def pull_branch(cwd, branch):
    r = run(["git", "pull", "--rebase", "origin", branch], cwd, capture=False)
    return r.returncode == 0


def stash_changes(cwd, message="fflow-stash"):
    r = run(["git", "stash", "push", "-u", "-m", message], cwd)
    return r.returncode == 0


def stash_pop(cwd):
    r = run(["git", "stash", "pop"], cwd, capture=True)
    return r.returncode == 0


def list_stashes(cwd):
    r = run(["git", "stash", "list"], cwd)
    return r.stdout.strip().splitlines()


def drop_fflow_stashes(cwd):
    """Drop all stashes whose message starts with 'fflow-'."""
    stashes = list_stashes(cwd)
    dropped = 0
    for entry in reversed(stashes):
        if "fflow-" in entry:
            idx = entry.split(":")[0]
            run(["git", "stash", "drop", idx], cwd)
            dropped += 1
    return dropped


def rebase_on(cwd, branch):
    r = run(["git", "rebase", f"origin/{branch}"], cwd, capture=False)
    return r.returncode == 0


def rebase_continue(cwd):
    env = os.environ.copy()
    env["GIT_EDITOR"] = "true"
    result = subprocess.run(
        ["git", "rebase", "--continue"],
        cwd=cwd,
        text=True,
        capture_output=True,
        env=env,
    )
    return result.returncode == 0, result.stdout + result.stderr


def rebase_abort(cwd):
    r = run(["git", "rebase", "--abort"], cwd, capture=False)
    return r.returncode == 0


def is_rebase_in_progress(cwd):
    git_dir_r = run(["git", "rev-parse", "--git-dir"], cwd)
    git_dir = git_dir_r.stdout.strip()
    rebase_merge = os.path.join(cwd, git_dir, "rebase-merge")
    rebase_apply = os.path.join(cwd, git_dir, "rebase-apply")
    return os.path.exists(rebase_merge) or os.path.exists(rebase_apply)


def get_conflicted_files(cwd):
    r = run(["git", "diff", "--name-only", "--diff-filter=U"], cwd)
    return [f.strip() for f in r.stdout.strip().splitlines() if f.strip()]


def stage_files(cwd, files):
    if not files:
        return True
    r = run(["git", "add"] + files, cwd, capture=False)
    return r.returncode == 0


def unstage_files(cwd, files):
    if not files:
        return True
    r = run(["git", "restore", "--staged"] + files, cwd, capture=False)
    return r.returncode == 0


def commit(cwd, message):
    r = run(["git", "commit", "-m", message], cwd, capture=False)
    return r.returncode == 0


def undo_last_commit(cwd):
    r = run(["git", "reset", "--soft", "HEAD~1"], cwd, capture=False)
    return r.returncode == 0


def get_last_commit_info(cwd):
    r = run(["git", "log", "-1", "--format=%h|%s|%ar"], cwd)
    if r.returncode != 0 or not r.stdout.strip():
        return None
    parts = r.stdout.strip().split("|", 2)
    if len(parts) < 3:
        return None
    return {"hash": parts[0], "message": parts[1], "time": parts[2]}


def amend_commit_message(cwd, message):
    r = run(["git", "commit", "--amend", "-m", message], cwd, capture=False)
    return r.returncode == 0


def push_branch(cwd, branch, force=False):
    args = ["git", "push", "origin", branch]
    if force:
        args.append("--force")
    r = run(args, cwd, capture=False)
    return r.returncode == 0


def get_recent_commits(cwd, n=5, since_branch=None):
    if since_branch:
        r = run(
            ["git", "log", f"origin/{since_branch}..HEAD", "--oneline", f"-{n}"], cwd
        )
    else:
        r = run(["git", "log", "--oneline", f"-{n}"], cwd)
    return r.stdout.strip().splitlines()


def get_commit_details(cwd, commit_hash):
    r = run(
        ["git", "show", "--stat", "--format=%H%n%an%n%ae%n%s%n%ci", commit_hash], cwd
    )
    lines = r.stdout.strip().splitlines()
    if len(lines) < 4:
        return {}
    return {
        "hash": lines[0][:8],
        "author": lines[1],
        "email": lines[2],
        "message": lines[3],
        "date": lines[4] if len(lines) > 4 else "",
    }


def get_all_known_branches(cwd):
    """Return deduplicated set of all local + remote branch names."""
    local_r = run(["git", "branch", "--format=%(refname:short)"], cwd)
    remote_r = run(["git", "branch", "-r", "--format=%(refname:short)"], cwd)
    local = [b.strip() for b in local_r.stdout.strip().splitlines() if b.strip()]
    remote = [
        b.strip().removeprefix("origin/")
        for b in remote_r.stdout.strip().splitlines()
        if b.strip() and not b.strip().endswith("/HEAD")
    ]
    return set(local + remote)


def get_all_feature_branches(cwd, parent_branches):
    """Return deduplicated list of all local + remote-tracking feature branches."""
    local_r = run(["git", "branch", "--format=%(refname:short)"], cwd)
    remote_r = run(["git", "branch", "-r", "--format=%(refname:short)"], cwd)
    local = [b.strip() for b in local_r.stdout.strip().splitlines() if b.strip()]
    remote = [
        b.strip().removeprefix("origin/")
        for b in remote_r.stdout.strip().splitlines()
        if b.strip() and not b.strip().endswith("/HEAD")
    ]
    seen = set()
    result = []
    for b in local + remote:
        if b not in seen and b not in parent_branches:
            seen.add(b)
            result.append(b)
    return sorted(result)


def get_deleted_unstaged_files(cwd):
    """Return list of files deleted on disk but not yet staged (unstaged deletions)."""
    r = run(["git", "ls-files", "--deleted"], cwd)
    return [f.strip() for f in r.stdout.strip().splitlines() if f.strip()]


def restore_deleted_files(cwd, files):
    """Restore a list of deleted-but-tracked files from git index, handling large lists safely."""
    if not files:
        return
    with tempfile.NamedTemporaryFile(mode="w", suffix=".txt", delete=False) as tmp:
        tmp.write("\n".join(files))
        tmp_path = tmp.name
    try:
        run(["git", "checkout", "--", f"--pathspec-from-file={tmp_path}"], cwd)
    finally:
        os.unlink(tmp_path)


def get_unpushed_commits(cwd):
    """Return list of (hash, message) for commits not yet pushed to origin."""
    branch_r = run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd)
    branch = branch_r.stdout.strip()
    remote_ref = f"origin/{branch}"
    r = run(["git", "log", f"{remote_ref}..HEAD", "--oneline"], cwd)
    if r.returncode != 0:
        r = run(["git", "log", "HEAD", "--oneline", "-5"], cwd)
    lines = [l.strip() for l in r.stdout.strip().splitlines() if l.strip()]
    result = []
    for line in lines:
        parts = line.split(" ", 1)
        result.append((parts[0], parts[1] if len(parts) > 1 else ""))
    return result


def is_valid_jira_id(jira_id):
    pattern = re.compile(r"^[A-Z0-9]+-[A-Z0-9]+(-[A-Z0-9]+)*$", re.IGNORECASE)
    return bool(pattern.match(jira_id.strip()))


def is_valid_commit_message(message, jira_id):
    return message.strip().startswith(jira_id)
