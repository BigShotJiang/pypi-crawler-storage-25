import os
import re


SEARCH_ROOTS = [
    "lib/pages",
    "lib/components",
    "lib/actions",
    "lib/backend",
    "lib/flutter_flow",
    "lib/custom_code",
    "lib",
]

EXCLUDE_ROOTS = {".git", ".dart_tool", ".idea", "build", ".gradle"}


def _to_snake(name):
    s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", name)
    return re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def _normalize(name):
    return name.lower().replace("_", "").replace("-", "").replace(" ", "")


def find_all_lib_folders(repo_path):
    lib_path = os.path.join(repo_path, "lib")
    if not os.path.exists(lib_path):
        return []
    folders = []
    for root, dirs, _ in os.walk(lib_path):
        for d in dirs:
            full = os.path.join(root, d)
            rel = os.path.relpath(full, repo_path).replace("\\", "/")
            folders.append(rel)
    return folders


def find_all_lib_files(repo_path):
    lib_path = os.path.join(repo_path, "lib")
    if not os.path.exists(lib_path):
        return []
    files = []
    for root, _, filenames in os.walk(lib_path):
        for fname in filenames:
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, repo_path).replace("\\", "/")
            files.append(rel)
    return files


def find_all_repo_files(repo_path):
    """Walk the entire repo (excluding build/tool dirs) and return all relative file paths."""
    files = []
    for root, dirs, filenames in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_ROOTS and not d.startswith(".")]
        for fname in filenames:
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, repo_path).replace("\\", "/")
            files.append(rel)
    return files


def find_all_repo_folders(repo_path):
    """Walk the entire repo and return all relative folder paths."""
    folders = []
    for root, dirs, _ in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_ROOTS and not d.startswith(".")]
        for d in dirs:
            full = os.path.join(root, d)
            rel = os.path.relpath(full, repo_path).replace("\\", "/")
            folders.append(rel)
    return folders


def _match_name(name, norm_kw, snake_kw, keyword):
    return (
        norm_kw in _normalize(name)
        or snake_kw in name
        or keyword.lower() in name.lower()
    )


def search_keyword(repo_path, keyword):
    """
    Given a keyword (partial name), find all matching folders and files.
    Searches lib/ first; falls back to entire repo if nothing found.
    Returns (matched_folders, matched_files) — rel paths.
    """
    norm_kw = _normalize(keyword)
    snake_kw = _to_snake(keyword)

    def _find_folders(folder_list):
        matched = []
        for folder in folder_list:
            if _match_name(os.path.basename(folder), norm_kw, snake_kw, keyword):
                matched.append(folder)
        if len(matched) > 1:
            filtered = [
                f for f in matched
                if not any(f != o and f.startswith(o + "/") for o in matched)
            ]
            matched = filtered if filtered else matched
        return matched

    def _find_files(file_list):
        return [
            f for f in file_list
            if _match_name(os.path.basename(f), norm_kw, snake_kw, keyword)
        ]

    lib_folders = find_all_lib_folders(repo_path)
    lib_files = find_all_lib_files(repo_path)

    matched_folders = _find_folders(lib_folders)
    matched_files = _find_files(lib_files) if not matched_folders else []

    if not matched_folders and not matched_files:
        all_folders = find_all_repo_folders(repo_path)
        all_files = find_all_repo_files(repo_path)
        matched_folders = _find_folders(all_folders)
        matched_files = _find_files(all_files) if not matched_folders else []

    return matched_folders, matched_files


def get_files_in_folder(repo_path, rel_folder):
    """Get all files recursively inside a folder (relative paths)."""
    full = os.path.join(repo_path, rel_folder)
    if not os.path.exists(full):
        return []
    files = []
    for root, _, filenames in os.walk(full):
        for fname in filenames:
            fp = os.path.join(root, fname)
            rel = os.path.relpath(fp, repo_path).replace("\\", "/")
            files.append(rel)
    return files


def resolve_keywords(repo_path, keywords):
    """
    Resolve a list of keywords to actual file lists.
    Returns:
      resolved: dict of keyword -> list of files
      ambiguous: dict of keyword -> list of candidate folders (needs user selection)
      not_found: list of keywords with no match
    """
    resolved = {}
    ambiguous = {}
    not_found = []

    for kw in keywords:
        folders, files = search_keyword(repo_path, kw)

        if len(folders) == 1:
            resolved[kw] = get_files_in_folder(repo_path, folders[0])
        elif len(folders) > 1:
            ambiguous[kw] = folders
        elif files:
            resolved[kw] = files
        else:
            not_found.append(kw)

    return resolved, ambiguous, not_found


