import socket
from . import config


def check_gitlab_reachable(repo_path):
    """
    Try to reach the GitLab host.
    Returns (reachable: bool, host: str)
    """
    cfg = config.load_config(repo_path)
    gitlab_url = cfg.get("gitlab_url", "")

    if not gitlab_url:
        return True, ""

    host = ""
    try:
        if gitlab_url.startswith("git@"):
            host = gitlab_url.split("git@")[1].split(":")[0]
        else:
            from urllib.parse import urlparse
            host = urlparse(gitlab_url).hostname or ""

        if not host:
            return True, ""

        conn = socket.create_connection((host, 443), timeout=5)
        conn.close()
        return True, host

    except (socket.gaierror, socket.timeout, OSError):
        return False, host


def warn_if_unreachable(repo_path):
    """
    Warn user if GitLab is not reachable.
    Returns True if reachable, False if not.
    Does NOT block — just warns.
    """
    from . import ui
    reachable, host = check_gitlab_reachable(repo_path)
    if not reachable:
        ui.blank()
        ui.warning(f"Cannot reach GitLab host: {host}")
        ui.warning("You may not be connected to the office network or VPN.")
        ui.warning("Remote git operations (push/pull/fetch) will fail.")
        ui.blank()
    return reachable
