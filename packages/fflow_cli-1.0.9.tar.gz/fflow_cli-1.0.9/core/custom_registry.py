import os
import shutil
import json
from .paths import fflow_dir

REGISTRY_FILE = "registry.json"
BACKUP_DIR = "custom_backup"


def _registry_path(repo_path):
    return os.path.join(fflow_dir(repo_path), REGISTRY_FILE)


def _backup_dir(repo_path):
    return os.path.join(fflow_dir(repo_path), BACKUP_DIR)


def _safe_rel_path(repo_path, rel_path):
    """
    Resolve rel_path against repo_path and verify the result stays inside
    the repo root.  Returns the normalised relative path, or raises ValueError.
    """
    rel_path = rel_path.replace("\\", "/")
    abs_repo = os.path.realpath(repo_path)
    abs_target = os.path.realpath(os.path.join(abs_repo, rel_path))
    if not abs_target.startswith(abs_repo + os.sep) and abs_target != abs_repo:
        raise ValueError(f"Path '{rel_path}' escapes the repository root")
    return os.path.relpath(abs_target, abs_repo).replace("\\", "/")


def load_registry(repo_path):
    path = _registry_path(repo_path)
    if not os.path.exists(path):
        return []
    with open(path, "r") as f:
        return json.load(f)


def save_registry(repo_path, files):
    path = _registry_path(repo_path)
    with open(path, "w") as f:
        json.dump(files, f, indent=2)


def register_file(repo_path, rel_path):
    try:
        rel_path = _safe_rel_path(repo_path, rel_path)
    except ValueError:
        return False
    registry = load_registry(repo_path)
    if rel_path not in registry:
        registry.append(rel_path)
        save_registry(repo_path, registry)
        return True
    return False


def unregister_file(repo_path, rel_path):
    try:
        rel_path = _safe_rel_path(repo_path, rel_path)
    except ValueError:
        return False
    registry = load_registry(repo_path)
    if rel_path in registry:
        registry.remove(rel_path)
        save_registry(repo_path, registry)
        return True
    return False


def backup_single_file(repo_path, rel_path):
    """Backup a single file immediately (e.g. at registration time)."""
    backup_dir = _backup_dir(repo_path)
    os.makedirs(backup_dir, exist_ok=True)
    src = os.path.join(repo_path, rel_path)
    if os.path.exists(src):
        dest = os.path.join(backup_dir, rel_path)
        dest_dir = os.path.dirname(dest)
        if dest_dir:
            os.makedirs(dest_dir, exist_ok=True)
        shutil.copy2(src, dest)
        return True
    return False


def backup_custom_files(repo_path):
    registry = load_registry(repo_path)
    backup_dir = _backup_dir(repo_path)
    os.makedirs(backup_dir, exist_ok=True)
    backed_up = []
    missing = []
    for rel_path in registry:
        src = os.path.join(repo_path, rel_path)
        if os.path.exists(src):
            dest = os.path.join(backup_dir, rel_path)
            dest_dir = os.path.dirname(dest)
            if dest_dir:
                os.makedirs(dest_dir, exist_ok=True)
            shutil.copy2(src, dest)
            backed_up.append(rel_path)
        else:
            missing.append(rel_path)
    return backed_up, missing


def restore_custom_files(repo_path):
    registry = load_registry(repo_path)
    backup_dir = _backup_dir(repo_path)
    restored = []
    not_found = []
    abs_repo = os.path.realpath(repo_path)
    for rel_path in registry:
        src = os.path.join(backup_dir, rel_path)
        if os.path.exists(src):
            dest = os.path.join(repo_path, rel_path)
            abs_dest = os.path.realpath(dest)
            if not abs_dest.startswith(abs_repo + os.sep) and abs_dest != abs_repo:
                not_found.append(rel_path)
                continue
            dest_dir = os.path.dirname(dest)
            if dest_dir:
                os.makedirs(dest_dir, exist_ok=True)
            shutil.copy2(src, dest)
            restored.append(rel_path)
        else:
            not_found.append(rel_path)
    return restored, not_found


def list_registered(repo_path):
    return load_registry(repo_path)
