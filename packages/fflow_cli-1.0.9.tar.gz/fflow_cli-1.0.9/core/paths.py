import hashlib
import os


def fflow_dir(repo_path):
    abs_path = os.path.abspath(repo_path)
    name = os.path.basename(abs_path)
    path_hash = hashlib.sha256(abs_path.encode()).hexdigest()[:12]
    repo_id = f"{name}_{path_hash}"
    d = os.path.join(os.path.expanduser("~"), ".fflow", repo_id)
    os.makedirs(d, exist_ok=True)
    return d
