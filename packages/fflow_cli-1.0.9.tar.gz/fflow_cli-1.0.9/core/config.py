import json
import os
import re
import shlex
from dotenv import load_dotenv, set_key as dotenv_set_key
from .paths import fflow_dir

CONFIG_FILE = "config.json"
ENV_FILE = "token.env"
REPO_CONFIG_FILE = ".fflow.json"

REQUIRED_FLAGS = ["--project", "--token", "--endpoint"]
UUID_PATTERN = re.compile(
    r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE
)
TOKEN_PLACEHOLDER = "__FF_TOKEN__"


def _config_path(repo_path):
    return os.path.join(fflow_dir(repo_path), CONFIG_FILE)


def _repo_config_path(repo_path):
    return os.path.join(repo_path, REPO_CONFIG_FILE)


def _env_path(repo_path):
    return os.path.join(fflow_dir(repo_path), ENV_FILE)


def config_exists(repo_path):
    return os.path.exists(_config_path(repo_path)) or os.path.exists(_repo_config_path(repo_path))


def load_config(repo_path):
    """Load config: local ~/.fflow/ config takes priority, repo .fflow.json fills in missing keys."""
    local_path = _config_path(repo_path)
    repo_path_cfg = _repo_config_path(repo_path)

    local = {}
    if os.path.exists(local_path):
        with open(local_path, "r") as f:
            local = json.load(f)

    repo_cfg = {}
    if os.path.exists(repo_path_cfg):
        with open(repo_path_cfg, "r") as f:
            repo_cfg = json.load(f)

    # Merge: local overrides repo-level, repo fills missing keys
    merged = {**repo_cfg, **local}
    return merged


def save_config(repo_path, cfg):
    """Save config to local ~/.fflow/ store. Also write shareable .fflow.json to repo (no token)."""
    local_path = _config_path(repo_path)
    with open(local_path, "w") as f:
        json.dump(cfg, f, indent=2)
    _save_repo_config(repo_path, cfg)


_SENSITIVE_KEYS = {"token", "raw", "raw_no_token"}


def _ensure_gitignored(repo_path, entry):
    """Add `entry` to the repo's .gitignore if it is not already listed there."""
    gitignore_path = os.path.join(repo_path, ".gitignore")
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r") as f:
            lines = f.read().splitlines()
        if any(line.strip() == entry for line in lines):
            return
        with open(gitignore_path, "a") as f:
            f.write(f"\n{entry}\n")
    else:
        with open(gitignore_path, "w") as f:
            f.write(f"{entry}\n")


def _save_repo_config(repo_path, cfg):
    """Write the shareable subset of config to .fflow.json in the repo (token is never included)."""
    shareable = {k: v for k, v in cfg.items() if k not in _SENSITIVE_KEYS}
    repo_cfg_path = _repo_config_path(repo_path)
    with open(repo_cfg_path, "w") as f:
        json.dump(shareable, f, indent=2)
    _ensure_gitignored(repo_path, REPO_CONFIG_FILE)


def load_token(repo_path):
    env_path = _env_path(repo_path)
    if not os.path.exists(env_path):
        return ""
    with open(env_path, "r") as f:
        for line in f:
            line = line.strip()
            if line.startswith("FF_TOKEN="):
                return line[len("FF_TOKEN="):].strip().strip("'\"")
    return ""


def save_token(repo_path, token):
    env_path = _env_path(repo_path)
    dotenv_set_key(env_path, "FF_TOKEN", token)


def parse_cli_command(command):
    """Parse and validate the FF CLI command. Returns (parsed_dict, errors)."""
    errors = []
    parsed = {}

    command = command.strip()
    if not command.startswith("flutterflow export-code"):
        errors.append("Command must start with 'flutterflow export-code'")
        return parsed, errors

    for flag in REQUIRED_FLAGS:
        if flag not in command:
            errors.append(f"Missing required flag: {flag}")

    token = None
    if "--token" in command:
        token_part = command.split("--token")[1].strip().split()[0].strip("'\"")
        if not UUID_PATTERN.match(token_part):
            errors.append(
                f"Token '{token_part}' looks invalid (expected UUID format like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)"
            )
        else:
            token = token_part
            parsed["token"] = token

    if "--endpoint" in command:
        endpoint_raw = command.split("--endpoint")[1].strip().split()[0]
        endpoint = endpoint_raw.strip("'\"")
        if not endpoint.startswith("http"):
            errors.append(f"--endpoint '{endpoint}' is not a valid URL")
        else:
            command = command.replace(endpoint_raw, endpoint)

    # Strip --dest and --[no-]parent-folder — fflow appends these dynamically
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    clean_parts = []
    skip_next = False
    for part in parts:
        if skip_next:
            skip_next = False
            continue
        if part == "--dest":
            skip_next = True
            continue
        if part.startswith("--dest="):
            continue
        if part in ("--no-parent-folder", "--parent-folder"):
            continue
        clean_parts.append(part)
    command = " ".join(clean_parts)

    if token:
        raw_no_token = command.replace(token, TOKEN_PLACEHOLDER)
    else:
        raw_no_token = command
    parsed["raw_no_token"] = raw_no_token
    parsed["raw"] = command

    return parsed, errors


def mask_token(command, token):
    if not token:
        return command
    masked = "****-****-****-****-" + token[-4:]
    return command.replace(token, masked)


_ALLOWED_ENDPOINTS = None  # None means all HTTPS endpoints are accepted


def _validate_endpoint(command):
    """Return an error string if --endpoint in the command is not HTTPS, else None."""
    if "--endpoint" not in command:
        return None
    try:
        from urllib.parse import urlparse
        endpoint_raw = command.split("--endpoint")[1].strip().split()[0].strip("'\"")
        parsed = urlparse(endpoint_raw)
        if parsed.scheme not in ("https",):
            return f"--endpoint must use HTTPS (got '{endpoint_raw}')"
    except Exception:
        pass
    return None


def build_cli_command(config, token):
    """Rebuild CLI command by substituting token back into the stored raw command."""
    raw = config.get("raw_no_token", "")
    if not raw:
        return ""
    command = raw.replace(TOKEN_PLACEHOLDER, token)
    err = _validate_endpoint(command)
    if err:
        raise ValueError(err)
    return command
