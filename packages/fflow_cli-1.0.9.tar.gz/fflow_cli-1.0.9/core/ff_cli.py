import subprocess
import shlex
import os
import sys
from .config import load_config, load_token, build_cli_command, mask_token


def _build_export_cmd(cfg, token, repo_path):
    """Build the FF export command, using parent dir of repo as --dest (same as manual usage)."""
    cmd = build_cli_command(cfg, token)
    if "--dest" not in cmd:
        parent_dir = os.path.dirname(repo_path)
        cmd = cmd + f" --dest {shlex.quote(parent_dir)}"
    return cmd


def get_display_command(repo_path):
    cfg = load_config(repo_path)
    token = load_token(repo_path)
    if not cfg.get("raw_no_token"):
        return None
    if not token:
        return None
    try:
        cmd = _build_export_cmd(cfg, token, repo_path)
    except ValueError:
        return None
    return mask_token(cmd, token)


def run_export(repo_path):
    cfg = load_config(repo_path)
    token = load_token(repo_path)
    if not cfg.get("raw_no_token"):
        return False, "FF CLI command not found in config. Run: fflow setup"
    if not token:
        return False, "FlutterFlow token not found. Run: fflow setup"

    try:
        cmd = _build_export_cmd(cfg, token, repo_path)
    except ValueError as e:
        return False, str(e)

    try:
        cmd_list = shlex.split(cmd)
    except ValueError:
        cmd_list = cmd.split()

    process = subprocess.Popen(
        cmd_list,
        shell=False,
        cwd=repo_path,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    for line in process.stdout:
        sys.stdout.write("    " + line)
        sys.stdout.flush()

    process.wait()

    if process.returncode != 0:
        return False, f"FlutterFlow export failed (exit code {process.returncode})"

    return True, "Export completed successfully"


def get_export_dest(repo_path):
    config = load_config(repo_path)
    if not config:
        return None
    dest = config.get("dest", "")
    dest = os.path.expanduser(dest)
    return dest
