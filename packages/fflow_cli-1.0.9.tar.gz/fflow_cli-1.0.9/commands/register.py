import os
from core import ui, custom_registry

EXCLUDE_DIRS = {".git", ".dart_tool", "build", ".gradle", ".idea"}


def _find_file_in_repo(repo_path, filename):
    """Search for a filename anywhere in the repo and return relative paths."""
    matches = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith(".")]
        if filename in files:
            rel = os.path.relpath(os.path.join(root, filename), repo_path).replace("\\", "/")
            matches.append(rel)
    return matches


def manage_custom_files(repo_path):
    """Interactive manage loop — list, add, and remove registered custom files."""
    while True:
        registered = custom_registry.list_registered(repo_path)
        ui.blank()
        if registered:
            ui.section(f"Registered custom files ({len(registered)}):")
            for i, f in enumerate(registered, 1):
                print(f"    [{i}] {f}")
        else:
            ui.info("No custom files registered yet.")
        ui.blank()

        options = ["Add file(s)", "Done"]
        if registered:
            options.insert(1, "Remove a file")
            options.insert(2, "Re-backup a file (update saved version)")
        idx = ui.choose("What do you want to do?", options)

        chosen = options[idx]

        if chosen == "Done":
            break

        if chosen == "Add file(s)":
            ui.info("Enter file paths relative to the repo root (e.g. lib/utils/custom_helper.dart).")
            ui.info("Press Enter with empty input when done.")
            while True:
                fp = input("  File path (or Enter to finish): ").strip()
                if not fp:
                    break
                fp = fp.replace("\\", "/")
                full = os.path.join(repo_path, fp)
                if not os.path.exists(full):
                    matches = _find_file_in_repo(repo_path, os.path.basename(fp))
                    if len(matches) == 1:
                        ui.warning(f"'{fp}' not found — auto-corrected to: {matches[0]}")
                        fp = matches[0]
                        full = os.path.join(repo_path, fp)
                    elif len(matches) > 1:
                        ui.warning(f"'{fp}' not found. Multiple matches found — pick the correct one:")
                        idx2 = ui.choose("Which file?", matches + ["None of these (register as-is)"])
                        if idx2 < len(matches):
                            fp = matches[idx2]
                            full = os.path.join(repo_path, fp)
                added = custom_registry.register_file(repo_path, fp)
                if added:
                    if os.path.exists(full):
                        custom_registry.backup_single_file(repo_path, fp)
                        ui.success(f"Registered and backed up: {fp}")
                    else:
                        ui.warning(f"'{fp}' not found in repo yet — will be protected once it exists after export")
                        ui.success(f"Registered: {fp}")
                else:
                    ui.info(f"Already registered: {fp}")

        if chosen == "Remove a file":
            registered = custom_registry.list_registered(repo_path)
            if not registered:
                ui.info("Nothing to remove.")
                continue
            idx2 = ui.choose("Which file to remove?", registered + ["Cancel"])
            if idx2 < len(registered):
                custom_registry.unregister_file(repo_path, registered[idx2])
                ui.success(f"Removed: {registered[idx2]}")

        if chosen == "Re-backup a file (update saved version)":
            registered = custom_registry.list_registered(repo_path)
            idx2 = ui.choose("Which file to re-backup?", registered + ["Cancel"])
            if idx2 < len(registered):
                fp = registered[idx2]
                full = os.path.join(repo_path, fp)
                if os.path.exists(full):
                    custom_registry.backup_single_file(repo_path, fp)
                    ui.success(f"Re-backed up: {fp} (this version will be restored on future exports)")
                else:
                    ui.warning(f"'{fp}' not found in repo — nothing to backup")
