import os
import shutil
from core import ui, git, config, state, custom_registry, network


def run(repo_path):
    ui.header("fflow — Doctor (Diagnostics)")
    issues = []
    ok = []

    if not git.is_git_repo(repo_path):
        ui.error("Not a Git repository.")
        return

    ok.append("Git repository detected")

    reachable, host = network.check_gitlab_reachable(repo_path)
    if reachable:
        ok.append(f"GitLab reachable{' (' + host + ')' if host else ''} — network/VPN OK")
    else:
        issues.append(f"Cannot reach GitLab ({host}) — check office network or VPN connection")


    if config.config_exists(repo_path):
        ok.append("fflow config found (~/.fflow/)")
    else:
        issues.append("No fflow config found — run: fflow setup")

    token = config.load_token(repo_path)
    if token:
        ok.append("FlutterFlow token found (~/.fflow/)")
    else:
        issues.append("No FlutterFlow token found — run: fflow setup")

    if shutil.which("flutterflow"):
        ok.append("FlutterFlow CLI found on PATH")
    else:
        issues.append("FlutterFlow CLI not found on PATH — install it or check your PATH")

    branch = git.current_branch(repo_path)
    if branch:
        ok.append(f"Current branch: {branch}")
    else:
        issues.append("Could not detect current branch")

    if git.is_rebase_in_progress(repo_path):
        issues.append("Rebase in progress — resolve conflicts and run: fflow")

    current_state = state.load_state(repo_path)
    if current_state.get("phase") == "paused_sync":
        issues.append("fflow sync is paused — resolve conflicts and run: fflow")

    if git.has_staged_files(repo_path):
        staged = git.get_staged_files(repo_path)
        issues.append(f"There are {len(staged)} staged file(s) not yet committed")

    registered = custom_registry.list_registered(repo_path)
    ok.append(f"{len(registered)} custom file(s) registered")

    missing_custom = []
    for f in registered:
        if not os.path.exists(os.path.join(repo_path, f)):
            missing_custom.append(f)
    if missing_custom:
        issues.append(f"{len(missing_custom)} registered custom file(s) not found on disk:")
        for f in missing_custom:
            print(f"      {f}")

    stashes = git.list_stashes(repo_path)
    if stashes:
        issues.append(f"{len(stashes)} unresolved stash(es) found:")
        for s in stashes:
            print(f"      {s}")

    ui.blank()
    ui.section("Checks passed:")
    for o in ok:
        ui.success(o)

    if issues:
        ui.blank()
        ui.section("Issues found:")
        for issue in issues:
            ui.warning(issue)
        ui.blank()
        ui.info("Fix the issues above, then run: fflow")
    else:
        ui.blank()
        ui.success("Everything looks good! Run: fflow")
    ui.blank()
