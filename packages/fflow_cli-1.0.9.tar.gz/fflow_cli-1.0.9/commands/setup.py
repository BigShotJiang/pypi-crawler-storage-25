import os
import re
import shutil
from core import ui, config, custom_registry, git, state
from core.paths import fflow_dir
from commands.register import manage_custom_files




def run(repo_path):
    if not git.is_git_repo(repo_path):
        ui.error("This directory is not a Git repository.")
        ui.info("Please run fflow setup from inside your project's Git repo folder.")
        return False

    has_pubspec = os.path.exists(os.path.join(repo_path, "pubspec.yaml"))
    has_lib = os.path.exists(os.path.join(repo_path, "lib"))
    if not has_pubspec and not has_lib:
        folder_name = os.path.basename(repo_path)
        ui.blank()
        ui.warning(f"'{folder_name}' doesn't look like a Flutter/FlutterFlow project.")
        ui.warning("No pubspec.yaml or lib/ folder found.")
        ui.info("cd into your Flutter project folder first, then run: fflow setup")
        ui.blank()
        if not ui.confirm("Continue setup here anyway?"):
            ui.aborted()
            return False

    repo_cfg_path = os.path.join(repo_path, ".fflow.json")
    has_repo_config = os.path.exists(repo_cfg_path)
    has_local_token = bool(config.load_token(repo_path))
    existing = config.load_config(repo_path)

    # Teammate scenario: shared .fflow.json exists but no local token yet
    if has_repo_config and not has_local_token and existing.get("raw_no_token"):
        return _token_only_setup(repo_path, existing)

    if existing:
        return _edit_config(repo_path, existing)
    else:
        return _full_setup(repo_path)


# ─── Full first-time setup ────────────────────────────────────────────────────

def _full_setup(repo_path):
    ui.header("fflow — Setup")

    cfg = {}
    token = None

    ui.blank()
    ui.info("Step 1 of 4 — FlutterFlow CLI Command")
    cfg, token = _ask_ff_command(repo_path, cfg)
    if cfg is None:
        return False

    ui.blank()
    ui.info("Step 2 of 4 — GitLab Repository URL")
    cfg = _ask_gitlab_url(cfg)
    if cfg is None:
        return False

    ui.blank()
    ui.info("Step 3 of 4 — Parent Branches")
    cfg = _ask_parent_branches(cfg)
    if cfg is None:
        return False

    ui.blank()
    ui.info("Step 4 of 4 — Custom Code Files")
    ui.info("Register any hand-written files that should never be overwritten by FlutterFlow export.")
    ui.blank()
    if ui.confirm("Manage custom code files now?"):
        manage_custom_files(repo_path)

    config.save_config(repo_path, cfg)
    config.save_token(repo_path, token)

    ui.blank()
    ui.success("Setup complete! fflow is ready.")
    ui.blank()
    ui.info("From now on, just run:  fflow")
    ui.blank()
    return True


# ─── Token-only setup (teammate with shared .fflow.json) ─────────────────────

def _token_only_setup(repo_path, existing):
    ui.header("fflow — Setup (Token Only)")
    ui.blank()
    ui.success("Found shared fflow config from your team (.fflow.json).")
    masked_cmd = existing.get("raw_no_token", "").replace("__FF_TOKEN__", "****")
    ui.info(f"  FF command     : {masked_cmd}")
    ui.info(f"  GitLab URL     : {existing.get('gitlab_url', '—')}")
    ui.info(f"  Parent branches: {', '.join(existing.get('parent_branches', []))}")
    ui.blank()
    ui.info("Just enter your personal FlutterFlow API token to get started.")
    ui.blank()

    while True:
        token = input("  Your FlutterFlow token: ").strip().strip("'\"")
        if not token:
            ui.error("Token cannot be empty.")
            continue
        UUID_PATTERN = re.compile(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", re.IGNORECASE
        )
        if not UUID_PATTERN.match(token):
            ui.error("Token looks invalid (expected UUID format like xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx).")
            if not ui.confirm("Try again?"):
                ui.aborted()
                return False
            continue
        break

    config.save_token(repo_path, token)
    # Sync local config from repo config
    config.save_config(repo_path, existing)
    ui.blank()
    ui.success("Setup complete! fflow is ready.")
    ui.info("From now on, just run:  fflow")
    ui.blank()
    return True


# ─── Edit existing config ─────────────────────────────────────────────────────

def _edit_config(repo_path, existing):
    ui.header("fflow — Update Configuration")

    token = config.load_token(repo_path)
    masked_cmd = config.mask_token(existing.get("raw_no_token", ""), token) if token else existing.get("raw_no_token", "—")

    ui.blank()
    ui.info(f"  FF command     : {masked_cmd}")
    ui.info(f"  GitLab URL     : {existing.get('gitlab_url', '—')}")
    ui.info(f"  Parent branches: {', '.join(existing.get('parent_branches', []))}")
    registered = custom_registry.list_registered(repo_path)
    ui.info(f"  Custom files   : {len(registered)} registered")
    ui.blank()

    idx = ui.choose(
        "What do you want to update?",
        [
            "FlutterFlow export command",
            "GitLab URL",
            "Parent branches",
            "Custom files",
            "Reset — clear all fflow config for this repo",
            "Cancel",
        ]
    )

    if idx == 5:
        ui.aborted()
        return False

    if idx == 4:
        return _reset_config(repo_path)

    cfg = dict(existing)

    if idx == 0:
        ui.blank()
        result, new_token = _ask_ff_command(repo_path, cfg)
        if result is None:
            return False
        cfg = result
        config.save_config(repo_path, cfg)
        config.save_token(repo_path, new_token)
        ui.success("FlutterFlow export command updated.")

    elif idx == 1:
        ui.blank()
        result = _ask_gitlab_url(cfg)
        if result is None:
            return False
        cfg = result
        config.save_config(repo_path, cfg)
        ui.success("GitLab URL updated.")

    elif idx == 2:
        ui.blank()
        result = _ask_parent_branches(cfg)
        if result is None:
            return False
        cfg = result
        config.save_config(repo_path, cfg)
        ui.success("Parent branches updated.")

    elif idx == 3:
        manage_custom_files(repo_path)

    return True


def _reset_config(repo_path):
    ui.blank()
    ui.warning("This will delete all fflow configuration for this repo:")
    ui.warning("  - Your FlutterFlow command, GitLab URL, parent branches")
    ui.warning("  - Your API token")
    ui.warning("  - Any registered custom files")
    ui.warning("  - The shared team config file in the repo")
    ui.blank()
    if not ui.confirm("Are you sure you want to reset everything?"):
        ui.aborted()
        return False

    local_dir = fflow_dir(repo_path)
    if os.path.exists(local_dir):
        shutil.rmtree(local_dir)

    repo_cfg = os.path.join(repo_path, ".fflow.json")
    if os.path.exists(repo_cfg):
        os.remove(repo_cfg)

    for fname in (".fflow_state.json", ".fflow_registry.json"):
        fpath = os.path.join(repo_path, fname)
        if os.path.exists(fpath):
            os.remove(fpath)

    ui.blank()
    ui.success("fflow config cleared. Run: fflow setup  to set up again.")
    return True


# ─── Shared input helpers ─────────────────────────────────────────────────────

def _ask_ff_command(repo_path, cfg):
    ui.info("Paste your full FlutterFlow export command (exactly as given by FlutterFlow).")
    ui.info("Example: flutterflow export-code --project my-proj --token xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx --endpoint https://api.flutterflow.io/v2 --include-assets")
    ui.blank()

    while True:
        raw_cmd = input("  Paste command: ").strip()
        if not raw_cmd:
            ui.error("Command cannot be empty.")
            continue

        parsed, errors = config.parse_cli_command(raw_cmd)
        if errors:
            ui.blank()
            ui.error("Invalid command. Issues found:")
            for e in errors:
                print(f"      - {e}")
            ui.blank()
            if not ui.confirm("Try again?"):
                ui.aborted()
                return None, None
            continue

        token = parsed["token"]
        cfg["raw_no_token"] = parsed["raw_no_token"]

        masked = config.mask_token(raw_cmd, token)
        ui.blank()
        ui.success("Command parsed successfully.")
        ui.info(f"Command: {masked}")
        ui.blank()

        if ui.confirm("Use this command?"):
            return cfg, token
        if not ui.confirm("Try again?"):
            ui.aborted()
            return None, None


def _ask_gitlab_url(cfg):
    def validate_url(url):
        if url.startswith("http://") or url.startswith("https://") or url.startswith("git@"):
            return True, ""
        return False, "URL must start with http://, https://, or git@"

    current = cfg.get("gitlab_url", "")
    if current:
        ui.info(f"Current: {current}")
    gitlab_url = ui.ask("GitLab repository URL", validator=validate_url)
    if not gitlab_url:
        ui.aborted()
        return None
    cfg["gitlab_url"] = gitlab_url
    return cfg


def _ask_parent_branches(cfg):
    current = list(dict.fromkeys(cfg.get("parent_branches", [])))
    is_first_time = not current

    if not is_first_time:
        ui.info(f"Current parent branches: {', '.join(current)}")
        ui.blank()
        idx = ui.choose(
            "What do you want to do?",
            [
                "Add more branches to existing list",
                "Replace list with new branches",
                "Keep current (no change)",
            ]
        )
        if idx == 2:
            cfg["parent_branches"] = current
            return cfg
    else:
        idx = 1

    repo_path = os.getcwd()
    known_branches = git.get_all_known_branches(repo_path)

    already_in_list = set(current) if idx == 0 else set()

    ui.info("Enter branch names one by one. Press Enter with empty input when done.")
    if known_branches:
        ui.info(f"Available branches: {', '.join(sorted(known_branches))}")
    ui.blank()

    new_branches = []
    while True:
        b = input("  Branch name (or Enter to finish): ").strip()
        if not b:
            if not new_branches and idx == 1:
                ui.warning("At least one branch is required.")
                continue
            break
        if known_branches and b not in known_branches:
            ui.error(f"'{b}' does not exist locally or remotely. Create it first.")
            continue
        if b in already_in_list:
            ui.warning(f"'{b}' is already in the parent branch list — skipped.")
            continue
        if b in new_branches:
            ui.warning(f"'{b}' already added — skipped.")
            continue
        new_branches.append(b)
        already_in_list.add(b)
        ui.success(f"Added: {b}")

    if idx == 0:
        merged = list(dict.fromkeys(current + new_branches))
        cfg["parent_branches"] = merged
        ui.success(f"Updated: {', '.join(merged)}")
    else:
        if not new_branches:
            ui.warning("No branches entered — keeping current list.")
            cfg["parent_branches"] = current
        else:
            cfg["parent_branches"] = new_branches
            ui.success(f"Replaced with: {', '.join(new_branches)}")
    return cfg


