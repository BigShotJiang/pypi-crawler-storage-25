import os
import re
from core import ui, git, config, state, ff_cli, custom_registry, page_mapper

JIRA_PATTERN = re.compile(r"^[A-Z0-9]+-[A-Z0-9]+(-[A-Z0-9]+)*$", re.IGNORECASE)
FFLOW_OWN_FILES = {".fflow.json", ".fflow.env", ".fflow_state.json", ".fflow_registry.json", ".gitignore"}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _jira_validator(val):
    if JIRA_PATTERN.match(val.strip()):
        return True, ""
    return False, "Invalid Jira ID. Must be alphanumeric segments with hyphens (e.g. PROJ-123, TASK-456)"


def _get_parent_branches(repo_path):
    cfg = config.load_config(repo_path)
    return cfg.get("parent_branches", [])


def _is_parent_branch(repo_path, branch):
    return branch in _get_parent_branches(repo_path)


def _is_at_or_before_baseline(repo_path, commit_hash, baseline):
    """Return True if commit_hash is an ancestor of baseline (i.e. came from parent branch sync)."""
    r = git.run(["git", "merge-base", "--is-ancestor", commit_hash, baseline], repo_path)
    return r.returncode == 0


def _parse_feature_branch(branch):
    parts = branch.split("-")
    if len(parts) >= 3:
        jira_id = f"{parts[0]}-{parts[1]}"
        parent = "-".join(parts[2:])
        return jira_id, parent
    return None, None


def _expected_branch_name(jira_id, parent_branch):
    return f"{jira_id}-{parent_branch}"


def _parse_mine_keywords(raw):
    raw = raw.strip()
    keywords = [k.strip() for k in re.split(r"[,\s]+", raw) if k.strip()]
    return keywords


def _check_manual_commits(repo_path, jira_id, parent_branch):
    """Check if there are commits not made by fflow with wrong format."""
    commits = git.get_recent_commits(repo_path, n=10, since_branch=parent_branch)
    bad_commits = []
    for line in commits:
        parts = line.split(" ", 1)
        if len(parts) < 2:
            continue
        h, msg = parts[0], parts[1]
        if not git.is_valid_commit_message(msg, jira_id):
            bad_commits.append((h, msg))
    return bad_commits


# ─── Step: Start new task ─────────────────────────────────────────────────────

def _handle_dirty_working_tree(repo_path, context="switching branches"):
    """
    If there are uncommitted/unstaged changes, ask user to stash or discard.
    Returns True if safe to proceed, False if user aborted.
    """
    staged = git.get_staged_files(repo_path)
    unstaged = git.get_modified_unstaged_files(repo_path)
    all_modified = list(dict.fromkeys(staged + unstaged))

    if not all_modified:
        return True

    ui.blank()
    ui.warning(f"You have {len(all_modified)} uncommitted change(s) that will block {context}:")
    for f in all_modified:
        tag = " (staged)" if f in staged else " (modified)"
        print(f"    {f}{tag}")

    idx = ui.choose(
        "What do you want to do with these changes?",
        ["Stash them (can be recovered later with: git stash pop)", "Discard them permanently", "Abort"]
    )
    if idx == 2:
        ui.aborted()
        return False
    if idx == 0:
        git.stash_changes(repo_path, "fflow-pre-start-stash")
        ui.success("Changes stashed. Recover later with: git stash pop")
    if idx == 1:
        if not ui.confirm("This will permanently delete your changes. Are you sure?"):
            ui.aborted()
            return False
        git.run(["git", "checkout", "--", "."], repo_path)
        git.run(["git", "clean", "-fd"], repo_path)
        ui.success("Changes discarded.")
    return True


def step_start(repo_path, skip_export=False, skip_to_push=False, run_export_first=False):
    ui.header("fflow — Starting New Task")

    if not git.fetch_origin(repo_path):
        ui.error("Could not reach GitLab — check your network/VPN connection and try again.")
        return False
    parent_branches = _get_parent_branches(repo_path)
    branch = git.current_branch(repo_path)

    if not _is_parent_branch(repo_path, branch):
        ui.warning(f"You are on branch '{branch}', not a parent branch.")
        idx = ui.choose(
            "Switch to a parent branch first:",
            parent_branches + ["Abort"]
        )
        if idx == len(parent_branches):
            ui.aborted()
            return False
        branch = parent_branches[idx]
        if not _handle_dirty_working_tree(repo_path, f"switching to '{branch}'"):
            return False
        ok = git.checkout_branch(repo_path, branch)
        if not ok:
            ui.error(f"Failed to switch to '{branch}'. Check git status manually.")
            return False
        ui.info(f"Pulling latest '{branch}'...")
        if not git.pull_branch(repo_path, branch):
            ui.error("Pull failed — check your network/VPN connection and try again.")
            return False
        ui.success(f"'{branch}' is up to date.")

    else:
        ui.info(f"Pulling latest '{branch}'...")
        if not git.pull_branch(repo_path, branch):
            ui.error("Pull failed — check your network/VPN connection and try again.")
            return False
        ui.success(f"'{branch}' is up to date.")

    ui.blank()
    jira_id = ui.ask(
        "Enter your Jira ID (e.g. PROJ-123, TASK-456)",
        validator=_jira_validator
    )
    jira_id = jira_id.upper().strip()

    current_branch_name = git.current_branch(repo_path)
    if _is_parent_branch(repo_path, current_branch_name):
        parent_branch = current_branch_name
    elif len(parent_branches) > 1:
        idx = ui.choose("Which parent branch are you working from?", parent_branches)
        parent_branch = parent_branches[idx]
    else:
        parent_branch = parent_branches[0]

    new_branch = _expected_branch_name(jira_id, parent_branch)

    exists_local = git.branch_exists_local(repo_path, new_branch)
    exists_remote = git.branch_exists_remote(repo_path, new_branch)

    if exists_local or exists_remote:
        where = "locally and remotely" if (exists_local and exists_remote) else ("locally" if exists_local else "on remote")
        ui.warning(f"Branch '{new_branch}' already exists {where}.")
        idx = ui.choose(
            "What do you want to do?",
            [f"Switch to existing branch '{new_branch}' and continue", "Start fresh with a different Jira ID", "Abort"]
        )
        if idx == 0:
            if not _handle_dirty_working_tree(repo_path, f"switching to '{new_branch}'"):
                return False
            ok = git.checkout_branch(repo_path, new_branch)
            if not ok:
                ui.error(f"Failed to switch to '{new_branch}'. Check git status manually.")
                return False
            baseline = git.get_remote_head_commit(repo_path, parent_branch)
            state.save_state(repo_path, {
                "jira_id": jira_id,
                "parent_branch": parent_branch,
                "baseline_commit": baseline,
                "phase": "ready_for_export"
            })
            ui.success(f"Switched to '{new_branch}'.")
            return True
        elif idx == 1:
            return step_start(repo_path)
        else:
            ui.aborted()
            return False

    ui.blank()

    if skip_export or skip_to_push:
        label = "(staged files will be carried over)" if skip_to_push else "(existing changes will be carried over)"
        ui.info(f"Will create branch: {new_branch}  {label}")
        if not ui.confirm("Proceed?"):
            ui.aborted()
            return False
        baseline = git.get_remote_head_commit(repo_path, parent_branch)
        ok = git.checkout_branch(repo_path, new_branch, create=True, start_point=parent_branch)
        if not ok:
            ui.error(f"Failed to create branch '{new_branch}'. Check git status manually.")
            return False
        phase = "ready_for_push" if skip_to_push else "ready_for_mine"
        ui.success(f"Branch '{new_branch}' created with existing changes intact.")
        state.save_state(repo_path, {
            "jira_id": jira_id,
            "parent_branch": parent_branch,
            "baseline_commit": baseline,
            "phase": phase
        })
        ui.blank()
        if skip_to_push:
            ui.success("Run: fflow  to commit and push your staged files.")
        else:
            ui.success("Run: fflow  to select and stage your files.")
        return True

    ui.info(f"Will create branch: {new_branch}")
    if not ui.confirm("Proceed?"):
        ui.aborted()
        return False

    if not _handle_dirty_working_tree(repo_path, f"creating branch '{new_branch}'"):
        return False

    baseline = git.get_remote_head_commit(repo_path, parent_branch)
    ok = git.checkout_branch(repo_path, new_branch, create=True, start_point=parent_branch)
    if not ok:
        ui.error(f"Failed to create branch '{new_branch}'. Check git status manually.")
        return False
    ui.success(f"Branch '{new_branch}' created.")

    current_state = {
        "jira_id": jira_id,
        "parent_branch": parent_branch,
        "baseline_commit": baseline,
        "phase": "ready_for_export"
    }
    state.save_state(repo_path, current_state)

    if run_export_first:
        ui.blank()
        ok = step_export(repo_path, current_state)
        if ok:
            current_state = state.load_state(repo_path)
            if current_state.get("phase") == "ready_for_mine":
                step_mine(repo_path, current_state)
        return ok

    ui.blank()
    ui.success("You are ready to work in FlutterFlow.")
    ui.info("Make your changes in FlutterFlow, then come back and run: fflow")
    ui.blank()
    return True


# ─── Step: FF Export ──────────────────────────────────────────────────────────

def step_export(repo_path, current_state):
    ui.header("fflow — FlutterFlow Export")

    ui.blank()
    ui.info("What do you want to do?")
    idx = ui.choose(
        "Choose an option:",
        [
            "Run FlutterFlow export (get latest code from FF)",
            "Skip export — changes are ready, go straight to staging",
            "Switch to an existing branch",
            "Start a new task on a different branch",
        ]
    )

    if idx == 2:
        parent_branches = config.load_config(repo_path).get("parent_branches", [])
        branches = git.get_all_feature_branches(repo_path, parent_branches)
        if not branches:
            ui.error("No existing feature branches found locally or on remote.")
            return False
        options = branches + ["Cancel"]
        bidx = ui.choose("Select a branch to switch to:", options)
        if bidx == len(branches):
            return False
        target = branches[bidx]
        if not _handle_dirty_working_tree(repo_path, f"switching to '{target}'"):
            return False
        ok = git.checkout_branch(repo_path, target)
        if ok:
            ui.success(f"Switched to '{target}'. Run: fflow  to continue.")
        else:
            ui.error(f"Failed to switch to '{target}'.")
        return False

    if idx == 3:
        state.clear_state(repo_path)
        step_start(repo_path)
        return False

    if idx == 1:
        staged_now = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
        unstaged_now = list(dict.fromkeys(
            [f for f in git.get_modified_unstaged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES] +
            [f for f in git.get_untracked_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
        ))
        if not staged_now and not unstaged_now:
            ui.blank()
            ui.warning("No file changes detected in the repo.")
            ui.info("Nothing to stage or commit. If you need to export from FF, run: fflow  and choose option [1].")
            state.set_key(repo_path, "phase", "ready_for_export")
            return False
        state.set_key(repo_path, "phase", "ready_for_mine")
        ui.success("Skipping export. Run: fflow  to select files to stage.")
        return True

    parent_branch = current_state.get("parent_branch")
    baseline = current_state.get("baseline_commit")

    git.fetch_origin(repo_path)
    has_new, count = git.parent_has_new_commits(repo_path, parent_branch, baseline)
    if has_new:
        ui.blank()
        ui.warning(f"Parent branch '{parent_branch}' has {count} new commit(s) since you started.")
        ui.warning("Running FF export without syncing first may cause conflicts later.")
        idx = ui.choose(
            "What do you want to do?",
            [f"Sync with '{parent_branch}' first (recommended)", "Export anyway", "Abort"]
        )
        if idx == 2:
            ui.aborted()
            return False
        if idx == 0:
            synced = step_sync(repo_path, current_state, return_phase="ready_for_export")
            if not synced:
                return False
            current_state = state.load_state(repo_path)

    staged = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
    unstaged = list(dict.fromkeys(
        [f for f in git.get_modified_unstaged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES] +
        [f for f in git.get_untracked_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
    ))
    all_modified = list(dict.fromkeys(staged + unstaged))

    stash_was_created = False
    if all_modified:
        ui.blank()
        ui.warning(f"You have {len(all_modified)} manually modified file(s) that FF export may overwrite:")
        for f in all_modified:
            tag = " (staged)" if f in staged else " (unstaged)"
            print(f"    {f}{tag}")

        ui.blank()
        ui.info("Options:")
        print("    [1] Save my changes, run FF export, restore my changes after")
        print("    [2] Discard all my changes and run FF export fresh")
        print("    [3] Stage specific files I care about, discard rest, skip export")
        print("    [4] Abort")
        ui.blank()
        raw_idx = input("  Choice (1/2/3/4): ").strip()
        if raw_idx not in ("1", "2", "3", "4"):
            ui.aborted()
            return False
        idx = int(raw_idx)

        if idx == 4:
            ui.aborted()
            return False

        if idx == 1:
            git.stash_changes(repo_path, "fflow-pre-export-stash")
            ui.success("Changes saved. Will be restored after export.")
            stash_was_created = True

        if idx == 2:
            if not ui.confirm("This will permanently discard all local changes. Are you sure?"):
                ui.aborted()
                return False
            git.run(["git", "checkout", "--", "."], repo_path)
            git.run(["git", "clean", "-fd"], repo_path)
            ui.success("All local changes discarded.")

        if idx == 3:
            ui.blank()
            ui.info("Which files do you want to STAGE? (rest will be discarded)")
            for i, f in enumerate(all_modified, 1):
                tag = " (staged)" if f in staged else " (unstaged)"
                print(f"    [{i}] {f}{tag}")
            ui.blank()
            raw = input("  File numbers (e.g. 1,3,5): ").strip()
            try:
                selected_indices = {int(x.strip()) - 1 for x in raw.split(",") if x.strip()}
                files_to_stage = [all_modified[i] for i in selected_indices if 0 <= i < len(all_modified)]
            except ValueError:
                files_to_stage = []

            git.run(["git", "checkout", "--", "."], repo_path)
            git.run(["git", "clean", "-fd"], repo_path)

            if files_to_stage:
                for f in files_to_stage:
                    git.run(["git", "checkout", "HEAD", "--", f], repo_path)
                    git.run(["git", "add", f], repo_path)
                ui.success(f"Staged {len(files_to_stage)} file(s). All other changes discarded.")
            else:
                ui.warning("No files selected — all changes discarded.")

            state.set_key(repo_path, "phase", "ready_for_mine")
            ui.success("Run: fflow  to continue.")
            return True

    custom_registry.backup_custom_files(repo_path)

    display_cmd = ff_cli.get_display_command(repo_path)
    ui.blank()
    ui.info("Will run:")
    print(f"\n    {display_cmd}\n")

    if not ui.confirm("Proceed with FlutterFlow export?"):
        ui.aborted()
        return False

    ui.info("Running FlutterFlow export... (this may take a while)")
    ok, msg = ff_cli.run_export(repo_path)
    if not ok:
        ui.error(f"Export failed: {msg}")
        if stash_was_created:
            ui.info("Restoring your stashed changes...")
            git.stash_pop(repo_path)
            ui.success("Changes restored.")
        return False

    ui.success("Export completed.")

    if stash_was_created:
        ui.info("Re-applying your stashed manual changes...")
        ok = git.stash_pop(repo_path)
        if ok:
            ui.success("Manual changes re-applied.")
        else:
            ui.warning("Could not re-apply stash automatically — run: git stash pop")

    restored, not_found = custom_registry.restore_custom_files(repo_path)
    if restored:
        for rf in restored:
            git.run(["git", "add", rf], repo_path)
        ui.success(f"{len(restored)} registered custom file(s) restored and staged automatically.")
    if not_found:
        newly_backed_up = []
        for rf in not_found:
            if custom_registry.backup_single_file(repo_path, rf):
                git.run(["git", "add", rf], repo_path)
                newly_backed_up.append(rf)
        if newly_backed_up:
            ui.warning(f"{len(newly_backed_up)} registered file(s) had no backup — FF-exported version saved as initial backup:")
            for rf in newly_backed_up:
                ui.info(f"  {rf}")
            ui.warning("These files now contain FlutterFlow's version. Edit them to your desired content, then run: fflow setup → Custom files to re-backup.")
        still_missing = [rf for rf in not_found if rf not in newly_backed_up]
        if still_missing:
            ui.warning(f"{len(still_missing)} registered custom file(s) not found even after export — skipped: {still_missing}")

    new_baseline = git.get_remote_head_commit(repo_path, current_state.get("parent_branch"))
    if new_baseline:
        current_state["baseline_commit"] = new_baseline
    current_state["phase"] = "ready_for_mine"
    state.save_state(repo_path, current_state)
    return True


# ─── Step: Mine (select files) ────────────────────────────────────────────────

def step_mine(repo_path, current_state):
    ui.header("fflow — Select Your Files")

    jira_id = current_state.get("jira_id", "")
    parent_branch = current_state.get("parent_branch", "")

    idx_back = ui.choose(
        "Where do you want to go?",
        ["Select files to stage (continue)", "Go back to FlutterFlow export step", "Switch branch or change parent"]
    )
    if idx_back == 1:
        staged_existing = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
        if staged_existing:
            git.unstage_files(repo_path, staged_existing)
            ui.info(f"Unstaged {len(staged_existing)} file(s).")
        state.set_key(repo_path, "phase", "ready_for_export")
        current_state["phase"] = "ready_for_export"
        ui.blank()
        return step_export(repo_path, current_state)

    if idx_back == 2:
        parent_branches = _get_parent_branches(repo_path)
        ui.blank()
        action = ui.choose(
            "What do you want to do?",
            [
                "Switch to an existing branch",
                f"Create a new branch under a different parent (current: {parent_branch})",
                "Abort"
            ]
        )
        if action == 2:
            ui.aborted()
            return False

        if action == 0:
            staged_existing = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
            if staged_existing:
                if not ui.confirm(f"You have {len(staged_existing)} staged file(s) — unstage them before switching?"):
                    ui.aborted()
                    return False
                git.unstage_files(repo_path, staged_existing)
            all_parent_branches = _get_parent_branches(repo_path)
            branches = git.get_all_feature_branches(repo_path, all_parent_branches)
            if not branches:
                ui.error("No existing feature branches found locally or on remote.")
                return False
            options = branches + ["Cancel"]
            bidx = ui.choose("Select a branch to switch to:", options)
            if bidx == len(branches):
                ui.aborted()
                return False
            target = branches[bidx]
            if not _handle_dirty_working_tree(repo_path, f"switching to '{target}'"):
                return False
            ok = git.checkout_branch(repo_path, target)
            if not ok:
                ui.error(f"Failed to switch to '{target}'.")
                return False
            new_jira, new_parent = _parse_feature_branch(target)
            if new_jira and new_parent:
                baseline = git.get_remote_head_commit(repo_path, new_parent)
                state.save_state(repo_path, {
                    "jira_id": new_jira,
                    "parent_branch": new_parent,
                    "baseline_commit": baseline,
                    "phase": "ready_for_export"
                })
            ui.success(f"Switched to '{target}'. Run: fflow  to continue.")
            return False

        if action == 1:
            ui.blank()
            if len(parent_branches) == 1:
                new_parent = parent_branches[0]
                ui.info(f"Only one parent branch available: '{new_parent}'")
            else:
                pidx = ui.choose("Select parent branch:", parent_branches)
                new_parent = parent_branches[pidx]

            ui.blank()
            new_jira = ui.ask(
                "Enter Jira ID for new branch (or press Enter to keep current)",
                validator=lambda v: (True, "") if not v else _jira_validator(v)
            ).strip().upper()
            if not new_jira:
                new_jira = jira_id

            new_branch = _expected_branch_name(new_jira, new_parent)
            ui.blank()
            ui.info(f"Will create branch: {new_branch}")
            if not ui.confirm("Proceed?"):
                ui.aborted()
                return False

            staged_existing = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES]
            if staged_existing:
                git.unstage_files(repo_path, staged_existing)

            if not _handle_dirty_working_tree(repo_path, f"creating branch '{new_branch}'"):
                return False

            ok = git.checkout_branch(repo_path, new_branch, create=True, start_point=new_parent)
            if not ok:
                ui.error(f"Failed to create '{new_branch}'. Check git status manually.")
                return False

            baseline = git.get_remote_head_commit(repo_path, new_parent)
            state.save_state(repo_path, {
                "jira_id": new_jira,
                "parent_branch": new_parent,
                "baseline_commit": baseline,
                "phase": "ready_for_export"
            })
            ui.success(f"Switched to '{new_branch}'. Run: fflow  to continue.")
            return False

    registered_files = set(custom_registry.list_registered(repo_path))
    staged_now = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES and f not in registered_files]
    unstaged_now = list(dict.fromkeys(
        [f for f in git.get_modified_unstaged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES and f not in registered_files] +
        [f for f in git.get_untracked_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES and f not in registered_files]
    ))

    if not staged_now and not unstaged_now:
        ui.blank()
        ui.warning("No file changes detected in the repo.")
        idx = ui.choose(
            "What do you want to do?",
            ["Run FlutterFlow export", "Abort"]
        )
        if idx == 1:
            ui.aborted()
            return False
        state.set_key(repo_path, "phase", "ready_for_export")
        return False

    if staged_now and not unstaged_now:
        ui.blank()
        ui.info(f"{len(staged_now)} file(s) already staged, no other changes.")
        ui.print_file_list("Staged:", staged_now)
        idx = ui.choose(
            "What do you want to do?",
            ["Commit these staged files", "Re-select files from scratch", "Abort"]
        )
        if idx == 2:
            ui.aborted()
            return False
        if idx == 1:
            git.unstage_files(repo_path, staged_now)
            state.set_key(repo_path, "phase", "ready_for_mine")
            ui.info("Run: fflow  to re-select.")
            return False
        current_state["phase"] = "ready_for_push"
        state.save_state(repo_path, current_state)
        ui.info("Run: fflow  to commit and push.")
        return True

    if staged_now and unstaged_now:
        ui.blank()
        ui.info(f"{len(staged_now)} file(s) already staged + {len(unstaged_now)} more unstaged change(s).")
        ui.print_file_list("Staged:", staged_now)
        idx = ui.choose(
            "What do you want to do?",
            ["Commit only staged files", "Add more files to staging", "Re-select files from scratch", "Abort"]
        )
        if idx == 3:
            ui.aborted()
            return False
        if idx == 2:
            git.unstage_files(repo_path, staged_now)
            state.set_key(repo_path, "phase", "ready_for_mine")
            ui.info("Run: fflow  to re-select.")
            return False
        if idx == 0:
            current_state["phase"] = "ready_for_push"
            state.save_state(repo_path, current_state)
            ui.info("Run: fflow  to commit and push.")
            return True

    ui.info("Enter the page/folder names YOU worked on.")
    ui.info("Use partial names, PascalCase or snake_case.")
    ui.info("Separate multiple with space or comma.")
    ui.info("Example: login, profile, actions")
    ui.blank()
    ui.info("Or type 'list' to see all available pages/folders.")
    ui.info("Or type 'all' to stage every changed file.")
    ui.info("Or type 'skip' to exit without staging.")
    ui.blank()

    while True:
        raw = input("  Your pages/folders: ").strip()
        if not raw:
            ui.error("Please enter at least one page or folder name.")
            continue

        if raw.lower() == "skip":
            ui.info("Skipped file selection. Run: fflow  to come back.")
            return False

        if raw.lower() == "all":
            all_changed = list(dict.fromkeys(staged_now + unstaged_now))
            if not all_changed:
                ui.error("No changed files found to stage.")
                continue
            existing_staged = git.get_staged_files(repo_path)
            if existing_staged:
                ui.blank()
                ui.warning(f"{len(existing_staged)} file(s) already staged.")
                idx = ui.choose("What do you want to do?", ["Merge with all changes", "Replace with all changes", "Abort"])
                if idx == 2:
                    ui.aborted()
                    return False
                if idx == 1:
                    git.unstage_files(repo_path, existing_staged)
            git.stage_files(repo_path, all_changed)
            ui.blank()
            ui.print_file_list("Staged all changed files:", all_changed)
            current_state["phase"] = "ready_for_push"
            current_state["staged_keywords"] = ["all"]
            state.save_state(repo_path, current_state)
            return True

        if raw.lower() == "list":
            _show_available(repo_path)
            continue

        keywords = _parse_mine_keywords(raw)
        resolved, ambiguous, not_found = page_mapper.resolve_keywords(repo_path, keywords)

        if not_found:
            ui.blank()
            for kw in not_found:
                ui.warning(f"'{kw}' — not found in lib/")
            if ambiguous or resolved:
                if not ui.confirm("Continue with found items and ignore not-found ones?"):
                    continue
            else:
                ui.error("No matching files found. Try again.")
                continue

        for kw, candidates in ambiguous.items():
            ui.blank()
            ui.warning(f"'{kw}' matched multiple folders:")
            indices = ui.choose_multiple(
                f"Select which to include for '{kw}':",
                candidates
            )
            selected = [candidates[i] for i in indices]
            files = []
            for folder in selected:
                files.extend(page_mapper.get_files_in_folder(repo_path, folder))
            resolved[kw] = files

        all_files = []
        for kw, files in resolved.items():
            all_files.extend(files)

        custom_files = custom_registry.list_registered(repo_path)
        for cf in custom_files:
            if cf not in all_files:
                all_files.append(cf)

        all_files = list(dict.fromkeys(all_files))

        changed_on_disk = set(git.get_staged_files(repo_path) + git.get_modified_unstaged_files(repo_path) + git.get_untracked_files(repo_path))
        unchanged = [f for f in all_files if f not in changed_on_disk]
        all_files = [f for f in all_files if f in changed_on_disk]

        if unchanged:
            ui.blank()
            ui.info(f"{len(unchanged)} file(s) from your selection have no changes — skipped:")
            for f in unchanged:
                print(f"    {f}")

        if not all_files:
            ui.blank()
            ui.warning("None of the selected files have any changes.")
            ui.info("Try different page/folder names, or type 'all' to see everything changed.")
            continue

        existing_staged = [f for f in git.get_staged_files(repo_path) if os.path.basename(f) not in FFLOW_OWN_FILES and f not in registered_files]
        if existing_staged:
            ui.blank()
            ui.warning(f"{len(existing_staged)} file(s) already staged from a previous selection.")
            idx = ui.choose(
                "What do you want to do?",
                ["Merge with new selection", "Replace with new selection", "Abort"]
            )
            if idx == 2:
                ui.aborted()
                return False
            if idx == 0:
                for f in existing_staged:
                    if f not in all_files:
                        all_files.append(f)
            else:
                git.unstage_files(repo_path, existing_staged)

        ui.blank()
        _print_grouped_files(resolved, custom_files, all_files)

        if not ui.confirm("Stage these files?"):
            ui.aborted("Nothing staged.")
            return False

        existing_on_disk = [f for f in all_files if os.path.exists(os.path.join(repo_path, f))]
        missing = [f for f in all_files if not os.path.exists(os.path.join(repo_path, f))]

        if missing:
            ui.blank()
            ui.warning(f"{len(missing)} file(s) not found on disk (skipped):")
            for f in missing:
                print(f"    {f}")

        git.stage_files(repo_path, existing_on_disk)

        ui.blank()
        ui.print_file_list("Staged Files:", existing_on_disk)

        unstaged_remaining = [
            f for f in git.get_modified_unstaged_files(repo_path)
            if os.path.basename(f) not in FFLOW_OWN_FILES
        ]
        untracked_remaining = [
            f for f in git.get_untracked_files(repo_path)
            if os.path.basename(f) not in FFLOW_OWN_FILES
        ]
        all_remaining = list(dict.fromkeys(unstaged_remaining + untracked_remaining))
        if all_remaining:
            ui.blank()
            ui.warning(f"{len(all_remaining)} remaining change(s) not staged:")
            for f in unstaged_remaining:
                print(f"    (modified)  {f}")
            for f in untracked_remaining:
                print(f"    (new file)  {f}")
            if ui.confirm("Discard these unstaged changes?"):
                if ui.confirm("This will permanently delete them. Are you sure?"):
                    git.run(["git", "checkout", "--", "."], repo_path)
                    git.run(["git", "clean", "-fd"], repo_path)
                    ui.success("Unstaged changes discarded.")
                else:
                    ui.info("Kept as-is.")
            else:
                ui.info("Kept as-is.")

        current_state["phase"] = "ready_for_push"
        current_state["staged_keywords"] = keywords
        state.save_state(repo_path, current_state)
        return True


def _show_available(repo_path):
    ui.blank()
    all_folders = page_mapper.find_all_lib_folders(repo_path)
    pages = [f for f in all_folders if "pages" in f]
    components = [f for f in all_folders if "components" in f]
    other = [f for f in all_folders if "pages" not in f and "components" not in f]

    if pages:
        ui.section("Pages:")
        for p in pages:
            print(f"    {os.path.basename(p):<30} → {p}")
    if components:
        ui.section("Components:")
        for c in components:
            print(f"    {os.path.basename(c):<30} → {c}")
    if other:
        ui.section("Other folders:")
        for o in other[:20]:
            print(f"    {os.path.basename(o):<30} → {o}")
    ui.blank()


def _print_grouped_files(resolved, custom_files, all_files):
    all_files_set = set(all_files)
    ui.section("Files to be staged:")
    for kw, files in resolved.items():
        non_custom = [f for f in files if f not in custom_files and f in all_files_set]
        if non_custom:
            print(f"\n  [{kw}]")
            for f in non_custom:
                print(f"    {f}")
    if custom_files:
        print(f"\n  [Custom / Registered files]")
        for f in custom_files:
            if f in all_files:
                print(f"    {f}")
    print(f"\n  {'─'*40}")
    print(f"  Total: {len(all_files)} file(s)")
    ui.blank()


# ─── Step: Sync ───────────────────────────────────────────────────────────────

def step_sync(repo_path, current_state, forced=False, return_phase=None):
    ui.header("fflow — Sync with Parent Branch")

    parent_branch = current_state.get("parent_branch")
    baseline = current_state.get("baseline_commit")

    git.fetch_origin(repo_path)
    has_new, count = git.parent_has_new_commits(repo_path, parent_branch, baseline)

    if not has_new and not forced:
        ui.success(f"Parent branch '{parent_branch}' is up to date. No sync needed.")
        return True

    if has_new:
        ui.warning(f"Parent branch '{parent_branch}' has {count} new commit(s) since you started.")
    
    staged = git.get_staged_files(repo_path)
    uncommitted = git.has_uncommitted_changes(repo_path)

    ui.blank()
    ui.info(f"Will rebase your branch on top of latest '{parent_branch}'.")
    if staged:
        ui.info(f"→ Will stash {len(staged)} staged file(s), rebase, then re-apply.")
    if uncommitted:
        ui.info("→ Will stash uncommitted changes, rebase, then re-apply.")

    if not ui.confirm("Proceed with sync?"):
        ui.aborted()
        if has_new:
            ui.warning("You should sync before pushing to avoid conflicts.")
        return False

    stashed = False
    if uncommitted or staged:
        ui.info("Stashing your changes...")
        current_state["pre_sync_staged"] = staged
        git.stash_changes(repo_path, "fflow-sync-stash")
        stashed = True
        ui.success("Changes stashed.")

    ui.info(f"Rebasing on origin/{parent_branch}...")
    ok = git.rebase_on(repo_path, parent_branch)

    if not ok:
        conflicted = git.get_conflicted_files(repo_path)
        FF_GENERATED_PREFIXES = (
            "lib/flutter_flow/",
            "lib/backend/schema/",
            "lib/backend/firebase/",
            "lib/auth/",
        )
        ff_files = [f for f in conflicted if any(f.startswith(p) for p in FF_GENERATED_PREFIXES)]
        your_files = [f for f in conflicted if not any(f.startswith(p) for p in FF_GENERATED_PREFIXES)]

        if ff_files:
            ui.blank()
            ui.info(f"Auto-resolving {len(ff_files)} FF-generated conflicted file(s) — keeping latest from '{parent_branch}'...")
            for f in ff_files:
                git.run(["git", "checkout", "--theirs", f], repo_path)
                git.run(["git", "add", f], repo_path)
            ui.success("FF-generated conflicts resolved — latest version kept.")

        if your_files:
            ui.blank()
            ui.error(f"Manual resolution needed for {len(your_files)} of your file(s):")
            for f in your_files:
                print(f"    {f}")

            current_state["pre_sync_phase"] = return_phase or "ready_for_mine"
            current_state["phase"] = "paused_sync"
            current_state["sync_stashed"] = stashed
            current_state["conflicted_files"] = your_files
            state.save_state(repo_path, current_state)

            ui.paused_notice(your_files)
            return False

        ok2, msg = git.rebase_continue(repo_path)
        if not ok2:
            ui.error(f"Rebase continue failed: {msg}")
            current_state["pre_sync_phase"] = return_phase or "ready_for_mine"
            current_state["phase"] = "paused_sync"
            current_state["sync_stashed"] = stashed
            state.save_state(repo_path, current_state)
            ui.paused_notice([])
            return False

    ui.success("Rebase complete.")

    if stashed:
        ui.info("Re-applying your stashed changes...")
        pre_sync_staged = current_state.pop("pre_sync_staged", [])
        git.stash_pop(repo_path)
        all_now_staged = git.get_staged_files(repo_path)
        extra_staged = [f for f in all_now_staged if f not in pre_sync_staged]
        if extra_staged:
            git.unstage_files(repo_path, extra_staged)
        if pre_sync_staged:
            existing = [f for f in pre_sync_staged if os.path.exists(os.path.join(repo_path, f))]
            if existing:
                git.stage_files(repo_path, existing)
        ui.success("Changes re-applied.")

    _, _ = custom_registry.restore_custom_files(repo_path)
    registered = custom_registry.list_registered(repo_path)
    if registered:
        ui.success(f"{len(registered)} custom file(s) re-restored after rebase.")

    new_baseline = git.get_remote_head_commit(repo_path, parent_branch)
    current_state["baseline_commit"] = new_baseline
    current_state["phase"] = return_phase or "ready_for_mine"
    state.save_state(repo_path, current_state)

    ui.success("Sync complete. You are now up to date with the parent branch.")
    return True


def step_sync_continue(repo_path, current_state):
    ui.header("fflow — Continue After Conflict Resolution")

    conflicted = git.get_conflicted_files(repo_path)
    if conflicted:
        ui.error("There are still unresolved conflicts:")
        for f in conflicted:
            print(f"    {f}")
        ui.info("Please resolve all conflicts before continuing.")
        return False

    for f in current_state.get("conflicted_files", []):
        git.run(["git", "add", f], repo_path)

    ok, msg = git.rebase_continue(repo_path)
    if not ok:
        still_conflicted = git.get_conflicted_files(repo_path)
        if still_conflicted:
            current_state["conflicted_files"] = still_conflicted
            state.save_state(repo_path, current_state)
            ui.paused_notice(still_conflicted)
            return False
        ui.error(f"Rebase continue error: {msg}")
        return False

    ui.success("Rebase complete.")

    stashed = current_state.get("sync_stashed", False)
    if stashed:
        ui.info("Re-applying stashed changes...")
        pre_sync_staged = current_state.pop("pre_sync_staged", [])
        git.stash_pop(repo_path)
        all_now_staged = git.get_staged_files(repo_path)
        extra_staged = [f for f in all_now_staged if f not in pre_sync_staged]
        if extra_staged:
            git.unstage_files(repo_path, extra_staged)
        if pre_sync_staged:
            existing = [f for f in pre_sync_staged if os.path.exists(os.path.join(repo_path, f))]
            if existing:
                git.stage_files(repo_path, existing)
        ui.success("Changes re-applied.")

    _, _ = custom_registry.restore_custom_files(repo_path)
    registered = custom_registry.list_registered(repo_path)
    if registered:
        ui.success(f"{len(registered)} custom file(s) re-restored.")

    parent_branch = current_state.get("parent_branch")
    new_baseline = git.get_remote_head_commit(repo_path, parent_branch)
    current_state["baseline_commit"] = new_baseline
    current_state["phase"] = current_state.pop("pre_sync_phase", "ready_for_mine")
    current_state.pop("conflicted_files", None)
    current_state.pop("sync_stashed", None)
    state.save_state(repo_path, current_state)

    ui.success("Sync complete. Run: fflow")
    return True


def step_sync_abort(repo_path, current_state):
    ui.header("fflow — Abort Sync")

    if not ui.confirm("Abort sync and restore to pre-sync state?"):
        ui.aborted()
        return False

    git.rebase_abort(repo_path)
    ui.success("Rebase aborted.")

    stashed = current_state.get("sync_stashed", False)
    if stashed:
        pre_sync_staged = current_state.pop("pre_sync_staged", [])
        git.stash_pop(repo_path)
        if pre_sync_staged:
            existing = [f for f in pre_sync_staged if os.path.exists(os.path.join(repo_path, f))]
            if existing:
                git.stage_files(repo_path, existing)
        ui.success("Stashed changes restored.")

    current_state["phase"] = current_state.pop("pre_sync_phase", "ready_for_mine")
    current_state.pop("conflicted_files", None)
    current_state.pop("sync_stashed", None)
    state.save_state(repo_path, current_state)

    ui.success("Sync aborted. Your branch is exactly as it was before.")
    return True


# ─── Step: Push ───────────────────────────────────────────────────────────────

def step_push(repo_path, current_state):
    ui.header("fflow — Commit & Push")

    jira_id = current_state.get("jira_id")
    parent_branch = current_state.get("parent_branch")
    baseline = current_state.get("baseline_commit")
    branch = git.current_branch(repo_path)

    staged = git.get_staged_files(repo_path)
    if not staged:
        unpushed = git.get_unpushed_commits(repo_path)
        if unpushed:
            ui.blank()
            if baseline:
                own = [(h, m) for h, m in unpushed if not _is_at_or_before_baseline(repo_path, h, baseline)]
                synced = [(h, m) for h, m in unpushed if _is_at_or_before_baseline(repo_path, h, baseline)]
            else:
                own = unpushed
                synced = []

            if own:
                ui.info(f"{len(own)} commit(s) from your work:")
                for h, msg in own:
                    print(f"    {h} — {msg}")
            if synced:
                ui.blank()
                ui.info(f"{len(synced)} commit(s) synced in from parent branch '{parent_branch}':")
                for h, msg in synced:
                    print(f"    {h} — {msg}")
            ui.blank()
            if not ui.confirm(f"Push all {len(unpushed)} commit(s) to origin/{branch}?"):
                ui.aborted()
                return False
            pushed = git.push_branch(repo_path, branch)
            if not pushed:
                ui.error("Push failed. Check git status manually.")
                return False
            cfg = config.load_config(repo_path)
            gitlab_url = cfg.get("gitlab_url", "")
            ui.blank()
            ui.success("All done! Your code has been pushed.")
            ui.info(f"Branch: {branch}")
            if gitlab_url:
                ui.info(f"URL: {gitlab_url.rstrip('/')}/-/tree/{branch}")
            state.clear_state(repo_path)
            git.drop_fflow_stashes(repo_path)
            return True
        ui.warning("No staged files found.")
        state.set_key(repo_path, "phase", "ready_for_mine")
        ui.info("Run: fflow  to select and stage your files.")
        return False

    ui.blank()
    ui.print_file_list("Currently staged files:", staged)
    ui.blank()
    idx = ui.choose(
        "What do you want to do?",
        ["Proceed to commit", "Re-select files from scratch", "Abort"]
    )
    if idx == 2:
        ui.aborted()
        return False
    if idx == 1:
        git.unstage_files(repo_path, staged)
        state.set_key(repo_path, "phase", "ready_for_mine")
        ui.info("Unstaged all files. Run: fflow  to re-select.")
        return False

    bad_commits = _check_manual_commits(repo_path, jira_id, parent_branch)
    if bad_commits:
        ui.blank()
        ui.warning(f"Found {len(bad_commits)} commit(s) with non-standard message format:")
        for h, msg in bad_commits:
            print(f"    {h} — \"{msg}\"  ✖ invalid format")
        ui.blank()
        idx = ui.choose(
            "What do you want to do?",
            ["Amend last commit message", "Push anyway (not recommended)", "Abort"]
        )
        if idx == 2:
            ui.aborted()
            return False
        if idx == 0:
            _amend_commit(repo_path, jira_id)
            return False
        if idx == 1:
            if not ui.confirm("Are you sure you want to push with non-standard commit message?"):
                ui.aborted()
                return False

    git.fetch_origin(repo_path)
    has_new, count = git.parent_has_new_commits(repo_path, parent_branch, baseline)
    if has_new:
        ui.blank()
        ui.warning(f"Parent branch '{parent_branch}' has {count} new commit(s) since your last sync.")
        ui.warning("You must sync before pushing to avoid MR conflicts.")
        idx = ui.choose(
            "What do you want to do?",
            [f"Sync with '{parent_branch}' now (required)", "Abort"]
        )
        if idx == 1:
            ui.aborted()
            return False
        synced = step_sync(repo_path, current_state, return_phase="ready_for_push")
        if not synced:
            return False
        current_state = state.load_state(repo_path)

    last_commit = git.get_last_commit_info(repo_path)
    if last_commit:
        ui.blank()
        ui.info(f"Last commit:  {last_commit['hash']} — \"{last_commit['message']}\"  ({last_commit['time']})")

    keywords = current_state.get("staged_keywords", [])
    page_names = ", ".join([k.title() for k in keywords]) if keywords else "changes"
    suggested_desc = f"{page_names} changes"
    commit_message = f"{jira_id} {suggested_desc}"

    ui.blank()
    ui.info(f"Suggested commit message:  {commit_message}")
    ui.info(f"(Jira ID prefix '{jira_id}' is fixed — you can edit the description part)")
    raw_desc = input(f"  Description [{suggested_desc}]: ").strip()
    if raw_desc:
        commit_message = f"{jira_id} {raw_desc}"

    ui.blank()
    ui.info(f"Final commit message:  {commit_message}")
    ui.print_file_list("Files to commit:", staged)

    if not ui.confirm("Commit?"):
        ui.aborted()
        return False

    committed = git.commit(repo_path, commit_message)
    if not committed:
        ui.error("Commit failed. Check for errors above.")
        ui.info("Your staged files are still intact. Fix the issue and run: fflow")
        return False

    ui.success("Committed.")
    ui.blank()

    idx = ui.choose(
        "What do you want to do?",
        [f"Push to origin/{branch}", "Undo last commit (keep files staged)", "Nothing for now"]
    )

    if idx == 2:
        ui.info("Commit saved locally. Run: fflow  to push when ready.")
        return True

    if idx == 1:
        ok = git.undo_last_commit(repo_path)
        if ok:
            state.set_key(repo_path, "phase", "ready_for_mine")
            still_staged = git.get_staged_files(repo_path)
            if still_staged:
                ui.success(f"Commit undone. {len(still_staged)} file(s) are staged and ready.")
            else:
                ui.warning("Commit undone but files are no longer staged (may be unstaged/modified).")
                ui.info("Run: git status  to see current state.")
            ui.info("Run: fflow  to re-select and re-commit.")
        else:
            ui.error("Undo failed. Run: git reset --soft HEAD~1  manually.")
        return False

    ui.info(f"Pushing to origin/{branch}...")

    pushed = git.push_branch(repo_path, branch)
    if not pushed:
        ui.blank()
        ui.error("Push rejected by GitLab — remote branch may have diverged.")
        idx = ui.choose(
            "What do you want to do?",
            ["Run sync and retry", "Force push (⚠ dangerous)", "Abort"]
        )
        if idx == 2:
            ui.aborted()
            return False
        if idx == 0:
            synced = step_sync(repo_path, current_state, forced=True, return_phase="ready_for_push")
            if synced:
                pushed2 = git.push_branch(repo_path, branch)
                if not pushed2:
                    ui.error("Push still failed after sync. Check git status manually.")
                    return False
        elif idx == 1:
            if ui.confirm_strong("Force push will overwrite remote. This cannot be undone.", "CONFIRM"):
                git.push_branch(repo_path, branch, force=True)
            else:
                ui.aborted()
                return False

    cfg = config.load_config(repo_path)
    gitlab_url = cfg.get("gitlab_url", "")
    ui.blank()
    ui.success("All done! Your code has been pushed.")
    ui.info(f"Branch: {branch}")
    if gitlab_url:
        branch_url = f"{gitlab_url.rstrip('/')}/-/tree/{branch}"
        ui.info(f"URL: {branch_url}")

    state.clear_state(repo_path)
    dropped = git.drop_fflow_stashes(repo_path)
    if dropped:
        ui.info(f"Cleaned up {dropped} fflow stash(es).")
    ui.blank()
    return True


def _amend_commit(repo_path, jira_id):
    ui.blank()
    desc = ui.ask("Enter short description (e.g. LoginPage UI changes)")
    new_msg = f"{jira_id} {desc}"
    ui.info(f"New commit message: {new_msg}")
    if ui.confirm("Amend commit with this message?"):
        git.amend_commit_message(repo_path, new_msg)
        ui.success("Commit message amended. Run: fflow")
    else:
        ui.aborted()
