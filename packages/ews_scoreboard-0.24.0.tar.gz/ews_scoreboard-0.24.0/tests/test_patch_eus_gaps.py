"""
Tests for patch_eus_gaps() — single-period gap interpolation in brz_eus_tahmin.

Run: python -m pytest tests/test_patch_eus_gaps.py -v
"""

import sys
from pathlib import Path

import duckdb
import pytest

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from ews_scoreboard.pipeline.patch_eus import patch_eus_gaps


@pytest.fixture
def db_path(tmp_path):
    """Create a temporary DuckDB with brz_eus_tahmin table."""
    p = tmp_path / "test.duckdb"
    con = duckdb.connect(str(p))
    con.execute("""
        CREATE TABLE brz_eus_tahmin (
            muta VARCHAR,
            donem VARCHAR,
            eus_skor DOUBLE,
            eus_ihtimal DOUBLE
        )
    """)
    return p, con


class TestPatchEusGaps:
    def test_single_gap_filled(self, db_path):
        """Firm has 2501 and 2503 but not 2502 → 2502 gets interpolated."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2503', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        row = con.execute(
            "SELECT eus_skor, eus_ihtimal FROM brz_eus_tahmin WHERE muta='100' AND donem='2502'"
        ).fetchone()
        con.close()

        assert row is not None, "Gap period 2502 should have been inserted"
        assert row[0] == 700.0, f"Expected avg 700.0, got {row[0]}"
        assert abs(row[1] - 0.8) < 0.0001, f"Expected avg 0.8, got {row[1]}"

    def test_no_gap_no_insert(self, db_path):
        """Firm has all 3 consecutive periods → no patch needed."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2502', 650.0, 0.75),
            ('100', '2503', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        cnt = con.execute("SELECT COUNT(*) FROM brz_eus_tahmin").fetchone()[0]
        con.close()
        assert cnt == 3, f"No rows should be added, got {cnt}"

    def test_two_period_gap_not_filled(self, db_path):
        """Firm has 2501 and 2504 (2-period gap) → should NOT fill."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2504', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        cnt = con.execute("SELECT COUNT(*) FROM brz_eus_tahmin").fetchone()[0]
        # 2502 and 2503 are both missing — neither is a single-period gap
        # 2502: prev=2501(yes), next=2503(no) → skip
        # 2503: prev=2502(no), next=2504(yes) → skip
        con.close()
        assert cnt == 2, f"Two-period gap should not be patched, got {cnt} rows"

    def test_multiple_firms(self, db_path):
        """Two firms, one has a gap, one doesn't."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2503', 800.0, 0.9),
            ('200', '2501', 500.0, 0.5),
            ('200', '2502', 550.0, 0.55),
            ('200', '2503', 600.0, 0.6)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        cnt = con.execute("SELECT COUNT(*) FROM brz_eus_tahmin").fetchone()[0]
        patched = con.execute(
            "SELECT eus_skor FROM brz_eus_tahmin WHERE muta='100' AND donem='2502'"
        ).fetchone()
        con.close()

        assert cnt == 6, f"Expected 6 rows (5+1 patch), got {cnt}"
        assert patched is not None
        assert patched[0] == 700.0

    def test_year_boundary_gap(self, db_path):
        """Gap spans year boundary: 2412 → 2501 → 2502."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2412', 600.0, 0.7),
            ('100', '2502', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        row = con.execute(
            "SELECT eus_skor FROM brz_eus_tahmin WHERE muta='100' AND donem='2501'"
        ).fetchone()
        con.close()

        assert row is not None, "Year-boundary gap 2501 should be filled"
        assert row[0] == 700.0

    def test_null_ihtimal_handled(self, db_path):
        """If one side has NULL ihtimal, patched ihtimal should be NULL."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, NULL),
            ('100', '2503', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        row = con.execute(
            "SELECT eus_skor, eus_ihtimal FROM brz_eus_tahmin WHERE muta='100' AND donem='2502'"
        ).fetchone()
        con.close()

        assert row is not None
        assert row[0] == 700.0
        assert row[1] is None, f"ihtimal should be NULL when one side is NULL, got {row[1]}"

    def test_empty_table(self, db_path):
        """Empty table → should skip gracefully."""
        p, con = db_path
        con.close()
        patch_eus_gaps(p)  # should not raise

    def test_less_than_3_periods(self, db_path):
        """Only 2 periods in table → should skip (can't have a gap)."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2502', 800.0, 0.9)
        """)
        con.close()
        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        cnt = con.execute("SELECT COUNT(*) FROM brz_eus_tahmin").fetchone()[0]
        con.close()
        assert cnt == 2

    def test_existing_rows_not_modified(self, db_path):
        """Patch should INSERT, never UPDATE existing rows."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2503', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        orig1 = con.execute(
            "SELECT eus_skor, eus_ihtimal FROM brz_eus_tahmin WHERE muta='100' AND donem='2501'"
        ).fetchone()
        orig2 = con.execute(
            "SELECT eus_skor, eus_ihtimal FROM brz_eus_tahmin WHERE muta='100' AND donem='2503'"
        ).fetchone()
        con.close()

        assert orig1 == (600.0, 0.7), "Original row 2501 should not be modified"
        assert orig2 == (800.0, 0.9), "Original row 2503 should not be modified"

    def test_idempotent(self, db_path):
        """Running patch twice should not duplicate rows."""
        p, con = db_path
        con.execute("""
            INSERT INTO brz_eus_tahmin VALUES
            ('100', '2501', 600.0, 0.7),
            ('100', '2503', 800.0, 0.9)
        """)
        con.close()

        patch_eus_gaps(p)
        patch_eus_gaps(p)

        con = duckdb.connect(str(p), read_only=True)
        cnt = con.execute(
            "SELECT COUNT(*) FROM brz_eus_tahmin WHERE muta='100' AND donem='2502'"
        ).fetchone()[0]
        con.close()
        assert cnt == 1, f"Idempotent: expected 1 patched row, got {cnt}"
