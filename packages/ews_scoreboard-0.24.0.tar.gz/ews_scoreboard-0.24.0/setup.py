"""Cython extension setup for compiled wheel builds.

PURE_PYTHON=1 ortam değişkeni ile Cython derleme atlanır.
sdist'ten kurulurken gcc yoksa otomatik olarak pure Python'a düşer.
"""
import os
from setuptools import setup

SKIP = {"__init__.py"}


def get_ext_modules():
    # Pure Python modu: PURE_PYTHON=1 veya Cython/gcc yoksa
    if os.environ.get("PURE_PYTHON", "0") == "1":
        return []

    try:
        from Cython.Build import cythonize
    except ImportError:
        return []

    # gcc kontrolü
    import shutil
    if not shutil.which("gcc") and not shutil.which("cc"):
        return []

    py_files = []
    for root, dirs, files in os.walk("src/ews_scoreboard"):
        for f in files:
            if f.endswith(".py") and f not in SKIP:
                py_files.append(os.path.join(root, f))

    return cythonize(py_files, language_level=3)


setup(ext_modules=get_ext_modules())
