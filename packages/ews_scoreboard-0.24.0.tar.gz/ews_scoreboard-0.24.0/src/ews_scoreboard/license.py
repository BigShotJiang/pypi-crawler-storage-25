"""
License validation for EWS Scoreboard.

Key format: XXXX-XXXX-XXXX-XXXX
Validation: HMAC(part1+part2, secret) == part3+part4
"""

import hashlib
import hmac
import sys
from pathlib import Path

# Compiled .so içinde gömülü kalır
_K = bytes([102, 56, 119, 83, 99, 48, 114, 51])
_S = bytes([98, 111, 97, 114, 100, 95, 50, 48, 50, 53])
_SECRET = _K + _S

_LICENSE_PATH = Path.home() / ".ews_license"


def _compute_check(payload: str) -> str:
    h = hmac.new(_SECRET, payload.upper().encode(), hashlib.sha256).hexdigest()
    return h[:8].upper()


def generate_key(payload: str = None) -> str:
    """Yeni lisans anahtarı üret (sadece geliştirici kullanımı)."""
    if payload is None:
        import secrets
        payload = secrets.token_hex(4).upper()
    payload = payload.upper()[:8]
    check = _compute_check(payload)
    return f"{payload[:4]}-{payload[4:8]}-{check[:4]}-{check[4:8]}"


def validate_key(key: str) -> bool:
    """Lisans anahtarını doğrula."""
    parts = key.strip().upper().split("-")
    if len(parts) != 4 or any(len(p) != 4 for p in parts):
        return False
    payload = parts[0] + parts[1]
    expected = _compute_check(payload)
    actual = parts[2] + parts[3]
    return actual == expected


def activate(key: str) -> bool:
    """Lisansı aktive et (anahtarı diske yaz)."""
    if not validate_key(key):
        return False
    _LICENSE_PATH.write_text(key.strip().upper(), encoding="utf-8")
    return True


def is_licensed() -> bool:
    """Geçerli lisans var mı kontrol et."""
    if not _LICENSE_PATH.exists():
        return False
    key = _LICENSE_PATH.read_text(encoding="utf-8").strip()
    return validate_key(key)


def require_license():
    """Lisans yoksa programı durdur."""
    if is_licensed():
        return
    print("Lisans gerekli.")
    print("  ews-scoreboard activate XXXX-XXXX-XXXX-XXXX")
    sys.exit(1)
