-- EWS Dashboard - DDL
-- Engine: DuckDB

-- ============================================================
-- BRONZE TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS brz_kik_izleme (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    ykn_izl_flag    VARCHAR,
    tfrs_rating     VARCHAR,
    rating_tarihi   VARCHAR,
    kik_risk        BIGINT,
    unvan           VARCHAR,
    gckm_gun_say    INTEGER,
    erkn_izlm_kod   VARCHAR,
    ciss_flag       INTEGER
);

CREATE TABLE IF NOT EXISTS brz_kredi_risk (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    kredi_risk      BIGINT
);

CREATE TABLE IF NOT EXISTS brz_yis_tahmin (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    yis_skor        INTEGER,
    yis_ihtimal     DOUBLE,
    yis_label       INTEGER
);

CREATE TABLE IF NOT EXISTS brz_eus_tahmin (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    eus_skor        DOUBLE,
    eus_ihtimal     DOUBLE
);

CREATE TABLE IF NOT EXISTS brz_eus_hedef (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS brz_eus_kapsam (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL
);

CREATE TABLE IF NOT EXISTS brz_statik (
    muta                VARCHAR NOT NULL,
    bolge_kodu          INTEGER,
    bolge_adi           VARCHAR,
    sube_kodu           INTEGER,
    sube_adi            VARCHAR,
    must_tip_kodu       VARCHAR,
    grup_kodu           VARCHAR,
    grup_tanimi          VARCHAR,
    firma_otorize_kodu  VARCHAR,
    aksiyon_sahibi      VARCHAR,
    kri_bolum           VARCHAR
);

CREATE TABLE IF NOT EXISTS brz_rkd_kriter (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    min_uzak_gun    INTEGER,
    sifir_flag      INTEGER
);

CREATE TABLE IF NOT EXISTS brz_memzuc (
    muta                VARCHAR NOT NULL,
    donem               VARCHAR NOT NULL,
    idari_kanuni_takip   DOUBLE,
    ikt_6ay_ort          DOUBLE
);

CREATE TABLE IF NOT EXISTS brz_train_features (
    muta            VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    segment         VARCHAR
);

CREATE TABLE IF NOT EXISTS brz_raporlama_depo (
    muta                VARCHAR NOT NULL,
    donem               VARCHAR NOT NULL,
    must_ad             VARCHAR,
    sube_kodu           INTEGER,
    bolge_adi           VARCHAR,
    must_tip_kodu       INTEGER,
    grup_tanimi          VARCHAR,
    firma_otorize_kodu  VARCHAR,
    genel_risk_toplam   DOUBLE,
    nakit_risk_toplam   DOUBLE,
    gnakit_risk_toplam  DOUBLE,
    son_izleme_kodu     VARCHAR,
    risk_grup_kodu      VARCHAR,
    pgy                 VARCHAR,
    finansman_konu      VARCHAR,
    tahsis_onay_birimi  VARCHAR
);

-- ============================================================
-- SILVER TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS dim_entity (
    entity_id           BIGINT PRIMARY KEY,
    segment             VARCHAR,
    bolge_kodu          INTEGER,
    sube_kodu           INTEGER,
    must_tip_kodu       VARCHAR,
    grup_kodu           VARCHAR,
    grup_tanimi          VARCHAR,
    firma_otorize_kodu  VARCHAR,
    aksiyon_sahibi      VARCHAR,
    kri_bolum           VARCHAR,
    son_izleme_kodu     VARCHAR,
    risk_grup_kodu      VARCHAR,
    pgy                 VARCHAR,
    finansman_konu      VARCHAR,
    tahsis_onay_birimi  VARCHAR
);

CREATE TABLE IF NOT EXISTS fact_periodic (
    entity_id       BIGINT NOT NULL,
    donem           VARCHAR NOT NULL,
    yis_skor        INTEGER,
    yis_ihtimal     DOUBLE,
    yis_label       INTEGER,
    eus_skor        DOUBLE,
    eus_ihtimal     DOUBLE,
    eus_tahmin_label INTEGER,
    eus_kapsam      INTEGER,
    eus_hedef       INTEGER,
    ews_skor        VARCHAR,
    ews_kaynak      VARCHAR,
    ykn_izl_flag    INTEGER,
    kombine_risk    BIGINT,
    kredi_risk      BIGINT,
    kik_risk        BIGINT,
    depo_risk       BIGINT,
    nakit_risk      BIGINT,
    gnakit_risk     BIGINT,
    risk_degisim    BIGINT,
    tfrs_rating     VARCHAR,
    rating_tarihi   VARCHAR,
    PRIMARY KEY (entity_id, donem)
);

CREATE TABLE IF NOT EXISTS map_identity (
    entity_id   BIGINT PRIMARY KEY,
    muta        BIGINT NOT NULL,
    unvan       VARCHAR
);

-- ============================================================
-- REFERENCE TABLES
-- ============================================================

CREATE TABLE IF NOT EXISTS ref_sube_bolge (
    sube_kodu   INTEGER PRIMARY KEY,
    sube_adi    VARCHAR,
    bolge_kodu  INTEGER NOT NULL,
    bolge_adi   VARCHAR
);
