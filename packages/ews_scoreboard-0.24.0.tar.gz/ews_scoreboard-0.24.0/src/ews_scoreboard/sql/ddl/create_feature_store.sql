-- Feature Store DDL
-- Grain: entity_id × donem × feature_name

CREATE TABLE IF NOT EXISTS feature_store (
    entity_id       VARCHAR NOT NULL,
    donem           VARCHAR NOT NULL,
    feature_name    VARCHAR NOT NULL,
    value_num       DOUBLE,
    value_cat       VARCHAR,
    PRIMARY KEY (entity_id, donem, feature_name)
);

-- Index for efficient feature slicing
CREATE INDEX IF NOT EXISTS idx_fs_feature
ON feature_store (feature_name, donem);

-- Index for entity timeline queries
CREATE INDEX IF NOT EXISTS idx_fs_entity_time
ON feature_store (entity_id, donem);
