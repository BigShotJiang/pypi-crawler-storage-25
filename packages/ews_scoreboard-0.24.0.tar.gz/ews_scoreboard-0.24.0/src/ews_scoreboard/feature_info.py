"""Merkezi kolon/kriter tanım yöneticisi.

Kaynak: feature_info.xlsx → feature_info.json (init sırasında dönüşüm)
Runtime: feature_info.json okunur (hızlı, openpyxl bağımlılığı yok)

Kullanım:
    from ews_scoreboard.feature_info import FI

    FI.kik_ciss_cols        # CISS kontrolüne dahil KIK kolonları
    FI.kik_all_cols         # Tüm KIK kontrol kolonları (CISS + special)
    FI.rkd_codes            # eu_n_yi_rkd_list karşılığı
    FI.rkd_sifir_cols       # Sıfır olması gereken RKD kolonları (kod_suffix)
    FI.rkd_uzak_cols        # Gün mesafesi kontrolü kolonları
    FI.rkd_delta_suffixes   # Delta hesabına dahil suffix'ler
    FI.kriter_aciklama      # kod → açıklama dict
    FI.delta_exclude_cols   # Delta hesabından hariç tutulan kolonlar
    FI.grup_for_rkd(code)   # RKD kodu → grup adı
    FI.grup_for_kik(col)    # KIK kolonu → grup adı
    FI.memzuc_kontrol_cols  # Memzuc nonzero kontrol kolonları
"""

import json
import warnings
from pathlib import Path


class FeatureInfo:
    def __init__(self):
        self._data = None

    def _load(self):
        """Lazy load — ilk erişimde JSON oku."""
        if self._data is not None:
            return

        for candidate in [
            Path("feature_info.json"),
            Path(__file__).parent / "data" / "feature_info.json",
        ]:
            if candidate.exists():
                self._data = json.loads(candidate.read_text(encoding="utf-8"))
                return

        warnings.warn(
            "feature_info.json bulunamadı, default değerler kullanılıyor. "
            "'ews-scoreboard init' çalıştırın.",
            stacklevel=2,
        )
        self._data = {"kik": [], "rkd": [], "memzuc": [], "izleme_kriterleri": []}

    # ── KIK ──

    @property
    def kik_ciss_cols(self):
        """CISS kontrolüne dahil KIK kolonları (ciss=1)."""
        self._load()
        return list(dict.fromkeys(
            r["kolon_adi"] for r in self._data["kik"] if r.get("ciss") == 1
        ))

    @property
    def kik_all_cols(self):
        """Tüm KIK kontrol kolonları."""
        self._load()
        return list(dict.fromkeys(r["kolon_adi"] for r in self._data["kik"]))

    @property
    def kik_delta_cols(self):
        """KIK delta hesabına dahil kolonlar (delta_dahil=1)."""
        self._load()
        return list(dict.fromkeys(
            r["kolon_adi"] for r in self._data["kik"] if r.get("delta_dahil") == 1
        ))

    def grup_for_kik(self, col):
        """KIK kolonu → grup adı."""
        self._load()
        for r in self._data["kik"]:
            if r["kolon_adi"] == col:
                return r.get("grup")
        return None

    # ── RKD ──

    @property
    def rkd_codes(self):
        """EUS kapsam RKD kriter kod listesi (eu_n_yi_rkd_list karşılığı)."""
        self._load()
        return [r["kod"] for r in self._data["rkd"] if r.get("eus_kapsam", 1) != 0]

    @property
    def rkd_all_codes(self):
        """Tüm RKD kriter kodları (diag grupları dahil)."""
        self._load()
        return [r["kod"] for r in self._data["rkd"]]

    @property
    def rkd_sifir_cols(self):
        """Sıfır olması gereken RKD kolonları (kod_SUFFIX formatında)."""
        self._load()
        cols = []
        for r in self._data["rkd"]:
            for sfx in ["suffix_a", "suffix_asgd", "suffix_aigd"]:
                if r.get(sfx) == "sifir":
                    suffix_name = sfx.replace("suffix_", "").upper()
                    cols.append(f"{r['kod']}_{suffix_name}")
        return cols

    @property
    def rkd_uzak_cols(self):
        """Gün mesafesi kontrolü kolonları (kod_SUFFIX formatında)."""
        self._load()
        cols = []
        for r in self._data["rkd"]:
            for sfx in ["suffix_pscd", "suffix_pigd"]:
                if r.get(sfx) == "uzak":
                    suffix_name = sfx.replace("suffix_", "").upper()
                    cols.append(f"{r['kod']}_{suffix_name}")
        return cols

    @property
    def rkd_delta_suffixes(self):
        """Delta hesabına dahil suffix'ler: ['A', 'P'] vb."""
        self._load()
        suffixes = set()
        for r in self._data["rkd"]:
            if r.get("suffix_a") in ("sifir", "delta"):
                suffixes.add("A")
            if r.get("suffix_p") == "delta":
                suffixes.add("P")
        return sorted(suffixes)

    def grup_for_rkd(self, code):
        """RKD kodu → grup adı."""
        self._load()
        for r in self._data["rkd"]:
            if r["kod"] == code:
                return r.get("grup")
        return None

    # ── Memzuc ──

    @property
    def memzuc_kontrol_cols(self):
        """Memzuc nonzero kontrol kolonları."""
        self._load()
        return [r["kolon_adi"] for r in self._data["memzuc"]
                if r.get("kontrol_tipi") == "nonzero"]

    @property
    def memzuc_delta_cols(self):
        """Memzuc delta hesabına dahil kolonlar."""
        self._load()
        return [r["kolon_adi"] for r in self._data["memzuc"]
                if r.get("delta_dahil") == 1]

    def grup_for_memzuc(self, col):
        """Memzuc kolonu → grup adı."""
        self._load()
        for r in self._data["memzuc"]:
            if r["kolon_adi"] == col:
                return r.get("grup")
        return None

    # ── Cross-cutting ──

    @property
    def kriter_aciklama(self):
        """Tüm kriter kodu → açıklama dict (RKD + KIK + izleme)."""
        self._load()
        d = {}
        for r in self._data.get("izleme_kriterleri", []):
            d[r["kod"]] = r["aciklama"]
        for r in self._data["rkd"]:
            d[r["kod"]] = r["aciklama"]
        for r in self._data["kik"]:
            d[r["kolon_adi"]] = r["aciklama"]
        for r in self._data["memzuc"]:
            d[r["kolon_adi"]] = r["aciklama"]
        return d

    @property
    def delta_exclude_cols(self):
        """Delta hesabından hariç tutulan kolonlar (asla yeni=1 olamaz)."""
        self._load()
        cols = []
        for sheet in ["kik", "memzuc"]:
            for r in self._data.get(sheet, []):
                if r.get("delta_dahil") == 0:
                    cols.append(r.get("kolon_adi", ""))
        return [c for c in cols if c]

    # ── Reverse mappings (diag_groups uyumlu) ──

    @property
    def rkd_code_to_group(self):
        """RKD kodu → grup dict."""
        self._load()
        return {r["kod"]: r["grup"] for r in self._data["rkd"] if r.get("grup")}

    @property
    def kik_col_to_group(self):
        """KIK kolonu → grup dict."""
        self._load()
        return {r["kolon_adi"]: r["grup"] for r in self._data["kik"] if r.get("grup")}

    @property
    def memzuc_col_to_group(self):
        """Memzuc kolonu → grup dict."""
        self._load()
        return {r["kolon_adi"]: r["grup"] for r in self._data["memzuc"]
                if r.get("grup") and r["grup"] != "-"}


# Singleton
FI = FeatureInfo()
