"""
Diag Groups: EUS kapsam dışı kalma teşhis bulgularının anlamlı gruplara ayrılması.

7 grup görsel tanımı + feature_info.json'dan okunan kod→grup eşleştirmesi.
Backend (nb_06a, marts) ve frontend (template) tarafından kullanılır.
"""

# ── Grup görsel tanımları (ikon, renk, pozisyon, öncelik) ──

DIAG_GROUPS = {
    "gecikme": {
        "label": "Ödeme Gecikmesi",
        "icon": "▲",
        "color": "#e74c3c",
        "position": "top-right",
        "priority": 5,
    },
    "ortak": {
        "label": "Ortak Olumsuzluğu",
        "icon": "◆",
        "color": "#e67e22",
        "position": "top-left",
        "priority": 3,
    },
    "cek_senet": {
        "label": "Çek / Senet",
        "icon": "■",
        "color": "#8e44ad",
        "position": "bottom-right",
        "priority": 4,
    },
    "diger_banka": {
        "label": "Diğer Banka Olumsuzluğu",
        "icon": "★",
        "color": "#2980b9",
        "position": "bottom-left",
        "priority": 2,
    },
    "icra": {
        "label": "İcra / Haciz",
        "icon": "◇",
        "color": "#d35400",
        "position": "center-right",
        "priority": 5,
    },
    "yasal": {
        "label": "İflas / Konkordato",
        "icon": "⚠",
        "color": "#c0392b",
        "position": "top-center",
        "priority": 6,
    },
    "izleme": {
        "label": "İzleme / Erken Uyarı",
        "icon": "●",
        "color": "#2c3e50",
        "position": "center-left",
        "priority": 1,
    },
}

# SQL kapsam dışı — sadece admin HTML'de gösterilecek
SQL_GROUP = "diger_banka"
SQL_ADMIN_ONLY = True

# ── Reverse mappings — feature_info.json'dan türetilir ──

try:
    from ews_scoreboard.feature_info import FI

    RKD_CODE_TO_GROUP = FI.rkd_code_to_group
    KIK_COL_TO_GROUP = FI.kik_col_to_group
    MEMZUC_COL_TO_GROUP = FI.memzuc_col_to_group
    DELTA_EXCLUDE_COLS = FI.delta_exclude_cols
    KRITER_ACIKLAMA = FI.kriter_aciklama
    KIK_COL_ACIKLAMA = {col: FI.kriter_aciklama.get(col, col) for col in FI.kik_all_cols}
    MEMZUC_COL_ACIKLAMA = {col: FI.kriter_aciklama.get(col, col)
                           for col in FI.memzuc_kontrol_cols}

    # DIAG_GROUPS'a rkd_codes ve kik_cols ekle (frontend uyumu için)
    _rkd_map = {}
    for _code, _grp in RKD_CODE_TO_GROUP.items():
        _rkd_map.setdefault(_grp, []).append(_code)
    _kik_map = {}
    for _col, _grp in KIK_COL_TO_GROUP.items():
        _kik_map.setdefault(_grp, []).append(_col)
    _memzuc_map = {}
    for _col, _grp in MEMZUC_COL_TO_GROUP.items():
        _memzuc_map.setdefault(_grp, []).append(_col)

    for _grp in DIAG_GROUPS:
        DIAG_GROUPS[_grp]["rkd_codes"] = _rkd_map.get(_grp, [])
        DIAG_GROUPS[_grp]["kik_cols"] = _kik_map.get(_grp, [])
        if _grp in _memzuc_map:
            DIAG_GROUPS[_grp]["memzuc_cols"] = _memzuc_map[_grp]

except Exception:
    # Fallback: feature_info.json yoksa boş mapping'ler
    import warnings as _w
    _w.warn("feature_info.json yüklenemedi, diag_groups boş mapping kullanıyor")
    RKD_CODE_TO_GROUP = {}
    KIK_COL_TO_GROUP = {}
    MEMZUC_COL_TO_GROUP = {}
    DELTA_EXCLUDE_COLS = []
    KRITER_ACIKLAMA = {}
    KIK_COL_ACIKLAMA = {}
    MEMZUC_COL_ACIKLAMA = {}
