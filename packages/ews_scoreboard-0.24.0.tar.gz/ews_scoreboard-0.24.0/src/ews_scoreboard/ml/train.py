"""
Train YI prediction model + SHAP explainer.

Usage:
    from ews_scoreboard.ml.train import train_model
    result = train_model(db_path)
    # result["model_path"] → saved model
    # result["metrics"] → AUC, precision, recall, etc.
"""

import json
import pickle
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    roc_auc_score, precision_score, recall_score, f1_score,
    classification_report
)

try:
    import lightgbm as lgb
    HAS_LGB = True
except ImportError:
    HAS_LGB = False

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

from ews_scoreboard.ml.features import build_features, FEATURE_COLS


def train_model(db_path: Path, output_dir: Path = None,
                test_size: float = 0.2, random_state: int = 42) -> dict:
    """Train LightGBM model for YI prediction.

    Args:
        db_path: Path to DuckDB file with fact_periodic.
        output_dir: Where to save model artifacts. Defaults to db parent / ml_models.
        test_size: Train/test split ratio.
        random_state: Random seed.

    Returns:
        dict with model_path, metrics, feature_importance.
    """
    if not HAS_LGB:
        raise ImportError("lightgbm required: pip install lightgbm")

    db_path = Path(db_path)
    if output_dir is None:
        output_dir = db_path.parent.parent / "ml_models"
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── Build features ──
    print("  Building feature matrix...")
    df = build_features(db_path)

    if df.empty:
        print("  [WARN] No data for training")
        return {"status": "no_data"}

    # Drop rows without labels (last periods with no future data)
    df = df.dropna(subset=["label"])
    df["label"] = df["label"].astype(int)

    if len(df) < 50:
        print(f"  [WARN] Only {len(df)} labeled rows, too few for training")
        return {"status": "insufficient_data", "n_rows": len(df)}

    X = df[FEATURE_COLS].copy()
    y = df["label"]

    # Handle NaN in features
    X = X.fillna(-999)

    print(f"  Dataset: {len(X)} rows, {y.sum()} positive ({y.mean()*100:.1f}%)")

    # ── Train/test split ──
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # ── LightGBM ──
    # CUDA kontrolü: varsa GPU, yoksa CPU
    _device = "cpu"
    try:
        import subprocess
        r = subprocess.run(["nvidia-smi"], capture_output=True, timeout=5)
        if r.returncode == 0:
            _device = "cuda"
    except Exception:
        pass

    print(f"  Training LightGBM (device={_device})...")
    params = {
        "objective": "binary",
        "metric": "auc",
        "verbosity": -1,
        "device": _device,
        "n_estimators": 300,
        "learning_rate": 0.05,
        "max_depth": 6,
        "num_leaves": 31,
        "min_child_samples": 10,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "reg_alpha": 0.1,
        "reg_lambda": 0.1,
        "random_state": random_state,
        "is_unbalance": True,  # handle class imbalance
    }

    model = lgb.LGBMClassifier(**params)
    model.fit(
        X_train, y_train,
        eval_set=[(X_test, y_test)],
        callbacks=[lgb.log_evaluation(period=0)],  # silent
    )

    # ── Evaluate ──
    y_prob = model.predict_proba(X_test)[:, 1]
    y_pred = (y_prob >= 0.5).astype(int)

    auc = roc_auc_score(y_test, y_prob)
    precision = precision_score(y_test, y_pred, zero_division=0)
    recall = recall_score(y_test, y_pred, zero_division=0)
    f1 = f1_score(y_test, y_pred, zero_division=0)

    print(f"  AUC: {auc:.4f}  |  Precision: {precision:.4f}  |  "
          f"Recall: {recall:.4f}  |  F1: {f1:.4f}")
    print(f"  {classification_report(y_test, y_pred, zero_division=0)}")

    # ── Feature importance ──
    importance = dict(zip(FEATURE_COLS, model.feature_importances_.tolist()))
    top_features = sorted(importance.items(), key=lambda x: x[1], reverse=True)[:10]
    print("  Top features:")
    for feat, imp in top_features:
        print(f"    {feat}: {imp}")

    # ── SHAP explainer ──
    explainer = None
    if HAS_SHAP:
        print("  Building SHAP explainer...")
        explainer = shap.TreeExplainer(model)
        # Verify on small sample
        sample = X_test.head(10)
        sv = explainer.shap_values(sample)
        print(f"  SHAP OK: {len(sv)} samples, {len(sv[0])} features")
    else:
        print("  [WARN] shap not installed, skipping explainer")

    # ── Save artifacts ──
    model_path = output_dir / "yi_model.pkl"
    with open(model_path, "wb") as f:
        pickle.dump({
            "model": model,
            "explainer": explainer,
            "feature_cols": FEATURE_COLS,
            "params": params,
            "metrics": {"auc": auc, "precision": precision, "recall": recall, "f1": f1},
        }, f)
    print(f"  Model saved: {model_path}")

    # Save metrics as JSON too
    metrics_path = output_dir / "yi_model_metrics.json"
    with open(metrics_path, "w") as f:
        json.dump({
            "auc": auc, "precision": precision, "recall": recall, "f1": f1,
            "train_size": len(X_train), "test_size": len(X_test),
            "positive_rate": float(y.mean()),
            "top_features": {k: v for k, v in top_features},
        }, f, indent=2)

    return {
        "status": "ok",
        "model_path": str(model_path),
        "metrics": {"auc": auc, "precision": precision, "recall": recall, "f1": f1},
        "feature_importance": importance,
    }
