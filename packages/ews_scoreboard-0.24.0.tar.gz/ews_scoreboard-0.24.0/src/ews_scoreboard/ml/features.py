"""
Feature engineering for YI prediction model.

Input: fact_periodic table (entity_id x donem)
Output: feature matrix with rolling EWS stats, risk deltas, flag history.

Features (per entity x donem):
  - ews_score: current EWS numeric (YI->1000, null->NaN)
  - ews_lag_{1,2,3}: previous period scores
  - ews_delta_1: score change vs 1 period ago
  - ews_delta_3: score change vs 3 periods ago
  - ews_max_3: max score in last 3 periods
  - ews_mean_3: mean score in last 3 periods
  - ews_std_3: std of scores in last 3 periods
  - ews_consec_rise: consecutive rising periods
  - ews_above_825_count: how many of last 4 periods >= 825
  - ews_above_500_count: how many of last 4 periods >= 500
  - ews_band: 0=EUS(<500), 1=YIS(500-824), 2=HIGH(825+), 3=YI
  - risk_current: kombine_risk (TL)
  - risk_delta_1: risk change vs 1 period ago
  - risk_delta_pct: risk change % vs 1 period ago
  - risk_mio: risk in milyon TL
  - yi_flag_current: ykn_izl_flag this period
  - yi_flag_prev: ykn_izl_flag previous period
  - yi_flag_count_4: number of YI flags in last 4 periods
  - was_yi_prev: was ews_skor='YI' previous period
  - segment_*: one-hot encoded segment (ESKK, KOBI, KUR-TIC, MIKRO)
  - bolge_kodu: numeric bolge code
"""

import duckdb
import pandas as pd
import numpy as np
from pathlib import Path


def build_features(db_path: Path, target_horizon: int = 3) -> pd.DataFrame:
    """Build feature matrix from fact_periodic (vectorized).

    Args:
        db_path: Path to DuckDB file.
        target_horizon: Number of future periods to check for YI (default 3).

    Returns:
        DataFrame with features + label column.
        Each row = one (entity_id, donem) observation.
    """
    con = duckdb.connect(str(db_path), read_only=True)

    fp = con.execute("""
        SELECT
            fp.entity_id, fp.donem,
            fp.ews_skor, fp.ews_kaynak,
            fp.kombine_risk, fp.risk_degisim,
            fp.ykn_izl_flag,
            de.segment, de.bolge_kodu
        FROM fact_periodic fp
        LEFT JOIN dim_entity de ON fp.entity_id = de.entity_id
        ORDER BY fp.entity_id, fp.donem
    """).fetchdf()
    con.close()

    if fp.empty:
        return pd.DataFrame()

    # Prevent CoW overhead on large DataFrames
    fp = fp.copy()

    # ── Vectorized ews_skor -> numeric (YI=1000, invalid=NaN) ──
    ews_str = fp["ews_skor"].astype(str)
    fp["ews_num"] = np.where(
        ews_str == "YI", 1000.0,
        pd.to_numeric(fp["ews_skor"], errors="coerce")
    )

    fp = fp.sort_values(["entity_id", "donem"]).reset_index(drop=True)

    # ── All vectorized ops via groupby ──
    g = fp.groupby("entity_id", sort=False)["ews_num"]

    # Lags
    fp["ews_lag_1"] = g.shift(1)
    fp["ews_lag_2"] = g.shift(2)
    fp["ews_lag_3"] = g.shift(3)

    # Deltas
    fp["ews_delta_1"] = fp["ews_num"] - fp["ews_lag_1"]
    fp["ews_delta_3"] = fp["ews_num"] - fp["ews_lag_3"]

    # Rolling stats (window=3, min_periods=1)
    rolling3 = g.rolling(3, min_periods=1)
    fp["ews_max_3"] = rolling3.max().reset_index(level=0, drop=True)
    fp["ews_mean_3"] = rolling3.mean().reset_index(level=0, drop=True)
    fp["ews_std_3"] = rolling3.std(ddof=0).reset_index(level=0, drop=True).fillna(0)

    # Consecutive rise (vectorized streak counting)
    shifted = g.shift(1)
    rising = (fp["ews_num"] > shifted) & fp["ews_num"].notna() & shifted.notna()
    streak_break = ~rising
    streak_id = streak_break.groupby(fp["entity_id"], sort=False).cumsum()
    consec = fp.groupby([fp["entity_id"], streak_id], sort=False).cumcount()
    fp["ews_consec_rise"] = consec.where(rising, 0).astype(int)

    # Threshold counts in last 4 periods
    above_825 = (fp["ews_num"] >= 825).astype(float)
    above_500 = (fp["ews_num"] >= 500).astype(float)
    fp["ews_above_825_count"] = (
        above_825.groupby(fp["entity_id"], sort=False)
        .rolling(4, min_periods=1).sum()
        .reset_index(level=0, drop=True).fillna(0).astype(int)
    )
    fp["ews_above_500_count"] = (
        above_500.groupby(fp["entity_id"], sort=False)
        .rolling(4, min_periods=1).sum()
        .reset_index(level=0, drop=True).fillna(0).astype(int)
    )

    # Band
    fp["ews_band"] = np.select(
        [fp["ews_num"].isna(), fp["ews_num"] >= 1000,
         fp["ews_num"] >= 825, fp["ews_num"] >= 500],
        [-1, 3, 2, 1],
        default=0
    )

    # Risk
    risk = fp["kombine_risk"].astype(float)
    risk_filled = risk.fillna(0)
    risk_prev = risk.groupby(fp["entity_id"], sort=False).shift(1)
    risk_prev = risk_prev.fillna(risk_filled)
    fp["risk_current"] = risk_filled
    fp["risk_delta_1"] = risk_filled - risk_prev
    fp["risk_delta_pct"] = np.where(risk_prev != 0, fp["risk_delta_1"] / risk_prev, 0.0)
    fp["risk_mio"] = risk_filled / 1_000_000

    # YI flags (vectorized)
    yi_str = fp["ykn_izl_flag"].astype(str)
    yi_flag = yi_str.isin(["1", "1.0"]).astype(int)
    fp["yi_flag_current"] = yi_flag
    fp["yi_flag_prev"] = (
        yi_flag.groupby(fp["entity_id"], sort=False).shift(1).fillna(0).astype(int)
    )
    fp["yi_flag_count_4"] = (
        yi_flag.astype(float)
        .groupby(fp["entity_id"], sort=False)
        .rolling(4, min_periods=1).sum()
        .reset_index(level=0, drop=True).fillna(0).astype(int)
    )

    # was_yi_prev
    is_yi = (fp["ews_skor"].astype(str) == "YI").astype(int)
    fp["was_yi_prev"] = (
        is_yi.groupby(fp["entity_id"], sort=False).shift(1).fillna(0).astype(int)
    )

    # Segment one-hot
    seg_str = fp["segment"].astype(str)
    seg_valid = ~seg_str.isin(["None", "<NA>", "nan", "NaN"]) & fp["segment"].notna()
    fp["seg_ESKK"] = ((seg_str == "ESKK") & seg_valid).astype(int)
    fp["seg_KOBI"] = ((seg_str == "KOBI") & seg_valid).astype(int)
    fp["seg_KUR_TIC"] = ((seg_str == "KUR-TIC") & seg_valid).astype(int)
    fp["seg_MIKRO"] = ((seg_str == "MIKRO") & seg_valid).astype(int)

    # bolge_kodu
    fp["bolge_kodu_clean"] = pd.to_numeric(
        fp["bolge_kodu"], errors="coerce"
    ).fillna(0).astype(int)

    # ── Label: YI in next 1..target_horizon periods (vectorized) ──
    is_yi_bool = fp["ews_skor"].astype(str) == "YI"
    g_yi = is_yi_bool.groupby(fp["entity_id"], sort=False)
    g_skor = fp["ews_skor"].groupby(fp["entity_id"], sort=False)

    future_yi = pd.Series(False, index=fp.index)
    has_future = pd.Series(False, index=fp.index)
    for h in range(1, target_horizon + 1):
        future_yi = future_yi | g_yi.shift(-h).fillna(False)
        has_future = has_future | g_skor.shift(-h).notna()

    fp["label"] = future_yi.astype(float)
    fp.loc[~has_future, "label"] = np.nan

    # ── Diag features (graceful degradation — yoksa 0) ──
    diag_parquet = Path(db_path).parent / "cache" / "diag_features.parquet"
    if diag_parquet.exists():
        diag_df = pd.read_parquet(diag_parquet)
        diag_df = diag_df.assign(
            entity_id=pd.to_numeric(diag_df["entity_id"], errors="coerce").astype("Int64"),
            donem=diag_df["donem"].astype(str),
        )
        fp = fp.assign(
            entity_id=pd.to_numeric(fp["entity_id"], errors="coerce").astype("Int64"),
            donem=fp["donem"].astype(str),
        )
        fp = fp.merge(diag_df, on=["entity_id", "donem"], how="left")
        for col in DIAG_FEATURE_COLS:
            if col in fp.columns:
                fill = -1 if col == "diag_en_agir_katman_kod" else 0
                fp[col] = fp[col].fillna(fill).astype(int if col != "diag_en_agir_katman_kod" else int)
            else:
                fp[col] = -1 if col == "diag_en_agir_katman_kod" else 0
        print(f"  [DIAG] {len(diag_df)} diag feature satırı merge edildi")
    else:
        for col in DIAG_FEATURE_COLS:
            fp[col] = -1 if col == "diag_en_agir_katman_kod" else 0
        print(f"  [DIAG] diag_features.parquet yok, tüm diag feature'lar 0")

    # ── Select output columns ──
    out_cols = [
        "entity_id", "donem", "ews_num",
        "ews_lag_1", "ews_lag_2", "ews_lag_3",
        "ews_delta_1", "ews_delta_3",
        "ews_max_3", "ews_mean_3", "ews_std_3",
        "ews_consec_rise", "ews_above_825_count", "ews_above_500_count", "ews_band",
        "risk_current", "risk_delta_1", "risk_delta_pct", "risk_mio",
        "yi_flag_current", "yi_flag_prev", "yi_flag_count_4", "was_yi_prev",
        "seg_ESKK", "seg_KOBI", "seg_KUR_TIC", "seg_MIKRO",
        "bolge_kodu_clean",
    ] + DIAG_FEATURE_COLS + ["label"]
    result = fp[out_cols].copy()
    result = result.rename(columns={"ews_num": "ews_score", "bolge_kodu_clean": "bolge_kodu"})

    print(f"  Features: {len(result)} rows, {result['entity_id'].nunique()} entities, "
          f"{result['donem'].nunique()} periods")
    if "label" in result.columns:
        labeled = result.dropna(subset=["label"])
        print(f"  Labeled: {len(labeled)} rows (YI={int(labeled['label'].sum())}, "
              f"non-YI={int((labeled['label'] == 0).sum())})")
    return result


# Diag feature columns (from nb_06c_diag_features)
DIAG_FEATURE_COLS = [
    "diag_bulgu_sayisi", "diag_katman_cesitlilik", "diag_kriter_cesitlilik",
    "diag_yeni_kriter_sayisi", "diag_kik_bulgu", "diag_rkd_bulgu",
    "diag_sql_diskalma", "diag_memzuc_aktif",
    "diag_bulgu_3d_toplam", "diag_bulgu_3d_trend",
    "diag_ilk_bulgu_uzaklik", "diag_katman_degisim",
    "diag_en_agir_katman_kod",
]

# Feature columns used by the model (excludes entity_id, donem, label)
FEATURE_COLS = [
    "ews_score", "ews_lag_1", "ews_lag_2", "ews_lag_3",
    "ews_delta_1", "ews_delta_3",
    "ews_max_3", "ews_mean_3", "ews_std_3",
    "ews_consec_rise", "ews_above_825_count", "ews_above_500_count", "ews_band",
    "risk_current", "risk_delta_1", "risk_delta_pct", "risk_mio",
    "yi_flag_current", "yi_flag_prev", "yi_flag_count_4", "was_yi_prev",
    "seg_ESKK", "seg_KOBI", "seg_KUR_TIC", "seg_MIKRO",
    "bolge_kodu",
] + DIAG_FEATURE_COLS

# Human-readable feature names for SHAP explanations
FEATURE_LABELS = {
    "ews_score": "Mevcut EWS skoru",
    "ews_lag_1": "Önceki dönem skoru",
    "ews_lag_2": "2 dönem önceki skor",
    "ews_lag_3": "3 dönem önceki skor",
    "ews_delta_1": "Son dönem skor değişimi",
    "ews_delta_3": "Son 3 dönem skor değişimi",
    "ews_max_3": "Son 3 dönem maks skor",
    "ews_mean_3": "Son 3 dönem ort skor",
    "ews_std_3": "Son 3 dönem skor dalgalanması",
    "ews_consec_rise": "Ardışık yükseliş dönem sayısı",
    "ews_above_825_count": "Son 4 dönemde 825+ olan dönem sayısı",
    "ews_above_500_count": "Son 4 dönemde 500+ olan dönem sayısı",
    "ews_band": "EWS bandı",
    "risk_current": "Mevcut risk (TL)",
    "risk_delta_1": "Risk değişimi (TL)",
    "risk_delta_pct": "Risk değişimi (%)",
    "risk_mio": "Risk (milyon TL)",
    "yi_flag_current": "Mevcut YI flag",
    "yi_flag_prev": "Önceki dönem YI flag",
    "yi_flag_count_4": "Son 4 dönemde YI flag sayısı",
    "was_yi_prev": "Önceki dönem YI miydi",
    "seg_ESKK": "Segment: ESKK",
    "seg_KOBI": "Segment: KOBİ",
    "seg_KUR_TIC": "Segment: Kurumsal-Ticari",
    "seg_MIKRO": "Segment: Mikro",
    "bolge_kodu": "Bölge kodu",
    # Diag features
    "diag_bulgu_sayisi": "EUS kapsam dışı bulgu sayısı",
    "diag_katman_cesitlilik": "Teşhis katman çeşitliliği",
    "diag_kriter_cesitlilik": "Teşhis kriter çeşitliliği",
    "diag_yeni_kriter_sayisi": "Yeni RKD kriter sayısı",
    "diag_kik_bulgu": "KIK katmanı bulgu sayısı",
    "diag_rkd_bulgu": "RKD katmanı bulgu sayısı",
    "diag_sql_diskalma": "SQL kapsam dışı",
    "diag_memzuc_aktif": "Memzuc idari takip",
    "diag_bulgu_3d_toplam": "Son 3 dönem toplam bulgu",
    "diag_bulgu_3d_trend": "Bulgu artış trendi (3 dönem)",
    "diag_ilk_bulgu_uzaklik": "İlk bulguden bu yana dönem sayısı",
    "diag_katman_degisim": "Katman sayısı değişimi",
    "diag_en_agir_katman_kod": "En ağır teşhis katmanı",
}
