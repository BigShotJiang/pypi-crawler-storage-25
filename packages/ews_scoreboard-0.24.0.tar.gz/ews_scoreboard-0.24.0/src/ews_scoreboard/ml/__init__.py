"""EWS ML module: YI prediction + SHAP-based reason generation."""
