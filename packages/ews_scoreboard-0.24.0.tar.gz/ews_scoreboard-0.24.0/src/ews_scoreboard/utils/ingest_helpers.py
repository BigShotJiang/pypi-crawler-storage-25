import json as _json
from pathlib import Path

import pandas as pd


def resolve_source(param_dir, dp_key, default):
    """SOURCE_DIR > DATA_PATHS JSON > default."""
    if param_dir:
        return Path(param_dir)
    for _dp_name in ["local_data_paths.json", "data_paths_nt.json", "data_paths.json"]:
        _dp_file = Path(_dp_name)
        if _dp_file.exists():
            _dp = _json.loads(_dp_file.read_text(encoding="utf-8"))
            if dp_key in _dp:
                return Path(_dp[dp_key])
            break
    return Path(default)


def normalize_muta(series):
    """MUTA kolonunu temizle: str strip, NA varyantları, int→str."""
    cleaned = series.astype(str).str.strip()
    cleaned = cleaned.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA})
    s = pd.to_numeric(cleaned, errors="coerce")
    return s.dropna().astype(int).astype(str)


def clean_str_col(series):
    """String kolonu temizle: strip, NA varyantları."""
    s = series.astype(str).str.strip()
    s = s.replace({"": pd.NA, "nan": pd.NA, "None": pd.NA, "NaN": pd.NA, "<NA>": pd.NA, "NaT": pd.NA})
    return s


def find_skor_col(columns):
    """Skor kolonunu bul (case-insensitive 'skor' arama)."""
    for c in columns:
        if "skor" in c.lower():
            return c
    return None


def find_ihtimal_col(columns):
    """İhtimal kolonunu bul (case-insensitive 'ihtimal' arama)."""
    for c in columns:
        if "ihtimal" in c.lower():
            return c
    return None
