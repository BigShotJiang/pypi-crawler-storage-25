"""
Sanitize sensitive information from text output.

Redacts: username, hostname, Windows user paths, home dirs, conda env names.
Safe for sharing error reports, logs, and pipeline output externally.

Usage:
    from ews_scoreboard.sanitize import sanitize, error_report

    clean = sanitize(text)             # redact sensitive info
    report = error_report(exception)   # generate safe error report
"""

import getpass
import os
import platform
import re
import socket
import traceback
from datetime import datetime
from pathlib import Path


def _build_patterns() -> list[tuple[re.Pattern, str]]:
    """Build regex patterns for sensitive info, ordered by specificity."""
    patterns = []

    # Current user
    try:
        username = getpass.getuser()
    except Exception:
        username = None

    # Hostname
    try:
        hostname = socket.gethostname()
    except Exception:
        hostname = None

    # Windows username (WSL paths)
    win_user = None
    wsl_home = Path("/mnt/c/Users")
    if wsl_home.exists():
        for d in wsl_home.iterdir():
            if d.is_dir() and d.name not in ("Public", "Default", "Default User", "All Users"):
                win_user = d.name
                break

    # Home dir
    home = str(Path.home())

    # Conda env name (may contain username)
    conda_prefix = os.environ.get("CONDA_PREFIX", "")
    conda_env = Path(conda_prefix).name if conda_prefix else None

    # ── Patterns (most specific first) ──

    # CWD path → ***/cwd (captures working directory structure)
    cwd = str(Path.cwd())
    if cwd and len(cwd) > 5:
        patterns.append((
            re.compile(re.escape(cwd)),
            "***/cwd"
        ))

    # Full home path → /home/***
    if home:
        patterns.append((
            re.compile(re.escape(home)),
            "/home/***"
        ))

    # Windows user path: /mnt/c/Users/Name → /mnt/c/Users/***
    if win_user:
        patterns.append((
            re.compile(r"/mnt/c/Users/" + re.escape(win_user), re.IGNORECASE),
            "/mnt/c/Users/***"
        ))
        patterns.append((
            re.compile(r"C:\\Users\\" + re.escape(win_user), re.IGNORECASE),
            "C:\\\\Users\\\\***"
        ))

    # user@hostname patterns (prompt, ssh, etc.)
    if username and hostname:
        patterns.append((
            re.compile(re.escape(username) + r"@" + re.escape(hostname)),
            "***@***"
        ))

    # Hostname standalone (in common contexts)
    if hostname and len(hostname) >= 3:
        patterns.append((
            re.compile(r"@" + re.escape(hostname) + r"(?=[\s:/]|$)"),
            "@***"
        ))
        # Hostname as standalone word
        patterns.append((
            re.compile(r"\b" + re.escape(hostname) + r"\b", re.IGNORECASE),
            "***"
        ))

    # Username in paths: /username/ or \username\
    if username and len(username) >= 3:
        patterns.append((
            re.compile(r"(?<=[/\\])" + re.escape(username) + r"(?=[/\\])", re.IGNORECASE),
            "***"
        ))

    # Conda env — in prompt, in paths, everywhere
    if conda_env and conda_env != "base" and len(conda_env) >= 3:
        patterns.append((
            re.compile(r"\(" + re.escape(conda_env) + r"\)"),
            "(***env)"
        ))
        # env name in paths: /envs/basent/ → /envs/***/
        patterns.append((
            re.compile(r"(?<=/envs/)" + re.escape(conda_env) + r"(?=[/\\])"),
            "***"
        ))

    # All conda envs (not just active one) — catch env names in traceback paths
    conda_base = os.environ.get("CONDA_PREFIX_1") or os.environ.get("CONDA_PREFIX", "")
    if conda_base:
        envs_dir = Path(conda_base).parent
        if envs_dir.name == "envs":
            envs_dir = envs_dir  # already pointing to envs/
        else:
            envs_dir = Path(conda_base) / "envs"
        if envs_dir.exists():
            for env_dir in envs_dir.iterdir():
                if env_dir.is_dir() and env_dir.name not in ("base",) and len(env_dir.name) >= 3:
                    patterns.append((
                        re.compile(r"(?<=/envs/)" + re.escape(env_dir.name) + r"(?=[/\\])"),
                        "***"
                    ))

    # Generic: username as standalone word (careful — only if 4+ chars to avoid false positives)
    if username and len(username) >= 4:
        patterns.append((
            re.compile(r"\b" + re.escape(username) + r"\b", re.IGNORECASE),
            "***"
        ))

    return patterns


# Build once on import
_PATTERNS = _build_patterns()


def sanitize(text: str, extra_redactions: dict[str, str] | None = None) -> str:
    """Redact sensitive information from text.

    Args:
        text: Input text to sanitize.
        extra_redactions: Optional dict of {pattern: replacement} for custom redactions.

    Returns:
        Sanitized text with sensitive info replaced by ***.
    """
    if not text:
        return text

    result = text

    # Apply built-in patterns
    for pattern, replacement in _PATTERNS:
        result = pattern.sub(replacement, result)

    # Apply custom redactions
    if extra_redactions:
        for pat, repl in extra_redactions.items():
            result = re.sub(pat, repl, result)

    return result


def error_report(exception: Exception = None,
                 db_path: Path = None,
                 context: str = None) -> str:
    """Generate a sanitized error report safe for sharing.

    Includes: stack trace, DB structure (table names + row counts),
    EWS score distribution, Python/package versions.
    Excludes: actual data values, usernames, hostnames, file paths.

    Args:
        exception: The exception to report (or None for status-only report).
        db_path: Path to DuckDB file for structural info.
        context: Optional context string (e.g., "transform step").

    Returns:
        Sanitized report string.
    """
    lines = []
    lines.append("=" * 60)
    lines.append("EWS SCOREBOARD — ERROR REPORT")
    lines.append(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    if context:
        lines.append(f"Context: {context}")
    lines.append("=" * 60)

    # ── Versions ──
    lines.append("\n[VERSIONS]")
    try:
        from ews_scoreboard import __version__
        lines.append(f"  ews_scoreboard: {__version__}")
    except Exception:
        lines.append("  ews_scoreboard: ?")

    import sys
    lines.append(f"  python: {sys.version.split()[0]}")
    # Platform: sanitize — kernel string'inde hostname/IP olabilir
    plat_str = platform.platform()
    # WSL kernel: "Linux-X.X.X.X-microsoft-standard-WSL2" → sadece versiyon + WSL2
    plat_str = re.sub(r"Linux-[\d.]+-", "Linux-*-", plat_str)
    lines.append(f"  platform: {sanitize(plat_str)}")

    for pkg in ["duckdb", "pandas", "numpy", "jinja2", "lightgbm", "shap"]:
        try:
            mod = __import__(pkg)
            lines.append(f"  {pkg}: {mod.__version__}")
        except ImportError:
            lines.append(f"  {pkg}: not installed")
        except Exception:
            lines.append(f"  {pkg}: ?")

    # ── Exception ──
    if exception:
        lines.append("\n[ERROR]")
        lines.append(f"  Type: {type(exception).__name__}")
        lines.append(f"  Message: {sanitize(str(exception))}")
        lines.append("\n[TRACEBACK]")
        tb = traceback.format_exception(type(exception), exception, exception.__traceback__)
        for line in tb:
            lines.append("  " + sanitize(line.rstrip()))

    # ── DB Structure ──
    if db_path and Path(db_path).exists():
        lines.append("\n[DB STRUCTURE]")
        try:
            import duckdb
            con = duckdb.connect(str(db_path), read_only=True)
            tables = [t[0] for t in con.execute("SHOW TABLES").fetchall()]
            for t in sorted(tables):
                try:
                    cnt = con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                    cols = [c[0] for c in con.execute(f"DESCRIBE {t}").fetchall()]
                    lines.append(f"  {t}: {cnt} rows, cols={cols}")
                except Exception as e:
                    lines.append(f"  {t}: ERROR ({e})")

            # EWS score distribution (no actual values, just counts)
            try:
                dist = con.execute("""
                    SELECT
                        CASE
                            WHEN ews_skor = 'YI' THEN 'YI'
                            WHEN ews_skor IS NULL THEN 'NULL'
                            WHEN CAST(ews_skor AS INT) < 325 THEN '0-324'
                            WHEN CAST(ews_skor AS INT) < 500 THEN '325-499'
                            WHEN CAST(ews_skor AS INT) < 825 THEN '500-824'
                            ELSE '825+'
                        END AS band,
                        COUNT(*) AS cnt
                    FROM fact_periodic
                    GROUP BY band ORDER BY band
                """).fetchall()
                lines.append("\n[EWS DISTRIBUTION]")
                for band, cnt in dist:
                    lines.append(f"  {band}: {cnt}")
            except Exception:
                pass

            # Period info
            try:
                periods = con.execute(
                    "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
                ).fetchall()
                lines.append(f"\n[PERIODS] {[p[0] for p in periods]}")
            except Exception:
                pass

            con.close()
        except Exception as e:
            lines.append(f"  DB read error: {sanitize(str(e))}")

    lines.append("\n" + "=" * 60)
    lines.append("END OF REPORT")
    lines.append("=" * 60)

    return "\n".join(lines)


def save_error_report(exception: Exception = None,
                      db_path: Path = None,
                      context: str = None,
                      output_path: Path = None) -> Path:
    """Generate and save sanitized error report.

    Args:
        exception: The exception to report.
        db_path: Path to DuckDB for structural info.
        context: Context string.
        output_path: Where to save. Defaults to outputs/error_report.txt.

    Returns:
        Path to saved report.
    """
    if output_path is None:
        output_path = Path("outputs") / "error_report.txt"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    report = error_report(exception, db_path, context)
    output_path.write_text(report, encoding="utf-8")
    print(f"Error report saved: {output_path}")
    return output_path
