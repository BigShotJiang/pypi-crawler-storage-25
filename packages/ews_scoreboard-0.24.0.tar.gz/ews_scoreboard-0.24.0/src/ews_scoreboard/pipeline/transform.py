"""
Transform: bronze → silver tables (dim_entity, fact_periodic, map_identity, ref_sube_bolge).
"""

import duckdb
from pathlib import Path


def run_transforms(db_path: Path, referans_tarih_list: list = None,
                    compute_kapsam: bool = False):
    """Run all silver transforms.

    Args:
        referans_tarih_list: Optional list of period codes (e.g. [2501, 2502]).
            If given, fact_periodic only contains these periods.
            LAG/window calculations still use full history for correctness.
        compute_kapsam: If True, compute EUS kapsam from KIK+RKD+memzuc+SQL
            instead of using brz_eus_kapsam directly.
    """
    con = duckdb.connect(str(db_path))

    # 1. ref_sube_bolge
    print("  Building ref_sube_bolge...")
    con.execute("DELETE FROM ref_sube_bolge")
    con.execute("""
        INSERT INTO ref_sube_bolge
        SELECT DISTINCT ON (sube_kodu)
            sube_kodu,
            sube_adi,
            COALESCE(bolge_kodu, 0) AS bolge_kodu,
            COALESCE(bolge_adi, 'Bölge Dışı') AS bolge_adi
        FROM brz_statik
        WHERE sube_kodu IS NOT NULL
        ORDER BY sube_kodu
    """)
    cnt = con.execute("SELECT COUNT(*) FROM ref_sube_bolge").fetchone()[0]
    print(f"    ref_sube_bolge: {cnt} rows")

    # Depo tablosu var mı?
    _has_depo = con.execute(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_name='brz_raporlama_depo'"
    ).fetchone()[0] > 0
    _depo_cnt = con.execute("SELECT COUNT(*) FROM brz_raporlama_depo").fetchone()[0] if _has_depo else 0
    if _has_depo and _depo_cnt > 0:
        print(f"  [DEPO] brz_raporlama_depo: {_depo_cnt} satır")
        con.execute("""
            CREATE OR REPLACE TEMP TABLE _depo_statik AS
            SELECT DISTINCT ON (CAST(muta AS BIGINT))
                CAST(muta AS BIGINT) AS muta, must_ad, sube_kodu, bolge_adi,
                must_tip_kodu, grup_tanimi, firma_otorize_kodu,
                son_izleme_kodu, risk_grup_kodu, pgy, finansman_konu, tahsis_onay_birimi
            FROM brz_raporlama_depo
            WHERE CAST(muta AS BIGINT) IS NOT NULL
            ORDER BY CAST(muta AS BIGINT), donem DESC
        """)
    else:
        print("  [DEPO] brz_raporlama_depo yok veya boş — depo fallback kapalı")

    # 2. dim_entity
    print("  Building dim_entity...")
    con.execute("DELETE FROM dim_entity")

    # ALTER TABLE: yeni kolonlar yoksa ekle (upgrade uyumu)
    _de_cols = {r[0] for r in con.execute("DESCRIBE dim_entity").fetchall()}
    for _col, _typ in [("son_izleme_kodu","VARCHAR"),("risk_grup_kodu","VARCHAR"),
                        ("pgy","VARCHAR"),("finansman_konu","VARCHAR"),("tahsis_onay_birimi","VARCHAR")]:
        if _col not in _de_cols:
            con.execute(f"ALTER TABLE dim_entity ADD COLUMN {_col} {_typ}")

    if _has_depo and _depo_cnt > 0:
        con.execute("""
            INSERT OR REPLACE INTO dim_entity
            SELECT
                CAST(s.muta AS BIGINT) AS entity_id,
                tf.segment,
                COALESCE(s.bolge_kodu, dp.sube_kodu) AS bolge_kodu,
                COALESCE(s.sube_kodu, dp.sube_kodu) AS sube_kodu,
                COALESCE(s.must_tip_kodu, CAST(dp.must_tip_kodu AS VARCHAR)),
                s.grup_kodu,
                COALESCE(s.grup_tanimi, dp.grup_tanimi),
                COALESCE(s.firma_otorize_kodu, dp.firma_otorize_kodu),
                s.aksiyon_sahibi,
                s.kri_bolum,
                dp.son_izleme_kodu,
                dp.risk_grup_kodu,
                dp.pgy,
                dp.finansman_konu,
                dp.tahsis_onay_birimi
            FROM (
                SELECT DISTINCT ON (muta) *
                FROM brz_statik ORDER BY muta
            ) s
            LEFT JOIN (
                SELECT DISTINCT ON (muta) muta, segment
                FROM brz_train_features ORDER BY muta, donem DESC
            ) tf ON s.muta = tf.muta
            LEFT JOIN _depo_statik dp ON CAST(s.muta AS BIGINT) = dp.muta
        """)
    else:
        con.execute("""
            INSERT OR REPLACE INTO dim_entity (entity_id, segment, bolge_kodu, sube_kodu,
                must_tip_kodu, grup_kodu, grup_tanimi, firma_otorize_kodu, aksiyon_sahibi, kri_bolum)
            SELECT
                CAST(s.muta AS BIGINT) AS entity_id, tf.segment,
                s.bolge_kodu, s.sube_kodu, s.must_tip_kodu,
                s.grup_kodu, s.grup_tanimi, s.firma_otorize_kodu,
                s.aksiyon_sahibi, s.kri_bolum
            FROM (
                SELECT DISTINCT ON (muta) * FROM brz_statik ORDER BY muta
            ) s
            LEFT JOIN (
                SELECT DISTINCT ON (muta) muta, segment
                FROM brz_train_features ORDER BY muta, donem DESC
            ) tf ON s.muta = tf.muta
        """)

    # YIS/EUS'ta olup dim_entity'de olmayan firmalar
    con.execute("""
        INSERT OR IGNORE INTO dim_entity (entity_id)
        SELECT DISTINCT muta FROM brz_yis_tahmin
        WHERE CAST(muta AS BIGINT) NOT IN (SELECT entity_id FROM dim_entity)
    """)
    con.execute("""
        INSERT OR IGNORE INTO dim_entity (entity_id)
        SELECT DISTINCT muta FROM brz_eus_tahmin
        WHERE CAST(muta AS BIGINT) NOT IN (SELECT entity_id FROM dim_entity)
    """)
    # Depo'da olup henüz dim_entity'de olmayan firmalar
    if _has_depo and _depo_cnt > 0:
        con.execute("""
            INSERT OR IGNORE INTO dim_entity (entity_id, son_izleme_kodu, risk_grup_kodu,
                pgy, finansman_konu, tahsis_onay_birimi)
            SELECT CAST(dp.muta AS BIGINT), dp.son_izleme_kodu, dp.risk_grup_kodu,
                   dp.pgy, dp.finansman_konu, dp.tahsis_onay_birimi
            FROM _depo_statik dp
            WHERE CAST(dp.muta AS BIGINT) NOT IN (SELECT entity_id FROM dim_entity)
        """)
    cnt = con.execute("SELECT COUNT(*) FROM dim_entity").fetchone()[0]
    print(f"    dim_entity: {cnt} rows")

    # 3. map_identity (KIK unvan birincil, depo must_ad fallback)
    print("  Building map_identity...")
    con.execute("DELETE FROM map_identity")
    if _has_depo and _depo_cnt > 0:
        con.execute("""
            INSERT OR REPLACE INTO map_identity
            SELECT
                de.entity_id,
                de.entity_id AS muta,
                COALESCE(u.unvan, dp.must_ad) AS unvan
            FROM dim_entity de
            LEFT JOIN (
                SELECT DISTINCT ON (muta) muta, unvan
                FROM brz_kik_izleme
                WHERE unvan IS NOT NULL AND TRIM(unvan) != '' AND unvan != 'None'
                ORDER BY muta, donem DESC
            ) u ON de.entity_id = CAST(u.muta AS BIGINT)
            LEFT JOIN _depo_statik dp ON de.entity_id = dp.muta
        """)
    else:
        con.execute("""
            INSERT OR REPLACE INTO map_identity
            SELECT
                de.entity_id,
                de.entity_id AS muta,
                u.unvan
            FROM dim_entity de
            LEFT JOIN (
                SELECT DISTINCT ON (muta) muta, unvan
                FROM brz_kik_izleme
                WHERE unvan IS NOT NULL AND TRIM(unvan) != '' AND unvan != 'None'
                ORDER BY muta, donem DESC
            ) u ON de.entity_id = CAST(u.muta AS BIGINT)
        """)
    cnt = con.execute("SELECT COUNT(*) FROM map_identity").fetchone()[0]
    bos = con.execute("SELECT COUNT(*) FROM map_identity WHERE unvan IS NULL OR TRIM(unvan)=''").fetchone()[0]
    print(f"    map_identity: {cnt} rows (unvan boş: {bos})")

    # 4. fact_periodic
    print("  Building fact_periodic...")
    con.execute("DELETE FROM fact_periodic")

    _depo_union = ""
    if _has_depo and _depo_cnt > 0:
        _depo_union = """
        UNION
        SELECT DISTINCT CAST(muta AS BIGINT), CAST(donem AS VARCHAR) FROM brz_raporlama_depo
        WHERE CAST(muta AS BIGINT) IS NOT NULL
          AND TRIM(CAST(son_izleme_kodu AS VARCHAR)) IN ('0','00','A','B','C','88','99')
        """
    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE _all_ed AS
        SELECT DISTINCT CAST(muta AS BIGINT) AS entity_id, CAST(donem AS VARCHAR) AS donem FROM brz_yis_tahmin
        UNION
        SELECT DISTINCT CAST(muta AS BIGINT), CAST(donem AS VARCHAR) FROM brz_eus_tahmin
        UNION
        SELECT DISTINCT CAST(muta AS BIGINT), CAST(donem AS VARCHAR) FROM brz_kredi_risk
        UNION
        SELECT DISTINCT CAST(muta AS BIGINT), CAST(donem AS VARCHAR) FROM brz_kik_izleme
        {_depo_union}
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _yis AS
        SELECT DISTINCT ON (muta, donem)
            CAST(muta AS BIGINT) AS muta, donem, yis_skor, yis_ihtimal, yis_label
        FROM brz_yis_tahmin ORDER BY muta, donem
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus AS
        SELECT DISTINCT ON (muta, donem)
            CAST(muta AS BIGINT) AS muta, donem, eus_skor, eus_ihtimal,
            CASE WHEN eus_skor >= 650 THEN 1 ELSE 0 END AS eus_tahmin_label
        FROM brz_eus_tahmin ORDER BY muta, donem
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus_kapsam AS
        SELECT DISTINCT CAST(muta AS BIGINT) AS muta, donem, 1 AS eus_kapsam FROM brz_eus_kapsam
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _eus_hedef AS
        SELECT DISTINCT CAST(muta AS BIGINT) AS muta, donem, 1 AS eus_hedef FROM brz_eus_hedef
    """)

    # Depo risk temp table (opsiyonel)
    if _has_depo and _depo_cnt > 0:
        con.execute("""
            CREATE OR REPLACE TEMP TABLE _depo_risk AS
            SELECT DISTINCT ON (CAST(muta AS BIGINT), CAST(donem AS VARCHAR))
                CAST(muta AS BIGINT) AS muta, CAST(donem AS VARCHAR) AS donem,
                CAST(genel_risk_toplam AS BIGINT) AS depo_risk,
                CAST(nakit_risk_toplam AS BIGINT) AS nakit_risk,
                CAST(gnakit_risk_toplam AS BIGINT) AS gnakit_risk
            FROM brz_raporlama_depo
            WHERE CAST(muta AS BIGINT) IS NOT NULL
            ORDER BY CAST(muta AS VARCHAR), CAST(donem AS VARCHAR)
        """)

    _depo_risk_join = ""
    _depo_risk_cols = "NULL AS depo_risk, NULL AS nakit_risk, NULL AS gnakit_risk,"
    if _has_depo and _depo_cnt > 0:
        _depo_risk_join = "LEFT JOIN _depo_risk dr ON risk_raw.muta = dr.muta AND risk_raw.donem = dr.donem"
        _depo_risk_cols = "dr.depo_risk, dr.nakit_risk, dr.gnakit_risk,"

    con.execute(f"""
        CREATE OR REPLACE TEMP TABLE _risk AS
        WITH risk_raw AS (
            SELECT
                CAST(COALESCE(kr.muta, ki.muta) AS BIGINT) AS muta,
                COALESCE(kr.donem, ki.donem) AS donem,
                kr.kredi_risk,
                ki.kik_risk,
                COALESCE(kr.kredi_risk, ki.kik_risk) AS kombine_risk
            FROM (SELECT DISTINCT ON (muta, donem) * FROM brz_kredi_risk ORDER BY muta, donem) kr
            FULL OUTER JOIN (
                SELECT DISTINCT ON (muta, donem) muta, donem, kik_risk
                FROM brz_kik_izleme WHERE kik_risk IS NOT NULL
                ORDER BY muta, donem
            ) ki ON kr.muta = ki.muta AND kr.donem = ki.donem
        ),
        risk_enriched AS (
            SELECT risk_raw.muta, risk_raw.donem, risk_raw.kredi_risk, risk_raw.kik_risk,
                   risk_raw.kombine_risk,
                   {_depo_risk_cols}
                   LAG(risk_raw.kombine_risk) OVER (PARTITION BY risk_raw.muta ORDER BY risk_raw.donem) AS _prev
            FROM risk_raw
            {_depo_risk_join}
        )
        SELECT muta, donem, kredi_risk, kik_risk, kombine_risk,
               depo_risk, nakit_risk, gnakit_risk,
               CAST(kombine_risk - _prev AS BIGINT) AS risk_degisim
        FROM risk_enriched
    """)

    if _has_depo and _depo_cnt > 0:
        con.execute("""
            CREATE OR REPLACE TEMP TABLE _yi AS
            SELECT
                COALESCE(k.muta, d.muta) AS muta,
                COALESCE(k.donem, d.donem) AS donem,
                CAST(CASE
                    WHEN COALESCE(k.ykn_izl_flag, '0') IN ('1','1.0','True','true') THEN 1
                    WHEN TRIM(CAST(COALESCE(d.son_izleme_kodu, '0') AS VARCHAR)) = '99' THEN 1
                    ELSE 0
                END AS INTEGER) AS ykn_izl_flag
            FROM (
                SELECT DISTINCT ON (CAST(muta AS BIGINT), donem) CAST(muta AS BIGINT) AS muta, donem, ykn_izl_flag
                FROM brz_kik_izleme ORDER BY CAST(muta AS BIGINT), donem
            ) k
            FULL OUTER JOIN (
                SELECT DISTINCT ON (CAST(muta AS BIGINT), CAST(donem AS VARCHAR))
                    CAST(muta AS BIGINT) AS muta, CAST(donem AS VARCHAR) AS donem, son_izleme_kodu
                FROM brz_raporlama_depo
                WHERE CAST(muta AS BIGINT) IS NOT NULL
                ORDER BY CAST(muta AS VARCHAR), CAST(donem AS VARCHAR)
            ) d ON k.muta = d.muta AND k.donem = d.donem
        """)
    else:
        con.execute("""
            CREATE OR REPLACE TEMP TABLE _yi AS
            SELECT DISTINCT ON (muta, donem)
                CAST(muta AS BIGINT) AS muta, donem,
                CAST(CASE WHEN ykn_izl_flag IN ('1','1.0','True','true') THEN 1 ELSE 0 END AS INTEGER) AS ykn_izl_flag
            FROM brz_kik_izleme ORDER BY muta, donem
        """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _rating AS
        SELECT DISTINCT ON (muta, donem)
            CAST(muta AS BIGINT) AS muta, donem, tfrs_rating, rating_tarihi
        FROM brz_kik_izleme
        WHERE tfrs_rating IS NOT NULL AND TRIM(tfrs_rating) != '' AND tfrs_rating != 'None'
        ORDER BY muta, donem, rating_tarihi DESC
    """)

    con.execute("""
        CREATE OR REPLACE TEMP TABLE _ews AS
        SELECT
            ad.entity_id, ad.donem,
            CASE
                WHEN COALESCE(y.yis_label, 0) = 1 OR COALESCE(yi.ykn_izl_flag, 0) = 1
                    THEN 'YI'
                WHEN e.eus_skor IS NOT NULL
                    THEN CAST(CAST(FLOOR(ROUND(e.eus_skor / 2) / 10) * 10 AS INTEGER) AS VARCHAR)
                WHEN y.yis_skor IS NOT NULL
                    THEN CAST(CAST(FLOOR((ROUND(CAST(y.yis_skor AS DOUBLE) / 2) + 500) / 10) * 10 AS INTEGER) AS VARCHAR)
                ELSE NULL
            END AS ews_skor,
            CASE
                WHEN COALESCE(y.yis_label, 0) = 1 OR COALESCE(yi.ykn_izl_flag, 0) = 1 THEN 'yi'
                WHEN e.eus_skor IS NOT NULL THEN 'eus'
                WHEN y.yis_skor IS NOT NULL THEN 'yis'
                ELSE NULL
            END AS ews_kaynak
        FROM _all_ed ad
        LEFT JOIN _yis y ON ad.entity_id = y.muta AND ad.donem = y.donem
        LEFT JOIN _yi yi ON ad.entity_id = yi.muta AND ad.donem = yi.donem
        LEFT JOIN _eus e ON ad.entity_id = e.muta AND ad.donem = e.donem
    """)

    # Period filter (if specified)
    donem_filtre = ""
    # "son_12" → DB'den son 12 dönem, diğer string → None
    if isinstance(referans_tarih_list, str):
        if referans_tarih_list.strip().lower() == "son_12":
            son12 = con.execute(
                "SELECT DISTINCT donem FROM _all_ed ORDER BY donem DESC LIMIT 12"
            ).fetchdf()["donem"].tolist()
            referans_tarih_list = son12 if son12 else None
            if referans_tarih_list:
                print(f"    son_12: {len(referans_tarih_list)} dönem ({min(referans_tarih_list)}..{max(referans_tarih_list)})")
        else:
            # String list parse: "[2503, 2504]" veya "2503,2504"
            try:
                import ast
                parsed = ast.literal_eval(referans_tarih_list)
                if isinstance(parsed, (list, tuple)):
                    referans_tarih_list = [str(d) for d in parsed]
                else:
                    referans_tarih_list = None
            except (ValueError, SyntaxError):
                referans_tarih_list = None
    if referans_tarih_list:
        donem_strs = ",".join(f"'{d}'" for d in referans_tarih_list)
        donem_filtre = f"WHERE ad.donem IN ({donem_strs})"
        print(f"    dönem filtresi: {len(referans_tarih_list)} dönem")

    # ALTER TABLE: yeni kolonlar yoksa ekle (upgrade uyumu)
    _fp_cols = {r[0] for r in con.execute("DESCRIBE fact_periodic").fetchall()}
    for _col, _typ in [("depo_risk","BIGINT"),("nakit_risk","BIGINT"),("gnakit_risk","BIGINT")]:
        if _col not in _fp_cols:
            con.execute(f"ALTER TABLE fact_periodic ADD COLUMN {_col} {_typ}")

    con.execute(f"""
        INSERT INTO fact_periodic (
            entity_id, donem,
            yis_skor, yis_ihtimal, yis_label,
            eus_skor, eus_ihtimal, eus_tahmin_label,
            eus_kapsam, eus_hedef,
            ews_skor, ews_kaynak, ykn_izl_flag,
            kombine_risk, kredi_risk, kik_risk,
            depo_risk, nakit_risk, gnakit_risk,
            risk_degisim, tfrs_rating, rating_tarihi
        )
        SELECT
            ad.entity_id, ad.donem,
            y.yis_skor, y.yis_ihtimal, y.yis_label,
            e.eus_skor, e.eus_ihtimal, e.eus_tahmin_label,
            COALESCE(ek.eus_kapsam, 0),
            COALESCE(eh.eus_hedef, 0),
            ews.ews_skor, ews.ews_kaynak,
            COALESCE(yi.ykn_izl_flag, 0),
            r.kombine_risk, r.kredi_risk, r.kik_risk,
            r.depo_risk, r.nakit_risk, r.gnakit_risk,
            r.risk_degisim,
            rt.tfrs_rating, rt.rating_tarihi
        FROM _all_ed ad
        LEFT JOIN _yis y ON ad.entity_id = y.muta AND ad.donem = y.donem
        LEFT JOIN _eus e ON ad.entity_id = e.muta AND ad.donem = e.donem
        LEFT JOIN _eus_kapsam ek ON ad.entity_id = ek.muta AND ad.donem = ek.donem
        LEFT JOIN _eus_hedef eh ON ad.entity_id = eh.muta AND ad.donem = eh.donem
        LEFT JOIN _risk r ON ad.entity_id = r.muta AND ad.donem = r.donem
        LEFT JOIN _yi yi ON ad.entity_id = yi.muta AND ad.donem = yi.donem
        LEFT JOIN _rating rt ON ad.entity_id = rt.muta AND ad.donem = rt.donem
        LEFT JOIN _ews ews ON ad.entity_id = ews.entity_id AND ad.donem = ews.donem
        {donem_filtre}
    """)

    cnt = con.execute("SELECT COUNT(*) FROM fact_periodic").fetchone()[0]
    n_ent = con.execute("SELECT COUNT(DISTINCT entity_id) FROM fact_periodic").fetchone()[0]
    n_per = con.execute("SELECT COUNT(DISTINCT donem) FROM fact_periodic").fetchone()[0]
    print(f"    fact_periodic: {cnt} rows ({n_ent} entities × {n_per} periods)")

    for t in ["_all_ed", "_yis", "_eus", "_eus_kapsam", "_eus_hedef", "_risk", "_depo_risk",
              "_yi", "_rating", "_ews", "_depo_statik"]:
        con.execute(f"DROP TABLE IF EXISTS {t}")

    con.close()

    # Computed EUS kapsam (KIK + RKD + SQL + memzuc)
    if compute_kapsam:
        from ews_scoreboard.pipeline.eus_kapsam import compute_eus_kapsam
        print("\n  compute_kapsam=True → EUS kapsam hesaplanıyor...")
        compute_eus_kapsam(db_path, donemler=referans_tarih_list)
