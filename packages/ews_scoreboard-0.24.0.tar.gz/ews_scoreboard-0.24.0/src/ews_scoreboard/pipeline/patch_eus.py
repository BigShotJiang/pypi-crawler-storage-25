"""
Patch: single-period gap interpolation in brz_eus_tahmin.

Post-ingest manipulation — deliberately separate from ingest.
"""

from pathlib import Path

import duckdb
import pandas as pd


def _next_donem(d: str) -> str:
    """YYMM → next month. '2512' → '2601'."""
    yy, mm = int(d[:2]), int(d[2:])
    mm += 1
    if mm > 12:
        mm = 1
        yy += 1
    return f"{yy:02d}{mm:02d}"


def patch_eus_gaps(db_path: Path):
    """Patch single-period gaps in brz_eus_tahmin by interpolation.

    For each muta: if period N-1 and N+1 have eus_skor but N doesn't,
    insert a new row for N with eus_skor = avg(N-1, N+1).
    Does NOT modify existing rows — only inserts new ones.

    Uses calendar-based period sequence (YYMM), not just existing periods.
    This correctly handles entirely missing periods (e.g., 2507 doesn't
    exist at all in the table).
    """
    con = duckdb.connect(str(db_path))

    # Build full calendar from min to max period
    min_d = con.execute("SELECT MIN(donem) FROM brz_eus_tahmin").fetchone()[0]
    max_d = con.execute("SELECT MAX(donem) FROM brz_eus_tahmin").fetchone()[0]

    if not min_d or not max_d:
        print("  [SKIP] patch_eus_gaps: empty table")
        con.close()
        return

    # Generate full YYMM calendar
    calendar = []
    d = min_d
    while d <= max_d:
        calendar.append(d)
        d = _next_donem(d)

    if len(calendar) < 3:
        print("  [SKIP] patch_eus_gaps: <3 calendar periods")
        con.close()
        return

    # Load all EUS data into pandas (muta, donem, eus_skor, eus_ihtimal)
    eus = con.execute(
        "SELECT muta, donem, eus_skor, eus_ihtimal FROM brz_eus_tahmin"
    ).fetchdf()

    # Create lookup: (muta, donem) → (eus_skor, eus_ihtimal)
    eus_lookup = {}
    for _, row in eus.iterrows():
        eus_lookup[(row["muta"], row["donem"])] = (row["eus_skor"], row["eus_ihtimal"])

    # Find single-period gaps
    rows = []
    for i in range(1, len(calendar) - 1):
        prev_d = calendar[i - 1]
        gap_d = calendar[i]
        next_d = calendar[i + 1]

        # Find mutas that have prev and next but not gap
        prev_mutas = {m for (m, d) in eus_lookup if d == prev_d}
        next_mutas = {m for (m, d) in eus_lookup if d == next_d}
        gap_mutas = {m for (m, d) in eus_lookup if d == gap_d}

        candidates = (prev_mutas & next_mutas) - gap_mutas

        for muta in candidates:
            prev_skor, prev_iht = eus_lookup[(muta, prev_d)]
            next_skor, next_iht = eus_lookup[(muta, next_d)]

            avg_skor = round((prev_skor + next_skor) / 2, 2)
            avg_iht = None
            if pd.notna(prev_iht) and pd.notna(next_iht):
                avg_iht = round((prev_iht + next_iht) / 2, 4)

            rows.append({
                "muta": muta,
                "donem": gap_d,
                "eus_skor": avg_skor,
                "eus_ihtimal": avg_iht,
            })

    if not rows:
        print("  patch_eus_gaps: 0 single-period gaps found")
        con.close()
        return

    patch_df = pd.DataFrame(rows)
    con.register("_patch_df", patch_df)
    con.execute("INSERT INTO brz_eus_tahmin SELECT * FROM _patch_df")
    con.unregister("_patch_df")

    # Report per-period breakdown
    period_counts = patch_df.groupby("donem").size()
    print(f"  patch_eus_gaps: {len(patch_df)} rows inserted "
          f"({patch_df['donem'].nunique()} periods, "
          f"{patch_df['muta'].nunique()} firms)")
    for d, cnt in period_counts.items():
        print(f"    {d}: {cnt} firms patched")

    con.close()
