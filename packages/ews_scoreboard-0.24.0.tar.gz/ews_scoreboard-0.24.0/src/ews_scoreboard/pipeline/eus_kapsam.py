"""
EUS Kapsam Pipeline: KIK + RKD + SQL kapsam + Memzuc filtrelerini birleştirerek
fact_periodic.eus_kapsam alanını hesaplar.

Transform sonrası, marts öncesi çalışır. Bronze tablolardan okur.
"""

import json
import duckdb
from pathlib import Path


def _donem_offset(donem: str, months: int = -2) -> str:
    """Dönem kodunu ay bazında kaydır. '2506' → '2504' (months=-2)."""
    yy, mm = int(donem[:2]), int(donem[2:])
    mm += months
    while mm < 1:
        mm += 12
        yy -= 1
    while mm > 12:
        mm -= 12
        yy += 1
    return f"{yy:02d}{mm:02d}"


def _kik_kapsam(con, donem: str) -> set:
    """KIK kapsam filtresi: kapsamdışı koşullarını sağlamayan firmalar."""
    df = con.execute("""
        SELECT DISTINCT muta FROM brz_kik_izleme
        WHERE donem = ?
          AND (ykn_izl_flag IS NULL OR ykn_izl_flag NOT IN ('1', '1.0', 'True', 'true'))
          AND COALESCE(gckm_gun_say, 0) = 0
          AND (erkn_izlm_kod IS NULL OR erkn_izlm_kod NOT IN ('1', '1.0', 'True', 'true'))
          AND COALESCE(ciss_flag, 0) = 0
    """, [donem]).fetchdf()
    return set(df["muta"].tolist())


def _rkd_kapsam(con, donem: str, kik_mutas: set) -> set:
    """RKD kapsam filtresi: KIK kapsamındaki firmalardan RKD koşullarını da sağlayanlar."""
    if not kik_mutas:
        return set()

    # Check if brz_rkd_kriter has data for this period
    cnt = con.execute("SELECT COUNT(*) FROM brz_rkd_kriter WHERE donem = ?", [donem]).fetchone()[0]
    if cnt == 0:
        # RKD verisi yoksa KIK kapsamını olduğu gibi döndür
        return kik_mutas

    df = con.execute("""
        SELECT DISTINCT muta FROM brz_rkd_kriter
        WHERE donem = ?
          AND COALESCE(sifir_flag, 0) = 0
          AND min_uzak_gun > 190
    """, [donem]).fetchdf()

    rkd_mutas = set(df["muta"].tolist())
    return kik_mutas & rkd_mutas


def _memzuc_filtre(con, donem: str, mutas: set) -> set:
    """Memzuc filtresi: idari_kanuni_takip ve ikt_6ay_ort ikisi de 0 olan firmalar."""
    if not mutas:
        return set()

    memzuc_donem = _donem_offset(donem, months=-2)

    cnt = con.execute("SELECT COUNT(*) FROM brz_memzuc WHERE donem = ?", [memzuc_donem]).fetchone()[0]
    if cnt == 0:
        # Memzuc verisi yoksa mevcut kapsamı döndür
        return mutas

    # Memzuc'ta temiz olanlar
    df = con.execute("""
        SELECT DISTINCT muta FROM brz_memzuc
        WHERE donem = ?
          AND COALESCE(idari_kanuni_takip, 0) = 0
          AND COALESCE(ikt_6ay_ort, 0) = 0
    """, [memzuc_donem]).fetchdf()

    temiz_mutas = set(df["muta"].tolist())
    return mutas & temiz_mutas


def _sql_kapsam(con, donem: str) -> set:
    """Mevcut brz_eus_kapsam listesinden SQL kapsamını al."""
    df = con.execute("""
        SELECT DISTINCT muta FROM brz_eus_kapsam WHERE donem = ?
    """, [donem]).fetchdf()
    return set(df["muta"].tolist())


def compute_eus_kapsam(db_path: Path, donemler: list = None) -> dict:
    """EUS kapsamını hesapla ve fact_periodic.eus_kapsam güncelle.

    Args:
        db_path: DuckDB veritabanı yolu.
        donemler: Hesaplanacak dönemler. None ise tüm dönemler.

    Returns:
        dict[donem, set[muta]]: Dönem bazında kapsamdaki firmalar.
    """
    con = duckdb.connect(str(db_path))

    if donemler is None:
        rows = con.execute(
            "SELECT DISTINCT donem FROM fact_periodic ORDER BY donem"
        ).fetchall()
        donemler = [r[0] for r in rows]

    donem_strs = [str(d) for d in donemler]
    sonuc = {}

    print("  EUS Kapsam hesaplama başladı...")

    for donem in donem_strs:
        # 1. KIK kapsam
        kik = _kik_kapsam(con, donem)

        # 2. RKD kapsam (KIK kesişimi)
        rkd = _rkd_kapsam(con, donem, kik)

        # 3. SQL kapsam (mevcut brz_eus_kapsam)
        sql = _sql_kapsam(con, donem)

        # 4. Memzuc filtre
        # Önce KIK ∩ RKD ∩ SQL, sonra memzuc filtresi
        if sql:
            combined = rkd & sql
        else:
            combined = rkd

        final = _memzuc_filtre(con, donem, combined)

        sonuc[donem] = final
        print(f"    {donem}: KIK={len(kik)} RKD={len(rkd)} SQL={len(sql)} Final={len(final)}")

    # fact_periodic.eus_kapsam güncelle
    print("  fact_periodic.eus_kapsam güncelleniyor...")
    for donem, mutas in sonuc.items():
        # Önce hepsini 0 yap
        con.execute("""
            UPDATE fact_periodic SET eus_kapsam = 0 WHERE donem = ?
        """, [donem])
        # Kapsamdakileri 1 yap
        if mutas:
            muta_list = list(mutas)
            # Batch update (DuckDB parameterized IN not supported, use temp table)
            muta_df = __import__('pandas').DataFrame({"entity_id": muta_list})
            con.execute("CREATE OR REPLACE TEMP TABLE _kapsam_update AS SELECT * FROM muta_df")
            con.execute("""
                UPDATE fact_periodic
                SET eus_kapsam = 1
                WHERE donem = ? AND entity_id IN (SELECT entity_id FROM _kapsam_update)
            """, [donem])
            con.execute("DROP TABLE IF EXISTS _kapsam_update")

    total_kapsam = sum(len(m) for m in sonuc.values())
    total_firma = sum(1 for m in sonuc.values() if m)
    print(f"  EUS Kapsam tamamlandı: {total_kapsam} kapsam kaydı ({len(donem_strs)} dönem)")

    con.close()
    return sonuc


def detect_anomalies(db_path: Path, output_path: Path = None,
                     min_donem: int = 6) -> list:
    """Kriter alıp kısa sürede kapsama dönen firmaları tespit et.

    Bir firma kapsam dışına çıkıp <min_donem dönem içinde tekrar kapsama giriyorsa
    bu 'sahte kriter' (geçici sorun) olabilir.

    Args:
        db_path: DuckDB veritabanı yolu.
        output_path: Sonuç JSON dosya yolu.
        min_donem: Kapsam dışı kalma eşiği (dönem sayısı).

    Returns:
        list[dict]: Anomali tespit edilen firmalar.
    """
    con = duckdb.connect(str(db_path), read_only=True)

    df = con.execute("""
        SELECT entity_id, donem, eus_kapsam
        FROM fact_periodic
        ORDER BY entity_id, donem
    """).fetchdf()

    con.close()

    if df.empty:
        return []

    anomaliler = []

    for entity_id, grp in df.groupby("entity_id"):
        grp = grp.sort_values("donem").reset_index(drop=True)
        kapsam_vals = grp["eus_kapsam"].tolist()
        donemler_list = grp["donem"].tolist()

        # Kapsam dışı dönemleri bul
        i = 0
        while i < len(kapsam_vals):
            if kapsam_vals[i] == 0:
                # Kapsam dışına çıkış başlangıcı
                start = i
                while i < len(kapsam_vals) and kapsam_vals[i] == 0:
                    i += 1
                # Kapsam dışı dönem sayısı
                gap_len = i - start

                # Tekrar kapsama girdi mi?
                if i < len(kapsam_vals) and kapsam_vals[i] == 1 and gap_len < min_donem:
                    anomaliler.append({
                        "entity_id": entity_id,
                        "cikis_donem": donemler_list[start],
                        "donus_donem": donemler_list[i],
                        "gap_donem": gap_len,
                    })
            else:
                i += 1

    if output_path and anomaliler:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(anomaliler, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
        print(f"  Anomali raporu: {len(anomaliler)} firma → {output_path}")

    return anomaliler
