"""
Pipeline checkpoint fonksiyonları.

Transform sonrası veri kalitesini kontrol eder.
Pipeline'ı DURDURMAZ — sadece uyarı verir ve diagnostik notebook'a yönlendirir.
"""

import duckdb


def kontrol_risk_tutarlilik(con, sample_n=1000, tolerans=1.0):
    """Risk değişim zinciri tutarlılık kontrolü.

    Her firma için: ilk_risk + sum(risk_degisim) ≈ son_risk olmalı.
    sample_n firma seçer, formülü kontrol eder.

    Returns: (status, detay_dict)
        status: "OK", "WARNING", "ERROR"
    """
    try:
        total_firms = con.execute(
            "SELECT COUNT(DISTINCT entity_id) FROM fact_periodic WHERE kombine_risk IS NOT NULL"
        ).fetchone()[0]

        if total_firms == 0:
            return "OK", {"tutarsiz": 0, "sample": 0, "oran": 0, "ornek_firmalar": []}

        actual_sample = min(sample_n, total_firms)

        # risk_degisim ilk dönemde fact_periodic dışı LAG'dan gelebilir.
        # Doğru kontrol: ardışık dönemler arasında risk_degisim == kombine_risk - LAG(kombine_risk)
        df = con.execute(f"""
            WITH sampled AS (
                SELECT DISTINCT entity_id FROM fact_periodic
                WHERE kombine_risk IS NOT NULL
                ORDER BY HASH(entity_id)
                LIMIT {actual_sample}
            ),
            with_lag AS (
                SELECT
                    fp.entity_id, fp.donem, fp.kombine_risk, fp.risk_degisim,
                    LAG(fp.kombine_risk) OVER (PARTITION BY fp.entity_id ORDER BY fp.donem) AS prev_risk
                FROM fact_periodic fp
                INNER JOIN sampled s ON fp.entity_id = s.entity_id
                WHERE fp.kombine_risk IS NOT NULL
            ),
            per_row_check AS (
                SELECT entity_id, donem, risk_degisim, kombine_risk, prev_risk,
                       kombine_risk - prev_risk AS beklenen,
                       COALESCE(risk_degisim, 0) - (kombine_risk - prev_risk) AS fark
                FROM with_lag
                WHERE prev_risk IS NOT NULL  -- ilk dönem hariç
            ),
            firma_tutarsiz AS (
                SELECT entity_id, COUNT(*) AS tutarsiz_donem,
                       MAX(ABS(fark)) AS max_fark
                FROM per_row_check
                WHERE ABS(fark) > {tolerans}
                GROUP BY entity_id
            )
            SELECT entity_id, tutarsiz_donem, max_fark
            FROM firma_tutarsiz
            ORDER BY max_fark DESC
        """).fetchdf()

        tutarsiz_count = len(df)
        oran = tutarsiz_count / actual_sample if actual_sample > 0 else 0

        if oran > 0.20:
            status = "ERROR"
        elif oran > 0.05:
            status = "WARNING"
        else:
            status = "OK"

        ornek = df.head(10).to_dict("records") if not df.empty else []

        print(f"  Risk tutarlılık: {status} ({tutarsiz_count}/{actual_sample} = {oran:.1%})")

        return status, {
            "tutarsiz": tutarsiz_count,
            "sample": actual_sample,
            "oran": oran,
            "ornek_firmalar": ornek,
        }

    except Exception as e:
        print(f"  Risk tutarlılık: HATA — {e}")
        return "ERROR", {"hata": str(e)}


def kontrol_unvan_doluluk(con):
    """Unvan boşluk oranı kontrolü.

    > %10 ise WARNING, > %30 ise ERROR.

    Returns: (status, detay_dict)
    """
    try:
        total = con.execute("SELECT COUNT(*) FROM map_identity").fetchone()[0]
        if total == 0:
            return "OK", {"toplam": 0, "bos": 0, "oran": 0}

        bos = con.execute("""
            SELECT COUNT(*) FROM map_identity
            WHERE unvan IS NULL OR TRIM(unvan) = '' OR unvan = 'None'
        """).fetchone()[0]

        oran = bos / total

        if oran > 0.30:
            status = "ERROR"
        elif oran > 0.10:
            status = "WARNING"
        else:
            status = "OK"

        print(f"  Unvan doluluk: {status} ({bos}/{total} boş = {oran:.1%})")

        return status, {
            "toplam": total,
            "bos": bos,
            "oran": oran,
        }

    except Exception as e:
        print(f"  Unvan doluluk: HATA — {e}")
        return "ERROR", {"hata": str(e)}
