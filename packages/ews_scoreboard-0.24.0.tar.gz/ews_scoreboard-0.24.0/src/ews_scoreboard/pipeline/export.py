"""
Export: mart → outputs (JSON, HTML).
"""

from pathlib import Path


def run_export(db_path: Path, output_dir: Path = None, file_suffix: str = ""):
    """Export step — verify outputs exist."""
    if output_dir is None:
        output_dir = Path(db_path).parent.parent / "outputs"
    json_dir = output_dir / "json"
    html_dir = output_dir / "html"
    json_dir.mkdir(parents=True, exist_ok=True)
    html_dir.mkdir(parents=True, exist_ok=True)

    scoreboard = json_dir / f"sample_scoreboard{file_suffix}.json"
    trending = json_dir / f"sample_trending_lists{file_suffix}.json"

    if scoreboard.exists():
        print(f"  [OK] {scoreboard} ({scoreboard.stat().st_size / 1024:.1f} KB)")
    else:
        print(f"  [WARN] {scoreboard} not found — run marts step first")

    if trending.exists():
        print(f"  [OK] {trending} ({trending.stat().st_size / 1024:.1f} KB)")
    else:
        print(f"  [WARN] {trending} not found — run marts step first")
