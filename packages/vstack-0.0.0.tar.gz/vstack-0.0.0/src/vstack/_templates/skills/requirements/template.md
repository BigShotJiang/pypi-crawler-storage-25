{{SKILL_CONTEXT}}

# requirements — Requirements Gathering & Documentation

Clarify and document what must be built before engineering starts. Produce a
`docs/product/requirements.md` that downstream roles (architect, designer, engineer) can
work from.

## Out of scope

- Technical design and architecture decisions (use `architecture`)
- API/service design (use `design`)
- Roadmap and milestone planning (product role artifact)
- Implementation (engineering role)

## Deliverable and artifact policy

- Primary deliverable: `docs/product/requirements.md`
- Baseline-first default: write final requirements directly to `docs/product/requirements.md` on the feature branch.
- Optional WIP area for complex/uncertain intake: `docs/delta/{intake-id}/REQUIREMENTS_DELTA.md`
- Before merge: consolidate any required content from optional delta notes back into `docs/product/requirements.md`, then remove stale WIP notes.

______________________________________________________________________

## Step 0: Context

Read existing artifacts before asking questions:

```bash
cat docs/product/vision.md 2>/dev/null || true
cat docs/product/requirements.md 2>/dev/null || true
cat docs/product/roadmap.md 2>/dev/null || true
cat README.md 2>/dev/null | head -40 || true
```

Identify what's already known and what needs clarification.

______________________________________________________________________

## Step 1: Problem Statement

Clarify the core problem being solved:

> **Question:** Describe what you want to build and why.
>
> - What problem does this solve?
> - Who experiences this problem today?
> - What happens if we don't solve it?

Document:

```text
## Problem Statement
[One paragraph: root problem, who has it, impact of not solving it]
```

______________________________________________________________________

## Step 2: Users & Stakeholders

Who uses or is affected by this?

| Role        | Description | Primary need |
| ----------- | ----------- | ------------ |
| [User type] |             |              |

______________________________________________________________________

## Step 3: Functional Requirements

What must the system do? Use the format: "The system must [verb] [object] [condition/constraint]."

Ask for clarity on ambiguous areas:

> **Question:** Are there any specific behaviors or edge cases that are critical?

```markdown
## Functional Requirements

### Must have (MVP)
- FR-01: The system must [...]
- FR-02: The system must [...]

### Should have (desirable)
- FR-03: [...]

### Won't have (explicitly out of scope)
- [State what will NOT be built in this iteration]
```

______________________________________________________________________

## Step 4: Non-Functional Requirements

| Category     | Requirement    | Measurable target                    |
| ------------ | -------------- | ------------------------------------ |
| Performance  | Response time  | p99 < 500ms under X rps              |
| Availability | Uptime         | 99.9% (< 8.7h downtime/year)         |
| Security     | Auth           | All endpoints require authentication |
| Scalability  | Load           | Handle up to N concurrent users      |
| Compliance   | Data residency | Data stored in [region]              |

Ask:

> **Question:** Are there any hard non-functional requirements (performance, security,
> compliance, data residency)?

______________________________________________________________________

## Step 5: Constraints & Assumptions

Document known constraints:

```markdown
## Constraints
- Budget: [if relevant]
- Timeline: [hard deadline if any]
- Technology: [must use X, cannot use Y]
- Team: [available skill set]
- Existing systems: [must integrate with X]

## Assumptions
- [Things assumed true that could invalidate requirements if wrong]
```

______________________________________________________________________

## Step 6: Success Criteria

What does "done" look like? How do we know the requirements are met?

```markdown
## Success Criteria
- [ ] [Measurable outcome 1]
- [ ] [Measurable outcome 2]
- [ ] [Acceptance test: given X, when Y, then Z]
```

______________________________________________________________________

## Step 7: Open Questions

List anything that is unclear and needs a decision before work begins:

```markdown
## Open Questions
- [ ] [Question] — Owner: [who decides] — Deadline: [when needed]
```

______________________________________________________________________

## Output: requirements.md

Write all findings to `docs/product/requirements.md`:

```markdown
# Requirements — [feature/project name]

**Status:** draft | reviewed | approved
**Date:** YYYY-MM-DD
**Author:** product role

## Problem Statement
[...]

## Users & Stakeholders
[table]

## Functional Requirements
[...]

## Non-Functional Requirements
[table]

## Constraints & Assumptions
[...]

## Success Criteria
[...]

## Open Questions
[...]
```

After writing, summarize what was decided so the architect role can start.

______________________________________________________________________
