{{SKILL_CONTEXT}}

# adr — Architecture Decision Record

Document a significant technical decision so future contributors understand
what was decided, why, and what alternatives were considered.

## Out of scope

- Architecture reviews of plans (use `architecture`)
- Gathering requirements (use `requirements`)
- Implementation (engineering role)
- Running analysis to inform the decision (use `analyse`)

______________________________________________________________________

## Step 0: Context Gathering

Read existing ADRs and architecture docs:

```bash
ls docs/architecture/adr/ 2>/dev/null | sort | head -20 || true
cat docs/architecture/architecture.md 2>/dev/null | head -40 || true
# Find highest existing ADR number
ls docs/architecture/adr/*.md 2>/dev/null | grep -oE '[0-9]+' | sort -n | tail -1 || echo "0"
```

Determine the next ADR number (pad to 3 digits: 001, 002, ...).

______________________________________________________________________

## Step 1: Understand the Decision

> **Question:** What decision are we recording?
> **Options:** A) Decision already made — record it | B) Options still open — evaluate and recommend | C) Superseding an existing ADR — which one?
> **Default if no response:** A (record an already-made decision)

Document:

```text
Decision: [One-line statement of what was decided]
Status:   proposed | accepted | rejected | deprecated | superseded
Date:     YYYY-MM-DD
```

______________________________________________________________________

## Step 2: Context

Why does this decision need to be made? What forces are at play?

Include:

- The problem or requirement driving the decision
- Relevant constraints (technical, organizational, timeline)
- Dependencies on other decisions
- What happens if no decision is made

```markdown
## Context
[2-4 paragraphs explaining the situation, constraints, and why this matters]
```

______________________________________________________________________

## Step 3: Alternatives Considered

List all serious options that were evaluated. For each:

```markdown
### Option A: [Name]
**Description:** [What this option is]
**Pros:**
- [...]
**Cons:**
- [...]
**Why rejected:** [or "this is the chosen option"]
```

Include at least 2-3 alternatives. Including a "do nothing" option is recommended.

______________________________________________________________________

## Step 4: Decision

State the chosen option clearly:

```markdown
## Decision
We will [chosen option].

[1-2 sentences on why this option was selected over alternatives]
```

______________________________________________________________________

## Step 5: Rationale

Explain the reasoning in depth:

```markdown
## Rationale
[Detailed explanation: what made this the right choice given the context and constraints.
Reference specific cons from rejected options and explain why they were acceptable tradeoffs.]
```

______________________________________________________________________

## Step 6: Consequences & Impact

```markdown
## Consequences

### Positive
- [Expected benefits]

### Negative / Tradeoffs
- [Known downsides or limitations of this choice]

### Risks
- [What could go wrong, and how we'd detect or mitigate it]
```

______________________________________________________________________

## Step 7: Related Decisions

```markdown
## Related ADRs
- ADR-NNN: [title] — [relationship: supersedes / related to / depends on]
```

______________________________________________________________________

## Output: ADR file

Write to `docs/architecture/adr/NNN-<slug>.md` where NNN is the next available number and slug
is a kebab-case title.

```markdown
# ADR-NNN: <title>

**Date:** YYYY-MM-DD
**Status:** proposed | accepted | rejected | deprecated | superseded

## Context
[...]

## Decision
[...]

## Alternatives Considered
[...]

## Rationale
[...]

## Consequences
[...]

## Related ADRs
[...]
```

After writing, state the file path and summary so the architect or product role can review.

______________________________________________________________________
