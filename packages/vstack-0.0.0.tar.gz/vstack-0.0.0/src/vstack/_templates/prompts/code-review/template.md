Review the selected code or diff for production risk.

Focus only on issues with real impact:

- correctness and edge cases
- security and data exposure
- performance and scalability
- maintainability and ownership boundaries
- missing tests for changed behavior

Ignore:

- style-only preferences with no runtime impact
- speculative risks without evidence in this change

Output exactly in this format:

## Must fix

List blocking issues that should be resolved before merge.

## Should consider

List non-blocking improvements worth addressing now.

## Looks good

List intentional strengths in this change.

For each item:

- cite the relevant file/section
- explain why it matters in one short sentence
- give one concrete fix suggestion

End with:

- Merge recommendation: yes / no / yes-with-conditions
- Biggest remaining risk: one sentence
