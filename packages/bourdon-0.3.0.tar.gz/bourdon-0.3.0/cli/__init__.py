"""Bourdon CLI package."""
