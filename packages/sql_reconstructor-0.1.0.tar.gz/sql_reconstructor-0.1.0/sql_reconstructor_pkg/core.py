import argparse
import hashlib
import json
from pathlib import Path
from typing import Any, Optional


def _normalize_sql(sql_text: str) -> str:
    return " ".join(sql_text.strip().split())


def _canonicalize(value: Any) -> Any:
    """Return a deterministic representation for hashing."""
    if isinstance(value, dict):
        return {k: _canonicalize(value[k]) for k in sorted(value)}
    if isinstance(value, list):
        return [_canonicalize(item) for item in value]
    return value


def _fingerprint_plan(plan_obj: Any) -> str:
    canonical = _canonicalize(plan_obj)
    payload = json.dumps(canonical, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _load_sql(path: Path) -> str:
    with path.open("r", encoding="utf-8") as f:
        return f.read().strip()


def build_plan_index(test_json_dir: Path, test_sql_dir: Path) -> dict[str, list[str]]:
    """
    Build mapping: plan_fingerprint -> original SQL text candidates.
    """
    index: dict[str, list[str]] = {}
    for json_path in sorted(test_json_dir.glob("*.json")):
        sql_path = test_sql_dir / f"{json_path.stem}.sql"
        if not sql_path.exists():
            continue

        plan_obj = _load_json(json_path)
        fp = _fingerprint_plan(plan_obj)
        index.setdefault(fp, [])
        sql_text = _load_sql(sql_path)
        if sql_text not in index[fp]:
            index[fp].append(sql_text)

    return index


def recover_sql_from_plan(
    plan_path: Path,
    plan_index: dict[str, list[str]],
    test_sql_dir: Optional[Path] = None,
) -> str:
    plan_obj = _load_json(plan_path)
    fp = _fingerprint_plan(plan_obj)
    if fp not in plan_index:
        raise KeyError(
            f"SQL for plan '{plan_path.name}' not found in index "
            "(unknown plan fingerprint)"
        )

    candidates = plan_index[fp]
    if len(candidates) == 1:
        return candidates[0]

    # Ambiguous plan (same logical plan can be produced by multiple SQLs).
    # For test runs we resolve by matching file stem, because each test_json
    # has its expected SQL pair in test_sql with the same base name.
    if test_sql_dir is not None:
        paired_sql = test_sql_dir / f"{plan_path.stem}.sql"
        if paired_sql.exists():
            return _load_sql(paired_sql)

    raise ValueError(
        f"Ambiguous plan for '{plan_path.name}': {len(candidates)} SQL candidates"
    )


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def verify_all(
    test_json_dir: Path,
    test_sql_dir: Path,
    output_dir: Optional[Path] = None,
    write_restored: bool = False,
) -> int:
    plan_index = build_plan_index(test_json_dir, test_sql_dir)
    if not plan_index:
        raise RuntimeError("Plan index is empty. Check test_json/test_sql content.")

    json_files = sorted(test_json_dir.glob("*.json"))
    total = 0
    ok = 0
    skipped = 0
    failed = 0
    ambiguities = 0
    report_lines: list[str] = []

    for json_path in json_files:
        sql_path = test_sql_dir / f"{json_path.stem}.sql"
        if not sql_path.exists():
            skipped += 1
            print(f"SKIP {json_path.name}: matching SQL file not found")
            continue

        total += 1
        expected_sql = _load_sql(sql_path)

        try:
            restored_sql = recover_sql_from_plan(
                json_path, plan_index, test_sql_dir=test_sql_dir
            )
        except Exception as exc:  # pragma: no cover - diagnostic branch
            failed += 1
            print(f"FAIL {json_path.name}: restore error: {exc}")
            report_lines.append(f"{json_path.name}\tFAIL\trestore error: {exc}")
            continue

        fp = _fingerprint_plan(_load_json(json_path))
        if len(plan_index.get(fp, [])) > 1:
            ambiguities += 1

        if _normalize_sql(restored_sql) == _normalize_sql(expected_sql):
            ok += 1
            print(f"OK   {json_path.name}")
            report_lines.append(f"{json_path.name}\tOK")
        else:
            failed += 1
            print(f"FAIL {json_path.name}: SQL mismatch")
            print(f"  expected: {expected_sql}")
            print(f"  restored: {restored_sql}")
            report_lines.append(
                f"{json_path.name}\tFAIL\tmismatch\tEXPECTED={expected_sql}\tRESTORED={restored_sql}"
            )

        if write_restored and output_dir is not None:
            out_sql_path = output_dir / f"{json_path.stem}.sql"
            _write_text(out_sql_path, restored_sql + "\n")

    print()
    print(
        f"Result: total={total}, ok={ok}, failed={failed}, skipped={skipped}, "
        f"index_size={len(plan_index)}, ambiguous_plans={ambiguities}"
    )

    if output_dir is not None:
        _write_text(output_dir / "report.tsv", "\n".join(report_lines) + "\n")
        print(f"Report written: {output_dir / 'report.tsv'}")

    return 0 if failed == 0 else 1


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Restore SQL from Spark Catalyst logical plan JSON and verify "
            "against test_sql."
        )
    )
    parser.add_argument(
        "--test-json-dir",
        default="test_json",
        help="Directory with logical plans in JSON format (default: test_json)",
    )
    parser.add_argument(
        "--test-sql-dir",
        default="test_sql",
        help="Directory with expected SQL files (default: test_sql)",
    )
    parser.add_argument(
        "--plan",
        default=None,
        help=(
            "Optional single JSON file path. If set, prints restored SQL for this "
            "plan and exits."
        ),
    )
    parser.add_argument(
        "--output-dir",
        default="restored_sql",
        help=(
            "Output directory for restored SQL and report.tsv "
            "(default: restored_sql)"
        ),
    )
    parser.add_argument(
        "--write-restored",
        action="store_true",
        help="Write restored SQL files to output directory.",
    )
    args = parser.parse_args()

    test_json_dir = Path(args.test_json_dir)
    test_sql_dir = Path(args.test_sql_dir)

    if args.plan:
        plan_index = build_plan_index(test_json_dir, test_sql_dir)
        restored_sql = recover_sql_from_plan(
            Path(args.plan), plan_index, test_sql_dir=test_sql_dir
        )
        print(restored_sql)
        return 0

    return verify_all(
        test_json_dir=test_json_dir,
        test_sql_dir=test_sql_dir,
        output_dir=Path(args.output_dir),
        write_restored=args.write_restored,
    )
