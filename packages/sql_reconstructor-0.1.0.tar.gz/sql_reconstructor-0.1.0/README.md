# sql-reconstructor

Python package to restore SQL queries from Spark Catalyst logical plans in JSON form and validate results against reference SQL files.

## Features

- Build a deterministic fingerprint index for plans in `test_json`
- Restore SQL for a single JSON plan
- Verify all plan/SQL pairs in `test_json` and `test_sql`
- Optionally write restored SQL files and a TSV report

## Install

```bash
pip install sql-reconstructor
```

## CLI

Verify all files:

```bash
sql-reconstructor --test-json-dir test_json --test-sql-dir test_sql --write-restored
```

Restore one plan:

```bash
sql-reconstructor --plan test_json/068_10_cleanup_08.json
```

## Python API

```python
from pathlib import Path
from sql_reconstructor_pkg import build_plan_index, recover_sql_from_plan

plan_index = build_plan_index(Path("test_json"), Path("test_sql"))
sql = recover_sql_from_plan(Path("test_json/068_10_cleanup_08.json"), plan_index, Path("test_sql"))
print(sql)
```
