

class SigningError(Exception):
    pass
