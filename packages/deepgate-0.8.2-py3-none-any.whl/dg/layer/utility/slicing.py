from dg.layer.base import BaseModule


class Slice(BaseModule):
    """Keep only the first ``keep_bits`` elements of the last dimension.

    Args:
        keep_bits: Number of elements to retain along the last dimension.
    """

    def __init__(self, keep_bits):
        super().__init__()
        self.keep_bits = keep_bits

    def get_module_specs(self):
        return {
            "keep_bits": self.keep_bits,
        }

    def _forward(self, x):
        return x[..., :self.keep_bits]
