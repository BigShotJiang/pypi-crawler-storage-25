from dg.layer.base import BaseModule


class BitShift(BaseModule):
    """Multiply-by-power-of-two layer that emulates compiler-side bit shifts.

    Multiplies the input by ``2 ** (±nb_shift)``, casts the result to ``int``
    to match the compiler's truncation, and uses a straight-through
    estimator so gradients bypass the cast.

    Args:
        nb_shift: Shift amount (positive integer).
        direction: ``"right"`` (divide) or ``"left"`` (multiply).
    """

    def __init__(self, nb_shift, direction="right"):
        super().__init__()
        self.nb_shift = nb_shift
        self.direction = direction

        sign = -1 if direction == "right" else 1
        exponent = sign * nb_shift
        self.multiplier = 2 ** exponent

    def get_module_specs(self):
        return {
            "nb_shift": self.nb_shift,
            "direction": self.direction,
        }

    def _forward(self, x):
        # We're distilling multiplication into bit-shifts on the compiler side, so we need to replicate the exact bit-shifting behavior here.
        # We do this by casting to int() and using the STE (straight-through estimator) for gradients.
        # For example: 9 * 0.5 = 4.5, but we need this to evaluate as 4 — hence the int() cast.
        x = self.multiplier * x
        return x.int() + x - x.detach()
