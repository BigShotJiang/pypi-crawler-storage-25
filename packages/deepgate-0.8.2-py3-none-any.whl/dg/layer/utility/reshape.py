import torch

from dg.layer.base import BaseModule


class Reshape(BaseModule):
    """Reshape spatial ``[C, H, W]`` to flat ``[N, K]`` detection output.

    In PyTorch forward: permutes ``NCHW → NHWC`` then reshapes. In compiler
    HWC layout this is a pure metadata change (no-op in C code).

    Args:
        target_shape: Output shape without batch dim, e.g. ``(1296, 5)`` for
            SSD stride-8 with 18x18 spatial, 4 anchors, 5 channels.
    """

    def __init__(self, target_shape: tuple[int, ...]):
        super().__init__()
        self.target_shape = tuple(target_shape)

    def get_module_specs(self):
        return {"target_shape": list(self.target_shape)}

    def _forward(self, x):
        B = x.shape[0]
        x = x.permute(0, 2, 3, 1).contiguous()
        result = x.reshape(B, *self.target_shape)
        return result

    def _permute_input_to_compiler_layout(self, x):
        if x.ndim == 3:
            return x.permute(1, 2, 0)
        return x

    def _permute_output_to_compiler_layout(self, x):
        return x
