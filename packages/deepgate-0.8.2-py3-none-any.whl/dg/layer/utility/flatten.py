import torch

from dg.layer.base import BaseModule


class Flatten(BaseModule):
    """Flatten a 4-D spatial tensor into a 2-D flat tensor.

    The tensor is permuted from ``[B, C, H, W]`` to ``[B, H, W, C]`` before
    being flattened along the trailing three dimensions (for compiler
    compatibility).
    """

    def __init__(self):
        super().__init__()

    def get_module_specs(self):
        return {}

    def _permute_input_to_compiler_layout(self, x):
        if len(x.shape) == 3:
            return x.permute(1, 2, 0)
        return x

    def _forward(self, x):
        assert x.ndim == 4
        # For compiler side, if x is batch of image data, we permute [B, C, H, W] -> [B, H, W, C]
        x = x.permute(0, 2, 3, 1)

        return torch.flatten(x, 1, 3)
