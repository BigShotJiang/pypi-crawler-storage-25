import torch

from dg.layer.base import BaseModule


class Concat(BaseModule):
    """Concatenate a list of tensors along a non-batch dimension.

    Called explicitly (not through :class:`torch.nn.Sequential`) with a list
    of tensors as input.

    Args:
        dim: Concatenation dimension, given without the batch dimension
            (``0`` is the first non-batch dim).
        input_shapes: Per-input shapes (batch-excluded). All inputs must
            match on every dimension except ``dim``.
    """

    def __init__(self, dim: int, input_shapes: list[list[int]]):
        super().__init__()
        self.dim = dim
        self.input_shapes = [list(s) for s in input_shapes]
        out_shape = list(input_shapes[0])
        out_shape[dim] = sum(s[dim] for s in input_shapes)
        self._output_shape = out_shape

    def get_module_specs(self):
        return {
            "dim": self.dim,
            "num_inputs": len(self.input_shapes),
            "input_shapes": self.input_shapes,
        }

    def _forward(self, tensors: list[torch.Tensor]):
        return torch.cat(tensors, dim=self.dim + 1)

    def forward(self, tensors: list[torch.Tensor]):
        # Override BaseModule.forward because the default assumes a single-tensor input.
        if self.shape_in is None:
            first = tensors[0][0]
            self.shape_in = self._jsonify_io_shape(list(first.shape))
        result = self._forward(tensors)
        if self.shape_out is None:
            out = result[0]
            self.shape_out = self._jsonify_io_shape(list(out.shape))
        return result
