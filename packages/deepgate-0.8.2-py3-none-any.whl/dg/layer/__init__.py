# ANN layers (standard and quantized)
from .ann import (
    Linear,
    Norm,
    UpperTriangularLinear,
    LowerTriangularLinear,
    QuantLinear,
    QuantUpperTriangularLinear,
    QuantLowerTriangularLinear,
    QuantConv2d,
    QuantDepthwiseConv2d,
    QuantAvgPool2d,
    QuantResidualAdd
)

# Utility layers (shared)
from .utility import Flatten, Pad, Slice, Expand, BlockShuffle, MaxPool2d, BitShift, Reshape, Concat

# Logic and encoding layers (available in workspace/source installs only)
try:
    from .logic import LUTLinear, LUTConv2d, GroupSum, ReadoutModule, get_readout, connectivity
    from .logic import ThermometerEncode, ThermometerEncode1d, RGB4bitTo32bitLUT
    from .logic.connectivity import BlockParamsBuilder
except ImportError:
    pass
