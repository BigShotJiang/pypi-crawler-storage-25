import torch
from typing import Any

from dg.dtype import torch_to_str


def tensor_spec(tensor: torch.Tensor) -> dict[str, Any]:
    """Convert torch tensor to spec dict with data and dtype.

    Args:
        tensor: PyTorch tensor (dtype is inferred automatically)

    Returns:
        {"data": [...], "dtype": "float32"}
    """
    return {
        "data": tensor.tolist(),
        "dtype": torch_to_str(tensor.dtype)
    }


def scalar_spec(value: float | int, dtype: str) -> dict[str, Any]:
    """Wrap a scalar value with dtype info.

    Args:
        value: Scalar number
        dtype: Explicit dtype string (required - Python scalars have no fixed dtype)

    Returns:
        {"data": value, "dtype": dtype}
    """
    return {"data": value, "dtype": dtype}
