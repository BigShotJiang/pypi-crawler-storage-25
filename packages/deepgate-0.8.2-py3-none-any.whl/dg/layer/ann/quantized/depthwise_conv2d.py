import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Any

from dg.layer.spec_utils import scalar_spec, tensor_spec

from .base import QuantBase
from .fake_quant import fake_quantize_symmetric, fake_quantize_asymmetric


class QuantDepthwiseConv2d(QuantBase):
    """Int8-quantized depthwise 2-D convolution with optional BatchNorm and ReLU.

    Each input channel is convolved with its own ``[1, kH, kW]`` kernel
    (``groups = channels``). BN parameters are folded into the weight for
    schema export.

    Args:
        channels: Number of input / output channels.
        kernel_size: Kernel size.
        stride: Convolution stride.
        padding: Zero-padding. ``int`` or 2-tuple ``(pad_h, pad_w)`` or
            4-tuple ``(L, R, T, B)``.
        bias: Whether to include an additive bias.
        device: Torch device for the underlying parameters.
        act_func: Either ``"relu"`` or ``None``.
        ema_constant: EMA smoothing factor for observers.
        bn: If ``True``, append a BatchNorm2d layer and fold it into weights
            for schema export.
    """

    def __init__(
        self,
        channels: int,
        kernel_size: int | tuple[int, int],
        stride: int | tuple[int, int] = 1,
        padding: int | tuple[int, int] | tuple[int, int, int, int] = 0,
        bias: bool = True,
        device: str = "cpu",
        act_func: str | None = None,
        ema_constant: float = 0.01,
        input_quant_op=fake_quantize_asymmetric,
        output_quant_op=fake_quantize_asymmetric,
        bn: bool = False,
    ):
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            fix_output_zero=(act_func == "relu"),
            ema_constant=ema_constant,
        )
        assert act_func in [None, "relu"]

        self.channels = channels
        self.act_func = act_func

        self.kernel_size = self._normalize_pair(kernel_size)
        self.stride = self._normalize_pair(stride)
        self.padding = self._normalize_padding(padding)

        self.conv = nn.Conv2d(
            in_channels=channels,
            out_channels=channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=0,
            groups=channels,
            bias=bias,
            device=device,
            dtype=torch.float32,
        )
        self.bn = nn.BatchNorm2d(channels) if bn else None

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.shape[1] == self.channels
        assert x.dim() == 4

        weight_scales = self._compute_weight_scales(self.conv.weight)
        weight_q = fake_quantize_symmetric(self.conv.weight, weight_scales.view(-1, 1, 1, 1))

        if any(p > 0 for p in self.padding):
            x = F.pad(x, self.padding, mode='constant', value=0)

        x = F.conv2d(x, weight_q, self.conv.bias, self.stride, padding=0, groups=self.channels)

        if self.bn is not None:
            x = self.bn(x)

        if self.act_func == "relu":
            x = F.relu(x)

        return x

    def _get_fused_weight_bias(self):
        weight = self.conv.weight.detach().cpu()
        bias = self.conv.bias.detach().cpu() if self.conv.bias is not None else torch.zeros(self.channels)
        if self.bn is None:
            return weight, self.conv.bias.detach().cpu() if self.conv.bias is not None else None
        gamma = self.bn.weight.detach().cpu()
        beta = self.bn.bias.detach().cpu()
        running_mean = self.bn.running_mean.detach().cpu()
        running_var = self.bn.running_var.detach().cpu()
        eps = self.bn.eps
        scale = gamma / torch.sqrt(running_var + eps)
        # Depthwise: weight shape is [channels, 1, kH, kW]
        weight_fused = weight * scale.view(-1, 1, 1, 1)
        bias_fused = (bias - running_mean) * scale + beta
        return weight_fused, bias_fused

    def get_module_specs(self) -> dict[str, Any]:
        weight, bias = self._get_fused_weight_bias()
        assert weight.shape == (self.channels, 1, self.kernel_size[0], self.kernel_size[1])

        input_scale = self.input_scale.item()
        output_scale = self.output_observer.scale.item()
        weight_scales = self._compute_weight_scales(weight)

        weights_int8 = self._quantize_weights_int8(weight, weight_scales)
        bias_int32 = self._quantize_bias_int32(bias, input_scale, weight_scales)
        requant_mult, requant_shift = self._compute_requant_params(
            self.channels, input_scale, weight_scales, output_scale
        )

        return {
            "act_func": self.act_func,
            "weights_int8": tensor_spec(weights_int8.squeeze(1).permute(1, 2, 0)),
            "weight_scales": tensor_spec(weight_scales),
            "bias_int32": tensor_spec(bias_int32) if bias_int32 is not None else None,
            "input_scale": scalar_spec(input_scale, "float32"),
            "input_zp": scalar_spec(int(self.input_zp.item()), "int32"),
            "input_no_quant": self.input_no_quant,
            "output_scale": scalar_spec(output_scale, "float32"),
            "output_zp": scalar_spec(int(self.output_observer.zero_point.item()), "int32"),
            "requant_multiplier": tensor_spec(requant_mult),
            "requant_shift": tensor_spec(requant_shift),
            "kernel_size": list(self.kernel_size),
            "stride": list(self.stride),
            "padding": list(self.padding),
        }
