import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Any

from dg.layer.spec_utils import scalar_spec, tensor_spec

from .base import QuantBase
from .fake_quant import fake_quantize_symmetric, fake_quantize_asymmetric


class QuantLinear(QuantBase):
    """Int8-quantized linear layer with optional ReLU activation.

    Uses asymmetric fake-quantization for activations and symmetric
    per-output-channel fake-quantization for weights.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias.
        act_func: Either ``"relu"`` or ``None``.
        ema_constant: EMA smoothing factor for activation observers.
        device: Torch device for the underlying parameters.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        act_func: str | None = None,
        ema_constant: float = 0.01,
        device: str = "cpu",
        input_quant_op=fake_quantize_asymmetric,
        output_quant_op=fake_quantize_asymmetric,
    ):
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            fix_output_zero=(act_func == "relu"),
            ema_constant=ema_constant,
        )
        assert act_func in [None, "relu"]

        self.in_features = in_features
        self.out_features = out_features
        self.act_func = act_func

        self.linear = nn.Linear(in_features, out_features, bias, device, dtype=torch.float32)

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.shape[-1] == self.in_features
        assert x.dim() == 2

        weight_scales = self._compute_weight_scales(self.linear.weight)
        weight_q = fake_quantize_symmetric(self.linear.weight, weight_scales.unsqueeze(1))

        x = F.linear(x, weight_q, self.linear.bias)

        if self.act_func == "relu":
            x = F.relu(x)

        return x

    def get_module_specs(self) -> dict[str, Any]:
        weight = self.linear.weight.detach().cpu()
        bias = self.linear.bias.detach().cpu() if self.linear.bias is not None else None
        input_scale = self.input_scale.item()
        output_scale = self.output_observer.scale.item()
        weight_scales = self._compute_weight_scales(weight)

        weights_int8 = self._quantize_weights_int8(weight, weight_scales)
        bias_int32 = self._quantize_bias_int32(bias, input_scale, weight_scales)
        requant_mult, requant_shift = self._compute_requant_params(
            self.out_features, input_scale, weight_scales, output_scale
        )

        return {
            "act_func": self.act_func,
            "weights_int8": tensor_spec(weights_int8),
            "weight_scales": tensor_spec(weight_scales),
            "bias_int32": tensor_spec(bias_int32) if bias_int32 is not None else None,
            "input_scale": scalar_spec(input_scale, "float32"),
            "input_zp": scalar_spec(int(self.input_zp.item()), "int32"),
            "input_no_quant": self.input_no_quant,
            "output_scale": scalar_spec(output_scale, "float32"),
            "output_zp": scalar_spec(int(self.output_observer.zero_point.item()), "int32"),
            "requant_multiplier": tensor_spec(requant_mult),
            "requant_shift": tensor_spec(requant_shift),
        }
