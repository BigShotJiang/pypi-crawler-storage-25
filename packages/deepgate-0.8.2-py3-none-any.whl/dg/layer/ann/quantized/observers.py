import torch
import torch.nn as nn


class StaticObserver(nn.Module):
    """Observer with fixed scale and zero-point; pass-through during forward."""

    def __init__(self, scale=1.0, zero_point=0.0):
        super().__init__()
        self.register_buffer("scale", torch.tensor(scale))
        self.register_buffer("zero_point", torch.tensor(zero_point))

    def forward(self, x):
        return x


class ViewObserver(StaticObserver):
    """Proxy observer that forwards all reads to another observer.

    Used during layer stitching so a downstream layer can share its
    predecessor's output observer as its own input observer, without
    duplicating statistics tracking.
    """

    def __init__(self, observer):
        super().__init__()
        self.observer = observer

    @property
    def scale(self):
        return self.observer.scale

    @property
    def zero_point(self):
        return self.observer.zero_point

    @property
    def min_val(self):
        return self.observer.min_val

    @property
    def max_val(self):
        return self.observer.max_val

    def forward(self, x):
        return x


class MinMaxObserver(StaticObserver):
    """Tracks running min / max statistics for asymmetric int8 quantization.

    An exponential moving average smooths the tracked statistics over training
    steps; scale and zero-point are recomputed after each update.

    Args:
        averaging_constant: EMA smoothing factor.
        fix_zero: If ``True``, pin ``min = 0`` / ``zero_point = -128`` for
            non-negative (e.g. ReLU) outputs (Jacob et al. 2017).
    """

    def __init__(self, averaging_constant: float = 0.01, fix_zero: bool = False):
        super().__init__(scale=1.0, zero_point=-128.0 if fix_zero else 0.0)
        self.averaging_constant = averaging_constant
        self.fix_zero = fix_zero
        self.register_buffer("min_val", torch.tensor(0.0 if fix_zero else float("inf")))
        self.register_buffer("max_val", torch.tensor(float("-inf")))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.training and torch.is_grad_enabled():
            max_val = x.detach().max()

            if self.fix_zero:
                # For ReLU outputs: min is fixed at 0, only track max
                if self.max_val == float("-inf"):
                    self.max_val.copy_(max_val)
                else:
                    self.max_val.copy_(
                        self.max_val + self.averaging_constant * (max_val - self.max_val)
                    )
            else:
                min_val = x.detach().min()
                if self.min_val == float("inf"):
                    self.min_val.copy_(min_val)
                    self.max_val.copy_(max_val)
                else:
                    self.min_val.copy_(
                        self.min_val + self.averaging_constant * (min_val - self.min_val)
                    )
                    self.max_val.copy_(
                        self.max_val + self.averaging_constant * (max_val - self.max_val)
                    )

            self._compute_qparams()

        return x

    def _compute_qparams(self):
        min_val = self.min_val.item()
        max_val = self.max_val.item()

        if max_val == float("-inf") or not (max_val == max_val):
            self.scale.fill_(1.0)
            if not self.fix_zero:
                self.zero_point.fill_(0.0)
            return

        if self.fix_zero:
            # ReLU optimization: min=0, zp=-128. Maps [0, max] to [-128, 127].
            if max_val <= 0:
                self.scale.fill_(1.0)
                return
            scale = max_val / 255.0
            self.scale.fill_(scale)
        else:
            if min_val == max_val:
                self.scale.fill_(1.0)
                self.zero_point.fill_(0.0)
                return

            scale = (max_val - min_val) / 255.0
            if scale < 1e-10:
                self.scale.fill_(1.0)
                self.zero_point.fill_(0.0)
                return

            zp = round(-128 - min_val / scale)
            zp = max(-128, min(127, zp))

            self.scale.fill_(scale)
            self.zero_point.fill_(zp)
