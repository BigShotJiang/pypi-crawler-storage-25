import torch


class FakeQuantizeAsymmetric(torch.autograd.Function):
    """Asymmetric fake-quantize op with a straight-through estimator.

    Forward applies round-to-nearest quantization to int8 range, then
    dequantizes back to float. Backward passes gradients unchanged.
    """

    @staticmethod
    def forward(ctx, x: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
        x_q = torch.round(x / scale) + zero_point
        x_q = torch.clamp(x_q, -128, 127)
        x_dq = (x_q - zero_point) * scale
        return x_dq

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return grad_output, None, None


class FakeQuantizeSymmetric(torch.autograd.Function):
    """Per-channel symmetric fake-quantize op for weights.

    Uses a zero-centered int8 range ``[-127, 127]`` with no zero-point, and
    supports per-channel scales broadcast over the trailing dimensions.
    """

    @staticmethod
    def forward(ctx, x: torch.Tensor, scale: torch.Tensor) -> torch.Tensor:
        x_q = torch.round(x / scale)
        x_q = torch.clamp(x_q, -127, 127)
        x_dq = x_q * scale
        return x_dq

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor):
        return grad_output, None


def fake_quantize_asymmetric(x: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor):
    return FakeQuantizeAsymmetric.apply(x, scale, zero_point)


def fake_quantize_symmetric(x: torch.Tensor, scale: torch.Tensor):
    return FakeQuantizeSymmetric.apply(x, scale)


def _identity_quant_op(x: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
    return x


def dequantize(x: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
    """Dequantize int8 to float: ``(x - zero_point) * scale``."""
    return (x - zero_point) * scale


def quantize(x: torch.Tensor, scale: torch.Tensor, zero_point: torch.Tensor) -> torch.Tensor:
    """Quantize float to int8 range: ``clamp(round(x / scale) + zero_point)``."""
    x_q = torch.round(x / scale) + zero_point
    return torch.clamp(x_q, -128, 127)
