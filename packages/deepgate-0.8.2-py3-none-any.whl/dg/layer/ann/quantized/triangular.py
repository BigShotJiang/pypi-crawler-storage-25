import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Any

from dg.layer.spec_utils import scalar_spec, tensor_spec

from .base import QuantBase
from .fake_quant import fake_quantize_symmetric, fake_quantize_asymmetric


def _init_quant_triu_weight(weight: torch.Tensor, in_features: int) -> None:
    nn.init.kaiming_uniform_(weight, a=math.sqrt(5))
    with torch.no_grad():
        out_features = weight.shape[0]
        start = max(0, out_features - in_features)
        weight[start:].triu_()


def _init_quant_tril_weight(weight: torch.Tensor, in_features: int) -> None:
    nn.init.kaiming_uniform_(weight, a=math.sqrt(5))
    with torch.no_grad():
        out_features = weight.shape[0]
        bottom = min(out_features, in_features)
        diagonal = in_features - bottom
        weight[:bottom].tril_(diagonal)


def _make_quant_triu_mask(out_features: int, in_features: int, device: str) -> torch.Tensor:
    mask = torch.ones(out_features, in_features, device=device)
    start = max(0, out_features - in_features)
    mask[start:] = torch.triu(mask[start:])
    return mask


def _make_quant_tril_mask(out_features: int, in_features: int, device: str) -> torch.Tensor:
    mask = torch.ones(out_features, in_features, device=device)
    bottom = min(out_features, in_features)
    diagonal = in_features - bottom
    mask[:bottom] = torch.tril(mask[:bottom], diagonal)
    return mask


def _specs_for_masked_linear(layer: "QuantBase", masked_weight: torch.Tensor) -> dict[str, Any]:
    """Shared spec exporter for masked triangular layers. Masked-out
    entries are exported as int8 zeros."""
    weight = masked_weight.detach().cpu()
    bias = layer.bias.detach().cpu() if layer.bias is not None else None
    input_scale = layer.input_scale.item()
    output_scale = layer.output_observer.scale.item()
    weight_scales = layer._compute_weight_scales(weight)

    weights_int8 = layer._quantize_weights_int8(weight, weight_scales)
    bias_int32 = layer._quantize_bias_int32(bias, input_scale, weight_scales)
    requant_mult, requant_shift = layer._compute_requant_params(
        layer.out_features, input_scale, weight_scales, output_scale
    )

    return {
        "act_func": layer.act_func,
        "weights_int8": tensor_spec(weights_int8),
        "weight_scales": tensor_spec(weight_scales),
        "bias_int32": tensor_spec(bias_int32) if bias_int32 is not None else None,
        "input_scale": scalar_spec(input_scale, "float32"),
        "input_zp": scalar_spec(int(layer.input_zp.item()), "int32"),
        "input_no_quant": layer.input_no_quant,
        "output_scale": scalar_spec(output_scale, "float32"),
        "output_zp": scalar_spec(int(layer.output_observer.zero_point.item()), "int32"),
        "requant_multiplier": tensor_spec(requant_mult),
        "requant_shift": tensor_spec(requant_shift),
    }


class QuantUpperTriangularLinear(QuantBase):
    """Quantized :class:`UpperTriangularLinear`.

    * ``out <= in``: top ``out`` rows of the ``in x in`` upper-triangular
      matrix.
    * ``out > in``: leading ``out - in`` rows are fully dense; trailing
      ``in`` rows form a square upper-triangular block.

    Fake-quantization is applied to ``weight * mask``, so masked-out entries
    remain exactly zero through quantization.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias.
        act_func: Either ``"relu"`` or ``None``.
        ema_constant: EMA smoothing factor for observers.
        device: Torch device for the parameters.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        act_func: str | None = None,
        ema_constant: float = 0.01,
        device: str = "cpu",
        input_quant_op=fake_quantize_asymmetric,
        output_quant_op=fake_quantize_asymmetric,
    ):
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            fix_output_zero=(act_func == "relu"),
            ema_constant=ema_constant,
        )
        assert act_func in [None, "relu"]

        self.in_features = in_features
        self.out_features = out_features
        self.act_func = act_func

        self.weight = nn.Parameter(torch.empty(out_features, in_features, device=device))
        _init_quant_triu_weight(self.weight, in_features)
        self.register_buffer("mask", _make_quant_triu_mask(out_features, in_features, device))
        self.bias = nn.Parameter(torch.zeros(out_features, device=device)) if bias else None

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.shape[-1] == self.in_features
        assert x.dim() == 2

        masked = self.weight * self.mask
        weight_scales = self._compute_weight_scales(masked)
        weight_q = fake_quantize_symmetric(masked, weight_scales.unsqueeze(1))

        x = F.linear(x, weight_q, self.bias)

        if self.act_func == "relu":
            x = F.relu(x)

        return x

    def get_module_specs(self) -> dict[str, Any]:
        return _specs_for_masked_linear(self, self.weight * self.mask)


class QuantLowerTriangularLinear(QuantBase):
    """Quantized :class:`LowerTriangularLinear`.

    * ``out <= in``: bottom ``out`` rows of the ``in x in`` lower-triangular
      matrix (block flush against the right edge of the weight matrix).
    * ``out > in``: leading ``in`` rows form a square lower-triangular
      block; trailing ``out - in`` rows are fully dense.

    Fake-quantization is applied to ``weight * mask``, so masked-out entries
    remain exactly zero through quantization.

    Args:
        in_features: Number of input features.
        out_features: Number of output features.
        bias: Whether to include an additive bias.
        act_func: Either ``"relu"`` or ``None``.
        ema_constant: EMA smoothing factor for observers.
        device: Torch device for the parameters.
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
        act_func: str | None = None,
        ema_constant: float = 0.01,
        device: str = "cpu",
        input_quant_op=fake_quantize_asymmetric,
        output_quant_op=fake_quantize_asymmetric,
    ):
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            fix_output_zero=(act_func == "relu"),
            ema_constant=ema_constant,
        )
        assert act_func in [None, "relu"]

        self.in_features = in_features
        self.out_features = out_features
        self.act_func = act_func

        self.weight = nn.Parameter(torch.empty(out_features, in_features, device=device))
        _init_quant_tril_weight(self.weight, in_features)
        self.register_buffer("mask", _make_quant_tril_mask(out_features, in_features, device))
        self.bias = nn.Parameter(torch.zeros(out_features, device=device)) if bias else None

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        assert x.shape[-1] == self.in_features
        assert x.dim() == 2

        masked = self.weight * self.mask
        weight_scales = self._compute_weight_scales(masked)
        weight_q = fake_quantize_symmetric(masked, weight_scales.unsqueeze(1))

        x = F.linear(x, weight_q, self.bias)

        if self.act_func == "relu":
            x = F.relu(x)

        return x

    def get_module_specs(self) -> dict[str, Any]:
        return _specs_for_masked_linear(self, self.weight * self.mask)
