def compute_requant_multiplier_shift(M: float) -> tuple[int, int]:
    """Convert a float requantization multiplier to fixed-point ``(M0, shift)``.

    The returned pair satisfies ``M ≈ (M0 / 2**31) * 2**(-shift)``, matching
    the fixed-point requantization formula used on the compiler side.
    ``shift`` may be negative when ``M >= 1`` (i.e. a left shift).
    """
    if M == 0:
        return 0, 0

    shift = 0
    while M < 0.5:
        M *= 2
        shift += 1
    while M >= 1.0:
        M /= 2
        shift -= 1

    M0 = int(round(M * (1 << 31)))

    M0 = min(M0, (1 << 31) - 1)

    return M0, shift
