import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Any

from dg.layer.spec_utils import scalar_spec

from .base import QuantBase
from .observers import MinMaxObserver
from .fake_quant import fake_quantize_asymmetric
from .utils import compute_requant_multiplier_shift


class QuantResidualAdd(QuantBase):
    """Quantized residual block with two parallel layer streams.

    The input flows through two parallel paths (``layers_a`` and
    ``layers_b``), whose outputs are added element-wise. An optional ReLU
    activation and output fake-quantization are applied after the add. An
    empty ``layers_b`` means the skip path is the identity.

    Args:
        layers_a: Quantized layers for stream A (main path).
        layers_b: Quantized layers for stream B (empty = identity skip).
        act_func: Either ``"relu"`` or ``None``.
        ema_constant: EMA smoothing factor for the output observer.
    """

    def __init__(
        self,
        layers_a: list,
        layers_b: list,
        act_func: str | None = None,
        ema_constant: float = 0.01,
        input_quant_op=fake_quantize_asymmetric,
        output_quant_op=fake_quantize_asymmetric,
    ):
        assert act_func in [None, "relu"], f"act_func must be None or 'relu', got {act_func}"
        super().__init__(
            input_quant_op=input_quant_op,
            output_quant_op=output_quant_op,
            fix_output_zero=(act_func == "relu"),
            ema_constant=ema_constant,
        )

        self.layers_a = nn.ModuleList(layers_a)
        self.layers_b = nn.ModuleList(layers_b)
        self.act_func = act_func

    @property
    def input_observer_a(self) -> MinMaxObserver:
        if len(self.layers_a) == 0:
            raise ValueError("layers_a is empty")
        return self.layers_a[-1].output_observer

    @property
    def input_observer_b(self) -> MinMaxObserver:
        # Empty layers_b means identity skip — reuse the block's input observer,
        # which has been stitched to the previous layer's output observer.
        if len(self.layers_b) == 0:
            return self.input_observer
        return self.layers_b[-1].output_observer

    @property
    def input_scale_a(self) -> torch.Tensor:
        return self.input_observer_a.scale

    @property
    def input_zp_a(self) -> torch.Tensor:
        return self.input_observer_a.zero_point

    @property
    def input_scale_b(self) -> torch.Tensor:
        return self.input_observer_b.scale

    @property
    def input_zp_b(self) -> torch.Tensor:
        return self.input_observer_b.zero_point

    def _quant_forward(self, x: torch.Tensor) -> torch.Tensor:
        a = x
        for layer in self.layers_a:
            a = layer(a)

        b = x
        for layer in self.layers_b:
            b = layer(b)

        y = a + b
        if self.act_func == "relu":
            y = F.relu(y)

        return y

    def get_module_specs(self) -> dict[str, Any]:
        output_scale = self.output_observer.scale.item()
        output_zp = int(self.output_observer.zero_point.item())

        stream_a_specs = [layer.get_compiler_specs() for layer in self.layers_a]
        stream_b_specs = [layer.get_compiler_specs() for layer in self.layers_b]

        # Per-stream fixed-point requantization: M = s_in / s_out
        M_a = self.input_scale_a.item() / output_scale
        M_b = self.input_scale_b.item() / output_scale

        requant_multiplier_a, requant_shift_a = compute_requant_multiplier_shift(M_a)
        requant_multiplier_b, requant_shift_b = compute_requant_multiplier_shift(M_b)

        return {
            "stream_a_specs": stream_a_specs,
            "stream_b_specs": stream_b_specs,
            "act_func": self.act_func,
            "input_scale_a": scalar_spec(self.input_scale_a.item(), "float32"),
            "input_zp_a": scalar_spec(int(self.input_zp_a.item()), "int32"),
            "input_scale_b": scalar_spec(self.input_scale_b.item(), "float32"),
            "input_zp_b": scalar_spec(int(self.input_zp_b.item()), "int32"),
            "output_scale": scalar_spec(output_scale, "float32"),
            "output_zp": scalar_spec(output_zp, "int32"),
            "requant_multiplier_a": scalar_spec(requant_multiplier_a, "int32"),
            "requant_shift_a": scalar_spec(requant_shift_a, "int32"),
            "requant_multiplier_b": scalar_spec(requant_multiplier_b, "int32"),
            "requant_shift_b": scalar_spec(requant_shift_b, "int32"),
        }

    def build_testcase_outputs(self, x: torch.Tensor) -> tuple[torch.Tensor, list[dict]]:
        """Capture every sub-layer output plus the final combined output."""
        entries = []
        base_name = self.__class__.__name__

        a = x
        for i, layer in enumerate(self.layers_a):
            a = layer(a)
            name = f"{base_name}/stream_a/{layer.__class__.__name__}_{i}"
            entries.append(layer._build_testcase_entry(a, layer_name=name))

        b = x
        for i, layer in enumerate(self.layers_b):
            b = layer(b)
            name = f"{base_name}/stream_b/{layer.__class__.__name__}_{i}"
            entries.append(layer._build_testcase_entry(b, layer_name=name))

        y = a + b
        if self.act_func == "relu":
            y = F.relu(y)
        y = self.output_observer(y)
        y = self.output_quant_op(y, self.output_observer.scale, self.output_observer.zero_point)

        entries.append(self._build_testcase_entry(y))
        return y, entries
