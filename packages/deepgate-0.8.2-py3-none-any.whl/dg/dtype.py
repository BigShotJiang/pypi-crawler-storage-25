"""Centralized dtype definitions for the DLG framework.

This module provides:
1. Canonical dtype string constants (DType class)
2. Bidirectional torch.dtype <-> string conversion
"""

import torch


class DType:
    """Dtypes actively used in the codebase."""
    UINT8 = "uint8"      # Raw image inputs
    UINT32 = "uint32"    # Bit-packed integers (LUT weights, testcase export)
    BIT = "bit"          # Individual binary bits (logic layer activations)
    BP32 = "bp32"
    INT8 = "int8"        # Quantized layer activations
    INT32 = "int32"      # Quantized bias
    INT64 = "int64"      # LUT weights (bit-packed base-10)
    FLOAT32 = "float32"  # ANN layer activations


_TORCH_TO_STR = {
    torch.uint8: DType.UINT8,
    torch.int8: DType.INT8,
    torch.int32: DType.INT32,
    torch.int64: DType.INT64,
    torch.float32: DType.FLOAT32,
}

_STR_TO_TORCH = {v: k for k, v in _TORCH_TO_STR.items()}
_STR_TO_TORCH[DType.UINT32] = torch.int32  # uint32 uses int32 in PyTorch (no native uint32)


def torch_to_str(dtype: torch.dtype) -> str:
    """Convert torch.dtype to canonical string."""
    return _TORCH_TO_STR[dtype]


def str_to_torch(dtype_str: str) -> torch.dtype:
    """Convert dtype string to torch.dtype."""
    return _STR_TO_TORCH[dtype_str]
