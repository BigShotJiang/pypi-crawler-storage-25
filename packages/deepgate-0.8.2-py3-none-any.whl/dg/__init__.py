__version__ = "0.8.0"  # x-release-please-version
from dg.hub import from_pretrained
from dg.train import freeze_backbone, Trainer as Train
from dg import eval, train
