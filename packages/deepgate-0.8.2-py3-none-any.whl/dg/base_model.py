import json
import shutil
import inspect
from pathlib import Path

import torch
import torch.nn as nn
from dg import __version__
from dg.dtype import DType
from dg.layer.base import BaseModule


class DLGModel(nn.Module):
    """Base class for DLG models.

    Subclasses override :meth:`build_model_graph` to return the list of layers
    that make up the model. The layers are wired into a
    :class:`torch.nn.Sequential` and dtypes / quantization observers are
    stitched between consecutive layers automatically.

    Subclass ``__init__`` parameters must all be named keywords with default
    values (no ``*args`` / ``**kwargs``) so they can be captured as
    ``self.config`` and round-tripped by :meth:`save_pretrained` /
    :func:`dg.hub.from_pretrained`.
    """

    def __init__(self):
        super().__init__()
        self.training_input_shape = None
        self.model_graph = None
        if not hasattr(self, 'config'):
            self.config = {}
        if not getattr(self, '_dlg_init_in_progress', False):
            self.post_init()

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if '__init__' in cls.__dict__:
            original_init = cls.__init__
            sig = inspect.signature(original_init)

            for name, param in list(sig.parameters.items())[1:]:
                if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                    raise TypeError(f"{cls.__name__}.__init__ must not use *args or **kwargs.")
                if param.default is inspect.Parameter.empty:
                    raise TypeError(f"{cls.__name__}.__init__ parameter '{name}' must have a default value.")

            def wrapped_init(self, *args, **kwargs):
                is_outermost = not getattr(self, '_dlg_init_in_progress', False)
                if is_outermost:
                    self._dlg_init_in_progress = True
                    bound = sig.bind(self, *args, **kwargs)
                    bound.apply_defaults()
                    self.config = {k: v for k, v in bound.arguments.items() if k != "self"}

                original_init(self, *args, **kwargs)
                if is_outermost:
                    self._dlg_init_in_progress = False
                    self.post_init()

            cls.__init__ = wrapped_init

    def build_model_graph(self):
        """Return the ordered list of layers that form the model.

        Subclasses must override this method.
        """
        raise NotImplementedError("Subclasses must implement build_model_graph()")

    def post_init(self):
        """Build :attr:`model_graph` from :meth:`build_model_graph` and wire layers.

        Called automatically once the outermost subclass ``__init__`` finishes.
        """
        model_graph = self.build_model_graph()
        assert isinstance(model_graph, list), "build_model_graph must return a list"
        self.model_graph = nn.Sequential(*model_graph)

        if len(self.model_graph) == 0:
            return

        input_dtype = self.model_graph[0].dtype_in or DType.UINT8
        self._process_layer_sequence(self.model_graph, None, input_dtype)

    def _process_layer_sequence(self, layers, prev_quant_layer, prev_dtype, ctx=""):
        prev_layer = None
        for idx, layer in enumerate(layers):
            name = f"{ctx}[{idx}]" if ctx else f"Layer {idx}"
            name = f"{name} ({layer.__class__.__name__})"
            if not isinstance(layer, BaseModule):
                raise TypeError(f"{name} does not extend BaseModule.")

            had_dynamic_dtype = layer.has_dynamic_dtype  # Check before propagation sets it

            self._stitch_quant(layer, prev_quant_layer, prev_dtype)
            self._propagate_dtype(layer, prev_dtype, prev_layer, name)

            prev_quant_layer = layer if hasattr(layer, 'output_observer') else (prev_quant_layer if had_dynamic_dtype else None)
            prev_dtype = layer.dtype_out
            prev_layer = layer

    def _stitch_quant(self, layer, prev_quant_layer, prev_dtype):
        if not hasattr(layer, 'input_observer'):
            return

        if prev_quant_layer and hasattr(prev_quant_layer, 'output_observer'):
            from dg.layer.ann.quantized.observers import ViewObserver
            from dg.layer.ann.quantized.fake_quant import _identity_quant_op

            layer.stitch_input(ViewObserver(prev_quant_layer.output_observer))
            layer.input_quant_op = _identity_quant_op

        if hasattr(layer, 'layers_a'):
            for name, stream in [("layers_a", layer.layers_a), ("layers_b", layer.layers_b)]:
                self._process_layer_sequence(stream, prev_quant_layer, prev_dtype, f"{layer.__class__.__name__}.{name}")

    def _propagate_dtype(self, layer, prev_dtype, prev_layer, name):
        if layer.dtype_in is None:
            layer.dtype_in = prev_dtype
        elif prev_dtype and prev_dtype != layer.dtype_in:
            src = prev_layer.__class__.__name__ if prev_layer else "input"
            raise ValueError(f"Dtype mismatch at {name}: expected '{layer.dtype_in}', got '{prev_dtype}' from {src}")
        if layer.dtype_out is None:
            layer.dtype_out = layer.dtype_in

    def forward(self, x):
        if self.training_input_shape is None:
            self.training_input_shape = tuple(x.shape[1:])
        return self.model_graph(x)

    def to_schema(self):
        """Export the model graph as a compiler-ready schema dictionary.

        Raises:
            ValueError: If :meth:`forward` has not been run yet (layer shapes
                are recorded on the first forward pass).
        """
        if self.training_input_shape is None:
            raise ValueError("Run forward pass first to capture layer shapes.")
        return {
            "dg_version": __version__,
            "model_graph": [m.get_compiler_specs() for m in self.model_graph],
        }

    def save_pretrained(self, path):
        """Serialize weights, source, config, and optional schema to ``path``.

        Writes ``model.pt`` (state dict), ``model.py`` (this class's source
        file), ``config.json`` (constructor kwargs) and, when a forward pass
        has already been run, ``schema.json``. The saved directory is
        round-tripped through :func:`dg.hub.from_pretrained` to validate that
        ``model.py`` is self-contained.

        Args:
            path (str | Path): Destination directory. Created if missing.

        Raises:
            RuntimeError: If the round-trip load fails. The destination
                directory is removed before re-raising.
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)

        torch.save(self.state_dict(), path / "model.pt")

        if hasattr(self, '_pretrained_path') and (Path(self._pretrained_path) / "model.py").exists():
            source_file = Path(self._pretrained_path) / "model.py"
        else:
            source_file = Path(inspect.getfile(self.__class__))

        shutil.copy2(source_file, path / "model.py")

        (path / "config.json").write_text(json.dumps(self.config))

        if self.training_input_shape is not None:
            (path / "schema.json").write_text(json.dumps(self.to_schema()))

        from dg.hub import from_pretrained
        try:
            from_pretrained(str(path), device="cpu")
        except Exception as e:
            shutil.rmtree(path)
            raise RuntimeError(
                f"save_pretrained validation failed — model.py could not be loaded. "
                f"Ensure model.py is self-contained and only imports from dg. "
                f"Error: {e}"
            ) from e
