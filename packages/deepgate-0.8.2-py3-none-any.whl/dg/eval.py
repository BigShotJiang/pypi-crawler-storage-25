import torch


def _accuracy_metric(output, target):
    _, predictions = torch.max(output, 1)
    return (predictions == target).sum().cpu().item()


def get_acc(model, dataset, batch_size=128, device="cuda"):
    model.eval()
    scores = compute_metric(
        model, dataset, _accuracy_metric, batch_size=batch_size, device=device
    )
    model.train()
    return torch.sum(torch.Tensor(scores)) / len(dataset)


def compute_metric(model, dataset, metric, batch_size=128, device="cuda", **kwargs):
    metric_list = []
    data_loader = torch.utils.data.DataLoader(dataset, batch_size)
    model.to(device)

    with torch.no_grad():
        for data, target in data_loader:
            data = data.to(device)
            target = target.to(device)
            output = model(data, **kwargs) if kwargs else model(data)
            metric_list.append(metric(output, target))

    return metric_list
