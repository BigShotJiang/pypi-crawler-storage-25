from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

VERSION = '1.0.0'
DESCRIPTION = 'Implementation of TOPSIS - Technique for Order of Preference by Similarity to Ideal Solution'

setup(
    name="Topsis-Shweta-2004",
    version=VERSION,
    author="Shweta",
    author_email="your-email@example.com",
    license='MIT License',
    description=DESCRIPTION,
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=['pandas', 'numpy'],
    project_urls={
        'Project Link': 'https://github.com/your-username/Topsis-Shweta-2004'
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Programming Language :: Python :: 3",
    ]
)
