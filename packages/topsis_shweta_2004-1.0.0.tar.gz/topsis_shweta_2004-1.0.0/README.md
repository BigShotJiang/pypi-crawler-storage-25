# Topsis-Shweta-2004

**TOPSIS** (Technique for Order of Preference by Similarity to Ideal Solution) is a multi-criteria decision-making method. This package implements TOPSIS in Python — it takes a decision matrix CSV, weights, and impacts, then returns a ranked result.

## Installation

```bash
pip install Topsis-Shweta-2004
```

## Usage

### In Python:

```python
from Topsis_Shweta_2004.topsis import topsis

topsis("data.csv", "1,1,1,2,1", "+,+,-,+,-", "result.csv")
```

### Via Command Line:

```bash
python -m Topsis_Shweta_2004.topsis input.csv "1,1,1,2" "+,+,-,+" output.csv
```

### Parameters:
| Parameter | Description |
|-----------|-------------|
| `input`   | Path to input CSV file |
| `weights` | Comma-separated weights e.g. `"1,1,2,1"` |
| `impacts` | Comma-separated impacts e.g. `"+,+,-,+"` |
| `result`  | Output CSV filename |

## Input Format

First column = object/alternative name. Remaining columns = numeric criteria.

| Fund Name | P1   | P2   | P3  | P4   | P5    |
|-----------|------|------|-----|------|-------|
| M1        | 0.62 | 0.38 | 6.7 | 58.7 | 16.60 |
| M2        | 0.93 | 0.86 | 5.5 | 47.9 | 13.80 |
| M3        | 0.62 | 0.38 | 3.2 | 65.9 | 17.53 |

## Output Format

Same as input with two additional columns: `Topsis Score` and `Rank`.

| Fund Name | P1   | P2   | P3  | P4   | P5    | Topsis Score | Rank |
|-----------|------|------|-----|------|-------|--------------|------|
| M1        | 0.62 | 0.38 | 6.7 | 58.7 | 16.60 | 0.3876       | 8.0  |
| M2        | 0.93 | 0.86 | 5.5 | 47.9 | 13.80 | 0.5213       | 4.0  |

## How TOPSIS Works

1. **Normalize** the decision matrix
2. **Apply weights** to each criterion
3. **Find Ideal Best & Worst** solutions
4. **Calculate distance** from ideal best and worst
5. **Rank** alternatives by closeness to ideal solution

## Error Handling

- File not found → clear error message
- Mismatched weights/impacts/columns → ValueError
- Non-numeric values in criteria columns → ValueError

## Requirements

- Python 3
- pandas
- numpy

## License

(c) 2024 Shweta — MIT License
