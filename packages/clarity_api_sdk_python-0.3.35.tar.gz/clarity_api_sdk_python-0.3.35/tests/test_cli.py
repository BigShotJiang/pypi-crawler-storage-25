"""Tests for the ftm CLI commands: init, list, upload, process, status."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch
from uuid import UUID

import pytest
from typer.testing import CliRunner

from cti.cli.main import app
from cti.model.device import Device
from cti.model.device_type import DeviceType
from cti.model.organization import Organization
from cti.model.platform import Platform
from cti.model.platform_type import PlatformType
from cti.model.processing_job import ProcessingJob, ProcessingJobList, ProcessingJobSummary
from cti.model.project import Project
from cti.model.raw_file import RawFile
from cti.model.raw_file_state import RawFileState
from cti.model.survey import Survey

from .conftest import (
    CONFIG_ID,
    JOB_ID,
    NOW,
    RAW_FILE_ID,
    SURVEY_ID,
    make_job_json,
    make_job_list_json,
    make_job_summary_json,
    make_raw_file_json,
)

ORG_ID = UUID("00000000-0000-0000-0000-000000000010")
PROJECT_ID = UUID("00000000-0000-0000-0000-000000000011")
PLATFORM_ID = UUID("00000000-0000-0000-0000-000000000012")
PLATFORM_TYPE_ID = UUID("00000000-0000-0000-0000-000000000013")
SS_DEVICE_ID = UUID("00000000-0000-0000-0000-000000000014")
GNSS_DEVICE_ID = UUID("00000000-0000-0000-0000-000000000015")
SS_DEVICE_TYPE_ID = UUID("00000000-0000-0000-0000-000000000016")
GNSS_DEVICE_TYPE_ID = UUID("00000000-0000-0000-0000-000000000017")

runner = CliRunner()


def _make_raw_file_model() -> RawFile:
    return RawFile.model_validate(make_raw_file_json(state="ready"))


def _make_job_model(status: str = "pending", **kwargs) -> ProcessingJob:
    return ProcessingJob.model_validate(make_job_json(status=status, **kwargs))


def _make_job_list_model() -> ProcessingJobList:
    return ProcessingJobList.model_validate(make_job_list_json())


class TestUploadCommand:
    """Tests for `ftm upload`."""

    def test_upload_success(self, tmp_path: Path):
        """upload prints raw_file_id and state on success."""
        test_file = tmp_path / "test.xtf"
        test_file.write_bytes(b"data")

        mock_api = MagicMock()
        mock_api.upload_file.return_value = _make_raw_file_model()

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "upload", str(test_file), "--survey", str(SURVEY_ID),
            ])

        assert result.exit_code == 0
        assert str(RAW_FILE_ID) in result.output
        assert "ready" in result.output

    def test_upload_file_not_found(self, tmp_path: Path):
        """upload exits with error when file does not exist."""
        result = runner.invoke(app, [
            "upload", str(tmp_path / "missing.xtf"), "--survey", str(SURVEY_ID),
        ])

        assert result.exit_code == 1
        assert "not found" in result.output

    def test_upload_json_output(self, tmp_path: Path):
        """upload --json outputs valid JSON."""
        test_file = tmp_path / "test.xtf"
        test_file.write_bytes(b"data")

        mock_api = MagicMock()
        mock_api.upload_file.return_value = _make_raw_file_model()

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "upload", str(test_file), "--survey", str(SURVEY_ID),
                "--json", "--no-mappings",
            ])

        assert result.exit_code == 0
        # JSON output is after progress messages
        lines = result.output.strip().split("\n")
        json_start = next(i for i, l in enumerate(lines) if l.strip().startswith("{"))
        data = json.loads("\n".join(lines[json_start:]))
        assert data["raw_file_id"] == str(RAW_FILE_ID)


class TestProcessCommand:
    """Tests for `ftm process`."""

    def test_process_no_wait(self):
        """process without --wait prints job info and exits."""
        mock_api = MagicMock()
        mock_api.trigger_processing.return_value = _make_job_model(status="pending")

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "process", str(SURVEY_ID),
            ])

        assert result.exit_code == 0
        assert str(JOB_ID) in result.output
        assert "pending" in result.output
        mock_api.wait_for_job.assert_not_called()

    def test_process_with_wait_completed(self):
        """process --wait polls and prints completed status."""
        mock_api = MagicMock()
        mock_api.trigger_processing.return_value = _make_job_model(status="pending")
        mock_api.wait_for_job.return_value = _make_job_model(status="completed", progress=1.0)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "process", str(SURVEY_ID), "--wait",
            ])

        assert result.exit_code == 0
        assert "completed" in result.output
        mock_api.wait_for_job.assert_called_once()

    def test_process_with_wait_failed(self):
        """process --wait exits 1 when job fails."""
        mock_api = MagicMock()
        mock_api.trigger_processing.return_value = _make_job_model(status="pending")
        mock_api.wait_for_job.return_value = _make_job_model(
            status="failed", error="engine crashed"
        )

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "process", str(SURVEY_ID), "--wait",
            ])

        assert result.exit_code == 1
        assert "engine crashed" in result.output

    def test_process_with_wait_timeout(self):
        """process --wait exits 1 on timeout."""
        mock_api = MagicMock()
        mock_api.trigger_processing.return_value = _make_job_model(status="pending")
        mock_api.wait_for_job.side_effect = TimeoutError("timed out")

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "process", str(SURVEY_ID), "--wait", "--timeout", "10",
            ])

        assert result.exit_code == 1
        assert "timed out" in result.output


def _setup_status_mocks(mock_api: MagicMock, job_list=None, file_count: int = 1, product_count: int = 2) -> None:
    """Configure common mocks for status tests."""
    mock_api.get_raw_files.return_value = [MagicMock()] * file_count
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = [{}] * product_count
    mock_api._client.get.return_value = mock_response
    mock_api.list_jobs.return_value = job_list if job_list else _make_job_list_model()


class TestStatusCommand:
    """Tests for `ftm status`."""

    def test_status_shows_latest_job(self):
        """status prints job details, file count, and product count."""
        mock_api = MagicMock()
        _setup_status_mocks(mock_api, file_count=3, product_count=5)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "status", str(SURVEY_ID),
            ])

        assert result.exit_code == 0
        assert str(JOB_ID) in result.output
        assert "completed" in result.output
        assert "3" in result.output  # file count
        assert "5" in result.output  # product count

    def test_status_json_output(self):
        """status --json outputs valid JSON with files and products."""
        mock_api = MagicMock()
        _setup_status_mocks(mock_api, file_count=2, product_count=4)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["status", str(SURVEY_ID), "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["job_id"] == str(JOB_ID)
        assert data["status"] == "completed"
        assert data["files"] == 2
        assert data["products"] == 4

    def test_status_no_jobs(self):
        """status shows file/product counts even with no jobs."""
        mock_api = MagicMock()
        _setup_status_mocks(
            mock_api,
            job_list=ProcessingJobList(jobs=[], total=0, limit=50, offset=0),
            file_count=1,
            product_count=0,
        )

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["status", str(SURVEY_ID), "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["latest_job"] == "none"
        assert data["files"] == 1


def _make_org(name: str = "Test Org", org_id: UUID = ORG_ID) -> Organization:
    return Organization(
        organization_id=org_id, name=name, created_date=NOW, updated_date=NOW
    )


def _make_project(name: str = "Test Project", project_id: UUID = PROJECT_ID) -> Project:
    return Project(
        project_id=project_id, organization_id=ORG_ID, project_name=name,
        project_description="", created_date=NOW, updated_date=NOW, updated_by="test",
    )


def _make_survey(name: str = "Test Survey", survey_id: UUID = SURVEY_ID) -> Survey:
    return Survey(
        survey_id=survey_id, project_id=PROJECT_ID, name=name, description=None,
        geodesy_srid="EPSG:32620", timezone_name="Etc/UTC",
        created_date=NOW, updated_date=NOW, updated_by="test",
    )


def _make_platform_type() -> PlatformType:
    return PlatformType(platform_type_id=PLATFORM_TYPE_ID, name="Towed Body", description="A towed sensor")


def _make_platform() -> Platform:
    return Platform(
        platform_id=PLATFORM_ID, survey_id=SURVEY_ID,
        platform_type_id=PLATFORM_TYPE_ID, name="Platform",
    )


def _make_device_types() -> list[DeviceType]:
    return [
        DeviceType(device_type_id=SS_DEVICE_TYPE_ID, name="Sidescan Sonar", enum_name="sidescan_sonar", can_parent=False, updated_by="test", updated_date=NOW, created_date=NOW),
        DeviceType(device_type_id=GNSS_DEVICE_TYPE_ID, name="GNSS", enum_name="gnss_gps_position_sensor", can_parent=False, updated_by="test", updated_date=NOW, created_date=NOW),
    ]


def _make_device(name: str = "Sidescan", device_id: UUID = SS_DEVICE_ID, device_type_id: UUID = SS_DEVICE_TYPE_ID, is_towed: bool = True) -> Device:
    return Device(
        device_id=device_id, platform_id=PLATFORM_ID, device_type_id=device_type_id,
        name=name, channel=0, offset_x=0, offset_y=0, offset_z=0,
        offset_heading=0, offset_pitch=0, offset_roll=0, latency=0, is_towed=is_towed,
        updated_by="test", updated_date=NOW, created_date=NOW,
    )


def _setup_init_mocks(mock_api: MagicMock, org_exists: bool = False) -> None:
    """Configure common mocks for init tests."""
    if org_exists:
        mock_api.list_organizations.return_value = [_make_org(name="Default Organization")]
    else:
        mock_api.list_organizations.return_value = []
        mock_api.create_organization.return_value = _make_org()
    mock_api.create_project.return_value = _make_project()
    mock_api.create_survey.return_value = _make_survey()
    mock_api.list_platform_types.return_value = [_make_platform_type()]
    mock_api.create_platform.return_value = _make_platform()
    mock_api.list_device_types.return_value = _make_device_types()
    mock_api.create_device.side_effect = [
        _make_device("Sidescan", SS_DEVICE_ID, SS_DEVICE_TYPE_ID, True),
        _make_device("GNSS", GNSS_DEVICE_ID, GNSS_DEVICE_TYPE_ID, False),
    ]


class TestInitCommand:
    """Tests for `ftm init`."""

    def test_init_creates_full_hierarchy(self):
        """init creates org, project, survey, platform, and devices."""
        mock_api = MagicMock()
        _setup_init_mocks(mock_api, org_exists=False)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "init", "--project", "Test Project", "--srid", "EPSG:32620",
            ])

        assert result.exit_code == 0
        assert str(SURVEY_ID) in result.output
        assert "Created organization" in result.output
        assert "Created project" in result.output
        assert "Created survey" in result.output
        assert "Created platform" in result.output
        assert "Created device: Sidescan" in result.output
        assert "Created device: GNSS" in result.output
        mock_api.create_organization.assert_called_once()
        mock_api.create_project.assert_called_once()
        mock_api.create_survey.assert_called_once()
        mock_api.create_platform.assert_called_once()
        assert mock_api.create_device.call_count == 2

    def test_init_reuses_existing_org(self):
        """init finds an existing org by name instead of creating one."""
        mock_api = MagicMock()
        _setup_init_mocks(mock_api, org_exists=True)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "init", "--project", "Test", "--srid", "EPSG:32620",
            ])

        assert result.exit_code == 0
        assert "Using organization" in result.output
        mock_api.create_organization.assert_not_called()

    def test_init_json_output(self):
        """init --json outputs valid JSON with all IDs."""
        mock_api = MagicMock()
        _setup_init_mocks(mock_api, org_exists=True)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "init", "--project", "Test", "--srid", "EPSG:32620", "--json",
            ])

        assert result.exit_code == 0
        lines = result.output.strip().split("\n")
        json_start = next(i for i, l in enumerate(lines) if l.strip().startswith("{"))
        data = json.loads("\n".join(lines[json_start:]))
        assert data["survey_id"] == str(SURVEY_ID)
        assert data["project_id"] == str(PROJECT_ID)
        assert data["organization_id"] == str(ORG_ID)
        assert data["platform_id"] == str(PLATFORM_ID)
        assert data["sidescan_device_id"] == str(SS_DEVICE_ID)
        assert data["gnss_device_id"] == str(GNSS_DEVICE_ID)

    def test_init_custom_survey_name(self):
        """init --survey uses a custom survey name."""
        mock_api = MagicMock()
        _setup_init_mocks(mock_api, org_exists=True)

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, [
                "init", "--project", "Test", "--srid", "EPSG:32620",
                "--survey", "Line 1",
            ])

        assert result.exit_code == 0
        call_args = mock_api.create_survey.call_args[0][0]
        assert call_args.name == "Line 1"


class TestListSurveysCommand:
    """Tests for `ftm list surveys`."""

    def test_list_surveys(self):
        """list surveys shows survey IDs and names."""
        mock_api = MagicMock()
        mock_api.list_surveys.return_value = [_make_survey()]

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "surveys"])

        assert result.exit_code == 0
        assert str(SURVEY_ID) in result.output
        assert "Test Survey" in result.output

    def test_list_surveys_filter_by_project(self):
        """list surveys --project filters by project name."""
        other_project_id = UUID("00000000-0000-0000-0000-000000000099")
        mock_api = MagicMock()
        mock_api.list_surveys.return_value = [
            _make_survey(name="Match"),
            Survey(
                survey_id=UUID("00000000-0000-0000-0000-000000000098"),
                project_id=other_project_id, name="No Match", description=None,
                geodesy_srid="EPSG:32620", timezone_name="Etc/UTC",
                created_date=NOW, updated_date=NOW, updated_by="test",
            ),
        ]
        mock_api.list_projects.return_value = [_make_project()]

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "surveys", "--project", "Test Project"])

        assert result.exit_code == 0
        assert "Match" in result.output
        assert "No Match" not in result.output

    def test_list_surveys_empty(self):
        """list surveys shows message when none found."""
        mock_api = MagicMock()
        mock_api.list_surveys.return_value = []

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "surveys"])

        assert result.exit_code == 0
        assert "No surveys found" in result.output

    def test_list_surveys_json(self):
        """list surveys --json outputs valid JSON array."""
        mock_api = MagicMock()
        mock_api.list_surveys.return_value = [_make_survey()]

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "surveys", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert len(data) == 1
        assert data[0]["survey_id"] == str(SURVEY_ID)


class TestListProjectsCommand:
    """Tests for `ftm list projects`."""

    def test_list_projects(self):
        """list projects shows project IDs and names."""
        mock_api = MagicMock()
        mock_api.list_projects.return_value = [_make_project()]

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "projects"])

        assert result.exit_code == 0
        assert str(PROJECT_ID) in result.output
        assert "Test Project" in result.output

    def test_list_projects_empty(self):
        """list projects shows message when none found."""
        mock_api = MagicMock()
        mock_api.list_projects.return_value = []

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "projects"])

        assert result.exit_code == 0
        assert "No projects found" in result.output


class TestListJobsCommand:
    """Tests for `ftm list jobs`."""

    def test_list_jobs(self):
        """list jobs --survey shows jobs."""
        mock_api = MagicMock()
        mock_api.list_jobs.return_value = _make_job_list_model()

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "jobs", "--survey", str(SURVEY_ID)])

        assert result.exit_code == 0
        assert str(JOB_ID) in result.output

    def test_list_jobs_empty(self):
        """list jobs shows message when none found."""
        mock_api = MagicMock()
        mock_api.list_jobs.return_value = ProcessingJobList(
            jobs=[], total=0, limit=50, offset=0
        )

        with patch("cti.cli.main.get_api", return_value=mock_api):
            result = runner.invoke(app, ["list", "jobs", "--survey", str(SURVEY_ID)])

        assert result.exit_code == 0
        assert "No jobs found" in result.output
