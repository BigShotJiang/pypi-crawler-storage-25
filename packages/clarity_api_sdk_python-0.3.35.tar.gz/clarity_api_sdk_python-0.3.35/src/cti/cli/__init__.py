"""Fathom CLI (ftm) — command-line interface for the Fathom platform."""
