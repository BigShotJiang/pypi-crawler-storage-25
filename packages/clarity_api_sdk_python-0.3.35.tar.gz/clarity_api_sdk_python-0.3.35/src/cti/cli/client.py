"""Client factory for the ftm CLI.

Builds a SonarWizApi instance from environment variables.
Uses a plain httpx.Client (no OAuth2) when CLARITY_PLATFORM=local.
"""

from __future__ import annotations

import os

import httpx
import typer

from cti.api.sonar_wiz_api import SonarWizApi


def get_api() -> SonarWizApi:
    """Create a SonarWizApi from environment variables.

    Environment variables:
        CLARITY_API_URL: Base URL for the API (default: http://localhost:8081)
        CLARITY_PLATFORM: Set to "local" to skip OAuth2 auth.

    Returns:
        Configured SonarWizApi instance.
    """
    base_url = os.environ.get("CLARITY_API_URL", "http://localhost:8081")
    is_local = os.environ.get("CLARITY_PLATFORM") == "local"

    if is_local:
        client = httpx.Client(base_url=base_url, timeout=60, follow_redirects=True)
    else:
        try:
            from cti.api.client import ClarityApiClient

            client = ClarityApiClient()
        except Exception as e:
            typer.echo(
                f"Error: failed to create authenticated client: {e}\n"
                "Set CLARITY_PLATFORM=local for local dev (no auth).",
                err=True,
            )
            raise typer.Exit(1)

    return SonarWizApi(client)
