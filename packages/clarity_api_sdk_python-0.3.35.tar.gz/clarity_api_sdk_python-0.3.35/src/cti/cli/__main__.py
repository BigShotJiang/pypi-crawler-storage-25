"""Entry point for `python -m cti.cli` and the `ftm` console script."""

import sys


def main() -> None:
    try:
        from cti.cli.main import app
    except ImportError:
        print(
            "Error: ftm requires the [cli] extra.\n"
            "Install with: pip install 'clarity-api-sdk-python[cli]'",
            file=sys.stderr,
        )
        sys.exit(1)
    app()


if __name__ == "__main__":
    main()
