"""Fathom CLI (ftm) — upload, process, and monitor sonar survey data."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Optional
from uuid import UUID

import httpx
import typer

from cti.cli.client import get_api

app = typer.Typer(
    name="ftm",
    help="Fathom CLI — upload, process, and monitor sonar survey data.",
    no_args_is_help=True,
)

list_app = typer.Typer(help="List resources (surveys, projects, jobs).", no_args_is_help=True)
app.add_typer(list_app, name="list")


def _output(data: dict, as_json: bool) -> None:
    """Print output as JSON or human-readable."""
    if as_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        for key, value in data.items():
            typer.echo(f"  {key}: {value}")


def _get_error_detail(e: httpx.HTTPStatusError) -> str:
    """Extract error detail from an HTTP error response."""
    if e.response.headers.get("content-type", "").startswith("application/json"):
        return e.response.json().get("detail", str(e))
    return str(e)


@app.command()
def upload(
    file: Path = typer.Argument(..., help="Path to sonar file (.xtf, .jsf, etc.)"),
    survey: UUID = typer.Option(..., "--survey", "-s", help="Survey ID to upload to"),
    config_id: UUID | None = typer.Option(None, "--config", "-c", help="Raw file configuration ID (default: survey's default)"),
    no_mappings: bool = typer.Option(False, "--no-mappings", help="Skip automatic device mapping creation"),
    sidescan_stream: str = typer.Option("0", "--sidescan-stream", help="Source stream identifier for sidescan device"),
    gnss_stream: str = typer.Option("1", "--gnss-stream", help="Source stream identifier for GNSS device"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Upload a sonar file to a survey.

    After uploading, automatically creates device mappings linking the file
    to the survey's sidescan and GNSS devices. Use --no-mappings to skip.
    """
    from cti.model.raw_file_device_mapping import RawFileDeviceMappingCreate

    if not file.exists():
        typer.echo(f"Error: file not found: {file}", err=True)
        raise typer.Exit(1)

    api = get_api()
    typer.echo(f"Uploading {file.name} to survey {survey}...")

    try:
        result = api.upload_file(
            survey_id=survey,
            file_path=file,
            raw_file_configuration_id=config_id,
        )
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    typer.echo(f"Uploaded: {result.raw_file_id} ({result.file_name}, {result.file_size} bytes)")

    # Auto-create device mappings
    if not no_mappings:
        try:
            # Get the survey's platform and its devices
            platform = api.get_first_survey_platform(survey_id=survey)
            devices = api.get_platform_devices(platform_id=platform.platform_id)

            # Look up device types to identify sidescan and GNSS
            dt_list = api.list_device_types()
            dt_by_id = {dt.device_type_id: dt for dt in dt_list}

            # Get survey timezone for mapping
            survey_obj = api.get_survey(survey)
            tz = survey_obj.timezone_name

            mappings_created = 0
            for device in devices:
                dt = dt_by_id.get(device.device_type_id)
                if not dt:
                    continue
                if dt.enum_name == "sidescan_sonar":
                    stream_id = sidescan_stream
                elif dt.enum_name == "gnss_gps_position_sensor":
                    stream_id = gnss_stream
                else:
                    continue

                api.create_raw_file_device_mapping(RawFileDeviceMappingCreate(
                    raw_file_id=result.raw_file_id,
                    device_id=device.device_id,
                    source_stream_identifier=stream_id,
                    input_srid=4326,
                    input_timezone=tz,
                ))
                typer.echo(f"Mapped: {device.name} → stream {stream_id}")
                mappings_created += 1

            if mappings_created == 0:
                typer.echo("Warning: no sidescan/GNSS devices found on survey platform — no mappings created", err=True)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                typer.echo("Warning: no platform found on survey — skipping device mappings. Run 'ftm init' first.", err=True)
            else:
                typer.echo(f"Warning: failed to create device mappings: {_get_error_detail(e)}", err=True)

    _output(
        {
            "raw_file_id": str(result.raw_file_id),
            "file_name": result.file_name,
            "file_size": result.file_size,
            "state": result.state.value if hasattr(result.state, "value") else str(result.state),
        },
        output_json,
    )


@app.command()
def process(
    survey: UUID = typer.Argument(..., help="Survey ID to process"),
    wait: bool = typer.Option(False, "--wait", "-w", help="Wait for processing to complete"),
    timeout: float = typer.Option(300, "--timeout", "-t", help="Wait timeout in seconds"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Trigger processing for a survey."""
    api = get_api()
    typer.echo(f"Triggering processing for survey {survey}...")

    try:
        job = api.trigger_processing(survey_id=survey)
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    if wait:
        typer.echo(f"Job {job.job_id} submitted. Waiting (timeout: {timeout}s)...")
        try:
            job = api.wait_for_job(job_id=job.job_id, timeout=timeout)
        except TimeoutError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1)

    _output(
        {
            "job_id": str(job.job_id),
            "status": job.status,
            "current_phase": job.current_phase or "",
            "progress": job.progress,
        },
        output_json,
    )

    if job.status == "failed":
        if job.error:
            typer.echo(f"Error: {job.error}", err=True)
        raise typer.Exit(1)


@app.command()
def status(
    survey: UUID = typer.Argument(..., help="Survey ID to check"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Show survey status: file count, latest job, and product count."""
    api = get_api()

    # File count
    try:
        raw_files = api.get_raw_files(survey_id=survey)
        file_count = len(raw_files)
    except httpx.HTTPStatusError:
        file_count = 0

    # Product count (no SDK wrapper — call endpoint directly)
    try:
        resp = api._client.get(f"/api/v1/surveys/{survey}/final-products")
        product_count = len(resp.json()) if resp.status_code == 200 else 0
    except Exception:
        product_count = 0

    # Latest job
    jobs = api.list_jobs(survey_id=survey, limit=1)

    if not jobs.jobs:
        _output(
            {
                "survey_id": str(survey),
                "files": file_count,
                "products": product_count,
                "latest_job": "none",
            },
            output_json,
        )
        return

    job = jobs.jobs[0]

    _output(
        {
            "survey_id": str(survey),
            "files": file_count,
            "products": product_count,
            "job_id": str(job.job_id),
            "job_type": job.job_type,
            "status": job.status,
            "current_phase": job.current_phase or "",
            "progress": job.progress,
            "created_at": str(job.created_at),
            "completed_at": str(job.completed_at) if job.completed_at else "",
        },
        output_json,
    )


@app.command()
def init(
    project: str = typer.Option(..., "--project", "-p", help="Project name"),
    srid: str = typer.Option(..., "--srid", help="Projected CRS (e.g. EPSG:32618)"),
    timezone: str = typer.Option("Etc/UTC", "--timezone", "-tz", help="IANA timezone (default: Etc/UTC)"),
    org: str = typer.Option("Default Organization", "--org", "-o", help="Organization name (found or created)"),
    survey_name: Optional[str] = typer.Option(None, "--survey", "-s", help="Survey name (default: project name)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Survey description"),
    platform_type: str = typer.Option("Towed Body", "--platform-type", help="Platform type name (from seed data)"),
    platform_name: str = typer.Option("Platform", "--platform-name", help="Platform name"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """Initialize a new project and survey for processing.

    Creates organization (if needed), project, survey, platform with
    sidescan sonar and GNSS devices — everything needed before uploading files.
    """
    from cti.model.device import DeviceCreate
    from cti.model.organization import OrganizationCreate
    from cti.model.platform import PlatformCreate
    from cti.model.project import ProjectCreate
    from cti.model.survey import SurveyCreate

    api = get_api()
    survey_name = survey_name or project

    # Find or create organization
    try:
        orgs = api.list_organizations()
        existing = next((o for o in orgs if o.name == org), None)
        if existing:
            org_id = existing.organization_id
            typer.echo(f"Using organization: {org} ({org_id})")
        else:
            new_org = api.create_organization(OrganizationCreate(name=org))
            org_id = new_org.organization_id
            typer.echo(f"Created organization: {org} ({org_id})")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error creating organization: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    # Create project
    try:
        new_project = api.create_project(
            ProjectCreate(
                organization_id=org_id,
                project_name=project,
                project_description=description or "",
            )
        )
        typer.echo(f"Created project: {project} ({new_project.project_id})")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error creating project: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    # Create survey
    try:
        new_survey = api.create_survey(
            SurveyCreate(
                project_id=new_project.project_id,
                name=survey_name,
                description=description,
                geodesy_srid=srid,
                timezone_name=timezone,
            )
        )
        typer.echo(f"Created survey: {survey_name} ({new_survey.survey_id})")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error creating survey: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    # Find platform type by name
    try:
        pt_list = api.list_platform_types()
        pt = next((p for p in pt_list if p.name == platform_type), None)
        if not pt:
            available = ", ".join(p.name for p in pt_list)
            typer.echo(f"Error: platform type '{platform_type}' not found. Available: {available}", err=True)
            raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error listing platform types: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    # Create platform
    try:
        new_platform = api.create_platform(
            PlatformCreate(
                survey_id=new_survey.survey_id,
                platform_type_id=pt.platform_type_id,
                name=platform_name,
            )
        )
        typer.echo(f"Created platform: {platform_name} ({new_platform.platform_id})")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error creating platform: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    # Look up device types and create sidescan + GNSS devices
    try:
        dt_list = api.list_device_types()
        dt_by_enum = {dt.enum_name: dt for dt in dt_list}
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error listing device types: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    sidescan_dt = dt_by_enum.get("sidescan_sonar")
    gnss_dt = dt_by_enum.get("gnss_gps_position_sensor")
    if not sidescan_dt or not gnss_dt:
        typer.echo("Error: required device types (sidescan_sonar, gnss_gps_position_sensor) not found in seed data", err=True)
        raise typer.Exit(1)

    device_defaults = dict(channel=0, offset_x=0, offset_y=0, offset_z=0, offset_heading=0, offset_pitch=0, offset_roll=0, latency=0)
    try:
        ss_device = api.create_device(DeviceCreate(
            platform_id=new_platform.platform_id, device_type_id=sidescan_dt.device_type_id,
            name="Sidescan", is_towed=True, **device_defaults,
        ))
        typer.echo(f"Created device: Sidescan ({ss_device.device_id})")

        gnss_device = api.create_device(DeviceCreate(
            platform_id=new_platform.platform_id, device_type_id=gnss_dt.device_type_id,
            name="GNSS", is_towed=False, **device_defaults,
        ))
        typer.echo(f"Created device: GNSS ({gnss_device.device_id})")
    except httpx.HTTPStatusError as e:
        typer.echo(f"Error creating device: {_get_error_detail(e)}", err=True)
        raise typer.Exit(1)

    typer.echo()
    _output(
        {
            "organization_id": str(org_id),
            "organization_name": org,
            "project_id": str(new_project.project_id),
            "project_name": project,
            "survey_id": str(new_survey.survey_id),
            "survey_name": survey_name,
            "geodesy_srid": srid,
            "timezone": timezone,
            "platform_id": str(new_platform.platform_id),
            "sidescan_device_id": str(ss_device.device_id),
            "gnss_device_id": str(gnss_device.device_id),
        },
        output_json,
    )


@list_app.command("surveys")
def list_surveys(
    project_name: Optional[str] = typer.Option(None, "--project", "-p", help="Filter by project name"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List surveys."""
    api = get_api()
    surveys = api.list_surveys()

    if project_name:
        projects = api.list_projects()
        project_ids = {p.project_id for p in projects if p.project_name == project_name}
        surveys = [s for s in surveys if s.project_id in project_ids]

    if not surveys:
        typer.echo("No surveys found.")
        raise typer.Exit(0)

    if output_json:
        typer.echo(json.dumps(
            [{"survey_id": str(s.survey_id), "name": s.name, "project_id": str(s.project_id), "geodesy_srid": s.geodesy_srid, "timezone": s.timezone_name, "created": str(s.created_date)} for s in surveys],
            indent=2, default=str,
        ))
    else:
        for s in surveys:
            typer.echo(f"  {s.survey_id}  {s.name}  (srid={s.geodesy_srid}, tz={s.timezone_name})")


@list_app.command("projects")
def list_projects(
    org_name: Optional[str] = typer.Option(None, "--org", "-o", help="Filter by organization name"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List projects."""
    api = get_api()
    projects = api.list_projects()

    if org_name:
        orgs = api.list_organizations()
        org_ids = {o.organization_id for o in orgs if o.name == org_name}
        projects = [p for p in projects if p.organization_id in org_ids]

    if not projects:
        typer.echo("No projects found.")
        raise typer.Exit(0)

    if output_json:
        typer.echo(json.dumps(
            [{"project_id": str(p.project_id), "name": p.project_name, "organization_id": str(p.organization_id), "created": str(p.created_date)} for p in projects],
            indent=2, default=str,
        ))
    else:
        for p in projects:
            typer.echo(f"  {p.project_id}  {p.project_name}")


@list_app.command("jobs")
def list_jobs(
    survey: UUID = typer.Option(..., "--survey", "-s", help="Survey ID"),
    output_json: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
) -> None:
    """List processing jobs for a survey."""
    api = get_api()
    result = api.list_jobs(survey_id=survey)

    if not result.jobs:
        typer.echo(f"No jobs found for survey {survey}.")
        raise typer.Exit(0)

    if output_json:
        typer.echo(json.dumps(
            [{"job_id": str(j.job_id), "status": j.status, "job_type": j.job_type, "created_at": str(j.created_at), "completed_at": str(j.completed_at) if j.completed_at else None} for j in result.jobs],
            indent=2, default=str,
        ))
    else:
        for j in result.jobs:
            typer.echo(f"  {j.job_id}  {j.status}  {j.job_type}  {j.created_at}")


def main() -> None:
    """Entry point for the ftm CLI."""
    app()
