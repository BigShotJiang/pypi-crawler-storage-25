"""Pydantic models for processing job data."""

from datetime import datetime
from typing import Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict


class ProcessingJobBase(BaseModel):
    """Base model for processing job data.

    Attributes:
        job_type: Type of job (ingest, process).
        status: Current status (pending, running, completed, failed, cancelled).
        current_phase: Current pipeline phase.
        progress: Progress from 0.0 to 1.0.
        error: Error message if failed.
    """

    job_type: Literal["ingest", "process"]
    status: Literal["pending", "running", "completed", "failed", "cancelled"]
    current_phase: str | None = None
    progress: float = 0.0
    error: str | None = None


class ProcessingJobCreate(BaseModel):
    """Model for creating a processing job.

    Attributes:
        survey_id: Foreign key reference to Survey.
        job_type: Type of job (ingest, process).
    """

    survey_id: UUID
    job_type: Literal["ingest", "process"]


class JobStatusCallback(BaseModel):
    """Request body for engine phase transition callbacks.

    Attributes:
        event: Type of phase event (started, completed, failed).
        phase: Pipeline phase name.
        error: Error message if failed.
        traceback: Stack trace if failed.
        worker_id: Engine instance identifier.
    """

    event: Literal["started", "completed", "failed"]
    phase: str
    error: str | None = None
    traceback: str | None = None
    worker_id: str | None = None


class ProcessingJob(ProcessingJobBase):
    """Full processing job model with database fields.

    Attributes:
        job_id: Unique identifier for the job.
        survey_id: Foreign key reference to Survey.
        error_phase: Phase where failure occurred.
        error_traceback: Stack trace if failed.
        phase_timings: Per-phase timing data.
        created_at: When the job was created.
        started_at: When processing began.
        completed_at: When processing finished.
        worker_id: Engine instance identifier.
    """

    job_id: UUID
    survey_id: UUID
    error_phase: str | None = None
    error_traceback: str | None = None
    phase_timings: dict | None = None
    created_at: datetime
    started_at: datetime | None = None
    completed_at: datetime | None = None
    worker_id: str | None = None

    model_config = ConfigDict(from_attributes=True)


class ProcessingJobSummary(ProcessingJobBase):
    """Summary processing job model returned by the list endpoint.

    Attributes:
        job_id: Unique identifier for the job.
        survey_id: Foreign key reference to Survey.
        created_at: When the job was created.
        completed_at: When processing finished.
    """

    job_id: UUID
    survey_id: UUID
    created_at: datetime
    completed_at: datetime | None = None

    model_config = ConfigDict(from_attributes=True)


class ProcessingJobList(BaseModel):
    """Paginated list of processing jobs.

    Attributes:
        jobs: List of job summaries.
        total: Total number of matching jobs.
        limit: Maximum results returned.
        offset: Pagination offset.
    """

    jobs: list[ProcessingJobSummary]
    total: int
    limit: int
    offset: int
