"""Pydantic models for target data."""

from uuid import UUID

from pydantic import BaseModel, ConfigDict


class TargetBase(BaseModel):
    """Base model for target data.

    Attributes:
        name: Target name.
        description: Target description.
        target_x: X coordinate of the target.
        target_y: Y coordinate of the target.
        width: Target width.
        height: Target height.
        shadow: Target shadow.
    """

    name: str
    description: str
    target_x: float
    target_y: float
    width: float | None = None
    height: float | None = None
    shadow: float | None = None


class TargetCreate(TargetBase):
    """Model for creating target data.

    Attributes:
        sidescan_ping_source_id: FK reference to SidescanPingSource.
        channel: Channel index (0=port, 1=starboard).
        row: Ping row index.
    """

    sidescan_ping_source_id: UUID
    channel: int
    row: int


class TargetUpdate(TargetBase):
    """Model for updating target data."""


class Target(TargetBase):
    """Model for target data with database fields.

    Attributes:
        target_id: Unique identifier for the target.
        sidescan_ping_source_id: FK reference to SidescanPingSource.
        channel: Channel index (0=port, 1=starboard).
        row: Ping row index.
    """

    target_id: UUID
    sidescan_ping_source_id: UUID
    channel: int
    row: int

    model_config = ConfigDict(from_attributes=True)
