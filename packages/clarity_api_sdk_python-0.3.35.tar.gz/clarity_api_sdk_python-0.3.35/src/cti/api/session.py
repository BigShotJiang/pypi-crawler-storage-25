"""Provides event loop-scoped async client instances.

This module uses contextvars to ensure each event loop gets its own
ClarityApiAsyncClient instance, preventing issues when event loops are
created/destroyed (common in Dask workers).

Example:
    # Each asyncio.run() gets its own isolated client
    async def task():
        await initialize_async_client()
        client = get_async_client()
        response = await client.get(...)
        await close_async_client()  # Optional, cleans up resources

    # Task 1 - creates client in loop 1
    asyncio.run(task())

    # Task 2 - creates new client in loop 2
    asyncio.run(task())
"""

# pylint: disable=unnecessary-dunder-call

import asyncio
from contextvars import ContextVar
from typing import Optional

from cti.api.async_client import ClarityApiAsyncClient

# Context-local storage (isolated per event loop)
# Stores tuple of (client, loop) to track which loop the client was created in
_async_client_var: ContextVar[
    Optional[tuple[ClarityApiAsyncClient, asyncio.AbstractEventLoop]]
] = ContextVar("clarity_async_client", default=None)


def _is_client_valid(
    client_tuple: Optional[tuple[ClarityApiAsyncClient, asyncio.AbstractEventLoop]],
    current_loop: asyncio.AbstractEventLoop,
) -> bool:
    """Check if client is still valid for the current event loop.

    Args:
        client_tuple: Tuple of (client, loop) from context storage.
        current_loop: The current event loop to check against.

    Returns:
        True if client is valid for the current loop, False otherwise.
    """
    if client_tuple is None:
        return False

    _, stored_loop = client_tuple

    try:
        # Check if stored loop is the same as current loop and not closed
        return stored_loop is current_loop and not current_loop.is_closed()
    except Exception:
        pass
    return False


async def initialize_async_client() -> None:
    """Initialize async client for the current event loop context.

    Creates a new client instance if:
    - No client exists in current context, OR
    - Existing client is bound to a different (closed) event loop

    This function is idempotent within a single event loop.
    """
    current_client_tuple = _async_client_var.get()
    current_loop = asyncio.get_running_loop()

    # Check if we need a new client
    needs_new_client = not _is_client_valid(current_client_tuple, current_loop)

    if needs_new_client:
        # Close old client if it exists
        if current_client_tuple is not None:
            old_client, _ = current_client_tuple
            try:
                await old_client.__aexit__(None, None, None)
            except Exception:
                pass  # Best effort cleanup

        # Create new client for this event loop
        new_client = ClarityApiAsyncClient()
        await new_client.__aenter__()
        _async_client_var.set((new_client, current_loop))


def get_async_client() -> ClarityApiAsyncClient:
    """Get the async client for the current context.

    Returns:
        ClarityApiAsyncClient instance for this event loop.

    Raises:
        ValueError: If initialize_async_client() hasn't been called in this context.
    """
    client_tuple = _async_client_var.get()
    if client_tuple is None:
        raise ValueError(
            "initialize_async_client() must be called first to initialize client."
        )
    client, _ = client_tuple
    return client


async def close_async_client() -> None:
    """Close the async client for the current context.

    This function should be awaited to ensure the underlying connection
    pool is closed gracefully. Resources are cleaned up for the current
    event loop context only.
    """
    client_tuple = _async_client_var.get()
    if client_tuple:
        client, _ = client_tuple
        await client.__aexit__(None, None, None)
        _async_client_var.set(None)
