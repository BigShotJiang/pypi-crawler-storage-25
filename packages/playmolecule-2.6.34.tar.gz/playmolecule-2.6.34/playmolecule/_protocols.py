import logging
import sys
import importlib
from importlib.machinery import ModuleSpec

logger = logging.getLogger(__name__)


class _AliasLoader:
    """Loader that reuses an already-imported module object."""

    def __init__(self, real_module):
        self._real_module = real_module

    def create_module(self, spec):
        return self._real_module

    def exec_module(self, module):
        pass


class _AliasFinder:
    """Redirect imports of ``alias_prefix.*`` to ``real_prefix.*``.

    This is needed because the real ``protocols`` package may be
    Nuitka-compiled. Nuitka-compiled submodules can only be imported
    under their original fully-qualified name, so simply aliasing the
    top-level package in ``sys.modules`` is not enough to make
    ``playmolecule.protocols.<sub>`` resolvable.
    """

    def __init__(self, alias_prefix: str, real_prefix: str):
        self._alias = alias_prefix + "."
        self._real = real_prefix + "."

    def find_spec(self, fullname, path=None, target=None):
        if not fullname.startswith(self._alias):
            return None
        real_name = self._real + fullname[len(self._alias) :]
        try:
            real_mod = importlib.import_module(real_name)
        except ImportError:
            return None
        sys.modules[fullname] = real_mod
        spec = ModuleSpec(fullname, _AliasLoader(real_mod))
        spec.submodule_search_locations = getattr(real_mod, "__path__", None)
        return spec


def __find_protocols_by_import(parent_module: str = "playmolecule"):
    """Find protocols by importing the top-level ``protocols`` package.

    Registers the package in :data:`sys.modules` under
    ``<parent>.protocols`` and installs a meta-path finder so that
    submodule imports such as ``<parent>.protocols.foo.bar`` resolve to
    ``protocols.foo.bar``. This is required because the ``protocols``
    package may be Nuitka-compiled, and Nuitka-compiled submodules can
    only be imported under their original fully-qualified name.

    Returns the module if it exists, None otherwise.
    """
    try:
        import protocols
    except ImportError:
        return None

    alias = f"{parent_module}.protocols"
    sys.modules[alias] = protocols

    alias_dot = alias + "."
    if not any(
        isinstance(f, _AliasFinder) and f._alias == alias_dot for f in sys.meta_path
    ):
        sys.meta_path.insert(0, _AliasFinder(alias, "protocols"))

    return protocols


def __find_protocols_by_filesystem(local_registry, parent_module="playmolecule"):
    """Find protocols by scanning the filesystem under a local registry.

    Searches ``{local_registry}/acellera-protocols/`` for Python files
    and registers them as sub-modules of *parent_module*.
    """
    import os

    root_dir = local_registry.replace("local:", "")

    prot_dir = os.path.join(root_dir, "acellera-protocols")

    if os.path.exists(root_dir) and os.path.exists(prot_dir):
        from glob import glob
        import importlib
        import sys

        sys.path.insert(0, prot_dir)

        files = glob(os.path.join(prot_dir, "**", "*.py"), recursive=True)
        if len(files) == 0:
            return None

        for file in files:
            if file.endswith("__init__.py"):
                continue
            rel_path = os.path.relpath(file[:-3], prot_dir)
            mod_name = rel_path.replace(os.path.sep, ".")
            parts = mod_name.split(".")

            for i in range(len(parts)):
                submod = ".".join(parts[: i + 1])
                sys.modules[parent_module + "." + submod] = importlib.import_module(
                    submod, package=parent_module
                )

            # Append tutorials to the docs of the protocol
            dirname = os.path.dirname(file)
            pieces = rel_path.split(os.path.sep)
            # Check if the loaded module is the actual protocol file
            if len(pieces) == 4 and pieces[1] == pieces[3]:
                # Check if there are files/tutorials
                nb_tuts = glob(os.path.join(dirname, "files", "tutorials", "*.ipynb"))
                if len(nb_tuts):
                    # Modify the docs of the protocol
                    main_func = getattr(
                        sys.modules[parent_module + "." + submod], pieces[1]
                    )
                    main_func.__doc__ = (
                        main_func.__doc__
                        + "\n\nNotes\n-----\nTutorials are available for this protocol:\n\n"
                        + "\n".join([f"    - {t}" for t in nb_tuts])
                    )

        return sys.modules[parent_module + ".protocols"]
    return None


def __find_protocols(local_registry, parent_module="playmolecule"):
    """Find protocols by scanning the filesystem (backward-compatible alias)."""
    return __find_protocols_by_filesystem(local_registry, parent_module)
