"""JD xIoT 设备类注册模块.

用于统一注册各类京东智能设备类到 device_mapping 中
"""

# 注册设备类到device_mapping中
from .jd._light._jdznsd04sy.device_jdznsd04sy import DeviceJdznsd04sy
from .jd._light._jdznxtd02sy.device_jdznxtd02sy import DeviceJdznxtd02sy
from .jd._light._jdznxtd01sy.device_jdznxtd01sy import DeviceJdznxtd01sy
from .jd._light._jdznxtd03sy.device_jdznxtd03sy import DeviceJdznxtd03sy
from .jd._light._jdznsd01sy.device_jdznsd01sy import DeviceJdznsd01sy
from .jd._light._jdzntd02sy.device_jdzntd02sy import DeviceJdzntd02sy
from .jd._light._jdzntd01sy.device_jdzntd01sy import DeviceJdzntd01sy
from .jd._switch._jdzn3kg03lf.device_jdzn3kg03lf import DeviceJdzn3kg03lf
from .jd._switch._jdzn2kg02lf.device_jdzn2kg02lf import DeviceJdzn2kg02lf
from .jd._switch._jdzn1kg01lf.device_jdzn1kg01lf import DeviceJdzn1kg01lf
from .jd._curtain._jdzncl01dy.device_jdzncl01dy import DeviceJdzncl01dy
from .jd._switch._jdzn1kg04lf.device_jdzn1kg04lf import DeviceJdzn1kg04lf
from .jd._switch._jdzn2kg05lf.device_jdzn2kg05lf import DeviceJdzn2kg05lf
from .jd._switch._jdzn3kg06lf.device_jdzn3kg06lf import DeviceJdzn3kg06lf
from .jd._gateway._jdzhp02qs.device_jdzhp02qs import DeviceJdzhp02qs
from .jd._gateway._jdzhp01qs.device_jdzhp01qs import DeviceJdzhp01qs
from .jd._light._jdznsd02sy.device_jdznsd02sy import DeviceJdznsd02sy
from .jd._light._jdznsd03sy.device_jdznsd03sy import DeviceJdznsd03sy
from .jd._light._d1max150.device_d1_max_150 import DeviceD1Max150
from .arrow._toilet._ad828a.device_ad828a import DeviceAd828a

__all__ = [
    "DeviceJdznsd04sy",
    "DeviceJdznxtd02sy",
    "DeviceJdznxtd01sy",
    "DeviceJdznxtd03sy",
    "DeviceJdznsd01sy",
    "DeviceJdzntd02sy",
    "DeviceJdzntd01sy",
    "DeviceJdzn3kg03lf",
    "DeviceJdzn2kg02lf",
    "DeviceJdzn1kg01lf",
    "DeviceJdzncl01dy",
    "DeviceJdzn1kg04lf",
    "DeviceJdzn2kg05lf",
    "DeviceJdzn3kg06lf",
    "DeviceJdzhp02qs",
    "DeviceJdzhp01qs",
    "DeviceJdznsd02sy",
    "DeviceJdznsd03sy",
    "DeviceD1Max150",
    "DeviceAd828a",
]
