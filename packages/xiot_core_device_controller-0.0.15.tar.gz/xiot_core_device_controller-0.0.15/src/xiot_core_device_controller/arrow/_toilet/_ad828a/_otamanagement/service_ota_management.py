from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_upgrade_firmware import ActionUpgradeFirmware

from .events.event_firmware_upgrade_succeeded import EventFirmwareUpgradeSucceeded
from .events.event_firmware_upgrade_failed import EventFirmwareUpgradeFailed
from .events.event_firmware_upgrade_progress import EventFirmwareUpgradeProgress

from .properties.property_protocol import PropertyProtocol
from .properties.property_progress import PropertyProgress
from .properties.property_md5 import PropertyMd5
from .properties.property_sha256 import PropertySha256
from .properties.property_firmware_revision import PropertyFirmwareRevision
from .properties.property_firmware_url import PropertyFirmwareUrl
from .properties.property_firmware_info_c import PropertyFirmwareInfoC
from .properties.property_code import PropertyCode
from .properties.property_firmware_type import PropertyFirmwareType
from .properties.property_file_size import PropertyFileSize
from .properties.property_did import PropertyDid

# ota管理服务
class ServiceOtaManagement(ServiceController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:service:ota-management:00000e75:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "ota-management"
        self.description["zh-CN"] = "ota管理服务"

        self.properties[PropertyProtocol.IID] = PropertyProtocol()
        self.properties[PropertyProgress.IID] = PropertyProgress()
        self.properties[PropertyMd5.IID] = PropertyMd5()
        self.properties[PropertySha256.IID] = PropertySha256()
        self.properties[PropertyFirmwareRevision.IID] = PropertyFirmwareRevision()
        self.properties[PropertyFirmwareUrl.IID] = PropertyFirmwareUrl()
        self.properties[PropertyFirmwareInfoC.IID] = PropertyFirmwareInfoC()
        self.properties[PropertyCode.IID] = PropertyCode()
        self.properties[PropertyFirmwareType.IID] = PropertyFirmwareType()
        self.properties[PropertyFileSize.IID] = PropertyFileSize()
        self.properties[PropertyDid.IID] = PropertyDid()

        self.actions[ActionUpgradeFirmware.IID] = ActionUpgradeFirmware()

        self.events[EventFirmwareUpgradeSucceeded.IID] = EventFirmwareUpgradeSucceeded()
        self.events[EventFirmwareUpgradeFailed.IID] = EventFirmwareUpgradeFailed()
        self.events[EventFirmwareUpgradeProgress.IID] = EventFirmwareUpgradeProgress()

    # 通信方式
    def property_protocol(self) -> PropertyProtocol:
        return self.properties[PropertyProtocol.IID] # type: ignore[no-any-return]

    # 进度
    def property_progress(self) -> PropertyProgress:
        return self.properties[PropertyProgress.IID] # type: ignore[no-any-return]

    # md5
    def property_md5(self) -> PropertyMd5:
        return self.properties[PropertyMd5.IID] # type: ignore[no-any-return]

    # sha256
    def property_sha256(self) -> PropertySha256:
        return self.properties[PropertySha256.IID] # type: ignore[no-any-return]

    # 固件版本
    def property_firmware_revision(self) -> PropertyFirmwareRevision:
        return self.properties[PropertyFirmwareRevision.IID] # type: ignore[no-any-return]

    # 固件地址
    def property_firmware_url(self) -> PropertyFirmwareUrl:
        return self.properties[PropertyFirmwareUrl.IID] # type: ignore[no-any-return]

    # 固件信息
    def property_firmware_info_c(self) -> PropertyFirmwareInfoC:
        return self.properties[PropertyFirmwareInfoC.IID] # type: ignore[no-any-return]

    # 回复码
    def property_code(self) -> PropertyCode:
        return self.properties[PropertyCode.IID] # type: ignore[no-any-return]

    # 固件类型
    def property_firmware_type(self) -> PropertyFirmwareType:
        return self.properties[PropertyFirmwareType.IID] # type: ignore[no-any-return]

    # 文件大小
    def property_file_size(self) -> PropertyFileSize:
        return self.properties[PropertyFileSize.IID] # type: ignore[no-any-return]

    # 设备did
    def property_did(self) -> PropertyDid:
        return self.properties[PropertyDid.IID] # type: ignore[no-any-return]


    # 升级固件
    def action_upgrade_firmware(self) -> ActionUpgradeFirmware:
        return self.actions[ActionUpgradeFirmware.IID] # type: ignore[no-any-return]


    # 升级固件成功
    def event_firmware_upgrade_succeeded(self) -> EventFirmwareUpgradeSucceeded:
        return self.events[EventFirmwareUpgradeSucceeded.IID] # type: ignore[no-any-return]

    # 固件升级失败
    def event_firmware_upgrade_failed(self) -> EventFirmwareUpgradeFailed:
        return self.events[EventFirmwareUpgradeFailed.IID] # type: ignore[no-any-return]

    # 固件升级进度上报
    def event_firmware_upgrade_progress(self) -> EventFirmwareUpgradeProgress:
        return self.events[EventFirmwareUpgradeProgress.IID] # type: ignore[no-any-return]

