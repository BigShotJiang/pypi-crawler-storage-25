from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_ip import PropertyIp
from .properties.property_ipv4_subnet_mask import PropertyIpv4SubnetMask
from .properties.property_mac_address import PropertyMacAddress
from .properties.property_rssi import PropertyRssi

# 无线网络连接
class ServiceWifiConnectivity(ServiceController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:service:wifi-connectivity:00000002:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Wi-Fi Connectivity"
        self.description["zh-CN"] = "无线网络连接"

        self.properties[PropertyIp.IID] = PropertyIp()
        self.properties[PropertyIpv4SubnetMask.IID] = PropertyIpv4SubnetMask()
        self.properties[PropertyMacAddress.IID] = PropertyMacAddress()
        self.properties[PropertyRssi.IID] = PropertyRssi()



    # IPv4地址
    def property_ip(self) -> PropertyIp:
        return self.properties[PropertyIp.IID] # type: ignore[no-any-return]

    # IPv4子网掩码
    def property_ipv4_subnet_mask(self) -> PropertyIpv4SubnetMask:
        return self.properties[PropertyIpv4SubnetMask.IID] # type: ignore[no-any-return]

    # Mac地址
    def property_mac_address(self) -> PropertyMacAddress:
        return self.properties[PropertyMacAddress.IID] # type: ignore[no-any-return]

    # 信号强度
    def property_rssi(self) -> PropertyRssi:
        return self.properties[PropertyRssi.IID] # type: ignore[no-any-return]



