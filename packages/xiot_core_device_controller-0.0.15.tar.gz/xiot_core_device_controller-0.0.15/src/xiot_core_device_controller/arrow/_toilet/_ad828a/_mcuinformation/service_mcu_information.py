from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_firmware_revision import PropertyFirmwareRevision
from .properties.property_hardware_revision import PropertyHardwareRevision
from .properties.property_manufacturer import PropertyManufacturer
from .properties.property_name import PropertyName

# mcu信息
class ServiceMcuInformation(ServiceController):
    IID: int = 130
    TYPE: str = "urn:jd:service:mcu-information:00001d03:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Mcu Information"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "mcu信息"

        self.properties[PropertyFirmwareRevision.IID] = PropertyFirmwareRevision()
        self.properties[PropertyHardwareRevision.IID] = PropertyHardwareRevision()
        self.properties[PropertyManufacturer.IID] = PropertyManufacturer()
        self.properties[PropertyName.IID] = PropertyName()



    # mcu固件版本
    def property_firmware_revision(self) -> PropertyFirmwareRevision:
        return self.properties[PropertyFirmwareRevision.IID] # type: ignore[no-any-return]

    # mcu硬件版本
    def property_hardware_revision(self) -> PropertyHardwareRevision:
        return self.properties[PropertyHardwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def property_manufacturer(self) -> PropertyManufacturer:
        return self.properties[PropertyManufacturer.IID] # type: ignore[no-any-return]

    # 固件名称
    def property_name(self) -> PropertyName:
        return self.properties[PropertyName.IID] # type: ignore[no-any-return]



