from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_full_flush import ActionFullFlush
from .actions.action_partial_flush import ActionPartialFlush


from .properties.property_on1 import PropertyOn1
from .properties.property_seat_temperature_gear import PropertySeatTemperatureGear
from .properties.property_on3 import PropertyOn3
from .properties.property_on4 import PropertyOn4
from .properties.property_on5 import PropertyOn5
from .properties.property_on6 import PropertyOn6
from .properties.property_on8 import PropertyOn8

# 马桶
class ServiceToilet(ServiceController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:service:toilet:000007d6:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Toilet"
        self.description["zh-CN"] = "马桶"

        self.properties[PropertyOn1.IID] = PropertyOn1()
        self.properties[PropertySeatTemperatureGear.IID] = PropertySeatTemperatureGear()
        self.properties[PropertyOn3.IID] = PropertyOn3()
        self.properties[PropertyOn4.IID] = PropertyOn4()
        self.properties[PropertyOn5.IID] = PropertyOn5()
        self.properties[PropertyOn6.IID] = PropertyOn6()
        self.properties[PropertyOn8.IID] = PropertyOn8()

        self.actions[ActionFullFlush.IID] = ActionFullFlush()
        self.actions[ActionPartialFlush.IID] = ActionPartialFlush()


    # 座温开关
    def property_on1(self) -> PropertyOn1:
        return self.properties[PropertyOn1.IID] # type: ignore[no-any-return]

    # 座温档位
    def property_seat_temperature_gear(self) -> PropertySeatTemperatureGear:
        return self.properties[PropertySeatTemperatureGear.IID] # type: ignore[no-any-return]

    # 离座自动冲水
    def property_on3(self) -> PropertyOn3:
        return self.properties[PropertyOn3.IID] # type: ignore[no-any-return]

    # 离座智感冲水
    def property_on4(self) -> PropertyOn4:
        return self.properties[PropertyOn4.IID] # type: ignore[no-any-return]

    # 自动润壁开关
    def property_on5(self) -> PropertyOn5:
        return self.properties[PropertyOn5.IID] # type: ignore[no-any-return]

    # 夜灯开关
    def property_on6(self) -> PropertyOn6:
        return self.properties[PropertyOn6.IID] # type: ignore[no-any-return]

    # 脚感开关
    def property_on8(self) -> PropertyOn8:
        return self.properties[PropertyOn8.IID] # type: ignore[no-any-return]


    # 大冲
    def action_full_flush(self) -> ActionFullFlush:
        return self.actions[ActionFullFlush.IID] # type: ignore[no-any-return]

    # 小冲
    def action_partial_flush(self) -> ActionPartialFlush:
        return self.actions[ActionPartialFlush.IID] # type: ignore[no-any-return]


