from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_firmware_revision import PropertyFirmwareRevision
from .properties.property_manufacturer import PropertyManufacturer
from .properties.property_hardware_revision import PropertyHardwareRevision

# 设备信息
class ServiceDeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:arrow:ad828a:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[PropertyFirmwareRevision.IID] = PropertyFirmwareRevision()
        self.properties[PropertyManufacturer.IID] = PropertyManufacturer()
        self.properties[PropertyHardwareRevision.IID] = PropertyHardwareRevision()



    # 固件版本
    def property_firmware_revision(self) -> PropertyFirmwareRevision:
        return self.properties[PropertyFirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def property_manufacturer(self) -> PropertyManufacturer:
        return self.properties[PropertyManufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def property_hardware_revision(self) -> PropertyHardwareRevision:
        return self.properties[PropertyHardwareRevision.IID] # type: ignore[no-any-return]



