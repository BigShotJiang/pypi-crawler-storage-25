from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._deviceinformation.service_device_information import ServiceDeviceInformation
from ._mcuinformation.service_mcu_information import ServiceMcuInformation
from ._wificonnectivity.service_wifi_connectivity import ServiceWifiConnectivity
from ._otamanagement.service_ota_management import ServiceOtaManagement
from ._toilet.service_toilet import ServiceToilet

# 箭牌马桶
@register_device
class DeviceAd828a(DeviceController):
    TYPE: str = "urn:jd-spec:device:toilet:0000a02e:arrow:ad828a:1"

    def __init__(self):
        super().__init__(DeviceType(string = self.TYPE))

        self.description["en-US"] = "Arrow Toilet"
        self.description["zh-CN"] = "箭牌马桶"

        self.services[ServiceDeviceInformation.IID] = ServiceDeviceInformation()
        self.services[ServiceMcuInformation.IID] = ServiceMcuInformation()
        self.services[ServiceWifiConnectivity.IID] = ServiceWifiConnectivity()
        self.services[ServiceOtaManagement.IID] = ServiceOtaManagement()
        self.services[ServiceToilet.IID] = ServiceToilet()

    # 设备信息
    def service_device_information(self) -> ServiceDeviceInformation:
        return self.services[ServiceDeviceInformation.IID] # type: ignore[no-any-return]

    # mcu信息
    def service_mcu_information(self) -> ServiceMcuInformation:
        return self.services[ServiceMcuInformation.IID] # type: ignore[no-any-return]

    # 无线网络连接
    def service_wifi_connectivity(self) -> ServiceWifiConnectivity:
        return self.services[ServiceWifiConnectivity.IID] # type: ignore[no-any-return]

    # ota管理服务
    def service_ota_management(self) -> ServiceOtaManagement:
        return self.services[ServiceOtaManagement.IID] # type: ignore[no-any-return]

    # 马桶
    def service_toilet(self) -> ServiceToilet:
        return self.services[ServiceToilet.IID] # type: ignore[no-any-return]

