from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_format import PropertyFormat
from ..properties.property_content import PropertyContent


import logging

_LOGGER = logging.getLogger(__name__)

# 说话
class ActionSay(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:say:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Say"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "说话"


    # 执行 Action 调用
    async def invoke(self, property_format: Optional[int], property_content: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_format is None:
            raise ValueError("参数property_format不能为空")
        arguments[PropertyFormat.IID] = ArgumentOperation(piid = PropertyFormat.IID, value = property_format)

        if property_content is None:
            raise ValueError("参数property_content不能为空")
        arguments[PropertyContent.IID] = ArgumentOperation(piid = PropertyContent.IID, value = property_content)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
