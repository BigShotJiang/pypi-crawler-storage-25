from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_verify_package import ActionVerifyPackage
from .actions.action_install_package import ActionInstallPackage


from .properties.property_path import PropertyPath
from .properties.property_progress import PropertyProgress

# Recovery系统
class ServiceRecoverySystem(ServiceController):
    IID: int = 25
    TYPE: str = "urn:jd-spec:service:recovery-system:000000f1:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Recovery System"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "Recovery系统"

        self.properties[PropertyPath.IID] = PropertyPath()
        self.properties[PropertyProgress.IID] = PropertyProgress()

        self.actions[ActionVerifyPackage.IID] = ActionVerifyPackage()
        self.actions[ActionInstallPackage.IID] = ActionInstallPackage()


    # 固件文件路径
    def property_path(self) -> PropertyPath:
        return self.properties[PropertyPath.IID] # type: ignore[no-any-return]

    # 验证固件包的进度
    def property_progress(self) -> PropertyProgress:
        return self.properties[PropertyProgress.IID] # type: ignore[no-any-return]


    # 验证固件包
    def action_verify_package(self) -> ActionVerifyPackage:
        return self.actions[ActionVerifyPackage.IID] # type: ignore[no-any-return]

    # 升级固件包
    def action_install_package(self) -> ActionInstallPackage:
        return self.actions[ActionInstallPackage.IID] # type: ignore[no-any-return]


