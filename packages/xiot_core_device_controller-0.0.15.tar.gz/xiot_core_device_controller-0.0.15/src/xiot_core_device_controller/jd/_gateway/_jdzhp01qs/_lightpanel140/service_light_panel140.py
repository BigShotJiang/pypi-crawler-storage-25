from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_send_easylink import ActionSendEasylink


from .properties.property_on import PropertyOn
from .properties.property_brightness import PropertyBrightness
from .properties.property_color_temperature import PropertyColorTemperature
from .properties.property_mode import PropertyMode

# 灯控面板
class ServiceLightPanel140(ServiceController):
    IID: int = 140
    TYPE: str = "urn:jd-spec:service:light-panel:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Light Panel"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "灯控面板"

        self.properties[PropertyOn.IID] = PropertyOn()
        self.properties[PropertyBrightness.IID] = PropertyBrightness()
        self.properties[PropertyColorTemperature.IID] = PropertyColorTemperature()
        self.properties[PropertyMode.IID] = PropertyMode()

        self.actions[ActionSendEasylink.IID] = ActionSendEasylink()


    # 开关
    def property_on(self) -> PropertyOn:
        return self.properties[PropertyOn.IID] # type: ignore[no-any-return]

    # 亮度
    def property_brightness(self) -> PropertyBrightness:
        return self.properties[PropertyBrightness.IID] # type: ignore[no-any-return]

    # 色温
    def property_color_temperature(self) -> PropertyColorTemperature:
        return self.properties[PropertyColorTemperature.IID] # type: ignore[no-any-return]

    # 模式
    def property_mode(self) -> PropertyMode:
        return self.properties[PropertyMode.IID] # type: ignore[no-any-return]


    # 发出爽连指令
    def action_send_easylink(self) -> ActionSendEasylink:
        return self.actions[ActionSendEasylink.IID] # type: ignore[no-any-return]


