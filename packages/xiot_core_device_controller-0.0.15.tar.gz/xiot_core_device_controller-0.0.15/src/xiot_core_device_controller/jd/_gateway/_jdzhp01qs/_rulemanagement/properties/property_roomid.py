from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 房间id
class PropertyRoomid(PropertyController[int]):
    IID: int = 7
    TYPE: str = "urn:jd-spec:property:roomid:00001c26:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.INT32
        )
        self.description["en-US"] = "roomId"
        self.description["zh-CN"] = "房间id"



