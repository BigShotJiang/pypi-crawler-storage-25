from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_did import PropertyDid

from ..properties.property_device_rssi_c import PropertyDeviceRssiC
from ..properties.property_device_rssi_c import PropertyDeviceRssiCValue

import logging

_LOGGER = logging.getLogger(__name__)

# 读取子设备rssi
class ActionGetDeviceRssi(ActionController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:action:get-device-rssi:00000d4a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "get-device-rssi"
        self.description["zh-CN"] = "读取子设备rssi"

    # Action 出参
    class Result:
        # 设备rssi列表
        property_device_rssi_cs: list[PropertyDeviceRssiCValue]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _7: Optional[ArgumentOperation] = result[PropertyDeviceRssiC.IID]
            if _7 is not None:
                self.property_device_rssi_cs = [PropertyDeviceRssiCValue(value=v) for v in _7.values if isinstance(v, dict)]
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyDeviceRssiC)

            return

    # 执行 Action 调用
    async def invoke(self, property_dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_dids is None or len(property_dids) == 0:
            raise ValueError("参数property_dids不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, values = property_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionGetDeviceRssi.Result(out)
