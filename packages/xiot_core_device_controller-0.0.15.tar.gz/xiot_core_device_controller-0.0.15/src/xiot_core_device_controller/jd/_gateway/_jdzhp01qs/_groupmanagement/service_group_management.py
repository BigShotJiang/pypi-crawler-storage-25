from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_create_groups import ActionCreateGroups
from .actions.action_delete_groups import ActionDeleteGroups
from .actions.action_get_group_info import ActionGetGroupInfo
from .actions.action_add_devices_to_group import ActionAddDevicesToGroup
from .actions.action_remove_devices_from_group import ActionRemoveDevicesFromGroup
from .actions.action_get_groups_list import ActionGetGroupsList
from .actions.action_update_group import ActionUpdateGroup

from .events.event_device_joined_group import EventDeviceJoinedGroup

from .properties.property_group_did import PropertyGroupDid
from .properties.property_did import PropertyDid

# 组管理
class ServiceGroupManagement(ServiceController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:service:group-management:00000ce5:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Group Mangement"
        self.description["zh-CN"] = "组管理"

        self.properties[PropertyGroupDid.IID] = PropertyGroupDid()
        self.properties[PropertyDid.IID] = PropertyDid()

        self.actions[ActionCreateGroups.IID] = ActionCreateGroups()
        self.actions[ActionDeleteGroups.IID] = ActionDeleteGroups()
        self.actions[ActionGetGroupInfo.IID] = ActionGetGroupInfo()
        self.actions[ActionAddDevicesToGroup.IID] = ActionAddDevicesToGroup()
        self.actions[ActionRemoveDevicesFromGroup.IID] = ActionRemoveDevicesFromGroup()
        self.actions[ActionGetGroupsList.IID] = ActionGetGroupsList()
        self.actions[ActionUpdateGroup.IID] = ActionUpdateGroup()

        self.events[EventDeviceJoinedGroup.IID] = EventDeviceJoinedGroup()

    # 组did
    def property_group_did(self) -> PropertyGroupDid:
        return self.properties[PropertyGroupDid.IID] # type: ignore[no-any-return]

    # 设备did
    def property_did(self) -> PropertyDid:
        return self.properties[PropertyDid.IID] # type: ignore[no-any-return]


    # 创建组
    def action_create_groups(self) -> ActionCreateGroups:
        return self.actions[ActionCreateGroups.IID] # type: ignore[no-any-return]

    # 删除组
    def action_delete_groups(self) -> ActionDeleteGroups:
        return self.actions[ActionDeleteGroups.IID] # type: ignore[no-any-return]

    # 获取组信息
    def action_get_group_info(self) -> ActionGetGroupInfo:
        return self.actions[ActionGetGroupInfo.IID] # type: ignore[no-any-return]

    # 将设备添加到群组
    def action_add_devices_to_group(self) -> ActionAddDevicesToGroup:
        return self.actions[ActionAddDevicesToGroup.IID] # type: ignore[no-any-return]

    # 从组中移除设备
    def action_remove_devices_from_group(self) -> ActionRemoveDevicesFromGroup:
        return self.actions[ActionRemoveDevicesFromGroup.IID] # type: ignore[no-any-return]

    # 获取组列表
    def action_get_groups_list(self) -> ActionGetGroupsList:
        return self.actions[ActionGetGroupsList.IID] # type: ignore[no-any-return]

    # 更新组内设备
    def action_update_group(self) -> ActionUpdateGroup:
        return self.actions[ActionUpdateGroup.IID] # type: ignore[no-any-return]


    # 设备加入了组
    def event_device_joined_group(self) -> EventDeviceJoinedGroup:
        return self.events[EventDeviceJoinedGroup.IID] # type: ignore[no-any-return]

