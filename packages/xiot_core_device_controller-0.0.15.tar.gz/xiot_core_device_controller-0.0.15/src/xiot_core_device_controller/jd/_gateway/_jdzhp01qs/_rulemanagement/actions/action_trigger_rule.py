from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_rule_id import PropertyRuleId


import logging

_LOGGER = logging.getLogger(__name__)

# 执行场景
class ActionTriggerRule(ActionController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:action:trigger-rule:00000d53:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "trigger-rule"
        self.description["zh-CN"] = "执行场景"


    # 执行 Action 调用
    async def invoke(self, property_rule_id: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_rule_id is None:
            raise ValueError("参数property_rule_id不能为空")
        arguments[PropertyRuleId.IID] = ArgumentOperation(piid = PropertyRuleId.IID, value = property_rule_id)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
