from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 设备本机 Mac 地址
class PropertyMacAddress(PropertyController[str]):
    IID: int = 6
    TYPE: str = "urn:jd-spec:property:mac-address:0000000e:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=False),
            fmt = DataFormat.STRING
        )
        self.description["en-US"] = "Device Local Mac Address"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "设备本机 Mac 地址"



