from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_rule_id import PropertyRuleId
from ..properties.property_rule_enable import PropertyRuleEnable


import logging

_LOGGER = logging.getLogger(__name__)

# 使能场景
class ActionEnableRule(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:enable-rule:00000d52:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "enable-rule"
        self.description["zh-CN"] = "使能场景"


    # 执行 Action 调用
    async def invoke(self, property_rule_id: Optional[str], property_rule_enable: Optional[bool]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_rule_id is None:
            raise ValueError("参数property_rule_id不能为空")
        arguments[PropertyRuleId.IID] = ArgumentOperation(piid = PropertyRuleId.IID, value = property_rule_id)

        if property_rule_enable is None:
            raise ValueError("参数property_rule_enable不能为空")
        arguments[PropertyRuleEnable.IID] = ArgumentOperation(piid = PropertyRuleEnable.IID, value = property_rule_enable)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
