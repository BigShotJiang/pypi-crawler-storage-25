from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 绿色
class PropertyGreen(PropertyController[int]):
    IID: int = 2
    TYPE: str = "urn:jd-spec:property:green:00000002:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "GREEN"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "绿色"



