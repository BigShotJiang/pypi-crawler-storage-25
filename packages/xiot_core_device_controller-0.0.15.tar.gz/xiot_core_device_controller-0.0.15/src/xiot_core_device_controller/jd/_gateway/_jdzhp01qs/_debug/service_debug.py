from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_debug_enable import PropertyDebugEnable
from .properties.property_url import PropertyUrl
from .properties.property_port import PropertyPort
from .properties.property_token import PropertyToken

# 调试
class ServiceDebug(ServiceController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:service:debug:00000c81:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Debug"
        self.description["zh-CN"] = "调试"

        self.properties[PropertyDebugEnable.IID] = PropertyDebugEnable()
        self.properties[PropertyUrl.IID] = PropertyUrl()
        self.properties[PropertyPort.IID] = PropertyPort()
        self.properties[PropertyToken.IID] = PropertyToken()



    # 调试功能开关
    def property_debug_enable(self) -> PropertyDebugEnable:
        return self.properties[PropertyDebugEnable.IID] # type: ignore[no-any-return]

    # RTTY URL
    def property_url(self) -> PropertyUrl:
        return self.properties[PropertyUrl.IID] # type: ignore[no-any-return]

    # RTTY PORT
    def property_port(self) -> PropertyPort:
        return self.properties[PropertyPort.IID] # type: ignore[no-any-return]

    # RTTY TOKEN
    def property_token(self) -> PropertyToken:
        return self.properties[PropertyToken.IID] # type: ignore[no-any-return]



