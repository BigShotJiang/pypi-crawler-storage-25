from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_say import ActionSay


from .properties.property_format import PropertyFormat
from .properties.property_content import PropertyContent

# 语音服务
class ServiceVoice(ServiceController):
    IID: int = 144
    TYPE: str = "urn:jd-spec:service:voice:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Voice Service"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "语音服务"

        self.properties[PropertyFormat.IID] = PropertyFormat()
        self.properties[PropertyContent.IID] = PropertyContent()

        self.actions[ActionSay.IID] = ActionSay()


    # 格式
    def property_format(self) -> PropertyFormat:
        return self.properties[PropertyFormat.IID] # type: ignore[no-any-return]

    # 内容
    def property_content(self) -> PropertyContent:
        return self.properties[PropertyContent.IID] # type: ignore[no-any-return]


    # 说话
    def action_say(self) -> ActionSay:
        return self.actions[ActionSay.IID] # type: ignore[no-any-return]


