from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.property_device_info_c import PropertyDeviceInfoC
from ..properties.property_device_info_c import PropertyDeviceInfoCValue

# 设备添加
class EventDeviceAdded(EventController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:event:device-added:00000a2d:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "device-added"
        self.description["zh-CN"] = "设备添加"

        self._observer: Callable[[list[PropertyDeviceInfoCValue]], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            property_device_info_cs: list[PropertyDeviceInfoCValue]  = self.__property_device_info_cs(o)
            self._observer(property_device_info_cs)

    def observer(self, observer: Callable[[list[PropertyDeviceInfoCValue]], None]) -> None:
        self._observer = observer

    @staticmethod
    def __property_device_info_cs(o: EventOperation) -> list[PropertyDeviceInfoCValue]:
        argument: ArgumentOperation = o.arguments[PropertyDeviceInfoC.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyDeviceInfoC.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyDeviceInfoC.IID))

        values: list[PropertyDeviceInfoCValue] = []
        for item in objects:
            if isinstance(item, dict):
                values.append(PropertyDeviceInfoCValue(item))
            else:
                _LOGGER.error("argument value invalid: %s", type(item).__name__)

        return values

