from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_did import PropertyDid

from ..properties.property_did import PropertyDid

import logging

_LOGGER = logging.getLogger(__name__)

# 批量添加设备
class ActionAddDevices(ActionController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:action:add-devices:00000d4a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "add-devices"
        self.description["zh-CN"] = "批量添加设备"

    # Action 出参
    class Result:
        # 设备did列表
        property_dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _3: Optional[ArgumentOperation] = result[PropertyDid.IID]
            if _3 is not None:
                self.property_dids = [str(item) for item in _3.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyDid)

            return

    # 执行 Action 调用
    async def invoke(self, property_dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_dids is None or len(property_dids) == 0:
            raise ValueError("参数property_dids不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, values = property_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionAddDevices.Result(out)
