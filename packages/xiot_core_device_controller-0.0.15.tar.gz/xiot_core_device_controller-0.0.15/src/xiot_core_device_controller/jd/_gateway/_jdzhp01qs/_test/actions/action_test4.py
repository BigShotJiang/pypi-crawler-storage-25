from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_color4 import PropertyColor4
from ..properties.property_color4 import PropertyColor4Value

from ..properties.property_color9 import PropertyColor9
from ..properties.property_color9 import PropertyColor9Value

import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法4（组合属性）
class ActionTest4(ActionController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Test 4"
        self.description["zh-CN"] = "测试方法4（组合属性）"

    # Action 出参
    class Result:
        # 颜色
        property_color9: PropertyColor9Value

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _9: Optional[ArgumentOperation] = result[PropertyColor9.IID]
            if _9 is not None:
                v = _9.values[0]
                if isinstance(v, dict):
                    self.property_color9 = PropertyColor9Value(v)
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyColor9)

            return

    # 执行 Action 调用
    async def invoke(self, property_color4: Optional[PropertyColor4Value]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_color4 is None:
            raise ValueError("参数property_color4不能为空")
        arguments[PropertyColor4.IID] = ArgumentOperation(piid = PropertyColor4.IID, value = property_color4.to_map())

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionTest4.Result(out)
