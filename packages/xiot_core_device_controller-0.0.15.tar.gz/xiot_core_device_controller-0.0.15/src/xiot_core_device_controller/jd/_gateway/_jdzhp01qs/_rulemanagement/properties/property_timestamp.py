from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 时间戳
class PropertyTimestamp(PropertyController[int]):
    IID: int = 8
    TYPE: str = "urn:jd-spec:property:timestamp:000016a9:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT32
        )
        self.description["en-US"] = "Timestamp"
        self.description["zh-CN"] = "时间戳"

        self.constraint_value = ValueRange(DataFormat.UINT32,
            min_ = 0,
            max_ = 4294967295,
            step_ = 1
        )


