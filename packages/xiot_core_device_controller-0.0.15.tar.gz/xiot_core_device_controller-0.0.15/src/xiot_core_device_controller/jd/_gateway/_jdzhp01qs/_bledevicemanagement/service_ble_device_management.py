from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_start_scan_device import ActionStartScanDevice
from .actions.action_stop_scan_device import ActionStopScanDevice
from .actions.action_get_scan_result import ActionGetScanResult
from .actions.action_add_device import ActionAddDevice
from .actions.action_remove_device import ActionRemoveDevice
from .actions.action_get_device_rssi import ActionGetDeviceRssi
from .actions.action_add_devices import ActionAddDevices

from .events.event_device_removed import EventDeviceRemoved
from .events.event_device_added import EventDeviceAdded

from .properties.property_ble_mac import PropertyBleMac
from .properties.property_time_out import PropertyTimeOut
from .properties.property_did import PropertyDid
from .properties.property_device_type import PropertyDeviceType
from .properties.property_rssi import PropertyRssi
from .properties.property_device_info_c import PropertyDeviceInfoC
from .properties.property_device_rssi_c import PropertyDeviceRssiC
from .properties.property_status_code import PropertyStatusCode

# 蓝牙设备管理服务
class ServiceBleDeviceManagement(ServiceController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:service:ble-device-management:00000e76:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "ble-device-management"
        self.description["zh-CN"] = "蓝牙设备管理服务"

        self.properties[PropertyBleMac.IID] = PropertyBleMac()
        self.properties[PropertyTimeOut.IID] = PropertyTimeOut()
        self.properties[PropertyDid.IID] = PropertyDid()
        self.properties[PropertyDeviceType.IID] = PropertyDeviceType()
        self.properties[PropertyRssi.IID] = PropertyRssi()
        self.properties[PropertyDeviceInfoC.IID] = PropertyDeviceInfoC()
        self.properties[PropertyDeviceRssiC.IID] = PropertyDeviceRssiC()
        self.properties[PropertyStatusCode.IID] = PropertyStatusCode()

        self.actions[ActionStartScanDevice.IID] = ActionStartScanDevice()
        self.actions[ActionStopScanDevice.IID] = ActionStopScanDevice()
        self.actions[ActionGetScanResult.IID] = ActionGetScanResult()
        self.actions[ActionAddDevice.IID] = ActionAddDevice()
        self.actions[ActionRemoveDevice.IID] = ActionRemoveDevice()
        self.actions[ActionGetDeviceRssi.IID] = ActionGetDeviceRssi()
        self.actions[ActionAddDevices.IID] = ActionAddDevices()

        self.events[EventDeviceRemoved.IID] = EventDeviceRemoved()
        self.events[EventDeviceAdded.IID] = EventDeviceAdded()

    # 蓝牙Mac
    def property_ble_mac(self) -> PropertyBleMac:
        return self.properties[PropertyBleMac.IID] # type: ignore[no-any-return]

    # 超时时间
    def property_time_out(self) -> PropertyTimeOut:
        return self.properties[PropertyTimeOut.IID] # type: ignore[no-any-return]

    # 设备did
    def property_did(self) -> PropertyDid:
        return self.properties[PropertyDid.IID] # type: ignore[no-any-return]

    # 设备类型
    def property_device_type(self) -> PropertyDeviceType:
        return self.properties[PropertyDeviceType.IID] # type: ignore[no-any-return]

    # 蓝牙信号强度
    def property_rssi(self) -> PropertyRssi:
        return self.properties[PropertyRssi.IID] # type: ignore[no-any-return]

    # 设备信息
    def property_device_info_c(self) -> PropertyDeviceInfoC:
        return self.properties[PropertyDeviceInfoC.IID] # type: ignore[no-any-return]

    # 设备rssi
    def property_device_rssi_c(self) -> PropertyDeviceRssiC:
        return self.properties[PropertyDeviceRssiC.IID] # type: ignore[no-any-return]

    # 状态码
    def property_status_code(self) -> PropertyStatusCode:
        return self.properties[PropertyStatusCode.IID] # type: ignore[no-any-return]


    # 开启扫描设备
    def action_start_scan_device(self) -> ActionStartScanDevice:
        return self.actions[ActionStartScanDevice.IID] # type: ignore[no-any-return]

    # 停止扫描设备
    def action_stop_scan_device(self) -> ActionStopScanDevice:
        return self.actions[ActionStopScanDevice.IID] # type: ignore[no-any-return]

    # 读取扫描结果
    def action_get_scan_result(self) -> ActionGetScanResult:
        return self.actions[ActionGetScanResult.IID] # type: ignore[no-any-return]

    # 添加设备
    def action_add_device(self) -> ActionAddDevice:
        return self.actions[ActionAddDevice.IID] # type: ignore[no-any-return]

    # 删除设备
    def action_remove_device(self) -> ActionRemoveDevice:
        return self.actions[ActionRemoveDevice.IID] # type: ignore[no-any-return]

    # 读取子设备rssi
    def action_get_device_rssi(self) -> ActionGetDeviceRssi:
        return self.actions[ActionGetDeviceRssi.IID] # type: ignore[no-any-return]

    # 批量添加设备
    def action_add_devices(self) -> ActionAddDevices:
        return self.actions[ActionAddDevices.IID] # type: ignore[no-any-return]


    # 设备删除
    def event_device_removed(self) -> EventDeviceRemoved:
        return self.events[EventDeviceRemoved.IID] # type: ignore[no-any-return]

    # 设备添加
    def event_device_added(self) -> EventDeviceAdded:
        return self.events[EventDeviceAdded.IID] # type: ignore[no-any-return]

