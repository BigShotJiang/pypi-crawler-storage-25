from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_desk_number import PropertyDeskNumber
from ..properties.property_content import PropertyContent


import logging

_LOGGER = logging.getLogger(__name__)

# 更新桌面
class ActionUpdateDesktop(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:update-desktop:00000e34:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Update Desktop"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "更新桌面"


    # 执行 Action 调用
    async def invoke(self, property_desk_number: Optional[int], property_content: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_desk_number is None:
            raise ValueError("参数property_desk_number不能为空")
        arguments[PropertyDeskNumber.IID] = ArgumentOperation(piid = PropertyDeskNumber.IID, value = property_desk_number)

        if property_content is None:
            raise ValueError("参数property_content不能为空")
        arguments[PropertyContent.IID] = ArgumentOperation(piid = PropertyContent.IID, value = property_content)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
