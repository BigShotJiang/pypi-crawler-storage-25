from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_add_desktop import ActionAddDesktop
from .actions.action_delete_desktop import ActionDeleteDesktop
from .actions.action_update_desktop import ActionUpdateDesktop
from .actions.action_get_desktop import ActionGetDesktop
from .actions.action_add_desktop_card import ActionAddDesktopCard
from .actions.action_delete_desktop_card import ActionDeleteDesktopCard
from .actions.action_update_desktop_card import ActionUpdateDesktopCard
from .actions.action_get_desktop_card import ActionGetDesktopCard


from .properties.property_desk_number import PropertyDeskNumber
from .properties.property_desk_card_number import PropertyDeskCardNumber
from .properties.property_content import PropertyContent

# 桌面管理
class ServiceDesktopManagement(ServiceController):
    IID: int = 21
    TYPE: str = "urn:jd-spec:service:desktop-management:00000e8b:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Desktop Management"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "桌面管理"

        self.properties[PropertyDeskNumber.IID] = PropertyDeskNumber()
        self.properties[PropertyDeskCardNumber.IID] = PropertyDeskCardNumber()
        self.properties[PropertyContent.IID] = PropertyContent()

        self.actions[ActionAddDesktop.IID] = ActionAddDesktop()
        self.actions[ActionDeleteDesktop.IID] = ActionDeleteDesktop()
        self.actions[ActionUpdateDesktop.IID] = ActionUpdateDesktop()
        self.actions[ActionGetDesktop.IID] = ActionGetDesktop()
        self.actions[ActionAddDesktopCard.IID] = ActionAddDesktopCard()
        self.actions[ActionDeleteDesktopCard.IID] = ActionDeleteDesktopCard()
        self.actions[ActionUpdateDesktopCard.IID] = ActionUpdateDesktopCard()
        self.actions[ActionGetDesktopCard.IID] = ActionGetDesktopCard()


    # 桌面编号
    def property_desk_number(self) -> PropertyDeskNumber:
        return self.properties[PropertyDeskNumber.IID] # type: ignore[no-any-return]

    # 桌面卡片编号
    def property_desk_card_number(self) -> PropertyDeskCardNumber:
        return self.properties[PropertyDeskCardNumber.IID] # type: ignore[no-any-return]

    # 内容
    def property_content(self) -> PropertyContent:
        return self.properties[PropertyContent.IID] # type: ignore[no-any-return]


    # 添加桌面
    def action_add_desktop(self) -> ActionAddDesktop:
        return self.actions[ActionAddDesktop.IID] # type: ignore[no-any-return]

    # 删除桌面
    def action_delete_desktop(self) -> ActionDeleteDesktop:
        return self.actions[ActionDeleteDesktop.IID] # type: ignore[no-any-return]

    # 更新桌面
    def action_update_desktop(self) -> ActionUpdateDesktop:
        return self.actions[ActionUpdateDesktop.IID] # type: ignore[no-any-return]

    # 查询桌面
    def action_get_desktop(self) -> ActionGetDesktop:
        return self.actions[ActionGetDesktop.IID] # type: ignore[no-any-return]

    # 添加桌面卡片
    def action_add_desktop_card(self) -> ActionAddDesktopCard:
        return self.actions[ActionAddDesktopCard.IID] # type: ignore[no-any-return]

    # 删除桌面卡片
    def action_delete_desktop_card(self) -> ActionDeleteDesktopCard:
        return self.actions[ActionDeleteDesktopCard.IID] # type: ignore[no-any-return]

    # 更新桌面卡片
    def action_update_desktop_card(self) -> ActionUpdateDesktopCard:
        return self.actions[ActionUpdateDesktopCard.IID] # type: ignore[no-any-return]

    # 查询桌面卡片
    def action_get_desktop_card(self) -> ActionGetDesktopCard:
        return self.actions[ActionGetDesktopCard.IID] # type: ignore[no-any-return]


