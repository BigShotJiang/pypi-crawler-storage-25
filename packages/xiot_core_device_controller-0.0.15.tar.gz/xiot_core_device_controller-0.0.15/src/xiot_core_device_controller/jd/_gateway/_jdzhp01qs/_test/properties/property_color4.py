from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_red import PropertyRed
from .property_green import PropertyGreen
from .property_blue import PropertyBlue

class PropertyColor4Value:
    property_red: PropertyRed = PropertyRed()
    property_green: PropertyGreen = PropertyGreen()
    property_blue: PropertyBlue = PropertyBlue()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_red.put_value(value[PropertyRed.IID])
            self.property_green.put_value(value[PropertyGreen.IID])
            self.property_blue.put_value(value[PropertyBlue.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyRed.IID: self.property_red.get_value(),
            PropertyGreen.IID: self.property_green.get_value(),
            PropertyBlue.IID: self.property_blue.get_value(),
        }
        return _map

# 颜色
class PropertyColor4(PropertyController[PropertyColor4Value]):
    IID: int = 4
    TYPE: str = "urn:jd-spec:property:color:00000004:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "RGB"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "颜色"



    def to_map(self, value: Optional[PropertyColor4Value]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
