from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_open_all_switches import ActionOpenAllSwitches
from .actions.action_close_all_switches import ActionCloseAllSwitches



# 多路开关控制
class ServiceMultiSwitchControl(ServiceController):
    IID: int = 146
    TYPE: str = "urn:jd-spec:service:multi-switch-control:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Multi Switch Control"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "多路开关控制"


        self.actions[ActionOpenAllSwitches.IID] = ActionOpenAllSwitches()
        self.actions[ActionCloseAllSwitches.IID] = ActionCloseAllSwitches()



    # 全开
    def action_open_all_switches(self) -> ActionOpenAllSwitches:
        return self.actions[ActionOpenAllSwitches.IID] # type: ignore[no-any-return]

    # 全关
    def action_close_all_switches(self) -> ActionCloseAllSwitches:
        return self.actions[ActionCloseAllSwitches.IID] # type: ignore[no-any-return]


