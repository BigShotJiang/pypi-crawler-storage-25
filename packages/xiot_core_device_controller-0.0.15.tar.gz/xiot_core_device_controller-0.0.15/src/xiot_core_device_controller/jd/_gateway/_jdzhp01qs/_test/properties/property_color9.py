from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_brightness import PropertyBrightness
from .property_hue import PropertyHue
from .property_saturation import PropertySaturation
from .property_color_temperature import PropertyColorTemperature

class PropertyColor9Value:
    property_brightness: PropertyBrightness = PropertyBrightness()
    property_hue: PropertyHue = PropertyHue()
    property_saturation: PropertySaturation = PropertySaturation()
    property_color_temperature: PropertyColorTemperature = PropertyColorTemperature()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_brightness.put_value(value[PropertyBrightness.IID])
            self.property_hue.put_value(value[PropertyHue.IID])
            self.property_saturation.put_value(value[PropertySaturation.IID])
            self.property_color_temperature.put_value(value[PropertyColorTemperature.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyBrightness.IID: self.property_brightness.get_value(),
            PropertyHue.IID: self.property_hue.get_value(),
            PropertySaturation.IID: self.property_saturation.get_value(),
            PropertyColorTemperature.IID: self.property_color_temperature.get_value(),
        }
        return _map

# 颜色
class PropertyColor9(PropertyController[PropertyColor9Value]):
    IID: int = 9
    TYPE: str = "urn:jd-spec:property:color:00000009:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "YUV"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "颜色"



    def to_map(self, value: Optional[PropertyColor9Value]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
