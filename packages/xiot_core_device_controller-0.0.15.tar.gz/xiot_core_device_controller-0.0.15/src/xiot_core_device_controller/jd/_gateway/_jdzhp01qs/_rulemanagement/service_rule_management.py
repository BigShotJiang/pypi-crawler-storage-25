from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_add_rule import ActionAddRule
from .actions.action_edit_rule import ActionEditRule
from .actions.action_enable_rule import ActionEnableRule
from .actions.action_trigger_rule import ActionTriggerRule
from .actions.action_remove_rule import ActionRemoveRule
from .actions.action_get_rules6 import ActionGetRules6
from .actions.action_get_rules7 import ActionGetRules7

from .events.event_rule_removed import EventRuleRemoved
from .events.event_rule_added import EventRuleAdded
from .events.event_rule_updated import EventRuleUpdated
from .events.event_rule_enabled import EventRuleEnabled
from .events.event_rule_started import EventRuleStarted
from .events.event_rule_running import EventRuleRunning
from .events.event_rule_excuted_result import EventRuleExcutedResult

from .properties.property_rule_name import PropertyRuleName
from .properties.property_rule_id import PropertyRuleId
from .properties.property_rule_enable import PropertyRuleEnable
from .properties.property_rule_content import PropertyRuleContent
from .properties.property_content_formatter import PropertyContentFormatter
from .properties.property_rule_info_c import PropertyRuleInfoC
from .properties.property_roomid import PropertyRoomid
from .properties.property_timestamp import PropertyTimestamp
from .properties.property_operation_type import PropertyOperationType
from .properties.property_operation_id import PropertyOperationId
from .properties.property_operation_value import PropertyOperationValue
from .properties.property_operation_result import PropertyOperationResult
from .properties.property_status import PropertyStatus
from .properties.property_r_description import PropertyRDescription
from .properties.property_progress import PropertyProgress
from .properties.property_iconid import PropertyIconid
from .properties.property_delete_after_execution import PropertyDeleteAfterExecution

# 场景管理服务
class ServiceRuleManagement(ServiceController):
    IID: int = 8
    TYPE: str = "urn:jd-spec:service:rule-management:00000e78:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "rule-management"
        self.description["zh-CN"] = "场景管理服务"

        self.properties[PropertyRuleName.IID] = PropertyRuleName()
        self.properties[PropertyRuleId.IID] = PropertyRuleId()
        self.properties[PropertyRuleEnable.IID] = PropertyRuleEnable()
        self.properties[PropertyRuleContent.IID] = PropertyRuleContent()
        self.properties[PropertyContentFormatter.IID] = PropertyContentFormatter()
        self.properties[PropertyRuleInfoC.IID] = PropertyRuleInfoC()
        self.properties[PropertyRoomid.IID] = PropertyRoomid()
        self.properties[PropertyTimestamp.IID] = PropertyTimestamp()
        self.properties[PropertyOperationType.IID] = PropertyOperationType()
        self.properties[PropertyOperationId.IID] = PropertyOperationId()
        self.properties[PropertyOperationValue.IID] = PropertyOperationValue()
        self.properties[PropertyOperationResult.IID] = PropertyOperationResult()
        self.properties[PropertyStatus.IID] = PropertyStatus()
        self.properties[PropertyRDescription.IID] = PropertyRDescription()
        self.properties[PropertyProgress.IID] = PropertyProgress()
        self.properties[PropertyIconid.IID] = PropertyIconid()
        self.properties[PropertyDeleteAfterExecution.IID] = PropertyDeleteAfterExecution()

        self.actions[ActionAddRule.IID] = ActionAddRule()
        self.actions[ActionEditRule.IID] = ActionEditRule()
        self.actions[ActionEnableRule.IID] = ActionEnableRule()
        self.actions[ActionTriggerRule.IID] = ActionTriggerRule()
        self.actions[ActionRemoveRule.IID] = ActionRemoveRule()
        self.actions[ActionGetRules6.IID] = ActionGetRules6()
        self.actions[ActionGetRules7.IID] = ActionGetRules7()

        self.events[EventRuleRemoved.IID] = EventRuleRemoved()
        self.events[EventRuleAdded.IID] = EventRuleAdded()
        self.events[EventRuleUpdated.IID] = EventRuleUpdated()
        self.events[EventRuleEnabled.IID] = EventRuleEnabled()
        self.events[EventRuleStarted.IID] = EventRuleStarted()
        self.events[EventRuleRunning.IID] = EventRuleRunning()
        self.events[EventRuleExcutedResult.IID] = EventRuleExcutedResult()

    # 场景名称
    def property_rule_name(self) -> PropertyRuleName:
        return self.properties[PropertyRuleName.IID] # type: ignore[no-any-return]

    # 场景id
    def property_rule_id(self) -> PropertyRuleId:
        return self.properties[PropertyRuleId.IID] # type: ignore[no-any-return]

    # 场景使能
    def property_rule_enable(self) -> PropertyRuleEnable:
        return self.properties[PropertyRuleEnable.IID] # type: ignore[no-any-return]

    # 场景内容
    def property_rule_content(self) -> PropertyRuleContent:
        return self.properties[PropertyRuleContent.IID] # type: ignore[no-any-return]

    # 场景内容格式
    def property_content_formatter(self) -> PropertyContentFormatter:
        return self.properties[PropertyContentFormatter.IID] # type: ignore[no-any-return]

    # 规则信息
    def property_rule_info_c(self) -> PropertyRuleInfoC:
        return self.properties[PropertyRuleInfoC.IID] # type: ignore[no-any-return]

    # 房间id
    def property_roomid(self) -> PropertyRoomid:
        return self.properties[PropertyRoomid.IID] # type: ignore[no-any-return]

    # 时间戳
    def property_timestamp(self) -> PropertyTimestamp:
        return self.properties[PropertyTimestamp.IID] # type: ignore[no-any-return]

    # 操作类型
    def property_operation_type(self) -> PropertyOperationType:
        return self.properties[PropertyOperationType.IID] # type: ignore[no-any-return]

    # 操作id，根据operation-type决定，invoke-aciton：aid，invoke-rule：null，sleep：null,set-property:pid
    def property_operation_id(self) -> PropertyOperationId:
        return self.properties[PropertyOperationId.IID] # type: ignore[no-any-return]

    # 操作值
    def property_operation_value(self) -> PropertyOperationValue:
        return self.properties[PropertyOperationValue.IID] # type: ignore[no-any-return]

    # 操作结果
    def property_operation_result(self) -> PropertyOperationResult:
        return self.properties[PropertyOperationResult.IID] # type: ignore[no-any-return]

    # 设备状态
    def property_status(self) -> PropertyStatus:
        return self.properties[PropertyStatus.IID] # type: ignore[no-any-return]

    # 描述
    def property_r_description(self) -> PropertyRDescription:
        return self.properties[PropertyRDescription.IID] # type: ignore[no-any-return]

    # 进度
    def property_progress(self) -> PropertyProgress:
        return self.properties[PropertyProgress.IID] # type: ignore[no-any-return]

    # iconId
    def property_iconid(self) -> PropertyIconid:
        return self.properties[PropertyIconid.IID] # type: ignore[no-any-return]

    # 执行完删除
    def property_delete_after_execution(self) -> PropertyDeleteAfterExecution:
        return self.properties[PropertyDeleteAfterExecution.IID] # type: ignore[no-any-return]


    # 添加场景
    def action_add_rule(self) -> ActionAddRule:
        return self.actions[ActionAddRule.IID] # type: ignore[no-any-return]

    # 修改场景
    def action_edit_rule(self) -> ActionEditRule:
        return self.actions[ActionEditRule.IID] # type: ignore[no-any-return]

    # 使能场景
    def action_enable_rule(self) -> ActionEnableRule:
        return self.actions[ActionEnableRule.IID] # type: ignore[no-any-return]

    # 执行场景
    def action_trigger_rule(self) -> ActionTriggerRule:
        return self.actions[ActionTriggerRule.IID] # type: ignore[no-any-return]

    # 删除场景
    def action_remove_rule(self) -> ActionRemoveRule:
        return self.actions[ActionRemoveRule.IID] # type: ignore[no-any-return]

    # 查询场景
    def action_get_rules6(self) -> ActionGetRules6:
        return self.actions[ActionGetRules6.IID] # type: ignore[no-any-return]

    # 查询场景列表
    def action_get_rules7(self) -> ActionGetRules7:
        return self.actions[ActionGetRules7.IID] # type: ignore[no-any-return]


    # 场景删除
    def event_rule_removed(self) -> EventRuleRemoved:
        return self.events[EventRuleRemoved.IID] # type: ignore[no-any-return]

    # 场景创建
    def event_rule_added(self) -> EventRuleAdded:
        return self.events[EventRuleAdded.IID] # type: ignore[no-any-return]

    # 场景更新
    def event_rule_updated(self) -> EventRuleUpdated:
        return self.events[EventRuleUpdated.IID] # type: ignore[no-any-return]

    # 场景使能
    def event_rule_enabled(self) -> EventRuleEnabled:
        return self.events[EventRuleEnabled.IID] # type: ignore[no-any-return]

    # 场景执行开始
    def event_rule_started(self) -> EventRuleStarted:
        return self.events[EventRuleStarted.IID] # type: ignore[no-any-return]

    # 场景执行中
    def event_rule_running(self) -> EventRuleRunning:
        return self.events[EventRuleRunning.IID] # type: ignore[no-any-return]

    # 场景执行结果
    def event_rule_excuted_result(self) -> EventRuleExcutedResult:
        return self.events[EventRuleExcutedResult.IID] # type: ignore[no-any-return]

