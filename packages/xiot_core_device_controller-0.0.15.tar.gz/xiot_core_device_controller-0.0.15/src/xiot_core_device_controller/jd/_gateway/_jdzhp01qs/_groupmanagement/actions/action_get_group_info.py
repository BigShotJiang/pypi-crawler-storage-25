from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_group_did import PropertyGroupDid

from ..properties.property_group_did import PropertyGroupDid
from ..properties.property_did import PropertyDid

import logging

_LOGGER = logging.getLogger(__name__)

# 获取组信息
class ActionGetGroupInfo(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:get-group-info:00000b5a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Get Group Info"
        self.description["zh-CN"] = "获取组信息"

    # Action 出参
    class Result:
        # 组did
        property_group_did: str
        # 设备did列表
        property_dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[PropertyGroupDid.IID]
            if _1 is not None:
                v = _1.values[0]
                if isinstance(v, str):
                    self.property_group_did = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyGroupDid)

            _2: Optional[ArgumentOperation] = result[PropertyDid.IID]
            if _2 is not None:
                self.property_dids = [str(item) for item in _2.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyDid)

            return

    # 执行 Action 调用
    async def invoke(self, property_group_did: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_group_did is None:
            raise ValueError("参数property_group_did不能为空")
        arguments[PropertyGroupDid.IID] = ArgumentOperation(piid = PropertyGroupDid.IID, value = property_group_did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionGetGroupInfo.Result(out)
