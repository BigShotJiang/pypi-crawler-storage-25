from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_operation_type import PropertyOperationType
from .property_operation_id import PropertyOperationId
from .property_operation_value import PropertyOperationValue
from .property_status import PropertyStatus
from .property_r_description import PropertyRDescription

class PropertyOperationResultValue:
    property_operation_type: PropertyOperationType = PropertyOperationType()
    property_operation_id: PropertyOperationId = PropertyOperationId()
    property_operation_value: PropertyOperationValue = PropertyOperationValue()
    property_status: PropertyStatus = PropertyStatus()
    property_r_description: PropertyRDescription = PropertyRDescription()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_operation_type.put_value(value[PropertyOperationType.IID])
            self.property_operation_id.put_value(value[PropertyOperationId.IID])
            self.property_operation_value.put_value(value[PropertyOperationValue.IID])
            self.property_status.put_value(value[PropertyStatus.IID])
            self.property_r_description.put_value(value[PropertyRDescription.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyOperationType.IID: self.property_operation_type.get_value(),
            PropertyOperationId.IID: self.property_operation_id.get_value(),
            PropertyOperationValue.IID: self.property_operation_value.get_value(),
            PropertyStatus.IID: self.property_status.get_value(),
            PropertyRDescription.IID: self.property_r_description.get_value(),
        }
        return _map

# 操作结果
class PropertyOperationResult(PropertyController[PropertyOperationResultValue]):
    IID: int = 12
    TYPE: str = "urn:jd-spec:property:operation-result:00001c3a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "operation-result"
        self.description["zh-CN"] = "操作结果"



    def to_map(self, value: Optional[PropertyOperationResultValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
