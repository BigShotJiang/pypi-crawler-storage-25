from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_color4 import PropertyColor4
from ..properties.property_color4 import PropertyColor4Value


import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法3（组合属性）
class ActionTest3(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Test 3"
        self.description["zh-CN"] = "测试方法3（组合属性）"


    # 执行 Action 调用
    async def invoke(self, property_color4: Optional[PropertyColor4Value]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_color4 is None:
            raise ValueError("参数property_color4不能为空")
        arguments[PropertyColor4.IID] = ArgumentOperation(piid = PropertyColor4.IID, value = property_color4.to_map())

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
