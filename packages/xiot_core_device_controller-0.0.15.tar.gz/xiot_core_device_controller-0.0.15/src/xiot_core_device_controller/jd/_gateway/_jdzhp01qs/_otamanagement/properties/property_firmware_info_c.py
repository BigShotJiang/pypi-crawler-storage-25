from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_protocol import PropertyProtocol
from .property_md5 import PropertyMd5
from .property_sha256 import PropertySha256
from .property_firmware_url import PropertyFirmwareUrl
from .property_firmware_type import PropertyFirmwareType
from .property_file_size import PropertyFileSize
from .property_firmware_revision import PropertyFirmwareRevision

class PropertyFirmwareInfoCValue:
    property_protocol: PropertyProtocol = PropertyProtocol()
    property_md5: PropertyMd5 = PropertyMd5()
    property_sha256: PropertySha256 = PropertySha256()
    property_firmware_url: PropertyFirmwareUrl = PropertyFirmwareUrl()
    property_firmware_type: PropertyFirmwareType = PropertyFirmwareType()
    property_file_size: PropertyFileSize = PropertyFileSize()
    property_firmware_revision: PropertyFirmwareRevision = PropertyFirmwareRevision()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_protocol.put_value(value[PropertyProtocol.IID])
            self.property_md5.put_value(value[PropertyMd5.IID])
            self.property_sha256.put_value(value[PropertySha256.IID])
            self.property_firmware_url.put_value(value[PropertyFirmwareUrl.IID])
            self.property_firmware_type.put_value(value[PropertyFirmwareType.IID])
            self.property_file_size.put_value(value[PropertyFileSize.IID])
            self.property_firmware_revision.put_value(value[PropertyFirmwareRevision.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyProtocol.IID: self.property_protocol.get_value(),
            PropertyMd5.IID: self.property_md5.get_value(),
            PropertySha256.IID: self.property_sha256.get_value(),
            PropertyFirmwareUrl.IID: self.property_firmware_url.get_value(),
            PropertyFirmwareType.IID: self.property_firmware_type.get_value(),
            PropertyFileSize.IID: self.property_file_size.get_value(),
            PropertyFirmwareRevision.IID: self.property_firmware_revision.get_value(),
        }
        return _map

# 固件信息
class PropertyFirmwareInfoC(PropertyController[PropertyFirmwareInfoCValue]):
    IID: int = 7
    TYPE: str = "urn:jd-spec:property:firmware-info-c:00001c27:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "firmware-info-c"
        self.description["zh-CN"] = "固件信息"



    def to_map(self, value: Optional[PropertyFirmwareInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
