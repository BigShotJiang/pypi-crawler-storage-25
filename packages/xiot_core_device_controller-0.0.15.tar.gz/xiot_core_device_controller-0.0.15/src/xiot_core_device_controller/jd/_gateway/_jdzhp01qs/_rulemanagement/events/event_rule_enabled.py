from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.property_rule_id import PropertyRuleId
from ..properties.property_rule_enable import PropertyRuleEnable

# 场景使能
class EventRuleEnabled(EventController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:event:rule-enabled:00000a37:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "rule-enabled"
        self.description["zh-CN"] = "场景使能"

        self._observer: Callable[[str, bool], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            property_rule_id = self.__property_rule_id(o)
            property_rule_enable = self.__property_rule_enable(o)
            self._observer(property_rule_id, property_rule_enable)

    def observer(self, observer: Callable[[str, bool], None]) -> None:
        self._observer = observer

    @staticmethod
    def __property_rule_id(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[PropertyRuleId.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyRuleId.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyRuleId.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyRuleId.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __property_rule_enable(o: EventOperation) -> bool :
        argument: ArgumentOperation = o.arguments[PropertyRuleEnable.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyRuleEnable.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyRuleEnable.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyRuleEnable.IID))

        value: object = objects[0]
        if not isinstance(value, bool):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

