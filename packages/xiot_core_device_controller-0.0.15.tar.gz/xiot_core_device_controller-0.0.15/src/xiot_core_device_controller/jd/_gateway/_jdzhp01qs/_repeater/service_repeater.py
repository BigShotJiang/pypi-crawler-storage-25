from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_enable import PropertyEnable

# 中继
class ServiceRepeater(ServiceController):
    IID: int = 145
    TYPE: str = "urn:jd-spec:service:repeater:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Repeater"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "中继"

        self.properties[PropertyEnable.IID] = PropertyEnable()



    # 启用
    def property_enable(self) -> PropertyEnable:
        return self.properties[PropertyEnable.IID] # type: ignore[no-any-return]



