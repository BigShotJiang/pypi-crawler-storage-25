from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_test1 import ActionTest1
from .actions.action_test2 import ActionTest2
from .actions.action_test3 import ActionTest3
from .actions.action_test4 import ActionTest4
from .actions.action_test5 import ActionTest5


from .properties.property_red import PropertyRed
from .properties.property_green import PropertyGreen
from .properties.property_blue import PropertyBlue
from .properties.property_color4 import PropertyColor4
from .properties.property_brightness import PropertyBrightness
from .properties.property_hue import PropertyHue
from .properties.property_saturation import PropertySaturation
from .properties.property_color_temperature import PropertyColorTemperature
from .properties.property_color9 import PropertyColor9
from .properties.property_settings import PropertySettings

# 测试服务
class ServiceTest(ServiceController):
    IID: int = 999
    TYPE: str = "urn:jd-spec:service:test:000000d1:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "TEST Service"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "测试服务"

        self.properties[PropertyRed.IID] = PropertyRed()
        self.properties[PropertyGreen.IID] = PropertyGreen()
        self.properties[PropertyBlue.IID] = PropertyBlue()
        self.properties[PropertyColor4.IID] = PropertyColor4()
        self.properties[PropertyBrightness.IID] = PropertyBrightness()
        self.properties[PropertyHue.IID] = PropertyHue()
        self.properties[PropertySaturation.IID] = PropertySaturation()
        self.properties[PropertyColorTemperature.IID] = PropertyColorTemperature()
        self.properties[PropertyColor9.IID] = PropertyColor9()
        self.properties[PropertySettings.IID] = PropertySettings()

        self.actions[ActionTest1.IID] = ActionTest1()
        self.actions[ActionTest2.IID] = ActionTest2()
        self.actions[ActionTest3.IID] = ActionTest3()
        self.actions[ActionTest4.IID] = ActionTest4()
        self.actions[ActionTest5.IID] = ActionTest5()


    # 红色
    def property_red(self) -> PropertyRed:
        return self.properties[PropertyRed.IID] # type: ignore[no-any-return]

    # 绿色
    def property_green(self) -> PropertyGreen:
        return self.properties[PropertyGreen.IID] # type: ignore[no-any-return]

    # 蓝色
    def property_blue(self) -> PropertyBlue:
        return self.properties[PropertyBlue.IID] # type: ignore[no-any-return]

    # 颜色
    def property_color4(self) -> PropertyColor4:
        return self.properties[PropertyColor4.IID] # type: ignore[no-any-return]

    # 亮度
    def property_brightness(self) -> PropertyBrightness:
        return self.properties[PropertyBrightness.IID] # type: ignore[no-any-return]

    # 色度
    def property_hue(self) -> PropertyHue:
        return self.properties[PropertyHue.IID] # type: ignore[no-any-return]

    # 饱和度
    def property_saturation(self) -> PropertySaturation:
        return self.properties[PropertySaturation.IID] # type: ignore[no-any-return]

    # 色温
    def property_color_temperature(self) -> PropertyColorTemperature:
        return self.properties[PropertyColorTemperature.IID] # type: ignore[no-any-return]

    # 颜色
    def property_color9(self) -> PropertyColor9:
        return self.properties[PropertyColor9.IID] # type: ignore[no-any-return]

    # 设置
    def property_settings(self) -> PropertySettings:
        return self.properties[PropertySettings.IID] # type: ignore[no-any-return]


    # 测试方法1（只有参数）
    def action_test1(self) -> ActionTest1:
        return self.actions[ActionTest1.IID] # type: ignore[no-any-return]

    # 测试方法2（有参数、有结果）
    def action_test2(self) -> ActionTest2:
        return self.actions[ActionTest2.IID] # type: ignore[no-any-return]

    # 测试方法3（组合属性）
    def action_test3(self) -> ActionTest3:
        return self.actions[ActionTest3.IID] # type: ignore[no-any-return]

    # 测试方法4（组合属性）
    def action_test4(self) -> ActionTest4:
        return self.actions[ActionTest4.IID] # type: ignore[no-any-return]

    # 测试方法5（嵌套组合属性）
    def action_test5(self) -> ActionTest5:
        return self.actions[ActionTest5.IID] # type: ignore[no-any-return]


