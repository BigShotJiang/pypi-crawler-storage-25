from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 亮度
class PropertyBrightness(PropertyController[int]):
    IID: int = 2
    TYPE: str = "urn:jd-spec:property:brightness:00000015:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=True, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Brightness"
        self.description["zh-CN"] = "亮度"

        self.constraint_value = ValueRange(DataFormat.UINT8,
            min_ = 0,
            max_ = 100,
            step_ = 1
        )


