from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 格式
class PropertyFormat(PropertyController[int]):
    IID: int = 1
    TYPE: str = "urn:jd-spec:property:format:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT8
        )
        self.description["en-US"] = "Format"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "格式"

        value_list: list[ValueDefinition[int]] = []
        desc_0: Dict[str, str] = {
            "en-US": "",
            "zh-CN": "",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 0, description = desc_0))

        desc_1: Dict[str, str] = {
            "en-US": "",
            "zh-CN": "",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 1, description = desc_1))

        desc_2: Dict[str, str] = {
            "en-US": "",
            "zh-CN": "",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT8, raw_value = 2, description = desc_2))

        self.constraint_value = ValueList(value_list)


