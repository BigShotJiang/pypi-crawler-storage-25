from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_permit_join import ActionPermitJoin
from .actions.action_forbid_join import ActionForbidJoin
from .actions.action_remove_device import ActionRemoveDevice

from .events.event_device_removed import EventDeviceRemoved
from .events.event_device_added import EventDeviceAdded

from .properties.property_did import PropertyDid
from .properties.property_time_out import PropertyTimeOut
from .properties.property_pid import PropertyPid
from .properties.property_device_type import PropertyDeviceType
from .properties.property_device_info_c import PropertyDeviceInfoC

# zigbee设备管理服务
class ServiceZigbeeDeviceManagement(ServiceController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:service:zigbee-device-management:00000e77:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "zigbee-device-management"
        self.description["zh-CN"] = "zigbee设备管理服务"

        self.properties[PropertyDid.IID] = PropertyDid()
        self.properties[PropertyTimeOut.IID] = PropertyTimeOut()
        self.properties[PropertyPid.IID] = PropertyPid()
        self.properties[PropertyDeviceType.IID] = PropertyDeviceType()
        self.properties[PropertyDeviceInfoC.IID] = PropertyDeviceInfoC()

        self.actions[ActionPermitJoin.IID] = ActionPermitJoin()
        self.actions[ActionForbidJoin.IID] = ActionForbidJoin()
        self.actions[ActionRemoveDevice.IID] = ActionRemoveDevice()

        self.events[EventDeviceRemoved.IID] = EventDeviceRemoved()
        self.events[EventDeviceAdded.IID] = EventDeviceAdded()

    # 设备did
    def property_did(self) -> PropertyDid:
        return self.properties[PropertyDid.IID] # type: ignore[no-any-return]

    # 超时时间
    def property_time_out(self) -> PropertyTimeOut:
        return self.properties[PropertyTimeOut.IID] # type: ignore[no-any-return]

    # 产品ID
    def property_pid(self) -> PropertyPid:
        return self.properties[PropertyPid.IID] # type: ignore[no-any-return]

    # 设备类型
    def property_device_type(self) -> PropertyDeviceType:
        return self.properties[PropertyDeviceType.IID] # type: ignore[no-any-return]

    # 设备信息
    def property_device_info_c(self) -> PropertyDeviceInfoC:
        return self.properties[PropertyDeviceInfoC.IID] # type: ignore[no-any-return]


    # 开启组网
    def action_permit_join(self) -> ActionPermitJoin:
        return self.actions[ActionPermitJoin.IID] # type: ignore[no-any-return]

    # 关闭组网
    def action_forbid_join(self) -> ActionForbidJoin:
        return self.actions[ActionForbidJoin.IID] # type: ignore[no-any-return]

    # 删除设备
    def action_remove_device(self) -> ActionRemoveDevice:
        return self.actions[ActionRemoveDevice.IID] # type: ignore[no-any-return]


    # 设备删除
    def event_device_removed(self) -> EventDeviceRemoved:
        return self.events[EventDeviceRemoved.IID] # type: ignore[no-any-return]

    # 设备添加
    def event_device_added(self) -> EventDeviceAdded:
        return self.events[EventDeviceAdded.IID] # type: ignore[no-any-return]

