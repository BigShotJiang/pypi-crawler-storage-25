from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 设备状态
class PropertyStatus(PropertyController[int]):
    IID: int = 13
    TYPE: str = "urn:jd-spec:property:status:00000fa7:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT16
        )
        self.description["en-US"] = "Status"
        self.description["zh-CN"] = "设备状态"

        value_list: list[ValueDefinition[int]] = []
        desc_0: Dict[str, str] = {
            "en-US": "Fresh Keeping",
            "zh-CN": "保鲜模式",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT16, raw_value = 2, description = desc_0))

        desc_1: Dict[str, str] = {
            "en-US": "Rinsing",
            "zh-CN": "漂洗模式",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT16, raw_value = 3, description = desc_1))

        desc_2: Dict[str, str] = {
            "en-US": "Purifing Water",
            "zh-CN": "净水模式",
        }
        value_list.append(ValueDefinition(fmt = DataFormat.UINT16, raw_value = 4, description = desc_2))

        self.constraint_value = ValueList(value_list)


