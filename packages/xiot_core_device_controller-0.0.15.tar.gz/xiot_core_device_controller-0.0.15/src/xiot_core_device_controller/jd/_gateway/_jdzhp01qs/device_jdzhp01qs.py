from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._button128.service_button128 import ServiceButton128
from ._deviceinformation.service_device_information import ServiceDeviceInformation
from ._button129.service_button129 import ServiceButton129
from ._button130.service_button130 import ServiceButton130
from ._debug.service_debug import ServiceDebug
from ._button131.service_button131 import ServiceButton131
from ._groupmanagement.service_group_management import ServiceGroupManagement
from ._button132.service_button132 import ServiceButton132
from ._otamanagement.service_ota_management import ServiceOtaManagement
from ._button133.service_button133 import ServiceButton133
from ._bledevicemanagement.service_ble_device_management import ServiceBleDeviceManagement
from ._button134.service_button134 import ServiceButton134
from ._zigbeedevicemanagement.service_zigbee_device_management import ServiceZigbeeDeviceManagement
from ._button135.service_button135 import ServiceButton135
from ._rulemanagement.service_rule_management import ServiceRuleManagement
from ._button136.service_button136 import ServiceButton136
from ._button137.service_button137 import ServiceButton137
from ._button138.service_button138 import ServiceButton138
from ._button139.service_button139 import ServiceButton139
from ._lightpanel140.service_light_panel140 import ServiceLightPanel140
from ._lightpanel141.service_light_panel141 import ServiceLightPanel141
from ._curtainpanel142.service_curtain_panel142 import ServiceCurtainPanel142
from ._curtainpanel143.service_curtain_panel143 import ServiceCurtainPanel143
from ._voice.service_voice import ServiceVoice
from ._systemsetup.service_system_setup import ServiceSystemSetup
from ._repeater.service_repeater import ServiceRepeater
from ._switch18.service_switch18 import ServiceSwitch18
from ._multiswitchcontrol.service_multi_switch_control import ServiceMultiSwitchControl
from ._switch19.service_switch19 import ServiceSwitch19
from ._switch20.service_switch20 import ServiceSwitch20
from ._desktopmanagement.service_desktop_management import ServiceDesktopManagement
from ._recoverysystem.service_recovery_system import ServiceRecoverySystem
from ._test.service_test import ServiceTest

# 智慧屏4英寸
@register_device
class DeviceJdzhp01qs(DeviceController):
    TYPE: str = "urn:jd-spec:device:gateway:0000012d:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(DeviceType(string = self.TYPE))

        self.description["en-US"] = "Smart Screen 4 inch"
        self.description["zh-CN"] = "智慧屏4英寸"

        self.services[ServiceButton128.IID] = ServiceButton128()
        self.services[ServiceDeviceInformation.IID] = ServiceDeviceInformation()
        self.services[ServiceButton129.IID] = ServiceButton129()
        self.services[ServiceButton130.IID] = ServiceButton130()
        self.services[ServiceDebug.IID] = ServiceDebug()
        self.services[ServiceButton131.IID] = ServiceButton131()
        self.services[ServiceGroupManagement.IID] = ServiceGroupManagement()
        self.services[ServiceButton132.IID] = ServiceButton132()
        self.services[ServiceOtaManagement.IID] = ServiceOtaManagement()
        self.services[ServiceButton133.IID] = ServiceButton133()
        self.services[ServiceBleDeviceManagement.IID] = ServiceBleDeviceManagement()
        self.services[ServiceButton134.IID] = ServiceButton134()
        self.services[ServiceZigbeeDeviceManagement.IID] = ServiceZigbeeDeviceManagement()
        self.services[ServiceButton135.IID] = ServiceButton135()
        self.services[ServiceRuleManagement.IID] = ServiceRuleManagement()
        self.services[ServiceButton136.IID] = ServiceButton136()
        self.services[ServiceButton137.IID] = ServiceButton137()
        self.services[ServiceButton138.IID] = ServiceButton138()
        self.services[ServiceButton139.IID] = ServiceButton139()
        self.services[ServiceLightPanel140.IID] = ServiceLightPanel140()
        self.services[ServiceLightPanel141.IID] = ServiceLightPanel141()
        self.services[ServiceCurtainPanel142.IID] = ServiceCurtainPanel142()
        self.services[ServiceCurtainPanel143.IID] = ServiceCurtainPanel143()
        self.services[ServiceVoice.IID] = ServiceVoice()
        self.services[ServiceSystemSetup.IID] = ServiceSystemSetup()
        self.services[ServiceRepeater.IID] = ServiceRepeater()
        self.services[ServiceSwitch18.IID] = ServiceSwitch18()
        self.services[ServiceMultiSwitchControl.IID] = ServiceMultiSwitchControl()
        self.services[ServiceSwitch19.IID] = ServiceSwitch19()
        self.services[ServiceSwitch20.IID] = ServiceSwitch20()
        self.services[ServiceDesktopManagement.IID] = ServiceDesktopManagement()
        self.services[ServiceRecoverySystem.IID] = ServiceRecoverySystem()
        self.services[ServiceTest.IID] = ServiceTest()

    # 按键 1
    def service_button128(self) -> ServiceButton128:
        return self.services[ServiceButton128.IID] # type: ignore[no-any-return]

    # 设备信息
    def service_device_information(self) -> ServiceDeviceInformation:
        return self.services[ServiceDeviceInformation.IID] # type: ignore[no-any-return]

    # 按键 2
    def service_button129(self) -> ServiceButton129:
        return self.services[ServiceButton129.IID] # type: ignore[no-any-return]

    # 按键 3
    def service_button130(self) -> ServiceButton130:
        return self.services[ServiceButton130.IID] # type: ignore[no-any-return]

    # 调试
    def service_debug(self) -> ServiceDebug:
        return self.services[ServiceDebug.IID] # type: ignore[no-any-return]

    # 按键 4
    def service_button131(self) -> ServiceButton131:
        return self.services[ServiceButton131.IID] # type: ignore[no-any-return]

    # 组管理
    def service_group_management(self) -> ServiceGroupManagement:
        return self.services[ServiceGroupManagement.IID] # type: ignore[no-any-return]

    # 按键 5
    def service_button132(self) -> ServiceButton132:
        return self.services[ServiceButton132.IID] # type: ignore[no-any-return]

    # ota管理服务
    def service_ota_management(self) -> ServiceOtaManagement:
        return self.services[ServiceOtaManagement.IID] # type: ignore[no-any-return]

    # 按键 6
    def service_button133(self) -> ServiceButton133:
        return self.services[ServiceButton133.IID] # type: ignore[no-any-return]

    # 蓝牙设备管理服务
    def service_ble_device_management(self) -> ServiceBleDeviceManagement:
        return self.services[ServiceBleDeviceManagement.IID] # type: ignore[no-any-return]

    # 按键 7
    def service_button134(self) -> ServiceButton134:
        return self.services[ServiceButton134.IID] # type: ignore[no-any-return]

    # zigbee设备管理服务
    def service_zigbee_device_management(self) -> ServiceZigbeeDeviceManagement:
        return self.services[ServiceZigbeeDeviceManagement.IID] # type: ignore[no-any-return]

    # 按键 8
    def service_button135(self) -> ServiceButton135:
        return self.services[ServiceButton135.IID] # type: ignore[no-any-return]

    # 场景管理服务
    def service_rule_management(self) -> ServiceRuleManagement:
        return self.services[ServiceRuleManagement.IID] # type: ignore[no-any-return]

    # 按键 9
    def service_button136(self) -> ServiceButton136:
        return self.services[ServiceButton136.IID] # type: ignore[no-any-return]

    # 按键 10
    def service_button137(self) -> ServiceButton137:
        return self.services[ServiceButton137.IID] # type: ignore[no-any-return]

    # 按键 11
    def service_button138(self) -> ServiceButton138:
        return self.services[ServiceButton138.IID] # type: ignore[no-any-return]

    # 按键 12
    def service_button139(self) -> ServiceButton139:
        return self.services[ServiceButton139.IID] # type: ignore[no-any-return]

    # 灯控面板
    def service_light_panel140(self) -> ServiceLightPanel140:
        return self.services[ServiceLightPanel140.IID] # type: ignore[no-any-return]

    # 灯控面板
    def service_light_panel141(self) -> ServiceLightPanel141:
        return self.services[ServiceLightPanel141.IID] # type: ignore[no-any-return]

    # 窗帘面板
    def service_curtain_panel142(self) -> ServiceCurtainPanel142:
        return self.services[ServiceCurtainPanel142.IID] # type: ignore[no-any-return]

    # 窗帘面板
    def service_curtain_panel143(self) -> ServiceCurtainPanel143:
        return self.services[ServiceCurtainPanel143.IID] # type: ignore[no-any-return]

    # 语音服务
    def service_voice(self) -> ServiceVoice:
        return self.services[ServiceVoice.IID] # type: ignore[no-any-return]

    # 系统设置
    def service_system_setup(self) -> ServiceSystemSetup:
        return self.services[ServiceSystemSetup.IID] # type: ignore[no-any-return]

    # 中继
    def service_repeater(self) -> ServiceRepeater:
        return self.services[ServiceRepeater.IID] # type: ignore[no-any-return]

    # 开关 1
    def service_switch18(self) -> ServiceSwitch18:
        return self.services[ServiceSwitch18.IID] # type: ignore[no-any-return]

    # 多路开关控制
    def service_multi_switch_control(self) -> ServiceMultiSwitchControl:
        return self.services[ServiceMultiSwitchControl.IID] # type: ignore[no-any-return]

    # 开关 2
    def service_switch19(self) -> ServiceSwitch19:
        return self.services[ServiceSwitch19.IID] # type: ignore[no-any-return]

    # 开关 3
    def service_switch20(self) -> ServiceSwitch20:
        return self.services[ServiceSwitch20.IID] # type: ignore[no-any-return]

    # 桌面管理
    def service_desktop_management(self) -> ServiceDesktopManagement:
        return self.services[ServiceDesktopManagement.IID] # type: ignore[no-any-return]

    # Recovery系统
    def service_recovery_system(self) -> ServiceRecoverySystem:
        return self.services[ServiceRecoverySystem.IID] # type: ignore[no-any-return]

    # 测试服务
    def service_test(self) -> ServiceTest:
        return self.services[ServiceTest.IID] # type: ignore[no-any-return]

