from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_group_did import PropertyGroupDid

from ..properties.property_group_did import PropertyGroupDid

import logging

_LOGGER = logging.getLogger(__name__)

# 删除组
class ActionDeleteGroups(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:delete-groups:00000b59:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Delete Groups"
        self.description["zh-CN"] = "删除组"

    # Action 出参
    class Result:
        # 组did列表
        property_group_dids: list[str]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[PropertyGroupDid.IID]
            if _1 is not None:
                self.property_group_dids = [str(item) for item in _1.values]
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyGroupDid)

            return

    # 执行 Action 调用
    async def invoke(self, property_group_dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_group_dids is None or len(property_group_dids) == 0:
            raise ValueError("参数property_group_dids不能为空")
        arguments[PropertyGroupDid.IID] = ArgumentOperation(piid = PropertyGroupDid.IID, values = property_group_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionDeleteGroups.Result(out)
