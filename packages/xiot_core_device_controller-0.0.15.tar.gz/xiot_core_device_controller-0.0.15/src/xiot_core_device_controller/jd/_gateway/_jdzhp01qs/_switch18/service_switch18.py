from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_start_easylink import ActionStartEasylink
from .actions.action_delete_easylink import ActionDeleteEasylink


from .properties.property_on import PropertyOn
from .properties.property_name import PropertyName
from .properties.property_enable import PropertyEnable
from .properties.property_power_on_state import PropertyPowerOnState

# 开关 1
class ServiceSwitch18(ServiceController):
    IID: int = 18
    TYPE: str = "urn:jd-spec:service:switch:00000002:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Switch 1"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "开关 1"

        self.properties[PropertyOn.IID] = PropertyOn()
        self.properties[PropertyName.IID] = PropertyName()
        self.properties[PropertyEnable.IID] = PropertyEnable()
        self.properties[PropertyPowerOnState.IID] = PropertyPowerOnState()

        self.actions[ActionStartEasylink.IID] = ActionStartEasylink()
        self.actions[ActionDeleteEasylink.IID] = ActionDeleteEasylink()


    # 开关
    def property_on(self) -> PropertyOn:
        return self.properties[PropertyOn.IID] # type: ignore[no-any-return]

    # 名称
    def property_name(self) -> PropertyName:
        return self.properties[PropertyName.IID] # type: ignore[no-any-return]

    # 启用
    def property_enable(self) -> PropertyEnable:
        return self.properties[PropertyEnable.IID] # type: ignore[no-any-return]

    # 上电开启
    def property_power_on_state(self) -> PropertyPowerOnState:
        return self.properties[PropertyPowerOnState.IID] # type: ignore[no-any-return]


    # 打开爽连
    def action_start_easylink(self) -> ActionStartEasylink:
        return self.actions[ActionStartEasylink.IID] # type: ignore[no-any-return]

    # 删除爽连
    def action_delete_easylink(self) -> ActionDeleteEasylink:
        return self.actions[ActionDeleteEasylink.IID] # type: ignore[no-any-return]


