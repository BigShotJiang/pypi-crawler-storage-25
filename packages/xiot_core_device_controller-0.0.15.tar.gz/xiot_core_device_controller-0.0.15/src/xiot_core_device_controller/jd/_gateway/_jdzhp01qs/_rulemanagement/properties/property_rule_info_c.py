from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_rule_name import PropertyRuleName
from .property_rule_id import PropertyRuleId
from .property_rule_enable import PropertyRuleEnable
from .property_rule_content import PropertyRuleContent
from .property_content_formatter import PropertyContentFormatter
from .property_roomid import PropertyRoomid
from .property_r_description import PropertyRDescription
from .property_iconid import PropertyIconid

class PropertyRuleInfoCValue:
    property_rule_name: PropertyRuleName = PropertyRuleName()
    property_rule_id: PropertyRuleId = PropertyRuleId()
    property_rule_enable: PropertyRuleEnable = PropertyRuleEnable()
    property_rule_content: PropertyRuleContent = PropertyRuleContent()
    property_content_formatter: PropertyContentFormatter = PropertyContentFormatter()
    property_roomid: PropertyRoomid = PropertyRoomid()
    property_r_description: PropertyRDescription = PropertyRDescription()
    property_iconid: PropertyIconid = PropertyIconid()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_rule_name.put_value(value[PropertyRuleName.IID])
            self.property_rule_id.put_value(value[PropertyRuleId.IID])
            self.property_rule_enable.put_value(value[PropertyRuleEnable.IID])
            self.property_rule_content.put_value(value[PropertyRuleContent.IID])
            self.property_content_formatter.put_value(value[PropertyContentFormatter.IID])
            self.property_roomid.put_value(value[PropertyRoomid.IID])
            self.property_r_description.put_value(value[PropertyRDescription.IID])
            self.property_iconid.put_value(value[PropertyIconid.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyRuleName.IID: self.property_rule_name.get_value(),
            PropertyRuleId.IID: self.property_rule_id.get_value(),
            PropertyRuleEnable.IID: self.property_rule_enable.get_value(),
            PropertyRuleContent.IID: self.property_rule_content.get_value(),
            PropertyContentFormatter.IID: self.property_content_formatter.get_value(),
            PropertyRoomid.IID: self.property_roomid.get_value(),
            PropertyRDescription.IID: self.property_r_description.get_value(),
            PropertyIconid.IID: self.property_iconid.get_value(),
        }
        return _map

# 规则信息
class PropertyRuleInfoC(PropertyController[PropertyRuleInfoCValue]):
    IID: int = 6
    TYPE: str = "urn:jd-spec:property:rule-info-c:00001c3b:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "rule-info-c"
        self.description["zh-CN"] = "规则信息"



    def to_map(self, value: Optional[PropertyRuleInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
