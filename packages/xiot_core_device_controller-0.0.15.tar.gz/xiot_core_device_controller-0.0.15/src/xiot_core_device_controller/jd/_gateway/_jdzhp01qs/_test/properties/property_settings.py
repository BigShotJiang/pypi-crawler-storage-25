from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_color4 import PropertyColor4
from .property_brightness import PropertyBrightness
from .property_hue import PropertyHue

class PropertySettingsValue:
    property_color4: PropertyColor4 = PropertyColor4()
    property_brightness: PropertyBrightness = PropertyBrightness()
    property_hue: PropertyHue = PropertyHue()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_color4.put_value(value[PropertyColor4.IID])
            self.property_brightness.put_value(value[PropertyBrightness.IID])
            self.property_hue.put_value(value[PropertyHue.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyColor4.IID: self.property_color4.to_map(self.property_color4.get_value()),
            PropertyBrightness.IID: self.property_brightness.get_value(),
            PropertyHue.IID: self.property_hue.get_value(),
        }
        return _map

# 设置
class PropertySettings(PropertyController[PropertySettingsValue]):
    IID: int = 10
    TYPE: str = "urn:jd-spec:property:settings:0000000a:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "Settings"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "设置"



    def to_map(self, value: Optional[PropertySettingsValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
