from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_reboot_system import ActionRebootSystem
from .actions.action_logout import ActionLogout


from .properties.property_mute import PropertyMute
from .properties.property_voice_assistant_enabled import PropertyVoiceAssistantEnabled

# 系统设置
class ServiceSystemSetup(ServiceController):
    IID: int = 17
    TYPE: str = "urn:jd-spec:service:system-setup:00000e7e:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "System Setup"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "系统设置"

        self.properties[PropertyMute.IID] = PropertyMute()
        self.properties[PropertyVoiceAssistantEnabled.IID] = PropertyVoiceAssistantEnabled()

        self.actions[ActionRebootSystem.IID] = ActionRebootSystem()
        self.actions[ActionLogout.IID] = ActionLogout()


    # 静音
    def property_mute(self) -> PropertyMute:
        return self.properties[PropertyMute.IID] # type: ignore[no-any-return]

    # 语音助手使能
    def property_voice_assistant_enabled(self) -> PropertyVoiceAssistantEnabled:
        return self.properties[PropertyVoiceAssistantEnabled.IID] # type: ignore[no-any-return]


    # 重启系统
    def action_reboot_system(self) -> ActionRebootSystem:
        return self.actions[ActionRebootSystem.IID] # type: ignore[no-any-return]

    # 登出
    def action_logout(self) -> ActionLogout:
        return self.actions[ActionLogout.IID] # type: ignore[no-any-return]


