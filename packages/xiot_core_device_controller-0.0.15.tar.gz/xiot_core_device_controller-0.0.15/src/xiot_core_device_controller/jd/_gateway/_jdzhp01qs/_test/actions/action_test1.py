from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_red import PropertyRed


import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法1（只有参数）
class ActionTest1(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Test 1"
        self.description["zh-CN"] = "测试方法1（只有参数）"


    # 执行 Action 调用
    async def invoke(self, property_red: Optional[int]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_red is None:
            raise ValueError("参数property_red不能为空")
        arguments[PropertyRed.IID] = ArgumentOperation(piid = PropertyRed.IID, value = property_red)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
