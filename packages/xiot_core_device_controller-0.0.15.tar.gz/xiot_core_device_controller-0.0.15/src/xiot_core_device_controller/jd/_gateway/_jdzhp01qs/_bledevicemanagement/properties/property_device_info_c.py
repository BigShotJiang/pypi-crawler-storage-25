from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.data.value.vcombination import Vcombination
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController

from .property_did import PropertyDid
from .property_device_type import PropertyDeviceType
from .property_rssi import PropertyRssi

class PropertyDeviceInfoCValue:
    property_did: PropertyDid = PropertyDid()
    property_device_type: PropertyDeviceType = PropertyDeviceType()
    property_rssi: PropertyRssi = PropertyRssi()

    def __init__(self, value: Optional[Dict[int, object]]) -> None:
        if value is not None:
            self.property_did.put_value(value[PropertyDid.IID])
            self.property_device_type.put_value(value[PropertyDeviceType.IID])
            self.property_rssi.put_value(value[PropertyRssi.IID])
        return

    def to_map(self) -> Dict[int, object]:
        _map: Dict[int, object] = {
            PropertyDid.IID: self.property_did.get_value(),
            PropertyDeviceType.IID: self.property_device_type.get_value(),
            PropertyRssi.IID: self.property_rssi.get_value(),
        }
        return _map

# 设备信息
class PropertyDeviceInfoC(PropertyController[PropertyDeviceInfoCValue]):
    IID: int = 6
    TYPE: str = "urn:jd-spec:property:device-info-c:00001c2f:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.COMBINATION
        )
        self.description["en-US"] = "device-info-c"
        self.description["zh-CN"] = "设备信息"



    def to_map(self, value: Optional[PropertyDeviceInfoCValue]) -> Dict[int, object]:
        if value is not None:
            return value.to_map()
        return {}
