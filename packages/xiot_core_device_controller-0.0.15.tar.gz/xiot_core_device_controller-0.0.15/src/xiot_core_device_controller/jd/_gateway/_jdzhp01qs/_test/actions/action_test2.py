from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_red import PropertyRed
from ..properties.property_green import PropertyGreen
from ..properties.property_blue import PropertyBlue

from ..properties.property_brightness import PropertyBrightness
from ..properties.property_hue import PropertyHue
from ..properties.property_saturation import PropertySaturation
from ..properties.property_color_temperature import PropertyColorTemperature

import logging

_LOGGER = logging.getLogger(__name__)

# 测试方法2（有参数、有结果）
class ActionTest2(ActionController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:action:test:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Test 2"
        self.description["zh-CN"] = "测试方法2（有参数、有结果）"

    # Action 出参
    class Result:
        # 亮度
        property_brightness: int
        # 色度
        property_hue: int
        # 饱和度
        property_saturation: int
        # 色温
        property_color_temperature: int

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _5: Optional[ArgumentOperation] = result[PropertyBrightness.IID]
            if _5 is not None:
                v = _5.values[0]
                if isinstance(v, int):
                    self.property_brightness = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyBrightness)

            _6: Optional[ArgumentOperation] = result[PropertyHue.IID]
            if _6 is not None:
                v = _6.values[0]
                if isinstance(v, int):
                    self.property_hue = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyHue)

            _7: Optional[ArgumentOperation] = result[PropertySaturation.IID]
            if _7 is not None:
                v = _7.values[0]
                if isinstance(v, int):
                    self.property_saturation = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertySaturation)

            _8: Optional[ArgumentOperation] = result[PropertyColorTemperature.IID]
            if _8 is not None:
                v = _8.values[0]
                if isinstance(v, int):
                    self.property_color_temperature = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyColorTemperature)

            return

    # 执行 Action 调用
    async def invoke(self, property_red: Optional[int], property_green: Optional[int], property_blue: Optional[int]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_red is None:
            raise ValueError("参数property_red不能为空")
        arguments[PropertyRed.IID] = ArgumentOperation(piid = PropertyRed.IID, value = property_red)

        if property_green is None:
            raise ValueError("参数property_green不能为空")
        arguments[PropertyGreen.IID] = ArgumentOperation(piid = PropertyGreen.IID, value = property_green)

        if property_blue is None:
            raise ValueError("参数property_blue不能为空")
        arguments[PropertyBlue.IID] = ArgumentOperation(piid = PropertyBlue.IID, value = property_blue)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionTest2.Result(out)
