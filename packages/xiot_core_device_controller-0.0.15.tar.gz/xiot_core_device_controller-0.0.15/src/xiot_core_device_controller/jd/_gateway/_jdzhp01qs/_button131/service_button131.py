from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_click import ActionClick
from .actions.action_send_easylink import ActionSendEasylink

from .events.event_clicked import EventClicked

from .properties.property_name import PropertyName

# 按键 4
class ServiceButton131(ServiceController):
    IID: int = 131
    TYPE: str = "urn:jd-spec:service:button:00000001:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Button 4"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "按键 4"

        self.properties[PropertyName.IID] = PropertyName()

        self.actions[ActionClick.IID] = ActionClick()
        self.actions[ActionSendEasylink.IID] = ActionSendEasylink()

        self.events[EventClicked.IID] = EventClicked()

    # 名称
    def property_name(self) -> PropertyName:
        return self.properties[PropertyName.IID] # type: ignore[no-any-return]


    # 点击
    def action_click(self) -> ActionClick:
        return self.actions[ActionClick.IID] # type: ignore[no-any-return]

    # 发出爽连指令
    def action_send_easylink(self) -> ActionSendEasylink:
        return self.actions[ActionSendEasylink.IID] # type: ignore[no-any-return]


    # 已被点击
    def event_clicked(self) -> EventClicked:
        return self.events[EventClicked.IID] # type: ignore[no-any-return]

