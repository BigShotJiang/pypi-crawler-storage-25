from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_desk_card_number import PropertyDeskCardNumber
from ..properties.property_content import PropertyContent


import logging

_LOGGER = logging.getLogger(__name__)

# 添加桌面卡片
class ActionAddDesktopCard(ActionController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:action:add-desktop-card:00000e2f:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Add Desktop Card"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "添加桌面卡片"


    # 执行 Action 调用
    async def invoke(self, property_desk_card_number: Optional[int], property_content: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_desk_card_number is None:
            raise ValueError("参数property_desk_card_number不能为空")
        arguments[PropertyDeskCardNumber.IID] = ArgumentOperation(piid = PropertyDeskCardNumber.IID, value = property_desk_card_number)

        if property_content is None:
            raise ValueError("参数property_content不能为空")
        arguments[PropertyContent.IID] = ArgumentOperation(piid = PropertyContent.IID, value = property_content)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
