from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_rule_id import PropertyRuleId

from ..properties.property_rule_info_c import PropertyRuleInfoC
from ..properties.property_rule_info_c import PropertyRuleInfoCValue

import logging

_LOGGER = logging.getLogger(__name__)

# 查询场景
class ActionGetRules6(ActionController):
    IID: int = 6
    TYPE: str = "urn:jd-spec:action:get-rules:00000d55:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "get-rule"
        self.description["zh-CN"] = "查询场景"

    # Action 出参
    class Result:
        # 规则信息
        property_rule_info_c: PropertyRuleInfoCValue

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _6: Optional[ArgumentOperation] = result[PropertyRuleInfoC.IID]
            if _6 is not None:
                v = _6.values[0]
                if isinstance(v, dict):
                    self.property_rule_info_c = PropertyRuleInfoCValue(v)
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyRuleInfoC)

            return

    # 执行 Action 调用
    async def invoke(self, property_rule_id: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_rule_id is None:
            raise ValueError("参数property_rule_id不能为空")
        arguments[PropertyRuleId.IID] = ArgumentOperation(piid = PropertyRuleId.IID, value = property_rule_id)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionGetRules6.Result(out)
