from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 超时时间
class PropertyTimeOut(PropertyController[int]):
    IID: int = 2
    TYPE: str = "urn:jd-spec:property:time-out:00001c30:jd:jdzhp01qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT16
        )
        self.description["en-US"] = "time-out"
        self.description["zh-CN"] = "超时时间"

        self.constraint_value = ValueRange(DataFormat.UINT16,
            min_ = 1,
            max_ = 300,
            step_ = 1
        )


