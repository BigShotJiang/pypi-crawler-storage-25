from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController


from ..properties.property_device_info_c import PropertyDeviceInfoC
from ..properties.property_device_info_c import PropertyDeviceInfoCValue

import logging

_LOGGER = logging.getLogger(__name__)

# 读取扫描结果
class ActionGetScanResult(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:get-scan-result:00000d4b:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "get-scan-result"
        self.description["zh-CN"] = "读取扫描结果"

    # Action 出参
    class Result:
        # 设备信息列表
        property_device_info_cs: list[PropertyDeviceInfoCValue]

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _6: Optional[ArgumentOperation] = result[PropertyDeviceInfoC.IID]
            if _6 is not None:
                self.property_device_info_cs = [PropertyDeviceInfoCValue(value=v) for v in _6.values if isinstance(v, dict)]
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyDeviceInfoC)

            return

    # 执行 Action 调用
    async def invoke(self, ) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionGetScanResult.Result(out)
