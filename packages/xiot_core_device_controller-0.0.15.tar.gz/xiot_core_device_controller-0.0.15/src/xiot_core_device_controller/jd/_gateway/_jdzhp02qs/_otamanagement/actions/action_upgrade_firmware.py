from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_firmware_info_c import PropertyFirmwareInfoC
from ..properties.property_firmware_info_c import PropertyFirmwareInfoCValue
from ..properties.property_did import PropertyDid


import logging

_LOGGER = logging.getLogger(__name__)

# 升级固件
class ActionUpgradeFirmware(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:upgrade-firmware:00000d49:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "upgrade-firmware"
        self.description["zh-CN"] = "升级固件"


    # 执行 Action 调用
    async def invoke(self, property_firmware_info_c: Optional[PropertyFirmwareInfoCValue], property_did: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_firmware_info_c is None:
            raise ValueError("参数property_firmware_info_c不能为空")
        arguments[PropertyFirmwareInfoC.IID] = ArgumentOperation(piid = PropertyFirmwareInfoC.IID, value = property_firmware_info_c.to_map())

        if property_did is None:
            raise ValueError("参数property_did不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, value = property_did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
