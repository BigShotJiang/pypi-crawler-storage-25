from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.property_code import PropertyCode
from ..properties.property_did import PropertyDid

# 固件升级失败
class EventFirmwareUpgradeFailed(EventController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:event:firmware-upgrade-failed:00000a2a:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "firmware-upgrade-failed"
        self.description["zh-CN"] = "固件升级失败"

        self._observer: Callable[[int, str], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            property_code = self.__property_code(o)
            property_did = self.__property_did(o)
            self._observer(property_code, property_did)

    def observer(self, observer: Callable[[int, str], None]) -> None:
        self._observer = observer

    @staticmethod
    def __property_code(o: EventOperation) -> int :
        argument: ArgumentOperation = o.arguments[PropertyCode.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyCode.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyCode.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyCode.IID))

        value: object = objects[0]
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __property_did(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[PropertyDid.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyDid.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyDid.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyDid.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

