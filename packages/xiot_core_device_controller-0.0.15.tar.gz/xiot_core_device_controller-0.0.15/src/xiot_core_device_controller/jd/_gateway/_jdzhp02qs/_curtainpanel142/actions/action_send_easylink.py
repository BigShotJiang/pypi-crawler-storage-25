from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController



import logging

_LOGGER = logging.getLogger(__name__)

# 发出爽连指令
class ActionSendEasylink(ActionController):
    IID: int = 4
    TYPE: str = "urn:jd-spec:action:send-easylink:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Send Easylink Command"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "发出爽连指令"


    # 执行 Action 调用
    async def invoke(self, ):
        arguments: Dict[int, ArgumentOperation] = {}

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
