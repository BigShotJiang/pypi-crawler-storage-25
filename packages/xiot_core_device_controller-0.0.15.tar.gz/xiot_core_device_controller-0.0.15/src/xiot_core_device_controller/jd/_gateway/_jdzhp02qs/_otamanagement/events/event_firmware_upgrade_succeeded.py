from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.property_firmware_revision import PropertyFirmwareRevision
from ..properties.property_did import PropertyDid

# 升级固件成功
class EventFirmwareUpgradeSucceeded(EventController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:event:firmware-upgrade-succeeded:00000a29:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "firmware-upgrade-succeeded"
        self.description["zh-CN"] = "升级固件成功"

        self._observer: Callable[[str, str], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            property_firmware_revision = self.__property_firmware_revision(o)
            property_did = self.__property_did(o)
            self._observer(property_firmware_revision, property_did)

    def observer(self, observer: Callable[[str, str], None]) -> None:
        self._observer = observer

    @staticmethod
    def __property_firmware_revision(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[PropertyFirmwareRevision.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyFirmwareRevision.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyFirmwareRevision.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyFirmwareRevision.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __property_did(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[PropertyDid.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyDid.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyDid.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyDid.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

