from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 固件类型
class PropertyFirmwareType(PropertyController[str]):
    IID: int = 9
    TYPE: str = "urn:jd-spec:property:firmware-type:00001c28:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.STRING
        )
        self.description["en-US"] = "firmware-type"
        self.description["zh-CN"] = "固件类型"



