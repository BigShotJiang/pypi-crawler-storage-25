from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_on import PropertyOn

# 中继
class ServiceRepeater(ServiceController):
    IID: int = 1025
    TYPE: str = "urn:jd-spec:service:repeater:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Repeater"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "中继"

        self.properties[PropertyOn.IID] = PropertyOn()



    # 开关
    def property_on(self) -> PropertyOn:
        return self.properties[PropertyOn.IID] # type: ignore[no-any-return]



