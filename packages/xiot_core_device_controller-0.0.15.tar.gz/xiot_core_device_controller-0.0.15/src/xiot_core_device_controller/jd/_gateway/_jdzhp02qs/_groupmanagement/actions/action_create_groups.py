from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_did import PropertyDid

from ..properties.property_group_did import PropertyGroupDid

import logging

_LOGGER = logging.getLogger(__name__)

# 创建组
class ActionCreateGroups(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:create-groups:00000b57:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Create Groups"
        self.description["zh-CN"] = "创建组"

    # Action 出参
    class Result:
        # 组did
        property_group_did: str

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _1: Optional[ArgumentOperation] = result[PropertyGroupDid.IID]
            if _1 is not None:
                v = _1.values[0]
                if isinstance(v, str):
                    self.property_group_did = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyGroupDid)

            return

    # 执行 Action 调用
    async def invoke(self, property_dids: Optional[list[str]]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_dids is None or len(property_dids) == 0:
            raise ValueError("参数property_dids不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, values = property_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionCreateGroups.Result(out)
