from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_time_out import PropertyTimeOut
from ..properties.property_did import PropertyDid


import logging

_LOGGER = logging.getLogger(__name__)

# 删除设备
class ActionRemoveDevice(ActionController):
    IID: int = 5
    TYPE: str = "urn:jd-spec:action:remove-device:00000d4c:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "remove-device"
        self.description["zh-CN"] = "删除设备"


    # 执行 Action 调用
    async def invoke(self, property_time_out: Optional[int], property_did: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_time_out is None:
            raise ValueError("参数property_time_out不能为空")
        arguments[PropertyTimeOut.IID] = ArgumentOperation(piid = PropertyTimeOut.IID, value = property_time_out)

        if property_did is None:
            raise ValueError("参数property_did不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, value = property_did)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
