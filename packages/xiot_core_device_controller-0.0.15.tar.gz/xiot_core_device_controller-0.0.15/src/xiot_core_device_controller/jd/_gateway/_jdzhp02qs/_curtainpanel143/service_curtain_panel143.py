from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_open_curtain import ActionOpenCurtain
from .actions.action_close_curtain import ActionCloseCurtain
from .actions.action_stop_curtain import ActionStopCurtain
from .actions.action_send_easylink import ActionSendEasylink


from .properties.property_target_position import PropertyTargetPosition

# 窗帘面板
class ServiceCurtainPanel143(ServiceController):
    IID: int = 143
    TYPE: str = "urn:jd-spec:service:curtain-panel:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Curtain Panel"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "窗帘面板"

        self.properties[PropertyTargetPosition.IID] = PropertyTargetPosition()

        self.actions[ActionOpenCurtain.IID] = ActionOpenCurtain()
        self.actions[ActionCloseCurtain.IID] = ActionCloseCurtain()
        self.actions[ActionStopCurtain.IID] = ActionStopCurtain()
        self.actions[ActionSendEasylink.IID] = ActionSendEasylink()


    # 目标位置
    def property_target_position(self) -> PropertyTargetPosition:
        return self.properties[PropertyTargetPosition.IID] # type: ignore[no-any-return]


    # 打开窗帘
    def action_open_curtain(self) -> ActionOpenCurtain:
        return self.actions[ActionOpenCurtain.IID] # type: ignore[no-any-return]

    # 关闭窗帘
    def action_close_curtain(self) -> ActionCloseCurtain:
        return self.actions[ActionCloseCurtain.IID] # type: ignore[no-any-return]

    # 暂停窗帘
    def action_stop_curtain(self) -> ActionStopCurtain:
        return self.actions[ActionStopCurtain.IID] # type: ignore[no-any-return]

    # 发出爽连指令
    def action_send_easylink(self) -> ActionSendEasylink:
        return self.actions[ActionSendEasylink.IID] # type: ignore[no-any-return]


