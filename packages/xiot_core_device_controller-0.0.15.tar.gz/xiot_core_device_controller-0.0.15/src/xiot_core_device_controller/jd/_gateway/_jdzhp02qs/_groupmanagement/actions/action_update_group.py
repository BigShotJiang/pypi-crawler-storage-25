from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_group_did import PropertyGroupDid
from ..properties.property_did import PropertyDid


import logging

_LOGGER = logging.getLogger(__name__)

# 更新组内设备
class ActionUpdateGroup(ActionController):
    IID: int = 7
    TYPE: str = "urn:jd-spec:action:update-group:00000bb9:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Update Group Device"
        self.description["zh-CN"] = "更新组内设备"


    # 执行 Action 调用
    async def invoke(self, property_group_did: Optional[str], property_dids: Optional[list[str]]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_group_did is None:
            raise ValueError("参数property_group_did不能为空")
        arguments[PropertyGroupDid.IID] = ArgumentOperation(piid = PropertyGroupDid.IID, value = property_group_did)

        if property_dids is None or len(property_dids) == 0:
            raise ValueError("参数property_dids不能为空")
        arguments[PropertyDid.IID] = ArgumentOperation(piid = PropertyDid.IID, values = property_dids)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
