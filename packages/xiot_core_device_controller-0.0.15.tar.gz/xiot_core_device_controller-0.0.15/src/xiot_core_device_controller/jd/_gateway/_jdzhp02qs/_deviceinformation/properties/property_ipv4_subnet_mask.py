from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 子网掩码
class PropertyIpv4SubnetMask(PropertyController[str]):
    IID: int = 4
    TYPE: str = "urn:jd-spec:property:ipv4-subnet-mask:00001db4:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.STRING
        )
        self.description["en-US"] = "Subnet Mask"
        self.description["zh-CN"] = "子网掩码"



