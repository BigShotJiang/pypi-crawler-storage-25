from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 蓝牙信号强度
class PropertyRssi(PropertyController[int]):
    IID: int = 5
    TYPE: str = "urn:jd-spec:property:rssi:000019c9:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.INT8
        )
        self.description["en-US"] = "rssi"
        self.description["zh-CN"] = "蓝牙信号强度"

        self.constraint_value = ValueRange(DataFormat.INT8,
            min_ = -128,
            max_ = 127,
            step_ = 1
        )


