from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 文件大小
class PropertyFileSize(PropertyController[int]):
    IID: int = 10
    TYPE: str = "urn:jd-spec:property:file-size:00001c29:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT32
        )
        self.description["en-US"] = "file-size"
        self.description["zh-CN"] = "文件大小"

        self.constraint_value = ValueRange(DataFormat.UINT32,
            min_ = 1,
            max_ = 1000000010,
            step_ = 1
        )


