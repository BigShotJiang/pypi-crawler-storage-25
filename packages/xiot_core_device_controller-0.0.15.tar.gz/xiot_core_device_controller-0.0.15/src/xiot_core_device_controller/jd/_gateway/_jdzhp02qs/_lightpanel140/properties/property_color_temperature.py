from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 色温
class PropertyColorTemperature(PropertyController[int]):
    IID: int = 3
    TYPE: str = "urn:jd-spec:property:color-temperature:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=True, notifiable=False),
            fmt = DataFormat.UINT16
        )
        self.description["en-US"] = "Color Temperature"
        self.description["zh-TW"] = ""
        self.description["zh-CN"] = "色温"

        self.constraint_value = ValueRange(DataFormat.UINT16,
            min_ = 2700,
            max_ = 6500,
            step_ = 1
        )


