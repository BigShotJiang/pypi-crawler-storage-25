from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 状态码
class PropertyStatusCode(PropertyController[int]):
    IID: int = 8
    TYPE: str = "urn:jd-spec:property:status-code:00001c30:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=False, writable=False, notifiable=False),
            fmt = DataFormat.UINT16
        )
        self.description["en-US"] = "status code"
        self.description["zh-CN"] = "状态码"



