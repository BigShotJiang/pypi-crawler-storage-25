from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_firmware_revision import PropertyFirmwareRevision
from .properties.property_manufacturer import PropertyManufacturer
from .properties.property_hardware_revision import PropertyHardwareRevision
from .properties.property_ipv4_subnet_mask import PropertyIpv4SubnetMask
from .properties.property_serial_number import PropertySerialNumber
from .properties.property_mac_address import PropertyMacAddress
from .properties.property_ip import PropertyIp
from .properties.property_support_time_configuration_for_automation import PropertySupportTimeConfigurationForAutomation
from .properties.property_support_scene_embed_for_automation import PropertySupportSceneEmbedForAutomation
from .properties.property_rssi import PropertyRssi
from .properties.property_gateway import PropertyGateway

# 设备信息
class ServiceDeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[PropertyFirmwareRevision.IID] = PropertyFirmwareRevision()
        self.properties[PropertyManufacturer.IID] = PropertyManufacturer()
        self.properties[PropertyHardwareRevision.IID] = PropertyHardwareRevision()
        self.properties[PropertyIpv4SubnetMask.IID] = PropertyIpv4SubnetMask()
        self.properties[PropertySerialNumber.IID] = PropertySerialNumber()
        self.properties[PropertyMacAddress.IID] = PropertyMacAddress()
        self.properties[PropertyIp.IID] = PropertyIp()
        self.properties[PropertySupportTimeConfigurationForAutomation.IID] = PropertySupportTimeConfigurationForAutomation()
        self.properties[PropertySupportSceneEmbedForAutomation.IID] = PropertySupportSceneEmbedForAutomation()
        self.properties[PropertyRssi.IID] = PropertyRssi()
        self.properties[PropertyGateway.IID] = PropertyGateway()



    # 固件版本
    def property_firmware_revision(self) -> PropertyFirmwareRevision:
        return self.properties[PropertyFirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def property_manufacturer(self) -> PropertyManufacturer:
        return self.properties[PropertyManufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def property_hardware_revision(self) -> PropertyHardwareRevision:
        return self.properties[PropertyHardwareRevision.IID] # type: ignore[no-any-return]

    # 子网掩码
    def property_ipv4_subnet_mask(self) -> PropertyIpv4SubnetMask:
        return self.properties[PropertyIpv4SubnetMask.IID] # type: ignore[no-any-return]

    # 序列号
    def property_serial_number(self) -> PropertySerialNumber:
        return self.properties[PropertySerialNumber.IID] # type: ignore[no-any-return]

    # 设备本机 Mac 地址
    def property_mac_address(self) -> PropertyMacAddress:
        return self.properties[PropertyMacAddress.IID] # type: ignore[no-any-return]

    # ipv4地址
    def property_ip(self) -> PropertyIp:
        return self.properties[PropertyIp.IID] # type: ignore[no-any-return]

    # 网关本地自动化是否支持时间配置
    def property_support_time_configuration_for_automation(self) -> PropertySupportTimeConfigurationForAutomation:
        return self.properties[PropertySupportTimeConfigurationForAutomation.IID] # type: ignore[no-any-return]

    # 网关本地自动化是否支持嵌入场景
    def property_support_scene_embed_for_automation(self) -> PropertySupportSceneEmbedForAutomation:
        return self.properties[PropertySupportSceneEmbedForAutomation.IID] # type: ignore[no-any-return]

    # Wi-Fi信号强度
    def property_rssi(self) -> PropertyRssi:
        return self.properties[PropertyRssi.IID] # type: ignore[no-any-return]

    # 网关功能
    def property_gateway(self) -> PropertyGateway:
        return self.properties[PropertyGateway.IID] # type: ignore[no-any-return]



