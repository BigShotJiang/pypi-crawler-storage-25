from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_iconid import PropertyIconid
from ..properties.property_rule_name import PropertyRuleName
from ..properties.property_delete_after_execution import PropertyDeleteAfterExecution
from ..properties.property_rule_enable import PropertyRuleEnable
from ..properties.property_rule_content import PropertyRuleContent
from ..properties.property_content_formatter import PropertyContentFormatter
from ..properties.property_roomid import PropertyRoomid
from ..properties.property_r_description import PropertyRDescription

from ..properties.property_rule_id import PropertyRuleId

import logging

_LOGGER = logging.getLogger(__name__)

# 添加场景
class ActionAddRule(ActionController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:action:add-rule:00000d50:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "add-rule"
        self.description["zh-CN"] = "添加场景"

    # Action 出参
    class Result:
        # 场景id
        property_rule_id: str

        def __init__(self, result: Dict[int, ArgumentOperation]):
            _2: Optional[ArgumentOperation] = result[PropertyRuleId.IID]
            if _2 is not None:
                v = _2.values[0]
                if isinstance(v, str):
                    self.property_rule_id = v
            else:
                _LOGGER.error("result error, not found: %s.IID}", PropertyRuleId)

            return

    # 执行 Action 调用
    async def invoke(self, property_iconid: Optional[str], property_rule_name: Optional[str], property_delete_after_execution: Optional[bool], property_rule_enable: Optional[bool], property_rule_content: Optional[str], property_content_formatter: Optional[int], property_roomid: Optional[int], property_r_description: Optional[str]) -> Result:
        arguments: Dict[int, ArgumentOperation] = {}

        if property_iconid is None:
            arguments[PropertyIconid.IID] = ArgumentOperation(PropertyIconid.IID, value = property_iconid)

        if property_rule_name is None:
            raise ValueError("参数property_rule_name不能为空")
        arguments[PropertyRuleName.IID] = ArgumentOperation(piid = PropertyRuleName.IID, value = property_rule_name)

        if property_delete_after_execution is None:
            arguments[PropertyDeleteAfterExecution.IID] = ArgumentOperation(PropertyDeleteAfterExecution.IID, value = property_delete_after_execution)

        if property_rule_enable is None:
            raise ValueError("参数property_rule_enable不能为空")
        arguments[PropertyRuleEnable.IID] = ArgumentOperation(piid = PropertyRuleEnable.IID, value = property_rule_enable)

        if property_rule_content is None:
            raise ValueError("参数property_rule_content不能为空")
        arguments[PropertyRuleContent.IID] = ArgumentOperation(piid = PropertyRuleContent.IID, value = property_rule_content)

        if property_content_formatter is None:
            raise ValueError("参数property_content_formatter不能为空")
        arguments[PropertyContentFormatter.IID] = ArgumentOperation(piid = PropertyContentFormatter.IID, value = property_content_formatter)

        if property_roomid is None:
            arguments[PropertyRoomid.IID] = ArgumentOperation(PropertyRoomid.IID, value = property_roomid)

        if property_r_description is None:
            arguments[PropertyRDescription.IID] = ArgumentOperation(PropertyRDescription.IID, value = property_r_description)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        out: Dict[int, ArgumentOperation] = await invocation.call(self.iid, arguments)
        return ActionAddRule.Result(out)
