from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController

from ..properties.property_progress import PropertyProgress
from ..properties.property_did import PropertyDid

# 固件升级进度上报
class EventFirmwareUpgradeProgress(EventController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:event:firmware-upgrade-progress:00000a2b:jd:jdzhp02qs:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "firmware-upgrade-progress"
        self.description["zh-CN"] = "固件升级进度上报"

        self._observer: Callable[[int, str], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            property_progress = self.__property_progress(o)
            property_did = self.__property_did(o)
            self._observer(property_progress, property_did)

    def observer(self, observer: Callable[[int, str], None]) -> None:
        self._observer = observer

    @staticmethod
    def __property_progress(o: EventOperation) -> int :
        argument: ArgumentOperation = o.arguments[PropertyProgress.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyProgress.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyProgress.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyProgress.IID))

        value: object = objects[0]
        if not isinstance(value, int):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

    @staticmethod
    def __property_did(o: EventOperation) -> str :
        argument: ArgumentOperation = o.arguments[PropertyDid.IID]
        if argument is None:
            raise ValueError("argument not found: " + str(PropertyDid.IID))

        objects: list[object] = argument.values
        if len(objects) == 0:
            raise ValueError("argument values is empty: " + str(PropertyDid.IID))

        # max: 1
        if len(objects) > 1:
            raise ValueError("argument values.size > 1: " + str(PropertyDid.IID))

        value: object = objects[0]
        if not isinstance(value, str):
            raise TypeError(f"Expected int, got {type(value).__name__}")

        return value

