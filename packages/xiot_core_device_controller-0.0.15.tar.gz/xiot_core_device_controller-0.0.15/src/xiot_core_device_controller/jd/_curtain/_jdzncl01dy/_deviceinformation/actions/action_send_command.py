from typing import Optional, Dict

from xiot_core.support.typedef.controller.operator.action_invoker_wrapper import ActionInvokerWrapper
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.definition.urn.action_type import ActionType
from xiot_core.support.typedef.controller.action_controller import ActionController

from ..properties.property_firmware_revision import PropertyFirmwareRevision


import logging

_LOGGER = logging.getLogger(__name__)

# 发送指令
class ActionSendCommand(ActionController):
    IID: int = 3
    TYPE: str = "urn:jd-spec:action:send-command:00000028:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ActionType(string = self.TYPE))
        self.description["en-US"] = "Send Command"
        self.description["zh-CN"] = "发送指令"


    # 执行 Action 调用
    async def invoke(self, property_firmware_revision: Optional[str]):
        arguments: Dict[int, ArgumentOperation] = {}

        if property_firmware_revision is None:
            raise ValueError("参数property_firmware_revision不能为空")
        arguments[PropertyFirmwareRevision.IID] = ArgumentOperation(piid = PropertyFirmwareRevision.IID, value = property_firmware_revision)

        invocation: Optional[ActionInvokerWrapper] = self.invoker
        if invocation is None:
            raise ValueError("invoker is None")

        await invocation.call(self.iid, arguments)
