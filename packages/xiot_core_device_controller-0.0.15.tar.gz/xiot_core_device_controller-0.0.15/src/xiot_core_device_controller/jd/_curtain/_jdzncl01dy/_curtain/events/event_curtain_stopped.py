from typing import Optional, Callable

from xiot_core.spec.typedef.definition.urn.event_type import EventType
from xiot_core.spec.typedef.operation.argument_operation import ArgumentOperation
from xiot_core.spec.typedef.operation.event_operation import EventOperation
from xiot_core.support.typedef.controller.event_controller import EventController


# 窗帘暂停
class EventCurtainStopped(EventController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:event:curtain-stopped:00000b58:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, EventType(string = self.TYPE))

        self.description["en-US"] = "Curtain Stopped"
        self.description["zh-CN"] = "窗帘暂停"

        self._observer: Callable[[None], None] | None = None

    def handle_event_occurred(self, o: EventOperation) -> None:
        if self._observer is not None:
            self._observer(None)

    def observer(self, observer: Callable[[None], None]) -> None:
        self._observer = observer

