from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_heartbeat_intertval import PropertyHeartbeatIntertval
from .properties.property_heartbeat_timeout import PropertyHeartbeatTimeout

# 心跳
class ServiceHeartbeat(ServiceController):
    IID: int = 129
    TYPE: str = "urn:jd-spec:service:heartbeat:000007d1:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Heartbeat"
        self.description["zh-CN"] = "心跳"

        self.properties[PropertyHeartbeatIntertval.IID] = PropertyHeartbeatIntertval()
        self.properties[PropertyHeartbeatTimeout.IID] = PropertyHeartbeatTimeout()



    # 心跳间隔
    def property_heartbeat_intertval(self) -> PropertyHeartbeatIntertval:
        return self.properties[PropertyHeartbeatIntertval.IID] # type: ignore[no-any-return]

    # 心跳超时次数
    def property_heartbeat_timeout(self) -> PropertyHeartbeatTimeout:
        return self.properties[PropertyHeartbeatTimeout.IID] # type: ignore[no-any-return]



