from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 开关
class PropertyOn(PropertyController[bool]):
    IID: int = 1
    TYPE: str = "urn:jd-spec:property:on:00000014:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=True, notifiable=True),
            fmt = DataFormat.BOOL
        )
        self.description["en-US"] = "on"
        self.description["zh-CN"] = "开关"



