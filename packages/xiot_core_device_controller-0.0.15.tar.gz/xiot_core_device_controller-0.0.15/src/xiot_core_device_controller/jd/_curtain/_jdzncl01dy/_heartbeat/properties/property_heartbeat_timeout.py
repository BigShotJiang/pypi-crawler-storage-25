from typing import Optional, Dict

from xiot_core.spec.typedef.definition.property.access import Access
from xiot_core.spec.typedef.definition.property.data.data_format import DataFormat
from xiot_core.spec.typedef.definition.property.value_range import ValueRange
from xiot_core.spec.typedef.definition.property.value_list import ValueList
from xiot_core.spec.typedef.definition.property.value_definition import ValueDefinition
from xiot_core.spec.typedef.definition.urn.property_type import PropertyType
from xiot_core.support.typedef.controller.property_controller import PropertyController



# 心跳超时次数
class PropertyHeartbeatTimeout(PropertyController[int]):
    IID: int = 2
    TYPE: str = "urn:jd-spec:property:heartbeat-timeout:00000fcb:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(
            iid = self.IID,
            type_ = PropertyType(string = self.TYPE),
            access = Access(readable=True, writable=False, notifiable=True),
            fmt = DataFormat.UINT16
        )
        self.description["en-US"] = "Heartbeat Timeout"
        self.description["zh-CN"] = "心跳超时次数"

        self.constraint_value = ValueRange(DataFormat.UINT16,
            min_ = 1,
            max_ = 1000,
            step_ = 1
        )

        self.defaultValue = 3

