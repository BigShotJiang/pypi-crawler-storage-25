from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_stop_curtain import ActionStopCurtain
from .actions.action_open_curtain import ActionOpenCurtain
from .actions.action_close_curtain import ActionCloseCurtain
from .actions.action_stroke_calibration import ActionStrokeCalibration
from .actions.action_motor_reverse import ActionMotorReverse

from .events.event_curtain_stopped import EventCurtainStopped
from .events.event_curtain_opened import EventCurtainOpened
from .events.event_curtain_closed import EventCurtainClosed

from .properties.property_motor_control import PropertyMotorControl
from .properties.property_current_position import PropertyCurrentPosition
from .properties.property_target_position import PropertyTargetPosition
from .properties.property_motor_reverse import PropertyMotorReverse
from .properties.property_whether_travel_exists import PropertyWhetherTravelExists
from .properties.property_name import PropertyName

# 窗帘
class ServiceCurtain(ServiceController):
    IID: int = 2
    TYPE: str = "urn:jd-spec:service:curtain:000007db:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Curtain"
        self.description["zh-CN"] = "窗帘"

        self.properties[PropertyMotorControl.IID] = PropertyMotorControl()
        self.properties[PropertyCurrentPosition.IID] = PropertyCurrentPosition()
        self.properties[PropertyTargetPosition.IID] = PropertyTargetPosition()
        self.properties[PropertyMotorReverse.IID] = PropertyMotorReverse()
        self.properties[PropertyWhetherTravelExists.IID] = PropertyWhetherTravelExists()
        self.properties[PropertyName.IID] = PropertyName()

        self.actions[ActionStopCurtain.IID] = ActionStopCurtain()
        self.actions[ActionOpenCurtain.IID] = ActionOpenCurtain()
        self.actions[ActionCloseCurtain.IID] = ActionCloseCurtain()
        self.actions[ActionStrokeCalibration.IID] = ActionStrokeCalibration()
        self.actions[ActionMotorReverse.IID] = ActionMotorReverse()

        self.events[EventCurtainStopped.IID] = EventCurtainStopped()
        self.events[EventCurtainOpened.IID] = EventCurtainOpened()
        self.events[EventCurtainClosed.IID] = EventCurtainClosed()

    # 电机控制
    def property_motor_control(self) -> PropertyMotorControl:
        return self.properties[PropertyMotorControl.IID] # type: ignore[no-any-return]

    # 当前位置
    def property_current_position(self) -> PropertyCurrentPosition:
        return self.properties[PropertyCurrentPosition.IID] # type: ignore[no-any-return]

    # 目标位置
    def property_target_position(self) -> PropertyTargetPosition:
        return self.properties[PropertyTargetPosition.IID] # type: ignore[no-any-return]

    # 电机反转
    def property_motor_reverse(self) -> PropertyMotorReverse:
        return self.properties[PropertyMotorReverse.IID] # type: ignore[no-any-return]

    # 是否存在行程
    def property_whether_travel_exists(self) -> PropertyWhetherTravelExists:
        return self.properties[PropertyWhetherTravelExists.IID] # type: ignore[no-any-return]

    # 名称
    def property_name(self) -> PropertyName:
        return self.properties[PropertyName.IID] # type: ignore[no-any-return]


    # 暂停窗帘
    def action_stop_curtain(self) -> ActionStopCurtain:
        return self.actions[ActionStopCurtain.IID] # type: ignore[no-any-return]

    # 打开窗帘
    def action_open_curtain(self) -> ActionOpenCurtain:
        return self.actions[ActionOpenCurtain.IID] # type: ignore[no-any-return]

    # 关闭窗帘
    def action_close_curtain(self) -> ActionCloseCurtain:
        return self.actions[ActionCloseCurtain.IID] # type: ignore[no-any-return]

    # 行程校准
    def action_stroke_calibration(self) -> ActionStrokeCalibration:
        return self.actions[ActionStrokeCalibration.IID] # type: ignore[no-any-return]

    # 电机反转
    def action_motor_reverse(self) -> ActionMotorReverse:
        return self.actions[ActionMotorReverse.IID] # type: ignore[no-any-return]


    # 窗帘暂停
    def event_curtain_stopped(self) -> EventCurtainStopped:
        return self.events[EventCurtainStopped.IID] # type: ignore[no-any-return]

    # 窗帘打开
    def event_curtain_opened(self) -> EventCurtainOpened:
        return self.events[EventCurtainOpened.IID] # type: ignore[no-any-return]

    # 窗帘关闭
    def event_curtain_closed(self) -> EventCurtainClosed:
        return self.events[EventCurtainClosed.IID] # type: ignore[no-any-return]

