from ....device_mapping import register_device

from xiot_core.spec.typedef.definition.urn.device_type import DeviceType
from xiot_core.support.typedef.controller.device_controller import DeviceController

from ._moduleinformation.service_module_information import ServiceModuleInformation
from ._deviceinformation.service_device_information import ServiceDeviceInformation
from ._heartbeat.service_heartbeat import ServiceHeartbeat
from ._curtain.service_curtain import ServiceCurtain
from ._repeater.service_repeater import ServiceRepeater
from ._interaction.service_interaction import ServiceInteraction

# 窗帘电机
@register_device
class DeviceJdzncl01dy(DeviceController):
    TYPE: str = "urn:jd-spec:device:curtain:00000010:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(DeviceType(string = self.TYPE))

        self.description["en-US"] = "Curtain Motor"
        self.description["zh-CN"] = "窗帘电机"

        self.services[ServiceModuleInformation.IID] = ServiceModuleInformation()
        self.services[ServiceDeviceInformation.IID] = ServiceDeviceInformation()
        self.services[ServiceHeartbeat.IID] = ServiceHeartbeat()
        self.services[ServiceCurtain.IID] = ServiceCurtain()
        self.services[ServiceRepeater.IID] = ServiceRepeater()
        self.services[ServiceInteraction.IID] = ServiceInteraction()

    # 模组信息
    def service_module_information(self) -> ServiceModuleInformation:
        return self.services[ServiceModuleInformation.IID] # type: ignore[no-any-return]

    # 设备信息
    def service_device_information(self) -> ServiceDeviceInformation:
        return self.services[ServiceDeviceInformation.IID] # type: ignore[no-any-return]

    # 心跳
    def service_heartbeat(self) -> ServiceHeartbeat:
        return self.services[ServiceHeartbeat.IID] # type: ignore[no-any-return]

    # 窗帘
    def service_curtain(self) -> ServiceCurtain:
        return self.services[ServiceCurtain.IID] # type: ignore[no-any-return]

    # 中继
    def service_repeater(self) -> ServiceRepeater:
        return self.services[ServiceRepeater.IID] # type: ignore[no-any-return]

    # 本地自动化设置
    def service_interaction(self) -> ServiceInteraction:
        return self.services[ServiceInteraction.IID] # type: ignore[no-any-return]

