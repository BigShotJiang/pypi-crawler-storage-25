from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_on import PropertyOn

# 中继
class ServiceRepeater(ServiceController):
    IID: int = 130
    TYPE: str = "urn:jd-spec:service:repeater:000009ca:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Repeater"
        self.description["zh-CN"] = "中继"

        self.properties[PropertyOn.IID] = PropertyOn()



    # 开关
    def property_on(self) -> PropertyOn:
        return self.properties[PropertyOn.IID] # type: ignore[no-any-return]



