from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_support_interaction import PropertySupportInteraction
from .properties.property_current_interaction import PropertyCurrentInteraction

# 本地自动化设置
class ServiceInteraction(ServiceController):
    IID: int = 132
    TYPE: str = "urn:jd-spec:service:interaction:00000d49:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Interaction"
        self.description["zh-CN"] = "本地自动化设置"

        self.properties[PropertySupportInteraction.IID] = PropertySupportInteraction()
        self.properties[PropertyCurrentInteraction.IID] = PropertyCurrentInteraction()



    # 设备支持的微型自动化数量
    def property_support_interaction(self) -> PropertySupportInteraction:
        return self.properties[PropertySupportInteraction.IID] # type: ignore[no-any-return]

    # 设备当下的微型自动化数量
    def property_current_interaction(self) -> PropertyCurrentInteraction:
        return self.properties[PropertyCurrentInteraction.IID] # type: ignore[no-any-return]



