from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController

from .actions.action_reset import ActionReset
from .actions.action_erase_network import ActionEraseNetwork
from .actions.action_send_command import ActionSendCommand
from .actions.action_delete_easylink import ActionDeleteEasylink
from .actions.action_start_easylink import ActionStartEasylink


from .properties.property_firmware_revision import PropertyFirmwareRevision
from .properties.property_manufacturer import PropertyManufacturer
from .properties.property_hardware_revision import PropertyHardwareRevision
from .properties.property_spec_version import PropertySpecVersion

# 设备信息
class ServiceDeviceInformation(ServiceController):
    IID: int = 1
    TYPE: str = "urn:jd-spec:service:device-information:00000001:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Device Information"
        self.description["zh-CN"] = "设备信息"

        self.properties[PropertyFirmwareRevision.IID] = PropertyFirmwareRevision()
        self.properties[PropertyManufacturer.IID] = PropertyManufacturer()
        self.properties[PropertyHardwareRevision.IID] = PropertyHardwareRevision()
        self.properties[PropertySpecVersion.IID] = PropertySpecVersion()

        self.actions[ActionReset.IID] = ActionReset()
        self.actions[ActionEraseNetwork.IID] = ActionEraseNetwork()
        self.actions[ActionSendCommand.IID] = ActionSendCommand()
        self.actions[ActionDeleteEasylink.IID] = ActionDeleteEasylink()
        self.actions[ActionStartEasylink.IID] = ActionStartEasylink()


    # 固件版本
    def property_firmware_revision(self) -> PropertyFirmwareRevision:
        return self.properties[PropertyFirmwareRevision.IID] # type: ignore[no-any-return]

    # 厂商
    def property_manufacturer(self) -> PropertyManufacturer:
        return self.properties[PropertyManufacturer.IID] # type: ignore[no-any-return]

    # 硬件版本
    def property_hardware_revision(self) -> PropertyHardwareRevision:
        return self.properties[PropertyHardwareRevision.IID] # type: ignore[no-any-return]

    # 物模型版本
    def property_spec_version(self) -> PropertySpecVersion:
        return self.properties[PropertySpecVersion.IID] # type: ignore[no-any-return]


    # 恢复出厂设置
    def action_reset(self) -> ActionReset:
        return self.actions[ActionReset.IID] # type: ignore[no-any-return]

    # 删除网络信息
    def action_erase_network(self) -> ActionEraseNetwork:
        return self.actions[ActionEraseNetwork.IID] # type: ignore[no-any-return]

    # 发送指令
    def action_send_command(self) -> ActionSendCommand:
        return self.actions[ActionSendCommand.IID] # type: ignore[no-any-return]

    # 删除爽连
    def action_delete_easylink(self) -> ActionDeleteEasylink:
        return self.actions[ActionDeleteEasylink.IID] # type: ignore[no-any-return]

    # 打开爽连
    def action_start_easylink(self) -> ActionStartEasylink:
        return self.actions[ActionStartEasylink.IID] # type: ignore[no-any-return]


