from xiot_core.spec.typedef.definition.urn.service_type import ServiceType
from xiot_core.support.typedef.controller.service_controller import ServiceController



from .properties.property_protocol import PropertyProtocol
from .properties.property_rssi import PropertyRssi

# 模组信息
class ServiceModuleInformation(ServiceController):
    IID: int = 128
    TYPE: str = "urn:jd-spec:service:module-information:00000c1e:jd:jdzncl01dy:1"

    def __init__(self):
        super().__init__(self.IID, ServiceType(string = self.TYPE))

        self.description["en-US"] = "Module Information"
        self.description["zh-CN"] = "模组信息"

        self.properties[PropertyProtocol.IID] = PropertyProtocol()
        self.properties[PropertyRssi.IID] = PropertyRssi()



    # 通信方式
    def property_protocol(self) -> PropertyProtocol:
        return self.properties[PropertyProtocol.IID] # type: ignore[no-any-return]

    # 接收信号强度指示
    def property_rssi(self) -> PropertyRssi:
        return self.properties[PropertyRssi.IID] # type: ignore[no-any-return]



