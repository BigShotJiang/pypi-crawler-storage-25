-----

# 🟦 SquareNet

**SquareNet** maps unstructured point clouds into structured D-dimensional grids. By building a bijective mapping, it replaces expensive spatial queries ($k$-NN, radius search) with **simple array slicing**.

-----

## 🚀 Why SquareNet?

  * **Speed:** $O(N)$ local operations via vectorized sliding windows.
  * **Memory:** Contiguous memory access instead of irregular spatial lookups.
  * **Simplicity:** Pure NumPy-based logic, no heavy spatial dependencies.

## 📦 Installation

```bash
pip install squarenet
# To include the demo (shapely)
pip install "squarenet[demo]"
```

## 🧠 Quick Start

```python
from squarenet import SquareNet
import numpy as np

# Initialize and Fit
N = 5*11*7*13
d = 4
IJKL = (5, 11, 7, 13)

sqnet = SquareNet(IJ=IJKL) # Define grid dimensions, here 4D
points = np.random.rand(N, d)
sqnet.fit(points)

# Map cloud index to grid index: (N, *) -> (5, 11, 7, 13, *)
grid_X = sqnet.map(cloud_X)
cloud_X = sqnet.invert_map(grid_X)   (5, 11, 7, 13, *) ->  (N, *) 

# Compute Local Gram Matrix (Sparse)
# Only computes interactions within a local window
G = sqnet.gram(points, ws=5)
```

## 🗺️ Visualizing the Mapping

You can use the built-in checkerboard to verify neighborhood preservation:

```python
sqnet = SquareNet(IJ=(200, 200))
sqnet.fit("france")
sqnet.checkerboard()
```

## 📈 Key Applications

  * **Point Cloud Processing:** Fast local feature aggregation.
  * **Kernel Methods:** Efficient sparse approximation of large kernels.
  * **Deep Learning:** Pre-structuring irregular data for CNN/Transformer inputs.

-----

**License:** MIT | **Author:** [ArmanddeCacqueray](mailto:armanddecacqueray@sfr.fr)