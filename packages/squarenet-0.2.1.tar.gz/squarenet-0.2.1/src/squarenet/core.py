import numpy as np
from .utils import initpoint, grid_disorder, gram
from .checkerboard import checkerboard, checkerboard2D, checkerboard3D

class SquareNet:
    """
    An iterative grid-straightening algorithm that untangles a D-dimensional mesh 
    by sorting nodes along each spatial axis to enforce a structured ordering.
    
    The grid is represented as an (I, J, ..., D) array, where D is the number of spatial dimensions.
    Each iteration attempts to minimize disorder along each dimension independently.
    """
    
    def __init__(self, IJ=(100, 100), max_iter=100):
        """
        Initialize the SquareNet.

        Args:
            IJ (tuple): Grid dimensions (Rows, Cols, ...). Supports any number of dimensions.
            max_iter (int): Maximum number of straightening iterations.
        """
        self.IJ = tuple(IJ)
        self.D = len(self.IJ)  # Spatial dimensions (x, y, z,...)
        self.N = np.prod(IJ)
        self.max_iter = max_iter
        self.learning_curve = []
        
        # Internal state
        self.points = None     # Points as given by the user
        self.net = None        # Grid with attached original indices
        self.mapID = None      # Permutation map after sorting

    def map(self, X):
        """
        Reorders any input array according to the optimized grid structure.

        Args:
            X (np.ndarray): Array of shape (N, ...) to be remapped.
            
        Returns:
            np.ndarray: Reshaped and reordered array of shape (*IJ, ...).
        """
        return X[self.mapID].reshape(*self.IJ, *X.shape[1:])

    def invert_map(self, X):
        """
        Restores the original ordering from the grid representation.

        Args:
            sqX (np.ndarray): Array of shape (*IJ, ...)

        Returns:
            np.ndarray: Array of shape (N, ...)
        """
        return (X.reshape(-1, *X.shape[len(self.IJ):]))[self.inv_mapID]

    def fit(self, points):
        """
        Fit the grid to a set of points in D dimensions.

        Args:
            points (np.ndarray or str): Array of shape (N, D) or a method name supported
                                        by .utils.initpoint.
        """
        if isinstance(points, str):
            points = initpoint(method=points, size=(self.N, self.D))
        
        self.points = points
        self.learning_curve = []
        
        N, D = points.shape
        assert N == self.N, f"Input points ({N}) must match grid size {self.N}"
        assert D == self.D, f"Input points dimension ({D}) must match D={self.D}"

        # Attach an ID to each point for tracking during swaps
        indexed_points = np.concatenate([points, np.arange(N)[:, None]], axis=-1)
        
        # Reshape into structured grid: (*IJ, D+1)
        self.net = indexed_points.reshape(*self.IJ, self.D + 1)

        # Iteratively sort along each spatial axis
        for k in range(self.max_iter):
            error = self.sort_increasing()
            if error ==0:
                print(f"succesfully sorted at step {k}")
                break

        # Extract permutation map and clean the coordinate grid
        self.mapID = self.net[..., -1].astype(int).ravel()
        self.inv_mapID = np.empty_like(self.mapID)
        self.inv_mapID[self.mapID] = np.arange(len(self.mapID))
        self.net = self.net[..., :-1]

    def sort_increasing(self):
        """
        Aligns the grid by sorting nodes along each spatial axis.
        Ensures that the points are generally ordered along all dimensions.
        """
        for axis in range(self.D):
            # np.argsort along the current spatial axis
            # Keep the last dimension (original index) attached
            flat_axis = axis
            idx = np.argsort(self.net[..., flat_axis], axis=axis)
            # Expand idx to match last dimension for np.take_along_axis
            idx_expanded = np.expand_dims(idx, axis=-1)
            self.net = np.take_along_axis(self.net, idx_expanded.repeat(self.D + 1, axis=-1), axis=axis)

        error = grid_disorder(self.net[..., :-1])
        self.learning_curve.append(error)
        return(error)
    
    def checkerboard(self, scale = 16, toplot = True):
        """
        return the net as a checkerboard at required scale = number of cells per axe
        make a nice plot if self.D = 2 or 3
        """
        if toplot and (self.D == 2):
            checkerboard2D(self.net)
        if toplot and (self.D == 3):
            checkerboard3D(self.net)
        return checkerboard(self.net, scale)

    def gram(self, X, ws=5):
        """
        Compute a sparse Gram matrix using local neighborhoods within a window.

        Args:
            X (np.ndarray): Input features of shape (N, C)
            ws (int or sequence): Half window size per dimension.
                                If int → same for all dims
                                If sequence → one per grid dim

        Returns:
            np.ndarray: Sparse Gram matrix of shape (N, K)
        """

        return gram(self, X, ws)

