from .core import SquareNet
from .utils import initpoint, grid_disorder, gram
from .checkerboard import checkerboard2D, checkerboard3D

__all__ = ["squarenet"]
__version__ = "0.1.0"