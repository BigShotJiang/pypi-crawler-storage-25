import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

def checkerboard(grid, scale):
    """
    Extracts checkerboard blocks and boundaries from a 2D manifold embedded in ND space.

    Args:
        grid (np.ndarray): A (N, M, D) array representing a 2D surface.
        scale (int): Number of checkerboard squares per axis.

    Returns:
        tuple: (blocks, boundaries) where:
            - blocks: List of (Points, D) arrays for scatter plotting.
            - boundaries: List of (4, D) arrays for polygon plotting.
    """
    ni, nj = grid.shape[:2]
    d = grid.shape[-1]
    blocks = []
    boundaries = []

    # Calculate step size for indices
    hi, hj = ni // scale, nj // scale

    for i in range(scale):
        # Define slice for the i-th row of blocks
        start_i = i * hi
        end_i = min((i + 1) * hi, ni - 1)
        slice_i = slice(start_i, end_i + 1)

        for j in range(scale):
            # Apply checkerboard logic (parity check)
            if (i % 2 == j % 2):
                start_j = j * hj
                end_j = min((j + 1) * hj, nj - 1)
                slice_j = slice(start_j, end_j + 1)

                block = grid[slice_i, slice_j]
                
                # Extract boundary: Top, Right, Bottom (reversed), Left (reversed)
                top    = block[0, :]
                right  = block[:, -1]
                bottom = block[-1, :][::-1]
                left   = block[:, 0][::-1]
                
                boundary = np.vstack([top, right, bottom, left])
                
                blocks.append(block.reshape(-1, d))
                boundaries.append(boundary)

    return blocks, boundaries

def checkerboard2D(grid2d, scales=[2, 4, 8, 16]):
    """
    Visualizes 2D deformed grids using checkerboard patterns at different scales.
    """
    fig, axes = plt.subplots(2, 2, figsize=(10, 10))
    
    for ax, scale in zip(axes.flat, scales):
        blocks, boundaries = checkerboard(grid2d, scale)
        
        # Plot filled areas with scatter (light effect)
        for blk in blocks:
            ax.scatter(blk[:, 0], blk[:, 1], color="lightgrey", s=1, alpha=0.2)
        
        # Plot precise boundaries
        for bnd in boundaries:
            ax.plot(bnd[:, 0], bnd[:, 1], color="black", lw=1)
            
        ax.set_aspect("equal")
        ax.set_title(f"Scale: {scale}x{scale}")
        ax.axis("off")
    
    plt.tight_layout()
    plt.show()

def checkerboard3D(grid3d, scale=4, alpha=0.8):
    """
    Plots the external faces of a 3D deformed volume with a consistent 
    checkerboard pattern.
    
    Args:
        grid3d (np.ndarray): (N, N, N, 3) array of coordinates.
        scale (int): Divisions per axis.
    """
    fig = plt.figure(figsize=(10, 10))
    ax = fig.add_subplot(111, projection='3d')
    
    # Extract the 6 outer boundary surfaces of the volume
    # Slicing is adjusted to try and maintain pattern continuity across edges
    faces_data = [
        grid3d[0, :, :],           # x = min
        grid3d[-1, :, :],          # x = max
        grid3d[:, 0, :],           # y = min
        grid3d[:, -1, :],          # y = max
        grid3d[:, :, 0],           # z = min
        grid3d[:, :, -1]           # z = max
    ]

    for face_grid in faces_data:
        _, boundaries = checkerboard(face_grid, scale)
        
        for bnd in boundaries:
            # Poly3DCollection handles the 3D vertex projection
            poly = Poly3DCollection([bnd], facecolor='lightgrey', 
                                    edgecolor='black', alpha=alpha, linewidths=0.5)
            ax.add_collection3d(poly)
    
    # Auto-scale the view based on grid deformation
    pts = grid3d.reshape(-1, 3)
    mins, maxs = pts.min(axis=0), pts.max(axis=0)
    ax.set_xlim(mins[0], maxs[0])
    ax.set_ylim(mins[1], maxs[1])
    ax.set_zlim(mins[2], maxs[2])
    
    ax.set_box_aspect([1, 1, 1]) # Equal aspect ratio
    ax.set_axis_off()
    plt.show()