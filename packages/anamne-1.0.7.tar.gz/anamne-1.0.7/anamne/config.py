from pathlib import Path
from typing import Literal
from pydantic_settings import BaseSettings, SettingsConfigDict


ModelTier = Literal["claude", "gemini", "none"]


# Look in multiple places so the MCP server (launched from any directory)
# still finds the user's keys. First non-empty match wins per pydantic-settings.
_ENV_PATHS = (
    Path.cwd() / ".env",                   # current working directory
    Path.home() / ".anamne" / ".env",      # user's data dir
)


class Settings(BaseSettings):
    """Reads from .env file (cwd or ~/.anamne/.env).

    Recognized env vars:
      ANTHROPIC_API_KEY  — Claude API key (best quality)
      GEMINI_API_KEY     — Gemini API key (free tier available)
      MODEL              — explicit model override
      DATA_DIR           — where to store the knowledge base
    """

    model_config = SettingsConfigDict(
        env_file=tuple(str(p) for p in _ENV_PATHS),
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    anthropic_api_key: str = ""
    gemini_api_key: str = ""
    model: str = ""  # if blank, picked automatically based on available keys
    data_dir: Path = Path.home() / ".anamne"
    mcp_host: str = "127.0.0.1"
    mcp_port: int = 8765

    def resolved_model(self) -> str:
        """Pick the best available model based on what the user has set up."""
        if self.model:
            return self.model
        if self.anthropic_api_key:
            return "claude-sonnet-4-6"
        if self.gemini_api_key:
            return "gemini-2.5-flash-lite"
        return ""

    def model_tier(self) -> ModelTier:
        m = self.resolved_model().lower()
        if "claude" in m or m.startswith("anthropic"):
            return "claude"
        if "gemini" in m:
            return "gemini"
        return "none"

    def has_any_key(self) -> bool:
        return bool(self.anthropic_api_key or self.gemini_api_key)


def get_settings() -> Settings:
    return Settings()
