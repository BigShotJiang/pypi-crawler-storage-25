from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel

from lumlflow.schemas.base import BaseOrmConfig


class Group(BaseModel, BaseOrmConfig):
    id: str
    name: str
    description: str | None
    created_at: datetime
    tags: list[str] | None = None
    last_modified: datetime | None = None


class GroupDetails(Group):
    experiments_static_params: list[str] | None = None
    experiments_dynamic_params: list[str] | None = None


class UpdateGroup(BaseModel):
    name: str | None = None
    description: str | None = None
    tags: list[str] | None = None


class PaginatedGroups(BaseModel):
    items: list[Group]
    cursor: str | None = None


class GroupsSortBy(StrEnum):
    NAME = "name"
    DESCRIPTION = "description"
    CREATED_AT = "created_at"
    LAST_MODIFIED = "last_modified"
