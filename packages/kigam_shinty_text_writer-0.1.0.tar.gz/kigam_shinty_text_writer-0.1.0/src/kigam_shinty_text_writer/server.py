from mcp.server.fastmcp import FastMCP

# Initialize FastMCP server
mcp = FastMCP("text_writer")

@mcp.tool()
def get_textwriter(contents: str) -> None:
    """
    Save the text entered by the user as contentfile.txt on the c: drive of the user's computer.
    
    Args:
        contents (str): Text entered by the user.
    
    Returns:
        None
    """
    with open("C:/python/text-writer/contentfile.txt", "a", encoding="utf-8") as file:
        file.write(contents)
        file.write("\n\n")  # Ensure the file ends with a newline
    print("Text saved to c:/contentfile.txt")


def main() -> None:
    # Initialize and run the server
    print("Starting Text Writer server...")
    mcp.run(transport='stdio')
    get_textwriter("Sample text for testing.")
    get_textwriter("Another line of text for testing.")
    

if __name__ == "__main__":
   main()   