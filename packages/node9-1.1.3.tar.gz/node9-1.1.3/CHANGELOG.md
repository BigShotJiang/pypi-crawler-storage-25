# CHANGELOG

<!-- version list -->

## v1.1.3 (2026-04-04)

### Bug Fixes

- Merge latest dev updates into main ([#4](https://github.com/node9-ai/node9-python/pull/4),
  [`b09c223`](https://github.com/node9-ai/node9-python/commit/b09c223e859ed803d93aba9ee823b95583868c15))


## v1.1.2 (2026-04-04)

### Bug Fixes

- Merge latest dev updates into main ([#3](https://github.com/node9-ai/node9-python/pull/3),
  [`f5659b0`](https://github.com/node9-ai/node9-python/commit/f5659b0eca4182afdcf58070b0ec4c1ffccccc09))


## v1.1.1 (2026-03-17)

### Bug Fixes

- Rename job to Claude, add env validation and diff size limit
  ([`24aca72`](https://github.com/node9-ai/node9-python/commit/24aca7239a4f00b1128749b7a4013c37e3d8e740))

- Surface truncation warning in PR comment, align word limit with max_tokens
  ([`12771d8`](https://github.com/node9-ai/node9-python/commit/12771d8b64d30ebc3556e3a7ba296618b7766471))

- **ai-review**: Upgrade to claude-sonnet-4-6 with 2048 max_tokens
  ([`52766cf`](https://github.com/node9-ai/node9-python/commit/52766cf88eebea0568223f25f27152c77b9b8a09))


## v1.1.0 (2026-03-15)

### Features

- Add Gemini AI code review on PRs to main
  ([`50b651d`](https://github.com/node9-ai/node9-python/commit/50b651dc2575dc954def69dd16d7492369a8149a))

- Switch AI code review from Gemini to Claude Sonnet
  ([`c52fbb4`](https://github.com/node9-ai/node9-python/commit/c52fbb4ee5d1b460ef008b708e3664e0650f93f9))


## v1.0.3 (2026-03-15)

### Bug Fixes

- Install twine before upload step
  ([`4b4e142`](https://github.com/node9-ai/node9-python/commit/4b4e142b02815937551cbbb8569aa72b0ab222bc))


## v1.0.2 (2026-03-15)

### Bug Fixes

- Publish to PyPI explicitly with twine instead of semantic-release publish
  ([`6847fdb`](https://github.com/node9-ai/node9-python/commit/6847fdbbf6c0bbd7a14a743b99745cdf005d73a9))


## v1.0.1 (2026-03-15)

### Bug Fixes

- Add TWINE credentials and twine to build command for PyPI upload
  ([`d71d73d`](https://github.com/node9-ai/node9-python/commit/d71d73d1caa3c05cfd5011edcd3913f5fc976d07))


## v1.0.0 (2026-03-15)

- Initial Release
