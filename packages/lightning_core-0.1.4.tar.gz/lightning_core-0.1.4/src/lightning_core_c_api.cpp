#include "lightning_core/lightning_core.h"

#include <string>

#include "lightning_core/core/runtime.hpp"

namespace {

lcError_t toLcError(lightning_core::runtime::Status status) {
  switch (status) {
    case lightning_core::runtime::Status::kSuccess:
      return LC_SUCCESS;
    case lightning_core::runtime::Status::kNotInitialized:
      return LC_NOT_INITIALIZED;
    case lightning_core::runtime::Status::kInvalidValue:
      return LC_INVALID_VALUE;
    case lightning_core::runtime::Status::kOutOfMemory:
      return LC_OUT_OF_MEMORY;
    case lightning_core::runtime::Status::kNotSupported:
      return LC_NOT_SUPPORTED;
    case lightning_core::runtime::Status::kDriverError:
      return LC_DRIVER_ERROR;
    case lightning_core::runtime::Status::kUnknown:
    default:
      return LC_UNKNOWN;
  }
}

lightning_core::runtime::MemcpyKind toMemcpyKind(lcMemcpyKind kind) {
  switch (kind) {
    case LC_MEMCPY_HOST_TO_HOST:
      return lightning_core::runtime::MemcpyKind::kHostToHost;
    case LC_MEMCPY_HOST_TO_DEVICE:
      return lightning_core::runtime::MemcpyKind::kHostToDevice;
    case LC_MEMCPY_DEVICE_TO_HOST:
      return lightning_core::runtime::MemcpyKind::kDeviceToHost;
    case LC_MEMCPY_DEVICE_TO_DEVICE:
      return lightning_core::runtime::MemcpyKind::kDeviceToDevice;
    default:
      return lightning_core::runtime::MemcpyKind::kHostToHost;
  }
}

lcDeviceKind toDeviceKind(lightning_core::runtime::Device device) {
  switch (device) {
    case lightning_core::runtime::Device::kCPU:
      return LC_DEVICE_CPU;
    case lightning_core::runtime::Device::kCUDA:
      return LC_DEVICE_CUDA;
    case lightning_core::runtime::Device::kMetal:
    default:
      return LC_DEVICE_METAL;
  }
}

lcMemoryModel toLcMemoryModel(lightning_core::runtime::MemoryModel model) {
  if (model == lightning_core::runtime::MemoryModel::kNativeDevice) {
    return LC_MEMORY_NATIVE_DEVICE;
  }
  return LC_MEMORY_HOST_MANAGED_COMPAT;
}

}  // namespace

extern "C" {

lcError_t lcMalloc(void** ptr, size_t size_bytes) {
  return toLcError(lightning_core::runtime::mallocDevice(ptr, size_bytes));
}

lcError_t lcFree(void* ptr) {
  return toLcError(lightning_core::runtime::freeDevice(ptr));
}

lcError_t lcMemcpy(void* dst, const void* src, size_t size_bytes, lcMemcpyKind kind) {
  return toLcError(lightning_core::runtime::memcpy(dst, src, size_bytes, toMemcpyKind(kind)));
}

lcError_t lcDeviceSynchronize(void) {
  return toLcError(lightning_core::runtime::deviceSynchronize());
}

lcError_t lcGetDeviceCount(int* count) {
  return toLcError(lightning_core::runtime::getDeviceCount(count));
}

lcError_t lcGetPreferredDeviceForInference(lcDeviceKind* device) {
  if (device == nullptr) {
    return LC_INVALID_VALUE;
  }
  *device = toDeviceKind(lightning_core::runtime::preferredDeviceFor(lightning_core::runtime::WorkloadKind::kInference));
  return LC_SUCCESS;
}

lcError_t lcGetPreferredDeviceForTraining(lcDeviceKind* device) {
  if (device == nullptr) {
    return LC_INVALID_VALUE;
  }
  *device = toDeviceKind(lightning_core::runtime::preferredDeviceFor(lightning_core::runtime::WorkloadKind::kTraining));
  return LC_SUCCESS;
}

int lcIsCudaAvailable(void) {
  return lightning_core::runtime::isCudaAvailable() ? 1 : 0;
}

int lcIsMetalAvailable(void) {
  return lightning_core::runtime::isMetalAvailable() ? 1 : 0;
}

lcMemoryModel lcGetMemoryModel(void) {
  return toLcMemoryModel(lightning_core::runtime::deviceMemoryModel());
}

const char* lcGetMemoryModelName(lcMemoryModel model) {
  if (model == LC_MEMORY_NATIVE_DEVICE) {
    return lightning_core::runtime::memoryModelName(lightning_core::runtime::MemoryModel::kNativeDevice);
  }
  return lightning_core::runtime::memoryModelName(lightning_core::runtime::MemoryModel::kHostManagedCompat);
}

const char* lcBackendName(void) {
  static std::string backend;
  backend = lightning_core::runtime::backendName();
  return backend.c_str();
}

const char* lcGetErrorString(lcError_t error) {
  switch (error) {
    case LC_SUCCESS:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kSuccess);
    case LC_NOT_INITIALIZED:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kNotInitialized);
    case LC_INVALID_VALUE:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kInvalidValue);
    case LC_OUT_OF_MEMORY:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kOutOfMemory);
    case LC_NOT_SUPPORTED:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kNotSupported);
    case LC_DRIVER_ERROR:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kDriverError);
    case LC_UNKNOWN:
    default:
      return lightning_core::runtime::getErrorString(lightning_core::runtime::Status::kUnknown);
  }
}

}  // extern "C"
