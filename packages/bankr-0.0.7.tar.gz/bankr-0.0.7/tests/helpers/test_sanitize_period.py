"""Unit tests for the sanitize_period function."""


def test_sanitize_period():
    """Test the sanitize_period function with various inputs."""
    from datetime import datetime

    from src.bankr.helpers import sanitize_period

    # Test cases: (input_str, expected_output_list)
    test_cases = [
        # Valid month formats
        ("2023-01", [datetime(2023, 1, 1), datetime(2023, 1, 31)]),
        # ("23-01", [datetime(2023, 1, 1), datetime(2023, 1, 31)]),
        ("1999-12", [datetime(1999, 12, 1), datetime(1999, 12, 31)]),
        # ("99-12", [datetime(1999, 12, 1), datetime(1999, 12, 31)]),
        # Valid year formats
        ("2023", [datetime(2023, 1, 1), datetime(2023, 12, 31)]),
        # ("99", [datetime(1999, 1, 1), datetime(1999, 12, 31)]),
        ("1999", [datetime(1999, 1, 1), datetime(1999, 12, 31)]),
        # Invalid formats (should return empty list)
        ("", []),
        ("-", []),
        ("2023-13", []),  # Invalid month
        ("2023-00", []),  # Invalid month
        # ("23-13", []),    # Invalid month
        ("10000", []),  # Year out of range
        ("1899", []),  # Year out of range
        ("2100", []),  # Year out of range
        ("2023-01-01", []),  # Full date not supported
        ("invalid", []),  # Non-numeric
        ("2023-1", []),  # Single digit month
        ("2023-01-", []),  # Incomplete date
        ("2023-01-01T00:00:00", []),  # ISO format not supported
    ]

    for input_str, expected in test_cases:
        result = sanitize_period(input_str)
        assert result == expected, f"Failed for input '{input_str}': expected {expected}, got {result}"
        print(f"✓ Test passed for input '{input_str}': {result}")

    print("All tests passed!")


if __name__ == "__main__":
    test_sanitize_period()
