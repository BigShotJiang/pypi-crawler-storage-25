"""Unit tests for the sanitize_iban function."""

from unittest.mock import patch


def test_sanitize_iban_with_sample_accounts():
    """Test the sanitize_iban function with sample accounts in `data_sample`."""
    from pathlib import Path

    from src.bankr.env import read_bankr_yaml
    from src.bankr.helpers import sanitize_iban

    # Load accounts from the sample data
    accounts_path = Path("src/bankr/data.sample/accounts.yaml")
    ACCOUNTS = read_bankr_yaml(accounts_path)

    # Test cases: (input_str, expected_output_str)
    test_cases = [
        # Full IBANs
        ("DE72387267777958538073", "DE72387267777958538073"),
        ("GB71RJKT75252048811544", "GB71RJKT75252048811544"),
        ("FR591344114241SLXBUAHDY9806", "FR591344114241SLXBUAHDY9806"),
        ("DE67077012434271299709", "DE67077012434271299709"),
        # Unique fragments
        # ("DE72387267777958538073", "DE72387267777958538073"),
        ("GB71RJKT", "GB71RJKT75252048811544"),
        ("FR591344114241", "FR591344114241SLXBUAHDY9806"),
        ("DE67077012434271299709", "DE67077012434271299709"),
        # Non-unique fragments (should return empty string)
        ("DE", ""),
        ("77", ""),
        # Case insensitivity
        ("de72387267777958538073", "DE72387267777958538073"),
        ("gb71rjkt", "GB71RJKT75252048811544"),
        # Empty and invalid inputs
        ("", ""),
        ("INVALIDIBAN", ""),
        ("1234567890", ""),
        # Partial matches that are unique
        ("38726777", "DE72387267777958538073"),
        ("RJKT75252048811544", "GB71RJKT75252048811544"),
        ("SLXBUAHDY9806", "FR591344114241SLXBUAHDY9806"),
        ("077012434271299709", "DE67077012434271299709"),
    ]

    with patch("src.bankr.helpers.ACCOUNTS", ACCOUNTS):
        for input_str, expected in test_cases:
            result = sanitize_iban(input_str)
            assert result == expected, f"Failed for input '{input_str}': expected '{expected}', got '{result}'"
            print(f"✓ Test passed for input '{input_str}': '{result}'")

    print("All tests passed!")


if __name__ == "__main__":
    test_sanitize_iban()
