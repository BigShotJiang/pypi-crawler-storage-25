"""Unit tests for the to_cents function."""


def test_to_cents():
    """Test the to_cents function with various inputs."""
    from src.bankr.helpers import to_cents

    # Test cases: (input_str, expected_output_int)
    test_cases = [
        ("1.234", 123400),
        ("-1 234", -123400),
        ("1.234,56", 123456),
        ("1 234.56-", -123456),
        ("1,2", 120),
        ("1,2-", -120),
        ("0", 0),
        ("-", 0),
        ("", 0),
        ("123", 12300),
        ("+123", 12300),
        ("-123", -12300),
        ("1.23", 123),
        ("-1.23", -123),
        ("1,23", 123),
        ("-1,23", -123),
        ("1 234", 123400),
        ("+ 1 234", 123400),
        ("-1 234", -123400),
        ("1.234.567", 123456700),
        ("-1.234.567", -123456700),
    ]

    for input_str, expected in test_cases:
        result_str = to_cents(input_str)
        result_int = int(result_str)
        assert result_int == expected, f"Failed for input '{input_str}': expected {expected}, got {result_int}"
        print(f"✓ Test passed for input '{input_str}': {result_int}")

    print("All tests passed!")


if __name__ == "__main__":
    test_to_cents()
