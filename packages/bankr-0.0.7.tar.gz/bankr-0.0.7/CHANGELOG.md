Bankr - Changelog
=================


v0.0.7 (05/2026)
----------------

- Reactivate apps, which had subsequent errors of the v0.0.6 updates
- Activate `bankr app start/stop` (might be tricky, but works at least on rokor's Linux machine)
- New structure of `pyproject.toml`: delete env `app`, implement panel/hvplot into `bankr/debug`
- Update of the environment and `bankr.sample.yaml`
- Write some unit tests for the module `bh` (assisted by Mistral Vibe)
- Correct bugs of `by.edit()`, and - even more important - serious ones in `bp.parse_csv()`


v0.0.6 (05/2026)
----------------

- Simplify the data structure and switch from Transaction to Entry, see the wiki
- Validate Pages using Pandera
- Start module reorganization: calculation/files/tuitable -> book/entry/env/helpers/page
- Start of refactoring, where reasonable (assisted by Mistral Vibe)
- Use tabulate in favour of prettytable
- Use module-wide i18n (assisted by Mistral Vibe)


v0.0.5 (04/2026)
----------------

- Remove Pandas dot notation from the codebase (assisted by Mistral Vibe)
- CLI-level plotting removed: Rendering often to imprecise, will be replaced by a dashboard
- Create function, variable, and file names in accordance with PEP 8 (assisted by Mistral Vibe)
- Correction of the Transaction IDs of a new Book (wrong dtype), correction of some inherited errors
- Use consequently entry_id instead of uuid


v0.0.4 (04/2026)
----------------

- Remove Pandas dot notation from function "condition_book"
- Separate columns in book-v1.yaml in mandatory and optional parameters
- Implement book-v2.yaml, which adds column tag to book-v1.yaml. Use function "book_v1_to_v2" in iPython to upgrade.
- Upgrade data.sample to book-v2.yaml


v0.0.3 (02/2025)
----------------

- Corrections of i18n
- "source" in book-v1.yaml switched to string to simplify the edit of transactions
- Improvement of the Dashboards, but still preliminary
- Some TODOs removed, others are left
- Fragments of command "app" added


v0.0.2 (01/2025)
----------------

- Improved documentation (p0.0.2)
- Sample data added


v0.0.1 (01/2025)
----------------

Initial release
