# Bankr Dashbords: Accounts

import i18n
import pandas as pd
import panel as pn

import bankr.book as bk
import bankr.page as bp
from bankr.env import ACCOUNTS, BANKR_PATH, LOCALE

# Panel init
pn.extension(design="material")

# Bankr Data Import
book = bk.unpickle()
accounts = bp.accounts(book)

# Init I18N
i18n.set("locale", LOCALE)
i18n.set("fallback", "en")
i18n.load_path.append(BANKR_PATH / "locale")


# Panel Bind: Refresh the table Accounts
def refresh_accounts(accounts: pd.DataFrame, active: bool, types: list[str], owners: list[str], groups: list[str]):
    accounts = accounts.copy()
    if active:
        accounts = accounts[accounts["active"] == "True"]
        accounts = accounts.drop(columns="active")
    accounts = accounts[accounts["type"].isin(types)]
    accounts = accounts[accounts["group"].isin(groups)]
    accounts = accounts[accounts["owner"].isin(owners)]
    # Calculate totals
    accounts_sum = f"## Gesamtbetrag: {accounts['balance'].sum()}\n### {accounts['entries'].sum()} Buchungen"
    accounts_pane = pn.pane.DataFrame(accounts, justify="left")
    accounts_sum_pane = pn.pane.Markdown(accounts_sum)

    return pn.Row(accounts_pane, accounts_sum_pane)


# Sidebar
sb_md = f"{i18n.t('app.accounts')}\n\n[{i18n.t('app.balance')}](/balance)"
sb_md += f"\n\nInfo: {__name__}"  # For test purposes only, in this case bokeh_app_0020c62d15a341fa80871f12b9adc73d
sidebar = pn.pane.Markdown(sb_md)

# Widgets for row select
# Hint: dict.fromkeys([l])) preserves order and removes duplicates
account_types = list(dict.fromkeys([account["type"] for account in ACCOUNTS if "type" in account]))
account_groups = list(dict.fromkeys([account["group"] for account in ACCOUNTS if "group" in account]))
account_owners = list(dict.fromkeys([account["owner"] for account in ACCOUNTS if "owner" in account]))
active = pn.widgets.Checkbox(name="active only", value=True)
types = pn.widgets.CheckBoxGroup(name="types", options=account_types, value=account_types)
owners = pn.widgets.CheckBoxGroup(name="owners", options=account_owners, value=account_owners)
groups = pn.widgets.CheckBoxGroup(name="groups", options=account_groups, value=account_groups)
select = pn.Row("### " + i18n.t("app.accounts"), active, types, owners, groups, styles=dict(background="Whitesmoke"))

# Row table
table = pn.bind(refresh_accounts, accounts=accounts, active=active, types=types, owners=owners, groups=groups)

# Panel Definition
pn.template.FastListTemplate(site="Bankr", title="Dashboards", sidebar=sidebar, main=[select, table]).servable()
