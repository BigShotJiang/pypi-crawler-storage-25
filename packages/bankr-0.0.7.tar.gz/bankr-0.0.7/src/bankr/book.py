"""
Book module `bk` for Bankr.

This module provides functions on the Book, especially reading and saving it.
"""

import sys
from datetime import datetime

import i18n
import pandas as pd

import bankr.entry as by
import bankr.helpers as bh
import bankr.page as bp
from bankr.env import ACCOUNTS, BOOK, DATA_PATH, OPTIONALS

# Type alias for clarity
Page = pd.DataFrame  # Used for a Page and the Book.


def unpickle() -> Page:
    """Read the Book from `book-v3.pickle`.

    Raise error, if the pickled Book is not found.
    """
    try:
        book: Page = pd.read_pickle(DATA_PATH / "book-v3.pickle")
        book = bp.validate(book)
        return book
    except FileNotFoundError as e:
        sys.exit(f"Bankr Error - Book not found.\n{e}")

    # TODO Verbose message


def pickle(book: Page) -> None:
    """Save the Book as `book-v3.pickle`.

    Before pickling, drop unused Optionals and categories, and create a backup
    of `book-v3.pickle`, if present.
    """

    # Drop unused Optionals
    drops = set(OPTIONALS) - set(BOOK.keys())
    if drops:
        book.drop(columns=drops, inplace=True)

    # Remove unused categories
    book["iban"] = book["iban"].cat.remove_unused_categories()
    book["currency"] = book["currency"].cat.remove_unused_categories()
    book["category"] = book["category"].cat.remove_unused_categories()
    book["tag"] = book["tag"].cat.remove_unused_categories()

    # Create backup, if needed
    pickle_path = DATA_PATH / "book-v3.pickle"
    if (pickle_path).is_file():
        pickle_path.rename(DATA_PATH / ("book-v3_" + datetime.now().strftime("%Y%m%d-%H%M%S") + ".pickle"))

    # And create "book-v3.pickle"
    try:
        book.to_pickle(pickle_path)
    except RuntimeError as e:
        sys.exit(f"Bankr Error - Book could not be saved.\n{e}")

    # Book saved
    bh.info(f"{i18n.t('book.book')} {i18n.t('book.saved')}")


def extract_from_book(book: Page, **kwargs) -> Page:
    """Extract a Page from the Book, based on different conditions.

    The extraction is done based on the category `cat` of the Transaction, its `iban` or `bounds` (date interval),
    or its offset account. All parameters are assumed to be sanitized.

    `offsets` in the given list are considered as valid, and are therefore removed from the Page. All other parameters
    are treated as inclusive, if given. The defaults below mean unfiltered, respectively.

    Args:
        book (Page): The validated Book (or a Page)

    Returns:
        The extracted Page
    """

    # Update default params
    params = {"category": "", "iban": "", "bounds": [], "offsets": []}
    params |= kwargs

    # Extract Page from Book
    page = book.copy()
    bounds = params["bounds"]
    if len(bounds) > 0:
        page = page[page["date"].between(pd.to_datetime(bounds[0]), pd.to_datetime(bounds[1]), inclusive="both")]
    if params["category"]:
        page = page[page["category"] == params["category"]]
    if params["iban"]:
        page = page[page["iban"] == params["iban"]]
    page = page.loc[~(page["offset"].isin(params["offsets"]))]  # TODO Does this work?
    return page


def create_new_book() -> Page:
    """tbc"""

    ibans = [account["iban"] for account in ACCOUNTS]
    book = by.empty(ibans[0])
    ibans = ibans[1:]
    for iban in ibans:
        book = bp.concat_pages(book, by.empty(iban))
    book["source"] = "Initial Entry"
    book["description"] = "Initial Entry"

    return book


def sum_per_category_period(book: Page, year: int, span: int, **kwargs) -> pd.DataFrame:
    """Calculate the sum of cents per category and per period. Returns a stacked or pivoted
    ("amounts-type") version of the sums. The sums are given in the main currency unit.

    The period is given as string YYYY-mm (months), YYYY-Qn (quarters), YYYY-Tn (terms), and YYYY.
    The stacked data consists of 3 columns time, cat, and main. The pivoted data is time in rows,
    and cat in columns.

    Parameters:
    - year: starting year of the total time considered
    - span: years to consider
    - period: 1-char string to mark (m)onth [default], (q)uarter, (t)erm, or (f)ull year, kwarg
    - pivot: True if pivoted, otherwise stacked, kwarg
    """

    # TODO Works, but needs refactoring.

    # Update params (defaults) with kwargs
    params = {"period": "m", "pivot": False}
    params |= kwargs

    # Limit Page to [year, year + span) if year and span > 0, otherwise take the Book
    # Exit, if there are no Entries in Page
    book["year"] = book["date"].dt.year
    page = book
    if year > 0 and span > 0:
        page = book[(book["year"] >= year) & (book["year"] < (year + span))]
    if not page.shape[0]:
        sys.exit(f"Bankr Error - No values in {year}!")

    # Create the Series time and concat it with the Page
    time = page["date"].dt.strftime("%Y-%m").rename("time")
    if params["period"] != "m":
        time = page["year"].astype(str).rename("time")
    if params["period"] == "q":
        quarter = page["date"].dt.quarter.astype(str)
        time = time.str.cat(others=quarter, sep="-Q")
    if params["period"] == "t":
        term = page["date"].dt.month.apply(_month2term).astype(str)
        time = time.str.cat(others=term, sep="-T")
    page = pd.concat([page, time], axis=1, copy=False)

    # Calculate sums and return it stacked or pivoted
    stacked = page.groupby(["time", "category"], as_index=False, observed=False)["cents"].sum()
    stacked["main"] = stacked["cents"].apply(_cents2euro)
    stacked.drop("cents", axis=1, inplace=True)
    if params["pivot"]:
        return stacked.pivot(index="time", columns="category", values="main")
    else:
        return stacked


def append_totals(amounts: pd.DataFrame) -> pd.DataFrame:
    """Calculate incomes/expenses/balances per row, and column totals.

    It expects an "amounts-type" dataframe. Firstly, it appends it with three columns,
    the total incomes per time interval (row), the total expenses, and the balance (sum).
    Secondly, it adds a row with column totals.
    """

    # TODO Works, but needs refactoring.

    amounts.loc["total"] = amounts.sum(axis=0)
    income = amounts.mask(amounts < 0, 0)
    income["internal"] = 0
    expense = amounts.mask(amounts > 0, 0)
    expense["internal"] = 0
    amounts["income"] = income.sum(axis=1)
    amounts["expense"] = expense.sum(axis=1)
    amounts["balance"] = amounts["income"] + amounts["expense"]

    return amounts  # TODO Remove categories, return totals only


def list_years_with_transactions(book: pd.DataFrame) -> list[str]:
    """bla"""

    years: list[str] = []
    book["year"] = book["date"].dt.year
    for year in range(1900, 2100):
        if (book["year"] == year).sum() > 0:
            years.append(str(year))

    return years


# Helper - Transfer cents to euros
def _cents2euro(x: int) -> float:
    return x / 100.0


# Helper - Month to Term
def _month2term(month: int) -> int:
    if month < 7:
        term = 1
    else:
        term = 2
    return term
