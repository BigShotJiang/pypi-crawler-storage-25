"""The commands of *Bankr*'s command line interface."""

# import re
import sys

import click
import i18n

import bankr.app as ba
import bankr.book as bk
import bankr.entry as by
import bankr.helpers as bh
import bankr.page as bp
from bankr.env import ACCOUNTS, BANKR_PATH, LOCALE

# Init I18N
i18n.set("locale", LOCALE)
i18n.set("fallback", "en")
i18n.load_path.append(BANKR_PATH / "locale")


# Helper - Test command for development
@click.command()
# @click.argument("csv_file")
def test():
    """For development purposes only."""
    ...


@click.command()
@click.option("-a", "--all", is_flag=True, help="Show all Accounts of the Book")
def iban(all: bool):
    """Show the Accounts of the Book."""

    book = bk.unpickle()
    active = not all
    bp.show_accounts(book, active=active)


@click.command()
@click.argument("csv_file")
@click.option("-a", "--add", is_flag=True, help="Add the auto-cat Page to the Book")
@click.option("-v", "--verbose", is_flag=True, help="Provide info about processing steps")
def parse(csv_file: str, add: bool, verbose: bool):
    """Parse CSV for a Page, and eventually add it to the Book.

    A summary of the Transactions of the Page, and the expectable changes of the Book are presented.
    The Book is not changed in Parse Mode. If in Add Mode, an auto categorized Page is added to the Book.
    """

    subtitle = "Parse Mode"
    if add:
        subtitle = "Add Mode"
    bh.title(subtitle)

    # Parse CSV to Page
    page = bp.parse_csv(csv_file)
    book = bk.unpickle()

    # Auto-categorize Page
    bp.categorize_entries(page, verbose=True)

    if add:
        # Import Page to Book, and save it
        book = bp.concat_pages(page, book)
        bk.pickle(book)
    else:
        # Print statistics of the relevant IBAN
        iban = csv_file.split("-")[0]
        click.echo(f"- {i18n.t('cli.page')}")
        page_balance = bp.show_iban_statistics(page, iban)
        click.echo(f"- {i18n.t('cli.book')}")
        book_balance = bp.show_iban_statistics(book, iban)
        click.echo(f"  {i18n.t('cli.new_balance'):<32}{book_balance + page_balance}\n")
        while True:  # TODO Refactor overly complicated code
            selection = input("Bankr Action - Show Entries of the created Page (y/n)? ")
            if selection == "y":
                if page.shape[0] > 500:
                    bh.info("Maximum number of Entries is 500.")
                    break
                else:
                    bp.show(page, enum=True)
                    entry_no = input("Bankr Action - Show # of Entry? ")
                    try:
                        entry_no = int(entry_no)
                    except ValueError:
                        entry_no = -1
                    if entry_no < 0 or entry_no >= page.shape[0]:
                        break
                    else:
                        entry = page.iloc[[entry_no]]
                        by.show(entry)
                        break
            elif selection == "n":
                break


@click.command()
@click.argument("iban")
def add(iban: str = "") -> None:
    """Add an Entry to the Book."""

    bh.title("Add an Entry")
    iban = bh.sanitize_iban(iban)
    if not iban:
        sys.exit("Bankr Error - No IBAN given.")
    entry = by.edit(by.empty(iban))
    book = bk.unpickle()
    book = bp.concat_pages(entry, book)
    by.show(entry)
    bh.info("Add this Entry?")
    if bh.confirm_save():
        bk.pickle(book)
    else:
        bh.info("Entry not added.")


@click.command()
@click.argument("entry_id")
def edit(entry_id: str):
    """Edit an Entry of the Book."""

    bh.title("Edit an Entry")
    book = bk.unpickle()
    entry = bh.locate_entry(book, entry_id)
    entry = by.edit(entry)
    book = bp.concat_pages(book.drop(entry_id), entry)
    by.show(entry)
    bh.info("Edit this Entry?")
    if bh.confirm_save():
        bk.pickle(book)
    else:
        bh.info("Entry not edited.")


@click.command()
@click.argument("entry_id")
def delete(entry_id: str) -> None:
    """Delete an Entry from the Book."""

    bh.title("Delete an Entry")
    book = bk.unpickle()
    entry = bh.locate_entry(book, entry_id)
    book = book.drop(entry_id)
    by.show(entry)
    bh.info("Delete this Entry?")
    if bh.confirm_save():
        bk.pickle(book)
    else:
        bh.info("Entry not deleted.")


@click.command()
@click.option("-y", "--year", type=click.IntRange(min=1900, max=2100, clamp=True), help="First year to show")
@click.option("-s", "--span", type=click.IntRange(min=1, max=10, clamp=True), help="Number of years to show")
@click.option("-q", "--quarter", is_flag=True, help="Show quarters")
@click.option("-t", "--term", is_flag=True, help="Show terms/half-years")
@click.option("-f", "--full", is_flag=True, help="Show full years")
def stats(year: int, span: int, quarter: bool, term: bool, full: bool):
    """Statistics of the Book or per time interval.

    Statistics of the Book:
    The number of transactions per IBAN, its current account balance, and the date of the
    first/last transaction are shown.

    Transaction Statistics:
    Amounts per category and time interval.
    """

    # TODO The options need improvement.

    book = bk.unpickle()
    if not year:
        year = 1900
    if not span:
        span = 200
    period = "m"
    if quarter:
        period = "q"
    if term:
        period = "t"
    if full:
        period = "f"
    bh.title(i18n.t("cli.statistics"))
    amounts = bk.sum_per_category_period(book, year, span, period=period, pivot=True)
    amounts = bk.append_totals(amounts)
    bp.show_balance_per_interval(amounts)


@click.command()
@click.option("-a", "--auto", is_flag=True, help="Auto categorize the Book")
@click.option("-e", "--entry_id", type=click.STRING, help="Categorize an Entry ID")
def cat(auto: bool, entry_id: str):
    """Categorize Entries of a Page or the Book.

    Basis of the automatic categorization is `filters.yaml`. Manual and auto cat work only
    on entries without a category.
    """

    book = bk.unpickle()
    if entry_id:
        try:
            entry = book.loc[["entry_id"]]
        except KeyError:
            sys.exit("Bankr Error - Invalid Entry ID")
        bh.title("Categorizing Entry ID")
        by.show(entry, details=True)
        selection = bh.select_category()
        if selection:
            book.loc[entry_id, "category"] = selection
            bh.info(f"{i18n.t('cli.entry_id')} {entry_id} {i18n.t('cli.categorized')}")
    elif auto:
        bh.title("Auto Categorizing")
        bp.categorize_entries(book)
        bh.info(f"{i18n.t('cli.book_categorized')} - {sum(book['category'] == 'none')} {i18n.t('cli.wo_cat')}")
    else:
        bh.title("Categorizing")
        bp.categorize_entries_manually(book)
        bh.info(f"{i18n.t('cli.book_categorized')} - {sum(book['category'] == 'none')} {i18n.t('cli.wo_cat')}")
    if bh.confirm_save():
        bk.pickle(book)


@click.command()
@click.option("-d", "--details", is_flag=True, help="Show the details (optionals) of an Entry.")
@click.argument("entry_id")
def entry(entry_id: str, details: bool) -> None:
    """Show an Entry of the Book."""

    book = bk.unpickle()
    try:
        entry = book.loc[[entry_id]]
    except KeyError:
        sys.exit("Bankr Error - Entry not found.")
    by.show(entry, details=details, header=True)


@click.command()
@click.option("-p", "--period", default="", type=click.STRING, help="Period to show")
@click.option("-c", "--category", default="", type=click.STRING, help="Category to show")
@click.option("-e", "--entry_id", is_flag=True, help="Show Entry IDs")
@click.option("-i", "--iban", default="", type=click.STRING, help="IBAN to show")
@click.option("-n", "--enum", is_flag=True, help="Enumerate Entries")
@click.option("-x", "--check_external", is_flag=True, help="Check if offset is external")
def show(period: str, category: str, entry_id: bool, iban: str, enum: bool, check_external: bool):
    """Show the filtered Entries of the Book (max 500)."""

    # Sanitize parameters and collect internal accounts
    bounds = bh.sanitize_period(period)
    category = bh.sanitize_category(category)
    iban = bh.sanitize_iban(iban)
    offsets = []
    if check_external:
        offsets = [account["iban"] for account in ACCOUNTS]

    # Load Book, extract and show Page
    bh.title("Page Mode")
    book = bk.unpickle()
    page = bk.extract_from_book(book, bounds=bounds, category=category, iban=iban, offsets=offsets)
    if page.shape[0] > 500:
        bh.info("Maximum number of Transactions is 500.")
    else:
        bp.show(page, entry_id=entry_id, enum=enum, header=False)


@click.command()
def new():
    """Create a new Book in DATA_PATH, see `bankr.yaml`.

    Creates an almost empty Book, which contains a zero value "Initial Entry" for each
    account in `accounts.yaml`.
    """

    bh.title("Create new Book")
    book = bk.create_new_book()
    if bh.confirm_save():
        bk.pickle(book)
        bh.info("Return to a backup, if processed erroneously.")


# v0.0.3 Just a mock up right now
@click.command()
@click.argument("cmd", default="start")
def app(cmd: str) -> None:
    """Start or stop the Bankr App.

    Args:
        cmd (str): `start` (default) or `stop` the Dashboard.
    """
    if cmd.lower() == "start":
        bh.info("Starting App (http://localhost:5006)...")
        ba.start_app()
    elif cmd.lower() == "stop":
        ba.stop_app()
        bh.info("App stopped")
    else:
        bh.info("Bankr does not understand")
