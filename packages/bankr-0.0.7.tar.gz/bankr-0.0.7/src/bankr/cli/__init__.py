# SPDX-FileCopyrightText: 2024-present Robert Kormann <rokor@kormann.info>
#
# SPDX-License-Identifier: Unlicense
import click

import bankr.cli.commands as commands
from bankr.__about__ import __version__


@click.group(
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
)
@click.version_option(version=__version__, prog_name="bankr")
def bankr():
    pass


bankr.add_command(commands.add)
bankr.add_command(commands.cat)
bankr.add_command(commands.delete)
bankr.add_command(commands.edit)
bankr.add_command(commands.entry)
bankr.add_command(commands.iban)
bankr.add_command(commands.new)
bankr.add_command(commands.parse)
bankr.add_command(commands.show)
bankr.add_command(commands.stats)
bankr.add_command(commands.test)
bankr.add_command(commands.app)
