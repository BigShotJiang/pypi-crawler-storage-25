"""
Page module for Bankr.

This module provides functions for importing, manipulating, and validating Pages.
"""

import sys
import time
import uuid

import i18n
import pandas as pd
import pandera.pandas as pa
from schwifty import IBAN
from tabulate import tabulate

import bankr.entry as by
import bankr.helpers as bh
from bankr.env import (
    ACCOUNTS,
    ANCHOR_CURRENCY,
    BOOK,
    CATEGORIES,
    CURRENCIES,
    DATA_PATH,
    DATE_FORMAT,
    FILTERS,
    MANDATORIES,
    OPTIONALS,
    TAGS,
    read_bankr_yaml,
)
from bankr.money import Money

# Type alias for clarity
Page = pd.DataFrame  # Used for a Page and the Book.
Entry = pd.DataFrame  # Used for an Entry.


def parse_csv(csv_file: str, **kwargs) -> Page:
    """Parse CSV and create a Page.

    Parse the CSV, defined by `<bank_code>.yaml`, and validate the parsed data. Before the validation,
    two pretty critical data transformations take place:
        1. The estimation of the dates for date and valuta, which needs proper adjustment in <bank_code>.yaml.
        2. Even more important is transfer of the value of the entry to cents, using `to cents`.

    Args:
        csv_file: A bank generated CSV file. Its format is imported from <bank_code>.yaml.
        verbose (bool, optional): Creates a completion message if True.

    Returns:
        A validated Page
    """

    params = {"verbose": False}
    params |= kwargs

    # Analyse filename, esp. the IBAN
    iban = csv_file.split("-")[0]
    source = csv_file.replace(".", "-").split("-")[1]
    if not IBAN(iban).is_valid:
        sys.exit("Bankr Error - Filename has invalid IBAN.")

    # Read CSV
    csv_format: dict = read_bankr_yaml(DATA_PATH / ("csv/" + IBAN(iban).bank_code + ".yaml"))
    try:
        csv = pd.read_csv(
            DATA_PATH / ("csv/" + csv_file),
            sep=csv_format["sep"],
            encoding=csv_format["encoding"],
            dtype="str",
            skiprows=csv_format["skiprows"],
            header=0,
            index_col=False,
            names=csv_format["names"],
        )
    except BaseException as e:  # Catch all exceptions
        sys.exit(f"Bankr Error - Page could not be read from CSV.\n{e}")

    # Add iban and source   TODO Improve using try ... except
    csv["iban"] = iban
    csv["iban"] = csv["iban"].astype("str")
    csv["source"] = source
    csv["source"] = csv["source"].astype("str")
    # csv["currency"] = csv_format["currency"]
    csv["cents"] = csv["cents"].apply(bh.to_cents).astype(int)
    csv["date"] = pd.to_datetime(csv["date"], format=csv_format["dateformat"])
    csv["valuta"] = pd.to_datetime(csv["valuta"], format=csv_format["dateformat"])

    # Verbose message
    bh.info(f"{csv_file} {i18n.t('page.parsed')}", verbose=params["verbose"])

    return validate(csv)


def validate(raw_page: Page) -> Page:
    """Parse and validate a Raw Page into a Page.

    The most important values are date/valuta, and cents. Te latter is kept as is before validation
    (Int64 therefore preferred). Dates, preferrably `datetime64[ns] are assumed to follow DATE_FORMAT, if `str`.

    Args:
        raw_page: The Raw Page to validate.

    Returns:
        The validated Page.
    """

    # YAML defined column categories
    ibans = [account["iban"] for account in ACCOUNTS]
    currencies = [currency["currency"] for currency in CURRENCIES]
    categories = [category["category"] for category in CATEGORIES]
    tags = [tag["tag"] for tag in TAGS]

    # Define Pandera Page schema
    schema = pa.DataFrameSchema(
        {
            "date": pa.Column("datetime64[ns]"),
            "iban": pa.Column("category", pa.Check.isin(ibans)),
            "cents": pa.Column("Int64"),
            "currency": pa.Column("category", pa.Check.isin(currencies), default=ANCHOR_CURRENCY),
            "offset": pa.Column("string", default=""),
            "category": pa.Column("category", pa.Check.isin(categories), default="none"),
            "tag": pa.Column("category", pa.Check.isin(tags), default="none"),
            "source": pa.Column("string", default="unknown"),
            "valuta": pa.Column("datetime64[ns]"),
            "name": pa.Column("string", default=""),
            "process": pa.Column("string", default=""),
            "description": pa.Column("string", default=""),
            "creditor": pa.Column("string", default=""),
            "mandate": pa.Column("string", default=""),
            "customer": pa.Column("string", default=""),
        },
        index=pa.Index("string"),
        add_missing_columns=True,
        strict="filter",
        coerce=True,
    )

    # Create index = entry_id if needed
    if raw_page.index.name != "entry_id":
        raw_page["entry_id"] = raw_page.apply(lambda _: uuid.uuid4(), axis=1)
        raw_page.set_index("entry_id", inplace=True)

    # Format date, if a string, assuming the string is in DATE_FORMAT
    if raw_page.dtypes["date"] == "str":
        try:
            raw_page["date"] = pd.to_datetime(raw_page["date"], format=DATE_FORMAT)
        except ValueError:
            sys.exit("Bankr Error - Date invalid")

    # If valuta is missing in Raw Page, set valuta to date
    if "valuta" not in raw_page.columns:
        if "date" in raw_page.columns:
            raw_page["valuta"] = raw_page["date"]

    # Format valuta, if a string, assuming the string is in DATE_FORMAT
    if raw_page.dtypes["valuta"] == "str":
        try:
            raw_page["valuta"] = pd.to_datetime(raw_page["valuta"], format=DATE_FORMAT)
        except ValueError:
            sys.exit("Bankr Error - Date invalid")

    # Validate Page gracefully using Pandera
    try:
        page: Page = schema.validate(raw_page, lazy=True)
    except pa.errors.SchemaErrors as exc:
        print(f"\nBankr Error - Page schema showed problems:\n\n{exc.failure_cases}\n")
        sys.exit()

    # Add categories to Categoricals
    page["iban"] = page["iban"].cat.add_categories(set(ibans) - set(page["iban"].cat.categories))
    page["currency"] = page["currency"].cat.add_categories(set(currencies) - set(page["currency"].cat.categories))
    page["category"] = page["category"].cat.add_categories(set(categories) - set(page["category"].cat.categories))
    page["tag"] = page["tag"].cat.add_categories(set(tags) - set(page["tag"].cat.categories))

    # Sort the columns and rows in Page
    page = page[[*(MANDATORIES + OPTIONALS)]]
    sort_page(page)

    return page


def categorize_entries(page: Page, **kwargs) -> None:
    """Auto-categorize the Entries in a Page or the Book in place.

    Applies only to Entries with cat == "none", since other, potential manually overruled
    categories must NOT be changed.
    """

    # *Technical remarks*
    # (1) return not needed due to inplace operations.
    # (2) Tilde operator ~ is an elementwise Not (needed, see "where" operator).
    # (3) catcon["nones"] limits replacement to page["category"] = "none". Index reset needed for "catcon" setup.
    # (4) catcon["keys"] limits replacement, where the filter is fullfilled.

    params = {"verbose": False}
    params |= kwargs

    catcon = pd.DataFrame(columns=["nones", "keys"], index=range(page.shape[0]))
    page.reset_index(inplace=True)
    catcon["nones"] = page["category"].str.contains("none")
    for filtr in FILTERS:
        category = filtr["category"]
        column = filtr["column"]
        keys = filtr["keys"]
        catcon["keys"] = page[column].str.contains(keys, case=False)
        page["category"] = page["category"].where(~catcon.all(axis=1), other=category)
    page.set_index("entry_id", inplace=True)

    # Verbose message
    bh.info(f"{i18n.t('page.page')} {i18n.t('page.categorized')}", verbose=params["verbose"])


def categorize_entries_manually(book: Page) -> None:
    """Manually categorize the Book inplace.

    Loop over all Entries with `category == "none"`, and offer a manual change of the category.
    The manual categorization can be stopped at any time. In this case, the function will return an empty string
    to the caller.
    """

    nones = sum(book["category"] == "none")
    none = 1

    for n in range(book.shape[0]):
        transaction = book.iloc[n]
        if transaction["category"] != "none":
            continue
        print("━" * 120)
        print(f"{i18n.t('entry.entry')} {none}/{nones}")
        by.show(book.iloc[[n]], header=False)
        selection = bh.select_category()
        if not selection:
            return
        book.loc[transaction.name, "category"] = selection
        print(f"{i18n.t('page.new_cat')}: {i18n.t('cats.' + selection)}", "\n")
        none += 1
        time.sleep(0.5)


def sort_page(page: Page) -> None:
    """Sort a Page by descending date and ascending iban"""

    page.sort_values(by=["date", "iban"], ascending=[False, True], inplace=True)


def concat_pages(page1: Page, page2: Page, **kwargs) -> Page:
    """Concat Pages or a Page to the Book."""

    params = {"verbose": False}
    params |= kwargs

    page = pd.concat([page1, page2], axis=0, ignore_index=False)
    sort_page(page)

    # Verbose message
    bh.info(f"{i18n.t('page.page')} {i18n.t('page.imported')}", verbose=params["verbose"])

    return page


def stringify(page: Page) -> pd.DataFrame:
    """
    Convert a Page into a Pandas DataFrame containing only string columns.

    Args:
        page (Page): A validated Page

    Returns:
        pd.DataFrame: An identically shaped DataFrame with all values transferred to strings.
    """

    # Do not change page
    page = page.copy()

    # Calculate currency
    page["cents"] = (page["cents"].astype(float) / 100).map("{:.2f}".format)
    page["cents"] += page["currency"].astype(str)

    # Prepare date formats
    page["date"] = page["date"].dt.strftime(DATE_FORMAT)
    page["valuta"] = page["valuta"].dt.strftime(DATE_FORMAT)

    # Provide the i18n version of "category" and "tag"
    page["category"] = page["category"].apply(lambda x: i18n.t(f"cats.{x}"))
    page["tag"] = page["tag"].apply(lambda x: bh.describe_tag(x))

    # Transfer all columns to strings
    string_schema = pa.DataFrameSchema(
        {
            "date": pa.Column("string"),
            "iban": pa.Column("string"),
            "cents": pa.Column("string"),
            "currency": pa.Column("string"),
            "offset": pa.Column("string"),
            "category": pa.Column("string"),
            "tag": pa.Column("string"),
            "source": pa.Column("string"),
            "valuta": pa.Column("string"),
            "name": pa.Column("string"),
            "process": pa.Column("string"),
            "description": pa.Column("string"),
            "creditor": pa.Column("string"),
            "mandate": pa.Column("string"),
            "customer": pa.Column("string"),
        },
        coerce=True,
    )

    return string_schema.validate(page)


def show(page: Page, **kwargs) -> None:
    """tbc"""

    params = {"details": False, "enum": True, "entry_id": False, "header": True}
    params |= kwargs

    # Do not change page
    page = page.copy()
    page.reset_index(inplace=True)

    # Prepare Figures to show
    figures = []
    if params["entry_id"]:
        figures += ["entry_id"]
        params["details"] = False
    figures += MANDATORIES
    figures.remove("currency")
    if params["details"]:
        try:
            figures += list(BOOK.keys())
        except AttributeError:
            pass

    # Format dates
    page["date"] = page["date"].dt.strftime("%d.%m.%Y")
    if "valuta" in page.columns:
        page["valuta"] = page["valuta"].dt.strftime("%d.%m.%Y")

    # Format amount
    page["cents"] = (page["cents"].astype(float) / 100).map("{:.2f}".format) + page["currency"].astype(str)
    page.drop(["currency"], axis=1, inplace=True)

    # Filter the data
    page = page[[*figures]]

    # I18n of Figures
    headers: list = []
    if params["enum"]:
        headers += ["#"]
    for figure in figures:
        headers.append(i18n.t(f"entry.{figure}"))

    # i18n of category and tag
    page["category"] = page["category"].apply(lambda x: i18n.t(f"cats.{x}"))
    page["tag"] = page["tag"].apply(lambda x: i18n.t(f"cats.{x}"))

    # Alignment of Figures
    colalign: list = []
    if params["enum"]:
        colalign += ["right"]
    if params["entry_id"]:
        colalign += ["center"]
    colalign += ["center", "left", "right", "left", "center", "center", "center"]

    if params["header"]:
        bh.title(i18n.t("page.entries"))
    print(
        tabulate(page, headers=headers, showindex=params["enum"], tablefmt="rounded_outline", colalign=colalign),
        "\n",
    )


def accounts(page: Page) -> pd.DataFrame:
    """tbc"""

    # Calculate the data of all accounts
    accounts: list[dict] = []
    for account in ACCOUNTS:
        account["entries"] = sum(page["iban"] == account["iban"])
        account["balance"] = page[page["iban"] == account["iban"]]["cents"].sum() / 100.0
        account["first_entry"] = ""
        account["last_entry"] = ""
        if account["entries"] > 0:
            account["first_entry"] = page[page["iban"] == account["iban"]].date.min().strftime("%d.%m.%Y")
            account["last_entry"] = page[page["iban"] == account["iban"]].date.max().strftime("%d.%m.%Y")
        accounts.append(account)

    return pd.DataFrame(accounts)


def show_accounts(page: Page, **kwargs) -> None:
    """Show a summary of the accounts in the Page.

    It includes the IBAN of the accounts, the number of Entries, first and last Entry dates, and a balance.

    Args:
        page (Page): The Page containing the account data to be displayed.
        active (bool, optional): If True (default), shows only active accounts
        details (bool, optional): If True, displays detailed information about each account. Defaults to False.

    Returns:
        None, table for CLI.
    """

    param = {"active": True, "details": False}
    param |= kwargs

    # Calculate the data of all accounts
    accounts: list[dict] = []
    for account in ACCOUNTS:
        account["entries"] = sum(page["iban"] == account["iban"])
        account["balance"] = Money.m(page[page["iban"] == account["iban"]].cents.sum() / 100.0)
        account["first_entry"] = ""
        account["last_entry"] = ""
        if account["entries"] > 0:
            account["first_entry"] = page[page["iban"] == account["iban"]].date.min().strftime("%d.%m.%Y")
            account["last_entry"] = page[page["iban"] == account["iban"]].date.max().strftime("%d.%m.%Y")
        if param["active"] and account["active"] == "True":
            accounts.append(account)
        if not param["active"]:
            accounts.append(account)
    accounts = pd.DataFrame(accounts)

    # Filter the data of accounts
    figures = ["iban", "entries", "first_entry", "last_entry", "balance", "description"]
    colalign = ["left", "right", "center", "center", "right", "left"]
    if param["details"]:
        figures += ["owner", "group", "type", "active"]
        colalign += ["center", "center", "left", "center"]
    accounts = accounts[[*figures]]

    # I18n of the Figures
    headers: list = []
    for figure in figures:
        headers.append(i18n.t(f"page.{figure}"))

    # Show accounts
    bh.title(i18n.t("page.accounts"))
    print(f"{i18n.t('page.total')}: {accounts['balance'].sum()}  ", end="")
    print(f"({accounts['entries'].sum()} {i18n.t('page.entries')})\n")
    print(tabulate(accounts, headers=headers, showindex=False, tablefmt="rounded_outline", colalign=colalign), "\n")


def show_balance_per_interval(amounts: pd.DataFrame, **kwargs) -> None:
    """Show the balance per time interval.

    Displays the categories and balance (columns) per interval (rows) for all categories except "internal".

    Args:
        amounts (pd.DataFrame): A DataFrame containing the amounts to be displayed.

    Returns:
        None, table for CLI.
    """

    amounts.drop(["internal"], axis=1, inplace=True)

    # I18n of the relevant categories
    headers: list = []
    for category in amounts.columns:
        headers.append(i18n.t(f"cats.{category}"))

    bh.title(i18n.t("cli.statistics"))
    print(tabulate(amounts, headers=headers, showindex=True, tablefmt="rounded_outline"), "\n")


def show_iban_statistics(page: Page, iban: str) -> Money:
    """Statistics of an Account.

    It provides the number of Entries, the first and last Entry date, and the balance of the Account.
    """
    try:
        first_entry = page[page["iban"] == iban].date.min().strftime("%d.%m.%Y")
    except:  # noqa: E722
        first_entry = f"{i18n.t('page.none'):>10}"
    try:
        last_entry = page[page["iban"] == iban].date.max().strftime("%d.%m.%Y")
    except:  # noqa: E722
        last_entry = f"{i18n.t('page.none'):>10}"
    try:
        value = Money.m(page[page["iban"] == iban].cents.sum() / 100.0)
    except:  # noqa: E722
        value = Money.m(0.0)

    # Print IBAN statistics
    print(f"    {i18n.t('page.no_tracts'):<30}{len(page[page.iban == iban]):>10}")
    print(f"    {i18n.t('page.first_transaction'):<30}{first_entry}")
    print(f"    {i18n.t('page.last_transaction'):<30}{last_entry}")
    print(f"    {i18n.t('page.fin_bal'):<30}{value}\n")

    return value
