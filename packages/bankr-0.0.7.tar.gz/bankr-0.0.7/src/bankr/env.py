"""
Environment module `be` for Bankr.

This module provides parameters collected from several YAML definitions
to be used in other Bankr modules.
"""

import sys
from pathlib import Path

import yaml


def read_bankr_yaml(path: Path) -> list | dict:
    """Read parameters from YAML file format."""
    try:
        with open(path, "r") as file:
            bankr_yaml = yaml.safe_load(file)
        return bankr_yaml
    except FileNotFoundError as e:
        sys.exit(f"Bankr Error - YAML file not found.\n{e}")


# Init fixed Bankr parameters
MANDATORIES = ["date", "iban", "cents", "currency", "offset", "category", "tag", "source"]
OPTIONALS = ["valuta", "name", "process", "description", "creditor", "mandate", "customer"]

# Init bankr.yaml parameters
config_path = Path("./bankr.yaml").resolve()
params: dict = read_bankr_yaml(config_path)
BANKR_PATH = Path(__file__).parent.resolve()
try:
    DATA_PATH = Path(params["DATA_PATH"]).resolve()  # TODO Validate DATA_PATH
except KeyError:
    DATA_PATH = Path(".").resolve()
try:
    LOCALE: str = params["LOCALE"]
except KeyError:
    LOCALE: str = "en"
try:
    DATE_FORMAT: str = params["DATE_FORMAT"]
except KeyError:
    DATE_FORMAT: str = "%d.%m.%Y"
try:
    ANCHOR_CURRENCY: str = params["ANCHOR_CURRENCY"]
except KeyError:
    ANCHOR_CURRENCY: str = "€"
try:
    CURRENCIES: list[dict] = params["CURRENCIES"]
except KeyError:
    CURRENCIES: list[dict] = [{"currency": "€", "description": "Euros"}]

# Init other YAML parameters
ACCOUNTS: list[dict] = read_bankr_yaml(DATA_PATH / "accounts.yaml")
BOOK: dict = read_bankr_yaml(DATA_PATH / "book-v3.yaml")
CATEGORIES: list[dict] = read_bankr_yaml(DATA_PATH / "categories.yaml")
FILTERS: list[dict] = read_bankr_yaml(DATA_PATH / "filters.yaml")
TAGS: list[dict] = read_bankr_yaml(DATA_PATH / "tags.yaml")
