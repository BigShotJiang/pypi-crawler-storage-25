"""
Helper module `bh` for Bankr.

This module provides helper functions for TUI messages and data sanitizing.
"""

import os
import re
import sys
from datetime import datetime

import i18n
from dateutil.relativedelta import relativedelta
from pyfiglet import Figlet

from bankr.env import ACCOUNTS, CATEGORIES, TAGS


def title(subtitle: str = "") -> None:
    """Clear CLI and print Bankr title

    Args:
        subtitle (str, optional): Additional subtitle. Defaults to "".
    """
    # Clear CLI
    if os.name == "nt":  # On Windblows
        os.system("cls")
    else:  # On valuable and expensive Linux
        os.system("clear")

    # Print title
    print(Figlet().renderText("Bankr"))
    if subtitle:
        print(f"### {i18n.t('helpers.title')} ### - {subtitle}\n")
    else:
        print(f"### {i18n.t('helpers.title')} ###\n")


def info(info: str = "", **kwargs) -> None:
    """Bankr Info

    Print a short info, except `verbose=False`

    Args:
        info (str): Info. Defaults to "".
    """
    params = {"verbose": True}
    params |= kwargs

    if params["verbose"]:
        print(f"Bankr {i18n.t('helpers.info')} - {info}")


def sanitize_category(category: str = "") -> str:
    """Sanitize the given category.

    Provides a valid `category`, if the category information could be identified uniquely in `categories.yaml`
    or its current translation.

    Args:
        category (str, optional): Category information to be sanitized. Defaults to "".

    Returns:
        str: Sanitized (internal) category as given in categories.yaml or empty string
    """
    candidates: list[str] = []
    for value in CATEGORIES:
        if (category.lower() in value["category"]) or (category in i18n.t("cats." + value["category"])):
            candidates.append(value["category"])
    if len(candidates) == 1:
        return candidates[0]
    else:
        return ""


def sanitize_iban(iban: str = "") -> str:
    """Sanitize a given IBAN or an IBAN fragment.

    The string `iban` is checked against the IBANs within `ACCOUNTS` or `accounts.yaml`.
    If the IBAN could be identified uniquely, it is returned. Unique fragements of IBANs are sufficient.

    Args:
        iban (str, optional): IBAN or IBAN fragment. Defaults to "".

    Returns:
        str: Identified IBAN or empty string
    """
    candidates: list[str] = []
    for value in ACCOUNTS:
        if iban.upper() in value["iban"]:
            candidates.append(value["iban"])
    if len(candidates) == 1:
        return candidates[0]
    else:
        return ""


def sanitize_period(period: str = "-") -> list[datetime]:
    """Sanitize period string.

    Converts a string into a bounds list (datetime of start and end date), empty if invalid.
    YYYY-MM is a month from 1900-01 to 2099-12. YYYY is a year from 1900 to 2099.

    TODO Accept two digit years (separator year?) and quarters/terms.

    Args:
        period (str): A string defining a time period. Defaults to "-", "" not allowed.

    Returns:
        list[datetime]: Bounds of the period, empty if invalid
    """
    # No bounds
    bounds: list = []

    # period = month, from 1900-01 to 2099-12
    if re.match(r"^(19|20)?\d{2}-(0[1-9]|1[0-2])$", period):
        period += "-01"
        start = datetime.strptime(period, "%Y-%m-%d")
        bounds = [start, start + relativedelta(day=31)]
    # period = year, from 1900 to 2099
    if re.match(r"^(19|20)?\d{2}$", period):
        bounds = [datetime(int(period), 1, 1), datetime(int(period), 12, 31)]
    return bounds


def to_cents(x: str) -> str:
    """Filter an "amount of money" string in a CSV.

    Strings indicating a certain amount of money can be quite pathological in CSV files of banks.
    Therefore, these need to be filtered, before being converted to integers:
    1. Limit to acceptable characters `"0123456789.,+- "`.
    2. Only dots as separators of cents and thousands.
    3. "" and "-" give "0".
    4. Minus sign as first character, no plus sign.

    "000" can happen as filter result, but this is fine for integers.
    """
    # Return 0, if invalid digits, check sign
    accept = set("0123456789.,+- ")
    check = set(x)
    if not check.issubset(accept):
        return "0"
    x = x.replace(",", ".").replace("+", "").replace(" ", "")
    if "-" in x:
        x = "-" + x.replace("-", "")
    if len(x) == 0 or x == "-":
        return "0"

    # Normal cases: *.??
    if len(x) > 2 and x[-3] == ".":
        return x.replace(".", "")

    # Pathological cases
    x = x + "00"
    if len(x) == 3:
        return x  # Single digit
    if len(x) >= 4:
        if x[-4] == ".":
            x = x[:-1]  # One digit after separator
        return x.replace(".", "")


def select_category() -> str:
    """Provide CATEGORIES for manual selection.

    The selection is enumerated as they show up in the parameter CATEGORIES (imported from `categories.yaml`).

    Args:
        None.

    Returns:
        Selected category, or empty string for quit.
    """
    # Display categories with enumeration
    for index, category in enumerate(CATEGORIES):
        translated_category = i18n.t("cats." + category["category"])
        truncated_description = category["description"][:58]
        print(f"[{index:>2}] - {translated_category:<15}{truncated_description}")

    print("─" * 80)

    # Get valid user selection
    while True:
        selection_input = input("Bankr Action - Select a category by [number] or (q)uit. ")
        if selection_input == "q":
            return ""
        try:
            selection = int(selection_input)
            if 0 <= selection < len(CATEGORIES):
                break
        except ValueError:
            pass

    return CATEGORIES[selection]["category"]


def describe_tag(tag: str) -> str:
    """Receive the description of a tag"""
    description = ""
    for t in TAGS:
        if t["tag"] == tag:
            description = t["description"]

    return description


def locate_entry(book: Page, entry_id: str) -> Page:
    """Locate an entry in the Book or a Page."""
    try:
        entry = book.loc[[entry_id]]
    except KeyError:
        sys.exit("Bankr Error - Entry not found in the Book.")

    return entry


def confirm_save() -> bool:
    """Confirmation dialog before the Book gets saved/pickled."""
    while True:
        selection = input("Bankr Action - Save the Book (y/n)? ")
        if selection == "y":
            return True
        elif selection == "n":
            return False
