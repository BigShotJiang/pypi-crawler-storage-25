"""
Entry module 'by' for Bankr.

This module provides functions for manipulating Entries.
"""

from datetime import date

import i18n
import inquirer as iq
import pandas as pd

import bankr.helpers as bh
import bankr.page as bp
from bankr.env import ACCOUNTS, BOOK, CATEGORIES, CURRENCIES, MANDATORIES, TAGS

# Type alias for clarity
Page = pd.DataFrame  # Used for a Page and the Book.
Entry = pd.DataFrame  # Used for an Entry.


def empty(iban: str) -> Entry:
    """Create an empty, validated Entry for the given IBAN.

    Args:
        iban: The IBAN for the entry.

    Returns:
        An empty, validated Entry with today's date as date and valuta.
    """

    today = date.today()
    raw_entry = pd.DataFrame({"iban": [iban], "date": [today], "valuta": [today], "cents": ["0"]})
    return bp.validate(raw_entry)


def show(entry: Page, **kwargs) -> None:
    """Show the Figures of an Entry in a tabular view.

    Args:
        entry: An Entry, or the first row of a Page.
        details: If True, show all fields. If False, show only mandatory fields.
        enum: If True, enumerate the lines for reference.
    """

    params = {"details": True, "enum": False, "header": True}
    params |= kwargs

    # Stringify deep copy of entry,
    entry = bp.stringify(entry.copy().iloc[[0]])

    # Figures to show
    figures = []  # New object needed
    figures += MANDATORIES
    if params["details"]:
        try:  # List might be empty
            figures += list(BOOK.keys())
        except AttributeError:
            pass
    figures.remove("currency")

    # Show the Entry
    if params["header"]:
        bh.title("Entry Mode")
    print("━" * 120)
    print(f" {i18n.t('entry.entry_id')}   {entry.index[0]}")
    print("─" * 120)
    for i, figure in enumerate(figures, 1):
        if params["enum"]:
            print(f"  {i:2d}.", end="")
        value = entry[figure].iloc[0]
        print(f"  {i18n.t(f'entry.{figure}'):<20} {value:.94}")
    print("━" * 120, "\n")


def edit(entry: Entry) -> Entry:
    """Edit the Figures of an Entry.

    Args:
        entry: The validated Entry to edit.

    Returns:
        The edited and validated Entry.
    """

    from bankr.helpers import to_cents

    # Extract choices from env
    iban_choices = [account["iban"] for account in ACCOUNTS]
    currency_choices = [currency["currency"] for currency in CURRENCIES]
    category_choices = [category["category"] for category in CATEGORIES]
    tag_choices = [tag["tag"] for tag in TAGS]

    # Get the first row and stringify it
    row = bp.stringify(entry.iloc[[0]].fillna(""))
    entry_id = entry.index[0]

    # Build questions for each column
    ask = []
    for col in row.columns:
        default = row.at[entry_id, col]

        # Special handling for category columns
        if col == "iban":
            ask.append(iq.List(col, message=i18n.t(f"entry.{col}"), choices=iban_choices, default=default))
        elif col == "cents":
            default = default[:-1]  # Remove currency symbol
            ask.append(iq.Text(col, message=i18n.t(f"entry.{col}"), default=default))
        elif col == "currency":
            ask.append(iq.List(col, message=i18n.t(f"entry.{col}"), choices=currency_choices, default=default))
        elif col == "category":
            ask.append(iq.List(col, message=i18n.t(f"entry.{col}"), choices=category_choices, default=default))
        elif col == "tag":
            ask.append(iq.List(col, message=i18n.t(f"entry.{col}"), choices=tag_choices, default=default))
        else:
            ask.append(iq.Text(col, message=i18n.t(f"entry.{col}"), default=default))

    # Prompt user
    editions = iq.prompt(ask)

    # Add entry_id and process cents
    editions["entry_id"] = entry_id
    if "cents" in editions:
        editions["cents"] = bh.to_cents(editions["cents"])

    # Create new entry
    new_entry = pd.DataFrame([editions])
    new_entry.set_index("entry_id", inplace=True)

    return bp.validate(new_entry)
