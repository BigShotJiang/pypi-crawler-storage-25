import typer
from typing import Optional
from pathlib import Path

from tko.app_context import AppContext

# This file contains the root commands that don't belong to a Typer sub-app 
# but will be added directly to the main Typer app.

def register_main_commands(app: typer.Typer):
    @app.command("run", help="Runs a task in raw terminal")
    def run_cmd( # type: ignore
        ctx: typer.Context,
        target_list: Optional[list[str]] = typer.Argument(None, help="Solvers files, test cases or directories containing them"),
        index: Optional[int] = typer.Option(None, "--index", "-i", help="Run a specific test index"),
        pattern: str = typer.Option("@.in @.sol", "--pattern", "-p", help="Input/output file pattern"),
        language: str = typer.Option(None, "--lang", "-l", help="Language for autoloading (e.g. py, cpp, java, go)"),
        filter: bool = typer.Option(False, "--filter", "-f", help="Filter solver files in temporary directory before running"),
        eval: bool = typer.Option(False, "--eval", "-e", help="Show percentage of passed tests"),
        compact: bool = typer.Option(False, "--compact", "-c", help="Hide test case descriptions in failures"),
        none: bool = typer.Option(False, "--none", "-n", help="Hide all failures"),
        all: bool = typer.Option(False, "--all", "-a", help="Show all failures"),
        down: bool = typer.Option(False, "--down", "-d", help="Diff mode: top-to-bottom"),
        side: bool = typer.Option(False, "--side", "-s", help="Diff mode: side-by-side")
    ):
        from tko.cli.common import load_repo
        from tko.util.param import Param
        from tko.util.pattern_loader import PatternLoader
        from tko.enums.diff_count import DiffCount
        from tko.enums.diff_mode import DiffMode
        from tko.cmds.cmd_run import Run
        

        app_ctx: AppContext = AppContext.load_from_context(ctx)
        settings = app_ctx.settings
        
        PatternLoader.pattern = pattern
        param = Param.Basic().set_index(index)
        if none:
            param.set_diff_count(DiffCount.NONE)
        elif all:
            param.set_diff_count(DiffCount.ALL)
        else:
            param.set_diff_count(DiffCount.FIRST)

        if filter:
            param.set_filter(True)
        if compact:
            param.set_compact(True)

        if not side and not down:
            param.set_diff_mode(settings.app.diff_mode if settings else DiffMode.SIDE)
        elif side:
            param.set_diff_mode(DiffMode.SIDE)
        elif down:
            param.set_diff_mode(DiffMode.DOWN)

        changedir = app_ctx.changedir
        repo, _, _ = load_repo(changedir, show_warnings=False, force_offline=True)
        targets = [Path(target) for target in target_list] if target_list else []
        cmd_run = Run(settings, targets, param, language, repo)
        if eval:
            cmd_run.show_track_info().show_self_info()

        cmd_run.execute()

    @app.command("open", help="Open repository in interactive mode")
    def open_cmd(ctx: typer.Context): # type: ignore
        from tko.cli.common import load_repo
        from tko.cmds.cmd_open import CmdOpen
        from tko.config.check_version import CheckVersion

        app_ctx: AppContext = AppContext.load_from_context(ctx)
        settings = app_ctx.settings
        changedir = app_ctx.changedir
        global_cache = app_ctx.global_cache
        update = app_ctx.update
        offline = app_ctx.offline
        
        repo, _, update_mode = load_repo(changedir, show_warnings=True, auto_load=True, global_cache=global_cache, force_update=update)
        if repo is None:
            return
            
        from tko.repository.repository_watcher import RepositoryWatcher
        watcher = RepositoryWatcher(repo).start_watching()
        action = CmdOpen(settings, repo, update_mode)
        
        if not offline:
            if not CheckVersion(settings).is_updated():
                action.display_need_update()
                
        action.execute()
        watcher.stop_watching()

    @app.command("init", help="Initialize empty TKO repository")
    def init_cmd( # type: ignore
        ctx: typer.Context,
        language: Optional[str] = typer.Option(None, "--language", "-l", help="Default repository language (e.g. py, cpp, java, go)")
    ):
        from tko.repository.repository_starter import RepositoryStarter
        
        app_ctx: AppContext = AppContext.load_from_context(ctx)
        settings = app_ctx.settings
        changedir = app_ctx.changedir
        
        rep_starter = RepositoryStarter(settings=settings, folder=changedir, language=language)
        rep_starter.execute()
