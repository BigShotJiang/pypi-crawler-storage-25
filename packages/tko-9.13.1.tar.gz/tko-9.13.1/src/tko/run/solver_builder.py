import tempfile
from collections.abc import Callable

import os
import shutil
from tko.util.rtext import RText
from tko.util.runner import Runner
from tko.config.settings import Settings
from pathlib import Path
from tko.run_build.ts_macro_preprocessor import TypeScriptMacroPreprocessor

class CompileError(Exception):
    def __init__(self, message: str):
        self.message = message

    def __str__(self):
        return self.message

class Executable:
    def __init__(self, cmd: list[str] | str | None, files: list[Path] | None, folder: Path):
        if cmd is None:
            cmd = []
        if files is None:
            files = []
        self.__cmd_list: list[str] | str = cmd
        self.__folder: Path = folder
        self.__compiled: bool = False
        self.__compile_error: bool = False
        self.__error_msg: RText = RText()
        self.__shell_mode: bool = False # subprocess needs bash mode to process symbols like & or |
    
    def needs_shell_mode(self):
        return self.__shell_mode
    
    def set_executable(self, cmd: list[str] | str, files: list[Path], folder: Path, shell_mode: bool):
        self.__compiled = True
        self.__cmd_list = cmd
        self.__files: list[Path] = files
        self.__folder: Path = folder.resolve()
        self.__shell_mode = shell_mode
        return self
    
    def get_command(self) -> tuple[list[str] | str, Path]:
        cmd: list[str] | str = self.__cmd_list
        if isinstance(cmd, str):
            cmd += " " + " ".join([str(file.resolve()) for file in self.__files])
        else:
            cmd += [str(file.resolve()) for file in self.__files]
        return cmd, self.__folder

    def set_compile_error(self, error_msg: RText | str):
        self.__compiled = True
        self.__compile_error = True
        if isinstance(error_msg, str):
            self.__error_msg = RText(error_msg)
        else:
            self.__error_msg = error_msg
        return self
    
    def compiled(self):
        return self.__compiled

    def has_compile_error(self):
        return self.__compiled and self.__compile_error
    
    def get_error_msg(self):
        return self.__error_msg

class SolverBuilder:
    TS_DEFAULT_BUILD_CMD = "npx esbuild {files} --outdir={cache} --format=cjs --log-level=error"
    TS_DEFAULT_RUN_CMD = "node {entry}"

    def __init__(self, args_list: list[Path], settings: Settings):
        self.settings = settings
        self.args_list: list[Path] = args_list
        self.cache_dir: Path = Path()
        if len(self.args_list) > 0:
            self.cache_dir = self.args_list[0].parent / ".build"
        else:
            self.cache_dir = Path(tempfile.mkdtemp())
        self.clear_cache()
        self.__exec: Executable = Executable(cmd=None, files=None, folder=Path(""))

    def check_tool(self, name: str):
        if shutil.which(name) is None:
            self.__exec.set_compile_error(RText.parse(f"[r]Falha: O comando '{name}' não foi encontrado[.]")) 
            raise CompileError("fail: comando '" + name + "' não foi encontrado")

    def not_compiled(self):
        return not self.__exec.compiled()

    def has_compile_error(self):
        return self.__exec.has_compile_error()

    def set_main(self, main: str):
        list_main: list[Path] = []
        list_other: list[Path] = []

        for path in self.args_list:
            if path.name == main:
                list_main.append(path)
            else:
                list_other.append(path)

        self.args_list = list_main + list_other
        return self

    def clear_cache(self):
        if os.path.exists(self.cache_dir):
            shutil.rmtree(self.cache_dir, ignore_errors=True)
        os.makedirs(self.cache_dir, exist_ok=True)

    def get_executable(self, force_rebuild: bool = False) -> tuple[Executable, bool]:
        if not self.args_list:
            return Executable(cmd=None, files=None, folder=Path("")), False
        if self.__exec.has_compile_error():
            return self.__exec, False
        if not self.__exec.compiled() or force_rebuild:
            self.prepare_exec()
        return self.__exec, True

    def reset(self):
        self.__exec = Executable(cmd=None, files=None, folder=Path(""))
        self.clear_cache()

    def prepare_exec(self) -> None:
        self.reset()
        first = self.args_list[0]

        handlers: dict[str, Callable[[], None]] = {
            ".mk": self.__prepare_make,
            ".ts": self.__prepare_ts,
        }
        handler = handlers.get(first.suffix)

        if handler is not None:
            handler()
        elif first.suffix[1:] in self.settings.get_languages_settings().get_languages().keys():
            self.prepare_exec_with_lang()
        else:
            self.__exec.set_executable([str(x) for x in self.args_list], [], Path(""), shell_mode=True)

    def replace_placeholders(self, text: str) -> str:
        parent_folder = self.args_list[0].parent
        main_file_without_ext = self.args_list[0].stem
        exe_ext = ".exe" if os.name == "nt" else ""
        output_path = self.cache_dir / ("a.out" + exe_ext)
        entry_path = self.cache_dir / (main_file_without_ext + ".js")
        
        files_str = " ".join([f'"{str(x.relative_to(parent_folder, walk_up=True))}"' for x in self.args_list])
        text = (text.replace("{files}", files_str)
                    .replace("{output}", f'"{str(output_path.relative_to(parent_folder, walk_up=True))}"')
                    .replace("{main}", main_file_without_ext)
                    .replace("{cache}", f'"{str(self.cache_dir.relative_to(parent_folder, walk_up=True))}"')
                    .replace("{entry}", f'"{str(entry_path.relative_to(parent_folder, walk_up=True))}"')).strip()

        return text

    def prepare_exec_with_lang(self):
        lang = self.settings.get_languages_settings().get_languages().get(self.args_list[0].suffix[1:], None)
        if lang is None:
            self.__exec.set_compile_error(RText.parse(f"[r]Falha: Extensão de arquivo '{self.args_list[0].suffix}' não reconhecida e sem configuração de linguagem[.]"))
            return
        self._prepare_exec_with_commands(lang.build_cmd, lang.run_cmd)

    def _prepare_exec_with_commands(self, build_cmd: str, run_cmd: str):
        parent_folder = self.args_list[0].parent
        build_cmd = self.replace_placeholders(build_cmd)
        return_code, stdout, stderr = Runner.subprocess_run(build_cmd, folder=parent_folder, shell_mode=True)
        if return_code != 0:
            self.__exec.set_compile_error(stdout + stderr)
            return
        run_cmd = self.replace_placeholders(run_cmd)
        self.__exec.set_executable(run_cmd, [], parent_folder, shell_mode=True)

    def __prepare_make(self):
        self.check_tool("make")
        solver = os.path.abspath(self.args_list[0])
        folder = os.path.dirname(solver)
        cmd = ["make", "-s", "-C", folder, "-f", solver, "build"]
        return_code, stdout, stderr = Runner.subprocess_run(cmd)
        if return_code != 0:
            self.__exec.set_compile_error(stdout + stderr)
        else:
            self.__exec.set_executable(cmd=["make", "-s", "-C", folder, "-f", solver, "run"], files=[], folder=Path(""), shell_mode=False)

    def __prepare_ts(self):
        copy_dir = self.cache_dir / "src"
        if copy_dir.exists():
            shutil.rmtree(copy_dir, ignore_errors=True)
        new_files = TypeScriptMacroPreprocessor.copy_and_patch(self.args_list, copy_dir)

        transpiler = "npx"
        if os.name == "nt":
            transpiler += ".cmd"

        self.check_tool(transpiler)
        self.check_tool("node")

        original_args = self.args_list
        self.args_list = new_files
        try:
            lang = self.settings.get_languages_settings().get_languages().get("ts", None)
            if lang is None:
                self.__exec.set_compile_error(RText.parse("[r]Falha: Configuração da linguagem 'ts' não encontrada[.]"))
                return
            build_cmd = lang.build_cmd.strip() if lang.build_cmd is not None else ""
            run_cmd = lang.run_cmd.strip() if lang.run_cmd is not None else ""
            if build_cmd == "":
                build_cmd = self.TS_DEFAULT_BUILD_CMD
            if run_cmd == "":
                run_cmd = self.TS_DEFAULT_RUN_CMD
            self._prepare_exec_with_commands(build_cmd, run_cmd)
        finally:
            self.args_list = original_args
