#! /usr/bin/env python3
# -*- coding:utf-8 -*-
# @Time : 2026/04/27 15:41 
# @Author : JY
"""
邮箱系统

SMTP文档发邮件 https://help.aliyun.com/zh/document_detail/36687.html?spm=a2c4g.11186623.help-menu-35466.d_8_2_1.5c3a6f1afRtJFM
IMAP收邮件 https://help.aliyun.com/zh/document_detail/2857997.html?spm=a2c4g.11186623.help-menu-35466.d_8_2_2_2.12d268514SitpD
"""
import smtplib
import email
import imaplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from email.header import Header
from email.header import decode_header
from email.utils import parseaddr
from email.utils import parsedate_to_datetime
import re
import os
import ssl
import hashlib
import datetime
from typing import Union, List, Tuple


class mailHelper:
    # 阿里企业邮箱默认参数
    ALI_SMTP_SERVER = 'smtp.qiye.aliyun.com'
    ALI_SMTP_PORT = 25
    ALI_IMAP_SERVER = 'imap.qiye.aliyun.com'
    ALI_IMAP_PORT = 993

    def __init__(self, smtp_server=None, smtp_port=None, smtp_client_type=1, imap_server=None, imap_port=None,
                 username=None, password=None, use_ali_param=False):
        """
        :param smtp_server: 发件SMTP
        :param smtp_port: 发件SMTP
        :param smtp_client_type: 发件SMTP认证方式 1/2/3
        :param imap_server: 收件IMAP
        :param imap_port: 收件IMAP
        :param username: 邮箱地址
        :param password: 密码
        :param use_ali_param: 是否使用预设的ALI_参数, 使用了预设就不用再挨个设置SMTP和IMAP了
        """
        if use_ali_param:
            smtp_server = self.ALI_SMTP_SERVER
            smtp_port = self.ALI_SMTP_PORT
            imap_server = self.ALI_IMAP_SERVER
            imap_port = self.ALI_IMAP_PORT
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.smtp_client_type = smtp_client_type
        self.imap_server = imap_server
        self.imap_port = imap_port
        self.username = username
        self.password = password
        if self.username is None or self.password is None:
            raise Exception("需要参数: username/password, 配置邮箱和密码")
        # self.use_smtp = False
        # if smtp_server is not None:
        #     if not smtp_server:
        #         raise Exception("需要参数: smtp_server")
        #     if not smtp_port:
        #         raise Exception("需要参数: smtp_port")
        #     if not username:
        #         raise Exception("需要参数: username")
        #     if not password:
        #         raise Exception("需要参数: password")
        #     self.use_smtp = True
        # else:
        #     raise Exception('未配置任何认证方式')

    @staticmethod
    def is_email(email_str: str) -> bool:
        if email_str.__len__() > 5 and re.match('^[A-Za-z0-9_.]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$',
                                                email_str) is not None:
            return True
        return False

    @staticmethod
    def _clean_text(s):
        """清理字符串空白字符"""
        return ("".join(s.split()) if s else "").replace('&nbsp;', '').replace('&lt;', '').replace('&gt;', '')

    @staticmethod
    def _decode_str(s):
        """解码邮件标题/发件人（解决中文乱码）"""
        value, charset = decode_header(s)[0]
        if charset:
            try:
                value = value.decode(charset)
            except:
                value = str(value)
        return str(value)

    @staticmethod
    def _md5(string: str) -> str:
        """对字符串进行md5编码"""
        string = string if isinstance(string, str) else str(string)
        hash_obj = hashlib.md5()
        hash_obj.update(string.encode('utf-8'))
        return hash_obj.hexdigest()

    @staticmethod
    def _to_imap_date(standard_date: str) -> str:
        """
        输入：2024-01-10  (YYYY-MM-DD)
        输出：10-Jan-2024 (IMAP搜索专用格式)
        """
        dt = datetime.datetime.strptime(standard_date, "%Y-%m-%d")
        return dt.strftime("%d-%b-%Y")

    # 解析邮件正文（兼容 纯文本+HTML 格式，核心修复！）
    @staticmethod
    def _get_email_content(msg):
        """
        你的邮件：text/plain 是无用代码，text/html 才是真实正文
        逻辑：优先提取 HTML 正文，无 HTML 再用纯文本
        """
        text_content = ""  # 纯文本内容（无用）
        html_content = ""  # HTML内容（你的真实正文）
        # 遍历所有邮件节点，穿透嵌套
        for part in msg.walk():
            ctype = part.get_content_type()
            # 跳过所有容器类型（必须跳！）
            if ctype in ["multipart/mixed", "multipart/alternative"]:
                continue
            # 跳过附件
            if part.get("Content-Disposition") is not None:
                continue

            # 1. 读取纯文本（你的无用代码）
            if ctype == "text/plain":
                try:
                    text_content = part.get_payload(decode=True).decode("utf-8")
                except:
                    text_content = part.get_payload(decode=True).decode("gbk", "ignore")

            # 2. 读取HTML（你的真实正文！！！）
            if ctype == "text/html":
                try:
                    html_content = part.get_payload(decode=True).decode("utf-8")
                except:
                    html_content = part.get_payload(decode=True).decode("gbk", "ignore")

        # 核心：优先用 HTML 真实内容，没有再用纯文本
        if html_content:
            # 清理HTML标签，得到纯文字正文
            text_str = re.sub(r"<[^>]+>", "", html_content)
            html_str = html_content
        else:
            text_str = text_content
            html_str = text_content

        return mailHelper._clean_text(text_str), html_str

    @staticmethod
    def _save_attachments(msg, save_dir, msg_uuid):
        """保存所有附件，返回附件名列表"""
        attachment_names = []
        if save_dir is None:
            return attachment_names
        for part in msg.walk():
            # 判断：是否为附件
            if part.get("Content-Disposition") is None:
                continue

            # 解码附件文件名（解决中文乱码）
            filename = mailHelper._decode_str(part.get_filename())
            if not filename:
                continue

            # 自动创建附件文件夹
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
            # 保存附件二进制数据
            today = datetime.datetime.now().strftime('%Y%m%d')
            file_path = os.path.join(save_dir, today + '-' + msg_uuid + '-' + filename)
            with open(file_path, "wb") as f:
                f.write(part.get_payload(decode=True))
            attachment_names.append(file_path)
        return attachment_names

    def send(self, to, cc=None, bcc=None, title=None, content=None, fj=None, reply_to=None) -> bool:
        """
        发送邮件\n
        :param to: 收件人 可以是单个,也可以列表表示多个\n
        :param cc: 抄送 可以是单个,也可以列表表示多个\n
        :param bcc: 密送 可以是单个,也可以列表表示多个\n
        :param title: 标题\n
        :param content: 正文\n
        :param fj: 附件文件 可以是单个,也可以列表表示多个\n
        :param reply_to: 回复地址,默认收件地址\n
        :return: bool 成功/失败\n
        """
        to = [to] if not isinstance(to, list) else to
        cc = [] if cc is None else cc
        cc = [cc] if not isinstance(cc, list) else cc
        bcc = [] if bcc is None else bcc
        bcc = [bcc] if not isinstance(bcc, list) else bcc
        title = 'undefined title' if title is None else title
        content = 'undefined content' if content is None else content
        # 排除掉不合规的邮箱地址
        receivers = to + cc + bcc
        receivers = [one for one in receivers if self.is_email(one)]
        # 发送邮件
        try:
            client = self._get_client('send')
            # 构建alternative结构
            msg = MIMEMultipart('mixed')
            msg['Subject'] = Header(title).encode()
            msg['From'] = '%s <%s>' % (Header(self.username.split('@')[0]).encode(), self.username)
            msg['To'] = ','.join(to)
            msg['Cc'] = ",".join(cc)
            msg['Reply-to'] = self.username if reply_to is None else reply_to
            msg['Message-id'] = email.utils.make_msgid()
            msg['Date'] = email.utils.formatdate()
            # 构建alternative的text/plain部分
            alternative = MIMEMultipart('alternative')
            textplain = MIMEText('自定义TEXT纯文本部分', _subtype='plain', _charset='UTF-8')
            alternative.attach(textplain)
            # 构建alternative的text/html部分
            texthtml = MIMEText(content, _subtype='html', _charset='UTF-8')
            alternative.attach(texthtml)
            # 将 alternative 加入 mixed 的内部
            msg.attach(alternative)
            # 添加附件
            if fj is not None:
                if not isinstance(fj, list):
                    fj = [fj]
                for one_fj in fj:
                    fj_file = MIMEApplication(open(one_fj, 'rb').read())
                    fj_file.add_header('Content-Disposition', 'attachment',
                                       filename=Header(os.path.basename(one_fj), "utf-8").encode())
                    msg.attach(fj_file)
            client.sendmail(self.username, receivers, msg.as_string())  # 支持多个收件人，具体数量参考规格清单
            client.quit()
            print('邮件发送成功！')
            return True
        except smtplib.SMTPConnectError as e:
            print('邮件发送失败，连接失败:', e.smtp_code, e.smtp_error)
            return False
        except smtplib.SMTPAuthenticationError as e:
            print('邮件发送失败，认证错误:', e.smtp_code, e.smtp_error)
            return False
        except smtplib.SMTPSenderRefused as e:
            print('邮件发送失败，发件人被拒绝:', e.smtp_code, e.smtp_error)
            return False
        except smtplib.SMTPRecipientsRefused as e:
            print('邮件发送失败，收件人被拒绝:', e.smtp_code, e.smtp_error)
            return False
        except smtplib.SMTPDataError as e:
            print('邮件发送失败，数据接收拒绝:', e.smtp_code, e.smtp_error)
            return False
        except smtplib.SMTPException as e:
            print('邮件发送失败, ', str(e))
            return False
        except Exception as e:
            print('邮件发送异常, ', str(e))
            return False

    def _get_client(self, send_or_get):
        client = None
        if send_or_get == 'send':
            if self.smtp_server:
                ########### 配置客户端 ###########
                if self.smtp_client_type == 1:
                    # SMTP普通端口为25
                    client = smtplib.SMTP(self.smtp_server, self.smtp_port, timeout=10)
                elif self.smtp_client_type == 2:
                    # 若需要加密使用SSL，可以这样创建client
                    client = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port)
                elif self.smtp_client_type == 3:
                    # python 3.10/3.11新版本若出现ssl握手失败,请使用下列方式处理：
                    ctxt = ssl.create_default_context()
                    ctxt.set_ciphers('DEFAULT')
                    client = smtplib.SMTP_SSL(self.smtp_server, self.smtp_port, context=ctxt)
                else:
                    raise Exception('参数 smtp_client_type 错误')
                client.login(self.username, self.password)
            else:
                raise Exception('发邮件未配置任何认证方式')
        if send_or_get == 'get':
            # 1. 连接IMAP服务器（SSL加密，安全）
            client = imaplib.IMAP4_SSL(self.imap_server, self.imap_port)
            # 2. 登录邮箱
            client.login(self.username, self.password)
        if client is None:
            raise Exception('初始化客户端错误')
        return client

    def search(self, latest: int = None, day_start: str = None, day_end: str = None, fj_save_dir: str = None) -> list:
        """
        查询收件箱\n
        :param latest: 返回最新的多少封邮件 默认全部\n
        :param day_start: 从哪天(包括)开始的邮件\n
        :param day_end: 截止哪天(不包括)  开始和结束时间相同 就表示只查询那一天\n
        :param fj_save_dir: 附件保存路径,默认不下载附件\n
        :return: [{
                    'id':mail_id.decode(),
                    'uuid':msg_uuid,
                    'from_name': from_name,
                    'from_email': from_addr,
                    'time': formatted_date,
                    'title': subject,
                    'content_text':text_str,
                    'content_html': html_str,
                    'fj':attachments
                }]
        """
        client = self._get_client('get')
        # 选择收件箱（INBOX=收件箱，固定写法）
        client.select("INBOX")
        """
        # search 示例
        # status, messages = mail.search(None, 'SEEN')  # 已读
        # status, messages = mail.search(None, 'UNSEEN')  # 未读
        # status, messages = mail.search(None, 'ALL')  # 全部
        # status, messages = mail.search(None, '(SEEN)')  # 另一种写法
        # status, messages = mail.search(None, '(SEEN UNSEEN)')  # 支持多条件
        # status, messages = mail.search(None, 'SEEN', ' UNSEEN')  # 支持多条件,逗号间隔
        # status, messages = mail.search(None, '1')  # UID
        # status, messages = mail.search(None, '(1 2)')  # UIDs #支持多UID
        # status, messages = mail.search(None, 'ON 10-Jan-2024')  # 搜索某一天的邮件
        # status, messages = mail.search(None, 'SINCE 10-Jan-2024')  # 搜索大于等于某天的邮件
        # status, messages = mail.search(None, "(SINCE 05-Dec-2023 BEFORE 12-Jan-2024)")  # SINCE代表开始，BEFORE代表结束
        # status, messages = mail.search(None, 'BEFORE', '12-Jan-2024', 'SEEN')  # 搜索某个日期前的邮件，不包含该日期
        # status, messages = mail.search(None, 'BEFORE', '12-Jan-2024', 'SEEN', 'ON 05-Dec-2023')  # 支持多条件，ON 是搜索某一天的邮件
        # status, messages = mail.search(None, 'BEFORE 12-Jan-2024', 'SEEN', 'ON 05-Dec-2023')  # 另一种写法
        # status, messages = mail.search(None, 'BEFORE 12-Jan-2023 SEEN ON 05-Dec-2022')
        # status, messages = mail.search(None, "SENTSINCE 26-Mar-2024")  # 自某个日期以来发送的邮件
        """
        searchCondition = "ALL"
        if day_start is not None and day_end is None:
            # 只传入了开始时间
            searchCondition = 'SINCE %s' % self._to_imap_date(day_start)
        if day_start is None and day_end is not None:
            # 只传入了结束时间
            searchCondition = 'BEFORE %s' % self._to_imap_date(day_end)
        if day_start is not None and day_end is not None:
            # 开始和结束时间都传了
            if day_start == day_end:
                searchCondition = 'ON %s' % self._to_imap_date(day_start)
            else:
                searchCondition = '(SINCE %s BEFORE %s)' % (self._to_imap_date(day_start), self._to_imap_date(day_end))
        status, messages = client.search(None, searchCondition)
        mail_ids = messages[0].split()  # 所有邮件ID
        mail_ids = mail_ids[::-1]
        if latest is not None:
            mail_ids = mail_ids[:latest]
        result = []
        for mail_id in mail_ids:
            # 获取邮件完整内容
            status, msg_data = client.fetch(mail_id, "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    # 解析邮件
                    msg = email.message_from_bytes(response_part[1])

                    # 解析 发件人
                    from_name, from_addr = parseaddr(msg.get("From", ""))
                    # from_name = self._decode_str(from_name)

                    # 解析 主题
                    subject = self._decode_str(msg.get("Subject", "无主题"))

                    # 解析 时间
                    date1 = msg.get('Received').split(';')[-1].strip().split(' at ')[-1].strip()
                    date2 = msg.get("Date", "")
                    date = date1 if date1 else date2
                    try:
                        # 解析邮件标准时间 → 转datetime对象
                        dt = parsedate_to_datetime(date)
                        # 格式化为：xxxx-xx-xx xx:xx:ss
                        formatted_date = dt.strftime("%Y-%m-%d %H:%M:%S")
                        # 添加时区到日期后面
                        time_zone = str(date)[-5:]
                        formatted_date += f' {time_zone}'
                    except:
                        formatted_date = date

                    # 解析 邮件正文
                    text_str, html_str = self._get_email_content(msg)
                    msg_uuid = mailHelper._md5(str(msg))
                    # 下载附件
                    attachments = self._save_attachments(msg=msg, save_dir=fj_save_dir, msg_uuid=msg_uuid)

                    # 打印结果
                    # print("-" * 50)
                    # print(f"邮件ID: {mail_id.decode()}")
                    # print(f"邮件UUID: {msg_uuid}")
                    # print(f"发件人: {from_name} <{from_addr}>")
                    # print(f"主  题: {subject}")
                    # print(f"时  间: {formatted_date}")
                    # print(f"正  文: {text_str}")
                    # print(f"正  文: {html_str}")
                    # if attachments:
                    #     for one_fj in attachments:
                    #         print(f"✅ 已下载附件: {one_fj}")
                    # else:
                    #     print("📎 无附件")
                    result.append({
                        'index': int(mail_id.decode()),
                        'id': msg_uuid,
                        'sender': from_addr,
                        'time': formatted_date,
                        'subject': subject,
                        'str': text_str,
                        'html': html_str,
                        'fj': attachments
                    })

        # 退出登录
        client.logout()
        return result

    def delete(self, search_return_id: Union[str, List[str]]) -> int:
        """
        根据收件箱中的唯一ID,删除邮件,可以一次性传入多个ID删除多个\n
        :param search_return_id:
        :return: 删除的邮件数量
        """
        if not isinstance(search_return_id, list):
            search_return_id = [search_return_id]
        client = self._get_client('get')
        # 选择收件箱（INBOX=收件箱，固定写法）
        client.select("INBOX")
        searchCondition = "ALL"
        status, messages = client.search(None, searchCondition)
        mail_ids = messages[0].split()  # 所有邮件ID
        del_num = 0
        for mail_id in mail_ids:
            # 获取邮件完整内容
            status, msg_data = client.fetch(mail_id, "(RFC822)")
            for response_part in msg_data:
                if isinstance(response_part, tuple):
                    # 解析邮件
                    msg = email.message_from_bytes(response_part[1])
                    # 解析 邮件正文
                    message_id = mailHelper._md5(str(msg))
                    if message_id in search_return_id:
                        client.store(mail_id, "+FLAGS", r"\Deleted")  # 加删除标记
                        del_num += 1
        client.expunge()  # 永久删除所有标记邮件
        # 退出登录
        client.logout()
        return del_num


if __name__ == '__main__':
    pass
    # 发邮件
    # mailIns = mailHelper(use_ali_param=True,username='notice@xxxx.com',password='xxxx')
    # mailIns.send(to='kf@xxxx',title='xxxx',content='xxxx')

    # 收件箱
    # mailIns = mailHelper(use_ali_param=True, username='kf@xxxx.com', password='xxxx')
    # mailIns.search(fj_save_dir='D:\downloads\Textures-Item1', day_end='2026-04-28', day_start='2026-04-27')

    EMAIL_USERNAME = ""
    EMAIL_PASSWORD = ""
    mailIns = mailHelper(use_ali_param=True, username=EMAIL_USERNAME, password=EMAIL_PASSWORD)
    for row in mailIns.search(day_start='2026-04-27'):
        print(row)
    print(mailIns.delete(['1a11402e1200b48295ed806c76a8024a','3e61ab856a850b76a5b51c65a1800c3a']))
