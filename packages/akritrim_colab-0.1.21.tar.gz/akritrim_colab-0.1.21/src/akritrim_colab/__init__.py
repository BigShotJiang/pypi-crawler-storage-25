"""Standalone collab TUI package."""

