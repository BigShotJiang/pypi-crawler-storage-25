# BSG-IDE - Beamer Slide Generator IDE

**Version 5.1.4**

Beamer Slide Generator IDE - Create professional LaTeX presentations with multimedia support

## Installation

```bash
pip install bsg-ide
```

## Usage

```bash
bsg-ide
```