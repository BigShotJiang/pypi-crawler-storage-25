from __future__ import annotations

from typing import Literal
from warnings import warn

import numpy as np

from spgrep._constants import ATOL, MAX_NUM_RANDOM_GENERATIONS, RTOL
from spgrep.rep.enumerate import enumerate_unitary_irreps_from_regular_representation
from spgrep.rep.group import get_identity_index, get_inverse_index, get_order
from spgrep.rep.irreps import frobenius_schur_indicator, is_equivalent_irrep
from spgrep.rep.representation import get_character, get_intertwiner
from spgrep.utils import NDArrayComplex, NDArrayFloat, NDArrayInt, nroot

from .group import (
    get_cayley_table,
    get_factor_system_from_little_group,
)
from .pir import _make_physically_irreps_from_complex
from .pointgroup import get_pointgroup_chain_generators
from .representation import get_projective_regular_representation


def enumerate_small_representations(
    little_rotations: NDArrayInt,
    little_translations: NDArrayFloat,
    kpoint: NDArrayFloat,
    real: bool = False,
    method: Literal["Neto", "random"] = "Neto",
    rtol: float = RTOL,
    atol: float = ATOL,
    max_num_random_generations: int = MAX_NUM_RANDOM_GENERATIONS,
) -> tuple[list[NDArrayComplex], list[int]] | tuple[list[NDArrayFloat], list[int]]:
    r"""Enumerate all unitary small representations of little group.

    Parameters
    ----------
    little_rotations: array, (order, 3, 3)
    little_translations: array, (order, 3)
    kpoint: array, (3, )
    real: bool, default=False
        If True, return irreps over real vector space (so called physically irreducible representations).
        For type-II and type-III cases, representation matrix for translation :math:`(\mathbf{E}, \mathbf{t})` is chosen as

        .. math::
           \begin{pmatrix}
           \cos (\mathbf{k} \cdot \mathbf{t}) \mathbf{1}_{d} & -\sin (\mathbf{k} \cdot \mathbf{t}) \mathbf{1}_{d} \\
           \sin (\mathbf{k} \cdot \mathbf{t}) \mathbf{1}_{d} & \cos (\mathbf{k} \cdot \mathbf{t}) \mathbf{1}_{d} \\
           \end{pmatrix}

        where :math:`\mathbf{k}` is `kpoint`.

    method: str, 'Neto' or 'random'
        'Neto': construct irreps from a fixed chain of subgroups of little co-group
        'random': construct irreps by numerically diagonalizing a random matrix commute with regular representation
    rtol: float
        Relative tolerance to distinguish difference eigenvalues
    atol: float
        Relative tolerance to compare
    max_num_random_generations: int
        Maximum number of trials to generate random matrix

    Returns
    -------
    irreps: list of unitary small representations (irreps of little group) with (order, dim, dim)
    indicators: list of int
        Frobenius-Schur indicator of composed irreps of each physically irreducible representation.
    """
    factor_system = get_factor_system_from_little_group(
        little_rotations, little_translations, kpoint
    )

    # Compute irreps of little co-group
    little_cogroup_irreps, _ = enumerate_unitary_irreps(
        little_rotations,
        factor_system,
        method=method,
        rtol=rtol,
        atol=atol,
        max_num_random_generations=max_num_random_generations,
    )

    # Small representations of little group
    phases = np.array([np.exp(-2j * np.pi * np.dot(kpoint, t)) for t in little_translations])
    irreps = [rep * phases[:, None, None] for rep in little_cogroup_irreps]

    if not real:
        indicators = [frobenius_schur_indicator(irrep) for irrep in irreps]
        return irreps, indicators

    return _make_physically_irreps_from_complex(
        irreps,
        kpoint=kpoint,
        atol=atol,
        max_num_random_generations=max_num_random_generations,
    )


def enumerate_unitary_irreps(
    rotations: NDArrayInt,
    factor_system: NDArrayComplex | None = None,
    real: bool = False,
    method: Literal["Neto", "random"] = "Neto",
    rtol: float = RTOL,
    atol: float = ATOL,
    max_num_random_generations: int = MAX_NUM_RANDOM_GENERATIONS,
) -> tuple[list[NDArrayComplex] | list[NDArrayFloat], list[int]]:
    """Enumerate all unitary irreps with of matrix group ``rotations`` with ``factor_system``.

    Parameters
    ----------
    rotations: array, (order, 3, 3)
    factor_system: array, (order, order)
        If not specified, treat as ordinary representation.
    real: bool, default=False
        If True, return irreps over real vector space (so called physically irreducible representations)
    method: str, 'Neto' or 'random'
        'Neto': construct irreps from a fixed chain of subgroups of little co-group
        'random': construct irreps by numerically diagonalizing a random matrix commute with regular representation
    rtol: float
        Relative tolerance to distinguish difference eigenvalues
    atol: float
        Relative tolerance to compare
    max_num_random_generations: int
        Maximum number of trials to generate random matrix

    Returns
    -------
    irreps: list of unitary irreps with (order, dim, dim)
    indicators: list of int
        Frobenius-Schur indicator of composed irreps of each physically irreducible representation.
    """
    order = rotations.shape[0]
    if factor_system is None:
        factor_system = np.ones((order, order), dtype=np.complex128)

    if method == "Neto":
        table = get_cayley_table(rotations)
        solvable_chain_generators = get_pointgroup_chain_generators(rotations)
        irreps = enumerate_unitary_irreps_from_solvable_group_chain(
            table,
            factor_system,
            solvable_chain_generators,
            atol=atol,
            max_num_random_generations=max_num_random_generations,
        )
    elif method == "random":
        reg = get_projective_regular_representation(rotations, factor_system)
        irreps = enumerate_unitary_irreps_from_regular_representation(
            reg, rtol=rtol, max_num_random_generations=max_num_random_generations
        )
    else:
        raise ValueError(f"Unknown method to compute irreps: {method}")

    # Purify values of `irreps`.
    for irrep in irreps:
        irrep = purify_irrep_value(irrep, atol=atol)

    if not real:
        indicators = [frobenius_schur_indicator(irrep) for irrep in irreps]
        return irreps, indicators

    return _make_physically_irreps_from_complex(
        irreps,
        kpoint=None,
        atol=atol,
        max_num_random_generations=max_num_random_generations,
    )


def enumerate_unitary_irreps_from_solvable_group_chain(
    table: NDArrayInt,
    factor_system: NDArrayComplex,
    solvable_chain_generators: list[int],
    atol: float = ATOL,
    max_num_random_generations: int = MAX_NUM_RANDOM_GENERATIONS,
):
    r"""Calculate symmetrized irreps from given chain of solvable group.

    Parameters
    ----------
    table: array, (order, order)
        Cayley table
    factor_system: array, (order, order)
    solvable_group_chain: list of single generator of coset
        Let :math:`G_{0} := G` and :math:`G_{i} := G_{i-1} / \langle` ``solvable_chain_generators[i]`` :math:`\rangle` (i = 0, 1, ...).
        Then, :math:`G_{i}` is normal subgroup of :math:`G_{i-1}` and factor group :math:`G_{i-1}/G_{i}` is Abelian.

    atol: float
        Absolute tolerance to distinguish difference eigenvalues
    max_num_random_generations: int
        Maximum number of trials to generate random matrix

    Returns
    -------
    irreps: list of unitary projective irrep with (order, dim, dim)
    """
    identity = get_identity_index(table)
    group = [identity]  # int -> GroupIdx
    irreps = [np.ones((1, 1, 1), dtype=np.complex128)]

    # Extend subgroups from identity to whole
    for r in solvable_chain_generators[::-1]:
        # Should be power of prime number
        p = get_order(table, r)

        # Power of `r`, rm[m] = r^m
        # Power of inverse of `coset_generator`, rminv[m] = r^-m
        rm = [identity]
        rinvm = [identity]
        rinv = get_inverse_index(table, r)
        for m in range(1, p):
            rm.append(table[rm[m - 1], r])
            rinvm.append(table[rinvm[m - 1], rinv])

        # Extend group by generator `r`
        subgroup = group[:]
        group = []
        for m in range(p):
            group.extend([table[rm[m], s] for s in subgroup])
        group = sorted(list(set(group)))

        subgroup_remapping = {}  # GroupIdx -> int for `subgroup`
        for i, si in enumerate(subgroup):
            subgroup_remapping[si] = i
        group_remapping = {}  # GroupIdx -> int for `group`
        for i, gi in enumerate(group):
            group_remapping[gi] = i

        # Consider induced representation and their decomposition
        next_sub_irreps = []
        for sub_irrep in irreps:
            dim = sub_irrep.shape[1]

            # Conjugated irreps with `sub_irrep`
            conj_sub_irreps = []
            for j in range(p):
                conj_sub_irrep = []
                for s in subgroup:
                    sj = table[rinvm[j], table[s, rm[j]]]
                    conj_sub_irrep.append(
                        factor_system[s, rm[j]]
                        / factor_system[rm[j], sj]
                        * sub_irrep[subgroup_remapping[sj]]
                    )
                conj_sub_irreps.append(np.array(conj_sub_irrep))

            # Check conjugated irreps are mutually equivalent or not, and construct induced representation
            conj_characters = [get_character(conj_sub_irrep) for conj_sub_irrep in conj_sub_irreps]
            if is_equivalent_irrep(conj_characters[0], conj_characters[1]):
                # Self-conjugated case

                # Scale intertwiner s.t. intertwiner^p == identity
                intertwiner = get_intertwiner(
                    conj_sub_irreps[0],
                    conj_sub_irreps[1],
                    atol=atol,
                    max_num_random_generations=max_num_random_generations,
                )
                scale = intertwiner.copy()
                for _ in range(p - 1):
                    scale = np.dot(intertwiner, scale)
                intertwiner /= scale[0, 0] ** (1 / p)

                omega = 1 / nroot(np.prod([factor_system[r, rm[m]] for m in range(1, p)]), p)
                for q in range(p):
                    omegaq = omega * np.exp(2j * np.pi * q / p)
                    delta_r = intertwiner / omegaq  # Rep. matrix for r
                    delta_rm = [
                        np.eye(intertwiner.shape[0], dtype=np.complex128)
                    ]  # delta_rm[m] is rep. matrix for r^m
                    for m in range(1, p):
                        # D(r^m) = D(r) @ D(r^{m-1}) / mu(r, r^{m-1})
                        delta_rm.append(delta_r @ delta_rm[m - 1] / factor_system[r, rm[m - 1]])

                    next_irrep = np.zeros((len(group), dim, dim), dtype=np.complex128)
                    for m in range(p):
                        for s in subgroup:
                            idx = table[rm[m], s]
                            next_irrep[group_remapping[idx]] = (
                                delta_rm[m]
                                @ sub_irrep[subgroup_remapping[s]]
                                / factor_system[rm[m], s]
                            )
                    next_sub_irreps.append(next_irrep)
            else:
                # Mutually inequivalent
                next_irrep = np.zeros((len(group), dim * p, dim * p), dtype=np.complex128)
                for m in range(p):
                    for s in subgroup:
                        idx = table[rm[m], s]
                        for j in range(p):
                            i = (j + m) % p
                            sj = table[rinvm[j], table[s, rm[j]]]
                            next_irrep[
                                group_remapping[idx],
                                i * dim : (i + 1) * dim,
                                j * dim : (j + 1) * dim,
                            ] = (
                                factor_system[idx, rm[j]]
                                / factor_system[rm[i], sj]
                                * sub_irrep[subgroup_remapping[sj]]
                            )
                next_sub_irreps.append(next_irrep)

        # Unique irreps so far
        irreps.clear()
        sub_characters = []  # type: ignore
        for sub_irrep in next_sub_irreps:
            # Skip duplicated irrep
            character = get_character(sub_irrep)
            if any([is_equivalent_irrep(character, c) for c in sub_characters]):
                continue

            irreps.append(sub_irrep)
            sub_characters.append(character)

    if group != list(range(table.shape[0])):
        warn("Generators are not sufficient to traverse group.")
        return []

    return irreps


def purify_irrep_value(irrep: NDArrayComplex, atol: float = ATOL) -> NDArrayComplex:
    """Purify values of irreps."""
    # Each value should be 0 or exp(2 pi q / p) (p=1,2,3,4,6, q = 0,...,p-1)
    possible_values = [
        0,
        1,  # 0/1
        np.exp(1j * np.pi / 3),  # 1/3
        1j,  # 1/4
        np.exp(1j * np.pi * 2 / 3),  # 2/3
        -1,  # 1/2
        np.exp(1j * np.pi * 4 / 3),  # 4/3
        -1j,  # 3/4
        np.exp(1j * np.pi * 5 / 3),  # 5/3
    ]
    for v in possible_values:
        irrep[np.abs(irrep - v) < atol] = v
    return irrep
