"""Shared request helpers and auto-pagination for the Gildea SDK."""

from __future__ import annotations

from urllib.parse import quote

from .exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    RateLimitError,
)

__all__ = ["_request", "_paginate", "_clean", "_quote"]


def _clean(params: dict) -> dict:
    """Remove None values from a dict of query parameters."""
    return {k: v for k, v in params.items() if v is not None}


def _quote(segment: str) -> str:
    """URL-encode a path segment."""
    return quote(segment, safe="")


def _request(client, method: str, path: str, *, params: dict | None = None):
    """Send a request and return parsed JSON, raising typed errors on failure."""
    resp = client.request(method, path, params=params)

    if resp.status_code == 204:
        return None

    try:
        body = resp.json()
    except Exception:
        if resp.is_success:
            raise APIError(
                f"Invalid JSON in response: {resp.text[:200]}",
                code="invalid_response",
                status=resp.status_code,
            )
        raise APIError(resp.text[:200] or "Unknown error", code="server_error", status=resp.status_code)

    if resp.is_success:
        return body

    error = body.get("error", {})
    msg = error.get("message", resp.text)
    code = error.get("code")
    status = resp.status_code

    if status in (401, 403):
        raise AuthenticationError(msg, code=code, status=status)
    if status == 404:
        raise NotFoundError(msg, code=code, status=status)
    if status == 429:
        retry_after = resp.headers.get("Retry-After")
        if retry_after is not None:
            retry_after = int(retry_after)
        raise RateLimitError(msg, code=code, status=status, retry_after=retry_after)
    if status == 400:
        raise BadRequestError(msg, code=code, status=status)

    raise APIError(msg, code=code, status=status)


def _paginate(client, path: str, params: dict):
    """Auto-paginating generator that yields items from paginated list endpoints."""
    params = dict(params)  # copy so we can mutate
    while True:
        resp = _request(client, "GET", path, params=_clean(params))
        yield from resp["data"]
        if not resp.get("has_more"):
            break
        params["cursor"] = resp["cursor"]
