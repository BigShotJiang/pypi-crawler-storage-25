"""
Per-stream HTTP request forwarding.

Each yamux stream carries one HTTP/1.1 request from the public internet
(already read and parsed by the Go server's proxy.go). This module reads
the request from the stream, forwards it to the local service, and writes
the HTTP/1.1 response back into the stream.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from .yamux import YamuxStream

logger = logging.getLogger(__name__)

# Headers that must not be forwarded to the local service (hop-by-hop).
_HOP_BY_HOP = frozenset(
    {
        "connection",
        "keep-alive",
        "proxy-authenticate",
        "proxy-authorization",
        "proxy-connection",
        "te",
        "trailers",
        "transfer-encoding",
        "upgrade",
    }
)


async def handle_stream(stream: "YamuxStream", local_addr: str) -> None:
    """
    Read one HTTP request from *stream*, forward it to *local_addr*, and write
    the HTTP/1.1 response back. Always closes the stream when finished.

    Args:
        stream:     An open YamuxStream received from YamuxSession.accept().
        local_addr: Host:port of the local service (e.g. "localhost:8000").
    """
    try:
        method, path, req_headers, body = await _read_http_request(stream)

        fwd_headers = {
            k: v
            for k, v in req_headers.items()
            if k.lower() not in _HOP_BY_HOP
        }

        async with httpx.AsyncClient() as http:
            resp = await http.request(
                method,
                f"http://{local_addr}{path}",
                headers=fwd_headers,
                content=body,
                follow_redirects=False,
            )

        await _write_http_response(stream, resp)
        logger.debug(
            "forward: %s %s → %d (%d bytes)",
            method,
            path,
            resp.status_code,
            len(resp.content),
        )

    except (httpx.ConnectError, httpx.TimeoutException, OSError) as exc:
        logger.warning("forward: local service unreachable at %s: %r", local_addr, exc)
        await _write_error(stream, 502, "local service unreachable")

    except EOFError as exc:
        logger.debug("forward: stream closed before request complete: %r", exc)

    except Exception as exc:
        logger.debug("forward: unexpected error: %r", exc)

    finally:
        await stream.close()


async def _read_http_request(
    stream: "YamuxStream",
) -> tuple[str, str, dict[str, str], bytes]:
    """
    Read a full HTTP/1.1 request from *stream*.

    Returns (method, path, headers_dict, body_bytes).
    Raises EOFError if the stream closes before the request is complete.
    """
    # Read headers section (up to and including the blank line).
    buf = bytearray()
    while True:
        chunk = await stream.read(4096)
        if not chunk:
            raise EOFError("stream closed before HTTP headers complete")
        buf.extend(chunk)
        if b"\r\n\r\n" in buf:
            break

    split_pos = buf.index(b"\r\n\r\n")
    header_bytes = bytes(buf[:split_pos])
    leftover = bytes(buf[split_pos + 4 :])

    # Parse request line and headers.
    lines = header_bytes.split(b"\r\n")
    if not lines:
        raise ValueError("empty HTTP request")

    request_line = lines[0].decode("latin-1")
    parts = request_line.split(" ", 2)
    if len(parts) < 2:
        raise ValueError(f"malformed request line: {request_line!r}")
    method = parts[0]
    path = parts[1]

    headers: dict[str, str] = {}
    for line in lines[1:]:
        if b":" in line:
            name, _, value = line.partition(b":")
            headers[name.decode("latin-1").strip()] = value.decode("latin-1").strip()

    # Read body.
    content_length = int(
        headers.get("Content-Length", headers.get("content-length", "0"))
    )
    body = bytearray(leftover[:content_length])

    while len(body) < content_length:
        remaining = content_length - len(body)
        chunk = await stream.read(min(remaining, 65536))
        if not chunk:
            break
        body.extend(chunk)

    return method, path, headers, bytes(body)


async def _write_http_response(
    stream: "YamuxStream", resp: httpx.Response
) -> None:
    """Serialise *resp* as HTTP/1.1 and write it into *stream*."""
    reason = resp.reason_phrase or ""
    lines = [f"HTTP/1.1 {resp.status_code} {reason}"]

    response_headers: dict[str, str] = {}
    for k, v in resp.headers.items():
        if k.lower() not in _HOP_BY_HOP:
            response_headers[k.lower()] = v

    # Always set Content-Length from the actual body we received.
    response_headers["content-length"] = str(len(resp.content))
    response_headers["connection"] = "close"

    for k, v in response_headers.items():
        lines.append(f"{k}: {v}")

    header_section = "\r\n".join(lines) + "\r\n\r\n"
    await stream.write(header_section.encode("latin-1") + resp.content)


async def _write_error(stream: "YamuxStream", code: int, message: str) -> None:
    """Write a minimal HTTP error response into *stream*."""
    body = (message + "\n").encode()
    reasons = {502: "Bad Gateway", 503: "Service Unavailable"}
    reason = reasons.get(code, "Error")
    response = (
        f"HTTP/1.1 {code} {reason}\r\n"
        f"Content-Type: text/plain\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n"
        f"\r\n"
    ).encode() + body
    try:
        await stream.write(response)
    except Exception:
        pass
