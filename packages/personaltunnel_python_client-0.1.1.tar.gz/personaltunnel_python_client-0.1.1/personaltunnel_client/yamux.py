"""
Minimal asyncio implementation of the hashicorp/yamux client protocol.

The Python library always plays the yamux *Client* role (even stream IDs).
The Go personaltunnel server plays the yamux *Server* role and opens streams
(odd stream IDs) — one per incoming public HTTP request.

Frame header (12 bytes, big-endian):
    version   (1 byte):  always 0
    type      (1 byte):  0=Data, 1=WindowUpdate, 2=Ping, 3=GoAway
    flags     (2 bytes): SYN=0x0001, ACK=0x0002, FIN=0x0004, RST=0x0008
    stream_id (4 bytes)
    length    (4 bytes): payload bytes (Data) or window delta (WindowUpdate)
"""

from __future__ import annotations

import asyncio
import logging
import struct
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .crypto import EncConn

logger = logging.getLogger(__name__)

# Frame types
_TYPE_DATA = 0
_TYPE_WINDOW_UPDATE = 1
_TYPE_PING = 2
_TYPE_GO_AWAY = 3

# Frame flags
_FLAG_SYN = 0x0001
_FLAG_ACK = 0x0002
_FLAG_FIN = 0x0004
_FLAG_RST = 0x0008

# hashicorp/yamux default initial receive window
_INITIAL_WINDOW = 256 * 1024  # 262144 bytes

_HEADER_FMT = ">BBHII"  # version, type, flags, stream_id, length
_HEADER_SIZE = 12


def _pack_header(type_: int, flags: int, stream_id: int, length: int) -> bytes:
    return struct.pack(_HEADER_FMT, 0, type_, flags, stream_id, length)


class YamuxStream:
    """
    A single bidirectional yamux stream.

    Callers use read() / write() / close() as with any async byte stream.
    Created internally by YamuxSession when the server opens a new stream.
    """

    def __init__(self, stream_id: int, session: "YamuxSession") -> None:
        self._stream_id = stream_id
        self._session = session

        self._recv_buf = bytearray()
        self._data_event = asyncio.Event()

        # Flow control: how much data the server is allowed to send us.
        # The reader sends WindowUpdate frames to restore the server's quota.
        self._send_window: int = _INITIAL_WINDOW
        self._window_event = asyncio.Event()

        self._eof = False       # server sent FIN
        self._rst = False       # stream was reset
        self._write_closed = False  # we sent FIN

    # ── Internal helpers called by YamuxSession._read_loop ──────────────────

    def _feed(self, data: bytes, fin: bool) -> None:
        """Append incoming data and/or mark EOF."""
        if data:
            self._recv_buf.extend(data)
        if fin:
            self._eof = True
        self._data_event.set()

    def _reset(self) -> None:
        """Mark the stream as reset by the remote peer."""
        self._rst = True
        self._eof = True
        self._data_event.set()
        self._window_event.set()

    def _add_send_window(self, delta: int) -> None:
        """Increase the send window and unblock any waiting write()."""
        self._send_window += delta
        if self._send_window > 0:
            self._window_event.set()

    # ── Public async API ────────────────────────────────────────────────────

    async def read(self, n: int) -> bytes:
        """
        Read up to n bytes from the stream.
        Blocks until data is available or the stream is closed (returns b'').
        """
        while not self._recv_buf and not self._eof and not self._rst:
            self._data_event.clear()
            # Re-check after clearing to avoid a TOCTOU gap.
            if self._recv_buf or self._eof or self._rst:
                break
            await self._data_event.wait()

        if self._rst and not self._recv_buf:
            raise ConnectionResetError("yamux stream was reset")

        if not self._recv_buf:
            return b""  # EOF

        data = bytes(self._recv_buf[:n])
        consumed = len(data)
        del self._recv_buf[:consumed]

        # Restore the server's send quota so it can keep sending.
        if consumed > 0:
            await self._session._send_frame(
                _TYPE_WINDOW_UPDATE, 0, self._stream_id, consumed
            )

        return data

    async def write(self, data: bytes) -> None:
        """
        Write data to the stream.
        Blocks when the remote receive window is exhausted (flow control).
        """
        if self._write_closed:
            raise ConnectionError("write on closed yamux stream")

        offset = 0
        while offset < len(data):
            # Wait for window space.
            while self._send_window <= 0 and not self._rst:
                self._window_event.clear()
                if self._send_window > 0 or self._rst:
                    break
                await self._window_event.wait()

            if self._rst:
                raise ConnectionResetError("yamux stream was reset")

            chunk_size = min(len(data) - offset, self._send_window)
            chunk = data[offset : offset + chunk_size]
            self._send_window -= chunk_size

            await self._session._send_frame(
                _TYPE_DATA, 0, self._stream_id, len(chunk), chunk
            )
            offset += chunk_size

    async def close(self) -> None:
        """Send FIN to signal end-of-write; does not prevent further reads."""
        if not self._write_closed and not self._rst:
            self._write_closed = True
            await self._session._send_frame(
                _TYPE_DATA, _FLAG_FIN, self._stream_id, 0
            )
        self._session._remove_stream(self._stream_id)


class YamuxSession:
    """
    Async yamux client session.

    After calling start(), the session accepts streams opened by the remote
    yamux server (the Go personaltunnel server). Each accepted YamuxStream
    carries exactly one HTTP request/response pair.

    Usage::

        session = YamuxSession(enc_conn)
        await session.start()

        while not session.closed:
            stream = await session.accept()
            if stream is None:
                break
            asyncio.create_task(handle_stream(stream))
    """

    def __init__(self, enc_conn: "EncConn") -> None:
        self._enc_conn = enc_conn
        self._streams: dict[int, YamuxStream] = {}
        self._accept_queue: asyncio.Queue[YamuxStream | None] = asyncio.Queue()
        self._send_lock = asyncio.Lock()
        self._reader_task: asyncio.Task | None = None
        self._closed = False

    async def start(self) -> None:
        """Launch the background frame-reader task."""
        self._reader_task = asyncio.create_task(
            self._read_loop(), name="yamux-reader"
        )

    async def accept(self) -> YamuxStream | None:
        """
        Wait for the server to open a new stream.
        Returns None when the session has been closed.
        """
        return await self._accept_queue.get()

    async def close(self) -> None:
        """Close the session and its underlying connection."""
        if not self._closed:
            self._closed = True
            if self._reader_task:
                self._reader_task.cancel()
            self._enc_conn.close()
            await self._accept_queue.put(None)

    @property
    def closed(self) -> bool:
        return self._closed

    # ── Internal ──────────────────────────────────────────────────────────

    async def _send_frame(
        self,
        type_: int,
        flags: int,
        stream_id: int,
        length: int,
        data: bytes = b"",
    ) -> None:
        """Serialise and send a yamux frame atomically."""
        async with self._send_lock:
            header = _pack_header(type_, flags, stream_id, length)
            await self._enc_conn.write(header + data)

    def _remove_stream(self, stream_id: int) -> None:
        self._streams.pop(stream_id, None)

    async def _read_loop(self) -> None:
        """Background task: read yamux frames and dispatch to streams."""
        try:
            while not self._closed:
                header = await self._enc_conn.read(_HEADER_SIZE)
                _version, type_, flags, stream_id, length = struct.unpack(
                    _HEADER_FMT, header
                )

                if type_ == _TYPE_DATA:
                    await self._handle_data(stream_id, flags, length)
                elif type_ == _TYPE_WINDOW_UPDATE:
                    self._handle_window_update(stream_id, flags, length)
                elif type_ == _TYPE_PING:
                    await self._handle_ping(flags, length)
                elif type_ == _TYPE_GO_AWAY:
                    logger.info("yamux: received GoAway (code=%d)", length)
                    break
                else:
                    logger.warning("yamux: unknown frame type %d, ignoring", type_)

        except asyncio.CancelledError:
            pass
        except Exception as exc:
            if not self._closed:
                logger.debug("yamux: reader error: %r", exc)
        finally:
            self._closed = True
            for stream in list(self._streams.values()):
                stream._reset()
            self._streams.clear()
            await self._accept_queue.put(None)

    async def _handle_data(self, stream_id: int, flags: int, length: int) -> None:
        body = b""
        if length > 0:
            body = await self._enc_conn.read(length)

        syn = bool(flags & _FLAG_SYN)
        fin = bool(flags & _FLAG_FIN)
        rst = bool(flags & _FLAG_RST)

        if rst:
            stream = self._streams.pop(stream_id, None)
            if stream:
                stream._reset()
            return

        if syn:
            # Server is opening a new stream.
            stream = YamuxStream(stream_id, self)
            self._streams[stream_id] = stream
            # Acknowledge with WindowUpdate + ACK and grant our receive window.
            await self._send_frame(
                _TYPE_WINDOW_UPDATE, _FLAG_ACK, stream_id, _INITIAL_WINDOW
            )
            if body or fin:
                stream._feed(body, fin)
            await self._accept_queue.put(stream)
            return

        stream = self._streams.get(stream_id)
        if stream is None:
            logger.debug(
                "yamux: data for unknown stream %d (len=%d)", stream_id, length
            )
            return

        stream._feed(body, fin)

    def _handle_window_update(self, stream_id: int, flags: int, delta: int) -> None:
        syn = bool(flags & _FLAG_SYN)
        rst = bool(flags & _FLAG_RST)

        if rst:
            stream = self._streams.pop(stream_id, None)
            if stream:
                stream._reset()
            return

        if syn:
            # Server is opening a new stream via WindowUpdate+SYN.
            stream = YamuxStream(stream_id, self)
            self._streams[stream_id] = stream
            await self._send_frame(
                _TYPE_WINDOW_UPDATE, _FLAG_ACK, stream_id, _INITIAL_WINDOW
            )
            if delta > 0:
                stream._add_send_window(delta)
            await self._accept_queue.put(stream)
            return

        stream = self._streams.get(stream_id)
        if stream is None:
            return
        stream._add_send_window(delta)


    async def _handle_ping(self, flags: int, value: int) -> None:
        if flags & _FLAG_SYN:
            await self._send_frame(_TYPE_PING, _FLAG_ACK, 0, value)
