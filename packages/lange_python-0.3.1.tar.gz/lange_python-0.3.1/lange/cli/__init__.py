"""CLI commands for the ``lange`` Python package."""

from __future__ import annotations
from .code import code_group
from .build import build_command

import click



@click.group()
@click.version_option(package_name="lange-python", message="%(version)s")
def cli() -> None:
    """
    Lange CLI entrypoint.

    :returns: ``None``.
    """

cli.add_command(code_group, "code")
cli.add_command(build_command, "build")
