from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Any

import httpx

from ._util import detect_distribution_os, parse_distribution_os, _compare_versions
from .._util import BaseLangeLabsClient


class DistributionClient(BaseLangeLabsClient):
    """
    Client for querying public distribution metadata and update availability.

    :param host: Base app-service URL, e.g. ``https://lange-labs.com``.
    :param api_key: Optional API key supplied directly or resolved from the environment.
    :param timeout: HTTP timeout in seconds for metadata requests.
    :raises ValueError: If ``api_key`` is unavailable or empty.
    """

    def __init__(self,
                 distribution_name: str,
                 host: str = "https://lange-labs.com",
                 api_key: str | None = None,
                 timeout: float = 10.0) -> None:
        """
        Initialize a distribution metadata client for the Lange app service.

        :param host: Base app-service URL, e.g. ``https://lange-labs.com``.
        :param api_key: Optional API key supplied directly or resolved from the environment.
        :param timeout: HTTP timeout in seconds for metadata requests.
        :param distribution_name: Distribution name as stored by the app service.
        :raises ValueError: If ``api_key`` is unavailable or empty.
        """
        super().__init__(api_key, host=host)
        self.timeout = timeout
        normalized_distribution_name = distribution_name.strip()

        if not normalized_distribution_name:
            raise ValueError("distribution_name is required.")

        if " " in normalized_distribution_name:
            raise ValueError("check your distribution name again. spaces are not allowed by design")

        self.distribution_name = normalized_distribution_name

    def search_for_update(self, current_version: str) -> str | None:
        """
        Resolve the newest available version for the current OS when it is newer.

        :param distribution_name: Distribution name as stored by the app service.
        :param current_version: Current installed version string.
        :returns: Newer version string when available, otherwise ``None``.
        :raises ValueError: If required inputs are missing.
        :raises httpx.HTTPError: If the metadata request fails.
        """
        normalized_current_version = current_version.strip()

        if not normalized_current_version:
            raise ValueError("current_version is required.")

        current_os = detect_distribution_os()
        payload = self._get_distribution_payload()
        versions = payload.get("distribution", {}).get("versions", [])

        newest_version: str | None = None

        for version_entry in versions:
            if not isinstance(version_entry, dict):
                continue

            version = str(version_entry.get("version", "")).strip()
            artifacts = version_entry.get("artifacts", {})
            artifact = artifacts.get(current_os) if isinstance(artifacts, dict) else None

            if not version or artifact is None:
                continue

            if _compare_versions(version, normalized_current_version) <= 0:
                continue

            if newest_version is None or _compare_versions(version, newest_version) > 0:
                newest_version = version

        return newest_version

    def _build_distribution_url(self) -> str:
        """
        Build the public metadata endpoint URL for one distribution.

        :param distribution_name: Distribution name to request.
        :returns: Fully qualified public metadata URL.
        """
        return f"{self.host}/api/public/distributions/{self.distribution_name}"

    def _build_artifact_download_url(self, version: str, os_name: str) -> str:
        """
        Build the public artifact download endpoint URL for one version and OS.

        :param version: Distribution version to download.
        :param os_name: Operating-system label accepted by the app service.
        :returns: Fully qualified public artifact download URL.
        """
        return (
            f"{self.host}/api/public/distributions/{self.distribution_name}"
            f"/versions/{version}/artifacts/{os_name}/download"
        )

    def _build_versions_url(self) -> str:
        """
        Build the authenticated distribution versions endpoint URL.

        :returns: Fully qualified versions collection URL.
        """
        return f"{self.host}/api/distributions/{self.distribution_name}/versions"

    def _get_newest_version_artifact(self, os_name: str) -> tuple[str, dict[str, Any]] | None:
        """
        Resolve the newest downloadable artifact for one operating system.

        :param os_name: Operating-system label accepted by the app service.
        :returns: Tuple of version string and artifact payload, otherwise ``None``.
        :raises httpx.HTTPError: If the metadata request fails.
        """
        payload = self._get_distribution_payload()
        versions = payload.get("distribution", {}).get("versions", [])
        newest_match: tuple[str, dict[str, Any]] | None = None

        for version_entry in versions:
            if not isinstance(version_entry, dict):
                continue

            version = str(version_entry.get("version", "")).strip()
            artifacts = version_entry.get("artifacts", {})
            artifact = artifacts.get(os_name) if isinstance(artifacts, dict) else None

            if not version or not isinstance(artifact, dict):
                continue

            if newest_match is None or _compare_versions(version, newest_match[0]) > 0:
                newest_match = (version, artifact)

        return newest_match

    def download_to_temp(self) -> Path:
        """
        Download the newest version artifact for the current OS into ``/tmp``.

        :returns: Absolute path to the downloaded artifact.
        :raises ValueError: If no downloadable artifact exists for the current OS.
        :raises httpx.HTTPError: If the metadata or artifact download fails.
        """
        current_os = detect_distribution_os()
        newest_match = self._get_newest_version_artifact(current_os)

        if newest_match is None:
            raise ValueError(f"No downloadable versions available for operating system: {current_os}.")

        version, artifact = newest_match
        filename = str(artifact.get("filename", "")).strip()

        if not filename:
            raise ValueError("Artifact filename is required.")

        destination_dir = Path("/tmp") / self.distribution_name / "versions" / version
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination_path = destination_dir / filename

        client = httpx.Client(timeout=self.timeout)

        try:
            response = client.get(
                self._build_artifact_download_url(version, current_os),
                headers=self._build_connection_headers(),
            )
            response.raise_for_status()
            destination_path.write_bytes(response.content)
        finally:
            client.close()

        return destination_path

    def upload(self, path: str | Path, version_name: str, os_name: str) -> dict[str, Any]:
        """
        Upload one OS-specific distribution artifact for a version.

        :param path: Artifact file path to upload.
        :param version_name: Version string to associate with the artifact.
        :param os_name: Operating-system label for the artifact.
        :returns: Decoded JSON response payload.
        :raises ValueError: If any input is missing, invalid, or the file does not exist.
        :raises httpx.HTTPError: If the upload request fails.
        """
        artifact_path = Path(path)
        normalized_version_name = version_name.strip()
        normalized_os_name = parse_distribution_os(os_name)

        if not normalized_version_name:
            raise ValueError("version_name is required.")

        if not artifact_path.exists():
            raise ValueError("Artifact file does not exist.")

        if not artifact_path.is_file():
            raise ValueError("Artifact path must point to a file.")

        content_type = mimetypes.guess_type(artifact_path.name)[0] or "application/octet-stream"
        file_field_name = f"{normalized_os_name}File"

        client = httpx.Client(timeout=self.timeout)

        try:
            with artifact_path.open("rb") as artifact_file:
                response = client.post(
                    self._build_versions_url(),
                    headers=self._build_connection_headers(),
                    data={"version": normalized_version_name},
                    files={
                        file_field_name: (
                            artifact_path.name,
                            artifact_file,
                            content_type,
                        )
                    },
                )
            response.raise_for_status()
            return response.json()
        finally:
            client.close()

    def _get_distribution_payload(self) -> dict[str, Any]:
        """
        Fetch the public distribution metadata payload from the app service.

        :param distribution_name: Distribution name to fetch.
        :returns: Decoded JSON payload.
        :raises httpx.HTTPError: If the request fails or returns invalid JSON.
        """
        client = httpx.Client(timeout=self.timeout)

        try:
            response = client.get(
                self._build_distribution_url(),
                headers=self._build_connection_headers(),
            )
            response.raise_for_status()
            return response.json()
        finally:
            client.close()
