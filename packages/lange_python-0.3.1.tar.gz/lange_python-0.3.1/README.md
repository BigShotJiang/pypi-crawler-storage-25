# lange-python

Python helpers and clients for Lange services.

## Tunnel worker

```python
from lange.tunnel import Tunnel

tunnel = Tunnel(
    host="wss://tunnel.lange-labs.com",
    secret_key="your-bearer-token",
    tunnel_name="dev-edge",  # Optional but recommended when one key is linked to multiple tunnels.
    target="http://localhost:3000",
)

tunnel.start()
# ...
tunnel.stop()
```
