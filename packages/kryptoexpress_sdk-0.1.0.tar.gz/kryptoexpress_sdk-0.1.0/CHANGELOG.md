# Changelog

## 0.1.0

- Initial SDK scaffolding.
- Added sync and async clients.
- Added payments, wallet, currencies, and fiat resources.
- Added typed request and response models with pydantic v2.
- Added typed exceptions and HTTP error mapping.
- Added domain validation for payment type semantics, stablecoin restrictions, and minimum amount rules.
- Added centralized `MinimumAmountPolicy` and fiat conversion abstraction.
- Added callback signature verification helper.
- Added typed withdrawal request variants and explicit dry-run helper.
- Added pytest test suite skeleton and GitHub Actions workflows.
