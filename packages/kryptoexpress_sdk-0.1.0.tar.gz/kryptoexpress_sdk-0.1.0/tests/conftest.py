from __future__ import annotations

import httpx
import pytest

from kryptoexpress.client import AsyncKryptoExpressClient, KryptoExpressClient
from kryptoexpress.policies import MinimumAmountPolicy


def make_sync_client(handler: httpx.MockTransport) -> KryptoExpressClient:
    http_client = httpx.Client(
        transport=handler,
        base_url="https://kryptoexpress.pro/api",
        headers={"X-Api-Key": "test-key"},
    )
    return KryptoExpressClient(api_key="test-key", http_client=http_client)


def make_sync_client_with_policy(
    handler: httpx.MockTransport,
    *,
    minimum_amount_policy: MinimumAmountPolicy,
) -> KryptoExpressClient:
    http_client = httpx.Client(
        transport=handler,
        base_url="https://kryptoexpress.pro/api",
        headers={"X-Api-Key": "test-key"},
    )
    return KryptoExpressClient(
        api_key="test-key",
        http_client=http_client,
        minimum_amount_policy=minimum_amount_policy,
    )


def make_async_client(handler: httpx.MockTransport) -> AsyncKryptoExpressClient:
    http_client = httpx.AsyncClient(
        transport=handler,
        base_url="https://kryptoexpress.pro/api",
        headers={"X-Api-Key": "test-key"},
    )
    return AsyncKryptoExpressClient(api_key="test-key", http_client=http_client)


@pytest.fixture
def payment_payload() -> dict[str, object]:
    return {
        "id": 1,
        "paymentType": "PAYMENT",
        "fiatCurrency": "USD",
        "fiatAmount": 12.34,
        "cryptoAmount": 0.0002,
        "cryptoCurrency": "BTC",
        "expireDatetime": 1710000000,
        "createDatetime": 1709990000,
        "paidAt": None,
        "address": "bc1abc",
        "isPaid": False,
        "isWithdrawn": False,
        "hash": "abc123",
        "callbackUrl": "https://example.com/callback",
    }
