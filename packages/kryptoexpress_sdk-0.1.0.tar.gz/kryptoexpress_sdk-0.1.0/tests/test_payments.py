from __future__ import annotations

import json

import httpx
import pytest

from kryptoexpress.errors import (
    CurrencyConversionError,
    MinimumAmountError,
    UnsupportedPaymentModeError,
)
from kryptoexpress.models.common import (
    CryptoCurrency,
    FiatCurrency,
    PaymentBehavior,
    PaymentType,
)
from kryptoexpress.models.payments import PaymentCreateRequest
from kryptoexpress.policies import MinimumAmountPolicy
from tests.conftest import make_async_client, make_sync_client, make_sync_client_with_policy


def test_create_payment_serializes_request(payment_payload: dict[str, object]) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.headers["content-type"] == "application/json"
        assert json.loads(request.read()) == {
            "paymentType": "PAYMENT",
            "cryptoCurrency": "BTC",
            "fiatCurrency": "USD",
            "fiatAmount": 12.34,
            "callbackUrl": "https://example.com/callback",
            "callbackSecret": "secret",
        }
        return httpx.Response(200, json=payment_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.create(
        PaymentCreateRequest(
            payment_type=PaymentType.PAYMENT,
            crypto_currency=CryptoCurrency.BTC,
            fiat_currency=FiatCurrency.USD,
            fiat_amount=12.34,
            callback_url="https://example.com/callback",
            callback_secret="secret",
        )
    )

    assert payment.hash == "abc123"
    assert payment.crypto_currency is CryptoCurrency.BTC
    client.close()


def test_get_by_hash_deserializes_response(payment_payload: dict[str, object]) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params["hash"] == "abc123"
        return httpx.Response(200, json=payment_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.get_by_hash("abc123")

    assert payment.id == 1
    assert payment.payment_type is PaymentType.PAYMENT
    client.close()


@pytest.mark.asyncio
async def test_async_payment_get_by_hash(payment_payload: dict[str, object]) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.params["hash"] == "abc123"
        return httpx.Response(200, json=payment_payload)

    client = make_async_client(httpx.MockTransport(handler))
    payment = await client.payments.get_by_hash("abc123")

    assert payment.hash == "abc123"
    await client.aclose()


def test_stablecoin_deposit_is_rejected_before_http_call() -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={})

    client = make_sync_client(httpx.MockTransport(handler))
    request = PaymentCreateRequest.for_deposit(
        crypto_currency=CryptoCurrency.USDT_ERC20,
        fiat_currency=FiatCurrency.USD,
        callback_url="https://example.com/callback",
    )

    with pytest.raises(UnsupportedPaymentModeError):
        client.payments.create(request)

    assert calls["count"] == 0
    client.close()


def test_stablecoin_non_exact_behavior_is_rejected_before_http_call() -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={})

    client = make_sync_client(httpx.MockTransport(handler))
    request = PaymentCreateRequest.for_payment(
        crypto_currency=CryptoCurrency.USDT_ERC20,
        fiat_currency=FiatCurrency.USD,
        fiat_amount=10.0,
        callback_url="https://example.com/callback",
        payment_behavior=PaymentBehavior.SPLIT,
    )

    with pytest.raises(UnsupportedPaymentModeError):
        client.payments.create(request)

    assert calls["count"] == 0
    client.close()


def test_non_stable_payment_allows_split_behavior(payment_payload: dict[str, object]) -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json=payment_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.create(
        PaymentCreateRequest.for_payment(
            crypto_currency=CryptoCurrency.BTC,
            fiat_currency=FiatCurrency.USD,
            fiat_amount=10.0,
            callback_url="https://example.com/callback",
            payment_behavior=PaymentBehavior.SPLIT,
        )
    )

    assert calls["count"] == 1
    assert payment.payment_type is PaymentType.PAYMENT
    client.close()


def test_create_payment_shortcut(payment_payload: dict[str, object]) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.read())
        assert body["paymentType"] == "PAYMENT"
        return httpx.Response(200, json=payment_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.create_payment(
        crypto_currency=CryptoCurrency.BTC,
        fiat_currency=FiatCurrency.USD,
        fiat_amount=10.0,
        callback_url="https://example.com/callback",
    )

    assert payment.id == 1
    client.close()


def test_create_deposit_shortcut(payment_payload: dict[str, object]) -> None:
    deposit_payload = dict(payment_payload)
    deposit_payload["paymentType"] = "DEPOSIT"
    deposit_payload["fiatAmount"] = None
    deposit_payload["cryptoAmount"] = None

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.read())
        assert body["paymentType"] == "DEPOSIT"
        assert "fiatAmount" not in body
        return httpx.Response(200, json=deposit_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.create_deposit(
        crypto_currency=CryptoCurrency.BTC,
        fiat_currency=FiatCurrency.USD,
        callback_url="https://example.com/callback",
    )

    assert payment.payment_type is PaymentType.DEPOSIT
    client.close()


def test_deposit_does_not_require_fiat_amount(payment_payload: dict[str, object]) -> None:
    deposit_payload = dict(payment_payload)
    deposit_payload["paymentType"] = "DEPOSIT"
    deposit_payload["fiatAmount"] = None
    deposit_payload["cryptoAmount"] = None

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.read())
        assert "fiatAmount" not in body
        return httpx.Response(200, json=deposit_payload)

    client = make_sync_client(httpx.MockTransport(handler))
    payment = client.payments.create(
        PaymentCreateRequest.for_deposit(
            crypto_currency=CryptoCurrency.BTC,
            fiat_currency=FiatCurrency.USD,
            callback_url="https://example.com/callback",
        )
    )

    assert payment.payment_type is PaymentType.DEPOSIT
    assert payment.fiat_amount is None
    assert payment.crypto_amount is None
    client.close()


def test_minimum_amount_validation_for_usd_happens_before_http_call() -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={})

    client = make_sync_client(httpx.MockTransport(handler))
    request = PaymentCreateRequest.for_payment(
        crypto_currency=CryptoCurrency.BTC,
        fiat_currency=FiatCurrency.USD,
        fiat_amount=0.99,
        callback_url="https://example.com/callback",
    )

    with pytest.raises(MinimumAmountError):
        client.payments.create(request)

    assert calls["count"] == 0
    client.close()


def test_minimum_amount_validation_for_non_usd_uses_converter(
    payment_payload: dict[str, object],
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json=payment_payload)

    def converter(amount: float, from_currency: FiatCurrency, to_currency: FiatCurrency) -> float:
        assert amount == 1.0
        assert from_currency is FiatCurrency.USD
        assert to_currency is FiatCurrency.EUR
        return 0.91

    policy = MinimumAmountPolicy(sync_converter=converter)
    client = make_sync_client_with_policy(
        httpx.MockTransport(handler),
        minimum_amount_policy=policy,
    )
    payment = client.payments.create(
        PaymentCreateRequest.for_payment(
            crypto_currency=CryptoCurrency.BTC,
            fiat_currency=FiatCurrency.EUR,
            fiat_amount=0.91,
            callback_url="https://example.com/callback",
        )
    )

    assert payment.id == 1
    client.close()


def test_non_usd_minimum_amount_requires_converter() -> None:
    calls = {"count": 0}

    def handler(request: httpx.Request) -> httpx.Response:
        calls["count"] += 1
        return httpx.Response(200, json={})

    client = make_sync_client(httpx.MockTransport(handler))
    request = PaymentCreateRequest.for_payment(
        crypto_currency=CryptoCurrency.BTC,
        fiat_currency=FiatCurrency.EUR,
        fiat_amount=2.0,
        callback_url="https://example.com/callback",
    )

    with pytest.raises(CurrencyConversionError):
        client.payments.create(request)

    assert calls["count"] == 0
    client.close()
