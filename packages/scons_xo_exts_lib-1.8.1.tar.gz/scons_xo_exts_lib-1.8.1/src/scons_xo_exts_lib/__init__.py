#!/usr/bin/env python

"""
Scons extensions library by XGQT.
"""

__version__ = "1.8.1"
__description__ = "Scons extensions library by XGQT"
