"""
Tests for filefy
"""

import pytest
import os
import tempfile
from pathlib import Path


class TestPackageImports:
    """Test that package imports work correctly"""

    def test_import_main_module(self):
        """Test importing the main module"""
        from filefy import __version__, app, create_app
        from filefy._version import __version__ as expected_version

        assert __version__ == expected_version
        assert app is not None
        assert callable(create_app)

    def test_import_server(self):
        """Test importing server module"""
        from filefy.server import app, run, create_app

        assert app is not None
        assert callable(run)
        assert callable(create_app)

    def test_import_cli(self):
        """Test importing CLI module"""
        from filefy.cli import main

        assert callable(main)


class TestFlaskApp:
    """Test Flask application"""

    def test_app_creation(self):
        """Test that app can be created"""
        from filefy import create_app

        app = create_app()
        assert app is not None
        assert app.config["MAX_CONTENT_LENGTH"] == 10 * 1024 * 1024 * 1024

    def test_app_with_custom_base_dir(self):
        """Test app creation with custom base directory"""
        from filefy import create_app

        with tempfile.TemporaryDirectory() as tmpdir:
            app = create_app(base_dir=tmpdir)
            assert app.config["BASE_DIR"] == tmpdir

    def test_app_routes_exist(self):
        """Test that main routes exist"""
        from filefy import app

        routes = [rule.rule for rule in app.url_map.iter_rules()]

        # Check main routes exist
        assert "/" in routes
        assert "/api/browse" in routes
        assert "/api/upload" in routes
        assert "/api/download/<path:file_path>" in routes
        assert "/api/remote-download" in routes
        assert "/api/quick-access" in routes


class TestAPIEndpoints:
    """Test API endpoints"""

    @pytest.fixture
    def client(self):
        """Create test client"""
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def test_index_page(self, client):
        """Test that index page loads"""
        response = client.get("/")
        assert response.status_code == 200

    def test_browse_home(self, client):
        """Test browsing home directory"""
        response = client.get("/api/browse?path=~")
        assert response.status_code == 200
        data = response.get_json()
        assert "current_path" in data
        assert "items" in data

    def test_browse_invalid_path(self, client):
        """Test browsing non-existent path"""
        response = client.get("/api/browse?path=/nonexistent/path/12345")
        assert response.status_code == 404

    def test_disk_usage(self, client):
        """Test disk usage endpoint"""
        response = client.get("/api/disk-usage")
        assert response.status_code == 200
        data = response.get_json()
        assert "total" in data
        assert "used" in data
        assert "free" in data

    def test_download_tasks(self, client):
        """Test download tasks endpoint"""
        response = client.get("/api/download-tasks")
        assert response.status_code == 200
        data = response.get_json()
        assert isinstance(data, list)


class TestFileOperations:
    """Test file operation endpoints"""

    @pytest.fixture
    def client(self):
        """Create test client"""
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for tests"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield tmpdir

    def test_create_folder(self, client, temp_dir):
        """Test creating a new folder"""
        response = client.post(
            "/api/create-folder", json={"path": temp_dir, "name": "test_folder"}
        )
        assert response.status_code == 200
        assert os.path.exists(os.path.join(temp_dir, "test_folder"))

    def test_create_folder_no_name(self, client, temp_dir):
        """Test creating folder without name"""
        response = client.post("/api/create-folder", json={"path": temp_dir})
        assert response.status_code == 400

    def test_file_info(self, client, temp_dir):
        """Test getting file info"""
        # Create a test file
        test_file = os.path.join(temp_dir, "test.txt")
        with open(test_file, "w") as f:
            f.write("Hello, World!")

        response = client.get(f"/api/file-info?path={test_file}")
        assert response.status_code == 200
        data = response.get_json()
        assert data["name"] == "test.txt"
        assert data["is_dir"] is False


class TestRemoteDownload:
    """Test remote download functionality"""

    @pytest.fixture
    def client(self):
        """Create test client"""
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def test_remote_download_no_url(self, client):
        """Test remote download without URL"""
        response = client.post("/api/remote-download", json={"destination": "/tmp"})
        assert response.status_code == 400
        data = response.get_json()
        assert "error" in data

    def test_remote_download_invalid_destination(self, client):
        """Test remote download with invalid destination"""
        response = client.post(
            "/api/remote-download",
            json={
                "url": "https://example.com/file.txt",
                "destination": "/nonexistent/path",
            },
        )
        assert response.status_code == 400

    def test_remote_download_rejects_invalid_scheme(self, client):
        """Test remote download only accepts HTTP(S) URLs"""
        response = client.post(
            "/api/remote-download",
            json={"url": "file:///etc/passwd", "destination": "/tmp"},
        )
        assert response.status_code == 400
        data = response.get_json()
        assert "invalid_urls" in data

    def test_remote_download_accepts_multiple_urls(self, client, monkeypatch):
        """Test starting multiple remote downloads in one request"""
        import filefy.server as server

        def skip_download(*args):
            return None

        with tempfile.TemporaryDirectory() as tmpdir:
            server.download_tasks.clear()
            monkeypatch.setattr(server, "remote_download_task", skip_download)

            response = client.post(
                "/api/remote-download",
                json={
                    "urls": [
                        "https://example.com/one.txt",
                        "https://example.com/two.txt",
                    ],
                    "destination": tmpdir,
                },
            )

            assert response.status_code == 200
            data = response.get_json()
            assert data["count"] == 2
            assert len(data["task_ids"]) == 2
            assert len(server.download_tasks) == 2
            server.download_tasks.clear()

    def test_remote_download_accepts_comma_separated_urls(self, client, monkeypatch):
        """Test comma-separated URLs match the client-side splitter behavior"""
        import filefy.server as server

        def skip_download(*args):
            return None

        with tempfile.TemporaryDirectory() as tmpdir:
            server.download_tasks.clear()
            monkeypatch.setattr(server, "remote_download_task", skip_download)

            response = client.post(
                "/api/remote-download",
                json={
                    "url": (
                        "https://example.com/one.txt," "https://example.com/two.txt"
                    ),
                    "destination": tmpdir,
                },
            )

            assert response.status_code == 200
            data = response.get_json()
            assert data["count"] == 2
            assert len(data["task_ids"]) == 2
            server.download_tasks.clear()

    def test_cancel_download_marks_active_task(self, client):
        """Test cancelling an active download marks it for cleanup"""
        import filefy.server as server

        task_id = "active-task"
        server.download_tasks[task_id] = {
            "id": task_id,
            "url": "https://example.com/file.txt",
            "destination": "/tmp",
            "status": "downloading",
            "progress": 10,
            "downloaded": 10,
            "total_size": 100,
            "speed": 1,
            "filename": "file.txt",
            "created_at": 1,
        }

        response = client.post(f"/api/cancel-download/{task_id}")
        assert response.status_code == 200
        assert server.download_tasks[task_id]["cancelled"] is True
        assert server.download_tasks[task_id]["status"] == "cancelling"
        server.download_tasks.clear()

    def test_cancel_download_removes_partial_files(self):
        """Test cancellation cleanup removes reserved and partial files"""
        import filefy.server as server

        task_id = "cleanup-task"
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "file.txt")
            partial_path = os.path.join(tmpdir, "file.txt.part")
            Path(file_path).touch()
            Path(partial_path).touch()
            server.download_tasks[task_id] = {
                "id": task_id,
                "status": "downloading",
                "speed": 1,
            }

            server.mark_download_cancelled(task_id, file_path, partial_path)

            assert not os.path.exists(file_path)
            assert not os.path.exists(partial_path)
            assert server.download_tasks[task_id]["status"] == "cancelled"
            server.download_tasks.clear()


class TestQuickAccess:
    """Test the dynamic Quick Access endpoint."""

    @pytest.fixture
    def client(self):
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def test_quick_access_endpoint(self, client):
        """The endpoint must report a home directory and a list of items."""
        response = client.get("/api/quick-access")
        assert response.status_code == 200
        data = response.get_json()
        assert "home" in data
        assert "items" in data
        assert isinstance(data["items"], list)
        # All returned shortcuts must point at directories that actually
        # exist on the host - never at hardcoded paths from the developer's
        # machine.
        for item in data["items"]:
            assert "label" in item
            assert "path" in item
            assert "icon" in item
            assert os.path.isdir(item["path"]), (
                f"Quick Access entry {item['label']!r} -> {item['path']!r} "
                "does not exist on this host"
            )

    def test_quick_access_includes_home(self, client):
        """The configured base/home directory must be among the shortcuts."""
        response = client.get("/api/quick-access")
        data = response.get_json()
        paths = {item["path"] for item in data["items"]}
        assert os.path.abspath(os.path.expanduser(data["home"])) in paths


class TestServerInfoAndTunnelParser:
    """Tests for the /api/server-info endpoint and the tunnel URL parser."""

    @pytest.fixture
    def client(self):
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def test_server_info_endpoint(self, client):
        response = client.get("/api/server-info")
        assert response.status_code == 200
        data = response.get_json()
        assert "version" in data
        assert "tunnel_status" in data
        assert "tunnel_url" in data
        assert "base_dir" in data

    def test_extract_tunnel_url_finds_quick_tunnel(self):
        from filefy.tunnel import extract_tunnel_url

        log = (
            "INF Your quick Tunnel has been created! Visit it at:\n"
            "INF https://random-words-1234.trycloudflare.com\n"
        )
        assert extract_tunnel_url(log) == (
            "https://random-words-1234.trycloudflare.com"
        )

    def test_extract_tunnel_url_returns_none_for_no_match(self):
        from filefy.tunnel import extract_tunnel_url

        assert extract_tunnel_url("nothing here") is None
        assert extract_tunnel_url("") is None
        assert extract_tunnel_url(None) is None


class TestCompressEndpoint:
    """Tests for /api/compress."""

    @pytest.fixture
    def client(self):
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def _make_tree(self, root):
        """Create a small directory tree under ``root`` and return a list
        of (file_path, content) tuples for assertions."""
        Path(root, "a.txt").write_text("hello A")
        Path(root, "b.txt").write_text("hello B")
        sub = Path(root, "sub")
        sub.mkdir()
        Path(sub, "c.txt").write_text("nested")

    def test_compress_zip_directory(self, client):
        import zipfile

        with tempfile.TemporaryDirectory() as tmp:
            self._make_tree(tmp)
            with tempfile.TemporaryDirectory() as dest:
                response = client.post(
                    "/api/compress",
                    json={
                        "sources": [tmp],
                        "destination": dest,
                        "name": "bundle",
                        "format": "zip",
                    },
                )
                assert response.status_code == 200, response.get_json()
                data = response.get_json()
                assert data["name"].endswith(".zip")
                with zipfile.ZipFile(data["archive"]) as zf:
                    names = sorted(zf.namelist())
                # Use forward slashes for cross-platform comparison
                names_norm = sorted(n.replace("\\", "/") for n in names)
                assert any(n.endswith("a.txt") for n in names_norm)
                assert any(n.endswith("c.txt") for n in names_norm)

    def test_compress_tar_gz_multiple_files(self, client):
        import tarfile

        with tempfile.TemporaryDirectory() as tmp:
            file_a = Path(tmp, "one.txt")
            file_a.write_text("one")
            file_b = Path(tmp, "two.txt")
            file_b.write_text("two")
            with tempfile.TemporaryDirectory() as dest:
                response = client.post(
                    "/api/compress",
                    json={
                        "sources": [str(file_a), str(file_b)],
                        "destination": dest,
                        "name": "pair",
                        "format": "tar.gz",
                    },
                )
                assert response.status_code == 200
                data = response.get_json()
                assert data["name"].endswith(".tar.gz")
                with tarfile.open(data["archive"], "r:gz") as tf:
                    members = sorted(m.name for m in tf.getmembers())
                assert members == ["one.txt", "two.txt"]

    def test_compress_rejects_unsupported_format(self, client):
        with tempfile.TemporaryDirectory() as tmp:
            Path(tmp, "x.txt").write_text("x")
            response = client.post(
                "/api/compress",
                json={
                    "sources": [tmp],
                    "destination": tmp,
                    "format": "rar",
                },
            )
            assert response.status_code == 400
            assert "Unsupported format" in response.get_json()["error"]

    def test_compress_requires_sources(self, client):
        response = client.post("/api/compress", json={"format": "zip"})
        assert response.status_code == 400
        assert "source" in response.get_json()["error"].lower()


class TestChunkedUpload:
    """Tests for the resumable chunked upload protocol."""

    @pytest.fixture
    def client(self):
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def _send_chunk(self, client, upload_id, payload, start, total):
        end = start + len(payload) - 1
        return client.put(
            f"/api/upload-chunk/{upload_id}",
            data=payload,
            headers={
                "Content-Range": f"bytes {start}-{end}/{total}",
                "Content-Type": "application/octet-stream",
            },
        )

    def test_full_upload_flow(self, client):
        with tempfile.TemporaryDirectory() as tmp:
            payload = b"abcdefghijklmnopqrstuvwxyz" * 4  # 104 bytes
            init = client.post(
                "/api/upload-init",
                json={
                    "filename": "hello.bin",
                    "path": tmp,
                    "size": len(payload),
                },
            )
            assert init.status_code == 200, init.get_json()
            upload_id = init.get_json()["upload_id"]

            # Upload in three chunks.
            chunk1, chunk2, chunk3 = payload[:40], payload[40:80], payload[80:]
            r1 = self._send_chunk(client, upload_id, chunk1, 0, len(payload))
            assert r1.status_code == 200
            r2 = self._send_chunk(client, upload_id, chunk2, 40, len(payload))
            assert r2.status_code == 200

            # Status should report 80 received before the last chunk.
            status = client.get(f"/api/upload-status/{upload_id}")
            assert status.get_json()["received"] == 80

            r3 = self._send_chunk(client, upload_id, chunk3, 80, len(payload))
            assert r3.status_code == 200

            done = client.post(f"/api/upload-complete/{upload_id}")
            assert done.status_code == 200, done.get_json()
            final_path = done.get_json()["path"]
            assert Path(final_path).read_bytes() == payload

    def test_upload_cancel_removes_partial_file(self, client):
        with tempfile.TemporaryDirectory() as tmp:
            payload = b"x" * 50
            init = client.post(
                "/api/upload-init",
                json={"filename": "drop.bin", "path": tmp, "size": len(payload)},
            )
            upload_id = init.get_json()["upload_id"]
            self._send_chunk(client, upload_id, payload[:20], 0, len(payload))

            cancel = client.delete(f"/api/upload-cancel/{upload_id}")
            assert cancel.status_code == 200
            # No leftover .filefy-upload file.
            leftovers = [
                p for p in os.listdir(tmp) if p.endswith(".filefy-upload")
            ]
            assert leftovers == []

    def test_upload_rejects_out_of_order_chunk(self, client):
        with tempfile.TemporaryDirectory() as tmp:
            payload = b"y" * 30
            init = client.post(
                "/api/upload-init",
                json={"filename": "ooo.bin", "path": tmp, "size": len(payload)},
            )
            upload_id = init.get_json()["upload_id"]
            # Skip directly to the second chunk to simulate a buggy client.
            response = self._send_chunk(
                client, upload_id, payload[10:20], 10, len(payload)
            )
            assert response.status_code == 409
            data = response.get_json()
            assert data["expected_offset"] == 0


class TestPauseResumeDownload:
    """Tests for the pause / resume / dismiss endpoints."""

    @pytest.fixture
    def client(self):
        from filefy import app

        app.config["TESTING"] = True
        with app.test_client() as client:
            yield client

    def test_pause_only_active_downloads(self, client):
        import filefy.server as server

        server.download_tasks.clear()
        server.download_tasks["abc"] = {
            "id": "abc",
            "status": "completed",
            "url": "https://example.com/x",
        }
        response = client.post("/api/pause-download/abc")
        assert response.status_code == 409
        server.download_tasks.clear()

    def test_pause_then_resume_marks_states(self, client):
        import filefy.server as server

        server.download_tasks.clear()
        server.download_tasks["abc"] = {
            "id": "abc",
            "status": "downloading",
            "url": "https://example.com/x",
            "destination": "/tmp",
        }
        response = client.post("/api/pause-download/abc")
        assert response.status_code == 200
        assert server.download_tasks["abc"]["paused"] is True

        # Move task to paused status (simulating worker exit).
        server.download_tasks["abc"]["status"] = "paused"

        # Patch the worker so we don't make real network calls.
        original = server.remote_download_task
        try:
            server.remote_download_task = lambda *args, **kwargs: None
            response = client.post("/api/resume-download/abc")
            assert response.status_code == 200
            assert server.download_tasks["abc"]["paused"] is False
        finally:
            server.remote_download_task = original
            server.download_tasks.clear()

    def test_dismiss_only_terminal_tasks(self, client):
        import filefy.server as server

        server.download_tasks.clear()
        server.download_tasks["live"] = {
            "id": "live",
            "status": "downloading",
        }
        server.download_tasks["done"] = {
            "id": "done",
            "status": "completed",
        }

        assert client.post("/api/dismiss-download/live").status_code == 409
        assert client.post("/api/dismiss-download/done").status_code == 200
        assert "done" not in server.download_tasks
        server.download_tasks.clear()
