value = 42
