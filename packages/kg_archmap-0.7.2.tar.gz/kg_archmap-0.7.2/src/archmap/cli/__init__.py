"""CLI package for ArchMAP."""
