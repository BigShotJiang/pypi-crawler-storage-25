# =============================================================================
# test_decorators.py — Test Suite for status_update
# =============================================================================
#
# Purpose:
#   Validates both decorators across realistic scenarios including
#   sub-second, multi-second, and simulated long-duration runs,
#   as well as progressive memory allocation up to safe thresholds.
#
# SAFETY NOTE:
#   Memory tests are capped at 70% of total system RAM by default.
#   The 85%, 95%, and 100% thresholds are documented but NOT run
#   automatically. See the "DANGEROUS ZONE" section at the bottom.
#
# Run with:
#   python test_decorators.py
#
# =============================================================================

import logging
import time
import gc
import sys
from unittest.mock import patch

logging.basicConfig(
    level=logging.DEBUG,
    format='%(levelname)-8s %(message)s'
)

# --- Import both decorators ---
from status_update import status_update, memory_track

# Optional psutil for memory tests
try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    _PSUTIL_AVAILABLE = False


# =============================================================================
# SECTION 1 — STATUS UPDATE TIME TESTS
# =============================================================================
# Philosophy: we cannot wait 2 days to test the formatter.
# Instead we mock time.time() to simulate elapsed durations
# and verify the output string is correct — without waiting at all.
# =============================================================================

print('\n' + '=' * 70)
print('SECTION 1 — STATUS UPDATE: TIME FORMAT TESTS')
print('=' * 70)

# --- Test 1a: Sub-second (real) ---
print('\n[Test 1a] Sub-second execution (real):')

@status_update
def instant_function():
    """Completes in under 1 second."""
    x = [i ** 2 for i in range(100_000)]
    return x

instant_function()

# --- Test 1b: A few real seconds ---
print('\n[Test 1b] Multi-second execution (real — waits 3 seconds):')

@status_update
def short_function():
    """Sleeps for 3 seconds to verify second-level formatting."""
    time.sleep(3)

short_function()

# --- Test 1c: Simulated 1 minute 45 seconds ---
print('\n[Test 1c] Simulated 1 minute 45 seconds (no actual wait):')

_fake_start = time.time()
_fake_elapsed = 105  # 1 min 45 sec in seconds

with patch('time.time', side_effect=[_fake_start, _fake_start + _fake_elapsed]):
    @status_update
    def simulated_minutes():
        """Simulates a function that ran for 1 minute 45 seconds."""
        pass

    simulated_minutes()

# --- Test 1d: Simulated 2 hours 30 minutes 15 seconds ---
print('\n[Test 1d] Simulated 2 hours 30 minutes 15 seconds (no actual wait):')

_fake_start = time.time()
_fake_elapsed = (2 * 3600) + (30 * 60) + 15

with patch('time.time', side_effect=[_fake_start, _fake_start + _fake_elapsed]):
    @status_update
    def simulated_hours():
        """Simulates a function that ran for 2 hours 30 minutes."""
        pass

    simulated_hours()

# --- Test 1e: Simulated 1 day 4 hours 22 minutes 8 seconds ---
print('\n[Test 1e] Simulated 1 day 4 hours 22 minutes 8 seconds (no actual wait):')

_fake_start = time.time()
_fake_elapsed = (1 * 86400) + (4 * 3600) + (22 * 60) + 8

with patch('time.time', side_effect=[_fake_start, _fake_start + _fake_elapsed]):
    @status_update
    def simulated_days():
        """Simulates a long-running overnight batch job."""
        pass

    simulated_days()

# --- Test 1f: Exception handling ---
print('\n[Test 1f] Exception during execution — verifies error logging:')

@status_update
def failing_function():
    """Raises an exception to test error path."""
    time.sleep(1)
    raise ValueError("Simulated computation failure.")

try:
    failing_function()
except ValueError:
    pass  # Expected — we just want to see the log output


# =============================================================================
# SECTION 2 — MEMORY TRACK TESTS
# =============================================================================
# Philosophy: we allocate memory in controlled chunks using bytearray
# (native, predictable, releasable). Each test cleans up after itself.
# Hard ceiling: 70% of total system RAM.
#
# We use bytearray because:
#   - It allocates exactly the bytes you ask for
#   - It is immediately reclaimable with del + gc.collect()
#   - No external libraries needed
# =============================================================================

print('\n' + '=' * 70)
print('SECTION 2 — MEMORY TRACK TESTS')
print('=' * 70)

if not _PSUTIL_AVAILABLE:
    print('\n[INFO] psutil not installed — system-level memory context unavailable.')
    print('[INFO] Install with: pip install psutil')
    print('[INFO] Decorator will still track process-level memory via tracemalloc.\n')


def _available_mb():
    """Returns available system RAM in MB, or None if psutil unavailable."""
    if not _PSUTIL_AVAILABLE:
        return None
    return psutil.virtual_memory().available / (1024 ** 2)


def _total_mb():
    """Returns total system RAM in MB, or None if psutil unavailable."""
    if not _PSUTIL_AVAILABLE:
        return None
    return psutil.virtual_memory().total / (1024 ** 2)


def _current_pct():
    """Returns current system RAM usage percentage."""
    if not _PSUTIL_AVAILABLE:
        return None
    return psutil.virtual_memory().percent


# --- Test 2a: Minimal allocation (baseline, no threshold triggered) ---
print('\n[Test 2a] Minimal allocation — baseline, no thresholds expected:')

@memory_track
def small_allocation():
    """Allocates 50 MB — baseline test, no warnings expected."""
    data = bytearray(50 * 1024 * 1024)  # 50 MB
    time.sleep(0.5)
    return len(data)

small_allocation()
gc.collect()

# --- Test 2b: Medium allocation ---
print('\n[Test 2b] Medium allocation — 200 MB:')

@memory_track
def medium_allocation():
    """Allocates 200 MB — tests process-level peak tracking."""
    data = bytearray(200 * 1024 * 1024)  # 200 MB
    time.sleep(0.5)
    return len(data)

medium_allocation()
gc.collect()

# --- Test 2c: Session accumulation across multiple functions ---
print('\n[Test 2c] Session accumulation — three sequential functions:')
memory_track.reset_session()

@memory_track
def pipeline_step_1():
    """Step 1: allocates 100 MB."""
    data = bytearray(100 * 1024 * 1024)
    time.sleep(0.3)
    return len(data)

@memory_track
def pipeline_step_2():
    """Step 2: allocates 150 MB."""
    data = bytearray(150 * 1024 * 1024)
    time.sleep(0.3)
    return len(data)

@memory_track
def pipeline_step_3():
    """Step 3: allocates 80 MB — smaller, session total should reflect all three."""
    data = bytearray(80 * 1024 * 1024)
    time.sleep(0.3)
    return len(data)

pipeline_step_1()
gc.collect()
pipeline_step_2()
gc.collect()
pipeline_step_3()
gc.collect()

# --- Test 2d: Exception during memory-heavy function ---
print('\n[Test 2d] Exception mid-execution — verifies memory error path:')

@memory_track
def failing_memory_function():
    """Allocates memory then raises — tests exception log path."""
    data = bytearray(100 * 1024 * 1024)
    time.sleep(0.5)
    raise MemoryError("Simulated computation failure mid-allocation.")

try:
    failing_memory_function()
except MemoryError:
    pass
gc.collect()

# --- Test 2e: Threshold trigger test (50% mark only — SAFE) ---
print('\n[Test 2e] Threshold trigger — attempts to cross 50% system RAM:')

if not _PSUTIL_AVAILABLE:
    print('[SKIP] psutil not available — cannot calculate safe allocation size.')
else:
    current_pct = _current_pct()
    total_mb    = _total_mb()
    target_pct  = 55  # aim just past the 50% threshold
    HARD_CEIL   = 70  # absolute safety ceiling — never exceed 70%

    if current_pct >= target_pct:
        print(f'[SKIP] System already at {current_pct:.0f}% — '
              f'50% threshold would fire immediately. Skipping to avoid instability.')
    elif current_pct >= HARD_CEIL:
        print(f'[SKIP] System at {current_pct:.0f}% — above hard safety ceiling of {HARD_CEIL}%.')
    else:
        headroom_pct = min(target_pct, HARD_CEIL) - current_pct
        alloc_mb     = int(total_mb * (headroom_pct / 100))
        print(f'[INFO] System currently at {current_pct:.0f}%. '
              f'Allocating ~{alloc_mb} MB to approach 55%.')

        @memory_track
        def threshold_trigger():
            """Allocates enough RAM to cross the 50% warning threshold."""
            data = bytearray(alloc_mb * 1024 * 1024)
            time.sleep(2)
            return len(data)

        threshold_trigger()
        gc.collect()


# =============================================================================
# SECTION 3 — STACKING BOTH DECORATORS
# =============================================================================

print('\n' + '=' * 70)
print('SECTION 3 — STACKED: @status_update + @memory_track')
print('=' * 70)
print('\n[Test 3a] Both decorators stacked on one function:\n')

@status_update
@memory_track
def full_pipeline():
    """
    Simulates a realistic quant workload:
    allocates 300 MB of data, does some computation, then releases.
    """
    data = bytearray(300 * 1024 * 1024)
    result = sum(data[i] for i in range(0, len(data), 1024))
    time.sleep(1)
    return result

full_pipeline()
gc.collect()


# =============================================================================
# DANGEROUS ZONE — DO NOT RUN AUTOMATICALLY
# =============================================================================
# The tests below target 85%, 95%, and 100% system memory.
# They are defined here for documentation purposes only.
# Uncomment ONE AT A TIME, only on a machine you can afford to restart,
# and only when no other important processes are running.
#
# At 95%+ your OS may kill the Python process or become unresponsive.
# At 100% the machine will very likely freeze or crash.
#
# YOU HAVE BEEN WARNED.
# =============================================================================

# def test_85_pct():
#     if not _PSUTIL_AVAILABLE:
#         return
#     vm          = psutil.virtual_memory()
#     target_mb   = int(vm.total * 0.87 / (1024**2)) - int(vm.used / (1024**2))
#     @memory_track
#     def heavy_load():
#         data = bytearray(target_mb * 1024 * 1024)
#         time.sleep(3)
#     heavy_load()
#     gc.collect()
#
# def test_95_pct():
#     if not _PSUTIL_AVAILABLE:
#         return
#     vm          = psutil.virtual_memory()
#     target_mb   = int(vm.total * 0.96 / (1024**2)) - int(vm.used / (1024**2))
#     @memory_track
#     def critical_load():
#         data = bytearray(target_mb * 1024 * 1024)
#         time.sleep(3)
#     critical_load()
#     gc.collect()


print('\n' + '=' * 70)
print('ALL TESTS COMPLETE')
print('=' * 70 + '\n')
