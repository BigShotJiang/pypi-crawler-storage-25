# =============================================================================
# status_update — Function Logging Decorator
# =============================================================================
#
# Author      : Alexandru-Gabriel Michiduță
# Contact     : michidutaalexandru1995@yahoo.ro
# License     : Attribution-Required Free License (see terms below)
#
# This software is open source and provided free of charge.
# You are free to use, copy, modify, and distribute it for any purpose,
# personal or commercial, at no cost.
#
# CONDITIONS:
#   1. Attribution — Any use in a professional, commercial, or
#      organisational environment must credit the original author:
#      "status_update decorator by Alexandru-Gabriel Michiduță"
#      This credit must appear in documentation, source code headers,
#      or any other reasonable location visible to the project's contributors.
#
#   2. Contributions — Improvements, bug reports, and suggestions are
#      warmly welcomed. Please reach out to the author at the contact
#      address above.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED. THE AUTHOR SHALL NOT BE HELD LIABLE FOR ANY
# CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM ITS USE.
#
# © 2026 Alexandru-Gabriel Michiduță. All rights reserved under the
# terms stated above.
# =============================================================================

# Import globals
import logging
import time
import functools

def status_update(func=None, *, logger=None):
    """
    Decorator that logs the start, end, and elapsed time of any function.

    Can be used bare or with an optional logger argument:

        @status_update
        def my_function(): ...

        @status_update(logger=logging.getLogger('myapp'))
        def my_function(): ...
    """
    _logger = logger or logging.getLogger(__name__)

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            start = time.time()
            _logger.info('Started [%s].', fn.__name__)

            def elapsed():
                seconds = int(time.time() - start)
                parts = []
                for unit, value in [('day', 86400), ('hour', 3600), ('minute', 60), ('second', 1)]:
                    qty = seconds // value
                    seconds %= value
                    if qty:
                        parts.append(f'{qty} {unit}{"s" if qty > 1 else ""}')
                return ', '.join(parts) if parts else '< 1 second'
            try:
                result = fn(*args, **kwargs)
                _logger.info('Completed [%s] in %s.', fn.__name__, elapsed())
                return result
            except Exception as e:
                _logger.exception('Failed [%s] after %s. Error: %s',
                                  fn.__name__, elapsed(), e)
                raise
        return wrapper

    # Handles both @status_update and @status_update(logger=...)
    if func is not None:
        return decorator(func)
    return decorator