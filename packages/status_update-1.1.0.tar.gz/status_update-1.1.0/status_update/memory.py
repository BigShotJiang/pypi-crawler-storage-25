# =============================================================================
# memory_track — Memory Tracking Decorator
# =============================================================================
#
# Author      : Alexandru-Gabriel Michiduță
# Contact     : michidutaalexandru1995@yahoo.ro
# License     : Attribution-Required Free License
#
# This software is open source and provided free of charge.
# You are free to use, copy, modify, and distribute it for any purpose,
# personal or commercial, at no cost.
#
# CONDITIONS:
#   1. Attribution — Any use in a professional, commercial, or
#      organisational environment must credit the original author:
#      "memory_track decorator by Alexandru-Gabriel Michduiță"
#      This credit must appear in documentation, source code headers,
#      or any other reasonable location visible to the project's contributors.
#
#   2. Contributions — Improvements, bug reports, and suggestions are
#      warmly welcomed. Please reach out to the author at the contact
#      address above.
#
# THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED. THE AUTHOR SHALL NOT BE HELD LIABLE FOR ANY
# CLAIM, DAMAGES, OR OTHER LIABILITY ARISING FROM ITS USE.
#
# © 2025 Alexandru-Gabriel Michiță. All rights reserved under the
# terms stated above.
# =============================================================================

import logging
import threading
import tracemalloc
import functools

# Optional psutil for system-level memory — graceful fallback if not installed
try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    _PSUTIL_AVAILABLE = False
    logging.getLogger(__name__).info(
        'memory_track: psutil is not installed. The decorator will track '
        'process-level memory only. For full system memory context and '
        'real-time threshold warnings, install psutil: pip install psutil'
    )

# Session accumulator — tracks net memory across all decorated calls
_session_net_bytes = 0


def reset_session():
    """Resets the session memory accumulator to zero."""
    global _session_net_bytes
    _session_net_bytes = 0


def _format_bytes(b):
    """Auto-scales bytes to the most readable unit."""
    abs_b = abs(b)
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if abs_b < 1024:
            return f'{abs_b:.1f} {unit}'
        abs_b /= 1024
    return f'{abs_b:.1f} PB'


def _signed(b):
    """Returns a signed, formatted byte string."""
    return ('+' if b >= 0 else '-') + _format_bytes(abs(b))


def _system_str():
    """Returns a formatted system memory string if psutil is available."""
    if not _PSUTIL_AVAILABLE:
        return None
    vm = psutil.virtual_memory()
    return (f'{_format_bytes(vm.used)} / {_format_bytes(vm.total)} '
            f'({vm.percent:.0f}%)')


def _system_percent():
    """Returns current system memory usage as a percentage."""
    if not _PSUTIL_AVAILABLE:
        return None
    return psutil.virtual_memory().percent


class _MemoryWatcher(threading.Thread):
    """
    Daemon thread that polls system memory once per second and fires
    threshold warnings exactly once per level per function call.
    """

    # (threshold %, log level, label)
    THRESHOLDS = [
        (50,  logging.INFO,     'NOTICE'),
        (75,  logging.WARNING,  'WARNING'),
        (85,  logging.WARNING,  'WARNING'),
        (95,  logging.CRITICAL, 'CRITICAL'),
        (100, logging.CRITICAL, 'CRITICAL'),
    ]

    def __init__(self, fn_name, logger):
        super().__init__(daemon=True)
        self._fn_name  = fn_name
        self._logger   = logger
        self._stop     = threading.Event()
        self._fired    = set()

    def run(self):
        while not self._stop.is_set():
            pct = _system_percent()
            if pct is not None:
                for threshold, level, _ in self.THRESHOLDS:
                    if pct >= threshold and threshold not in self._fired:
                        self._fired.add(threshold)
                        sys_str = _system_str()
                        if threshold == 100:
                            self._logger.log(
                                level,
                                '[%s] ⚠ Memory saturated — process will likely be killed '
                                '| System: %s',
                                self._fn_name, sys_str
                            )
                        else:
                            self._logger.log(
                                level,
                                '[%s] Memory at %d%% | System: %s',
                                self._fn_name, threshold, sys_str
                            )
            self._stop.wait(1.0)  # 1 second poll — negligible overhead

    def stop(self):
        self._stop.set()
        self.join(timeout=2)


def memory_track(func=None, *, logger=None):
    """
    Decorator that tracks memory usage of any function.

    Logs before, peak, net delta, and running session total.
    If psutil is installed, also tracks real system memory and fires
    real-time threshold warnings in a background thread.

    Can be used bare or with an optional logger:

        @memory_track
        def my_function(): ...

        @memory_track(logger=logging.getLogger('myapp'))
        def my_function(): ...

    Stacks cleanly with @status_update:

        @status_update
        @memory_track
        def my_function(): ...

    To reset the session accumulator mid-run:

        from status_update import memory_track
        memory_track.reset_session()
    """
    _logger = logger or logging.getLogger(__name__)

    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            global _session_net_bytes

            # Layer 1: start tracing fresh for accurate per-function peak
            tracemalloc.stop()
            tracemalloc.start()

            # Layer 2: log start with system context
            sys_before = _system_str()
            if sys_before:
                _logger.info('[%s] Memory started | System: %s',
                             fn.__name__, sys_before)
            else:
                _logger.info('[%s] Memory started.', fn.__name__)

            # Layer 3: launch background watcher ---
            watcher = _MemoryWatcher(fn.__name__, _logger)
            watcher.start()

            try:
                result = fn(*args, **kwargs)
            except Exception as e:
                watcher.stop()
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()
                _logger.exception('[%s] Memory — failed | Peak reached: %s | Error: %s',
                                  fn.__name__, _format_bytes(peak), e)
                raise
            else:
                watcher.stop()
                current, peak = tracemalloc.get_traced_memory()
                tracemalloc.stop()

                net = current
                _session_net_bytes += net
                sys_after = _system_str()

                if sys_after:
                    _logger.info(
                        '[%s] Memory completed | Before: %s | Peak: %s | '
                        'Net: %s | Session: %s | System: %s',
                        fn.__name__,
                        _format_bytes(0),           # before is baseline zero per fresh trace
                        _format_bytes(peak),
                        _signed(net),
                        _signed(_session_net_bytes),
                        sys_after
                    )
                else:
                    _logger.info(
                        '[%s] Memory completed | Peak: %s | Net: %s | Session: %s',
                        fn.__name__,
                        _format_bytes(peak),
                        _signed(net),
                        _signed(_session_net_bytes)
                    )

                return result

        return wrapper

    if func is not None:
        return decorator(func)
    return decorator

# Attach reset_session to the decorator itself for clean API access
memory_track.reset_session = reset_session