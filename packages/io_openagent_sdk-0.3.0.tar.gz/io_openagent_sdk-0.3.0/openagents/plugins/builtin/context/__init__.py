"""Builtin context assembler implementations."""
