"""Builtin memory plugins."""

