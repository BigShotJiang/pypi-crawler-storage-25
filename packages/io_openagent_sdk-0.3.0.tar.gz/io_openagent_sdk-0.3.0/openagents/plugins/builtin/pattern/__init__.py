"""Builtin pattern plugins."""

