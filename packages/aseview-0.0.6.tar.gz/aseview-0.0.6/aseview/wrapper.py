"""
Wrapper module for molecular visualization
"""

import glob as glob_module
import json
import os
import re
from typing import Dict, Any, List, Union
from ase import Atoms
import numpy as np

_STYLES_JS_TAG_RE = re.compile(
    r'<script\s+src=["\']https://cdn\.jsdelivr\.net/gh/kangmg/aseview@main/aseview/static/js/styles\.js(?:\?[^"\']*)?["\']\s*></script>'
)

# ── Theme management ──────────────────────────────────────────────────────────
_THEME = 'dark'

def set_theme(name: str) -> None:
    """Set the global default theme for all viewers."""
    global _THEME
    _THEME = name

def get_theme() -> str:
    """Return the current global theme name."""
    return _THEME

def list_themes() -> List[str]:
    """Return the names of all installed themes."""
    themes_dir = os.path.join(os.path.dirname(__file__), "themes")
    if not os.path.isdir(themes_dir):
        return []
    return sorted(d for d in os.listdir(themes_dir)
                  if os.path.isdir(os.path.join(themes_dir, d)))

def _resolve_template(name: str, theme: str = None) -> str:
    """
    Resolve an HTML template file path for the given theme.

    Search order:
      1. aseview/themes/{theme}/{name}
      2. aseview/templates/{name}  (backward-compat fallback)
    """
    theme = theme or _THEME
    pkg = os.path.dirname(__file__)
    path = os.path.join(pkg, "themes", theme, name)
    if os.path.exists(path):
        return path
    path = os.path.join(pkg, "templates", name)
    if os.path.exists(path):
        return path
    raise FileNotFoundError(
        f"Template '{name}' not found for theme '{theme}'. "
        f"Available themes: {list_themes()}"
    )


def _inline_styles_js(html: str) -> str:
    """Inline packaged styles.js, accepting cache-busted CDN script tags."""
    styles_path = os.path.join(os.path.dirname(__file__), "static", "js", "styles.js")
    if not os.path.exists(styles_path):
        return html
    with open(styles_path, "r", encoding="utf-8") as style_file:
        styles_js = style_file.read()
    return _STYLES_JS_TAG_RE.sub(f"<script>\n{styles_js}\n</script>", html)


class MolecularData:
    """Class to handle molecular data conversion between ASE Atoms and JSON format."""

    @staticmethod
    def from_atoms(atoms: Atoms) -> Dict[str, Any]:
        """Convert ASE Atoms object to JSON-serializable dictionary."""
        positions = atoms.get_positions().tolist()
        symbols = atoms.get_chemical_symbols()

        data = {"positions": positions, "symbols": symbols}

        # Add cell information if present
        cell = atoms.get_cell()
        if cell.rank > 0:
            data["cell"] = cell.tolist()
            data["pbc"] = atoms.pbc.tolist()

        # Add forces if present (from calculator or arrays)
        try:
            if atoms.calc is not None:
                forces = atoms.get_forces()
                data["forces"] = forces.tolist()
        except Exception:
            pass

        # Fallback to arrays if not from calculator
        if "forces" not in data and hasattr(atoms, "arrays") and "forces" in atoms.arrays:
            data["forces"] = atoms.arrays["forces"].tolist()

        # Add energy if available (from calculator or info dict)
        try:
            if atoms.calc is not None:
                data["energy"] = float(atoms.get_potential_energy())
        except Exception:
            pass

        # Check info dict for energy (common in trajectory files)
        if "energy" not in data and hasattr(atoms, "info"):
            for key in ["energy", "Energy", "E", "total_energy"]:
                if key in atoms.info:
                    data["energy"] = float(atoms.info[key])
                    break

        # Add name if available in info dict
        if hasattr(atoms, "info") and "name" in atoms.info:
            data["name"] = str(atoms.info["name"])

        # Add charges if available (from arrays or info dict)
        charges = None
        if hasattr(atoms, "arrays") and "charges" in atoms.arrays:
            charges = atoms.arrays["charges"]
        elif hasattr(atoms, "info") and "charges" in atoms.info:
            charges = atoms.info["charges"]

        if charges is not None:
            try:
                import numpy as np

                charges_array = np.asarray(charges, dtype=float).flatten()
                if len(charges_array) == len(symbols):
                    data["charges"] = charges_array.tolist()
            except (TypeError, ValueError):
                pass

        # Add fixed atom indices from FixAtoms constraints
        if hasattr(atoms, "constraints") and atoms.constraints:
            import numpy as np

            fixed = []
            for c in atoms.constraints:
                if hasattr(c, "index"):  # FixAtoms stores indices in .index
                    fixed.extend(int(i) for i in np.asarray(c.index).flatten())
            if fixed:
                data["fixed"] = sorted(set(fixed))

        return data

    @staticmethod
    def to_atoms(data: Dict[str, Any]) -> Atoms:
        """Convert JSON-serializable dictionary to ASE Atoms object."""
        atoms = Atoms(symbols=data["symbols"], positions=data["positions"])

        if "cell" in data:
            atoms.set_cell(data["cell"])
            atoms.pbc = data.get("pbc", [True, True, True])

        if "fixed" in data and data["fixed"]:
            from ase.constraints import FixAtoms

            atoms.set_constraint(FixAtoms(indices=data["fixed"]))

        return atoms


class BaseViewer:
    """Base class for all molecular viewers."""

    def __init__(self, data: Union[Atoms, Dict[str, Any], str, List]):
        """
        Initialize the viewer with molecular data.

        Args:
            data: Can be an ASE Atoms object, a dictionary with molecular data,
                  a path to a JSON file containing molecular data, or a list of any of these.
        """
        self.data = self._process_data(data)

    def _process_data(self, data):
        """Process input data into a standardized format."""
        if isinstance(data, str):
            from ase.io import read as ase_read

            # Check if it's a glob pattern
            is_glob = any(c in data for c in ("*", "?", "["))
            if is_glob:
                files = sorted(glob_module.glob(data))
                if not files:
                    raise ValueError(f"No files matched glob pattern: {data}")
                all_atoms = []
                for f in files:
                    frames = ase_read(f, index=":")
                    if isinstance(frames, Atoms):
                        frames = [frames]
                    all_atoms.extend(frames)
                return [MolecularData.from_atoms(a) for a in all_atoms]
            elif os.path.exists(data):
                # File path: read all frames by default
                frames = ase_read(data, index=":")
                if isinstance(frames, Atoms):
                    frames = [frames]
                return [MolecularData.from_atoms(a) for a in frames]
            else:
                # Fall back to JSON
                with open(data, "r") as f:
                    return json.load(f)
        elif isinstance(data, Atoms):
            return MolecularData.from_atoms(data)
        elif isinstance(data, list):
            # If it's a list, process each element
            processed_list = []
            for item in data:
                if isinstance(item, Atoms):
                    processed_list.append(MolecularData.from_atoms(item))
                elif isinstance(item, dict):
                    processed_list.append(item)
                else:
                    raise ValueError(f"Unsupported data type in list: {type(item)}")
            return processed_list
        elif isinstance(data, dict):
            return data
        elif hasattr(data, "__iter__") and not isinstance(data, (str, dict)):
            # Handle iterables like ASE Trajectory - convert to list and process
            return self._process_data(list(data))
        else:
            raise ValueError(f"Unsupported data type: {type(data)}")

    def _get_js_data(self) -> str:
        """Convert molecular data to JavaScript-compatible JSON string."""
        # Ensure data is a list for consistency
        if not isinstance(self.data, list):
            data_to_convert = [self.data]
        else:
            data_to_convert = self.data

        return json.dumps(data_to_convert)

    def show(self, width="100%", height=600):
        """Display the viewer in a Jupyter notebook."""
        try:
            from IPython.display import display, HTML

            html = self._generate_html()

            # Escape HTML for srcdoc attribute (handles quotes and special chars)
            # This avoids data: URI size limits that cause failures with large molecules
            escaped_html = (
                html.replace("&", "&amp;")
                .replace('"', "&quot;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
            )

            # Use srcdoc instead of data: URI to avoid size limits
            # srcdoc supports much larger content than data: URIs
            width_style = width if isinstance(width, str) else f"{width}px"
            iframe_html = f"""
<div style="width: {width_style}; height: {height}px; position: relative;">
    <iframe
        srcdoc="{escaped_html}"
        width="100%"
        height="100%"
        style="border: 1px solid #ddd; border-radius: 4px; display: block;"
        sandbox="allow-scripts allow-same-origin allow-downloads allow-modals"
        scrolling="no">
    </iframe>
</div>
"""
            display(HTML(iframe_html))
        except ImportError:
            print("IPython is not available. Use get_html() to get the HTML content.")

    def get_html(self) -> str:
        """Get the HTML content for the viewer."""
        return self._generate_html()

    def save_html(self, filename: str) -> None:
        """Save the viewer as an HTML file."""
        html = self.get_html()
        with open(filename, "w") as f:
            f.write(html)
        print(f"Saved viewer to {filename}")

    def _generate_html(self) -> str:
        """Generate the HTML content for the viewer."""
        # This will be implemented by subclasses
        raise NotImplementedError


class MolecularViewer(BaseViewer):
    """Molecular viewer with advanced settings and controls."""

    def __init__(self, data: Union[Atoms, Dict[str, Any], str, List], theme: str = None, **kwargs):
        super().__init__(data)
        self._theme = theme
        self.settings = {
            "bondThreshold": 1.2,  # Scale factor for covalent radii sum
            "hBondThreshold": 2.5, # H...A distance cutoff for hydrogen-bond detection (Å)
            "bondThickness": 0.1,
            "atomSize": 0.4,
            "animationSpeed": 30,
            "forceScale": 1.0,
            "backgroundColor": "#1f2937",
            "style": "cartoon",
            "showCell": True,
            "showBond": True,
            "hideHydrogens": False,
            "showBlur": False,
            "blurStrength": 1.5,
            "showHBond": False,          # Hydrogen bond detection (N/O/F donors & acceptors)
            "showShadow": False,
            "showShading": True,
            "showEnergyPlot": False,
            "showForces": False,
            "colorBy": "Element",        # "Element" or "Charge"
            "showConstraint": False,
            "colorScheme": "Jmol",       # "Jmol" (default), "CPK", "PyMOL", or "VMD"
            "normalizeCharges": False,   # Normalize charges to symmetric range
            "chargeColormap": "coolwarm",
            "viewMode": "Perspective",
            "rotationMode": "TrackBall",
            "selectionMode": "Lasso",
            "performanceMode": "auto",   # "auto", "high", or "normal"
            **kwargs,
        }

    def _generate_html(self) -> str:
        """Generate the HTML content for the molecular viewer."""
        js_data = self._get_js_data()

        # Load the HTML template
        try:
            template_path = _resolve_template("molecular_viewer.html", self._theme)
            with open(template_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return self._generate_simple_html()

        # Inline all JavaScript dependencies for Jupyter compatibility
        vendor_dir = os.path.join(os.path.dirname(__file__), "static", "js", "vendor")

        # Inline Three.js
        three_path = os.path.join(vendor_dir, "three.min.js")
        if os.path.exists(three_path):
            with open(three_path, "r", encoding="utf-8") as f:
                three_js = f.read()
            html = html.replace(
                '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>',
                f"<script>{three_js}</script>",
            )

        # Inline OrbitControls
        orbit_path = os.path.join(vendor_dir, "OrbitControls.js")
        if os.path.exists(orbit_path):
            with open(orbit_path, "r", encoding="utf-8") as f:
                orbit_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js"></script>',
                f"<script>{orbit_js}</script>",
            )

        # Inline TrackballControls
        trackball_path = os.path.join(vendor_dir, "TrackballControls.js")
        if os.path.exists(trackball_path):
            with open(trackball_path, "r", encoding="utf-8") as f:
                trackball_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/TrackballControls.js"></script>',
                f"<script>{trackball_js}</script>",
            )

        # Inline styles.js
        html = _inline_styles_js(html)

        # Inline gifshot.js for GIF export
        gifshot_path = os.path.join(vendor_dir, "gifshot.js")
        if os.path.exists(gifshot_path):
            with open(gifshot_path, "r", encoding="utf-8") as f:
                gifshot_js = f.read()
            gifshot_tag = '<script src="https://cdnjs.cloudflare.com/ajax/libs/gifshot/0.3.2/gifshot.min.js"></script>'
            inline_gifshot_tag = f"<script>{gifshot_js}</script>"
            if gifshot_tag in html:
                html = html.replace(gifshot_tag, inline_gifshot_tag)
            else:
                html = html.replace("</head>", f"{inline_gifshot_tag}\n</head>")

        # Inject molecular data
        if "{{molecular_data}}" in html:
            html = html.replace("{{molecular_data}}", js_data)
            return html

        # If template does not expose placeholder, call setMolecularData at load
        # Use both DOMContentLoaded and immediate execution for iframe compatibility
        settings_json = json.dumps(self.settings)
        script = f"""
<script>
    (function() {{
        var MAX_RETRIES = 100;  // 5 seconds max (100 * 50ms)
        var retryCount = 0;
        var pythonSettings = {settings_json};

        function initData() {{
            function trySetData() {{
                retryCount++;
                if (typeof renderer !== 'undefined' && renderer !== null) {{
                    // Apply Python settings to the settings object
                    if (typeof settings === 'undefined') {{
                        window.settings = {{}};
                    }}
                    Object.assign(settings, pythonSettings);
                    // Sync UI elements to reflect the applied Python settings
                    if (typeof updateFromSettings === 'function') {{
                        updateFromSettings();
                    }}
                    if (typeof setMolecularData === 'function') {{
                        setMolecularData({js_data});
                    }} else {{
                        console.error('setMolecularData function not found!');
                    }}
                }} else if (retryCount < MAX_RETRIES) {{
                    setTimeout(trySetData, 50);
                }} else {{
                    console.error('Renderer initialization timeout after ' + (MAX_RETRIES * 50) + 'ms');
                }}
            }}

            trySetData();
        }}

        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', initData);
        }} else {{
            initData();
        }}
    }})();
</script>
</body>
"""
        return html.replace("</body>", script)

    def _generate_simple_html(self) -> str:
        """Generate a simple HTML fallback."""
        return f"""
<!DOCTYPE html>
<html>
<head>
    <title>Molecular Viewer</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{ font-family: Arial, sans-serif; background: #111827; color: #f9fafb; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }}
        .container {{ text-align: center; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Molecular Viewer</h1>
        <p>Molecular data loaded successfully</p>
        <div>
            <p>Number of molecules: {len(self.data) if isinstance(self.data, list) else 1}</p>
            <p>Atoms in first molecule: {len(self.data[0]['symbols']) if (isinstance(self.data, list) and self.data and 'symbols' in self.data[0]) else (len(self.data['symbols']) if (isinstance(self.data, dict) and 'symbols' in self.data) else 0)}</p>
        </div>
    </div>
    <script>
        function setMolecularData(data) {{
            console.log('Molecular data set:', data);
        }}
        setMolecularData({self._get_js_data()});
    </script>
</body>
</html>
        """


def _expand_selective_modes(
    normal_modes: "np.ndarray",
    free_positions: "np.ndarray",
    struct_positions: "np.ndarray",
    n_free: int,
    n_full: int,
    tol: float = 0.5,
) -> "np.ndarray":
    """
    Expand normal modes from n_free atoms to n_full atoms (selective dynamics).

    Maps each free atom to its counterpart in the full structure by nearest
    Cartesian position, then zero-pads fixed atoms.

    Args:
        normal_modes: (n_modes, 3*n_free) displacement array
        free_positions: (n_free, 3) Cartesian coords from OUTCAR eigenvector block
        struct_positions: (n_full, 3) Cartesian coords from the full structure
        n_free: number of free atoms in OUTCAR
        n_full: total atom count in full structure
        tol: maximum allowed matching distance in Angstrom

    Returns:
        (n_modes, 3*n_full) array with zeros for fixed atoms
    """
    import numpy as np

    free_indices = []
    for i, fpos in enumerate(free_positions):
        dists = np.linalg.norm(struct_positions - fpos, axis=1)
        best = int(np.argmin(dists))
        if dists[best] > tol:
            raise ValueError(
                f"Selective dynamics: free atom {i} at {fpos} cannot be matched "
                f"to any atom in the structure (closest distance: {dists[best]:.3f} Å). "
                "Check that the OUTCAR and structure file correspond to the same geometry."
            )
        free_indices.append(best)

    n_modes = normal_modes.shape[0]
    full_modes = np.zeros((n_modes, n_full * 3))
    for free_idx, struct_idx in enumerate(free_indices):
        full_modes[:, struct_idx * 3 : struct_idx * 3 + 3] = (
            normal_modes[:, free_idx * 3 : free_idx * 3 + 3]
        )
    return full_modes


class NormalViewer(BaseViewer):
    """Normal mode viewer for molecular vibrations."""

    def __init__(
        self,
        atoms: Union[Atoms, Dict[str, Any]],
        vibrations=None,
        mode_vectors: List = None,
        frequencies: List = None,
        n_frames: int = 30,
        theme: str = None,
        **kwargs,
    ):
        """
        Initialize NormalViewer for visualizing vibrational modes.

        Args:
            atoms: ASE Atoms object of equilibrium structure
            vibrations: ASE Vibrations or VibrationsData object (optional)
            mode_vectors: List of mode displacement vectors (optional, extracted from vibrations if not provided)
            frequencies: List of frequencies in cm^-1 (optional, extracted from vibrations if not provided)
            n_frames: Number of animation frames per cycle
            **kwargs: Additional viewer settings
        """
        self._theme = theme

        # Process atoms data
        if isinstance(atoms, Atoms):
            self.atoms_data = MolecularData.from_atoms(atoms)
        elif isinstance(atoms, dict):
            self.atoms_data = atoms
        else:
            raise ValueError(f"Unsupported atoms type: {type(atoms)}")

        # Store as data for compatibility
        self.data = self.atoms_data

        # Extract vibration data
        self.mode_vectors = None
        self.frequencies = None
        self.is_imaginary = None

        if vibrations is not None:
            self._extract_vibration_data(vibrations)
        elif mode_vectors is not None and frequencies is not None:
            self.mode_vectors = (
                mode_vectors if isinstance(mode_vectors, list) else mode_vectors.tolist()
            )
            self.frequencies, self.is_imaginary = self._format_frequencies(frequencies)

        self.n_frames = n_frames

        self.settings = {
            "bondThreshold": 1.2,
            "bondThickness": 0.1,
            "atomSize": 0.4,
            "animationSpeed": 30,
            "backgroundColor": "#1f2937",
            "style": "cartoon",
            "showCell": True,
            "cellColor": "#808080",
            "showBond": True,
            "hideHydrogens": False,
            "showBlur": False,
            "blurStrength": 1.5,
            "showShadow": False,
            "displacementAmplitude": 0.75,
            "showModeVector": False,
            "initialModeIndex": 0,
            "nFrames": n_frames,
            "performanceMode": "auto",  # "auto", "high", or "normal"
            **kwargs,
        }

    def _extract_vibration_data(self, vib):
        """Extract mode vectors and frequencies from ASE Vibrations object."""
        import numpy as np

        # Try to get VibrationsData
        try:
            from ase.vibrations import Vibrations
            from ase.vibrations.data import VibrationsData
        except ImportError:
            raise ImportError("ASE vibrations module is required")

        if hasattr(vib, "get_vibrations"):
            vib_data = vib.get_vibrations()
        else:
            vib_data = vib

        # Get mode vectors (all atoms)
        modes = vib_data.get_modes(all_atoms=True)
        self.mode_vectors = modes.tolist()

        # Get frequencies and format them
        freqs = vib_data.get_frequencies()
        self.frequencies, self.is_imaginary = self._format_frequencies(freqs)

    def _format_frequencies(self, freqs):
        """Format frequencies for display, handling imaginary values."""
        import numpy as np

        formatted = []
        is_imaginary = []

        for f in freqs:
            if np.iscomplexobj(f) and f.imag != 0:
                formatted.append(f"{f.imag:.2f}i")
                is_imaginary.append(True)
            else:
                val = f.real if np.iscomplexobj(f) else float(f)
                formatted.append(f"{val:.2f}")
                is_imaginary.append(False)

        return formatted, is_imaginary

    def _get_js_data(self) -> str:
        """Get molecular data as JSON for JavaScript."""
        return json.dumps(self.atoms_data)

    def _get_vibration_data(self) -> dict:
        """Get vibration data for JavaScript."""
        return {
            "modeVectors": self.mode_vectors,
            "frequencies": self.frequencies,
            "isImaginary": self.is_imaginary,
            "nFrames": self.n_frames,
        }

    def _generate_html(self) -> str:
        """Generate the HTML content for the normal mode viewer."""
        atoms_json = self._get_js_data()

        # Prepare vibration data
        if self.mode_vectors is not None:
            vib_data = self._get_vibration_data()
            vib_json = json.dumps(vib_data)
            has_vibrations = "true"
        else:
            vib_json = "null"
            has_vibrations = "false"

        # Load normal_viewer template
        try:
            template_path = _resolve_template("normal_viewer.html", self._theme)
            with open(template_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return self._generate_simple_html("Normal Mode Viewer")

        # Inline JavaScript dependencies
        vendor_dir = os.path.join(os.path.dirname(__file__), "static", "js", "vendor")

        # Inline Three.js
        three_path = os.path.join(vendor_dir, "three.min.js")
        if os.path.exists(three_path):
            with open(three_path, "r", encoding="utf-8") as f:
                three_js = f.read()
            html = html.replace(
                '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>',
                f"<script>{three_js}</script>",
            )

        # Inline OrbitControls
        orbit_path = os.path.join(vendor_dir, "OrbitControls.js")
        if os.path.exists(orbit_path):
            with open(orbit_path, "r", encoding="utf-8") as f:
                orbit_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js"></script>',
                f"<script>{orbit_js}</script>",
            )

        # Inline TrackballControls
        trackball_path = os.path.join(vendor_dir, "TrackballControls.js")
        if os.path.exists(trackball_path):
            with open(trackball_path, "r", encoding="utf-8") as f:
                trackball_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/TrackballControls.js"></script>',
                f"<script>{trackball_js}</script>",
            )

        # Inline styles.js
        html = _inline_styles_js(html)

        # Inline gifshot.js for GIF export
        gifshot_path = os.path.join(vendor_dir, "gifshot.js")
        if os.path.exists(gifshot_path):
            with open(gifshot_path, "r", encoding="utf-8") as f:
                gifshot_js = f.read()
            gifshot_tag = '<script src="https://cdnjs.cloudflare.com/ajax/libs/gifshot/0.3.2/gifshot.min.js"></script>'
            inline_gifshot_tag = f"<script>{gifshot_js}</script>"
            if gifshot_tag in html:
                html = html.replace(gifshot_tag, inline_gifshot_tag)
            else:
                html = html.replace("</head>", f"{inline_gifshot_tag}\n</head>")

        # Inject data and settings
        settings_json = json.dumps(self.settings)
        script = f"""
<script>
    (function() {{
        var MAX_RETRIES = 100;
        var retryCount = 0;
        var pythonSettings = {settings_json};

        // Inject data from Python
        window.equilibriumAtoms = {atoms_json};
        window.vibrationData = {vib_json};
        window.hasVibrations = {has_vibrations};

        function initData() {{
            function trySetData() {{
                retryCount++;
                if (typeof renderer !== 'undefined' && renderer !== null) {{
                    // Apply Python settings to the settings object
                    if (typeof settings === 'undefined') {{
                        window.settings = {{}};
                    }}
                    Object.assign(settings, pythonSettings);
                    // Sync UI elements to reflect the applied Python settings
                    if (typeof updateFromSettings === 'function') {{
                        updateFromSettings();
                    }}
                    if (typeof initNormalModeViewer === 'function') {{
                        initNormalModeViewer(window.equilibriumAtoms, window.vibrationData);
                    }} else if (typeof setMolecularData === 'function') {{
                        // Fallback for templates without vibration support
                        setMolecularData([window.equilibriumAtoms]);
                    }}
                }} else if (retryCount < MAX_RETRIES) {{
                    setTimeout(trySetData, 50);
                }}
            }}

            trySetData();
        }}

        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', initData);
        }} else {{
            initData();
        }}
    }})();
</script>
</body>
"""
        return html.replace("</body>", script)

    def _generate_simple_html(self, title: str) -> str:
        """Generate a simple HTML fallback."""
        return f"""
<!DOCTYPE html>
<html>
<head>
    <title>{title}</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; background: #111827; color: #f9fafb;
                display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }}
        .container {{ text-align: center; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        <p>Data loaded successfully</p>
    </div>
</body>
</html>
        """

    @classmethod
    def from_orca(cls, atoms, hess_file: str, skip_imaginary: bool = False, **kwargs):
        """
        Create NormalViewer from ORCA .hess file.

        Args:
            atoms: ASE Atoms object of equilibrium structure
            hess_file: Path to ORCA .hess file
            skip_imaginary: If True, skip translational/rotational modes (freq < 10 cm^-1). Default False.
            **kwargs: Additional viewer settings

        Returns:
            NormalViewer instance

        Example:
            >>> from ase.io import read
            >>> atoms = read("molecule.xyz")
            >>> viewer = NormalViewer.from_orca(atoms, "orca.hess")
            >>> viewer.show()
        """
        if isinstance(atoms, str):
            raise TypeError(
                f"Expected an Atoms object as the first argument, got a string '{atoms}'. "
                "Usage: NormalViewer.from_orca(atoms, hess_file)"
            )

        from .hessian_parsers import parse_orca_hess, reshape_modes_to_atoms, get_real_vibrations

        # Parse ORCA .hess file
        frequencies, normal_modes, n_atoms_hess = parse_orca_hess(hess_file)

        # Verify atom count matches
        if isinstance(atoms, Atoms):
            n_atoms = len(atoms)
        else:
            n_atoms = len(atoms.get("symbols", []))

        if n_atoms != n_atoms_hess:
            raise ValueError(
                f"Atom count mismatch: structure has {n_atoms} atoms, "
                f"but Hessian file has {n_atoms_hess} atoms"
            )

        # Filter out translations/rotations if requested
        if skip_imaginary:
            frequencies, normal_modes = get_real_vibrations(frequencies, normal_modes)

        # Reshape modes to per-atom format
        mode_vectors = reshape_modes_to_atoms(normal_modes, n_atoms)

        return cls(atoms, mode_vectors=mode_vectors, frequencies=frequencies.tolist(), **kwargs)

    @classmethod
    def from_vasp(cls, atoms, outcar_file: str, skip_imaginary: bool = False, **kwargs):
        """
        Create NormalViewer from VASP OUTCAR file (IBRION=5 or 6).

        Supports selective dynamics: if the OUTCAR contains eigenvectors only for
        a subset of free atoms, their Cartesian positions are used to match them
        to the full structure and the mode vectors are zero-padded for fixed atoms.

        Args:
            atoms: ASE Atoms object of equilibrium structure
            outcar_file: Path to VASP OUTCAR file
            skip_imaginary: If True, skip translational/rotational modes (freq < 10 cm^-1). Default False.
            **kwargs: Additional viewer settings

        Returns:
            NormalViewer instance

        Example:
            >>> from ase.io import read
            >>> atoms = read("POSCAR")
            >>> viewer = NormalViewer.from_vasp(atoms, "OUTCAR")
            >>> viewer.show()
        """
        import numpy as np
        from .hessian_parsers import parse_vasp_outcar, reshape_modes_to_atoms, get_real_vibrations

        if isinstance(atoms, str):
            raise TypeError(
                f"Expected an Atoms object as the first argument, got a string '{atoms}'. "
                "Usage: NormalViewer.from_vasp(atoms, outcar_file)"
            )

        frequencies, normal_modes, n_atoms_outcar, free_positions = parse_vasp_outcar(outcar_file)

        if isinstance(atoms, Atoms):
            n_atoms = len(atoms)
            struct_positions = atoms.get_positions()
        else:
            syms = atoms.get("symbols", [])
            n_atoms = len(syms)
            struct_positions = np.array(atoms.get("positions", []))

        if n_atoms != n_atoms_outcar:
            # Selective dynamics: OUTCAR only has eigenvectors for free atoms.
            # Match free atoms to the full structure by Cartesian position.
            normal_modes = _expand_selective_modes(
                normal_modes, free_positions, struct_positions, n_atoms_outcar, n_atoms
            )

        if skip_imaginary:
            frequencies, normal_modes = get_real_vibrations(frequencies, normal_modes)

        mode_vectors = reshape_modes_to_atoms(normal_modes, n_atoms)

        return cls(atoms, mode_vectors=mode_vectors, frequencies=frequencies.tolist(), **kwargs)

    @classmethod
    def from_file(cls, atoms, filepath: str, skip_imaginary: bool = False, **kwargs):
        """
        Create NormalViewer from a Hessian file, auto-detecting the format.

        Supports ORCA .hess files and VASP OUTCAR files (IBRION=5 or 6).

        Args:
            atoms: ASE Atoms object of equilibrium structure
            filepath: Path to Hessian file (ORCA .hess or VASP OUTCAR)
            skip_imaginary: If True, skip translational/rotational modes (freq < 10 cm^-1). Default False.
            **kwargs: Additional viewer settings

        Returns:
            NormalViewer instance

        Example:
            >>> from ase.io import read
            >>> atoms = read("molecule.xyz")
            >>> viewer = NormalViewer.from_file(atoms, "orca.hess")   # ORCA
            >>> viewer = NormalViewer.from_file(atoms, "OUTCAR")       # VASP
            >>> viewer.show()
        """
        if isinstance(atoms, str):
            raise TypeError(
                f"Expected an Atoms object as the first argument, got a string '{atoms}'. "
                "Usage: NormalViewer.from_file(atoms, filepath)"
            )

        from .hessian_parsers import detect_hessian_format

        fmt = detect_hessian_format(filepath)
        if fmt == "vasp":
            return cls.from_vasp(atoms, filepath, skip_imaginary, **kwargs)
        return cls.from_orca(atoms, filepath, skip_imaginary, **kwargs)


class OverlayViewer(BaseViewer):
    """Overlay viewer for comparing multiple molecules simultaneously."""

    def __init__(
        self,
        data: Union[Atoms, List[Atoms], Dict[str, Any], str, List],
        index_list=None,
        theme: str = None,
        **kwargs,
    ):
        """
        Initialize the overlay viewer with one or more molecules.

        Args:
            data: Can be a single Atoms object, a list of Atoms objects,
                  or any format supported by BaseViewer
            index_list: Controls which atoms to include in the overlay.
                - None          → "all"     : use all atoms from every structure
                - list          → "same"    : apply the same indices to every structure
                                  e.g. [0, 1, 2]
                - list[list]    → "indices" : apply different indices per structure
                                  e.g. [[0, 1], [2, 3], [0, 2]]
            **kwargs: Additional settings for visualization
        """
        self._theme = theme
        super().__init__(data)

        # Ensure data is always a list for overlay viewer
        if not isinstance(self.data, list):
            self.data = [self.data]

        # Apply atom index filtering
        if index_list is not None:
            self.data = self._apply_index_list(self.data, index_list)

        self.settings = {
            "bondThreshold": 1.2,  # Scale factor for covalent radii sum
            "bondThickness": 0.1,
            "atomSize": 0.4,
            "backgroundColor": "#1f2937",
            "style": "cartoon",
            "showCell": True,
            "showBond": True,
            "hideHydrogens": False,
            "showBlur": False,
            "blurStrength": 1.5,
            "showShadow": False,
            "viewMode": "Perspective",
            "rotationMode": "TrackBall",
            "colorBy": "Atom",
            "performanceMode": "auto",  # "auto", "high", or "normal"
            **kwargs,
        }

    @staticmethod
    def _filter_structure(structure: Dict[str, Any], indices: List[int]) -> Dict[str, Any]:
        """Return a copy of *structure* keeping only the atoms at *indices*."""
        filtered = {}
        per_atom_keys = {"symbols", "positions", "forces", "charges"}
        for key, value in structure.items():
            if key in per_atom_keys and isinstance(value, list):
                filtered[key] = [value[i] for i in indices]
            else:
                filtered[key] = value
        return filtered

    def _apply_index_list(
        self, structures: List[Dict[str, Any]], index_list
    ) -> List[Dict[str, Any]]:
        """Filter *structures* according to *index_list*.

        Mode detection (automatic, based on index_list type):
          - list[int]        → "same"    – identical indices applied to every structure
          - list[list[int]]  → "indices" – per-structure index lists
        """
        if not index_list:
            return structures

        # Determine mode from the type of the first element
        if isinstance(index_list[0], (list, tuple)):
            # "indices" mode – one sub-list per structure
            if len(index_list) != len(structures):
                raise ValueError(
                    f"index_list has {len(index_list)} entries but there are "
                    f"{len(structures)} structures. Lengths must match for "
                    f"per-structure index selection."
                )
            return [
                self._filter_structure(s, idxs)
                for s, idxs in zip(structures, index_list)
            ]
        else:
            # "same" mode – same indices for every structure
            return [self._filter_structure(s, index_list) for s in structures]

    def _generate_html(self) -> str:
        """Generate the HTML content for the overlay viewer."""
        js_data = self._get_js_data()

        # Load overlay_viewer template
        try:
            template_path = _resolve_template("overlay_viewer.html", self._theme)
            with open(template_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return self._generate_simple_html("Overlay Viewer")

        # Inline JavaScript dependencies
        vendor_dir = os.path.join(os.path.dirname(__file__), "static", "js", "vendor")

        # Inline Three.js
        three_path = os.path.join(vendor_dir, "three.min.js")
        if os.path.exists(three_path):
            with open(three_path, "r", encoding="utf-8") as f:
                three_js = f.read()
            html = html.replace(
                '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>',
                f"<script>{three_js}</script>",
            )

        # Inline OrbitControls
        orbit_path = os.path.join(vendor_dir, "OrbitControls.js")
        if os.path.exists(orbit_path):
            with open(orbit_path, "r", encoding="utf-8") as f:
                orbit_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js"></script>',
                f"<script>{orbit_js}</script>",
            )

        # Inline TrackballControls
        trackball_path = os.path.join(vendor_dir, "TrackballControls.js")
        if os.path.exists(trackball_path):
            with open(trackball_path, "r", encoding="utf-8") as f:
                trackball_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/TrackballControls.js"></script>',
                f"<script>{trackball_js}</script>",
            )

        # Inline styles.js
        html = _inline_styles_js(html)

        # Inject molecular data and settings
        settings_json = json.dumps(self.settings)
        script = f"""
<script>
    (function() {{
        var MAX_RETRIES = 100;
        var retryCount = 0;
        var pythonSettings = {settings_json};

        function initData() {{
            function trySetData() {{
                retryCount++;
                if (typeof renderer !== 'undefined' && renderer !== null) {{
                    // Apply Python settings to the settings object
                    if (typeof settings === 'undefined') {{
                        window.settings = {{}};
                    }}
                    Object.assign(settings, pythonSettings);
                    // Sync UI elements to reflect the applied Python settings
                    if (typeof updateFromSettings === 'function') {{
                        updateFromSettings();
                    }}
                    if (typeof setMolecularData === 'function') {{
                        setMolecularData({js_data});
                    }}
                }} else if (retryCount < MAX_RETRIES) {{
                    setTimeout(trySetData, 50);
                }}
            }}

            trySetData();
        }}

        if (document.readyState === 'loading') {{
            document.addEventListener('DOMContentLoaded', initData);
        }} else {{
            initData();
        }}
    }})();
</script>
</body>
"""
        return html.replace("</body>", script)

    def _generate_simple_html(self, title: str) -> str:
        """Generate a simple HTML fallback."""
        num_molecules = len(self.data) if isinstance(self.data, list) else 1
        return f"""
<!DOCTYPE html>
<html>
<head>
    <title>{title}</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: Arial, sans-serif; background: #111827; color: #f9fafb;
                display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }}
        .container {{ text-align: center; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        <p>Loaded {num_molecules} molecule(s) for overlay comparison</p>
    </div>
</body>
</html>
"""


class FragSelector(BaseViewer):
    """
    Interactive fragment selector with synchronized 2D (SVG) and 3D (THREE.js) views.

    Click atoms in either panel to toggle selection.
    Selected / unselected atom indices are shown in the sidebar and can be copied
    to the clipboard.

    Parameters
    ----------
    data : Atoms or str
        A single ASE Atoms object or a path to a structure file.
        Only the first frame is used if a multi-frame file is given.
    bondThreshold : float
        Scale factor applied to the sum of covalent radii for bond detection (default 1.2).
    atomSize : float
        Relative atom sphere size (default 0.4).
    style : str
        3-D rendering style: 'cartoon', 'glossy', 'default', 'bubble', 'metallic', 'cinematic' (default 'cartoon').
    showBond : bool
        Whether to draw bonds (default True).
    showShading : bool
        Enable directional shading on atom spheres (default True).
    backgroundColor : str
        Hex colour string for the 3-D panel background (default '#1f2937').
    """

    def __init__(self, data: Union[Atoms, Dict[str, Any], str, List], theme: str = None, **kwargs):
        self._theme = theme
        super().__init__(data)
        # Keep only the first frame
        if isinstance(self.data, list):
            self.data = self.data[0] if self.data else {}

        self.settings = {
            "bondThreshold": 1.2,
            "atomSize":      0.4,
            "style":         "cartoon",
            "showBond":      True,
            "hideHydrogens": False,
            "showBlur":      False,
            "blurStrength":  1.5,
            "showShading":   True,
            "backgroundColor": "#1f2937",
            **kwargs,
        }

    def _get_js_data(self) -> str:
        """Return a single-element JSON array for the template."""
        data = self.data
        if isinstance(data, list):
            data = data[0] if data else {}
        return json.dumps([data])

    def _generate_html(self) -> str:
        js_data       = self._get_js_data()
        settings_json = json.dumps(self.settings)

        # ── Load template ──────────────────────────────────────────────────
        try:
            template_path = _resolve_template("frag_selector.html", self._theme)
            with open(template_path, "r", encoding="utf-8") as f:
                html = f.read()
        except FileNotFoundError:
            return "<html><body><p>FragSelector template not found.</p></body></html>"

        # ── Inline vendor JS (same pattern as MolecularViewer) ─────────────
        vendor_dir = os.path.join(os.path.dirname(__file__), "static", "js", "vendor")

        three_path = os.path.join(vendor_dir, "three.min.js")
        if os.path.exists(three_path):
            with open(three_path, "r", encoding="utf-8") as f:
                three_js = f.read()
            html = html.replace(
                '<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>',
                f"<script>{three_js}</script>",
            )

        orbit_path = os.path.join(vendor_dir, "OrbitControls.js")
        if os.path.exists(orbit_path):
            with open(orbit_path, "r", encoding="utf-8") as f:
                orbit_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/OrbitControls.js"></script>',
                f"<script>{orbit_js}</script>",
            )

        trackball_path = os.path.join(vendor_dir, "TrackballControls.js")
        if os.path.exists(trackball_path):
            with open(trackball_path, "r", encoding="utf-8") as f:
                trackball_js = f.read()
            html = html.replace(
                '<script src="https://unpkg.com/three@0.128.0/examples/js/controls/TrackballControls.js"></script>',
                f"<script>{trackball_js}</script>",
            )

        html = _inline_styles_js(html)

        # ── Inject molecular data and settings ────────────────────────────
        html = html.replace("{{molecular_data}}", js_data)
        html = html.replace("{{settings}}", settings_json)

        return html
