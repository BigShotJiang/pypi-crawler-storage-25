"""Alembic migration environment for Agent Drop.

The SQLAlchemy URL is pulled from :class:`agentdrop.config.Settings` at runtime
so that the DB URL is single-sourced via pydantic-settings rather than
duplicated in ``alembic.ini``. Importing :mod:`agentdrop.models` populates
``Base.metadata`` for autogenerate.

``render_as_batch=True`` is enabled so future migrations that ALTER columns
work on SQLite (which doesn't support ALTER natively and needs the
copy-table-then-rename workaround).
"""

from __future__ import annotations

from logging.config import fileConfig

from sqlalchemy import engine_from_config, pool

import agentdrop.models  # noqa: F401  (populates Base.metadata for autogenerate)
from agentdrop.config import get_settings
from agentdrop.db.base import Base
from alembic import context

# Alembic Config object, provides access to values within the .ini file.
config = context.config

# Interpret the config file for Python logging.
if config.config_file_name is not None:
    fileConfig(config.config_file_name)

# Resolve the SQLAlchemy URL from Settings at runtime. We look the method up
# dynamically so that scaffolding can be written before the parallel DB agent
# finishes adding effective_database_url(); by integration time it must exist.
_settings = get_settings()
_url_getter = getattr(_settings, "effective_database_url", None)
if _url_getter is None:
    raise RuntimeError(
        "Settings.effective_database_url() is missing; the DB agent has not "
        "landed yet. Alembic cannot determine the database URL."
    )
config.set_main_option("sqlalchemy.url", _url_getter())

target_metadata = Base.metadata


# FTS5 virtual tables and their shadow tables (``drops_fts``,
# ``drops_fts_data``, ``drops_fts_idx``, ``drops_fts_content``,
# ``drops_fts_docsize``, ``drops_fts_config``) are created by raw DDL
# inside the FTS migration, not declared on ``Base.metadata``. Without
# this filter, ``compare_type``-driven autogenerate / ``alembic check``
# would propose dropping them on every run.
_FTS_TABLE_NAMES = frozenset(
    {
        "drops_fts",
        "drops_fts_data",
        "drops_fts_idx",
        "drops_fts_content",
        "drops_fts_docsize",
        "drops_fts_config",
    }
)


def _include_object(object_, name, type_, reflected, compare_to):  # type: ignore[no-untyped-def]
    """Skip FTS5 virtual + shadow tables during autogenerate compares."""
    return not (type_ == "table" and name in _FTS_TABLE_NAMES)


def run_migrations_offline() -> None:
    """Run migrations in 'offline' mode (emits SQL, no DBAPI needed)."""
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        render_as_batch=True,
        compare_server_default=True,
        compare_type=True,
        include_object=_include_object,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    """Run migrations in 'online' mode against a live database connection."""
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            render_as_batch=True,
            compare_server_default=True,
            compare_type=True,
            include_object=_include_object,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
