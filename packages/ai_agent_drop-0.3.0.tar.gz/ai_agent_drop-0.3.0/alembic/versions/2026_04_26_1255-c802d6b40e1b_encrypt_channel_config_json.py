"""encrypt channel config_json

Revision ID: c802d6b40e1b
Revises: 8ba4a3445348
Create Date: 2026-04-26 12:55:00.000000

Re-encrypts every existing ``channels.config_json`` row with the configured
Fernet key (issue #17, phase 2A). The column was previously plain JSON
text; from this migration onward it stores a Fernet token wrapping the
canonicalised JSON, matching :class:`agentdrop.db.encrypted_types.EncryptedJSON`.

Idempotent: rows whose value already starts with the Fernet ``gAAAAA``
prefix are skipped, so a partial run can be safely retried. NULL or
empty rows are skipped too.

Column type is altered from ``JSON`` to ``String`` for cleanliness; on
SQLite both map to TEXT so this is metadata-only there. ``render_as_batch``
in ``alembic/env.py`` lets this work on SQLite via the copy-and-rename
dance.

The migration imports :mod:`agentdrop.crypto.secrets`, which reads
``AGENTDROP_ENCRYPTION_KEY`` from the environment. If the key is unset
this migration fails loudly — that is the correct behaviour: encrypting
without a key would silently lock data away forever.
"""

from __future__ import annotations

import json
from collections.abc import Sequence

import sqlalchemy as sa

from agentdrop.crypto.secrets import decrypt, encrypt
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "c802d6b40e1b"
down_revision: str | Sequence[str] | None = "8ba4a3445348"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


# Fernet tokens are url-safe base64 starting with the version byte 0x80
# which encodes to ``gAAAAA``. Used to detect already-encrypted rows so
# the migration is safe to re-run after a partial failure.
_FERNET_PREFIX = "gAAAAA"


def upgrade() -> None:
    """Encrypt every ``channels.config_json`` row in place."""
    bind = op.get_bind()
    rows = bind.execute(sa.text("SELECT id, config_json FROM channels")).fetchall()

    n = 0
    for row_id, raw in rows:
        if raw is None:
            continue
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode("utf-8")
        if not isinstance(raw, str):
            # SQLite's JSON storage returns TEXT, but if a future driver
            # decoded to dict we still want to round-trip cleanly.
            raw = json.dumps(raw, separators=(",", ":"), sort_keys=True)
        if raw == "":
            continue
        if raw.startswith(_FERNET_PREFIX):
            # Already encrypted (idempotent re-run).
            continue
        parsed = json.loads(raw)
        canonical = json.dumps(parsed, separators=(",", ":"), sort_keys=True)
        cipher = encrypt(canonical)
        bind.execute(
            sa.text("UPDATE channels SET config_json = :v WHERE id = :id"),
            {"v": cipher, "id": row_id},
        )
        n += 1

    # Tighten the column type. On SQLite both JSON and String are TEXT so
    # this is a no-op at the storage layer; on Postgres it changes the
    # column to TEXT (matching EncryptedJSON's ``impl = String``).
    with op.batch_alter_table("channels") as batch_op:
        batch_op.alter_column(
            "config_json",
            existing_type=sa.JSON(),
            type_=sa.String(),
            existing_nullable=False,
        )

    print(f"Encrypted {n} channel rows")


def downgrade() -> None:
    """Decrypt every ``channels.config_json`` row back to plaintext JSON."""
    bind = op.get_bind()
    rows = bind.execute(sa.text("SELECT id, config_json FROM channels")).fetchall()

    n = 0
    for row_id, raw in rows:
        if raw is None:
            continue
        if isinstance(raw, (bytes, bytearray)):
            raw = raw.decode("utf-8")
        if not isinstance(raw, str) or raw == "":
            continue
        if not raw.startswith(_FERNET_PREFIX):
            # Already plaintext (idempotent reverse).
            continue
        plaintext = decrypt(raw)
        # Re-canonicalise so the on-disk form is stable JSON.
        parsed = json.loads(plaintext)
        canonical = json.dumps(parsed, separators=(",", ":"), sort_keys=True)
        bind.execute(
            sa.text("UPDATE channels SET config_json = :v WHERE id = :id"),
            {"v": canonical, "id": row_id},
        )
        n += 1

    with op.batch_alter_table("channels") as batch_op:
        batch_op.alter_column(
            "config_json",
            existing_type=sa.String(),
            type_=sa.JSON(),
            existing_nullable=False,
        )

    print(f"Decrypted {n} channel rows")
