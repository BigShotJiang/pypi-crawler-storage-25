"""add drops fts5 index

Revision ID: 8ba4a3445348
Revises: 63706b51734b
Create Date: 2026-04-21 20:38:55.983417

Adds a SQLite FTS5 virtual table ``drops_fts`` covering the searchable
columns on ``drops`` (title, body, content_md, source, tags) so the inbox
``?q=`` search can range over full content, not just title + source.

FTS5 is a SQLite-only feature; on Postgres this migration is a no-op and
the search code falls back to a broadened LIKE. A proper PG-native search
(tsvector / GIN) lands as a follow-up — tracked in ``ROADMAP.md`` under
"Known tech debt".

The actual DDL lives in :mod:`agentdrop.db.fts` so the test suite (which
uses ``Base.metadata.create_all`` instead of Alembic) can install the same
schema.
"""

from collections.abc import Sequence

from agentdrop.db.fts import (
    BACKFILL,
    CREATE_FTS_TABLE,
    CREATE_TRIGGER_DELETE,
    CREATE_TRIGGER_INSERT,
    CREATE_TRIGGER_UPDATE,
    DROP_FTS_TABLE,
    DROP_TRIGGER_DELETE,
    DROP_TRIGGER_INSERT,
    DROP_TRIGGER_UPDATE,
)
from alembic import op

# revision identifiers, used by Alembic.
revision: str = "8ba4a3445348"
down_revision: str | Sequence[str] | None = "63706b51734b"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Upgrade schema."""
    bind = op.get_bind()
    if bind.dialect.name != "sqlite":
        # FTS5 is SQLite-only. Postgres uses the LIKE fallback in
        # agentdrop.search until a PG-native search lands.
        return

    op.execute(CREATE_FTS_TABLE)
    op.execute(CREATE_TRIGGER_INSERT)
    op.execute(CREATE_TRIGGER_UPDATE)
    op.execute(CREATE_TRIGGER_DELETE)
    # Seed the FTS table with existing live (non-soft-deleted) rows.
    op.execute(BACKFILL)


def downgrade() -> None:
    """Downgrade schema."""
    bind = op.get_bind()
    if bind.dialect.name != "sqlite":
        return

    op.execute(DROP_TRIGGER_DELETE)
    op.execute(DROP_TRIGGER_UPDATE)
    op.execute(DROP_TRIGGER_INSERT)
    op.execute(DROP_FTS_TABLE)
