"""add drops source indexes

Revision ID: 1a4d9c2f8e10
Revises: c802d6b40e1b
Create Date: 2026-04-26 14:30:00.000000

Adds two indexes on the ``drops`` table that back the hot read paths:

* ``ix_drops_source`` — ``WHERE source = ?`` used by the routing resolver
  and the per-source sidebar facets.
* ``ix_drops_source_priority`` — ``WHERE source = ? AND priority = ?``
  used by the inbox source-filter and the routing-rule lookup that takes
  both columns into account.

Without these, the inbox and resolver fall back to a full table scan
once drops accumulate. See issue #14 (G1).

Both Postgres and SQLite (3.9+) support ``CREATE INDEX IF NOT EXISTS``,
so the migration is safe to re-run after a partial failure.
"""

from collections.abc import Sequence

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "1a4d9c2f8e10"
down_revision: str | Sequence[str] | None = "c802d6b40e1b"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    """Add source / (source, priority) indexes."""
    op.create_index(
        "ix_drops_source",
        "drops",
        ["source"],
        unique=False,
        if_not_exists=True,
    )
    op.create_index(
        "ix_drops_source_priority",
        "drops",
        ["source", "priority"],
        unique=False,
        if_not_exists=True,
    )


def downgrade() -> None:
    """Drop the indexes added by :func:`upgrade`."""
    op.drop_index("ix_drops_source_priority", table_name="drops", if_exists=True)
    op.drop_index("ix_drops_source", table_name="drops", if_exists=True)
