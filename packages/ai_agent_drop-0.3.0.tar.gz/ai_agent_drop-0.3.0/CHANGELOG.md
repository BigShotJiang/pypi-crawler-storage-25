# Changelog

All notable changes to Agent Drop are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-04-26

Operational maturity sweep: structured logging, CI hardening, alembic guards,
deployment docs (#16).

### Added

- GHCR publishing workflow (`.github/workflows/docker-publish.yml`) — every
  push to `main` produces `:edge` and `:sha-<short>`, and every `v*.*.*` tag
  produces `:latest`, `:vX.Y.Z`, `:X.Y.Z`, and `:X.Y` images at
  `ghcr.io/jay-uk/agent-drop`. Build provenance and SBOM attestations ride
  alongside the image.
- `docs/QUICKSTART.md` — step-by-step first-time setup walkthrough aimed at
  users new to self-hosted agent tooling. Sits alongside `docs/DEPLOYMENT.md`
  (operational runbook) and the README's terse five-minute path.

### Changed

- Published GHCR image is `linux/amd64` only; ARM64 remains supported for
  local dev (`make docker-up` / `make docker-build`). The published image
  name moved from `ghcr.io/jamescadman/agentdrop` (placeholder, never
  published) to `ghcr.io/jay-uk/agent-drop` to match the actual repo owner.

## [0.2.0] - 2026-04-24

### Added

- Web Push (PWA) delivery driver as the recommended default channel — `web_push`
  fans out to every device subscribed via the installed PWA, no third-party app
  required (#5, #6, #8).
- PWA shell: Web App Manifest, service worker, generated icon set (192/512/180-
  apple/maskable). Add-to-home-screen on iOS 16.4+ and Android Chrome (#5).
- VAPID configuration via `AGENTDROP_VAPID_PUBLIC_KEY` / `_PRIVATE_KEY` /
  `_SUBJECT`; `make vapid-keys` generates a keypair (#6).
- `Settings → Devices` page for managing PWA push subscriptions, including
  one-click enable / disable / test-fire on the current device (#8).
- MCP server (`agentdrop-mcp`) exposing `create_drop` and `list_recent_drops`
  as native tools for Claude Desktop and Claude Code (#7).
- Routing rules: map `(source, priority)` pairs onto specific channels at
  `Settings → Routing`; most-specific rule wins (#7).
- Full-text search over drops via SQLite FTS5 (Porter stemmer, diacritic
  folding) — `?q=` on the inbox API and search box in the UI (#7).
- Cloudflare Access service-token support in the CLI / MCP server
  (`AGENTDROP_CF_ACCESS_CLIENT_ID` / `_SECRET`) for zero-trust deployments
  (#4).
- Product screenshots embedded in the README (#10).

### Changed

- Notification channels are managed exclusively through `Settings → Channels`;
  the env-var path for provider credentials has been removed (#9).
- README rewritten as a features catalogue with a linear first-time-setup
  walkthrough (#10).
- PyPI distribution renamed to `ai-agent-drop` (the `agentdrop` and
  `agentdrop-mcp` console scripts are unchanged) (#3).

### Fixed

- VAPID public-key double-decode that caused every push to 400 from Apple
  Push services (#9).

## [0.1.0] - 2026-04-20

Initial public release.

### Added

- Ingestion API: `POST /api/v1/drops` with bearer auth; required `title` +
  `body` + `content` fields; optional `source`, `tags`, `priority`,
  `external_url`, `expires_in_days`, `channel` (#1).
- Public rendered drop pages at `/d/{short_id}` — unguessable short ids,
  unauthenticated by default for tap-from-notification reading (#1).
- Markdown rendering via `markdown-it-py` with GFM, task lists, footnotes,
  admonitions, syntax-highlighted code, and client-side Mermaid (#1).
- Notification drivers: Pushover and ntfy (hosted or self-hosted) shipped at
  MVP; Apprise and generic JSON webhook added in v1 (#1, #2).
- Inbox UI at `/` with desktop and mobile layouts, source filters, pin /
  archive / mark-read actions, retention sweep (soft-delete at 30d, hard-
  delete at 90d) (#2).
- Settings UI behind admin-session auth: channels, API keys with per-agent
  labels and `last_used_at`, login at `/login` with
  `AGENTDROP_ADMIN_PASSWORD` (#2).
- `agentdrop` CLI distributed on PyPI: `drop`, `list`, `config`, `version`
  subcommands; config at `~/.config/agentdrop/config.toml` mode `0600` (#2).
- Single Docker image (linux/amd64 + linux/arm64) on GHCR; `docker compose
  up` boots SQLite-backed default deployment.

[Unreleased]: https://github.com/Jay-uk/agent-drop/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/Jay-uk/agent-drop/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/Jay-uk/agent-drop/releases/tag/v0.1.0
