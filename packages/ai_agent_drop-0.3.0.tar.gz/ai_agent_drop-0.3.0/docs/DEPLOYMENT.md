# Deployment

Operational runbook for self-hosting Agent Drop. The README walks through the
five-minute happy path; this file covers the things you only need once but
must get right — backup, restore, upgrade, migration, recovery.

## Overview

Agent Drop ships as a single Docker image on GHCR
(`ghcr.io/jay-uk/agent-drop`, linux/amd64). It runs a
FastAPI app backed by SQLite (WAL mode) by default, with PostgreSQL available
via `AGENTDROP_DATABASE_URL`. Notifications go out through one or more of:
`web_push` (PWA, recommended default), Pushover, ntfy, Apprise (~80
back-ends), or a generic JSON webhook. Channel credentials are encrypted at
rest with Fernet, keyed off `AGENTDROP_ENCRYPTION_KEY`.

## First-time setup

```sh
git clone https://github.com/Jay-uk/agent-drop.git
cd agent-drop
cp .env.example .env
```

Fill in `.env`. The must-set variables are listed under
[Environment variables](#environment-variables) below; `.env.example` is the
exhaustive reference.

Generate a VAPID keypair for Web Push and paste the three printed lines into
`.env`:

```sh
make vapid-keys
```

Bring the stack up:

```sh
docker compose up -d
```

Verify the health probe and register a device as a PWA:

```sh
curl -sS http://localhost:8080/health
# {"status":"ok","version":"..."}
```

Open `AGENTDROP_BASE_URL` in Safari (iOS 16.4+) or Chrome (Android), add to
home screen, launch the installed app, log in with `AGENTDROP_ADMIN_PASSWORD`,
then go to **Settings → Devices** and click **Enable on this device**.

## Backup

The default deployment writes a SQLite database in WAL mode to `./data/`
(bind-mounted to `/data` in the container). WAL splits state across three
files; a backup that copies only `agentdrop.db` will silently lose any commits
still in the write-ahead log. **Copy all three:**

```
data/agentdrop.db
data/agentdrop.db-wal
data/agentdrop.db-shm
```

A safe-live-copy procedure (no app downtime, copies are crash-consistent
because SQLite's WAL design tolerates a snapshot of all three files):

```sh
#!/usr/bin/env bash
set -euo pipefail
ts=$(date -u +%Y%m%dT%H%M%SZ)
dest="/var/backups/agentdrop/${ts}"
mkdir -p "${dest}"
cp /srv/agent-drop/data/agentdrop.db      "${dest}/"
cp /srv/agent-drop/data/agentdrop.db-wal  "${dest}/" 2>/dev/null || true
cp /srv/agent-drop/data/agentdrop.db-shm  "${dest}/" 2>/dev/null || true
tar -C /var/backups/agentdrop -czf "${dest}.tar.gz" "${ts}"
rm -rf "${dest}"
```

Cron example (hourly, with seven-day retention by mtime):

```cron
17 * * * * /usr/local/bin/agentdrop-backup.sh >> /var/log/agentdrop-backup.log 2>&1
@daily find /var/backups/agentdrop -name '*.tar.gz' -mtime +7 -delete
```

`AGENTDROP_ENCRYPTION_KEY` must be backed up **separately** from the
database. See [Encryption at rest](#encryption-at-rest) — a backup of the
encrypted DB co-located with its key is equivalent to a plaintext backup.

## Restore

```sh
docker compose down
rm -f /srv/agent-drop/data/agentdrop.db /srv/agent-drop/data/agentdrop.db-wal /srv/agent-drop/data/agentdrop.db-shm
tar -C /tmp -xzf /var/backups/agentdrop/20260426T031700Z.tar.gz
cp /tmp/20260426T031700Z/agentdrop.db*  /srv/agent-drop/data/
docker compose up -d
curl -sS http://localhost:8080/health
```

Then sanity-check by loading a known-good drop URL in the browser; if the
inbox renders and a recent drop opens, the restore is good.

## Upgrade path

1. Read [`CHANGELOG.md`](../CHANGELOG.md) for the version you're moving to —
   look for **Changed** entries and any operator notes.
2. Pin the new image tag in `compose.yaml` (or rely on `latest` if you accept
   the surprise budget).
3. Pull and roll:

   ```sh
   docker compose pull
   docker compose up -d
   docker compose logs -f agentdrop
   ```

4. Watch for the migration line in the logs (alembic prints
   `Running upgrade <rev> -> <rev>` per step) and confirm the app reaches the
   `Application startup complete.` line.
5. Check `/health` returns `200 OK`.

Rollback is `docker compose pull` of the previous image tag and a restart —
GHCR tags are immutable, so the previous `:vX.Y.Z` is still there. If a
migration applied successfully you may also need to restore the DB backup
taken just before the upgrade; see
[Recovering from a bad migration](#recovering-from-a-bad-migration).

## Migrating SQLite to Postgres

There is no `pg_dump`/`pg_restore` path — those tools are Postgres-to-Postgres
only. The intended flow is to let alembic build the empty Postgres schema,
then copy the row data across:

1. Stand up a Postgres instance (psql 14+ recommended) and create an empty
   database. The `psycopg[binary]` driver is bundled in the image; the
   connection URL form is
   `postgresql+psycopg://user:pass@host:5432/agentdrop`.
2. Take a fresh SQLite backup (see [Backup](#backup)) and stop the app.
3. Point the app at the new database and let alembic build the schema:

   ```sh
   AGENTDROP_DATABASE_URL=postgresql+psycopg://agentdrop:...@db:5432/agentdrop \
     docker compose run --rm agentdrop alembic upgrade head
   ```

4. Copy the row data. Rough sketch — adapt for your row volumes and table
   list:

   ```sh
   sqlite3 data/agentdrop.db .dump > /tmp/dump.sql
   # Hand-edit out CREATE TABLE / CREATE INDEX statements; keep INSERTs.
   # Or use a small Python script with SQLAlchemy that streams rows from the
   # SQLite engine into the Postgres engine, table by table, in dependency
   # order (api_keys, drops, channels, routes, push_subscriptions, ...).
   psql "$AGENTDROP_DATABASE_URL" < /tmp/dump.sql.cleaned
   ```

5. Update `.env` with the Postgres URL and bring the app up under it.

### FTS5 caveat

Full-text search is implemented with SQLite's FTS5 virtual table. Postgres
deployments fall back to LIKE-based search until a `tsvector`/GIN
implementation lands (tracked in [`ROADMAP.md`](../ROADMAP.md)). Queries still
work; ranking is cruder and large inboxes will be slower.

## Recovering from a bad migration

If a migration leaves the schema in a state the app refuses to boot under:

1. Stop the container:

   ```sh
   docker compose down
   ```

2. Restore the most recent DB backup taken **before** the upgrade (see
   [Restore](#restore)).
3. Pin the previous image tag in `compose.yaml` and bring the app back up
   — restoring the DB without rolling back the image will replay the bad
   migration on the next start.
4. If you need to keep the new image and walk one revision back instead of
   restoring the backup, run:

   ```sh
   docker compose run --rm agentdrop alembic downgrade -1
   ```

   This only works if the offending migration provides a `downgrade()` body
   that's actually correct — not all do. Restore-from-backup is the safer
   default.
5. File an issue with the alembic log line, the previous and new image tags,
   and (if it's safe to share) the schema diff.

## Logs and observability

Production logs are JSON Lines: one event per line, one structured event per
log call. Every request log carries a `request_id`; per-domain events
additionally carry `drop_id`, `driver`, `channel_id`, etc., where they apply.
The same `request_id` is echoed on the response as `X-Request-ID` so client
and server logs can be stitched together.

Pipe the container's stdout into a JSON-aware viewer rather than `grep`:

```sh
docker compose logs -f agentdrop | jq -r 'select(.level == "ERROR")'
```

For longer-term storage, ship the JSON stream into Loki / Vector / your log
backend of choice. There's no separate metrics endpoint yet — `/health` is
the only liveness signal.

## Troubleshooting

- **`/pwa/subscribe` returns 503.** The `web_push` driver isn't configured —
  either the VAPID env vars are missing / partial, or the channel was deleted
  from `Settings → Channels`. Check startup logs for `VAPID` warnings; the
  app refuses to start if VAPID is partially configured.
- **`/health` returns 500.** Almost always a migration failure. Check
  `docker compose logs agentdrop` for the alembic traceback; see
  [Recovering from a bad migration](#recovering-from-a-bad-migration).
- **Notifications are silent.** Hit **Send test push** on the channel in
  `Settings → Channels`. If the test fires from the UI but real drops don't
  notify, check `Settings → Routing` — a routing rule may be steering this
  drop's `(source, priority)` to a different channel. If the test itself
  fails, the driver credentials are wrong; re-enter and save (the form
  re-validates on save).
- **Push works on Android, silent on iOS.** The PWA must be launched from the
  home-screen icon, not a Safari tab — iOS 16.4+ requirement, not an Agent
  Drop one. Re-add to home screen and re-subscribe.

## Environment variables

[`.env.example`](../.env.example) is the canonical reference and explains
every variable in context. Must-set on first deploy:

| Variable | Purpose |
| --- | --- |
| `AGENTDROP_API_KEY` | Bootstrap bearer token for `POST /api/v1/drops`. |
| `AGENTDROP_ADMIN_PASSWORD` | Password for the Settings UI; app refuses to start without it. |
| `AGENTDROP_BASE_URL` | Public URL baked into push payloads — wrong value means tap-throughs go nowhere. |
| `AGENTDROP_SECRET_KEY` | Stable session-cookie signing key; if unset, every restart logs admins out. |
| `AGENTDROP_ENCRYPTION_KEY` | Fernet key encrypting `channels.config_json`; required once any channel exists. |
| `AGENTDROP_VAPID_PUBLIC_KEY` | Web Push server identity (public half). Generate with `make vapid-keys`. |
| `AGENTDROP_VAPID_PRIVATE_KEY` | Web Push server identity (private half). Treat as a credential. |
| `AGENTDROP_VAPID_SUBJECT` | `mailto:` or `https:` contact URI advertised to push services. |
| `AGENTDROP_DATABASE_URL` | Optional. Set when using Postgres instead of the default SQLite. |

## Postgres notes

- **Driver.** The image bundles `psycopg[binary]`. Connection URLs use the
  `postgresql+psycopg://` scheme. There is no async driver in the supported
  set today; the app's request handlers run sync against the connection pool.
- **Pool sizing.** Default SQLAlchemy pool is fine for a single-node
  Agent Drop install. If you've front-ended with multiple uvicorn workers,
  size `pool_size + max_overflow` such that
  `workers * (pool_size + max_overflow)` stays below your Postgres
  `max_connections` minus headroom for backups / psql sessions.
- **FTS5.** Search falls back to LIKE on Postgres until proper
  `tsvector`/GIN support lands — see
  [Migrating SQLite to Postgres](#migrating-sqlite-to-postgres).
- **Enabling Postgres.** Set `AGENTDROP_DATABASE_URL` in `.env`, ensure the
  database exists and the role can `CREATE`, then `docker compose up -d`.
  Alembic creates every table on first boot.

## Encryption at rest

Channel configs hold raw provider tokens — Pushover application/user keys,
ntfy access tokens, Apprise URLs (which often embed credentials), and the
bearer / basic-auth secrets used by the generic `webhook` driver. Those are
encrypted at rest via the `EncryptedJSON` SQLAlchemy type, keyed off
`AGENTDROP_ENCRYPTION_KEY`.

### What's encrypted, what isn't

- **Encrypted:** `channels.config_json` — every secret a notification driver
  needs to call out to its provider.
- **Not encrypted (and that's intentional):**
  - `api_keys.key_hash` — SHA-256 of the bearer token. Already irreversible;
    encryption would add nothing.
  - Web Push subscription keys (`p256dh`, `auth`) — supplied by the user's
    browser and only useful in combination with the device that produced
    them. Out of scope.
  - VAPID keys — live in env vars, never written to the DB.
  - Drop content (`title`, `body`, `content_md`) — not a secret store; see
    PRD §5.

If you've added a column that holds a third-party credential, it belongs in
`EncryptedJSON`, not a plain `JSON` / `Text`. Open an issue first if you're
not sure.

### Generating a key

The key is 32 random bytes, base64url-encoded:

```bash
python -c "import secrets, base64; print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"
```

Store the output in your secrets manager and set it as
`AGENTDROP_ENCRYPTION_KEY` in the environment the app runs under
(`compose.yaml`, your shell, systemd unit, etc. — `.env.example` shows the
shape).

### First-run setup

Set `AGENTDROP_ENCRYPTION_KEY` **before you configure any channels**. The
app refuses to start if the `channels` table has rows but no key is
configured (Phase 2B startup guard), which prevents you from silently
locking yourself out by removing the env var later. If you set the key
after creating channels in plaintext on an older build, you'll need to
delete and re-create those channels via the Settings UI on the new build.

### Backups

> **Backing up the SQLite database without backing up
> `AGENTDROP_ENCRYPTION_KEY` separately produces an unrecoverable backup.**
> Backing up the key into the same archive / same bucket / same disk
> snapshot as the database is equivalent to taking a plaintext backup —
> anyone with the snapshot can decrypt every channel secret.

Concretely:

- Keep the key in a password manager, a sealed-secret slot (Vault,
  Bitwarden, 1Password, SOPS-encrypted file with a separate KMS key,
  etc.), or your platform's secret store.
- The DB backup can live wherever it normally lives (object storage,
  borg, `litestream`, etc.) — just not co-located with the key.
- Test recovery occasionally: spin up a fresh container, set the
  retrieved key, point it at a copy of the DB, and confirm a "test fire"
  on each channel still succeeds.

### Key rotation

`agentdrop crypto rotate` (Phase 2B CLI) re-encrypts every row in
`channels` from the previous key to the current one. The flow:

1. Generate a new key (see above).
2. Set the **new** key as `AGENTDROP_ENCRYPTION_KEY` and the **old** key
   as `AGENTDROP_ENCRYPTION_KEY_PREV`.
3. Restart the app. With both keys present, decryption tries the current
   key first and falls back to `_PREV`, so nothing breaks while rows are
   still encrypted under the old key.
4. Run `agentdrop crypto rotate`. This reads each row under whichever
   key works and writes it back encrypted under the current key.
5. Unset `AGENTDROP_ENCRYPTION_KEY_PREV` and restart. The old key is no
   longer needed; destroy it according to your secret-management policy.

If the rotate command exits non-zero, do **not** unset `_PREV` — at least
one row is still encrypted under the old key, and removing it will brick
that channel.

### What if I lose the key?

Channel configs are unrecoverable. There is no master key, no escrow, no
"forgot password" path — that's the whole point of encrypting them.

Recovery procedure:

1. Generate a fresh `AGENTDROP_ENCRYPTION_KEY` and start the app with it.
2. The startup guard will refuse to boot because rows exist that can't be
   decrypted. Delete the affected `channels` rows directly in SQLite (or
   wipe the table — you're going to re-add them anyway).
3. Restart. Re-add each channel via **Settings → Channels** with the
   tokens from the upstream provider (Pushover dashboard, ntfy account,
   etc.).

Drops, API keys, retention state, and Web Push subscriptions are
unaffected by losing the encryption key — only `channels.config_json`
is.
