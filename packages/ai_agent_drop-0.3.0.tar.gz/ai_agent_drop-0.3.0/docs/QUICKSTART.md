# Quickstart — your first AI agent notification

This is a step-by-step setup for **first-time users**. The aim:

> "I want my AI agent to be able to send me a notification on my phone, and have me tap it to read what it wrote."

If you already self-host services and read `docker compose` files for fun, the
[README](../README.md) has the same walkthrough in five minutes and
[`DEPLOYMENT.md`](./DEPLOYMENT.md) is the operations runbook. This doc is the
hand-holding version.

Estimated time: **20–30 minutes**, most of it waiting for downloads.

---

## What you'll end up with

- Agent Drop running in Docker on a computer you control.
- Your phone subscribed so notifications land directly on it.
- One AI agent (we'll use Claude Desktop, but anything that can make an HTTP
  request works) able to send you a drop with a tap-to-read URL.

## Before you start — what you need

| Thing | Why | Get it |
| --- | --- | --- |
| **A computer that stays on** | Where Agent Drop runs. A laptop is fine for testing, but for real use a desktop / NAS / mini PC / cloud VM is better. | — |
| **Docker Desktop** | The container runtime that runs Agent Drop. Free for personal use. | [docker.com/products/docker-desktop](https://www.docker.com/products/docker-desktop/) |
| **A phone** | iPhone on iOS 16.4 or newer, or any reasonably modern Android. | — |
| **A text editor** | Anything: Notepad, TextEdit, VS Code, nano. We'll edit one short config file. | — |

### Step 0 — Install Docker Desktop and start it

1. Download Docker Desktop from the link above for your OS.
2. Run the installer. On macOS that means dragging it into Applications; on
   Windows the installer reboots your machine. Accept the defaults.
3. Open Docker Desktop. Wait until the whale icon in your menu bar / system
   tray stops animating.
4. Open a terminal (macOS: **Terminal.app**; Windows: **PowerShell**;
   Linux: any) and check it works:

   ```sh
   docker --version
   ```

   You should see something like `Docker version 27.x`.

If `docker` isn't found, Docker Desktop isn't running yet, or its CLI tools
aren't on your PATH. On macOS, opening Docker Desktop once usually fixes that.

---

## Step 1 — Make a folder for Agent Drop

Pick somewhere you don't mind a folder living long-term — these files persist
your inbox database and your secrets.

```sh
mkdir agent-drop
cd agent-drop
mkdir data
```

The `data/` subfolder is where the SQLite database lives. Don't delete it.

## Step 2 — Generate three secrets

Agent Drop needs three random values that act as keys / passwords. Generate
each one with this command (run it three times, save each output):

```sh
docker run --rm --entrypoint python ghcr.io/jay-uk/agent-drop:latest \
  -c "import secrets; print(secrets.token_urlsafe(48))"
```

The first time you run that, Docker pulls the image — it might take a minute
or two. Subsequent runs are instant.

Save the three outputs labelled like this (a password manager is ideal):

| Label | Value |
| --- | --- |
| `AGENTDROP_API_KEY` | (output 1) |
| `AGENTDROP_ADMIN_PASSWORD` | (output 2 — or pick a passphrase you'll remember) |
| `AGENTDROP_SECRET_KEY` | (output 3) |

These do different things:
- `AGENTDROP_API_KEY` — the bearer token your agents will use to send drops.
- `AGENTDROP_ADMIN_PASSWORD` — what you'll type to log into the Settings UI.
- `AGENTDROP_SECRET_KEY` — keeps your login session valid across restarts.

## Step 3 — Generate VAPID keys (for push notifications)

VAPID keys identify *your* Agent Drop server to the push services that
deliver notifications to phones. Without them, the page-rendering still
works but no notifications fire — so we'll set them up now.

```sh
docker run --rm --entrypoint python ghcr.io/jay-uk/agent-drop:latest \
  /app/scripts/gen_vapid_keys.py
```

Three lines come back, each starting with `AGENTDROP_VAPID_`. Keep all three;
we'll paste them into the config file in the next step.

> Don't regenerate these later just for fun. Every phone that subscribes is
> tied to your current public key, and changing it forces every device to
> re-subscribe.

## Step 4 — Create the configuration file

In your `agent-drop/` folder, create a file called **`.env`** with this
content, replacing the bracketed `<...>` values with the secrets and VAPID
lines you just generated:

```sh
# Required
AGENTDROP_BASE_URL=http://localhost:8080
AGENTDROP_API_KEY=<your AGENTDROP_API_KEY>
AGENTDROP_ADMIN_PASSWORD=<your AGENTDROP_ADMIN_PASSWORD>
AGENTDROP_SECRET_KEY=<your AGENTDROP_SECRET_KEY>

# Required for local-HTTP testing on http://localhost (not for production).
AGENTDROP_INSECURE_COOKIES=1

# Web Push — paste the three lines from Step 3 here.
AGENTDROP_VAPID_PUBLIC_KEY=<line 1 from Step 3>
AGENTDROP_VAPID_PRIVATE_KEY=<line 2 from Step 3>
AGENTDROP_VAPID_SUBJECT=mailto:you@example.com
```

Replace `you@example.com` with your own email — push services use it to
contact you if the server starts misbehaving. It doesn't get shown publicly.

> If the file isn't appearing in your file browser, that's because the
> leading dot makes it hidden. On macOS press `Cmd-Shift-.` in Finder to
> show hidden files. From the terminal you can always edit it with
> `nano .env` or `code .env`.

## Step 5 — Create the compose file

In the same folder, create **`compose.yaml`** (no leading dot this time):

```yaml
services:
  agentdrop:
    image: ghcr.io/jay-uk/agent-drop:latest
    container_name: agentdrop
    ports:
      - "127.0.0.1:8080:8080"
    volumes:
      - ./data:/data
    env_file:
      - .env
    restart: unless-stopped
```

This says: pull the published image, run it on port 8080 (only reachable
from this computer for now), persist the database to `./data/`, and read
secrets from `.env`.

## Step 6 — Start it

```sh
docker compose up -d
```

`-d` runs it in the background. The first run pulls the image and creates
the database. Check it's healthy:

```sh
curl http://localhost:8080/health
```

Expected reply (your version may differ):

```json
{"status":"ok","version":"0.2.0"}
```

If it's not responding yet, wait 5 seconds and try again — the first start
runs database migrations.

To watch the logs:

```sh
docker compose logs -f agentdrop
```

(`Ctrl-C` exits the log view; the container keeps running.)

To stop it:

```sh
docker compose down
```

## Step 7 — Open it in your browser and log in

In your computer's browser, go to **<http://localhost:8080>**.

You'll see a login screen. Username doesn't matter — paste your
`AGENTDROP_ADMIN_PASSWORD` and submit. You should land on the inbox
(empty for now).

## Step 8 — Subscribe your phone

This is the part that lights up notifications. Two pieces:

### A. Reach the server from your phone

`http://localhost:8080` only works from your computer. Your phone needs
to reach the server somehow. The simplest option for testing:

1. Find your computer's local IP. On macOS / Linux:

   ```sh
   ipconfig getifaddr en0   # macOS Wi-Fi; try en1 for Ethernet
   # or: ifconfig | grep 'inet '
   ```

   On Windows PowerShell:

   ```powershell
   ipconfig | Select-String IPv4
   ```

   You'll get something like `192.168.1.42`.

2. Update `AGENTDROP_BASE_URL` in your `.env` to that IP, e.g.:

   ```sh
   AGENTDROP_BASE_URL=http://192.168.1.42:8080
   ```

3. Change `compose.yaml` so the port is reachable on your network — replace
   `127.0.0.1:8080:8080` with `8080:8080`:

   ```yaml
       ports:
         - "8080:8080"
   ```

4. Restart:

   ```sh
   docker compose up -d
   ```

5. Make sure your phone is on the **same Wi-Fi** as the computer.

> This is fine for testing. For a real always-on setup, see
> [Step 11 — Reaching it from outside](#step-11--reaching-it-from-outside-your-network)
> at the end of this guide.

### B. Add to home screen and subscribe

On your phone:

- **iPhone (iOS 16.4+):** open Safari → go to your `AGENTDROP_BASE_URL` →
  tap the **Share** button → **Add to Home Screen**. *Important:* you must
  launch Agent Drop from the home-screen icon, not from a Safari tab — Apple
  only allows push notifications from installed PWAs.
- **Android:** open in Chrome → menu (⋮) → **Install app** (sometimes
  labelled "Add to Home screen").

Now launch Agent Drop from the home-screen icon. Log in with your admin
password. Then:

1. Tap the menu → **Settings** → **Devices**.
2. Tap **Enable on this device**.
3. The browser will ask for notification permission — grant it.
4. Tap **Send test push**. A real notification should land on your phone.

Tap the test notification: it should open Agent Drop straight to a drop page.
That's the loop end-to-end.

> **iPhone troubleshooting:** if the notification doesn't arrive, you almost
> certainly opened Agent Drop in a Safari tab instead of the installed PWA.
> Re-launch it from the home-screen icon and re-subscribe.

## Step 9 — Send your first drop from the command line

Back on your computer, send a drop with `curl` (or the equivalent in
PowerShell — see below). Use the `AGENTDROP_API_KEY` and `AGENTDROP_BASE_URL`
from your `.env`:

```sh
curl -X POST "$AGENTDROP_BASE_URL/api/v1/drops" \
  -H "Authorization: Bearer $AGENTDROP_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Hello from Agent Drop",
    "body":  "Tap to open the rendered page.",
    "content": "## First drop\n\nIf you are reading this on your phone after tapping a notification, everything works."
  }'
```

A second or two later, a notification should land on your phone. Tap it —
you should see a rendered drop page with the markdown laid out nicely.

PowerShell version (Windows):

```powershell
$body = @{
  title = "Hello from Agent Drop"
  body  = "Tap to open the rendered page."
  content = "## First drop`n`nIf you are reading this on your phone after tapping a notification, everything works."
} | ConvertTo-Json

Invoke-RestMethod -Method Post `
  -Uri "$env:AGENTDROP_BASE_URL/api/v1/drops" `
  -Headers @{ Authorization = "Bearer $env:AGENTDROP_API_KEY"; "Content-Type" = "application/json" } `
  -Body $body
```

(Set `$env:AGENTDROP_BASE_URL` and `$env:AGENTDROP_API_KEY` first.)

## Step 10 — Wire it up to an AI agent

Anything that can make an HTTP `POST` works. The two easiest paths:

### Option A: Claude Desktop (no scripting needed)

Agent Drop ships an MCP server that registers as a native Claude Desktop
tool, so Claude can call `create_drop` directly when you ask it to.

1. Install [Python 3.12+](https://www.python.org/downloads/) and
   [`pipx`](https://pipx.pypa.io/stable/installation/) if you don't already
   have them.
2. Install the Agent Drop CLI (it bundles the MCP server):

   ```sh
   pipx install ai-agent-drop
   ```

3. Open Claude Desktop's config file:
   - **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
   - **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

   Add the `agentdrop` MCP server (replace the URL and key with the same
   values from your `.env`):

   ```json
   {
     "mcpServers": {
       "agentdrop": {
         "command": "agentdrop-mcp",
         "env": {
           "AGENTDROP_BASE_URL": "http://192.168.1.42:8080",
           "AGENTDROP_API_KEY": "<your AGENTDROP_API_KEY>"
         }
       }
     }
   }
   ```

4. Quit Claude Desktop fully and reopen it. The `agentdrop` tool should now
   show up in Claude's tool picker.
5. In a Claude conversation, try:

   > "Drop me a summary of today's news. Title: 'Today in AI', body: '3 things'."

   Claude will call `create_drop`. Your phone buzzes a moment later.

### Option B: A shell script / cron / scheduled task

Use the same `curl` recipe from Step 9 inside a script. Anywhere you can
run a shell command on a schedule (cron, launchd, Windows Task Scheduler,
GitHub Actions, n8n, …) is a place that can fire drops.

A single-purpose example: send yourself a drop every weekday morning with
a one-line summary of yesterday's commits.

```sh
#!/usr/bin/env bash
set -euo pipefail
summary=$(git -C ~/projects/myrepo log --since=yesterday --pretty='- %s')
curl -sS -X POST "$AGENTDROP_BASE_URL/api/v1/drops" \
  -H "Authorization: Bearer $AGENTDROP_API_KEY" \
  -H "Content-Type: application/json" \
  -d "$(jq -n --arg s "$summary" '{title:"Yesterday in code", body:"Commits", content:$s}')"
```

---

## Step 11 — Reaching it from outside your network

Once the basics work, you'll want Agent Drop reachable when you're not at
home. There are three common patterns; pick whichever you're most
comfortable with:

- **[Tailscale](https://tailscale.com/)** — easiest for personal use. Install
  on your computer and your phone; your phone can reach `localhost`-style
  hostnames over the tailnet. No public exposure.
- **[Cloudflare Tunnel](https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/)**
  — good if you want a real public URL like `drop.example.com`. Combine with
  Cloudflare Access for sign-in.
- **A reverse proxy** (Caddy, nginx) on a VPS — most control, most setup.

When you switch, update `AGENTDROP_BASE_URL` in `.env` to the new public
hostname (e.g. `https://drop.example.com`), remove
`AGENTDROP_INSECURE_COOKIES=1` (you'll have HTTPS now), revert the
`compose.yaml` ports binding back to `127.0.0.1:8080:8080` if the proxy is
on the same machine, and restart with `docker compose up -d`.

> The push notifications you've already enabled will keep working — the
> `AGENTDROP_BASE_URL` change only affects the URL baked into *new* drops.

## Where to go next

- **Add more notification channels.** Settings → Channels lets you fan out
  to Pushover, ntfy, Discord (via Apprise), email, and ~80 other services.
  Useful if some drops should also email you, or if you want phone +
  watch + Discord.
- **Mint per-agent API keys.** Settings → API keys lets you create
  revocable keys per integration. The bootstrap `AGENTDROP_API_KEY` is
  fine for testing; for real use, give each agent its own.
- **Routing rules.** Settings → Routing lets you say things like "send
  `urgent`-priority drops via Pushover, send everything else via Web Push."
- **Read [`DEPLOYMENT.md`](./DEPLOYMENT.md).** Once it's actually doing
  useful work for you, you'll care about backups, upgrades, and recovery.

## Common problems

- **`docker: command not found`** — Docker Desktop isn't running, or its
  CLI tools aren't on your PATH yet. Open Docker Desktop, wait for the whale
  icon to settle, then try again.
- **`/health` returns nothing / connection refused** — the container hasn't
  started yet. `docker compose logs agentdrop` will show the error if there
  is one. Most often it's a missing required env var (e.g.
  `AGENTDROP_ADMIN_PASSWORD` empty).
- **Login keeps failing** — make sure `AGENTDROP_INSECURE_COOKIES=1` is in
  `.env` while you're using `http://` (not `https://`). Without it, browsers
  silently refuse to set the session cookie.
- **Notifications work on Android but not iPhone** — you launched from a
  Safari tab, not the home-screen icon. iOS only delivers Web Push to
  installed PWAs. Re-add to home screen and re-subscribe at
  Settings → Devices.
- **"No channel configured" warning on a drop** — your VAPID lines are
  missing or partial in `.env`, so the auto-provisioned Web Push channel
  didn't get created. Fix `.env`, `docker compose up -d`, then go to
  Settings → Channels and verify a `web_push` channel exists.
