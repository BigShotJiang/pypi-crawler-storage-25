# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project status

**Pre-build.** The repo currently contains only a product spec and a design handoff — no application code exists yet. First implementation work will create the source tree.

- `PRD.md` — product spec (v0.1 draft). Source of truth for scope, API shape, data model, non-goals, and milestones.
- `design_handoff_agent_drop/` — high-fidelity design reference (see below).

When asked to "build X", check `PRD.md` §8–11 (functional reqs, data model, API surface) before inventing anything.

## Product in one line

Agent Drop is a self-hostable app that takes an HTTP POST from an LLM agent, stores it as a rendered markdown page at a short URL, and fires a push notification to the user with a tappable link. It's the "look at this now" surface that sits alongside Obsidian/Notion/etc. — not a replacement for them.

See `PRD.md` §5 for explicit non-goals (not a knowledge store, not a chat app, not multi-tenant SaaS, not a notification service itself).

## Planned tech stack (from PRD §12)

- **Python 3.12 + FastAPI**, server-rendered Jinja2 templates, HTMX for interactivity. No SPA, no bundler.
- **SQLite** (WAL mode) by default; PostgreSQL optional via env var.
- **Markdown**: `markdown-it-py` with GFM plugins + client-side Mermaid.
- **Notifications**: Apprise library as the workhorse, with first-class Pushover/ntfy wrappers that expose provider-specific features.
- **Deploy target**: single Docker image published to GHCR, `docker compose up`.

Deviations from this stack need a reason — flipping to Go, adding a frontend framework, or swapping the DB all cost something the PRD deliberately avoided.

## Non-obvious constraints

- **`title` and `body` are schema-required on every drop.** This is the core product constraint (PRD §8.1) — it forces agents to think about what the notification says, not just what the content is. Don't relax this in the ingestion schema.
- **Public drop URLs are unguessable but unauthed by default.** The whole point is tap-from-notification reading on a phone. Auth is an opt-in per-drop flag, not the default.
- **Three drop-page variants exist in the design** (Reading / Editorial / Terminal). Product direction hasn't picked one yet — see `design_handoff_agent_drop/README.md` "Open questions for the team". Implement whichever the current task specifies; don't assume.
- **Retention is near-ephemeral by design.** Default 30d soft-delete, 90d hard-delete. Don't build features that assume drops stick around forever.
- **All markdown links in drops are rendered but click-prevented.** External navigation goes through the drop's `external_url` field and the dedicated "Open original" card, not inline links. See handoff README, Markdown renderer `a` styling.

## Design system

Colors are **OKLCH** (not hex). Full token table and type scale in `design_handoff_agent_drop/README.md` under "Design Tokens". Key points:

- Aesthetic: warm off-white paper (`oklch(0.985 0.008 75)`), not pure white. No gradients, no AI-sparkle iconography, no emoji.
- Type mix: Instrument Serif italic (display), Inter Tight (UI/body), JetBrains Mono (metadata, source ids, timestamps).
- "Whimsy" is a 0–10 scalar that gates hand-drawn SVG decorations (hand-circle around "N new", pen-underlines, brush marks on urgent priority). Thresholds listed in the handoff README. Default is 6.
- The `sage` color appears in **one place only** — checked task-list checkboxes. Don't repurpose it.

## The `prototype/` directory is not production code

`design_handoff_agent_drop/prototype/*.jsx` and `Agent Drop.html` are JSX-in-browser (Babel standalone) references for look, layout, and behaviour. Recreate the designs in the target environment (once chosen) using its idiomatic patterns — do not copy these files into the app. The markdown parser in `markdown.jsx` is explicitly expendable; its **styles** are what matter.

Open `prototype/Agent Drop.html` in a browser to view the reference canvas (pan/zoom, Figma-style, with a Tweaks panel bottom-right for variant/density/whimsy toggles).

## Commands

None yet — no build, test, or lint tooling is configured. When setting up the Python project for the first time, follow PRD §12's stack and add the corresponding entries here (uv/poetry install, pytest, ruff, docker build, etc.).
