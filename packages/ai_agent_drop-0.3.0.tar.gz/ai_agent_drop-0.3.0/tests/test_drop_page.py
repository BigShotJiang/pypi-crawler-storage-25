"""Tests for the public unauthenticated ``GET /d/{short_id}`` drop page.

These exercise the Reading-variant template end-to-end: 200-on-exists,
404-on-missing, 404-on-soft-deleted, markdown renders, tags render, the
external-link card conditionally appears, and the view auto-marks the drop
as read.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


def _make_drop(**overrides: object) -> Drop:
    """Persist a Drop with known values and return it.

    Uses a dedicated session (bound to the test engine via ``SessionLocal``'s
    ``bind`` override) so the row is committed before the TestClient request
    runs.
    """
    fields: dict[str, object] = {
        "short_id": "testshortid0000000000000",
        "title": "A drop about the weekly scan",
        "body": "Three notable items were flagged this week.",
        "content_md": (
            "# Hello reader\n\n"
            "This drop's body has a heading, a paragraph, and a list.\n\n"
            "- one\n- two\n- three\n"
        ),
        "source": "weekly-scan",
        "tags_json": ["earnings", "ops"],
        "priority": "normal",
    }
    fields.update(overrides)

    session = SessionLocal(bind=get_engine())
    try:
        drop = Drop(**fields)
        session.add(drop)
        session.commit()
        session.refresh(drop)
        # Detach so callers can read attrs after the session closes.
        session.expunge(drop)
        return drop
    finally:
        session.close()


def _reload_drop(short_id: str) -> Drop:
    session = SessionLocal(bind=get_engine())
    try:
        drop = session.query(Drop).filter(Drop.short_id == short_id).one()
        session.expunge(drop)
        return drop
    finally:
        session.close()


def test_drop_page_renders_200_html(client: TestClient) -> None:
    _make_drop()
    resp = client.get("/d/testshortid0000000000000")
    assert resp.status_code == 200, resp.text
    assert resp.headers["content-type"].startswith("text/html")

    html = resp.text
    # Reading body class is on <body>.
    assert 'class="drop-reading"' in html
    # Title appears (escaped / unescaped forms are both fine for this one).
    assert "A drop about the weekly scan" in html
    # Summary text (drop.body) appears.
    assert "Three notable items were flagged this week." in html
    # Rendered markdown contains the heading text.
    assert "Hello reader" in html
    assert "<h1" in html
    # A tag pill rendered.
    assert 'class="tag"' in html
    assert ">earnings<" in html


def test_drop_page_escapes_title_html(client: TestClient) -> None:
    _make_drop(
        short_id="escapedrop00000000000000",
        title="Tricky <script>alert(1)</script> title",
    )
    resp = client.get("/d/escapedrop00000000000000")
    assert resp.status_code == 200
    # The raw tag must not appear; Jinja autoescape should have turned it into
    # entity-escaped text.
    assert "<script>alert(1)</script>" not in resp.text
    assert "&lt;script&gt;" in resp.text


def test_drop_page_escapes_title_in_title_tag_context(client: TestClient) -> None:
    """XSS regression for issue #15 I1.

    ``<title>`` is a special HTML context: a literal ``</title>`` byte
    sequence inside the element's text content closes it early, after
    which any subsequent markup (including a fresh ``<script>``) is
    parsed as page content. Jinja's autoescape turns ``<`` into ``&lt;``
    so this can't happen — but ``<title>`` is special enough that we
    pin the behaviour with an explicit test.
    """
    payload = "</title><script>alert(1)</script>"
    _make_drop(
        short_id="titleescape00000000aaaa1",
        title=payload,
    )
    resp = client.get("/d/titleescape00000000aaaa1")
    assert resp.status_code == 200
    body = resp.text

    # Pull out the <title>...</title> region and assert nothing escaped
    # from it. Use a forgiving regex: the <title> tag stays a single
    # element, no attributes added by the template.
    import re

    match = re.search(r"<title>(.*?)</title>", body, re.DOTALL)
    assert match is not None, "no <title>...</title> in response body"
    title_inner = match.group(1)

    # Inside <title>, there must be no literal closing tag escape and
    # no script element start — the dangerous bytes have to be entity-
    # escaped to preserve the title context.
    assert "</title>" not in title_inner
    assert "<script>" not in title_inner

    # And the literal payload (verbatim) must not appear anywhere in the
    # response — neither in <title> nor in the article body.
    assert payload not in body

    # Positive assertion: the escaped form is what Jinja produced.
    assert "&lt;/title&gt;" in body
    assert "&lt;script&gt;" in body


def test_drop_page_external_card_present_when_url_set(client: TestClient) -> None:
    _make_drop(
        short_id="external000000000000aaaa",
        external_url="https://example.com/orig",
    )
    resp = client.get("/d/external000000000000aaaa")
    assert resp.status_code == 200
    assert "external-card" in resp.text
    assert "https://example.com/orig" in resp.text
    assert "Open original" in resp.text


def test_drop_page_external_card_absent_when_no_url(client: TestClient) -> None:
    _make_drop(short_id="noexternal00000000000000", external_url=None)
    resp = client.get("/d/noexternal00000000000000")
    assert resp.status_code == 200
    assert "external-card" not in resp.text
    assert "Open original" not in resp.text


def test_drop_page_404_for_unknown_short_id(client: TestClient) -> None:
    resp = client.get("/d/does-not-exist----------")
    assert resp.status_code == 404


def test_drop_page_404_for_soft_deleted(client: TestClient) -> None:
    _make_drop(
        short_id="softdeleted00000000000000",
        soft_deleted_at=datetime.now(UTC),
    )
    resp = client.get("/d/softdeleted00000000000000")
    assert resp.status_code == 404


def test_drop_page_view_auto_marks_unread_as_read(client: TestClient) -> None:
    _make_drop(short_id="autoread000000000000aaaa")
    # read_at starts null
    before = _reload_drop("autoread000000000000aaaa")
    assert before.read_at is None

    resp = client.get("/d/autoread000000000000aaaa")
    assert resp.status_code == 200

    after = _reload_drop("autoread000000000000aaaa")
    assert after.read_at is not None


def test_drop_page_is_unauthenticated(client: TestClient) -> None:
    """No ``Authorization`` header — still 200."""
    _make_drop(short_id="noauth000000000000000000")
    resp = client.get("/d/noauth000000000000000000")
    assert resp.status_code == 200


def test_drop_page_returns_429_when_rate_limit_exceeded(
    client: TestClient,
) -> None:
    """Per-IP rate limit on /d/{short_id} returns 429 + Retry-After."""
    from agentdrop.web import rate_limit as rl

    _make_drop(short_id="ratelimit00000000000xxxx")

    bucket_key = "testclient"
    limit = get_settings().drop_read_rate_limit_per_min
    for _ in range(limit):
        rl.record_attempt("drop_get", bucket_key)

    resp = client.get("/d/ratelimit00000000000xxxx")
    assert resp.status_code == 429
    assert "retry-after" in {h.lower() for h in resp.headers}
    retry_after = int(resp.headers["retry-after"])
    assert 1 <= retry_after <= 60


def test_drop_page_renders_recent_notification_failures(
    client: TestClient,
) -> None:
    """Notification_failed events for the drop appear in a diagnostics block.

    Regression for issue #14 E2: failures are recorded as events and
    surfaced on the drop page so the operator who taps the link can see
    why the push didn't fire.
    """
    from agentdrop.models import Event

    _make_drop(short_id="evtshow0000000000000aaaa")

    session = SessionLocal(bind=get_engine())
    try:
        drop = session.query(Drop).filter(Drop.short_id == "evtshow0000000000000aaaa").one()
        session.add(
            Event(
                drop_id=drop.id,
                kind="notification_failed",
                detail_json={
                    "driver": "ntfy",
                    "error_class": "DriverDeliveryError",
                    "message": "ntfy: HTTP 503 from upstream: temporary",
                },
            )
        )
        session.commit()
    finally:
        session.close()

    resp = client.get("/d/evtshow0000000000000aaaa")
    assert resp.status_code == 200
    body = resp.text
    assert "Notification didn't deliver" in body
    assert "ntfy" in body
    assert "DriverDeliveryError" in body
    assert "HTTP 503" in body


def test_drop_page_omits_failures_block_when_no_events(
    client: TestClient,
) -> None:
    """No notification_failed events -> no diagnostics block rendered."""
    _make_drop(short_id="noevents00000000000000aa")
    resp = client.get("/d/noevents00000000000000aa")
    assert resp.status_code == 200
    assert "Notification didn't deliver" not in resp.text
