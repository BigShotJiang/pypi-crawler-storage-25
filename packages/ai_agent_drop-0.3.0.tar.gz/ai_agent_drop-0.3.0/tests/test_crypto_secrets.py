"""Tests for the at-rest encryption helper (issue #17 foundation)."""

from __future__ import annotations

import base64
import secrets

import pytest
from cryptography.fernet import Fernet

from agentdrop.config import get_settings
from agentdrop.crypto import secrets as crypto_secrets
from agentdrop.crypto.secrets import (
    DecryptionFailed,
    EncryptionKeyMissing,
    decrypt,
    encrypt,
    is_key_configured,
)


def _gen_key() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()


@pytest.fixture(autouse=True)
def _clear_settings_cache(monkeypatch: pytest.MonkeyPatch):
    """Each test sets its own env; clear the cached Settings before & after."""
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def test_round_trip(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    cipher = encrypt("hunter2")
    assert cipher != "hunter2"
    assert decrypt(cipher) == "hunter2"


def test_round_trip_unicode(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    payload = '{"token": "süp£r-secret-🔑"}'
    assert decrypt(encrypt(payload)) == payload


def test_encrypt_without_key_raises():
    with pytest.raises(EncryptionKeyMissing):
        encrypt("anything")


def test_decrypt_without_key_raises():
    with pytest.raises(EncryptionKeyMissing):
        decrypt("gAAAAAB...")


def test_invalid_key_format_raises(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", "not-a-valid-fernet-key")
    get_settings.cache_clear()
    with pytest.raises(EncryptionKeyMissing):
        encrypt("anything")


def test_malformed_ciphertext_raises(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    with pytest.raises(DecryptionFailed):
        decrypt("not-a-real-token")


def test_decrypt_with_wrong_key_raises(monkeypatch: pytest.MonkeyPatch):
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    cipher = encrypt("hunter2")

    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    with pytest.raises(DecryptionFailed):
        decrypt(cipher)


def test_prev_key_decrypts_old_ciphertext(monkeypatch: pytest.MonkeyPatch):
    """Rotation flow: write with old key, then move it to _PREV and add a new
    key — old ciphertext must still decrypt via the fallback slot."""
    old_key = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", old_key)
    get_settings.cache_clear()
    cipher = encrypt("hunter2")

    new_key = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", new_key)
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", old_key)
    get_settings.cache_clear()
    assert decrypt(cipher) == "hunter2"


def test_new_writes_use_current_key_not_prev(monkeypatch: pytest.MonkeyPatch):
    """Writes go through the *first* key. After rotation completes (operator
    drops _PREV), old _PREV-only ciphertext would no longer decrypt — but new
    encrypts must already use the new key, otherwise rotation never finishes.
    """
    old_key = _gen_key()
    new_key = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", new_key)
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", old_key)
    get_settings.cache_clear()

    cipher = encrypt("fresh-write")

    # Drop _PREV; the value must still decrypt because it was written with
    # the current key.
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()
    assert decrypt(cipher) == "fresh-write"


def test_is_key_configured(monkeypatch: pytest.MonkeyPatch):
    assert is_key_configured() is False
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()
    assert is_key_configured() is True


def test_uses_real_fernet(monkeypatch: pytest.MonkeyPatch):
    """Sanity check: a token from our ``encrypt`` is decryptable by a vanilla
    Fernet instance using the same key — i.e. we're not rolling our own."""
    key = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key)
    get_settings.cache_clear()
    cipher = crypto_secrets.encrypt("hello")
    assert Fernet(key.encode()).decrypt(cipher.encode()).decode() == "hello"
