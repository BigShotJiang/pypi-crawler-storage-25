"""Tests for the Jinja2 base template + design-token CSS foundation."""

from fastapi.testclient import TestClient

from agentdrop.web import templates


def test_tokens_css_served(client: TestClient) -> None:
    response = client.get("/static/tokens.css")
    assert response.status_code == 200
    # OKLCH paper value is the canonical design-handoff token — if this drifts
    # the whole aesthetic drifts with it.
    assert "--color-paper: oklch(0.985 0.008 75)" in response.text


def test_base_css_served(client: TestClient) -> None:
    response = client.get("/static/base.css")
    assert response.status_code == 200
    assert "font-family: var(--font-sans)" in response.text


def test_base_template_renders() -> None:
    template = templates.get_template("base.html")
    html = template.render()
    assert "<!doctype html>" in html
    assert 'lang="en"' in html
    assert "/static/tokens.css" in html
    assert "/static/base.css" in html


def test_static_files_carry_cache_control(client: TestClient) -> None:
    """Issue #15 I6: static assets must ship a ``Cache-Control`` header.

    Unhashed names get a one-hour cache; the immutable variant kicks in
    only when a content-hashed name is used (none in the repo today, so
    this asserts the default branch).
    """
    response = client.get("/static/tokens.css")
    assert response.status_code == 200
    cache_control = response.headers.get("cache-control", "")
    assert "max-age=3600" in cache_control
    assert "public" in cache_control
    # Without fingerprinting, the response must NOT be marked immutable —
    # otherwise edits to tokens.css would never reach returning users.
    assert "immutable" not in cache_control


def test_static_files_immutable_for_hashed_names() -> None:
    """Hashed-name detection: ``foo.abc1234.css`` -> immutable cache.

    Exercised at the unit-regex level rather than e2e because the repo
    doesn't yet ship hashed assets. Future build-step work that emits
    fingerprinted names should benefit immediately.
    """
    from agentdrop.web.static_files import _HASHED_NAME

    assert _HASHED_NAME.search("main.5f3a9b2e.js") is not None
    assert _HASHED_NAME.search("foo.[hash].css") is not None
    # Plain names + version-y names must NOT match (otherwise they'd be
    # cached for a year and break editing).
    assert _HASHED_NAME.search("tokens.css") is None
    assert _HASHED_NAME.search("foo.10.css") is None
