"""Tests for the ``agentdrop-mcp`` server.

The MCP Python SDK doesn't expose a public test client at 1.27, so we
drive the registered request handlers directly. The Server's
``call_tool`` decorator wraps the user handler with input-schema
validation, so exercising those wrappers gives us realistic coverage
of the tool surface without a stdio round-trip.
"""

from __future__ import annotations

import subprocess
import sys
from typing import Any

import pytest
from mcp import types

from agentdrop.mcp import server as mcp_server

# ---------------------------------------------------------------------------
# Fakes + helpers
# ---------------------------------------------------------------------------


class _FakeClient:
    """Captures calls made by the MCP tool handlers to a real CliClient."""

    def __init__(
        self,
        *,
        post_response: dict[str, Any] | None = None,
        list_response: dict[str, Any] | None = None,
        raise_on_post: Exception | None = None,
        raise_on_list: Exception | None = None,
    ) -> None:
        self.post_response = post_response or {
            "id": "drp_abc",
            "url": "https://drop.example.test/d/abcdef",
            "created_at": "2026-04-19T10:00:00Z",
            "warnings": [],
        }
        self.list_response = list_response or {
            "items": [{"id": "drp_abc", "title": "T"}],
            "count": 1,
            "next_cursor": None,
        }
        self.raise_on_post = raise_on_post
        self.raise_on_list = raise_on_list
        self.post_calls: list[dict[str, Any]] = []
        self.list_calls: list[dict[str, Any]] = []

    def post_drop(self, payload: dict[str, Any]) -> dict[str, Any]:
        self.post_calls.append(payload)
        if self.raise_on_post is not None:
            raise self.raise_on_post
        return self.post_response

    def list_drops(self, params: dict[str, Any]) -> dict[str, Any]:
        self.list_calls.append(params)
        if self.raise_on_list is not None:
            raise self.raise_on_list
        return self.list_response


def _install_fake_client(monkeypatch: pytest.MonkeyPatch, fake: _FakeClient) -> None:
    """Swap ``_get_client`` for one that returns ``fake``."""
    monkeypatch.setattr(mcp_server, "_get_client", lambda: fake)


async def _call_registered_tool(name: str, arguments: dict[str, Any]) -> types.CallToolResult:
    """Build the server, prime the tool cache, invoke ``tools/call``.

    Priming the cache (via ``list_tools``) is required because the SDK's
    input validator reads tool definitions from the in-memory cache that
    ``list_tools`` populates.
    """
    server = mcp_server.build_server()
    list_req = types.ListToolsRequest(method="tools/list", params=None)
    await server.request_handlers[types.ListToolsRequest](list_req)

    call_req = types.CallToolRequest(
        method="tools/call",
        params=types.CallToolRequestParams(name=name, arguments=arguments),
    )
    server_result = await server.request_handlers[types.CallToolRequest](call_req)
    # ``ServerResult`` is a RootModel wrapping the actual result type.
    inner = server_result.root
    assert isinstance(inner, types.CallToolResult)
    return inner


# ---------------------------------------------------------------------------
# create_drop
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_create_drop_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {
            "title": "Weekly scan",
            "body": "3 items flagged",
            "content": "# Report\n\nhello",
            "source": "weekly-scan",
            "tags": ["markets", "research"],
            "priority": "high",
            "external_url": "obsidian://open?vault=Work&file=Reports/2026-04-19",
            "channel": "priority-alerts",
        },
    )

    assert result.isError is False
    assert result.structuredContent == {
        "id": "drp_abc",
        "url": "https://drop.example.test/d/abcdef",
        "created_at": "2026-04-19T10:00:00Z",
    }
    assert len(fake.post_calls) == 1
    sent = fake.post_calls[0]
    assert sent["title"] == "Weekly scan"
    assert sent["body"] == "3 items flagged"
    assert sent["content"] == "# Report\n\nhello"
    assert sent["source"] == "weekly-scan"
    assert sent["tags"] == ["markets", "research"]
    assert sent["priority"] == "high"
    assert sent["external_url"].startswith("obsidian://")
    assert sent["channel"] == "priority-alerts"


@pytest.mark.asyncio
async def test_create_drop_minimal_fields(monkeypatch: pytest.MonkeyPatch) -> None:
    """Only required fields reach the server; optionals are omitted entirely."""
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"title": "t", "body": "b", "content": "c"},
    )
    assert result.isError is False
    sent = fake.post_calls[0]
    assert set(sent.keys()) == {"title", "body", "content"}


@pytest.mark.asyncio
async def test_create_drop_missing_title_is_schema_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"body": "b", "content": "c"},
    )
    assert result.isError is True
    # SDK validation emits "Input validation error: ..." messages.
    text = " ".join(block.text for block in result.content if isinstance(block, types.TextContent))
    assert "title" in text.lower()
    # The server must NOT have been hit.
    assert fake.post_calls == []


@pytest.mark.asyncio
async def test_create_drop_missing_body_is_schema_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"title": "t", "content": "c"},
    )
    assert result.isError is True
    assert fake.post_calls == []


@pytest.mark.asyncio
async def test_create_drop_missing_content_is_schema_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"title": "t", "body": "b"},
    )
    assert result.isError is True
    assert fake.post_calls == []


@pytest.mark.asyncio
async def test_create_drop_bogus_priority_is_schema_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"title": "t", "body": "b", "content": "c", "priority": "bogus"},
    )
    assert result.isError is True
    text = " ".join(block.text for block in result.content if isinstance(block, types.TextContent))
    assert "bogus" in text
    assert fake.post_calls == []


@pytest.mark.asyncio
async def test_create_drop_surfaces_server_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentdrop.cli.http import CliHttpError

    fake = _FakeClient(
        raise_on_post=CliHttpError("HTTP 422: title: field required", status_code=422)
    )
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool(
        "create_drop",
        {"title": "t", "body": "b", "content": "c"},
    )
    assert result.isError is True
    text = " ".join(block.text for block in result.content if isinstance(block, types.TextContent))
    # Server's message must flow through to the caller.
    assert "422" in text
    assert "field required" in text


# ---------------------------------------------------------------------------
# list_recent_drops
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_recent_drops_default_limit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool("list_recent_drops", {})
    assert result.isError is False
    assert fake.list_calls == [{"limit": 20, "state": "all"}]
    assert result.structuredContent is not None
    assert result.structuredContent["items"] == fake.list_response["items"]


@pytest.mark.asyncio
async def test_list_recent_drops_custom_limit(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool("list_recent_drops", {"limit": 5})
    assert result.isError is False
    assert fake.list_calls == [{"limit": 5, "state": "all"}]


@pytest.mark.asyncio
async def test_list_recent_drops_rejects_limit_over_max(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool("list_recent_drops", {"limit": 1000})
    assert result.isError is True
    assert fake.list_calls == []


@pytest.mark.asyncio
async def test_list_recent_drops_rejects_limit_zero(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake = _FakeClient()
    _install_fake_client(monkeypatch, fake)

    result = await _call_registered_tool("list_recent_drops", {"limit": 0})
    assert result.isError is True
    assert fake.list_calls == []


# ---------------------------------------------------------------------------
# Config resolution + env overlay
# ---------------------------------------------------------------------------


def test_env_overlay_env_wins_over_file(monkeypatch: pytest.MonkeyPatch) -> None:
    from agentdrop.cli.config_file import CliConfig

    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://from-env.test")
    monkeypatch.setenv("AGENTDROP_API_KEY", "agdr_from_env")
    monkeypatch.setenv("AGENTDROP_CF_ACCESS_CLIENT_ID", "cf-id-env")
    monkeypatch.setenv("AGENTDROP_CF_ACCESS_CLIENT_SECRET", "cf-secret-env")

    merged = mcp_server._env_overlay(
        CliConfig(
            base_url="https://from-file.test",
            api_key="agdr_from_file",
            cf_access_client_id="cf-id-file",
            cf_access_client_secret="cf-secret-file",
        )
    )
    assert merged.base_url == "https://from-env.test"
    assert merged.api_key == "agdr_from_env"
    assert merged.cf_access_client_id == "cf-id-env"
    assert merged.cf_access_client_secret == "cf-secret-env"


def test_env_overlay_file_wins_when_env_unset(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from agentdrop.cli.config_file import CliConfig

    for var in (
        "AGENTDROP_BASE_URL",
        "AGENTDROP_API_KEY",
        "AGENTDROP_CF_ACCESS_CLIENT_ID",
        "AGENTDROP_CF_ACCESS_CLIENT_SECRET",
    ):
        monkeypatch.delenv(var, raising=False)

    merged = mcp_server._env_overlay(CliConfig(base_url="https://file.test", api_key="agdr_file"))
    assert merged.base_url == "https://file.test"
    assert merged.api_key == "agdr_file"


# ---------------------------------------------------------------------------
# main() startup validation
# ---------------------------------------------------------------------------


def test_main_exits_when_config_missing(monkeypatch: pytest.MonkeyPatch, tmp_path: Any) -> None:
    """No config on disk + no env => non-zero exit + helpful stderr message."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    for var in (
        "AGENTDROP_BASE_URL",
        "AGENTDROP_API_KEY",
    ):
        monkeypatch.delenv(var, raising=False)

    # Run in a subprocess so the actual sys.exit in main() is observable
    # without unwinding the test runner. Using ``-m`` so we also exercise
    # the ``__main__`` entry point.
    result = subprocess.run(
        [sys.executable, "-m", "agentdrop.mcp"],
        capture_output=True,
        text=True,
        env={
            **{k: v for k, v in _safe_env().items()},
            "XDG_CONFIG_HOME": str(tmp_path),
        },
        timeout=10,
    )
    assert result.returncode != 0
    combined = result.stderr + result.stdout
    assert "missing config" in combined.lower() or "base_url" in combined.lower()


def _safe_env() -> dict[str, str]:
    """Return the current process env stripped of AGENTDROP_* overrides.

    The test harness can export AGENTDROP_* in CI for other tests; this
    strips those so the subprocess really does see "nothing configured".
    """
    import os

    return {k: v for k, v in os.environ.items() if not k.startswith("AGENTDROP_")}


def test_main_version_flag(monkeypatch: pytest.MonkeyPatch, tmp_path: Any) -> None:
    """--version short-circuits before config check and exits 0."""
    result = subprocess.run(
        [sys.executable, "-m", "agentdrop.mcp", "--version"],
        capture_output=True,
        text=True,
        env={
            **{k: v for k, v in _safe_env().items()},
            "XDG_CONFIG_HOME": str(tmp_path),
        },
        timeout=10,
    )
    assert result.returncode == 0
    assert "agentdrop-mcp" in result.stdout
