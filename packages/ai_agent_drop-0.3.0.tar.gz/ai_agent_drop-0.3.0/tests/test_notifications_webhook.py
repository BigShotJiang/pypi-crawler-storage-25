"""Tests for the generic webhook notification driver.

These use :class:`httpx.MockTransport` to intercept outbound HTTP calls,
patching ``WebhookDriver._client`` so the driver talks to a transport we
control. No real network is ever touched.

Tests also import ``agentdrop.notifications.webhook`` at collection time to
force the module's self-registration line to run, so the registry-lookup
test is self-contained and does not depend on the package ``__init__.py``
explicitly importing us.
"""

from __future__ import annotations

import base64
import json
from collections.abc import Callable
from typing import Any

import httpx
import pytest

# Importing ``webhook`` here is load-bearing: it triggers the self-register
# line at the bottom of the module, so ``get_driver("webhook", ...)`` works
# even if nobody has patched ``__init__.py`` yet.
import agentdrop.notifications.webhook as _webhook_mod  # noqa: F401
from agentdrop.notifications import get_driver
from agentdrop.notifications.base import (
    DriverConfigError,
    DriverDeliveryError,
)
from agentdrop.notifications.webhook import WebhookDriver


def _make_driver(
    config: dict[str, Any],
    handler: Callable[[httpx.Request], httpx.Response],
) -> WebhookDriver:
    """Build a driver whose internal client is backed by a mock transport."""
    driver = WebhookDriver(config)
    transport = httpx.MockTransport(handler)

    def _client() -> httpx.Client:
        return httpx.Client(transport=transport, timeout=10.0)

    driver._client = _client  # type: ignore[method-assign]
    return driver


def _ok(request: httpx.Request) -> httpx.Response:
    return httpx.Response(200, text="ok")


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


def test_missing_url_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver({})


def test_non_http_scheme_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver({"url": "ftp://nope.example/hook"})


def test_bearer_plus_basic_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver(
            {
                "url": "https://example.com/hook",
                "bearer": "abc",
                "basic_user": "u",
                "basic_pass": "p",
            }
        )


def test_invalid_method_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver({"url": "https://example.com/hook", "method": "DELETE"})


def test_invalid_payload_style_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver({"url": "https://example.com/hook", "payload_style": "carrier-pigeon"})


def test_basic_without_password_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        WebhookDriver({"url": "https://example.com/hook", "basic_user": "u"})


# ---------------------------------------------------------------------------
# Payload styles
# ---------------------------------------------------------------------------


def test_default_agentdrop_style_payload_shape() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["method"] = request.method
        captured["body"] = json.loads(request.content.decode("utf-8"))
        captured["headers"] = dict(request.headers)
        return _ok(request)

    driver = _make_driver(
        {"url": "https://example.com/hook"},
        handler,
    )
    long_md = "x" * 1000
    result = driver.send(
        title="Hello",
        body="hello world",
        url="https://drop.example/d/abc123",
        priority="high",
        extras={
            "content_md": long_md,
            "tags": ["alpha", "beta"],
            "source": "claude-code",
            "drop_id": "d_abc123",
            "created_at": "2026-04-19T12:00:00Z",
        },
    )

    assert result.ok is True
    assert result.driver == "webhook"
    assert captured["method"] == "POST"
    assert captured["url"] == "https://example.com/hook"

    body = captured["body"]
    assert body["title"] == "Hello"
    assert body["body"] == "hello world"
    assert body["url"] == "https://drop.example/d/abc123"
    assert body["priority"] == "high"
    assert body["source"] == "claude-code"
    assert body["drop_id"] == "d_abc123"
    assert body["created_at"] == "2026-04-19T12:00:00Z"
    assert body["tags"] == ["alpha", "beta"]
    assert "content_preview" in body
    assert len(body["content_preview"]) <= 500
    assert body["content_preview"] == "x" * 500

    assert captured["headers"]["content-type"].startswith("application/json")


def test_discord_style_packs_title_body_url_into_content() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode("utf-8"))
        return _ok(request)

    driver = _make_driver(
        {"url": "https://discord.example/webhooks/123/abc", "payload_style": "discord"},
        handler,
    )
    driver.send(
        title="Deploy done",
        body="green across the board",
        url="https://drop.example/d/xyz",
        priority="normal",
    )

    body = captured["body"]
    assert set(body.keys()) == {"content"}
    assert "Deploy done" in body["content"]
    assert "green across the board" in body["content"]
    assert "https://drop.example/d/xyz" in body["content"]


@pytest.mark.parametrize(
    ("priority", "expected_color"),
    [
        ("low", "#9ca3af"),
        ("normal", "#6b7280"),
        ("high", "#f59e0b"),
        ("urgent", "#dc2626"),
    ],
)
def test_slack_style_uses_priority_color(priority: str, expected_color: str) -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["body"] = json.loads(request.content.decode("utf-8"))
        return _ok(request)

    driver = _make_driver(
        {"url": "https://hooks.slack.com/services/T/B/X", "payload_style": "slack"},
        handler,
    )
    driver.send(
        title="Incident",
        body="db latency spiking",
        url="https://drop.example/d/inc",
        priority=priority,  # type: ignore[arg-type]
    )

    body = captured["body"]
    assert body["text"] == "Incident"
    assert isinstance(body["attachments"], list)
    assert len(body["attachments"]) == 1
    attachment = body["attachments"][0]
    assert attachment["color"] == expected_color
    assert "db latency spiking" in attachment["text"]
    assert "https://drop.example/d/inc" in attachment["text"]


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_bearer_header_is_applied() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok(request)

    driver = _make_driver(
        {"url": "https://example.com/hook", "bearer": "tok-123"},
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert captured["headers"]["authorization"] == "Bearer tok-123"


def test_basic_auth_header_encodes_correctly() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok(request)

    driver = _make_driver(
        {
            "url": "https://example.com/hook",
            "basic_user": "alice",
            "basic_pass": "s3cret",
        },
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    expected = base64.b64encode(b"alice:s3cret").decode("ascii")
    assert captured["headers"]["authorization"] == f"Basic {expected}"


def test_bearer_not_logged_on_failure() -> None:
    token = "super-secret-bearer-xyz"

    def handler(request: httpx.Request) -> httpx.Response:
        # Attacker-controlled server might echo the token in an error body;
        # make sure we scrub it before surfacing the exception.
        return httpx.Response(401, text=f"unauthorized: bearer {token} expired")

    driver = _make_driver(
        {"url": "https://example.com/hook", "bearer": token},
        handler,
    )
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    msg = str(excinfo.value)
    assert token not in msg
    assert "[redacted]" in msg
    assert "401" in msg


def test_basic_pass_not_logged_on_failure() -> None:
    password = "hunter2-very-secret"

    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, text=f"nope pw={password} bad")

    driver = _make_driver(
        {
            "url": "https://example.com/hook",
            "basic_user": "alice",
            "basic_pass": password,
        },
        handler,
    )
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    msg = str(excinfo.value)
    assert password not in msg
    assert "[redacted]" in msg


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


def test_4xx_raises_delivery_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(404, text="not found")

    driver = _make_driver({"url": "https://example.com/hook"}, handler)
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert "404" in str(excinfo.value)


def test_timeout_raises_delivery_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("simulated timeout", request=request)

    driver = _make_driver({"url": "https://example.com/hook"}, handler)
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert "timed out" in str(excinfo.value).lower()


# ---------------------------------------------------------------------------
# Method + headers
# ---------------------------------------------------------------------------


def test_custom_method_put() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["method"] = request.method
        return _ok(request)

    driver = _make_driver(
        {"url": "https://example.com/hook", "method": "PUT"},
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert captured["method"] == "PUT"


def test_user_headers_merged_but_content_type_wins() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok(request)

    driver = _make_driver(
        {
            "url": "https://example.com/hook",
            "headers": {
                "X-Custom": "hello",
                # Deliberately try to force a wrong content type — the driver
                # must overwrite this with application/json since we're always
                # sending a JSON body.
                "Content-Type": "text/plain",
            },
        },
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert captured["headers"]["x-custom"] == "hello"
    assert captured["headers"]["content-type"].startswith("application/json")


# ---------------------------------------------------------------------------
# httpx client lifecycle (issue #14 E5)
# ---------------------------------------------------------------------------


def test_client_closed_when_request_raises_inside_with_block() -> None:
    """If the HTTP call raises inside the with-block, the client must close.

    Regression for issue #14 E5: an early raise must not leak the httpx
    Client. We track every client instance handed out by ``_client()`` and
    assert each one ends up closed after ``send()`` returns/raises.
    """
    instances: list[httpx.Client] = []

    def boom(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")

    driver = WebhookDriver({"url": "https://example.com/hook"})
    transport = httpx.MockTransport(boom)

    def _client() -> httpx.Client:
        c = httpx.Client(transport=transport, timeout=10.0)
        instances.append(c)
        return c

    driver._client = _client  # type: ignore[method-assign]

    with pytest.raises(DriverDeliveryError):
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert instances, "expected _client() to have been invoked"
    for c in instances:
        assert c.is_closed, "httpx.Client leaked: not closed after send()"


def test_no_client_created_when_payload_construction_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If construction raises before the with-block, ``_client()`` is never called.

    Regression for issue #14 E5: ``_client()`` must be created *inside* the
    with-statement, so a failure earlier in ``send()`` cannot leak a client.
    """
    instances: list[httpx.Client] = []

    driver = WebhookDriver({"url": "https://example.com/hook"})

    def _client() -> httpx.Client:
        c = httpx.Client(timeout=10.0)
        instances.append(c)
        return c

    driver._client = _client  # type: ignore[method-assign]

    def explode(**_kwargs: Any) -> dict[str, Any]:
        raise RuntimeError("payload boom")

    monkeypatch.setattr(driver, "_build_payload", explode)

    with pytest.raises(RuntimeError, match="payload boom"):
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert instances == [], "client must not be created before the with-block"


# ---------------------------------------------------------------------------
# Registry registration
# ---------------------------------------------------------------------------


def test_registry_lookup_returns_webhook_driver() -> None:
    """The self-register line at the bottom of ``webhook.py`` must have fired
    as a side-effect of our import at the top of this file, so
    ``get_driver("webhook", ...)`` should resolve."""
    driver = get_driver("webhook", {"url": "https://example.com/hook"})
    assert isinstance(driver, WebhookDriver)
