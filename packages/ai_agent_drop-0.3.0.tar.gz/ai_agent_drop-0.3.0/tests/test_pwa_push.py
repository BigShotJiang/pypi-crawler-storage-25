"""Tests for the Web Push driver, subscribe/unsubscribe endpoints, and
the VAPID public-key surface.

The actual ``pywebpush.webpush`` call is faked out — we never make a
real HTTPS request to a push service. The driver-level tests assert on
which subscriptions get sent, which get pruned (HTTP 410), and how
errors collapse into the ``DeliveryResult`` contract.
"""

from __future__ import annotations

import json
from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.notifications import DRIVERS, get_driver
from agentdrop.notifications.base import DriverConfigError, DriverDeliveryError
from agentdrop.web.session import _get_admin_password_hash

from .conftest import fetch_csrf

# A throwaway but well-formed VAPID keypair (raw P-256, base64url). Generated
# once with `make vapid-keys` for this test module so the suite is fully
# deterministic and never has to talk to py_vapid's RNG at collection time.
TEST_VAPID_PUBLIC = (
    "BHG6L8wG7FUd4lB3hFmQkDoIC66u037RPc-PeZxBf_MapAjbmfULCCBtDft0IKY-IFSI8bH8qyd2-iLHLmoTaBs"
)
TEST_VAPID_PRIVATE = "nBeKH4L68UJhP8P7Mx34EkHJWsNIophoPcg3ddZ61ns"
TEST_VAPID_SUBJECT = "mailto:tests@example.com"
TEST_ADMIN_PASSWORD = "test-admin-password"


# ---------------------------------------------------------------------------
# fixtures
# ---------------------------------------------------------------------------


def _set_vapid_env(monkeypatch: pytest.MonkeyPatch, *, configured: bool) -> None:
    if configured:
        monkeypatch.setenv("AGENTDROP_VAPID_PUBLIC_KEY", TEST_VAPID_PUBLIC)
        monkeypatch.setenv("AGENTDROP_VAPID_PRIVATE_KEY", TEST_VAPID_PRIVATE)
        monkeypatch.setenv("AGENTDROP_VAPID_SUBJECT", TEST_VAPID_SUBJECT)
    else:
        monkeypatch.delenv("AGENTDROP_VAPID_PUBLIC_KEY", raising=False)
        monkeypatch.delenv("AGENTDROP_VAPID_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("AGENTDROP_VAPID_SUBJECT", raising=False)


def _build_app_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> sessionmaker[Session]:
    """Point the app at a tmp SQLite, rebuild engine/caches, create tables.

    Returns a sessionmaker bound to the freshly-built engine for tests
    that need to inspect rows directly.
    """
    db_path = tmp_path / "pwa.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_ADMIN_PASSWORD)
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key-for-sessions")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_admin_password_hash.cache_clear()
    Base.metadata.create_all(get_engine())
    return sessionmaker(bind=get_engine(), expire_on_commit=False)


@pytest.fixture
def vapid_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    _set_vapid_env(monkeypatch, configured=True)
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def no_vapid_env(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    _set_vapid_env(monkeypatch, configured=False)
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture
def db_session_factory(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Iterator[sessionmaker[Session]]:
    factory = _build_app_db(tmp_path, monkeypatch)
    yield factory
    get_engine.cache_clear()
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()


@pytest.fixture
def client(
    db_session_factory: sessionmaker[Session],
) -> Iterator[TestClient]:
    """TestClient against the app, backed by the per-test tmp DB.

    Overrides the conftest fixture because PWA tests need a writable DB.
    """
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def authed_client(client: TestClient) -> TestClient:
    """Drive the login flow so subsequent requests carry a session cookie."""
    token = fetch_csrf(client)
    response = client.post(
        "/login",
        data={"password": TEST_ADMIN_PASSWORD, "next": "/", "_csrf": token},
        follow_redirects=False,
    )
    assert response.status_code == 303, (
        f"login fixture failed: HTTP {response.status_code} {response.text}"
    )
    return client


# ---------------------------------------------------------------------------
# driver registration
# ---------------------------------------------------------------------------


def test_web_push_driver_is_registered() -> None:
    assert "web_push" in DRIVERS


def test_driver_init_requires_full_vapid_config(no_vapid_env: None) -> None:
    with pytest.raises(DriverConfigError) as excinfo:
        get_driver("web_push", {})
    assert "VAPID" in str(excinfo.value)


def test_driver_init_succeeds_with_valid_vapid(vapid_env: None) -> None:
    driver = get_driver("web_push", {})
    assert driver.driver_name == "web_push"


def test_driver_private_key_pairs_with_advertised_public_key(vapid_env: None) -> None:
    # Regression: ``py_vapid.Vapid.from_raw`` expects a base64url-encoded
    # string and decodes it itself. A past bug passed it already-decoded
    # bytes, double-decoding into a garbage scalar whose public key no
    # longer matched the one the subscribe endpoint advertised — Apple
    # then rejected every push with ``VapidPkHashMismatch``. Guard the
    # invariant directly: the public key derived from the driver's
    # private scalar must equal what ``/pwa/vapid-public-key`` serves.
    from cryptography.hazmat.primitives import serialization
    from py_vapid.utils import b64urlencode

    driver = get_driver("web_push", {})
    derived = driver._vapid.public_key.public_bytes(  # type: ignore[attr-defined]
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    assert b64urlencode(derived) == TEST_VAPID_PUBLIC


def test_driver_init_rejects_malformed_private_key(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_VAPID_PUBLIC_KEY", TEST_VAPID_PUBLIC)
    monkeypatch.setenv("AGENTDROP_VAPID_PRIVATE_KEY", "this-is-not-base64url-or-anything-valid!!")
    monkeypatch.setenv("AGENTDROP_VAPID_SUBJECT", TEST_VAPID_SUBJECT)
    get_settings.cache_clear()
    try:
        with pytest.raises(DriverConfigError) as excinfo:
            get_driver("web_push", {})
        assert "malformed" in str(excinfo.value).lower()
    finally:
        get_settings.cache_clear()


# ---------------------------------------------------------------------------
# driver send behaviour
# ---------------------------------------------------------------------------


def _make_sub(endpoint: str = "https://push.example/abcdef") -> PushSubscription:
    sub = PushSubscription(
        endpoint=endpoint,
        p256dh="p256dh-stub",
        auth="auth-stub",
        user_agent="pytest",
    )
    return sub


def _seed_sub(
    factory: sessionmaker[Session],
    endpoint: str = "https://push.example/abcdef",
) -> str:
    with factory() as session:
        sub = _make_sub(endpoint)
        session.add(sub)
        session.commit()
        session.refresh(sub)
        return sub.id


def test_send_returns_ok_when_no_subscriptions(
    vapid_env: None, db_session_factory: sessionmaker[Session]
) -> None:
    driver = get_driver("web_push", {})
    result = driver.send(title="t", body="b", url="https://x/d/abc", priority="normal")
    assert result.ok is True
    assert "no subscriptions" in (result.detail or "")


def test_send_calls_webpush_for_each_subscription(
    vapid_env: None, db_session_factory: sessionmaker[Session]
) -> None:
    _seed_sub(db_session_factory, "https://push.example/one")
    _seed_sub(db_session_factory, "https://push.example/two")
    driver = get_driver("web_push", {})

    captured: list[dict[str, Any]] = []

    def _fake_webpush(**kwargs: Any) -> Any:
        captured.append(kwargs)
        return None

    with patch("agentdrop.notifications.web_push.webpush", side_effect=_fake_webpush):
        result = driver.send(
            title="hello",
            body="body text",
            url="https://drop.example/d/abc",
            priority="normal",
            extras={"drop_id": "drp_1"},
        )

    assert result.ok is True
    assert "2/2" in (result.detail or "")
    assert len(captured) == 2

    # Payload should be tiny JSON with title/body/url/drop_id.
    payload = json.loads(captured[0]["data"])
    assert payload == {
        "title": "hello",
        "body": "body text",
        "url": "https://drop.example/d/abc",
        "drop_id": "drp_1",
    }


def test_send_prunes_subscription_on_410(
    vapid_env: None, db_session_factory: sessionmaker[Session]
) -> None:
    """A push service returning 410 means the subscription is dead — we
    must delete the row so we stop trying every drop."""
    from pywebpush import WebPushException

    sub_id = _seed_sub(db_session_factory, "https://push.example/dead")

    class _FakeResponse:
        status_code = 410

    def _raise_410(**kwargs: Any) -> None:
        exc = WebPushException("gone")
        exc.response = _FakeResponse()
        raise exc

    with (
        patch("agentdrop.notifications.web_push.webpush", side_effect=_raise_410),
        pytest.raises(DriverDeliveryError),
    ):
        get_driver("web_push", {}).send(
            title="t",
            body="b",
            url="https://x/d/abc",
            priority="normal",
        )

    # Row is gone.
    with db_session_factory() as session:
        remaining = session.execute(
            select(PushSubscription).where(PushSubscription.id == sub_id)
        ).scalar_one_or_none()
        assert remaining is None


def test_send_partial_success_keeps_live_sub_and_prunes_dead(
    vapid_env: None, db_session_factory: sessionmaker[Session]
) -> None:
    from pywebpush import WebPushException

    live_id = _seed_sub(db_session_factory, "https://push.example/live")
    dead_id = _seed_sub(db_session_factory, "https://push.example/dead")

    class _FakeResponse:
        status_code = 410

    def _selective(**kwargs: Any) -> None:
        if "dead" in kwargs["subscription_info"]["endpoint"]:
            exc = WebPushException("gone")
            exc.response = _FakeResponse()
            raise exc
        # success — webpush returns the requests.Response normally, but
        # the driver only checks for raise; returning anything is fine.
        return None

    with patch("agentdrop.notifications.web_push.webpush", side_effect=_selective):
        result = get_driver("web_push", {}).send(
            title="t",
            body="b",
            url="https://x/d/abc",
            priority="normal",
        )

    assert result.ok is True
    assert "1/2" in (result.detail or "")

    with db_session_factory() as session:
        ids = {s.id for s in session.execute(select(PushSubscription)).scalars().all()}
        assert live_id in ids
        assert dead_id not in ids


def test_send_raises_when_every_attempt_fails(
    vapid_env: None, db_session_factory: sessionmaker[Session]
) -> None:
    """All subs failing for a non-stale reason should surface as a
    DriverDeliveryError so the dispatch path records a failure warning."""
    _seed_sub(db_session_factory, "https://push.example/x")
    _seed_sub(db_session_factory, "https://push.example/y")

    def _explode(**kwargs: Any) -> None:
        raise RuntimeError("boom")

    with (
        patch("agentdrop.notifications.web_push.webpush", side_effect=_explode),
        pytest.raises(DriverDeliveryError) as excinfo,
    ):
        get_driver("web_push", {}).send(
            title="t",
            body="b",
            url="https://x/d/abc",
            priority="normal",
        )
    assert "all 2 subscriptions failed" in str(excinfo.value)


# ---------------------------------------------------------------------------
# /pwa/vapid-public-key
# ---------------------------------------------------------------------------


def test_vapid_public_key_returns_configured_key(vapid_env: None, client: TestClient) -> None:
    response = client.get("/pwa/vapid-public-key")
    assert response.status_code == 200
    assert response.json() == {"key": TEST_VAPID_PUBLIC}


def test_vapid_public_key_returns_null_when_unset(no_vapid_env: None, client: TestClient) -> None:
    response = client.get("/pwa/vapid-public-key")
    assert response.status_code == 200
    assert response.json() == {"key": None}


# ---------------------------------------------------------------------------
# /pwa/subscribe + /pwa/unsubscribe
# ---------------------------------------------------------------------------


def test_subscribe_requires_session(vapid_env: None, client: TestClient) -> None:
    response = client.post(
        "/pwa/subscribe",
        json={
            "endpoint": "https://push.example/x",
            "keys": {"p256dh": "p", "auth": "a"},
        },
        follow_redirects=False,
    )
    # The session dep redirects unauthenticated callers to /login.
    assert response.status_code == 303


def _csrf_headers(client: TestClient) -> dict[str, str]:
    return {"X-CSRF-Token": fetch_csrf(client)}


def test_subscribe_rejects_when_vapid_unconfigured(
    no_vapid_env: None, authed_client: TestClient
) -> None:
    response = authed_client.post(
        "/pwa/subscribe",
        json={
            "endpoint": "https://push.example/x",
            "keys": {"p256dh": "p", "auth": "a"},
        },
        headers=_csrf_headers(authed_client),
    )
    assert response.status_code == 503


def test_subscribe_creates_row(
    vapid_env: None,
    authed_client: TestClient,
    db_session_factory: sessionmaker[Session],
) -> None:
    response = authed_client.post(
        "/pwa/subscribe",
        json={
            "endpoint": "https://push.example/new",
            "keys": {"p256dh": "p256-value", "auth": "auth-value"},
        },
        headers=_csrf_headers(authed_client),
    )
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["endpoint"] == "https://push.example/new"
    assert body["id"].startswith("psub")

    with db_session_factory() as session:
        sub = session.execute(
            select(PushSubscription).where(PushSubscription.endpoint == "https://push.example/new")
        ).scalar_one()
        assert sub.p256dh == "p256-value"
        assert sub.auth == "auth-value"


def test_subscribe_updates_existing_row(
    vapid_env: None,
    authed_client: TestClient,
    db_session_factory: sessionmaker[Session],
) -> None:
    """Re-subscribing the same endpoint should refresh keys, not duplicate."""
    payload = {
        "endpoint": "https://push.example/repeat",
        "keys": {"p256dh": "v1-p256", "auth": "v1-auth"},
    }
    headers = _csrf_headers(authed_client)
    first = authed_client.post("/pwa/subscribe", json=payload, headers=headers).json()

    payload["keys"] = {"p256dh": "v2-p256", "auth": "v2-auth"}
    second = authed_client.post("/pwa/subscribe", json=payload, headers=headers).json()

    assert first["id"] == second["id"]
    with db_session_factory() as session:
        rows = session.execute(select(PushSubscription)).scalars().all()
        assert len(rows) == 1
        assert rows[0].p256dh == "v2-p256"
        assert rows[0].auth == "v2-auth"


def test_unsubscribe_deletes_row(
    vapid_env: None,
    authed_client: TestClient,
    db_session_factory: sessionmaker[Session],
) -> None:
    headers = _csrf_headers(authed_client)
    authed_client.post(
        "/pwa/subscribe",
        json={
            "endpoint": "https://push.example/byebye",
            "keys": {"p256dh": "p", "auth": "a"},
        },
        headers=headers,
    )

    response = authed_client.post(
        "/pwa/unsubscribe",
        json={"endpoint": "https://push.example/byebye"},
        headers=headers,
    )
    assert response.status_code == 204

    with db_session_factory() as session:
        rows = session.execute(select(PushSubscription)).scalars().all()
        assert rows == []


def test_unsubscribe_is_idempotent(vapid_env: None, authed_client: TestClient) -> None:
    """Deleting an endpoint we don't have shouldn't error."""
    response = authed_client.post(
        "/pwa/unsubscribe",
        json={"endpoint": "https://push.example/never-existed"},
        headers=_csrf_headers(authed_client),
    )
    assert response.status_code == 204
