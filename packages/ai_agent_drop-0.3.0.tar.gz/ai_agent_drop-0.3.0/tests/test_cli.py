"""Tests for the ``agentdrop`` CLI.

We use Typer's :class:`~typer.testing.CliRunner` to drive the app end-to-end
without a subprocess. Network calls are faked by monkeypatching
:mod:`agentdrop.cli.http` so no real HTTP ever leaves the test.
"""

from __future__ import annotations

import json
import tomllib
from typing import Any

import httpx
import pytest
from typer.testing import CliRunner

from agentdrop import __version__
from agentdrop.cli import http as cli_http
from agentdrop.cli.app import app
from agentdrop.cli.config_file import CliConfig


@pytest.fixture
def runner() -> CliRunner:
    # Typer >= 0.12 splits stdout / stderr by default.
    return CliRunner()


@pytest.fixture
def config_home(monkeypatch: pytest.MonkeyPatch, tmp_path: Any) -> Any:
    """Redirect ``XDG_CONFIG_HOME`` at a tmp dir so tests never touch real config."""
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    return tmp_path


@pytest.fixture
def configured(config_home: Any, runner: CliRunner) -> Any:
    """Write a known config so subcommands that need it can run."""
    runner.invoke(
        app,
        [
            "config",
            "--base-url",
            "https://drop.example.test",
            "--api-key",
            "agdr_test_abcdef1234567890",
        ],
    )
    return config_home


class _FakeResponse:
    """Tiny stand-in for ``httpx.Response`` used by the client under test."""

    def __init__(
        self,
        status_code: int,
        payload: dict[str, Any] | list[Any] | None = None,
        *,
        text: str | None = None,
    ) -> None:
        self.status_code = status_code
        self._payload = payload
        self._text = text
        self.reason_phrase = "Bad Request" if status_code >= 400 else "OK"

    @property
    def content(self) -> bytes:
        if self._payload is not None:
            return json.dumps(self._payload).encode()
        return (self._text or "").encode()

    @property
    def text(self) -> str:
        if self._text is not None:
            return self._text
        if self._payload is not None:
            return json.dumps(self._payload)
        return ""

    def json(self) -> Any:
        if self._payload is None:
            raise ValueError("no json payload")
        return self._payload


def _patch_http(monkeypatch: pytest.MonkeyPatch, handler: Any) -> list[dict[str, Any]]:
    """Replace ``httpx.Client`` with a fake that calls ``handler(method, url, **kw)``.

    Returns a list that captures every call for later assertion.
    """
    calls: list[dict[str, Any]] = []

    class _FakeClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def __enter__(self) -> _FakeClient:
            return self

        def __exit__(self, *exc: Any) -> None:
            return None

        def request(self, method: str, url: str, **kwargs: Any) -> _FakeResponse:
            call = {"method": method, "url": url, **kwargs}
            calls.append(call)
            return handler(method, url, **kwargs)

    monkeypatch.setattr(cli_http.httpx, "Client", _FakeClient)
    return calls


# ---------------------------------------------------------------------------
# top-level help + version
# ---------------------------------------------------------------------------


def test_top_level_help_lists_subcommands(runner: CliRunner) -> None:
    result = runner.invoke(app, ["--help"])
    assert result.exit_code == 0
    out = result.stdout
    # Typer renders help via rich; just check the command names appear.
    assert "drop" in out
    assert "list" in out
    assert "config" in out


def test_version_prints_semverish_string(runner: CliRunner) -> None:
    result = runner.invoke(app, ["version"])
    assert result.exit_code == 0
    assert result.stdout.strip() == __version__
    # sanity check: at least one dot
    assert "." in __version__


# ---------------------------------------------------------------------------
# config
# ---------------------------------------------------------------------------


def test_config_writes_file(runner: CliRunner, config_home: Any) -> None:
    result = runner.invoke(
        app,
        [
            "config",
            "--base-url",
            "https://drop.example.test",
            "--api-key",
            "agdr_secret_key_1234567890",
        ],
    )
    assert result.exit_code == 0, result.stdout + result.stderr

    written = config_home / "agentdrop" / "config.toml"
    assert written.is_file()
    data = tomllib.loads(written.read_text())
    assert data["base_url"] == "https://drop.example.test"
    assert data["api_key"] == "agdr_secret_key_1234567890"


def test_config_no_flags_prints_masked_summary(runner: CliRunner, configured: Any) -> None:
    result = runner.invoke(app, ["config"])
    assert result.exit_code == 0, result.stderr
    out = result.stdout
    assert "config path:" in out
    assert "agdr_test_abcdef1234567890" not in out  # raw key must not leak
    assert "base_url" in out
    assert "drop.example.test" in out
    # masked form: starts with agdr, ends with last two chars of the key
    assert "agdr" in out
    assert "90" in out  # trailing chars


def test_config_show_path_prints_only_path(runner: CliRunner, config_home: Any) -> None:
    result = runner.invoke(app, ["config", "--show-path"])
    assert result.exit_code == 0
    # exactly one line, ends in config.toml
    line = result.stdout.strip()
    assert line.endswith("config.toml")
    assert str(config_home) in line


def test_config_set_flags_never_prints_raw_key(runner: CliRunner, config_home: Any) -> None:
    secret = "agdr_super_secret_value_never_leak"
    result = runner.invoke(
        app,
        [
            "config",
            "--base-url",
            "https://x.test",
            "--api-key",
            secret,
        ],
    )
    assert result.exit_code == 0
    assert secret not in result.stdout


# ---------------------------------------------------------------------------
# drop
# ---------------------------------------------------------------------------


def _ok_drop_response() -> _FakeResponse:
    return _FakeResponse(
        201,
        {
            "id": "drp_abcdef",
            "url": "https://drop.example.test/d/abc123",
            "created_at": "2026-04-19T10:00:00Z",
            "warnings": [],
        },
    )


def test_drop_success_prints_url(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        [
            "drop",
            "--title",
            "T",
            "--body",
            "B",
            "--content",
            "hello body",
        ],
    )
    assert result.exit_code == 0, result.stderr
    assert result.stdout.strip() == "https://drop.example.test/d/abc123"

    assert len(calls) == 1
    call = calls[0]
    assert call["method"] == "POST"
    assert call["url"].endswith("/api/v1/drops")
    # bearer header present, payload shape matches PRD §8.1
    assert call["headers"]["Authorization"].startswith("Bearer ")
    body = call["json"]
    assert body["title"] == "T"
    assert body["body"] == "B"
    assert body["content"] == "hello body"
    assert body["priority"] == "normal"


def test_drop_missing_required_flags_errors(runner: CliRunner, configured: Any) -> None:
    result = runner.invoke(app, ["drop", "--title", "only-title"])
    assert result.exit_code != 0
    # typer emits its own usage error; it lands on stderr.
    combined = (result.stdout or "") + (result.stderr or "")
    assert "body" in combined.lower() or "missing" in combined.lower()


def test_drop_content_stdin(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        ["drop", "--title", "T", "--body", "B", "--content", "-"],
        input="piped markdown content\nline 2\n",
    )
    assert result.exit_code == 0, result.stderr
    assert calls[0]["json"]["content"] == "piped markdown content\nline 2\n"


def test_drop_4xx_surfaces_server_error(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_http(
        monkeypatch,
        lambda *a, **kw: _FakeResponse(
            422, {"detail": [{"loc": ["body", "title"], "msg": "field required"}]}
        ),
    )

    result = runner.invoke(
        app,
        ["drop", "--title", "T", "--body", "B", "--content", "c"],
    )
    assert result.exit_code != 0
    assert "422" in result.stderr
    assert "field required" in result.stderr


def test_drop_network_error_exits_nonzero(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _raise(*a: Any, **kw: Any) -> Any:
        raise httpx.ConnectError("connection refused")

    class _ExplodingClient:
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            pass

        def __enter__(self) -> _ExplodingClient:
            return self

        def __exit__(self, *exc: Any) -> None:
            return None

        def request(self, *args: Any, **kwargs: Any) -> Any:
            raise httpx.ConnectError("connection refused")

    monkeypatch.setattr(cli_http.httpx, "Client", _ExplodingClient)
    result = runner.invoke(app, ["drop", "--title", "T", "--body", "B", "--content", "c"])
    assert result.exit_code != 0
    assert "network error" in result.stderr.lower()


def test_drop_json_flag_prints_raw_response(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())
    result = runner.invoke(
        app,
        ["drop", "--title", "T", "--body", "B", "--content", "c", "--json"],
    )
    assert result.exit_code == 0
    parsed = json.loads(result.stdout)
    assert parsed["id"] == "drp_abcdef"
    assert parsed["url"] == "https://drop.example.test/d/abc123"


def test_drop_requires_exactly_one_content_source(
    runner: CliRunner, configured: Any, tmp_path: Any
) -> None:
    f = tmp_path / "c.md"
    f.write_text("from file")
    result = runner.invoke(
        app,
        [
            "drop",
            "--title",
            "T",
            "--body",
            "B",
            "--content",
            "literal",
            "--content-file",
            str(f),
        ],
    )
    assert result.exit_code != 0
    assert "exactly one" in result.stderr.lower()


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


def _list_payload() -> dict[str, Any]:
    return {
        "items": [
            {
                "id": "drp_aaaaaaaa",
                "short_id": "abc1234",
                "url": "https://drop.example.test/d/abc1234",
                "title": "Weekly scan",
                "body": "b",
                "summary": "b",
                "source": "weekly",
                "tags": [],
                "priority": "normal",
                "external_url": None,
                "channel_id": None,
                "created_at": "2026-04-19T09:00:00Z",
                "expires_at": None,
                "pinned_at": None,
                "archived_at": None,
                "read_at": None,
                "state": "unread",
            }
        ],
        "next_cursor": None,
        "count": 1,
    }


def test_list_renders_compact_table(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_http(monkeypatch, lambda *a, **kw: _FakeResponse(200, _list_payload()))
    result = runner.invoke(app, ["list"])
    assert result.exit_code == 0, result.stderr
    out = result.stdout
    assert "id" in out
    assert "age" in out
    assert "title" in out
    assert "abc1234" in out
    assert "Weekly scan" in out


def test_list_json_flag_prints_raw_payload(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_http(monkeypatch, lambda *a, **kw: _FakeResponse(200, _list_payload()))
    result = runner.invoke(app, ["list", "--json"])
    assert result.exit_code == 0
    parsed = json.loads(result.stdout)
    assert parsed["count"] == 1
    assert parsed["items"][0]["short_id"] == "abc1234"


def test_list_sends_filters(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = _patch_http(monkeypatch, lambda *a, **kw: _FakeResponse(200, _list_payload()))
    result = runner.invoke(
        app,
        ["list", "--limit", "5", "--source", "weekly", "--state", "unread"],
    )
    assert result.exit_code == 0, result.stderr
    params = calls[0]["params"]
    assert params["limit"] == 5
    assert params["state"] == "unread"
    assert params["source"] == "weekly"


# ---------------------------------------------------------------------------
# config-file helpers (unit-level)
# ---------------------------------------------------------------------------


def test_mask_key_hides_body_and_tail() -> None:
    from agentdrop.cli.config_file import mask_key

    assert mask_key(None) == "(unset)"
    assert mask_key("") == "(unset)"
    assert mask_key("short") == "*****"
    masked = mask_key("agdr_abcdef1234")
    assert masked.startswith("agdr")
    assert masked.endswith("34")
    assert "abcdef12" not in masked


def test_cli_config_roundtrip(tmp_path: Any) -> None:
    from agentdrop.cli.config_file import load_config, save_config

    target = tmp_path / "nested" / "config.toml"
    save_config(CliConfig(base_url="https://x", api_key="k", default_source="cli"), target)
    assert target.is_file()
    loaded = load_config(target)
    assert loaded.base_url == "https://x"
    assert loaded.api_key == "k"
    assert loaded.default_source == "cli"


# ---------------------------------------------------------------------------
# CF Access (Cloudflare Access service-token headers)
# ---------------------------------------------------------------------------


def test_config_writes_cf_access_fields(runner: CliRunner, config_home: Any) -> None:
    result = runner.invoke(
        app,
        [
            "config",
            "--base-url",
            "https://drop.example.test",
            "--api-key",
            "agdr_secret_key_1234567890",
            "--cf-access-client-id",
            "cfid_public.access",
            "--cf-access-client-secret",
            "cfsecret_long_enough_to_mask",
        ],
    )
    assert result.exit_code == 0, result.stderr

    written = config_home / "agentdrop" / "config.toml"
    data = tomllib.loads(written.read_text())
    assert data["cf_access_client_id"] == "cfid_public.access"
    assert data["cf_access_client_secret"] == "cfsecret_long_enough_to_mask"


def test_config_summary_masks_cf_access_secret(runner: CliRunner, config_home: Any) -> None:
    secret = "cfsecret_super_private_value_xyz"
    runner.invoke(
        app,
        [
            "config",
            "--base-url",
            "https://x.test",
            "--api-key",
            "agdr_test_abcdef1234567890",
            "--cf-access-client-id",
            "cfid_public.access",
            "--cf-access-client-secret",
            secret,
        ],
    )
    result = runner.invoke(app, ["config"])
    assert result.exit_code == 0, result.stderr
    out = result.stdout
    assert "cf_access_client_id" in out
    assert "cfid_public.access" in out  # id is not a secret
    assert "cf_access_client_secret" in out
    assert secret not in out  # secret must never leak


def test_drop_sends_cf_access_headers_when_configured(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(
        app,
        [
            "config",
            "--cf-access-client-id",
            "cfid_public.access",
            "--cf-access-client-secret",
            "cfsecret_value",
        ],
    )
    calls = _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        ["drop", "--title", "T", "--body", "B", "--content", "c"],
    )
    assert result.exit_code == 0, result.stderr
    headers = calls[0]["headers"]
    assert headers["CF-Access-Client-Id"] == "cfid_public.access"
    assert headers["CF-Access-Client-Secret"] == "cfsecret_value"


def test_drop_omits_cf_access_headers_when_unconfigured(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls = _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        ["drop", "--title", "T", "--body", "B", "--content", "c"],
    )
    assert result.exit_code == 0, result.stderr
    headers = calls[0]["headers"]
    assert "CF-Access-Client-Id" not in headers
    assert "CF-Access-Client-Secret" not in headers


def test_drop_cli_flags_override_cf_access_config(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    runner.invoke(
        app,
        [
            "config",
            "--cf-access-client-id",
            "old_id",
            "--cf-access-client-secret",
            "old_secret",
        ],
    )
    calls = _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        [
            "drop",
            "--title",
            "T",
            "--body",
            "B",
            "--content",
            "c",
            "--cf-access-client-id",
            "new_id",
            "--cf-access-client-secret",
            "new_secret",
        ],
    )
    assert result.exit_code == 0, result.stderr
    headers = calls[0]["headers"]
    assert headers["CF-Access-Client-Id"] == "new_id"
    assert headers["CF-Access-Client-Secret"] == "new_secret"


def test_drop_errors_when_only_one_cf_access_field_set(
    runner: CliRunner,
    configured: Any,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    _patch_http(monkeypatch, lambda *a, **kw: _ok_drop_response())

    result = runner.invoke(
        app,
        [
            "drop",
            "--title",
            "T",
            "--body",
            "B",
            "--content",
            "c",
            "--cf-access-client-id",
            "id_only_no_secret",
        ],
    )
    assert result.exit_code != 0
    assert "cf_access" in result.stderr.lower()
