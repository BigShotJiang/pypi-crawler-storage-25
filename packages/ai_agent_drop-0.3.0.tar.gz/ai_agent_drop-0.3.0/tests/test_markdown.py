"""Tests for ``agentdrop.web.markdown.render_markdown``.

Each test asserts on rendered HTML substrings (not an exact equality) so
we're resilient to upstream whitespace/attribute-order nudges in
markdown-it-py while still locking the contract the drop template depends on.
"""

from __future__ import annotations

from markupsafe import Markup

from agentdrop.web.markdown import render_markdown


def test_returns_markup() -> None:
    """Return type must be ``Markup`` so Jinja skips double-escaping."""
    out = render_markdown("# Hello")
    assert isinstance(out, Markup)


def test_heading_and_bold() -> None:
    out = render_markdown("# Hi\n\nHello **world**")
    assert "<h1" in out  # anchors plugin may add `id=` — match prefix only
    assert ">Hi</h1>" in out
    assert "<strong>world</strong>" in out


def test_gfm_table() -> None:
    md = """\
| Col A | Col B |
| ----- | ----- |
| 1     | 2     |
| 3     | 4     |
"""
    out = render_markdown(md)
    assert "<table>" in out
    assert "<thead>" in out
    assert "<th>Col A</th>" in out
    assert "<td>1</td>" in out


def test_task_list_classes_and_checked_state() -> None:
    out = render_markdown("- [x] done\n- [ ] todo\n")
    # Upstream class on the <ul>
    assert 'class="contains-task-list"' in out
    # Each <li> gets the ``task-list-item`` class (our CSS keys on this).
    assert 'class="task-list-item"' in out
    # Both an unchecked and a checked checkbox are emitted.
    assert "<input" in out
    assert 'type="checkbox"' in out
    assert 'checked="checked"' in out
    # And there's at least one input without `checked=`.
    unchecked_marker = 'class="task-list-item-checkbox" disabled="disabled" type="checkbox"'
    assert unchecked_marker in out


def test_strikethrough() -> None:
    out = render_markdown("~~ok~~")
    # markdown-it-py uses <s>; accept either spelling to be safe across versions.
    assert "<s>ok</s>" in out or "<del>ok</del>" in out


def test_fenced_python_is_highlighted() -> None:
    md = "```python\ndef foo():\n    return 42\n```\n"
    out = render_markdown(md)
    assert "<pre>" in out
    assert '<code class="language-python">' in out
    # Pygments emits token spans like <span class="k">def</span> for keywords.
    assert '<span class="k">' in out


def test_mermaid_fence_becomes_div() -> None:
    md = "```mermaid\ngraph TD; A-->B;\n```\n"
    out = render_markdown(md)
    assert '<div class="mermaid">' in out
    # The arrow must be HTML-escaped (no raw `-->` emerging as a comment).
    assert "A--&gt;B" in out
    # And it must NOT have gone through the code-block renderer.
    assert "<code" not in out


def test_raw_html_is_escaped() -> None:
    out = render_markdown("<script>alert(1)</script>")
    # No executable script tag should appear.
    assert "<script>" not in out
    assert "&lt;script&gt;" in out


def test_hr_from_triple_dash() -> None:
    out = render_markdown("before\n\n---\n\nafter\n")
    assert "<hr" in out


def test_linkify_autolinks_bare_urls() -> None:
    out = render_markdown("Visit https://example.com now")
    assert '<a href="https://example.com">https://example.com</a>' in out


def test_inline_code_renders() -> None:
    out = render_markdown("use `foo()` to call")
    assert "<code>foo()</code>" in out


def test_blockquote_and_paragraph() -> None:
    out = render_markdown("> quoted\n\nregular")
    assert "<blockquote>" in out
    assert "<p>regular</p>" in out


def test_empty_input_is_empty_string() -> None:
    out = render_markdown("")
    assert str(out) == ""


def test_heading_ids_enabled_for_h1_h2_h3() -> None:
    out = render_markdown("# Hi there\n\n## Second\n\n### Third\n")
    # anchors plugin slugs -> ``hi-there``, ``second``, ``third``
    assert 'id="hi-there"' in out
    assert 'id="second"' in out
    assert 'id="third"' in out
