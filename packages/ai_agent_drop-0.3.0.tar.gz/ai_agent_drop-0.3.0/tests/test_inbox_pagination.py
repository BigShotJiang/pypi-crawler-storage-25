"""Tests for inbox cursor pagination via HTMX (issue #14, G2).

Covers two surfaces:

* Backend: walking the cursor returns every drop exactly once, in
  ``(created_at DESC, id DESC)`` order, with no duplicates.
* Template: the ``Load more`` button is present when more rows exist and
  absent on the final page (and absent entirely when the inbox fits in
  one page).
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.fts import install_fts_schema
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop
from agentdrop.web.inbox import _PAGE_SIZE
from agentdrop.web.session import Admin, require_session


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())
    install_fts_schema(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _seed_n(n: int) -> list[str]:
    """Seed ``n`` drops with strictly decreasing created_at. Returns short_ids
    in newest-first order so tests can assert ordering directly."""
    now = datetime.now(UTC)
    session = SessionLocal(bind=get_engine())
    short_ids: list[str] = []
    try:
        for i in range(n):
            short_id = f"sid{i:021d}"  # 24 chars
            drop = Drop(
                short_id=short_id,
                title=f"Drop number {i}",
                body=f"body {i}",
                content_md="",
                source="bulk",
                created_at=now - timedelta(seconds=i),
            )
            session.add(drop)
            short_ids.append(short_id)
        session.commit()
    finally:
        session.close()
    # Newest first = i=0 (smallest offset from ``now``).
    return short_ids


def _extract_cursor_from_html(html: str) -> str | None:
    """Pull the cursor value out of the ``Load more`` button's hx-get URL."""
    marker = 'hx-get="/?'
    start = html.find(marker)
    if start == -1:
        return None
    start += len(marker)
    end = html.find('"', start)
    qs = html[start:end].replace("&amp;", "&")
    parsed = parse_qs(urlparse("/?" + qs).query)
    cursors = parsed.get("cursor")
    return cursors[0] if cursors else None


def test_first_page_renders_load_more_when_more_rows(client: TestClient) -> None:
    _seed_n(_PAGE_SIZE + 5)
    resp = client.get("/")
    assert resp.status_code == 200
    html = resp.text
    assert "inbox-load-more" in html
    cursor = _extract_cursor_from_html(html)
    assert cursor is not None and cursor != ""


def test_no_load_more_when_inbox_fits_in_one_page(client: TestClient) -> None:
    _seed_n(_PAGE_SIZE - 1)
    resp = client.get("/")
    assert resp.status_code == 200
    assert "inbox-load-more" not in resp.text


def test_no_load_more_when_inbox_exactly_one_page(client: TestClient) -> None:
    """An exact page-size inbox is a soft edge case — we render the button
    because the server cannot know there are no further rows without a
    second query. Following the cursor returns an empty fragment with no
    further button. This matches the API's cursor contract."""
    _seed_n(_PAGE_SIZE)
    resp = client.get("/")
    assert resp.status_code == 200
    cursor = _extract_cursor_from_html(resp.text)
    assert cursor is not None
    # Following it returns an empty fragment (no drops, no button).
    follow = client.get(f"/?cursor={cursor}", headers={"HX-Request": "true"})
    assert follow.status_code == 200
    assert "Drop number" not in follow.text
    assert "inbox-load-more" not in follow.text


def test_cursor_walk_returns_every_drop_no_duplicates(client: TestClient) -> None:
    n = _PAGE_SIZE * 2 + 7
    seeded = _seed_n(n)

    seen: list[str] = []

    # First page (full chrome). Extract dropcard short_ids in render order.
    resp = client.get("/")
    assert resp.status_code == 200
    seen.extend(_extract_short_ids(resp.text))
    cursor = _extract_cursor_from_html(resp.text)

    pages = 0
    while cursor is not None:
        pages += 1
        if pages > 10:
            pytest.fail("cursor walk did not terminate")
        resp = client.get(f"/?cursor={cursor}", headers={"HX-Request": "true"})
        assert resp.status_code == 200
        seen.extend(_extract_short_ids(resp.text))
        cursor = _extract_cursor_from_html(resp.text)

    # Every seeded drop appeared exactly once, in newest-first order.
    assert len(seen) == n
    assert len(set(seen)) == n
    assert seen == seeded


def test_htmx_cursor_returns_partial_no_chrome(client: TestClient) -> None:
    _seed_n(_PAGE_SIZE + 3)
    first = client.get("/")
    cursor = _extract_cursor_from_html(first.text)
    assert cursor is not None

    resp = client.get(f"/?cursor={cursor}", headers={"HX-Request": "true"})
    assert resp.status_code == 200
    body = resp.text
    # Partial: no <html>/<body> wrapper, no sidebar, no header chrome.
    assert "<html" not in body
    assert "<aside" not in body
    assert "sidebar__brand" not in body
    # But it does contain dropcards.
    assert "dropcard" in body


def test_invalid_cursor_returns_400(client: TestClient) -> None:
    _seed_n(5)
    resp = client.get("/?cursor=not-a-real-cursor")
    # The decoder raises 400 on invalid input — same contract as the API.
    assert resp.status_code == 400


def _extract_short_ids(html: str) -> list[str]:
    """Pull dropcard short_ids out of rendered HTML in render order.

    The dropcard macro emits ``<a class="dropcard" href="/d/{short_id}">``
    so a simple substring scan for ``/d/sid`` gives stable results for
    seeded test data (which uses the ``sid…`` prefix).
    """
    marker = 'href="/d/'
    out: list[str] = []
    pos = 0
    while True:
        i = html.find(marker, pos)
        if i == -1:
            break
        i += len(marker)
        end = html.find('"', i)
        out.append(html[i:end])
        pos = end
    return out
