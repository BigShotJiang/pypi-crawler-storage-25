"""Tests for the ntfy notification driver.

These use ``httpx.MockTransport`` to intercept outbound HTTP calls, patching
``NtfyDriver._client`` so the driver talks to a transport we control. No real
network is ever touched.
"""

from __future__ import annotations

import base64
import json
from collections.abc import Callable
from typing import Any

import httpx
import pytest

from agentdrop.notifications.base import (
    DriverConfigError,
    DriverDeliveryError,
)
from agentdrop.notifications.ntfy import NtfyDriver


def _make_driver(
    config: dict[str, Any],
    handler: Callable[[httpx.Request], httpx.Response],
) -> NtfyDriver:
    """Build a driver whose internal client is backed by a mock transport."""
    driver = NtfyDriver(config)
    transport = httpx.MockTransport(handler)

    def _client() -> httpx.Client:
        return httpx.Client(transport=transport, timeout=10.0)

    driver._client = _client  # type: ignore[method-assign]
    return driver


def _ok_response(request: httpx.Request, body: dict[str, Any] | None = None) -> httpx.Response:
    payload = body if body is not None else {"id": "msg_123", "time": 1700000000}
    return httpx.Response(200, json=payload)


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


def test_missing_topic_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        NtfyDriver({})


def test_blank_topic_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        NtfyDriver({"topic": "   "})


def test_both_auth_modes_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        NtfyDriver(
            {
                "topic": "foo",
                "access_token": "xyz",
                "username": "u",
                "password": "p",
            }
        )


def test_invalid_base_url_scheme_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        NtfyDriver({"topic": "foo", "base_url": "ftp://nope.example"})


# ---------------------------------------------------------------------------
# Happy-path publishing
# ---------------------------------------------------------------------------


def test_hosted_default_base_url_posts_to_ntfy_sh() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        captured["method"] = request.method
        captured["body"] = request.content.decode("utf-8")
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver({"topic": "foo"}, handler)
    result = driver.send(
        title="Hello",
        body="hello world",
        url="https://drop.example/d/abc123",
        priority="normal",
    )

    assert result.ok is True
    assert result.driver == "ntfy"
    assert result.provider_id == "msg_123"
    assert captured["url"] == "https://ntfy.sh/foo"
    assert captured["method"] == "POST"
    assert captured["body"] == "hello world"
    assert captured["headers"]["title"] == "Hello"
    assert captured["headers"]["priority"] == "3"
    assert captured["headers"]["click"] == "https://drop.example/d/abc123"
    assert "authorization" not in captured["headers"]


def test_self_hosted_base_url() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return _ok_response(request)

    driver = _make_driver(
        {"topic": "foo", "base_url": "https://ntfy.lan:8443"},
        handler,
    )
    driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority="normal",
    )

    assert captured["url"] == "https://ntfy.lan:8443/foo"


def test_self_hosted_base_url_with_trailing_slash_is_normalised() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["url"] = str(request.url)
        return _ok_response(request)

    driver = _make_driver(
        {"topic": "foo", "base_url": "https://ntfy.lan:8443/"},
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert captured["url"] == "https://ntfy.lan:8443/foo"


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_bearer_auth_header_set() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver(
        {"topic": "foo", "access_token": "xyz"},
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert captured["headers"]["authorization"] == "Bearer xyz"


def test_basic_auth_header_set() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver(
        {"topic": "foo", "username": "u", "password": "p"},
        handler,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    expected = base64.b64encode(b"u:p").decode("ascii")
    assert captured["headers"]["authorization"] == f"Basic {expected}"


# ---------------------------------------------------------------------------
# Priority mapping
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("priority", "expected"),
    [("low", "2"), ("normal", "3"), ("high", "4"), ("urgent", "5")],
)
def test_priority_mapping(priority: str, expected: str) -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver({"topic": "foo"}, handler)
    driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority=priority,  # type: ignore[arg-type]
    )

    assert captured["headers"]["priority"] == expected


# ---------------------------------------------------------------------------
# Extras passthrough
# ---------------------------------------------------------------------------


def test_ntfy_tags_extras_set_tags_header() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver({"topic": "foo"}, handler)
    driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority="high",
        extras={"ntfy_tags": ["warning", "rotating_light"]},
    )

    assert captured["headers"]["tags"] == "warning,rotating_light"


def test_no_extras_omits_tags_header() -> None:
    captured: dict[str, Any] = {}

    def handler(request: httpx.Request) -> httpx.Response:
        captured["headers"] = dict(request.headers)
        return _ok_response(request)

    driver = _make_driver({"topic": "foo"}, handler)
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert "tags" not in captured["headers"]


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


def test_403_response_raises_delivery_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(403, json={"error": "forbidden"})

    driver = _make_driver(
        {"topic": "foo", "access_token": "xyz"},
        handler,
    )
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert "403" in str(excinfo.value)


def test_timeout_raises_delivery_error() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("simulated timeout", request=request)

    driver = _make_driver({"topic": "foo"}, handler)
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert "timed out" in str(excinfo.value).lower()


def test_bearer_token_never_appears_in_403_exception() -> None:
    token = "super-secret-token-abc"

    def handler(request: httpx.Request) -> httpx.Response:
        # Attacker-controlled server could echo the token back; make sure we
        # still redact it before surfacing the error.
        return httpx.Response(
            403,
            text=f"forbidden: token {token} is revoked",
        )

    driver = _make_driver(
        {"topic": "foo", "access_token": token},
        handler,
    )
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert token not in str(excinfo.value)
    assert "[redacted]" in str(excinfo.value)


def test_non_json_success_response_still_ok_with_no_provider_id() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, text="not json")

    driver = _make_driver({"topic": "foo"}, handler)
    result = driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority="normal",
    )

    assert result.ok is True
    assert result.provider_id is None


def test_success_response_id_field_parsed() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, content=json.dumps({"id": "xyz789"}).encode("utf-8"))

    driver = _make_driver({"topic": "foo"}, handler)
    result = driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority="normal",
    )

    assert result.provider_id == "xyz789"


# ---------------------------------------------------------------------------
# httpx client lifecycle (issue #14 E5)
# ---------------------------------------------------------------------------


def test_client_closed_when_request_raises_inside_with_block() -> None:
    """Regression for issue #14 E5: client must close even on transport error."""
    instances: list[httpx.Client] = []

    def boom(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")

    driver = NtfyDriver({"topic": "foo"})
    transport = httpx.MockTransport(boom)

    def _client() -> httpx.Client:
        c = httpx.Client(transport=transport, timeout=10.0)
        instances.append(c)
        return c

    driver._client = _client  # type: ignore[method-assign]

    with pytest.raises(DriverDeliveryError):
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert instances, "expected _client() to have been invoked"
    for c in instances:
        assert c.is_closed, "httpx.Client leaked: not closed after send()"


def test_no_client_created_when_header_construction_raises() -> None:
    """Regression for issue #14 E5: ``_client()`` must run *inside* the with-block.

    A bad ``ntfy_tags`` value triggers ``DriverDeliveryError`` before any HTTP
    work; ``_client()`` must not have been called.
    """
    instances: list[httpx.Client] = []

    driver = NtfyDriver({"topic": "foo"})

    def _client() -> httpx.Client:
        c = httpx.Client(timeout=10.0)
        instances.append(c)
        return c

    driver._client = _client  # type: ignore[method-assign]

    with pytest.raises(DriverDeliveryError, match="ntfy_tags"):
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
            extras={"ntfy_tags": "not-a-list"},
        )

    assert instances == [], "client must not be created before the with-block"
