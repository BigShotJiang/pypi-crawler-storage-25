"""Tests for the session-authed drop action endpoints.

Covers ``POST /d/{short_id}/pin`` and ``POST /d/{short_id}/archive``:

* Unauth'd -> 303 to ``/login``.
* Auth'd plain POST -> 303 back to the drop page, timestamp set.
* Auth'd toggle twice -> timestamp cleared on the second POST.
* Auth'd HTMX POST -> 200 with a rendered button partial.
* Unknown / soft-deleted short_id -> 404.

Agent B owns ``_action_button.html``; if the template isn't in place yet
we drop a minimal stub at the standard location (guarded by
``os.path.exists``) so the HTMX path can be exercised.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop
from agentdrop.web import templates_dir
from agentdrop.web.session import Admin, require_session

from .conftest import fetch_csrf

_ACTION_BUTTON_PATH = Path(templates_dir) / "_action_button.html"

# Minimal stub body used only if Agent B hasn't landed the real partial
# yet. Intentionally boring: just the bare minimum so the route's
# TemplateResponse renders, and a visible "pin"/"archive" token so the
# content-sniff assertion in the HTMX test has something to land on.
_STUB_BODY = (
    '<button data-kind="{{ kind }}" data-short-id="{{ drop.short_id }}">{{ kind }}</button>\n'
)


@pytest.fixture(autouse=True)
def _ensure_action_button_template() -> Iterator[None]:
    """Stub ``_action_button.html`` if Agent B hasn't written it yet.

    We only create the file when it doesn't exist — never overwrite a
    real partial. Clean up after ourselves so the stub doesn't linger
    past the test run.
    """
    created = False
    if not os.path.exists(_ACTION_BUTTON_PATH):
        _ACTION_BUTTON_PATH.write_text(_STUB_BODY, encoding="utf-8")
        created = True
    try:
        yield
    finally:
        if created and os.path.exists(_ACTION_BUTTON_PATH):
            os.remove(_ACTION_BUTTON_PATH)


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Test client with a fresh SQLite DB and session auth overridden.

    ``require_session`` returns a sentinel ``Admin`` so we don't have to
    drive the real login flow. The unauth test clears the override for
    its single case.
    """
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _make_drop(**overrides: object) -> Drop:
    """Persist a Drop and return the detached instance."""
    fields: dict[str, object] = {
        "short_id": "actiondrop00000000000000",
        "title": "A drop to act on",
        "body": "Summary.",
        "content_md": "# hello",
        "source": "weekly-scan",
    }
    fields.update(overrides)

    session = SessionLocal(bind=get_engine())
    try:
        drop = Drop(**fields)
        session.add(drop)
        session.commit()
        session.refresh(drop)
        session.expunge(drop)
        return drop
    finally:
        session.close()


def _reload(short_id: str) -> Drop:
    session = SessionLocal(bind=get_engine())
    try:
        drop = session.query(Drop).filter(Drop.short_id == short_id).one()
        session.expunge(drop)
        return drop
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_pin_without_session_redirects_to_login(
    client: TestClient,
) -> None:
    """Dropping the session override -> 303 to /login with ?next=."""
    _make_drop()
    # Remove the auto-applied override for this one case.
    app.dependency_overrides.pop(require_session, None)
    try:
        resp = client.post(
            "/d/actiondrop00000000000000/pin",
            follow_redirects=False,
        )
    finally:
        # Restore for any subsequent tests sharing the module state.
        app.dependency_overrides[require_session] = lambda: Admin()

    assert resp.status_code == 303
    assert resp.headers["location"].startswith("/login")
    assert "next=" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Pin toggle (plain form POST)
# ---------------------------------------------------------------------------


def test_pin_authed_plain_post_sets_pinned_at_and_redirects(
    client: TestClient,
) -> None:
    _make_drop()
    before = _reload("actiondrop00000000000000")
    assert before.pinned_at is None

    resp = client.post(
        "/d/actiondrop00000000000000/pin",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert resp.headers["location"] == "/d/actiondrop00000000000000"

    after = _reload("actiondrop00000000000000")
    assert after.pinned_at is not None


def test_pin_twice_toggles_off(client: TestClient) -> None:
    _make_drop()
    token = fetch_csrf(client)

    r1 = client.post(
        "/d/actiondrop00000000000000/pin",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert r1.status_code == 303
    assert _reload("actiondrop00000000000000").pinned_at is not None

    r2 = client.post(
        "/d/actiondrop00000000000000/pin",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert r2.status_code == 303
    assert _reload("actiondrop00000000000000").pinned_at is None


# ---------------------------------------------------------------------------
# Pin toggle (HTMX)
# ---------------------------------------------------------------------------


def test_pin_htmx_returns_rendered_button(client: TestClient) -> None:
    _make_drop()
    resp = client.post(
        "/d/actiondrop00000000000000/pin",
        headers={"HX-Request": "true", "X-CSRF-Token": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    # The body is a re-rendered action button. Agent B owns the markup,
    # so we only assert something pin-related is present — stub or real.
    assert "pin" in resp.text.lower()
    assert _reload("actiondrop00000000000000").pinned_at is not None


# ---------------------------------------------------------------------------
# Archive toggle
# ---------------------------------------------------------------------------


def test_archive_authed_plain_post_sets_archived_at(client: TestClient) -> None:
    _make_drop()
    assert _reload("actiondrop00000000000000").archived_at is None

    resp = client.post(
        "/d/actiondrop00000000000000/archive",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert resp.headers["location"] == "/d/actiondrop00000000000000"

    assert _reload("actiondrop00000000000000").archived_at is not None


def test_archive_twice_toggles_off(client: TestClient) -> None:
    _make_drop()
    token = fetch_csrf(client)

    client.post(
        "/d/actiondrop00000000000000/archive",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert _reload("actiondrop00000000000000").archived_at is not None
    client.post(
        "/d/actiondrop00000000000000/archive",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert _reload("actiondrop00000000000000").archived_at is None


def test_archive_htmx_returns_rendered_button(client: TestClient) -> None:
    _make_drop()
    resp = client.post(
        "/d/actiondrop00000000000000/archive",
        headers={"HX-Request": "true", "X-CSRF-Token": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/html")
    assert "archive" in resp.text.lower()


# ---------------------------------------------------------------------------
# 404 paths
# ---------------------------------------------------------------------------


def test_pin_unknown_short_id_404(client: TestClient) -> None:
    resp = client.post(
        "/d/doesnotexist0000000000aa/pin",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 404


def test_archive_unknown_short_id_404(client: TestClient) -> None:
    resp = client.post(
        "/d/doesnotexist0000000000aa/archive",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 404


def test_pin_soft_deleted_404(client: TestClient) -> None:
    _make_drop(
        short_id="softdeleted0000000000000",
        soft_deleted_at=datetime.now(UTC),
    )
    resp = client.post(
        "/d/softdeleted0000000000000/pin",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 404


def test_archive_soft_deleted_404(client: TestClient) -> None:
    _make_drop(
        short_id="softdeleted0000000000000",
        soft_deleted_at=datetime.now(UTC),
    )
    resp = client.post(
        "/d/softdeleted0000000000000/archive",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 404
