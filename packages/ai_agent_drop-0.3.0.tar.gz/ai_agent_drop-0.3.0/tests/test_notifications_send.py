"""Unit tests for :mod:`agentdrop.notifications.send`.

The point of this module is the failure-mapping table: each exception
class from the driver layer turns into a specific, user-safe warning
string and (since issue #14 E2) appends a ``notification_failed`` event
to the ``events`` table.

We isolate the test from real HTTP by monkeypatching ``resolve_channel``
(so we don't need a populated ``channels`` row) and ``get_driver`` (so
no network). We **do** use a real SQLite session so we can assert on
the events that were written.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.models import Event
from agentdrop.models.drop import Drop
from agentdrop.notifications import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
)
from agentdrop.notifications import send as send_mod


@pytest.fixture
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Session]:
    """Real SQLite session bound to an isolated DB file.

    The drop is persisted before ``send_drop_notification`` runs so the
    FK from ``events.drop_id -> drops.id`` is satisfied.
    """
    db_path = tmp_path / "send.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())
    SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        get_engine.cache_clear()
        get_settings.cache_clear()


def _persist_drop(db: Session) -> Drop:
    """Build + commit a drop so events can FK to it."""
    drop = Drop(
        title="Alert",
        body="Two items need attention",
        content_md="# hi",
        priority="normal",
    )
    db.add(drop)
    db.commit()
    db.refresh(drop)
    return drop


def _events_for(db: Session, drop_id: str) -> list[Event]:
    return (
        db.query(Event)
        .filter(Event.drop_id == drop_id, Event.kind == "notification_failed")
        .order_by(Event.created_at)
        .all()
    )


class _StubDriver(Driver):
    """Minimal driver whose behaviour is injected per-test."""

    driver_name = "stub"

    def __init__(self, send_impl: Any) -> None:
        super().__init__({})
        self._send_impl = send_impl

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: str,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        return self._send_impl(title=title, body=body, url=url, priority=priority)


def _install_driver(monkeypatch: pytest.MonkeyPatch, send_impl: Any) -> None:
    """Make ``resolve_channel`` return a stub driver spec and stub the factory."""
    monkeypatch.setattr(send_mod, "resolve_channel", lambda _db, **_kw: ("stub", {}))
    monkeypatch.setattr(send_mod, "get_driver", lambda name, config: _StubDriver(send_impl))


# ---------------------------------------------------------------------------
# Happy path + no-channel branch
# ---------------------------------------------------------------------------


def test_happy_path_returns_no_warnings(db: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    def ok_send(**_: Any) -> DeliveryResult:
        return DeliveryResult(ok=True, driver="stub", provider_id="abc")

    _install_driver(monkeypatch, ok_send)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert warnings == []
    # Happy path must not write any failure event.
    assert _events_for(db, drop.id) == []


def test_no_channel_configured(db: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(send_mod, "resolve_channel", lambda _db, **_kw: None)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert warnings == ["no channel configured"]
    # No-channel-configured is intentionally NOT recorded as a
    # notification_failed event — there's no driver to attribute it to.
    assert _events_for(db, drop.id) == []


# ---------------------------------------------------------------------------
# Failure paths — warning text + recorded events
# ---------------------------------------------------------------------------


def test_driver_config_error_yields_misconfigured_warning_and_event(
    db: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    def bad_config(**_: Any) -> DeliveryResult:
        raise DriverConfigError("missing token")

    _install_driver(monkeypatch, bad_config)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert len(warnings) == 1
    assert warnings[0].startswith("channel misconfigured:")
    assert "missing token" in warnings[0]

    events = _events_for(db, drop.id)
    assert len(events) == 1
    detail = events[0].detail_json
    assert detail["driver"] == "stub"
    assert detail["error_class"] == "DriverConfigError"
    assert "missing token" in detail["message"]


def test_driver_delivery_error_yields_delivery_failed_warning_and_event(
    db: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    def delivery_fail(**_: Any) -> DeliveryResult:
        raise DriverDeliveryError("HTTP 503")

    _install_driver(monkeypatch, delivery_fail)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert len(warnings) == 1
    assert warnings[0].startswith("notification delivery failed:")
    assert "HTTP 503" in warnings[0]

    events = _events_for(db, drop.id)
    assert len(events) == 1
    detail = events[0].detail_json
    assert detail["driver"] == "stub"
    assert detail["error_class"] == "DriverDeliveryError"
    assert "HTTP 503" in detail["message"]


def test_unexpected_exception_yields_crashed_warning_and_event(
    db: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    def boom(**_: Any) -> DeliveryResult:
        raise RuntimeError("kaboom")

    _install_driver(monkeypatch, boom)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert warnings == ["notification driver crashed"]

    events = _events_for(db, drop.id)
    assert len(events) == 1
    detail = events[0].detail_json
    assert detail["driver"] == "stub"
    assert detail["error_class"] == "RuntimeError"
    # The raw "kaboom" string is *not* surfaced — the message is a
    # canned "driver crashed during send" so a buggy driver can't smuggle
    # arbitrary text into the events row.
    assert "kaboom" not in detail["message"]


def test_driver_init_failure_records_event(db: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    """Failure during ``get_driver()`` itself also writes a failure event."""

    def bad_factory(_name: str, _config: dict[str, Any]) -> Driver:
        raise DriverConfigError("bad config at init")

    monkeypatch.setattr(send_mod, "resolve_channel", lambda _db, **_kw: ("stub", {}))
    monkeypatch.setattr(send_mod, "get_driver", bad_factory)

    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert warnings[0].startswith("channel misconfigured:")

    events = _events_for(db, drop.id)
    assert len(events) == 1
    assert events[0].detail_json["error_class"] == "DriverConfigError"
    assert events[0].detail_json["driver"] == "stub"


def test_falsy_result_records_event(db: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    """A driver returning ``ok=False`` is treated as a delivery failure."""

    def half_done(**_: Any) -> DeliveryResult:
        return DeliveryResult(ok=False, driver="stub", detail="upstream said no")

    _install_driver(monkeypatch, half_done)
    drop = _persist_drop(db)
    warnings = send_mod.send_drop_notification(drop, "https://drop.test", db)
    assert warnings[0].startswith("notification delivery failed:")

    events = _events_for(db, drop.id)
    assert len(events) == 1
    assert events[0].detail_json["error_class"] == "DriverReportedFailure"
    assert "upstream said no" in events[0].detail_json["message"]


# ---------------------------------------------------------------------------
# Secret hygiene
# ---------------------------------------------------------------------------


def test_event_detail_does_not_carry_full_url_or_token(
    db: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The driver's redacted error string is what lands in detail_json.

    Drivers redact their own credentials before raising. We assert here
    that the events row only contains the driver-shaped error text,
    and that obvious secret-shaped fragments don't appear in any other
    detail_json key (driver / error_class / message are the only keys).
    """

    def delivery_fail(**_: Any) -> DeliveryResult:
        # A driver-redacted error message: never the raw token.
        raise DriverDeliveryError("ntfy: HTTP 401 from upstream: [redacted]")

    _install_driver(monkeypatch, delivery_fail)
    drop = _persist_drop(db)
    send_mod.send_drop_notification(drop, "https://drop.test", db)

    events = _events_for(db, drop.id)
    assert len(events) == 1
    detail = events[0].detail_json
    # Schema is locked: the only keys are these three.
    assert set(detail.keys()) == {"driver", "error_class", "message"}
    # The full drop URL is not interesting and is not stored.
    assert "https://drop.test/d/" not in detail["message"]
    # The driver's redaction marker is preserved (sanity).
    assert "[redacted]" in detail["message"]


def test_event_detail_message_capped(db: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    """Very long error strings are truncated before persisting."""

    def long_fail(**_: Any) -> DeliveryResult:
        raise DriverDeliveryError("X" * 5000)

    _install_driver(monkeypatch, long_fail)
    drop = _persist_drop(db)
    send_mod.send_drop_notification(drop, "https://drop.test", db)

    events = _events_for(db, drop.id)
    assert len(events) == 1
    # Cap is 500 chars — much smaller than the 5kB raised string.
    assert len(events[0].detail_json["message"]) <= 500
