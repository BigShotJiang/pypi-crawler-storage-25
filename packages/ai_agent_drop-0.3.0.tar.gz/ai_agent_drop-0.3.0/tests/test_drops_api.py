"""End-to-end tests for the drops HTTP API.

Sidesteps Alembic (``Base.metadata.create_all``) and the real API-key check
(dep override on ``require_api_key``) so the tests exercise routing, schemas,
and DB behaviour in isolation.
"""

from __future__ import annotations

import time
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.auth import _get_expected_hash, require_api_key
from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    # Rebuild caches so the engine + settings pick up the patched env.
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_expected_hash.cache_clear()

    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_api_key] = lambda: None
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_api_key, None)
        get_engine.cache_clear()
        get_settings.cache_clear()
        _get_expected_hash.cache_clear()


def _valid_payload(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "title": "Weekly scan",
        "body": "Three items flagged",
        "content": "# Heading\n\nSome markdown body.",
    }
    payload.update(overrides)
    return payload


def test_create_drop_returns_201_and_expected_shape(client: TestClient) -> None:
    resp = client.post("/api/v1/drops", json=_valid_payload(source="weekly-scan"))
    assert resp.status_code == 201, resp.text
    data = resp.json()

    assert data["id"].startswith("drp_")
    assert data["url"].startswith("https://drop.test/d/")
    # Short id slug is exactly 24 chars.
    slug = data["url"].rsplit("/", 1)[-1]
    assert len(slug) == 24
    assert "created_at" in data
    assert data["warnings"] == ["no channel configured"]


@pytest.mark.parametrize(
    "mutation",
    [
        pytest.param({"title": None}, id="missing-title"),
        pytest.param({"body": None}, id="missing-body"),
        pytest.param({"content": ""}, id="empty-content"),
        pytest.param({"title": "x" * 251}, id="title-too-long"),
        pytest.param({"body": "x" * 1025}, id="body-too-long"),
    ],
)
def test_create_drop_rejects_invalid_payloads(
    client: TestClient, mutation: dict[str, object]
) -> None:
    payload = _valid_payload()
    for k, v in mutation.items():
        if v is None:
            payload.pop(k, None)
        else:
            payload[k] = v
    resp = client.post("/api/v1/drops", json=payload)
    assert resp.status_code == 422, resp.text


def test_create_drop_rejects_unknown_fields(client: TestClient) -> None:
    resp = client.post("/api/v1/drops", json=_valid_payload(wat="nope"))
    assert resp.status_code == 422


def test_create_drop_with_unknown_channel_warns(client: TestClient) -> None:
    resp = client.post("/api/v1/drops", json=_valid_payload(channel="nope"))
    assert resp.status_code == 201
    assert "channel 'nope' not found" in resp.json()["warnings"]


def test_create_drop_fires_configured_channel(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    """With a default DB channel, the handler hands off to the driver.

    We monkeypatch ``resolve_channel`` (so we don't need to seed a real
    channel row) and ``get_driver`` (so no HTTP or registry lookup
    happens) — the fake driver just records what it was asked to send.
    That lets us assert the handler wires ``title`` / ``body`` / a
    short-id-bearing URL through verbatim, without pulling any real
    notification backend into the test.
    """
    from agentdrop.notifications import DeliveryResult, Driver
    from agentdrop.notifications import send as send_mod

    calls: list[dict[str, object]] = []

    class RecordingDriver(Driver):
        driver_name = "fake"

        def send(
            self,
            *,
            title: str,
            body: str,
            url: str,
            priority: str,
            extras: dict[str, object] | None = None,
        ) -> DeliveryResult:
            calls.append({"title": title, "body": body, "url": url, "priority": priority})
            return DeliveryResult(ok=True, driver=self.driver_name, provider_id="rec-1")

    monkeypatch.setattr(send_mod, "resolve_channel", lambda _db, **_kw: ("fake", {}))
    monkeypatch.setattr(send_mod, "get_driver", lambda name, config: RecordingDriver(config))

    resp = client.post("/api/v1/drops", json=_valid_payload(title="Hello", body="World"))
    assert resp.status_code == 201, resp.text
    assert resp.json()["warnings"] == []

    assert len(calls) == 1
    (call,) = calls
    assert call["title"] == "Hello"
    assert call["body"] == "World"
    assert isinstance(call["url"], str)
    assert call["url"].startswith("https://drop.test/d/")
    # URL slug should match the one the API returned.
    expected_slug = resp.json()["url"].rsplit("/", 1)[-1]
    assert call["url"].endswith(expected_slug)


def test_list_drops_returns_newest_first(client: TestClient) -> None:
    # SQLite's server-side ``CURRENT_TIMESTAMP`` is second-granularity, so
    # burn a second between inserts to guarantee strict ordering — when the
    # timestamps tie, id-DESC is the tiebreaker and those are random slugs.
    for i in range(3):
        resp = client.post("/api/v1/drops", json=_valid_payload(title=f"Drop {i}"))
        assert resp.status_code == 201
        if i < 2:
            time.sleep(1.1)

    resp = client.get("/api/v1/drops")
    assert resp.status_code == 200
    data = resp.json()
    assert data["count"] == 3
    titles = [item["title"] for item in data["items"]]
    assert titles == ["Drop 2", "Drop 1", "Drop 0"]
    # All list items carry a short summary derived from body.
    assert all(len(item["summary"]) <= 200 for item in data["items"])


def test_list_drops_filters_by_source(client: TestClient) -> None:
    client.post("/api/v1/drops", json=_valid_payload(source="alpha", title="A"))
    client.post("/api/v1/drops", json=_valid_payload(source="beta", title="B"))
    client.post("/api/v1/drops", json=_valid_payload(source="alpha", title="A2"))

    resp = client.get("/api/v1/drops", params={"source": "alpha"})
    assert resp.status_code == 200
    titles = {item["title"] for item in resp.json()["items"]}
    assert titles == {"A", "A2"}


def test_get_drop_roundtrip_and_404(client: TestClient) -> None:
    created = client.post("/api/v1/drops", json=_valid_payload()).json()
    drop_id = created["id"]

    resp = client.get(f"/api/v1/drops/{drop_id}")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == drop_id
    assert data["state"] == "unread"
    assert data["content"].startswith("# Heading")

    missing = client.get("/api/v1/drops/drp_doesnotexist")
    assert missing.status_code == 404


def test_patch_pin_then_unpin(client: TestClient) -> None:
    drop_id = client.post("/api/v1/drops", json=_valid_payload()).json()["id"]

    pinned = client.patch(f"/api/v1/drops/{drop_id}", json={"pinned": True})
    assert pinned.status_code == 200
    assert pinned.json()["pinned_at"] is not None
    assert pinned.json()["state"] == "pinned"

    unpinned = client.patch(f"/api/v1/drops/{drop_id}", json={"pinned": False})
    assert unpinned.status_code == 200
    assert unpinned.json()["pinned_at"] is None
    assert unpinned.json()["state"] == "unread"


def test_create_drop_returns_429_when_rate_limit_exceeded(
    client: TestClient,
) -> None:
    """The per-API-key bucket on POST /api/v1/drops returns 429 + Retry-After."""
    from agentdrop.web import rate_limit as rl

    # ``require_api_key`` is dep-overridden to ``lambda: None`` in this
    # fixture, so the route's key_builder falls back to ``ip:<host>``.
    # TestClient sends from ``testclient`` by default.
    bucket_key = "ip:testclient"
    limit = get_settings().drops_rate_limit_per_hour
    for _ in range(limit):
        rl.record_attempt("drops_post", bucket_key)

    resp = client.post("/api/v1/drops", json=_valid_payload())
    assert resp.status_code == 429
    assert "retry-after" in {h.lower() for h in resp.headers}
    retry_after = int(resp.headers["retry-after"])
    assert 1 <= retry_after <= 3600


def test_delete_soft_deletes_and_hides_from_list(client: TestClient) -> None:
    drop_id = client.post("/api/v1/drops", json=_valid_payload()).json()["id"]

    resp = client.delete(f"/api/v1/drops/{drop_id}")
    assert resp.status_code == 200
    assert resp.json()["id"] == drop_id
    assert resp.json()["soft_deleted_at"] is not None

    # Subsequent GET is 404; listing excludes it.
    assert client.get(f"/api/v1/drops/{drop_id}").status_code == 404
    listing = client.get("/api/v1/drops").json()
    assert listing["count"] == 0
    assert drop_id not in [i["id"] for i in listing["items"]]


def test_delete_clears_content_synchronously(client: TestClient) -> None:
    """DELETE clears ``content_md`` and ``body`` in-line, not on the next sweep.

    Mirrors the retention sweep's soft-delete phase (PRD §8.4 + F2 of
    issue #14). Title is preserved as audit metadata.
    """
    from sqlalchemy import select
    from sqlalchemy.orm import Session

    from agentdrop.db.session import get_engine
    from agentdrop.models import Drop

    payload = _valid_payload(
        title="Audit me",
        body="this should be wiped",
        content="# wipe me too\n\nlong markdown here",
    )
    drop_id = client.post("/api/v1/drops", json=payload).json()["id"]

    resp = client.delete(f"/api/v1/drops/{drop_id}")
    assert resp.status_code == 200

    # Inspect the row directly: soft-deleted, content-cleared, title kept.
    with Session(get_engine()) as session:
        row = session.execute(select(Drop).where(Drop.id == drop_id)).scalar_one()
        assert row.soft_deleted_at is not None
        assert row.content_md == ""
        assert row.body == ""
        assert row.title == "Audit me"
