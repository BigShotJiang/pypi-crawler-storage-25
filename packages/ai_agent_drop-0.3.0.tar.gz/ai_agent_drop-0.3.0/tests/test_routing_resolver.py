"""Tests for :func:`agentdrop.notifications.resolver.resolve_channel`.

Covers the specificity bucketing documented in the resolver:

* both source and priority explicit → most specific (bucket 0)
* exactly one wildcard → bucket 1
* both wildcards → bucket 2

Within a bucket ties break on ``order`` ASC then ``created_at`` ASC.

Also exercises the no-rules fallback path (default channel → env → None)
to make sure the old :func:`resolve_default_channel` behaviour is
preserved under the new signature.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import event, select
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.models import Channel, RoutingRule
from agentdrop.notifications.resolver import (
    resolve_channel,
    resolve_default_channel,
)


@pytest.fixture
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Session]:
    """Fresh SQLite DB + session with FK enforcement enabled."""
    db_path = tmp_path / "routing.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()

    engine = get_engine()

    # The cached engine already installs a connect listener for pragmas,
    # but rebind explicitly here in case tests rebuild the engine. This
    # keeps FK cascade assertions honest.
    @event.listens_for(engine, "connect")
    def _fk_on(dbapi_connection, _record):  # type: ignore[no-untyped-def]
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        get_engine.cache_clear()
        get_settings.cache_clear()


def _channel(
    db: Session,
    *,
    name: str,
    driver: str = "ntfy",
    config: dict | None = None,
    is_default: bool = False,
) -> Channel:
    ch = Channel(
        name=name,
        driver=driver,
        config_json=config or {"topic": f"topic-{name}"},
        is_default=is_default,
    )
    db.add(ch)
    db.commit()
    db.refresh(ch)
    return ch


def _rule(
    db: Session,
    *,
    source_pattern: str,
    priority_pattern: str,
    channel: Channel,
    order: int = 100,
    created_at: datetime | None = None,
) -> RoutingRule:
    rule = RoutingRule(
        source_pattern=source_pattern,
        priority_pattern=priority_pattern,
        channel_id=channel.id,
        order=order,
    )
    db.add(rule)
    db.flush()
    if created_at is not None:
        rule.created_at = created_at
    db.commit()
    db.refresh(rule)
    return rule


# ---------------------------------------------------------------------------
# No-rules fallback paths
# ---------------------------------------------------------------------------


def test_no_rules_no_channels_no_env_returns_none(db: Session) -> None:
    assert resolve_channel(db, source="thinkr", priority="urgent") is None
    # The backward-compat alias also returns None.
    assert resolve_default_channel(db) is None


def test_no_rules_default_channel_wins(db: Session) -> None:
    _channel(
        db, name="primary", driver="pushover", config={"token": "t", "user": "u"}, is_default=True
    )
    _channel(db, name="secondary", driver="ntfy", config={"topic": "x"})

    resolved = resolve_channel(db, source="thinkr", priority="urgent")
    assert resolved == ("pushover", {"token": "t", "user": "u"})


def test_no_rules_no_channels_returns_none(db: Session) -> None:
    resolved = resolve_channel(db, source="thinkr", priority="normal")
    assert resolved is None


# ---------------------------------------------------------------------------
# Routing-rule matching
# ---------------------------------------------------------------------------


def test_exact_match_rule_picks_its_channel(db: Session) -> None:
    _channel(db, name="default", is_default=True, config={"topic": "default"})
    target_ch = _channel(db, name="target", driver="pushover", config={"token": "x", "user": "y"})

    _rule(db, source_pattern="thinkr", priority_pattern="normal", channel=target_ch)

    resolved = resolve_channel(db, source="thinkr", priority="normal")
    assert resolved == ("pushover", {"token": "x", "user": "y"})

    # Source that doesn't match still resolves to the default.
    other = resolve_channel(db, source="other", priority="normal")
    assert other is not None
    assert other[1] == {"topic": "default"}


def test_source_wildcard_rule_matches_any_source(db: Session) -> None:
    # Two channels so the no-rule fallback is genuinely ambiguous — otherwise
    # a single channel would be auto-picked as the default.
    target_ch = _channel(db, name="target", config={"topic": "urgent-bucket"})
    _channel(db, name="filler", config={"topic": "filler"})

    _rule(db, source_pattern="*", priority_pattern="urgent", channel=target_ch)

    for source in ("thinkr", "cron", None, "anything-else"):
        resolved = resolve_channel(db, source=source, priority="urgent")
        assert resolved is not None
        assert resolved[1] == {"topic": "urgent-bucket"}

    # Wrong priority → no rule match, multiple channels, no env → None.
    assert resolve_channel(db, source="thinkr", priority="low") is None


def test_priority_wildcard_rule_matches_any_priority(db: Session) -> None:
    # Same reasoning as the source-wildcard test: two channels → no ambient
    # "single-channel becomes default" shortcut.
    target_ch = _channel(db, name="target", config={"topic": "thinkr-bucket"})
    _channel(db, name="filler", config={"topic": "filler"})

    _rule(db, source_pattern="thinkr", priority_pattern="*", channel=target_ch)

    for priority in ("low", "normal", "high", "urgent"):
        resolved = resolve_channel(db, source="thinkr", priority=priority)
        assert resolved is not None
        assert resolved[1] == {"topic": "thinkr-bucket"}

    assert resolve_channel(db, source="other", priority="urgent") is None


def test_specific_rule_beats_catch_all(db: Session) -> None:
    catchall_ch = _channel(db, name="catch", config={"topic": "catchall"})
    specific_ch = _channel(db, name="specific", config={"topic": "thinkr-urgent"})

    # Catch-all first (lower order!) must still lose to the more-specific rule.
    _rule(db, source_pattern="*", priority_pattern="*", channel=catchall_ch, order=1)
    _rule(db, source_pattern="thinkr", priority_pattern="urgent", channel=specific_ch, order=100)

    resolved = resolve_channel(db, source="thinkr", priority="urgent")
    assert resolved is not None
    assert resolved[1] == {"topic": "thinkr-urgent"}

    # Non-matching drop falls to the catch-all.
    other = resolve_channel(db, source="cron", priority="low")
    assert other is not None
    assert other[1] == {"topic": "catchall"}


def test_one_wildcard_beats_both_wildcards(db: Session) -> None:
    catchall_ch = _channel(db, name="catch", config={"topic": "catchall"})
    source_only_ch = _channel(db, name="source", config={"topic": "thinkr-any"})

    _rule(db, source_pattern="*", priority_pattern="*", channel=catchall_ch, order=1)
    _rule(db, source_pattern="thinkr", priority_pattern="*", channel=source_only_ch, order=100)

    resolved = resolve_channel(db, source="thinkr", priority="low")
    assert resolved is not None
    assert resolved[1] == {"topic": "thinkr-any"}


def test_same_specificity_lower_order_wins(db: Session) -> None:
    cheap_ch = _channel(db, name="cheap", config={"topic": "cheap"})
    pricey_ch = _channel(db, name="pricey", config={"topic": "pricey"})

    _rule(db, source_pattern="thinkr", priority_pattern="urgent", channel=pricey_ch, order=200)
    _rule(db, source_pattern="thinkr", priority_pattern="urgent", channel=cheap_ch, order=10)

    resolved = resolve_channel(db, source="thinkr", priority="urgent")
    assert resolved is not None
    assert resolved[1] == {"topic": "cheap"}


def test_same_order_older_created_at_wins(db: Session) -> None:
    older_ch = _channel(db, name="older", config={"topic": "older"})
    newer_ch = _channel(db, name="newer", config={"topic": "newer"})

    now = datetime.now(UTC)
    _rule(
        db,
        source_pattern="thinkr",
        priority_pattern="urgent",
        channel=newer_ch,
        order=50,
        created_at=now,
    )
    _rule(
        db,
        source_pattern="thinkr",
        priority_pattern="urgent",
        channel=older_ch,
        order=50,
        created_at=now - timedelta(seconds=30),
    )

    resolved = resolve_channel(db, source="thinkr", priority="urgent")
    assert resolved is not None
    assert resolved[1] == {"topic": "older"}


# ---------------------------------------------------------------------------
# Integrity: channel delete cascades to rules
# ---------------------------------------------------------------------------


def test_channel_delete_cascades_to_rules(db: Session) -> None:
    target_ch = _channel(db, name="target", config={"topic": "x"})
    _rule(db, source_pattern="thinkr", priority_pattern="urgent", channel=target_ch)

    assert db.execute(select(RoutingRule)).scalars().all() != []

    db.delete(target_ch)
    db.commit()

    assert db.execute(select(RoutingRule)).scalars().all() == []


def test_resolve_default_channel_alias_delegates(db: Session) -> None:
    """The legacy alias has no source/priority, so only a catch-all rule
    could match — here the only rule is priority-specific and fails to
    match ``priority="normal"``, so we fall through to the default channel."""
    target_ch = _channel(db, name="target", config={"topic": "x"})
    _rule(db, source_pattern="thinkr", priority_pattern="urgent", channel=target_ch)

    _channel(
        db, name="default", driver="pushover", config={"token": "t", "user": "u"}, is_default=True
    )

    resolved = resolve_default_channel(db)
    assert resolved == ("pushover", {"token": "t", "user": "u"})
