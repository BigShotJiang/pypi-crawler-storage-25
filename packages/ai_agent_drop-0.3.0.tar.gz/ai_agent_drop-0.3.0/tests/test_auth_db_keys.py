"""Tests for the DB-backed side of Bearer-token auth.

The env-key path is covered in ``test_auth.py`` and must still pass
untouched (M2 invariants). These tests exercise the additional path:

* DB row created directly (simulating the UI create flow) → accepted.
* Revoked row → rejected with 401.
* ``last_used_at`` bumps on every successful request.
* Timestamp bump is best-effort: a commit failure does not fail auth.
* Neither env nor any DB row configured → 503.
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.exc import OperationalError

from agentdrop.auth import _get_expected_hash, hash_key, require_api_key
from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.models.api_key import ApiKey

TEST_TOKEN = "agdr_TESTTOKEN0123456789abcdefghij01234567"


def _build_app() -> FastAPI:
    """Minimal app mounting one protected route — no middleware needed."""
    app = FastAPI()

    @app.get("/protected", dependencies=[Depends(require_api_key)])
    def protected() -> dict[str, str]:
        return {"ok": "yes"}

    return app


@pytest.fixture
def db_only_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Client with no env key, backed by a real SQLite DB.

    Authoritative source of keys is the ``api_keys`` table. Each test
    seeds whatever rows it needs via ``_insert_key``.
    """
    db_path = tmp_path / "apikeys.db"
    monkeypatch.delenv("AGENTDROP_API_KEY", raising=False)
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_expected_hash.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        get_engine.cache_clear()
        _get_expected_hash.cache_clear()


@pytest.fixture
def env_and_db_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Client with BOTH an env key AND a DB-backed key available."""
    db_path = tmp_path / "apikeys.db"
    monkeypatch.setenv("AGENTDROP_API_KEY", "env-fallback-token")
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_expected_hash.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        get_engine.cache_clear()
        _get_expected_hash.cache_clear()


@pytest.fixture
def no_source_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Client with no env key and no DB rows — 'unconfigured' state."""
    db_path = tmp_path / "apikeys.db"
    monkeypatch.delenv("AGENTDROP_API_KEY", raising=False)
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_expected_hash.cache_clear()

    # Table exists but holds nothing.
    Base.metadata.create_all(get_engine())

    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        get_engine.cache_clear()
        _get_expected_hash.cache_clear()


def _insert_key(token: str, *, label: str = "test", revoked: bool = False) -> str:
    """Persist an ApiKey row for ``token`` and return its id."""
    session = SessionLocal(bind=get_engine())
    try:
        row = ApiKey(key_hash=hash_key(token), label=label)
        if revoked:
            row.revoked_at = datetime.now(UTC)
        session.add(row)
        session.commit()
        session.refresh(row)
        return row.id
    finally:
        session.close()


def _reload_key(key_id: str) -> ApiKey | None:
    session = SessionLocal(bind=get_engine())
    try:
        return session.execute(select(ApiKey).where(ApiKey.id == key_id)).scalar_one_or_none()
    finally:
        session.close()


# ---------------------------------------------------------------------------
# DB path: acceptance + rejection
# ---------------------------------------------------------------------------


def test_db_key_accepted(db_only_client: TestClient) -> None:
    _insert_key(TEST_TOKEN)
    resp = db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    assert resp.status_code == 200
    assert resp.json() == {"ok": "yes"}


def test_db_revoked_key_rejected(db_only_client: TestClient) -> None:
    _insert_key(TEST_TOKEN, revoked=True)
    resp = db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    assert resp.status_code == 401
    assert resp.json() == {"detail": "Invalid API key"}


def test_db_wrong_token_rejected(db_only_client: TestClient) -> None:
    _insert_key(TEST_TOKEN)
    resp = db_only_client.get("/protected", headers={"Authorization": "Bearer agdr_wrong-token"})
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# Env + DB coexistence
# ---------------------------------------------------------------------------


def test_env_key_still_works_alongside_db_keys(env_and_db_client: TestClient) -> None:
    """M2 invariant: env key remains an always-accepted bootstrap token."""
    _insert_key(TEST_TOKEN, label="ui-issued")
    resp = env_and_db_client.get(
        "/protected", headers={"Authorization": "Bearer env-fallback-token"}
    )
    assert resp.status_code == 200


def test_db_key_works_when_env_is_also_set(env_and_db_client: TestClient) -> None:
    _insert_key(TEST_TOKEN, label="ui-issued")
    resp = env_and_db_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# last_used_at bumping
# ---------------------------------------------------------------------------


def test_last_used_at_bumps_on_success(db_only_client: TestClient) -> None:
    key_id = _insert_key(TEST_TOKEN)

    # Pre-auth: last_used_at is None.
    assert _reload_key(key_id).last_used_at is None

    before = datetime.now(UTC)
    resp = db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    assert resp.status_code == 200

    after = _reload_key(key_id)
    assert after is not None
    assert after.last_used_at is not None
    # Datetime was bumped into the [before, now] window. SQLite may drop
    # tzinfo when round-tripping; coerce before comparing.
    bumped = after.last_used_at
    if bumped.tzinfo is None:
        bumped = bumped.replace(tzinfo=UTC)
    # Allow a one-second smear either side because SQLite's CURRENT_TIMESTAMP
    # has second granularity (relevant when NOT using ours) and the request
    # can straddle the second boundary.
    assert (bumped - before).total_seconds() >= -1


def test_last_used_at_bumps_monotonically(db_only_client: TestClient) -> None:
    key_id = _insert_key(TEST_TOKEN)

    db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    first = _reload_key(key_id).last_used_at

    # Sleep briefly so the second bump has a distinct timestamp. The
    # ``datetime.now(UTC)`` we use is microsecond-precision, so we don't
    # need a full second here.
    import time as _time

    _time.sleep(0.01)
    db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    second = _reload_key(key_id).last_used_at

    assert first is not None and second is not None
    # second should be at-or-after first.
    assert second >= first


def test_last_used_bump_failure_does_not_fail_auth(
    db_only_client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """If the last_used bump commit fails, the request still succeeds.

    We monkeypatch ``Session.commit`` to raise on the specific call made
    by ``_check_db_api_key`` — but we have to be selective because the
    request path depends on get_db() giving us a working session; the
    commit targeted here is the one that happens inside
    ``_check_db_api_key`` after finding the row.
    """
    _insert_key(TEST_TOKEN)

    from agentdrop import auth as auth_mod

    original = auth_mod._check_db_api_key

    def _raising_check(db, token: str) -> str | None:
        # Call the original, but swap ``db.commit`` on this session so
        # the best-effort bump fails — that's the branch we care about.
        original_commit = db.commit

        def _bad_commit() -> None:
            raise OperationalError("boom", params=None, orig=None)

        db.commit = _bad_commit  # type: ignore[method-assign]
        try:
            return original(db, token)
        finally:
            db.commit = original_commit  # type: ignore[method-assign]

    monkeypatch.setattr(auth_mod, "_check_db_api_key", _raising_check)

    with caplog.at_level(logging.WARNING, logger="agentdrop.auth"):
        resp = db_only_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})

    # Auth still succeeds — the token is valid, only the touch failed.
    assert resp.status_code == 200
    # And we logged the failure so operators can notice.
    assert any("api_key_last_used_at_update_failed" in rec.getMessage() for rec in caplog.records)


# ---------------------------------------------------------------------------
# 503 when nothing is configured
# ---------------------------------------------------------------------------


def test_no_env_no_db_returns_503(no_source_client: TestClient) -> None:
    resp = no_source_client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    assert resp.status_code == 503
    assert resp.json() == {"detail": "API key not configured on server"}


def test_no_env_no_db_missing_header_returns_503(no_source_client: TestClient) -> None:
    """Even with no header, "server not configured" beats "missing header"."""
    resp = no_source_client.get("/protected")
    assert resp.status_code == 503
    assert resp.json() == {"detail": "API key not configured on server"}


def test_revoked_only_db_is_still_configured(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """A DB with only revoked rows still counts as "configured" → 401.

    Once the user has minted any key via the UI, the server is
    considered configured; revoking their last key doesn't regress the
    server to "unconfigured". A subsequent bad-token request gets 401
    (the right signal — "your token doesn't match anything active")
    rather than 503 ("no keys anywhere").
    """
    db_path = tmp_path / "apikeys.db"
    monkeypatch.delenv("AGENTDROP_API_KEY", raising=False)
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_expected_hash.cache_clear()

    Base.metadata.create_all(get_engine())
    _insert_key(TEST_TOKEN, revoked=True)

    try:
        with TestClient(_build_app()) as client:
            resp = client.get("/protected", headers={"Authorization": f"Bearer {TEST_TOKEN}"})
    finally:
        get_settings.cache_clear()
        get_engine.cache_clear()
        _get_expected_hash.cache_clear()

    assert resp.status_code == 401
    assert resp.json() == {"detail": "Invalid API key"}
