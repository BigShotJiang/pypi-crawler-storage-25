"""Tests for the session-cookie admin auth (login/logout + require_session)."""

from __future__ import annotations

import asyncio
import re
from collections.abc import Iterator
from typing import Annotated
from unittest.mock import patch

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from starlette.middleware.sessions import SessionMiddleware

from agentdrop.config import get_settings
from agentdrop.web import rate_limit as rl
from agentdrop.web.auth_routes import router as auth_router
from agentdrop.web.session import (
    Admin,
    _get_admin_password_hash,
    averify_admin_password,
    require_session,
    verify_admin_password,
)

TEST_PASSWORD = "hunter2-correct-horse"

_RequireSession = Annotated[Admin, Depends(require_session)]

_CSRF_RE = re.compile(r'<input[^>]*name="_csrf"[^>]*value="([^"]+)"', re.IGNORECASE)


def _csrf(client: TestClient) -> str:
    """Fetch a CSRF token by hitting GET /login and parsing the form."""
    response = client.get("/login")
    assert response.status_code == 200
    match = _CSRF_RE.search(response.text)
    assert match is not None, "expected CSRF input on login form"
    return match.group(1)


def _build_app() -> FastAPI:
    """Build a small app that mounts the auth router and one protected route."""
    app = FastAPI()
    app.add_middleware(
        SessionMiddleware,
        secret_key="test-secret-key-not-used-in-prod",
        session_cookie="agentdrop_session",
        max_age=60 * 60 * 24 * 14,
        same_site="lax",
        https_only=False,
    )
    app.include_router(auth_router)

    @app.get("/protected")
    def protected(admin: _RequireSession) -> dict[str, str]:
        return {"user": admin.username}

    return app


@pytest.fixture
def configured_client(monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Client with AGENTDROP_ADMIN_PASSWORD set to TEST_PASSWORD."""
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_PASSWORD)
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()
    rl._TEST_clear()
    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        _get_admin_password_hash.cache_clear()
        rl._TEST_clear()


@pytest.fixture
def unconfigured_client(monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Client with AGENTDROP_ADMIN_PASSWORD unset."""
    monkeypatch.delenv("AGENTDROP_ADMIN_PASSWORD", raising=False)
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()
    rl._TEST_clear()
    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        _get_admin_password_hash.cache_clear()
        rl._TEST_clear()


# ---------------------------------------------------------------------------
# GET /login
# ---------------------------------------------------------------------------


def test_login_get_renders_form(configured_client: TestClient) -> None:
    response = configured_client.get("/login")
    assert response.status_code == 200
    assert "Agent Drop" in response.text
    assert 'name="password"' in response.text
    assert 'name="next"' in response.text


def test_login_get_shows_error_message(configured_client: TestClient) -> None:
    response = configured_client.get("/login?error=bad_password")
    assert response.status_code == 200
    assert "Incorrect password" in response.text


def test_login_get_already_logged_in_redirects(configured_client: TestClient) -> None:
    # First, log in.
    configured_client.post(
        "/login",
        data={"password": TEST_PASSWORD, "next": "/", "_csrf": _csrf(configured_client)},
        follow_redirects=False,
    )
    # Then GET /login with next=/inbox -> should 303 straight there.
    response = configured_client.get("/login?next=/inbox", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/inbox"


# ---------------------------------------------------------------------------
# POST /login
# ---------------------------------------------------------------------------


def test_login_post_wrong_password_redirects_back(configured_client: TestClient) -> None:
    response = configured_client.post(
        "/login",
        data={
            "password": "definitely-wrong",
            "next": "/",
            "_csrf": _csrf(configured_client),
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    location = response.headers["location"]
    assert location.startswith("/login?")
    assert "error=bad_password" in location


def test_login_post_correct_password_redirects_to_root(
    configured_client: TestClient,
) -> None:
    response = configured_client.post(
        "/login",
        data={"password": TEST_PASSWORD, "_csrf": _csrf(configured_client)},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/"
    # Session cookie must be set.
    assert "agentdrop_session" in response.cookies or any(
        "agentdrop_session" in h for h in response.headers.get_list("set-cookie")
    )


def test_login_post_honours_next_path(configured_client: TestClient) -> None:
    response = configured_client.post(
        "/login",
        data={
            "password": TEST_PASSWORD,
            "next": "/foo",
            "_csrf": _csrf(configured_client),
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/foo"


def test_login_post_rejects_open_redirect(configured_client: TestClient) -> None:
    response = configured_client.post(
        "/login",
        data={
            "password": TEST_PASSWORD,
            "next": "https://evil.example.com/",
            "_csrf": _csrf(configured_client),
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/"


def test_login_post_rejects_protocol_relative_redirect(
    configured_client: TestClient,
) -> None:
    response = configured_client.post(
        "/login",
        data={
            "password": TEST_PASSWORD,
            "next": "//evil.example.com/path",
            "_csrf": _csrf(configured_client),
        },
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/"


def test_login_post_unconfigured_returns_503(unconfigured_client: TestClient) -> None:
    response = unconfigured_client.post(
        "/login",
        data={"password": "anything", "_csrf": _csrf(unconfigured_client)},
        follow_redirects=False,
    )
    assert response.status_code == 503
    assert response.json() == {"detail": "Admin password not configured on server"}


# ---------------------------------------------------------------------------
# require_session dependency
# ---------------------------------------------------------------------------


def test_protected_route_without_session_redirects(configured_client: TestClient) -> None:
    response = configured_client.get("/protected", follow_redirects=False)
    assert response.status_code == 303
    location = response.headers["location"]
    assert location.startswith("/login?next=")
    # URL-encoded original path.
    assert "%2Fprotected" in location


def test_protected_route_with_session_returns_200(configured_client: TestClient) -> None:
    # Log in first.
    login = configured_client.post(
        "/login",
        data={"password": TEST_PASSWORD, "_csrf": _csrf(configured_client)},
        follow_redirects=False,
    )
    assert login.status_code == 303

    response = configured_client.get("/protected")
    assert response.status_code == 200
    assert response.json() == {"user": "admin"}


def test_protected_route_preserves_query_in_next(configured_client: TestClient) -> None:
    response = configured_client.get("/protected?filter=unread", follow_redirects=False)
    assert response.status_code == 303
    location = response.headers["location"]
    # Query string should be percent-encoded inside the next param.
    assert "filter%3Dunread" in location


# ---------------------------------------------------------------------------
# POST /logout
# ---------------------------------------------------------------------------


def test_logout_clears_session(configured_client: TestClient) -> None:
    # Log in first.
    token = _csrf(configured_client)
    configured_client.post(
        "/login",
        data={"password": TEST_PASSWORD, "_csrf": token},
        follow_redirects=False,
    )
    # Sanity: protected route works.
    assert configured_client.get("/protected").status_code == 200

    # Log out — the same session-bound token still applies.
    response = configured_client.post(
        "/logout",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/login"

    # Subsequent access should redirect.
    follow = configured_client.get("/protected", follow_redirects=False)
    assert follow.status_code == 303
    assert follow.headers["location"].startswith("/login?next=")


# ---------------------------------------------------------------------------
# Rate limiting on POST /login
# ---------------------------------------------------------------------------


def _stub_verify_factory(correct: str = TEST_PASSWORD):
    """Build sync + async stubs that mimic verify_admin_password fast."""

    def _sync(raw: str) -> bool:
        return raw == correct

    async def _async(raw: str) -> bool:
        return raw == correct

    return _sync, _async


def test_login_rate_limit_after_five_failures(
    configured_client: TestClient,
) -> None:
    sync_stub, async_stub = _stub_verify_factory()
    token = _csrf(configured_client)
    with (
        patch("agentdrop.web.auth_routes.averify_admin_password", async_stub),
        patch("agentdrop.web.session.verify_admin_password", sync_stub),
    ):
        for _ in range(5):
            r = configured_client.post(
                "/login",
                data={"password": "wrong", "_csrf": token},
                follow_redirects=False,
            )
            assert r.status_code == 303
            assert "error=bad_password" in r.headers["location"]

        # Sixth attempt: rate limited.
        r = configured_client.post(
            "/login",
            data={"password": "wrong", "_csrf": token},
            follow_redirects=False,
        )
        assert r.status_code == 429
        assert "retry-after" in {h.lower() for h in r.headers}


def test_login_success_resets_counter(configured_client: TestClient) -> None:
    sync_stub, async_stub = _stub_verify_factory()
    token = _csrf(configured_client)
    with (
        patch("agentdrop.web.auth_routes.averify_admin_password", async_stub),
        patch("agentdrop.web.session.verify_admin_password", sync_stub),
    ):
        # Burn 4 failed attempts.
        for _ in range(4):
            r = configured_client.post(
                "/login",
                data={"password": "wrong", "_csrf": token},
                follow_redirects=False,
            )
            assert r.status_code == 303

        # Successful login resets the bucket.
        r = configured_client.post(
            "/login",
            data={"password": TEST_PASSWORD, "_csrf": token},
            follow_redirects=False,
        )
        assert r.status_code == 303
        assert r.headers["location"] == "/"

        # Now fire 5 more failures; none should hit the limit. The
        # session-bound token from before survives the login flip.
        for _ in range(5):
            r = configured_client.post(
                "/login",
                data={"password": "wrong", "_csrf": token},
                follow_redirects=False,
            )
            assert r.status_code == 303

        # Sixth in this fresh window: limited.
        r = configured_client.post(
            "/login",
            data={"password": "wrong", "_csrf": token},
            follow_redirects=False,
        )
        assert r.status_code == 429


# ---------------------------------------------------------------------------
# Async argon2 verify (non-blocking)
# ---------------------------------------------------------------------------


def test_averify_calls_to_thread() -> None:
    """``averify_admin_password`` must dispatch to a worker thread.

    Patches ``asyncio.to_thread`` to assert it's used; if the route ever
    regresses to calling the sync verify directly we'd block the loop.
    """
    called = {"hit": False}

    async def fake_to_thread(func, *args, **kwargs):  # type: ignore[no-untyped-def]
        called["hit"] = True
        return func(*args, **kwargs)

    async def _run() -> bool:
        with (
            patch("agentdrop.web.session.verify_admin_password", return_value=True),
            patch("asyncio.to_thread", fake_to_thread),
        ):
            return await averify_admin_password("anything")

    result = asyncio.run(_run())
    assert result is True
    assert called["hit"] is True


def test_averify_returns_sync_result(monkeypatch: pytest.MonkeyPatch) -> None:
    """Async wrapper returns the same boolean as the sync impl."""

    monkeypatch.setattr("agentdrop.web.session.verify_admin_password", lambda raw: raw == "yes")

    async def _run() -> tuple[bool, bool]:
        return (
            await averify_admin_password("yes"),
            await averify_admin_password("no"),
        )

    ok, bad = asyncio.run(_run())
    assert ok is True
    assert bad is False


def test_verify_admin_password_sync_still_works(
    configured_client: TestClient,
) -> None:
    """Existing sync callers must keep working unchanged."""
    assert verify_admin_password(TEST_PASSWORD) is True
    assert verify_admin_password("nope") is False


# ---------------------------------------------------------------------------
# Cookie Secure flag (A1)
# ---------------------------------------------------------------------------


def _build_app_with_secure(insecure_cookies: bool) -> FastAPI:
    """Mirror the real main.py setup with ``https_only`` configurable."""
    app = FastAPI()
    app.add_middleware(
        SessionMiddleware,
        secret_key="test-secret-key-not-used-in-prod",
        session_cookie="agentdrop_session",
        max_age=60 * 60 * 24 * 14,
        same_site="lax",
        https_only=not insecure_cookies,
    )
    app.include_router(auth_router)
    return app


def test_session_cookie_has_secure_flag_by_default(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_PASSWORD)
    monkeypatch.delenv("AGENTDROP_INSECURE_COOKIES", raising=False)
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()
    rl._TEST_clear()
    try:
        # Use https base_url so the Secure session cookie minted by GET
        # /login (where the CSRF token is seeded) is sent back on the
        # subsequent POST /login. With http://, the cookie is dropped
        # by httpx's filter and the CSRF check fails.
        with TestClient(
            _build_app_with_secure(insecure_cookies=False),
            base_url="https://testserver",
        ) as client:
            r = client.post(
                "/login",
                data={"password": TEST_PASSWORD, "_csrf": _csrf(client)},
                follow_redirects=False,
            )
            assert r.status_code == 303
            cookies = r.headers.get_list("set-cookie")
            assert any("agentdrop_session=" in c for c in cookies)
            session_cookie = next(c for c in cookies if "agentdrop_session=" in c)
            assert "secure" in session_cookie.lower()
    finally:
        get_settings.cache_clear()
        _get_admin_password_hash.cache_clear()
        rl._TEST_clear()


def test_session_cookie_no_secure_when_insecure_cookies(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_PASSWORD)
    monkeypatch.setenv("AGENTDROP_INSECURE_COOKIES", "1")
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()
    rl._TEST_clear()
    try:
        with TestClient(_build_app_with_secure(insecure_cookies=True)) as client:
            r = client.post(
                "/login",
                data={"password": TEST_PASSWORD, "_csrf": _csrf(client)},
                follow_redirects=False,
            )
            assert r.status_code == 303
            cookies = r.headers.get_list("set-cookie")
            assert any("agentdrop_session=" in c for c in cookies)
            session_cookie = next(c for c in cookies if "agentdrop_session=" in c)
            assert "secure" not in session_cookie.lower()
    finally:
        get_settings.cache_clear()
        _get_admin_password_hash.cache_clear()
        rl._TEST_clear()
