"""Tests for the inbox CSS static asset.

Confirms the file is served with the correct content-type, references the
key class names Agent B's templates rely on, uses design tokens (not inline
hex/OKLCH), and carries the expected mobile breakpoint.
"""

from __future__ import annotations

from fastapi.testclient import TestClient


def test_inbox_css_served(client: TestClient) -> None:
    response = client.get("/static/inbox.css")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/css")


def test_inbox_css_contains_key_class_names(client: TestClient) -> None:
    body = client.get("/static/inbox.css").text
    for class_name in (
        ".inbox-grid",
        ".sidebar",
        ".dropcard",
        ".dropcard__dot--unread",
        ".dropcard__dot--pinned",
        ".mobile-tab--active",
    ):
        assert class_name in body, f"missing selector {class_name!r}"


def test_inbox_css_uses_design_tokens(client: TestClient) -> None:
    body = client.get("/static/inbox.css").text
    # Must reference the paper-deep token at least once — proves tokens are
    # driving backgrounds, not inlined hex/OKLCH literals.
    assert "var(--color-paper-deep)" in body


def test_inbox_css_has_mobile_breakpoint(client: TestClient) -> None:
    body = client.get("/static/inbox.css").text
    assert "@media (max-width: 640px)" in body
