"""Tests for the admin inbox route ``GET /``.

The session dependency is overridden with a no-op so we don't have to
exercise the real login flow for every case — auth paths are tested
separately in ``test_auth.py`` (API) / the forthcoming session tests.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.fts import install_fts_schema
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop
from agentdrop.web.session import Admin, require_session


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())
    # FTS5 virtual table + triggers live only in the Alembic migration,
    # not in Base.metadata. Install them here so the inbox's ?q= path
    # (which goes through FTS5 on SQLite) works in tests.
    install_fts_schema(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _persist(drops: list[Drop]) -> None:
    session = SessionLocal(bind=get_engine())
    try:
        for d in drops:
            session.add(d)
        session.commit()
    finally:
        session.close()


def _seed_drops() -> list[Drop]:
    """Build a mixed fixture: unread, read, pinned, archived across sources."""
    now = datetime.now(UTC)
    drops = [
        Drop(
            short_id="s0unread00000000000000aa",
            title="Hello unread drop",
            body="Summary A.",
            content_md="# hello",
            source="weekly-scan",
            created_at=now - timedelta(minutes=5),
        ),
        Drop(
            short_id="s1read000000000000000aaa",
            title="A read drop",
            body="Summary B.",
            content_md="# read",
            source="weekly-scan",
            read_at=now - timedelta(minutes=30),
            created_at=now - timedelta(hours=1),
        ),
        Drop(
            short_id="s2pinned00000000000000aa",
            title="A pinned drop",
            body="Summary C.",
            content_md="# pinned",
            source="ops-alerts",
            pinned_at=now - timedelta(hours=2),
            created_at=now - timedelta(hours=2),
        ),
        Drop(
            short_id="s3archive00000000000000a",
            title="An archived drop",
            body="Summary D.",
            content_md="# archived",
            source="news-digest",
            archived_at=now - timedelta(days=3),
            created_at=now - timedelta(days=3),
        ),
        Drop(
            short_id="s4urgent00000000000000aa",
            title="Urgent incident",
            body="Summary E.",
            content_md="# urgent",
            source="ops-alerts",
            priority="urgent",
            created_at=now - timedelta(minutes=15),
        ),
    ]
    _persist(drops)
    return drops


def test_inbox_renders_html_with_titles_counter_and_sources(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/")
    assert resp.status_code == 200, resp.text
    assert resp.headers["content-type"].startswith("text/html")

    html = resp.text
    # Page title uses "Drops" for the default view.
    assert "Drops" in html
    # "N new" counter — 3 unread, non-archived, non-"read" drops in the seed
    # (unread + pinned + urgent-unread). Pinned drops count as unread here
    # because they have read_at IS NULL.
    assert "3 new" in html
    # Each non-archived drop's title appears in the default view.
    assert "Hello unread drop" in html
    assert "A read drop" in html
    assert "A pinned drop" in html
    assert "Urgent incident" in html
    # Archived drop's title does NOT appear in the default view.
    assert "An archived drop" not in html
    # Sources in the sidebar.
    assert "weekly-scan" in html
    assert "ops-alerts" in html
    assert "news-digest" in html


def test_inbox_state_pinned_only(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/?state=pinned")
    assert resp.status_code == 200
    html = resp.text
    assert "A pinned drop" in html
    # Non-pinned titles absent from the list.
    assert "Hello unread drop" not in html
    assert "A read drop" not in html
    assert "Urgent incident" not in html


def test_inbox_state_archived_shows_archived(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/?state=archived")
    assert resp.status_code == 200
    assert "An archived drop" in resp.text


def test_inbox_source_filter(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/?source=ops-alerts")
    assert resp.status_code == 200
    html = resp.text
    # Both ops-alerts drops visible.
    assert "A pinned drop" in html
    assert "Urgent incident" in html
    # weekly-scan drops absent from the list (note: "weekly-scan" still
    # appears in the sidebar, so we check for the titles instead).
    assert "Hello unread drop" not in html
    assert "A read drop" not in html


def test_inbox_search_case_insensitive(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/?q=Hello")
    assert resp.status_code == 200
    html = resp.text
    assert "Hello unread drop" in html
    # Other titles filtered out.
    assert "A read drop" not in html
    assert "Urgent incident" not in html


def test_inbox_search_matches_source_substring(client: TestClient) -> None:
    _seed_drops()
    resp = client.get("/?q=ops")
    assert resp.status_code == 200
    html = resp.text
    # Both ops-alerts drops match via source.
    assert "A pinned drop" in html
    assert "Urgent incident" in html
    # weekly-scan titles do not.
    assert "Hello unread drop" not in html


def test_inbox_search_matches_content_md(client: TestClient) -> None:
    """FTS5 lets the inbox find words only present in ``content_md``.

    The old LIKE-on-title+source path couldn't do this. This test
    pins the new capability.
    """
    now = datetime.now(UTC)
    _persist(
        [
            Drop(
                short_id="contentmd000000000000001",
                title="Totally unrelated title",
                body="Nothing to see here.",
                content_md="# Post-mortem\n\nKubernetes control plane wobble.",
                source="ops-alerts",
                created_at=now - timedelta(minutes=5),
            )
        ]
    )
    resp = client.get("/?q=kubernetes")
    assert resp.status_code == 200
    assert "Totally unrelated title" in resp.text


def test_inbox_empty_state(client: TestClient) -> None:
    # No drops seeded — the empty state should render.
    resp = client.get("/")
    assert resp.status_code == 200
    assert "No drops in this view." in resp.text


def test_inbox_respects_soft_delete(client: TestClient) -> None:
    now = datetime.now(UTC)
    _persist(
        [
            Drop(
                short_id="softdel000000000000000aa",
                title="Tombstoned drop",
                body="x",
                content_md="x",
                source="weekly-scan",
                soft_deleted_at=now,
                created_at=now - timedelta(minutes=5),
            )
        ]
    )
    resp = client.get("/")
    assert resp.status_code == 200
    assert "Tombstoned drop" not in resp.text
    # The sidebar shouldn't surface a source entry driven only by a
    # soft-deleted row either.
    assert "weekly-scan" not in resp.text
