"""Perf-shape tests for the ``drops(source)`` and ``drops(source, priority)``
indexes added in the ``1a4d9c2f8e10`` migration (issue #14, G1).

We don't measure wall-clock time here — that's flaky in CI. Instead we
assert the SQLite query planner picks the new index for the routing
resolver and inbox source-filter shapes. If a future schema change
removes or renames the index, these tests fail loudly.
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from agentdrop.db.base import Base
from agentdrop.models import Drop


@pytest.fixture
def session() -> Iterator[Session]:
    """Fresh in-memory SQLite with the model schema and a few seeded drops.

    ``ANALYZE`` is run after the seed so the planner has stats to base
    index-vs-scan decisions on. Without it, SQLite may pick a scan even
    when an index exists, which would defeat the test.
    """
    engine = create_engine("sqlite://", future=True)
    Base.metadata.create_all(engine)
    with Session(engine) as s:
        # Seed a mix of sources and priorities so the planner sees enough
        # cardinality to prefer the index over a scan.
        for i in range(200):
            s.add(
                Drop(
                    title=f"t{i}",
                    body=f"b{i}",
                    content_md="",
                    source=f"src-{i % 10}",
                    priority="urgent" if i % 3 == 0 else "normal",
                )
            )
        s.commit()
        s.execute(text("ANALYZE"))
        yield s
    engine.dispose()


def test_create_all_creates_source_index(session: Session) -> None:
    """``Base.metadata.create_all`` must produce the same indexes as Alembic."""
    rows = session.execute(
        text("SELECT name FROM sqlite_master WHERE type = 'index' AND tbl_name = 'drops'")
    ).all()
    names = {row[0] for row in rows}
    assert "ix_drops_source" in names
    assert "ix_drops_source_priority" in names


def test_explain_uses_source_index_for_resolver_shape(session: Session) -> None:
    """The routing-resolver / sidebar query (``WHERE source = ?``) hits ``ix_drops_source``."""
    rows = session.execute(
        text("EXPLAIN QUERY PLAN SELECT id FROM drops WHERE source = :s"),
        {"s": "src-3"},
    ).all()
    plan = " | ".join(row.detail for row in rows)
    assert "SEARCH" in plan and "ix_drops_source" in plan, plan


def test_explain_uses_composite_index_for_inbox_shape(session: Session) -> None:
    """The inbox source+priority filter hits ``ix_drops_source_priority``.

    SQLite is free to pick either ``ix_drops_source`` (covers source) or
    ``ix_drops_source_priority`` (covers both). We accept either as long
    as the plan is an INDEX search rather than a full scan — but assert
    the composite index is the preferred choice when both columns are in
    the predicate, since it's more selective.
    """
    rows = session.execute(
        text("EXPLAIN QUERY PLAN SELECT id FROM drops WHERE source = :s AND priority = :p"),
        {"s": "src-3", "p": "urgent"},
    ).all()
    plan = " | ".join(row.detail for row in rows)
    assert "SEARCH" in plan, plan
    assert "ix_drops_source_priority" in plan, plan
