"""Tests for ``agentdrop crypto rotate`` (issue #17 phase 2B).

Rows are seeded by direct SQL with ciphertext produced via
``agentdrop.crypto.secrets.encrypt`` so this test file does NOT depend
on phase 2A's ``EncryptedJSON`` column landing first.
"""

from __future__ import annotations

import base64
import secrets as _secrets
from collections.abc import Iterator
from pathlib import Path

import pytest
from cryptography.fernet import Fernet
from sqlalchemy import text
from typer.testing import CliRunner

from agentdrop.cli.app import app
from agentdrop.config import get_settings
from agentdrop.crypto import secrets as crypto_secrets
from agentdrop.db import session as db_session
from agentdrop.db.base import Base


def _gen_key() -> str:
    return base64.urlsafe_b64encode(_secrets.token_bytes(32)).decode()


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


@pytest.fixture
def temp_db(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Iterator[Path]:
    """Point the app at an isolated SQLite file and create the schema.

    Clears the cached engine and Settings on entry and exit so the test's
    env (``AGENTDROP_DATABASE_URL``, ``AGENTDROP_ENCRYPTION_KEY``,
    ``AGENTDROP_ENCRYPTION_KEY_PREV``) is honoured.
    """
    db_path = tmp_path / "rotate-test.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()
    db_session.get_engine.cache_clear()

    engine = db_session.get_engine()
    Base.metadata.create_all(engine)
    try:
        yield db_path
    finally:
        engine.dispose()
        get_settings.cache_clear()
        db_session.get_engine.cache_clear()


def _insert_channel(db_path: Path, row_id: str, ciphertext: str) -> None:
    """Seed a channel row via direct SQL so we control the ciphertext byte-for-byte."""
    from sqlalchemy import create_engine

    engine = create_engine(f"sqlite:///{db_path}", future=True)
    try:
        with engine.begin() as conn:
            conn.execute(
                text(
                    "INSERT INTO channels (id, name, driver, config_json, is_default) "
                    "VALUES (:id, :name, :driver, :cfg, 0)"
                ),
                {
                    "id": row_id,
                    "name": f"test-{row_id}",
                    "driver": "webhook",
                    "cfg": ciphertext,
                },
            )
    finally:
        engine.dispose()


def _read_channel_ciphertext(db_path: Path, row_id: str) -> str:
    from sqlalchemy import create_engine

    engine = create_engine(f"sqlite:///{db_path}", future=True)
    try:
        with engine.connect() as conn:
            result = conn.execute(
                text("SELECT config_json FROM channels WHERE id = :id"),
                {"id": row_id},
            ).scalar_one()
        return result
    finally:
        engine.dispose()


def test_rotate_re_encrypts_with_current_key(
    runner: CliRunner,
    monkeypatch: pytest.MonkeyPatch,
    temp_db: Path,
) -> None:
    """Happy path: row written with key A is rewritten so it decrypts under B alone."""
    key_a = _gen_key()
    key_b = _gen_key()

    # Encrypt a row's plaintext under key A.
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key_a)
    get_settings.cache_clear()
    plaintext = '{"token":"super-secret"}'
    ciphertext_a = crypto_secrets.encrypt(plaintext)
    _insert_channel(temp_db, "ch_rotateA000000000", ciphertext_a)

    # Now flip: new key B is current, A is _PREV. Rotate.
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key_b)
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", key_a)
    get_settings.cache_clear()
    db_session.get_engine.cache_clear()

    result = runner.invoke(app, ["crypto", "rotate"])
    assert result.exit_code == 0, result.output
    assert "Rotation complete" in result.output

    # The stored ciphertext must now decrypt under key B alone.
    new_ciphertext = _read_channel_ciphertext(temp_db, "ch_rotateA000000000")
    assert new_ciphertext != ciphertext_a
    assert Fernet(key_b.encode()).decrypt(new_ciphertext.encode()).decode() == plaintext


def test_rotate_wrong_prev_reports_failed_row_and_exits_1(
    runner: CliRunner,
    monkeypatch: pytest.MonkeyPatch,
    temp_db: Path,
) -> None:
    """If neither current nor _PREV can decrypt a row, name the row id and exit 1."""
    key_a = _gen_key()
    key_b = _gen_key()
    bogus_prev = _gen_key()

    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key_a)
    get_settings.cache_clear()
    ciphertext_a = crypto_secrets.encrypt('{"token":"x"}')
    row_id = "ch_rotateBADprev0000"
    _insert_channel(temp_db, row_id, ciphertext_a)

    # Operator gets _PREV wrong: rotation can't decrypt.
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key_b)
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", bogus_prev)
    get_settings.cache_clear()
    db_session.get_engine.cache_clear()

    result = runner.invoke(app, ["crypto", "rotate"])
    assert result.exit_code == 1
    combined = result.output + (result.stderr if result.stderr else "")
    assert row_id in combined


def test_rotate_missing_keys_errors_before_touching_db(
    runner: CliRunner,
    monkeypatch: pytest.MonkeyPatch,
    temp_db: Path,
) -> None:
    """Both keys are required — clear error and no DB writes when either is missing."""
    key_a = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key_a)
    get_settings.cache_clear()
    ciphertext_a = crypto_secrets.encrypt('{"token":"y"}')
    _insert_channel(temp_db, "ch_rotateNOPREV0000", ciphertext_a)

    # Only current set — _PREV missing.
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()
    db_session.get_engine.cache_clear()

    result = runner.invoke(app, ["crypto", "rotate"])
    assert result.exit_code == 1
    combined = result.output + (result.stderr if result.stderr else "")
    assert "AGENTDROP_ENCRYPTION_KEY_PREV" in combined

    # The row must be untouched.
    assert _read_channel_ciphertext(temp_db, "ch_rotateNOPREV0000") == ciphertext_a

    # Now flip the missing slot: only _PREV set, current missing.
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", key_a)
    get_settings.cache_clear()

    result = runner.invoke(app, ["crypto", "rotate"])
    assert result.exit_code == 1
    combined = result.output + (result.stderr if result.stderr else "")
    assert "AGENTDROP_ENCRYPTION_KEY" in combined
    assert _read_channel_ciphertext(temp_db, "ch_rotateNOPREV0000") == ciphertext_a


def test_rotate_no_rows_is_a_clean_noop(
    runner: CliRunner,
    monkeypatch: pytest.MonkeyPatch,
    temp_db: Path,
) -> None:
    """An empty channels table should still satisfy the key-presence check and exit 0."""
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY_PREV", _gen_key())
    get_settings.cache_clear()
    db_session.get_engine.cache_clear()

    result = runner.invoke(app, ["crypto", "rotate"])
    assert result.exit_code == 0, result.output
    assert "No channel rows" in result.output
