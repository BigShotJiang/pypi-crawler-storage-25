"""Tests for the in-memory per-IP rate limiter."""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from fastapi import FastAPI, HTTPException, Request
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.web import rate_limit as rl


@pytest.fixture(autouse=True)
def _clear_state() -> Iterator[None]:
    rl._TEST_clear()
    get_settings.cache_clear()
    yield
    rl._TEST_clear()
    get_settings.cache_clear()


# ---------------------------------------------------------------------------
# Unit tests for record_attempt / reset_attempts and the dependency
# ---------------------------------------------------------------------------


def _make_request(host: str = "1.2.3.4", headers: dict[str, str] | None = None) -> Request:
    raw_headers = []
    if headers:
        for k, v in headers.items():
            raw_headers.append((k.lower().encode("latin-1"), v.encode("latin-1")))
    scope = {
        "type": "http",
        "method": "POST",
        "path": "/login",
        "headers": raw_headers,
        "client": (host, 12345),
        "scheme": "http",
        "server": ("testserver", 80),
        "query_string": b"",
    }
    return Request(scope)


def test_within_window_allows_then_blocks() -> None:
    dep = rl.rate_limit("test", max_attempts=3, window_seconds=60)
    req = _make_request()

    # Three checks pass while no attempts recorded.
    dep(req)
    dep(req)
    dep(req)

    # Record three failed attempts.
    rl.record_attempt("test", "1.2.3.4")
    rl.record_attempt("test", "1.2.3.4")
    rl.record_attempt("test", "1.2.3.4")

    # Fourth check raises.
    with pytest.raises(HTTPException) as exc_info:
        dep(req)
    assert exc_info.value.status_code == 429
    assert "Retry-After" in exc_info.value.headers


def test_window_expiry_resets_counter(monkeypatch: pytest.MonkeyPatch) -> None:
    dep = rl.rate_limit("test", max_attempts=2, window_seconds=10)
    req = _make_request()

    fake_now = {"t": 1000.0}

    def fake_monotonic() -> float:
        return fake_now["t"]

    monkeypatch.setattr(rl.time, "monotonic", fake_monotonic)

    rl.record_attempt("test", "1.2.3.4")
    rl.record_attempt("test", "1.2.3.4")
    with pytest.raises(HTTPException) as exc_info:
        dep(req)
    assert exc_info.value.status_code == 429

    # Advance past the window.
    fake_now["t"] = 1100.0
    dep(req)


def test_different_ips_tracked_independently() -> None:
    dep = rl.rate_limit("test", max_attempts=2, window_seconds=60)

    rl.record_attempt("test", "1.2.3.4")
    rl.record_attempt("test", "1.2.3.4")

    # First IP exceeded.
    with pytest.raises(HTTPException):
        dep(_make_request(host="1.2.3.4"))

    # Second IP unaffected.
    dep(_make_request(host="5.6.7.8"))


def test_reset_attempts_clears_counter() -> None:
    dep = rl.rate_limit("test", max_attempts=2, window_seconds=60)
    req = _make_request()

    rl.record_attempt("test", "1.2.3.4")
    rl.record_attempt("test", "1.2.3.4")
    with pytest.raises(HTTPException):
        dep(req)

    rl.reset_attempts("test", "1.2.3.4")
    dep(req)  # Now allowed.


def test_retry_after_header_present_on_429() -> None:
    dep = rl.rate_limit("test", max_attempts=1, window_seconds=120)
    req = _make_request()

    rl.record_attempt("test", "1.2.3.4")
    with pytest.raises(HTTPException) as exc_info:
        dep(req)

    headers = exc_info.value.headers or {}
    assert "Retry-After" in headers
    retry_after = int(headers["Retry-After"])
    assert 1 <= retry_after <= 120


# ---------------------------------------------------------------------------
# X-Forwarded-For handling
# ---------------------------------------------------------------------------


def test_xff_ignored_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("AGENTDROP_TRUST_PROXY_HEADERS", raising=False)
    get_settings.cache_clear()
    req = _make_request(host="1.2.3.4", headers={"X-Forwarded-For": "9.9.9.9"})
    assert rl.client_ip(req) == "1.2.3.4"


def test_xff_honored_when_trusted(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTDROP_TRUST_PROXY_HEADERS", "1")
    get_settings.cache_clear()
    try:
        req = _make_request(host="1.2.3.4", headers={"X-Forwarded-For": "9.9.9.9, 10.0.0.1"})
        assert rl.client_ip(req) == "9.9.9.9"
    finally:
        get_settings.cache_clear()


# ---------------------------------------------------------------------------
# Integration: dependency wired into a FastAPI app
# ---------------------------------------------------------------------------


def test_dependency_returns_429_when_quota_used() -> None:
    """Hitting the dependency through a real route returns 429 once exceeded."""
    app = FastAPI()
    dep = rl.rate_limit("integration", max_attempts=2, window_seconds=60)

    from fastapi import Depends

    @app.post("/limited", dependencies=[Depends(dep)])
    def limited(request: Request) -> dict[str, str]:
        rl.record_attempt("integration", rl.client_ip(request))
        return {"ok": "yes"}

    with TestClient(app) as client:
        assert client.post("/limited").status_code == 200
        assert client.post("/limited").status_code == 200
        # Third call: dependency sees 2 recorded attempts and blocks.
        resp = client.post("/limited")
        assert resp.status_code == 429
        assert "retry-after" in {h.lower() for h in resp.headers}
