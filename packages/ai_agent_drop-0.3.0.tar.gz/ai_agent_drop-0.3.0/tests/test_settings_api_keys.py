"""Tests for the API-keys settings UI.

Covers:

* Auth: unauth'd GET redirects to /login.
* Empty-state copy when there are no rows.
* Create: POST returns the plaintext token exactly once, and a DB row
  whose hash matches it.
* Display-once: subsequent GET does NOT include the plaintext token.
* Revoke: sets ``revoked_at`` and the key no longer appears in the
  default list.
* Show-revoked toggle: ``?show_revoked=1`` includes revoked rows.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select

from agentdrop.auth import hash_key
from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models.api_key import ApiKey
from agentdrop.web.session import Admin, require_session

from .conftest import fetch_csrf

# The template extracts the plaintext token inside a <code> block with the
# id ``apikey-new-token``. Use it to anchor the extraction so we don't
# conflate with other code-tagged content on the page.
_TOKEN_CODE_RE = re.compile(r'<code[^>]*id="apikey-new-token"[^>]*>(agdr_[A-Za-z0-9]+)</code>')


@pytest.fixture
def authed_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Session-authed TestClient with a fresh SQLite DB."""
    db_path = tmp_path / "apikeys.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    # Keep the retention thread quiet during TestClient startup.
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as client:
            yield client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _all_keys() -> list[ApiKey]:
    session = SessionLocal(bind=get_engine())
    try:
        return list(session.execute(select(ApiKey)).scalars().all())
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth posture
# ---------------------------------------------------------------------------


def test_list_unauth_redirects_to_login(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Without the session override, we should be redirected to /login."""
    db_path = tmp_path / "apikeys.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        # No require_session override: real dep runs, raises 303.
        with TestClient(app) as client:
            resp = client.get("/settings/api-keys", follow_redirects=False)
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()

    assert resp.status_code == 303
    assert resp.headers["location"].startswith("/login")
    assert "next=" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Empty state + create + display-once
# ---------------------------------------------------------------------------


def test_empty_list_shows_no_keys_copy(authed_client: TestClient) -> None:
    resp = authed_client.get("/settings/api-keys")
    assert resp.status_code == 200
    # Empty-state copy.
    assert "No API keys yet" in resp.text


def test_create_key_reveals_plaintext_and_persists_hash(
    authed_client: TestClient,
) -> None:
    resp = authed_client.post(
        "/settings/api-keys",
        data={"label": "ci-bot", "_csrf": fetch_csrf(authed_client)},
        follow_redirects=False,
    )
    assert resp.status_code == 200, resp.text

    # Plaintext token appears exactly once in the rendered HTML.
    match = _TOKEN_CODE_RE.search(resp.text)
    assert match is not None, "expected plaintext token in reveal card"
    plaintext = match.group(1)
    assert plaintext.startswith("agdr_")
    # agdr_ + 32 chars body = 37 total.
    assert len(plaintext) == len("agdr_") + 32

    # DB row exists with a matching hash, no plaintext persisted.
    rows = _all_keys()
    assert len(rows) == 1
    assert rows[0].label == "ci-bot"
    assert rows[0].key_hash == hash_key(plaintext)
    assert rows[0].revoked_at is None


def test_plaintext_is_display_once(authed_client: TestClient) -> None:
    """After the POST render, subsequent GETs must not include the token."""
    create = authed_client.post(
        "/settings/api-keys",
        data={"label": "one-shot", "_csrf": fetch_csrf(authed_client)},
        follow_redirects=False,
    )
    assert create.status_code == 200
    match = _TOKEN_CODE_RE.search(create.text)
    assert match is not None
    plaintext = match.group(1)

    # A fresh GET should not contain the plaintext anywhere.
    resp = authed_client.get("/settings/api-keys")
    assert resp.status_code == 200
    assert plaintext not in resp.text
    # But the row (by label) is still listed.
    assert "one-shot" in resp.text


def test_create_rejects_empty_label(authed_client: TestClient) -> None:
    # Empty label should be rejected with a visible error, not a 500.
    resp = authed_client.post(
        "/settings/api-keys",
        data={"label": "   ", "_csrf": fetch_csrf(authed_client)},
        follow_redirects=False,
    )
    assert resp.status_code == 200
    assert "Label must be" in resp.text
    # No row created.
    assert _all_keys() == []


def test_create_rejects_over_long_label(authed_client: TestClient) -> None:
    resp = authed_client.post(
        "/settings/api-keys",
        data={"label": "x" * 121, "_csrf": fetch_csrf(authed_client)},
        follow_redirects=False,
    )
    assert resp.status_code == 200
    assert "Label must be" in resp.text
    assert _all_keys() == []


# ---------------------------------------------------------------------------
# Revoke
# ---------------------------------------------------------------------------


def test_revoke_sets_revoked_at_and_hides_from_default_list(
    authed_client: TestClient,
) -> None:
    # Create one key, grab its id, revoke it.
    token = fetch_csrf(authed_client)
    authed_client.post(
        "/settings/api-keys",
        data={"label": "to-revoke", "_csrf": token},
    )
    rows = _all_keys()
    assert len(rows) == 1
    key_id = rows[0].id

    resp = authed_client.post(
        f"/settings/api-keys/{key_id}/revoke",
        data={"_csrf": token},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert resp.headers["location"] == "/settings/api-keys"

    # revoked_at is set.
    rows_after = _all_keys()
    assert rows_after[0].revoked_at is not None

    # Default list hides it.
    default_list = authed_client.get("/settings/api-keys")
    assert "to-revoke" not in default_list.text
    assert "No API keys yet" in default_list.text
    # But the "Show revoked (1)" link should appear.
    assert "Show revoked" in default_list.text


def test_show_revoked_toggle_includes_revoked_rows(authed_client: TestClient) -> None:
    token = fetch_csrf(authed_client)
    authed_client.post(
        "/settings/api-keys",
        data={"label": "hidden-one", "_csrf": token},
    )
    key_id = _all_keys()[0].id
    authed_client.post(
        f"/settings/api-keys/{key_id}/revoke",
        data={"_csrf": token},
    )

    resp = authed_client.get("/settings/api-keys?show_revoked=1")
    assert resp.status_code == 200
    assert "hidden-one" in resp.text
    # Status pill.
    assert "revoked" in resp.text.lower()


def test_revoke_unknown_id_returns_404(authed_client: TestClient) -> None:
    resp = authed_client.post(
        "/settings/api-keys/ak_doesnotexist/revoke",
        data={"_csrf": fetch_csrf(authed_client)},
        follow_redirects=False,
    )
    assert resp.status_code == 404


def test_revoke_is_idempotent(authed_client: TestClient) -> None:
    """Revoking an already-revoked key should not shift revoked_at."""
    token = fetch_csrf(authed_client)
    authed_client.post(
        "/settings/api-keys",
        data={"label": "double-revoke", "_csrf": token},
    )
    key_id = _all_keys()[0].id

    authed_client.post(f"/settings/api-keys/{key_id}/revoke", data={"_csrf": token})
    first = _all_keys()[0].revoked_at
    assert first is not None

    authed_client.post(f"/settings/api-keys/{key_id}/revoke", data={"_csrf": token})
    second = _all_keys()[0].revoked_at
    assert second == first
