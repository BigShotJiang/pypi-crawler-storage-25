"""Tests for the APScheduler wrapper in ``agentdrop.scheduler``.

These are state-only tests — we don't wait for the interval to fire.
Triggering ``.running`` is enough to show the scheduler was wired up;
actual retention behaviour is covered by ``test_retention.py``.

Monkeypatching note: ``start_scheduler`` / ``stop_scheduler`` use a
module-level ``_scheduler`` singleton. Tests that start it must also
stop it, otherwise the thread leaks across tests.

Lock-path note (issue #14 F1): the default scheduler lock path is
``<data_dir>/.scheduler.lock`` which is ``/data/...`` in a fresh
process — read-only on dev machines. The autouse
``redirect_lock_path`` fixture below points it at ``tmp_path`` for
every test in this module so we never touch ``/data``.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest

from agentdrop import scheduler as scheduler_mod
from agentdrop.config import get_settings


@pytest.fixture(autouse=True)
def reset_settings_cache() -> Iterator[None]:
    """Invalidate the cached ``Settings`` between tests.

    ``get_settings`` is ``@lru_cache``'d at the module level. Without
    clearing the cache, a test that sets env vars before calling it
    would race against a previous test that already populated the cache.
    """
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture(autouse=True)
def redirect_lock_path(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Iterator[None]:
    """Point ``AGENTDROP_SCHEDULER_LOCK_PATH`` at a tmp file.

    Without this, ``start_scheduler`` would try to create
    ``/data/.scheduler.lock`` and fail on read-only dev filesystems.
    """
    monkeypatch.setenv("AGENTDROP_SCHEDULER_LOCK_PATH", str(tmp_path / ".scheduler.lock"))
    yield


@pytest.fixture(autouse=True)
def teardown_scheduler() -> Iterator[None]:
    """Make sure no test leaves a background thread running."""
    yield
    scheduler_mod.stop_scheduler()


def test_disabled_flag_prevents_startup(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    # Sanity: settings actually picked it up.
    assert get_settings().retention_disabled is True

    scheduler_mod.start_scheduler()

    assert scheduler_mod._scheduler is None


def test_start_scheduler_runs_and_stop_scheduler_shuts_down(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "false")
    # Crank the interval up so the job definitely does not fire during
    # the test — we're only checking state, not behaviour.
    monkeypatch.setenv("AGENTDROP_RETENTION_INTERVAL_HOURS", "24")

    scheduler_mod.start_scheduler()

    assert scheduler_mod._scheduler is not None
    assert scheduler_mod._scheduler.running is True
    job = scheduler_mod._scheduler.get_job("retention_sweep")
    assert job is not None

    scheduler_mod.stop_scheduler()

    assert scheduler_mod._scheduler is None


def test_start_scheduler_is_idempotent(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "false")
    monkeypatch.setenv("AGENTDROP_RETENTION_INTERVAL_HOURS", "24")

    scheduler_mod.start_scheduler()
    first = scheduler_mod._scheduler
    assert first is not None

    # Second call must not replace or crash the running scheduler.
    scheduler_mod.start_scheduler()
    assert scheduler_mod._scheduler is first
    assert scheduler_mod._scheduler.running is True


def test_stop_scheduler_without_start_is_noop() -> None:
    # Ensures we don't raise when the scheduler was never started.
    scheduler_mod.stop_scheduler()
    assert scheduler_mod._scheduler is None
