"""Tests for the /settings shell.

Covers:
- The landing redirect (``GET /settings`` → ``/settings/channels``).
- Auth gating (unauth'd access bounces to ``/login``).
- The shared ``settings.css`` asset (scoped class, tokens, media query).
- The shared ``settings/_base.html`` template parses cleanly and wires up
  the left-nav + logout affordance the section agents depend on.
- The inbox page now carries a ``/settings`` link.

These tests mount the settings router onto a **minimal** FastAPI app
rather than importing ``agentdrop.main`` — this keeps the settings shell
tests decoupled from the other work-in-progress settings routers (whose
presence/absence in ``main.app`` shouldn't affect us), and mirrors the
pattern used by ``test_session_auth.py``.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.testclient import TestClient
from starlette.middleware.sessions import SessionMiddleware

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.web import static_dir, templates
from agentdrop.web.auth_routes import router as auth_router
from agentdrop.web.inbox import router as inbox_router
from agentdrop.web.session import Admin, require_session
from agentdrop.web.settings import router as settings_router


def _build_app() -> FastAPI:
    """Minimal app with session middleware, static files, and the routers
    this test file needs (auth for /login + /logout, inbox for the /
    Settings-link assertion, and the settings shell itself).

    Avoids importing ``agentdrop.main.app``, which also wires in routers
    owned by other parallel agents — if one of those modules fails to
    import (e.g. during concurrent development), this test file keeps
    running and continues to prove the shell contract.
    """
    app = FastAPI()
    app.add_middleware(
        SessionMiddleware,
        secret_key="test-secret-key-not-used-in-prod",
        session_cookie="agentdrop_session",
        max_age=60 * 60 * 24 * 14,
        same_site="lax",
        https_only=False,
    )
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")
    app.include_router(auth_router)
    app.include_router(inbox_router)
    app.include_router(settings_router)
    return app


@pytest.fixture
def authed_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient with ``require_session`` stubbed out as a signed-in admin."""
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())

    app = _build_app()
    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as c:
            yield c
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


@pytest.fixture
def unauthed_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient that exercises the real ``require_session`` dependency
    (no session cookie present → 303 to /login)."""
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    monkeypatch.delenv("AGENTDROP_ADMIN_PASSWORD", raising=False)
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())

    try:
        with TestClient(_build_app()) as c:
            yield c
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


# ---------------------------------------------------------------------------
# /settings redirect
# ---------------------------------------------------------------------------


def test_settings_root_authed_redirects_to_channels(authed_client: TestClient) -> None:
    response = authed_client.get("/settings", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/settings/channels"


def test_settings_root_slash_authed_redirects_to_channels(authed_client: TestClient) -> None:
    response = authed_client.get("/settings/", follow_redirects=False)
    assert response.status_code == 303
    assert response.headers["location"] == "/settings/channels"


def test_settings_root_unauthed_redirects_to_login(unauthed_client: TestClient) -> None:
    response = unauthed_client.get("/settings", follow_redirects=False)
    assert response.status_code == 303
    location = response.headers["location"]
    assert location.startswith("/login")
    assert "next=" in location


# ---------------------------------------------------------------------------
# /static/settings.css
# ---------------------------------------------------------------------------


def test_settings_css_served(authed_client: TestClient) -> None:
    response = authed_client.get("/static/settings.css")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("text/css")

    body = response.text
    # Shell anchor selector the _base template relies on.
    assert ".settings-shell" in body
    # At least one design-token reference — proves tokens drive colours.
    assert "var(--color-" in body
    # Mobile breakpoint present.
    assert "@media (max-width: 640px)" in body


def test_settings_css_has_button_and_card_variants(authed_client: TestClient) -> None:
    """Agents A/B target these selectors — lock them in."""
    body = authed_client.get("/static/settings.css").text
    for selector in (
        ".btn",
        ".btn--primary",
        ".btn--danger",
        ".btn--ghost",
        ".card",
        ".form-field",
        ".flash--success",
        ".flash--error",
        ".data-table",
    ):
        assert selector in body, f"missing selector {selector!r}"


# ---------------------------------------------------------------------------
# settings/_base.html template
# ---------------------------------------------------------------------------


def test_settings_base_template_parses() -> None:
    """Loading the template via the shared Jinja env smokes-out syntax errors."""
    template = templates.get_template("settings/_base.html")
    html = template.render(active_section="channels", section_title="Channels")
    # Brand + nav
    assert "Settings" in html
    assert 'href="/settings/channels"' in html
    assert 'href="/settings/api-keys"' in html
    # Active highlight wired up for the correct section.
    assert "settings-nav__item--active" in html
    # Logout affordance present in the shell.
    assert 'action="/logout"' in html
    assert "Log out" in html
    # Body class distinguishes the section for CSS.
    assert "settings--channels" in html


def test_settings_base_template_active_section_api_keys() -> None:
    """The active-section highlight follows the passed context, not a
    hard-coded value."""
    template = templates.get_template("settings/_base.html")
    html = template.render(active_section="api-keys", section_title="API keys")
    assert "settings--api-keys" in html


# ---------------------------------------------------------------------------
# Inbox page carries a /settings link
# ---------------------------------------------------------------------------


def test_inbox_has_settings_link(authed_client: TestClient) -> None:
    response = authed_client.get("/")
    assert response.status_code == 200
    assert 'href="/settings"' in response.text
