"""Tests for the ``encrypt channel config_json`` alembic migration (issue #17).

Builds a temp SQLite database with a plaintext-JSON ``channels`` table
seeded by hand, runs the migration's ``upgrade()`` function in-process
against that bind, and asserts every row is now a Fernet token that
decrypts back to the original dict.

The migration module imports :mod:`agentdrop.crypto.secrets`, which uses
the ``AGENTDROP_ENCRYPTION_KEY`` already set in ``conftest.py``. We
override it per-test for hermeticism.
"""

from __future__ import annotations

import base64
import importlib.util
import json
import secrets
from pathlib import Path

import pytest
from alembic.migration import MigrationContext
from alembic.operations import Operations
from sqlalchemy import create_engine, text

from agentdrop.config import get_settings
from agentdrop.crypto.secrets import decrypt


def _gen_key() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()


def _seed_legacy_channels_table(db_url: str, rows: list[tuple[str, str]]) -> None:
    """Build a minimal pre-migration ``channels`` table and insert ``rows``.

    ``rows`` is ``[(id, plaintext_json_str), ...]``.
    """
    engine = create_engine(db_url, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE channels (
                    id VARCHAR(32) PRIMARY KEY,
                    name VARCHAR(80) NOT NULL UNIQUE,
                    driver VARCHAR(32) NOT NULL,
                    config_json JSON NOT NULL,
                    is_default BOOLEAN NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        for i, (row_id, payload) in enumerate(rows):
            conn.execute(
                text(
                    "INSERT INTO channels (id, name, driver, config_json) "
                    "VALUES (:id, :name, :driver, :cfg)"
                ),
                {
                    "id": row_id,
                    "name": f"ch-{i}",
                    "driver": "pushover",
                    "cfg": payload,
                },
            )
    engine.dispose()


def _run_upgrade(db_url: str) -> None:
    """Run the migration's ``upgrade()`` against a real connection.

    We import the migration module directly and drive it via
    ``MigrationContext`` + ``Operations`` so the test doesn't need to
    bootstrap the full alembic env (which insists on a configured
    settings url and prepends sys.path).
    """
    # Module name is the file stem; importlib needs the dotted path.
    module_name = "alembic.versions.2026_04_26_1255-c802d6b40e1b_encrypt_channel_config_json"
    # ``alembic.versions`` isn't a package on disk in this layout; load
    # the file by path instead.
    here = Path(__file__).resolve().parents[1]
    mig_path = (
        here
        / "alembic"
        / "versions"
        / "2026_04_26_1255-c802d6b40e1b_encrypt_channel_config_json.py"
    )
    spec = importlib.util.spec_from_file_location(module_name, mig_path)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    engine = create_engine(db_url, future=True)
    with engine.begin() as conn:
        ctx = MigrationContext.configure(
            connection=conn,
            opts={"render_as_batch": True},
        )
        with Operations.context(ctx):
            module.upgrade()
    engine.dispose()


def test_migration_encrypts_existing_rows(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()

    db_path = tmp_path / "agentdrop.db"
    db_url = f"sqlite:///{db_path}"

    payloads = [
        {"token": "secret-pushover", "user": "u-abc"},
        {"url": "https://ntfy.sh/private", "auth": "Bearer xyz"},
        {"webhook_url": "https://example.test/h", "secret": "abc"},
    ]
    seed = [
        (f"ch_{i:020d}", json.dumps(p, separators=(",", ":"), sort_keys=True))
        for i, p in enumerate(payloads)
    ]
    _seed_legacy_channels_table(db_url, seed)

    _run_upgrade(db_url)

    engine = create_engine(db_url, future=True)
    with engine.connect() as conn:
        rows = conn.execute(text("SELECT id, config_json FROM channels ORDER BY id")).fetchall()
    engine.dispose()

    assert len(rows) == len(payloads)
    for (row_id, raw), original in zip(rows, payloads, strict=True):
        assert isinstance(raw, str), (row_id, raw)
        assert raw.startswith("gAAAAA"), raw[:20]
        # Plaintext secrets must not be in the on-disk value.
        for v in original.values():
            assert v not in raw
        # And the cipher decrypts back to the original dict.
        assert json.loads(decrypt(raw)) == original


def test_migration_is_idempotent(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Running the upgrade twice doesn't double-encrypt."""
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()

    db_path = tmp_path / "agentdrop.db"
    db_url = f"sqlite:///{db_path}"

    original = {"token": "rerun-safe", "user": "u"}
    _seed_legacy_channels_table(
        db_url,
        [("ch_00000000000000000001", json.dumps(original, sort_keys=True))],
    )

    _run_upgrade(db_url)
    _run_upgrade(db_url)  # second run must be a no-op

    engine = create_engine(db_url, future=True)
    with engine.connect() as conn:
        raw = conn.execute(text("SELECT config_json FROM channels")).scalar_one()
    engine.dispose()

    assert raw.startswith("gAAAAA")
    assert json.loads(decrypt(raw)) == original


def test_migration_skips_empty_and_null(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """NULL / empty-string config_json values are left alone."""
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()

    db_path = tmp_path / "agentdrop.db"
    db_url = f"sqlite:///{db_path}"

    # Build the table allowing NULL for this test only.
    engine = create_engine(db_url, future=True)
    with engine.begin() as conn:
        conn.execute(
            text(
                """
                CREATE TABLE channels (
                    id VARCHAR(32) PRIMARY KEY,
                    name VARCHAR(80) NOT NULL UNIQUE,
                    driver VARCHAR(32) NOT NULL,
                    config_json JSON,
                    is_default BOOLEAN NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
                """
            )
        )
        conn.execute(
            text(
                "INSERT INTO channels (id, name, driver, config_json) "
                "VALUES (:id, :name, :driver, :cfg)"
            ),
            {"id": "ch_null", "name": "null", "driver": "pushover", "cfg": None},
        )
        conn.execute(
            text(
                "INSERT INTO channels (id, name, driver, config_json) "
                "VALUES (:id, :name, :driver, :cfg)"
            ),
            {"id": "ch_empty", "name": "empty", "driver": "pushover", "cfg": ""},
        )
    engine.dispose()

    _run_upgrade(db_url)

    engine = create_engine(db_url, future=True)
    with engine.connect() as conn:
        rows = dict(conn.execute(text("SELECT id, config_json FROM channels")).fetchall())
    engine.dispose()

    assert rows["ch_null"] is None
    assert rows["ch_empty"] == ""
