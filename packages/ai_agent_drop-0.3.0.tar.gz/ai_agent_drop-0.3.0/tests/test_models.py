"""Smoke tests for the ORM models.

These tests sidestep Alembic by running ``Base.metadata.create_all`` on an
in-memory SQLite engine. They don't assert anything about migration
ordering — that belongs in a dedicated alembic test.
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from agentdrop.db.base import Base
from agentdrop.models import ApiKey, Channel, Drop, Event


@pytest.fixture
def session() -> Iterator[Session]:
    engine = create_engine("sqlite://", future=True)
    Base.metadata.create_all(engine)
    with Session(engine) as s:
        yield s
    engine.dispose()


def test_insert_drop(session: Session) -> None:
    drop = Drop(title="Hello", body="World", content_md="# hi")
    session.add(drop)
    session.commit()
    session.refresh(drop)

    assert drop.id.startswith("drp_")
    assert len(drop.short_id) == 24
    assert drop.priority == "normal"
    assert drop.tags_json == []
    assert drop.created_at is not None


def test_channel_links_to_drops(session: Session) -> None:
    channel = Channel(name="primary", driver="pushover", config_json={"user": "u", "token": "t"})
    session.add(channel)
    session.flush()

    assert channel.id.startswith("ch_")

    drop = Drop(title="T", body="B", content_md="x", channel_id=channel.id)
    session.add(drop)
    session.commit()
    session.refresh(drop)
    session.refresh(channel)

    assert drop.channel_id == channel.id
    assert drop.channel is not None
    assert drop.channel.name == "primary"
    assert [d.id for d in channel.drops] == [drop.id]


def test_insert_api_key(session: Session) -> None:
    key = ApiKey(key_hash="sha256:deadbeef", label="laptop")
    session.add(key)
    session.commit()
    session.refresh(key)

    assert key.id.startswith("ak_")
    assert key.revoked_at is None
    assert key.last_used_at is None


def test_insert_event(session: Session) -> None:
    drop = Drop(title="T", body="B", content_md="x")
    session.add(drop)
    session.flush()

    event = Event(
        drop_id=drop.id,
        kind="notification_sent",
        detail_json={"channel": "pushover", "status": 200},
    )
    session.add(event)
    session.commit()
    session.refresh(event)

    assert event.id.startswith("evt_")
    assert event.drop_id == drop.id
    assert event.detail_json["channel"] == "pushover"


def test_event_without_drop(session: Session) -> None:
    """drop_id is nullable — sweep-level events need no drop context."""
    event = Event(kind="retention_swept", detail_json={"purged": 0})
    session.add(event)
    session.commit()
    session.refresh(event)

    assert event.id.startswith("evt_")
    assert event.drop_id is None
