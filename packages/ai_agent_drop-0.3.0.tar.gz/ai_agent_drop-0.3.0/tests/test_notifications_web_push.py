"""Tests for the Web Push notification driver.

Focus: chunking + cap behaviour added in issue #14 E1. The driver iterates
the ``push_subscriptions`` table; without a cap, a popular deployment
would buffer every device into memory and POST serially before returning.

These tests stub out ``WebPushDriver._send_one`` so they don't make any
real HTTP calls — we're testing the loop, not pywebpush itself.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Iterator
from pathlib import Path

import pytest
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.notifications.web_push import WebPushDriver

# A real, freshly-generated P-256 VAPID keypair. ``WebPushDriver.__init__``
# decodes this and constructs a ``py_vapid.Vapid`` from it; using a real
# key avoids having to monkeypatch ``Vapid.from_raw`` everywhere.
_TEST_VAPID_PUBLIC = (
    "BLh8d7UHlqpDFp5txyN-ZRpyo4JAPBYER6jC-FeQzByjD526I3b0mn-7-zInS8QGsrO3IRpawyeBQnXX1esQZjM"
)
_TEST_VAPID_PRIVATE = "5fIjsjBFqAHbC1eDJUSKaW9391fpMCRQRmLNu_RjE9Q"
_TEST_VAPID_SUBJECT = "mailto:ops@example.com"


@pytest.fixture
def db(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> Iterator[Callable[[], Session]]:
    """Spin up an isolated SQLite DB and return a session factory."""
    db_path = tmp_path / "web_push.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_VAPID_PUBLIC_KEY", _TEST_VAPID_PUBLIC)
    monkeypatch.setenv("AGENTDROP_VAPID_PRIVATE_KEY", _TEST_VAPID_PRIVATE)
    monkeypatch.setenv("AGENTDROP_VAPID_SUBJECT", _TEST_VAPID_SUBJECT)
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())
    SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False)
    try:
        yield SessionLocal
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


def _seed_subscriptions(session_factory: Callable[[], Session], count: int) -> None:
    with session_factory() as session:
        for i in range(count):
            session.add(
                PushSubscription(
                    endpoint=f"https://push.example/sub/{i}",
                    p256dh="x" * 32,
                    auth="y" * 16,
                    user_agent=f"test-{i}",
                )
            )
        session.commit()


def test_cap_limits_attempts_and_logs_warning(
    db: Callable[[], Session],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """With cap=3 and 5 subs, only 3 sends fire and a warning is emitted."""
    monkeypatch.setenv("AGENTDROP_MAX_PUSH_SUBSCRIPTIONS", "3")
    get_settings.cache_clear()

    _seed_subscriptions(db, 5)

    sent: list[str] = []

    def fake_send_one(
        self: WebPushDriver, sub: PushSubscription, payload: str
    ) -> tuple[bool, str | None]:
        sent.append(sub.endpoint)
        return True, None

    monkeypatch.setattr(WebPushDriver, "_send_one", fake_send_one)

    driver = WebPushDriver({}, session_factory=db)
    with caplog.at_level(logging.WARNING, logger="agentdrop.notifications.web_push"):
        result = driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert len(sent) == 3, f"expected exactly 3 attempts, got {len(sent)}"
    assert result.ok is True
    # Warning surfaces the cap-reached condition.
    warnings = [r for r in caplog.records if r.levelno == logging.WARNING]
    assert any("cap" in r.getMessage().lower() for r in warnings), [
        r.getMessage() for r in warnings
    ]


def test_no_warning_when_under_cap(
    db: Callable[[], Session],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    monkeypatch.setenv("AGENTDROP_MAX_PUSH_SUBSCRIPTIONS", "10")
    get_settings.cache_clear()

    _seed_subscriptions(db, 3)

    sent: list[str] = []

    def fake_send_one(
        self: WebPushDriver, sub: PushSubscription, payload: str
    ) -> tuple[bool, str | None]:
        sent.append(sub.endpoint)
        return True, None

    monkeypatch.setattr(WebPushDriver, "_send_one", fake_send_one)

    driver = WebPushDriver({}, session_factory=db)
    with caplog.at_level(logging.WARNING, logger="agentdrop.notifications.web_push"):
        result = driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert len(sent) == 3
    assert result.ok is True
    cap_warnings = [
        r
        for r in caplog.records
        if r.levelno == logging.WARNING and "cap" in r.getMessage().lower()
    ]
    assert cap_warnings == []


def test_default_cap_is_one_hundred(
    db: Callable[[], Session],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """If the env var isn't set, the default cap is 100."""
    # Nuke any inherited override so we read the model default.
    monkeypatch.delenv("AGENTDROP_MAX_PUSH_SUBSCRIPTIONS", raising=False)
    get_settings.cache_clear()

    settings = get_settings()
    assert settings.max_push_subscriptions == 100


def test_no_subscriptions_returns_no_op(
    db: Callable[[], Session],
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Empty table — driver returns ok with a "no subscriptions" detail."""
    monkeypatch.setenv("AGENTDROP_MAX_PUSH_SUBSCRIPTIONS", "100")
    get_settings.cache_clear()

    def fake_send_one(
        self: WebPushDriver, sub: PushSubscription, payload: str
    ) -> tuple[bool, str | None]:
        raise AssertionError("should not be called when no subscriptions exist")

    monkeypatch.setattr(WebPushDriver, "_send_one", fake_send_one)

    driver = WebPushDriver({}, session_factory=db)
    result = driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority="normal",
    )
    assert result.ok is True
    assert result.detail == "no subscriptions"
