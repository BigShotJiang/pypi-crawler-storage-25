"""Unit tests for :func:`agentdrop.notifications.resolver.resolve_default_channel`.

Covers the precedence table in the resolver's docstring:

* no DB channels -> ``None``
* 1 non-default channel -> that channel
* N channels, one default -> default channel
* N channels, no default -> ``None``
* N channels, multiple defaults (defensive) -> most recent wins

The resolver is DB-coupled but FastAPI-free, so these tests build a
fresh SQLite engine per test and hand sessions straight to the callable.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.models import Channel
from agentdrop.notifications.resolver import resolve_default_channel


@pytest.fixture
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Session]:
    """Fresh SQLite DB + session. Clears all caches that touch env/engine."""
    db_path = tmp_path / "resolver.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()

    engine = get_engine()
    Base.metadata.create_all(engine)
    SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        get_engine.cache_clear()
        get_settings.cache_clear()


def _add_channel(
    db: Session,
    *,
    name: str,
    driver: str = "ntfy",
    config: dict | None = None,
    is_default: bool = False,
) -> Channel:
    """Persist a channel and return the refreshed row."""
    channel = Channel(
        name=name,
        driver=driver,
        config_json=config or {"topic": f"topic-{name}"},
        is_default=is_default,
    )
    db.add(channel)
    db.commit()
    db.refresh(channel)
    return channel


# ---------------------------------------------------------------------------
# Precedence cases
# ---------------------------------------------------------------------------


def test_no_channels_returns_none(db: Session) -> None:
    assert resolve_default_channel(db) is None


def test_single_non_default_channel_is_chosen(db: Session) -> None:
    _add_channel(db, name="only", driver="ntfy", config={"topic": "t"})

    resolved = resolve_default_channel(db)
    assert resolved is not None
    assert resolved[0] == "ntfy"
    assert resolved[1] == {"topic": "t"}


def test_multiple_channels_one_default_picks_default(db: Session) -> None:
    _add_channel(db, name="a", driver="ntfy", config={"topic": "a"})
    _add_channel(
        db, name="b", driver="pushover", config={"token": "t", "user": "u"}, is_default=True
    )

    resolved = resolve_default_channel(db)
    assert resolved is not None
    assert resolved[0] == "pushover"
    assert resolved[1] == {"token": "t", "user": "u"}


def test_multiple_channels_no_default_returns_none(db: Session) -> None:
    _add_channel(db, name="a", driver="ntfy", config={"topic": "a"})
    _add_channel(db, name="b", driver="ntfy", config={"topic": "b"})

    assert resolve_default_channel(db) is None


def test_multiple_defaults_picks_most_recent(db: Session) -> None:
    from datetime import UTC, datetime, timedelta

    older = _add_channel(db, name="older", driver="ntfy", config={"topic": "old"}, is_default=True)
    newer = _add_channel(db, name="newer", driver="ntfy", config={"topic": "new"}, is_default=True)

    # SQLite's CURRENT_TIMESTAMP has 1s granularity so two back-to-back
    # inserts may tie. Pin the ordering explicitly.
    now = datetime.now(UTC)
    older_row = db.query(type(older)).filter_by(id=older.id).one()
    older_row.created_at = now - timedelta(seconds=10)
    newer_row = db.query(type(newer)).filter_by(id=newer.id).one()
    newer_row.created_at = now
    db.commit()

    resolved = resolve_default_channel(db)
    assert resolved is not None
    # "newer" was created last.
    assert resolved[1] == {"topic": "new"}
