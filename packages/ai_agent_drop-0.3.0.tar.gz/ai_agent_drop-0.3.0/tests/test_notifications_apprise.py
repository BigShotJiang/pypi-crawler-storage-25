"""Tests for the Apprise notification driver.

The driver's :meth:`AppriseDriver._build_apprise` is monkeypatched to return a
:class:`_FakeApprise` instance that records every ``.add()`` and ``.notify()``
call and returns scripted booleans. No real network — or real Apprise plugin
— is ever exercised.
"""

from __future__ import annotations

from typing import Any

import apprise
import pytest

from agentdrop.notifications import DRIVERS, get_driver
from agentdrop.notifications.apprise_driver import AppriseDriver
from agentdrop.notifications.base import (
    DeliveryResult,
    DriverConfigError,
    DriverDeliveryError,
)


class _FakeApprise:
    """Minimal stand-in for :class:`apprise.Apprise` that records calls."""

    def __init__(
        self,
        *,
        add_results: dict[str, bool] | None = None,
        notify_result: bool = True,
        notify_raises: BaseException | None = None,
    ) -> None:
        # ``add_results`` maps URL -> bool to let tests mark specific URLs as
        # unparseable. Any URL not in the map defaults to True.
        self._add_results = add_results or {}
        self._notify_result = notify_result
        self._notify_raises = notify_raises
        self.added: list[str] = []
        self.notify_calls: list[dict[str, Any]] = []

    def add(self, url: str) -> bool:
        self.added.append(url)
        return self._add_results.get(url, True)

    def notify(self, **kwargs: Any) -> bool:
        self.notify_calls.append(kwargs)
        if self._notify_raises is not None:
            raise self._notify_raises
        return self._notify_result


def _make_driver(
    config: dict[str, Any],
    fake: _FakeApprise | None = None,
    monkeypatch: pytest.MonkeyPatch | None = None,
) -> tuple[AppriseDriver, _FakeApprise]:
    """Build an ``AppriseDriver`` whose Apprise instance is a controllable fake.

    The fake is injected by monkeypatching :meth:`AppriseDriver._build_apprise`
    **before** the driver's ``__init__`` runs (since ``__init__`` calls
    ``_build_apprise`` and then ``.add()`` on every configured URL).
    """
    fake = fake if fake is not None else _FakeApprise()
    if monkeypatch is None:
        monkeypatch = pytest.MonkeyPatch()
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: fake)
    driver = AppriseDriver(config)
    return driver, fake


# ---------------------------------------------------------------------------
# Config validation
# ---------------------------------------------------------------------------


def test_missing_urls_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    with pytest.raises(DriverConfigError):
        AppriseDriver({})


def test_empty_url_list_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    with pytest.raises(DriverConfigError):
        AppriseDriver({"urls": []})


def test_non_string_url_entry_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    with pytest.raises(DriverConfigError):
        AppriseDriver({"urls": [123]})


def test_invalid_url_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = _FakeApprise(add_results={"pover://user@token": False})
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: fake)

    with pytest.raises(DriverConfigError) as excinfo:
        AppriseDriver({"urls": ["pover://user@token"]})

    # Error must name the scheme only — never the raw URL (it carries creds).
    message = str(excinfo.value)
    assert "pover" in message
    assert "<redacted>" in message
    assert "user@token" not in message


def test_invalid_body_format_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    with pytest.raises(DriverConfigError):
        AppriseDriver({"urls": ["tgram://abc/123"], "body_format": "rtf"})


def test_blank_tag_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    with pytest.raises(DriverConfigError):
        AppriseDriver({"urls": ["tgram://abc/123"], "tag": "   "})


# ---------------------------------------------------------------------------
# Happy path
# ---------------------------------------------------------------------------


def test_send_happy_path_returns_delivery_result(monkeypatch: pytest.MonkeyPatch) -> None:
    driver, fake = _make_driver({"urls": ["tgram://abc/123"]}, monkeypatch=monkeypatch)

    result = driver.send(
        title="Hello",
        body="hello world",
        url="https://drop.example/d/abc123",
        priority="normal",
    )

    assert isinstance(result, DeliveryResult)
    assert result.ok is True
    assert result.driver == "apprise"
    assert fake.added == ["tgram://abc/123"]
    assert len(fake.notify_calls) == 1

    call = fake.notify_calls[0]
    assert call["title"] == "Hello"
    # Drop URL is appended to the body so it remains tappable on providers
    # without a dedicated "click URL" field.
    assert call["body"].endswith("https://drop.example/d/abc123")
    assert "hello world" in call["body"]


def test_send_failure_raises_delivery_error(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = _FakeApprise(notify_result=False)
    driver, _ = _make_driver({"urls": ["tgram://abc/123"]}, fake=fake, monkeypatch=monkeypatch)

    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert "apprise" in str(excinfo.value).lower()


def test_notify_exception_wrapped_in_delivery_error(monkeypatch: pytest.MonkeyPatch) -> None:
    fake = _FakeApprise(notify_raises=RuntimeError("boom"))
    driver, _ = _make_driver({"urls": ["tgram://abc/123"]}, fake=fake, monkeypatch=monkeypatch)

    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="normal",
        )

    assert "RuntimeError" in str(excinfo.value)


# ---------------------------------------------------------------------------
# Priority mapping
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("priority", "expected"),
    [
        ("low", apprise.NotifyType.INFO),
        ("normal", apprise.NotifyType.INFO),
        ("high", apprise.NotifyType.WARNING),
        ("urgent", apprise.NotifyType.FAILURE),
    ],
)
def test_priority_mapping(monkeypatch: pytest.MonkeyPatch, priority: str, expected: str) -> None:
    driver, fake = _make_driver({"urls": ["tgram://abc/123"]}, monkeypatch=monkeypatch)
    driver.send(
        title="t",
        body="b",
        url="https://drop.example/d/x",
        priority=priority,  # type: ignore[arg-type]
    )

    assert fake.notify_calls[-1]["notify_type"] == expected


# ---------------------------------------------------------------------------
# Tag + body_format passthrough
# ---------------------------------------------------------------------------


def test_tag_is_forwarded_when_set(monkeypatch: pytest.MonkeyPatch) -> None:
    driver, fake = _make_driver(
        {"urls": ["tgram://abc/123"], "tag": "ops"},
        monkeypatch=monkeypatch,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert fake.notify_calls[-1]["tag"] == "ops"


def test_tag_omitted_when_not_set(monkeypatch: pytest.MonkeyPatch) -> None:
    driver, fake = _make_driver({"urls": ["tgram://abc/123"]}, monkeypatch=monkeypatch)
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert "tag" not in fake.notify_calls[-1]


def test_body_format_defaults_to_markdown(monkeypatch: pytest.MonkeyPatch) -> None:
    driver, fake = _make_driver({"urls": ["tgram://abc/123"]}, monkeypatch=monkeypatch)
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert fake.notify_calls[-1]["body_format"] == apprise.NotifyFormat.MARKDOWN


@pytest.mark.parametrize(
    ("configured", "expected"),
    [
        ("text", apprise.NotifyFormat.TEXT),
        ("markdown", apprise.NotifyFormat.MARKDOWN),
        ("html", apprise.NotifyFormat.HTML),
    ],
)
def test_body_format_forwarded(
    monkeypatch: pytest.MonkeyPatch, configured: str, expected: str
) -> None:
    driver, fake = _make_driver(
        {"urls": ["tgram://abc/123"], "body_format": configured},
        monkeypatch=monkeypatch,
    )
    driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert fake.notify_calls[-1]["body_format"] == expected


# ---------------------------------------------------------------------------
# Registry wiring
# ---------------------------------------------------------------------------


def test_registry_contains_apprise() -> None:
    assert "apprise" in DRIVERS
    assert DRIVERS["apprise"] is AppriseDriver


def test_get_driver_apprise_returns_instance(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(AppriseDriver, "_build_apprise", lambda self: _FakeApprise())
    driver = get_driver("apprise", {"urls": ["tgram://abc/123"]})
    assert isinstance(driver, AppriseDriver)
