"""Unit tests for ``agentdrop.net.ssrf.validate_outbound_url``.

Covers each blocked range (IPv4 + IPv6), reserved hostnames, IDN
homograph rejection, the ``AGENTDROP_ALLOW_PRIVATE_OUTBOUND`` opt-out,
and the DNS-rebinding scenario where ``getaddrinfo`` returns a private
IP for an otherwise-public hostname.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import Any

import pytest

from agentdrop.config import get_settings
from agentdrop.net import ssrf
from agentdrop.net.ssrf import OutboundUrlError, validate_outbound_url


@pytest.fixture(autouse=True)
def _clear_settings(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    monkeypatch.delenv("AGENTDROP_ALLOW_PRIVATE_OUTBOUND", raising=False)
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def _patch_resolution(monkeypatch: pytest.MonkeyPatch, addrs: list[str]) -> None:
    """Force ``_resolve`` to return ``addrs`` for any hostname."""
    monkeypatch.setattr(ssrf, "_resolve", lambda hostname: addrs)


# ---------------------------------------------------------------------------
# IP-literal blocks (IPv4 and IPv6)
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url",
    [
        "http://127.0.0.1/",
        "http://127.1.2.3:8080/x",
        "https://10.0.0.1/",
        "https://10.255.255.255/",
        "https://172.16.0.1/",
        "https://172.31.255.254/",
        "https://192.168.1.1/",
        "https://169.254.169.254/latest/meta-data/",
        "https://0.0.0.0/",
        "https://224.0.0.1/",
    ],
)
def test_blocks_ipv4_literal_in_private_range(url: str) -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url(url)


@pytest.mark.parametrize(
    "url",
    [
        "http://[::1]/",
        "http://[fe80::1]/",
        "http://[fc00::1]/",
        "http://[fd12:3456:789a::1]/",
        "http://[ff00::1]/",
        "http://[::]/",
    ],
)
def test_blocks_ipv6_literal_in_private_range(url: str) -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url(url)


# ---------------------------------------------------------------------------
# Hostname blocks
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url",
    [
        "http://localhost/",
        "https://localhost:8080/",
        "http://Localhost/",  # case-insensitive
        "http://broadcasthost/",
        "http://printer.local/",
        "https://router.LOCAL/",
    ],
)
def test_blocks_reserved_hostnames(url: str) -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url(url)


# ---------------------------------------------------------------------------
# DNS-rebinding scenario
# ---------------------------------------------------------------------------


def test_blocks_when_dns_resolves_to_private(monkeypatch: pytest.MonkeyPatch) -> None:
    """A public hostname that resolves to a private IP is rejected."""
    _patch_resolution(monkeypatch, ["10.0.0.1"])
    with pytest.raises(OutboundUrlError, match="resolves to blocked address"):
        validate_outbound_url("https://example.com/webhook")


def test_blocks_when_any_resolved_address_is_private(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Mixed A-record set with one private entry is rejected entirely."""
    _patch_resolution(monkeypatch, ["93.184.216.34", "127.0.0.1"])
    with pytest.raises(OutboundUrlError):
        validate_outbound_url("https://example.com/webhook")


def test_allows_when_dns_resolves_to_public(monkeypatch: pytest.MonkeyPatch) -> None:
    _patch_resolution(monkeypatch, ["93.184.216.34"])
    validate_outbound_url("https://example.com/webhook")


# ---------------------------------------------------------------------------
# IDN handling
# ---------------------------------------------------------------------------


def test_idn_hostname_resolved_via_ascii(monkeypatch: pytest.MonkeyPatch) -> None:
    """Unicode hostname is IDN-encoded before resolution."""
    seen: dict[str, Any] = {}

    def _spy(hostname: str) -> list[str]:
        seen["hostname"] = hostname
        return ["93.184.216.34"]

    monkeypatch.setattr(ssrf, "_resolve", _spy)
    validate_outbound_url("https://exämple.com/webhook")
    assert seen["hostname"] == "xn--exmple-cua.com"


def test_invalid_idn_rejected(monkeypatch: pytest.MonkeyPatch) -> None:
    # Names that cannot be IDN-encoded should raise.
    with pytest.raises(OutboundUrlError, match=r"(IDN|hostname)"):
        validate_outbound_url("https://" + "x" * 250 + ".test/")


# ---------------------------------------------------------------------------
# Opt-out flag
# ---------------------------------------------------------------------------


def test_allow_private_outbound_skips_check(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_ALLOW_PRIVATE_OUTBOUND", "1")
    get_settings.cache_clear()
    # 127.0.0.1 would normally be rejected; flag bypasses the check.
    validate_outbound_url("http://127.0.0.1:8000/webhook")
    validate_outbound_url("http://localhost/")


def test_allow_private_explicit_param_overrides_setting() -> None:
    # Explicit ``allow_private=True`` skips the check regardless of env.
    validate_outbound_url("http://10.0.0.1/", allow_private=True)


# ---------------------------------------------------------------------------
# Schemes outside the raw-HTTP set pass through
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url",
    [
        "pover://userkey@apptoken",  # Apprise Pushover
        "tgram://bottoken/chatid",  # Apprise Telegram
        "mailto:ops@example.com",
        "slack://TOKEN_A/TOKEN_B/TOKEN_C/CHANNEL",
    ],
)
def test_non_http_schemes_pass_through(url: str) -> None:
    """Service-specific Apprise schemes are not user-controllable for SSRF."""
    validate_outbound_url(url)


# ---------------------------------------------------------------------------
# Apprise raw-HTTP schemes are validated
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "url",
    [
        "json://127.0.0.1/path",
        "jsons://10.0.0.1/path",
        "form://192.168.1.1/path",
        "xml://localhost/path",
    ],
)
def test_apprise_raw_http_schemes_blocked_for_private(url: str) -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url(url)


# ---------------------------------------------------------------------------
# Empty / malformed input
# ---------------------------------------------------------------------------


def test_empty_url_rejected() -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url("")


def test_url_without_hostname_rejected() -> None:
    with pytest.raises(OutboundUrlError):
        validate_outbound_url("http:///path")


def test_dns_failure_surfaces_as_error(monkeypatch: pytest.MonkeyPatch) -> None:
    import socket

    def _fail(_hostname: str) -> list[str]:
        raise socket.gaierror("no such host")

    monkeypatch.setattr(ssrf, "_resolve", _fail)
    with pytest.raises(OutboundUrlError, match="DNS lookup failed"):
        validate_outbound_url("https://no-such-host.example/")
