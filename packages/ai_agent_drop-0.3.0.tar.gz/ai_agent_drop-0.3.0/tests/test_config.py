"""Tests for ``agentdrop.config.Settings`` validators.

Currently focused on the VAPID cross-field validator (issue #14 E3): the
three VAPID fields must be all-or-none, never partial.
"""

from __future__ import annotations

import pytest

from agentdrop.config import Settings


def _make(**overrides: object) -> Settings:
    """Build a ``Settings`` ignoring ambient ``AGENTDROP_*`` env vars.

    The conftest sets a few defaults via ``os.environ`` (encryption key,
    insecure cookies) for the rest of the suite; we want this test to be
    purely about explicit field values, so we feed them in directly and
    rely on pydantic-settings precedence (kwargs > env).
    """
    return Settings(**overrides)  # type: ignore[arg-type]


def test_vapid_all_unset_ok() -> None:
    settings = _make(
        vapid_public_key=None,
        vapid_private_key=None,
        vapid_subject=None,
    )
    assert settings.vapid_public_key is None
    assert settings.vapid_private_key is None
    assert settings.vapid_subject is None


def test_vapid_all_set_ok() -> None:
    settings = _make(
        vapid_public_key="pub",
        vapid_private_key="priv",
        vapid_subject="mailto:ops@example.com",
    )
    assert settings.vapid_public_key == "pub"
    assert settings.vapid_private_key == "priv"
    assert settings.vapid_subject == "mailto:ops@example.com"


def test_vapid_only_public_set_rejected() -> None:
    with pytest.raises(ValueError) as excinfo:
        _make(
            vapid_public_key="pub",
            vapid_private_key=None,
            vapid_subject=None,
        )
    msg = str(excinfo.value)
    assert "vapid_private_key" in msg
    assert "vapid_subject" in msg
    assert "vapid_public_key" not in msg.split("Missing:")[1]


def test_vapid_public_and_private_without_subject_rejected() -> None:
    with pytest.raises(ValueError) as excinfo:
        _make(
            vapid_public_key="pub",
            vapid_private_key="priv",
            vapid_subject=None,
        )
    msg = str(excinfo.value)
    assert "vapid_subject" in msg
    # Only the missing field should be named in the "Missing:" list.
    missing_section = msg.split("Missing:")[1]
    assert "vapid_public_key" not in missing_section
    assert "vapid_private_key" not in missing_section


def test_vapid_only_subject_set_rejected() -> None:
    with pytest.raises(ValueError) as excinfo:
        _make(
            vapid_public_key=None,
            vapid_private_key=None,
            vapid_subject="mailto:ops@example.com",
        )
    msg = str(excinfo.value)
    missing_section = msg.split("Missing:")[1]
    assert "vapid_public_key" in missing_section
    assert "vapid_private_key" in missing_section


def test_vapid_empty_strings_treated_as_unset() -> None:
    """Blank strings must not count as "set" — they came from an empty .env line."""
    settings = _make(
        vapid_public_key="",
        vapid_private_key="",
        vapid_subject="",
    )
    # No exception raised; empty-string trio is treated as all-unset.
    assert settings.vapid_public_key == ""
