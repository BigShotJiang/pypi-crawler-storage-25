"""Tests for the 5c PWA slice: service worker push/click handlers, the
UA-label heuristic, the Settings > Devices page, and its subscription
delete / test-push endpoints.

These exercise the last mile of the Web Push flow — everything below
has been covered by ``test_pwa.py`` (shell) and ``test_pwa_push.py``
(driver + subscribe endpoint). The fixtures here mirror
``test_pwa_push.py`` so both files can co-evolve.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any
from unittest.mock import patch

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import select
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.web import static_dir
from agentdrop.web.session import _get_admin_password_hash
from agentdrop.web.ua_label import label_for

from .conftest import fetch_csrf

TEST_VAPID_PUBLIC = (
    "BHG6L8wG7FUd4lB3hFmQkDoIC66u037RPc-PeZxBf_MapAjbmfULCCBtDft0IKY-IFSI8bH8qyd2-iLHLmoTaBs"
)
TEST_VAPID_PRIVATE = "nBeKH4L68UJhP8P7Mx34EkHJWsNIophoPcg3ddZ61ns"
TEST_VAPID_SUBJECT = "mailto:tests@example.com"
TEST_ADMIN_PASSWORD = "test-admin-password"


# ---------------------------------------------------------------------------
# Fixtures (mirror test_pwa_push.py; kept local so each module is readable
# on its own and the two files don't have to share state).
# ---------------------------------------------------------------------------


def _set_vapid_env(monkeypatch: pytest.MonkeyPatch, *, configured: bool) -> None:
    if configured:
        monkeypatch.setenv("AGENTDROP_VAPID_PUBLIC_KEY", TEST_VAPID_PUBLIC)
        monkeypatch.setenv("AGENTDROP_VAPID_PRIVATE_KEY", TEST_VAPID_PRIVATE)
        monkeypatch.setenv("AGENTDROP_VAPID_SUBJECT", TEST_VAPID_SUBJECT)
    else:
        monkeypatch.delenv("AGENTDROP_VAPID_PUBLIC_KEY", raising=False)
        monkeypatch.delenv("AGENTDROP_VAPID_PRIVATE_KEY", raising=False)
        monkeypatch.delenv("AGENTDROP_VAPID_SUBJECT", raising=False)


def _build_app_db(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    *,
    vapid: bool,
) -> sessionmaker[Session]:
    db_path = tmp_path / "devices.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_ADMIN_PASSWORD)
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key-for-sessions")
    _set_vapid_env(monkeypatch, configured=vapid)
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_admin_password_hash.cache_clear()
    Base.metadata.create_all(get_engine())
    return sessionmaker(bind=get_engine(), expire_on_commit=False)


@pytest.fixture
def app_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[sessionmaker[Session]]:
    factory = _build_app_db(tmp_path, monkeypatch, vapid=True)
    yield factory
    get_engine.cache_clear()
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()


@pytest.fixture
def app_db_no_vapid(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> Iterator[sessionmaker[Session]]:
    factory = _build_app_db(tmp_path, monkeypatch, vapid=False)
    yield factory
    get_engine.cache_clear()
    get_settings.cache_clear()
    _get_admin_password_hash.cache_clear()


@pytest.fixture
def authed(app_db: sessionmaker[Session]) -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        token = fetch_csrf(test_client)
        response = test_client.post(
            "/login",
            data={"password": TEST_ADMIN_PASSWORD, "next": "/", "_csrf": token},
            follow_redirects=False,
        )
        assert response.status_code == 303, response.text
        yield test_client


@pytest.fixture
def authed_no_vapid(app_db_no_vapid: sessionmaker[Session]) -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        token = fetch_csrf(test_client)
        response = test_client.post(
            "/login",
            data={"password": TEST_ADMIN_PASSWORD, "next": "/", "_csrf": token},
            follow_redirects=False,
        )
        assert response.status_code == 303, response.text
        yield test_client


def _seed_sub(
    factory: sessionmaker[Session],
    *,
    endpoint: str = "https://push.example/one",
    user_agent: str | None = None,
) -> str:
    with factory() as session:
        sub = PushSubscription(
            endpoint=endpoint,
            p256dh="p256dh-stub",
            auth="auth-stub",
            user_agent=user_agent,
        )
        session.add(sub)
        session.commit()
        session.refresh(sub)
        return sub.id


# ---------------------------------------------------------------------------
# Service worker content
# ---------------------------------------------------------------------------


def test_service_worker_handles_push_event() -> None:
    sw_text = (static_dir / "sw.js").read_text(encoding="utf-8")
    assert 'self.addEventListener("push"' in sw_text
    # Decoding the JSON payload is how the driver and worker speak — if
    # the worker silently only reads .text(), the JSON contract is broken.
    assert "event.data.json()" in sw_text
    assert "showNotification" in sw_text


def test_service_worker_handles_notificationclick() -> None:
    sw_text = (static_dir / "sw.js").read_text(encoding="utf-8")
    assert 'self.addEventListener("notificationclick"' in sw_text
    # Prefer focusing an existing tab over opening a new one — otherwise
    # every tap spawns a duplicate window.
    assert "matchAll" in sw_text
    assert "openWindow" in sw_text


# ---------------------------------------------------------------------------
# UA label heuristic
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "ua,expected",
    [
        # Real(ish) UAs from the common self-hoster browsers. Version
        # strings are stripped from the assertion on purpose — we don't
        # want this test to care whether Safari is on 17 or 18.
        (
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
            "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            "iPhone · Safari",
        ),
        (
            "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
            "iPad · Safari",
        ),
        (
            "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
            "Android · Chrome",
        ),
        (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "macOS · Chrome",
        ),
        (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
            "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
            "macOS · Safari",
        ),
        (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.2478.97",
            "Windows · Edge",
        ),
        (
            "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
            "Linux · Firefox",
        ),
    ],
)
def test_ua_label_common_browsers(ua: str, expected: str) -> None:
    assert label_for(ua) == expected


def test_ua_label_falls_back_for_missing_ua() -> None:
    assert label_for(None) == "Unknown device"
    assert label_for("") == "Unknown device"


def test_ua_label_trims_unrecognised_strings() -> None:
    weird = "NetFront/4.2 (something extremely long that should get truncated)"
    result = label_for(weird)
    # Unknown OS, unknown browser → returns (possibly trimmed) raw UA.
    assert result.startswith("NetFront") or len(result) <= 60


# ---------------------------------------------------------------------------
# Devices page rendering
# ---------------------------------------------------------------------------


def test_devices_page_requires_session(app_db: sessionmaker[Session]) -> None:
    with TestClient(app) as client:
        response = client.get("/settings/devices", follow_redirects=False)
    assert response.status_code == 303
    assert "/login" in response.headers["location"]


def test_devices_nav_includes_devices_entry(authed: TestClient) -> None:
    response = authed.get("/settings/devices")
    assert response.status_code == 200
    assert 'href="/settings/devices"' in response.text
    assert "Devices" in response.text


def test_devices_page_empty_state(authed: TestClient) -> None:
    response = authed.get("/settings/devices")
    assert response.status_code == 200
    assert "No devices subscribed yet" in response.text
    # The "this browser" card and the subscribe JS should be present when
    # VAPID is configured.
    assert "data-devices-root" in response.text
    assert "/static/push.js" in response.text


def test_devices_page_lists_subscriptions_with_friendly_labels(
    authed: TestClient, app_db: sessionmaker[Session]
) -> None:
    _seed_sub(
        app_db,
        endpoint="https://push.example/iphone",
        user_agent=(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
            "AppleWebKit/605.1.15 Safari/604.1"
        ),
    )
    _seed_sub(
        app_db,
        endpoint="https://push.example/mac",
        user_agent=(
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
            "Chrome/124.0.0.0 Safari/537.36"
        ),
    )
    response = authed.get("/settings/devices")
    assert response.status_code == 200
    body = response.text
    assert "iPhone · Safari" in body
    assert "macOS · Chrome" in body
    # Delete action per row.
    assert body.count("/delete") >= 2


def test_devices_page_shows_vapid_unconfigured_banner(
    authed_no_vapid: TestClient,
) -> None:
    response = authed_no_vapid.get("/settings/devices")
    assert response.status_code == 200
    # No JS subscription flow without VAPID; the card renders an
    # explanatory banner instead and the script is omitted.
    assert "isn't configured" in response.text
    assert "/static/push.js" not in response.text


# ---------------------------------------------------------------------------
# Delete subscription
# ---------------------------------------------------------------------------


def test_delete_subscription_removes_row(authed: TestClient, app_db: sessionmaker[Session]) -> None:
    sub_id = _seed_sub(app_db, endpoint="https://push.example/gone")
    response = authed.post(
        f"/settings/devices/{sub_id}/delete",
        data={"_csrf": fetch_csrf(authed)},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert "/settings/devices?notice=deleted" in response.headers["location"]

    with app_db() as session:
        remaining = session.execute(
            select(PushSubscription).where(PushSubscription.id == sub_id)
        ).scalar_one_or_none()
    assert remaining is None


def test_delete_unknown_subscription_returns_404(authed: TestClient) -> None:
    response = authed.post(
        "/settings/devices/psub_does_not_exist/delete",
        data={"_csrf": fetch_csrf(authed)},
    )
    assert response.status_code == 404


# ---------------------------------------------------------------------------
# Test push
# ---------------------------------------------------------------------------


def test_test_push_without_vapid_redirects_failed(
    authed_no_vapid: TestClient,
) -> None:
    response = authed_no_vapid.post(
        "/settings/devices/test",
        data={"_csrf": fetch_csrf(authed_no_vapid)},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert "notice=failed" in response.headers["location"]
    assert "VAPID" in response.headers["location"] or "configured" in response.headers["location"]


def test_test_push_with_no_subs_reports_empty(authed: TestClient) -> None:
    response = authed.post(
        "/settings/devices/test",
        data={"_csrf": fetch_csrf(authed)},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert "notice=sent-empty" in response.headers["location"]


def test_test_push_with_subs_fires_driver(
    authed: TestClient, app_db: sessionmaker[Session]
) -> None:
    _seed_sub(app_db, endpoint="https://push.example/alpha")
    _seed_sub(app_db, endpoint="https://push.example/beta")

    captured: list[dict[str, Any]] = []

    def _fake_webpush(**kwargs: Any) -> None:
        captured.append(kwargs)

    with patch("agentdrop.notifications.web_push.webpush", side_effect=_fake_webpush):
        response = authed.post(
            "/settings/devices/test",
            data={"_csrf": fetch_csrf(authed)},
            follow_redirects=False,
        )
    assert response.status_code == 303
    assert "notice=sent-ok" in response.headers["location"]
    # Fanned out to both stored subs.
    assert len(captured) == 2


def test_test_push_surface_driver_failure(
    authed: TestClient, app_db: sessionmaker[Session]
) -> None:
    _seed_sub(app_db, endpoint="https://push.example/alpha")

    def _explode(**kwargs: Any) -> None:
        raise RuntimeError("boom")

    with patch("agentdrop.notifications.web_push.webpush", side_effect=_explode):
        response = authed.post(
            "/settings/devices/test",
            data={"_csrf": fetch_csrf(authed)},
            follow_redirects=False,
        )
    assert response.status_code == 303
    assert "notice=failed" in response.headers["location"]
