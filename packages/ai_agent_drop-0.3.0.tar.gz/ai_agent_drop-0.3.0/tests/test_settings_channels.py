"""End-to-end tests for ``/settings/channels/*``.

Exercises:

* Auth posture (unauth'd -> 303 /login for every route).
* List empty + populated states.
* Create / edit / delete / set-default / test-fire.
* Validation surfaces (name shape, JSON parse, driver config errors,
  duplicate names).
* Secret-preserving edit merge (user leaves masked fields at their
  placeholder; old secrets survive).
* Test-fire happy + failure paths, with ``get_driver`` monkeypatched
  so no real HTTP traffic leaves the process.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app
from agentdrop.models import Channel
from agentdrop.notifications import DeliveryResult, Driver
from agentdrop.web import settings_channels as channels_mod
from agentdrop.web.session import Admin, require_session

from .conftest import fetch_csrf


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Logged-in TestClient on a fresh SQLite DB.

    Mirrors the pattern in ``test_drop_actions.py`` / ``test_admin_retention.py``:
    ``require_session`` is overridden with a sentinel ``Admin`` so we don't
    have to drive the real login flow. One test clears the override to
    exercise the redirect-to-login path.
    """
    db_path = tmp_path / "settings_channels.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")

    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _session() -> Session:
    """Return a fresh Session bound to the currently active engine."""
    SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False)
    return SessionLocal()


def _make_channel(**fields: Any) -> Channel:
    defaults: dict[str, Any] = {
        "name": "primary",
        "driver": "ntfy",
        "config_json": {"topic": "drops"},
        "is_default": False,
    }
    defaults.update(fields)
    session = _session()
    try:
        channel = Channel(**defaults)
        session.add(channel)
        session.commit()
        session.refresh(channel)
        session.expunge(channel)
        return channel
    finally:
        session.close()


def _reload(channel_id: str) -> Channel | None:
    session = _session()
    try:
        return session.query(Channel).filter(Channel.id == channel_id).one_or_none()
    finally:
        session.close()


def _all_channels() -> list[Channel]:
    session = _session()
    try:
        return list(session.query(Channel).all())
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth posture
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "method,path",
    [
        ("get", "/settings/channels"),
        ("get", "/settings/channels/new"),
        ("post", "/settings/channels"),
        ("get", "/settings/channels/xyz/edit"),
        ("post", "/settings/channels/xyz"),
        ("post", "/settings/channels/xyz/delete"),
        ("post", "/settings/channels/xyz/default"),
        ("post", "/settings/channels/xyz/test"),
    ],
)
def test_unauth_redirects_to_login(client: TestClient, method: str, path: str) -> None:
    # Clear the override so the real dependency runs for this one call.
    app.dependency_overrides.pop(require_session, None)
    try:
        resp = getattr(client, method)(path, follow_redirects=False)
    finally:
        app.dependency_overrides[require_session] = lambda: Admin()

    assert resp.status_code == 303, (method, path)
    assert resp.headers["location"].startswith("/login")


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


def test_list_empty_shows_empty_state(client: TestClient) -> None:
    resp = client.get("/settings/channels")
    assert resp.status_code == 200
    assert "No channels yet" in resp.text


def test_list_shows_existing_channels(client: TestClient) -> None:
    _make_channel(name="phone", driver="ntfy", config_json={"topic": "drops"})
    resp = client.get("/settings/channels")
    assert resp.status_code == 200
    assert "phone" in resp.text
    assert "ntfy" in resp.text


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


def test_create_ntfy_channel_happy_path(client: TestClient) -> None:
    resp = client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "ntfy",
            "config_json": '{"topic": "drops"}',
            "_csrf": fetch_csrf(client),
        },
        follow_redirects=False,
    )
    assert resp.status_code == 303, resp.text
    assert resp.headers["location"].startswith("/settings/channels")

    rows = _all_channels()
    assert len(rows) == 1
    assert rows[0].name == "phone"
    assert rows[0].driver == "ntfy"
    assert rows[0].config_json == {"topic": "drops"}


def test_create_with_invalid_json_re_renders_form(client: TestClient) -> None:
    resp = client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "ntfy",
            "config_json": "{not-json",
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Config is not valid JSON" in resp.text
    assert _all_channels() == []


def test_create_with_unknown_driver_re_renders_form(client: TestClient) -> None:
    resp = client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "doesnotexist",
            "config_json": "{}",
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Unknown driver" in resp.text
    assert _all_channels() == []


def test_create_with_invalid_driver_config_re_renders_form(
    client: TestClient,
) -> None:
    # pushover requires token+user; empty config must be rejected by the driver.
    resp = client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "pushover",
            "config_json": "{}",
            "_csrf": fetch_csrf(client),
        },
    )
    # Driver-level config rejection surfaces as 422 (semantic validation),
    # not 400 (structural / well-formedness). Issue #14 E4.
    assert resp.status_code == 422
    # The error message surface is whatever DriverConfigError raised.
    assert "pushover" in resp.text
    assert _all_channels() == []


@pytest.mark.parametrize(
    ("driver", "config_json", "needle"),
    [
        # pushover requires both ``token`` and ``user``.
        ("pushover", "{}", "pushover"),
        ("pushover", '{"token": "abc"}', "user"),
        # ntfy requires ``topic``.
        ("ntfy", "{}", "topic"),
        # webhook requires ``url``.
        ("webhook", "{}", "url"),
        ("webhook", '{"url": "ftp://nope.example/x"}', "http"),
        # apprise requires a non-empty list of URLs.
        ("apprise", "{}", "urls"),
        ("apprise", '{"urls": []}', "urls"),
    ],
)
def test_create_missing_required_fields_returns_422(
    client: TestClient,
    driver: str,
    config_json: str,
    needle: str,
) -> None:
    """Each driver's required-field validator runs at save time (issue #14 E4).

    A missing field re-renders the form with a 422 (semantic validation)
    and surfaces the driver's own error message on the config_json field.
    """
    resp = client.post(
        "/settings/channels",
        data={
            "name": f"chan-{driver}",
            "driver": driver,
            "config_json": config_json,
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 422, resp.text
    assert needle in resp.text
    assert _all_channels() == []


def test_create_webhook_with_loopback_url_rejected(client: TestClient) -> None:
    """SSRF guard rejects webhook URLs targeting private/loopback space."""
    resp = client.post(
        "/settings/channels",
        data={
            "name": "internal",
            "driver": "webhook",
            "config_json": '{"url": "http://127.0.0.1:8000/webhook"}',
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 422
    assert "webhook" in resp.text
    assert _all_channels() == []


def test_create_webhook_with_loopback_allowed_when_opted_in(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    """``AGENTDROP_ALLOW_PRIVATE_OUTBOUND=1`` lets internal webhooks save."""
    monkeypatch.setenv("AGENTDROP_ALLOW_PRIVATE_OUTBOUND", "1")
    get_settings.cache_clear()
    try:
        resp = client.post(
            "/settings/channels",
            data={
                "name": "ha",
                "driver": "webhook",
                "config_json": '{"url": "http://127.0.0.1:8123/api/webhook/x"}',
                "_csrf": fetch_csrf(client),
            },
            follow_redirects=False,
        )
    finally:
        get_settings.cache_clear()
    assert resp.status_code == 303, resp.text
    assert len(_all_channels()) == 1


def test_create_with_duplicate_name_re_renders_form(client: TestClient) -> None:
    _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "ntfy",
            "config_json": '{"topic": "drops"}',
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "already exists" in resp.text
    # Still only one row.
    assert len(_all_channels()) == 1


def test_create_with_invalid_name_re_renders_form(client: TestClient) -> None:
    resp = client.post(
        "/settings/channels",
        data={
            "name": "has/slash",
            "driver": "ntfy",
            "config_json": '{"topic": "drops"}',
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Name must be" in resp.text


# ---------------------------------------------------------------------------
# Edit
# ---------------------------------------------------------------------------


def test_edit_form_masks_secrets(client: TestClient) -> None:
    channel = _make_channel(
        name="phone",
        driver="pushover",
        config_json={"token": "app-secret", "user": "user-secret"},
    )
    resp = client.get(f"/settings/channels/{channel.id}/edit")
    assert resp.status_code == 200
    assert "app-secret" not in resp.text
    assert "user-secret" not in resp.text
    # Placeholder shows up in the masked JSON.
    assert "••••••••" in resp.text


def test_edit_preserves_secrets_when_unchanged(client: TestClient) -> None:
    channel = _make_channel(
        name="phone",
        driver="pushover",
        config_json={"token": "real-token", "user": "real-user"},
    )

    # Submit the masked values back as-is (simulating "user didn't touch them").
    resp = client.post(
        f"/settings/channels/{channel.id}",
        data={
            "name": "phone-renamed",
            "driver": "pushover",
            "has_existing_config": "1",
            "config_json": '{"token": "••••••••", "user": "••••••••"}',
            "_csrf": fetch_csrf(client),
        },
        follow_redirects=False,
    )
    assert resp.status_code == 303, resp.text

    refreshed = _reload(channel.id)
    assert refreshed is not None
    assert refreshed.name == "phone-renamed"
    # Secrets preserved from the original row.
    assert refreshed.config_json["token"] == "real-token"
    assert refreshed.config_json["user"] == "real-user"


def test_edit_invalid_config_returns_422_and_does_not_leak_existing_secrets(
    client: TestClient,
) -> None:
    """When validate_config rejects the edit, the form re-renders with the
    user's submitted JSON — not the existing row's plaintext secrets.

    Regression for issue #14 E4: 422 on driver-level rejection, and the
    response must not include the stored ``token``/``user`` values.
    Switching driver type drops the existing secrets-merge (different
    schema) so we can drive validation failure cleanly.
    """
    channel = _make_channel(
        name="phone",
        driver="pushover",
        config_json={"token": "supersecret-token", "user": "supersecret-user"},
    )

    # Switch to ntfy with an incomplete config — ntfy validation fails
    # because ``topic`` is missing. ``has_existing_config`` is set but
    # the merge only fires when the driver is unchanged, so the existing
    # pushover secrets are not touched.
    submitted_json = "{}"
    resp = client.post(
        f"/settings/channels/{channel.id}",
        data={
            "name": "phone",
            "driver": "ntfy",
            "has_existing_config": "1",
            "config_json": submitted_json,
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 422, resp.text
    # The driver's error message points at the missing field.
    assert "topic" in resp.text
    # The stored plaintext secrets must NOT have leaked into the rendered
    # form. The form preserves the user's submitted text exactly.
    assert "supersecret-token" not in resp.text
    assert "supersecret-user" not in resp.text
    # And the channel row stayed untouched.
    refreshed = _reload(channel.id)
    assert refreshed is not None
    assert refreshed.config_json == {"token": "supersecret-token", "user": "supersecret-user"}
    assert refreshed.driver == "pushover"


def test_edit_can_replace_secrets_when_user_retypes(client: TestClient) -> None:
    channel = _make_channel(
        name="phone",
        driver="pushover",
        config_json={"token": "old-token", "user": "old-user"},
    )
    resp = client.post(
        f"/settings/channels/{channel.id}",
        data={
            "name": "phone",
            "driver": "pushover",
            "has_existing_config": "1",
            "config_json": '{"token": "new-token", "user": "new-user"}',
            "_csrf": fetch_csrf(client),
        },
        follow_redirects=False,
    )
    assert resp.status_code == 303, resp.text
    refreshed = _reload(channel.id)
    assert refreshed is not None
    assert refreshed.config_json["token"] == "new-token"
    assert refreshed.config_json["user"] == "new-user"


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


def test_delete_removes_row_and_redirects(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        f"/settings/channels/{channel.id}/delete",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert resp.headers["location"].startswith("/settings/channels")
    assert _reload(channel.id) is None


# ---------------------------------------------------------------------------
# Set default
# ---------------------------------------------------------------------------


def test_set_default_flips_flag_on_target_and_clears_previous(
    client: TestClient,
) -> None:
    first = _make_channel(name="phone", driver="ntfy", is_default=True)
    second = _make_channel(name="laptop", driver="ntfy", config_json={"topic": "laptop"})

    resp = client.post(
        f"/settings/channels/{second.id}/default",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303

    first_now = _reload(first.id)
    second_now = _reload(second.id)
    assert first_now is not None and first_now.is_default is False
    assert second_now is not None and second_now.is_default is True


# ---------------------------------------------------------------------------
# Test-fire
# ---------------------------------------------------------------------------


class _FakeDriver(Driver):
    driver_name = "fake"

    def __init__(self, config: dict[str, Any], *, raises: Exception | None = None) -> None:
        super().__init__(config)
        self._raises = raises

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: str,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        if self._raises is not None:
            raise self._raises
        return DeliveryResult(ok=True, driver=self.driver_name, provider_id="fake-1")


def test_test_fire_happy_path_redirects_with_sent_ok(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    channel = _make_channel(name="phone", driver="ntfy")

    def fake_get_driver(name: str, config: dict[str, Any]) -> Driver:
        return _FakeDriver(config)

    monkeypatch.setattr(channels_mod, "get_driver", fake_get_driver)

    resp = client.post(
        f"/settings/channels/{channel.id}/test",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    location = resp.headers["location"]
    assert "notice=sent-ok" in location


def test_test_fire_driver_failure_redirects_with_failed(
    client: TestClient, monkeypatch: pytest.MonkeyPatch
) -> None:
    from agentdrop.notifications import DriverDeliveryError

    channel = _make_channel(name="phone", driver="ntfy")

    def fake_get_driver(name: str, config: dict[str, Any]) -> Driver:
        return _FakeDriver(config, raises=DriverDeliveryError("upstream 503"))

    monkeypatch.setattr(channels_mod, "get_driver", fake_get_driver)

    resp = client.post(
        f"/settings/channels/{channel.id}/test",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    location = resp.headers["location"]
    assert "notice=failed" in location
    assert "upstream" in location  # URL-encoded detail survives the redirect
