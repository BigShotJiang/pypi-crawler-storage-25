"""Smoke + behavioural tests for the ``RoutingRule`` ORM model.

Covers the matcher contract (literal vs wildcard on source and
priority), default column values, and the FK cascade from ``channels``.
The resolver itself is exercised in ``test_routing_resolver``.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import create_engine, event, select
from sqlalchemy.orm import Session

from agentdrop.db.base import Base
from agentdrop.models import Channel, RoutingRule
from agentdrop.notifications.resolver import list_rules, matches


@pytest.fixture
def session() -> Iterator[Session]:
    engine = create_engine("sqlite://", future=True)

    # SQLite ignores FK constraints unless PRAGMA foreign_keys=ON.
    @event.listens_for(engine, "connect")
    def _fk_on(dbapi_connection, _record):  # type: ignore[no-untyped-def]
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    Base.metadata.create_all(engine)
    with Session(engine) as s:
        yield s
    engine.dispose()


def _channel(session: Session, *, name: str = "c1") -> Channel:
    ch = Channel(name=name, driver="ntfy", config_json={"topic": name})
    session.add(ch)
    session.flush()
    return ch


def test_insert_rule_defaults(session: Session) -> None:
    ch = _channel(session)
    rule = RoutingRule(
        source_pattern="thinkr",
        priority_pattern="urgent",
        channel_id=ch.id,
    )
    session.add(rule)
    session.commit()
    session.refresh(rule)

    assert rule.id.startswith("rr_")
    assert rule.order == 100
    assert rule.created_at is not None
    assert rule.channel_id == ch.id


def test_list_rules_sort_order(session: Session) -> None:
    ch = _channel(session)

    older_low_order = RoutingRule(
        source_pattern="*", priority_pattern="*", channel_id=ch.id, order=50
    )
    newer_low_order = RoutingRule(
        source_pattern="*", priority_pattern="*", channel_id=ch.id, order=50
    )
    high_order = RoutingRule(source_pattern="*", priority_pattern="*", channel_id=ch.id, order=200)
    session.add_all([older_low_order, newer_low_order, high_order])
    session.flush()

    # Pin created_at so we don't depend on SQLite's 1s CURRENT_TIMESTAMP tick.
    now = datetime.now(UTC)
    older_low_order.created_at = now - timedelta(seconds=10)
    newer_low_order.created_at = now
    high_order.created_at = now + timedelta(seconds=10)
    session.commit()

    listed = list_rules(session)
    assert [r.id for r in listed] == [
        older_low_order.id,
        newer_low_order.id,
        high_order.id,
    ]


def test_matches_exact_source_and_priority() -> None:
    rule = RoutingRule(source_pattern="thinkr", priority_pattern="urgent", channel_id="ch_x")
    assert matches(rule, source="thinkr", priority="urgent") is True
    assert matches(rule, source="thinkr", priority="normal") is False
    assert matches(rule, source="other", priority="urgent") is False


def test_matches_source_wildcard_matches_any_including_none() -> None:
    rule = RoutingRule(source_pattern="*", priority_pattern="urgent", channel_id="ch_x")
    assert matches(rule, source="thinkr", priority="urgent") is True
    assert matches(rule, source=None, priority="urgent") is True
    assert matches(rule, source="anything", priority="urgent") is True
    assert matches(rule, source="thinkr", priority="normal") is False


def test_matches_priority_wildcard() -> None:
    rule = RoutingRule(source_pattern="thinkr", priority_pattern="*", channel_id="ch_x")
    assert matches(rule, source="thinkr", priority="low") is True
    assert matches(rule, source="thinkr", priority="urgent") is True
    assert matches(rule, source="other", priority="urgent") is False


def test_matches_both_wildcards_catch_all() -> None:
    rule = RoutingRule(source_pattern="*", priority_pattern="*", channel_id="ch_x")
    assert matches(rule, source=None, priority="normal") is True
    assert matches(rule, source="whatever", priority="low") is True


def test_fk_cascade_on_channel_delete(session: Session) -> None:
    ch = _channel(session)
    rule = RoutingRule(source_pattern="thinkr", priority_pattern="normal", channel_id=ch.id)
    session.add(rule)
    session.commit()

    assert session.execute(select(RoutingRule)).scalars().all() != []

    session.delete(ch)
    session.commit()

    # Cascade should have removed the rule too.
    remaining = session.execute(select(RoutingRule)).scalars().all()
    assert remaining == []
