"""Tests for Bearer-token API-key authentication."""

from __future__ import annotations

import hashlib
import hmac
from collections.abc import Iterator

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient

from agentdrop.auth import _get_expected_hash, hash_key, require_api_key
from agentdrop.config import get_settings

TEST_KEY = "s3cret-test-key"


def _build_app() -> FastAPI:
    app = FastAPI()

    @app.get("/protected", dependencies=[Depends(require_api_key)])
    def protected() -> dict[str, str]:
        return {"ok": "yes"}

    return app


@pytest.fixture
def configured_client(monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient with AGENTDROP_API_KEY set to TEST_KEY."""
    monkeypatch.setenv("AGENTDROP_API_KEY", TEST_KEY)
    get_settings.cache_clear()
    _get_expected_hash.cache_clear()
    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        _get_expected_hash.cache_clear()


@pytest.fixture
def unconfigured_client(monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient with AGENTDROP_API_KEY unset."""
    monkeypatch.delenv("AGENTDROP_API_KEY", raising=False)
    get_settings.cache_clear()
    _get_expected_hash.cache_clear()
    try:
        with TestClient(_build_app()) as client:
            yield client
    finally:
        get_settings.cache_clear()
        _get_expected_hash.cache_clear()


def test_no_authorization_header_returns_401(configured_client: TestClient) -> None:
    response = configured_client.get("/protected")
    assert response.status_code == 401
    assert response.json() == {"detail": "Missing bearer token"}
    assert response.headers.get("www-authenticate") == "Bearer"


def test_wrong_scheme_returns_401(configured_client: TestClient) -> None:
    response = configured_client.get("/protected", headers={"Authorization": "Basic foo"})
    assert response.status_code == 401
    assert response.json() == {"detail": "Missing bearer token"}


def test_wrong_token_returns_401(configured_client: TestClient) -> None:
    response = configured_client.get(
        "/protected", headers={"Authorization": "Bearer not-the-right-key"}
    )
    assert response.status_code == 401
    assert response.json() == {"detail": "Invalid API key"}
    assert response.headers.get("www-authenticate") == "Bearer"


def test_correct_token_returns_200(configured_client: TestClient) -> None:
    response = configured_client.get("/protected", headers={"Authorization": f"Bearer {TEST_KEY}"})
    assert response.status_code == 200
    assert response.json() == {"ok": "yes"}


def test_correct_token_with_surrounding_whitespace_returns_200(
    configured_client: TestClient,
) -> None:
    response = configured_client.get(
        "/protected", headers={"Authorization": f"Bearer  {TEST_KEY}  "}
    )
    assert response.status_code == 200


def test_empty_token_after_bearer_returns_401(configured_client: TestClient) -> None:
    response = configured_client.get("/protected", headers={"Authorization": "Bearer "})
    assert response.status_code == 401
    # "Bearer " (trailing space) is accepted as the prefix; token strips to empty.
    assert response.json() == {"detail": "Empty bearer token"}


def test_bearer_without_space_treated_as_missing(configured_client: TestClient) -> None:
    # "Bearer" with no trailing space doesn't start with "Bearer " -> missing.
    response = configured_client.get("/protected", headers={"Authorization": "Bearer"})
    assert response.status_code == 401
    assert response.json() == {"detail": "Missing bearer token"}


def test_unconfigured_server_returns_503(unconfigured_client: TestClient) -> None:
    response = unconfigured_client.get(
        "/protected", headers={"Authorization": f"Bearer {TEST_KEY}"}
    )
    assert response.status_code == 503
    assert response.json() == {"detail": "API key not configured on server"}


def test_hash_key_is_sha256_hex() -> None:
    raw = "hello-world"
    expected = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    assert hash_key(raw) == expected
    # And length/shape sanity.
    assert len(hash_key(raw)) == 64
    assert all(c in "0123456789abcdef" for c in hash_key(raw))


def test_compare_digest_matches_hash_key_output() -> None:
    """Smoke test: the digests we compare are byte-for-byte equal under hmac."""
    raw = TEST_KEY
    a = hash_key(raw)
    b = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    assert hmac.compare_digest(a, b) is True
    assert hmac.compare_digest(a, hash_key("something-else")) is False
