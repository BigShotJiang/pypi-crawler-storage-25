"""Tests for :mod:`agentdrop.ids`."""

from __future__ import annotations

import pytest

from agentdrop.ids import ALPHABET, new_id, new_short_id

ALPHABET_SET = set(ALPHABET)


def test_short_id_length_and_alphabet() -> None:
    sid = new_short_id()
    assert len(sid) == 24
    assert set(sid) <= ALPHABET_SET


def test_new_id_prefix_and_default_length() -> None:
    ident = new_id("drp")
    assert ident.startswith("drp_")
    suffix = ident[len("drp_") :]
    assert len(suffix) == 12
    assert set(suffix) <= ALPHABET_SET


def test_new_id_custom_length() -> None:
    ident = new_id("ch", length=20)
    assert ident.startswith("ch_")
    suffix = ident.split("_", 1)[1]
    assert len(suffix) == 20
    assert set(suffix) <= ALPHABET_SET


def test_new_id_rejects_empty_prefix() -> None:
    with pytest.raises(ValueError):
        new_id("")


def test_short_ids_are_unique_across_many_calls() -> None:
    # Birthday-attack sanity check: with 24 chars of base62 (~143 bits),
    # 1000 draws should never collide in practice.
    ids = {new_short_id() for _ in range(1000)}
    assert len(ids) == 1000
