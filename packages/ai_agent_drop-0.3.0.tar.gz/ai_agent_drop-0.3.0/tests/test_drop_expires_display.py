"""Tests for the drop-page footer "expires in …" display (PRD §8.4).

Covers the four permutations the renderer cares about:

* Fresh drop, no explicit ``expires_at`` → falls back to
  ``created_at + retention_days``, shows ``"expires in 30d …"``.
* Drop with ``expires_at`` set a couple of days out → shows the literal
  countdown, not the retention-days fallback.
* Pinned drop → shows ``"pinned · no expiry"``, never the word
  ``"expires"``.
* Already-past expiry → shows ``"expired"``.
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_RETENTION_DAYS", "30")
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


def _make_drop(**overrides: object) -> Drop:
    fields: dict[str, object] = {
        "short_id": "expdisplay00000000000000",
        "title": "A drop",
        "body": "Summary.",
        "content_md": "# hello",
    }
    fields.update(overrides)

    session = SessionLocal(bind=get_engine())
    try:
        drop = Drop(**fields)
        session.add(drop)
        session.commit()
        session.refresh(drop)
        session.expunge(drop)
        return drop
    finally:
        session.close()


def _set_created_at(short_id: str, created_at: datetime) -> None:
    """Backdate / forward-date a drop's ``created_at``.

    SQLAlchemy fills ``created_at`` via a server default at INSERT, so
    overriding it has to be a second UPDATE.
    """
    session = SessionLocal(bind=get_engine())
    try:
        drop = session.query(Drop).filter(Drop.short_id == short_id).one()
        drop.created_at = created_at
        session.add(drop)
        session.commit()
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Fresh drop — default retention fallback
# ---------------------------------------------------------------------------


def test_fresh_drop_footer_shows_default_retention_countdown(
    client: TestClient,
) -> None:
    """A just-created drop with no explicit expiry shows ~30 days.

    The handler computes ``effective_expiry = created_at + 30d``, then
    formats the delta from ``now``. Between the insert and the GET a
    few milliseconds elapse, so the rendered string is either
    ``"expires in 30d 0h"`` (common) or ``"expires in 29d Yh"`` where
    ``Y`` is 23. We allow the slop window explicitly.
    """
    _make_drop(short_id="freshexp0000000000000000")

    resp = client.get("/d/freshexp0000000000000000")
    assert resp.status_code == 200, resp.text

    match = re.search(r"expires in (\d+)d (\d+)h", resp.text)
    assert match is not None, f"no 'expires in Xd Yh' found in footer: {resp.text[:2000]}"
    days, hours = int(match.group(1)), int(match.group(2))

    # 30d exactly, or 29d 23h (fraction-of-an-hour slop). Anything else
    # means the fallback arithmetic is wrong.
    assert (days, hours) in {(30, 0), (29, 23)}, f"unexpected countdown: {days}d {hours}h"


# ---------------------------------------------------------------------------
# Explicit expires_at
# ---------------------------------------------------------------------------


def test_drop_with_explicit_expiry_shows_that_countdown(client: TestClient) -> None:
    """``expires_at`` ~2d out renders ``expires in 1d 23h`` or ``2d 0h``."""
    now = datetime.now(UTC)
    _make_drop(
        short_id="explicitexp00000000000aa",
        expires_at=now + timedelta(days=2),
    )

    resp = client.get("/d/explicitexp00000000000aa")
    assert resp.status_code == 200

    match = re.search(r"expires in (\d+)d (\d+)h", resp.text)
    assert match is not None, resp.text[:2000]
    days = int(match.group(1))
    assert days in {1, 2}
    # Guardrail: nowhere near 30d — confirms we didn't fall through to
    # the default-retention branch.
    assert days < 5


# ---------------------------------------------------------------------------
# Pinned drop
# ---------------------------------------------------------------------------


def test_pinned_drop_shows_no_expiry_wording(client: TestClient) -> None:
    """Pinned drops render ``pinned · no expiry`` and never ``expires``."""
    now = datetime.now(UTC)
    _make_drop(
        short_id="pinnedrop0000000000000aa",
        pinned_at=now,
        # Pinned wins even if an explicit expiry exists — pin is the
        # exemption (PRD §8.4).
        expires_at=now + timedelta(days=1),
    )

    resp = client.get("/d/pinnedrop0000000000000aa")
    assert resp.status_code == 200

    # Core assertion: the pinned wording appears.
    assert "pinned" in resp.text
    assert "no expiry" in resp.text
    # And the word ``expires`` does NOT — this is the "don't show a
    # countdown on pinned drops" invariant. We scope the assertion to
    # the rendered footer region so unrelated uses of the word elsewhere
    # (none today, but defensively) don't break the test.
    footer_start = resp.text.rfind('class="footer-expiry"')
    assert footer_start != -1, "footer-expiry span missing from template"
    footer_slice = resp.text[footer_start : footer_start + 200]
    assert "expires" not in footer_slice


# ---------------------------------------------------------------------------
# Expired
# ---------------------------------------------------------------------------


def test_past_expiry_shows_expired(client: TestClient) -> None:
    """A drop with ``expires_at`` in the past renders ``expired``."""
    now = datetime.now(UTC)
    _make_drop(
        short_id="expireddrop0000000000aaa",
        expires_at=now - timedelta(hours=3),
    )

    resp = client.get("/d/expireddrop0000000000aaa")
    assert resp.status_code == 200

    # Scope to the footer span so we don't false-positive on e.g.
    # "expired" appearing in some unrelated CSS class name elsewhere.
    footer_start = resp.text.rfind('class="footer-expiry"')
    assert footer_start != -1
    footer_slice = resp.text[footer_start : footer_start + 200]
    assert "expired" in footer_slice
    # Must not still say "expires in".
    assert "expires in" not in footer_slice
