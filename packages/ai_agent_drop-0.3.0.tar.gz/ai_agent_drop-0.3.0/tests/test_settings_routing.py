"""End-to-end tests for ``/settings/routing/*``.

Exercises:

* Auth posture (unauth'd -> 303 /login for every route).
* Empty state rendering.
* Create happy path, plus validation errors (bad priority, missing channel).
* Delete.
* Re-ordering: swap with adjacent, no-op at boundaries.
* Zero-channels empty state: create form hidden, CTA to /settings/channels/new.

Mirrors the TestClient + ``require_session`` override pattern from
``test_settings_channels.py``.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app
from agentdrop.models import Channel, RoutingRule
from agentdrop.web.session import Admin, require_session

from .conftest import fetch_csrf


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Logged-in TestClient on a fresh SQLite DB."""
    db_path = tmp_path / "settings_routing.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")

    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _session() -> Session:
    SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False)
    return SessionLocal()


def _make_channel(**fields: Any) -> Channel:
    defaults: dict[str, Any] = {
        "name": "primary",
        "driver": "ntfy",
        "config_json": {"topic": "drops"},
        "is_default": False,
    }
    defaults.update(fields)
    session = _session()
    try:
        channel = Channel(**defaults)
        session.add(channel)
        session.commit()
        session.refresh(channel)
        session.expunge(channel)
        return channel
    finally:
        session.close()


def _make_rule(**fields: Any) -> RoutingRule:
    defaults: dict[str, Any] = {
        "source_pattern": "*",
        "priority_pattern": "*",
        "order": 100,
    }
    defaults.update(fields)
    session = _session()
    try:
        rule = RoutingRule(**defaults)
        session.add(rule)
        session.commit()
        session.refresh(rule)
        session.expunge(rule)
        return rule
    finally:
        session.close()


def _all_rules() -> list[RoutingRule]:
    session = _session()
    try:
        return list(
            session.query(RoutingRule)
            .order_by(RoutingRule.order.asc(), RoutingRule.created_at.asc())
            .all()
        )
    finally:
        session.close()


def _reload_rule(rule_id: str) -> RoutingRule | None:
    session = _session()
    try:
        return session.query(RoutingRule).filter(RoutingRule.id == rule_id).one_or_none()
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth posture
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "method,path",
    [
        ("get", "/settings/routing"),
        ("post", "/settings/routing"),
        ("post", "/settings/routing/xyz/delete"),
        ("post", "/settings/routing/xyz/move-up"),
        ("post", "/settings/routing/xyz/move-down"),
    ],
)
def test_unauth_redirects_to_login(client: TestClient, method: str, path: str) -> None:
    app.dependency_overrides.pop(require_session, None)
    try:
        resp = getattr(client, method)(path, follow_redirects=False)
    finally:
        app.dependency_overrides[require_session] = lambda: Admin()

    assert resp.status_code == 303, (method, path)
    assert resp.headers["location"].startswith("/login")


# ---------------------------------------------------------------------------
# Empty state
# ---------------------------------------------------------------------------


def test_empty_state_when_no_rules(client: TestClient) -> None:
    _make_channel(name="phone", driver="ntfy")
    resp = client.get("/settings/routing")
    assert resp.status_code == 200
    assert "No routing rules yet" in resp.text
    # Create form is visible since we have a channel.
    assert 'name="source_pattern"' in resp.text
    assert 'name="priority_pattern"' in resp.text


def test_empty_state_hides_form_when_no_channels(client: TestClient) -> None:
    """When zero channels exist, the create form is replaced with a CTA."""
    resp = client.get("/settings/routing")
    assert resp.status_code == 200
    assert "Create a channel first" in resp.text
    assert 'href="/settings/channels/new"' in resp.text
    # The actual input element should not be rendered.
    assert 'name="source_pattern"' not in resp.text


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


def test_create_happy_path(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        "/settings/routing",
        data={
            "source_pattern": "thinkr",
            "priority_pattern": "high",
            "channel_id": channel.id,
            "order": "50",
            "_csrf": fetch_csrf(client),
        },
        follow_redirects=False,
    )
    assert resp.status_code == 303, resp.text
    assert resp.headers["location"] == "/settings/routing?notice=created"

    rules = _all_rules()
    assert len(rules) == 1
    assert rules[0].source_pattern == "thinkr"
    assert rules[0].priority_pattern == "high"
    assert rules[0].channel_id == channel.id
    assert rules[0].order == 50


def test_create_with_default_order_when_blank(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        "/settings/routing",
        data={
            "source_pattern": "*",
            "priority_pattern": "*",
            "channel_id": channel.id,
            "order": "",
            "_csrf": fetch_csrf(client),
        },
        follow_redirects=False,
    )
    assert resp.status_code == 303, resp.text
    rules = _all_rules()
    assert len(rules) == 1
    assert rules[0].order == 100


def test_create_with_invalid_priority_re_renders(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        "/settings/routing",
        data={
            "source_pattern": "thinkr",
            "priority_pattern": "critical",  # not in the enum
            "channel_id": channel.id,
            "order": "50",
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Priority must be one of" in resp.text
    assert _all_rules() == []


def test_create_with_missing_channel_re_renders(client: TestClient) -> None:
    _make_channel(name="phone", driver="ntfy")  # a valid channel exists
    resp = client.post(
        "/settings/routing",
        data={
            "source_pattern": "thinkr",
            "priority_pattern": "high",
            "channel_id": "ch_nonexistent_id_value",
            "order": "50",
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Unknown channel" in resp.text
    assert _all_rules() == []


def test_create_with_empty_source_re_renders(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    resp = client.post(
        "/settings/routing",
        data={
            "source_pattern": "",
            "priority_pattern": "high",
            "channel_id": channel.id,
            "order": "50",
            "_csrf": fetch_csrf(client),
        },
    )
    assert resp.status_code == 400
    assert "Source pattern is required" in resp.text
    assert _all_rules() == []


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


def test_delete_removes_row_and_redirects(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    rule = _make_rule(source_pattern="*", priority_pattern="*", channel_id=channel.id)
    resp = client.post(
        f"/settings/routing/{rule.id}/delete",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert resp.headers["location"] == "/settings/routing?notice=deleted"
    assert _reload_rule(rule.id) is None


def test_delete_unknown_rule_redirects_not_found(client: TestClient) -> None:
    resp = client.post(
        "/settings/routing/rr_does_not_exist/delete",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303
    assert "notice=not-found" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Re-ordering
# ---------------------------------------------------------------------------


def test_move_up_swaps_order_with_previous(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    top = _make_rule(source_pattern="a", priority_pattern="*", channel_id=channel.id, order=10)
    bottom = _make_rule(source_pattern="b", priority_pattern="*", channel_id=channel.id, order=20)

    resp = client.post(
        f"/settings/routing/{bottom.id}/move-up",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303

    top_now = _reload_rule(top.id)
    bottom_now = _reload_rule(bottom.id)
    assert top_now is not None and bottom_now is not None
    assert top_now.order == 20
    assert bottom_now.order == 10


def test_move_down_swaps_order_with_next(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    top = _make_rule(source_pattern="a", priority_pattern="*", channel_id=channel.id, order=10)
    bottom = _make_rule(source_pattern="b", priority_pattern="*", channel_id=channel.id, order=20)

    resp = client.post(
        f"/settings/routing/{top.id}/move-down",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303

    top_now = _reload_rule(top.id)
    bottom_now = _reload_rule(bottom.id)
    assert top_now is not None and bottom_now is not None
    assert top_now.order == 20
    assert bottom_now.order == 10


def test_move_up_on_top_rule_is_noop(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    top = _make_rule(source_pattern="a", priority_pattern="*", channel_id=channel.id, order=10)
    bottom = _make_rule(source_pattern="b", priority_pattern="*", channel_id=channel.id, order=20)

    resp = client.post(
        f"/settings/routing/{top.id}/move-up",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303

    top_now = _reload_rule(top.id)
    bottom_now = _reload_rule(bottom.id)
    assert top_now is not None and bottom_now is not None
    assert top_now.order == 10  # unchanged
    assert bottom_now.order == 20  # unchanged


def test_move_down_on_bottom_rule_is_noop(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    top = _make_rule(source_pattern="a", priority_pattern="*", channel_id=channel.id, order=10)
    bottom = _make_rule(source_pattern="b", priority_pattern="*", channel_id=channel.id, order=20)

    resp = client.post(
        f"/settings/routing/{bottom.id}/move-down",
        data={"_csrf": fetch_csrf(client)},
        follow_redirects=False,
    )
    assert resp.status_code == 303

    top_now = _reload_rule(top.id)
    bottom_now = _reload_rule(bottom.id)
    assert top_now is not None and bottom_now is not None
    assert top_now.order == 10
    assert bottom_now.order == 20


# ---------------------------------------------------------------------------
# List rendering
# ---------------------------------------------------------------------------


def test_list_shows_existing_rules(client: TestClient) -> None:
    channel = _make_channel(name="phone", driver="ntfy")
    _make_rule(
        source_pattern="thinkr",
        priority_pattern="high",
        channel_id=channel.id,
        order=10,
    )
    resp = client.get("/settings/routing")
    assert resp.status_code == 200
    assert "thinkr" in resp.text
    assert "high" in resp.text
    assert "phone" in resp.text
