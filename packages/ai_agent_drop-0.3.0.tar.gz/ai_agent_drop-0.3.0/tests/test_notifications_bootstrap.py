"""Unit tests for the first-run default-channel bootstrap."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import Settings, get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.models import Channel
from agentdrop.notifications.bootstrap import ensure_default_web_push_channel


@pytest.fixture
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Session]:
    db_path = tmp_path / "bootstrap.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())
    SessionLocal = sessionmaker(bind=get_engine(), autoflush=False, expire_on_commit=False)
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()
        get_engine.cache_clear()
        get_settings.cache_clear()


def _settings(*, vapid: bool = True) -> Settings:
    if vapid:
        return Settings(
            vapid_public_key="public",
            vapid_private_key="private",
            vapid_subject="mailto:admin@example.com",
        )
    return Settings()


def test_creates_default_when_vapid_set_and_no_channels(db: Session) -> None:
    created = ensure_default_web_push_channel(db, _settings())
    assert created is not None
    assert created.driver == "web_push"
    assert created.is_default is True
    assert created.config_json == {}
    rows = db.query(Channel).all()
    assert len(rows) == 1
    assert rows[0].id == created.id


def test_noop_when_vapid_not_configured(db: Session) -> None:
    assert ensure_default_web_push_channel(db, _settings(vapid=False)) is None
    assert db.query(Channel).count() == 0


def test_noop_when_any_channel_already_exists(db: Session) -> None:
    # Even a non-default, non-web_push channel suppresses the bootstrap —
    # we only ever auto-create on a truly empty table.
    existing = Channel(name="prior", driver="ntfy", config_json={"topic": "t"})
    db.add(existing)
    db.commit()

    assert ensure_default_web_push_channel(db, _settings()) is None
    names = {c.name for c in db.query(Channel).all()}
    assert names == {"prior"}


def test_is_idempotent_across_repeated_calls(db: Session) -> None:
    first = ensure_default_web_push_channel(db, _settings())
    assert first is not None

    # Second call is a no-op because a channel now exists.
    second = ensure_default_web_push_channel(db, _settings())
    assert second is None
    assert db.query(Channel).count() == 1


def test_respects_user_deletion_of_bootstrapped_channel(db: Session) -> None:
    # After first-run bootstrap, if the operator deletes every channel,
    # the next startup does NOT re-add the default — deletion is an
    # explicit signal and should be respected.
    created = ensure_default_web_push_channel(db, _settings())
    assert created is not None

    # Simulate the operator deleting everything by adding a sentinel
    # channel (any row is enough to mark "this DB has been configured").
    # We don't actually empty the table, because doing so would hit the
    # "empty table" branch again — that's expected behaviour if a user
    # fully resets their DB. Instead, assert the intermediate case.
    sentinel = Channel(name="operator-added", driver="ntfy", config_json={"topic": "x"})
    db.add(sentinel)
    db.commit()
    db.delete(created)
    db.commit()

    assert ensure_default_web_push_channel(db, _settings()) is None
    names = {c.name for c in db.query(Channel).all()}
    assert names == {"operator-added"}
