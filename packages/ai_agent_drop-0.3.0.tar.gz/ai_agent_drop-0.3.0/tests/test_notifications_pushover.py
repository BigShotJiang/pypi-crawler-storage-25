"""Tests for the Pushover notification driver.

Uses :class:`httpx.MockTransport` to intercept the outbound POST so no real
network traffic happens. Each test installs a handler that asserts on the
request shape and returns a crafted response.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any
from urllib.parse import parse_qs

import httpx
import pytest

from agentdrop.notifications import (
    DeliveryResult,
    DriverConfigError,
    DriverDeliveryError,
    get_driver,
)
from agentdrop.notifications.pushover import PushoverDriver

Handler = Callable[[httpx.Request], httpx.Response]


def _install_transport(
    monkeypatch: pytest.MonkeyPatch,
    handler: Handler,
) -> list[httpx.Request]:
    """Patch ``PushoverDriver._client`` so every driver built inside a test
    uses a MockTransport running ``handler``.

    Returns a list that will be populated with every request the handler
    sees, so tests can assert on the captured form body without having to
    mutate a closure variable.
    """
    captured: list[httpx.Request] = []

    def wrapped(request: httpx.Request) -> httpx.Response:
        captured.append(request)
        return handler(request)

    transport = httpx.MockTransport(wrapped)

    def fake_client(self: PushoverDriver) -> httpx.Client:
        return httpx.Client(transport=transport, timeout=10.0)

    monkeypatch.setattr(PushoverDriver, "_client", fake_client)
    return captured


def _form(request: httpx.Request) -> dict[str, str]:
    """Decode a captured request's URL-encoded form body to a flat dict."""
    body = request.content.decode("utf-8")
    parsed = parse_qs(body, keep_blank_values=True)
    return {k: v[0] for k, v in parsed.items()}


def _valid_config(**overrides: Any) -> dict[str, Any]:
    config: dict[str, Any] = {"token": "tkn_abc", "user": "usr_xyz"}
    config.update(overrides)
    return config


def test_config_error_on_missing_fields() -> None:
    with pytest.raises(DriverConfigError):
        PushoverDriver({})
    with pytest.raises(DriverConfigError):
        PushoverDriver({"token": "t"})
    with pytest.raises(DriverConfigError):
        PushoverDriver({"user": "u"})
    with pytest.raises(DriverConfigError):
        PushoverDriver({"token": "", "user": "u"})
    with pytest.raises(DriverConfigError):
        PushoverDriver({"token": 123, "user": "u"})


def test_registry_exposes_pushover() -> None:
    driver = get_driver("pushover", _valid_config())
    assert isinstance(driver, PushoverDriver)


def test_registry_is_case_insensitive() -> None:
    assert isinstance(get_driver("Pushover", _valid_config()), PushoverDriver)


def test_registry_unknown_raises_config_error() -> None:
    with pytest.raises(DriverConfigError):
        get_driver("not-a-real-driver", {})


def test_success_returns_delivery_result(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert str(request.url) == "https://api.pushover.net/1/messages.json"
        return httpx.Response(200, json={"status": 1, "request": "req-123"})

    _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    result = driver.send(
        title="Hello",
        body="world",
        url="https://example.test/d/abc",
        priority="normal",
    )

    assert isinstance(result, DeliveryResult)
    assert result.ok is True
    assert result.driver == "pushover"
    assert result.provider_id == "req-123"


def test_4xx_with_errors_raises_delivery_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            400,
            json={"errors": ["user key is invalid"], "status": 0, "request": "req-err"},
        )

    _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://example.test/d/abc",
            priority="normal",
        )

    # The raised error should name the upstream complaint so operators can
    # diagnose from logs without having to re-run anything.
    assert "user key is invalid" in str(excinfo.value)
    assert "400" in str(excinfo.value)


def test_timeout_raises_delivery_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.TimeoutException("slow", request=request)

    _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://example.test/d/abc",
            priority="normal",
        )

    assert "timed out" in str(excinfo.value)


def test_network_error_raises_delivery_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused", request=request)

    _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://example.test/d/abc",
            priority="normal",
        )

    assert "network error" in str(excinfo.value)


def test_5xx_raises_delivery_error_with_trimmed_body(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(503, text="upstream unavailable")

    _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    with pytest.raises(DriverDeliveryError) as excinfo:
        driver.send(
            title="t",
            body="b",
            url="https://example.test/d/abc",
            priority="normal",
        )

    assert "503" in str(excinfo.value)


@pytest.mark.parametrize(
    ("priority", "expected"),
    [
        ("low", "-1"),
        ("normal", "0"),
        ("high", "1"),
    ],
)
def test_non_urgent_priority_mapping(
    monkeypatch: pytest.MonkeyPatch,
    priority: str,
    expected: str,
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority=priority,  # type: ignore[arg-type]
    )

    assert len(captured) == 1
    form = _form(captured[0])
    assert form["priority"] == expected
    # Non-urgent priorities must not ship retry/expire — Pushover rejects
    # those fields when priority != 2.
    assert "retry" not in form
    assert "expire" not in form


def test_urgent_priority_includes_retry_and_expire(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority="urgent",
    )

    assert len(captured) == 1
    form = _form(captured[0])
    assert form["priority"] == "2"
    assert form["retry"] == "60"
    assert form["expire"] == "3600"


def test_urgent_priority_respects_config_retry_expire(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config(retry=120, expire=7200))
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority="urgent",
    )

    form = _form(captured[0])
    assert form["retry"] == "120"
    assert form["expire"] == "7200"


def test_url_title_default(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority="normal",
    )

    form = _form(captured[0])
    assert form["url_title"] == "Open drop"


def test_url_title_override_via_extras(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority="normal",
        extras={"url_title": "View on Agent Drop"},
    )

    form = _form(captured[0])
    assert form["url_title"] == "View on Agent Drop"


def test_url_title_default_overridable_via_config(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config(url_title_default="See drop"))
    driver.send(
        title="t",
        body="b",
        url="https://example.test/d/abc",
        priority="normal",
    )

    form = _form(captured[0])
    assert form["url_title"] == "See drop"


def test_form_body_contains_credentials_and_content(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(200, json={"status": 1, "request": "r"})

    captured = _install_transport(monkeypatch, handler)

    driver = PushoverDriver(_valid_config())
    driver.send(
        title="Deploy succeeded",
        body="main @ a1b2c3 is live",
        url="https://example.test/d/abc",
        priority="high",
    )

    form = _form(captured[0])
    assert form["token"] == "tkn_abc"
    assert form["user"] == "usr_xyz"
    assert form["title"] == "Deploy succeeded"
    assert form["message"] == "main @ a1b2c3 is live"
    assert form["url"] == "https://example.test/d/abc"


# ---------------------------------------------------------------------------
# httpx client lifecycle (issue #14 E5)
# ---------------------------------------------------------------------------


def test_client_closed_when_request_raises_inside_with_block(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for issue #14 E5: client must close even on transport error."""
    instances: list[httpx.Client] = []

    def boom(_request: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("boom")

    transport = httpx.MockTransport(boom)

    def fake_client(self: PushoverDriver) -> httpx.Client:
        c = httpx.Client(transport=transport, timeout=10.0)
        instances.append(c)
        return c

    monkeypatch.setattr(PushoverDriver, "_client", fake_client)

    driver = PushoverDriver({"token": "tok", "user": "usr"})

    with pytest.raises(DriverDeliveryError):
        driver.send(title="t", body="b", url="https://drop.example/d/x", priority="normal")

    assert instances, "expected _client() to have been invoked"
    for c in instances:
        assert c.is_closed, "httpx.Client leaked: not closed after send()"


def test_no_client_created_when_priority_lookup_raises(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Regression for issue #14 E5: ``_client()`` runs *inside* the with-block.

    Passing an unmapped priority makes ``send()`` raise ``KeyError`` during
    payload construction, before any client should exist.
    """
    instances: list[httpx.Client] = []

    def fake_client(self: PushoverDriver) -> httpx.Client:
        c = httpx.Client(timeout=10.0)
        instances.append(c)
        return c

    monkeypatch.setattr(PushoverDriver, "_client", fake_client)

    driver = PushoverDriver({"token": "tok", "user": "usr"})

    with pytest.raises(KeyError):
        driver.send(
            title="t",
            body="b",
            url="https://drop.example/d/x",
            priority="bogus",  # type: ignore[arg-type]
        )

    assert instances == [], "client must not be created before the with-block"
