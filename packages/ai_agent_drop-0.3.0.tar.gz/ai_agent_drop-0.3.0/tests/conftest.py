import os
import re
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient

# TestClient transports as ``http://testserver``; the SessionMiddleware's
# ``Secure`` cookie flag (default-on after A1) would otherwise prevent
# the test client from sending the session cookie back. Set the dev
# escape hatch before the app is imported so the middleware is built
# with ``https_only=False``.
os.environ.setdefault("AGENTDROP_INSECURE_COOKIES", "1")

# Channels store provider tokens in ``config_json`` which is now encrypted
# at rest (issue #17). The model's ``EncryptedJSON`` TypeDecorator needs a
# Fernet key on every commit, including in tests that never touched
# encryption explicitly. A deterministic test key keeps runs reproducible
# and avoids regenerating per-process. Tests that exercise key handling
# (e.g. ``tests/test_crypto_secrets.py``, rotation, "no key" paths)
# override via ``monkeypatch``.
os.environ.setdefault("AGENTDROP_ENCRYPTION_KEY", "q3pBGsixz44PtbFvLmCLMuOnAwmmNwdFHYFZoGnOXTM=")

# Disable the retention scheduler globally for the test suite. Tests that
# spin up the FastAPI app via ``TestClient`` trigger the lifespan, which
# calls ``start_scheduler`` and would otherwise try to create the lock
# file at ``/data/.scheduler.lock`` (read-only on dev / CI machines).
# Tests that exercise the scheduler explicitly (``test_scheduler.py``,
# ``test_scheduler_lock.py``) flip this back to false via ``monkeypatch``
# and point the lock at ``tmp_path``.
os.environ.setdefault("AGENTDROP_RETENTION_DISABLED", "true")

from agentdrop.main import app
from agentdrop.net import ssrf as _ssrf
from agentdrop.web import rate_limit as _rate_limit


@pytest.fixture(autouse=True)
def _clear_rate_limit_buckets() -> Iterator[None]:
    """Reset the in-memory rate-limit buckets between tests.

    Several endpoints (POST /api/v1/drops, GET /d/{short_id}, /login)
    are now rate-limited at module-level. The buckets persist across
    requests in a single process, so without this autouse cleanup a
    test making lots of POSTs to /api/v1/drops would burn another
    test's quota.
    """
    _rate_limit._TEST_clear()
    yield
    _rate_limit._TEST_clear()


@pytest.fixture(autouse=True)
def _stub_outbound_dns(monkeypatch: pytest.MonkeyPatch) -> None:
    """Resolve any hostname to a public IP by default.

    The SSRF guard refuses to send if DNS fails; a wide swathe of test
    fixtures use unresolvable hostnames like ``push.example`` or
    ``example.test``. Stub ``_resolve`` so these tests don't need the
    network — tests that exercise SSRF DNS behaviour explicitly
    re-patch ``ssrf._resolve`` and the later setattr wins.
    """
    monkeypatch.setattr(_ssrf, "_resolve", lambda hostname: ["93.184.216.34"])


_CSRF_RE = re.compile(r'<input[^>]*name="_csrf"[^>]*value="([^"]+)"', re.IGNORECASE)


def fetch_csrf(client: TestClient) -> str:
    """Return a session-bound CSRF token by hitting ``GET /login``.

    Mints (or reuses) the token in the test client's session cookie and
    extracts the value from the rendered hidden input. Tests pass it
    back as ``data={"_csrf": ...}`` (or via the ``X-CSRF-Token``
    header) so CSRF-protected POSTs accept the request.
    """
    response = client.get("/login")
    assert response.status_code in (200, 303), response.text
    if response.status_code == 303:
        # Already-logged-in branch redirects without a form; mint via a
        # second hit while logged out is impossible, so fall through to
        # the meta tag on whatever page the redirect lands on.
        response = client.get("/login", follow_redirects=True)
    match = _CSRF_RE.search(response.text)
    if match is None:
        # Fall back to the base.html meta tag on any rendered page.
        meta = re.search(
            r'<meta\s+name="csrf-token"\s+content="([^"]+)"',
            response.text,
            re.IGNORECASE,
        )
        assert meta is not None, "no CSRF token in response"
        return meta.group(1)
    return match.group(1)


@pytest.fixture
def client() -> Iterator[TestClient]:
    with TestClient(app) as test_client:
        yield test_client
