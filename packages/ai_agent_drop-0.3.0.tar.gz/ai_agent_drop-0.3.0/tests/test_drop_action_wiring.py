"""Frontend wiring tests for the Pin/Archive actions on the drop page.

These tests only care about what the rendered HTML looks like. The POST
endpoints themselves live in ``agentdrop.web.drop_actions`` (Agent A) and
are covered by their own test module. What's verified here:

* HTMX is pulled in from the CDN at a pinned minor version.
* Each action renders as a ``<form method="post">`` (progressive-enhancement
  fallback) wrapping a single ``<button>`` that carries the HTMX attrs.
* The button label and active class flip with the drop's ``pinned_at`` /
  ``archived_at`` state.
* The Copy button is left alone (client-only, no hx-post).
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from datetime import UTC, datetime
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


def _make_drop(**overrides: object) -> Drop:
    fields: dict[str, object] = {
        "short_id": "wiringdrop00000000000000",
        "title": "Wiring fixture",
        "body": "Fixture body.",
        "content_md": "Fixture body.\n",
        "source": "wiring",
        "tags_json": [],
        "priority": "normal",
    }
    fields.update(overrides)

    session = SessionLocal(bind=get_engine())
    try:
        drop = Drop(**fields)
        session.add(drop)
        session.commit()
        session.refresh(drop)
        session.expunge(drop)
        return drop
    finally:
        session.close()


def _find_action_form(html: str, short_id: str, kind: str) -> str:
    """Return the substring of ``html`` containing the ``<form>`` for ``kind``.

    Matches from ``<form`` up to the closing ``</form>``. Raises if absent.
    """
    action = f"/d/{short_id}/{kind}"
    # Match the smallest <form ...> ... </form> that contains the action URL.
    pattern = re.compile(
        r"<form\b[^>]*action=\"" + re.escape(action) + r"\"[^>]*>.*?</form>",
        re.DOTALL,
    )
    match = pattern.search(html)
    assert match is not None, f"No <form> found posting to {action}\n\nHTML:\n{html}"
    return match.group(0)


def test_drop_page_includes_pinned_htmx_script(client: TestClient) -> None:
    _make_drop(short_id="htmxscript00000000000000")
    resp = client.get("/d/htmxscript00000000000000")
    assert resp.status_code == 200, resp.text

    # HTMX must be loaded at a pinned minor version, not "latest".
    assert "unpkg.com/htmx.org@1.9.12" in resp.text
    assert "htmx.org@latest" not in resp.text


def test_drop_page_renders_pin_and_archive_forms(client: TestClient) -> None:
    _make_drop(short_id="wiringforms00000000aaaaa")
    resp = client.get("/d/wiringforms00000000aaaaa")
    assert resp.status_code == 200

    pin_form = _find_action_form(resp.text, "wiringforms00000000aaaaa", "pin")
    archive_form = _find_action_form(resp.text, "wiringforms00000000aaaaa", "archive")

    # Both are POST forms (no-JS fallback).
    assert 'method="post"' in pin_form
    assert 'method="post"' in archive_form


def test_pin_and_archive_buttons_carry_htmx_attrs(client: TestClient) -> None:
    _make_drop(short_id="htmxattrs00000000000aaaa")
    resp = client.get("/d/htmxattrs00000000000aaaa")

    for kind in ("pin", "archive"):
        form = _find_action_form(resp.text, "htmxattrs00000000000aaaa", kind)
        assert f'hx-post="/d/htmxattrs00000000000aaaa/{kind}"' in form
        assert 'hx-target="this"' in form
        assert 'hx-swap="outerHTML"' in form


def test_default_labels_are_pin_and_archive(client: TestClient) -> None:
    _make_drop(short_id="defaultlabels0000000aaaa")
    resp = client.get("/d/defaultlabels0000000aaaa")
    html = resp.text

    pin_form = _find_action_form(html, "defaultlabels0000000aaaa", "pin")
    archive_form = _find_action_form(html, "defaultlabels0000000aaaa", "archive")

    assert ">Pin<" in pin_form
    assert ">Archive<" in archive_form
    # Not in an "already done" state, so no active class on either button.
    assert "action-btn--pin-active" not in pin_form
    assert "action-btn--archive-active" not in archive_form


def test_copy_button_is_untouched(client: TestClient) -> None:
    _make_drop(short_id="copybtn00000000000000aaa")
    resp = client.get("/d/copybtn00000000000000aaa")
    html = resp.text

    # A <button data-action="copy" ...> lives in the actions row.
    copy_match = re.search(
        r'<button\b[^>]*data-action="copy"[^>]*>.*?</button>',
        html,
        re.DOTALL,
    )
    assert copy_match is not None, "Copy button not found"
    copy_btn = copy_match.group(0)

    # The copy button must NOT have been HTMX-wired.
    assert "hx-post" not in copy_btn
    assert "hx-target" not in copy_btn
    # The label is preserved.
    assert ">Copy<" in copy_btn


def test_pinned_drop_renders_pinned_label_and_active_class(client: TestClient) -> None:
    _make_drop(
        short_id="pinnedstate000000000aaaa",
        pinned_at=datetime.now(UTC),
    )
    resp = client.get("/d/pinnedstate000000000aaaa")
    html = resp.text

    pin_form = _find_action_form(html, "pinnedstate000000000aaaa", "pin")
    assert "action-btn--pin-active" in pin_form
    assert ">Pinned<" in pin_form
    # aria-pressed reflects active state for screen readers.
    assert 'aria-pressed="true"' in pin_form

    # Archive, untouched, still says "Archive" (no active class).
    archive_form = _find_action_form(html, "pinnedstate000000000aaaa", "archive")
    assert "action-btn--archive-active" not in archive_form
    assert ">Archive<" in archive_form


def test_archived_drop_renders_archived_label_and_active_class(client: TestClient) -> None:
    _make_drop(
        short_id="archivedstate0000000aaaa",
        archived_at=datetime.now(UTC),
    )
    resp = client.get("/d/archivedstate0000000aaaa")
    html = resp.text

    archive_form = _find_action_form(html, "archivedstate0000000aaaa", "archive")
    assert "action-btn--archive-active" in archive_form
    assert ">Archived<" in archive_form
    assert 'aria-pressed="true"' in archive_form

    # Pin, untouched, still says "Pin" (no active class).
    pin_form = _find_action_form(html, "archivedstate0000000aaaa", "pin")
    assert "action-btn--pin-active" not in pin_form
    assert ">Pin<" in pin_form
