"""End-to-end Alembic round-trip on a fresh SQLite tempfile DB.

Exercises ``upgrade head`` -> ``downgrade -1`` -> ``upgrade head`` on the
full migration chain. The downgrade-by-one lands on the revision *before*
the FTS5 migration (currently ``63706b51734b``), so the cycle proves that
the most schema-active migration in the project — the SQLite virtual
table + three triggers — is reversible end-to-end.

Driven via ``python -m alembic`` subprocess calls so we go through the
exact code path that ``make migrate`` and the deploy pipeline use.
"""

from __future__ import annotations

import os
import sqlite3
import subprocess
import sys
from pathlib import Path

ALEMBIC_HEAD = "head"

# Revision IDs (linear chain). Keep in sync with ``alembic/versions/*``.
REV_BEFORE_FTS = "63706b51734b"  # routing_rules — the rev FTS5 builds on
REV_FTS = "8ba4a3445348"  # add drops_fts5_index


def _inherit_env(db_url: str) -> dict[str, str]:
    """Build a minimal env for the alembic subprocess."""
    keys = ("PATH", "PYTHONPATH", "HOME", "USER", "LANG", "LC_ALL", "LC_CTYPE")
    env = {k: os.environ[k] for k in keys if k in os.environ}
    env.update(
        {
            "AGENTDROP_DATABASE_URL": db_url,
            "AGENTDROP_BASE_URL": "https://drop.test",
            "AGENTDROP_SECRET_KEY": "test-secret-key",
            # Required by the ``encrypt_channel_config_json`` migration's
            # crypto.secrets import path.
            "AGENTDROP_ENCRYPTION_KEY": os.environ.get(
                "AGENTDROP_ENCRYPTION_KEY",
                "q3pBGsixz44PtbFvLmCLMuOnAwmmNwdFHYFZoGnOXTM=",
            ),
        }
    )
    return env


def _alembic(args: list[str], env: dict[str, str]) -> None:
    subprocess.run(  # noqa: S603 — args constructed from constants + repo paths
        [sys.executable, "-m", "alembic", *args],
        env=env,
        check=True,
        capture_output=True,
    )


def test_alembic_round_trip_through_fts5_migration(tmp_path: Path) -> None:
    """upgrade head -> downgrade -1 -> upgrade head leaves a clean schema."""
    db_path = tmp_path / "round_trip.db"
    db_url = f"sqlite:///{db_path}"
    env = _inherit_env(db_url)

    # 1. Fresh DB, migrate forward to head. The FTS5 migration is the last
    #    in the chain only if no later migrations have landed; we don't
    #    rely on that. Instead we explicitly downgrade to the pre-FTS rev
    #    in step 2.
    _alembic(["upgrade", ALEMBIC_HEAD], env)

    # FTS5 virtual table must exist and be queryable after the first
    # forward pass.
    with sqlite3.connect(db_path) as conn:
        names = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table','trigger')"
            )
        }
    assert "drops_fts" in names
    assert {"drops_fts_ai", "drops_fts_au", "drops_fts_ad"}.issubset(names)

    # 2. Downgrade past the FTS migration. Use the rev id explicitly so
    #    the test stays meaningful even if newer migrations are added on
    #    top: the FTS5 add/drop is what we actually want to exercise.
    _alembic(["downgrade", REV_BEFORE_FTS], env)

    with sqlite3.connect(db_path) as conn:
        names = {
            row[0]
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table','trigger')"
            )
        }
    assert "drops_fts" not in names
    assert "drops_fts_ai" not in names
    assert "drops_fts_au" not in names
    assert "drops_fts_ad" not in names
    # Core tables still present at the prior rev.
    assert "drops" in names
    assert "routing_rules" in names

    # 3. Re-apply head. This proves the FTS migration's upgrade is
    #    re-runnable after a downgrade — i.e. the trigger and table
    #    drops were complete (no leftovers that would cause CREATE
    #    TRIGGER to fail with "already exists").
    _alembic(["upgrade", ALEMBIC_HEAD], env)

    with sqlite3.connect(db_path) as conn:
        # Virtual table is queryable end-to-end.
        match_count = conn.execute(
            "SELECT COUNT(*) FROM drops_fts WHERE drops_fts MATCH 'anything'"
        ).fetchone()[0]
    assert match_count == 0
