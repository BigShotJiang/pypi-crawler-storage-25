"""Tests for the scheduler's multi-worker advisory file lock (issue #14 F1).

Under ``uvicorn --workers N`` each worker imports the scheduler module
and calls :func:`agentdrop.scheduler.start_scheduler`. Without
coordination, every worker would spawn its own background sweep —
wasteful, and racy on the soft-delete → hard-delete transition.

The lock is a POSIX advisory ``fcntl.flock`` on a path under the
configured data directory. These tests exercise:

* The bare lock helper (:func:`_acquire_scheduler_lock`) — the low-level
  primitive everything else builds on.
* A ``start_scheduler`` that lost the race — the second start sees the
  lock held by another holder and logs an info line.
* Shutdown releases the lock, freeing it for a subsequent start.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterator
from pathlib import Path

import pytest

from agentdrop import scheduler as scheduler_mod
from agentdrop.config import get_settings


@pytest.fixture(autouse=True)
def reset_settings_cache() -> Iterator[None]:
    """Invalidate the cached ``Settings`` between tests.

    ``get_settings`` is ``@lru_cache``'d at the module level. Without
    clearing the cache, env vars set by a previous test would leak into
    this one.
    """
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


@pytest.fixture(autouse=True)
def teardown_scheduler() -> Iterator[None]:
    """Ensure no test leaves a background thread or open lock FD behind."""
    yield
    scheduler_mod.stop_scheduler()


def _set_lock_path(monkeypatch: pytest.MonkeyPatch, path: Path) -> None:
    """Point the scheduler at a tmp_path-scoped lock file.

    Sets ``AGENTDROP_RETENTION_DISABLED=false`` and
    ``AGENTDROP_RETENTION_INTERVAL_HOURS=24`` while we're at it — every
    test in this module wants the scheduler enabled but unfired.
    """
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "false")
    monkeypatch.setenv("AGENTDROP_RETENTION_INTERVAL_HOURS", "24")
    monkeypatch.setenv("AGENTDROP_SCHEDULER_LOCK_PATH", str(path))


def test_acquire_lock_succeeds_when_unheld(tmp_path: Path) -> None:
    lock_path = tmp_path / ".scheduler.lock"

    fd = scheduler_mod._acquire_scheduler_lock(lock_path)
    try:
        assert fd is not None
        assert lock_path.exists()
    finally:
        if fd is not None:
            os.close(fd)


def test_acquire_lock_fails_when_held_by_another_holder(tmp_path: Path) -> None:
    """Second acquisition against the same path returns ``None``.

    Two distinct file descriptors on the same path are exactly what
    distinct uvicorn workers look like to the kernel — each fork-exec'd
    process opens its own FD on the shared bind-mount. Tested in-process
    here for speed and determinism.
    """
    lock_path = tmp_path / ".scheduler.lock"

    first = scheduler_mod._acquire_scheduler_lock(lock_path)
    second = scheduler_mod._acquire_scheduler_lock(lock_path)
    try:
        assert first is not None
        assert second is None
    finally:
        if first is not None:
            os.close(first)


def test_acquire_lock_succeeds_after_holder_releases(tmp_path: Path) -> None:
    """Closing the holder's FD frees the lock for the next acquirer."""
    lock_path = tmp_path / ".scheduler.lock"

    first = scheduler_mod._acquire_scheduler_lock(lock_path)
    assert first is not None
    os.close(first)

    second = scheduler_mod._acquire_scheduler_lock(lock_path)
    try:
        assert second is not None
    finally:
        if second is not None:
            os.close(second)


def test_start_scheduler_acquires_lock_and_runs(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    lock_path = tmp_path / ".scheduler.lock"
    _set_lock_path(monkeypatch, lock_path)

    scheduler_mod.start_scheduler()

    assert scheduler_mod._scheduler is not None
    assert scheduler_mod._scheduler.running is True
    assert scheduler_mod._lock_fd is not None
    assert lock_path.exists()


def test_second_start_when_lock_held_externally_skips(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Simulate worker #2: lock already held externally, start is a no-op.

    We hold the lock with our own FD (representing worker #1) and call
    ``start_scheduler``, which now plays the role of worker #2's
    startup. It must observe the contention and skip without crashing,
    leaving the module-level singleton untouched and emitting the
    documented info line so operators can see what happened in their
    logs.
    """
    lock_path = tmp_path / ".scheduler.lock"
    _set_lock_path(monkeypatch, lock_path)

    # "Worker #1": grab the lock and hold it.
    holder_fd = scheduler_mod._acquire_scheduler_lock(lock_path)
    assert holder_fd is not None

    try:
        with caplog.at_level(logging.INFO, logger="agentdrop.retention"):
            # "Worker #2": tries to start, should skip silently.
            scheduler_mod.start_scheduler()

        assert scheduler_mod._scheduler is None
        assert scheduler_mod._lock_fd is None
        # The skip is observable in logs — operators rely on this line.
        assert any(
            "retention_scheduler_lock_held_by_other_worker" in record.getMessage()
            for record in caplog.records
        ), [r.getMessage() for r in caplog.records]
    finally:
        os.close(holder_fd)


def test_stop_scheduler_releases_lock(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    """After ``stop_scheduler`` a fresh acquisition must succeed.

    This is the contract that makes restart-after-crash work: if the
    process exits cleanly the lock is released; if it doesn't, the
    kernel releases the FD on process death anyway.
    """
    lock_path = tmp_path / ".scheduler.lock"
    _set_lock_path(monkeypatch, lock_path)

    scheduler_mod.start_scheduler()
    assert scheduler_mod._lock_fd is not None

    scheduler_mod.stop_scheduler()

    assert scheduler_mod._scheduler is None
    assert scheduler_mod._lock_fd is None

    # The freshly-released lock should be acquirable by a new "worker".
    fd = scheduler_mod._acquire_scheduler_lock(lock_path)
    try:
        assert fd is not None
    finally:
        if fd is not None:
            os.close(fd)


def test_disabled_flag_prevents_lock_acquisition(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    """``AGENTDROP_RETENTION_DISABLED=true`` short-circuits before the lock.

    The disabled path must not touch the filesystem — tests rely on it
    to avoid writing to ``/data`` from CI environments without that
    directory.
    """
    lock_path = tmp_path / ".scheduler.lock"
    _set_lock_path(monkeypatch, lock_path)
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")

    scheduler_mod.start_scheduler()

    assert scheduler_mod._scheduler is None
    assert scheduler_mod._lock_fd is None
    assert not lock_path.exists()
