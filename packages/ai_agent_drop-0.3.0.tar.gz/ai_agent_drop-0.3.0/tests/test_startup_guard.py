"""Tests for the lifespan encryption-key startup guard (issue #17 phase 2B).

The helper ``_check_encryption_key_or_die`` is exercised directly with a
fresh in-memory SQLite session so we don't have to spin up the full
FastAPI lifespan — the helper is the single place all the policy lives,
and ``lifespan`` is a one-liner around it.
"""

from __future__ import annotations

import base64
import secrets
from collections.abc import Iterator

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.main import _check_encryption_key_or_die
from agentdrop.models import Channel  # noqa: F401  -- registers mapper


def _gen_key() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()


@pytest.fixture
def session() -> Iterator[Session]:
    """Fresh in-memory DB per test so channel counts start at zero."""
    engine = create_engine("sqlite://", future=True)
    Base.metadata.create_all(engine)
    with Session(engine) as s:
        yield s
    engine.dispose()


@pytest.fixture(autouse=True)
def _reset_settings_cache(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Each test owns its env; clear the cached Settings before & after.

    The autouse fixture in :mod:`tests.conftest` and the ``setdefault``
    at module load may have already cached a settings instance with the
    default test key — wipe it so per-test ``setenv``/``delenv`` calls
    actually take effect.
    """
    get_settings.cache_clear()
    yield
    get_settings.cache_clear()


def test_no_channels_no_key_starts_fine(session: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    """Fresh install: zero rows, no key — should be a no-op."""
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()

    # Must not raise.
    _check_encryption_key_or_die(session)


def test_channels_present_no_key_raises(session: Session, monkeypatch: pytest.MonkeyPatch) -> None:
    """Existing channel row + no key — refuse to start."""
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()

    # Seed one row directly via SQL so we don't trip the EncryptedJSON
    # column adaptation when phase 2A merges and adds it to the model.
    from sqlalchemy import text

    session.execute(
        text(
            "INSERT INTO channels (id, name, driver, config_json, is_default) "
            "VALUES (:id, :name, :driver, :cfg, 0)"
        ),
        {"id": "ch_test1234567890", "name": "test", "driver": "webhook", "cfg": "{}"},
    )
    session.commit()

    with pytest.raises(RuntimeError, match=r"AGENTDROP_ENCRYPTION_KEY"):
        _check_encryption_key_or_die(session)


def test_channels_present_with_key_starts_fine(
    session: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Existing channel row + key set — happy path."""
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", _gen_key())
    get_settings.cache_clear()

    from sqlalchemy import text

    session.execute(
        text(
            "INSERT INTO channels (id, name, driver, config_json, is_default) "
            "VALUES (:id, :name, :driver, :cfg, 0)"
        ),
        {"id": "ch_test1234567890", "name": "test", "driver": "webhook", "cfg": "{}"},
    )
    session.commit()

    # Must not raise.
    _check_encryption_key_or_die(session)


def test_error_message_includes_keygen_command(
    session: Session, monkeypatch: pytest.MonkeyPatch
) -> None:
    """The message has to be actionable — name the var and the keygen one-liner."""
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY", raising=False)
    get_settings.cache_clear()

    from sqlalchemy import text

    session.execute(
        text(
            "INSERT INTO channels (id, name, driver, config_json, is_default) "
            "VALUES (:id, :name, :driver, :cfg, 0)"
        ),
        {"id": "ch_test1234567890", "name": "test", "driver": "webhook", "cfg": "{}"},
    )
    session.commit()

    with pytest.raises(RuntimeError) as exc_info:
        _check_encryption_key_or_die(session)
    msg = str(exc_info.value)
    assert "AGENTDROP_ENCRYPTION_KEY" in msg
    assert "urlsafe_b64encode" in msg
    assert "refusing to start" in msg.lower()
