"""End-to-end tests for the A4 CSRF protection layer.

Covers the matrix of:

* Session-authed POSTs reject missing tokens with 403.
* Session-authed POSTs accept valid tokens (form field or X-CSRF-Token header).
* A token from a different session is rejected.
* GET routes don't require a token.
* The bearer-token API surface (``/api/v1/*``) is exempt.
* HTMX-style header carry works as an alternative to the form field.
"""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import get_engine
from agentdrop.main import app
from agentdrop.web import rate_limit as rl
from agentdrop.web.session import (
    Admin,
    _get_admin_password_hash,
    require_session,
)

from .conftest import fetch_csrf

TEST_ADMIN_PASSWORD = "csrf-test-admin-password"


@pytest.fixture
def overridden_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient with a tmp DB and ``require_session`` overridden.

    Mirrors the pattern used in ``test_settings_channels.py``: bypasses
    the real login flow by stubbing the session dependency. This lets
    us isolate CSRF behaviour without dragging in the bearer/login
    machinery for every assertion.
    """
    db_path = tmp_path / "csrf.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key-for-csrf")
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()
    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


@pytest.fixture
def real_login_client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """TestClient that drives the actual login flow (no override)."""
    db_path = tmp_path / "csrf-real.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key-for-csrf")
    monkeypatch.setenv("AGENTDROP_ADMIN_PASSWORD", TEST_ADMIN_PASSWORD)
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()
    _get_admin_password_hash.cache_clear()
    rl._TEST_clear()
    Base.metadata.create_all(get_engine())
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()
        _get_admin_password_hash.cache_clear()
        rl._TEST_clear()


# ---------------------------------------------------------------------------
# Missing / mismatched tokens are rejected with 403
# ---------------------------------------------------------------------------


def test_settings_channels_post_without_token_is_403(
    overridden_client: TestClient,
) -> None:
    response = overridden_client.post(
        "/settings/channels",
        data={"name": "phone", "driver": "ntfy", "config_json": "{}"},
        follow_redirects=False,
    )
    assert response.status_code == 403


def test_pwa_subscribe_without_token_is_403(
    overridden_client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("AGENTDROP_VAPID_PUBLIC_KEY", "fake-key")
    monkeypatch.setenv("AGENTDROP_VAPID_PRIVATE_KEY", "fake-private")
    monkeypatch.setenv("AGENTDROP_VAPID_SUBJECT", "mailto:t@example.com")
    get_settings.cache_clear()

    response = overridden_client.post(
        "/pwa/subscribe",
        json={
            "endpoint": "https://push.example/x",
            "keys": {"p256dh": "p", "auth": "a"},
        },
    )
    assert response.status_code == 403


def test_drop_action_post_without_token_is_403(
    overridden_client: TestClient,
) -> None:
    # Path with a syntactically valid short_id; CSRF check fires before
    # the DB lookup so it doesn't matter that the row doesn't exist.
    response = overridden_client.post(
        "/d/csrftest000000000000aaaa/pin",
        follow_redirects=False,
    )
    assert response.status_code == 403


def test_login_post_without_token_is_403(
    real_login_client: TestClient,
) -> None:
    """Even unauthenticated, ``POST /login`` enforces the session-bound
    CSRF token. The token is seeded by the GET that renders the form."""
    response = real_login_client.post(
        "/login",
        data={"password": TEST_ADMIN_PASSWORD},
        follow_redirects=False,
    )
    assert response.status_code == 403


# ---------------------------------------------------------------------------
# Valid token is accepted
# ---------------------------------------------------------------------------


def test_settings_channels_post_with_valid_token_succeeds(
    overridden_client: TestClient,
) -> None:
    token = fetch_csrf(overridden_client)
    response = overridden_client.post(
        "/settings/channels",
        data={
            "name": "phone",
            "driver": "ntfy",
            "config_json": '{"topic": "drops"}',
            "_csrf": token,
        },
        follow_redirects=False,
    )
    # Channels accept happy path → 303 to list page.
    assert response.status_code == 303, response.text


def test_x_csrf_token_header_is_accepted(
    overridden_client: TestClient,
) -> None:
    """HTMX-style requests pass the token via the header instead of a form field."""
    token = fetch_csrf(overridden_client)
    response = overridden_client.post(
        "/d/csrftest000000000000aaaa/pin",
        headers={"X-CSRF-Token": token, "HX-Request": "true"},
        follow_redirects=False,
    )
    # 404 means the token cleared CSRF and we hit the drop-not-found
    # branch — which is exactly what we want to assert: CSRF passed.
    assert response.status_code == 404


def test_login_post_with_valid_token_succeeds(
    real_login_client: TestClient,
) -> None:
    token = fetch_csrf(real_login_client)
    response = real_login_client.post(
        "/login",
        data={"password": TEST_ADMIN_PASSWORD, "_csrf": token},
        follow_redirects=False,
    )
    assert response.status_code == 303
    assert response.headers["location"] == "/"


# ---------------------------------------------------------------------------
# Cross-session token is rejected
# ---------------------------------------------------------------------------


def test_token_from_different_session_is_rejected(
    overridden_client: TestClient,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """A token minted in client A must not be accepted on a request from client B."""
    foreign_token = fetch_csrf(overridden_client)

    # Build a second TestClient whose session/cookie state is independent.
    with TestClient(app) as other_client:
        # Mint a token in *this* client too so the session has *some*
        # csrf_token — otherwise the check fails at the "no token in
        # session" gate rather than at the comparison.
        fetch_csrf(other_client)
        response = other_client.post(
            "/settings/channels",
            data={
                "name": "phone",
                "driver": "ntfy",
                "config_json": '{"topic": "drops"}',
                "_csrf": foreign_token,
            },
            follow_redirects=False,
        )
    assert response.status_code == 403


# ---------------------------------------------------------------------------
# GET routes don't require a token
# ---------------------------------------------------------------------------


def test_get_settings_channels_does_not_require_token(
    overridden_client: TestClient,
) -> None:
    response = overridden_client.get("/settings/channels")
    assert response.status_code == 200


def test_get_login_does_not_require_token(real_login_client: TestClient) -> None:
    response = real_login_client.get("/login")
    assert response.status_code == 200
    assert 'name="_csrf"' in response.text


def test_get_health_does_not_require_token(overridden_client: TestClient) -> None:
    response = overridden_client.get("/health")
    assert response.status_code == 200


def test_vapid_public_key_get_is_unauth_and_noncsrf(
    overridden_client: TestClient,
) -> None:
    response = overridden_client.get("/pwa/vapid-public-key")
    assert response.status_code == 200


# ---------------------------------------------------------------------------
# Bearer-token API exempt
# ---------------------------------------------------------------------------


def test_api_post_with_bearer_does_not_require_csrf(
    overridden_client: TestClient,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``POST /api/v1/drops`` uses bearer-token auth and is exempt from
    CSRF. The agent supplies its key in the ``Authorization`` header,
    not via cookies, so the CSRF threat doesn't apply."""
    monkeypatch.setenv("AGENTDROP_API_KEY", "test-bearer-key-1234")
    get_settings.cache_clear()

    response = overridden_client.post(
        "/api/v1/drops",
        json={
            "title": "csrf exempt",
            "body": "the api is exempt",
            "content": "# hi",
            "source": "test",
        },
        headers={"Authorization": "Bearer test-bearer-key-1234"},
    )
    # 201 on success — proves the API path runs to completion without
    # anyone having injected a CSRF token.
    assert response.status_code == 201, response.text
