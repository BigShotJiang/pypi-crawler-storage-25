"""Tests for the session-authed ``POST /admin/retention/run`` endpoint.

The endpoint is a thin wrapper around :func:`agentdrop.retention.run_retention`
— these tests exercise the wiring (auth posture, response shape,
idempotency) rather than re-testing the sweep semantics, which belong to
``tests/test_retention.py`` if/when Agent A adds one.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.main import app
from agentdrop.models import Drop
from agentdrop.web.session import Admin, require_session

from .conftest import fetch_csrf


@pytest.fixture
def client(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[TestClient]:
    """Test client with a fresh SQLite DB and session auth overridden.

    Matches the pattern established in ``test_drop_actions.py``: we
    bypass the real login flow by overriding ``require_session`` with a
    sentinel. One test below clears the override to exercise the
    redirect-to-login path.
    """
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    # Tight retention windows so a single datetime.now() call sees a
    # soft-delete + a hard-delete candidate without time-travelling the
    # fixture.
    monkeypatch.setenv("AGENTDROP_RETENTION_DAYS", "30")
    monkeypatch.setenv("AGENTDROP_TOMBSTONE_DAYS", "60")
    # Don't let the scheduler thread start up under TestClient.
    monkeypatch.setenv("AGENTDROP_RETENTION_DISABLED", "true")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())

    app.dependency_overrides[require_session] = lambda: Admin()
    try:
        with TestClient(app) as test_client:
            yield test_client
    finally:
        app.dependency_overrides.pop(require_session, None)
        get_engine.cache_clear()
        get_settings.cache_clear()


def _make_drop(**overrides: object) -> Drop:
    """Persist a Drop via a dedicated session and return the detached row."""
    fields: dict[str, object] = {
        "short_id": "adminret00000000000000aa",
        "title": "A drop",
        "body": "Summary.",
        "content_md": "# hello",
        "source": "weekly-scan",
    }
    fields.update(overrides)

    session = SessionLocal(bind=get_engine())
    try:
        drop = Drop(**fields)
        session.add(drop)
        session.commit()
        session.refresh(drop)
        session.expunge(drop)
        return drop
    finally:
        session.close()


def _seed_retention_corpus() -> None:
    """Seed drops covering every retention case in one fixture.

    * ``fresh`` — created just now. Should not transition.
    * ``old_unpinned`` — created > 30d ago, not pinned. Should soft-delete.
    * ``old_pinned`` — created > 30d ago but pinned. Pin exempts — no change.
    * ``tombstone`` — already soft-deleted, soft_deleted_at > 60d ago.
      Should hard-delete.
    """
    now = datetime.now(UTC)
    _make_drop(short_id="fresh00000000000000000aa", title="Fresh")
    _make_drop(
        short_id="oldunpinned0000000000000",
        title="Old unpinned",
        # Override created_at by direct assignment below — SQLAlchemy
        # default doesn't trigger when we pass an explicit value, so use
        # a raw session update.
    )
    _make_drop(
        short_id="oldpinned000000000000000",
        title="Old pinned",
        pinned_at=now - timedelta(days=40),
    )
    _make_drop(
        short_id="tombstone000000000000000",
        title="Tombstone",
        soft_deleted_at=now - timedelta(days=65),
    )

    # Backdate created_at on the rows that need to look "old". SQLAlchemy
    # sets ``created_at`` via the server default at INSERT time, so we
    # override it after the fact.
    session = SessionLocal(bind=get_engine())
    try:
        for short_id, created_offset_days in [
            ("oldunpinned0000000000000", 40),
            ("oldpinned000000000000000", 40),
            ("tombstone000000000000000", 70),
        ]:
            drop = session.query(Drop).filter(Drop.short_id == short_id).one()
            drop.created_at = now - timedelta(days=created_offset_days)
            session.add(drop)
        session.commit()
    finally:
        session.close()


def _reload(short_id: str) -> Drop | None:
    session = SessionLocal(bind=get_engine())
    try:
        return session.query(Drop).filter(Drop.short_id == short_id).one_or_none()
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Auth posture
# ---------------------------------------------------------------------------


def test_retention_run_unauth_redirects_to_login(client: TestClient) -> None:
    """Dropping the session override -> 303 to /login with ?next=."""
    # Clear the override so the real require_session runs.
    app.dependency_overrides.pop(require_session, None)
    try:
        resp = client.post("/admin/retention/run", follow_redirects=False)
    finally:
        app.dependency_overrides[require_session] = lambda: Admin()

    assert resp.status_code == 303
    assert resp.headers["location"].startswith("/login")
    assert "next=" in resp.headers["location"]


# ---------------------------------------------------------------------------
# Response shape + transitions
# ---------------------------------------------------------------------------


def test_retention_run_returns_stats_shape(client: TestClient) -> None:
    _seed_retention_corpus()

    resp = client.post(
        "/admin/retention/run",
        headers={"X-CSRF-Token": fetch_csrf(client)},
    )
    assert resp.status_code == 200, resp.text

    data = resp.json()
    # All four fields of RetentionStats must be present.
    assert set(data.keys()) == {"soft_deleted", "hard_deleted", "examined", "ran_at"}
    assert isinstance(data["soft_deleted"], int)
    assert isinstance(data["hard_deleted"], int)
    assert isinstance(data["examined"], int)
    # ran_at is ISO-8601 serialisable.
    assert isinstance(data["ran_at"], str)
    # Round-trips through fromisoformat without raising.
    datetime.fromisoformat(data["ran_at"])


def test_retention_run_transitions_expected_drops(client: TestClient) -> None:
    _seed_retention_corpus()

    resp = client.post(
        "/admin/retention/run",
        headers={"X-CSRF-Token": fetch_csrf(client)},
    )
    assert resp.status_code == 200, resp.text
    data = resp.json()

    # One old unpinned drop → soft-deleted.
    assert data["soft_deleted"] >= 1
    # One tombstone aged past 60d → hard-deleted.
    assert data["hard_deleted"] >= 1

    # Spot-check the individual rows.
    fresh = _reload("fresh00000000000000000aa")
    assert fresh is not None and fresh.soft_deleted_at is None

    old_unpinned = _reload("oldunpinned0000000000000")
    assert old_unpinned is not None
    assert old_unpinned.soft_deleted_at is not None
    assert old_unpinned.content_md == ""
    assert old_unpinned.body == ""

    old_pinned = _reload("oldpinned000000000000000")
    assert old_pinned is not None
    # Pin exempts — must still be active.
    assert old_pinned.soft_deleted_at is None

    tombstone = _reload("tombstone000000000000000")
    assert tombstone is None  # hard-deleted


# ---------------------------------------------------------------------------
# Idempotency
# ---------------------------------------------------------------------------


def test_retention_run_is_idempotent(client: TestClient) -> None:
    _seed_retention_corpus()

    headers = {"X-CSRF-Token": fetch_csrf(client)}
    first = client.post("/admin/retention/run", headers=headers).json()
    second = client.post("/admin/retention/run", headers=headers).json()

    # The second run can't find new work: nothing new aged into a
    # window between the two back-to-back invocations.
    assert second["soft_deleted"] == 0
    assert second["hard_deleted"] == 0
    # ``examined`` is a plain active-row count; it should drop by the
    # number soft-deleted on the first run.
    assert second["examined"] <= first["examined"]
