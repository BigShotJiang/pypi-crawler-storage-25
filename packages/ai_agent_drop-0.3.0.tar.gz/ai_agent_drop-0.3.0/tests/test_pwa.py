"""Tests for the PWA shell — manifest, service worker, head wiring.

This is the foundation PR: it verifies the page is recognised as a PWA
(installable on iOS / Android) and the service worker has root scope.
Push delivery is exercised by the next PR's tests; these only confirm
the SW is reachable and registers cleanly.
"""

from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from agentdrop.web import static_dir


def test_manifest_is_served(client: TestClient) -> None:
    response = client.get("/static/manifest.webmanifest")
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Agent Drop"
    assert data["start_url"] == "/"
    assert data["scope"] == "/"
    assert data["display"] == "standalone"


def test_manifest_lists_required_icon_sizes(client: TestClient) -> None:
    response = client.get("/static/manifest.webmanifest")
    icons = response.json()["icons"]
    sizes = {icon["sizes"] for icon in icons}
    assert "192x192" in sizes
    assert "512x512" in sizes
    purposes = {icon.get("purpose") for icon in icons}
    assert "maskable" in purposes


def test_service_worker_served_at_root_with_js_content_type(
    client: TestClient,
) -> None:
    """SW *must* be at root — serving from /static/sw.js would scope it
    to /static/* and the worker couldn't claim drop / inbox URLs."""
    response = client.get("/sw.js")
    assert response.status_code == 200
    assert response.headers["content-type"].startswith("application/javascript")
    assert "self.addEventListener" in response.text


def test_service_worker_not_aggressively_cached(client: TestClient) -> None:
    response = client.get("/sw.js")
    cache_control = response.headers.get("cache-control", "")
    assert "no-cache" in cache_control


def test_static_under_static_does_not_serve_sw_at_root_implicitly(
    client: TestClient,
) -> None:
    """Sanity: the static mount is unchanged. /static/sw.js should also
    work (since the file is under static_dir), but the canonical scope
    target is /sw.js — both paths exist and that's fine."""
    response = client.get("/static/sw.js")
    assert response.status_code == 200


def test_pwa_icons_exist_on_disk() -> None:
    """The generation script outputs four PNGs that are committed to the
    repo — make sure the manifest's referenced files actually ship."""
    icons_dir = static_dir / "icons"
    assert (icons_dir / "icon-192.png").is_file()
    assert (icons_dir / "icon-512.png").is_file()
    assert (icons_dir / "icon-180-apple.png").is_file()
    assert (icons_dir / "icon-maskable-512.png").is_file()


def test_icon_endpoints_serve_png(client: TestClient) -> None:
    for name in ("icon-192", "icon-512", "icon-180-apple", "icon-maskable-512"):
        response = client.get(f"/static/icons/{name}.png")
        assert response.status_code == 200, name
        assert response.headers["content-type"] == "image/png", name
        # PNG signature: 89 50 4E 47 0D 0A 1A 0A
        assert response.content[:8] == b"\x89PNG\r\n\x1a\n", name


def test_inbox_head_includes_manifest_and_apple_icon(
    client: TestClient,
) -> None:
    """Pages rendered through base.html should advertise the PWA manifest
    and the apple-touch-icon. Hit /login since it's reachable without
    auth setup and also extends base.html."""
    response = client.get("/login")
    assert response.status_code == 200
    body = response.text
    assert '<link rel="manifest" href="/static/manifest.webmanifest">' in body
    assert '<link rel="apple-touch-icon" href="/static/icons/icon-180-apple.png">' in body
    assert '<meta name="theme-color" content="#f6efe6">' in body
    assert '<meta name="apple-mobile-web-app-capable" content="yes">' in body


def test_base_template_registers_service_worker(client: TestClient) -> None:
    response = client.get("/login")
    body = response.text
    assert "navigator.serviceWorker.register" in body
    assert '"/sw.js"' in body
    assert '"scope": "/"' in body or 'scope: "/"' in body


def test_manifest_file_is_valid_json_on_disk() -> None:
    """The manifest must be parseable as JSON — a typo would silently
    break PWA detection without an HTTP error."""
    path = static_dir / "manifest.webmanifest"
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    assert "icons" in data
    assert isinstance(data["icons"], list)
    assert len(data["icons"]) >= 2
