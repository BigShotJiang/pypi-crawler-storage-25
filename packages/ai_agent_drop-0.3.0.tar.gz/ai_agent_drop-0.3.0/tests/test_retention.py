"""Tests for the retention sweep (PRD §8.4).

Uses an in-memory SQLite engine so the DB state is fresh per test and
the whole suite runs in milliseconds. We build Drops directly with
explicit timestamps rather than going through the HTTP API — the
retention logic is a pure function of the DB state and the wall clock,
and the API round-trip would just obscure that.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta

import pytest
from sqlalchemy import Engine, create_engine, select
from sqlalchemy.orm import Session

from agentdrop.db.base import Base
from agentdrop.models import Drop
from agentdrop.retention import RetentionStats, run_retention

RETENTION_DAYS = 30
TOMBSTONE_DAYS = 60


@pytest.fixture
def engine() -> Iterator[Engine]:
    # Shared cache is unnecessary — we only need one connection's worth
    # of state for a single-test lifespan. ``sqlite://`` is in-memory.
    eng = create_engine("sqlite://", future=True)
    Base.metadata.create_all(eng)
    try:
        yield eng
    finally:
        eng.dispose()


@pytest.fixture
def session(engine: Engine) -> Iterator[Session]:
    with Session(engine) as s:
        yield s


# The "wall clock" every test uses. Fixed so eligibility math is
# predictable; injected into ``run_retention`` via the ``now`` kwarg.
FIXED_NOW = datetime(2026, 6, 1, 12, 0, 0, tzinfo=UTC)


def _make_drop(
    session: Session,
    *,
    title: str = "t",
    body: str = "b",
    content_md: str = "# hi",
    created_at: datetime,
    expires_at: datetime | None = None,
    pinned_at: datetime | None = None,
    archived_at: datetime | None = None,
    soft_deleted_at: datetime | None = None,
) -> Drop:
    """Insert a drop with explicit lifecycle timestamps.

    We set ``created_at`` manually (bypassing the server_default) because
    retention eligibility depends on historical dates, and SQLite's
    ``CURRENT_TIMESTAMP`` wouldn't help us pretend a drop is 45 days old.
    """
    drop = Drop(
        title=title,
        body=body,
        content_md=content_md,
        created_at=created_at,
        expires_at=expires_at,
        pinned_at=pinned_at,
        archived_at=archived_at,
        soft_deleted_at=soft_deleted_at,
    )
    session.add(drop)
    session.commit()
    session.refresh(drop)
    return drop


def _run(session: Session, now: datetime = FIXED_NOW) -> RetentionStats:
    return run_retention(
        session,
        retention_days=RETENTION_DAYS,
        tombstone_days=TOMBSTONE_DAYS,
        now=now,
    )


def test_young_drop_is_not_soft_deleted(session: Session) -> None:
    drop = _make_drop(session, created_at=FIXED_NOW - timedelta(days=5))

    stats = _run(session)

    session.refresh(drop)
    assert drop.soft_deleted_at is None
    assert stats.soft_deleted == 0
    assert stats.examined == 1


def test_old_drop_gets_soft_deleted_and_content_cleared(session: Session) -> None:
    drop = _make_drop(
        session,
        title="Keep me",
        body="gone soon",
        content_md="# bye",
        created_at=FIXED_NOW - timedelta(days=45),
    )

    stats = _run(session)

    session.refresh(drop)
    assert stats.soft_deleted == 1
    # SQLite strips tz info on round-trip; compare naive.
    assert drop.soft_deleted_at is not None
    assert drop.soft_deleted_at.replace(tzinfo=None) == FIXED_NOW.replace(tzinfo=None)
    # PRD §8.4: content cleared. Title preserved for audit.
    assert drop.content_md == ""
    assert drop.body == ""
    assert drop.title == "Keep me"


def test_pinned_drop_is_exempt(session: Session) -> None:
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=120),  # very old
        pinned_at=FIXED_NOW - timedelta(days=1),
    )

    stats = _run(session)

    session.refresh(drop)
    assert drop.soft_deleted_at is None
    assert stats.soft_deleted == 0


def test_explicit_expires_at_in_past_overrides_retention_window(session: Session) -> None:
    """Per-drop override: young drop with expires_at in the past is eligible."""
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=2),  # very young
        expires_at=FIXED_NOW - timedelta(hours=1),  # but already expired
    )

    stats = _run(session)

    session.refresh(drop)
    assert stats.soft_deleted == 1
    # SQLite strips tz info on round-trip; compare naive.
    assert drop.soft_deleted_at is not None
    assert drop.soft_deleted_at.replace(tzinfo=None) == FIXED_NOW.replace(tzinfo=None)


def test_explicit_expires_at_in_future_overrides_retention_window(session: Session) -> None:
    """Per-drop override: old drop with expires_at in the future stays."""
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=90),  # older than retention
        expires_at=FIXED_NOW + timedelta(days=30),  # but explicitly kept
    )

    stats = _run(session)

    session.refresh(drop)
    assert drop.soft_deleted_at is None
    assert stats.soft_deleted == 0


def test_tombstone_expired_drop_is_hard_deleted(session: Session) -> None:
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=120),
        soft_deleted_at=FIXED_NOW - timedelta(days=TOMBSTONE_DAYS + 1),
    )
    drop_id = drop.id

    stats = _run(session)

    assert stats.hard_deleted == 1
    # Row is gone.
    assert session.execute(select(Drop).where(Drop.id == drop_id)).scalar_one_or_none() is None


def test_recently_soft_deleted_drop_stays_as_tombstone(session: Session) -> None:
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=40),
        soft_deleted_at=FIXED_NOW - timedelta(days=10),
    )

    stats = _run(session)

    session.refresh(drop)
    assert stats.hard_deleted == 0
    assert drop.soft_deleted_at is not None  # still present


def test_idempotent_second_run_is_noop(session: Session) -> None:
    _make_drop(session, created_at=FIXED_NOW - timedelta(days=45))
    _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=120),
        soft_deleted_at=FIXED_NOW - timedelta(days=TOMBSTONE_DAYS + 1),
    )

    first = _run(session)
    assert first.soft_deleted == 1
    assert first.hard_deleted == 1

    second = _run(session)
    assert second.soft_deleted == 0
    assert second.hard_deleted == 0


def test_archived_drop_older_than_retention_is_soft_deleted(session: Session) -> None:
    """Archive hides from inbox but does NOT exempt from retention (PRD §8.4)."""
    drop = _make_drop(
        session,
        created_at=FIXED_NOW - timedelta(days=45),
        archived_at=FIXED_NOW - timedelta(days=40),
    )

    stats = _run(session)

    session.refresh(drop)
    assert stats.soft_deleted == 1
    # SQLite strips tz info on round-trip; compare naive.
    assert drop.soft_deleted_at is not None
    assert drop.soft_deleted_at.replace(tzinfo=None) == FIXED_NOW.replace(tzinfo=None)


def test_default_now_is_utc_aware(session: Session) -> None:
    """Smoke: ``now=None`` uses ``datetime.now(UTC)``, not naive now()."""
    _make_drop(session, created_at=FIXED_NOW - timedelta(days=5))
    # No ``now`` arg — must not raise a naive-vs-aware comparison error.
    stats = run_retention(session, retention_days=RETENTION_DAYS, tombstone_days=TOMBSTONE_DAYS)
    assert stats.ran_at.tzinfo is not None
