"""Tests for the SQLAlchemy engine + session wiring."""

from __future__ import annotations

from collections.abc import Iterator
from pathlib import Path

import pytest
from sqlalchemy import text

from agentdrop.config import get_settings
from agentdrop.db import get_engine


@pytest.fixture
def file_db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Path]:
    """Point the app at a fresh file-backed SQLite DB for the duration of the test."""
    db_path = tmp_path / "test.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    # Caches on get_settings + get_engine hold references to the old config /
    # engine; clear them so the next call rebuilds with the patched env.
    get_settings.cache_clear()
    get_engine.cache_clear()
    try:
        yield db_path
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


@pytest.fixture
def memory_db(monkeypatch: pytest.MonkeyPatch) -> Iterator[None]:
    """Point the app at an in-memory SQLite DB."""
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", "sqlite:///:memory:")
    get_settings.cache_clear()
    get_engine.cache_clear()
    try:
        yield
    finally:
        get_engine.cache_clear()
        get_settings.cache_clear()


def test_engine_connects_to_in_memory_sqlite(memory_db: None) -> None:
    engine = get_engine()
    with engine.connect() as conn:
        result = conn.execute(text("SELECT 1")).scalar_one()
    assert result == 1


def test_journal_mode_is_wal_on_file_backed_sqlite(file_db: Path) -> None:
    engine = get_engine()
    with engine.connect() as conn:
        mode = conn.execute(text("PRAGMA journal_mode")).scalar_one()
    # File-backed SQLite should report WAL. In-memory SQLite would report
    # "memory" — we accept that too so the pragma test stays robust if the
    # underlying DB is ever swapped.
    assert str(mode).lower() in {"wal", "memory"}


def test_foreign_keys_pragma_is_on(file_db: Path) -> None:
    engine = get_engine()
    with engine.connect() as conn:
        fk = conn.execute(text("PRAGMA foreign_keys")).scalar_one()
    assert int(fk) == 1
