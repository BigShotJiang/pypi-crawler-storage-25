"""Tests for at-rest encryption of ``Channel.config_json`` (issue #17).

Round-trip via the ORM and a raw-SQL inspection that proves the on-disk
value is a Fernet token, not the plaintext token an agent sent us.
"""

from __future__ import annotations

import base64
import secrets
from collections.abc import Iterator

import pytest
from sqlalchemy import create_engine, text
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.models import Channel


def _gen_key() -> str:
    return base64.urlsafe_b64encode(secrets.token_bytes(32)).decode()


@pytest.fixture
def encryption_key(monkeypatch: pytest.MonkeyPatch) -> str:
    """Fresh key per test so cross-test ciphertext can't accidentally read."""
    key = _gen_key()
    monkeypatch.setenv("AGENTDROP_ENCRYPTION_KEY", key)
    monkeypatch.delenv("AGENTDROP_ENCRYPTION_KEY_PREV", raising=False)
    get_settings.cache_clear()
    yield key
    get_settings.cache_clear()


@pytest.fixture
def session(encryption_key: str) -> Iterator[Session]:
    engine = create_engine("sqlite://", future=True)
    Base.metadata.create_all(engine)
    with Session(engine) as s:
        yield s
    engine.dispose()


def test_config_json_round_trips_via_orm(session: Session) -> None:
    """Insert -> commit -> expire -> re-fetch reads the same dict back."""
    channel = Channel(
        name="primary",
        driver="pushover",
        config_json={"token": "secret123", "user": "u-abc"},
    )
    session.add(channel)
    session.commit()
    channel_id = channel.id

    session.expire_all()
    fetched = session.get(Channel, channel_id)
    assert fetched is not None
    assert fetched.config_json == {"token": "secret123", "user": "u-abc"}


def test_config_json_is_ciphertext_on_disk(session: Session) -> None:
    """Bypass the ORM and read the raw column — must not be plaintext."""
    channel = Channel(
        name="primary",
        driver="pushover",
        config_json={"token": "secret123", "user": "u-abc"},
    )
    session.add(channel)
    session.commit()

    raw = session.execute(
        text("SELECT config_json FROM channels WHERE id = :id"),
        {"id": channel.id},
    ).scalar_one()

    assert isinstance(raw, str)
    # Fernet tokens (url-safe base64 of a payload starting with version
    # byte 0x80) always begin with ``gAAAAA``.
    assert raw.startswith("gAAAAA"), raw[:20]
    # Hard guarantee: the secret token isn't sitting in the column.
    assert "secret123" not in raw
    assert "u-abc" not in raw


def test_empty_config_round_trips(session: Session) -> None:
    """Default empty dict must encrypt and decrypt cleanly."""
    channel = Channel(name="empty", driver="pushover")
    session.add(channel)
    session.commit()
    channel_id = channel.id

    session.expire_all()
    fetched = session.get(Channel, channel_id)
    assert fetched is not None
    assert fetched.config_json == {}

    raw = session.execute(
        text("SELECT config_json FROM channels WHERE id = :id"),
        {"id": channel_id},
    ).scalar_one()
    assert raw.startswith("gAAAAA")
