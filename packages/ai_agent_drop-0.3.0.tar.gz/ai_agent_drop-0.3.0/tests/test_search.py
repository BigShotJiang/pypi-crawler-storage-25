"""Tests for :mod:`agentdrop.search` and the ``drops_fts`` triggers.

Covers:

* Functional coverage of :func:`search_drops` — title, body, content_md,
  source, tags all searchable; stemming; AND semantics; empty-query
  short-circuit; FTS5 meta-character sanitization; soft-deleted
  exclusion.
* Trigger maintenance — insert / update / delete of a Drop keeps the FTS
  index in sync.
* Backfill — drops existing before the migration ran end up in the FTS
  index afterwards.
"""

from __future__ import annotations

from collections.abc import Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
from sqlalchemy import text
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.base import Base
from agentdrop.db.fts import install_fts_schema
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.models import Drop
from agentdrop.search import (
    _sanitize_fts_query,
    search_drops,
    search_drops_like,
    search_drops_sqlite,
)


@pytest.fixture
def db(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[Session]:
    """Fresh SQLite DB with ``drops`` + ``drops_fts`` + triggers installed."""
    db_path = tmp_path / "drops.db"
    monkeypatch.setenv("AGENTDROP_DATABASE_URL", f"sqlite:///{db_path}")
    monkeypatch.setenv("AGENTDROP_BASE_URL", "https://drop.test")
    monkeypatch.setenv("AGENTDROP_SECRET_KEY", "test-secret-key")
    get_settings.cache_clear()
    get_engine.cache_clear()

    Base.metadata.create_all(get_engine())
    install_fts_schema(get_engine())

    session = SessionLocal(bind=get_engine())
    try:
        yield session
    finally:
        session.close()
        get_engine.cache_clear()
        get_settings.cache_clear()


def _mkdrop(**overrides: object) -> Drop:
    """Build a Drop with sensible defaults; callers override fields they care about."""
    now = datetime.now(UTC)
    defaults: dict[str, object] = {
        "title": "Default title",
        "body": "Default body.",
        "content_md": "# default",
        "source": "test-source",
        "tags_json": [],
        "priority": "normal",
        "created_at": now,
    }
    defaults.update(overrides)
    # Each drop needs a unique short_id; pin it off the title to stay stable.
    if "short_id" not in defaults:
        title = str(defaults["title"])
        base = title.replace(" ", "-").lower()[:20]
        defaults["short_id"] = (base + "0000000000000000000000")[:24]
    return Drop(**defaults)


def _seed_varied(session: Session) -> dict[str, Drop]:
    """Seed a mix of drops with distinct tokens in each field."""
    base = datetime.now(UTC)
    drops = {
        "title_only": _mkdrop(
            short_id="title0000000000000001aa",
            title="Pelican migration report",
            body="Generic summary.",
            content_md="# notes",
            source="weekly-scan",
            tags_json=["birds"],
            created_at=base - timedelta(minutes=10),
        ),
        "body_only": _mkdrop(
            short_id="body00000000000000001aaa",
            title="Alpha report",
            body="The seafaring narwhal surfaced at noon.",
            content_md="# nothing notable",
            source="weekly-scan",
            tags_json=[],
            created_at=base - timedelta(minutes=20),
        ),
        "content_only": _mkdrop(
            short_id="content00000000000001aaa",
            title="Beta report",
            body="Summary B.",
            content_md="## Deep dive\n\nThe quokka colony on Rottnest stabilised.",
            source="nature-digest",
            tags_json=[],
            created_at=base - timedelta(minutes=30),
        ),
        "tagged": _mkdrop(
            short_id="tagged000000000000001aaa",
            title="Gamma report",
            body="Summary G.",
            content_md="# boring",
            source="ops-alerts",
            tags_json=["kubernetes", "sev1"],
            created_at=base - timedelta(minutes=40),
        ),
        "deploy": _mkdrop(
            short_id="deploy000000000000001aaa",
            title="Deployment status",
            body="Deployed to prod.",
            content_md="# deployment notes",
            source="ci",
            tags_json=[],
            created_at=base - timedelta(minutes=50),
        ),
        "multi_word": _mkdrop(
            short_id="multi0000000000000001aaa",
            title="Ops dashboard reboot",
            body="The ops team saw markets wobble overnight.",
            content_md="# mixed",
            source="ops-alerts",
            tags_json=[],
            created_at=base - timedelta(minutes=60),
        ),
    }
    for drop in drops.values():
        session.add(drop)
    session.commit()
    return drops


# --- sanitization ---------------------------------------------------------


def test_sanitize_strips_fts_meta_chars() -> None:
    assert _sanitize_fts_query('foo"bar:baz*') == "foo bar baz"
    assert _sanitize_fts_query("(title:foo)^3") == "title foo 3"
    assert _sanitize_fts_query("   hello    world   ") == "hello world"


def test_sanitize_empty_returns_empty_string() -> None:
    assert _sanitize_fts_query("") == ""
    assert _sanitize_fts_query("   ") == ""
    # Pure punctuation collapses to nothing searchable.
    assert _sanitize_fts_query('"*():^') == ""


# --- functional: search_drops --------------------------------------------


def test_empty_query_returns_empty_list(db: Session) -> None:
    _seed_varied(db)
    assert search_drops(db, q="") == []
    assert search_drops(db, q="   ") == []
    # All-sanitized-out query also returns empty.
    assert search_drops(db, q='":*') == []


def test_search_by_title_word(db: Session) -> None:
    seeded = _seed_varied(db)
    results = search_drops(db, q="pelican")
    assert [d.id for d in results] == [seeded["title_only"].id]


def test_search_by_body_word(db: Session) -> None:
    """New capability vs the old LIKE-on-title+source path."""
    seeded = _seed_varied(db)
    results = search_drops(db, q="narwhal")
    assert [d.id for d in results] == [seeded["body_only"].id]


def test_search_by_content_md_word(db: Session) -> None:
    seeded = _seed_varied(db)
    results = search_drops(db, q="quokka")
    assert [d.id for d in results] == [seeded["content_only"].id]


def test_search_by_tag(db: Session) -> None:
    seeded = _seed_varied(db)
    results = search_drops(db, q="kubernetes")
    assert [d.id for d in results] == [seeded["tagged"].id]


def test_search_with_fts_special_chars_sanitized(db: Session) -> None:
    """FTS5 meta-chars would raise ``OperationalError`` if passed raw.

    Sanitization strips them and splits into implicit-AND tokens so the
    query is interpreted as the user typed words — the call must not
    raise, regardless of how the tokens recombine.
    """
    seeded = _seed_varied(db)

    # Garbage input containing every FTS meta-char we strip. Must not raise.
    results = search_drops(db, q='pelican"foo:bar*()^')
    # After sanitization the tokens are "pelican foo bar". Only "pelican"
    # matches any drop; AND semantics mean the overall query matches no
    # drop. The important assertion is that the call returns a list
    # (i.e. didn't raise), and doesn't accidentally pull in unrelated
    # drops.
    assert isinstance(results, list)
    assert seeded["title_only"].id not in [d.id for d in results]

    # And a "works as if user typed the words" case: stripping "..." from
    # around "narwhal" should still match the body_only drop.
    results = search_drops(db, q='"narwhal"')
    assert [d.id for d in results] == [seeded["body_only"].id]


def test_multi_word_query_is_and_not_or(db: Session) -> None:
    """FTS5 default behaviour is implicit AND between tokens."""
    seeded = _seed_varied(db)
    # Both "ops" and "markets" appear together only in the multi_word drop.
    results = search_drops(db, q="ops markets")
    assert [d.id for d in results] == [seeded["multi_word"].id]


def test_soft_deleted_drop_excluded_via_dispatch(db: Session) -> None:
    """F3 regression: :func:`search_drops` filters soft-deleted rows.

    Scopes the assertion explicitly to the dispatch entrypoint; the
    per-branch tests below cover the two implementations directly so the
    filter can't regress on either path without a test failure.
    """
    seeded = _seed_varied(db)
    target = seeded["title_only"]
    target.soft_deleted_at = datetime.now(UTC)
    db.commit()

    results = search_drops(db, q="pelican")
    assert target.id not in [d.id for d in results]
    # Sanity: a non-soft-deleted match still works post-filter.
    assert seeded["body_only"].id in [d.id for d in search_drops(db, q="narwhal")]


def test_soft_deleted_drop_excluded_from_fts5_path(db: Session) -> None:
    """F3: SQLite FTS5 path filters ``soft_deleted_at IS NULL``.

    Calls :func:`search_drops_sqlite` directly so we're testing the
    branch chosen for SQLite-backed deployments specifically — not just
    whatever ``search_drops`` happens to dispatch to.
    """
    seeded = _seed_varied(db)
    target = seeded["title_only"]

    # Pre-condition: visible on the FTS5 path.
    pre = search_drops_sqlite(db, q="pelican")
    assert target.id in [d.id for d in pre]

    target.soft_deleted_at = datetime.now(UTC)
    db.commit()

    post = search_drops_sqlite(db, q="pelican")
    assert target.id not in [d.id for d in post]


def test_soft_deleted_drop_excluded_from_like_fallback(db: Session) -> None:
    """F3: LIKE fallback (Postgres path) also filters soft-deleted rows.

    SQLite is happy to run the LIKE-based query too — the branch is
    selected by dialect, not by table layout — so we can exercise the
    Postgres-bound code path on the same fixture without spinning up
    a real Postgres instance.
    """
    seeded = _seed_varied(db)
    # Use ``body_only`` because the LIKE fallback covers title + body +
    # source + tags (deliberately not content_md), and "narwhal" lives
    # in the body of that drop.
    target = seeded["body_only"]

    pre = search_drops_like(db, q="narwhal")
    assert target.id in [d.id for d in pre]

    target.soft_deleted_at = datetime.now(UTC)
    db.commit()

    post = search_drops_like(db, q="narwhal")
    assert target.id not in [d.id for d in post]


def test_delete_route_clears_content_and_drops_from_fts(db: Session) -> None:
    """F2: ``DELETE /api/v1/drops/{id}`` clears content + FTS row in one txn.

    The handler mirrors the retention sweep's soft-delete phase: sets
    ``soft_deleted_at`` and zeroes ``content_md`` / ``body``. Because
    those columns are part of the FTS5 virtual table, the AFTER UPDATE
    trigger re-indexes the row with empty content, and the explicit
    ``soft_deleted_at IS NULL`` filter in :func:`search_drops_sqlite`
    excludes it from results.

    Calls the route handler directly instead of standing up a
    ``TestClient`` so we can stay on the FTS-enabled fixture above.
    """
    from agentdrop.routes.drops import delete_drop

    seeded = _seed_varied(db)
    target = seeded["body_only"]  # body contains "narwhal"
    drop_id = target.id

    # Pre-condition: searchable.
    assert drop_id in [d.id for d in search_drops(db, q="narwhal")]

    response = delete_drop(drop_id, db)
    assert response["id"] == drop_id
    assert response["soft_deleted_at"] is not None

    db.expire_all()
    refreshed = db.get(Drop, drop_id)
    assert refreshed is not None
    assert refreshed.soft_deleted_at is not None
    assert refreshed.body == ""
    assert refreshed.content_md == ""
    assert refreshed.title == "Alpha report"  # preserved as audit metadata

    # FTS5 search no longer surfaces the drop.
    assert drop_id not in [d.id for d in search_drops(db, q="narwhal")]


def test_pinned_drop_included_in_search(db: Session) -> None:
    """Pin state should not affect search inclusion on state='all'."""
    seeded = _seed_varied(db)
    target = seeded["content_only"]
    target.pinned_at = datetime.now(UTC)
    db.commit()

    results = search_drops(db, q="quokka")
    assert target.id in [d.id for d in results]


def test_stemming_deploy_matches_deployed(db: Session) -> None:
    """Porter tokenizer: ``deploy`` matches ``deployed`` and ``deployment``."""
    seeded = _seed_varied(db)
    results = search_drops(db, q="deploy")
    assert seeded["deploy"].id in [d.id for d in results]


def test_search_filters_by_source(db: Session) -> None:
    """State / source filters compose with FTS match."""
    _seed_varied(db)
    # Two drops use ops-alerts; only "tagged" has kubernetes in tags.
    results = search_drops(db, q="gamma", source="ops-alerts")
    assert len(results) == 1
    assert results[0].source == "ops-alerts"


def test_search_filters_by_state_archived(db: Session) -> None:
    seeded = _seed_varied(db)
    target = seeded["title_only"]
    target.archived_at = datetime.now(UTC)
    db.commit()

    # Default state ('all') hides archived.
    assert target.id not in [d.id for d in search_drops(db, q="pelican")]
    # state='archived' surfaces it.
    assert target.id in [d.id for d in search_drops(db, q="pelican", state="archived")]


# --- triggers -------------------------------------------------------------


def _fts_row_count(db: Session, drop_id: str) -> int:
    row = db.execute(
        text("SELECT COUNT(*) FROM drops_fts WHERE drop_id = :drop_id"),
        {"drop_id": drop_id},
    ).scalar_one()
    return int(row)


def _fts_title(db: Session, drop_id: str) -> str | None:
    row = db.execute(
        text("SELECT title FROM drops_fts WHERE drop_id = :drop_id"),
        {"drop_id": drop_id},
    ).scalar()
    return row


def test_insert_trigger_populates_fts(db: Session) -> None:
    drop = _mkdrop(title="Freshly inserted", body="x", content_md="y")
    db.add(drop)
    db.commit()

    assert _fts_row_count(db, drop.id) == 1
    assert _fts_title(db, drop.id) == "Freshly inserted"


def test_update_trigger_replaces_fts_row(db: Session) -> None:
    drop = _mkdrop(title="Before", body="b", content_md="c")
    db.add(drop)
    db.commit()

    drop.title = "After"
    db.commit()

    # One row per drop, and its title reflects the UPDATE.
    assert _fts_row_count(db, drop.id) == 1
    assert _fts_title(db, drop.id) == "After"


def test_delete_trigger_removes_fts_row(db: Session) -> None:
    drop = _mkdrop(title="To be deleted", body="b", content_md="c")
    db.add(drop)
    db.commit()
    drop_id = drop.id
    assert _fts_row_count(db, drop_id) == 1

    db.delete(drop)
    db.commit()
    assert _fts_row_count(db, drop_id) == 0


def test_backfill_migration_indexes_existing_rows(tmp_path: Path) -> None:
    """Seed drops before the FTS migration and verify they land in FTS."""
    import subprocess
    import sys

    db_path = tmp_path / "backfill.db"
    env_url = f"sqlite:///{db_path}"

    # Run alembic up to the previous (pre-FTS) revision.
    subprocess.run(
        [
            sys.executable,
            "-m",
            "alembic",
            "upgrade",
            "63706b51734b",
        ],
        env={
            **_inherit_env(),
            "AGENTDROP_DATABASE_URL": env_url,
            "AGENTDROP_BASE_URL": "https://drop.test",
            "AGENTDROP_SECRET_KEY": "test-secret-key",
        },
        check=True,
        capture_output=True,
    )

    # Seed a live drop + a soft-deleted drop via raw SQL so we don't
    # accidentally exercise triggers that don't exist yet.
    import sqlite3

    with sqlite3.connect(db_path) as conn:
        conn.executescript(
            """
            INSERT INTO drops (id, short_id, title, body, content_md, source,
                               tags_json, priority, created_at)
            VALUES ('drp_live1', 'short000000000000live001',
                    'Live drop one', 'body one',
                    'content one with wombat',
                    'src', '[]', 'normal', CURRENT_TIMESTAMP);
            INSERT INTO drops (id, short_id, title, body, content_md, source,
                               tags_json, priority, created_at, soft_deleted_at)
            VALUES ('drp_soft1', 'short000000000000soft001',
                    'Tombstone drop', '', '',
                    'src', '[]', 'normal', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
            """
        )
        conn.commit()

    # Run alembic upgrade head — this installs FTS5 and backfills live rows.
    subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        env={
            **_inherit_env(),
            "AGENTDROP_DATABASE_URL": env_url,
            "AGENTDROP_BASE_URL": "https://drop.test",
            "AGENTDROP_SECRET_KEY": "test-secret-key",
        },
        check=True,
        capture_output=True,
    )

    with sqlite3.connect(db_path) as conn:
        live_count = conn.execute(
            "SELECT COUNT(*) FROM drops_fts WHERE drop_id='drp_live1'"
        ).fetchone()[0]
        soft_count = conn.execute(
            "SELECT COUNT(*) FROM drops_fts WHERE drop_id='drp_soft1'"
        ).fetchone()[0]
        match_wombat = conn.execute(
            "SELECT drop_id FROM drops_fts WHERE drops_fts MATCH 'wombat'"
        ).fetchall()

    assert live_count == 1
    # Soft-deleted rows are skipped by the backfill.
    assert soft_count == 0
    assert match_wombat == [("drp_live1",)]


def _inherit_env() -> dict[str, str]:
    import os

    # Keep PATH / PYTHONPATH so the subprocess can find alembic and agentdrop.
    keys = ("PATH", "PYTHONPATH", "HOME", "USER", "LANG", "LC_ALL", "LC_CTYPE")
    return {k: os.environ[k] for k in keys if k in os.environ}
