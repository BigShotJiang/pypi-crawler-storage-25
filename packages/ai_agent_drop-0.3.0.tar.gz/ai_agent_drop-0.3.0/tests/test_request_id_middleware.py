"""Tests for the request-ID middleware (issue #16 L4)."""

from __future__ import annotations

import re

import structlog
from fastapi import FastAPI
from fastapi.testclient import TestClient

from agentdrop.middleware import REQUEST_ID_HEADER, RequestIDMiddleware

UUID_HEX_RE = re.compile(r"^[0-9a-f]{32}$")


def _build_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(RequestIDMiddleware)

    @app.get("/echo")
    def echo() -> dict[str, object]:
        # Read what the middleware bound to structlog contextvars and
        # return it so the test can verify the bind happened during
        # request processing.
        return {
            "contextvars": structlog.contextvars.get_contextvars(),
        }

    return app


def test_request_id_echoed_when_supplied() -> None:
    client = TestClient(_build_app())
    incoming = "abc123-DEF_456"
    response = client.get("/echo", headers={REQUEST_ID_HEADER: incoming})
    assert response.status_code == 200
    assert response.headers[REQUEST_ID_HEADER] == incoming
    assert response.json()["contextvars"] == {"request_id": incoming}


def test_request_id_generated_when_absent() -> None:
    client = TestClient(_build_app())
    response = client.get("/echo")
    assert response.status_code == 200
    rid = response.headers[REQUEST_ID_HEADER]
    assert UUID_HEX_RE.match(rid), rid
    assert response.json()["contextvars"] == {"request_id": rid}


def test_request_id_rejects_malformed_input() -> None:
    client = TestClient(_build_app())
    # Spaces / control chars / oversized values get replaced by a fresh uuid.
    response = client.get("/echo", headers={REQUEST_ID_HEADER: "has spaces and ;injection"})
    rid = response.headers[REQUEST_ID_HEADER]
    assert UUID_HEX_RE.match(rid), rid


def test_contextvars_cleared_after_request() -> None:
    client = TestClient(_build_app())
    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(outer="kept")
    client.get("/echo", headers={REQUEST_ID_HEADER: "rid-1"})
    # After the request, the test's own contextvars should be restored
    # (the middleware clears, but TestClient runs the request in a
    # separate task — the cleanup matters most for in-process worker
    # threads, which would otherwise leak request_id between requests).
    # Issue a second request without an explicit ID and confirm the
    # response ID is fresh, not the previous request's value.
    second = client.get("/echo")
    assert second.headers[REQUEST_ID_HEADER] != "rid-1"
