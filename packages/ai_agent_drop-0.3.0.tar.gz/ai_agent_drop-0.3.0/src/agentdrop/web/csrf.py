"""CSRF protection for session-authed (browser/HTMX) routes.

Bearer-token API auth (``/api/v1/*``) is exempt — bearer tokens are not
sent automatically by browsers cross-origin, so CSRF is moot there.

Posture: a per-session random token, stored in ``request.session`` and
echoed on every state-changing request via either a hidden form field
``_csrf`` or the ``X-CSRF-Token`` header (HTMX). Comparison is constant
time. Logging out clears the session, which rotates the token implicitly.

Why a raw session-bound secret rather than ``itsdangerous`` signing: the
token is already protected by the SessionMiddleware's signed cookie. A
second signing layer would add complexity without changing the threat
model — an attacker who can read the session can already act as the
user.
"""

from __future__ import annotations

import secrets

from fastapi import HTTPException, Request, status

_SESSION_KEY = "csrf_token"
_FORM_FIELD = "_csrf"
_HEADER = "X-CSRF-Token"
_SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS", "TRACE"})


def generate_csrf_token(request: Request) -> str:
    """Return the session-bound CSRF token, minting one if absent.

    Idempotent: subsequent calls within the same session return the same
    token. Mutating ``request.session`` triggers Set-Cookie even on
    otherwise-anonymous requests, which is what makes ``GET /login`` able
    to seed a token before the user authenticates.
    """
    token = request.session.get(_SESSION_KEY)
    if not isinstance(token, str) or not token:
        token = secrets.token_urlsafe(32)
        request.session[_SESSION_KEY] = token
    return token


async def require_csrf(request: Request) -> None:
    """FastAPI dependency: enforce a valid CSRF token on the request.

    Reads the token from a form field (``_csrf``) when the body is
    ``application/x-www-form-urlencoded`` or ``multipart/form-data``,
    otherwise from the ``X-CSRF-Token`` header. Compares to the
    session-bound token in constant time.

    Skips safe methods (GET / HEAD / OPTIONS / TRACE) so router-level
    wiring on mixed-method routers (e.g. ``/settings/channels`` lists
    via GET, mutates via POST) only enforces on state-changing requests.
    """
    if request.method in _SAFE_METHODS:
        return

    expected = request.session.get(_SESSION_KEY)
    if not isinstance(expected, str) or not expected:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing or invalid CSRF token",
        )

    submitted = request.headers.get(_HEADER)
    if not submitted:
        content_type = request.headers.get("content-type", "")
        if content_type.startswith(("application/x-www-form-urlencoded", "multipart/form-data")):
            try:
                form = await request.form()
            except Exception:
                form = None
            if form is not None:
                value = form.get(_FORM_FIELD)
                if isinstance(value, str):
                    submitted = value

    if not submitted or not secrets.compare_digest(submitted, expected):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing or invalid CSRF token",
        )
