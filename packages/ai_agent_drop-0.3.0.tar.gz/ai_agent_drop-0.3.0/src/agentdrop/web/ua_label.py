"""Human-friendly labels for stored ``user_agent`` strings.

The Web Push subscribe endpoint captures the raw UA header for each
device; the Settings > Devices page shows one row per subscription and
a full UA string is too ugly to stare at. This module turns something
like::

    Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 ...

into ``"iPhone · Safari"``.

Deliberate non-goals:

* Not a general UA parser. If someone shows up on NetFront we render
  the raw ``user_agent`` — better to look weird than wrong.
* No version numbers. "Chrome 120" ages instantly and self-hosters
  don't need to audit browser versions of their own devices.
* No dependency. ``ua-parser`` is a 2MB YAML + regex machine; we only
  need the top six or seven combinations.

Ordering matters inside :func:`label_for`:

* Edge's UA contains ``"Chrome"`` and ``"Safari"``; match Edge first.
* Chrome's UA contains ``"Safari"``; match Chrome before Safari.
* Firefox's UA does not contain ``"Safari"`` so order is free there.
"""

from __future__ import annotations

_SEPARATOR = " \u00b7 "  # U+00B7 middle-dot, matches existing settings typography.


def label_for(user_agent: str | None) -> str:
    """Return a ``"OS · Browser"`` label, or a sensible fallback.

    Never raises — the caller feeds this directly into a template so a
    surprise regex case should degrade to the raw UA, not crash the
    devices page.
    """
    if not user_agent:
        return "Unknown device"

    ua = user_agent
    os_label = _os_label(ua)
    browser_label = _browser_label(ua)

    if os_label and browser_label:
        return f"{os_label}{_SEPARATOR}{browser_label}"
    if os_label:
        return os_label
    if browser_label:
        return browser_label

    # Nothing matched. Trim aggressively — a raw UA is ~200 chars and
    # would blow out the table layout. 60 chars is enough to recognise.
    trimmed = ua.strip()
    if len(trimmed) > 60:
        return trimmed[:57] + "..."
    return trimmed or "Unknown device"


def _os_label(ua: str) -> str | None:
    # Order here matters less than in _browser_label — OS tokens don't
    # overlap the way "Chrome"/"Safari" do — but keep the most specific
    # checks first (iPhone / iPad before "Mac OS X").
    if "iPhone" in ua:
        return "iPhone"
    if "iPad" in ua:
        return "iPad"
    if "Android" in ua:
        return "Android"
    if "Windows" in ua:
        return "Windows"
    if "Macintosh" in ua or "Mac OS X" in ua:
        return "macOS"
    if "CrOS" in ua:
        return "ChromeOS"
    if "Linux" in ua or "X11" in ua:
        return "Linux"
    return None


def _browser_label(ua: str) -> str | None:
    # Edge first — its UA contains both "Chrome" and "Safari".
    if "Edg/" in ua or "EdgiOS" in ua or "EdgA/" in ua:
        return "Edge"
    # Opera (OPR) and Brave (uses "Chrome" but exposes a brand-hints
    # header, not UA) aren't distinguishable here — fall through to
    # Chrome which is the right label for Brave anyway.
    if "OPR/" in ua or "Opera" in ua:
        return "Opera"
    if "Firefox" in ua or "FxiOS" in ua:
        return "Firefox"
    # Chrome before Safari: Chrome UAs always include "Safari" as a
    # legacy compatibility token.
    if "Chrome/" in ua or "CriOS" in ua:
        return "Chrome"
    if "Safari" in ua:
        return "Safari"
    return None
