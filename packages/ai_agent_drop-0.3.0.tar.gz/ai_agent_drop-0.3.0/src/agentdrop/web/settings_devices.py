"""Settings UI for Web Push devices (PRD §8.3; ROADMAP v1.5).

One row per stored :class:`~agentdrop.models.push_subscription.PushSubscription`.
The page has two responsibilities:

* Reflect the browser's current subscription state. The hard bits of
  that live client-side in ``/static/push.js`` — this page only supplies
  the DOM hooks and the status banner.
* Administer existing subscriptions: delete a specific row (e.g. a lost
  phone), or fire a test push through the ``web_push`` driver against
  every device at once.

Routes are session-authed via the router-level ``require_session`` dep
so an unauth'd GET falls through to ``/login?next=/settings/devices``.

Test-push posture: we delegate to the ``web_push`` driver with an empty
config (the driver reads VAPID creds from env settings, not per-channel
config — see ``notifications/web_push.py``). Successes and failures are
surfaced through the same ``?notice=…&detail=…`` pattern
``settings_channels.py`` uses, so the flash-banner code stays uniform
across sections.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated
from urllib.parse import quote

import structlog
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.notifications import DriverConfigError, get_driver
from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session
from agentdrop.web.ua_label import label_for

logger = structlog.get_logger("agentdrop.web.settings_devices")

router = APIRouter(
    prefix="/settings/devices",
    tags=["web-settings"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]


def _list_subscriptions(db: Session) -> list[PushSubscription]:
    stmt = select(PushSubscription).order_by(PushSubscription.created_at.desc())
    return list(db.execute(stmt).scalars().all())


@router.get("", response_class=HTMLResponse)
def list_devices(
    request: Request,
    db: DbSession,
    notice: str | None = None,
    detail: str | None = None,
) -> HTMLResponse:
    settings = get_settings()
    subs = _list_subscriptions(db)
    decorated = [
        {
            "id": s.id,
            "label": label_for(s.user_agent),
            "user_agent": s.user_agent,
            "created_at": s.created_at,
            "last_used_at": s.last_used_at,
        }
        for s in subs
    ]
    return templates.TemplateResponse(
        request,
        "settings/devices_list.html",
        {
            "active_section": "devices",
            "section_title": "Devices",
            "subscriptions": decorated,
            "vapid_configured": bool(settings.vapid_public_key),
            "notice": notice,
            "detail": detail,
        },
    )


@router.post("/{subscription_id}/delete")
def delete_subscription(
    subscription_id: str,
    db: DbSession,
) -> RedirectResponse:
    """Remove a specific subscription row.

    Unknown ids return 404 rather than a silent redirect so an operator
    clicking a stale link gets a clear signal. The browser that still
    has a live ``PushSubscription`` will discover the server-side
    removal next time we receive a 410 from its push service (see
    ``web_push.py``) — nothing else we need to do here.
    """
    row = db.execute(
        select(PushSubscription).where(PushSubscription.id == subscription_id)
    ).scalar_one_or_none()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Subscription not found",
        )
    db.delete(row)
    db.commit()
    return RedirectResponse(
        url="/settings/devices?notice=deleted",
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/test")
def test_push(db: DbSession) -> RedirectResponse:
    """Fan a test push out to every stored subscription.

    Empty-inbox is explicitly allowed: the driver returns ``ok=True`` with
    ``"no subscriptions"`` detail and we surface that honestly so the
    user can tell the difference between "it worked and nobody's
    listening" and "it failed".
    """
    settings = get_settings()
    if not settings.vapid_public_key:
        return _redirect_with_failure(
            "Web Push is not configured on this server. Set AGENTDROP_VAPID_* env vars and restart."
        )

    try:
        driver = get_driver("web_push", {})
    except DriverConfigError as exc:
        return _redirect_with_failure(str(exc))

    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")
    try:
        result = driver.send(
            title="Agent Drop: test push",
            body=f"Sent from Devices at {timestamp}",
            url=settings.base_url,
            priority="normal",
            extras={"source": "settings-devices-test"},
        )
    except Exception as exc:
        return _redirect_with_failure(str(exc) or exc.__class__.__name__)

    if not result.ok:
        return _redirect_with_failure(result.detail or "driver reported failure")

    detail = result.detail or ""
    if "no subscriptions" in detail:
        return RedirectResponse(
            url="/settings/devices?notice=sent-empty",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    return RedirectResponse(
        url=f"/settings/devices?notice=sent-ok&detail={quote(detail[:200], safe='')}",
        status_code=status.HTTP_303_SEE_OTHER,
    )


def _redirect_with_failure(detail: str) -> RedirectResponse:
    capped = detail[:200]
    return RedirectResponse(
        url=f"/settings/devices?notice=failed&detail={quote(capped, safe='')}",
        status_code=status.HTTP_303_SEE_OTHER,
    )
