"""Public, unauthenticated web routes for rendering drops.

The one route today is ``GET /d/{short_id}`` — the tap-from-notification
surface described in PRD §6.2 and §8.5. Public drop URLs are deliberately
unauthed by default (§8.5); auth is an opt-in per-drop flag that we don't
implement yet. This router therefore does **not** carry an auth dependency.

Do not add this to ``agentdrop.routes.drops`` — that router locks every
handler behind ``require_api_key``.
"""

from __future__ import annotations

from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import HTMLResponse
from sqlalchemy import and_, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.models import Drop, Event
from agentdrop.web import templates
from agentdrop.web.markdown import render_markdown
from agentdrop.web.rate_limit import rate_limit
from agentdrop.web.time_format import format_expires_in

web_router = APIRouter(tags=["web"])

DbSession = Annotated[Session, Depends(get_db)]


# Per-IP rate limit on the public drop page. URLs are unguessable but a
# known one is trivially DoS-able by hammering it; this caps the cost.
# ``record_on_check=True`` so 404s and 429s also consume budget — else
# an attacker could probe for valid short_ids without paying.
_DROP_READ_RATE_LIMIT = rate_limit(
    "drop_get",
    max_attempts=get_settings().drop_read_rate_limit_per_min,
    window_seconds=60,
    record_on_check=True,
)


def _format_drop_date(dt: datetime) -> str:
    """Format a drop's created-at timestamp for the meta row.

    Target format: ``Sat, Apr 19, 1:45 PM`` (per the handoff). We deliberately
    avoid the platform-specific ``%-d`` / ``%-I`` conversions (they're a
    glibc/BSD extension, broken on Windows) and hand-format the day and hour
    so the output is identical everywhere Python runs.
    """
    weekday = dt.strftime("%a")
    month = dt.strftime("%b")
    day = dt.day  # no leading zero
    hour12 = dt.hour % 12 or 12
    minute = dt.strftime("%M")
    ampm = "AM" if dt.hour < 12 else "PM"
    return f"{weekday}, {month} {day}, {hour12}:{minute} {ampm}"


def _compute_expires_in_text(drop: Drop, now: datetime, retention_days: int) -> str:
    """Build the footer's right-hand "expires in …" string.

    Three cases, in order:

    * Pinned drops are exempt from retention (PRD §8.4), so we render
      ``"pinned · no expiry"`` instead of a countdown.
    * If the drop has an explicit ``expires_at`` we use it verbatim.
    * Otherwise we synthesise an effective expiry from
      ``created_at + retention_days`` so the UI still shows a countdown
      before the retention sweep has stamped ``expires_at`` on the row.

    Past expiries collapse to ``"expired"`` via :func:`format_expires_in`.
    """
    if drop.pinned_at is not None:
        return "pinned · no expiry"

    if drop.expires_at is not None:
        effective_expiry = drop.expires_at
    else:
        effective_expiry = drop.created_at + timedelta(days=retention_days)

    # SQLite round-trips DateTime as tz-naive strings even when we wrote
    # tz-aware values (SQLAlchemy doesn't persist the zone for the
    # default SQLite dialect). Coerce both sides to UTC-aware so the
    # subtraction in ``format_expires_in`` doesn't TypeError.
    if effective_expiry.tzinfo is None:
        effective_expiry = effective_expiry.replace(tzinfo=UTC)

    interval = format_expires_in(now, effective_expiry)
    if interval == "expired":
        return "expired"
    return f"expires in {interval}"


@web_router.get(
    "/d/{short_id}",
    response_class=HTMLResponse,
    dependencies=[Depends(_DROP_READ_RATE_LIMIT)],
)
def read_drop(
    short_id: str,
    request: Request,
    db: DbSession,
) -> HTMLResponse:
    """Render the Reading-variant drop page at the public short URL.

    Behaviour:
        * 404 if the short_id doesn't match, or if the drop is soft-deleted.
        * Archived drops still render — the URL was shared, the content is
          presumed still wanted by anyone holding the link.
        * On first view, ``read_at`` is set to now. Commit failures are
          swallowed so a DB hiccup doesn't 500 the page — read-marking is
          best-effort per PRD §6.3 semantics.
    """
    drop = db.execute(
        select(Drop).where(and_(Drop.short_id == short_id, Drop.soft_deleted_at.is_(None)))
    ).scalar_one_or_none()

    if drop is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Drop not found")

    # Auto-mark read on first view. Best-effort — don't fail the request if
    # the commit trips over a transient DB error. Reading variant has no
    # explicit "Mark read" button because the view *is* the mark-read signal
    # (per the design handoff).
    if drop.read_at is None:
        try:
            drop.read_at = datetime.now(UTC)
            db.commit()
            db.refresh(drop)
        except SQLAlchemyError:
            db.rollback()

    now = datetime.now(UTC)
    settings = get_settings()
    # ``retention_days`` is added to Settings by the retention service
    # (Agent A). Fall back to the PRD §8.4 default so this route doesn't
    # explode if it renders before that field lands.
    retention_days = getattr(settings, "retention_days", 30)
    formatted_date = _format_drop_date(drop.created_at)
    expires_in_text = _compute_expires_in_text(drop, now, retention_days)
    rendered = render_markdown(drop.content_md)

    # Recent notification_failed events for this drop. Surfaced as a small
    # diagnostics block so the operator who taps the link doesn't have to
    # tail logs to find out why the push didn't fire. Capped to a handful
    # because retention sweeps may queue them up over time. Issue #14 E2.
    notification_failures = list(
        db.execute(
            select(Event)
            .where(
                Event.drop_id == drop.id,
                Event.kind == "notification_failed",
            )
            .order_by(Event.created_at.desc())
            .limit(5)
        )
        .scalars()
        .all()
    )

    return templates.TemplateResponse(
        request,
        "drop_reading.html",
        {
            "drop": drop,
            "formatted_date": formatted_date,
            "expires_in_text": expires_in_text,
            "rendered": rendered,
            "notification_failures": notification_failures,
        },
    )
