"""Web auth routes: ``/login`` (GET + POST) and ``/logout`` (POST).

These run alongside the public ``/d/{short_id}`` router; the session
cookie is set/cleared here and checked elsewhere via
``agentdrop.web.session.require_session``.
"""

from __future__ import annotations

from typing import Annotated
from urllib.parse import quote

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse

from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.rate_limit import (
    client_ip,
    rate_limit,
    record_attempt,
    reset_attempts,
)
from agentdrop.web.session import averify_admin_password, is_admin_configured

router = APIRouter(tags=["web-auth"])

# 5 attempts per 15 minutes per IP. Conservative — single-admin login
# means legitimate retries are rare; brute-force attempts hit the wall
# fast.
_LOGIN_RATE_LIMIT = rate_limit("login", max_attempts=5, window_seconds=15 * 60)


def _safe_next(next_: str | None) -> str:
    """Return ``next_`` if it is a safe same-origin path, else ``/``.

    Blocks open-redirects: we accept only strings that begin with a single
    ``/`` and are not protocol-relative (``//evil.example.com``). Anything
    else (absolute URLs, empty strings, ``None``) falls back to ``/``.
    """
    if not next_:
        return "/"
    if not next_.startswith("/"):
        return "/"
    # Reject protocol-relative URLs like ``//evil.example.com/path`` which
    # browsers resolve against the current scheme.
    if next_.startswith("//"):
        return "/"
    return next_


@router.get("/login", response_class=HTMLResponse, response_model=None)
def login_form(
    request: Request,
    next: str | None = None,
    error: str | None = None,
) -> HTMLResponse | RedirectResponse:
    """Render the login form.

    If the user already has a valid session, redirect straight to ``next``
    (or ``/``) rather than showing the form — there's no useful action on
    this page for a logged-in admin.
    """
    if request.session.get("admin") is True:
        return RedirectResponse(url=_safe_next(next), status_code=status.HTTP_303_SEE_OTHER)

    return templates.TemplateResponse(
        request,
        "login.html",
        {"next": next or "", "error": error},
    )


@router.post(
    "/login",
    dependencies=[Depends(_LOGIN_RATE_LIMIT), Depends(require_csrf)],
)
async def login_submit(
    request: Request,
    password: Annotated[str, Form()],
    next: Annotated[str | None, Form()] = None,
) -> RedirectResponse:
    """Handle login form submission.

    Returns 303 on every path so the browser re-requests via GET — avoids
    the "refresh re-submits the form" dialog. Mirrors the bearer-token
    503 behaviour when the admin password is unset, to keep the "server
    not configured" signal consistent.
    """
    if not is_admin_configured():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Admin password not configured on server",
        )

    ip = client_ip(request)
    if not await averify_admin_password(password):
        record_attempt("login", ip)
        # Preserve ``next`` so a retry lands back on the original target.
        safe_next = _safe_next(next)
        location = f"/login?error=bad_password&next={quote(safe_next, safe='')}"
        return RedirectResponse(url=location, status_code=status.HTTP_303_SEE_OTHER)

    reset_attempts("login", ip)
    request.session["admin"] = True
    return RedirectResponse(url=_safe_next(next), status_code=status.HTTP_303_SEE_OTHER)


@router.post("/logout", dependencies=[Depends(require_csrf)])
def logout(request: Request) -> RedirectResponse:
    """Clear the session and send the user back to ``/login``."""
    request.session.clear()
    return RedirectResponse(url="/login", status_code=status.HTTP_303_SEE_OTHER)
