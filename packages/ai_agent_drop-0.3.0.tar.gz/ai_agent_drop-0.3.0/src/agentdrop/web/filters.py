"""Jinja filters for the web UI.

Currently exposes ``time_ago`` — a relative-time formatter mirroring the
prototype's ``timeAgo`` helper in ``design_handoff_agent_drop/prototype/
tokens.jsx``. The filter is registered on the module-level
``agentdrop.web.templates`` environment at import time so templates can
reference it without further wiring.
"""

from __future__ import annotations

from datetime import UTC, datetime

from agentdrop.web import templates


def time_ago(dt: datetime | None) -> str:
    """Return a short relative-time string for ``dt``.

    Formats (matching the prototype):
        * ``< 1m``  → ``"just now"``
        * ``< 1h``  → ``"Xm ago"``
        * ``< 1d``  → ``"Xh ago"``
        * ``< 7d``  → ``"Xd ago"``
        * ``>= 7d`` → ``"Xw ago"``

    Edge cases:
        * ``dt`` is ``None`` → empty string (templates call this on
          optional timestamps; treating ``None`` as "" keeps callers
          simple).
        * ``dt`` is naive (no tzinfo) → treated as UTC. The DB schema
          uses timezone-aware DateTimes everywhere, so this fallback
          mainly exists for tests that build fixtures with ``datetime.
          utcnow()`` or similar.
        * ``dt`` is in the future → rendered as ``"just now"``. A drop
          created at ``now + 30s`` due to clock skew shouldn't display as
          ``"-1m ago"``.
    """
    if dt is None:
        return ""

    now = datetime.now(UTC)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)

    delta = now - dt
    total_seconds = delta.total_seconds()

    # Future or nearly-now: clamp to "just now".
    if total_seconds < 60:
        return "just now"

    minutes = int(total_seconds // 60)
    if minutes < 60:
        return f"{minutes}m ago"

    hours = minutes // 60
    if hours < 24:
        return f"{hours}h ago"

    days = hours // 24
    if days < 7:
        return f"{days}d ago"

    weeks = days // 7
    return f"{weeks}w ago"


# Register on the global templates environment at import time. Modules that
# need the filter must import this module (or transitively depend on it via
# ``agentdrop.web.inbox``) before rendering.
templates.env.filters["time_ago"] = time_ago
