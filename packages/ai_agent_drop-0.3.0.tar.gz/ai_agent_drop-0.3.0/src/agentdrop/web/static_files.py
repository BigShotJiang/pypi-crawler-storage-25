"""Static file serving with sensible ``Cache-Control`` defaults.

Issue #15 (I6): the bare :class:`fastapi.staticfiles.StaticFiles` mount
emits no ``Cache-Control`` header, so every page reload re-fetches every
CSS / JS / icon over the network. This module subclasses ``StaticFiles``
to set:

* ``public, max-age=3600`` on regular asset names (1 hour) — safe even
  without a build-step content hash because the worst case is a 1-hour
  delay picking up a CSS edit on a returning user.

* ``public, max-age=31536000, immutable`` on names that already carry a
  content hash (``foo.abc123.css`` or ``foo.[hash].css``) — those names
  change when the contents change, so the response can be cached
  forever.

Hashed-name detection is forward-looking: we don't yet emit hashed
filenames in the build, but recognising the convention now means a
future build step can drop fingerprinted assets in
``src/agentdrop/web/static/`` and instantly benefit from immutable
caching without re-touching this module.
"""

from __future__ import annotations

import re
from typing import Any

from starlette.staticfiles import StaticFiles
from starlette.types import Scope

# Content-hash filename pattern. Matches ``foo.abc1234.css``,
# ``foo.[hash].css``, ``main.5f3a9b2e.js``, etc. — at least 7 hex (or
# bracketed-hash placeholder) characters between two dots and an
# extension. Tightened to "at least 7" so we don't accidentally match
# minor.major version segments like ``foo.10.css``.
_HASHED_NAME = re.compile(r"\.(?:[0-9a-f]{7,}|\[hash\])\.[^.]+$")


class CachedStaticFiles(StaticFiles):
    """``StaticFiles`` with ``Cache-Control`` headers on every response.

    Headers are applied in :meth:`get_response` because that's the
    single funnel through which both 200 and 304 responses pass. We
    mutate ``response.headers`` after super() builds the response so
    Starlette's range / etag logic stays untouched.
    """

    async def get_response(self, path: str, scope: Scope) -> Any:
        response = await super().get_response(path, scope)
        # Only attach caching headers on successful responses (200 / 206
        # / 304). Errors should be free to be re-requested.
        status = getattr(response, "status_code", None)
        if status in (200, 206, 304):
            if _HASHED_NAME.search(path):
                response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
            else:
                response.headers["Cache-Control"] = "public, max-age=3600"
        return response
