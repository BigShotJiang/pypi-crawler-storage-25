"""Session-authed HTMX action endpoints for the drop page (PRD §6.2, §8.4).

The public ``GET /d/{short_id}`` route in :mod:`agentdrop.web.routes` is
deliberately unauth'd — that's the tap-from-notification surface. These
sibling ``POST /d/{short_id}/{action}`` routes live behind the session
cookie because they mutate state (pin / archive) and only the logged-in
admin should be driving them. Agent B's Reading-variant template POSTs
here with HTMX.

Why a separate module from ``routes.py``: the public GET must have no
auth dependency at all, while this router carries ``require_session`` on
every handler. Keeping them split makes the auth posture obvious at
import-time rather than per-route.

Why not reuse ``PATCH /api/v1/drops/{id}``: that one is locked behind
the Bearer-token API auth (``require_api_key``) and speaks JSON. A
parallel session-authed form-post surface is simpler than unifying the
two — and the HTMX response shape (single re-rendered button partial)
doesn't fit the JSON contract.

CSRF: every route here carries ``Depends(require_csrf)`` at the router
level (see :mod:`agentdrop.web.csrf`). The plain-form path includes a
hidden ``_csrf`` field; the HTMX path passes the same token via
``hx-headers`` as ``X-CSRF-Token``. ``SameSite=Lax`` on the session
cookie is a defence-in-depth layer on top, not a substitute.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import RedirectResponse, Response
from sqlalchemy import and_, select
from sqlalchemy.orm import Session

from agentdrop.db.session import get_db
from agentdrop.models import Drop
from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

router = APIRouter(
    tags=["web-drop-actions"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]

ActionKind = Literal["pin", "archive"]


def _get_drop_or_404(db: Session, short_id: str) -> Drop:
    """Look up a live drop by its public slug, or 404.

    Matches the filter semantics of the public ``GET /d/{short_id}`` route:
    soft-deleted rows are invisible. Archived rows are still addressable
    by their short URL — archive just hides from the default inbox, it
    doesn't tombstone the page.
    """
    drop = db.execute(
        select(Drop).where(and_(Drop.short_id == short_id, Drop.soft_deleted_at.is_(None)))
    ).scalar_one_or_none()
    if drop is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Drop not found")
    return drop


def _is_htmx(request: Request) -> bool:
    """Detect an HTMX-initiated request via the ``HX-Request`` header."""
    return request.headers.get("hx-request") == "true"


def _render_button(request: Request, kind: ActionKind, drop: Drop) -> Response:
    """Render a single action-button partial (HTMX swap target).

    Agent B owns ``_action_button.html``; we just hand it the two vars
    it expects (``kind`` + ``drop``) and return the render. ``hx-swap=outerHTML``
    on the client side means this replaces the clicked button with its
    updated self (e.g. ``Pin`` flips to ``Pinned``).
    """
    return templates.TemplateResponse(
        request,
        "_action_button.html",
        {"kind": kind, "drop": drop},
    )


def _toggle_timestamp(current: datetime | None) -> datetime | None:
    """Flip a nullable timestamp: ``None`` -> now, set -> ``None``.

    Symmetric toggle — there's no separate un-pin / un-archive endpoint.
    We set to ``None`` explicitly rather than using SQL ``IS NULL`` magic;
    SQLAlchemy translates Python ``None`` into a ``NULL`` UPDATE just fine.

    NOTE: un-pinning a drop whose ``expires_at`` has passed does *not*
    currently re-schedule it for expiry (the retention sweep isn't wired
    yet — see PRD §8.4). When the sweep lands, we'll need to revisit
    whether "a drop the user explicitly pinned" should get a grace
    period; for now this toggle is purely a state flip.
    """
    if current is None:
        return datetime.now(UTC)
    return None


@router.post("/d/{short_id}/pin")
def toggle_pin(
    short_id: str,
    request: Request,
    db: DbSession,
) -> Response:
    """Toggle the pin state on a drop.

    Returns the re-rendered pin button (HTMX) or a 303 back to the drop
    page (plain form submit). 404 if the drop is missing or soft-deleted.
    """
    drop = _get_drop_or_404(db, short_id)
    drop.pinned_at = _toggle_timestamp(drop.pinned_at)
    db.commit()
    db.refresh(drop)

    if _is_htmx(request):
        return _render_button(request, "pin", drop)
    return RedirectResponse(
        url=f"/d/{short_id}",
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/d/{short_id}/archive")
def toggle_archive(
    short_id: str,
    request: Request,
    db: DbSession,
) -> Response:
    """Toggle the archive state on a drop.

    Archive hides from the default inbox but keeps the content and
    public URL live (PRD §8.4). Same contract as :func:`toggle_pin`.
    """
    drop = _get_drop_or_404(db, short_id)
    drop.archived_at = _toggle_timestamp(drop.archived_at)
    db.commit()
    db.refresh(drop)

    if _is_htmx(request):
        return _render_button(request, "archive", drop)
    return RedirectResponse(
        url=f"/d/{short_id}",
        status_code=status.HTTP_303_SEE_OTHER,
    )
