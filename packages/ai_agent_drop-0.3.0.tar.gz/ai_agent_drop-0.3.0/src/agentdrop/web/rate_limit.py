"""In-memory sliding-window rate limiter.

Built for the single-host, single-process deployment posture in PRD §12
(no Redis, no shared state). State lives in a module-level dict keyed by
``(name, key)`` where ``key`` is by default the client IP but can be
overridden per call site via a ``key_builder`` (e.g. per-API-key buckets
on ingestion).

The dependency factory :func:`rate_limit` returns a FastAPI dependency
that raises ``HTTPException(429)`` when the key has already used its
quota.

Two recording modes:

* ``record_on_check=False`` (default): the dependency only *checks* the
  limit; the route calls :func:`record_attempt` after a failed verify
  and :func:`reset_attempts` on success. Used for login — only failures
  count, success clears.
* ``record_on_check=True``: the dependency records an attempt whenever
  the check passes. Used for ingestion endpoints where every accepted
  request should consume budget.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable

from fastapi import HTTPException, Request, status

from agentdrop.config import get_settings

_lock = threading.Lock()
_attempts: dict[tuple[str, str], list[float]] = {}


def _client_ip(request: Request) -> str:
    """Return the client IP for rate-limit keying.

    Honours ``X-Forwarded-For`` (first entry) only when
    ``AGENTDROP_TRUST_PROXY_HEADERS=1`` — otherwise a public deployment
    sitting directly on the internet could be trivially spoofed by a
    client setting the header itself.
    """
    if get_settings().trust_proxy_headers:
        forwarded = request.headers.get("x-forwarded-for")
        if forwarded:
            first = forwarded.split(",", 1)[0].strip()
            if first:
                return first
    if request.client is not None and request.client.host:
        return request.client.host
    return "unknown"


def _prune(timestamps: list[float], window_seconds: int, now: float) -> list[float]:
    cutoff = now - window_seconds
    return [t for t in timestamps if t > cutoff]


def rate_limit(
    name: str,
    max_attempts: int,
    window_seconds: int,
    key_builder: Callable[[Request], str] | None = None,
    record_on_check: bool = False,
) -> Callable[[Request], None]:
    """Build a FastAPI dependency that enforces ``max_attempts`` per key.

    Args:
        name: Bucket name. Different limits for the same key live in
            different buckets.
        max_attempts: Number of attempts allowed within ``window_seconds``.
        window_seconds: Sliding window length.
        key_builder: Per-request key extractor. Defaults to client IP.
            Pass a custom builder to bucket per-API-key, per-user, etc.
        record_on_check: When ``True``, the dependency itself appends a
            timestamp on each successful check — appropriate for endpoints
            where every accepted request consumes budget. When ``False``,
            the route is expected to call :func:`record_attempt` /
            :func:`reset_attempts` itself (login flow).
    """

    def _dependency(request: Request) -> None:
        bucket_key = key_builder(request) if key_builder is not None else _client_ip(request)
        key = (name, bucket_key)
        now = time.monotonic()
        with _lock:
            timestamps = _prune(_attempts.get(key, []), window_seconds, now)
            _attempts[key] = timestamps
            if len(timestamps) >= max_attempts:
                oldest = timestamps[0]
                retry_after = max(1, int(window_seconds - (now - oldest)))
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="Too many attempts. Try again later.",
                    headers={"Retry-After": str(retry_after)},
                )
            if record_on_check:
                timestamps.append(now)

    return _dependency


def record_attempt(name: str, ip: str) -> None:
    """Record a failed attempt for ``(name, ip)``."""
    now = time.monotonic()
    with _lock:
        _attempts.setdefault((name, ip), []).append(now)


def reset_attempts(name: str, ip: str) -> None:
    """Clear the attempt counter for ``(name, ip)``."""
    with _lock:
        _attempts.pop((name, ip), None)


def client_ip(request: Request) -> str:
    """Public helper for routes that need to record/reset by IP."""
    return _client_ip(request)


def _TEST_clear() -> None:
    """Wipe all rate-limit state. Tests only."""
    with _lock:
        _attempts.clear()
