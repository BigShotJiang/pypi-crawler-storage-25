"""Admin inbox route — ``GET /`` (PRD §6.3, §10).

The server-rendered counterpart to the JSON listing API at
``/api/v1/drops``. Both hit the same ``drops`` table but answer different
questions: the JSON endpoint returns a flat paginated page for programmatic
callers, while this route assembles the full inbox UI — the drop list plus
the sidebar counts and source facets — in a single response.

We deliberately don't reuse ``agentdrop.routes.drops.list_drops`` here: its
keyset-pagination + cursor contract and its per-state ``and_`` clauses are
tuned for the API's invariants (e.g. ``state='unread'`` must exclude pinned
AND archived). The inbox's state semantics are looser — ``"all"`` hides only
archived, ``"unread"`` just means ``read_at IS NULL``, etc. Sharing the
function would mean threading another enum through the API route, which
isn't worth the coupling.

Cursor pagination shares its **format** with the API (opaque base64 of
``{created_at_iso}|{id}``) so a future ``/api/v1/drops`` cursor stays
swappable into the inbox if we ever want to consolidate. See ``_encode_cursor``
/ ``_decode_cursor`` here vs. the API's helpers in
:mod:`agentdrop.routes.drops`.
"""

from __future__ import annotations

import base64
import binascii
from datetime import datetime
from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from fastapi.responses import HTMLResponse
from sqlalchemy import and_, func, or_, select
from sqlalchemy.orm import Session

from agentdrop.db.session import get_db
from agentdrop.models import Drop
from agentdrop.search import search_drops
from agentdrop.web import templates
from agentdrop.web.filters import time_ago as _time_ago  # noqa: F401  registers filter
from agentdrop.web.session import Admin, require_session

router = APIRouter(tags=["web-inbox"])

DbSession = Annotated[Session, Depends(get_db)]

# Inbox state filter (matches mobile FilterTabs copy).
InboxState = Literal["all", "unread", "pinned", "archived"]

# Page size for the inbox list. Smaller than the API's default — the inbox
# is rendered as HTML and HTMX appends pages on demand, so we don't need to
# fetch 100 rows up front. Issue #14 (G2).
_PAGE_SIZE = 50


# ---------------------------------------------------------------------------
# Cursor helpers — keyset pagination over (created_at DESC, id DESC).
# Format mirrors the JSON API in :mod:`agentdrop.routes.drops` so the two can
# converge later. Opaque base64 of ``{created_at_iso}|{id}``; not a security
# boundary, just a hint that clients shouldn't rewrite it.
# ---------------------------------------------------------------------------


def _encode_cursor(created_at: datetime, drop_id: str) -> str:
    raw = f"{created_at.isoformat()}|{drop_id}".encode()
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_cursor(cursor: str) -> tuple[datetime, str]:
    padding = "=" * (-len(cursor) % 4)
    try:
        raw = base64.urlsafe_b64decode(cursor + padding).decode("utf-8")
        created_iso, drop_id = raw.split("|", 1)
        return datetime.fromisoformat(created_iso), drop_id
    except (ValueError, binascii.Error) as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid cursor",
        ) from exc


def _state_clause(state: InboxState):
    """Return a SQL predicate expressing the inbox ``state`` filter.

    ``"all"`` = everything except archived. ``"unread"`` = ``read_at IS NULL``
    (pinned-unread drops should count as unread so users see them in both
    views). ``"pinned"`` = pinned AND not archived. ``"archived"`` = archived.
    """
    if state == "unread":
        return and_(Drop.read_at.is_(None), Drop.archived_at.is_(None))
    if state == "pinned":
        return and_(Drop.pinned_at.is_not(None), Drop.archived_at.is_(None))
    if state == "archived":
        return Drop.archived_at.is_not(None)
    # "all" — default inbox view hides archived.
    return Drop.archived_at.is_(None)


def _title_for(state: InboxState, source: str | None) -> str:
    """Pick the page title: source filter beats state name."""
    if source:
        return source
    return {
        "all": "Drops",
        "unread": "Unread",
        "pinned": "Pinned",
        "archived": "Archived",
    }[state]


def _counts_by_state(db: Session) -> dict[str, int]:
    """Per-view counts for the sidebar rows + mobile filter tabs.

    Two queries total: one aggregating archived-vs-live with subtotals for
    unread / pinned, plus a trivial "archived total" fall-out. Using a single
    ``CASE``-based aggregate would be cleverer but less readable; this isn't
    a hot path.
    """
    # "all" = every live (non-soft-deleted) drop that isn't archived.
    all_count = db.execute(
        select(func.count(Drop.id)).where(
            and_(Drop.soft_deleted_at.is_(None), Drop.archived_at.is_(None))
        )
    ).scalar_one()

    unread_count = db.execute(
        select(func.count(Drop.id)).where(
            and_(
                Drop.soft_deleted_at.is_(None),
                Drop.archived_at.is_(None),
                Drop.read_at.is_(None),
            )
        )
    ).scalar_one()

    pinned_count = db.execute(
        select(func.count(Drop.id)).where(
            and_(
                Drop.soft_deleted_at.is_(None),
                Drop.archived_at.is_(None),
                Drop.pinned_at.is_not(None),
            )
        )
    ).scalar_one()

    archived_count = db.execute(
        select(func.count(Drop.id)).where(
            and_(Drop.soft_deleted_at.is_(None), Drop.archived_at.is_not(None))
        )
    ).scalar_one()

    return {
        "all": int(all_count),
        "unread": int(unread_count),
        "pinned": int(pinned_count),
        "archived": int(archived_count),
    }


def _sources_with_unread_counts(db: Session) -> list[dict[str, object]]:
    """Distinct non-null sources plus their per-source unread counts.

    Two grouped queries over live drops (no N+1). Sources with
    ``source IS NULL`` are excluded — the sidebar is "Sources", not
    "Unsourced". A single-query ``SUM(CASE WHEN ...)`` form works too but is
    harder to read for negligible gain at MVP scale.
    """
    # Total per source (any state except soft-deleted).
    totals_stmt = (
        select(Drop.source, func.count(Drop.id))
        .where(and_(Drop.soft_deleted_at.is_(None), Drop.source.is_not(None)))
        .group_by(Drop.source)
        .order_by(Drop.source.asc())
    )
    totals = list(db.execute(totals_stmt).all())

    # Unread per source. "Unread" here matches the "N new" definition:
    # read_at IS NULL AND archived_at IS NULL (soft_deleted already filtered).
    unread_stmt = (
        select(Drop.source, func.count(Drop.id))
        .where(
            and_(
                Drop.soft_deleted_at.is_(None),
                Drop.source.is_not(None),
                Drop.read_at.is_(None),
                Drop.archived_at.is_(None),
            )
        )
        .group_by(Drop.source)
    )
    unreads: dict[str, int] = {row[0]: row[1] for row in db.execute(unread_stmt).all()}

    return [
        {
            "id": source,
            "name": source,
            "total": int(total),
            "unread": int(unreads.get(source, 0)),
        }
        for source, total in totals
    ]


def _list_drops(
    db: Session,
    *,
    state: InboxState,
    source: str | None,
    cursor: str | None,
) -> tuple[list[Drop], str | None]:
    """Return one page of drops (newest first) plus the next cursor or ``None``.

    Always excludes soft-deleted rows. Search is *not* handled here — see
    :func:`agentdrop.search.search_drops` and the ``q`` branch of the
    handler below; search has no cursor (single-shot, capped).

    Ordering is ``(created_at DESC, id DESC)`` — same tuple the cursor
    encodes, so pagination is keyset-stable even when many drops share a
    second-resolution timestamp.
    """
    stmt = select(Drop).where(Drop.soft_deleted_at.is_(None))
    stmt = stmt.where(_state_clause(state))

    if source is not None:
        stmt = stmt.where(Drop.source == source)

    if cursor is not None:
        cur_created, cur_id = _decode_cursor(cursor)
        stmt = stmt.where(
            or_(
                Drop.created_at < cur_created,
                and_(Drop.created_at == cur_created, Drop.id < cur_id),
            )
        )

    stmt = stmt.order_by(Drop.created_at.desc(), Drop.id.desc()).limit(_PAGE_SIZE)
    drops = list(db.execute(stmt).scalars().all())

    next_cursor = (
        _encode_cursor(drops[-1].created_at, drops[-1].id) if len(drops) == _PAGE_SIZE else None
    )
    return drops, next_cursor


def _is_htmx(request: Request) -> bool:
    """Detect an HTMX-initiated request via the ``HX-Request`` header.

    Mirrors :func:`agentdrop.web.drop_actions._is_htmx`; kept inline here
    rather than importing across modules because it's a one-line stable
    contract HTMX defines, not domain logic.
    """
    return request.headers.get("hx-request") == "true"


@router.get("/", response_class=HTMLResponse)
def inbox(
    request: Request,
    db: DbSession,
    _admin: Annotated[Admin, Depends(require_session)],
    state: Annotated[InboxState, Query()] = "all",
    source: Annotated[str | None, Query()] = None,
    q: Annotated[str | None, Query()] = None,
    cursor: Annotated[str | None, Query()] = None,
) -> HTMLResponse:
    """Render the inbox for the logged-in admin.

    Unauthenticated requests are redirected to ``/login`` via the
    ``require_session`` dependency; see ``agentdrop.web.session``.

    With a ``cursor`` query parameter and an ``HX-Request`` header, returns
    the list partial only (next page of dropcards + the next ``Load more``
    button, or just the dropcards on the final page). Without HTMX the
    cursor is still honoured but the full page renders — useful as a
    progressive-enhancement fallback if JS is disabled.
    """
    if q:
        # FTS5 on SQLite, broadened LIKE on other dialects. Returns [] when
        # the user's query sanitizes down to nothing (pure punctuation).
        # Search is single-shot (no cursor) — capped at ``_PAGE_SIZE``.
        drops = search_drops(db, q=q, source=source, state=state, limit=_PAGE_SIZE)
        next_cursor: str | None = None
    else:
        drops, next_cursor = _list_drops(db, state=state, source=source, cursor=cursor)

    # HTMX request → list partial only (cards + next button). Hit by both
    # the cursor-paginated "Load more" button (issue #14 G2) and the
    # debounced search input (issue #15 I5). The full-page response is
    # still served on a non-HTMX request so progressive enhancement works
    # — typing into the search box without JS submits the form normally
    # and re-renders the whole inbox.
    if _is_htmx(request):
        return templates.TemplateResponse(
            request,
            "_inbox_list.html",
            {
                "drops": drops,
                "next_cursor": next_cursor,
                "state": state,
                "source": source,
                "q": q or "",
            },
        )

    counts = _counts_by_state(db)
    sources = _sources_with_unread_counts(db)

    return templates.TemplateResponse(
        request,
        "inbox.html",
        {
            "drops": drops,
            "next_cursor": next_cursor,
            "title": _title_for(state, source),
            "new_count": counts["unread"],
            "counts": counts,
            "sources": sources,
            "state": state,
            "source": source,
            "q": q or "",
        },
    )
