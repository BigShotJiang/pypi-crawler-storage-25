"""Session-cookie admin authentication for the web UI.

Distinct from ``agentdrop.auth`` (bearer-token API auth for ``/api/v1/*``);
the inbox and other UI surfaces sit behind a cookie-backed session instead,
so a human on a phone can tap a notification, land on the drop page, and
navigate into the inbox without juggling headers. PRD §8.5.

MVP scope: one admin, password sourced from ``AGENTDROP_ADMIN_PASSWORD``,
hashed with argon2 once at first use and cached. The v1 first-run password
setup flow (PRD §6.1) will replace the env-var source with a DB row.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from functools import lru_cache
from urllib.parse import quote

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError
from fastapi import HTTPException, Request, status

from agentdrop.config import get_settings

# Default argon2 parameters (time_cost=3, memory_cost=64MiB, parallelism=4)
# per argon2-cffi defaults — fine for a single-admin login path where we
# hash once at boot and verify at most once per login attempt.
_hasher = PasswordHasher()


@dataclass(frozen=True)
class Admin:
    """Sentinel for the logged-in admin principal.

    MVP has a single admin, so the username is a constant. Kept as a
    frozen dataclass so downstream code has a stable type to depend on
    when v1 introduces multi-user auth.
    """

    username: str = "admin"


@lru_cache(maxsize=1)
def _get_admin_password_hash() -> str | None:
    """Return the argon2 hash of the configured admin password, or ``None``.

    Cached so we only hash the plaintext once per process. Call
    ``_get_admin_password_hash.cache_clear()`` (and
    ``get_settings.cache_clear()``) in tests that flip
    ``AGENTDROP_ADMIN_PASSWORD`` between cases.
    """
    configured = get_settings().admin_password
    if configured is None or configured == "":
        return None
    return _hasher.hash(configured)


def is_admin_configured() -> bool:
    """True if ``AGENTDROP_ADMIN_PASSWORD`` is set to a non-empty value."""
    return _get_admin_password_hash() is not None


def verify_admin_password(raw: str) -> bool:
    """Verify ``raw`` against the cached admin password hash.

    Returns ``False`` if no password is configured, or if the hash does
    not match. Callers that need to distinguish "not configured" from
    "wrong password" should use :func:`is_admin_configured` first.
    """
    expected = _get_admin_password_hash()
    if expected is None:
        return False
    try:
        return _hasher.verify(expected, raw)
    except (VerifyMismatchError, VerificationError, InvalidHashError):
        return False


async def averify_admin_password(raw: str) -> bool:
    """Async wrapper around :func:`verify_admin_password`.

    Argon2 verification is CPU-bound (50-100ms with default parameters)
    and would block the event loop if called directly from an async
    route. ``asyncio.to_thread`` hands it off to the default executor so
    concurrent login attempts don't serialize on a single core.
    """
    return await asyncio.to_thread(verify_admin_password, raw)


def require_session(request: Request) -> Admin:
    """FastAPI dependency: require a logged-in admin session.

    Raises ``HTTPException(303)`` with a ``Location`` header pointing at
    ``/login?next=<original-path>`` when no session is present. Starlette
    turns the exception into a redirect response, which is the idiomatic
    FastAPI pattern for "send unauth'd users to login".
    """
    if request.session.get("admin") is True:
        return Admin()

    next_path = request.url.path
    # Preserve the query string so users land back on the exact URL they
    # were trying to reach (e.g. ``/inbox?filter=unread``).
    if request.url.query:
        next_path = f"{next_path}?{request.url.query}"

    raise HTTPException(
        status_code=status.HTTP_303_SEE_OTHER,
        headers={"Location": f"/login?next={quote(next_path, safe='')}"},
    )


def current_admin(request: Request) -> Admin | None:
    """Optional variant of :func:`require_session`.

    Returns ``None`` instead of redirecting. Useful for templates that
    want to show "Sign in" vs "Sign out" without forcing auth.
    """
    if request.session.get("admin") is True:
        return Admin()
    return None
