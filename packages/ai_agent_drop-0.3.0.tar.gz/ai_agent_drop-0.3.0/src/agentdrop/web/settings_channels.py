"""Settings UI for notification channels (PRD §7, §8.3, §14).

Session-authed CRUD over the ``channels`` table. This replaces (well, now
takes precedence over) the env-only MVP channel bootstrap: once any row
exists here the env vars become an optional fallback only — see
:func:`agentdrop.notifications.resolver.resolve_default_channel`.

Conventions locked with the Agent-C settings shell:

* Pages extend ``settings/_base.html`` and wrap content in the
  ``settings_content`` block. The shell owns the body class.
* Every ``TemplateResponse`` passes ``active_section="channels"`` so the
  shell can highlight the nav.

Form posture (MVP):

* Config is a raw JSON textarea. Per-driver structured forms are a v1
  concern; surface driver validation errors verbatim next to the field
  and point users at ``.env.example`` for the schema.
* Secrets are never re-displayed after creation. On edit the user sees
  ``••••••••`` and re-types to change. If they don't re-type, we merge
  the partial config into the existing ``config_json`` so untouched
  secrets survive (driven by the hidden ``has_existing_config`` flag).
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from typing import Annotated, Any
from urllib.parse import quote

import structlog
from fastapi import APIRouter, Depends, Form, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.models import Channel
from agentdrop.notifications import (
    DRIVERS,
    DriverConfigError,
    get_driver,
    validate_driver_config,
)
from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

logger = structlog.get_logger("agentdrop.web.settings_channels")

router = APIRouter(
    prefix="/settings/channels",
    tags=["web-settings"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]

# Name validation per the task brief: 1-80 chars, letters/digits/hyphen/
# underscore/space. The DB enforces uniqueness separately.
_NAME_RE = re.compile(r"^[A-Za-z0-9 _\-]{1,80}$")

# Fields in each driver's config whose values are sensitive and should
# never be shown in the edit form. The per-driver lookup is deliberately
# explicit (not derived from a "secret?" flag on each key) so adding a
# new driver forces the author to think about which of its fields are
# credentials. Mirrors the redaction posture in ntfy/webhook drivers.
_SENSITIVE_FIELDS: dict[str, frozenset[str]] = {
    "pushover": frozenset({"token", "user"}),
    "ntfy": frozenset({"access_token", "password"}),
    "apprise": frozenset({"urls"}),
    "webhook": frozenset({"bearer", "basic_pass"}),
}

_SECRET_PLACEHOLDER = "••••••••"  # noqa: S105  # nosec B105 — UI mask for redacted secrets, not a credential


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mask_config(driver: str, config: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of ``config`` with known sensitive fields masked.

    For ``apprise.urls`` (a list of credentialed URLs) the whole list is
    replaced with a single placeholder string; operators re-enter the
    list or leave the textarea unchanged on edit.
    """
    sensitive = _SENSITIVE_FIELDS.get(driver, frozenset())
    masked: dict[str, Any] = {}
    for k, v in config.items():
        if k in sensitive and v not in (None, ""):
            masked[k] = _SECRET_PLACEHOLDER
        else:
            masked[k] = v
    return masked


def _merge_existing_secrets(
    driver: str,
    submitted: dict[str, Any],
    existing: dict[str, Any],
) -> dict[str, Any]:
    """Fill any missing / placeholder secret values from ``existing``.

    If the user left the sensitive field unchanged (equal to the
    placeholder) or removed it from the JSON entirely, we copy the old
    value back in. Non-secret fields come through from ``submitted``
    unchanged — they're authoritative.
    """
    sensitive = _SENSITIVE_FIELDS.get(driver, frozenset())
    merged = dict(submitted)
    for field in sensitive:
        value = merged.get(field)
        is_placeholder = value == _SECRET_PLACEHOLDER
        # apprise.urls placeholder is a single-element list or a bare string
        # depending on what the form round-tripped; treat both as "unchanged".
        if field == "urls" and isinstance(value, list) and value == [_SECRET_PLACEHOLDER]:
            is_placeholder = True
        if field not in merged or value in (None, "") or is_placeholder:
            if field in existing:
                merged[field] = existing[field]
            elif field in merged:
                merged.pop(field)
    return merged


def _validate_name(name: str) -> str | None:
    """Return an error string, or ``None`` if the name is valid."""
    if not name or not _NAME_RE.fullmatch(name):
        return (
            "Name must be 1-80 characters and use only letters, digits, "
            "hyphens, underscores, or spaces."
        )
    return None


def _parse_config_json(raw: str) -> tuple[dict[str, Any] | None, str | None]:
    """Parse the JSON textarea; return ``(config, error)``.

    Empty strings decode to ``{}`` — a couple of drivers accept an empty
    config. Non-dict JSON is rejected (the driver's ``__init__`` expects
    a ``dict[str, Any]``).
    """
    stripped = raw.strip()
    if not stripped:
        return {}, None
    try:
        parsed = json.loads(stripped)
    except json.JSONDecodeError as exc:
        return None, f"Config is not valid JSON: {exc.msg} (line {exc.lineno}, col {exc.colno})"
    if not isinstance(parsed, dict):
        return None, "Config must decode to a JSON object ({...})."
    return parsed, None


def _driver_choices() -> list[str]:
    """Driver names for the ``<select>`` — ``web_push`` first as the
    recommended default, then the rest alphabetically.
    """
    rest = sorted(name for name in DRIVERS if name != "web_push")
    return (["web_push"] if "web_push" in DRIVERS else []) + rest


def _render_form(
    request: Request,
    *,
    channel: Channel | None,
    form_values: dict[str, Any],
    errors: dict[str, str],
    status_code: int = status.HTTP_200_OK,
) -> HTMLResponse:
    return templates.TemplateResponse(
        request,
        "settings/channel_form.html",
        {
            "active_section": "channels",
            "channel": channel,
            "form": form_values,
            "errors": errors,
            "drivers": _driver_choices(),
        },
        status_code=status_code,
    )


def _load_channel_or_404(db: Session, channel_id: str) -> Channel | None:
    return db.execute(select(Channel).where(Channel.id == channel_id)).scalar_one_or_none()


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


@router.get("", response_class=HTMLResponse)
def list_channels(
    request: Request,
    db: DbSession,
    notice: str | None = None,
    detail: str | None = None,
) -> HTMLResponse:
    channels = list(db.execute(select(Channel).order_by(Channel.created_at.desc())).scalars().all())
    return templates.TemplateResponse(
        request,
        "settings/channels_list.html",
        {
            "active_section": "channels",
            "channels": channels,
            "notice": notice,
            "detail": detail,
        },
    )


# ---------------------------------------------------------------------------
# New
# ---------------------------------------------------------------------------


@router.get("/new", response_class=HTMLResponse)
def new_channel_form(request: Request) -> HTMLResponse:
    return _render_form(
        request,
        channel=None,
        form_values={
            "name": "",
            "driver": _driver_choices()[0] if _driver_choices() else "",
            "config_json": "{}",
        },
        errors={},
    )


@router.post("", response_class=HTMLResponse, response_model=None)
def create_channel(
    request: Request,
    db: DbSession,
    name: Annotated[str, Form()],
    driver: Annotated[str, Form()],
    config_json: Annotated[str, Form()] = "",
) -> HTMLResponse | RedirectResponse:
    errors: dict[str, str] = {}
    name = name.strip()

    if (err := _validate_name(name)) is not None:
        errors["name"] = err

    if driver not in DRIVERS:
        errors["driver"] = f"Unknown driver: {driver!r}. Choose one of {_driver_choices()}."

    config, cfg_err = _parse_config_json(config_json)
    if cfg_err is not None:
        errors["config_json"] = cfg_err

    # Uniqueness check — do this before driver-validation so the user gets
    # one clean "pick a different name" error rather than two.
    if "name" not in errors:
        existing = db.execute(select(Channel).where(Channel.name == name)).scalar_one_or_none()
        if existing is not None:
            errors["name"] = f"A channel named {name!r} already exists."

    # Only run driver validation once the easy checks have passed — driver
    # validate_config may reach out to external libs (e.g. apprise URL
    # parsing) and we don't want those running on obviously-invalid input.
    config_invalid = False
    if not errors and config is not None:
        try:
            validate_driver_config(driver, config)
        except DriverConfigError as exc:
            errors["config_json"] = str(exc)
            config_invalid = True
        except Exception as exc:
            # Anything else is a programming bug in the driver — surface
            # the class name so operators can file a ticket.
            logger.exception("driver_validate_config_crashed", driver=driver)
            errors["config_json"] = f"driver rejected config ({exc.__class__.__name__})"
            config_invalid = True

    if errors:
        # Driver-level config rejection is a semantic-validation error —
        # the request was well-formed but the values failed driver-specific
        # rules. Use 422 to match REST conventions; structural errors
        # (bad JSON, unknown driver, name format) stay at 400.
        status_code = (
            status.HTTP_422_UNPROCESSABLE_CONTENT if config_invalid else status.HTTP_400_BAD_REQUEST
        )
        return _render_form(
            request,
            channel=None,
            form_values={
                "name": name,
                "driver": driver,
                "config_json": config_json,
            },
            errors=errors,
            status_code=status_code,
        )

    assert config is not None  # noqa: S101 — for mypy; errors above would have returned
    row = Channel(name=name, driver=driver, config_json=config, is_default=False)
    db.add(row)
    db.commit()

    return RedirectResponse(
        url="/settings/channels?notice=created",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Edit
# ---------------------------------------------------------------------------


@router.get("/{channel_id}/edit", response_class=HTMLResponse, response_model=None)
def edit_channel_form(
    request: Request,
    db: DbSession,
    channel_id: str,
) -> HTMLResponse | RedirectResponse:
    channel = _load_channel_or_404(db, channel_id)
    if channel is None:
        return RedirectResponse(
            url="/settings/channels?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )

    masked = _mask_config(channel.driver, dict(channel.config_json or {}))
    return _render_form(
        request,
        channel=channel,
        form_values={
            "name": channel.name,
            "driver": channel.driver,
            "config_json": json.dumps(masked, indent=2),
        },
        errors={},
    )


@router.post("/{channel_id}", response_class=HTMLResponse, response_model=None)
def update_channel(
    request: Request,
    db: DbSession,
    channel_id: str,
    name: Annotated[str, Form()],
    driver: Annotated[str, Form()],
    config_json: Annotated[str, Form()] = "",
    has_existing_config: Annotated[str, Form()] = "",
) -> HTMLResponse | RedirectResponse:
    channel = _load_channel_or_404(db, channel_id)
    if channel is None:
        return RedirectResponse(
            url="/settings/channels?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )

    errors: dict[str, str] = {}
    name = name.strip()

    if (err := _validate_name(name)) is not None:
        errors["name"] = err

    if driver not in DRIVERS:
        errors["driver"] = f"Unknown driver: {driver!r}. Choose one of {_driver_choices()}."

    config, cfg_err = _parse_config_json(config_json)
    if cfg_err is not None:
        errors["config_json"] = cfg_err

    if "name" not in errors and name != channel.name:
        dupe = db.execute(
            select(Channel).where(Channel.name == name, Channel.id != channel.id)
        ).scalar_one_or_none()
        if dupe is not None:
            errors["name"] = f"A channel named {name!r} already exists."

    # Secrets-preserving merge. Only when the user is editing an existing
    # row for the same driver — if they switched driver, the old secrets
    # don't apply to the new schema.
    merged_config = config
    if not errors and config is not None and has_existing_config and driver == channel.driver:
        merged_config = _merge_existing_secrets(driver, config, dict(channel.config_json or {}))

    config_invalid = False
    if not errors and merged_config is not None:
        try:
            validate_driver_config(driver, merged_config)
        except DriverConfigError as exc:
            errors["config_json"] = str(exc)
            config_invalid = True
        except Exception as exc:
            logger.exception("driver_validate_config_crashed", driver=driver)
            errors["config_json"] = f"driver rejected config ({exc.__class__.__name__})"
            config_invalid = True

    if errors:
        status_code = (
            status.HTTP_422_UNPROCESSABLE_CONTENT if config_invalid else status.HTTP_400_BAD_REQUEST
        )
        return _render_form(
            request,
            channel=channel,
            form_values={
                "name": name,
                "driver": driver,
                "config_json": config_json,
            },
            errors=errors,
            status_code=status_code,
        )

    assert merged_config is not None  # noqa: S101 — for mypy; errors above would have returned
    channel.name = name
    channel.driver = driver
    channel.config_json = merged_config
    db.add(channel)
    db.commit()

    return RedirectResponse(
        url="/settings/channels?notice=updated",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


@router.post("/{channel_id}/delete")
def delete_channel(db: DbSession, channel_id: str) -> RedirectResponse:
    channel = _load_channel_or_404(db, channel_id)
    if channel is None:
        return RedirectResponse(
            url="/settings/channels?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    # drops.channel_id uses ON DELETE SET NULL (see models/drop.py) so we
    # can drop the row without cascading to the drop history.
    db.delete(channel)
    db.commit()
    return RedirectResponse(
        url="/settings/channels?notice=deleted",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Set default
# ---------------------------------------------------------------------------


@router.post("/{channel_id}/default")
def set_default_channel(db: DbSession, channel_id: str) -> RedirectResponse:
    channel = _load_channel_or_404(db, channel_id)
    if channel is None:
        return RedirectResponse(
            url="/settings/channels?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    # Single-default invariant is app-layer (see Channel's module docstring),
    # so clear every other row first.
    others = (
        db.execute(select(Channel).where(Channel.id != channel.id, Channel.is_default.is_(True)))
        .scalars()
        .all()
    )
    for other in others:
        other.is_default = False
        db.add(other)
    channel.is_default = True
    db.add(channel)
    db.commit()
    return RedirectResponse(
        url="/settings/channels?notice=default-set",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Test-fire a notification
# ---------------------------------------------------------------------------


@router.post("/{channel_id}/test")
def test_channel(db: DbSession, channel_id: str) -> RedirectResponse:
    channel = _load_channel_or_404(db, channel_id)
    if channel is None:
        return RedirectResponse(
            url="/settings/channels?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )

    settings = get_settings()
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M:%S UTC")
    title = "Agent Drop: test notification"
    body = f"Sent from the Settings UI at {timestamp}"
    url = settings.base_url

    try:
        driver = get_driver(channel.driver, dict(channel.config_json or {}))
    except DriverConfigError as exc:
        return _redirect_with_failure(str(exc))
    except Exception as exc:  # pragma: no cover - programming bug
        logger.exception("driver_instantiation_crashed_during_test", driver=channel.driver)
        return _redirect_with_failure(f"driver init error ({exc.__class__.__name__})")

    try:
        result = driver.send(
            title=title,
            body=body,
            url=url,
            priority="normal",
            extras={"source": "settings-test"},
        )
    except Exception as exc:
        # Drivers raise DriverDeliveryError / DriverConfigError on expected
        # failures and arbitrary exceptions on bugs. Flatten them all into
        # a single "failed" branch — the UI only distinguishes ok / not-ok.
        # The exception *class* leaks; the message is pass-through from the
        # driver, which already redacts credentials.
        return _redirect_with_failure(str(exc) or exc.__class__.__name__)

    if not result.ok:
        return _redirect_with_failure(result.detail or "driver reported failure")

    return RedirectResponse(
        url="/settings/channels?notice=sent-ok",
        status_code=status.HTTP_303_SEE_OTHER,
    )


def _redirect_with_failure(detail: str) -> RedirectResponse:
    # Cap + URL-quote so a multi-line upstream error body can't smuggle
    # whitespace into the Location header.
    capped = detail[:200]
    return RedirectResponse(
        url=f"/settings/channels?notice=failed&detail={quote(capped, safe='')}",
        status_code=status.HTTP_303_SEE_OTHER,
    )
