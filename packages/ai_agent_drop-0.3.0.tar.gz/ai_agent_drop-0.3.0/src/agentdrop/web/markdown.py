"""Markdown -> HTML renderer for Agent Drop's drop page.

Pipeline:
    markdown-it-py (gfm-like preset, HTML disabled) +
      - tables + strikethrough (built-in gfm-like)
      - linkify (autolinks — we prevent click in the browser)
      - tasklists plugin (emits ``task-list-item`` class on ``<li>``)
      - footnote plugin
      - anchors plugin (adds ``id`` to h1/h2/h3 for deep linking)
      - custom fence renderer:
          * ``mermaid`` -> ``<div class="mermaid">...</div>``
          * everything else -> Pygments-highlighted
            ``<pre><code class="language-XYZ">...</code></pre>``

All output is wrapped in ``markupsafe.Markup`` so Jinja skips escaping. The
drop template is expected to wrap the output in a ``<div class="md-body">``
container — all CSS (see ``static/markdown.css``) is scoped to that class.
"""

from __future__ import annotations

from html import escape as html_escape

from markdown_it import MarkdownIt
from markdown_it.token import Token
from markupsafe import Markup
from mdit_py_plugins.anchors import anchors_plugin
from mdit_py_plugins.footnote import footnote_plugin
from mdit_py_plugins.tasklists import tasklists_plugin
from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_by_name, guess_lexer
from pygments.util import ClassNotFound

# A single formatter instance drives both render-time highlighting and the
# generation of the shipped stylesheet (see ``scripts/gen_pygments_css.py``).
# ``nowrap=True`` so markdown-it emits the surrounding ``<pre><code>`` — the
# design's code-block chrome lives in ``markdown.css`` (padding, border,
# radius, warm paperDeep bg).
_FORMATTER = HtmlFormatter(
    style="friendly",
    nowrap=True,
    nobackground=True,
)


def _highlight(code: str, lang: str) -> str:
    """Highlight ``code`` with Pygments.

    Returns token ``<span>``s only — caller supplies the ``<pre><code>`` wrapper
    with the right language class so the Pygments stylesheet can scope styles.
    Falls back to escaped plaintext if no lexer matches.
    """
    lexer = None
    if lang:
        try:
            lexer = get_lexer_by_name(lang, stripall=False)
        except ClassNotFound:
            lexer = None
    if lexer is None:
        try:
            lexer = guess_lexer(code)
        except ClassNotFound:
            return html_escape(code)
    return highlight(code, lexer, _FORMATTER)


def _render_fence(self, tokens: list[Token], idx: int, options, env) -> str:
    token = tokens[idx]
    info = (token.info or "").strip()
    lang = info.split(None, 1)[0] if info else ""
    code = token.content or ""

    if lang == "mermaid":
        # Mermaid diagrams are rendered client-side; we just need to ship the
        # source verbatim inside a ``.mermaid`` element so ``mermaid.run()``
        # picks it up. Escape so user content can never break out.
        return f'<div class="mermaid">{html_escape(code)}</div>\n'

    highlighted = _highlight(code, lang)
    lang_class = f' class="language-{html_escape(lang)}"' if lang else ""
    return f"<pre><code{lang_class}>{highlighted}</code></pre>\n"


def _build_md() -> MarkdownIt:
    md = MarkdownIt(
        "gfm-like",
        {
            # Critical: disable raw HTML. Content is authored by agents and
            # we don't want ``<script>`` or ``<style>`` to pass through.
            "html": False,
            # Turn plain URLs and emails into ``<a>`` elements. Click is
            # suppressed client-side (see ``prevent_link_click.js``) so
            # external navigation always goes through the drop's dedicated
            # "Open original" card (``drop.external_url``).
            "linkify": True,
            # Soft line breaks -> ``<br>``. Matches the prototype's feel
            # (every newline in the markdown source translates to something
            # visible) — and keeps agent-generated content readable even when
            # the agent forgets to double-space.
            "breaks": False,
            # Typographer adds smart quotes etc. We leave it off; the warm
            # paper aesthetic is carried by fonts, not punctuation rewriting.
            "typographer": False,
        },
    )
    # gfm-like preset already enables table + strikethrough; linkify is
    # gated on the ``linkify`` option above.
    md.use(tasklists_plugin, enabled=False, label=False)
    md.use(footnote_plugin)
    md.use(
        anchors_plugin,
        min_level=1,
        max_level=3,
        slug_func=None,
        permalink=False,
    )
    md.add_render_rule("fence", _render_fence)
    return md


_md = _build_md()


def render_markdown(md: str) -> Markup:
    """Render markdown ``md`` to HTML.

    The returned value is a :class:`markupsafe.Markup` so Jinja2 will not
    double-escape it when the drop template emits ``{{ body_html }}``.

    HTML in the source is **escaped, not passed through** — raw ``<script>``
    tags from agent output cannot execute. GFM features (tables, task lists,
    strikethrough, footnotes, fenced code with syntax highlighting, linkify)
    are enabled. ``mermaid`` fences render as ``<div class="mermaid">`` so the
    client-side mermaid init (see ``static/mermaid_init.js``) can pick them up.
    """
    return Markup(_md.render(md or ""))  # noqa: S704  # nosec B704 — markdown-it-py renders with html=False; raw HTML is escaped, not passed through


__all__ = ["render_markdown"]
