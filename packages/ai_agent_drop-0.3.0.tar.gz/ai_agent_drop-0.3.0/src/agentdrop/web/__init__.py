from pathlib import Path

from fastapi import Request
from fastapi.templating import Jinja2Templates
from jinja2 import Undefined

web_dir = Path(__file__).parent
templates_dir = web_dir / "templates"
static_dir = web_dir / "static"
templates = Jinja2Templates(directory=str(templates_dir))

# Expose ``csrf_token(request)`` as a Jinja global so any template can
# render the per-session token without each route having to pass it
# through context. Imported here (not at the top) to avoid a circular
# import: ``csrf`` imports nothing from this module at import-time.
from agentdrop.web.csrf import generate_csrf_token  # noqa: E402


def _csrf_token(request: Request | Undefined) -> str:
    """Jinja-global wrapper around :func:`generate_csrf_token`.

    Returns an empty string when ``request`` isn't in scope (e.g. unit
    tests rendering the template directly via ``templates.get_template``)
    so those don't have to thread a real Starlette request through. Real
    HTTP renders always pass ``request`` to ``TemplateResponse``, so this
    fallback is exercised only by tests.
    """
    if isinstance(request, Undefined):
        return ""
    return generate_csrf_token(request)


templates.env.globals["csrf_token"] = _csrf_token
