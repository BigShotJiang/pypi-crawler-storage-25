"""Small datetime formatting helpers for the web UI.

Isolated from :mod:`agentdrop.web.filters` because this module is only
consumed by the drop page's "expires in" footer today, and the Jinja
filter registry in ``filters.py`` keeps a tight remit around inbox
formatters. Keeping the formatter free-standing also makes it trivial
to unit-test.
"""

from __future__ import annotations

from datetime import datetime, timedelta


def format_expires_in(now: datetime, expiry: datetime) -> str:
    """Return a short "time until expiry" string for the drop footer.

    Matches the handoff wording ``"expires in 6d 23h"`` — this function
    returns just the interval part (``"6d 23h"``); the template prepends
    ``"expires in "``. For intervals shorter than a day we switch to
    ``"Xh Ym"`` granularity so a drop minutes from expiry doesn't flash
    ``"0d 0h"``.

    Semantics:
        * ``expiry <= now`` → ``"expired"``.
        * ``expiry - now >= 1d`` → ``"Xd Yh"`` (e.g. ``"2d 4h"``).
        * ``expiry - now <  1d`` → ``"Xh Ym"`` (e.g. ``"5h 12m"``).

    Both inputs should be timezone-aware UTC datetimes (or both naive;
    we only do arithmetic on the delta). No rounding up — we floor to
    the displayed unit, matching the prototype's "6d 23h" example for a
    drop ~7 days out.
    """
    remaining = expiry - now
    if remaining <= timedelta(0):
        return "expired"

    total_seconds = int(remaining.total_seconds())
    if remaining >= timedelta(days=1):
        days = total_seconds // 86_400
        hours = (total_seconds % 86_400) // 3600
        return f"{days}d {hours}h"

    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    return f"{hours}h {minutes}m"
