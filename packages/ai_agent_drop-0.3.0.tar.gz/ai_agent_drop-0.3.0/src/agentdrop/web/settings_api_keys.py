"""Settings > API keys: create, list, revoke.

PRD §8.5 specifies multiple API keys so users can rotate and scope per
agent; this module is the UI surface for that. The bearer-token
enforcement itself lives in :mod:`agentdrop.auth`, which accepts both
env-configured and DB-stored keys.

Token format:

    agdr_<32-char base62>

The prefix is a visible signal ("this is an Agent Drop API key") that
makes leak-scanner regexes ergonomic. The 32-char body is drawn from
the same base62 alphabet as ``new_id`` — ~190 bits, well above the
24-char short-id entropy floor.

Security posture:

* The plaintext token is shown **once**, on creation, in a highlighted
  card. The DB never stores the plaintext — only its SHA-256 hash.
* Revocation sets ``revoked_at`` and keeps the row; we never hard-delete
  keys so the label + timestamp remain as an audit trail.
* All routes require a valid admin session. The bearer-token auth path
  (``/api/v1/*``) is deliberately separate: agents can't manage keys.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentdrop.auth import hash_key
from agentdrop.db.session import get_db
from agentdrop.ids import _generate
from agentdrop.models.api_key import ApiKey
from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

router = APIRouter(
    prefix="/settings/api-keys",
    tags=["web-settings"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]

# Label bounds match the column (``String(120)``) and enforce a non-empty
# value so every row in the UI has something to identify it by.
_LABEL_MIN = 1
_LABEL_MAX = 120

# Token body length. 32 base62 chars ≈ 190 bits of entropy. The column
# is ``String(32)`` for the PK only — the token/hash column is unbounded.
_TOKEN_BODY_LEN = 32
_TOKEN_PREFIX = "agdr_"  # noqa: S105  # nosec B105 — token prefix, not a credential


def _mint_token() -> str:
    """Return a freshly generated ``agdr_<32 base62>`` token.

    Reuses :func:`agentdrop.ids._generate` for the body so entropy source
    and alphabet stay in one place; the prefix is a product-side marker
    that lets us greet leaked tokens in log scanners.
    """
    return f"{_TOKEN_PREFIX}{_generate(_TOKEN_BODY_LEN)}"


def _list_keys(db: Session, *, include_revoked: bool) -> list[ApiKey]:
    """Return API keys, newest first. ``include_revoked`` toggles the filter."""
    stmt = select(ApiKey)
    if not include_revoked:
        stmt = stmt.where(ApiKey.revoked_at.is_(None))
    stmt = stmt.order_by(ApiKey.created_at.desc(), ApiKey.id.desc())
    return list(db.execute(stmt).scalars().all())


def _count_revoked(db: Session) -> int:
    """Cheap count used to render the "Show revoked (N)" toggle hint."""
    return len(
        list(db.execute(select(ApiKey).where(ApiKey.revoked_at.is_not(None))).scalars().all())
    )


def _render_list(
    request: Request,
    db: Session,
    *,
    include_revoked: bool = False,
    new_token_plaintext: str | None = None,
    new_token_label: str | None = None,
    error: str | None = None,
) -> HTMLResponse:
    """Render the list page, optionally with the one-time-display card."""
    keys = _list_keys(db, include_revoked=include_revoked)
    revoked_count = _count_revoked(db)

    return templates.TemplateResponse(
        request,
        "settings/api_keys_list.html",
        {
            "active_section": "api-keys",
            "section_title": "API keys",
            "keys": keys,
            "revoked_count": revoked_count,
            "include_revoked": include_revoked,
            "new_token_plaintext": new_token_plaintext,
            "new_token_label": new_token_label,
            "error": error,
        },
    )


@router.get("", response_class=HTMLResponse)
def list_keys(
    request: Request,
    db: DbSession,
    show_revoked: bool = False,
) -> HTMLResponse:
    """Render the API-keys list. ``?show_revoked=1`` includes revoked rows."""
    return _render_list(request, db, include_revoked=show_revoked)


@router.post("", response_class=HTMLResponse)
def create_key(
    request: Request,
    db: DbSession,
    label: Annotated[str, Form()],
) -> HTMLResponse:
    """Mint a new API key and render the list with the plaintext revealed.

    The plaintext token survives exactly one response — it's passed to
    the template as context and never persisted. The DB row holds only
    ``sha256(token)``, so a user who navigates away (or reloads) can't
    recover the plaintext.
    """
    label = label.strip()
    if len(label) < _LABEL_MIN or len(label) > _LABEL_MAX:
        # Re-render with an error rather than raising; the form lives on
        # the list page, so the user stays where they are and can fix it.
        return _render_list(
            request,
            db,
            error=f"Label must be {_LABEL_MIN}-{_LABEL_MAX} characters.",
        )

    token = _mint_token()
    row = ApiKey(
        key_hash=hash_key(token),
        label=label,
    )
    db.add(row)
    db.commit()
    db.refresh(row)

    return _render_list(
        request,
        db,
        new_token_plaintext=token,
        new_token_label=row.label,
    )


@router.post("/{api_key_id}/revoke")
def revoke_key(
    api_key_id: str,
    db: DbSession,
) -> RedirectResponse:
    """Mark the key revoked. Bearer auth will stop accepting it immediately.

    Idempotent: revoking an already-revoked key is a no-op. Unknown ids
     → 404 so an operator who clicks a stale link gets a clear signal
    rather than a silent success.
    """
    row = db.execute(select(ApiKey).where(ApiKey.id == api_key_id)).scalar_one_or_none()
    if row is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found")

    if row.revoked_at is None:
        row.revoked_at = datetime.now(UTC)
        db.commit()

    return RedirectResponse(url="/settings/api-keys", status_code=status.HTTP_303_SEE_OTHER)
