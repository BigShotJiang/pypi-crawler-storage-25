"""Settings shell — ``/settings`` landing + redirect.

Provides the chrome (left-nav + shared CSS + base template) that the
per-section routers slot into. The section routers themselves live in
sibling modules:

- ``agentdrop.web.settings_channels`` — notification channels CRUD.
- ``agentdrop.web.settings_api_keys`` — API key management.

This module owns only:

- ``GET /settings`` → 303 to ``/settings/channels``. We redirect rather
  than render a landing page because there's no useful content at the
  bare ``/settings`` URL yet — every concrete setting lives under a
  subsection, and "Channels" is the most-used one. Switching to a real
  landing later is a one-line change.
- ``GET /settings/`` — same, for trailing-slash tolerance. FastAPI's
  default ``redirect_slashes`` handles this for concrete routes but not
  for bare prefix roots reliably, so we spell it out.

Every route is gated by ``require_session`` at the router level so
unauth'd access falls through to ``/login`` with ``next=/settings/...``.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, status
from fastapi.responses import RedirectResponse

from agentdrop.web.session import require_session

router = APIRouter(
    prefix="/settings",
    tags=["web-settings"],
    dependencies=[Depends(require_session)],
)


@router.get("", include_in_schema=False)
def settings_root() -> RedirectResponse:
    """Redirect the bare ``/settings`` URL to the Channels section."""
    return RedirectResponse(url="/settings/channels", status_code=status.HTTP_303_SEE_OTHER)


@router.get("/", include_in_schema=False)
def settings_root_slash() -> RedirectResponse:
    """Trailing-slash variant — same redirect target."""
    return RedirectResponse(url="/settings/channels", status_code=status.HTTP_303_SEE_OTHER)
