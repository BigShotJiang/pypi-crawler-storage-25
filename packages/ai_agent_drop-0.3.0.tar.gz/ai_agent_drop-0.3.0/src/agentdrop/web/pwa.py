"""PWA-related routes — service worker, VAPID public key, subscriptions.

Three responsibilities live here:

1. ``GET /sw.js`` — the service worker. Served from root so its scope
   covers every URL the user navigates to (serving it from ``/static/``
   would limit it to ``/static/*``).
2. ``GET /pwa/vapid-public-key`` — public-by-design; the inbox JS calls
   this then passes the key to ``pushManager.subscribe()``.
3. ``POST /pwa/subscribe`` and ``DELETE /pwa/subscribe`` — session-authed
   endpoints the inbox calls to register / revoke a device's push
   subscription. The body is the JSON the browser hands us from
   ``PushSubscription.toJSON()``; we upsert by endpoint URL.

The manifest itself lives under ``/static`` (``<link rel="manifest">``
takes an explicit URL) — only the service worker has the path-scoping
rule.
"""

from __future__ import annotations

from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.net.ssrf import OutboundUrlError, validate_outbound_url
from agentdrop.web import static_dir
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

pwa_router = APIRouter(tags=["pwa"])

DbSession = Annotated[Session, Depends(get_db)]


@pwa_router.get("/sw.js", include_in_schema=False)
def service_worker() -> FileResponse:
    """Serve the service worker from the site root with full scope."""
    return FileResponse(
        static_dir / "sw.js",
        media_type="application/javascript",
        headers={
            # Service workers should not be cached aggressively — browsers
            # already cap caching at 24h, but we want updates to land on
            # the next page load.
            "Cache-Control": "no-cache",
        },
    )


@pwa_router.get("/pwa/vapid-public-key")
def vapid_public_key() -> dict[str, str | None]:
    """Return the VAPID public key for ``pushManager.subscribe``.

    Public by design — the key is the application server identity that
    push services check for VAPID auth, not a secret. Returns ``null``
    when no key is configured so the inbox JS can hide the subscribe
    button gracefully instead of erroring.
    """
    settings = get_settings()
    return {"key": settings.vapid_public_key}


class SubscriptionKeys(BaseModel):
    p256dh: str = Field(min_length=1, max_length=255)
    auth: str = Field(min_length=1, max_length=64)


class SubscriptionPayload(BaseModel):
    """Shape of the JSON the browser sends from ``PushSubscription.toJSON()``."""

    endpoint: str = Field(min_length=1)
    keys: SubscriptionKeys


@pwa_router.post(
    "/pwa/subscribe",
    dependencies=[Depends(require_session), Depends(require_csrf)],
)
def subscribe(
    payload: SubscriptionPayload,
    request: Request,
    db: DbSession,
) -> dict[str, Any]:
    """Upsert a Web Push subscription by endpoint URL.

    The browser returns the same endpoint for the same device + same
    VAPID app-key, so the natural unique constraint is the endpoint
    itself. If a row already exists we refresh the keys (the auth
    secret can rotate) and the user-agent label.
    """
    if not get_settings().vapid_public_key:
        # Pre-flight: subscribing while VAPID is unset is meaningless —
        # the next attempt to send a push would fail. Reject early so the
        # browser doesn't store a useless subscription.
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Web Push is not configured on this server.",
        )

    # Defense-in-depth: browsers normally only hand us public push-service
    # endpoints, but a malicious or compromised client could submit one
    # pointing at internal infrastructure. Reject any endpoint resolving
    # to private/loopback/link-local space at subscribe time so we never
    # store it.
    try:
        validate_outbound_url(payload.endpoint)
    except OutboundUrlError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid push endpoint: {exc}",
        ) from exc

    user_agent = request.headers.get("user-agent")

    existing = db.execute(
        select(PushSubscription).where(PushSubscription.endpoint == payload.endpoint)
    ).scalar_one_or_none()

    if existing is not None:
        existing.p256dh = payload.keys.p256dh
        existing.auth = payload.keys.auth
        if user_agent is not None:
            existing.user_agent = user_agent[:255]
        sub = existing
    else:
        sub = PushSubscription(
            endpoint=payload.endpoint,
            p256dh=payload.keys.p256dh,
            auth=payload.keys.auth,
            user_agent=user_agent[:255] if user_agent else None,
        )
        db.add(sub)

    db.commit()
    db.refresh(sub)
    structlog.contextvars.bind_contextvars(push_subscription_id=sub.id, action="push_subscribe")
    return {"id": sub.id, "endpoint": sub.endpoint}


class UnsubscribePayload(BaseModel):
    endpoint: str = Field(min_length=1)


@pwa_router.post(
    "/pwa/unsubscribe",
    dependencies=[Depends(require_session), Depends(require_csrf)],
    status_code=status.HTTP_204_NO_CONTENT,
)
def unsubscribe(payload: UnsubscribePayload, db: DbSession) -> None:
    """Delete a subscription by endpoint URL.

    POST (not DELETE) because the inbox JS sends the endpoint in the
    request body and DELETE-with-body has spotty fetch / proxy support.
    """
    structlog.contextvars.bind_contextvars(action="push_unsubscribe")
    db.execute(delete(PushSubscription).where(PushSubscription.endpoint == payload.endpoint))
    db.commit()
