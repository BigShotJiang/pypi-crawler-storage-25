"""Settings UI for routing rules (PRD §7; ROADMAP v1.5).

A routing rule maps ``(source, priority)`` → :class:`~agentdrop.models.Channel`.
The matcher / precedence logic is owned by
:mod:`agentdrop.notifications.resolver` (parallel agent). This module is
purely the CRUD surface behind ``/settings/routing``.

Session-authed, pattern mirrors ``settings_channels.py`` and
``settings_api_keys.py``:

* One template for list + create form (MVP; edit isn't supported — delete
  and recreate is fine and keeps the form a single code path).
* Ordering controls are plain ``POST`` forms (no HTMX yet) that redirect
  303 back to the list. Progressive-enhancement with ``hx-post`` can be
  layered on later without changing the URL shape.
* Source pattern is a free-text input (``"*"`` for wildcard). Priority
  pattern is a ``<select>`` over the four ``Priority`` values plus ``"*"``.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, Form, Request, status
from fastapi.responses import HTMLResponse, RedirectResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentdrop.db.session import get_db
from agentdrop.models import Channel, RoutingRule
from agentdrop.web import templates
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

logger = structlog.get_logger("agentdrop.web.settings_routing")

router = APIRouter(
    prefix="/settings/routing",
    tags=["web-settings"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]

# The five valid values for ``priority_pattern``. Keep in sync with
# ``agentdrop.models._types.Priority`` plus the wildcard sentinel.
PRIORITY_CHOICES: tuple[str, ...] = ("low", "normal", "high", "urgent", "*")
DEFAULT_PRIORITY = "*"
DEFAULT_ORDER = 100


# ---------------------------------------------------------------------------
# Rule loading
# ---------------------------------------------------------------------------


def _list_rules(db: Session) -> list[RoutingRule]:
    """Return rules sorted by ``(order asc, created_at asc)``.

    Agent A ships the canonical version on
    :mod:`agentdrop.notifications.resolver` (``list_rules``); we import
    it lazily so our module still loads if their resolver changes land
    out of order. Falling back to an inline query keeps the UI usable
    in that window — the ordering contract is simple enough that the
    duplicated SELECT can't drift.
    """
    _canonical: Callable[[Session], list[RoutingRule]] | None
    try:
        from agentdrop.notifications.resolver import list_rules as _canonical
    except ImportError:
        _canonical = None

    if _canonical is not None:
        return list(_canonical(db))

    stmt = select(RoutingRule).order_by(RoutingRule.order.asc(), RoutingRule.created_at.asc())
    return list(db.execute(stmt).scalars().all())


def _list_channels(db: Session) -> list[Channel]:
    """Return channels ordered by name for the create-form ``<select>``."""
    return list(db.execute(select(Channel).order_by(Channel.name.asc())).scalars().all())


def _load_rule_or_none(db: Session, rule_id: str) -> RoutingRule | None:
    return db.execute(select(RoutingRule).where(RoutingRule.id == rule_id)).scalar_one_or_none()


# ---------------------------------------------------------------------------
# Render helpers
# ---------------------------------------------------------------------------


def _render_list(
    request: Request,
    db: Session,
    *,
    form_values: dict[str, Any] | None = None,
    errors: dict[str, str] | None = None,
    notice: str | None = None,
    status_code: int = status.HTTP_200_OK,
) -> HTMLResponse:
    rules = _list_rules(db)
    channels = _list_channels(db)
    return templates.TemplateResponse(
        request,
        "settings/routing_list.html",
        {
            "active_section": "routing",
            "section_title": "Routing",
            "rules": rules,
            "channels": channels,
            "priority_choices": PRIORITY_CHOICES,
            "default_priority": DEFAULT_PRIORITY,
            "default_order": DEFAULT_ORDER,
            "form": form_values
            or {
                "source_pattern": "",
                "priority_pattern": DEFAULT_PRIORITY,
                "channel_id": "",
                "order": str(DEFAULT_ORDER),
            },
            "errors": errors or {},
            "notice": notice,
        },
        status_code=status_code,
    )


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------


@router.get("", response_class=HTMLResponse)
def list_routing_rules(
    request: Request,
    db: DbSession,
    notice: str | None = None,
) -> HTMLResponse:
    return _render_list(request, db, notice=notice)


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------


@router.post("", response_class=HTMLResponse, response_model=None)
def create_routing_rule(
    request: Request,
    db: DbSession,
    source_pattern: Annotated[str, Form()],
    priority_pattern: Annotated[str, Form()],
    channel_id: Annotated[str, Form()],
    order: Annotated[str, Form()] = str(DEFAULT_ORDER),
) -> HTMLResponse | RedirectResponse:
    errors: dict[str, str] = {}

    source_pattern = source_pattern.strip()
    priority_pattern = priority_pattern.strip()
    channel_id = channel_id.strip()
    order_raw = (order or "").strip()

    if not source_pattern:
        errors["source_pattern"] = "Source pattern is required. Use * for any source."
    elif len(source_pattern) > 64:
        errors["source_pattern"] = "Source pattern is too long (max 64 characters)."

    if priority_pattern not in PRIORITY_CHOICES:
        errors["priority_pattern"] = f"Priority must be one of {list(PRIORITY_CHOICES)}."

    # Channel must exist — the FK would 500 otherwise, but a friendly
    # re-render is nicer.
    channel: Channel | None = None
    if not channel_id:
        errors["channel_id"] = "Pick a channel."
    else:
        channel = db.execute(select(Channel).where(Channel.id == channel_id)).scalar_one_or_none()
        if channel is None:
            errors["channel_id"] = "Unknown channel."

    # Order is optional on the form; default to 100 if blank.
    if order_raw == "":
        order_int = DEFAULT_ORDER
    else:
        try:
            order_int = int(order_raw)
        except ValueError:
            errors["order"] = "Order must be a whole number."
            order_int = DEFAULT_ORDER

    if errors:
        return _render_list(
            request,
            db,
            form_values={
                "source_pattern": source_pattern,
                "priority_pattern": priority_pattern or DEFAULT_PRIORITY,
                "channel_id": channel_id,
                "order": order_raw or str(DEFAULT_ORDER),
            },
            errors=errors,
            status_code=status.HTTP_400_BAD_REQUEST,
        )

    assert channel is not None  # noqa: S101 — for mypy; errors above would have returned
    rule = RoutingRule(
        source_pattern=source_pattern,
        priority_pattern=priority_pattern,
        channel_id=channel.id,
        order=order_int,
    )
    db.add(rule)
    db.commit()

    return RedirectResponse(
        url="/settings/routing?notice=created",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------


@router.post("/{rule_id}/delete")
def delete_routing_rule(db: DbSession, rule_id: str) -> RedirectResponse:
    rule = _load_rule_or_none(db, rule_id)
    if rule is None:
        return RedirectResponse(
            url="/settings/routing?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    db.delete(rule)
    db.commit()
    return RedirectResponse(
        url="/settings/routing?notice=deleted",
        status_code=status.HTTP_303_SEE_OTHER,
    )


# ---------------------------------------------------------------------------
# Re-ordering
# ---------------------------------------------------------------------------


def _swap_order(db: Session, a: RoutingRule, b: RoutingRule) -> None:
    """Swap ``order`` between two rules in a single commit.

    The ``order`` column is non-unique, so we can write the new values
    directly without worrying about a transient collision violating a
    unique constraint.
    """
    a_order, b_order = a.order, b.order
    a.order = b_order
    b.order = a_order
    db.add(a)
    db.add(b)
    db.commit()


@router.post("/{rule_id}/move-up")
def move_up(db: DbSession, rule_id: str) -> RedirectResponse:
    rule = _load_rule_or_none(db, rule_id)
    if rule is None:
        return RedirectResponse(
            url="/settings/routing?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    rules = _list_rules(db)
    try:
        idx = next(i for i, r in enumerate(rules) if r.id == rule.id)
    except StopIteration:  # pragma: no cover - matched rule above
        return RedirectResponse(
            url="/settings/routing",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    if idx == 0:
        # Already at the top — no-op.
        return RedirectResponse(
            url="/settings/routing",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    _swap_order(db, rules[idx], rules[idx - 1])
    return RedirectResponse(
        url="/settings/routing",
        status_code=status.HTTP_303_SEE_OTHER,
    )


@router.post("/{rule_id}/move-down")
def move_down(db: DbSession, rule_id: str) -> RedirectResponse:
    rule = _load_rule_or_none(db, rule_id)
    if rule is None:
        return RedirectResponse(
            url="/settings/routing?notice=not-found",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    rules = _list_rules(db)
    try:
        idx = next(i for i, r in enumerate(rules) if r.id == rule.id)
    except StopIteration:  # pragma: no cover - matched rule above
        return RedirectResponse(
            url="/settings/routing",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    if idx == len(rules) - 1:
        # Already at the bottom — no-op.
        return RedirectResponse(
            url="/settings/routing",
            status_code=status.HTTP_303_SEE_OTHER,
        )
    _swap_order(db, rules[idx], rules[idx + 1])
    return RedirectResponse(
        url="/settings/routing",
        status_code=status.HTTP_303_SEE_OTHER,
    )
