"""Session-authed admin endpoints for the web UI.

Currently a very thin router: one POST to manually trigger the retention
sweep (PRD §8.4). The scheduler runs the same job on a timer — this
endpoint exists so an operator can force-run it during testing, and so a
future settings page can expose a "Run retention now" button.

Auth posture: every route here sits behind :func:`require_session`. The
manual-trigger surface is deliberately **not** reachable via the Bearer
API-key path (``/api/v1/*``); agents have no business triggering
retention on a user's inbox.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Annotated, Any

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.retention import run_retention
from agentdrop.web.csrf import require_csrf
from agentdrop.web.session import require_session

router = APIRouter(
    prefix="/admin",
    tags=["web-admin"],
    dependencies=[Depends(require_session), Depends(require_csrf)],
)

DbSession = Annotated[Session, Depends(get_db)]


@router.post("/retention/run")
def run_retention_now(db: DbSession) -> dict[str, Any]:
    """Trigger a retention sweep synchronously and return its stats.

    Thin wrapper around :func:`agentdrop.retention.run_retention`. The
    service is idempotent — a second call moments later will return
    zeros for ``soft_deleted`` / ``hard_deleted`` because the first run
    already moved every eligible row.
    """
    settings = get_settings()
    stats = run_retention(
        db,
        retention_days=settings.retention_days,
        tombstone_days=settings.tombstone_days,
    )
    payload = asdict(stats)
    # ``ran_at`` is a datetime; FastAPI will serialize it to ISO-8601 in
    # the JSON response, but we normalise here so tests comparing the
    # raw dict don't need to know about JSON encoding.
    ran_at = payload.get("ran_at")
    if ran_at is not None and hasattr(ran_at, "isoformat"):
        payload["ran_at"] = ran_at.isoformat()
    return payload
