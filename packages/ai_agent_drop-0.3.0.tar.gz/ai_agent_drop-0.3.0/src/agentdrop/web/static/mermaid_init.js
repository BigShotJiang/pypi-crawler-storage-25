// Conditionally initialise Mermaid.
//
// Mermaid is ~1 MB minified. We don't want it on every drop page — only
// drops that actually use `graph TD;`-style fences get the cost. The
// markdown renderer emits ``<div class="mermaid">…</div>`` for mermaid
// fences (see src/agentdrop/web/markdown.py); if none exist on the
// current page, this script is a no-op.
//
// The dynamic import is deferred to `requestIdleCallback` (or a
// `setTimeout(..., 200)` fallback for Safari, which doesn't expose it) so
// the CDN fetch doesn't block first paint or interaction. We also race
// the import against a 5-second timeout: if the CDN is slow or
// unreachable, we log a console warning and leave the code blocks as
// styled `<pre>` (the fence source remains visible inside the
// ``.mermaid`` container's styling). The rendering API itself is
// unchanged — we still call `mermaid.initialize` then `mermaid.run`.
(function () {
  var IMPORT_TIMEOUT_MS = 5000;
  var IDLE_FALLBACK_MS = 200;

  function loadMermaid() {
    if (document.querySelectorAll(".mermaid").length === 0) return;

    var importPromise = import(
      "https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.esm.min.mjs"
    );
    var timeoutPromise = new Promise(function (_, reject) {
      setTimeout(function () {
        reject(new Error("Mermaid load timed out after " + IMPORT_TIMEOUT_MS + "ms"));
      }, IMPORT_TIMEOUT_MS);
    });

    Promise.race([importPromise, timeoutPromise])
      .then(function (mod) {
        var mermaid = mod.default;
        mermaid.initialize({
          startOnLoad: false,
          securityLevel: "strict",
          theme: "neutral",
          fontFamily:
            '"Inter Tight", "Inter", -apple-system, BlinkMacSystemFont, sans-serif',
        });
        return mermaid.run({ querySelector: ".md-body .mermaid, .mermaid" });
      })
      .catch(function (err) {
        // Surface the failure but don't break the page — the fence source
        // remains visible as text under the .mermaid container's styling.
        console.warn("Mermaid init failed:", err);
      });
  }

  function schedule() {
    if (typeof window.requestIdleCallback === "function") {
      window.requestIdleCallback(loadMermaid, { timeout: 2000 });
    } else {
      // Safari (and older browsers) don't expose requestIdleCallback. A
      // 200ms timeout keeps mermaid off the critical render path while
      // still loading promptly enough that scroll-into-view is rare.
      setTimeout(loadMermaid, IDLE_FALLBACK_MS);
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", schedule);
  } else {
    schedule();
  }
})();
