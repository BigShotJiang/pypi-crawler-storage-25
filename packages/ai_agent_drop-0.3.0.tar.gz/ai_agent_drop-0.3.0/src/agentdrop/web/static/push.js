// Settings › Devices — subscribe / unsubscribe flow for Web Push.
//
// The page renders a status banner and an "enable / disable" button
// that reflects the browser's current `PushSubscription` state for
// the active service worker. This script:
//
//   1. Feature-detects Web Push support and Notification permission.
//   2. Fetches the configured VAPID public key from the server.
//   3. Renders one of four states: unsupported / denied / enabled /
//      disabled, and wires the toggle button.
//   4. On enable: requests Notification permission, calls
//      `registration.pushManager.subscribe()`, POSTs the resulting
//      subscription to `/pwa/subscribe`.
//   5. On disable: calls `subscription.unsubscribe()` locally and
//      POSTs the endpoint to `/pwa/unsubscribe` so the server row is
//      removed too.
//
// The DOM contract is documented on the devices page template:
//   #devices-status           — status text, replaced by class changes.
//   #devices-toggle           — the main button.
//   #devices-toggle-label     — button text (replaced on state change).
//   #devices-error            — error message slot; empty = hidden.
//   [data-devices-root]       — the whole PWA-status card, to scope.

(function () {
  "use strict";

  const root = document.querySelector("[data-devices-root]");
  if (!root) {
    return; // Not on the devices page; nothing to do.
  }

  const statusEl = document.getElementById("devices-status");
  const toggleBtn = document.getElementById("devices-toggle");
  const toggleLabel = document.getElementById("devices-toggle-label");
  const errorEl = document.getElementById("devices-error");

  function setError(msg) {
    if (!errorEl) return;
    if (msg) {
      errorEl.textContent = msg;
      errorEl.hidden = false;
    } else {
      errorEl.textContent = "";
      errorEl.hidden = true;
    }
  }

  function setStatus(state, text) {
    if (!statusEl) return;
    statusEl.dataset.state = state;
    statusEl.textContent = text;
  }

  function renderSupportFailure(reason) {
    setStatus("unsupported", reason);
    if (toggleBtn) {
      toggleBtn.hidden = true;
    }
  }

  if (
    !("serviceWorker" in navigator) ||
    !("PushManager" in window) ||
    !("Notification" in window)
  ) {
    renderSupportFailure(
      "This browser does not support Web Push. Try Safari 16+ on iOS, or Chrome / Firefox on desktop.",
    );
    return;
  }

  // Base64url-to-Uint8Array for `applicationServerKey`. The VAPID key we
  // hand the browser must be a BufferSource, not a string — the spec
  // specifically forbids the plain base64url variant the server emits.
  function urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    const raw = atob(base64);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; ++i) {
      bytes[i] = raw.charCodeAt(i);
    }
    return bytes;
  }

  async function fetchVapidKey() {
    const response = await fetch("/pwa/vapid-public-key", {
      credentials: "same-origin",
    });
    if (!response.ok) {
      throw new Error("VAPID key endpoint returned HTTP " + response.status);
    }
    const data = await response.json();
    return data.key || null;
  }

  function csrfToken() {
    const meta = document.querySelector('meta[name="csrf-token"]');
    return meta ? meta.getAttribute("content") || "" : "";
  }

  // Custom error type so the caller can read the HTTP status and the
  // server's text body (if short enough to be useful) without parsing
  // a stringified message. Throw this from postSubscription only.
  class SubscribeError extends Error {
    constructor(status, body) {
      super("subscribe failed: HTTP " + status);
      this.name = "SubscribeError";
      this.status = status;
      this.body = body || "";
    }
  }

  async function postSubscription(subscription) {
    const response = await fetch("/pwa/subscribe", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrfToken(),
      },
      body: JSON.stringify(subscription.toJSON()),
    });
    if (!response.ok) {
      let text = "";
      try {
        text = await response.text();
      } catch (_e) {
        // Body unreadable; fall back to status-only error.
      }
      throw new SubscribeError(response.status, text);
    }
  }

  function showToast(type, message) {
    if (window.AgentDrop && typeof window.AgentDrop.toast === "function") {
      window.AgentDrop.toast({ type: type, message: message });
    }
  }

  function delay(ms) {
    return new Promise(function (resolve) {
      setTimeout(resolve, ms);
    });
  }

  // Wrap postSubscription with the H3 error-surfacing behaviour:
  //   - 503: retry once after a 1s delay; if still failing, toast the
  //          "Push not available — try again in a moment." copy.
  //   - other 4xx/5xx: toast the server's text body (when short) or a
  //          generic "Couldn't enable push notifications…" message.
  // Returns true on success, false on a surfaced failure (so callers
  // can skip the post-success refresh()).
  async function postSubscriptionWithToast(subscription) {
    try {
      await postSubscription(subscription);
      return true;
    } catch (err) {
      if (err && err.status === 503) {
        try {
          await delay(1000);
          await postSubscription(subscription);
          return true;
        } catch (retryErr) {
          showToast("error", "Push not available — try again in a moment.");
          return false;
        }
      }
      let msg = "Couldn't enable push notifications — please try again.";
      if (err && err.body) {
        const body = err.body.trim();
        if (body && body.length > 0 && body.length < 200) {
          msg = body;
        }
      }
      showToast("error", msg);
      return false;
    }
  }

  async function postUnsubscribe(endpoint) {
    const response = await fetch("/pwa/unsubscribe", {
      method: "POST",
      credentials: "same-origin",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrfToken(),
      },
      body: JSON.stringify({ endpoint: endpoint }),
    });
    if (!response.ok) {
      throw new Error("server unsubscribe failed: HTTP " + response.status);
    }
  }

  async function getRegistration() {
    // We register in base.html on every page load, but `ready` waits
    // until an active worker controls the scope — which is what we
    // need for `pushManager` to work.
    return navigator.serviceWorker.ready;
  }

  async function refresh() {
    setError(null);
    if (Notification.permission === "denied") {
      setStatus(
        "denied",
        "Notifications are blocked in this browser. Re-enable them in your site settings to subscribe.",
      );
      toggleBtn.disabled = true;
      toggleLabel.textContent = "Blocked";
      return;
    }

    let registration;
    try {
      registration = await getRegistration();
    } catch (err) {
      renderSupportFailure("Service worker failed to start: " + err.message);
      return;
    }

    const existing = await registration.pushManager.getSubscription();
    if (existing) {
      setStatus("enabled", "Notifications are on for this device.");
      toggleBtn.disabled = false;
      toggleBtn.dataset.action = "disable";
      toggleLabel.textContent = "Disable on this device";
    } else {
      setStatus(
        "disabled",
        "Notifications are off. Enable to receive drops as push notifications on this device.",
      );
      toggleBtn.disabled = false;
      toggleBtn.dataset.action = "enable";
      toggleLabel.textContent = "Enable on this device";
    }
  }

  async function enable() {
    setError(null);
    const permission = await Notification.requestPermission();
    if (permission !== "granted") {
      setError(
        "Permission denied. You'll need to allow notifications in your browser settings.",
      );
      await refresh();
      return;
    }

    const vapidKey = await fetchVapidKey();
    if (!vapidKey) {
      setError(
        "Web Push is not configured on this server. Set AGENTDROP_VAPID_* env vars and restart.",
      );
      return;
    }

    const registration = await getRegistration();
    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(vapidKey),
    });
    const ok = await postSubscriptionWithToast(subscription);
    if (!ok) {
      // Server didn't accept the subscription. Roll back the browser
      // side so the UI accurately reflects the unsubscribed state and
      // the user can retry without a stale `existing` getting in the
      // way of refresh()'s state machine.
      try {
        await subscription.unsubscribe();
      } catch (e) {
        console.warn("agentdrop: rollback unsubscribe failed", e);
      }
      // Also surface the inline error slot for screen-reader users
      // who may miss the toast region focus order.
      setError("Couldn't enable push notifications.");
      await refresh();
      return;
    }
    await refresh();
  }

  async function disable() {
    setError(null);
    const registration = await getRegistration();
    const subscription = await registration.pushManager.getSubscription();
    if (!subscription) {
      await refresh();
      return;
    }
    const endpoint = subscription.endpoint;
    await subscription.unsubscribe();
    try {
      await postUnsubscribe(endpoint);
    } catch (err) {
      // Browser already forgot the subscription; surfacing a server
      // error here would be misleading. Log for operator awareness.
      console.warn("agentdrop: server unsubscribe failed", err);
    }
    await refresh();
  }

  toggleBtn.addEventListener("click", async () => {
    toggleBtn.disabled = true;
    try {
      if (toggleBtn.dataset.action === "enable") {
        await enable();
      } else {
        await disable();
      }
    } catch (err) {
      console.error("agentdrop push toggle failed", err);
      setError(err && err.message ? err.message : "Something went wrong.");
      toggleBtn.disabled = false;
    }
  });

  refresh().catch((err) => {
    console.error("agentdrop: initial refresh failed", err);
    setError(err && err.message ? err.message : "Could not read subscription state.");
  });
})();
