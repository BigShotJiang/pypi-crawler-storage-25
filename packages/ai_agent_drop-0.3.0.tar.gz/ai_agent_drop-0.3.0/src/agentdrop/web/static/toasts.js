// Agent Drop — global toast region.
//
// One singleton container (`#toasts`) lives in the page's <body>; this
// script attaches `window.AgentDrop.toast({type, message, timeoutMs})`
// for callers (push.js, confirm dialogs, ad-hoc) and listens globally
// for HTMX 4xx/5xx responses so any failed action surfaces a toast
// without each call site duplicating the wiring.
//
// Types:
//   - "info"   — neutral paper background, default 5000ms auto-dismiss.
//   - "error"  — peach-tinted edge, default 8000ms auto-dismiss.
//
// Each toast carries a manual close button labelled "Dismiss". The
// container has `aria-live="polite" aria-atomic="false"` so newly
// appended toasts are announced one at a time without re-reading
// older ones.
//
// Keep this file framework-free: no HTMX dependency for the manual
// toast() call (the HTMX listener is feature-detected, but the rest
// of the API is plain DOM).

(function () {
  "use strict";

  const DEFAULT_TIMEOUTS = {
    info: 5000,
    error: 8000,
  };

  function getContainer() {
    return document.getElementById("toasts");
  }

  function dismiss(toastEl) {
    if (!toastEl || !toastEl.parentNode) return;
    toastEl.classList.add("toast--leaving");
    // Wait one transition frame, then remove from the DOM. We use a
    // hard fallback of 240ms so a misconfigured CSS transition can't
    // strand the node forever.
    const remove = () => {
      if (toastEl.parentNode) {
        toastEl.parentNode.removeChild(toastEl);
      }
    };
    let removed = false;
    const onEnd = () => {
      if (removed) return;
      removed = true;
      toastEl.removeEventListener("transitionend", onEnd);
      remove();
    };
    toastEl.addEventListener("transitionend", onEnd);
    setTimeout(onEnd, 240);
  }

  function toast(opts) {
    opts = opts || {};
    const type = opts.type === "error" ? "error" : "info";
    const message = (opts.message || "").toString();
    if (!message) return null;
    const timeoutMs =
      typeof opts.timeoutMs === "number" && opts.timeoutMs >= 0
        ? opts.timeoutMs
        : DEFAULT_TIMEOUTS[type];

    const container = getContainer();
    if (!container) {
      // No region in the DOM (e.g. an unusual standalone page); fall
      // back to console so we don't swallow important errors silently.
      console.warn("agentdrop: #toasts region missing, dropping toast", message);
      return null;
    }

    const toastEl = document.createElement("div");
    toastEl.className = "toast toast--" + type;
    toastEl.setAttribute("role", "status");

    const msgEl = document.createElement("div");
    msgEl.className = "toast__message";
    msgEl.textContent = message;
    toastEl.appendChild(msgEl);

    const closeBtn = document.createElement("button");
    closeBtn.type = "button";
    closeBtn.className = "toast__close";
    closeBtn.setAttribute("aria-label", "Dismiss");
    closeBtn.textContent = "×"; // multiplication sign as close glyph
    closeBtn.addEventListener("click", function () {
      dismiss(toastEl);
    });
    toastEl.appendChild(closeBtn);

    container.appendChild(toastEl);

    if (timeoutMs > 0) {
      setTimeout(function () {
        dismiss(toastEl);
      }, timeoutMs);
    }

    return toastEl;
  }

  window.AgentDrop = window.AgentDrop || {};
  window.AgentDrop.toast = toast;

  // ----- Global HTMX error listener --------------------------------
  //
  // Any 4xx/5xx response on an HTMX-driven request fires
  // `htmx:responseError`. We surface a generic toast unless the
  // server returned a short text/plain body (under 200 chars), in
  // which case we use that — handy for one-off messages without
  // shipping a JSON envelope.
  function defaultErrorMessage(xhr) {
    if (!xhr) return "Something went wrong — please try again.";
    const contentType = (xhr.getResponseHeader("content-type") || "").toLowerCase();
    if (contentType.indexOf("text/plain") !== -1) {
      const body = (xhr.responseText || "").trim();
      if (body && body.length > 0 && body.length < 200) {
        return body;
      }
    }
    return "Something went wrong — please try again.";
  }

  document.body.addEventListener("htmx:responseError", function (evt) {
    const xhr = evt && evt.detail ? evt.detail.xhr : null;
    toast({ type: "error", message: defaultErrorMessage(xhr) });
  });
})();
