// Agent Drop service worker.
//
// Responsibilities:
//   - Claim the root scope so the page is recognised as a PWA and is
//     installable on iOS / Android.
//   - Handle `push` events: decode the payload written by the
//     ``web_push`` driver and surface a system notification.
//   - Handle `notificationclick`: focus an existing tab already on the
//     drop URL, or open a new one. This is the one-tap flow motivation.
//
// The wire format for push payloads is the tiny JSON object produced by
// ``agentdrop/notifications/web_push.py``:
//   { title, body, url, drop_id }

const VERSION = "agentdrop-pwa-v1";

self.addEventListener("install", (event) => {
  // Take over from any older worker version immediately on install.
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  // Claim open clients so the very first navigation after install is
  // already controlled by this worker (otherwise the user has to reload).
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", (event) => {
  // No event.data is extremely rare (some push services send "wake-up"
  // pushes with no body). Show a generic fallback so the user still
  // sees something rather than a silent, unexplained permission use.
  let payload = { title: "Agent Drop", body: "New drop", url: "/", drop_id: null };
  if (event.data) {
    try {
      payload = { ...payload, ...event.data.json() };
    } catch (_err) {
      // Malformed payload — fall back to the plain-text body.
      payload.body = event.data.text() || payload.body;
    }
  }

  const options = {
    body: payload.body,
    // `data` rides along to the click handler so we don't have to parse
    // the payload twice.
    data: { url: payload.url, drop_id: payload.drop_id },
    icon: "/static/icons/icon-192.png",
    badge: "/static/icons/icon-192.png",
    // Coalesce successive pushes for the same drop (e.g. a retry) onto
    // one notification so the user doesn't see duplicates stack up.
    tag: payload.drop_id || undefined,
    renotify: Boolean(payload.drop_id),
  };

  event.waitUntil(self.registration.showNotification(payload.title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();

  const targetUrl = (event.notification.data && event.notification.data.url) || "/";

  event.waitUntil(
    (async () => {
      const all = await self.clients.matchAll({
        type: "window",
        includeUncontrolled: true,
      });

      // If any open tab is already on this drop URL, focus it.
      for (const client of all) {
        try {
          const clientUrl = new URL(client.url);
          const target = new URL(targetUrl, self.location.origin);
          if (clientUrl.href === target.href) {
            return client.focus();
          }
        } catch (_err) {
          // Non-http URLs (about:blank, etc.) can't be compared — skip.
        }
      }

      // Otherwise open a fresh window. ``openWindow`` accepts absolute
      // or same-origin relative URLs.
      return self.clients.openWindow(targetUrl);
    })(),
  );
});
