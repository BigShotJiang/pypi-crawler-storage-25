// Suppress navigation on in-body markdown links.
//
// Drops are self-contained. External navigation is funneled through the
// drop's dedicated "Open original" card (drop.external_url), not inline
// markdown links — so we render <a> for affordance but no-op the click.
// See design_handoff_agent_drop/README.md: "Markdown renderer > a".
(function () {
  function bind() {
    document.querySelectorAll(".md-body a").forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault();
      });
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", bind);
  } else {
    bind();
  }
})();
