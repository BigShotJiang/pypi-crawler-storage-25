from functools import lru_cache
from pathlib import Path
from typing import Self

from pydantic import model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="AGENTDROP_", case_sensitive=False)

    base_url: str = "http://localhost:8080"
    api_key: str | None = None
    data_dir: Path = Path("/data")
    database_url: str | None = None

    # Logging (issue #16 L4). ``env`` switches the structlog renderer:
    # ``"dev"`` / ``"development"`` get the pretty console renderer,
    # anything else (``"prod"``, ``"production"``, ``"staging"``) gets
    # JSON. ``log_level`` is the root level for stdlib + structlog.
    # ``log_json`` overrides the env-derived choice when explicitly set.
    env: str = "dev"
    log_level: str = "INFO"
    log_json: bool | None = None

    # Admin session auth (PRD §8.5). ``admin_password`` is plaintext on the
    # env; the session module hashes it once at first use and caches the hash.
    # ``secret_key`` signs the session cookie; if unset we generate an
    # ephemeral one at startup (sessions invalidate on restart).
    admin_password: str | None = None
    secret_key: str | None = None

    # Retention / lifecycle (PRD §8.4). Defaults: 30 days active, then 60
    # days as a cleared-content tombstone, then the row is purged. See
    # ``agentdrop.retention`` for the actual sweep logic. The scheduler in
    # ``agentdrop.scheduler`` picks these up at app startup and runs every
    # ``retention_interval_hours``. ``retention_disabled`` short-circuits
    # the scheduler entirely — tests and one-shot CLI invocations set this
    # so nothing fires in the background.
    retention_days: int = 30
    tombstone_days: int = 60
    retention_interval_hours: int = 1
    retention_disabled: bool = False

    # Path to the advisory file lock that ensures the retention scheduler
    # runs in exactly one uvicorn worker (issue #14 F1). Each worker
    # process tries to acquire this lock at startup with ``fcntl.flock``
    # ``LOCK_EX | LOCK_NB``; whichever wins runs the sweep, the rest log
    # a debug line and skip the scheduler. Single-host self-hosted target
    # — the file lives under ``data_dir`` so it's bind-mounted alongside
    # the database in compose, which means it survives restarts but not
    # ``docker compose down`` (the lock is process-bound anyway, so a
    # stale path with no holder is fine).
    scheduler_lock_path: Path | None = None

    # Web Push / VAPID (v1.5). Both keys are EC P-256, base64url-encoded;
    # generate them once with ``make vapid-keys`` and paste into ``.env``.
    # ``vapid_subject`` is the contact URI browsers use to reach the
    # operator if a subscription misbehaves — ``mailto:you@host`` is fine.
    # All three must be set for the ``web_push`` driver to register; if
    # any is missing the driver is skipped at startup with a warning.
    vapid_public_key: str | None = None
    vapid_private_key: str | None = None
    vapid_subject: str | None = None

    # Set to True (env: AGENTDROP_INSECURE_COOKIES=1) to disable the
    # ``Secure`` flag on the session cookie for local HTTP development.
    # Defaults to False (cookie marked Secure).
    insecure_cookies: bool = False

    # Set to True (env: AGENTDROP_TRUST_PROXY_HEADERS=1) when running
    # behind a trusted reverse proxy that sets ``X-Forwarded-For``. The
    # rate limiter and other client-IP-keyed code will then honour the
    # first entry of that header instead of the direct socket peer.
    # Default False so a misconfigured public deployment can't be spoofed.
    trust_proxy_headers: bool = False

    # Set to True (env: AGENTDROP_ALLOW_PRIVATE_OUTBOUND=1) to skip the
    # SSRF guard on user-configured outbound URLs (webhook / Apprise raw
    # HTTP / web push). Required for legitimate internal-network use
    # cases — e.g. a webhook posting to Home Assistant on the same docker
    # network. Default False: any URL resolving to private/loopback/
    # link-local space is rejected at config save and at send time.
    allow_private_outbound: bool = False

    # Encryption-at-rest for channel provider tokens (issue #17). 32-byte
    # url-safe-base64 key. Generate with:
    #   python -c "import secrets, base64; \
    #     print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"
    # ``encryption_key_prev`` is a decrypt-only fallback used during a key
    # rotation: set the new key as ``encryption_key`` and the old one as
    # ``_PREV`` so reads keep working, run ``agentdrop crypto rotate`` to
    # re-encrypt every row with the new key, then drop ``_PREV``.
    encryption_key: str | None = None
    encryption_key_prev: str | None = None

    # Cap on subscriptions processed per Web Push send (env:
    # AGENTDROP_MAX_PUSH_SUBSCRIPTIONS). The Web Push driver iterates the
    # ``push_subscriptions`` table per drop. Without a cap, 1000 devices
    # means 1000 serial POSTs blocking the request thread. Set this above
    # your real device count plus headroom; if exceeded, the driver logs a
    # warning and skips the rest. Long term: move to a background queue.
    max_push_subscriptions: int = 100

    # Per-API-key cap on POST /api/v1/drops (env:
    # AGENTDROP_DROPS_RATE_LIMIT_PER_HOUR). Returns 429 with
    # ``Retry-After`` when exceeded. Tune up for high-volume agents,
    # down to mitigate a leaked key.
    drops_rate_limit_per_hour: int = 100

    # Per-IP cap on GET /d/{short_id} (env:
    # AGENTDROP_DROP_READ_RATE_LIMIT_PER_MIN). Drop URLs are unguessable
    # but a known one is trivially DoS-able by hammering it. Returns 429
    # with ``Retry-After`` when exceeded.
    drop_read_rate_limit_per_min: int = 100

    def effective_database_url(self) -> str:
        """Return the configured database URL or synthesize a SQLite URL from data_dir."""
        if self.database_url:
            return self.database_url
        return f"sqlite:///{self.data_dir}/agentdrop.db"

    def effective_scheduler_lock_path(self) -> Path:
        """Return the configured lock path or default to ``<data_dir>/.scheduler.lock``."""
        if self.scheduler_lock_path is not None:
            return self.scheduler_lock_path
        return self.data_dir / ".scheduler.lock"

    @model_validator(mode="after")
    def _validate_vapid_all_or_none(self) -> Self:
        """VAPID: all three fields must be set together, or all left unset.

        A partial config (e.g. public+private without a subject) produces a
        cryptic ``pywebpush`` error at first send. Reject it at startup with
        a message that names the missing fields. See issue #14 E3.
        """
        fields = {
            "vapid_public_key": self.vapid_public_key,
            "vapid_private_key": self.vapid_private_key,
            "vapid_subject": self.vapid_subject,
        }
        set_fields = [name for name, value in fields.items() if value]
        # All-empty and all-set are both fine. Anything in between is not.
        if 0 < len(set_fields) < len(fields):
            missing = sorted(name for name, value in fields.items() if not value)
            raise ValueError(
                "VAPID config is partial: all of vapid_public_key, vapid_private_key, "
                "and vapid_subject must be set together, or all left unset. "
                f"Missing: {', '.join(missing)}."
            )
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()
