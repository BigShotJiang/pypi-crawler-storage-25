"""ORM model for stored Web Push subscriptions.

Each row represents one device that has called ``pushManager.subscribe()``
on its service worker and POSTed the resulting subscription to
``/pwa/subscribe``. The ``web_push`` driver iterates over every active
row when sending a drop notification.

v1 is single-admin so there's no ``user_id`` column yet — every row
implicitly belongs to "the admin". When multi-user lands we add the FK
and migrate existing rows to the bootstrap admin.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column

from agentdrop.db.base import Base
from agentdrop.ids import new_id


class PushSubscription(Base):
    """A browser's Web Push subscription, captured per device."""

    __tablename__ = "push_subscriptions"

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("psub"),
    )

    # The push service URL the browser hands us. Globally unique — same
    # browser re-subscribing returns the same endpoint, so we treat it
    # as the natural key for upsert.
    endpoint: Mapped[str] = mapped_column(Text, unique=True, nullable=False)

    # ECDH P-256 public key (base64url), used to encrypt the payload.
    p256dh: Mapped[str] = mapped_column(String(255), nullable=False)
    # 16-byte client auth secret (base64url), also used in the encryption.
    auth: Mapped[str] = mapped_column(String(64), nullable=False)

    # Optional human-readable label so the settings UI can show
    # "iPhone 15 — Safari" instead of an opaque endpoint URL.
    user_agent: Mapped[str | None] = mapped_column(String(255), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    last_used_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True),
        nullable=True,
    )
