"""ORM model for ingestion API keys.

Multiple keys are supported per PRD §8.5 so users can rotate and scope
keys per agent. Only the hash is stored; the plaintext is shown once at
creation time.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column

from agentdrop.db.base import Base
from agentdrop.ids import new_id


class ApiKey(Base):
    """A hashed API key used for ``Authorization: Bearer ...`` on ingestion."""

    __tablename__ = "api_keys"

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("ak"),
    )
    key_hash: Mapped[str] = mapped_column(String, unique=True, index=True, nullable=False)
    label: Mapped[str] = mapped_column(String(120), nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
