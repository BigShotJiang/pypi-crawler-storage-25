"""Shared literal types for the ORM + API layers.

Kept separate from the model modules so Pydantic schemas and route handlers
can import them without pulling in SQLAlchemy.
"""

from __future__ import annotations

from typing import Literal

Priority = Literal["low", "normal", "high", "urgent"]
"""Drop urgency. Maps to provider-specific priorities in the notification layer."""

EventKind = Literal[
    "notification_sent",
    "notification_failed",
    "viewed",
    "acted_on",
]
"""Event kinds recorded against a drop. Extend as new lifecycle events are added."""
