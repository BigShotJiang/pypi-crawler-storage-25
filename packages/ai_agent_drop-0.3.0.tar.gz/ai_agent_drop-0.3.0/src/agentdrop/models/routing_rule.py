"""ORM model for routing rules (PRD §7).

A routing rule maps ``(source, priority)`` tuples to a specific
:class:`~agentdrop.models.channel.Channel`, so different agents or
urgency levels can target different notification backends without the
agents themselves knowing about channel config.

Precedence — when multiple rules match a drop, the *single* highest-
priority rule wins (routing does NOT fan out to multiple channels):

1. Rules with BOTH ``source_pattern`` and ``priority_pattern`` set to
   explicit values (no wildcards).
2. Rules with exactly one wildcard (either source or priority is ``"*"``).
3. Rules with both wildcards (``"*"`` / ``"*"`` — the catch-all band).

Within the same specificity band, ties break on lower ``order`` first,
then oldest ``created_at``. If no rule matches, the resolver falls back
to the default-channel logic in :mod:`agentdrop.notifications.resolver`.

The FK to ``channels`` uses ``ON DELETE CASCADE`` so deleting a channel
also drops any rules pointing at it — the settings UI never has to
deal with orphan rules.
"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Index, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column

from agentdrop.db.base import Base
from agentdrop.ids import new_id


class RoutingRule(Base):
    """A source+priority → channel mapping used by the notification resolver."""

    __tablename__ = "routing_rules"

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("rr"),
    )

    # Exact source value (e.g. ``"thinkr"``) or ``"*"`` for any source
    # (including a drop with ``source = None``).
    source_pattern: Mapped[str] = mapped_column(String(64), nullable=False)

    # One of ``low`` / ``normal`` / ``high`` / ``urgent`` or ``"*"``.
    priority_pattern: Mapped[str] = mapped_column(String(16), nullable=False)

    channel_id: Mapped[str] = mapped_column(
        String(32),
        ForeignKey("channels.id", ondelete="CASCADE"),
        nullable=False,
    )

    # Lower order = higher precedence within the same specificity band.
    # Non-unique — ties are broken by ``created_at``.
    order: Mapped[int] = mapped_column(Integer, nullable=False, default=100)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    __table_args__ = (Index("ix_routing_rules_order_created_at", "order", "created_at"),)
