"""ORM model for drops — the core content surface.

See PRD §8.1 (ingestion payload) and §9 (data model). The public URL
``/d/{short_id}`` uses ``short_id`` — a separate 24-char base62 slug — not
the prefixed primary key.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING

from sqlalchemy import JSON, DateTime, ForeignKey, Index, String, Text, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agentdrop.db.base import Base
from agentdrop.ids import new_id, new_short_id

from ._types import Priority

if TYPE_CHECKING:
    from .channel import Channel


class Drop(Base):
    """A single piece of content posted by an agent."""

    __tablename__ = "drops"

    # Indexes that back the routing resolver (``WHERE source = ?``) and the
    # inbox source-filter (``WHERE source = ? AND priority = ?``). Without
    # these the inbox and resolver fall back to a full table scan once
    # drops accumulate (issue #14, G1).
    __table_args__ = (
        Index("ix_drops_source", "source"),
        Index("ix_drops_source_priority", "source", "priority"),
    )

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("drp"),
    )
    # Public slug used in /d/{short_id}. Unguessable per PRD §8.5.
    short_id: Mapped[str] = mapped_column(
        String(24),
        unique=True,
        index=True,
        default=new_short_id,
    )

    title: Mapped[str] = mapped_column(String(250), nullable=False)
    body: Mapped[str] = mapped_column(String(1024), nullable=False)
    content_md: Mapped[str] = mapped_column(Text, nullable=False, default="")

    source: Mapped[str | None] = mapped_column(String(64), nullable=True)
    tags_json: Mapped[list[str]] = mapped_column(JSON, default=list, nullable=False)
    priority: Mapped[Priority] = mapped_column(String(16), default="normal", nullable=False)
    external_url: Mapped[str | None] = mapped_column(String, nullable=True)

    channel_id: Mapped[str | None] = mapped_column(
        String(32),
        ForeignKey("channels.id", ondelete="SET NULL"),
        nullable=True,
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    pinned_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    read_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    soft_deleted_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    channel: Mapped[Channel | None] = relationship(back_populates="drops")
