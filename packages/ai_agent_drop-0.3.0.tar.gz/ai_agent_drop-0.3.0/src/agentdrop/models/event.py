"""ORM model for drop lifecycle events (debug trail, PRD §9).

Events are append-only. ``drop_id`` is nullable so non-drop-scoped events
(e.g. a scheduled sweep summary) can still be logged.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from sqlalchemy import JSON, DateTime, ForeignKey, String, func
from sqlalchemy.orm import Mapped, mapped_column

from agentdrop.db.base import Base
from agentdrop.ids import new_id


class Event(Base):
    """An append-only record of something that happened to a drop."""

    __tablename__ = "events"

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("evt"),
    )
    drop_id: Mapped[str | None] = mapped_column(
        String(32),
        ForeignKey("drops.id", ondelete="CASCADE"),
        nullable=True,
        index=True,
    )
    kind: Mapped[str] = mapped_column(String(32), nullable=False)
    detail_json: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict, nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
