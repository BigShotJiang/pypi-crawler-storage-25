"""ORM model for notification channels (Pushover, ntfy, Apprise, webhook).

Per-channel driver config lives in ``config_json``. The "only one default"
invariant is enforced at the application layer (see module docstring in
the services module), not the DB — SQLite partial-unique indices aren't
worth the complexity here.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

from sqlalchemy import Boolean, DateTime, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from agentdrop.db.base import Base
from agentdrop.db.encrypted_types import EncryptedJSON
from agentdrop.ids import new_id

if TYPE_CHECKING:
    from .drop import Drop


class Channel(Base):
    """A configured notification backend."""

    __tablename__ = "channels"

    id: Mapped[str] = mapped_column(
        String(32),
        primary_key=True,
        default=lambda: new_id("ch"),
    )
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    driver: Mapped[str] = mapped_column(String(32), nullable=False)
    # Encrypted-at-rest with the configured Fernet key (issue #17). DB-side
    # impl is ``String`` (TEXT); python-side stays ``dict[str, Any]`` so all
    # callers that read/write ``channel.config_json`` keep working unchanged.
    config_json: Mapped[dict[str, Any]] = mapped_column(EncryptedJSON, default=dict, nullable=False)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )

    drops: Mapped[list[Drop]] = relationship(back_populates="channel")
