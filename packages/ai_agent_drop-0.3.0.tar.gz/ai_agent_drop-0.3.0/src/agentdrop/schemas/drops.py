"""Pydantic v2 request/response schemas for the drops API.

See ``PRD.md`` §8.1 for the ingestion payload shape, §8.4 for lifecycle
semantics, and §10 for the full route list. The module intentionally avoids
``from __future__ import annotations`` — Pydantic v2 has edge cases around
PEP 563 that are easier to sidestep by being explicit.
"""

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

from agentdrop.models._types import Priority
from agentdrop.models.drop import Drop

DropState = Literal["unread", "read", "pinned", "archived"]


class DropCreate(BaseModel):
    """Request body for ``POST /api/v1/drops`` (see PRD §8.1)."""

    model_config = ConfigDict(extra="forbid")

    title: str = Field(min_length=1, max_length=250)
    body: str = Field(min_length=1, max_length=1024)
    content: str = Field(min_length=1)
    source: str | None = Field(default=None, max_length=64)
    tags: list[str] = Field(default_factory=list, max_length=16)
    priority: Priority = "normal"
    # Plain str (not HttpUrl) so non-http schemes like ``obsidian://``,
    # ``gh://`` round-trip unchanged — see PRD §8.1 example payloads.
    external_url: str | None = None
    expires_in_days: int | None = Field(default=None, gt=0, le=3650)
    channel: str | None = None

    @classmethod
    def _validate_tags(cls, tags: list[str]) -> list[str]:
        # Runs via the post-parse validator below; see ``model_post_init``
        # on subclasses if more complex invariants emerge.
        return tags


class DropCreateResponse(BaseModel):
    """Minimal response for ``POST /api/v1/drops`` (PRD §8.1 contract)."""

    id: str
    url: str
    created_at: datetime
    warnings: list[str] = Field(default_factory=list)


class DropRead(BaseModel):
    """Full JSON view of a drop — used by GET ``/api/v1/drops/{id}``.

    ``soft_deleted_at`` is deliberately omitted; callers see 404 for
    soft-deleted drops, so exposing the column would leak tombstones.
    """

    model_config = ConfigDict(from_attributes=True)

    id: str
    short_id: str
    url: str
    title: str
    body: str
    content: str
    source: str | None
    tags: list[str]
    priority: Priority
    external_url: str | None
    channel_id: str | None
    created_at: datetime
    expires_at: datetime | None
    pinned_at: datetime | None
    archived_at: datetime | None
    read_at: datetime | None
    state: DropState


class DropUpdate(BaseModel):
    """Request body for ``PATCH /api/v1/drops/{id}``.

    Each field is tri-valued: ``None`` means "leave as-is", ``True`` sets
    the corresponding timestamp to now, ``False`` clears it.
    """

    model_config = ConfigDict(extra="forbid")

    pinned: bool | None = None
    archived: bool | None = None
    read: bool | None = None


class DropListItem(BaseModel):
    """Item in a paginated listing — omits ``content`` to keep payloads small."""

    model_config = ConfigDict(from_attributes=True)

    id: str
    short_id: str
    url: str
    title: str
    body: str
    summary: str
    source: str | None
    tags: list[str]
    priority: Priority
    external_url: str | None
    channel_id: str | None
    created_at: datetime
    expires_at: datetime | None
    pinned_at: datetime | None
    archived_at: datetime | None
    read_at: datetime | None
    state: DropState


class DropListResponse(BaseModel):
    """Paginated response for ``GET /api/v1/drops``."""

    items: list[DropListItem]
    next_cursor: str | None = None
    count: int


def _compute_state(drop: Drop) -> DropState:
    """Collapse the four lifecycle timestamps into a single display state.

    Priority order: archived > pinned > read > unread. Pinned-and-read drops
    still show as pinned because pin is the stronger UI affordance.
    """
    if drop.archived_at is not None:
        return "archived"
    if drop.pinned_at is not None:
        return "pinned"
    if drop.read_at is not None:
        return "read"
    return "unread"


def _public_url(drop: Drop, base_url: str) -> str:
    return f"{base_url.rstrip('/')}/d/{drop.short_id}"


def drop_to_read(drop: Drop, base_url: str) -> DropRead:
    """Project a :class:`Drop` ORM row into the ``DropRead`` schema."""
    return DropRead(
        id=drop.id,
        short_id=drop.short_id,
        url=_public_url(drop, base_url),
        title=drop.title,
        body=drop.body,
        content=drop.content_md,
        source=drop.source,
        tags=list(drop.tags_json or []),
        priority=drop.priority,
        external_url=drop.external_url,
        channel_id=drop.channel_id,
        created_at=drop.created_at,
        expires_at=drop.expires_at,
        pinned_at=drop.pinned_at,
        archived_at=drop.archived_at,
        read_at=drop.read_at,
        state=_compute_state(drop),
    )


def drop_to_list_item(drop: Drop, base_url: str) -> DropListItem:
    """Project a :class:`Drop` ORM row into the list-item schema.

    ``summary`` is the first 200 chars of ``body`` (not ``content_md``) —
    ``body`` is already the short human-readable teaser, ``content_md`` is
    the full rendered payload and is intentionally omitted from list views.
    """
    summary = drop.body[:200]
    return DropListItem(
        id=drop.id,
        short_id=drop.short_id,
        url=_public_url(drop, base_url),
        title=drop.title,
        body=drop.body,
        summary=summary,
        source=drop.source,
        tags=list(drop.tags_json or []),
        priority=drop.priority,
        external_url=drop.external_url,
        channel_id=drop.channel_id,
        created_at=drop.created_at,
        expires_at=drop.expires_at,
        pinned_at=drop.pinned_at,
        archived_at=drop.archived_at,
        read_at=drop.read_at,
        state=_compute_state(drop),
    )
