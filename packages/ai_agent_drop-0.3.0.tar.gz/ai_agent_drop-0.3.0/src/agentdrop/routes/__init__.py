"""HTTP route modules. Each submodule exposes an ``APIRouter`` as ``router``."""

from agentdrop.routes.drops import router as drops_router

__all__ = ["drops_router"]
