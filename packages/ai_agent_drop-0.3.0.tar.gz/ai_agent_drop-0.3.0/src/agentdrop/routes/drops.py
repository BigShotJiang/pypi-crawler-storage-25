"""HTTP routes for ``/api/v1/drops`` (PRD §10).

Covers creation, listing, retrieval, flag updates, and soft-delete. The
POST handler also fires the outbound notification synchronously (M4).
Failures downstream of the DB write never 500 the request — they become
``warnings`` entries on the 201 response per PRD §8.1.
"""

from __future__ import annotations

import base64
import binascii
from datetime import UTC, datetime, timedelta
from typing import Annotated, Literal

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from sqlalchemy import and_, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from agentdrop.auth import require_api_key
from agentdrop.config import Settings, get_settings
from agentdrop.db.session import get_db
from agentdrop.ids import new_short_id
from agentdrop.models import Channel, Drop
from agentdrop.notifications.send import send_drop_notification
from agentdrop.schemas.drops import (
    DropCreate,
    DropCreateResponse,
    DropListResponse,
    DropRead,
    DropUpdate,
    drop_to_list_item,
    drop_to_read,
)
from agentdrop.web.rate_limit import client_ip, rate_limit

router = APIRouter(
    prefix="/api/v1/drops",
    tags=["drops"],
    dependencies=[Depends(require_api_key)],
)


# Typed dependency aliases — using ``Annotated`` here (vs a raw ``Depends(...)``
# default) keeps ruff's B008 quiet and makes each handler's signature shorter.
DbSession = Annotated[Session, Depends(get_db)]
SettingsDep = Annotated[Settings, Depends(get_settings)]


# ---------------------------------------------------------------------------
# Cursor helpers — keyset pagination over (created_at DESC, id DESC).
# Opaque base64 of ``{created_at_iso}|{id}`` so clients can't meaningfully
# rewrite it. Not a security boundary, just a hint that it's opaque.
# ---------------------------------------------------------------------------


def _encode_cursor(created_at: datetime, drop_id: str) -> str:
    raw = f"{created_at.isoformat()}|{drop_id}".encode()
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _decode_cursor(cursor: str) -> tuple[datetime, str]:
    padding = "=" * (-len(cursor) % 4)
    try:
        raw = base64.urlsafe_b64decode(cursor + padding).decode("utf-8")
        created_iso, drop_id = raw.split("|", 1)
        return datetime.fromisoformat(created_iso), drop_id
    except (ValueError, binascii.Error) as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid cursor",
        ) from exc


def _now() -> datetime:
    return datetime.now(UTC)


def _find_channel_by_name(db: Session, name: str) -> Channel | None:
    return db.execute(select(Channel).where(Channel.name == name)).scalar_one_or_none()


def _drops_post_rate_key(request: Request) -> str:
    """Bucket the POST rate limit per API key.

    ``require_api_key`` (router-level dependency) runs first and stashes
    a stable identifier on ``request.state.api_key_id``: ``"env"`` for
    the env-configured key, ``"db:<id>"`` for a UI-managed key. Falls
    back to client IP if for some reason auth didn't run — defensive,
    shouldn't happen in normal flow because the bucket dep can't be
    reached without passing auth.
    """
    api_key_id = getattr(request.state, "api_key_id", None)
    if api_key_id:
        return api_key_id
    return f"ip:{client_ip(request)}"


# Module-level so the bucket persists across requests. Reads settings at
# import time — operators tune via env before starting the process.
_DROPS_POST_RATE_LIMIT = rate_limit(
    "drops_post",
    max_attempts=get_settings().drops_rate_limit_per_hour,
    window_seconds=3600,
    key_builder=_drops_post_rate_key,
    record_on_check=True,
)


# ---------------------------------------------------------------------------
# POST /api/v1/drops
# ---------------------------------------------------------------------------


@router.post(
    "",
    response_model=DropCreateResponse,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(_DROPS_POST_RATE_LIMIT)],
)
def create_drop(
    payload: DropCreate,
    db: DbSession,
    settings: SettingsDep,
) -> DropCreateResponse:
    """Create a new drop and return its id + public URL.

    Notification delivery is best-effort: the drop is always persisted and
    the response is always 201. Every downstream failure surfaces as a
    warning string on the response (see PRD §8.1).

    For MVP the active outbound channel is resolved from env vars, not the
    DB ``channels`` table — that table remains for v1's UI-managed channels
    and still accepts a ``payload.channel`` lookup so callers can tag drops
    with a named channel once populated.
    """
    warnings: list[str] = []

    channel: Channel | None = None
    if payload.channel is not None:
        channel = _find_channel_by_name(db, payload.channel)
        if channel is None:
            warnings.append(f"channel '{payload.channel}' not found")

    now = _now()
    expires_at: datetime | None = None
    if payload.expires_in_days is not None:
        expires_at = now + timedelta(days=payload.expires_in_days)

    def _build() -> Drop:
        return Drop(
            short_id=new_short_id(),
            title=payload.title,
            body=payload.body,
            content_md=payload.content,
            source=payload.source,
            tags_json=list(payload.tags),
            priority=payload.priority,
            external_url=payload.external_url,
            channel_id=channel.id if channel is not None else None,
            expires_at=expires_at,
        )

    drop = _build()
    structlog.contextvars.bind_contextvars(
        drop_short_id=drop.short_id,
        drop_priority=drop.priority,
        drop_source=drop.source,
    )
    db.add(drop)
    try:
        db.commit()
    except IntegrityError:
        # short_id collisions are astronomically rare but handle them: one
        # retry with a fresh id, then 409 if the DB still says no.
        db.rollback()
        drop = _build()
        db.add(drop)
        try:
            db.commit()
        except IntegrityError as exc:
            db.rollback()
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Short-id collision; please retry",
            ) from exc

    db.refresh(drop)
    structlog.contextvars.bind_contextvars(drop_id=drop.id)

    # Fire the outbound push synchronously (sync httpx). Background tasks
    # are a v1 concern; the MVP keeps the request-response simple and the
    # failure surface narrow — everything downstream becomes a warning
    # string rather than a non-201 response.
    warnings.extend(send_drop_notification(drop, settings.base_url, db))

    return DropCreateResponse(
        id=drop.id,
        url=f"{settings.base_url.rstrip('/')}/d/{drop.short_id}",
        created_at=drop.created_at,
        warnings=warnings,
    )


# ---------------------------------------------------------------------------
# GET /api/v1/drops — paginated listing
# ---------------------------------------------------------------------------


StateFilter = Literal["all", "unread", "read", "pinned", "archived"]


@router.get("", response_model=DropListResponse)
def list_drops(
    db: DbSession,
    settings: SettingsDep,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    cursor: Annotated[str | None, Query()] = None,
    source: Annotated[str | None, Query()] = None,
    tag: Annotated[str | None, Query()] = None,
    state: Annotated[StateFilter, Query()] = "all",
) -> DropListResponse:
    """Return drops newest-first, keyset-paginated.

    ``state="all"`` excludes archived by design convention — archived drops
    are hidden from the default inbox per PRD §6.3. Use ``state="archived"``
    to see them explicitly.
    """
    stmt = select(Drop).where(Drop.soft_deleted_at.is_(None))

    if source is not None:
        stmt = stmt.where(Drop.source == source)

    if tag is not None:
        # JSON containment isn't portable; fall back to a LIKE over the
        # serialised JSON. Tags are <=64 chars so false positives are rare
        # and real filtering lands when we add proper indexing.
        stmt = stmt.where(Drop.tags_json.cast(str).like(f'%"{tag}"%'))

    if state == "unread":
        stmt = stmt.where(
            and_(
                Drop.read_at.is_(None),
                Drop.pinned_at.is_(None),
                Drop.archived_at.is_(None),
            )
        )
    elif state == "read":
        stmt = stmt.where(
            and_(
                Drop.read_at.is_not(None),
                Drop.pinned_at.is_(None),
                Drop.archived_at.is_(None),
            )
        )
    elif state == "pinned":
        stmt = stmt.where(and_(Drop.pinned_at.is_not(None), Drop.archived_at.is_(None)))
    elif state == "archived":
        stmt = stmt.where(Drop.archived_at.is_not(None))
    else:  # "all" — inbox default, hide archived
        stmt = stmt.where(Drop.archived_at.is_(None))

    if cursor is not None:
        cur_created, cur_id = _decode_cursor(cursor)
        stmt = stmt.where(
            or_(
                Drop.created_at < cur_created,
                and_(Drop.created_at == cur_created, Drop.id < cur_id),
            )
        )

    stmt = stmt.order_by(Drop.created_at.desc(), Drop.id.desc()).limit(limit)
    drops = list(db.execute(stmt).scalars().all())

    items = [drop_to_list_item(d, settings.base_url) for d in drops]
    next_cursor = (
        _encode_cursor(drops[-1].created_at, drops[-1].id) if len(drops) == limit else None
    )
    return DropListResponse(items=items, next_cursor=next_cursor, count=len(items))


# ---------------------------------------------------------------------------
# GET /api/v1/drops/{drop_id}
# ---------------------------------------------------------------------------


def _load_live_drop(db: Session, drop_id: str) -> Drop:
    drop = db.execute(
        select(Drop).where(and_(Drop.id == drop_id, Drop.soft_deleted_at.is_(None)))
    ).scalar_one_or_none()
    if drop is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Drop not found")
    return drop


@router.get("/{drop_id}", response_model=DropRead)
def get_drop(
    drop_id: str,
    db: DbSession,
    settings: SettingsDep,
) -> DropRead:
    structlog.contextvars.bind_contextvars(drop_id=drop_id)
    drop = _load_live_drop(db, drop_id)
    return drop_to_read(drop, settings.base_url)


# ---------------------------------------------------------------------------
# PATCH /api/v1/drops/{drop_id}
# ---------------------------------------------------------------------------


@router.patch("/{drop_id}", response_model=DropRead)
def update_drop(
    drop_id: str,
    payload: DropUpdate,
    db: DbSession,
    settings: SettingsDep,
) -> DropRead:
    """Toggle ``pinned`` / ``archived`` / ``read`` flags.

    Each field is tri-valued: ``None`` = leave-as-is, ``True`` = set the
    timestamp to now, ``False`` = clear the timestamp.
    """
    drop = _load_live_drop(db, drop_id)
    now = _now()

    if payload.pinned is not None:
        drop.pinned_at = now if payload.pinned else None
    if payload.archived is not None:
        drop.archived_at = now if payload.archived else None
    if payload.read is not None:
        drop.read_at = now if payload.read else None

    db.commit()
    db.refresh(drop)
    return drop_to_read(drop, settings.base_url)


# ---------------------------------------------------------------------------
# DELETE /api/v1/drops/{drop_id} — soft delete
# ---------------------------------------------------------------------------


@router.delete("/{drop_id}")
def delete_drop(
    drop_id: str,
    db: DbSession,
) -> dict[str, object]:
    """Soft-delete a drop and clear its content synchronously.

    Mirrors the retention sweep's soft-delete phase (PRD §8.4): sets
    ``soft_deleted_at = now`` and clears ``content_md`` / ``body``. The
    user pressed delete — they expect the content gone *now*, not on the
    next retention tick. ``title``, ``source``, and ``tags_json`` are
    preserved as audit metadata, matching ``agentdrop.retention``.

    Both the timestamp and the content-clear happen in the same
    transaction, so a crash mid-write can't leave a row that's flagged
    deleted but still has content. The FTS5 update trigger fires once
    on commit and re-indexes the now-empty body / content_md, which
    drops the row out of full-text search results.
    """
    drop = _load_live_drop(db, drop_id)
    drop.soft_deleted_at = _now()
    drop.content_md = ""
    drop.body = ""
    db.commit()
    db.refresh(drop)
    return {"id": drop.id, "soft_deleted_at": drop.soft_deleted_at}
