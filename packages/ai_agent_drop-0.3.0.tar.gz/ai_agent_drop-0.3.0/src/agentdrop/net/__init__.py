"""Network-level helpers (SSRF validation, etc.)."""
