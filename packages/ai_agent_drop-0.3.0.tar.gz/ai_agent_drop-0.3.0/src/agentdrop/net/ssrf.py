"""Outbound URL validation to block SSRF.

Drivers that fire user-configured outbound HTTP (webhook, Apprise, web
push) call :func:`validate_outbound_url` to refuse URLs that resolve to
private/loopback/link-local/multicast/unspecified/reserved address space
— otherwise an authenticated admin (or compromised client, in the web
push case) could turn the server into an SSRF launchpad against internal
services.

Validation runs at config save time **and** immediately before each
outbound HTTP call. The send-time re-validation defends against DNS
rebinding, where a hostname resolves public at config time but private
at send time.

Operators with a legitimate internal-webhook use case (Home Assistant on
the same docker network, etc.) opt out via
``AGENTDROP_ALLOW_PRIVATE_OUTBOUND=1``.
"""

from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlparse

from agentdrop.config import get_settings

# Apprise's "raw HTTP" schemes wrap arbitrary user-controllable hosts;
# treat them like webhook URLs. Service-specific schemes (``pover://``,
# ``tgram://``, ``mailto://`` …) point at hardcoded provider endpoints
# and aren't user-controllable for SSRF — skip those.
_RAW_HTTP_SCHEMES = frozenset({"http", "https", "json", "jsons", "xml", "xmls", "form", "forms"})

_BLOCKED_HOSTNAMES = frozenset({"localhost", "ip6-localhost", "ip6-loopback", "broadcasthost"})


class OutboundUrlError(ValueError):
    """Raised when an outbound URL fails SSRF validation."""


def _is_blocked_address(addr: str) -> bool:
    try:
        ip = ipaddress.ip_address(addr)
    except ValueError:
        return True
    return (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_unspecified
        or ip.is_reserved
    )


def _resolve(hostname: str) -> list[str]:
    """Return all IPs ``getaddrinfo`` reports for ``hostname``."""
    infos = socket.getaddrinfo(hostname, None)
    return [str(info[4][0]) for info in infos]


def validate_outbound_url(url: str, *, allow_private: bool | None = None) -> None:
    """Validate that ``url`` is safe for outbound HTTP from the server.

    Schemes outside ``_RAW_HTTP_SCHEMES`` (e.g. Apprise's ``pover://``)
    are passed through — their destinations are service-internal and not
    user-controllable.

    Args:
        url: The URL to validate.
        allow_private: Override for the ``AGENTDROP_ALLOW_PRIVATE_OUTBOUND``
            setting. ``None`` (default) reads from settings.

    Raises:
        OutboundUrlError: hostname or any resolved address is in the
            blocklist, the URL is malformed, or DNS resolution failed.
    """
    if allow_private is None:
        allow_private = get_settings().allow_private_outbound

    if not url:
        raise OutboundUrlError("URL is empty")

    try:
        parsed = urlparse(url)
    except ValueError as exc:
        raise OutboundUrlError(f"Malformed URL: {exc}") from exc

    if parsed.scheme.lower() not in _RAW_HTTP_SCHEMES:
        return

    if allow_private:
        return

    hostname = parsed.hostname
    if not hostname:
        raise OutboundUrlError("URL has no hostname")

    hostname_lower = hostname.lower()
    if hostname_lower in _BLOCKED_HOSTNAMES or hostname_lower.endswith(".local"):
        raise OutboundUrlError(f"Hostname is blocked: {hostname}")

    # Encode IDN to ASCII so DNS sees the same bytes the operator typed —
    # rejects homographs that would otherwise resolve to a different host
    # than the rendered string suggests.
    try:
        ascii_host = hostname.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise OutboundUrlError(f"Invalid IDN hostname: {hostname}") from exc

    try:
        ip = ipaddress.ip_address(ascii_host)
    except ValueError:
        ip = None

    if ip is not None:
        if _is_blocked_address(str(ip)):
            raise OutboundUrlError(f"IP address is blocked: {ip}")
        return

    try:
        addrs = _resolve(ascii_host)
    except socket.gaierror as exc:
        raise OutboundUrlError(f"DNS lookup failed for {hostname}: {exc}") from exc

    if not addrs:
        raise OutboundUrlError(f"DNS lookup returned no addresses for {hostname}")

    for addr in addrs:
        if _is_blocked_address(addr):
            raise OutboundUrlError(f"{hostname} resolves to blocked address {addr}")
