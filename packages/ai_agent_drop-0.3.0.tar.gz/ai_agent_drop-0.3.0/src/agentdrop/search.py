"""Full-text search over drops.

The inbox's ``?q=`` parameter used to be a case-insensitive LIKE on title
and source only. That's narrow and surprising — users typed words they
remembered from the *body* or *content* and got nothing back. This module
replaces that code path with a real full-text index on SQLite (FTS5) and
a broadened LIKE fallback for Postgres installations.

Dispatch is by dialect:

* ``sqlite`` → :func:`search_drops_sqlite`, which joins ``drops`` against
  the ``drops_fts`` virtual table created in the
  ``add_drops_fts5_index`` migration. Ordered by ``rank`` (FTS5's
  relevance score — smaller is better).
* Anything else → :func:`search_drops_like`. Broader than the old code
  (title + body + source + tags) but still doesn't scan ``content_md``
  — a LIKE over full markdown is O(n) per row and a foot-gun at scale.
  Postgres gets a proper tsvector-based search in a follow-up; see
  ``ROADMAP.md`` under "Known tech debt".

The user's query is not FTS5 query syntax. They expect to type words.
:func:`_sanitize_fts_query` strips FTS5's meta-characters and re-joins
the remaining tokens with spaces so two tokens on either side of e.g.
``foo"bar:baz*`` get interpreted as implicit AND'd search terms.
"""

from __future__ import annotations

from typing import Literal

from sqlalchemy import and_, column, func, or_, select, table, text
from sqlalchemy.orm import Session

from agentdrop.models import Drop

# Lightweight SQLAlchemy Core handle for the FTS5 virtual table. We only
# need ``drop_id`` and ``rank`` for the join / ordering; FTS5 exposes
# ``rank`` as a hidden column on every row.
_drops_fts = table(
    "drops_fts",
    column("drop_id"),
    column("rank"),
)

# Mirrors the inbox's state enum (see ``agentdrop.web.inbox.InboxState``).
# Duplicated here rather than imported to keep search decoupled from the
# web layer — this module should be reusable from a future API endpoint.
SearchState = Literal["all", "unread", "pinned", "archived"]

# Hard cap for MVP. No cursor UI yet; the inbox caller deliberately skips
# pagination on the search path.
DEFAULT_LIMIT = 100

# FTS5 operators / characters that break query parsing when a user just
# wants to type words. We strip these rather than escape — the user's
# intent is "find the word I typed", not "this is a literal phrase".
# Covers: double-quote (phrase), colon (column filter), asterisk (prefix),
# caret (proximity weight), and parens (grouping).
_FTS_SPECIAL_CHARS = str.maketrans({c: " " for c in '":*^()'})


def _sanitize_fts_query(raw: str) -> str:
    """Strip FTS5 operators and collapse whitespace.

    Returns an empty string when the query has no searchable tokens left
    (e.g. the user typed only punctuation). Callers should short-circuit
    to "no search" in that case.
    """
    cleaned = raw.translate(_FTS_SPECIAL_CHARS)
    # Split on any whitespace, drop empties, re-join with single spaces.
    # FTS5 treats adjacent tokens as implicit AND by default, which is
    # what the user expects when they type two words.
    tokens = cleaned.split()
    return " ".join(tokens)


def _state_clause(state: SearchState):
    """SQL predicate matching the inbox's state filter.

    Kept in step with :func:`agentdrop.web.inbox._state_clause` — whichever
    path renders the inbox, state semantics are identical.
    """
    if state == "unread":
        return and_(Drop.read_at.is_(None), Drop.archived_at.is_(None))
    if state == "pinned":
        return and_(Drop.pinned_at.is_not(None), Drop.archived_at.is_(None))
    if state == "archived":
        return Drop.archived_at.is_not(None)
    return Drop.archived_at.is_(None)


def search_drops_sqlite(
    db: Session,
    *,
    q: str,
    source: str | None = None,
    state: SearchState = "all",
    limit: int = DEFAULT_LIMIT,
) -> list[Drop]:
    """FTS5 search path. Assumes ``q`` is already sanitized and non-empty.

    Joins ``drops`` against the ``drops_fts`` virtual table via
    ``drop_id`` (not ``rowid`` — see the migration for why). Soft-deleted
    rows are filtered *after* the FTS match: the update trigger clears
    body / content_md on soft-delete anyway, so those rows wouldn't match
    on real query text, but the explicit filter keeps the contract tight.
    """
    # FTS5 exposes MATCH as an operator on the virtual-table name.
    # ``text("drops_fts MATCH :fts_q")`` binds the query as a parameter so
    # SQLAlchemy doesn't try to quote-escape the MATCH expression.
    fts_match = text("drops_fts MATCH :fts_q").bindparams(fts_q=q)

    stmt = (
        select(Drop)
        .join(_drops_fts, _drops_fts.c.drop_id == Drop.id)
        .where(fts_match)
        .where(Drop.soft_deleted_at.is_(None))
        .where(_state_clause(state))
    )

    if source is not None:
        stmt = stmt.where(Drop.source == source)

    # FTS5's ``rank`` column is smallest-is-best. Tie-break on created_at
    # so newer drops win ties — feels right for an inbox.
    stmt = stmt.order_by(_drops_fts.c.rank, Drop.created_at.desc()).limit(limit)

    return list(db.execute(stmt).scalars().all())


def search_drops_like(
    db: Session,
    *,
    q: str,
    source: str | None = None,
    state: SearchState = "all",
    limit: int = DEFAULT_LIMIT,
) -> list[Drop]:
    """Fallback for non-SQLite backends. Broader LIKE than the old code.

    Covers title + body + source + tags_json (as a serialized string,
    which is enough for tag-word matching). Deliberately skips
    ``content_md`` — LIKE over full markdown is a foot-gun. Postgres
    installs lose content-body search until the tsvector path lands.
    """
    like = f"%{q.lower()}%"
    stmt = (
        select(Drop)
        .where(Drop.soft_deleted_at.is_(None))
        .where(_state_clause(state))
        .where(
            or_(
                func.lower(Drop.title).like(like),
                func.lower(Drop.body).like(like),
                func.lower(Drop.source).like(like),
                # ``tags_json`` is a JSON column. CAST to text so LIKE works
                # across dialects; the serialized form contains tag strings
                # plus JSON punctuation, which LIKE handles fine.
                func.lower(func.cast(Drop.tags_json, Drop.title.type)).like(like),
            )
        )
    )

    if source is not None:
        stmt = stmt.where(Drop.source == source)

    stmt = stmt.order_by(Drop.created_at.desc(), Drop.id.desc()).limit(limit)
    return list(db.execute(stmt).scalars().all())


def search_drops(
    db: Session,
    *,
    q: str,
    source: str | None = None,
    state: SearchState = "all",
    limit: int = DEFAULT_LIMIT,
) -> list[Drop]:
    """Dispatch to the right search implementation for the active dialect.

    Returns ``[]`` when ``q`` is empty after sanitization — callers should
    treat an empty query as "no search, show everything" via the regular
    list path instead.
    """
    sanitized = _sanitize_fts_query(q)
    if not sanitized:
        return []

    dialect = db.get_bind().dialect.name
    if dialect == "sqlite":
        return search_drops_sqlite(db, q=sanitized, source=source, state=state, limit=limit)
    return search_drops_like(db, q=sanitized, source=source, state=state, limit=limit)
