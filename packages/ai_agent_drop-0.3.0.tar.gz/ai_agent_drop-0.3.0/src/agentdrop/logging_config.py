"""Structlog setup: pretty in dev, JSON in prod, with stdlib bridged through.

Call :func:`configure_logging` once at process start (FastAPI app, CLI, MCP
server). After that, ``structlog.get_logger(__name__)`` and
``logging.getLogger(__name__)`` both flow through the same processor chain,
so library logs (uvicorn, sqlalchemy, apscheduler, httpx) end up shaped the
same way as application logs.

Per-request context (request_id, drop_id, channel/driver, ...) is bound via
``structlog.contextvars`` and rendered automatically by the
``merge_contextvars`` processor, so call sites don't have to thread the
context through arguments.
"""

from __future__ import annotations

import logging
import sys

import structlog

from agentdrop.config import Settings, get_settings


def _is_dev(env: str) -> bool:
    return env.lower() in {"dev", "development", "local"}


def configure_logging(env: str | None = None, level: str | None = None) -> None:
    settings: Settings = get_settings()
    resolved_env = env if env is not None else settings.env
    resolved_level = (level if level is not None else settings.log_level).upper()

    use_json = settings.log_json if settings.log_json is not None else not _is_dev(resolved_env)

    timestamper = structlog.processors.TimeStamper(fmt="iso", utc=True)

    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        timestamper,
        structlog.processors.StackInfoRenderer(),
    ]

    if use_json:
        renderer: structlog.types.Processor = structlog.processors.JSONRenderer()
        # JSON renderer needs exc_info expanded to a string field; the
        # console renderer does its own pretty printing.
        renderer_chain: list[structlog.types.Processor] = [
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.format_exc_info,
            renderer,
        ]
    else:
        renderer = structlog.dev.ConsoleRenderer(colors=sys.stderr.isatty())
        renderer_chain = [
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ]

    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelNamesMapping().get(resolved_level, logging.INFO)
        ),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=renderer_chain,
    )

    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(resolved_level)

    # Library loggers that default to noisy levels — pin them to the same
    # root so structured output stays consistent. Uvicorn's access logger
    # is noisy at INFO; leave it for now (operators can tune via env).
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "sqlalchemy", "apscheduler"):
        lg = logging.getLogger(name)
        lg.handlers = []
        lg.propagate = True
