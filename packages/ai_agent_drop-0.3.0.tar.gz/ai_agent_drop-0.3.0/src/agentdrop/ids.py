"""Short, URL-safe identifier generation for Agent Drop.

Two flavours are exposed:

* :func:`new_short_id` — 24-char base62 token used for the public, unguessable
  drop URL (see PRD §8.5).
* :func:`new_id` — prefixed base62 token (``drp_…``, ``ch_…``, etc.) used as
  internal primary keys. The default 12-char suffix is ~71 bits of entropy,
  which is plenty for PKs that are never exposed in URLs.

Entropy comes from :mod:`secrets`. No external dependencies.
"""

from __future__ import annotations

import secrets
import string

ALPHABET: str = string.digits + string.ascii_lowercase + string.ascii_uppercase
"""Base62 alphabet: ``0-9`` + ``a-z`` + ``A-Z`` (62 characters)."""

_ALPHABET_LEN: int = len(ALPHABET)


def _generate(n: int) -> str:
    """Return a random string of length ``n`` drawn from :data:`ALPHABET`.

    Uses :func:`secrets.choice` per character — simple and unbiased because
    62 maps cleanly onto the underlying ``random.SystemRandom`` draw.
    """
    if n <= 0:
        raise ValueError("length must be positive")
    return "".join(secrets.choice(ALPHABET) for _ in range(n))


def new_short_id() -> str:
    """Return a 24-char base62 id (~143 bits of entropy).

    This is the token used in public drop URLs; it must be unguessable per
    PRD §8.5.
    """
    return _generate(24)


def new_id(prefix: str, length: int = 12) -> str:
    """Return a prefixed base62 id of the form ``{prefix}_{token}``.

    ``length`` controls the token (suffix) length only; the prefix and
    underscore are extra. Default of 12 gives ~71 bits of entropy, which is
    appropriate for internal primary keys that are never exposed in URLs.
    """
    if not prefix:
        raise ValueError("prefix must be non-empty")
    return f"{prefix}_{_generate(length)}"
