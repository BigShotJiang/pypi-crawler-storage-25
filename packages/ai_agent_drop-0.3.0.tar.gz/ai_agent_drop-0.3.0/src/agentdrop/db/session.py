"""Engine + session factory for Agent Drop.

Builds a SQLAlchemy 2.x engine from settings. For SQLite URLs we set
``check_same_thread=False`` (FastAPI may call the session from different
threads) and register a ``connect`` listener that applies WAL mode and a
set of sensible pragmas on every connection. Non-SQLite URLs (e.g.
Postgres) skip the pragma listener entirely.
"""

from __future__ import annotations

from collections.abc import Iterator
from functools import lru_cache

from sqlalchemy import Engine, create_engine, event
from sqlalchemy.orm import Session, sessionmaker

from agentdrop.config import get_settings


def _apply_sqlite_pragmas(dbapi_connection, connection_record) -> None:  # type: ignore[no-untyped-def]
    """Apply WAL + safety pragmas to every new SQLite connection."""
    cursor = dbapi_connection.cursor()
    try:
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.execute("PRAGMA busy_timeout=5000")
    finally:
        cursor.close()


@lru_cache(maxsize=1)
def get_engine() -> Engine:
    """Build (and cache) the SQLAlchemy engine for the active settings.

    The cache means every caller in a given process shares one engine
    and its connection pool. Tests that change ``AGENTDROP_DATABASE_URL``
    must clear this cache (and the settings cache) to pick up the new URL.
    """
    settings = get_settings()
    url = settings.effective_database_url()

    is_sqlite = url.startswith("sqlite")
    connect_args: dict[str, object] = {}
    if is_sqlite:
        connect_args["check_same_thread"] = False

    engine = create_engine(
        url,
        connect_args=connect_args,
        future=True,
    )

    if is_sqlite:
        event.listen(engine, "connect", _apply_sqlite_pragmas)

    return engine


# Module-level convenience; built lazily via the cached factory.
engine: Engine = get_engine()

SessionLocal = sessionmaker(
    bind=engine,
    autocommit=False,
    autoflush=False,
    expire_on_commit=False,
    class_=Session,
)


def get_db() -> Iterator[Session]:
    """FastAPI dependency that yields a session and closes it on exit."""
    # Always bind to the *current* engine so tests that swap the engine
    # (by clearing caches and pointing ``AGENTDROP_DATABASE_URL`` somewhere
    # else) still get a working session factory.
    session = SessionLocal(bind=get_engine())
    try:
        yield session
    finally:
        session.close()
