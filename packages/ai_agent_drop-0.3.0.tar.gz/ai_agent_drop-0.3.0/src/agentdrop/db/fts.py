"""Shared DDL for the SQLite FTS5 index over ``drops``.

These statements are emitted by the Alembic migration that introduces the
index and reused by the test suite, which spins up throwaway SQLite
databases via ``Base.metadata.create_all`` instead of running Alembic.
Keeping the SQL in one place avoids drift between "schema as applied by
migrations" and "schema as exercised by tests".

The contract is described in detail in the migration docstring
(``alembic/versions/..._add_drops_fts5_index.py``); in short:

* Contentless-style virtual table whose rows are tied to Drop rows via a
  ``drop_id UNINDEXED`` column. Not the SQLite rowid, because Drop PKs
  are prefixed strings.
* Three triggers on ``drops`` maintain the index (INSERT / UPDATE /
  DELETE). Soft-deletes happen via UPDATE and are handled by the update
  trigger.
* ``tags_json`` flattens to space-separated tokens via nested REPLACEs.
* Porter tokenizer for stemming; ``unicode61`` with diacritic folding so
  ``café`` and ``cafe`` match.
"""

from __future__ import annotations

# JSON-array -> space-separated token expression. Strips ``[``, ``]`` and
# ``"`` from the serialized tags_json. IFNULL guards against a NULL column
# (shouldn't happen given the model default, but cheap defence).
_TAGS_EXPR_NEW = "IFNULL(REPLACE(REPLACE(REPLACE(new.tags_json, '[', ''), ']', ''), '\"', ''), '')"


CREATE_FTS_TABLE = """
CREATE VIRTUAL TABLE drops_fts USING fts5(
    title,
    body,
    content_md,
    source,
    tags,
    drop_id UNINDEXED,
    tokenize='porter unicode61 remove_diacritics 2'
)
""".strip()


CREATE_TRIGGER_INSERT = f"""
CREATE TRIGGER drops_fts_ai AFTER INSERT ON drops BEGIN
    INSERT INTO drops_fts(drop_id, title, body, content_md, source, tags)
    VALUES (
        new.id,
        IFNULL(new.title, ''),
        IFNULL(new.body, ''),
        IFNULL(new.content_md, ''),
        IFNULL(new.source, ''),
        {_TAGS_EXPR_NEW}
    );
END
""".strip()  # noqa: S608  # nosec B608 — interpolated value is a module-level SQL literal, not user input


CREATE_TRIGGER_UPDATE = f"""
CREATE TRIGGER drops_fts_au AFTER UPDATE ON drops BEGIN
    DELETE FROM drops_fts WHERE drop_id = old.id;
    INSERT INTO drops_fts(drop_id, title, body, content_md, source, tags)
    VALUES (
        new.id,
        IFNULL(new.title, ''),
        IFNULL(new.body, ''),
        IFNULL(new.content_md, ''),
        IFNULL(new.source, ''),
        {_TAGS_EXPR_NEW}
    );
END
""".strip()  # noqa: S608  # nosec B608 — interpolated value is a module-level SQL literal, not user input


CREATE_TRIGGER_DELETE = """
CREATE TRIGGER drops_fts_ad AFTER DELETE ON drops BEGIN
    DELETE FROM drops_fts WHERE drop_id = old.id;
END
""".strip()


BACKFILL = """
INSERT INTO drops_fts(drop_id, title, body, content_md, source, tags)
SELECT
    id,
    IFNULL(title, ''),
    IFNULL(body, ''),
    IFNULL(content_md, ''),
    IFNULL(source, ''),
    IFNULL(
        REPLACE(REPLACE(REPLACE(tags_json, '[', ''), ']', ''), '"', ''),
        ''
    )
FROM drops
WHERE soft_deleted_at IS NULL
""".strip()


DROP_TRIGGER_INSERT = "DROP TRIGGER IF EXISTS drops_fts_ai"
DROP_TRIGGER_UPDATE = "DROP TRIGGER IF EXISTS drops_fts_au"
DROP_TRIGGER_DELETE = "DROP TRIGGER IF EXISTS drops_fts_ad"
DROP_FTS_TABLE = "DROP TABLE IF EXISTS drops_fts"


def install_fts_schema(target) -> None:  # type: ignore[no-untyped-def]
    """Create the FTS5 table + triggers on a live SQLite connection.

    Accepts either a SQLAlchemy ``Engine`` / ``Connection`` or a raw
    DBAPI ``sqlite3.Connection``. The one-argument signature keeps the
    test path short: ``install_fts_schema(get_engine())`` after
    ``Base.metadata.create_all`` is all it takes.

    No-ops on non-SQLite backends.
    """
    from sqlalchemy.engine import Connection, Engine

    if isinstance(target, Engine):
        if target.dialect.name != "sqlite":
            return
        with target.begin() as conn:
            for stmt in _ALL_CREATE:
                conn.exec_driver_sql(stmt)
        return

    if isinstance(target, Connection):
        if target.dialect.name != "sqlite":
            return
        for stmt in _ALL_CREATE:
            target.exec_driver_sql(stmt)
        return

    # Raw sqlite3 connection (duck-typed — anything with cursor()).
    cursor = target.cursor()
    try:
        for stmt in _ALL_CREATE:
            cursor.execute(stmt)
    finally:
        cursor.close()


_ALL_CREATE = (
    CREATE_FTS_TABLE,
    CREATE_TRIGGER_INSERT,
    CREATE_TRIGGER_UPDATE,
    CREATE_TRIGGER_DELETE,
)
