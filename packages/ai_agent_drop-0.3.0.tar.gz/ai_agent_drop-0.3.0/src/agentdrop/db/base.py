"""SQLAlchemy declarative base.

Models live in ``agentdrop.models`` and import ``Base`` from here. Keep this
module minimal — adding model definitions here creates import cycles and
breaks Alembic's metadata discovery.
"""

from sqlalchemy.orm import DeclarativeBase


class Base(DeclarativeBase):
    """Declarative base class for all Agent Drop ORM models."""
