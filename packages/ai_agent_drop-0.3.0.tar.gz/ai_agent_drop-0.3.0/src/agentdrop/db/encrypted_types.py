"""SQLAlchemy ``TypeDecorator`` that stores a dict as encrypted JSON text.

Used by ``Channel.config_json`` so notification provider tokens (Pushover
keys, ntfy access tokens, Apprise URLs with embedded credentials, webhook
bearer/basic auth) are never on disk in plaintext. Python-side stays
``dict[str, Any]``; the DB column is a Fernet token wrapping the JSON.
"""

from __future__ import annotations

import json
from typing import Any

from sqlalchemy import String
from sqlalchemy.types import TypeDecorator

from agentdrop.crypto.secrets import decrypt, encrypt


class EncryptedJSON(TypeDecorator[dict[str, Any]]):
    """Encrypts JSON-serialisable dicts at rest with the configured Fernet key.

    Fernet tokens are url-safe base64 of ~100+ bytes; ``String`` (no length
    cap) maps to SQLite ``TEXT`` and Postgres ``TEXT``, both unbounded.
    """

    impl = String
    cache_ok = True

    def process_bind_param(self, value: Any, dialect: Any) -> str | None:
        if value is None:
            return None
        if not isinstance(value, dict):
            raise TypeError(f"EncryptedJSON expects a dict, got {type(value).__name__}")
        return encrypt(json.dumps(value, separators=(",", ":"), sort_keys=True))

    def process_result_value(self, value: Any, dialect: Any) -> dict[str, Any] | None:
        if value is None:
            return None
        return json.loads(decrypt(value))
