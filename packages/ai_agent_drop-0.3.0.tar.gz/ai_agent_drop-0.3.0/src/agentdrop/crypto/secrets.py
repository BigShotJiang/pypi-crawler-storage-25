"""Symmetric encryption for at-rest secrets (channel config tokens).

Fernet (AES-128-CBC + HMAC-SHA256, with a version byte and timestamp) is the
chosen primitive: it's a single high-level construct in ``cryptography``,
authenticated, and carries everything we need (versioning, IV) inside the
token itself.

Keys come from ``AGENTDROP_ENCRYPTION_KEY``. A second slot,
``AGENTDROP_ENCRYPTION_KEY_PREV``, accepts a decrypt-only fallback so
operators can rotate the key without downtime: write with the new key,
read with either, then drop ``_PREV`` once ``agentdrop crypto rotate`` has
re-encrypted everything.
"""

from __future__ import annotations

from cryptography.fernet import Fernet, InvalidToken, MultiFernet

from agentdrop.config import get_settings


class EncryptionKeyMissing(RuntimeError):
    """Raised when an encrypt/decrypt is attempted without a configured key."""


class DecryptionFailed(ValueError):
    """Raised when ciphertext is malformed or no configured key can decrypt it."""


def is_key_configured() -> bool:
    return bool(get_settings().encryption_key)


def _build_multifernet() -> MultiFernet:
    settings = get_settings()
    if not settings.encryption_key:
        raise EncryptionKeyMissing(
            "AGENTDROP_ENCRYPTION_KEY is not set. Generate one with:\n"
            '  python -c "import secrets, base64; '
            'print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"\n'
            "and set it in your environment before starting."
        )
    keys = [settings.encryption_key]
    if settings.encryption_key_prev:
        keys.append(settings.encryption_key_prev)
    try:
        fernets = [Fernet(k.encode("ascii")) for k in keys]
    except (ValueError, TypeError) as e:
        raise EncryptionKeyMissing(
            "AGENTDROP_ENCRYPTION_KEY is not a valid 32-byte url-safe base64 key."
        ) from e
    return MultiFernet(fernets)


def encrypt(plaintext: str) -> str:
    """Encrypt with the current (first) key. Returns a Fernet token string."""
    mf = _build_multifernet()
    return mf.encrypt(plaintext.encode("utf-8")).decode("ascii")


def encrypt_with_current_only(plaintext: str) -> str:
    """Encrypt using *only* the current key, ignoring ``_PREV``.

    ``encrypt`` already writes with the current (first) key of the
    ``MultiFernet``, but rotation is the one place we want the intent
    explicit: re-encrypting old ciphertext with the new key, period.
    Using a single-key Fernet here makes that contract obvious in the
    call site (and impossible to subvert by reordering the key list).
    """
    settings = get_settings()
    if not settings.encryption_key:
        raise EncryptionKeyMissing(
            "AGENTDROP_ENCRYPTION_KEY is not set. Generate one with:\n"
            '  python -c "import secrets, base64; '
            'print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"\n'
            "and set it in your environment before starting."
        )
    try:
        fernet = Fernet(settings.encryption_key.encode("ascii"))
    except (ValueError, TypeError) as e:
        raise EncryptionKeyMissing(
            "AGENTDROP_ENCRYPTION_KEY is not a valid 32-byte url-safe base64 key."
        ) from e
    return fernet.encrypt(plaintext.encode("utf-8")).decode("ascii")


def decrypt(ciphertext: str) -> str:
    """Decrypt with any configured key (current or _PREV). Raises on failure."""
    mf = _build_multifernet()
    try:
        return mf.decrypt(ciphertext.encode("ascii")).decode("utf-8")
    except InvalidToken as e:
        raise DecryptionFailed(
            "Could not decrypt value: ciphertext is malformed, tampered with, "
            "or no configured key can decrypt it."
        ) from e
