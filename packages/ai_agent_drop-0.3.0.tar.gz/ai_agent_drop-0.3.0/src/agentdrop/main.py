import secrets
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

import structlog
from fastapi import FastAPI
from sqlalchemy import func, select
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session
from starlette.middleware.sessions import SessionMiddleware

from agentdrop import __version__
from agentdrop.config import get_settings
from agentdrop.crypto import secrets as crypto_secrets
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.logging_config import configure_logging
from agentdrop.middleware import RequestIDMiddleware
from agentdrop.models.channel import Channel
from agentdrop.notifications.bootstrap import ensure_default_web_push_channel
from agentdrop.routes import drops_router
from agentdrop.scheduler import start_scheduler, stop_scheduler
from agentdrop.web import static_dir
from agentdrop.web.admin_routes import router as admin_router
from agentdrop.web.auth_routes import router as auth_router
from agentdrop.web.drop_actions import router as drop_actions_router
from agentdrop.web.inbox import router as inbox_router
from agentdrop.web.pwa import pwa_router
from agentdrop.web.routes import web_router
from agentdrop.web.settings import router as settings_router
from agentdrop.web.settings_api_keys import router as settings_api_keys_router
from agentdrop.web.settings_channels import router as settings_channels_router
from agentdrop.web.settings_devices import router as settings_devices_router
from agentdrop.web.settings_routing import router as settings_routing_router
from agentdrop.web.static_files import CachedStaticFiles

configure_logging()
logger = structlog.get_logger(__name__)


def _check_encryption_key_or_die(session: Session) -> None:
    """Refuse to start if channel rows exist but no encryption key is configured.

    Phase 2 of issue #17 moves ``Channel.config_json`` to encrypted-at-rest
    storage. Booting without ``AGENTDROP_ENCRYPTION_KEY`` set on a database
    that already contains channel rows would either re-encrypt with a
    different (ephemeral) key on the next write — silently locking the
    operator out of their own data — or, worse, write fresh provider
    tokens with no encryption at all. Both are footguns; we hard-fail at
    lifespan startup instead.

    Fresh installs (zero channel rows) skip the check so the operator can
    set up the key and the first channel together at first run. If the
    ``channels`` table doesn't exist yet (pre-migration), we're definitely
    pre-bootstrap and there are no rows to lose, so we skip too.
    """
    try:
        count = session.execute(select(func.count(Channel.id))).scalar_one()
    except OperationalError:
        # Table missing (e.g. before ``alembic upgrade head`` on a fresh
        # DB). No rows means no encrypted data at risk.
        return
    if count and not crypto_secrets.is_key_configured():
        raise RuntimeError(
            "AGENTDROP_ENCRYPTION_KEY is not set, but the database already "
            f"contains {count} channel row(s). Refusing to start to avoid "
            "silently re-encrypting with a different key or operating with "
            "no encryption.\n"
            "Generate a key with:\n"
            '  python -c "import secrets, base64; '
            'print(base64.urlsafe_b64encode(secrets.token_bytes(32)).decode())"\n'
            "and set AGENTDROP_ENCRYPTION_KEY in the environment before "
            "starting."
        )


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """FastAPI lifespan: boot the retention scheduler, tear it down on exit.

    Uses the modern lifespan context (``on_event`` is deprecated in
    FastAPI). The scheduler honours ``settings.retention_disabled``
    internally, so tests that construct the app via TestClient don't
    spawn a background thread when they don't want one.

    Also runs the first-run channel bootstrap: if VAPID is configured
    and no channels exist yet, a default ``web_push`` channel is
    created so the happy path works as soon as a device subscribes.
    """
    with SessionLocal(bind=get_engine()) as db:
        _check_encryption_key_or_die(db)
        ensure_default_web_push_channel(db, get_settings())
    start_scheduler()
    try:
        yield
    finally:
        stop_scheduler()


app = FastAPI(title="Agent Drop", version=__version__, lifespan=lifespan)

_settings = get_settings()
_secret_key = _settings.secret_key
if not _secret_key:
    _secret_key = secrets.token_urlsafe(32)
    logger.warning(
        "secret_key_unset_ephemeral",
        message=(
            "AGENTDROP_SECRET_KEY is not set; generated an ephemeral session "
            "key. Sessions will invalidate on every restart."
        ),
    )

if _settings.insecure_cookies:
    logger.warning(
        "insecure_cookies_enabled",
        message=(
            "AGENTDROP_INSECURE_COOKIES=1 — session cookie will not be "
            "marked Secure. Use only for local HTTP development."
        ),
    )

app.add_middleware(
    SessionMiddleware,
    secret_key=_secret_key,
    session_cookie="agentdrop_session",
    max_age=60 * 60 * 24 * 14,
    same_site="lax",
    https_only=not _settings.insecure_cookies,
)
# Added last → runs first (Starlette wraps in reverse order). Request ID
# must be bound before any logging or session work.
app.add_middleware(RequestIDMiddleware)

app.mount("/static", CachedStaticFiles(directory=str(static_dir)), name="static")

app.include_router(auth_router)
app.include_router(inbox_router)
app.include_router(drop_actions_router)
app.include_router(drops_router)
app.include_router(web_router)
app.include_router(admin_router)
app.include_router(settings_router)
app.include_router(settings_channels_router)
app.include_router(settings_routing_router)
app.include_router(settings_api_keys_router)
app.include_router(settings_devices_router)
app.include_router(pwa_router)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "version": __version__}
