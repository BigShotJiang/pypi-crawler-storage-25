"""Retention sweep — PRD §8.4 lifecycle.

Two phases, one transaction:

1. **Soft-delete** eligible rows. A row is eligible when it is still
   active (``soft_deleted_at IS NULL``), not user-pinned (``pinned_at
   IS NULL``), and past its effective expiry. "Effective expiry" honours
   the per-drop override: if ``expires_at`` is set we use that; otherwise
   we fall back to ``created_at + retention_days``. The soft-delete sets
   ``soft_deleted_at = now`` and **clears content** (``content_md`` and
   ``body`` both set to ``""``) per PRD §8.4 "content cleared, row
   retained for another 60 days as a tombstone". ``title``, ``source``,
   and ``tags_json`` are preserved — they're small audit metadata that
   makes post-hoc forensics cheap and costs nothing.

2. **Hard-delete** rows whose tombstone window has elapsed, i.e.
   ``soft_deleted_at + tombstone_days < now``. The ``ON DELETE CASCADE``
   on ``events.drop_id`` cleans up related events for us.

Architectural notes:

- This is a pure function, not a class. It takes an injected ``Session``
  and an injected ``now``; this lets tests pass a frozen clock and lets
  the scheduler, the admin endpoint, and pytest all share one code path.
- Commits exactly once, at the end, after both phases succeed. If
  something raises in phase 2, phase 1 rolls back too — we'd rather
  run the whole sweep again next hour than leave half-applied state.
- "Examined" count is a cheap ``COUNT(*)`` over active rows; it's for
  observability logging, not for correctness.

``DELETE /api/v1/drops/{id}`` mirrors phase 1's content-clear in the
same transaction (see ``agentdrop.routes.drops.delete_drop``) so a
manual delete and a retention-driven soft-delete leave the row in
identical shape.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

import structlog
from sqlalchemy import delete, func, or_, select, update
from sqlalchemy.orm import Session

from agentdrop.models import Drop

logger = structlog.get_logger("agentdrop.retention")


@dataclass(frozen=True)
class RetentionStats:
    """Result summary from a single :func:`run_retention` invocation.

    Frozen so callers (notably the admin endpoint Agent B is building)
    can safely treat it as a value type and e.g. JSON-encode its fields
    without worrying about mutation.
    """

    soft_deleted: int
    hard_deleted: int
    examined: int
    ran_at: datetime


def run_retention(
    db: Session,
    *,
    retention_days: int,
    tombstone_days: int,
    now: datetime | None = None,
) -> RetentionStats:
    """Sweep drops per PRD §8.4. See module docstring for semantics.

    ``now`` is injectable so tests get deterministic behaviour and the
    function is idempotent under a fixed clock. Default is
    ``datetime.now(UTC)``.
    """
    now = now or datetime.now(UTC)
    retention_cutoff = now - timedelta(days=retention_days)
    tombstone_cutoff = now - timedelta(days=tombstone_days)

    logger.info(
        "retention_sweep_starting",
        now=now.isoformat(),
        retention_days=retention_days,
        tombstone_days=tombstone_days,
    )

    # Observability: how many *active* (not soft-deleted) rows exist?
    # This is decoupled from eligibility — it's a denominator that makes
    # soft-deleted counts interpretable at a glance.
    examined: int = (
        db.execute(select(func.count(Drop.id)).where(Drop.soft_deleted_at.is_(None))).scalar() or 0
    )

    # ------------------------------------------------------------------
    # Phase 1 — soft-delete
    # ------------------------------------------------------------------
    # Eligibility predicate encoded in SQL as a single UPDATE ... WHERE:
    #
    #   - not already soft-deleted
    #   - not user-pinned (pinned drops are exempt, always; PRD §8.4)
    #   - AND one of:
    #       * expires_at IS NOT NULL AND expires_at < now        (per-drop override)
    #       * expires_at IS NULL    AND created_at < retention_cutoff  (global)
    #
    # Archive does *not* exempt — archived drops still expire. The
    # handoff README "archive hides, doesn't preserve" backs this up.
    #
    # Using ``update().where(...).values(...)`` means one round-trip and
    # one SQL statement per phase; fine for the expected scale (thousands
    # of drops lifetime). If we outgrow that we'd chunk by id.
    expiry_predicate = or_(
        Drop.expires_at.is_not(None) & (Drop.expires_at < now),
        Drop.expires_at.is_(None) & (Drop.created_at < retention_cutoff),
    )
    soft_delete_stmt = (
        update(Drop)
        .where(
            Drop.soft_deleted_at.is_(None),
            Drop.pinned_at.is_(None),
            expiry_predicate,
        )
        .values(
            soft_deleted_at=now,
            content_md="",
            body="",
        )
        # synchronize_session=False: we don't need the in-session identity
        # map to stay consistent — this is a one-shot batch job with no
        # subsequent reads of the same rows.
        .execution_options(synchronize_session=False)
    )
    soft_result = db.execute(soft_delete_stmt)
    soft_deleted = soft_result.rowcount or 0  # type: ignore[attr-defined]

    # ------------------------------------------------------------------
    # Phase 2 — hard-delete
    # ------------------------------------------------------------------
    # Rows whose tombstone window has elapsed. ``ON DELETE CASCADE``
    # on events.drop_id purges their audit trail; that's intentional
    # because the events FK is the only pointer back, and we're trying
    # to actually free the bytes.
    hard_delete_stmt = (
        delete(Drop)
        .where(
            Drop.soft_deleted_at.is_not(None),
            Drop.soft_deleted_at < tombstone_cutoff,
        )
        .execution_options(synchronize_session=False)
    )
    hard_result = db.execute(hard_delete_stmt)
    hard_deleted = hard_result.rowcount or 0  # type: ignore[attr-defined]

    db.commit()

    stats = RetentionStats(
        soft_deleted=soft_deleted,
        hard_deleted=hard_deleted,
        examined=examined,
        ran_at=now,
    )
    logger.info(
        "retention_sweep_finished",
        soft_deleted=stats.soft_deleted,
        hard_deleted=stats.hard_deleted,
        examined=stats.examined,
    )
    return stats
