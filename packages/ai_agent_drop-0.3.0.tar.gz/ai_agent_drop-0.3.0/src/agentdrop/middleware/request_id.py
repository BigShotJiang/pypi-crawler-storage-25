"""Per-request ID middleware: read or mint, bind to structlog, echo on response."""

from __future__ import annotations

import re
import uuid

import structlog
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

REQUEST_ID_HEADER = "X-Request-ID"

# Accept reasonably-formed inbound IDs so a malicious client can't pollute
# logs with megabyte payloads or control chars. uuid hex, dashed uuid, or
# any short alphanumeric/-/_ token up to 64 chars.
_VALID_REQUEST_ID = re.compile(r"^[A-Za-z0-9_\-]{1,64}$")


def _normalize(candidate: str | None) -> str | None:
    if candidate is None:
        return None
    candidate = candidate.strip()
    if _VALID_REQUEST_ID.match(candidate):
        return candidate
    return None


class RequestIDMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp, header: str = REQUEST_ID_HEADER) -> None:
        super().__init__(app)
        self.header = header

    async def dispatch(self, request: Request, call_next):  # type: ignore[override]
        request_id = _normalize(request.headers.get(self.header)) or uuid.uuid4().hex
        request.state.request_id = request_id
        structlog.contextvars.clear_contextvars()
        structlog.contextvars.bind_contextvars(request_id=request_id)
        try:
            response: Response = await call_next(request)
        finally:
            structlog.contextvars.clear_contextvars()
        response.headers[self.header] = request_id
        return response
