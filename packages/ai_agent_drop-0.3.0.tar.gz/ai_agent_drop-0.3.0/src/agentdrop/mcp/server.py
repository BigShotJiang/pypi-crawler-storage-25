"""``agentdrop-mcp`` — an MCP server wrapping the Agent Drop HTTP API.

The server exposes two tools over stdio (the only transport Claude Desktop
and Claude Code need):

- ``create_drop`` — POST ``/api/v1/drops``. Schema requires ``title``,
  ``body`` and ``content`` (PRD §11: "Schema enforces title, body, content
  as required so the LLM cannot post without them").
- ``list_recent_drops`` — GET ``/api/v1/drops`` with a bounded limit.

Both tools delegate to :class:`agentdrop.cli.http.CliClient` so the HTTP
transport (Bearer, Cloudflare Access service-token headers, error
translation) is shared with the CLI and there is exactly one code path
for auth headers.

Config precedence (highest wins):

1. Process environment (``AGENTDROP_BASE_URL``, ``AGENTDROP_API_KEY``,
   ``AGENTDROP_CF_ACCESS_CLIENT_ID``, ``AGENTDROP_CF_ACCESS_CLIENT_SECRET``) —
   this is how Claude Desktop injects config via the ``env`` block in
   ``claude_desktop_config.json``.
2. ``~/.config/agentdrop/config.toml`` — shared with the CLI, so
   ``agentdrop config`` configures both.

Logging always goes to stderr; MCP uses stdout for JSON-RPC framing and
any stray log line on stdout corrupts the transport.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
from typing import Any

import structlog
from mcp import types
from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.server.stdio import stdio_server

from agentdrop import __version__
from agentdrop.cli.config_file import CliConfig, load_config
from agentdrop.cli.http import CliClient, CliHttpError
from agentdrop.logging_config import configure_logging

logger = structlog.get_logger("agentdrop.mcp")

SERVER_NAME = "agentdrop-mcp"


# ---------------------------------------------------------------------------
# Tool JSON schemas
# ---------------------------------------------------------------------------
#
# The MCP Python SDK accepts raw JSON-schema dicts for ``Tool.inputSchema``
# and does input validation via ``jsonschema`` before the handler runs (see
# :meth:`mcp.server.Server.call_tool`). Pydantic models aren't accepted
# directly — the schema must be a dict. We also don't pass an
# ``outputSchema`` because both tools return arbitrary JSON shaped by the
# server, and duplicating that schema here would just invite drift.

# Mirror the server constraints in ``agentdrop.schemas.drops.DropCreate``
# so the MCP client gets fast, well-phrased validation errors without
# needing a round-trip. We intentionally do NOT revalidate at runtime —
# if the server tightens a rule, the server-side error is the source of
# truth.
CREATE_DROP_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["title", "body", "content"],
    "properties": {
        "title": {
            "type": "string",
            "minLength": 1,
            "maxLength": 250,
            "description": "Notification headline shown on the device lock screen.",
        },
        "body": {
            "type": "string",
            "minLength": 1,
            "maxLength": 1024,
            "description": "Short notification body. Keep it scannable.",
        },
        "content": {
            "type": "string",
            "minLength": 1,
            "description": (
                "Full markdown content of the drop. Rendered on the public "
                "drop page. GFM supported."
            ),
        },
        "source": {
            "type": "string",
            "maxLength": 64,
            "description": (
                "Short identifier for the agent / routine that produced "
                "this drop (e.g. 'weekly-scan')."
            ),
        },
        "tags": {
            "type": "array",
            "items": {"type": "string"},
            "maxItems": 16,
            "description": "Optional free-form tags used for filtering.",
        },
        "priority": {
            "type": "string",
            "enum": ["low", "normal", "high", "urgent"],
            "description": "Priority level mapped onto the configured push channel.",
        },
        "external_url": {
            "type": "string",
            "description": (
                "Optional deep-link for the 'Open original' card — any scheme "
                "(https://, obsidian://, gh://, ...)."
            ),
        },
        "channel": {
            "type": "string",
            "description": "Override the default channel slug for this drop.",
        },
    },
}

LIST_RECENT_DROPS_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 200,
            "default": 20,
            "description": "How many recent drops to return (server-side maximum 200).",
        }
    },
}


# ---------------------------------------------------------------------------
# Client resolution
# ---------------------------------------------------------------------------


_ENV_PREFIX = "AGENTDROP_"


def _env_overlay(config: CliConfig) -> CliConfig:
    """Return a new ``CliConfig`` with env vars applied over the file values.

    Env vars matter for Claude Desktop, which injects them via the ``env``
    block of ``claude_desktop_config.json`` — users with multi-host
    Claude Desktop setups shouldn't have to edit a TOML file per machine.
    """
    env = os.environ
    return CliConfig(
        base_url=env.get(_ENV_PREFIX + "BASE_URL") or config.base_url,
        api_key=env.get(_ENV_PREFIX + "API_KEY") or config.api_key,
        default_source=env.get(_ENV_PREFIX + "DEFAULT_SOURCE") or config.default_source,
        cf_access_client_id=(
            env.get(_ENV_PREFIX + "CF_ACCESS_CLIENT_ID") or config.cf_access_client_id
        ),
        cf_access_client_secret=(
            env.get(_ENV_PREFIX + "CF_ACCESS_CLIENT_SECRET") or config.cf_access_client_secret
        ),
    )


def _get_client() -> CliClient:
    """Resolve config + return a configured :class:`CliClient`.

    Called once per tool invocation so the MCP server picks up config
    changes without a restart. The underlying ``httpx.Client`` is still
    short-lived per call (see :class:`CliClient`), which is fine for the
    low request rate of a human-in-the-loop notification system.
    """
    config = _env_overlay(load_config())
    return CliClient(config)


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


def _handle_create_drop(arguments: dict[str, Any]) -> dict[str, Any]:
    """Synchronous core of ``create_drop``; easier to test than the async wrapper."""
    payload: dict[str, Any] = {
        "title": arguments["title"],
        "body": arguments["body"],
        "content": arguments["content"],
    }
    for optional in ("source", "tags", "priority", "external_url", "channel"):
        if optional in arguments and arguments[optional] is not None:
            payload[optional] = arguments[optional]

    try:
        client = _get_client()
    except CliHttpError as exc:
        raise RuntimeError(f"agentdrop config incomplete: {exc.message}") from exc

    try:
        response = client.post_drop(payload)
    except CliHttpError as exc:
        # Surface the server's validation message verbatim so the LLM can
        # correct course (e.g. "HTTP 422: title: field required").
        raise RuntimeError(f"create_drop failed: {exc.message}") from exc

    return {
        "id": response.get("id"),
        "url": response.get("url"),
        "created_at": response.get("created_at"),
    }


def _handle_list_recent_drops(arguments: dict[str, Any]) -> dict[str, Any]:
    """Synchronous core of ``list_recent_drops``."""
    limit = arguments.get("limit", 20)
    try:
        client = _get_client()
    except CliHttpError as exc:
        raise RuntimeError(f"agentdrop config incomplete: {exc.message}") from exc

    try:
        response = client.list_drops({"limit": limit, "state": "all"})
    except CliHttpError as exc:
        raise RuntimeError(f"list_recent_drops failed: {exc.message}") from exc

    return {"items": response.get("items", []), "count": response.get("count")}


# ---------------------------------------------------------------------------
# MCP server wiring
# ---------------------------------------------------------------------------


def build_server() -> Server:
    """Construct and return a :class:`Server` with tools registered.

    Split out from :func:`run_stdio` so tests can exercise the registered
    handlers directly without needing a stdio transport.
    """
    server: Server = Server(SERVER_NAME, version=__version__)

    @server.list_tools()
    async def _list_tools() -> list[types.Tool]:
        return [
            types.Tool(
                name="create_drop",
                description=(
                    "Post a drop to the configured Agent Drop server and fire a push "
                    "notification. Returns the public drop URL the user can tap open."
                ),
                inputSchema=CREATE_DROP_SCHEMA,
            ),
            types.Tool(
                name="list_recent_drops",
                description=(
                    "List recent drops (newest first) for deduplication checks like "
                    "'did I already send this today'."
                ),
                inputSchema=LIST_RECENT_DROPS_SCHEMA,
            ),
        ]

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if name == "create_drop":
            # Offload the blocking ``httpx.Client`` call so the stdio event
            # loop keeps processing incoming messages.
            return await asyncio.to_thread(_handle_create_drop, arguments)
        if name == "list_recent_drops":
            return await asyncio.to_thread(_handle_list_recent_drops, arguments)
        raise ValueError(f"unknown tool: {name}")

    return server


async def run_stdio() -> None:
    """Run the MCP server over stdio until the client disconnects."""
    from mcp.server import NotificationOptions

    server = build_server()
    init_options = InitializationOptions(
        server_name=SERVER_NAME,
        server_version=__version__,
        capabilities=server.get_capabilities(
            notification_options=NotificationOptions(),
            experimental_capabilities={},
        ),
    )
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, init_options)


def _check_config_or_exit() -> None:
    """Fail fast on startup if base_url / api_key aren't resolvable.

    Claude Desktop surfaces a non-zero exit as a visible "server crashed"
    error in its UI, which is much nicer than a silent hang waiting for
    JSON-RPC that will never arrive.
    """
    config = _env_overlay(load_config())
    missing: list[str] = []
    if not config.base_url:
        missing.append("base_url (AGENTDROP_BASE_URL)")
    if not config.api_key:
        missing.append("api_key (AGENTDROP_API_KEY)")
    if missing:
        logger.error(
            "mcp_missing_config",
            missing=missing,
            hint="Run 'agentdrop config' or set the AGENTDROP_* env vars.",
        )
        sys.exit(2)


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog=SERVER_NAME,
        description=(
            "MCP server exposing create_drop / list_recent_drops over stdio. "
            "Reads config from ~/.config/agentdrop/config.toml (overridable by "
            "AGENTDROP_* env vars)."
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"{SERVER_NAME} {__version__}",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> None:
    """Console-script entry point for ``agentdrop-mcp``."""
    # MCP uses stdout for JSON-RPC framing; structlog renders to stderr by
    # default so we're safe. ``AGENTDROP_MCP_LOG_LEVEL`` retained as an
    # override so existing operator configs keep working.
    configure_logging(level=os.environ.get("AGENTDROP_MCP_LOG_LEVEL"))
    _parse_args(argv)
    _check_config_or_exit()
    logger.info("mcp_starting", transport="stdio", version=__version__)
    try:
        asyncio.run(run_stdio())
    except KeyboardInterrupt:  # pragma: no cover - interactive only
        logger.info("mcp_interrupted")
