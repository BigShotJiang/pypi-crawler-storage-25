"""Enable ``python -m agentdrop.mcp`` as an alternative to ``agentdrop-mcp``."""

from __future__ import annotations

from agentdrop.mcp.server import main

if __name__ == "__main__":
    main()
