"""MCP server (``agentdrop-mcp``) exposing drop creation to local LLM clients.

A thin stdio wrapper around the existing HTTP API so Claude Desktop /
Claude Code can invoke :func:`create_drop` and :func:`list_recent_drops`
as native tools. See :mod:`agentdrop.mcp.server` for the entry point and
``PRD.md`` §11 for the contract.

The server deliberately reuses :class:`agentdrop.cli.http.CliClient` and
:func:`agentdrop.cli.config_file.load_config` so a user who already ran
``agentdrop config --base-url ... --api-key ...`` gets MCP working for
free.
"""
