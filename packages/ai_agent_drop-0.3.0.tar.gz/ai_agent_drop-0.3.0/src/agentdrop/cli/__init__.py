"""CLI entry point for the ``agentdrop`` command.

The Typer app is defined in :mod:`agentdrop.cli.app`. This module re-exports
``app`` so ``pyproject.toml``'s ``[project.scripts]`` entry and
``python -m agentdrop`` both resolve to the same object.
"""

from agentdrop.cli.app import app
from agentdrop.logging_config import configure_logging

configure_logging()

__all__ = ["app"]
