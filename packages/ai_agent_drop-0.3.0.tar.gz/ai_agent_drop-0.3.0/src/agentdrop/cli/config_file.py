"""Load, save, and locate the ``agentdrop`` CLI config file.

The canonical location is ``$XDG_CONFIG_HOME/agentdrop/config.toml`` (falling
back to ``~/.config/agentdrop/config.toml`` on Linux/macOS, matching the XDG
basedir spec). Windows isn't an MVP concern — see the CLI conventions in the
build plan.

Config schema (all keys optional)::

    base_url = "https://drop.example.com"
    api_key = "agdr_xxxxx"
    default_source = "cli"
    cf_access_client_id = "abc123.access"
    cf_access_client_secret = "..."

``api_key`` and ``cf_access_client_secret`` are treated as secrets and are
never echoed by the CLI in plain form; see :func:`mask_key`.

The CF Access fields are intended for self-hosted instances sitting behind
Cloudflare Access. When both are set, the CLI sends ``CF-Access-Client-Id``
and ``CF-Access-Client-Secret`` headers on every request.
"""

from __future__ import annotations

import contextlib
import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

import tomli_w


@dataclass
class CliConfig:
    """Parsed on-disk config for the CLI."""

    base_url: str | None = None
    api_key: str | None = None
    default_source: str | None = None
    cf_access_client_id: str | None = None
    cf_access_client_secret: str | None = None

    def to_dict(self) -> dict[str, str]:
        """Serialise to a TOML-friendly dict, skipping unset keys."""
        out: dict[str, str] = {}
        if self.base_url is not None:
            out["base_url"] = self.base_url
        if self.api_key is not None:
            out["api_key"] = self.api_key
        if self.default_source is not None:
            out["default_source"] = self.default_source
        if self.cf_access_client_id is not None:
            out["cf_access_client_id"] = self.cf_access_client_id
        if self.cf_access_client_secret is not None:
            out["cf_access_client_secret"] = self.cf_access_client_secret
        return out


def config_path() -> Path:
    """Return the path to the CLI config file.

    Honours ``XDG_CONFIG_HOME``; otherwise falls back to ``~/.config``.
    The file itself may or may not exist — callers should check.
    """
    base = os.environ.get("XDG_CONFIG_HOME")
    root = Path(base) if base else Path.home() / ".config"
    return root / "agentdrop" / "config.toml"


def load_config(path: Path | None = None) -> CliConfig:
    """Load the config file, returning defaults if it does not exist."""
    path = path or config_path()
    if not path.is_file():
        return CliConfig()
    with path.open("rb") as fh:
        data = tomllib.load(fh)
    return CliConfig(
        base_url=data.get("base_url"),
        api_key=data.get("api_key"),
        default_source=data.get("default_source"),
        cf_access_client_id=data.get("cf_access_client_id"),
        cf_access_client_secret=data.get("cf_access_client_secret"),
    )


def save_config(config: CliConfig, path: Path | None = None) -> Path:
    """Atomically write ``config`` to disk and return the resolved path.

    Parent directories are created as needed; the file is written with
    ``0o600`` permissions because it holds the API key.
    """
    path = path or config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = tomli_w.dumps(config.to_dict()).encode("utf-8")
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(payload)
    # Best effort on exotic filesystems; the rename still happens either way.
    with contextlib.suppress(OSError):
        os.chmod(tmp, 0o600)
    tmp.replace(path)
    return path


def mask_key(key: str | None) -> str:
    """Return a masked representation of ``key`` that is safe to print.

    Shows the first 4 and last 2 characters when the key is long enough;
    otherwise returns a fixed placeholder. Never returns the raw key.
    """
    if not key:
        return "(unset)"
    if len(key) <= 8:
        return "*" * len(key)
    return f"{key[:4]}{'*' * (len(key) - 6)}{key[-2:]}"
