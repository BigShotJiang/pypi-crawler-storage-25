"""Typer app for the ``agentdrop`` CLI.

Subcommands:

- ``agentdrop config``  — view / set the server URL + API key.
- ``agentdrop drop``    — create a drop from a literal string, a file, or stdin.
- ``agentdrop list``    — list recent drops, table or JSON.
- ``agentdrop version`` — print the installed package version.

See ``PRD.md`` §11 (CLI) and §8.1 (ingestion payload) for the spec this
implements.
"""

from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Any

import typer

from agentdrop import __version__
from agentdrop.cli.config_file import (
    CliConfig,
    config_path,
    load_config,
    mask_key,
    save_config,
)
from agentdrop.cli.http import CliClient, CliHttpError

app = typer.Typer(
    name="agentdrop",
    help="Create drops, list them, and manage CLI config for an Agent Drop server.",
    no_args_is_help=True,
    add_completion=False,
)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------


class Priority(StrEnum):
    """Priority levels accepted by the server (see ``PRD.md`` §8.1)."""

    low = "low"
    normal = "normal"
    high = "high"
    urgent = "urgent"


class StateFilter(StrEnum):
    """Lifecycle states for ``agentdrop list --state``."""

    all = "all"
    unread = "unread"
    pinned = "pinned"
    archived = "archived"


def _err(msg: str) -> None:
    """Print a one-line error to stderr."""
    typer.echo(msg, err=True)


def _exit(code: int) -> None:  # pragma: no cover - trivial wrapper
    raise typer.Exit(code=code)


def _read_content(
    content: str | None,
    content_file: Path | None,
) -> str:
    """Resolve the drop content from the three mutually-exclusive sources.

    ``--content -`` reads from stdin. Any other value of ``--content`` is
    treated as a literal string. ``--content-file`` reads the file verbatim.
    Exactly one source must be provided.
    """
    provided = [v is not None for v in (content, content_file)]
    if sum(provided) != 1:
        _err("error: provide exactly one of --content TEXT, --content-file FILE, or --content -")
        _exit(2)
    if content is not None:
        if content == "-":
            data = sys.stdin.read()
            if not data:
                _err("error: --content - was given but stdin is empty")
                _exit(2)
            return data
        return content
    assert content_file is not None  # noqa: S101 — invariant: callers pass content xor content_file
    if not content_file.is_file():
        _err(f"error: content file not found: {content_file}")
        _exit(2)
    return content_file.read_text(encoding="utf-8")


def _parse_tags(tags: str | None) -> list[str]:
    if not tags:
        return []
    return [t.strip() for t in tags.split(",") if t.strip()]


def _short_id(drop_id: str) -> str:
    """Render an id in a table-friendly short form.

    The server exposes both ``id`` and ``short_id``; we prefer ``short_id``
    when present, otherwise trim the uuid-ish id to 8 chars.
    """
    return drop_id[:10]


def _relative_time(iso_ts: str) -> str:
    """Format an ISO-8601 timestamp as a compact relative age (e.g. ``3h``)."""
    try:
        ts = datetime.fromisoformat(iso_ts.replace("Z", "+00:00"))
    except ValueError:
        return iso_ts
    now = datetime.now(UTC)
    if ts.tzinfo is None:
        ts = ts.replace(tzinfo=UTC)
    delta = now - ts
    seconds = int(delta.total_seconds())
    if seconds < 0:
        return "now"
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    if days < 30:
        return f"{days}d"
    return ts.strftime("%Y-%m-%d")


def _render_list_table(items: list[dict[str, Any]]) -> str:
    """Return a mono-friendly table for ``agentdrop list``."""
    if not items:
        return "(no drops)"
    rows: list[tuple[str, str, str]] = []
    for item in items:
        drop_id = item.get("short_id") or _short_id(item.get("id", ""))
        created = _relative_time(str(item.get("created_at", "")))
        title = str(item.get("title", "")).replace("\n", " ")
        if len(title) > 60:
            title = title[:57] + "..."
        rows.append((drop_id, created, title))
    id_w = max(len("id"), max(len(r[0]) for r in rows))
    time_w = max(len("age"), max(len(r[1]) for r in rows))
    header = f"{'id':<{id_w}}  {'age':<{time_w}}  title"
    lines = [header, "-" * len(header)]
    for rid, age, title in rows:
        lines.append(f"{rid:<{id_w}}  {age:<{time_w}}  {title}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# subcommand: config
# ---------------------------------------------------------------------------


@app.command("config")
def config_cmd(
    base_url: Annotated[
        str | None, typer.Option("--base-url", help="Base URL of the Agent Drop server.")
    ] = None,
    api_key: Annotated[
        str | None, typer.Option("--api-key", help="Bearer API key. Stored in the config file.")
    ] = None,
    default_source: Annotated[
        str | None,
        typer.Option("--default-source", help="Default value for --source on 'agentdrop drop'."),
    ] = None,
    cf_access_client_id: Annotated[
        str | None,
        typer.Option(
            "--cf-access-client-id",
            help="Cloudflare Access service-token client id. Sent as CF-Access-Client-Id.",
        ),
    ] = None,
    cf_access_client_secret: Annotated[
        str | None,
        typer.Option(
            "--cf-access-client-secret",
            help="Cloudflare Access service-token client secret. Stored in the config file.",
        ),
    ] = None,
    show_path: Annotated[
        bool,
        typer.Option("--show-path", help="Print the config file path and exit (for scripting)."),
    ] = False,
) -> None:
    """View or update the CLI config file.

    With no flags, prints the config path plus a masked summary of the
    currently-stored values. Pass ``--base-url`` and/or ``--api-key`` to
    update those entries; the file is written with mode ``0600``.
    """
    path = config_path()

    if show_path:
        typer.echo(str(path))
        return

    updates = (
        base_url,
        api_key,
        default_source,
        cf_access_client_id,
        cf_access_client_secret,
    )
    if any(v is not None for v in updates):
        existing = load_config(path)
        if base_url is not None:
            existing.base_url = base_url
        if api_key is not None:
            existing.api_key = api_key
        if default_source is not None:
            existing.default_source = default_source
        if cf_access_client_id is not None:
            existing.cf_access_client_id = cf_access_client_id
        if cf_access_client_secret is not None:
            existing.cf_access_client_secret = cf_access_client_secret
        written = save_config(existing, path)
        typer.echo(f"wrote {written}")
        _print_config_summary(existing)
        return

    cfg = load_config(path)
    typer.echo(f"config path: {path}")
    _print_config_summary(cfg)


def _print_config_summary(cfg: CliConfig) -> None:
    """Print the config in a fixed, secret-masking format."""
    typer.echo(f"  base_url                = {cfg.base_url or '(unset)'}")
    typer.echo(f"  api_key                 = {mask_key(cfg.api_key)}")
    typer.echo(f"  default_source          = {cfg.default_source or '(unset)'}")
    typer.echo(f"  cf_access_client_id     = {cfg.cf_access_client_id or '(unset)'}")
    typer.echo(f"  cf_access_client_secret = {mask_key(cfg.cf_access_client_secret)}")


# ---------------------------------------------------------------------------
# subcommand: drop
# ---------------------------------------------------------------------------


@app.command("drop")
def drop_cmd(
    title: Annotated[str, typer.Option("--title", help="Notification headline (required).")],
    body: Annotated[str, typer.Option("--body", help="Short notification body (required).")],
    content: Annotated[
        str | None,
        typer.Option(
            "--content",
            help="Markdown body as a literal string, or '-' to read stdin.",
        ),
    ] = None,
    content_file: Annotated[
        Path | None,
        typer.Option(
            "--content-file",
            help="Path to a markdown file to use as the drop content.",
        ),
    ] = None,
    source: Annotated[str | None, typer.Option("--source")] = None,
    tags: Annotated[
        str | None, typer.Option("--tags", help="Comma-separated list of tags.")
    ] = None,
    priority: Annotated[Priority, typer.Option("--priority")] = Priority.normal,
    external_url: Annotated[str | None, typer.Option("--external-url")] = None,
    channel: Annotated[str | None, typer.Option("--channel")] = None,
    expires_in_days: Annotated[int | None, typer.Option("--expires-in-days", min=1)] = None,
    base_url: Annotated[
        str | None, typer.Option("--base-url", help="Override base_url for this invocation.")
    ] = None,
    api_key: Annotated[
        str | None, typer.Option("--api-key", help="Override api_key for this invocation.")
    ] = None,
    cf_access_client_id: Annotated[
        str | None,
        typer.Option(
            "--cf-access-client-id",
            help="Override cf_access_client_id for this invocation.",
        ),
    ] = None,
    cf_access_client_secret: Annotated[
        str | None,
        typer.Option(
            "--cf-access-client-secret",
            help="Override cf_access_client_secret for this invocation.",
        ),
    ] = None,
    as_json: Annotated[
        bool,
        typer.Option(
            "--json", help="Print the raw server JSON response instead of just the drop URL."
        ),
    ] = False,
) -> None:
    """Create a drop. On success, prints the drop URL (pipe-friendly).

    Exit code 0 on 2xx; non-zero with a one-line stderr message on any
    HTTP, network, or validation failure.
    """
    resolved_content = _read_content(content, content_file)

    cfg = load_config()
    resolved_source = source if source is not None else cfg.default_source

    payload: dict[str, Any] = {
        "title": title,
        "body": body,
        "content": resolved_content,
        "priority": priority.value,
    }
    if resolved_source is not None:
        payload["source"] = resolved_source
    parsed_tags = _parse_tags(tags)
    if parsed_tags:
        payload["tags"] = parsed_tags
    if external_url is not None:
        payload["external_url"] = external_url
    if channel is not None:
        payload["channel"] = channel
    if expires_in_days is not None:
        payload["expires_in_days"] = expires_in_days

    try:
        client = CliClient(
            cfg,
            base_url=base_url,
            api_key=api_key,
            cf_access_client_id=cf_access_client_id,
            cf_access_client_secret=cf_access_client_secret,
        )
        response = client.post_drop(payload)
    except CliHttpError as exc:
        _err(f"error: {exc.message}")
        _exit(1)

    if as_json:
        typer.echo(json.dumps(response, indent=2))
    else:
        url = response.get("url")
        if not url:
            _err("error: server response did not include a url")
            _exit(1)
        typer.echo(url)


# ---------------------------------------------------------------------------
# subcommand: list
# ---------------------------------------------------------------------------


@app.command("list")
def list_cmd(
    limit: Annotated[int, typer.Option("--limit", min=1, max=200)] = 20,
    source: Annotated[str | None, typer.Option("--source")] = None,
    state: Annotated[StateFilter, typer.Option("--state")] = StateFilter.all,
    base_url: Annotated[str | None, typer.Option("--base-url")] = None,
    api_key: Annotated[str | None, typer.Option("--api-key")] = None,
    cf_access_client_id: Annotated[str | None, typer.Option("--cf-access-client-id")] = None,
    cf_access_client_secret: Annotated[
        str | None, typer.Option("--cf-access-client-secret")
    ] = None,
    as_json: Annotated[
        bool, typer.Option("--json", help="Print raw server JSON instead of a compact table.")
    ] = False,
) -> None:
    """List recent drops as a compact table or raw JSON."""
    cfg = load_config()

    params: dict[str, Any] = {"limit": limit, "state": state.value}
    if source is not None:
        params["source"] = source

    try:
        client = CliClient(
            cfg,
            base_url=base_url,
            api_key=api_key,
            cf_access_client_id=cf_access_client_id,
            cf_access_client_secret=cf_access_client_secret,
        )
        response = client.list_drops(params)
    except CliHttpError as exc:
        _err(f"error: {exc.message}")
        _exit(1)

    if as_json:
        typer.echo(json.dumps(response, indent=2))
        return

    items = response.get("items", [])
    typer.echo(_render_list_table(items))


# ---------------------------------------------------------------------------
# subcommand: version
# ---------------------------------------------------------------------------


@app.command("version")
def version_cmd() -> None:
    """Print the installed ``agentdrop`` package version."""
    typer.echo(__version__)


# ---------------------------------------------------------------------------
# subcommand group: crypto
# ---------------------------------------------------------------------------


crypto_app = typer.Typer(
    name="crypto",
    help="Encryption-at-rest maintenance.",
    no_args_is_help=True,
)
app.add_typer(crypto_app, name="crypto")


@crypto_app.command("rotate")
def crypto_rotate() -> None:
    """Re-encrypt every ``channels.config_json`` row with the current key.

    Rotation flow (issue #17):

    1. Generate the new key, set ``AGENTDROP_ENCRYPTION_KEY`` to it and
       move the previously-active key to ``AGENTDROP_ENCRYPTION_KEY_PREV``.
    2. Run ``agentdrop crypto rotate`` — every row is decrypted via the
       MultiFernet (which tries current then previous), then re-encrypted
       with the current key alone.
    3. Unset ``AGENTDROP_ENCRYPTION_KEY_PREV`` and restart the server.

    On any per-row failure the row id is logged, processing continues for
    the remaining rows, and the command exits 1 so the operator notices.
    """
    # Imports are deferred so the CLI can boot even if the DB / settings
    # aren't healthy enough to import them at module load.
    from sqlalchemy import text

    from agentdrop.config import get_settings
    from agentdrop.crypto.secrets import (
        DecryptionFailed,
        EncryptionKeyMissing,
        decrypt,
        encrypt_with_current_only,
    )
    from agentdrop.db.session import SessionLocal, get_engine

    settings = get_settings()
    if not settings.encryption_key or not settings.encryption_key_prev:
        _err(
            "error: rotation requires both AGENTDROP_ENCRYPTION_KEY (the new "
            "key) and AGENTDROP_ENCRYPTION_KEY_PREV (the previous key) to be "
            "set. Move the active key to _PREV, set the new key, then re-run."
        )
        _exit(1)

    failures: list[tuple[str, str]] = []
    with SessionLocal(bind=get_engine()) as db:
        rows = db.execute(text("SELECT id, config_json FROM channels")).all()
        total = len(rows)
        if total == 0:
            typer.echo("No channel rows to rotate.")
            return

        for index, (row_id, ciphertext) in enumerate(rows, start=1):
            typer.echo(f"Rotating row {index}/{total} (id={row_id})...")
            if ciphertext is None:
                # Nothing to re-encrypt; skip but don't fail.
                continue
            try:
                plaintext = decrypt(ciphertext)
            except (DecryptionFailed, EncryptionKeyMissing) as exc:
                failures.append((row_id, f"decrypt failed: {exc}"))
                _err(f"  ! row {row_id}: decrypt failed ({exc})")
                continue
            try:
                new_ciphertext = encrypt_with_current_only(plaintext)
            except EncryptionKeyMissing as exc:  # pragma: no cover - defensive
                failures.append((row_id, f"encrypt failed: {exc}"))
                _err(f"  ! row {row_id}: encrypt failed ({exc})")
                continue
            try:
                db.execute(
                    text("UPDATE channels SET config_json = :ct WHERE id = :id"),
                    {"ct": new_ciphertext, "id": row_id},
                )
                db.commit()
            except Exception as exc:
                db.rollback()
                failures.append((row_id, f"update failed: {exc}"))
                _err(f"  ! row {row_id}: update failed ({exc})")
                continue

    if failures:
        typer.echo(
            f"Rotation finished with {len(failures)} failure(s) out of {total} row(s).",
            err=True,
        )
        for row_id, reason in failures:
            _err(f"  - {row_id}: {reason}")
        _exit(1)

    typer.echo(f"Rotated {total} row(s).")
    typer.echo("Rotation complete. You can now unset AGENTDROP_ENCRYPTION_KEY_PREV and restart.")


def _cli_config_snapshot() -> CliConfig:
    """Testing hook: return the currently-resolved config."""
    return load_config()
