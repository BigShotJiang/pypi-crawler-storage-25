"""Thin ``httpx`` wrapper for the CLI.

Responsibilities:

- Resolve ``base_url`` / ``api_key`` from CLI flags, falling back to the
  loaded config file.
- Attach ``Authorization: Bearer <api_key>``.
- Raise :class:`CliHttpError` with a human-readable short message on any
  HTTP failure (network, timeout, 4xx, 5xx). Success path returns the
  parsed JSON body.

The CLI intentionally does *not* mirror the server's Pydantic validation —
the spec is clear: let the server return 4xx and surface the error. This
keeps the CLI tiny and avoids a version skew between client and server
schemas.
"""

from __future__ import annotations

from typing import Any

import httpx

from agentdrop.cli.config_file import CliConfig


class CliHttpError(Exception):
    """Raised when a CLI HTTP call fails for any reason.

    ``message`` is a one-line human-friendly description suitable for
    printing to stderr. ``status_code`` is populated when we got a
    response; ``None`` for network/timeout errors.
    """

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def _resolve(
    config: CliConfig,
    *,
    base_url: str | None,
    api_key: str | None,
) -> tuple[str, str]:
    resolved_base = base_url or config.base_url
    resolved_key = api_key or config.api_key
    if not resolved_base:
        raise CliHttpError(
            "base_url is not configured. Run 'agentdrop config --base-url URL' first."
        )
    if not resolved_key:
        raise CliHttpError("api_key is not configured. Run 'agentdrop config --api-key KEY' first.")
    return resolved_base.rstrip("/"), resolved_key


def _resolve_cf_access(
    config: CliConfig,
    *,
    cf_access_client_id: str | None,
    cf_access_client_secret: str | None,
) -> tuple[str, str] | None:
    """Return the CF-Access header pair if both id and secret resolve; else None.

    Setting only one half is treated as misconfiguration — Cloudflare requires
    both headers to authenticate, and silently sending one would just produce
    confusing 403s.
    """
    resolved_id = cf_access_client_id or config.cf_access_client_id
    resolved_secret = cf_access_client_secret or config.cf_access_client_secret
    if resolved_id and resolved_secret:
        return resolved_id, resolved_secret
    if resolved_id or resolved_secret:
        raise CliHttpError(
            "cf_access_client_id and cf_access_client_secret must both be set "
            "(or both unset). Run 'agentdrop config --cf-access-client-id ID "
            "--cf-access-client-secret SECRET'."
        )
    return None


def _format_http_error(response: httpx.Response) -> str:
    """Condense a 4xx/5xx response into a single printable line."""
    status = response.status_code
    try:
        body = response.json()
    except ValueError:
        body = None
    detail: str | None = None
    if isinstance(body, dict):
        raw_detail = body.get("detail") or body.get("error") or body.get("message")
        if isinstance(raw_detail, list):
            # FastAPI returns validation errors as a list of dicts.
            pieces: list[str] = []
            for entry in raw_detail:
                if isinstance(entry, dict):
                    loc = ".".join(str(x) for x in entry.get("loc", []) if x != "body")
                    msg = entry.get("msg") or ""
                    pieces.append(f"{loc}: {msg}".strip(": ").strip())
                else:
                    pieces.append(str(entry))
            detail = "; ".join(p for p in pieces if p)
        elif isinstance(raw_detail, str):
            detail = raw_detail
    if not detail:
        text = response.text.strip()
        detail = text[:200] if text else response.reason_phrase or "request failed"
    return f"HTTP {status}: {detail}"


class CliClient:
    """Minimal synchronous HTTP client used by the CLI subcommands."""

    def __init__(
        self,
        config: CliConfig,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        cf_access_client_id: str | None = None,
        cf_access_client_secret: str | None = None,
        timeout: float = 30.0,
        client: httpx.Client | None = None,
    ) -> None:
        self.base_url, self.api_key = _resolve(config, base_url=base_url, api_key=api_key)
        self._cf_access = _resolve_cf_access(
            config,
            cf_access_client_id=cf_access_client_id,
            cf_access_client_secret=cf_access_client_secret,
        )
        self.timeout = timeout
        self._client = client

    def _headers(self) -> dict[str, str]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }
        if self._cf_access is not None:
            cf_id, cf_secret = self._cf_access
            headers["CF-Access-Client-Id"] = cf_id
            headers["CF-Access-Client-Secret"] = cf_secret
        return headers

    def _request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = {**self._headers(), **kwargs.pop("headers", {})}
        try:
            if self._client is not None:
                response = self._client.request(
                    method, url, headers=headers, timeout=self.timeout, **kwargs
                )
            else:
                with httpx.Client(timeout=self.timeout) as client:
                    response = client.request(method, url, headers=headers, **kwargs)
        except httpx.TimeoutException as exc:
            raise CliHttpError(f"request timed out: {exc}") from exc
        except httpx.HTTPError as exc:
            raise CliHttpError(f"network error: {exc}") from exc

        if response.status_code >= 400:
            raise CliHttpError(_format_http_error(response), status_code=response.status_code)
        if not response.content:
            return {}
        try:
            data = response.json()
        except ValueError as exc:
            raise CliHttpError(f"invalid JSON response: {exc}") from exc
        if not isinstance(data, dict):
            raise CliHttpError("expected JSON object in response")
        return data

    def post_drop(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._request("POST", "/api/v1/drops", json=payload)

    def list_drops(self, params: dict[str, Any]) -> dict[str, Any]:
        return self._request("GET", "/api/v1/drops", params=params)
