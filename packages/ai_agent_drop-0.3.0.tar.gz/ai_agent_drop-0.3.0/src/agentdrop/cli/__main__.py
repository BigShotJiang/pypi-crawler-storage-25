"""Support ``python -m agentdrop`` as an alias for the ``agentdrop`` script."""

from agentdrop.cli import app

if __name__ == "__main__":
    app()
