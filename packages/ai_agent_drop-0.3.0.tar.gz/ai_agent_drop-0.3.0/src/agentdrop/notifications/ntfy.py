"""ntfy notification driver.

Implements the :class:`~agentdrop.notifications.base.Driver` contract against
`ntfy <https://ntfy.sh>`_, supporting both the hosted instance and self-hosted
deployments. See ``PRD.md`` §8.3 — ntfy is one of the two first-class channels
for MVP.

Publishing is an HTTP POST to ``<base_url>/<topic>`` with the notification body
as the request body and metadata (title, priority, click URL, tags, auth)
carried in headers. See `ntfy publish docs
<https://docs.ntfy.sh/publish/>`_ for the full reference.

Security posture: we never let an auth credential (access token, Basic
password) make it into an exception string. ``DriverDeliveryError`` contains
only HTTP status + a truncated, credential-redacted slice of the response
body.
"""

from __future__ import annotations

import base64
import json
from typing import Any, ClassVar

import httpx

from agentdrop.models._types import Priority
from agentdrop.notifications.base import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
)

_TIMEOUT_SECONDS = 10.0
_RESPONSE_SNIPPET_CHARS = 200


class NtfyDriver(Driver):
    """Driver for ntfy topics (hosted and self-hosted)."""

    driver_name: ClassVar[str] = "ntfy"

    _priority_map: ClassVar[dict[str, int]] = {
        "low": 2,
        "normal": 3,
        "high": 4,
        "urgent": 5,
    }

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate an ntfy config dict.

        Re-uses ``__init__``'s checks (topic, base_url, auth combo). The
        instance is discarded; only the validation side-effects matter.
        Issue #14 E4.
        """
        cls(config)

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)

        topic = config.get("topic")
        if not isinstance(topic, str) or not topic.strip():
            raise DriverConfigError("ntfy: 'topic' is required and must be a non-empty string")
        self._topic = topic.strip()

        base_url = config.get("base_url", "https://ntfy.sh")
        if not isinstance(base_url, str) or not base_url.strip():
            raise DriverConfigError("ntfy: 'base_url' must be a non-empty string")
        if not (base_url.startswith("http://") or base_url.startswith("https://")):
            raise DriverConfigError("ntfy: 'base_url' must start with http:// or https://")
        self._base_url = base_url.rstrip("/")

        access_token = config.get("access_token")
        username = config.get("username")
        password = config.get("password")

        if access_token is not None and username is not None:
            raise DriverConfigError(
                "ntfy: provide either 'access_token' or 'username'/'password', not both"
            )

        if access_token is not None and not isinstance(access_token, str):
            raise DriverConfigError("ntfy: 'access_token' must be a string")

        if username is not None and (
            not isinstance(username, str) or not isinstance(password, str)
        ):
            raise DriverConfigError(
                "ntfy: 'username' and 'password' must both be strings when basic auth is used"
            )

        self._access_token: str | None = access_token
        self._username: str | None = username
        self._password: str | None = password

    def _client(self) -> httpx.Client:
        """Return the HTTP client used for publishing.

        Exposed as a method so tests can monkeypatch it with an
        :class:`httpx.MockTransport`-backed client.
        """
        return httpx.Client(timeout=_TIMEOUT_SECONDS)

    def _auth_header(self) -> dict[str, str]:
        if self._access_token is not None:
            return {"Authorization": f"Bearer {self._access_token}"}
        if self._username is not None and self._password is not None:
            raw = f"{self._username}:{self._password}".encode()
            encoded = base64.b64encode(raw).decode("ascii")
            return {"Authorization": f"Basic {encoded}"}
        return {}

    def _redact(self, text: str) -> str:
        """Strip any configured credential out of ``text``."""
        for secret in (self._access_token, self._password):
            if secret:
                text = text.replace(secret, "[redacted]")
        return text

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        publish_url = f"{self._base_url}/{self._topic}"

        headers: dict[str, str] = {
            "Title": title,
            "Priority": str(self._priority_map[priority]),
            "Click": url,
        }
        headers.update(self._auth_header())

        if extras:
            tags = extras.get("ntfy_tags")
            if tags:
                if not isinstance(tags, list) or not all(isinstance(t, str) for t in tags):
                    raise DriverDeliveryError("ntfy: 'ntfy_tags' must be a list of strings")
                headers["Tags"] = ",".join(tags)

        try:
            with self._client() as client:
                response = client.post(
                    publish_url,
                    content=body.encode("utf-8"),
                    headers=headers,
                )
        except httpx.TimeoutException:
            raise DriverDeliveryError("ntfy: request timed out after 10s") from None
        except httpx.HTTPError as exc:
            # Redact any secret that might have leaked into the transport error str.
            raise DriverDeliveryError(f"ntfy: network error ({self._redact(str(exc))})") from None

        if response.status_code >= 400:
            snippet = self._redact(response.text[:_RESPONSE_SNIPPET_CHARS])
            raise DriverDeliveryError(f"ntfy: HTTP {response.status_code} from upstream: {snippet}")

        provider_id: str | None = None
        try:
            payload = response.json()
        except (json.JSONDecodeError, ValueError):
            payload = None
        if isinstance(payload, dict):
            raw_id = payload.get("id")
            if isinstance(raw_id, str):
                provider_id = raw_id

        return DeliveryResult(ok=True, driver=self.driver_name, provider_id=provider_id)


# Self-registration so ``from agentdrop.notifications import ntfy`` is enough
# to make the driver discoverable via the registry. If Agent A's package
# ``__init__.py`` hasn't landed yet, this import will fail at module load —
# which is the right behaviour, since the driver isn't usable until the base
# exists. See the integration note in the orchestrator handoff.
# TODO(orchestrator): ensure ``src/agentdrop/notifications/__init__.py``
# contains ``from .ntfy import NtfyDriver; register_driver("ntfy", NtfyDriver)``
# (or equivalent import side-effect) so this registration actually runs.
try:  # pragma: no cover - defensive: registry may not exist yet during bring-up
    from agentdrop.notifications import register_driver

    register_driver("ntfy", NtfyDriver)
except ImportError:
    pass
