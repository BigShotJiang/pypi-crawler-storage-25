"""Web Push driver — delivers notifications to subscribed PWA clients.

Unlike the other drivers in this package, ``WebPushDriver`` does not talk
to a single remote provider. It iterates over every row in
``push_subscriptions`` and POSTs an encrypted payload to each device's
push service URL (Apple, Mozilla autopush, FCM, …) using VAPID auth.

Architecture notes:

- VAPID keys come from ``AGENTDROP_VAPID_*`` env vars (see ``Settings``).
  All three (public + private + subject) must be set or the driver fails
  at instantiation. Generate a fresh keypair with ``make vapid-keys``.
- Subscriptions live in the local DB. The driver opens its own session
  via ``SessionLocal`` because the existing ``Driver`` contract doesn't
  thread a request session in. Tests inject an alternative session
  factory via ``WebPushDriver(..., session_factory=...)``.
- A 410 ``Gone`` from the push service is the documented signal that a
  subscription has been revoked or expired — when we see it we delete
  the row so we stop trying.
- The payload the browser receives is a tiny JSON blob; the service
  worker (PR 5c) parses it and calls ``showNotification``. Keep the
  payload schema small — push services cap encrypted payloads at ~4KB
  and we don't want to flirt with the limit.
"""

from __future__ import annotations

import json
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, ClassVar

import structlog
from py_vapid import Vapid
from py_vapid.utils import b64urldecode
from pywebpush import WebPushException, webpush
from sqlalchemy import delete, select, update
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import SessionLocal, get_engine
from agentdrop.models._types import Priority
from agentdrop.models.push_subscription import PushSubscription
from agentdrop.net.ssrf import OutboundUrlError, validate_outbound_url

from .base import DeliveryResult, Driver, DriverConfigError, DriverDeliveryError

logger = structlog.get_logger(__name__)

_REQUEST_TIMEOUT_SECONDS = 10.0


class WebPushDriver(Driver):
    """Driver that fans out to every stored Web Push subscription.

    Config is read from app settings (``AGENTDROP_VAPID_*``), not from
    the channel's ``config_json`` — Web Push has nowhere meaningful for
    per-channel knobs to live, and stuffing the VAPID private key into
    a DB JSON column would be a footgun.
    """

    driver_name: ClassVar[str] = "web_push"

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate a Web Push config dict.

        Web Push reads its operational config (VAPID keys) from app-level
        settings, not from the per-channel ``config_json``. There's nothing
        meaningful to put in the config dict, so we only enforce that it
        is a dict. We deliberately do **not** check VAPID env presence —
        that's a deployment concern surfaced at startup (issue #14 E3) and
        a partial VAPID config rejected at boot time can't reach this save
        handler at all. Issue #14 E4.
        """
        if not isinstance(config, dict):
            raise DriverConfigError("web_push: config must be a JSON object")

    def __init__(
        self,
        config: dict[str, Any],
        *,
        session_factory: Callable[[], Session] | None = None,
    ) -> None:
        super().__init__(config)
        settings = get_settings()
        public = settings.vapid_public_key
        private = settings.vapid_private_key
        subject = settings.vapid_subject

        if not public or not private or not subject:
            raise DriverConfigError(
                "web_push: AGENTDROP_VAPID_PUBLIC_KEY, "
                "AGENTDROP_VAPID_PRIVATE_KEY and AGENTDROP_VAPID_SUBJECT "
                "must all be set. Generate a keypair with 'make vapid-keys'."
            )

        # Validate the key is a 32-byte P-256 scalar, then hand py_vapid
        # the *base64url-encoded* form — its ``Vapid.from_raw`` does its
        # own ``b64urldecode`` internally, so passing raw bytes would
        # double-decode into a garbage scalar whose public key no longer
        # matches the one we advertise to subscribers (Apple rejects the
        # resulting push with ``VapidPkHashMismatch``).
        private_b64 = private.encode("ascii")
        try:
            raw = b64urldecode(private_b64)
        except (ValueError, TypeError, UnicodeEncodeError) as exc:
            raise DriverConfigError(
                f"web_push: AGENTDROP_VAPID_PRIVATE_KEY is malformed: {exc}"
            ) from exc
        if len(raw) != 32:
            raise DriverConfigError(
                "web_push: AGENTDROP_VAPID_PRIVATE_KEY is malformed: "
                f"expected 32 bytes after base64url decode, got {len(raw)}"
            )
        try:
            self._vapid = Vapid.from_raw(private_b64)
        except (ValueError, TypeError) as exc:
            raise DriverConfigError(
                f"web_push: AGENTDROP_VAPID_PRIVATE_KEY is malformed: {exc}"
            ) from exc

        self._vapid_subject = subject
        # Bind every session to the *current* engine (matches the pattern
        # in ``get_db``). Tests that swap ``AGENTDROP_DATABASE_URL`` and
        # rebuild the engine via ``get_engine.cache_clear()`` then get a
        # session against the fresh DB without needing to inject a custom
        # factory.
        self._session_factory = session_factory or (lambda: SessionLocal(bind=get_engine()))

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        extras = extras or {}
        payload_json = json.dumps(
            {
                "title": title,
                "body": body,
                "url": url,
                "drop_id": extras.get("drop_id"),
            },
            ensure_ascii=False,
            separators=(",", ":"),
        )

        settings = get_settings()
        cap = max(0, int(settings.max_push_subscriptions))

        with self._session_factory() as session:
            # Iterate subscriptions in chunks (server-side via yield_per) so
            # we don't materialise every row at once. Cap the total processed
            # at ``settings.max_push_subscriptions``: if there are more rows,
            # log a warning and skip the rest. Long term this should be a
            # background queue (see issue #14 E1 acceptance notes).
            #
            # We fetch ``cap + 1`` to detect overflow without paginating the
            # entire table. Anything beyond the (cap+1)th row stays unknown
            # to this loop — that's fine, we already know we're over cap.
            stmt = (
                select(PushSubscription)
                .order_by(PushSubscription.created_at, PushSubscription.id)
                .limit(cap + 1)
                .execution_options(yield_per=50)
            )

            successes = 0
            attempted = 0
            last_error: str | None = None
            stale_ids: list[str] = []
            live_ids: list[str] = []
            over_cap = False

            for sub in session.execute(stmt).scalars():
                if attempted >= cap:
                    over_cap = True
                    break
                attempted += 1
                ok, detail = self._send_one(sub, payload_json)
                if ok:
                    successes += 1
                    live_ids.append(sub.id)
                elif detail == "stale":
                    stale_ids.append(sub.id)
                else:
                    last_error = detail
                    live_ids.append(sub.id)

            if over_cap:
                # We don't know the exact total beyond cap+1 without a second
                # query; phrase the warning so operators know to raise the
                # cap or run a count themselves.
                logger.warning(
                    "web_push_subscription_cap_reached",
                    cap=cap,
                    hint="Raise AGENTDROP_MAX_PUSH_SUBSCRIPTIONS or move to a background queue.",
                )

            if attempted == 0 and not over_cap:
                # No devices subscribed yet — that's not a failure, just a
                # no-op. The drop is in the DB; the user can still open
                # the inbox to see it.
                return DeliveryResult(
                    ok=True,
                    driver=self.driver_name,
                    detail="no subscriptions",
                )

            now = datetime.now(UTC)
            if successes and live_ids:
                # Bump last_used_at on every sub we tried that didn't 410.
                session.execute(
                    update(PushSubscription)
                    .where(PushSubscription.id.in_(live_ids))
                    .values(last_used_at=now)
                )
            if stale_ids:
                session.execute(delete(PushSubscription).where(PushSubscription.id.in_(stale_ids)))
            session.commit()

        if successes:
            detail = f"sent to {successes}/{attempted} devices"
            if over_cap:
                detail += " (cap reached, some skipped)"
            return DeliveryResult(
                ok=True,
                driver=self.driver_name,
                detail=detail,
            )

        if attempted == 0 and over_cap:
            # cap == 0 with subscriptions present. Treat as a delivery
            # failure so operators see it; they can raise the cap.
            raise DriverDeliveryError(
                "web_push: cap of 0 (AGENTDROP_MAX_PUSH_SUBSCRIPTIONS) blocked all subscriptions"
            )

        # Every attempted send failed and we have no successful detail.
        raise DriverDeliveryError(
            f"web_push: all {attempted} subscriptions failed "
            f"(last error: {last_error or 'unknown'})"
        )

    def _send_one(self, sub: PushSubscription, payload_json: str) -> tuple[bool, str | None]:
        """Push ``payload_json`` to one subscription.

        Returns ``(True, None)`` on success, ``(False, "stale")`` if the
        push service told us the subscription is gone (delete it), or
        ``(False, "<message>")`` for any other failure.
        """
        # Re-validate endpoint at send time. Subscribe-time validation
        # already gates the row; this defends against DNS rebinding (a
        # public hostname that resolves private at send time). Don't
        # delete the row on failure — the endpoint may be transiently
        # mis-resolving and could recover.
        try:
            validate_outbound_url(sub.endpoint)
        except OutboundUrlError as exc:
            logger.warning(
                "web_push_endpoint_blocked",
                subscription_id=sub.id,
                error=str(exc),
            )
            return False, f"endpoint blocked: {exc}"

        subscription_info = {
            "endpoint": sub.endpoint,
            "keys": {"p256dh": sub.p256dh, "auth": sub.auth},
        }
        try:
            webpush(
                subscription_info=subscription_info,
                data=payload_json,
                vapid_private_key=self._vapid,
                vapid_claims={"sub": self._vapid_subject},
                timeout=_REQUEST_TIMEOUT_SECONDS,
            )
        except WebPushException as exc:
            response = getattr(exc, "response", None)
            status = getattr(response, "status_code", None)
            # 404 / 410: subscription is gone. Documented in RFC 8030 §5
            # and the Web Push spec — treat the row as garbage and prune.
            if status in (404, 410):
                logger.info(
                    "web_push_pruning_stale_subscription",
                    subscription_id=sub.id,
                    http_status=status,
                )
                return False, "stale"
            return False, f"HTTP {status}: {exc}"
        except Exception as exc:
            return False, f"{exc.__class__.__name__}: {exc}"
        return True, None
