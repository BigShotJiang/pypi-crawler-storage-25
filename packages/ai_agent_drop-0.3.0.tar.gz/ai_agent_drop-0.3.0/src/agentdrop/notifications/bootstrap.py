"""First-run bootstrapping of the default notification channel.

When an operator has generated a VAPID keypair (so Web Push is viable)
and there are no ``channels`` rows yet, create a default ``web_push``
channel so push delivery works end-to-end as soon as they subscribe a
device. This is strictly additive — any existing channel (default or
not) suppresses the bootstrap. Users who delete the auto-created row
don't get it back on the next restart.

Idempotent by design: called unconditionally at app startup, no-ops
once any channel exists.
"""

from __future__ import annotations

import structlog
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from agentdrop.config import Settings
from agentdrop.models.channel import Channel

logger = structlog.get_logger(__name__)

_DEFAULT_WEB_PUSH_NAME = "Web Push"


def ensure_default_web_push_channel(db: Session, settings: Settings) -> Channel | None:
    """Create a default ``web_push`` channel on first run, if appropriate.

    Returns the newly-created row, or ``None`` when the bootstrap was
    skipped (already bootstrapped, or VAPID not configured).
    """
    if not (settings.vapid_public_key and settings.vapid_private_key and settings.vapid_subject):
        return None

    existing = db.execute(select(func.count(Channel.id))).scalar_one()
    if existing:
        return None

    channel = Channel(
        name=_DEFAULT_WEB_PUSH_NAME,
        driver="web_push",
        config_json={},
        is_default=True,
    )
    db.add(channel)
    db.commit()
    db.refresh(channel)
    logger.info(
        "bootstrap_default_web_push_channel_created",
        channel_id=channel.id,
    )
    return channel
