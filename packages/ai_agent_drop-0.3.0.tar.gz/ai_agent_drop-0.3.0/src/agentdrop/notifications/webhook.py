"""Generic webhook notification driver.

Posts a JSON payload to a user-defined URL. This is the "catch-all" channel
for integrations that don't have (or don't need) a bespoke driver: Home
Assistant, Discord incoming webhooks, Mattermost/Slack incoming webhooks,
bespoke receivers, and — per ``PRD.md`` §15 note 6 — Thinkr's API.

The shape of the outbound JSON is configurable via ``payload_style``:

- ``agentdrop`` (default): structured object with all the fields a downstream
  receiver might want. Use this for Home Assistant, Thinkr, and bespoke
  endpoints you control.
- ``discord``: Discord's ``{"content": "..."}`` incoming-webhook shape.
- ``slack``: Slack's legacy ``{"text": "...", "attachments": [...]}`` shape,
  which Mattermost also honours.

See ``PRD.md`` §8.3 for product intent and the task brief for the locked
config schema + redaction rules. The body sent is at most a 500-char preview
of the drop's markdown content — webhook endpoints commonly impose size
limits, and this is a notification-class surface, not a document transport.
"""

from __future__ import annotations

import base64
from typing import Any, ClassVar
from urllib.parse import urlparse

import httpx

from agentdrop.models._types import Priority
from agentdrop.net.ssrf import OutboundUrlError, validate_outbound_url
from agentdrop.notifications.base import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
)

_TIMEOUT_SECONDS = 10.0
_RESPONSE_SNIPPET_CHARS = 200
_CONTENT_PREVIEW_CHARS = 500

_ALLOWED_METHODS = frozenset({"POST", "PUT"})
_ALLOWED_STYLES = frozenset({"agentdrop", "discord", "slack"})


class WebhookDriver(Driver):
    """Driver that POSTs (or PUTs) a JSON payload to an arbitrary URL."""

    driver_name: ClassVar[str] = "webhook"

    # Slack attachment colors keyed by Agent Drop ``Priority``. Discord's
    # ``content`` payload has no color field, so this mapping only applies
    # to the Slack/Mattermost style.
    _priority_slack_color: ClassVar[dict[str, str]] = {
        "low": "#9ca3af",
        "normal": "#6b7280",
        "high": "#f59e0b",
        "urgent": "#dc2626",
    }

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate a webhook config dict.

        Re-uses ``__init__``'s checks (URL shape, method, payload style,
        auth combo, header types, SSRF guard). The instance is discarded;
        only the validation side-effects matter. Issue #14 E4.
        """
        cls(config)

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)

        url = config.get("url")
        if not isinstance(url, str) or not url.strip():
            raise DriverConfigError("webhook: 'url' is required and must be a non-empty string")
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https") or not parsed.netloc:
            raise DriverConfigError("webhook: 'url' must be an http:// or https:// URL")
        try:
            validate_outbound_url(url)
        except OutboundUrlError as exc:
            raise DriverConfigError(f"webhook: 'url' is not allowed: {exc}") from exc
        self._url = url

        method = config.get("method", "POST")
        if not isinstance(method, str) or method.upper() not in _ALLOWED_METHODS:
            raise DriverConfigError("webhook: 'method' must be 'POST' or 'PUT'")
        self._method = method.upper()

        headers = config.get("headers", {})
        if not isinstance(headers, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in headers.items()
        ):
            raise DriverConfigError("webhook: 'headers' must be a dict of str -> str")
        self._user_headers: dict[str, str] = dict(headers)

        bearer = config.get("bearer")
        basic_user = config.get("basic_user")
        basic_pass = config.get("basic_pass")

        if bearer is not None and (basic_user is not None or basic_pass is not None):
            raise DriverConfigError(
                "webhook: provide either 'bearer' or 'basic_user'/'basic_pass', not both"
            )
        if bearer is not None and not isinstance(bearer, str):
            raise DriverConfigError("webhook: 'bearer' must be a string")
        if (basic_user is None) != (basic_pass is None):
            raise DriverConfigError(
                "webhook: 'basic_user' and 'basic_pass' must both be set or both omitted"
            )
        if basic_user is not None and (
            not isinstance(basic_user, str) or not isinstance(basic_pass, str)
        ):
            raise DriverConfigError("webhook: 'basic_user' and 'basic_pass' must both be strings")

        self._bearer: str | None = bearer
        self._basic_user: str | None = basic_user
        self._basic_pass: str | None = basic_pass

        style = config.get("payload_style", "agentdrop")
        if not isinstance(style, str) or style not in _ALLOWED_STYLES:
            raise DriverConfigError(
                "webhook: 'payload_style' must be one of 'agentdrop', 'discord', 'slack'"
            )
        self._payload_style = style

    # ------------------------------------------------------------------ helpers

    def _client(self) -> httpx.Client:
        """Return a fresh sync ``httpx.Client`` with our 10s timeout.

        Tests monkeypatch this method to inject an :class:`httpx.MockTransport`.
        Keep the signature stable.
        """
        return httpx.Client(timeout=_TIMEOUT_SECONDS)

    def _auth_header(self) -> dict[str, str]:
        if self._bearer is not None:
            return {"Authorization": f"Bearer {self._bearer}"}
        if self._basic_user is not None and self._basic_pass is not None:
            raw = f"{self._basic_user}:{self._basic_pass}".encode()
            encoded = base64.b64encode(raw).decode("ascii")
            return {"Authorization": f"Basic {encoded}"}
        return {}

    def _redact(self, text: str) -> str:
        """Strip any configured credential out of ``text``.

        Mirrors the ntfy driver's approach: we null out the bearer token and
        the basic-auth password if either happens to appear in the message.
        The basic-auth *username* is not considered a secret.
        """
        for secret in (self._bearer, self._basic_pass):
            if secret:
                text = text.replace(secret, "[redacted]")
        return text

    def _build_payload(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any],
    ) -> dict[str, Any]:
        """Shape the outbound JSON body per configured ``payload_style``."""
        if self._payload_style == "discord":
            return {"content": f"{title}\n{body}\n{url}"}

        if self._payload_style == "slack":
            return {
                "text": title,
                "attachments": [
                    {
                        "color": self._priority_slack_color[priority],
                        "text": f"{body}\n{url}",
                    }
                ],
            }

        # "agentdrop" — the default structured shape. ``content_md`` is never
        # sent whole; we include a 500-char preview so the receiver can show
        # a teaser without blowing up size-limited endpoints.
        content_md = extras.get("content_md") or ""
        if not isinstance(content_md, str):
            content_md = ""
        content_preview = content_md[:_CONTENT_PREVIEW_CHARS]

        tags = extras.get("tags", [])
        if not isinstance(tags, list):
            tags = []

        return {
            "title": title,
            "body": body,
            "content_preview": content_preview,
            "url": url,
            "priority": priority,
            "tags": tags,
            "source": extras.get("source"),
            "drop_id": extras.get("drop_id"),
            "created_at": extras.get("created_at"),
        }

    # ------------------------------------------------------------------ send

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        extras = extras or {}
        payload = self._build_payload(
            title=title,
            body=body,
            url=url,
            priority=priority,
            extras=extras,
        )

        # Order matters: user-supplied headers first, then auth, then
        # Content-Type — Content-Type wins so a caller can't accidentally
        # (or otherwise) force a mismatched encoding on a JSON body.
        headers: dict[str, str] = {}
        headers.update(self._user_headers)
        headers.update(self._auth_header())
        headers["Content-Type"] = "application/json"

        # Re-validate at send time — defends against DNS rebinding where a
        # hostname resolved public at config save but resolves private now.
        try:
            validate_outbound_url(self._url)
        except OutboundUrlError as exc:
            raise DriverDeliveryError(f"webhook: outbound URL no longer allowed: {exc}") from exc

        try:
            with self._client() as client:
                response = client.request(
                    self._method,
                    self._url,
                    json=payload,
                    headers=headers,
                    timeout=_TIMEOUT_SECONDS,
                )
        except httpx.TimeoutException:
            raise DriverDeliveryError(
                f"webhook: request timed out after {_TIMEOUT_SECONDS:.0f}s"
            ) from None
        except httpx.HTTPError as exc:
            raise DriverDeliveryError(
                f"webhook: network error ({self._redact(str(exc))})"
            ) from None

        status = response.status_code
        if 200 <= status < 300:
            return DeliveryResult(ok=True, driver=self.driver_name)

        snippet = self._redact(response.text[:_RESPONSE_SNIPPET_CHARS])
        raise DriverDeliveryError(f"webhook: HTTP {status} from upstream: {snippet}")


# Self-registration so ``from agentdrop.notifications import webhook`` is
# enough to make the driver discoverable via the registry. Mirrors the
# pattern used by :mod:`agentdrop.notifications.ntfy` and
# :mod:`agentdrop.notifications.apprise_driver`.
#
# TODO(orchestrator): ensure ``src/agentdrop/notifications/__init__.py``
# contains ``from . import webhook as _webhook  # noqa: F401`` (placed right
# after the matching ntfy line) so this registration fires at runtime. The
# test suite force-imports this module explicitly, so tests don't depend on
# that edit.
try:  # pragma: no cover - defensive: registry may not exist yet during bring-up
    from agentdrop.notifications import register_driver

    register_driver("webhook", WebhookDriver)
except (ImportError, ValueError):
    # ValueError: registry module already imported us and registered — benign.
    pass
