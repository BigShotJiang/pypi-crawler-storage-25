"""Glue between drop creation and outbound notifications.

The POST ``/api/v1/drops`` handler calls :func:`send_drop_notification` after
a drop has been persisted. Everything here is best-effort: the drop is
already in the DB, so we never raise — every failure mode maps to a
human-readable warning string appended to the API response (see PRD §8.1:
"if no channels are configured the drop is stored and the API returns a
warning header but still succeeds").

Channel resolution is delegated to :func:`resolve_channel`, which first
checks routing rules (PRD §7) for a ``(source, priority)`` match, then
falls back to the default DB channel. All channels are managed through
the settings UI — see that module's docstring for precedence rules.

Failure observability (issue #14 E2): every error class also writes a
``notification_failed`` row to ``events`` so operators have an audit
trail. The ``detail_json`` is hand-shaped — only the driver short name,
the error class name, and a redacted error message ever land there.
"""

from __future__ import annotations

from typing import Any

import structlog
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from agentdrop.models.drop import Drop
from agentdrop.models.event import Event
from agentdrop.notifications import (
    DriverConfigError,
    DriverDeliveryError,
    get_driver,
)
from agentdrop.notifications.resolver import resolve_channel

logger = structlog.get_logger("agentdrop.notifications.send")

# Cap the redacted error message stored in the ``events`` row. Driver-level
# errors are already credential-redacted upstream, but we still don't need
# 4kB stack-trace strings landing in JSON.
_DETAIL_MESSAGE_CAP = 500


def _record_failure(
    db: Session,
    *,
    drop_id: str,
    driver: str | None,
    error_class: str,
    message: str,
) -> None:
    """Append a ``notification_failed`` event for this drop.

    Best-effort: a DB hiccup writing the event must not surface as a
    request failure. The drop is already persisted; the warning string
    is what the API response shows the caller. Issue #14 E2.
    """
    detail: dict[str, Any] = {
        "driver": driver,
        "error_class": error_class,
        # Driver classes already redact credentials in their exception
        # text; we cap length here to keep ``events.detail_json`` small.
        "message": message[:_DETAIL_MESSAGE_CAP],
    }
    try:
        db.add(Event(drop_id=drop_id, kind="notification_failed", detail_json=detail))
        db.commit()
    except SQLAlchemyError:
        # Don't let event bookkeeping break the caller. Log + roll back so
        # the surrounding session stays usable for the response.
        logger.exception("notification_event_record_failed", drop_id=drop_id)
        db.rollback()


def send_drop_notification(drop: Drop, base_url: str, db: Session) -> list[str]:
    """Fire a single notification for ``drop``; return any warnings.

    Never raises. Each failure class maps to one of the strings documented
    below — these are user-visible in the POST response's ``warnings`` list:

    - ``"no channel configured"`` — no DB ``Channel`` row matched this
      drop's routing. Add one via Settings → Channels. (Not recorded as
      a ``notification_failed`` event — there's no driver to attribute
      it to and it's an operator-config gap, not a delivery failure.)
    - ``"channel misconfigured: <detail>"`` — driver rejected the config
      (unknown name, missing required key, bad type).
    - ``"notification delivery failed: <detail>"`` — upstream provider
      returned an error or was unreachable.
    - ``"notification driver crashed"`` — anything else. Logged at ERROR
      with traceback so operators can dig in.

    The last three failure classes also append a ``notification_failed``
    event to the ``events`` table; see :func:`_record_failure`.
    """
    structlog.contextvars.bind_contextvars(drop_id=drop.id, drop_short_id=drop.short_id)
    resolved = resolve_channel(db, source=drop.source, priority=drop.priority)
    if resolved is None:
        return ["no channel configured"]

    driver_name, config = resolved
    structlog.contextvars.bind_contextvars(driver=driver_name)
    url = f"{base_url.rstrip('/')}/d/{drop.short_id}"

    try:
        driver = get_driver(driver_name, config)
    except DriverConfigError as exc:
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class="DriverConfigError",
            message=str(exc),
        )
        return [f"channel misconfigured: {exc}"]
    except Exception as exc:
        logger.exception("driver_instantiation_failed", driver=driver_name)
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class=exc.__class__.__name__,
            message="driver instantiation crashed",
        )
        return ["notification driver crashed"]

    try:
        result = driver.send(
            title=drop.title,
            body=drop.body,
            url=url,
            priority=drop.priority,
            extras={
                "drop_id": drop.id,
                "source": drop.source,
                "tags": drop.tags_json or [],
                "content_md": drop.content_md,
                "created_at": drop.created_at.isoformat() if drop.created_at else None,
                "external_url": drop.external_url,
            },
        )
    except DriverConfigError as exc:
        # Some drivers defer a couple of config checks until send time (e.g.
        # validating a shape in ``extras``). Treat them the same way.
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class="DriverConfigError",
            message=str(exc),
        )
        return [f"channel misconfigured: {exc}"]
    except DriverDeliveryError as exc:
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class="DriverDeliveryError",
            message=str(exc),
        )
        return [f"notification delivery failed: {exc}"]
    except Exception as exc:
        logger.exception("notification_driver_crashed", driver=driver_name, drop_id=drop.id)
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class=exc.__class__.__name__,
            message="driver crashed during send",
        )
        return ["notification driver crashed"]

    if not result.ok:
        # Drivers *should* raise on failure rather than return ok=False, but
        # defensive: treat a falsy result as a delivery failure so we never
        # silently swallow it.
        detail = result.detail or "driver reported failure"
        _record_failure(
            db,
            drop_id=drop.id,
            driver=driver_name,
            error_class="DriverReportedFailure",
            message=detail,
        )
        return [f"notification delivery failed: {detail}"]

    logger.info(
        "drop_notified",
        drop_id=drop.id,
        driver=result.driver,
        provider_id=result.provider_id,
    )
    return []
