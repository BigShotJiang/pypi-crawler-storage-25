"""Apprise notification driver.

Bridges Agent Drop to the `Apprise <https://github.com/caronc/apprise>`_
library, which unlocks 100+ notification services via a single URL-based
configuration scheme (``pover://``, ``tgram://``, ``slack://``, …). See
``PRD.md`` §8.3 — Apprise is the catch-all fallback alongside the first-class
Pushover and ntfy drivers.

Module name is ``apprise_driver.py`` (not ``apprise.py``) to avoid shadowing
the top-level :mod:`apprise` package at import time.

Security posture: Apprise URLs carry credentials (tokens, passwords) inline.
We **never** include a raw URL in an exception message; the only identifier
that leaves this module is the URL's scheme (e.g. ``"pover"``), stitched
together with ``://<redacted>`` when we have to name one.
"""

from __future__ import annotations

from typing import Any, ClassVar
from urllib.parse import urlsplit

import apprise

from agentdrop.models._types import Priority
from agentdrop.net.ssrf import OutboundUrlError, validate_outbound_url
from agentdrop.notifications.base import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
)

_TIMEOUT_SECONDS = 10

_VALID_BODY_FORMATS = ("text", "markdown", "html")

_BODY_FORMAT_MAP: dict[str, str] = {
    "text": apprise.NotifyFormat.TEXT,
    "markdown": apprise.NotifyFormat.MARKDOWN,
    "html": apprise.NotifyFormat.HTML,
}


def _redact_url(url: str) -> str:
    """Return a credential-free identifier for ``url`` (scheme only)."""
    try:
        scheme = urlsplit(url).scheme or "unknown"
    except ValueError:
        scheme = "unknown"
    return f"{scheme}://<redacted>"


class AppriseDriver(Driver):
    """Driver backed by the Apprise multi-service notification library.

    Config keys:

    - ``urls`` (required): non-empty list of Apprise URLs. Each URL targets a
      distinct service/channel (e.g. ``"pover://user@token"``,
      ``"tgram://bottoken/chatid"``, ``"slack://TOKEN/CHANNEL"``).
    - ``tag`` (optional): if set, passed as ``tag=`` to :meth:`apprise.Apprise.notify`
      so a single driver instance can route a drop to a subset of its URLs.
    - ``body_format`` (optional, default ``"markdown"``): one of ``"text"``,
      ``"markdown"``, ``"html"``. Apprise renders per-provider from this hint.
    """

    driver_name: ClassVar[str] = "apprise"

    # Agent Drop's four-level ``Priority`` maps onto Apprise's ``NotifyType``.
    # ``SUCCESS`` is intentionally unused — reserved for a future
    # "delivery-confirmed" signal. ``FAILURE`` is the "red pager" on every
    # Apprise-supported service that distinguishes severities.
    _priority_map: ClassVar[dict[str, str]] = {
        "low": apprise.NotifyType.INFO,
        "normal": apprise.NotifyType.INFO,
        "high": apprise.NotifyType.WARNING,
        "urgent": apprise.NotifyType.FAILURE,
    }

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate an Apprise config dict.

        Re-uses ``__init__``'s checks (urls list, body_format, tag, SSRF
        guard for raw-HTTP schemes, Apprise URL parse). The Apprise
        instance is built and discarded — same parser path as ``send()``
        but without firing any actual notifications. Issue #14 E4.
        """
        cls(config)

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)

        urls = config.get("urls")
        if not isinstance(urls, list) or not urls:
            raise DriverConfigError(
                "apprise: 'urls' is required and must be a non-empty list of strings"
            )
        for entry in urls:
            if not isinstance(entry, str) or not entry.strip():
                raise DriverConfigError("apprise: every entry in 'urls' must be a non-empty string")
            # SSRF guard. Apprise dispatches the actual HTTP requests
            # internally, so we can't intercept the outbound call — but
            # for "raw HTTP" schemes (json://, xml://, form://, http(s)://)
            # the destination is user-controllable and worth validating
            # at config time. Service-specific schemes (pover://, tgram://,
            # …) point at hardcoded provider endpoints and pass through.
            try:
                validate_outbound_url(entry)
            except OutboundUrlError as exc:
                # Use redacted scheme — Apprise URLs can carry credentials
                # inline, so never surface the raw entry in an error.
                raise DriverConfigError(
                    f"apprise: URL not allowed for service {_redact_url(entry)}: {exc}"
                ) from exc

        body_format = config.get("body_format", "markdown")
        if body_format not in _VALID_BODY_FORMATS:
            raise DriverConfigError(
                f"apprise: 'body_format' must be one of {_VALID_BODY_FORMATS!r}"
            )
        self._body_format = _BODY_FORMAT_MAP[body_format]

        tag = config.get("tag")
        if tag is not None and (not isinstance(tag, str) or not tag.strip()):
            raise DriverConfigError("apprise: 'tag' must be a non-empty string if provided")
        self._tag: str | None = tag

        self._urls: list[str] = list(urls)

        # Build the Apprise instance up-front so configuration errors surface
        # at ``__init__`` time rather than on first ``send``.
        self._apobj = self._build_apprise()
        for entry in self._urls:
            # ``Apprise.add`` returns False if the URL can't be parsed into a
            # recognised plugin; surface that as a config problem, with the
            # scheme only (never the raw URL — it may contain credentials).
            if not self._apobj.add(entry):
                raise DriverConfigError(
                    f"apprise: could not parse URL for service {_redact_url(entry)}"
                )

    def _build_apprise(self) -> apprise.Apprise:
        """Return a fresh :class:`apprise.Apprise` instance.

        Exposed as a method so tests can monkeypatch it to inject a fake that
        records calls without doing any real network I/O.
        """
        return apprise.Apprise()

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        # Apprise has no universal "click URL" field across all providers;
        # some (e.g. Pushover via Apprise) auto-linkify URLs in the body, so
        # appending the drop URL is the most portable way to get a tappable
        # link into the notification on every backend.
        message_body = f"{body}\n\n{url}"

        notify_type = self._priority_map[priority]

        kwargs: dict[str, Any] = {
            "title": title,
            "body": message_body,
            "notify_type": notify_type,
            "body_format": self._body_format,
        }
        if self._tag is not None:
            kwargs["tag"] = self._tag

        try:
            ok = self._apobj.notify(**kwargs)
        except Exception as exc:
            # Apprise's own exceptions aren't a stable hierarchy we can catch
            # narrowly; anything escaping ``notify`` is a delivery failure.
            raise DriverDeliveryError(f"apprise: notify raised {exc.__class__.__name__}") from exc

        if not ok:
            # Apprise logs per-URL detail at WARNING/ERROR via its own logger;
            # we don't re-parse or leak URLs into our exception text.
            raise DriverDeliveryError(
                "apprise: one or more URLs failed; check server logs for per-URL detail"
            )

        return DeliveryResult(ok=True, driver=self.driver_name)


# Registration lives in :mod:`agentdrop.notifications.__init__` alongside the
# Pushover registration — consistent with the explicit pattern used there,
# rather than ntfy's side-effecting self-registration. This keeps driver
# modules free of import-order hazards.
