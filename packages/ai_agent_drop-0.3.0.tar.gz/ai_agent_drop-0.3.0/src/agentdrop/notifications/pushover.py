"""Pushover notification driver.

Implements :class:`agentdrop.notifications.base.Driver` against Pushover's
``/1/messages.json`` endpoint. See the task brief for the priority mapping
and the docstring on :meth:`PushoverDriver.send` for the error taxonomy.

The HTTP client is built per request via :meth:`_client`. Tests monkeypatch
that method to swap in an :class:`httpx.MockTransport`.
"""

from __future__ import annotations

import json
from typing import Any, ClassVar

import httpx

from agentdrop.models._types import Priority

from .base import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
)

_PUSHOVER_ENDPOINT = "https://api.pushover.net/1/messages.json"
_TIMEOUT_SECONDS = 10.0


class PushoverDriver(Driver):
    """Driver for the Pushover push-notification service.

    Required config keys: ``token`` (app token) and ``user`` (user or group
    key). Optional keys: ``device``, ``sound``, ``retry`` (urgent only,
    seconds between retries), ``expire`` (urgent only, seconds before giving
    up), ``url_title_default`` (label on the link button if callers don't
    pass ``extras["url_title"]``).
    """

    driver_name: ClassVar[str] = "pushover"

    # Agent Drop's four-level ``Priority`` collapses onto Pushover's five
    # integer levels. We never emit -2 ("no notification") because it defeats
    # the point of the product.
    _priority_map: ClassVar[dict[str, int]] = {
        "low": -1,
        "normal": 0,
        "high": 1,
        "urgent": 2,
    }

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate a Pushover config dict.

        Re-uses ``__init__``'s checks (token, user, optional knobs). No
        network I/O. Issue #14 E4.
        """
        cls(config)

    def __init__(self, config: dict[str, Any]) -> None:
        super().__init__(config)

        token = config.get("token")
        user = config.get("user")
        if not isinstance(token, str) or not token:
            raise DriverConfigError("pushover: 'token' must be a non-empty string")
        if not isinstance(user, str) or not user:
            raise DriverConfigError("pushover: 'user' must be a non-empty string")

        self._token = token
        self._user = user
        self._device = config.get("device")
        self._sound = config.get("sound")
        # Pushover requires both retry and expire when priority=2; fall back
        # to their documented minimums if the channel config doesn't set them.
        self._retry = int(config.get("retry", 60))
        self._expire = int(config.get("expire", 3600))
        self.url_title_default = config.get("url_title_default", "Open drop")

    def _client(self) -> httpx.Client:
        """Return a fresh sync ``httpx.Client`` with our 10s timeout.

        Tests monkeypatch this method to inject an ``httpx.MockTransport``.
        Keep the signature stable.
        """
        return httpx.Client(timeout=_TIMEOUT_SECONDS)

    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        extras = extras or {}
        mapped_priority = self._priority_map[priority]

        data: dict[str, Any] = {
            "token": self._token,
            "user": self._user,
            "message": body,
            "title": title,
            "url": url,
            "url_title": extras.get("url_title", self.url_title_default),
            "priority": mapped_priority,
        }

        # Pushover mandates retry/expire whenever priority == 2 (emergency).
        # We always populate them when mapped_priority is 2, so a badly
        # configured channel (retry too small, say) fails fast upstream.
        if mapped_priority == 2:
            data["retry"] = self._retry
            data["expire"] = self._expire

        if self._device:
            data["device"] = self._device
        if self._sound:
            data["sound"] = self._sound

        try:
            with self._client() as client:
                response = client.post(_PUSHOVER_ENDPOINT, data=data)
        except httpx.TimeoutException as exc:
            raise DriverDeliveryError(
                f"pushover: request timed out after {_TIMEOUT_SECONDS}s"
            ) from exc
        except httpx.HTTPError as exc:
            # Covers connection errors, DNS issues, etc. Message intentionally
            # terse — we don't want to leak request internals.
            raise DriverDeliveryError(
                f"pushover: network error ({exc.__class__.__name__})"
            ) from exc

        return self._interpret_response(response)

    def _interpret_response(self, response: httpx.Response) -> DeliveryResult:
        """Turn an HTTP response into a :class:`DeliveryResult` or raise.

        Pushover's contract: on success you get 200 with ``{"status": 1,
        "request": "<uuid>"}``. On validation failure you typically get a
        4xx with ``{"status": 0, "errors": ["..."], "request": "..."}``.
        5xx is treated as a transient delivery error with whatever body we
        got back (truncated).
        """
        status = response.status_code

        parsed: dict[str, Any] | None
        try:
            parsed = response.json()
            if not isinstance(parsed, dict):
                parsed = None
        except (json.JSONDecodeError, ValueError):
            parsed = None

        if status == 200 and parsed is not None and parsed.get("status") == 1:
            request_id = parsed.get("request")
            return DeliveryResult(
                ok=True,
                driver=self.driver_name,
                provider_id=request_id if isinstance(request_id, str) else None,
            )

        if 400 <= status < 500 and parsed is not None:
            errors = parsed.get("errors")
            if isinstance(errors, list) and errors:
                joined = "; ".join(str(e) for e in errors)
            else:
                joined = "unspecified validation error"
            raise DriverDeliveryError(f"pushover: HTTP {status}: {joined}")

        # 5xx or unparseable body: surface the status and a trimmed body so
        # operators can diagnose, but cap length to avoid unbounded log spam.
        trimmed = response.text[:200] if response.text else ""
        raise DriverDeliveryError(f"pushover: HTTP {status}: {trimmed!r}")
