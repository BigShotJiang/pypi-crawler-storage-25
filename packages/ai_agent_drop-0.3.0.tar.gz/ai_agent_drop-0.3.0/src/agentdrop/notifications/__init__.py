"""Notification driver registry and factory.

Drivers self-register via :func:`register_driver` at import time so the
rest of the app can look them up by short name (``"pushover"``, ``"ntfy"``,
…). See ``PRD.md`` §8.3 for the product-level driver list and
``base.py`` for the contract drivers implement.
"""

from __future__ import annotations

from typing import Any

from .base import (
    DeliveryResult,
    Driver,
    DriverConfigError,
    DriverDeliveryError,
    DriverError,
)

__all__ = [
    "DRIVERS",
    "DeliveryResult",
    "Driver",
    "DriverConfigError",
    "DriverDeliveryError",
    "DriverError",
    "get_driver",
    "register_driver",
    "validate_driver_config",
]

# Keyed by the lowercase short name; populated by ``register_driver`` calls
# at the bottom of this module and from sibling driver modules.
DRIVERS: dict[str, type[Driver]] = {}


def register_driver(name: str, cls: type[Driver]) -> None:
    """Register ``cls`` under ``name`` (case-insensitive).

    Raises :class:`ValueError` on duplicate registration — two drivers
    competing for the same short name is always a bug, never something we
    should silently overwrite.
    """
    key = name.lower()
    if key in DRIVERS:
        raise ValueError(f"driver already registered: {key!r}")
    DRIVERS[key] = cls


def get_driver(name: str, config: dict[str, Any]) -> Driver:
    """Instantiate the driver registered under ``name`` with ``config``.

    Lookup is case-insensitive. Raises :class:`DriverConfigError` if the
    name isn't known or if the driver rejects the config.
    """
    key = name.lower()
    cls = DRIVERS.get(key)
    if cls is None:
        raise DriverConfigError(f"unknown notification driver: {name!r}")
    # Driver.__init__ is expected to raise DriverConfigError on bad input;
    # let it propagate unchanged. Any other exception is a programming bug.
    return cls(config)


def validate_driver_config(name: str, config: dict[str, Any]) -> None:
    """Validate ``config`` for the driver registered under ``name``.

    Lookup is case-insensitive. Raises :class:`DriverConfigError` if the
    name isn't known or if the driver rejects the config. No network I/O
    beyond what the driver's own validator performs (e.g. webhook does a
    DNS resolution as part of its SSRF guard). Used by the settings UI
    save handler so users see field-level errors before persisting.
    Issue #14 E4.
    """
    key = name.lower()
    cls = DRIVERS.get(key)
    if cls is None:
        raise DriverConfigError(f"unknown notification driver: {name!r}")
    cls.validate_config(config)


# Register built-in drivers. Sibling modules (e.g. ``ntfy.py``) self-register
# at the bottom of their own file so this module stays import-light and we
# avoid circular-import hazards as the driver list grows.
from .pushover import PushoverDriver  # noqa: E402

register_driver("pushover", PushoverDriver)

from . import ntfy as _ntfy  # noqa: E402, F401  (triggers self-registration)
from . import webhook as _webhook  # noqa: E402, F401  (triggers self-registration)
from .apprise_driver import AppriseDriver  # noqa: E402

register_driver("apprise", AppriseDriver)

from .web_push import WebPushDriver  # noqa: E402

register_driver("web_push", WebPushDriver)
