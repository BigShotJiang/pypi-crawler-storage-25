"""Driver contract for outbound notification providers.

This module is the stable surface that both concrete drivers
(:mod:`agentdrop.notifications.pushover`, :mod:`agentdrop.notifications.ntfy`)
and the firing code in the POST handler import from. Keep the public symbols
minimal — see ``PRD.md`` §8.3 for the product intent.

Design notes:

- We use an ABC rather than :class:`typing.Protocol` so subclasses can share
  small helpers (e.g. the sync ``httpx`` client factory) without every driver
  having to re-declare the interface.
- :class:`DeliveryResult` is frozen because a result is an immutable record
  of what happened — downstream code (event log, HTMX refresh) should never
  mutate it.
- Secrets never appear in exception messages. ``DriverConfigError`` gets the
  *shape* of the problem, not the offending value.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, ClassVar

from agentdrop.models._types import Priority


@dataclass(frozen=True)
class DeliveryResult:
    """Outcome of a single :meth:`Driver.send` call.

    ``provider_id`` is whatever the upstream service returns as a request
    handle (Pushover's ``request`` field, ntfy's message id, …). It's purely
    diagnostic — nothing in the app keys off it.
    """

    ok: bool
    driver: str
    detail: str | None = None
    provider_id: str | None = None


class DriverError(Exception):
    """Base class for every notification driver failure.

    Callers should catch this and log/record an ``notification_failed`` event
    rather than letting it escape into the API response.
    """


class DriverConfigError(DriverError):
    """Raised when a channel's ``config_json`` is structurally invalid.

    This is a *configuration* problem (missing token, wrong type) — not a
    provider-side failure. It happens at ``Driver.__init__`` time, before we
    ever touch the network.
    """


class DriverDeliveryError(DriverError):
    """Raised when the upstream provider rejected the request or was unreachable.

    The string form includes whatever safe descriptor we have (HTTP status,
    trimmed response body, ``"timeout"``, ``"network error"``). Never
    includes secrets from the request payload.
    """


class Driver(ABC):
    """Abstract notification driver.

    Subclasses set :attr:`driver_name` as a class var, override ``__init__``
    to validate their slice of the config, and implement :meth:`send`.
    """

    driver_name: ClassVar[str]

    def __init__(self, config: dict[str, Any]) -> None:
        """Validate ``config`` and stash whatever the driver needs.

        Subclasses must call ``super().__init__(config)`` (or not — we don't
        rely on this base storing the dict). They must raise
        :class:`DriverConfigError` on invalid input.
        """
        self._config = config

    @abstractmethod
    def send(
        self,
        *,
        title: str,
        body: str,
        url: str,
        priority: Priority,
        extras: dict[str, Any] | None = None,
    ) -> DeliveryResult:
        """Deliver a single notification.

        ``url`` is the public drop URL (the thing the user taps from the
        notification). ``extras`` is driver-specific overrides — for example,
        Pushover looks at ``extras["url_title"]``. Unknown keys are ignored
        so callers can pass a single superset dict.
        """

    @classmethod
    def validate_config(cls, config: dict[str, Any]) -> None:
        """Validate ``config`` without doing any I/O.

        Used by the settings UI save handler so users see field-level errors
        before persisting an unusable channel (issue #14 E4). The default
        implementation tries to instantiate the driver — that's correct but
        slow for drivers that read app-level state on init (e.g. web_push
        opens a session factory). Drivers can override this with a cheaper
        check that only inspects ``config`` keys and types.

        Must raise :class:`DriverConfigError` on invalid input.
        """
        cls(config)
