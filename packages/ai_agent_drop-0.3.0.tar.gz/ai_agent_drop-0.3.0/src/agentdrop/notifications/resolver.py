"""Resolution of the active outbound channel.

Channels are managed exclusively through the settings UI — the DB
``channels`` table is the sole source of truth. Routing rules
(:class:`~agentdrop.models.routing_rule.RoutingRule`) layer on top to
map ``(source, priority)`` pairs onto specific channels (PRD §7).

Resolution order for a given drop:

1. If any :class:`RoutingRule` matches the drop's ``source`` and
   ``priority``, pick the single most-specific rule (see
   :func:`resolve_channel` for the tie-break rules) and use the channel
   it points at.
2. Otherwise, fall back to the "default channel" logic:

   * at least one :class:`Channel` row → prefer ``is_default=True``,
     else the sole row, else ambiguous;
   * else ``None`` (caller surfaces a "no channel configured" warning).

Keeping this in its own module means every caller (the drops POST
handler, a future background-dispatch worker, the settings ``test``
route) goes through exactly one function — no FastAPI coupling, easy to
unit-test in isolation.
"""

from __future__ import annotations

from typing import Any

import structlog
from sqlalchemy import select
from sqlalchemy.orm import Session

from agentdrop.models.channel import Channel
from agentdrop.models.routing_rule import RoutingRule

logger = structlog.get_logger("agentdrop.notifications.resolver")


def matches(rule: RoutingRule, *, source: str | None, priority: str) -> bool:
    """Return True if ``rule`` applies to a drop with this ``source``/``priority``.

    ``source_pattern == "*"`` matches any source including ``None``.
    ``priority_pattern == "*"`` matches any priority. Non-wildcard
    patterns require an exact string equality match.
    """
    if rule.source_pattern != "*" and rule.source_pattern != source:
        return False
    return not (rule.priority_pattern != "*" and rule.priority_pattern != priority)


def _specificity(rule: RoutingRule) -> int:
    """Lower number = more specific. Used to bucket candidate rules.

    * 0 — both source and priority are explicit values.
    * 1 — exactly one wildcard.
    * 2 — both wildcards (the catch-all).
    """
    src_wild = rule.source_pattern == "*"
    pri_wild = rule.priority_pattern == "*"
    return int(src_wild) + int(pri_wild)


def list_rules(db: Session) -> list[RoutingRule]:
    """Return every routing rule, ordered by ``order`` ASC then ``created_at`` ASC.

    Useful for the settings list page and for the resolver itself — once
    we've fetched them sorted, Python-side bucketing by specificity is
    trivial and avoids a second SQL round-trip.
    """
    stmt = select(RoutingRule).order_by(
        RoutingRule.order.asc(),
        RoutingRule.created_at.asc(),
    )
    return list(db.execute(stmt).scalars().all())


def _resolve_default_channel_row(db: Session) -> Channel | None:
    """Pick the "default" channel from the ``channels`` table, if any.

    Mirrors the precedence described in :func:`resolve_channel`'s
    fallback: exactly-one default → that row; multiple defaults
    (defensive) → most recent; no defaults but a single row → that row;
    ambiguous → ``None``.
    """
    channels = list(db.execute(select(Channel).order_by(Channel.created_at.desc())).scalars().all())
    if not channels:
        return None

    defaults = [c for c in channels if c.is_default]

    if len(defaults) == 1:
        return defaults[0]

    if len(defaults) > 1:
        chosen = defaults[0]  # already ordered created_at DESC
        logger.warning(
            "multiple_default_channels",
            count=len(defaults),
            chosen_channel_id=chosen.id,
        )
        return chosen

    if len(channels) == 1:
        return channels[0]

    # Multiple channels exist, none default — no sensible auto-pick.
    logger.warning(
        "no_default_channel",
        channel_count=len(channels),
        message=(
            "channels configured but none marked default; drop will warn "
            "'no channel configured' until one is set as default in settings"
        ),
    )
    return None


def resolve_channel(
    db: Session,
    *,
    source: str | None = None,
    priority: str = "normal",
) -> tuple[str, dict[str, Any]] | None:
    """Return ``(driver_name, config_dict)`` for the channel that should
    receive a drop with this ``source``/``priority``.

    Routing-rule precedence (most → least specific):

    1. Rules with BOTH source and priority matching (i.e. neither is
       ``"*"``).
    2. Rules with exactly one wildcard.
    3. Rules with both wildcards.

    Within the same specificity band, the rule with the lowest
    ``order`` wins; then the oldest ``created_at``. If multiple rules
    match, the single highest-priority rule wins — routing does NOT
    fan out to multiple channels.

    If no routing rule matches, the call falls back to the default-
    channel logic: DB ``Channel`` row (preferring ``is_default=True``),
    else ``None`` — the caller then surfaces a "no channel configured"
    warning on the POST response.
    """
    rules = list_rules(db)
    candidates = [r for r in rules if matches(r, source=source, priority=priority)]

    if candidates:
        # rules are already ordered by (order ASC, created_at ASC); the
        # first rule in the smallest specificity bucket wins.
        candidates.sort(key=_specificity)
        best_bucket = _specificity(candidates[0])
        winner = next(r for r in candidates if _specificity(r) == best_bucket)

        channel = db.get(Channel, winner.channel_id)
        if channel is not None:
            return channel.driver, dict(channel.config_json or {})

        # Defensive: FK cascade should remove rules whose channel is
        # deleted, but if the DB is in an inconsistent state we'd rather
        # fall through than raise.
        logger.warning(
            "routing_rule_missing_channel",
            rule_id=winner.id,
            channel_id=winner.channel_id,
        )

    chosen = _resolve_default_channel_row(db)
    if chosen is not None:
        return chosen.driver, dict(chosen.config_json or {})

    return None


def resolve_default_channel(db: Session) -> tuple[str, dict[str, Any]] | None:
    """Backward-compatible alias for the "no routing context" resolver.

    The settings "test-fire" button and older callers that don't have a
    drop in hand go through this entry point. It's a thin wrapper over
    :func:`resolve_channel` with default arguments (source=None,
    priority="normal"), so rules that match the catch-all or priority
    "normal" still apply. Callers that care about routing should use
    :func:`resolve_channel` directly.
    """
    return resolve_channel(db)
