"""In-process scheduler for the retention sweep (PRD §13).

The PRD is explicit: "retention sweep runs on a schedule in-process, no
cron required". We use APScheduler's ``BackgroundScheduler`` — it runs
in a daemon thread, which plays nicely with our sync SQLAlchemy code
(no need to marshal a session across an asyncio event loop) and dies
with the process on shutdown (no zombie threads blocking a ``docker
stop``).

Why not AsyncIOScheduler: the rest of the app's DB access is sync
SQLAlchemy ``Session``. A background thread that calls ``SessionLocal()``
is trivial; an async scheduler would force either a sync-to-async
bridge per job or a duplicate async session factory. Not worth the
complexity for one hourly job.

Lifecycle:
- ``start_scheduler()`` is called from the FastAPI ``lifespan`` context
  on app startup. It's idempotent — calling it twice is a no-op.
- ``stop_scheduler()`` runs on app shutdown. We call
  ``.shutdown(wait=False)`` so a still-running job is abandoned rather
  than holding up shutdown; the next start will sweep whatever the
  aborted job would have swept.
- ``settings.retention_disabled = True`` short-circuits the whole thing
  for tests, which don't want a background thread poking at their
  sessions mid-assertion.

Multi-worker safety (issue #14 F1):
- Under ``uvicorn --workers N`` each worker process imports this module
  and calls ``start_scheduler``. Without coordination every worker would
  fire its own retention sweep, which is wasteful and can race on the
  soft-delete → hard-delete transition.
- We coordinate via an advisory POSIX file lock (``fcntl.flock`` with
  ``LOCK_EX | LOCK_NB``). The first worker to ``start_scheduler`` wins
  the lock and runs the scheduler; later workers fail acquisition,
  log an info line, and never construct their scheduler.
- The lock is held for the lifetime of the scheduler — releasing the
  file descriptor releases the lock, so the FD stays open in
  ``_lock_fd`` and is closed only by ``stop_scheduler``.

Job failures: any exception inside ``_retention_job`` is logged with a
stack trace at WARNING. We don't re-raise — APScheduler would log
it too, but we want it at a level that's guaranteed to reach uvicorn's
log aggregator, and we want a predictable level for alerting rules.
"""

from __future__ import annotations

import fcntl
import os
from pathlib import Path

import structlog
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from agentdrop.config import get_settings
from agentdrop.db.session import SessionLocal
from agentdrop.retention import run_retention

logger = structlog.get_logger("agentdrop.retention")

# Module-level singleton. ``start_scheduler`` / ``stop_scheduler``
# treat it as the source of truth for "are we running?", which keeps
# the functions idempotent without extra bookkeeping state.
_scheduler: BackgroundScheduler | None = None

# File descriptor for the advisory lock acquired in ``start_scheduler``.
# Held open for the lifetime of the scheduler; closed (releasing the
# lock) by ``stop_scheduler``. ``None`` when no scheduler is running in
# this process.
_lock_fd: int | None = None


def _acquire_scheduler_lock(lock_path: Path) -> int | None:
    """Try to acquire an exclusive non-blocking advisory lock.

    Returns the open file descriptor on success, or ``None`` if another
    process already holds the lock. Creates the parent directory if it
    doesn't exist (matches the data_dir bind-mount pattern). The caller
    owns the FD and must ``os.close`` it to release the lock.
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    # ``O_RDWR | O_CREAT`` so the file always exists when we try to lock
    # it — flock on a non-existent FD isn't a thing. Mode 0o644 because
    # the lock file's existence is fine to leak between users on a
    # single-host deployment; nothing secret in it.
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o644)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        # Another worker already holds the lock. Close our FD so we
        # don't leak it; the OS releases the lock when we exit anyway,
        # but the FD itself is ours to clean up.
        os.close(fd)
        return None
    return fd


def _retention_job() -> None:
    """One run of the sweep.

    Opens its own session so the scheduler thread never shares a session
    with request handlers. Catches and logs any exception — APScheduler
    already swallows exceptions by default, but we explicitly log with
    ``exc_info=True`` so the stack trace reaches the application log
    rather than disappearing into the scheduler's internal logger.
    """
    settings = get_settings()
    db = SessionLocal()
    try:
        stats = run_retention(
            db,
            retention_days=settings.retention_days,
            tombstone_days=settings.tombstone_days,
        )
        logger.info(
            "retention_job_complete",
            soft_deleted=stats.soft_deleted,
            hard_deleted=stats.hard_deleted,
            examined=stats.examined,
        )
    except Exception:
        # Scheduler jobs must not propagate — APScheduler would swallow
        # anyway, but we log here so the stack trace reaches uvicorn's
        # aggregator instead of APScheduler's internal logger.
        logger.warning("retention_job_failed", exc_info=True)
    finally:
        db.close()


def start_scheduler() -> None:
    """Start the background scheduler if enabled.

    Idempotent: calling when already running is a no-op. Honours
    ``settings.retention_disabled`` — disabled means we never construct
    the scheduler at all, which keeps pytest sessions thread-free.

    Multi-worker coordination (issue #14 F1): tries to acquire an
    advisory file lock at ``settings.effective_scheduler_lock_path``.
    If another worker in the same deployment already holds it, this
    worker logs an info line and returns without constructing a
    scheduler. The held FD is stashed in the module-level ``_lock_fd``
    so that ``stop_scheduler`` can release it on shutdown.
    """
    global _scheduler, _lock_fd

    settings = get_settings()
    if settings.retention_disabled:
        logger.info("retention_scheduler_disabled")
        return

    if _scheduler is not None and _scheduler.running:
        logger.debug("retention_scheduler_already_running")
        return

    lock_path = settings.effective_scheduler_lock_path()
    fd = _acquire_scheduler_lock(lock_path)
    if fd is None:
        logger.info(
            "retention_scheduler_lock_held_by_other_worker",
            lock_path=str(lock_path),
        )
        return

    try:
        scheduler = BackgroundScheduler(daemon=True)
        scheduler.add_job(
            _retention_job,
            trigger=IntervalTrigger(hours=settings.retention_interval_hours),
            id="retention_sweep",
            # coalesce: if the app was asleep and we missed several fires,
            # collapse the backlog into one run. There's no value in running
            # the sweep three times back-to-back.
            coalesce=True,
            # misfire_grace_time: how late a fire can be and still run. 15
            # minutes covers GC pauses, brief network hiccups, and slow
            # startups without letting a long-dead job fire for no reason.
            misfire_grace_time=900,
            max_instances=1,
        )
        scheduler.start()
    except Exception:
        # Constructing or starting the scheduler raised; release the lock
        # so a later restart in this process (or the next worker) can
        # take over instead of being stuck behind a dead holder.
        os.close(fd)
        raise

    _scheduler = scheduler
    _lock_fd = fd
    logger.info(
        "retention_scheduler_started",
        interval_hours=settings.retention_interval_hours,
        lock_path=str(lock_path),
    )


def stop_scheduler() -> None:
    """Stop the scheduler if it is running.

    ``wait=False`` means we don't block shutdown on an in-flight job;
    the next startup will sweep anything the aborted job would have.
    Also releases the advisory file lock acquired in ``start_scheduler``
    by closing its FD — flock is released automatically on FD close.
    """
    global _scheduler, _lock_fd

    if _scheduler is not None:
        if _scheduler.running:
            _scheduler.shutdown(wait=False)
            logger.info("retention_scheduler_stopped")
        _scheduler = None

    if _lock_fd is not None:
        try:
            os.close(_lock_fd)
        except OSError:
            # Already closed somehow; not worth raising on shutdown.
            logger.debug("scheduler_lock_fd_already_closed")
        _lock_fd = None
