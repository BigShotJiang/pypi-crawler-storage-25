"""Bearer-token API-key authentication for the ingestion API.

Two accepted sources, in order:

1. ``AGENTDROP_API_KEY`` env var — the "bootstrap / fallback" key. Hashed
   once at boot and compared constant-time per request. This is what the
   MVP shipped with; operators who never opened the UI still rely on it.
2. ``api_keys`` table — UI-managed keys created via the settings screen.
   Each row stores only a SHA-256 hash of the plaintext token; the
   plaintext is shown once at creation and never again.

Either source can be authoritative; having neither configured (env unset
**and** no DB rows) is a "server not configured" condition and produces
``503`` — same signal M2 used so agents can distinguish "typo your token"
from "nothing set up yet".
"""

from __future__ import annotations

import hashlib
import hmac
from datetime import UTC, datetime
from functools import lru_cache
from typing import Annotated

import structlog
from fastapi import Depends, Header, HTTPException, Request, status
from sqlalchemy import func, select
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from agentdrop.config import get_settings
from agentdrop.db.session import get_db
from agentdrop.models.api_key import ApiKey

logger = structlog.get_logger(__name__)


def hash_key(raw: str) -> str:
    """Return the SHA-256 hex digest of ``raw``."""
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


@lru_cache(maxsize=1)
def _get_expected_hash() -> str | None:
    """Return the hashed configured API key, or ``None`` if unset.

    Cached so we hash the key exactly once per process. Call
    ``_get_expected_hash.cache_clear()`` in tests after flipping the
    ``AGENTDROP_API_KEY`` env var (and ``get_settings.cache_clear()``).
    """
    configured = get_settings().api_key
    if configured is None:
        return None
    return hash_key(configured)


def _db_has_any_key(db: Session) -> bool:
    """True if *any* API key row exists in the DB, revoked or not.

    Used to distinguish "nothing configured anywhere" (→ 503) from
    "something configured, you just presented a bad token" (→ 401).
    Even revoked rows count: once the UI has been used to mint a key,
    the server has been configured, and a subsequent bad token is a 401
    question, not a "server not configured" one. Users who revoke their
    last key and then present something bogus get 401, not 503 — their
    server isn't un-configured, it just has no active keys.
    """
    try:
        count = db.execute(select(func.count(ApiKey.id))).scalar_one()
        return bool(count)
    except SQLAlchemyError:
        # Treat DB errors as "no keys" — the env path (if configured) will
        # still work; if neither is available the user sees 503, which is
        # the right signal for a broken server.
        return False


def _check_db_api_key(db: Session, token: str) -> str | None:
    """Return the matched ``ApiKey.id`` for ``token``, or ``None``.

    On a match, bump ``last_used_at`` to now as a best-effort write. A
    failure to persist the timestamp does **not** fail auth — the key is
    still valid, we just lose one touch in the audit trail. The failure
    is logged so operators can notice if the DB is wedged.
    """
    presented_hash = hash_key(token)
    try:
        row = db.execute(
            select(ApiKey).where(
                ApiKey.key_hash == presented_hash,
                ApiKey.revoked_at.is_(None),
            )
        ).scalar_one_or_none()
    except SQLAlchemyError:
        # Table missing / DB unreachable — treat as "no DB key". The env
        # path (if present) may still accept the token upstream, so we
        # don't fail closed here.
        logger.warning("api_key_lookup_failed", exc_info=True)
        db.rollback()
        return None
    if row is None:
        return None

    matched_id = row.id

    try:
        row.last_used_at = datetime.now(UTC)
        db.commit()
    except SQLAlchemyError:
        # Best-effort: the token is valid; only the touch failed.
        logger.warning("api_key_last_used_at_update_failed", exc_info=True)
        db.rollback()

    return matched_id


def require_api_key(
    request: Request,
    authorization: Annotated[str | None, Header()] = None,
    db: Annotated[Session, Depends(get_db)] = None,  # type: ignore[assignment]
) -> None:
    """FastAPI dependency enforcing ``Authorization: Bearer <token>``.

    Checks the env-configured key first (one hash compare, constant
    time) and falls back to a DB lookup. If neither an env key nor any
    DB keys exist, the server is effectively unconfigured and we raise
    ``503`` — same signal the MVP used, so agents can still tell
    "misconfigured server" apart from "wrong token".

    On success, stashes a stable identifier for the matched key on
    ``request.state.api_key_id`` (``"env"`` for the env-configured key,
    ``"db:<id>"`` for a DB-managed key) so downstream dependencies — in
    particular per-API-key rate limiting — can bucket by caller without
    re-doing the lookup or seeing the plaintext token.

    Raises:
        HTTPException 503: no env key **and** no DB keys configured.
        HTTPException 401: header missing/malformed, or token matches
            neither the env key nor any non-revoked DB row.
    """
    if authorization is None or not authorization.startswith("Bearer "):
        # Be explicit about "nothing configured" vs "wrong token" even
        # before touching the token — if the server truly has no keys,
        # the caller deserves a 503 regardless of their header.
        if _get_expected_hash() is None and not _db_has_any_key(db):
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="API key not configured on server",
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    token = authorization[len("Bearer ") :].strip()
    if not token:
        if _get_expected_hash() is None and not _db_has_any_key(db):
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="API key not configured on server",
            )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Empty bearer token",
            headers={"WWW-Authenticate": "Bearer"},
        )

    expected_hash = _get_expected_hash()

    # Env path first — same shape as M2 so the existing constant-time
    # comparison stays hot and its tests continue to pass verbatim.
    if expected_hash is not None:
        presented_hash = hash_key(token)
        if hmac.compare_digest(presented_hash, expected_hash):
            request.state.api_key_id = "env"
            return None

    # DB path — per-token query + best-effort last_used_at bump.
    db_key_id = _check_db_api_key(db, token)
    if db_key_id is not None:
        request.state.api_key_id = f"db:{db_key_id}"
        return None

    # Nothing matched. If neither source is configured, call it 503 so
    # the signal to the caller matches the M2 behaviour.
    if expected_hash is None and not _db_has_any_key(db):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="API key not configured on server",
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid API key",
        headers={"WWW-Authenticate": "Bearer"},
    )
