# Roadmap

Living list of work that isn't in the MVP but has been explicitly committed to or identified as worth doing. MVP scope itself lives in the (local-only) product spec.

## Shipped

- **MVP** — HTTP API, SQLite + auto-migrate, Reading-variant drop page, Pushover + ntfy drivers, env-based channel config, Docker image.
- **v1 ("month-one")** — full web UI (inbox desktop + mobile, drop-page action wiring for pin/archive, settings for channels + API keys), session auth, DB-backed channels and keys managed via UI, Apprise + generic webhook drivers, retention sweep (soft-delete at 30d, hard-delete at 90d, APScheduler in-process), `agentdrop` CLI + GH Action for PyPI publishing.
- **MCP server (`agentdrop-mcp`)** — stdio MCP server distributed alongside the CLI. Exposes `create_drop` and `list_recent_drops`, reuses the CLI's config file and Cloudflare Access handling, works with Claude Desktop and Claude Code out of the box.
- **Full-text search over drops (SQLite FTS5).** Inbox `?q=` now ranges over title + body + content_md + source + tags via a contentless `drops_fts` virtual table maintained by AFTER triggers on `drops`. Porter stemmer + unicode61 tokenizer (diacritic folding). User queries are sanitized (FTS5 meta-chars stripped) so typing naive words "just works".

## v1.5

- Routing rules — map `source` and `priority` to different channels.
- **Web Push via PWA.** Self-hosted push delivered directly to the browser, tap opens the drop page with one tap (no third-party notification app in between). Requires: service worker on the drop page, PWA manifest, VAPID keys, subscription endpoint, a `web_push` driver registered alongside Pushover / ntfy. The one-tap flow is the motivation — Pushover / ntfy iOS clients always route through their own app first, which is a platform limitation, not a driver config we can flip.

## v2 ideas

- Multi-user / team mode.
- Reply-back path (drop → agent webhook → conversational channel).
- Read-rate / source-volume / time-to-read analytics.
- "Send a copy to Obsidian / Notion" actions on the drop page.
- Browser extension for quick manual drops.

## Known tech debt

- Docker image is ~275 MB; PRD target is under 200 MB. Largest contributors are `pydantic-core`, `sqlalchemy`, `uvicorn[standard]`'s C extensions, and `apprise`'s transitive `requests` stack. Revisit when shipping 0.1 (distroless base, trim `[standard]` to the extensions actually used, strip `__pycache__` more aggressively, consider separating the CLI into its own thin dist so server installs don't pull typer+tomli-w).
- Drop page's Pin / Archive buttons work; Copy works client-side. There's no **undo** toast on Archive — the handoff intentionally omits one (archived drops are still in the Archived view), but worth re-reading if we add bulk archive later.
- **Postgres installs get degraded search.** FTS5 is SQLite-only; when `AGENTDROP_DATABASE_URL` points at Postgres the inbox `?q=` falls back to a broadened LIKE over title + body + source + tags (no `content_md` — too big to LIKE-scan). A PG-native `tsvector` / GIN path is a follow-up; most self-hosters run SQLite anyway.
