#!/usr/bin/env bash
# Local dry run for the PyPI release pipeline.
#
# Builds the sdist + wheel into dist/ using `uv build`, prints what landed
# there, and reminds you how to trigger the real release (which publishes
# via GitHub Actions + PyPI trusted publishing — see
# .github/workflows/release.yml).
#
# This script does NOT publish anything to PyPI. The only way to publish
# is to push a `v*.*.*` tag to GitHub on the main branch.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

UV="${UV:-uv}"
if ! command -v "$UV" >/dev/null 2>&1; then
    if [[ -x "$HOME/.local/bin/uv" ]]; then
        UV="$HOME/.local/bin/uv"
    else
        echo "error: uv not found on PATH (and $HOME/.local/bin/uv doesn't exist)." >&2
        echo "install: https://docs.astral.sh/uv/getting-started/installation/" >&2
        exit 1
    fi
fi

echo "==> Cleaning dist/"
rm -rf dist/

echo "==> Running uv build"
"$UV" build

echo
echo "==> dist/ contents:"
ls -la dist/

echo
echo "Dry run OK. To publish for real:"
echo "  1. Commit your changes and ensure you're on main."
echo "  2. Bump the version in pyproject.toml."
echo "  3. git tag vX.Y.Z && git push origin vX.Y.Z"
echo "     (this triggers .github/workflows/release.yml, which publishes via"
echo "      PyPI trusted publishing — no token needed in the runner)."
