#!/bin/bash
# Container entrypoint: run pending migrations, then exec uvicorn so SIGTERM
# reaches the server cleanly. The runtime image is python:3.12-slim (debian),
# so bash is available — using it for `pipefail` and clearer failure semantics.
set -euo pipefail
echo "[entrypoint] running migrations"
alembic upgrade head || { echo "[entrypoint] migration failed"; exit 1; }
echo "[entrypoint] starting uvicorn on 0.0.0.0:8080"
exec uvicorn agentdrop.main:app --host 0.0.0.0 --port 8080
