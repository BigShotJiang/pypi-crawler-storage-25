"""Generate a fresh VAPID keypair for Web Push.

Run with ``uv run scripts/gen_vapid_keys.py`` (or ``make vapid-keys``).
Prints three lines in ``KEY=value`` format suitable for pasting into
``.env``. Does **not** write to disk — copy the output yourself so
nothing accidentally clobbers existing keys (subscriptions are tied to
the public key; rotating it forces every subscriber to re-subscribe).

The key format is the one ``pywebpush`` and the browser's
``pushManager.subscribe({applicationServerKey})`` both expect:
base64url-encoded raw EC P-256 keys.
"""

from __future__ import annotations

import argparse
import sys

from cryptography.hazmat.primitives import serialization
from py_vapid import Vapid
from py_vapid.utils import b64urlencode


def _generate(subject: str) -> tuple[str, str, str]:
    vapid = Vapid()
    vapid.generate_keys()

    # Public key as 65-byte uncompressed P-256 point (X9.62), base64url —
    # the format the browser's pushManager.subscribe applicationServerKey
    # expects and that we'll round-trip through .env.
    pub_raw = vapid.public_key.public_bytes(
        encoding=serialization.Encoding.X962,
        format=serialization.PublicFormat.UncompressedPoint,
    )
    # Private key as 32-byte raw scalar, base64url — Vapid.from_raw on
    # the receiving side reconstructs the keypair.
    priv_raw = vapid.private_key.private_numbers().private_value.to_bytes(32, "big")

    public = b64urlencode(pub_raw)
    private = b64urlencode(priv_raw)
    return public, private, subject


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument(
        "--subject",
        default="mailto:admin@example.com",
        help="Contact URI advertised to push services. Use mailto: or https:.",
    )
    args = parser.parse_args(argv)

    public, private, subject = _generate(args.subject)
    sys.stdout.write(f"AGENTDROP_VAPID_PUBLIC_KEY={public}\n")
    sys.stdout.write(f"AGENTDROP_VAPID_PRIVATE_KEY={private}\n")
    sys.stdout.write(f"AGENTDROP_VAPID_SUBJECT={subject}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
