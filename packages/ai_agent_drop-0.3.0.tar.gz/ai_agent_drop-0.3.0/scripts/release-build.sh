#!/usr/bin/env bash
# Local release build — linux/amd64 tagged for GHCR.
#
# CI (.github/workflows/docker-publish.yml) is the canonical path that
# publishes to ghcr.io on tag pushes. This script exists for the "I need
# to ship a fix without waiting on CI" case; PUSH=1 plus a prior
# `docker login ghcr.io` will publish from your laptop.
#
# Usage:
#   scripts/release-build.sh           # build only (no push)
#   PUSH=1 scripts/release-build.sh    # build + push to GHCR
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

IMAGE="ghcr.io/jay-uk/agent-drop"

# Derive VERSION:
#   1. Latest annotated/lightweight git tag (with leading `v` stripped), or
#   2. The `version = "..."` line in pyproject.toml as a fallback.
# Avoids drifting between release tags and the hardcoded literal that used
# to live here.
VERSION=""
if RAW_TAG="$(git describe --tags --abbrev=0 2>/dev/null)"; then
    VERSION="${RAW_TAG#v}"
fi
if [[ -z "${VERSION}" ]]; then
    VERSION="$(grep -E '^version[[:space:]]*=' pyproject.toml | head -n1 | sed -E 's/.*"([^"]+)".*/\1/')"
fi
if [[ -z "${VERSION}" ]]; then
    echo "release-build: could not determine version (no git tag, pyproject.toml unparseable)" >&2
    exit 1
fi

PUSH_FLAG=""
if [[ "${PUSH:-0}" == "1" ]]; then
    PUSH_FLAG="--push"
fi

docker buildx build \
    --platform linux/amd64 \
    -t "${IMAGE}:latest" \
    -t "${IMAGE}:${VERSION}" \
    ${PUSH_FLAG} \
    .

echo
echo "Built ${IMAGE}:${VERSION} and ${IMAGE}:latest for linux/amd64."
if [[ -z "${PUSH_FLAG}" ]]; then
    echo "(Not pushed — rerun with PUSH=1 after \`docker login ghcr.io\` to publish.)"
fi
