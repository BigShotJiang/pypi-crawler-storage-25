#!/usr/bin/env bash
# Local dev build — single-arch (linux/arm64, Apple Silicon), loaded into the
# local docker daemon so `docker run agentdrop:dev` works immediately.
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

docker buildx build \
    --platform linux/arm64 \
    --load \
    -t agentdrop:dev \
    .

echo
echo "Built agentdrop:dev (linux/arm64). Run with:"
echo "  docker run --rm -p 8080:8080 -v \"\$PWD/data:/data\" agentdrop:dev"
