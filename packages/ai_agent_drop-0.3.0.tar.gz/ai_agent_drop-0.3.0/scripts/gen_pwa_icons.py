# /// script
# requires-python = ">=3.12"
# dependencies = ["pillow>=10"]
# ///
"""Generate the PWA icon set for Agent Drop.

Run with ``uv run scripts/gen_pwa_icons.py`` after tweaking the design.
Outputs are written to ``src/agentdrop/web/static/icons/`` and committed —
there is no build step at serve time.

Design: the ⟐ brand glyph rendered geometrically (outer outlined diamond
+ inner filled diamond) on the warm paper background. Drawn with Pillow
primitives so the result is identical regardless of which fonts are
installed on the generating machine.

Color choices are sRGB approximations of the OKLCH design tokens
(``--color-paper`` and ``--color-ink`` in tokens.css). PNG cannot carry
OKLCH; matching by eye is fine since these only render at small sizes.
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw

OUT_DIR = Path(__file__).resolve().parent.parent / "src" / "agentdrop" / "web" / "static" / "icons"

# sRGB approximations of tokens.css --color-paper and --color-ink.
PAPER = (246, 239, 230)
INK = (45, 38, 32)


def _draw_brand(size: int, *, safe_padding_ratio: float = 0.0) -> Image.Image:
    """Render the diamond-in-diamond brand mark at ``size`` x ``size`` px.

    ``safe_padding_ratio`` shrinks the design toward the centre to leave
    room for the maskable-icon safe zone (Android crops up to ~10% on
    each edge for various mask shapes).
    """
    img = Image.new("RGB", (size, size), PAPER)
    draw = ImageDraw.Draw(img)

    cx = cy = size / 2
    usable = size * (1 - 2 * safe_padding_ratio)

    outer_radius = usable * 0.36
    outer_points = [
        (cx, cy - outer_radius),
        (cx + outer_radius, cy),
        (cx, cy + outer_radius),
        (cx - outer_radius, cy),
    ]
    stroke = max(2, round(size * 0.018))
    draw.polygon(outer_points, outline=INK, width=stroke)

    inner_radius = usable * 0.10
    inner_points = [
        (cx, cy - inner_radius),
        (cx + inner_radius, cy),
        (cx, cy + inner_radius),
        (cx - inner_radius, cy),
    ]
    draw.polygon(inner_points, fill=INK)

    return img


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)

    targets: list[tuple[str, int, float]] = [
        ("icon-192.png", 192, 0.0),
        ("icon-512.png", 512, 0.0),
        ("icon-180-apple.png", 180, 0.0),
        # Maskable: 10% safe padding on each side so Android's mask crop
        # never bites into the brand mark.
        ("icon-maskable-512.png", 512, 0.10),
    ]
    for filename, size, padding in targets:
        img = _draw_brand(size, safe_padding_ratio=padding)
        path = OUT_DIR / filename
        img.save(path, format="PNG", optimize=True)
        print(f"wrote {path}")


if __name__ == "__main__":
    main()
