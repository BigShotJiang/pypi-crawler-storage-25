"""Tests for page_utils module."""

import os
from unittest.mock import patch


from conftest import create_dummy_file
from pbir_utils.page_utils import (
    hide_pages_by_type,
    set_active_page,
    set_first_page_as_active,
    set_page_order,
    remove_empty_pages,
    set_page_size,
    set_page_display_option,
    remove_unused_hidden_pages,
)
from pbir_utils.common import load_json


class TestHidePagesByType:
    """Tests for hide_pages_by_type."""

    def test_hide_tooltip_pages(self, tmp_path):
        """Test hiding only tooltip pages."""
        report_path = str(tmp_path)

        # Tooltip page - should be hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "displayName": "Page1",
                "pageBinding": {"type": "Tooltip"},
                "visibility": "Visible",
            },
        )
        # Drillthrough page - should NOT be hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "displayName": "Page2",
                "pageBinding": {"type": "Drillthrough"},
                "visibility": "Visible",
            },
        )
        # Normal page - should stay visible
        create_dummy_file(
            tmp_path,
            "definition/pages/Page3/page.json",
            {
                "displayName": "Page3",
                "pageBinding": {"type": "ReportSection"},
                "visibility": "Visible",
            },
        )

        result = hide_pages_by_type(report_path, page_type="Tooltip")

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["visibility"] == "HiddenInViewMode"

        p2 = load_json(os.path.join(report_path, "definition/pages/Page2/page.json"))
        assert p2["visibility"] == "Visible"  # NOT hidden

        p3 = load_json(os.path.join(report_path, "definition/pages/Page3/page.json"))
        assert p3["visibility"] == "Visible"

    def test_hide_drillthrough_pages(self, tmp_path):
        """Test hiding only drillthrough pages."""
        report_path = str(tmp_path)

        # Tooltip page - should NOT be hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "displayName": "Page1",
                "pageBinding": {"type": "Tooltip"},
                "visibility": "Visible",
            },
        )
        # Drillthrough page - should be hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "displayName": "Page2",
                "pageBinding": {"type": "Drillthrough"},
                "visibility": "Visible",
            },
        )

        result = hide_pages_by_type(report_path, page_type="Drillthrough")

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["visibility"] == "Visible"  # NOT hidden

        p2 = load_json(os.path.join(report_path, "definition/pages/Page2/page.json"))
        assert p2["visibility"] == "HiddenInViewMode"

    def test_no_pages_to_hide(self, tmp_path):
        """Test when no pages of the specified type need hiding."""
        report_path = str(tmp_path)

        # Normal page only - no tooltip pages
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "displayName": "Page1",
                "pageBinding": {"type": "ReportSection"},
                "visibility": "Visible",
            },
        )

        result = hide_pages_by_type(report_path, page_type="Tooltip")
        assert result is False


class TestSetActivePage:
    """Tests for set_active_page and backwards compat wrapper."""

    def test_with_hidden_pages(self, tmp_path):
        """Test that the first non-hidden page is set as active when page=None."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {
                "pageOrder": ["Page1", "Page2", "Page3"],
                "activePageName": "Page1",
            },
        )

        # Page 1: Hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "name": "Page1",
                "displayName": "Tooltip",
                "visibility": "HiddenInViewMode",
            },
        )
        # Page 2: Also hidden
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "name": "Page2",
                "displayName": "Another Hidden",
                "visibility": "HiddenInViewMode",
            },
        )
        # Page 3: Visible
        create_dummy_file(
            tmp_path,
            "definition/pages/Page3/page.json",
            {
                "name": "Page3",
                "displayName": "Main Page",
                "visibility": "Visible",
            },
        )

        set_active_page(report_path)

        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["activePageName"] == "Page3"

    def test_all_hidden(self, tmp_path):
        """Test fallback when all pages are hidden."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {
                "pageOrder": ["Page1", "Page2"],
                "activePageName": "Page2",
            },
        )

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "name": "Page1",
                "displayName": "Hidden 1",
                "visibility": "HiddenInViewMode",
            },
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "name": "Page2",
                "displayName": "Hidden 2",
                "visibility": "HiddenInViewMode",
            },
        )

        with patch("builtins.print") as mock_print:
            set_active_page(report_path)
            assert any("Warning" in str(call) for call in mock_print.call_args_list)

        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["activePageName"] == "Page1"

    def test_specific_page_by_display_name(self, tmp_path):
        """Test setting a specific page by displayName."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"name": "Page1", "displayName": "Overview", "visibility": "Visible"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"name": "Page2", "displayName": "Details", "visibility": "Visible"},
        )

        set_active_page(report_path, page="Details")

        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["activePageName"] == "Page2"

    def test_page_not_found(self, tmp_path):
        """Test behavior when specific page is not found."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1"], "activePageName": "Page1"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"name": "Page1", "displayName": "Overview"},
        )

        with patch("builtins.print"):
            result = set_active_page(report_path, page="Missing")

        assert result is False
        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["activePageName"] == "Page1"

    def test_backward_compat_wrapper(self, tmp_path):
        """Test the set_first_page_as_active wrapper works."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "name": "Page1",
                "displayName": "Hidden",
                "visibility": "HiddenInViewMode",
            },
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"name": "Page2", "displayName": "Visible", "visibility": "Visible"},
        )

        set_first_page_as_active(report_path)
        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["activePageName"] == "Page2"


class TestSetPageOrder:
    """Tests for set_page_order."""

    def test_set_page_order_successful(self, tmp_path):
        """Test successfully setting page order using internal names and display names."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2", "Page3"]},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"name": "Page1", "displayName": "First"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"name": "Page2", "displayName": "Second"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page3/page.json",
            {"name": "Page3", "displayName": "Third"},
        )

        # Test case-insensitive and using logic mix of ID and displayName
        result = set_page_order(report_path, ["Second", "page3", "Page1"])
        assert result is True

        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["pageOrder"] == ["Page2", "Page3", "Page1"]

    def test_unresolved_pages_aborts(self, tmp_path):
        """Test that if a page cannot be found, the update aborts."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1", "Page2"]}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"name": "Page1"}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page2/page.json", {"name": "Page2"}
        )

        with patch("builtins.print"):
            result = set_page_order(report_path, ["Page2", "MissingPage"])

        assert result is False
        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["pageOrder"] == ["Page1", "Page2"]

    def test_appends_unspecified_pages(self, tmp_path):
        """Test that pages not in the order list are appended to the end."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2", "Page3"]},
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"name": "Page1"}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page2/page.json", {"name": "Page2"}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page3/page.json", {"name": "Page3"}
        )

        # Only ordered Page2
        result = set_page_order(report_path, ["Page2"])

        assert result is True
        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["pageOrder"] == ["Page2", "Page1", "Page3"]


class TestRemoveEmptyPages:
    """Tests for remove_empty_pages."""

    def test_all_empty(self, tmp_path):
        """Test when all pages are empty."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )
        os.makedirs(
            os.path.join(report_path, "definition/pages/Page1/visuals"), exist_ok=True
        )
        os.makedirs(
            os.path.join(report_path, "definition/pages/Page2/visuals"), exist_ok=True
        )

        with patch("builtins.print"):
            remove_empty_pages(report_path)
            pages_data = load_json(
                os.path.join(report_path, "definition/pages/pages.json")
            )
            assert pages_data["pageOrder"] == ["Page1"]
            assert pages_data["activePageName"] == "Page1"

    def test_renamed_folders(self, tmp_path):
        """Test removing empty pages with renamed folders."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )

        create_dummy_file(
            tmp_path, "definition/pages/Folder_Page1/page.json", {"name": "Page1"}
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Folder_Page1/visuals/v1/visual.json",
            {"name": "v1"},
        )

        create_dummy_file(
            tmp_path, "definition/pages/Folder_Page2/page.json", {"name": "Page2"}
        )
        os.makedirs(
            os.path.join(report_path, "definition/pages/Folder_Page2/visuals"),
            exist_ok=True,
        )

        os.makedirs(
            os.path.join(report_path, "definition/pages/RogueFolder"), exist_ok=True
        )

        with patch("builtins.print"):
            remove_empty_pages(report_path)

        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["pageOrder"] == ["Page1"]
        assert os.path.exists(
            os.path.join(report_path, "definition/pages/Folder_Page1")
        )
        assert not os.path.exists(
            os.path.join(report_path, "definition/pages/Folder_Page2")
        )
        assert not os.path.exists(
            os.path.join(report_path, "definition/pages/RogueFolder")
        )


class TestSetPageSize:
    """Tests for set_page_size."""

    def test_set_page_size(self, tmp_path):
        """Test setting page size on non-tooltip pages."""
        report_path = str(tmp_path)

        # Normal page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"displayName": "Page1", "width": 1000, "height": 600},
        )
        # Tooltip page - should be skipped
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"displayName": "Tooltip", "type": "Tooltip", "width": 200, "height": 100},
        )

        result = set_page_size(report_path, width=1280, height=720)

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["width"] == 1280
        assert p1["height"] == 720

        p2 = load_json(os.path.join(report_path, "definition/pages/Page2/page.json"))
        assert p2["width"] == 200  # Unchanged
        assert p2["height"] == 100

    def test_no_changes_needed(self, tmp_path):
        """Test when pages already have target size."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"displayName": "Page1", "width": 1280, "height": 720},
        )

        result = set_page_size(report_path, width=1280, height=720)
        assert result is False


class TestSetPageDisplayOption:
    """Tests for set_page_display_option."""

    def test_set_display_option_by_display_name(self, tmp_path):
        """Test setting display option on a page matched by displayName."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "name": "abc123",
                "displayName": "Trends",
                "displayOption": "FitToWidth",
            },
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "name": "def456",
                "displayName": "Overview",
                "displayOption": "FitToWidth",
            },
        )

        result = set_page_display_option(
            report_path, display_option="ActualSize", page="Trends"
        )

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["displayOption"] == "ActualSize"

        # Other page should be unchanged
        p2 = load_json(os.path.join(report_path, "definition/pages/Page2/page.json"))
        assert p2["displayOption"] == "FitToWidth"

    def test_set_display_option_by_name(self, tmp_path):
        """Test setting display option on a page matched by internal name."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {
                "name": "abc123",
                "displayName": "Trends",
                "displayOption": "FitToWidth",
            },
        )

        result = set_page_display_option(
            report_path, display_option="FitToPage", page="abc123"
        )

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["displayOption"] == "FitToPage"

    def test_set_display_option_all_pages(self, tmp_path):
        """Test setting display option on all pages when no filter provided."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"name": "abc123", "displayName": "Trends", "displayOption": "FitToWidth"},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {
                "name": "def456",
                "displayName": "Overview",
                "displayOption": "ActualSize",
            },
        )

        result = set_page_display_option(report_path, display_option="FitToPage")

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["displayOption"] == "FitToPage"
        p2 = load_json(os.path.join(report_path, "definition/pages/Page2/page.json"))
        assert p2["displayOption"] == "FitToPage"

    def test_no_changes_needed(self, tmp_path):
        """Test when pages already have target display option."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"displayName": "Page1", "displayOption": "FitToWidth"},
        )

        result = set_page_display_option(report_path, display_option="FitToWidth")
        assert result is False

    def test_dry_run_mode(self, tmp_path):
        """Test that dry run does not modify files."""
        report_path = str(tmp_path)

        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"displayName": "Page1", "displayOption": "FitToWidth"},
        )

        result = set_page_display_option(
            report_path, display_option="ActualSize", dry_run=True
        )

        assert result is True
        p1 = load_json(os.path.join(report_path, "definition/pages/Page1/page.json"))
        assert p1["displayOption"] == "FitToWidth"  # Unchanged due to dry run


class TestRemoveUnusedHiddenPages:
    """Tests for remove_unused_hidden_pages."""

    def test_removes_hidden_page_with_no_deps(self, tmp_path):
        """Test that a hidden page with no dependencies is removed."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )

        # Visible page
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(tmp_path, "definition/pages/Page1/visuals/v1/visual.json", {})

        # Hidden unused page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode"},
        )
        create_dummy_file(tmp_path, "definition/pages/Page2/visuals/v2/visual.json", {})

        result = remove_unused_hidden_pages(report_path)

        assert result is True
        pages_data = load_json(os.path.join(report_path, "definition/pages/pages.json"))
        assert pages_data["pageOrder"] == ["Page1"]
        assert os.path.exists(os.path.join(report_path, "definition/pages/Page1"))
        assert not os.path.exists(os.path.join(report_path, "definition/pages/Page2"))

    def test_keeps_tooltip_page(self, tmp_path):
        """Test that a hidden tooltip page is kept."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1"]}
        )

        # Hidden tooltip page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"visibility": "HiddenInViewMode", "pageBinding": {"type": "Tooltip"}},
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is False
        assert os.path.exists(os.path.join(report_path, "definition/pages/Page1"))

    def test_keeps_drillthrough_page(self, tmp_path):
        """Test that a hidden drillthrough page is kept."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1"]}
        )

        # Hidden drillthrough page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"visibility": "HiddenInViewMode", "pageBinding": {"type": "Drillthrough"}},
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is False

    def test_keeps_page_navigation_target(self, tmp_path):
        """Test that a hidden page targeted by page navigation is kept."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1", "Page2"]}
        )

        # Visible page with a navigation button to Page2
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/visuals/v1/visual.json",
            {
                "visual": {
                    "visualContainerObjects": {
                        "visualLink": [
                            {
                                "properties": {
                                    "navigationSection": {
                                        "expr": {"Literal": {"Value": "'Page2'"}}
                                    }
                                }
                            }
                        ]
                    }
                }
            },
        )

        # Hidden target page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page2"},
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is False

    def test_keeps_tooltip_target_page(self, tmp_path):
        """Test that a hidden page targeted as a visual tooltip is kept."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1", "Page2"]}
        )

        # Visible page with a visual using Page2 as tooltip
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/visuals/v1/visual.json",
            {
                "visual": {
                    "visualContainerObjects": {
                        "visualTooltip": [
                            {
                                "properties": {
                                    "section": {
                                        "expr": {"Literal": {"Value": "'Page2'"}}
                                    }
                                }
                            }
                        ]
                    }
                }
            },
        )

        # Hidden target page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page2"},
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is False

    def test_keeps_page_with_used_bookmark(self, tmp_path):
        """Test that a hidden page referenced by a *used* bookmark is kept."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1", "Page2"]}
        )

        # Visible page with a bookmark navigator pointing to "MyGroup"
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/visuals/v1/visual.json",
            {
                "visual": {
                    "visualType": "bookmarkNavigator",
                    "objects": {
                        "bookmarks": [
                            {
                                "properties": {
                                    "bookmarkGroup": {
                                        "expr": {"Literal": {"Value": "'MyGroup'"}}
                                    }
                                }
                            }
                        ]
                    },
                }
            },
        )

        # Hidden target page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page2"},
        )

        # Bookmark in "MyGroup" referencing Page2
        create_dummy_file(
            tmp_path,
            "definition/bookmarks/bookmarks.json",
            {"items": [{"name": "bm1"}]},
        )
        create_dummy_file(
            tmp_path,
            "definition/bookmarks/bm1.bookmark.json",
            {
                "name": "MyGroup",
                "explorationState": {
                    "activeSection": "Page2",
                    "sections": {"Page2": {}},
                },
            },
        )

        result = remove_unused_hidden_pages(report_path)
        assert result is False

    def test_removes_page_with_only_unused_bookmarks(self, tmp_path):
        """Test that a hidden page referenced only by unused bookmarks is removed."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )

        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page1/visuals/v1/visual.json", {}
        )  # No bookmark refs

        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page2"},
        )

        # Unused bookmark referencing Page2
        create_dummy_file(
            tmp_path,
            "definition/bookmarks/bookmarks.json",
            {"items": [{"name": "UnusedBM"}]},
        )
        create_dummy_file(
            tmp_path,
            "definition/bookmarks/b1.bookmark.json",
            {
                "name": "UnusedBM",
                "explorationState": {
                    "activeSection": "Page2",
                    "sections": {"Page2": {}},
                },
            },
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is True
        assert not os.path.exists(os.path.join(report_path, "definition/pages/Page2"))

        # Bookmark file should be deleted since its activeSection was removed
        assert not os.path.exists(
            os.path.join(report_path, "definition/bookmarks/b1.bookmark.json")
        )
        # Directory should be cleaned up too since it's now empty
        assert not os.path.exists(os.path.join(report_path, "definition/bookmarks"))

    def test_keeps_active_page(self, tmp_path):
        """Test that the active page is not removed even if hidden and unused."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"], "activePageName": "Page1"},
        )

        # Hidden active page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page1"},
        )
        # Visible remaining page
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "Visible", "name": "Page2"},
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is False
        assert os.path.exists(os.path.join(report_path, "definition/pages/Page1"))

    def test_dry_run_no_changes(self, tmp_path):
        """Test that dry run identifies pages but modifies nothing."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1"]},
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page1/page.json",
            {"visibility": "HiddenInViewMode"},
        )

        with patch("builtins.print"):
            result = remove_unused_hidden_pages(report_path, dry_run=True)

        assert result is True
        assert os.path.exists(os.path.join(report_path, "definition/pages/Page1"))

    def test_no_hidden_pages(self, tmp_path):
        """Test when no hidden pages exist."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path, "definition/pages/pages.json", {"pageOrder": ["Page1"]}
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )

        result = remove_unused_hidden_pages(report_path)
        assert result is False

    def test_cleans_bookmark_references(self, tmp_path):
        """Test that sections pointing to a removed page are stripped from keeping bookmarks."""
        report_path = str(tmp_path)
        create_dummy_file(
            tmp_path,
            "definition/pages/pages.json",
            {"pageOrder": ["Page1", "Page2"]},
        )
        create_dummy_file(
            tmp_path, "definition/pages/Page1/page.json", {"visibility": "Visible"}
        )
        create_dummy_file(
            tmp_path,
            "definition/pages/Page2/page.json",
            {"visibility": "HiddenInViewMode", "name": "Page2"},
        )

        # This bookmark is unused but its activeSection is Page1. It has a section for Page2.
        # Since Page2 is removed, but activeSection is preserved, the bookmark file is kept but section removed.
        create_dummy_file(
            tmp_path, "definition/bookmarks/bookmarks.json", {"items": [{"name": "bm"}]}
        )
        create_dummy_file(
            tmp_path,
            "definition/bookmarks/b1.bookmark.json",
            {
                "name": "bm",
                "explorationState": {
                    "activeSection": "Page1",
                    "sections": {"Page1": {}, "Page2": {"visualContainers": {}}},
                },
            },
        )

        result = remove_unused_hidden_pages(report_path)

        assert result is True
        # Bookmark file still exists
        bm_data = load_json(
            os.path.join(report_path, "definition/bookmarks/b1.bookmark.json")
        )
        assert "Page2" not in bm_data["explorationState"]["sections"]
        assert "Page1" in bm_data["explorationState"]["sections"]
