from tritlib import Z, N, P, logic_mode, Lukasiewicz, Bochvar, RM3, HT, L3, B3

def test_and():
    assert Z & N == N
    with logic_mode(Bochvar()):
        assert N & Z == Z



def test_imply():
    assert Z.imply(Z) == Z
    with logic_mode(Lukasiewicz()):
        assert Z.imply(Z) == P
    with logic_mode(L3):
        assert Z.imply(Z) == P

    with logic_mode(RM3()):
        assert Z.imply(N) == N
        assert Z.imply(Z) == Z
        assert P.imply(Z) == N

    assert Z.imply(N) == Z
    assert P.imply(Z) == Z

def test_or():
    assert Z|P == P
    with logic_mode(Bochvar()):
        assert Z|P == Z
    with logic_mode(B3):
        assert Z|P == Z

def test_not():
    assert ~N == P
    assert ~P == N
    assert ~Z == Z
    with logic_mode(HT()):
        assert ~N == P
        assert ~P == N
        assert ~Z == N

    with logic_mode(HT):
        assert ~N == P
        assert ~P == N
    assert ~N == P
    assert ~P == N
    assert ~Z == Z
