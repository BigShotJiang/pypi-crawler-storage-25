import pytest
from tritlib import P, Z, N
from tritlib.logic.plural import pluralize, PluralResult


class TestPluralize:
    """Tests for the pluralize function and PluralResult."""

    def test_unanimous_negation(self):
        """NOT P = N in all logics except Heyting."""
        r = pluralize(lambda a: ~a, P)
        assert r.results['K3'] == N
        assert r.results['L3'] == N

    def test_unanimous_and(self):
        """P & N = N in all logics."""
        r = pluralize(lambda a, b: a & b, P, N)
        assert r.consensus == N
        assert r.divergent is False
        assert len(r.disagree) == 0

    def test_divergent_imply_zz(self):
        """Z → Z is the classic divergence point between K3 and L3."""
        r = pluralize(lambda a, b: a.imply(b), Z, Z)
        assert r.divergent is True
        assert r.consensus is None
        assert r.results['K3'] == Z
        assert r.results['L3'] == P
        assert r.results['HT'] == P

    def test_unanimous_imply_pn(self):
        """P → N = N in all logics."""
        r = pluralize(lambda a, b: a.imply(b), P, N)
        assert r.consensus == N
        assert r.divergent is False

    def test_divergent_imply_zn(self):
        """Z → N diverges: some logics give Z, others N."""
        r = pluralize(lambda a, b: a.imply(b), Z, N)
        assert r.divergent is True
        assert 'K3' in r.agree or 'K3' in r.disagree

    def test_groups_structure(self):
        """Groups should partition all logics by result."""
        r = pluralize(lambda a, b: a.imply(b), Z, Z)
        all_logics = set()
        for names in r.groups.values():
            all_logics.update(names)
        assert all_logics == set(r.results.keys())

    def test_agree_disagree_partition(self):
        """agree + disagree should cover all logics."""
        r = pluralize(lambda a, b: a.imply(b), Z, Z)
        assert set(list(r.agree) + list(r.disagree)) == set(r.results.keys())
        # No overlap
        assert set(r.agree) & set(r.disagree) == set()

    def test_consensus_unanimous(self):
        """When all agree, consensus is the shared value."""
        r = pluralize(lambda a, b: a & b, P, P)
        assert r.consensus == P
        assert r.divergent is False
        assert len(r.agree) == 5

    def test_single_argument(self):
        """pluralize works with a single trit argument."""
        r = pluralize(lambda a: ~a, Z)
        # K3: ~Z = Z, HT: ~Z = N
        assert r.results['K3'] == Z
        assert r.results['HT'] == N
        assert r.divergent is True

    def test_or_unanimous(self):
        """N | P = P in all logics."""
        r = pluralize(lambda a, b: a | b, N, P)
        assert r.consensus == P

    def test_all_five_logics_present(self):
        """Results should contain all five logic systems."""
        r = pluralize(lambda a: ~a, P)
        assert set(r.results.keys()) == {'K3', 'L3', 'HT', 'BI3', 'RM3'}

    def test_repr_does_not_crash(self):
        """PluralResult.__repr__ should not raise."""
        r = pluralize(lambda a, b: a.imply(b), Z, Z)
        s = repr(r)
        assert isinstance(s, str)
        assert len(s) > 0

    def test_complicated_function(self):
        _ = pluralize(lambda a,b : a|a.imply(~b), N,Z)
