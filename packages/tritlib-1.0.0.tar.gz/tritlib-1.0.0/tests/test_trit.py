from tritlib.trit import Trit, N, P, Z
import pytest

def test_hash():
    assert hash(Trit(1)) == hash(P)
    assert hash(Trit(0)) == hash(Z)
    assert hash(Trit(-1)) == hash(N)

def test_hash_in_set():
    s = {Trit(1), Trit(-1), Trit(1)}
    assert len(s) == 2

def test_hash_as_dict_key():
    d = {Trit(1): "hello"}
    assert d[Trit(1)] == "hello"

def test_tritP():
    t = Trit(1)
    assert str(t) == "+"
    assert t == P
    assert repr(t) == "Trit(1)"

def test_tritN():
    t = Trit(-1)
    assert str(t) == "-"
    assert t == N
    assert repr(t) == "Trit(-1)"

def test_tritZ():
    t = Trit(0)
    assert str(t) == "0"
    assert t == Z
    assert repr(t) == "Trit(0)"

def test_trit_invalid():
    with pytest.raises(ValueError):
        Trit(2)
    with pytest.raises(ValueError):
        Trit(-3)

def test_eq():
    b = Trit(1)==1
    assert b == False 

def test_immutable():
    t = Trit(0)
    with pytest.raises(AttributeError):
        t._value = -1

def test_negation():
    assert -P == N
    assert -N == P
    assert -Z == Z

def test_multiplication():
    assert P * P == P
    assert P * N == N
    assert N * N == P
    assert Z * P == Z
    assert Z * Z == Z
    with pytest.raises(TypeError):
        _ = Z*3

def test_half_add():
    # Pas de retenue
    s, c = P.half_add(N)
    assert s == Z
    assert c == Z

    # Retenue négative
    s, c = N.half_add(N)
    assert s == P
    assert c == N

    # Zéro neutre
    s, c = P.half_add(Z)
    assert s == P
    assert c == Z
    assert NotImplemented == P.half_add(3)

def full_add():
    # sans retenue
    s, c = P.full_add(N, Z)
    assert s == Z and c == Z

    # avec retenue qui propage
    s, c = P.full_add(P, P)
    assert s == Z and c == P
    assert NotImplemented == P.full_add(3,P)
    assert NotImplemented == P.full_add(Z,4)
    assert NotImplemented == P.full_add(2,4)


def test_cons():
    assert P.cons(N) == Z == N.cons(P)
    assert P.cons(P) == P 
    assert Z.cons(N) == Z == N.cons(Z)
    assert Z.cons(P) == Z == P.cons(Z)
    assert Z.cons(Z) == Z
    assert N.cons(N) == N

def test_acons():
    assert P.acons(N) == Z == N.acons(P)
    assert P.acons(P) == Z 
    assert Z.acons(N) == P == N.acons(Z)
    assert Z.acons(P) == N == P.acons(Z)
    assert Z.acons(Z) == Z
    assert N.acons(N) == Z

def test_NotImplemented():
    assert NotImplemented == P.imply(3)
