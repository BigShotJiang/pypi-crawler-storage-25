"""Tests for TFloat based on Tekum paper (arXiv:2512.10964).
All tests use width=8 (minimum valid width).

Key reference value: +-+-+-+- (int=1640) is the anchor origin,
mapping to θ=1.0 (regime=0, exponent=0, fraction=0).
"""
import math
import pytest
from tritlib import Tryte, P, Z, N
from tritlib.tfloat import TFloat

def test_hash():
    assert hash(TFloat(1.0, 8)) == hash(TFloat(1.0,8))
    assert hash(TFloat(1.0, 8)) != hash(TFloat(1.0,10))

def test_hash_in_set():
    s = {TFloat(12.3,8), TFloat(-11,8), TFloat(12.3,8), TFloat(12.3,10)}
    assert len(s) == 3

def test_hash_as_dict_key():
    d = {TFloat(1.0,8): "hello"}
    assert d[TFloat(1.0,8)] == "hello"

def test_immutable():
    t = TFloat(1.0,8)
    with pytest.raises(AttributeError):
        t._raw = Tryte("+-++-+00",8)

def test_init():
    with pytest.raises(TypeError):
        TFloat("+-0",10)


# ── Special values ──────────────────────────────────────────────

def test_zero():
    tf = TFloat(Tryte(0, 8))
    assert tf._special == tf.special == "zero"
    assert tf.regime == 0
    assert tf.exponent == [Z]
    assert tf.exponent_value == 0
    assert tf.fraction == [Z]
    assert tf.fraction_value == 0
    assert float(tf) == 0.0
    assert str(tf) == "0.0"
    assert tf.__repr__() == "TFloat(0)"

def test_nar():
    nar = Tryte._from_trits([N] * 8, 8)
    tf = TFloat(nar)
    assert tf._special == tf.special == "nar"
    assert math.isnan(float(tf))
    assert tf.exponent_value == 0
    assert tf.exponent == [Z]
    assert tf.fraction == [Z]
    assert tf.fraction_value == 0
    assert str(tf) == "NaR"
    assert tf.__repr__() == "TFloat(NaR)"

def test_inf():
    inf = Tryte._from_trits([P] * 8, 8)
    tf = TFloat(inf)
    assert tf._special == tf.special == "inf"
    assert tf.exponent == [Z]
    assert tf.exponent_value == 0
    assert tf.fraction == [Z]
    assert tf.fraction_value == 0
    assert math.isinf(float(tf))
    assert str(tf) == "∞"
    assert tf.__repr__() == "TFloat(∞)"


# ── Width validation ────────────────────────────────────────────

def test_odd_width_rejected():
    with pytest.raises(ValueError):
        TFloat(Tryte(0, 9))

def test_small_width_rejected():
    with pytest.raises(ValueError):
        TFloat(Tryte(0, 6))

def test_width_8():
    tf = TFloat(Tryte(0, 8))
    assert tf._special == "zero"

def test_width_10():
    tf = TFloat(Tryte(0, 10))
    assert tf._special == "zero"

def test_width_26():
    tf = TFloat(Tryte(0, 26))
    assert tf._special == tf.special == "zero"


# ── Decoding (n=8) ─────────────────────────────────────────────
# +-+-+-+- = 2187-729+243-81+27-9+3-1 = 1640
# anc(t) = |t| - +-+-+-+-
# For t=1640: anc = 00000000 → r=0, e=0, f=0 → θ=1.0

def test_decode_one():
    tf = TFloat(Tryte(1640, 8))
    assert tf.special is None
    assert tf.regime == 0
    assert tf.exponent_value == 0
    assert tf.fraction_value == 0.0
    assert abs(float(tf) - 1.0) < 1e-10

def test_decode_regime_one():
    # anc = 00+00000 (big-endian), int=243
    # r=1, c=max(0,1-2)=0, b=1, e=0+1=1
    # p=8-0-3=5, f=0 → θ = 1.0 * 3^1 = 3.0
    tf = TFloat(Tryte(1640 + 243, 8))
    assert tf.regime == 1
    assert tf.exponent_value == 1
    assert tf.exponent_trit_count == tf._c
    assert len(tf.fraction) == tf.fraction_trit_count 
    assert abs(float(tf) - 3.0) < 0.01

def test_decode_regime_two():
    # anc = 0+-00000 (big-endian)
    # r=2, c=max(0,2-2)=0, b=2, e=0+2=2
    # θ = 1.0 * 3^2 = 9.0
    # int(0+-00000) = 1*3^6 - 1*3^5 = 729 - 243 = 486
    tf = TFloat(Tryte(1640 + 486, 8))
    assert tf.regime == 2
    assert tf.exponent_value == 2
    assert abs(float(tf) - 9.0) < 0.1

def test_decode_regime_negative_one():
    # anc = 00-00000 (big-endian)
    # r=-1, c=max(0,1-2)=0, b=-1, e=0+(-1)=-1
    # θ = 1.0 * 3^(-1) = 0.333...
    # int(00-00000) = -1*3^5 = -243
    tf = TFloat(Tryte(1640 - 243, 8))
    assert tf.regime == -1
    assert tf.exponent_value == -1
    assert abs(float(tf) - 1/3) < 0.01

def test_decode_fraction_nonzero():
    # anc = 0000000+ (big-endian)
    # r=0, c=0, b=0, e=0, p=5
    # fraction trits (big-endian): 0000+ → f = 1*3^(-5) ≈ 0.00412
    # θ = (1 + 0.00412) * 3^0 ≈ 1.00412
    # int(0000000+) = 1
    tf = TFloat(Tryte(1640 + 1, 8))
    assert tf.regime == 0
    assert tf.exponent_value == 0
    assert tf.fraction_value > 0
    assert len(tf.fraction) == tf.fraction_trit_count 
    assert abs(float(tf) - 1.0) < 0.01
    assert float(tf) > 1.0


# ── Negation (Proposition 3) ───────────────────────────────────
# θ(-t) = -θ(t)

def test_negation_one():
    tf_pos = TFloat(Tryte(1640, 8))
    tf_neg = TFloat(Tryte(-1640, 8))
    assert abs(float(tf_neg) + float(tf_pos)) < 1e-10

def test_negation_three():
    tf_pos = TFloat(Tryte(1883, 8))
    tf_neg = TFloat(Tryte(-1883, 8))
    assert abs(float(tf_neg) + float(tf_pos)) < 1e-10

def test_negation_various():
    for val in [1640, 1883, 2000, 2500, 3000]:
        tf_pos = TFloat(Tryte(val, 8))
        tf_neg = TFloat(Tryte(-val, 8))
        if tf_pos._special is None and tf_neg._special is None:
            assert abs(float(tf_neg) + float(tf_pos)) < 1e-6, \
                f"Negation failed for int={val}"


# ── Regime and trit counts ─────────────────────────────────────

def test_regime_zero_trit_counts():
    tf = TFloat(Tryte(1640, 8))
    assert tf.regime == 0
    assert len(tf.exponent) == 0
    assert len(tf.fraction) == 5

def test_regime_three_trit_counts():
    # r=3 → c=max(0,3-2)=1, p=8-1-3=4
    # anc = 0+0-0000 (big-endian)
    # int(0+0-0000) = 3^6 + 3^5 - 3^4 = 729 + 243 - 81 = 891 (WRONG)
    # Actually: 0*3^7 + 1*3^6 + 0*3^5 + (-1)*3^4 + 0+0+0+0
    # = 729 - 81 = 648
    # Wait, regime trits are 010 → int = 0*9 + 1*3 + 0 = 3
    # c=1, next trit is exponent, rest is fraction
    # anc = 0+0 | - | 0000 → e_trits=-, f_trits=0000
    # b = sign(3)*BIAS[3] = 4
    # e = -1 + 4 = 3
    # int(0+000000) = 3^6 = 729 (just regime 010 + zeros)
    # But we need 0+0-0000 for e_trit=T
    # int(0+0-0000) = 3^6 - 3^4 = 729 - 81 = 648
    tf = TFloat(Tryte(1640 + 648, 8))
    assert tf.regime == 3
    assert len(tf.exponent) == 1
    assert len(tf.fraction) == 4


# ── to_tryte roundtrip ─────────────────────────────────────────

def test_to_tryte_roundtrip():
    original = Tryte(1640, 8)
    tf = TFloat(original)
    assert tf.to_tryte() == original

def test_to_tryte_roundtrip_negative():
    original = Tryte(-1640, 8)
    tf = TFloat(original)
    assert tf.to_tryte() == original

def test_to_tryte_special():
    assert TFloat(Tryte(0, 8)).to_tryte() == Tryte(0, 8)


# ── Sign property ──────────────────────────────────────────────

def test_sign_positive():
    tf = TFloat(Tryte(1640, 8))
    assert tf.sign == P

def test_sign_negative():
    tf = TFloat(Tryte(-1640, 8))
    assert tf.sign == N

def test_sign_zero():
    tf = TFloat(Tryte(0, 8))
    assert tf.sign == Z


# ── Monotonicity (Proposition 4) ───────────────────────────────
# int(t) < int(u) ⇒ θ(t) < θ(u)

def test_positive_monotonic():
    """All positive 8-trit tekums should be monotonically increasing."""
    prev = None
    max_val = (3**8 - 1) // 2  # 3280
    for i in range(1, max_val):
        try:
            tf = TFloat(Tryte(i, 8))
        except (OverflowError, ValueError):
            continue
        if tf._special is not None:
            continue
        val = float(tf)
        if prev is not None:
            assert val >= prev, f"Monotonicity broken at int={i}"
        prev = val

def test_negative_monotonic():
    """All negative 8-trit tekums should be monotonically increasing
    (more negative → less negative)."""
    prev = None
    max_val = (3**8 - 1) // 2
    for i in range(-max_val + 1, 0):
        try:
            tf = TFloat(Tryte(i, 8))
        except (OverflowError, ValueError):
            continue
        if tf._special is not None:
            continue
        val = float(tf)
        if prev is not None:
            assert val >= prev, f"Monotonicity broken at int={i}"
        prev = val

# ── Construction from float ─────────────────────────────────────
 
def test_from_float_one():
    tf = TFloat(1.0, width=8)
    assert abs(float(tf) - 1.0) < 1e-6
 
def test_from_float_three():
    tf = TFloat(3.0, width=8)
    assert str(tf) == "3.0"
    assert tf.__repr__() == "TFloat(3.0, width=8)"
    assert abs(float(tf) - 3.0) < 0.5
 
def test_from_float_negative():
    tf = TFloat(-1.0, width=8)
    assert abs(float(tf) + 1.0) < 1e-6
    assert tf.__repr__() == "TFloat(-1.0, width=8)"
    assert str(tf) == "-1.0"
 
def test_from_float_fraction():
    tf = TFloat(0.5, width=8)
    assert abs(float(tf) - 0.5) < 0.1
 
def test_from_float_large():
    tf = TFloat(1400.0, width=36)
    assert abs(float(tf) - 1400.0) < 1.0
 
def test_from_float_small():
    tf = TFloat(0.001, width=8)
    assert float(tf) > 0
    assert abs(float(tf) - 0.001) < 0.01
 
def test_from_float_very_large():
    tf = TFloat(1e30, width=26)
    assert float(tf) > 1e28
 
def test_from_float_very_small():
    tf = TFloat(1e-30, width=26)
    assert float(tf) > 0
    assert float(tf) < 1e-28
 
def test_from_float_negative_large():
    tf = TFloat(-1e10, width=26)
    assert float(tf) < 0
 
def test_from_float_various_widths():
    for w in [8, 10, 20, 26, 36]:
        tf = TFloat(42.0, width=w)
        assert abs(float(tf) - 42.0) < 1.0, f"Failed for width={w}"
 
def test_from_float_precision_increases_with_width():
    errors = []
    for w in [8, 10, 20, 26]:
        tf = TFloat(3.14159, width=w)
        errors.append(abs(float(tf) - 3.14159))
    for i in range(len(errors) - 1):
        assert errors[i] >= errors[i+1] - 1e-15, \
            f"Precision did not improve from width {[8,10,20,26][i]} to {[8,10,20,26][i+1]}"
 
 
# ── Special values from float ───────────────────────────────────
 
def test_from_float_zero():
    tf = TFloat(0.0, width=8)
    assert tf._special == "zero"
    assert float(tf) == 0.0
 
def test_from_float_inf():
    tf = TFloat(float('inf'), width=8)
    assert tf._special == "inf"
    assert math.isinf(float(tf))
 
def test_from_float_nan():
    tf = TFloat(float('nan'), width=8)
    assert tf._special == "nar"
    assert math.isnan(float(tf))
 
 
# ── Roundtrip float → TFloat → float ───────────────────────────
 
def test_roundtrip_one():
    assert abs(float(TFloat(1.0, width=8)) - 1.0) < 1e-6
 
def test_roundtrip_integers():
    for v in [1, 2, 3, 9, 27, 81]:
        tf = TFloat(float(v), width=20)
        assert abs(float(tf) - v) < 0.5, f"Roundtrip failed for {v}"
 
def test_roundtrip_negative():
    for v in [-1.0, -3.0, -9.0, -0.5]:
        tf = TFloat(v, width=20)
        assert abs(float(tf) - v) < 0.5, f"Roundtrip failed for {v}"
 
def test_roundtrip_tryte_float_tryte():
    """Tryte → TFloat → float → TFloat → Tryte should preserve the Tryte."""
    for val in [1640, 1883, 2000, 2500]:
        original = Tryte(val, 8)
        tf1 = TFloat(original)
        v = float(tf1)
        tf2 = TFloat(v, width=8)
        assert abs(float(tf1) - float(tf2)) < 1e-6, \
            f"Roundtrip diverged for int={val}"
 
 
# ── Width validation from float ─────────────────────────────────
 
def test_from_float_odd_width():
    with pytest.raises(ValueError):
        TFloat(1.0, width=9)
 
def test_from_float_small_width():
    with pytest.raises(ValueError):
        TFloat(1.0, width=6)
 
def test_from_float_no_width():
    with pytest.raises(ValueError):
        TFloat(1.0)

def test_neg():
    for v in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
        assert float(TFloat(-v, 26)) - float(-TFloat(v, 26)) < 1e-6
        assert abs(float(-TFloat(v, 26)) + v ) < 1e-6

def test_lt():
    # Cf proposition 4 Tekum Paper
    v = [-30.23, -24.1,-1.3, 2.56, 15.23234, 1240.23]
    for i in range(len(v)-1):
        assert TFloat(v[i],10) < TFloat(v[i+1],10)

    with pytest.raises(TypeError):
        _ = TFloat(9.0, 8) < 10.0

def test_eq():
    assert TFloat(5.0,8) == -TFloat(-5.0,8)
    with pytest.raises(ValueError):
        _ = TFloat(5.0,8) != TFloat(5.0,10)
    assert not TFloat(5.0,8) == 8

def test_add():
    for i in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
        for j in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
            a = TFloat(i,26)
            b = TFloat(j,26)
            assert abs(float(a+b) - (i+j)) < 1e-6
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) + TFloat(23.2,22)

    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) + 23.2

def test_sub():
    for i in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
        for j in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
            a = TFloat(i,26)
            b = TFloat(j,26)
            assert abs(float(a-b) - (i-j)) < 1e-6
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) - TFloat(23.2,22)

    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) - 23.2

def test_mul():
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) * 23.2
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) * TFloat(23.2,22)
    for i in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
        for j in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
            a = TFloat(i,26)
            b = TFloat(j,26)
            assert abs(float(a*b) - (i*j)) < 1e-4

def test_truediv():
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) / 23.2
    with pytest.raises(TypeError):
        _ = TFloat(12.0,24) / TFloat(23.2,22)
    for i in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
        for j in [-30.23, 24.1,-1.3, 2.56, 15.23234, 1240.23]:
            a = TFloat(i,26)
            b = TFloat(j,26)
            assert abs(float(a/b) - (i/j)) < 1e-4
    assert (TFloat(12.0,8)/TFloat(0.0,8)) == TFloat(float('inf'), 8)

