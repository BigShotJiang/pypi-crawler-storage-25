from tritlib import Trits, Trit, Tryte, Z,N,P
import pytest

def test_tryte():
    a = Tryte(0, width = 6) 
    assert list(a.trits) == [Z]*6
    b = Tryte(2, width = 6)
    assert list(b.trits) == [N, P] + [Z] * 4

    with pytest.raises(OverflowError):
        Tryte(-400, width=6)
    with pytest.raises(OverflowError):
        Tryte(400, width=6)

    assert Tryte(42, width=6) == Tryte("+---0",6)

def test_hash_equal():
    assert hash(Tryte(42, 6)) == hash(Tryte(42, 6))

def test_hash_in_set():
    s = {Tryte(42, 6), Tryte(42, 6), Tryte(10, 6)}
    assert len(s) == 2

def test_hash_as_dict_key():
    d = {Tryte(42, 6): "hello"}
    assert d[Tryte(42, 6)] == "hello"

def test_immutability():
    t = Tryte(12,4)
    with pytest.raises(AttributeError):
        t._trits = (Z, Z, P, Z)

def test_repr():
    t = Tryte(12,4)
    assert t.__repr__() == "Tryte(12,4)"

def test_get_item():
    a = Tryte('+-0++',5)
    assert a[2:4] == Trits('-0')
    with pytest.raises(TypeError):
        a["test"]

def test_set():
    a = Tryte('+--+',4)
    b = a.set(3, Z)
    assert b == Tryte("0--+",4)
    with pytest.raises(ValueError):
        a.set(5, Z)

def test_tryte_lt():
    assert Tryte(42, width=6) < Tryte(45, width=6)
    assert Tryte(-19, width=6) < Tryte(45, width=6)
    assert Tryte(-42, width=6) < Tryte(-14, width=6)
    assert Tryte(45, width=6) > Tryte(-42, width=6)
    assert Tryte(45, width=6) > Tryte(42, width=6)
    assert Tryte(-15, width=6) > Tryte(-42, width=6)
    assert Tryte(-42, width=6) <= Tryte(-42, width=6)
    assert Tryte(42, width=6) >= Tryte(42, width=6)

def test_tryte_width():
    assert len(Tryte(42,6)) == 6
    with pytest.raises(ValueError):
        _ = Tryte(42,6) > Tryte(42,9)
    with pytest.raises(ValueError):
        _ = Tryte(42,6) == Tryte(42,9)

def test_tryte_add():
    assert Tryte(42,6) == Tryte(31,6) + Tryte(11,6)
    assert Tryte(300,6) + Tryte(300,6)
    assert (Tryte(332,6),Trit(0)) == Tryte(300,6).add_with_carry(Tryte(32,6))
    assert (Tryte(-364,6),Trit(1)) == Tryte(300,6).add_with_carry(Tryte(65,6))
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) + Tryte(i,6) == Tryte(i+j, 6)

    with pytest.raises(TypeError):
        _ = Tryte(12,4) + 3
    with pytest.raises(TypeError):
        _ = Tryte(12,4) + Tryte(12,5)
    with pytest.raises(TypeError):
        Tryte(300,6).add_with_carry(Tryte(32,4))
    assert Tryte(300,6).add_with_carry(32) is NotImplemented

def test_tryte_neg():
    assert Tryte(4,6) == -Tryte(-4,6)
    assert Tryte(0,6) == -Tryte(0,6)
    assert Tryte(-10,6) == -Tryte(10,6)

def test_tryte_sub():
    assert Tryte(6,6) - Tryte(7,6) == Tryte(-1,6)
    assert Tryte(20,6) - Tryte(4,6) == Tryte(16,6)
    assert Tryte(10,6) - Tryte(24,6) == Tryte(-14,6)
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) - Tryte(i,6) == Tryte(j-i, 6)

def test_tryte_mul():
    for i in range(-10,10):
        for j in range(-10,10):
            assert Tryte(j,6) * Tryte(i,6) == Tryte(i*j, 6)
    with pytest.raises(TypeError):
        _ = Tryte(12,4)*Tryte(3,3)
    with pytest.raises(TypeError):
        _ = Tryte(12,4)*3

def test_tryte_to_str():
    assert str(Tryte(-1,6)) == "00000-"
    assert str(Tryte(1,6)) == "00000+"
    assert str(Tryte(0,6)) == "000000"
    assert str(Tryte(2,6)) == "0000+-"
    assert str(Tryte(3,6)) == "0000+0"
    assert str(Tryte(5,6)) == "000+--"
    assert str(Tryte(-2,6)) == "0000-+"
    assert str(Tryte(-3,6)) == "0000-0"
    assert str(Tryte(-5,6)) == "000-++"

def test_tryte_to_trits():
    for i in range(-15,15):
        assert Tryte(i,6).to_trits() == Trits(i)


def test_be_trits():
    assert Tryte(-1,6)._be_trits == [N]
    assert Tryte(2,6)._be_trits == [P,N]
    assert Tryte(5,6)._be_trits == [P,N,N]
    assert Tryte(5,9)._be_trits == [P,N,N]
    assert Tryte(-5,6)._be_trits == [N,P,P]
    assert Tryte(-5,9)._be_trits == [N,P,P]

    assert Tryte.from_be_trits([N,P,P],6) == Tryte(-5,6)
    assert Tryte.from_be_trits([P,N],6) == Tryte(2,6)
    assert Tryte.from_be_trits([P,N,N],6) == Tryte(5,6)
    assert Tryte.from_be_trits([N,P,P],9) == Tryte(-5,9)

    for i in range(-105,355):
        t = Tryte(i, 6)
        b = t._be_trits
        assert Tryte.from_be_trits(b, 6) == t

def test_resize():
    for j in range(-10,10):
        for i in range(7,10):
            a = Tryte(j, 6)
            assert a.to_width(i) == Tryte(j,i)

    be_trits = [N,P,P,Z,P]
    assert Tryte.from_be_trits(be_trits,6).to_width(3) == Tryte.from_be_trits(be_trits[2:],3)


def test_divmod():
    a = [-101,-42,-13,-4,0,5,11,43,123]
    b = [-89,-34,-10,-1,2,8,20,40,80]
    for i in a[::1]:
        for j in b:
            q, r = divmod(Tryte(i,6), Tryte(j,6))
            assert int(q) * j + int(r) == i
    q, r = divmod(Tryte(13,6), Tryte(4,6))
    assert int(q) * 4 + int(r) == 13
    q, r = divmod(Tryte(7,6), Tryte(4,6))
    assert int(q) == 2 and int(r) == -1
    q, r = divmod(Tryte(-7,6), Tryte(4,6))
    assert int(q) * 4 + int(r) == -7

    q, r = divmod(Tryte(40,27), Tryte(6, 27))
    assert len(q) == len(r) == 27
    assert int(q) == 6
    assert int(r) == 4

    q, r = divmod(Tryte(0,6), Tryte(5,6))
    assert int(q) == 0 and int(r) == 0

    with pytest.raises(ZeroDivisionError):
        divmod(Tryte(4,6),Tryte(0,6))

    q, r = divmod(Tryte(5,6), Tryte(15,6))
    assert int(q) == 0 and int(r) == 5
    q, r = divmod(Tryte(14,6), Tryte(15,6))
    assert int(q) == 1 and int(r) == -1
    with pytest.raises(TypeError):
        _ = divmod(Tryte(12,4),Tryte(3,3))
    with pytest.raises(TypeError):
        _ = divmod(Tryte(12,4),3)

def test_floordiv_and_mod():
    assert Tryte(12,4)//Tryte(5,4) == Tryte(2,4)
    assert Tryte(13,4) % Tryte(5,4) == Tryte(3,4)


def test_shift():
    for n in range(10):
        a = Tryte(3**n,10)
        assert a >> n == Tryte(1,10)
        assert Tryte(1,10) << n == a
        a = Tryte(-3**n,10)
        assert a >> n == Tryte(-1,10)
        assert Tryte(-1,10) << n == a


def test_rotations():
    a = Tryte("++-+00", 6)
    assert a.rotate_left(2) == Tryte("-+00++", 6)
    assert a.rotate_right(2) == Tryte("00++-+", 6)


def test_get():
    a = Tryte("+-0++-",6)
    assert a[0] == N
    assert a[1] == P
    assert a[2] == P
    assert a[3] == Z
    assert a[4] == N
    assert a[5] == P

    b = a.set(3,N)
    assert b[3] == N
    assert b == Tryte("+--++-",6)

def test_cons():
    a = Tryte("+++---000", 9)
    b = Tryte("+-0+-0+-0", 9)
    assert a.cons(b) == Tryte("+000-0000",9)

def test_acons():
    a = Tryte("+++---000", 9)
    b = Tryte("+-0+-0+-0", 9)
    assert a.acons(b) == Tryte("00-00+-+0",9)


def test_add_saturating():
    assert int(Tryte(300, 6).add_saturating(Tryte(300, 6))) == 364
    assert int(Tryte(-300, 6).add_saturating(Tryte(-300, 6))) == -364
    assert int(Tryte(10, 6).add_saturating(Tryte(5, 6))) == 15  # pas d'overflow

def test_sub_saturating():
    assert int(Tryte(-300, 6).sub_saturating(Tryte(300, 6))) == -364
    assert int(Tryte(300, 6).sub_saturating(Tryte(-300, 6))) == 364
    assert int(Tryte(10, 6).sub_saturating(Tryte(15, 6))) == -5  # pas d'overflow
