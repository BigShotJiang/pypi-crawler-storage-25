
from contextvars import ContextVar
_current_logic = ContextVar('_current_logic', default=None)
from contextlib import contextmanager

@contextmanager
def logic_mode(logic):
    if isinstance(logic, type):
        logic = logic()
    token = _current_logic.set(logic)
    try:
        yield
    finally:
        _current_logic.reset(token)
