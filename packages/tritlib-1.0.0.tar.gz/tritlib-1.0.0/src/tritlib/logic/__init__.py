"""
tritlib.logic: Ternary logic operations.

This subpackage provides implementations of various ternary logic systems:
Lukasiewicz, RM3, Bochvar, Heyting, and Kleene.
"""

from .lukasiewicz import Lukasiewicz
from .rm3 import RM3
from .bochvar import Bochvar
from .heyting import HT
from .kleene import Kleene
L3 = Lukasiewicz
B3 = Bochvar
K3 = Kleene
from .plural import PluralResult, pluralize

__all__ = ["Lukasiewicz", "RM3", "Bochvar", "HT", "Kleene", "B3","K3","L3", "pluralize", "PluralResult"]
