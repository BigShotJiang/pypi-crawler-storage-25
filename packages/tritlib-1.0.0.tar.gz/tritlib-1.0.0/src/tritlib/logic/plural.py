from collections import Counter
from tritlib import Trit
from dataclasses import dataclass
from .bochvar import Bochvar as BI3
from .kleene import Kleene as K3
from .heyting import HT
from .lukasiewicz import Lukasiewicz as L3
from .rm3 import RM3
from tritlib.context import logic_mode


@dataclass(frozen=True)
class PluralResult:
    results: dict[str, Trit] 

    @property
    def _to_list(self):
        return list(self.results.values())

    @property
    def divergent(self):
        return len(set(self._to_list)) > 1

    @property
    def consensus(self):
        return None if self.divergent else self._to_list[0]

    @property
    def agree(self) -> set[str]:
        counts = Counter(self.results.values())
        majority_value = counts.most_common(1)[0][0]
        return set([k for k, v in self.results.items() if v == majority_value])

    @property
    def disagree(self) -> set[str]:
        if self.consensus is not None:
            return set([])
        counts = Counter(self.results.values())
        majority_value = counts.most_common(1)[0][0]
        return set([k for k, v in self.results.items() if v != majority_value])


    @property
    def groups(self) -> dict[str,list[Trit]]:
        res = dict()
        for t in set(self._to_list):
            res[t] = [k for k, v in self.results.items() if v == t]
        return res


def pluralize(f, *args) -> PluralResult:
    logics = {'BI3':BI3, 'HT':HT, 'K3':K3, 'L3':L3, 'RM3': RM3}
    res = dict()
    for k,v in logics.items():
        with logic_mode(v):
            res[k] = f(*args)
    return PluralResult(res)
