# markdawn

English description follows Japanese.

**数式対応**の Markdown → HTML コンバーター。教科書のように綺麗で読みやすいドキュメントを生成します。

発音: `/ˈmɑːrkdɔːn/`

`markdawn` という名前は `md` (markdown) と `dawn` (夜明け) を掛けたものです。元の Markdown よりも読みやすくて綺麗な資料が出来ることを夜明けに重ねています。

## 特徴

- **数式レンダリング**: KaTeX による LaTeX 形式の数式を標準サポート
- **教科書のような見た目**: 学習ノート・レポート・LLM の回答整形などに最適
- **シンタックスハイライト**: highlight.js による多彩なテーマでコードを綺麗に表示
- **単一 HTML ファイル出力**: 共有・公開・印刷が簡単
- ヘッダー・サブタイトル・アクセントカラー・言語などをカスタマイズ可能

## インストール

```bash
pip install markdawn
```

## 使い方

### コマンドラインから

基本形:

```bash
markdawn input.md
```

これで `input.html` が同じ場所に生成されます。

利用可能なオプション:

| オプション | デフォルト | 説明 |
|---|---|---|
| `input` | (必須) | 入力 Markdown ファイル |
| `-o`, `--output` | 同名の `.html` | 出力 HTML ファイルのパス |
| `--title` | H1 またはファイル名 | ヘッダーバーのタイトル |
| `--subtitle` | (空) | ヘッダーバーのサブタイトル |
| `--accent` | `#2c5f8a` | アクセントカラー (16進数) |
| `--lang` | `ja` | HTML の `lang` 属性 (例: `ja`, `en`) |
| `--hl-theme` | `atom-one-light` | highlight.js のテーマ名 (例: `github`, `github-dark`, `monokai`, `vs2015`) |

実行例:

```bash
markdawn notes.md -o notes.html --title "第3講" --subtitle "線形代数" --accent "#8a2c5f" --hl-theme github-dark
```

### Python から

```python
import markdawn

markdawn.convert("input_filename.md")
```

## 使いどころ

- LLM の回答を綺麗で共有しやすい資料に整える
- 数式を含む講義ノートや技術文書の作成
- 素の Markdown では味気ないので、もっと整った見た目にしたいとき

---

# markdawn

A Markdown-to-HTML converter with **math support**, designed to produce textbook-quality, beautifully readable documents.

Pronunciation: `/ˈmɑːrkdɔːn/`

The name `markdawn` is a play on `md` (markdown) + `dawn` — the goal is to produce documents that are cleaner and more readable than plain Markdown, like a new dawn for your notes.

## Features

- **Math rendering** powered by KaTeX (LaTeX-style equations work out of the box)
- **Textbook-style appearance** — clean typography suitable for study notes, reports, or polished LLM outputs
- **Syntax highlighting** for code blocks via highlight.js (multiple themes available)
- **Single-file HTML output** — easy to share, host, or print
- Customizable header, subtitle, accent color, and language

## Installation

```bash
pip install markdawn
```

## Usage

### From the command line

The basic form is:

```bash
markdawn input.md
```

This produces `input.html` next to the source file.

Available options:

| Option | Default | Description |
|---|---|---|
| `input` | (required) | Input Markdown file |
| `-o`, `--output` | same name with `.html` | Output HTML file path |
| `--title` | H1 or filename | Title shown in the header bar |
| `--subtitle` | (empty) | Subtitle shown in the header bar |
| `--accent` | `#2c5f8a` | Accent color (hex code) |
| `--lang` | `ja` | `lang` attribute of the HTML (e.g. `ja`, `en`) |
| `--hl-theme` | `atom-one-light` | highlight.js theme name (e.g. `github`, `github-dark`, `monokai`, `vs2015`) |

Example:

```bash
markdawn notes.md -o notes.html --title "Lecture 3" --subtitle "Linear Algebra" --accent "#8a2c5f" --lang en --hl-theme github-dark
```

### From Python

```python
import markdawn

markdawn.convert("input_filename.md")
```

## When to use markdawn

- Turning LLM responses into clean, shareable documents
- Class notes or technical writeups containing equations
- Any case where plain Markdown looks too raw and you want a more polished result
