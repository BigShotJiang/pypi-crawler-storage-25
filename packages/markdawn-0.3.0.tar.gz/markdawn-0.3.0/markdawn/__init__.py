# 数式・コードのmarkdownの描画ツール [markdawn]

"""
md_to_html.py — 数式対応 Markdown → HTML コンバーター
KaTeX によるレンダリングに対応したスタイリッシュな HTML を生成します。
highlight.js によるコードのシンタックスハイライトにも対応。

使い方 (引数):
	input.md
	input.md -o output.html
	input.md --title "カスタムタイトル" --subtitle "サブタイトル"
	input.md --accent "#2c5f8a" --lang en
	input.md --hl-theme github-dark
"""

import re
import sys
import fies
import argparse
from html import escape
from pathlib import Path
from relpath import rel2abs

# ─────────────────────────────────────────
#  数式プレースホルダー (mistune が数式を壊さないよう保護)
# ─────────────────────────────────────────
class MathProtector:
	"""$...$ と $$...$$ をプレースホルダーで保護し、HTML変換後に復元する"""

	def __init__(self):
		self._store: dict[str, str] = {}
		self._counter = 0

	def _key(self) -> str:
		k = f"\x00MATH{self._counter}\x00"
		self._counter += 1
		return k

	def protect(self, text: str) -> str:
		# ブロック数式 $$...$$ を先に処理
		def replace_block(m):
			k = self._key()
			self._store[k] = f"$$\n{m.group(1).strip()}\n$$"
			return f"\n\n{k}\n\n"

		text = re.sub(r'\$\$(.*?)\$\$', replace_block, text, flags=re.DOTALL)

		# インライン数式 $...$
		def replace_inline(m):
			k = self._key()
			self._store[k] = f"${m.group(1)}$"
			return k

		text = re.sub(r'\$(?!\$)(.+?)(?<!\$)\$', replace_inline, text)
		return text

	def restore(self, html: str) -> str:
		for k, v in self._store.items():
			html = html.replace(escape(k), v)   # escape() された版
			html = html.replace(k, v)            # そのままの版
		return html


# ─────────────────────────────────────────
#  Markdown → HTML 変換
# ─────────────────────────────────────────
def md_to_html_body(md_text: str) -> tuple[str, str]:
	"""
	Markdown テキストを HTML ボディ文字列に変換する。
	戻り値: (html_body, detected_title)
	"""
	protector = MathProtector()
	md_text = protector.protect(md_text)

	# mistune が利用可能なら使用、なければ簡易変換にフォールバック
	try:
		import mistune
		html_body = mistune.html(md_text)
	except ImportError:
		html_body = _simple_md_to_html(md_text)

	html_body = protector.restore(html_body)

	# H1 からタイトルを取得（あれば）
	m = re.search(r'<h1[^>]*>(.*?)</h1>', html_body, re.IGNORECASE | re.DOTALL)
	detected_title = re.sub(r'<[^>]+>', '', m.group(1)).strip() if m else ""

	return html_body, detected_title


def _simple_md_to_html(text: str) -> str:
	"""mistune 未インストール時の簡易フォールバック変換"""
	lines = text.split('\n')
	html_lines = []
	in_code = False
	in_list = False
	buffer = []

	def flush_paragraph():
		nonlocal buffer
		if buffer:
			content = ' '.join(buffer).strip()
			if content:
				html_lines.append(f'<p>{inline_format(content)}</p>')
			buffer = []

	def inline_format(s: str) -> str:
		s = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', s)
		s = re.sub(r'\*(.+?)\*', r'<em>\1</em>', s)
		s = re.sub(r'`(.+?)`', r'<code>\1</code>', s)
		s = re.sub(r'\[(.+?)\]\((.+?)\)', r'<a href="\2">\1</a>', s)
		return s

	for line in lines:
		# コードブロック
		if line.startswith('```'):
			if not in_code:
				flush_paragraph()
				lang = line[3:].strip()
				html_lines.append(f'<pre><code class="language-{lang}">' if lang else '<pre><code>')
				in_code = True
			else:
				html_lines.append('</code></pre>')
				in_code = False
			continue

		if in_code:
			html_lines.append(escape(line))
			continue

		# 見出し
		hm = re.match(r'^(#{1,6})\s+(.*)', line)
		if hm:
			flush_paragraph()
			if in_list:
				html_lines.append('</ul>')
				in_list = False
			level = len(hm.group(1))
			html_lines.append(f'<h{level}>{inline_format(hm.group(2))}</h{level}>')
			continue

		# 水平線
		if re.match(r'^[-*_]{3,}\s*$', line):
			flush_paragraph()
			html_lines.append('<hr>')
			continue

		# リスト
		lm = re.match(r'^[-*+]\s+(.*)', line)
		if lm:
			flush_paragraph()
			if not in_list:
				html_lines.append('<ul>')
				in_list = True
			html_lines.append(f'<li>{inline_format(lm.group(1))}</li>')
			continue

		if in_list and not lm:
			html_lines.append('</ul>')
			in_list = False

		# 空行
		if line.strip() == '':
			flush_paragraph()
			continue

		buffer.append(inline_format(line))

	flush_paragraph()
	if in_list:
		html_lines.append('</ul>')

	return '\n'.join(html_lines)


#  HTML テンプレート (htmlではezpipの公開範囲に含まれないため便宜上py拡張子としている)
HTML_TEMPLATE = fies[rel2abs("./parts/template.py"), "text"]

def build_header(title: str, subtitle: str) -> str:
	if not title:
		return ""
	subtitle_html = f'\n  <div class="subtitle">{escape(subtitle)}</div>' if subtitle else ""
	return (
		f'<div class="header-bar">\n'
		f'  <div class="main-title">{escape(title)}</div>'
		f'{subtitle_html}\n'
		f'</div>'
	)


def hex_to_light(hex_color: str, lightness: float = 0.92) -> str:
	"""アクセントカラーから薄い背景色を自動生成"""
	h = hex_color.lstrip('#')
	if len(h) != 6:
		return "#e8f0f8"
	r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
	r2 = int(r + (255 - r) * lightness)
	g2 = int(g + (255 - g) * lightness)
	b2 = int(b + (255 - b) * lightness)
	return f"#{r2:02x}{g2:02x}{b2:02x}"


def annotate_code_blocks_with_lang(html_body: str) -> str:
	"""
	<pre><code class="language-xxx"> を <pre data-lang="xxx"><code class="language-xxx">
	に書き換え、CSS擬似要素で言語ラベルを表示できるようにする。
	"""
	pattern = re.compile(
		r'<pre>(\s*<code\s+class="language-([^"\s]+)"[^>]*>)',
		re.IGNORECASE,
	)
	return pattern.sub(lambda m: f'<pre data-lang="{m.group(2)}">{m.group(1)}', html_body)

# md→html 変換 (python API) [markdawn]
def convert(
	input_path: str,
	output_path: str | None = None,
	title: str | None = None,
	subtitle: str = "",
	accent: str = "#2c5f8a",
	lang: str = "ja",
	hl_theme: str = "atom-one-light",
) -> Path:
	src = Path(input_path)
	if not src.exists():
		sys.exit(f"Error: ファイルが見つかりません: {src}")

	md_text = src.read_text(encoding="utf-8")
	html_body, detected_title = md_to_html_body(md_text)

	# コードブロックに言語ラベル用の data-lang 属性を付与
	html_body = annotate_code_blocks_with_lang(html_body)

	# タイトル決定（優先順位: 引数 > Markdown の H1 > ファイル名）
	final_title = title or detected_title or src.stem

	header_html = build_header(final_title, subtitle)

	accent_light = hex_to_light(accent)
	# border は accent を少し薄く
	h = accent.lstrip('#')
	r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
	border_color = f"#{min(r+80,255):02x}{min(g+80,255):02x}{min(b+80,255):02x}"

	html = HTML_TEMPLATE.format(
		lang=lang,
		title=escape(final_title),
		color_text="#1a1a2e",
		color_bg="#ffffff",
		color_accent=accent,
		color_accent_light=accent_light,
		color_border=border_color,
		color_code_bg="#f4f6f9",
		font_family="'Hiragino Kaku Gothic ProN', 'Noto Sans JP', 'Yu Gothic', sans-serif",
		header_html=header_html,
		body_html=html_body,
		hl_theme=hl_theme,
	)

	out = Path(output_path) if output_path else src.with_suffix(".html")
	out.write_text(html, encoding="utf-8")
	return out

# コマンドラインからの利用
def console_command():
	parser = argparse.ArgumentParser(
		description="数式対応 Markdown → HTML コンバーター 「markdawn」 (KaTeX + highlight.js)"
	)
	parser.add_argument("input", help="入力 Markdown ファイル")
	parser.add_argument("-o", "--output", default=None, help="出力 HTML ファイル（省略時は同名 .html）")
	parser.add_argument("--title",    default=None,     help="ヘッダーバーのタイトル（省略時は H1 またはファイル名）")
	parser.add_argument("--subtitle", default="",       help="ヘッダーバーのサブタイトル")
	parser.add_argument("--accent",   default="#2c5f8a",help="アクセントカラー（16進数, 例: #2c5f8a）")
	parser.add_argument("--lang",     default="ja",     help="HTML の lang 属性（例: ja, en）")
	parser.add_argument("--hl-theme", default="atom-one-light",
						help="highlight.js テーマ名 (例: atom-one-light, github, github-dark, monokai, vs2015)")
	args = parser.parse_args()

	# md→html 変換 (python API) [markdawn]
	out = convert(
		input_path=args.input,
		output_path=args.output,
		title=args.title,
		subtitle=args.subtitle,
		accent=args.accent,
		lang=args.lang,
		hl_theme=args.hl_theme,
	)
	print(f"markdawn 出力完了: {out}")
