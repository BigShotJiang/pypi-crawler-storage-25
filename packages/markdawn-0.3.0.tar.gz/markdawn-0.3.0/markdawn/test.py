
import sys
import ezpip
markdawn = ezpip.load_develop("markdawn", "../", develop_flag = True)

# md→html 変換 (python API) [markdawn]
markdawn.convert(
	input_path="猫の素晴らしさ.md",
)
