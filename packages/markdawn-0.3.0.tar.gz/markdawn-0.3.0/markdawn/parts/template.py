<!DOCTYPE html>
<html lang="{lang}">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title}</title>

  <!-- KaTeX (数式) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.css">
  <script defer src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js"></script>
  <script defer src="https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/contrib/auto-render.min.js"
	onload="renderMathInElement(document.body, {{
	  delimiters: [
		{{left: '$$', right: '$$', display: true}},
		{{left: '$',  right: '$',  display: false}}
	  ],
	  throwOnError: false
	}});"></script>

  <!-- highlight.js (シンタックスハイライト) -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/{hl_theme}.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/highlight.min.js"></script>
  <script>
	document.addEventListener('DOMContentLoaded', () => {{
	  document.querySelectorAll('pre code').forEach((el) => {{
		hljs.highlightElement(el);
	  }});
	}});
  </script>

  <style>
	:root {{
	  --text:         {color_text};
	  --bg:           {color_bg};
	  --accent:       {color_accent};
	  --accent-light: {color_accent_light};
	  --border:       {color_border};
	  --code-bg:      {color_code_bg};
	}}

	* {{ box-sizing: border-box; margin: 0; padding: 0; }}

	body {{
	  font-family: {font_family};
	  font-size: 16px;
	  line-height: 1.85;
	  color: var(--text);
	  background: var(--bg);
	  max-width: 820px;
	  margin: 0 auto;
	  padding: 48px 32px 80px;
	}}

	h1 {{ display: none; }}

	h2 {{
	  font-size: 1.35rem;
	  color: var(--accent);
	  border-left: 4px solid var(--accent);
	  padding: 6px 0 6px 14px;
	  margin: 2.4em 0 0.9em;
	}}

	h3 {{
	  font-size: 1.1rem;
	  color: #2a4060;
	  margin: 1.8em 0 0.6em;
	  padding-bottom: 3px;
	  border-bottom: 1px solid var(--border);
	}}

	h4 {{
	  font-size: 1rem;
	  font-weight: bold;
	  margin: 1.4em 0 0.4em;
	}}

	p {{ margin: 0.7em 0; }}

	ul, ol {{ margin: 0.6em 0 0.6em 1.5em; }}
	li {{ margin: 0.3em 0; }}

	strong {{ color: #1a3a5c; }}

	/* インラインコード */
	code {{
	  font-family: 'SFMono-Regular', 'Consolas', 'Menlo', monospace;
	  font-size: 0.87em;
	  background: var(--code-bg);
	  border: 1px solid var(--border);
	  border-radius: 4px;
	  padding: 1px 5px;
	}}

	/* コードブロックのラッパー */
	pre {{
	  border-radius: 8px;
	  overflow: hidden;
	  margin: 1.2em 0;
	  font-size: 0.88em;
	  line-height: 1.6;
	  position: relative;
	  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
	}}

	/* highlight.js のコードブロック
	   hljs クラスが highlight.js によって付与されるので
	   そちらで背景・文字色が決定される。padding のみ指定。 */
	pre code.hljs {{
	  padding: 18px 22px;
	  background: none; /* pre 側と二重にしない */
	  font-family: 'SFMono-Regular', 'Consolas', 'Menlo', monospace;
	  font-size: 1em;
	}}

	/* 未ハイライト時 (fallback) */
	pre > code:not(.hljs) {{
	  display: block;
	  background: var(--code-bg);
	  border: 1px solid var(--border);
	  padding: 18px 22px;
	  font-family: 'SFMono-Regular', 'Consolas', 'Menlo', monospace;
	}}

	/* 言語ラベル (右上に言語名を表示) */
	pre[data-lang]::before {{
	  content: attr(data-lang);
	  position: absolute;
	  top: 0;
	  right: 0;
	  font-size: 0.72rem;
	  font-family: 'SFMono-Regular', 'Consolas', monospace;
	  color: #888;
	  background: rgba(255,255,255,0.75);
	  padding: 2px 10px;
	  border-radius: 0 8px 0 6px;
	  letter-spacing: 0.05em;
	  text-transform: lowercase;
	  pointer-events: none;
	}}

	.katex-display {{
	  margin: 1.2em 0;
	  overflow-x: auto;
	  padding: 6px 0;
	}}

	hr {{
	  border: none;
	  border-top: 1px solid var(--border);
	  margin: 2.5em 0;
	}}

	table {{
	  border-collapse: collapse;
	  width: 100%;
	  margin: 1.2em 0;
	  font-size: 0.95em;
	}}

	th, td {{
	  border: 1px solid var(--border);
	  padding: 8px 14px;
	  text-align: left;
	}}

	th {{
	  background: var(--accent-light);
	  color: var(--accent);
	  font-weight: bold;
	}}

	blockquote {{
	  border-left: 3px solid var(--accent);
	  background: var(--accent-light);
	  margin: 1em 0;
	  padding: 10px 16px;
	  border-radius: 0 6px 6px 0;
	}}

	a {{ color: var(--accent); }}

	.header-bar {{
	  background: var(--accent);
	  color: white;
	  border-radius: 8px;
	  padding: 22px 28px;
	  margin-bottom: 2.5em;
	}}

	.header-bar .main-title {{
	  font-size: 1.4rem;
	  font-weight: bold;
	  margin: 0 0 4px;
	}}

	.header-bar .subtitle {{
	  font-size: 0.88rem;
	  opacity: 0.8;
	}}
  </style>
</head>
<body>

{header_html}

{body_html}

</body>
</html>
