# Ask Core Node

This is the core node in the Ask KOI network application. It's responsible for creating new conversation threads, and recording any respones that are made.