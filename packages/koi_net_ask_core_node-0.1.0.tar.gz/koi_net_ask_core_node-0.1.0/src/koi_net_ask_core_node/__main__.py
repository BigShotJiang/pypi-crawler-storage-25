from .core import AskCoreNode

AskCoreNode().run()