from slack_bolt import App as SlackApp
from koi_net.core import FullNode

from .slack_config_manager import SlackConfigManager
from .socket_mode import SlackSocketMode
from .slack_handlers import SlackHandlers
from .config import AskCoreNodeConfig


class AskCoreNode(FullNode):
    config_schema = AskCoreNodeConfig
    
    slack_app = lambda config: SlackApp(
        token=config.env.ask_core_slack_bot_token,
        signing_secret=config.env.ask_core_slack_signing_secret)
    
    slack_config_manager = SlackConfigManager
    
    slack_handlers = SlackHandlers
    socket_mode = SlackSocketMode


