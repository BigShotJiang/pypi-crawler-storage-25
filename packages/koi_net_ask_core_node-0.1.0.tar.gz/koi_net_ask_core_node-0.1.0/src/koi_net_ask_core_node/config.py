from koi_net.config import (
    FullNodeConfig, 
    KoiNetConfig, 
    FullNodeProfile, 
    NodeProvides,
    EnvConfig
)
from pydantic import BaseModel, Field

from .rid_types import AskCoreThread, AskCoreResponse


class SlackEnvConfig(EnvConfig):
    ask_core_slack_bot_token: str
    ask_core_slack_signing_secret: str
    ask_core_slack_app_token: str
    
class SlackConfig(BaseModel):
    team_id: str | None = None
    
class AskCoreNodeConfig(FullNodeConfig):
    env: SlackEnvConfig = Field(default_factory=SlackEnvConfig)
    koi_net: KoiNetConfig = KoiNetConfig(
        node_name="ask-core",
        node_profile=FullNodeProfile(
            provides=NodeProvides(
                event=[AskCoreThread, AskCoreResponse],
                state=[AskCoreThread, AskCoreResponse]
            )
        )
    )
    slack: SlackConfig = SlackConfig()