from dataclasses import dataclass
from logging import Logger
from rid_lib.ext import Bundle
from rid_lib.types import SlackMessage, SlackUser
from slack_bolt import App, Respond
from slack_bolt.context.say.say import Say
from slack_sdk.web.slack_response import SlackResponse
from koi_net.components import Cache, KobjQueue

from .config import AskCoreNodeConfig
from .models import AskCoreThreadModel, AskCoreResponseModel
from .rid_types import AskCoreThread, AskCoreResponse


@dataclass
class SlackHandlers:
    log: Logger
    slack_app: App
    kobj_queue: KobjQueue
    cache: Cache
    config: AskCoreNodeConfig
    
    def __post_init__(self):
        self.register_handlers()
    
    def register_handlers(self):
        self.slack_app.command("/ask-metagov")(self.ask_metagov_cmd)
        self.slack_app.event("message")(self.handle_msg_event)
        self.slack_app.event("reaction_added")(self.handle_reaction_added)
        
    def handle_msg_event(self, event: dict):
        team_id = event["team"]
        channel_id = event["channel"]
        ts = event["ts"]
        user_id = event["user"]
        thread_ts = event.get("thread_ts")
        
        text = event["text"]
        
        subtype = event.get("subtype")
        
        if thread_ts:
            thread_rid = AskCoreThread(team_id, channel_id, thread_ts)
            
            if not self.cache.read(thread_rid):
                return

            resp_rid = AskCoreResponse(team_id, channel_id, ts)
            
            resp = self.slack_app.client.chat_getPermalink(
                channel=channel_id,
                message_ts=ts
            )
            permalink = resp.get("permalink")
            
            resp = AskCoreResponseModel(
                author=SlackUser(team_id, user_id),
                content=text,
                original_msg=SlackMessage(team_id, channel_id, ts),
                permalink=permalink,
                thread=thread_rid
            )
            
            resp_bundle = Bundle.generate(
                rid=resp_rid,
                contents=resp.model_dump(mode="json")
            )
            
            self.kobj_queue.push(bundle=resp_bundle)
            
    def ensure_bot_in_channel(self, channel_id: str):
        try:
            result = self.slack_app.client.conversations_info(channel=channel_id)
            channel = result["channel"]
            
            if not channel.get("is_member", False):
                self.slack_app.client.conversations_join(channel=channel_id)
                self.log.info(f"Joined channel #{channel_id}")
        
        except Exception as e:
            self.log.error(f"Unhandled exception joining channel: {e}")
    
    def ask_metagov_cmd(self, ack, say: Say, command):
        ack()
        
        team_id = command['team_id']
        user_id = command['user_id']
        channel_id = command['channel_id']
        
        self.ensure_bot_in_channel(channel_id)
        
        text = command['text']
        
        msg: SlackResponse = say(blocks=[
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": text
                }
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"Asked by <@{user_id}>"
                    }
                ]
            }
        ])
        
        ts = msg['ts']
        
        thread_rid = AskCoreThread(team_id, channel_id, ts)
        
        resp = self.slack_app.client.chat_getPermalink(
            channel=channel_id,
            message_ts=ts
        )
        permalink = resp.get("permalink")
        
        thread = AskCoreThreadModel(
            asker=SlackUser(team_id, user_id),
            timestamp=float(ts),
            prompt=text,
            original_msg=SlackMessage(team_id, channel_id, ts),
            permalink=permalink
        )
        
        bundle = Bundle.generate(
            rid=thread_rid,
            contents=thread.model_dump(mode="json")
        )
        
        self.kobj_queue.push(bundle=bundle)
    
    def handle_reaction_added(self, event: dict):
        self.log.info("triggered reaction handler")
        
        item = event["item"]
        if item["type"] != "message":
            return
        
        response_rid = AskCoreResponse(
            team_id=self.config.slack.team_id,
            channel_id=item["channel"],
            ts=item["ts"]
        )
        
        bundle = self.cache.read(response_rid)
        if not bundle:
            self.log.info("couldn't find reponse")
            return
        
        response = bundle.validate_contents(AskCoreResponseModel)
        
        emoji: str = event["reaction"]
        reacter = SlackUser(self.config.slack.team_id, event["user"])
        response.reactions.setdefault(emoji, list()).append(reacter)
        
        self.log.info(f"Added reaction '{emoji}' from reacter {reacter}")
        
        self.kobj_queue.push(bundle=Bundle.generate(
            rid=response_rid,
            contents=response.model_dump()
        ))