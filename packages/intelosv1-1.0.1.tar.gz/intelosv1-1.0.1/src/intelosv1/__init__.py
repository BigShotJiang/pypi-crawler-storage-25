def help():
    print("""
========================================
       INTELOSV1 - HELP MENU
========================================

1. TO SEE SOURCE CODE (Menu):
   import intelosv1.__main__ as viewer
   viewer.main()

2. TO RUN EXPERIMENTS DIRECTLY:
   from intelosv1 import aihealthcare
   from intelosv1 import aieducation
   from intelosv1 import token_word
   from intelosv1 import stem_lema

3. FROM TERMINAL / CMD:
   python -m intelosv1

========================================
    """)

# Also make help available directly
if __name__ == "__main__":
    help()
