import os
import sys

def main():
    current_dir = os.path.dirname(__file__)
    files = {
        "1": "aihealthcare.py",
        "2": "aieducation.py",
        "3": "token_word.py",
        "4": "stem_lema.py"
    }

    print("\n" + "="*40)
    print("      AI LAB EXAM CODE VIEWER")
    print("="*40)
    print("Select a file to view the source code:")
    for key, val in files.items():
        print(f"{key}. {val}")
    
    choice = input("\nEnter number (or 'all'): ").strip()

    def print_file(filename):
        path = os.path.join(current_dir, filename)
        if os.path.exists(path):
            print(f"\n--- {filename} ---")
            with open(path, "r") as f:
                print(f.read())
            print("-" * (len(filename) + 10))
        else:
            print(f"Error: {filename} not found.")

    if choice == "all":
        for f in files.values():
            print_file(f)
    elif choice in files:
        print_file(files[choice])
    else:
        print("Invalid choice.")

if __name__ == "__main__":
    main()
