import nltk
from nltk.stem import WordNetLemmatizer
from nltk.stem import PorterStemmer
nltk.download('wordnet')
nltk.download('omw-1.4')
le = WordNetLemmatizer()
ps = PorterStemmer()
sentence = "the QUICK brown fox are 1 and jumping over the lazy dog flies"
k = sentence.split()
stem = []
lemet = []
print(k)
for word in k:
    word = word.lower()
    if word.isalpha():
        stem.append(ps.stem(word))
        lemet.append(le.lemmatize(word,pos='v'))
print(stem)
print(lemet)
