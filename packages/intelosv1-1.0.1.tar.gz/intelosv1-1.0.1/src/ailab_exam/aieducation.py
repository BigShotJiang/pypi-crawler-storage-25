import tensorflow as tf
import numpy as np

# 1. Dataset: [User ID, Course ID]
# User 0 likes courses 0 and 1. User 1 likes courses 1 and 2.
x_train = np.array([[0, 0], [0, 1], [1, 1], [1, 2]], dtype=np.int32)
y_train = np.array([1, 1, 1, 1], dtype=np.float32)

# 2. Sequential Model with Embedding
model = tf.keras.Sequential([
    tf.keras.layers.Embedding(input_dim=10, output_dim=8, input_length=2),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy')
model.fit(x_train, y_train, epochs=50, verbose=0)

# 3. Predict for User 0 and Course 2
prediction = model.predict(np.array([[0, 2]]), verbose=0)
print(f"Prediction Score for User 0 on Course 2: {prediction[0][0]:.4f}")
