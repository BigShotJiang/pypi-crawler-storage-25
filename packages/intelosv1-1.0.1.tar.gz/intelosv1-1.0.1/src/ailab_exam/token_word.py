from nltk.corpus import stopwords
from collections import Counter
import nltk
from nltk import word_tokenize
nltk.download('punkt')


sample_text = "This is a great day for Artificial Intelligence. AI is the future."

tokens = word_tokenize(sample_text.lower())
noise = set(stopwords.words('english'))

clean_tokens = []
for t in tokens:
  if t not in noise and t.isalpha():
    clean_tokens.append(t)

counts = Counter(clean_tokens)
print(counts)
