import tensorflow as tf
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

# 1. Load the CSV Dataset
# Ensure the CSV file is in the same folder as this script
df = pd.read_csv('diabetes_binary_health_indicators_BRFSS2015.csv')

# 'Diabetes_binary' is the target column in the binary dataset
X = df.drop('Diabetes_binary', axis=1).values
y = df['Diabetes_binary'].values

# 2. Preprocess and Scale
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 3. Build Neural Network (Classification Architecture)
model = tf.keras.Sequential([
    tf.keras.Input(shape=(X_train.shape[1],)),
    tf.keras.layers.Dense(32, activation='relu'),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(1, activation='sigmoid') # 1 unit with sigmoid for binary classification
])

# 4. Compile and Train
model.compile(optimizer='adam', 
              loss='binary_crossentropy', 
              metrics=['accuracy'])

print("Training on BRFSS Dataset...")
model.fit(X_train, y_train, epochs=20, batch_size=64, verbose=1)

# 5. Evaluate
loss, accuracy = model.evaluate(X_test, y_test, verbose=0)
print(f"\nTest Accuracy: {accuracy*100:.2f}%")

# 6. Interactive Prediction
def predict_diabetes_interactive():
    print("  DIABETES RISK PREDICTOR")
    try:
        # Get User Inputs
        age = float(input("Enter your Age: "))
        bmi = float(input("Enter your BMI (e.g., 25.5): "))
        
        # BRFSS Age is categorized (1: 18-24, ..., 13: 80+)
        age_cat = max(1, min(13, int((age - 18) // 5 + 1)))

        # Default values for the other 19 features (Dataset Means)
        feature_defaults = [
            0.43, 0.42, 0.96, bmi, 0.44, 0.04, 0.09, 0.76, 
            0.63, 0.81, 0.06, 0.95, 0.08, 2.51, 3.18, 4.24, 
            0.17, 0.44, age_cat, 5.05, 6.05
        ]

        # Scale and Predict
        input_data = scaler.transform([feature_defaults])
        prediction = model.predict(input_data, verbose=0)[0][0]
        
        print(f"\n Probability of Diabetes: {prediction*100:.2f}%")
        if prediction > 0.5:
            print(" Assessment: High Risk")
        else:
            print("Assessment: Low Risk")
            
    except ValueError:
        print("Invalid input. Please enter numbers.")

if __name__ == "__main__":
    predict_diabetes_interactive()
