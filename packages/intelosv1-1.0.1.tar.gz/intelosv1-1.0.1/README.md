# AI Lab Exam Code Viewer

A utility package to quickly access and print source codes for AI Lab experiments.

## Installation

```bash
pip install .
```

## Usage

After installation, run the following command in your terminal:

```bash
show-lab-code
```

This will open an interactive menu where you can choose which experiment's source code you want to print.
