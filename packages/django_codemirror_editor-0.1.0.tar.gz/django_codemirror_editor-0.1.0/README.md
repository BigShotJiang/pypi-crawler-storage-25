# django-codemirror-editor

A Django widget that integrates [CodeMirror 6](https://codemirror.net/) into Django forms and admin as a drop-in replacement for standard textarea fields.

## Features

- **CodeMirrorWidget** - Form widget that renders textareas with CodeMirror 6
- **AdminCodeMirrorWidget** - Specialized widget with admin-specific styling
- **CodeMirrorField** - Model field (`TextField`) that automatically uses CodeMirror in forms
- **Language support** - HTML, CSS, and JavaScript syntax highlighting
- **Formset support** - Works with Django admin inlines and dynamically added forms
- **content-editor plugin** - Integrates with django-content-editor activation/deactivation events

## Requirements

- Python 3.10+
- Django 4.2+

## Installation

```bash
pip install django-codemirror-editor
```

Add to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    ...
    'codemirror_editor',
]
```

## Quick Start

### In a Model

```python
from django.db import models
from codemirror_editor.fields import CodeMirrorField

class Snippet(models.Model):
    code = CodeMirrorField(language='javascript')
```

### In a Form

```python
from django import forms
from codemirror_editor.widgets import CodeMirrorWidget

class SnippetForm(forms.Form):
    code = forms.CharField(widget=CodeMirrorWidget(language='html'))
```

### In Django Admin

```python
from django.contrib import admin
from codemirror_editor.widgets import AdminCodeMirrorWidget

class SnippetAdmin(admin.ModelAdmin):
    formfield_overrides = {
        models.TextField: {'widget': AdminCodeMirrorWidget(language='css')},
    }
```

## Configuration

The `language` parameter accepts: `'html'`, `'css'`, or `'javascript'`.

## Disclaimer

This project is not affiliated with, endorsed by, or associated with [CodeMirror](https://codemirror.net/) or its maintainers. It is an independent, third-party Django integration that bundles the CodeMirror 6 editor library.

## License

MIT License - see [LICENSE](LICENSE) for details.
