default_app_config = "codemirror_editor.apps.CodeMirrorEditorConfig"
