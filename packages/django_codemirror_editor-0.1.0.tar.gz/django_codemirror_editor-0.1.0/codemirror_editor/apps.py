from django.apps import AppConfig


class CodeMirrorEditorConfig(AppConfig):
    name = "codemirror_editor"
    verbose_name = "CodeMirror Editor"
