import json

from django import forms


class CodeMirrorWidget(forms.Textarea):
    """Drop-in Textarea replacement backed by CodeMirror 6."""

    template_name = "codemirror_editor/widget.html"

    def __init__(self, attrs=None, config=None):
        self.config = config or {"language": "html"}
        defaults = {"class": "codemirror-editor-textarea"}
        if attrs:
            defaults.update(attrs)
        super().__init__(attrs=defaults)

    class Media:
        css = {"all": ("codemirror_editor/codemirror-widget.css",)}
        js = (
            "codemirror_editor/codemirror-bundle.min.js",
            "codemirror_editor/codemirror-widget.js",
        )

    def build_attrs(self, base_attrs, extra_attrs=None):
        attrs = super().build_attrs(base_attrs, extra_attrs)
        attrs["data-codemirror-config"] = json.dumps(self.config)
        return attrs


class AdminCodeMirrorWidget(CodeMirrorWidget):
    """CodeMirror widget with admin-specific styling."""

    def __init__(self, attrs=None, config=None):
        admin_attrs = {"class": "codemirror-editor-textarea codemirror-admin"}
        if attrs:
            admin_attrs.update(attrs)
        super().__init__(attrs=admin_attrs, config=config)
