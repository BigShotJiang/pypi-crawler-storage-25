from django.db import models

from .widgets import CodeMirrorWidget


class CodeMirrorField(models.TextField):
    """TextField that uses CodeMirrorWidget by default in forms."""

    def __init__(self, *args, config=None, **kwargs):
        self.codemirror_config = config or {"language": "html"}
        super().__init__(*args, **kwargs)

    def formfield(self, **kwargs):
        kwargs.setdefault("widget", CodeMirrorWidget(config=self.codemirror_config))
        return super().formfield(**kwargs)
