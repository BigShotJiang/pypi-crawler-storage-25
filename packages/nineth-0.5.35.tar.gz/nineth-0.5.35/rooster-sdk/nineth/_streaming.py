"""Internal streaming helpers for public SDK event streams."""

from __future__ import annotations

from typing import Any, Dict, Iterator


_INTERNAL_STREAM_EVENT_TYPES = {
    "client_service_call",
    "client_service_response",
    "model_raw_delta",
    "service_call",
    "service_response",
}


def _coalesce_deltas(events: Iterator[Dict[str, Any]]) -> Iterator[Dict[str, Any]]:
    """Keep visible deltas immediate while dropping internal control events."""
    for event in events:
        if event.get("type") in _INTERNAL_STREAM_EVENT_TYPES:
            continue
        yield event
