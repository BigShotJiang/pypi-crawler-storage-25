"""Internal HTTP and payload helpers — not part of the public API."""

from __future__ import annotations

import json
from typing import Any, Dict, Iterator, List, Optional, Union

import httpx


# ---------------------------------------------------------------------------
# Payload builder
# ---------------------------------------------------------------------------

def _build_payload(
    task_input: str,
    model: str,
    *,
    max_iterations: int,
    reasoning: Optional[str],
    show_reasoning: bool,
    images: Optional[List[str]],
    system_prompt: Optional[str],
    continuous: Optional[bool] = None,
    cache: bool = False,
    base_system: bool = True,
    default_service: Union[bool, List[str]] = False,
    include_service: Optional[List[Any]] = None,
    client_service_results: Optional[List[Dict[str, Any]]] = None,
    debug: bool = False,
    session_id: Optional[str] = None,
) -> Dict[str, Any]:
    if session_id and not cache and not client_service_results:
        raise ValueError("session_id requires cache=True.")

    if isinstance(default_service, bool):
        services_enabled = default_service
        service_names = None
    else:
        seen = set()
        service_names = []
        for raw_name in default_service:
            name = str(raw_name).strip()
            if not name or name in seen:
                continue
            seen.add(name)
            service_names.append(name)
        services_enabled = bool(service_names)
        service_names = service_names or None

    include_service_values = None
    if include_service:
        seen_paths = set()
        seen_client_services = set()
        include_service_values = []
        for raw_item in include_service:
            if isinstance(raw_item, dict):
                name = str(raw_item.get("name", "")).strip()
                if not name or name in seen_client_services:
                    continue
                seen_client_services.add(name)
                include_service_values.append(raw_item)
                continue

            path = str(raw_item).strip()
            if not path or path in seen_paths:
                continue
            seen_paths.add(path)
            include_service_values.append(path)
        include_service_values = include_service_values or None

    payload: Dict[str, Any] = {
        "task_input": task_input,
        "model": model,
        "max_iterations": max_iterations,
        "show_reasoning": show_reasoning,
        "continuous": continuous if continuous is not None else (max_iterations > 10),
        "cache": cache,
        "base_system": bool(base_system),
        "services": services_enabled,
        "debug": debug,
    }
    if reasoning is not None:
        payload["reasoning_effort"] = reasoning
    if service_names:
        payload["service_names"] = service_names
    if include_service_values:
        payload["include_service"] = include_service_values
    if client_service_results:
        payload["client_service_results"] = client_service_results
    if images:
        payload["images"] = images
    if system_prompt:
        payload["system_prompt"] = system_prompt
    if session_id:
        payload["process_id"] = session_id
    return payload


# ---------------------------------------------------------------------------
# Error helpers
# ---------------------------------------------------------------------------

def _mask_model_unavailable_error(
    message: str,
    *,
    model: Optional[str],
    status_code: Optional[int] = None,
) -> str:
    text = (message or "").strip()
    lowered = text.lower()
    is_subscription_error = (
        "requires a subscription" in lowered
        or "upgrade for access" in lowered
        or "unable to access model" in lowered
        or "please visit https://api.together.ai/models to view the list of supported models." in lowered
    )

    if not is_subscription_error:
        return text
    if status_code is not None and status_code != 403:
        return text
    resolved_model = model or "unknown"
    return f"model {resolved_model} is currently unavailable. [err_hint]: oom."


def _read_error_response_text(response: httpx.Response) -> str:
    try:
        body = response.read()
    except Exception:
        body = b""

    if body:
        try:
            return body.decode().strip()
        except UnicodeDecodeError:
            return body.decode(errors="replace").strip()

    try:
        return response.text.strip()
    except Exception:
        return ""

def _raise_for_status(response: httpx.Response, *, model: Optional[str] = None) -> None:
    try:
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        from nineth.client import NinethAPIError
        message = _read_error_response_text(response) or str(exc)
        message = _mask_model_unavailable_error(
            message,
            model=model,
            status_code=response.status_code,
        )
        raise NinethAPIError(message) from exc


def _raise_for_stream_event(event: Dict[str, Any], *, model: Optional[str] = None) -> None:
    if event.get("type") != "error":
        return
    from nineth.client import NinethAPIError
    data = event.get("data", {})
    if isinstance(data, dict):
        message = data.get("message") or data.get("error") or "Streaming request failed."
    else:
        message = str(data) or "Streaming request failed."
    message = _mask_model_unavailable_error(message, model=model)
    raise NinethAPIError(message)


# ---------------------------------------------------------------------------
# SSE parser
# ---------------------------------------------------------------------------

def _parse_sse_lines(lines: Iterator[str]) -> Iterator[Dict[str, Any]]:
    event_type = "message"
    data_lines: list[str] = []

    for raw_line in lines:
        line = raw_line.rstrip("\r")
        if not line:
            if data_lines:
                payload = json.loads("\n".join(data_lines))
                payload.setdefault("type", event_type)
                yield payload
            event_type = "message"
            data_lines = []
            continue
        if line.startswith(":"):
            continue
        if line.startswith("event:"):
            event_type = line.split(":", 1)[1].strip()
            continue
        if line.startswith("data:"):
            data_lines.append(line.split(":", 1)[1].strip())

    if data_lines:
        payload = json.loads("\n".join(data_lines))
        payload.setdefault("type", event_type)
        yield payload


# ---------------------------------------------------------------------------
# Response trimming
# ---------------------------------------------------------------------------

_BUFFERED_KEEP = {
    "final_response", "iterations", "thinking",
    "service_calls", "service_responses", "artifacts", "usage", "events",
    "process_id",
}

_CALLBACK_KEEP = _BUFFERED_KEEP | {"status", "pending_client_calls"}

_CALLBACK_CONTROL_EVENTS = {"accepted", "awaiting_client_services", "result"}
_PUBLIC_STREAM_EVENT_TYPES = {"accepted", "awaiting_client_services", "error", "model_delta", "result"}


def _trim_response(body: Dict[str, Any], *, cache_enabled: bool = False) -> Dict[str, Any]:
    trimmed = {k: v for k, v in body.items() if k in _BUFFERED_KEEP}
    process_id = trimmed.pop("process_id", None)
    if cache_enabled and process_id:
        trimmed["session_id"] = process_id
    return trimmed


def _trim_callback_response(body: Dict[str, Any], *, cache_enabled: bool = False) -> Dict[str, Any]:
    trimmed = {k: v for k, v in body.items() if k in _CALLBACK_KEEP}
    process_id = trimmed.pop("process_id", None)
    if cache_enabled and process_id:
        trimmed["session_id"] = process_id
    elif process_id and body.get("status") == "awaiting_client_services":
        trimmed["process_id"] = process_id
    return trimmed


def _trim_event(event: Dict[str, Any], *, cache_enabled: bool = False) -> Optional[Dict[str, Any]]:
    if event.get("type") not in _PUBLIC_STREAM_EVENT_TYPES:
        return None

    trimmed = dict(event)
    if trimmed.get("type") == "model_delta":
        data = trimmed.get("data") if isinstance(trimmed.get("data"), dict) else {}
        text = data.get("text", "")
        if not isinstance(text, str) or not text:
            return None

    process_id = trimmed.pop("process_id", None)
    if process_id and event.get("type") in _CALLBACK_CONTROL_EVENTS:
        trimmed["process_id"] = process_id
        if cache_enabled:
            trimmed["session_id"] = process_id
    elif cache_enabled and process_id:
        trimmed["session_id"] = process_id
    return trimmed
