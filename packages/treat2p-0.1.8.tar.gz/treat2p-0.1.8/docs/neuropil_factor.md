---
icon: lucide/radical
---

# Neuropil Factor

::: treat2p.calculations.neuropil_factor_ARDSIP
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 2
        show_signature: false