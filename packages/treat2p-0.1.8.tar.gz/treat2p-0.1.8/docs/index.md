---
icon: lucide/rocket
---

# Getting started

Made to be used with [suite2p](https://pypi.org/project/suite2p/), to extend it's capabilities with treatment ones, on top of the nice roi signal extraction features of suite2p.

**Made following the matlab developments of [Pierre Marie Gardères](https://www.linkedin.com/in/pierre-marie-gard%C3%A8res-065ab5246/)**

## Installation

To install this package, you simply need to hop into your own virtual environment and run :

=== "pip"
    ```.sh
    pip install treat2p
    ```
=== "uv"
    ```.sh
    uv add treat2p
    ```

## How to use

In short, to treat some plane/channel data that suite2p extracted already:

```python
import treat2p
suite2p_path = r"C:\Users\yourname\Desktop\suite2p"
outputs, stats, ops = treat2p.run_treat2p(suite2p_path, plane = 0, chan = 1)
```

???+ note "`run_treat2p`"
    Takes all the arguments that goes into the various stages of the pipeline, registers, them, and stores them in the ``ops.npy`` file under the `treat2p` key. 


**The stages of treat2p pipeline are (for each roi):**

- [neuropil factor](neuropil_factor/#treat2p.calculations.neuropil_factor_ARDSIP) estimation (and correction)
- [slow trend](neuropil_factor/#treat2p.calculations.neuropil_factor_ARDSIP) estimation (and correction)
    - [deltaF/F0 normalization](normalization/#treat2p.normalisation.delta_over_F) normalisation or
    - ["mean centered"](normalization/#treat2p.normalisation.center_normalize) normalization

!!! tip "notebook tutorial"
    For a bit more explanations, please see the jupyter notebook tutorial [here](https://gitlab.pasteur.fr/haisslab/analysis-packages/treat2p/-/blob/main/treat2p_tuto.ipynb).
