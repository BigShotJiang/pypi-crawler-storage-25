---
icon: lucide/cpu
---

## Pipeline

::: treat2p.core.run_treat2p
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 3
        show_signature: false
        show_signature_annotations : false

::: treat2p.core.pipeline
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 3
        show_signature: false
        show_signature_annotations : false

## Figures

::: treat2p.plots.RoiFigure
    options:
        members:
        - save
        - this_function
        show_root_heading: true    
        show_source: false
        heading_level: 3
        show_signature: true
        show_signature_annotations : true

::: treat2p.plots.ArdsipFigure
    options:
        show_root_heading: true    
        show_source: false
        heading_level: 3
        show_signature: true
        show_signature_annotations : true