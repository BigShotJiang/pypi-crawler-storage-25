---
icon: lucide/land-plot
---


::: treat2p.normalisation.delta_over_F
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 2
        show_signature: false
        show_signature_annotations : false

::: treat2p.normalisation.center_normalize
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 2
        show_signature: false
        show_signature_annotations : false