---
icon: lucide/snail
---

# Slow Trend

::: treat2p.calculations.estimate_slow_trend
    options:
        show_root_heading: true    
        show_source: true
        heading_level: 2
        show_signature: false
        show_signature_annotations : false

!!! tip "combining options"
    You can combine ``filter_percentiles=True``,  ``filter_savgol=True``, ``filter_lowpass=True`` and ``fit=True``
    or any combination of them, and the result of each step will be used to process the next, in this exact order.