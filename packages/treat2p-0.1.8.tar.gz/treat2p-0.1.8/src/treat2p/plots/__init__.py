from dataclasses import dataclass
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from matplotlib import rc_context
import matplotlib.pyplot as plt
from pathlib import Path

from typing import Union


@dataclass
class ArdsipFigure:
    roi_number: int
    fig: Figure
    ax_raw: Axes
    ax_noactivity: Axes

    ax_neuropil_factors: Axes
    ax_iteraction_neuropil_factor: Axes

    ax_corrected: Axes
    ax_corrected_noactivity: Axes
    ax_low_perc: Axes
    ax_corr_norm: Axes
    ax_autocorr: Axes

    @staticmethod
    def from_roi_number(roi_number: int) -> "ArdsipFigure":
        fig, axes = plt.subplots(nrows=9, figsize=(10, 15))
        return ArdsipFigure(roi_number, fig, *axes)

    def __post_init__(self):
        self.fig.suptitle(f"Neuropil factor estimation of Roi n°{self.roi_number}")
        self.ax_raw.set_title("Raw traces")
        self.ax_noactivity.set_title("No-activity traces")
        self.ax_neuropil_factors.set_title("Neuropil factors over time (from autoregression trace)")
        self.ax_iteraction_neuropil_factor.set_title(
            "Neuropil values over iteractions (all other plot traces are from final iteration)"
        )
        self.ax_corrected.set_title("Neuropil corrected cell trace")
        self.ax_corrected_noactivity.set_title("Neuropil corrected cell trace (no activity)")
        self.ax_low_perc.set_title("Low percentiles of cell trace (baseline, from non-NaN trace above)")
        self.ax_corr_norm.set_title("Cell trace corrected by low percentiles and normalized")
        self.ax_autocorr.set_title("Lag autorcorrelated cell trace")

        self.ax_iteraction_neuropil_factor.set_ylim(-0.1, 1.1)

    @property
    def axes(self) -> list[Axes]:
        return [
            self.ax_raw,
            self.ax_noactivity,
            self.ax_neuropil_factors,
            self.ax_iteraction_neuropil_factor,
            self.ax_corrected,
            self.ax_corrected_noactivity,
            self.ax_low_perc,
            self.ax_corr_norm,
            self.ax_autocorr,
        ]

    def finalize(self):
        for ax in self.axes[:-1]:
            ax.set_xticks(())
        for ax in self.axes:
            ax.legend()

    def save(self, root_path: Union[str, Path]):

        extensions = ["svg", "png"]
        rcparams = {
            "image.composite_image": False,
            # https://github.com/matplotlib/matplotlib/issues/7151
            "font.family": ["sans-serif"],
            "font.sans-serif": ["Arial"],
            "text.usetex": False,
            "svg.fonttype": "none",
        }

        fullpath = str(Path(root_path) / f"treatp2_neuropil_factor.roi#{self.roi_number}")

        with rc_context(rcparams):
            for extension in extensions:
                self.fig.savefig(f"{fullpath}.{extension}")
        plt.close(self.fig)


@dataclass
class RoiFigure:
    roi_number: int
    fig: Figure
    raw_ax: Axes
    neu_corr_ax: Axes
    st_corr_ax: Axes
    df_ax: Axes
    norm_ax: Axes

    @staticmethod
    def from_roi_number(roi_number: int) -> "RoiFigure":
        fig, axes = plt.subplots(nrows=5, figsize=(10, 8))
        return RoiFigure(roi_number, fig, *axes)

    def __post_init__(self):
        self.fig.suptitle(f"Treat2p process of Roi n°{self.roi_number}")
        self.raw_ax.set_title("Raw trace")
        self.neu_corr_ax.set_title("Neuropil corrected trace")
        self.st_corr_ax.set_title("Slow trend corrected trace")
        self.df_ax.set_title("DF/F trace")
        self.norm_ax.set_title("Normalized trace")

    @property
    def ardsip_figure(self) -> ArdsipFigure:
        if not hasattr(self, "_ardsip_figure"):
            self._ardsip_figure = ArdsipFigure.from_roi_number(self.roi_number)
        return self._ardsip_figure

    @property
    def axes(self) -> list[Axes]:
        return [
            self.raw_ax,
            self.neu_corr_ax,
            self.st_corr_ax,
            self.df_ax,
            self.norm_ax,
        ]

    def finalize(self):
        for ax in self.axes[:-1]:
            ax.set_xticks(())
        for ax in self.axes:
            ax.legend()

    def save(self, root_path: Union[str, Path]):
        extensions = ["svg", "png"]
        rcparams = {
            "image.composite_image": False,
            # https://github.com/matplotlib/matplotlib/issues/7151
            "font.family": ["sans-serif"],
            "font.sans-serif": ["Arial"],
            "text.usetex": False,
            "svg.fonttype": "none",
        }

        fullpath = str(Path(root_path) / f"treatp2_treatment.roi#{self.roi_number}")

        with rc_context(rcparams):
            for extension in extensions:
                self.fig.savefig(f"{fullpath}.{extension}")
        plt.close(self.fig)

        if hasattr(self, "_ardsip_figure"):
            self.ardsip_figure.finalize()
            self.ardsip_figure.save(root_path)
