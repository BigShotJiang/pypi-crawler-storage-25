from treat2p.plots import RoiFigure
import numpy as np
from logging import getLogger
from scipy.signal import savgol_filter, filtfilt, butter
from scipy.signal.windows import boxcar
from .utils import filter_save_kwargs

from typing import Optional, Literal
### Main functions, used directly in correction


@filter_save_kwargs("F")
def estimate_slow_trend(
    F: np.ndarray,
    *,
    fps=30,  # samples per sec, in Hz
    # performed action arguments
    fit: Literal[False, "poly"] = False,
    filter_savgol: bool = False,
    filter_lowpass: bool = True,
    filter_percentiles: bool = True,
    # lower percentiles slow trend estimation arguments
    slow_trend_percentile: float = 10,
    percentiles_window: int = 120,  # in seconds
    percentiles_step: int = 10,
    # savgol filter slow trend estimation arguments
    savgol_window_length: int = 50,
    savgol_polyorder: int = 2,
    # lowpass filter slow trend estimation arguments
    lowpass_order: int = 3,
    lowpass_fcut: float = 0.0033,  # in Hz
    lowpass_method: Literal["gust", "pad"] = "gust",
    lowpass_irlen: Optional[int] = None,
    lowpass_padlen: Optional[int] = None,
    # polynomial fit slow trend estimation arguments
    polyfit_order: int = 2,
) -> np.ndarray:
    """Estimate the slow-varying trend of a 1D signal.

    This function computes a baseline (slow trend) for the input signal `F` by
    optionally applying a sequence of operations:

     1. a rolling lower-percentile estimator,
     2. Savitzky-Golay smoothing,
     3. a low-pass Butterworth filter, and
     4. an optional polynomial fit.

    The returned array is truncated to match the original length of `F`.

    Args:
        F: Input signal as a NumPy array (expected to be 1D). The slow trend is
            estimated from this signal.
        fps: Sampling rate of `F` in Hz (samples per second).
        fit: Optional final fitting step. If ``"poly"``, fits a polynomial of
            order `polyfit_order` to the estimated slow trend. If ``False``,
            no fitting is performed.
        filter_savgol: If True, apply a Savitzky-Golay filter to the current
            slow-trend estimate using `savgol_window_length` and
            `savgol_polyorder`.
        filter_lowpass: If True, apply a zero-phase low-pass Butterworth filter
            (via `scipy.signal.filtfilt`) using `lowpass_order` and
            `lowpass_fcut`.
        filter_percentiles: If True, estimate the slow trend using a rolling
            lower percentile over windows of length `percentiles_window`
            seconds.
        slow_trend_percentile: Percentile (0-100) used for the rolling
            percentile baseline estimate (e.g., 10 for the 10th percentile).
        percentiles_window: Window size (in seconds) used to compute the rolling
            percentile.
        percentiles_step: Step size (in samples) used to extend each computed
            percentile value. Each computed percentile is repeated
            `percentiles_step` times to form the baseline estimate.
        savgol_window_length: Window length (in samples) for the Savitzky-Golay
            filter. Must be a positive odd integer and less than or equal to the
            signal length (per SciPy requirements).
        savgol_polyorder: Polynomial order for the Savitzky-Golay filter.
        lowpass_order: Order of the Butterworth low-pass filter.
        lowpass_fcut: Cutoff frequency of the low-pass filter in Hz.
        lowpass_method: Filtering method passed to `scipy.signal.filtfilt`
            (e.g., ``"gust"`` or ``"pad"``).
        lowpass_irlen: Optional impulse response length passed to
            `scipy.signal.filtfilt` (used by some methods to improve speed).
        lowpass_padlen: Optional padding length passed to `scipy.signal.filtfilt`
            when padding is used.
        polyfit_order: Polynomial order used when `fit="poly"`.

    Returns:
        A NumPy array containing the estimated slow trend, with length equal to `len(F)`.

    Raises:
        ValueError: If filter parameters are invalid (e.g., invalid Savitzky-Golay
            settings, invalid cutoff frequency), as raised by underlying SciPy /
            NumPy functions.

    """

    slow_trend = F.copy()

    if filter_percentiles:
        _slow_trend = []
        frames_half_window = int((fps * percentiles_window) / 2)
        for i in range(0, len(F), 10):
            start = i - frames_half_window
            start = start if start >= 0 else 0
            stop = i + frames_half_window
            stop = stop if stop <= len(F) else len(F)

            value = np.percentile(F[start:stop], slow_trend_percentile)
            _slow_trend.extend([value for _ in range(percentiles_step)])
        slow_trend = np.asarray(_slow_trend)

    if filter_savgol:
        slow_trend = savgol_filter(slow_trend, window_length=savgol_window_length, polyorder=savgol_polyorder)

    if filter_lowpass:
        b, a = butter(lowpass_order, lowpass_fcut, btype="low", fs=fps, output="ba", analog=False)
        slow_trend = filtfilt(
            b,
            a,
            slow_trend,
            padlen=lowpass_padlen,
            padtype="odd",
            method=lowpass_method,
            irlen=lowpass_irlen,
            axis=0,
        )

    if fit:
        if fit == "poly":
            span = np.arange(0, len(slow_trend))
            poly = np.polyfit(span, slow_trend, polyfit_order)
            slow_trend = np.polyval(poly, span)

    return np.asarray(slow_trend)[0 : len(F)]


@filter_save_kwargs("F_Cell", "F_Neu")
def neuropil_factor_ARDSIP(
    F_Cell: np.ndarray,
    F_Neu: np.ndarray,
    *,
    fig: Optional[RoiFigure] = None,
    max_iterations: int = 10,
    long_window_length: float = 30,  # in seconds
    short_window_length: float = 3,
    baseline_percentile: float = 10,
    convergence_criteria: float = 0.025,
    autoregressed_activity_threshold: float = 0.5,
    initial_neuropil_factor: float = 0.5,
    downsampling: int = 4,  # factor
    zscoring_mid_percentile: float = 16,
    zscoring_low_percentile: float = 2.3,
    fps: float = 30,  # in hertz
) -> dict:
    """This function performs neuropil correction using an AutoRegressed DownSampling Iterative Process (A.R.DS.I.P).

    Args:
        F_Cell (numpy.ndarray): The array of fluorescence intensity for the cell.
        F_Neu (numpy.ndarray): The array of fluorescence intensity for the neuropil.
        max_iterations (int, optional): The maximum number of iterations to perform. Default is 10.
        long_window_length (int, optional): The length of the long sliding window. Default is 30.
        short_window_length (int, optional): The length of the short sliding window. Default is 3.
        baseline_percentile (float, optional): The percentile of the baseline fluorescence. Default is 10.
        convergence_criteria (float, optional): The criteria for convergence. Default is 0.025.
        autoregressed_activity_threshold (float, optional): The threshold for determining if there is activity in the
            cell based on autoregression. Default is 0.5.
        initial_neuropil_factor (float, optional): The initial neuropil factor. Default is 0.5.
        downsampling (float, optional): How much downsampled is the original aray when computing baseline.
            1 means no downsampling, 4 means 1 smple out of 4 is used.
            Higher values speedup the computation at fidelity cost. Default is 4.
        zscoring_mid_percentile (float, optional): Upper percentile used for zscoring. Default is 16.
        zscoring_low_percentile (float, optional): Lower percentile used for zscoring. Default is 2.3.
            Both of zscoring_mid_percentile and zscoring_low_percentile refer to z_score_from_percentile arguments.
            See that function for more details.

    Returns:
        dict: A dictionary containing :
            the calculated neuropil factor (float),
            the final neuropil factor after bounding to [0.1, 0.7] (float),
            a list of the neuropil factor across all iterations (list[float])
            a boolean indicating whether the function converged (bool).
    """

    F_Cell = np.asarray(F_Cell)
    F_Neu = np.asarray(F_Neu)

    # loop changing variable :
    neuropil_factor = initial_neuropil_factor
    local_log = getLogger("neuropil_factor_ardsip")
    local_log.debug("Starting Neuropil Refined Correction")
    iteration_results = [initial_neuropil_factor]
    converged = False

    iteration = 0
    activity_periods_mask = None

    if fig is not None:
        fig.ardsip_figure.ax_raw.plot(F_Cell, label="cell", lw=0.05)
        fig.ardsip_figure.ax_raw.plot(F_Neu, label="neuropil", lw=0.05)

    for iteration in range(max_iterations):
        local_log.debug(f"Starting new iteration with neuropil_factor : {neuropil_factor:.2f} ")
        F_Corrected = F_Cell - (neuropil_factor * F_Neu)
        new_neuropil_factors = []

        if iteration == 0:  # activity_periods_mask is None at that stage, and for further iterations,
            # it has an array shape like F_Corrected
            activity_periods_mask = np.zeros_like(F_Corrected, dtype=bool)

        F_Corrected_activity_removed = F_Corrected.copy()
        F_Corrected_activity_removed[activity_periods_mask] = np.nan
        # suppress periods of ROI activity , in the first iteration include all data
        # ( activity_periods_mask is redefined later)

        low_percentiles = sliding_window_percentile(
            F_Corrected_activity_removed,
            percentile=baseline_percentile,
            window_length=long_window_length,
            window_sample_displacement=downsampling,
            window_internal_downsampling=downsampling + 1,
            samples_per_sec=fps,
        )

        # why not using standard zscoring here >?
        F_Corrected_normalized = z_score_percentile(
            F_Corrected - low_percentiles,
            mid_percentile=zscoring_mid_percentile,
            low_percentile=zscoring_low_percentile,
        )

        F_Autocorr = lagged_autorcorrelation(F_Corrected_normalized)

        bool_no_activity = (F_Autocorr < autoregressed_activity_threshold) & (
            F_Autocorr > -autoregressed_activity_threshold
        )  # periods without activity
        bool_state_nochange = ~np.abs(np.diff(bool_no_activity.astype(int), prepend=False)).astype(
            bool
        )  # periods of changes between activity / non activity
        bool_stable_no_activity = (
            bool_no_activity & bool_state_nochange
        )  # stable periods without activity nor instantaneous changes

        F_Cell_noactivity = F_Cell.copy()
        F_Cell_noactivity[~bool_stable_no_activity] = np.nan

        F_Neu_noactivity = F_Neu.copy()
        F_Neu_noactivity[~bool_stable_no_activity] = np.nan

        if np.sum(bool_stable_no_activity) < 0.1 * len(bool_stable_no_activity):
            local_log.warning(
                "Non activity periods cannot realistically consist of less than 10% of all time. Skipping."
            )
            iteration_results.append(np.nan)
            neuropil_factor = neuropil_factor + convergence_criteria
            continue

        activity_periods_mask = ~bool_stable_no_activity  # activity periods are the inverse of no activity periods
        # we assign it here, only after the continue, in case detected "rest" periods were too few.

        # loop's final estimation of neuropil_factor
        short_window_indices = rolling_indices(
            F_Cell_noactivity,
            window_displacement=short_window_length,
            window_length=short_window_length,
            window_internal_downsampling=1,
            samples_per_sec=fps,
        )[0]

        F_Cell_windows = F_Cell_noactivity[short_window_indices]
        F_Neu_windows = F_Neu_noactivity[short_window_indices]

        for cell_chunk, neu_chunk in zip(F_Cell_windows, F_Neu_windows):
            non_nan_vec = ~np.isnan(cell_chunk)
            if sum(non_nan_vec) > 5:  # at least 6 non nan data points needed for regression
                new_neuropil_factors.append(np.polyfit(neu_chunk[non_nan_vec], cell_chunk[non_nan_vec], 1)[0])
            else:
                new_neuropil_factors.append(np.nan)
        new_neuropil_factors = np.array(new_neuropil_factors)
        local_log.debug(
            "Finished calculating chunks regressions with "
            f"{len(new_neuropil_factors[~np.isnan(new_neuropil_factors)])} valid chunks"
        )
        new_neuropil_factor_mean = float(np.nanmean(new_neuropil_factors))

        divergence = abs(neuropil_factor - new_neuropil_factor_mean)
        neuropil_factor = new_neuropil_factor_mean
        iteration_results.append(neuropil_factor)
        if divergence < convergence_criteria:
            local_log.info(
                f"Found convergence in {iteration + 1} iterations. Ending with neuropil_factor value : "
                f"{neuropil_factor:.2f} (last run divergence : {divergence:.3f})."
            )
            converged = True
            break

    if not converged:
        local_log.info(
            f"Found no convergence in {iteration + 1} iterations. "
            f"Ending with neuropil_factor value : {neuropil_factor:.2f}."
        )

    if neuropil_factor < 0.1:
        constrained_neuropil_factor = 0.1
    elif neuropil_factor > 0.7:
        constrained_neuropil_factor = 0.7
    else:
        constrained_neuropil_factor = neuropil_factor

    if fig is not None:
        fig.ardsip_figure.ax_noactivity.plot(F_Cell_noactivity, label="cell", lw=0.05)
        fig.ardsip_figure.ax_noactivity.plot(F_Neu_noactivity, label="neuropil", lw=0.05)
        fig.ardsip_figure.ax_corrected.plot(F_Corrected, label="cell_corrected", lw=0.05)
        fig.ardsip_figure.ax_corrected_noactivity.plot(
            F_Corrected_activity_removed, label="cell_corr_no_activity", lw=0.05
        )
        fig.ardsip_figure.ax_corr_norm.plot(F_Corrected_normalized, label="cell_corr_normalized", lw=0.05)
        fig.ardsip_figure.ax_low_perc.plot(low_percentiles, label="cell_low_perc", lw=0.05)
        fig.ardsip_figure.ax_autocorr.plot(F_Autocorr, label="cell_lag_autocorrelation", lw=0.05)
        fig.ardsip_figure.ax_autocorr.axhline(
            autoregressed_activity_threshold, label="activity_threshold", ls="--", color="gray"
        )
        fig.ardsip_figure.ax_autocorr.axhline(-autoregressed_activity_threshold, ls="--", color="gray")
        bool_no_activity = bool_no_activity.astype(float)
        bool_state_nochange = bool_state_nochange.astype(float)
        bool_stable_no_activity = bool_stable_no_activity.astype(float)
        bool_no_activity[bool_no_activity < 1] = np.nan
        bool_state_nochange[bool_state_nochange < 1] = np.nan
        bool_stable_no_activity[bool_stable_no_activity < 1] = np.nan
        fig.ardsip_figure.ax_autocorr.plot(bool_no_activity, label="no_activity_periods")
        fig.ardsip_figure.ax_autocorr.plot(bool_state_nochange * 2, label="no_change_periods")
        fig.ardsip_figure.ax_autocorr.plot(bool_stable_no_activity * 3, label="stable_no_activity_periods")

        fig.ardsip_figure.ax_neuropil_factors.plot(new_neuropil_factors, label="neuropil_factor_over_time", lw=0.05)

        fig.ardsip_figure.ax_iteraction_neuropil_factor.plot(
            iteration_results, "o-", label="neuropil_factor_over_iterations"
        )
        fig.ardsip_figure.ax_iteraction_neuropil_factor.plot(
            len(iteration_results), constrained_neuropil_factor, "o", label="final_neu_factor"
        )

        fig.ardsip_figure.ax_corrected.text(
            0.2,
            0.5,
            f"neu_factor={neuropil_factor}",
            transform=fig.ardsip_figure.ax_corrected.transAxes,
            ha="left",
            va="center",
        )

    return {
        "neuropil_factor": neuropil_factor,
        "neuropil_factor_constrained": constrained_neuropil_factor,
        "neuropil_factor_iterations": iteration_results,
        "neuropil_factor_converged": converged,
    }


### Helper functions made to make life easy / enhance speed of above calculations


def rolling_indices(
    array,
    *,
    window_displacement=None,  # how much each window moves from the next one, in seconds units.
    # Results in general downsampling from initial array length
    # after collapsing windows to one number by merging operations such as averaging etc.
    window_length=30,  # in seconds units
    samples_per_sec=30,
    window_internal_downsampling=4,  # if more than one, downsample INSIDE a window. In index units
    window_sample_length=None,  # same as window_length but in sample index units instead of seconds.
    # will skip window_length value if used.
    window_sample_displacement=4,  # same as window_displacement but in sample index units.
    # will skip window_displacement value is used
):
    """
    Specifies the indices in an input 'array' over which rolling windows are defined.
    The indices can be used later to easily and efficiently create such windows with vanilla numpy slicing
    (leveraging SIMD).
    The resulting windows can have optional downsampling and are defined by their length and displacement.

    Args:
        array (numpy.ndarray): Input array over which rolling windows are to be calculated.
        window_displacement (int, optional): Defines how much each window moves from the next one. Defaults to None.
        window_length (int, optional): Defines the desired window length in seconds. Defaults to 30.
        samples_per_sec (int, optional): Defines the number of samples per second in the array. Defaults to 30.
        window_internal_downsampling (int, optional): If more than one, downsample within window. Defaults to 4.
        window_sample_length (int, optional): Same as window_length but in sample indices instead of seconds.
            Will skip window_length value if used. Defaults to None.
        window_sample_displacement (int, optional): Same as window_displacement but in seconds instead of sample points.
            Will skip window_displacement value if used. Defaults to 4.

    Returns:
        tuple: Tuple containing numpy.ndarray of rolling window indices and numpy.ndarray
               of indices central to each window.
    """

    if window_sample_length is None:
        window_sample_length = round(window_length * samples_per_sec)
    else:
        window_sample_length = round(window_sample_length)
    if window_sample_displacement is None:
        if window_displacement is None:
            raise ValueError("window_displacement cannot be None if window_sample_displacement is None.")
        window_sample_displacement = round(window_displacement * samples_per_sec)
    else:
        window_sample_displacement = round(window_sample_displacement)
    half_window_length = round(window_sample_length / 2)
    windows_indices = []
    indices = []
    for i in range(0, len(array) - window_sample_length, window_sample_displacement):
        window = np.array(range(i, i + window_sample_length, window_internal_downsampling), dtype=int)
        windows_indices.append(window)
        indices.append(i + half_window_length)
    return np.array(windows_indices), np.array(indices)


def sliding_window_percentile(input_array: np.ndarray, percentile: float = 10, **rolling_kwargs) -> np.ndarray:
    """This function applies sliding window computation on an input data array, computing a user-specified percentile
    within each window.
    It uses the 'rolling_indices' to generate windows in the input data. For each generated window,
    it computes the specified percentile and assigns this value to the representative sample for the window.
    For samples not directly represented by a window, the function interpolates the percentile values.

    Args:
        input_array (numpy.ndarray): The array on which sliding window computation is to be performed.
        percentile (int, optional): The percentile to be computed within each window. Defaults to 10.
        **kwargs: Additional keyword arguments to passed to the 'rolling_indices' function.

    Returns:
        numpy.ndarray : Array filled with the computed percentile values for each window,
            with the same shape as 'input_array'.
            For positions between windows, the percentile values are interpolated."""

    long_windows_indices, downsampled_indices = rolling_indices(input_array, **rolling_kwargs)

    input_array_long_windows = input_array[long_windows_indices]

    low_percentiles = np.nanpercentile(input_array_long_windows, percentile, axis=1)

    x_indices = np.arange(len(input_array))
    interped_indices = np.setdiff1d(x_indices[downsampled_indices[0] : downsampled_indices[-1]], downsampled_indices)
    interped_values = np.interp(interped_indices, downsampled_indices, low_percentiles)

    interped_low_percentiles = np.full_like(input_array, np.nan, dtype=float)
    interped_low_percentiles[downsampled_indices] = low_percentiles
    interped_low_percentiles[interped_indices] = interped_values
    return interped_low_percentiles


def lagged_autorcorrelation(input_array: np.ndarray, lag=1, boxcar_width=3) -> np.ndarray:
    """
    This function performs autoregression on a given data array by applying boxcar filtering first to the array and
    then to a copy of the array rolled by a certain lag. The results of these filterings
    are then multiplied elementwise.
    Need to explain the choice of values for this weird zscoring. Why not using standard zscoring ?

    Args:
        input_array (numpy.ndarray): The array on which to perform autoregression.
        lag (int, optional): The size of the shift applied to the input array for the 'rolled' boxcar filtering.
        Default is 1.
        boxcar_value (int, optional): The width of the boxcar window to be applied. Default is 3.

    Returns:
        numpy.ndarray: The array of the resulting autoregressed values. It has the same shape as the input array.
    """
    prefilter = boxcar_filtering(input_array, boxcar_width=boxcar_width) / 2
    postfilter = boxcar_filtering(np.roll(input_array, -lag), boxcar_width=boxcar_width) / 2
    autoregressed = prefilter * postfilter
    return autoregressed


def boxcar_filtering(x: np.ndarray, boxcar_width=3) -> np.ndarray:
    """Applies boxcar filtering on the input data.

    Args:
        x (np.array): The input data for which the boxcar filtering needs to be performed.
        boxcar_value (int, optional): The width of the boxcar window. Defaults to 3.

    Returns:
        np.array: The output data after applying the boxcar filtering.
    """
    filter_window = boxcar(boxcar_width)
    return filtfilt(filter_window / sum(filter_window), [1.0], x)


def z_score_percentile(input_array, mid_percentile=16, low_percentile=2.3):
    """
    This function performs zscore normalization on an array, using a percentile based mean and sigma values.
    Such that : output = (input - mean) / sigma
        where sigma = mid_percentile - low_percentile
        and   mean = low_percentile + (2 * sigma)

    Args:
        input_array (numpy.ndarray): The array on which to perform zscore normalization.
        mid_percentile (float, optional): The percentile (from 0 to 100) that will be used for "mid" estimates.
        Default is 16.
        low_percentile (float, optional): The percentile (from 0 to 100) that will be used for "low" estimates.
        Default is 2.3.

    Returns:
        numpy.ndarray: The array of the resulting normalization. It has the same shape as the input array.
    """
    local_log = getLogger("zscore_percentile")
    low_percentile_value = np.nanpercentile(input_array, low_percentile)
    mid_percentile_value = np.nanpercentile(input_array, mid_percentile)
    percentile_based_sigma = mid_percentile_value - low_percentile_value
    percentile_based_mean = low_percentile_value + (
        2 * percentile_based_sigma
    )  # why this weird calculation and not simply np.nanpercentile(input_array, 50) as a median ?
    local_log.debug(
        f"Percentile 'mean' is : {percentile_based_mean}, real median is : {np.nanpercentile(input_array, 50)}"
    )
    local_log.debug(f"Percentile based 'sigma' is : {percentile_based_sigma}, real std is : {np.nanstd(input_array)}")

    return (input_array - percentile_based_mean) / percentile_based_sigma
