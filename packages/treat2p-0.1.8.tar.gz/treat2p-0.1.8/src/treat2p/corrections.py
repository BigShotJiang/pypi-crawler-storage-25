from .calculations import estimate_slow_trend, neuropil_factor_ARDSIP
import numpy as np
from .plots import RoiFigure
from typing import Optional, Literal


def slow_trend(F: np.ndarray, *, fig: Optional[RoiFigure] = None, **slow_trend_kwargs) -> np.ndarray:
    """_summary_

    Args:
        F (_type_): _description_

    Returns:
        _type_: _description_
    """
    slow_F = estimate_slow_trend(F, **slow_trend_kwargs)
    slow_trend_corrected = F - slow_F
    if fig is not None:
        fig.neu_corr_ax.plot(slow_F, label="slow_trend_estimation")
        fig.st_corr_ax.plot(slow_trend_corrected, label="slow_trend_corrected", lw=0.05)
    return slow_trend_corrected


def neuropil(
    F: np.ndarray,
    Fneu: np.ndarray,
    *,
    neuropil_correction_factor: Optional[float] = None,
    factor_to_use: Literal["neuropil_factor_constrained", "neuropil_factor"] = "neuropil_factor_constrained",
    fig: Optional[RoiFigure] = None,
    **ardsip_kwargs,
) -> tuple[np.ndarray, dict]:
    """Performs correction of F with neuropil signal Fneu with a substraction factor neuropil_correction_factor.
    (Fcorr = F - (Fneu * neuropil_correction_factor) )
    If no neuropil correction factor is supplied, it is determined from F and Fneu with the ARDSIP algorithm.

    Args:
        F (array_like): Raw neuron's fluoresence
        Fneu (array_like): Raw neuron's neuropil (neighbouring region excluding other neurons) fluoresence
        neuropil_correction_factor (float, optional): _description_. Defaults to None.
        factor_to_use (str, optional): _description_. Defaults to "neuropil_factor_constrained".

    Returns:
        array_like: Corrected fluorescence
    """
    stats = {}
    if neuropil_correction_factor is None:
        stats = neuropil_factor_ARDSIP(F, Fneu, fig=fig, **ardsip_kwargs)
        neuropil_correction_factor = stats[factor_to_use]
    F = np.asarray(F, dtype=np.float64)
    Fneu = np.array(Fneu, dtype=np.float64)
    Fcorr = F - (Fneu * neuropil_correction_factor)
    if fig is not None:
        fig.neu_corr_ax.text(
            0.2,
            0.5,
            f"neu_factor={neuropil_correction_factor}",
            transform=fig.neu_corr_ax.transAxes,
            ha="left",
            va="center",
        )
        fig.neu_corr_ax.plot(Fcorr, label="neuropil_corrected", lw=0.05)
    return Fcorr, stats
