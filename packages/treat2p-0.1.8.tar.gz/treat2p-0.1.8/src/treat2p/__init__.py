__version__ = "0.1.8"

__all__ = ["run_treat2p", "pipeline", "calculations", "corrections", "utils", "normalisation"]

from .core import run_treat2p, pipeline
from . import calculations, corrections, utils, normalisation
