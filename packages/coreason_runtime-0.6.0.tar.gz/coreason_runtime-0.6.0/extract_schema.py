import json

from coreason_manifest.spec.ontology import CapabilityForgeTopologyManifest

with open("schema.json", "w") as f:
    json.dump(CapabilityForgeTopologyManifest.model_json_schema(), f, indent=2)
