import os

directories = ["src/coreason_runtime", "tests", "docs"]
files_to_process = ["AGENTS.md", "README.md"]


def replace_terms(content: str) -> str:
    # Tool -> Actuator (kinetic) or Oracle (data). For simplicity, we use Actuator for 'tool_name', 'target_tool_name'
    content = content.replace("tool_name", "actuator_name")
    content = content.replace("target_tool_name", "target_actuator_name")
    content = content.replace("ExecuteMCPToolIOActivity", "ExecuteMCPActuatorIOActivity")
    content = content.replace("tool_query", "actuator_query")
    content = content.replace("tool_arguments", "actuator_arguments")
    content = content.replace("tool_history", "actuator_history")
    content = content.replace("Target_tool_name", "target_actuator_name")
    content = content.replace("target_tool", "target_actuator")

    # Agent -> Epistemic Node / Cognitive Entity
    content = content.replace("AgentResponse", "EpistemicNodeResponse")
    content = content.replace("AutonomousAgentResponse", "AutonomousEpistemicNodeResponse")
    content = content.replace("agent_profile", "epistemic_node_profile")
    content = content.replace("agent_name", "epistemic_node_name")
    content = content.replace("AGENT INSTRUCTION", "EPISTEMIC NODE INSTRUCTION")

    # schema_payload, role_description
    content = content.replace("schema_payload", "geometric_schema")
    return content.replace("role_description", "cognitive_boundary_directive")


for d in directories:
    if os.path.isdir(d):
        for root, _, files in os.walk(d):
            base_dir = os.path.basename(root)
            if base_dir == "__pycache__":
                continue
            files_to_process.extend(os.path.join(root, f) for f in files if f.endswith((".py", ".md")))

for f in set(files_to_process):
    if os.path.isfile(f):
        with open(f, encoding="utf-8") as file:
            content = file.read()

        new_content = replace_terms(content)
        if new_content != content:
            with open(f, "w", encoding="utf-8") as file:
                file.write(new_content)
            print(f"Updated {f}")
