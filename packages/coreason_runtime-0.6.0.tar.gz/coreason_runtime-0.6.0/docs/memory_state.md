# Memory & Epistemic State Management

The `coreason-runtime` manages episodic events, trace contexts, and capability telemetry through a high-throughput, Arrow-native Medallion Architecture. This system ensures that the continuous generative output of multi-agent topologies is deterministically unified, indexed, and stored without starving the asynchronous execution plane.

---

## 1. The Medallion Data Pipeline

Telemetry and state transitions flow through three distinct epistemic layers:

1. **Bronze Layer (Raw Ingestion):** High-velocity Server-Sent Events (SSE) and raw JSON-RPC logs are captured continuously. The `ContinuousStreamBuffer` manages memory backpressure using a probabilistic forget-gate driven by strict spatial SHA-1 hashing, ensuring zero distributed CRDT state forks during load shedding.
2. **Silver Layer (Entity Resolution):** The `PolarsSilverGate` cleanses, normalizes, and assigns deterministic cryptographic identities to all events.
3. **Gold Layer (Latent Aggregation):** Unified traces are structured into capability metrics, topological usage graphs, and long-term sovereign memory.

---

## 2. High-Velocity ETL (The Silver Gate)

To unblock the `uvloop` async reactor during massive burst-ingestion scenarios, the Silver Layer entity resolution pipeline operates entirely outside the Python Global Interpreter Lock (GIL) using Apache Arrow and Polars.

### GIL Eradication & Vectorization
The runtime adheres to a strict "Borrow Over Build" mandate for cryptographic operations. Rather than utilizing slow, scalar Python `for` loops or maintaining custom Rust `pyo3-polars` extensions, the pipeline leverages the `polars-hash` namespace.
* Cryptographic hashing is executed natively in Rust across contiguous Arrow memory arrays.
* The Python GIL is entirely bypassed during massive parallel data transformations.

### Vectorized Cryptographic Forgery (UUIDv5)
The Silver Gate generates deterministic identities (`entity_uuid`) based on composite natural keys (e.g., `intent_id` + `workflow_id`). To satisfy strict downstream schema requirements (RFC 4122 UUIDv5) without sacrificing SIMD throughput:
1. The pipeline generates an `$O(1)` vectorized SHA-1 digest over the CoReason namespace and the composite key.
2. It utilizes vectorized regex substitution to mathematically inject the required **Version (5)** and **Variant (8)** bitmasks into the raw hash string.
3. The result is a mathematically perfect, schema-compliant UUIDv5 generated at maximum hardware memory bandwidth.

### Shuffle-Invariant Idempotence
The Silver Layer guarantees strict mathematical idempotence. Extensive property-based fuzzing ensures that regardless of network jitter, micro-batch chunk sizing, or the arrival order of out-of-sequence events, the generated `entity_uuid` outputs remain 100% identical and deterministic.

---

## 3. Sovereign Storage & Fallback (LanceDB)

While the runtime relies on the `coreason-ecosystem` for global URN resolution, it maintains a localized sovereign memory matrix using **LanceDB**.

* **Latent Memory:** Agent embeddings, episodic RAG documents, and execution traces are persisted locally in LanceDB, enabling `$O(1)` memory retrieval during rapid workflow rehydration.
* **Network Partition Resilience:** If the `EcosystemRegistryClient` fails to reach the global capability registry during a Master MCP publication (Epistemic Crystallization), the runtime gracefully falls back to logging the `EpistemicPromotionEvent` directly into the LanceDB sovereign store, ensuring zero data loss during network degradation.
