# CoReason Runtime Knowledge Base

Welcome to the **CoReason Runtime** (`coreason-runtime`) Knowledge Base. This repository operates as the strictly bound **Tier-1 Kinetic Execution Engine** within the CoReason Tripartite Doctrine.

*If `coreason-manifest` is the blueprint, `coreason-runtime` is the biological cell physically executing it.*

---

## The Architectural Matrix

The documentation is structurally segregated to match the strict computational boundaries enforced by the orchestrator. For complete architectural mastery, read the documents sequentially:

### 1. [The Philosophy of Bounded Execution](architecture.md)
The gateway document for system architects. Understand how `coreason-runtime` enforces mathematical boundaries using Finite State Machines and Zero-Trust networks, eradicating legacy flat-loop LLM vulnerabilities.
* **Key Concept:** The Multi-Endpoint Cognitive Router and Bounded Execution.

### 2. [Kinetic Capabilities & WASM Hypervisors](capabilities.md)
The physical rulebook for tools. Understand how topological memory caging limits payloads to exactly 3.27 MB and how WebAssembly intercepts OS-level traps to ensure absolute worker invulnerability.
* **Key Concept:** The Linear Lattice and Virtual File Descriptors.

### 3. [The Universal Asset Forge & Epistemic Purity](../AGENTS.md)
The core laws bounding autonomous file execution. **The runtime cannot build.** Read this protocol to map exactly how `coreason-runtime` proposes intents across the Model Context Protocol (MCP) to the `coreason-meta-engineering` capability forge.
* **Key Concept:** The Bipartite Proposer-Verifier Loop and File I/O Guillotine.

### 4. [Tensor Routing Protocol](tensor_routing.md)
Deep dive into Phase-1 generation. How SGLang, Outlines, and our AST validation matrix execute deterministic Speculative Logit Suffocation to force output schemas.
* **Key Concept:** $O(1)$ Rehydration and Token Compression.

### 5. [The Oracle Circuit (HITL)](oracle_circuit.md)
The cybernetic bridge back to human supervisors. When uncertainty bounds exceed standard thresholds, the Swarm suspends state mathematically.
* **Key Concept:** Variational Free Energy and Yield Constraints.

---

## System Development Axioms

1. **Zero-Trust is Literal:** Assume the LLM will generate catastrophic code.
2. **Deterministic Over Heuristic:** Traceability equals capability. Memory runs strictly on the Merkle Graph.
3. **Delegation is Safety:** Any macroscopic code modifications MUST flow to `coreason-meta-engineering`.

*For detailed CLI operation and testing matrices, please see the root [README.md](../README.md).*
