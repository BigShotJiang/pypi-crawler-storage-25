# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import hashlib
from typing import Any

from coreason_manifest import WetwareAttestationContract

from coreason_runtime.utils.security import (
    compute_homomorphic_cosine_similarity,
    generate_canonical_hash,
    verify_wetware_attestation,
    verify_zk_proof,
)


def test_generate_canonical_hash_ordering() -> None:
    """Verify lexicographical key sorting for canonical hashing."""
    dict1 = {"b": 2, "a": 1}
    dict2 = {"a": 1, "b": 2}

    assert generate_canonical_hash(dict1) == generate_canonical_hash(dict2)


def test_generate_canonical_hash_floats() -> None:
    """Verify float normalization rules for canonical hashing."""
    dict1 = {"v": 1.0}
    dict2 = {"v": 1}

    assert generate_canonical_hash(dict1) == generate_canonical_hash(dict2)

    dict3 = {"v": 100000000000000000000.0}
    dict4 = {"v": 1e20}

    assert generate_canonical_hash(dict3) == generate_canonical_hash(dict4)


def test_generate_canonical_hash_whitespace() -> None:
    """Verify elimination of whitespace between structural characters."""
    dict1 = {"a": [1, 2, 3], "b": {"c": 4, "d": 5}}

    # Hand-calculate expected canonical JSON
    expected_str = '{"a":[1,2,3],"b":{"c":4,"d":5}}'
    expected_hash = hashlib.sha256(expected_str.encode("utf-8")).hexdigest()

    assert generate_canonical_hash(dict1) == expected_hash


def test_generate_canonical_hash_complex() -> None:
    """Test complex dictionary structures to ensure all rules apply recursively."""
    payload: dict[str, Any] = {"user_id": "123456", "nested": {"z": 1.5e-5, "a": "text", "c": [True, False, None, 0.0]}}

    # Expected canonicalization:
    # "0.0" -> "0"
    # "1.5e-5" -> "1.5E-5"
    # Keys get sorted
    expected_str = '{"nested":{"a":"text","c":[true,false,null,0],"z":1.5E-5},"user_id":"123456"}'
    expected_hash = hashlib.sha256(expected_str.encode("utf-8")).hexdigest()

    assert generate_canonical_hash(payload) == expected_hash


def test_verify_zk_proof_exception() -> None:
    # Trigger TypeError on len() to hit the exception block
    assert verify_zk_proof(12345) is False  # type: ignore[arg-type]


def test_compute_homomorphic_cosine_similarity_bounds() -> None:
    # Trigger zero norm
    assert compute_homomorphic_cosine_similarity(b"\x00" * 30, b"\x00" * 30) == 0.0  # type: ignore[arg-type]

    # Trigger exception (invalid base64 decode for short strings)
    # Wait, if less than 20 it just encodes. Let's pass an int to trigger exception on len().
    assert compute_homomorphic_cosine_similarity(12345, 12345) == 0.0  # type: ignore[arg-type]


def test_verify_wetware_attestation_errors() -> None:
    attestation = WetwareAttestationContract.model_construct(
        mechanism="webauthn",
        did_subject="did:coreason:admin",
        liveness_challenge_hash="abcd",
        dag_node_nonce="12345",
        cryptographic_payload="not_valid_base_64",
    )
    # Trigger json loads exception after base64 decode
    assert verify_wetware_attestation(attestation) is False
