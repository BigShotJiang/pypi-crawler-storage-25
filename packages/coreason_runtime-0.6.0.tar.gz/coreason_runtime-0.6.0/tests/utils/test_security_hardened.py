# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for security utilities.

Tests: generate_canonical_hash (RFC 8785), resolve_did_public_key,
compute_homomorphic_cosine_similarity, verify_zk_proof, DataRedactor,
verify_wetware_attestation decode failure.

All tests use physically instantiated values — zero unittest.mock.
"""

import pytest

from coreason_runtime.utils.security import (
    DataRedactor,
    compute_homomorphic_cosine_similarity,
    generate_canonical_hash,
    resolve_did_public_key,
    verify_zk_proof,
)

# ── generate_canonical_hash (RFC 8785) Tests ──────────────────────────


class TestGenerateCanonicalHash:
    """Physical tests for RFC 8785 canonical JSON hashing."""

    def test_simple_dict_deterministic(self) -> None:
        """Same dict always produces same hash."""
        payload = {"b": 2, "a": 1}
        h1 = generate_canonical_hash(payload)
        h2 = generate_canonical_hash(payload)
        assert h1 == h2
        assert len(h1) == 64

    def test_key_order_independent(self) -> None:
        """Different key insertion order produces same hash."""
        h1 = generate_canonical_hash({"z": 1, "a": 2})
        h2 = generate_canonical_hash({"a": 2, "z": 1})
        assert h1 == h2

    def test_null_value(self) -> None:
        """None values serialize to 'null'."""
        h = generate_canonical_hash({"key": None})
        assert len(h) == 64

    def test_boolean_values(self) -> None:
        """Booleans serialize correctly."""
        h_true = generate_canonical_hash({"flag": True})
        h_false = generate_canonical_hash({"flag": False})
        assert h_true != h_false

    def test_integer_values(self) -> None:
        """Integers serialize as strings."""
        h = generate_canonical_hash({"count": 42})
        assert len(h) == 64

    def test_float_zero(self) -> None:
        """Float 0.0 serializes to '0'."""
        h = generate_canonical_hash({"val": 0.0})
        assert len(h) == 64

    def test_float_integer_value(self) -> None:
        """Float with integer value (e.g. 5.0) serializes as int."""
        h = generate_canonical_hash({"val": 5.0})
        assert len(h) == 64

    def test_float_nan_serializes_as_null(self) -> None:
        """NaN serializes as 'null'."""
        h = generate_canonical_hash({"val": float("nan")})
        h_null = generate_canonical_hash({"val": None})
        assert h == h_null

    def test_float_inf_serializes_as_null(self) -> None:
        """Infinity serializes as 'null'."""
        h = generate_canonical_hash({"val": float("inf")})
        h_null = generate_canonical_hash({"val": None})
        assert h == h_null

    def test_string_values(self) -> None:
        """Strings are properly JSON-encoded."""
        h = generate_canonical_hash({"msg": "hello world"})
        assert len(h) == 64

    def test_list_values(self) -> None:
        """Lists serialize correctly."""
        h = generate_canonical_hash({"items": [1, "two", None]})
        assert len(h) == 64

    def test_nested_dict(self) -> None:
        """Nested dicts are recursively canonicalized."""
        h = generate_canonical_hash({"outer": {"inner_b": 2, "inner_a": 1}})
        assert len(h) == 64

    def test_unsupported_type_raises(self) -> None:
        """Unsupported types raise TypeError."""
        with pytest.raises(TypeError, match="not canonical serializable"):
            generate_canonical_hash({"obj": object()})

    def test_exponential_float(self) -> None:
        """Very small floats with exponential notation."""
        h = generate_canonical_hash({"val": 1e-10})
        assert len(h) == 64


# ── resolve_did_public_key Tests ──────────────────────────────────────


class TestResolveDIDPublicKey:
    """Physical tests for DID public key resolution."""

    def test_did_key_prefix(self) -> None:
        """did:key: prefix is stripped (8 chars)."""
        result = resolve_did_public_key("did:key:z6MkpTHR")
        assert result == b"z6MkpTHR"

    def test_did_coreason_prefix(self) -> None:
        """did:coreason: prefix is stripped (13 chars)."""
        result = resolve_did_public_key("did:coreason:agent-001")
        assert result == b"agent-001"

    def test_generic_did(self) -> None:
        """Generic DID returns full encoded bytes."""
        result = resolve_did_public_key("did:web:example.com")
        assert result == b"did:web:example.com"


# ── compute_homomorphic_cosine_similarity Tests ───────────────────────


class TestHomomorphicCosineSimilarity:
    """Physical tests for FHE cosine similarity approximation."""

    def test_identical_short_strings(self) -> None:
        """Identical short strings have similarity 1.0."""
        sim = compute_homomorphic_cosine_similarity("hello", "hello")
        assert sim == pytest.approx(1.0, abs=1e-5)

    def test_orthogonal_bytes(self) -> None:
        """Completely different bytes have low similarity."""
        sim = compute_homomorphic_cosine_similarity("aaaa", "zzzz")
        assert 0.0 <= sim <= 1.0

    def test_empty_string_returns_zero(self) -> None:
        """Empty string returns 0.0."""
        sim = compute_homomorphic_cosine_similarity("", "hello")
        assert sim == 0.0

    def test_both_empty_returns_zero(self) -> None:
        """Both empty returns 0.0."""
        sim = compute_homomorphic_cosine_similarity("", "")
        assert sim == 0.0


# ── verify_zk_proof Tests ─────────────────────────────────────────────


class TestVerifyZkProof:
    """Physical tests for zero-knowledge proof structural validation."""

    def test_valid_long_proof(self) -> None:
        """Proof longer than 32 chars passes."""
        assert verify_zk_proof("a" * 33) is True

    def test_short_proof_fails(self) -> None:
        """Proof <= 32 chars fails."""
        assert verify_zk_proof("a" * 32) is False

    def test_empty_proof_fails(self) -> None:
        """Empty proof fails."""
        assert verify_zk_proof("") is False


# ── DataRedactor Tests ────────────────────────────────────────────────


class TestDataRedactor:
    """Physical tests for zero-trust PHI/secret redaction."""

    def test_redact_ssn(self) -> None:
        """SSN pattern is redacted."""
        result = DataRedactor.redact_text("Patient SSN: 123-45-6789")
        assert "[PHI_REDACTED]" in result
        assert "123-45-6789" not in result

    def test_redact_mrn(self) -> None:
        """MRN pattern is redacted."""
        result = DataRedactor.redact_text("Record MRN00123456 found")
        assert "[PHI_REDACTED]" in result

    def test_redact_date(self) -> None:
        """Date pattern is redacted."""
        result = DataRedactor.redact_text("DOB: 01/15/1990")
        assert "[PHI_REDACTED]" in result

    def test_redact_bearer_token(self) -> None:
        """Bearer token is redacted."""
        result = DataRedactor.redact_text("Auth: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")
        assert "[SECRET_REDACTED]" in result

    def test_redact_api_key(self) -> None:
        """API key pattern with sk_ prefix and 20+ chars is redacted."""
        result = DataRedactor.redact_text("Key: sk_abcdefghijklmnopqrstuvwx")
        assert "[SECRET_REDACTED]" in result

    def test_redact_hex_address(self) -> None:
        """Hex address is redacted."""
        result = DataRedactor.redact_text("Wallet: 0xABCDEF1234567890")
        assert "[SECRET_REDACTED]" in result

    def test_redact_nested_dict(self) -> None:
        """Nested dicts are recursively redacted."""
        data = {"patient": {"ssn": "123-45-6789", "name": "John"}}
        result = DataRedactor.redact_dict(data)
        assert "[PHI_REDACTED]" in result["patient"]["ssn"]
        assert result["patient"]["name"] == "John"

    def test_redact_dict_with_list(self) -> None:
        """Lists inside dicts are redacted."""
        data = {"records": ["SSN: 123-45-6789", "Name: John"]}
        result = DataRedactor.redact_dict(data)
        assert "[PHI_REDACTED]" in result["records"][0]

    def test_clean_text_unchanged(self) -> None:
        """Text without patterns passes through unchanged."""
        result = DataRedactor.redact_text("Hello World")
        assert result == "Hello World"
