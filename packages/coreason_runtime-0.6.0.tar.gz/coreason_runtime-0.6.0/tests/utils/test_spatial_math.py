# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for spatial_math utilities.

Covers: vector_isometry, validate_normalized_vector,
mock_verify_hardware_signature, intersect_ray_with_nodes.

All tests use physically instantiated values — zero unittest.mock.
"""

import base64
import math

import pytest

from coreason_runtime.utils.spatial_math import (
    intersect_ray_with_nodes,
    mock_verify_hardware_signature,
    validate_normalized_vector,
    vector_isometry,
)

# ── vector_isometry Tests ─────────────────────────────────────────────


class TestVectorIsometry:
    """Physical tests for cosine similarity computation."""

    def test_identical_vectors(self) -> None:
        """Identical vectors have isometry 1.0."""
        assert vector_isometry([1.0, 0.0, 0.0], [1.0, 0.0, 0.0]) == pytest.approx(1.0)

    def test_orthogonal_vectors(self) -> None:
        """Orthogonal vectors have isometry 0.0."""
        assert vector_isometry([1.0, 0.0], [0.0, 1.0]) == pytest.approx(0.0)

    def test_opposite_vectors_clamped(self) -> None:
        """Opposite vectors are clamped to 0.0."""
        assert vector_isometry([1.0, 0.0], [-1.0, 0.0]) == pytest.approx(0.0)

    def test_empty_vectors_return_zero(self) -> None:
        """Empty vectors return 0.0."""
        assert vector_isometry([], []) == 0.0

    def test_mismatched_dimensions(self) -> None:
        """Mismatched dimensions return 0.0."""
        assert vector_isometry([1.0], [1.0, 2.0]) == 0.0

    def test_zero_magnitude_vector(self) -> None:
        """Zero magnitude vector returns 0.0."""
        assert vector_isometry([0.0, 0.0], [1.0, 0.0]) == 0.0


# ── validate_normalized_vector Tests ──────────────────────────────────


class TestValidateNormalizedVector:
    """Physical tests for direction vector normalization validation."""

    def test_valid_unit_vector(self) -> None:
        """Valid unit vector passes."""
        assert validate_normalized_vector(1.0, 0.0, 0.0) is True

    def test_valid_diagonal_unit_vector(self) -> None:
        """Valid diagonal unit vector."""
        v = 1.0 / math.sqrt(3)
        assert validate_normalized_vector(v, v, v) is True

    def test_non_normalized_raises(self) -> None:
        """Non-normalized vector raises ValueError."""
        with pytest.raises(ValueError, match="not normalized"):
            validate_normalized_vector(1.0, 1.0, 1.0)

    def test_zero_vector_raises(self) -> None:
        """Zero vector raises ValueError."""
        with pytest.raises(ValueError, match="not normalized"):
            validate_normalized_vector(0.0, 0.0, 0.0)


# ── mock_verify_hardware_signature Tests ──────────────────────────────


class TestMockVerifyHardwareSignature:
    """Physical tests for hardware gaze signature verification."""

    def test_valid_hardware_signature(self) -> None:
        """Signature containing VALID_GAZE_HARDWARE returns True."""
        sig = base64.urlsafe_b64encode(b"VALID_GAZE_HARDWARE").decode()
        assert mock_verify_hardware_signature(sig) is True

    def test_invalid_signature_raises(self) -> None:
        """Invalid signature raises ValueError."""
        sig = base64.urlsafe_b64encode(b"INVALID_DATA").decode()
        with pytest.raises(ValueError):
            mock_verify_hardware_signature(sig)

    def test_malformed_base64_raises(self) -> None:
        """Malformed base64 raises ValueError with wrapping."""
        with pytest.raises(ValueError):
            mock_verify_hardware_signature("not-valid-base64!!!")

    def test_hardware_signature_type_error(self) -> None:
        """Passing None triggering TypeError will be wrapped by the broad exception handler."""
        with pytest.raises(ValueError, match="Hardware validation error"):
            mock_verify_hardware_signature(None)  # type: ignore


# ── intersect_ray_with_nodes Tests ────────────────────────────────────


class TestIntersectRayWithNodes:
    """Physical tests for spatial raycast intersection."""

    def test_positive_z_hits_positive_box(self) -> None:
        """Positive z direction hits positive z box."""
        boxes = [{"cid": "box-1", "center": [0, 0, 5]}]
        result = intersect_ray_with_nodes([0, 0, 0], [0, 0, 1], boxes)
        assert "box-1" in result

    def test_negative_z_hits_negative_box(self) -> None:
        """Negative z direction hits negative z box."""
        boxes = [{"cid": "box-1", "center": [0, 0, -5]}]
        result = intersect_ray_with_nodes([0, 0, 0], [0, 0, -1], boxes)
        assert "box-1" in result

    def test_positive_z_misses_negative_box(self) -> None:
        """Positive z direction misses negative z box."""
        boxes = [{"cid": "box-1", "center": [0, 0, -5]}]
        result = intersect_ray_with_nodes([0, 0, 0], [0, 0, 1], boxes)
        assert "box-1" not in result

    def test_empty_boxes(self) -> None:
        """Empty boxes returns empty list."""
        result = intersect_ray_with_nodes([0, 0, 0], [0, 0, 1], [])
        assert result == []
