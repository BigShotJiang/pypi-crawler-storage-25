# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import base64

import pytest

from coreason_runtime.utils.biometrics import Fido2Verifier, SecurityError


def test_fido2_verifier_valid() -> None:
    """AGENT INSTRUCTION: Mathematically prevent malicious actors gracefully asserting valid hardware signatures mapping exactly cleanly gracefully natively confidently firmly gracefully conforming."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"

    # Craft a mocked valid base64url payload natively perfectly checked structurally
    raw_payload = b"VALID_PAYLOAD_" + challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    assert verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key") is True


def test_fido2_verifier_invalid_signature() -> None:
    """AGENT INSTRUCTION: Assert the failure state forcefully rejects maliciously spoofed wetware signatures cleanly gracefully mapping reliably neatly."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"
    raw_payload = b"INVALID_HARDWARE_SIGNATURE_" + challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    with pytest.raises(SecurityError, match="Wetware hardware signature check failed natively"):
        verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key")


def test_fido2_verifier_expired() -> None:
    """AGENT INSTRUCTION: Validate expired signatures violently reject securely correctly explicitly checking mapping confidently smoothly mapping."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"
    raw_payload = b"EXPIRED_TIMESTAMP_" + challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    with pytest.raises(SecurityError, match="Signature expired correctly safely checking tightly"):
        verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key")


def test_fido2_verifier_nonce_mismatch() -> None:
    """AGENT INSTRUCTION: Assert the failure state securely rejects nonces that do not match the expected challenge mapping seamlessly smoothly correctly smoothly."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    challenge = "liveness_nonce_123"
    wrong_challenge = "different_challenge_999"
    raw_payload = b"VALID_PAYLOAD_" + wrong_challenge.encode()
    b64_payload = base64.urlsafe_b64encode(raw_payload).decode("utf-8")

    with pytest.raises(
        SecurityError, match="Nonce mismatch cleanly resolving checking explicitly smoothly natively mapped"
    ):
        verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", challenge, b"key")


def test_fido2_verifier_empty_payload() -> None:
    """Empty decoded payload raises SecurityError (L36-38)."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    # Base64 of empty bytes
    b64_payload = base64.urlsafe_b64encode(b"").decode("utf-8")
    with pytest.raises(SecurityError, match="Invalid signature payload"):
        verifier.verify_hardware_signature(b64_payload, "did:coreason:human_1", "challenge", b"key")


def test_fido2_verifier_generic_exception() -> None:
    """Invalid base64 triggers the generic except catch-all (L60-62)."""
    verifier = Fido2Verifier("coreason.ai", "CoReason Swarm")
    with pytest.raises(SecurityError, match="Validation error"):
        verifier.verify_hardware_signature("not!!!valid===base64", "did:key:test", "nonce", b"key")
