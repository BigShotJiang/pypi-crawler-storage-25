# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import base64
import datetime

import cbor2
import pytest
from cryptography import x509
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import Encoding
from cryptography.x509.oid import NameOID

from coreason_runtime.utils.enclave import SecurityError, TEEVerifier


def generate_mock_nitro_attestation(pcr_hex: str, valid_signature: bool = True) -> str:
    """Generate a mathematically valid mock AWS Nitro COSE Sign1 Document."""
    private_key = ec.generate_private_key(ec.SECP384R1())
    public_key = private_key.public_key()

    subject = issuer = x509.Name(
        [
            x509.NameAttribute(NameOID.COMMON_NAME, "Mock AWS Nitro Enclave"),
        ]
    )
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(public_key)
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.UTC))
        .not_valid_after(
            # Valid for 10 days
            datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=10)
        )
        .sign(private_key, hashes.SHA384())
    )

    cert_der = cert.public_bytes(Encoding.DER)

    protected_header = cbor2.dumps({1: -35})  # alg: ES384
    unprotected_header = {b"cab": [cert_der]}

    payload_data = {"pcrs": {0: bytes.fromhex(pcr_hex)}}
    payload = cbor2.dumps(payload_data)

    sig_structure = cbor2.dumps(["Signature1", protected_header, b"", payload])

    if valid_signature:
        signature = private_key.sign(sig_structure, ec.ECDSA(hashes.SHA384()))
    else:
        # Generate an invalid signature by using a different key
        bad_key = ec.generate_private_key(ec.SECP384R1())
        signature = bad_key.sign(sig_structure, ec.ECDSA(hashes.SHA384()))

    cose_sign1 = [protected_header, unprotected_header, payload, signature]

    return base64.urlsafe_b64encode(cbor2.dumps(cose_sign1)).decode("utf-8")


def test_verify_hardware_quote_success() -> None:
    """Verify perfectly matched PCR and structurally sound signatures correctly parse."""
    verifier = TEEVerifier()
    pcr_hex = "0000000000000000000000000000000000000000000000000000000000000000"
    quote_b64 = generate_mock_nitro_attestation(pcr_hex=pcr_hex, valid_signature=True)

    assert verifier.verify_hardware_quote(quote_b64, "aws_nitro", pcr_hex) is True


def test_verify_hardware_quote_invalid_pcr() -> None:
    """Verify structurally sound quotes with invalid PCR mappings aggressively fail."""
    verifier = TEEVerifier()
    pcr_hex = "1111111111111111111111111111111111111111111111111111111111111111"
    quote_b64 = generate_mock_nitro_attestation(pcr_hex=pcr_hex, valid_signature=True)

    with pytest.raises(SecurityError, match="PCR measurement mismatch"):
        verifier.verify_hardware_quote(
            quote_b64, "aws_nitro", "0000000000000000000000000000000000000000000000000000000000000000"
        )


def test_verify_hardware_quote_invalid_signature() -> None:
    """Verify cryptographic boundaries catch intentionally manipulated COSE signatures."""
    verifier = TEEVerifier()
    pcr_hex = "0000000000000000000000000000000000000000000000000000000000000000"
    quote_b64 = generate_mock_nitro_attestation(pcr_hex=pcr_hex, valid_signature=False)

    with pytest.raises(SecurityError, match="Mathematical verification of the COSE signature failed"):
        verifier.verify_hardware_quote(quote_b64, "aws_nitro", pcr_hex)


def test_verify_hardware_quote_unsupported_enclave() -> None:
    """Verify enclave enforcement routing limits correctly against unsupported types."""
    verifier = TEEVerifier()
    with pytest.raises(SecurityError, match="Unsupported enclave class"):
        verifier.verify_hardware_quote("dummy", "intel_tdx", "0")


def test_verify_hardware_quote_invalid_cose_structure() -> None:
    """COSE document that isn't a 4-element list raises SecurityError."""
    verifier = TEEVerifier()
    bad_cose = cbor2.dumps(["a", "b", "c"])
    blob = base64.urlsafe_b64encode(bad_cose).decode("ascii")
    with pytest.raises(SecurityError, match="Invalid COSE Sign1"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "abc123")


def test_verify_hardware_quote_non_list_cose() -> None:
    """COSE document that is a dict instead of a list."""
    verifier = TEEVerifier()
    bad_cose = cbor2.dumps({"key": "value"})
    blob = base64.urlsafe_b64encode(bad_cose).decode("ascii")
    with pytest.raises(SecurityError, match="Invalid COSE Sign1"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "abc123")


def test_verify_hardware_quote_missing_cab() -> None:
    """COSE document with no CAB in unprotected header."""
    verifier = TEEVerifier()
    protected = cbor2.dumps({})
    payload = cbor2.dumps({"pcrs": {}})
    cose_sign1 = [protected, {}, payload, b"fake_signature"]
    raw = cbor2.dumps(cose_sign1)
    blob = base64.urlsafe_b64encode(raw).decode("ascii")
    with pytest.raises(SecurityError, match="No x509 certificate"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "abc123")


def test_verify_hardware_quote_corrupt_certificate() -> None:
    """COSE document with garbage cert DER bytes."""
    verifier = TEEVerifier()
    protected = cbor2.dumps({})
    payload = cbor2.dumps({"pcrs": {0: b"\x00" * 32}})
    cose_sign1 = [protected, {b"cab": [b"not_a_real_cert"]}, payload, b"fake_sig"]
    raw = cbor2.dumps(cose_sign1)
    blob = base64.urlsafe_b64encode(raw).decode("ascii")
    with pytest.raises(SecurityError, match="Certificate parsing or verification failed"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "00" * 32)


def test_verify_hardware_quote_missing_pcr0() -> None:
    """Valid signature but PCR0 is missing entirely from the payload."""
    private_key = ec.generate_private_key(ec.SECP384R1())
    public_key = private_key.public_key()

    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "test-no-pcr0")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(public_key)
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.UTC))
        .not_valid_after(datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=1))
        .sign(private_key, hashes.SHA384())
    )
    cert_der = cert.public_bytes(Encoding.DER)

    payload_data = {"pcrs": {1: b"\xaa" * 48}}
    payload = cbor2.dumps(payload_data)
    protected = cbor2.dumps({})

    sig_structure = cbor2.dumps(["Signature1", protected, b"", payload])
    signature = private_key.sign(sig_structure, ec.ECDSA(hashes.SHA384()))

    cose_sign1 = [protected, {b"cab": [cert_der]}, payload, signature]
    raw = cbor2.dumps(cose_sign1)
    blob = base64.urlsafe_b64encode(raw).decode("ascii")

    verifier = TEEVerifier()
    with pytest.raises(SecurityError, match="PCR0 measurement completely missing"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "aa" * 48)


def test_verify_hardware_quote_malformed_cbor() -> None:
    """Completely invalid CBOR bytes."""
    verifier = TEEVerifier()
    # These bytes are truly invalid and cannot be decoded as CBOR at all
    bad_bytes = b"\xff\xfe\xfd\xfc"
    blob = base64.urlsafe_b64encode(bad_bytes).decode("ascii")
    with pytest.raises(SecurityError):
        verifier.verify_hardware_quote(blob, "aws_nitro", "000000")


def test_verify_hardware_quote_decode_exception() -> None:
    verifier = TEEVerifier()
    # Trigger a binascii exception in base64.urlsafe_b64decode
    with pytest.raises(SecurityError, match="Structural parsing of COSE document failed"):
        verifier.verify_hardware_quote("INVALID-BASE-64!!!!", "aws_nitro", "00")


def test_verify_hardware_quote_payload_decode_exception() -> None:
    verifier = TEEVerifier()
    private_key = ec.generate_private_key(ec.SECP384R1())
    public_key = private_key.public_key()

    subject = issuer = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "test")])
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(public_key)
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.datetime.now(datetime.UTC))
        .not_valid_after(datetime.datetime.now(datetime.UTC) + datetime.timedelta(days=1))
        .sign(private_key, hashes.SHA384())
    )

    protected = cbor2.dumps({1: -35})
    bad_payload = b"\x18"

    sig_structure = cbor2.dumps(["Signature1", protected, b"", bad_payload])
    signature = private_key.sign(sig_structure, ec.ECDSA(hashes.SHA384()))

    cose_sign1 = [protected, {b"cab": [cert.public_bytes(Encoding.DER)]}, bad_payload, signature]
    raw = cbor2.dumps(cose_sign1)
    blob = base64.urlsafe_b64encode(raw).decode("ascii")

    with pytest.raises(SecurityError, match="Failed to extract platform configuration registers"):
        verifier.verify_hardware_quote(blob, "aws_nitro", "00")
