from typing import Any

# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime
import pytest
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import Worker

from coreason_runtime.orchestration.workflows.dynamic_routing_execution_workflow import (
    DynamicRoutingExecutionWorkflow,
    DynamicSubgraphExecutionWorkflow,
)


@pytest.fixture
def base_routing_payload() -> dict[str, Any]:
    """Provides a structurally conformant DynamicRoutingManifest to validate modality routing bounds."""
    return {
        "manifest_cid": "router-dispatch-1",
        "artifact_profile": {
            "artifact_event_cid": "doc-artifact-100",
            "detected_modalities": ["text", "tabular_grid"],
            "token_density": 5000,  # nosec B105
        },
        "active_subgraphs": {
            "text": ["did:coreason:node_text_extractor_1", "did:coreason:node_summarizer_2"],
            "tabular_grid": ["did:coreason:node_pandas_agent_1"],
        },
        "bypassed_steps": [
            {
                "artifact_event_cid": "doc-artifact-100",
                "bypassed_node_cid": "did:coreason:node_summarizer_2",
                "justification": "modality_mismatch",
                "cryptographic_null_hash": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
            }
        ],
        "branch_budgets_magnitude": {
            "did:coreason:node_text_extractor_1": 150,
            "did:coreason:node_summarizer_2": 50,
            "did:coreason:node_pandas_agent_1": 300,
            "did:coreason:node_vision_agent": 500,
        },
    }


@pytest.mark.asyncio
async def test_dynamic_routing_workflow_execution(base_routing_payload: dict) -> None:  # type: ignore
    """Ensure the workflow triggers appropriate subgraphs mapped to modalities while strictly honoring bypasses."""
    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="routing-queue",
            workflows=[DynamicRoutingExecutionWorkflow, DynamicSubgraphExecutionWorkflow],
        ):
            result = await env.client.execute_workflow(
                DynamicRoutingExecutionWorkflow.run,
                args=[base_routing_payload],
                id="test-routing-workflow-1",
                task_queue="routing-queue",
            )

            """The router must only fire node_text_extractor_1 and node_pandas_agent_1.

            node_summarizer_2 is explicitly bypassed based on the bypassing receipts.
            The Pydantic Strict bounds have mathematically verified NO routing errors natively occur.
            """
            assert result["status"] == "routing_completed"
            assert result["total_subgraphs_spawned"] == 2
