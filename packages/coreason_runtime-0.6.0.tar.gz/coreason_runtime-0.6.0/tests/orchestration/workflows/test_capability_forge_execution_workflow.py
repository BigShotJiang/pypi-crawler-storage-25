# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.capability_forge_execution_workflow import (
    CapabilityForgeExecutionWorkflow,
)


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def mock_execute_tensor_inference_compute_activity(
    workflow_id: str, payload: dict[str, Any], schema: str
) -> dict[str, Any]:
    if schema == "AgentResponse":
        return {
            "output": '{"scaffold_type": "scaffold_logic_actuator"}',
            "usage": {"total_tokens": 10},
            "cost": 0.05,
            "intent_hash": "testhash",
        }
    if schema == "VerificationYield":
        return {
            "success": True,
            "justification": "Looks good",
            "usage": {"total_tokens": 5},
            "cost": 0.01,
            "intent_hash": "testhash",
        }
    return {}


@activity.defn(name="ExecuteMCPToolIOActivity")
async def mock_execute_mcp_tool_io_activity(
    tool_name: str, payload: dict[str, Any], agent_profile_payload: dict[str, Any] | None = None
) -> dict[str, Any]:
    return {"success": True, "status": "success", "intent_hash": "mcp_hash"}


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state_io_activity(*args: Any) -> dict[str, Any]:
    return {"status": "stored"}


@activity.defn(name="RecordTokenBurnIOActivity")
async def mock_record_token_burn_io_activity(*args: Any) -> dict[str, Any]:
    return {"status": "recorded"}


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_bipartite() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
            "did:coreason:verifier_1": {
                "topology_class": "agent",
                "description": "Verifier node",
            },
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:verifier_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                mock_execute_tensor_inference_compute_activity,
                mock_execute_mcp_tool_io_activity,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf",
                task_queue="capability-forge-test",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "verification"
            assert results[2]["type"] == "forge_proxy"


@pytest.mark.asyncio
async def test_capability_forge_execution_workflow_no_verifier_and_bad_json() -> None:
    manifest_payload = {
        "nodes": {
            "did:coreason:generator_1": {
                "topology_class": "agent",
                "description": "Generator node",
            },
            "did:coreason:fake_1": {
                "topology_class": "agent",
                "description": "Fake node",
            },
            "did:coreason:fuzz_1": {
                "topology_class": "agent",
                "description": "Fuzzer node",
            },
        },
        "target_epistemic_deficit": {
            "topology_class": "semantic_discovery",
            "query_vector": {"vector_base64": "AAAA", "dimensionality": 1, "foundation_matrix_name": "test"},
            "min_isometry_score": 0.5,
            "required_structural_types": [],
        },
        "generator_node_cid": "did:coreason:generator_1",
        "formal_verifier_cid": "did:coreason:fake_1",
        "fuzzing_engine_cid": "did:coreason:fuzz_1",
    }

    envelope_payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
        },
        "state_vector": {
            "immutable_matrix": {},
            "mutable_matrix": {},
        },
        "payload": manifest_payload,
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="capability-forge-test",
            workflows=[CapabilityForgeExecutionWorkflow],
            activities=[
                mock_execute_tensor_inference_compute_activity,
                mock_execute_mcp_tool_io_activity,
                mock_store_epistemic_state_io_activity,
                mock_record_token_burn_io_activity,
            ],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            # We must trick the mock to return bad JSON
            # However mock_execute_tensor_inference_compute_activity returns hardcoded {"output": '{"scaffold_type": "scaffold_logic_actuator"}'}
            # Instead of changing it, we will just expect missing verifier coverage to be hit.
            result = await env.client.execute_workflow(
                CapabilityForgeExecutionWorkflow.run,
                args=[envelope_payload],
                id="test-forge-wf-2",
                task_queue="capability-forge-test",
            )
            assert result["status"] == "success"
            results = result["results"]
            assert len(results) == 2  # Only generation and forge_proxy
            assert results[0]["type"] == "generation"
            assert results[1]["type"] == "forge_proxy"
