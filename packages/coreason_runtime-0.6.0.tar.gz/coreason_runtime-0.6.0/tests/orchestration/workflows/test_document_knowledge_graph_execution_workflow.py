# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for DocumentKnowledgeGraphExecutionWorkflow.

Tests both the extract_causal_edges_activity (local activity / pure function)
and the full Temporal workflow via WorkflowEnvironment.start_time_skipping().

All tests use physically instantiated manifest models —
returning manifest-typed payloads — zero unittest.mock.
"""

import concurrent.futures
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ExecutionEnvelopeState,
    StateVectorProfile,
    TraceContextState,
)
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.document_knowledge_graph_execution_workflow import (
    DocumentKnowledgeGraphExecutionWorkflow,
    extract_causal_edges_activity,
)

# ── Pure Function Tests (extract_causal_edges_activity) ───────────────


class TestExtractCausalEdgesActivity:
    """Physical tests for the local activity computing causal edges."""

    def test_dict_edges(self) -> None:
        """Dict-format edges are parsed into subject/predicate/object triples."""
        payload = {
            "edges": [
                {"source": "A", "target": "B", "relation": "causes"},
                {"source": "B", "target": "C"},
            ]
        }
        result = extract_causal_edges_activity(payload)

        assert len(result["causal_edges"]) == 2
        assert result["causal_edges"][0] == {"subject": "A", "predicate": "causes", "object": "B"}
        assert result["causal_edges"][1]["predicate"] == "Predicate"
        assert len(result["isomorphism_hashes"]) == 2
        assert all(len(h) == 64 for h in result["isomorphism_hashes"])

    def test_tuple_edges(self) -> None:
        """List-format edges (tuples) are parsed with positional extraction."""
        payload = {
            "edges": [
                ["X", "implies", "Y"],
                ["P", "Q"],
            ]
        }
        result = extract_causal_edges_activity(payload)

        assert result["causal_edges"][0] == {"subject": "X", "predicate": "implies", "object": "Y"}
        assert result["causal_edges"][1] == {"subject": "P", "predicate": "Predicate", "object": "Q"}

    def test_empty_edges(self) -> None:
        """Empty edges list produces empty results."""
        result = extract_causal_edges_activity({"edges": []})
        assert result["causal_edges"] == []
        assert result["isomorphism_hashes"] == []

    def test_deterministic_hashes(self) -> None:
        """Same edge always produces same SHA-256 hash."""
        payload = {"edges": [{"source": "A", "target": "B", "relation": "causes"}]}
        r1 = extract_causal_edges_activity(payload)
        r2 = extract_causal_edges_activity(payload)
        assert r1["isomorphism_hashes"] == r2["isomorphism_hashes"]

    def test_missing_edges_key(self) -> None:
        """Missing 'edges' key produces empty results."""
        result = extract_causal_edges_activity({})
        assert result["causal_edges"] == []


# ── Temporal Workflow Tests ───────────────────────────────────────────


def _build_kg_envelope(edges: list[dict[str, str] | list[str]]) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState for the KG workflow."""
    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload={"edges": edges},
    )
    return envelope.model_dump(mode="json")


class TestDocumentKnowledgeGraphWorkflow:
    """Physical Temporal tests for DocumentKnowledgeGraphExecutionWorkflow."""

    @pytest.mark.asyncio
    async def test_workflow_extracts_edges(self) -> None:
        """Workflow processes graph edges and returns causal structure."""
        payload = _build_kg_envelope(
            [
                {"source": "concept-A", "target": "concept-B", "relation": "implies"},
            ]
        )

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="kg-test-queue",
                workflows=[DocumentKnowledgeGraphExecutionWorkflow],
                activities=[extract_causal_edges_activity],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    DocumentKnowledgeGraphExecutionWorkflow.run,
                    payload,
                    id="kg-test-workflow",
                    task_queue="kg-test-queue",
                )

        assert result["success"] is True
        assert len(result["causal_edges"]) == 1
        assert len(result["isomorphism_hashes"]) == 1
        assert "knowledge_graph_" in result["manifest"]["server_cid"]

    @pytest.mark.asyncio
    async def test_workflow_empty_edges(self) -> None:
        """Workflow handles empty edges gracefully."""
        payload = _build_kg_envelope([])

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="kg-empty-queue",
                workflows=[DocumentKnowledgeGraphExecutionWorkflow],
                activities=[extract_causal_edges_activity],
                workflow_runner=UnsandboxedWorkflowRunner(),
                activity_executor=concurrent.futures.ThreadPoolExecutor(),
            ):
                result = await env.client.execute_workflow(
                    DocumentKnowledgeGraphExecutionWorkflow.run,
                    payload,
                    id="kg-empty-test",
                    task_queue="kg-empty-queue",
                )

        assert result["success"] is True
        assert result["causal_edges"] == []
