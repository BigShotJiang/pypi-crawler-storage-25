# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for BaseTopologyWorkflow: state management, governance, LBAC, and signal handlers.

These tests exercise the pure-function methods of the base workflow class directly,
without Temporal. Signal handlers and activity-dispatching methods are tested via
physical Temporal time-skipping environments.

Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

from typing import Any

import pytest
from coreason_manifest import ExecutionEnvelopeState, StateVectorProfile, TraceContextState

from coreason_runtime.orchestration.workflows.base_topology_workflow import BaseTopologyWorkflow

# ── Fixtures ───────────────────────────────────────────────────────


def _build_envelope() -> ExecutionEnvelopeState[dict[str, Any]]:
    """Build a minimal ExecutionEnvelopeState for testing."""
    import uuid

    trace_id = str(uuid.uuid7())
    span_id = str(uuid.uuid7())
    return ExecutionEnvelopeState(
        trace_context=TraceContextState(
            trace_cid=trace_id,
            span_cid=span_id,
            causal_clock=0,
        ),
        state_vector=StateVectorProfile(
            immutable_matrix={"tenant_cid": "test-tenant", "session_cid": "test-session"},
            mutable_matrix={"accumulated_tokens": 0, "accumulated_cost": 0.0},
            is_delta=False,
        ),
        payload={"type": "dag", "nodes": {}},
    )


# ── Init Tests ─────────────────────────────────────────────────────


class TestBaseTopologyInit:
    """Verify default initialization state."""

    def test_default_init(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf._current_state_envelope is None
        assert wf._pending_oracle_override is None
        assert wf._current_oracle_resolution is None
        assert wf._accumulated_tokens == 0
        assert wf._accumulated_cost == 0.0
        assert wf._is_interrupted is False
        assert wf._interrupt_disposition is None
        assert wf._interrupt_event is None


# ── State Reconciliation Tests ─────────────────────────────────────


class TestReconcileState:
    """Exercise the CRDT-style reconcile_state method."""

    def test_reconcile_updates_mutable_matrix(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        wf.reconcile_state({"new_key": "new_value"})

        matrix = wf._current_state_envelope.state_vector.mutable_matrix
        assert matrix["new_key"] == "new_value"  # type: ignore[index]
        # Original keys preserved
        assert matrix["accumulated_tokens"] == 0  # type: ignore[index]

    def test_reconcile_increments_causal_clock(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        assert wf._current_state_envelope.trace_context.causal_clock == 0

        wf.reconcile_state({"delta": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 1

        wf.reconcile_state({"delta_2": True})
        assert wf._current_state_envelope.trace_context.causal_clock == 2

    def test_reconcile_immutable_key_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()

        with pytest.raises(ValueError, match="read-only context key"):
            wf.reconcile_state({"tenant_cid": "evil_override"})

    def test_reconcile_no_envelope_raises(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(ValueError, match="No current state envelope"):
            wf.reconcile_state({"key": "value"})


# ── Governance Enforcement Tests ───────────────────────────────────


class TestEnforceGovernanceLimits:
    """Exercise the economic constraint enforcement."""

    def test_no_governance_is_noop(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_governance_limits(None, None)  # Should not raise

    def test_token_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 5000
        governance = {"max_global_tokens": 4000}

        with pytest.raises(ValueError, match="Global token budget breached"):
            wf.enforce_governance_limits(governance, None)

    def test_token_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_tokens = 3000
        governance = {"max_global_tokens": 4000}
        wf.enforce_governance_limits(governance, None)  # Should not raise

    def test_cost_budget_breach(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 50.0
        governance = {"max_budget_magnitude": 25.0}

        with pytest.raises(ValueError, match="Global budget magnitude breached"):
            wf.enforce_governance_limits(governance, None)

    def test_cost_budget_within_limits(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._accumulated_cost = 10.0
        governance = {"max_budget_magnitude": 25.0}
        wf.enforce_governance_limits(governance, None)  # Should not raise


# ── LBAC Clearance Tests ──────────────────────────────────────────


class TestEnforceLBACClearance:
    """Exercise the Lattice-Based Access Control clearance hierarchy."""

    def test_public_tool_allowed_by_public_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["public"], tool_classification="public")

    def test_confidential_tool_blocked_by_public_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public"], tool_classification="confidential")

    def test_restricted_tool_allowed_by_restricted_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["restricted"], tool_classification="restricted")

    def test_internal_tool_allowed_by_confidential_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        wf.enforce_lbac_clearance(["confidential"], tool_classification="internal")

    def test_no_classifications_defaults_to_max_clearance(self) -> None:
        wf = BaseTopologyWorkflow()
        # None allowed_classifications defaults max_allowed to 3 (restricted)
        wf.enforce_lbac_clearance(None, tool_classification="restricted")

    def test_no_tool_classification_defaults_to_restricted(self) -> None:
        wf = BaseTopologyWorkflow()
        # tool_classification=None defaults to "restricted", allowed only if max is restricted
        wf.enforce_lbac_clearance(["restricted"], tool_classification=None)

    def test_internal_tool_blocked_by_public_only(self) -> None:
        wf = BaseTopologyWorkflow()
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public"], tool_classification="internal")

    def test_highest_of_multiple_classifications_wins(self) -> None:
        wf = BaseTopologyWorkflow()
        # ["public", "confidential"] → max is confidential (2), so "confidential" tool passes
        wf.enforce_lbac_clearance(["public", "confidential"], tool_classification="confidential")

        # But "restricted" (3) should still fail
        with pytest.raises(PermissionError, match="LBAC clearance breached"):
            wf.enforce_lbac_clearance(["public", "confidential"], tool_classification="restricted")


# ── Query Tests ────────────────────────────────────────────────────


class TestGetCurrentState:
    """Test the query handler for current state."""

    def test_no_envelope_returns_empty_dict(self) -> None:
        wf = BaseTopologyWorkflow()
        assert wf.get_current_state() == {}

    def test_with_envelope_returns_serialized(self) -> None:
        wf = BaseTopologyWorkflow()
        wf._current_state_envelope = _build_envelope()
        state = wf.get_current_state()
        assert "trace_context" in state
        assert "state_vector" in state
        assert "payload" in state
        assert state["trace_context"]["trace_cid"] is not None
        assert len(state["trace_context"]["trace_cid"]) >= 26


# Note: Signal handlers (receive_oracle_override, barge_in_interrupt, inject_oracle_resolution)
# and methods using workflow.logger (intercept_kinematic_intent, emit_mcp_ui_intent) require
# running inside a Temporal workflow context. They are tested via the DAG/speculative
# execution workflow integration tests with WorkflowEnvironment.start_time_skipping().
