# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for DiscourseTreeExecutionWorkflow.

Tests the BFS discourse tree traversal: root-to-leaf extraction,
upstream dependency injection, multi-proposition processing,
and telemetry emission lifecycle.

All tests use Temporal time-skipping environments with physical stub activities
returning manifest-typed payloads — zero unittest.mock.
"""

from typing import Any

import pytest
from coreason_manifest import (
    DiscourseTreeManifest,
    ExecutionEnvelopeState,
)
from coreason_manifest.spec.ontology import (
    DiscourseNodeState,
    ExecutionNodeReceipt,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.discourse_tree_execution_workflow import (
    DiscourseTreeExecutionWorkflow,
)

# ── Physical Stub Activities (Manifest-Typed Returns) ──────────────────


@activity.defn(name="ExecuteNodeActivity")
async def stub_execute_node(*args: Any) -> dict[str, Any]:
    """Return a physically validated ExecutionNodeReceipt payload."""
    receipt = ExecutionNodeReceipt(
        request_cid="stub-discourse-req",
        inputs={},
        outputs={"extracted_text": "Lorem ipsum analysis complete"},
        node_hash="b" * 64,
    )
    payload = receipt.model_dump(mode="json")
    payload["intent_hash"] = "b" * 64
    payload["usage"] = {"prompt_tokens": 20, "completion_tokens": 10, "total_tokens": 30}
    payload["cost"] = 0.02
    payload["success"] = True
    return payload


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic_dt(*args: Any) -> None:
    """Physical no-op stub for epistemic storage."""


@activity.defn(name="RecordTokenBurnIOActivity")
async def stub_record_burn_dt(*args: Any) -> None:
    """Physical no-op stub for token burn recording."""


# ── Manifest Model Factories ──────────────────────────────────────────


def _build_discourse_envelope(
    node_count: int = 1,
    propositions_per_node: int = 1,
    multi_level: bool = False,
) -> dict[str, Any]:
    """Construct a physically validated ExecutionEnvelopeState for a discourse tree.

    Instantiates DiscourseTreeManifest with configurable node depth and
    proposition counts, wraps in ExecutionEnvelopeState.
    """
    discourse_nodes: dict[str, DiscourseNodeState] = {}

    # Root node
    root_props = [f"did:coreason:prop-root-{i}" for i in range(propositions_per_node)]
    discourse_nodes["did:coreason:root"] = DiscourseNodeState(
        node_cid="did:coreason:root",
        discourse_type="preamble",
        parent_node_cid=None,
        contained_propositions=root_props,
    )

    if multi_level:
        # Level 1 child
        child_props = [f"did:coreason:prop-child-{i}" for i in range(propositions_per_node)]
        discourse_nodes["did:coreason:child-0"] = DiscourseNodeState(
            node_cid="did:coreason:child-0",
            discourse_type="methodology",
            parent_node_cid="did:coreason:root",
            contained_propositions=child_props,
        )

        # Level 2 grandchild
        grandchild_props = [f"did:coreason:prop-grandchild-{i}" for i in range(propositions_per_node)]
        discourse_nodes["did:coreason:grandchild-0"] = DiscourseNodeState(
            node_cid="did:coreason:grandchild-0",
            discourse_type="findings",
            parent_node_cid="did:coreason:child-0",
            contained_propositions=grandchild_props,
        )
    elif node_count > 1:
        # Flat children of root
        discourse_types = ["methodology", "argumentation", "findings", "conclusion", "addendum"]
        for i in range(1, node_count):
            child_props = [f"did:coreason:prop-{i}-{j}" for j in range(propositions_per_node)]
            discourse_nodes[f"did:coreason:node-{i}"] = DiscourseNodeState(
                node_cid=f"did:coreason:node-{i}",
                discourse_type=discourse_types[(i - 1) % len(discourse_types)],  # type: ignore[arg-type]
                parent_node_cid="did:coreason:root",
                contained_propositions=child_props,
            )

    manifest = DiscourseTreeManifest(
        manifest_cid="did:coreason:discourse-manifest-001",
        root_node_cid="did:coreason:root",
        discourse_nodes=discourse_nodes,
    )

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H0000000000000000000000A",
            span_cid="01H0000000000000000000000B",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=manifest.model_dump(mode="json"),
    )

    return envelope.model_dump(mode="json")


# ── Discourse Tree Execution Tests ─────────────────────────────────────


class TestDiscourseTreeExecutionWorkflow:
    """Physical Temporal tests for the discourse tree BFS traversal workflow."""

    @pytest.mark.asyncio
    async def test_single_node_tree_success(self) -> None:
        """Single-node tree (root with one proposition) → success."""
        payload = _build_discourse_envelope(node_count=1, propositions_per_node=1)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discourse-test-queue",
                workflows=[DiscourseTreeExecutionWorkflow],
                activities=[stub_execute_node, stub_store_epistemic_dt, stub_record_burn_dt],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscourseTreeExecutionWorkflow.run,
                    payload,
                    id="discourse-single-test",
                    task_queue="discourse-test-queue",
                )

        assert result["status"] == "success"
        assert "did:coreason:root" in result["results"]
        root_data = result["results"]["did:coreason:root"]
        assert root_data["discourse_type"] == "preamble"
        assert len(root_data["extracted_propositions"]) == 1

    @pytest.mark.asyncio
    async def test_multi_level_bfs_traversal(self) -> None:
        """Multi-level tree (root → child → grandchild) traverses BFS order."""
        payload = _build_discourse_envelope(multi_level=True)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discourse-multi-queue",
                workflows=[DiscourseTreeExecutionWorkflow],
                activities=[stub_execute_node, stub_store_epistemic_dt, stub_record_burn_dt],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscourseTreeExecutionWorkflow.run,
                    payload,
                    id="discourse-multi-test",
                    task_queue="discourse-multi-queue",
                )

        assert result["status"] == "success"
        assert "did:coreason:root" in result["results"]
        assert "did:coreason:child-0" in result["results"]
        assert "did:coreason:grandchild-0" in result["results"]

    @pytest.mark.asyncio
    async def test_multiple_propositions_per_node(self) -> None:
        """Node with multiple propositions processes all of them."""
        payload = _build_discourse_envelope(node_count=1, propositions_per_node=3)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discourse-multiprops-queue",
                workflows=[DiscourseTreeExecutionWorkflow],
                activities=[stub_execute_node, stub_store_epistemic_dt, stub_record_burn_dt],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscourseTreeExecutionWorkflow.run,
                    payload,
                    id="discourse-multiprops-test",
                    task_queue="discourse-multiprops-queue",
                )

        assert result["status"] == "success"
        root_data = result["results"]["did:coreason:root"]
        assert len(root_data["extracted_propositions"]) == 3

    @pytest.mark.asyncio
    async def test_flat_children_traversal(self) -> None:
        """Root with 3 flat children all get processed."""
        payload = _build_discourse_envelope(node_count=4, propositions_per_node=1)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discourse-flat-queue",
                workflows=[DiscourseTreeExecutionWorkflow],
                activities=[stub_execute_node, stub_store_epistemic_dt, stub_record_burn_dt],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscourseTreeExecutionWorkflow.run,
                    payload,
                    id="discourse-flat-test",
                    task_queue="discourse-flat-queue",
                )

        assert result["status"] == "success"
        # root + 3 children = 4 nodes
        assert len(result["results"]) == 4

    @pytest.mark.asyncio
    async def test_empty_propositions_handled(self) -> None:
        """Node with zero propositions processes gracefully."""
        payload = _build_discourse_envelope(node_count=1, propositions_per_node=0)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discourse-empty-queue",
                workflows=[DiscourseTreeExecutionWorkflow],
                activities=[stub_execute_node, stub_store_epistemic_dt, stub_record_burn_dt],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscourseTreeExecutionWorkflow.run,
                    payload,
                    id="discourse-empty-test",
                    task_queue="discourse-empty-queue",
                )

        assert result["status"] == "success"
        root_data = result["results"]["did:coreason:root"]
        assert len(root_data["extracted_propositions"]) == 0
