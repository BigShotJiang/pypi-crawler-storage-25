# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for the EvolutionaryExecutionWorkflow."""

from collections.abc import Generator
from typing import Any
from unittest.mock import patch

import pytest
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.evolutionary_execution_workflow import EvolutionaryExecutionWorkflow


@pytest.fixture(autouse=True)
def mock_telemetry_emitter() -> Generator[Any]:
    with patch("coreason_runtime.orchestration.workflows.evolutionary_execution_workflow.TelemetryEmitter") as mock:
        mock_instance = mock.return_value

        async def mock_wrap(name: str, kind: str, block: Any, trace_context: Any = None) -> Any:
            return await block()

        mock_instance.wrap_execution_block.side_effect = mock_wrap
        yield mock_instance


@activity.defn(name="ExecuteTensorInferenceComputeActivity")
async def mock_execute_tensor_inference(
    workflow_id: str, payload_block: dict[str, Any], target_class: str
) -> dict[str, Any]:
    """Mock tensor inference returning a dummy fitness score."""
    return {
        "intent_hash": "mocked_hash123",
        "outputs": {"accuracy": 0.95},
        "usage": {"total_tokens": 10},
        "cost": 0.001,
        "success": True,
    }


@activity.defn(name="StoreEpistemicStateIOActivity")
async def mock_store_epistemic_state(
    workflow_id: str, intent_hash: str, success: bool, fittest_individual: dict[str, Any], unused: Any = None
) -> None:
    """Mock storing the epistemic state."""


@activity.defn(name="RecordTokenBurnIOActivity")
async def mock_record_token_burn(workflow_id: str, receipt: dict[str, Any]) -> None:
    pass


@pytest.mark.asyncio
async def test_evolutionary_execution_workflow_success() -> None:
    """Test full convergence over multiple evolutionary generations."""
    payload = {
        "trace_context": {
            "trace_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "span_cid": "01ARZ3NDEKTSV4RRFFQ69G5FAX",
            "causal_clock": 0,
        },
        "state_vector": {"immutable_matrix": {"test_key": "test_val"}, "mutable_matrix": {}},
        "payload": {
            "epistemic_enforcement": {
                "decay_propagation_rate": 0.1,
                "epistemic_quarantine_threshold": 0.5,
                "enforce_cross_agent_quarantine": False,
                "max_cascade_depth": 1,
                "max_quarantine_blast_radius": 1,
                "retroactive_falsification_mode": "cap_validity",
            },
            "lifecycle_phase": "live",
            "architectural_intent": "test",
            "justification": None,
            "nodes": {
                "did:coreason:agent01": {
                    "architectural_intent": None,
                    "justification": None,
                    "intervention_policies": [],
                    "description": "test",
                    "topology_class": "agent",
                    "hardware": {
                        "compute_tier": "urn:coreason:KINETIC",
                        "min_vram_gb": 8.0,
                        "accelerator_type": "urn:coreason:BF16_TENSOR",
                        "provider_whitelist": ["aws"],
                    },
                    "security": {
                        "epistemic_security": "STANDARD",
                        "network_isolation": False,
                        "egress_obfuscation": False,
                    },
                    "action_space_cid": "act1",
                }
            },
            "topology_class": "evolutionary",
            "generations": 1,
            "population_size": 1,
            "mutation": {"mutation_rate": 0.1, "temperature_shift_variance": 0.1, "verifiable_entropy": None},
            "crossover": {"strategy_profile": "uniform_blend", "blending_factor": 0.1, "verifiable_entropy": None},
            "fitness_objectives": [{"target_metric": "accuracy", "direction": "maximize", "weight": 1.0}],
        },
    }

    async with await WorkflowEnvironment.start_time_skipping() as env:
        async with Worker(
            env.client,
            task_queue="evo-test-queue",
            workflows=[EvolutionaryExecutionWorkflow],
            activities=[mock_execute_tensor_inference, mock_store_epistemic_state, mock_record_token_burn],
            workflow_runner=UnsandboxedWorkflowRunner(),
        ):
            result = await env.client.execute_workflow(
                EvolutionaryExecutionWorkflow.run,
                payload,
                id="test-val-wf-evo-1",
                task_queue="evo-test-queue",
            )
            assert result["status"] == "success"
            assert result["generations_completed"] == 1
            assert len(result["results"]) == 1
            assert result["results"][0]["best_fitness"] == 0.95
