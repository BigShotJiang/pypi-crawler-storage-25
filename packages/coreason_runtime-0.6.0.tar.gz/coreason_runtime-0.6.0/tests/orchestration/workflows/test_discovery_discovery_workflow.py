# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for DiscoveryDiscoveryWorkflow.

Tests concept reification above/below isometry threshold via
physical Temporal time-skipping with manifest-typed stub activities.

All tests use physically instantiated manifest models —
returning manifest-typed payloads — zero unittest.mock.
"""

from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    ExecutionEnvelopeState,
    StateVectorProfile,
    TraceContextState,
)
from temporalio import activity
from temporalio.testing import WorkflowEnvironment
from temporalio.worker import UnsandboxedWorkflowRunner, Worker

from coreason_runtime.orchestration.workflows.discovery_discovery_workflow import (
    DiscoveryDiscoveryWorkflow,
)

# ── Stub Activities ──────────────────────────────────────────────────


@activity.defn(name="ExecuteOntologyDiscoveryComputeActivity")
async def stub_ontology_discovery(node_data: dict[str, Any]) -> list[dict[str, Any]]:
    """Returns discovery results with configurable isometry scores."""
    threshold = node_data.get("_test_threshold", 0.95)
    return [
        {
            "concept_cid": f"concept-{node_data.get('node_cid', 'anon')}",
            "isometry_score": threshold,
            "registry_uri_verified": "urn:coreason:test-registry",
            "parsed_schema": {"type": "test_schema"},
        }
    ]


@activity.defn(name="StoreEpistemicStateIOActivity")
async def stub_store_epistemic(*args: Any) -> None:
    """Physical no-op epistemic store stub."""


@activity.defn(name="BroadcastStateEchoIOActivity")
async def stub_broadcast(*args: Any) -> None:
    """Physical no-op broadcast stub."""


# ── Envelope Builder ─────────────────────────────────────────────────


def _build_discovery_envelope(
    nodes: dict[str, Any] | None = None,
    threshold: float = 0.90,
) -> dict[str, Any]:
    """Build a physically validated ExecutionEnvelopeState for the discovery workflow."""
    if nodes is None:
        nodes = {
            "discover-1": {
                "topology_class": "ontology_discovery",
                "node_cid": "n1",
                "_test_threshold": 0.95,
            }
        }

    payload: dict[str, Any] = {
        "nodes": nodes,
        "governance": {"discovery_threshold": threshold},
    }

    envelope = ExecutionEnvelopeState(
        trace_context=TraceContextState(
            causal_clock=1,
            trace_cid="01H00000000000000000000000",
            span_cid="01H00000000000000000000001",
        ),
        state_vector=StateVectorProfile(immutable_matrix={}, mutable_matrix={}),
        payload=payload,
    )
    return envelope.model_dump(mode="json")


# ── Temporal Workflow Tests ───────────────────────────────────────────


class TestDiscoveryDiscoveryWorkflow:
    """Physical Temporal tests for DiscoveryDiscoveryWorkflow."""

    @pytest.mark.asyncio
    async def test_concept_minted_above_threshold(self) -> None:
        """Discovery above isometry threshold mints a concept."""
        payload = _build_discovery_envelope(threshold=0.90)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discovery-mint-queue",
                workflows=[DiscoveryDiscoveryWorkflow],
                activities=[stub_ontology_discovery, stub_store_epistemic, stub_broadcast],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscoveryDiscoveryWorkflow.run,
                    payload,
                    id="discovery-mint-test",
                    task_queue="discovery-mint-queue",
                )

        assert result["status"] == "success"
        assert result["concepts_minted"] == 1
        assert len(result["concepts_geometry"]) == 1
        assert result["concepts_geometry"][0]["topology_class"] == "synthetic_concept"

    @pytest.mark.asyncio
    async def test_concept_rejected_below_threshold(self) -> None:
        """Discovery below isometry threshold rejects the concept."""
        nodes = {
            "discover-1": {
                "topology_class": "ontology_discovery",
                "node_cid": "n1",
                "_test_threshold": 0.50,  # Below threshold
            }
        }
        payload = _build_discovery_envelope(nodes=nodes, threshold=0.90)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discovery-reject-queue",
                workflows=[DiscoveryDiscoveryWorkflow],
                activities=[stub_ontology_discovery, stub_store_epistemic, stub_broadcast],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscoveryDiscoveryWorkflow.run,
                    payload,
                    id="discovery-reject-test",
                    task_queue="discovery-reject-queue",
                )

        assert result["status"] == "success"
        assert result["concepts_minted"] == 0

    @pytest.mark.asyncio
    async def test_empty_nodes(self) -> None:
        """No discovery nodes produces zero concepts."""
        payload = _build_discovery_envelope(nodes={})

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discovery-empty-queue",
                workflows=[DiscoveryDiscoveryWorkflow],
                activities=[stub_ontology_discovery, stub_store_epistemic, stub_broadcast],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscoveryDiscoveryWorkflow.run,
                    payload,
                    id="discovery-empty-test",
                    task_queue="discovery-empty-queue",
                )

        assert result["status"] == "success"
        assert result["concepts_minted"] == 0

    @pytest.mark.asyncio
    async def test_non_discovery_nodes_skipped(self) -> None:
        """Nodes without topology_class='ontology_discovery' are skipped."""
        nodes = {
            "agent-1": {"topology_class": "agent", "node_cid": "a1"},
        }
        payload = _build_discovery_envelope(nodes=nodes)

        async with await WorkflowEnvironment.start_time_skipping() as env:
            async with Worker(
                env.client,
                task_queue="discovery-skip-queue",
                workflows=[DiscoveryDiscoveryWorkflow],
                activities=[stub_ontology_discovery, stub_store_epistemic, stub_broadcast],
                workflow_runner=UnsandboxedWorkflowRunner(),
            ):
                result = await env.client.execute_workflow(
                    DiscoveryDiscoveryWorkflow.run,
                    payload,
                    id="discovery-skip-test",
                    task_queue="discovery-skip-queue",
                )

        assert result["status"] == "success"
        assert result["concepts_minted"] == 0
