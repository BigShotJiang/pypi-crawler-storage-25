from typing import Any

# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Extended activity tests covering schema resolution, inference dispatch, and MCP tool execution.

All tests exercise the pure-function logic paths of the activity layer without network calls.
Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

import pytest
from coreason_manifest import ExecutionNodeReceipt, MCPClientIntent

from coreason_runtime.orchestration.activities import KineticActivities, resolve_schema_class

# ── Tier 3A: resolve_schema_class Pure Function Tests ──────────────


class TestResolveSchemaClass:
    """Exercise every branch of the pure schema resolver."""

    def test_resolve_manifest_ontology_type(self) -> None:
        """Direct lookup in coreason_manifest.spec.ontology succeeds."""
        cls = resolve_schema_class("ExecutionNodeReceipt")
        assert cls is ExecutionNodeReceipt

    def test_resolve_agent_response_fallback(self) -> None:
        """AgentResponse fallback creates a dynamic model."""
        cls = resolve_schema_class("AgentResponse")
        assert cls.__name__ == "AgentResponse"
        # Verify the model has an "output" field
        assert "output" in cls.model_fields  # type: ignore[attr-defined]

    def test_resolve_verification_yield_fallback(self) -> None:
        """VerificationYield fallback creates a dynamic model."""
        cls = resolve_schema_class("VerificationYield")
        assert cls.__name__ == "VerificationYield"
        assert "success" in cls.model_fields  # type: ignore[attr-defined]
        assert "justification" in cls.model_fields  # type: ignore[attr-defined]

    def test_resolve_domain_extension_dict(self) -> None:
        """Dynamic model creation from domain_extensions dict."""
        extensions = {
            "CustomSchema": {
                "field_a": "string description",
                "field_b": "boolean flag",
            }
        }
        cls = resolve_schema_class("CustomSchema", domain_extensions=extensions)
        assert cls.__name__ == "CustomSchema"
        assert "field_a" in cls.model_fields  # type: ignore[attr-defined]
        assert "field_b" in cls.model_fields  # type: ignore[attr-defined]

    def test_resolve_unknown_type_raises(self) -> None:
        """Unknown schema without domain_extensions raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("NonExistentSchemaXYZ")

    def test_resolve_domain_extension_ignores_wrong_name(self) -> None:
        """domain_extensions present but schema_type_name not in them raises ValueError."""
        extensions = {"OtherSchema": {"field": "desc"}}
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("MissingSchema", domain_extensions=extensions)


# ── Tier 3A: KineticActivities Initialization ──────────────────────


class TestKineticActivitiesInit:
    """Verify the singleton initialization wiring."""

    def test_init_creates_all_subsystems(self) -> None:
        """All subsystem pools are created on init."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-init",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )
        assert activities.tensor_router is not None
        assert activities.store is not None
        assert activities.ledger is not None
        assert activities.latent is not None
        assert activities.sandbox is not None
        assert activities.telemetry is not None
        assert activities.mcp_manager is not None


# ── Tier 3A: Activity Dispatch Logic (Pure Path) ──────────────────


class TestExecuteTensorInferenceActivity:
    """Test the tensor inference activity's schema resolution + dispatch logic."""

    @pytest.mark.asyncio
    async def test_inference_unknown_schema_raises_value_error(self) -> None:
        """When schema_type_name is not found, the activity raises ValueError directly."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-inference",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        payload: Any = {"node_profile": {}, "immutable_matrix": {}}
        with pytest.raises(ValueError, match="not found"):
            await activities.execute_tensor_inference_compute_activity("wf-test-001", payload, "TotallyFakeSchemaName")

    @pytest.mark.asyncio
    async def test_inference_agent_response_schema_with_connection_error(self) -> None:
        """AgentResponse schema resolves, but ConnectionError from dead SGLang is caught."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-inference-2",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        payload = {"node_profile": {}, "immutable_matrix": {"tenant_cid": "t1", "session_cid": "s1"}}
        result = await activities.execute_tensor_inference_compute_activity("wf-conn-err", payload, "AgentResponse")

        # Physical ConnectionError from dead port → epistemic_yield
        assert result["status"] == "epistemic_yield"
        assert "node_cid" in result


class TestExecuteMCPToolActivity:
    """Test the MCP tool dispatch path for local WASM sandbox execution."""

    @pytest.mark.asyncio
    async def test_mcp_tool_local_sandbox_path(self) -> None:
        """When no MCP server_cid matches, falls through to local WASM sandbox."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-mcp",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        # Build a physically valid intent payload
        intent_dict = MCPClientIntent.model_construct(
            holographic_projection=None,  # type: ignore[arg-type]
            jsonrpc="2.0",
            method="mcp.ui.emit_intent",
            params={"name": "nonexistent_tool", "arguments": {}},
            id="req-mcp-001",
        ).model_dump(mode="json")

        result = await activities.execute_mcp_tool_io_activity("nonexistent_tool", intent_dict)

        # The sandbox will fail (no WASM binary), but the activity catches it
        assert "receipt" in result
        assert result["receipt"]["success"] is False

    @pytest.mark.asyncio
    async def test_mcp_tool_params_normalization(self) -> None:
        """Payload with non-dict params is normalized to empty dict."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-mcp-norm",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        payload = {
            "jsonrpc": "2.0",
            "method": "mcp.ui.emit_intent",
            "params": "not-a-dict",
            "id": "req-mcp-002",
        }

        result = await activities.execute_mcp_tool_io_activity("some_tool", payload)

        # Should still execute (sandbox path) and return a receipt
        assert "receipt" in result


class TestApplyDefeasibleCascadeActivity:
    """Test the defeasible cascade and rollback activity paths."""

    @pytest.mark.asyncio
    async def test_apply_defeasible_cascade(self) -> None:
        """Exercise the defeasible cascade logic path (L217)."""
        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-cascade",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        # This should execute without raising — the ledger handles missing data gracefully
        await activities.apply_defeasible_cascade_compute_activity("nonexistent-hash")

    @pytest.mark.asyncio
    async def test_execute_rollback(self) -> None:
        """Exercise the rollback logic path (L222) with a valid rollback payload."""
        import types

        activities = KineticActivities(
            sglang_url="http://127.0.0.1:49999",
            memory_path="memory://test-rollback",
            plugins_dir="tests/assets/wasm",
            telemetry_url="http://127.0.0.1:49998",
        )

        # Bootstrap ledger tables so rollback can find tables to operate on
        await activities.ledger.bootstrap()

        # The ledger's execute_rollback uses getattr(), expecting an object not a dict
        rollback_intent = types.SimpleNamespace(
            target_event_cid="node-tainted-001",
            invalidated_node_cids=["node-tainted-001"],
            request_cid="req-rollback-001",
        )
        await activities.ledger.execute_rollback("wf-rollback-001", rollback_intent)
