# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for GRPO Advantage Evaluators.

Tests the complete evaluation pipeline: per-step reward computation,
GRPO baseline normalization, topological bonus application,
token efficiency penalties, Merkle-DAG commitment hashing,
Gold crystallization to LanceDB, and Lean4 premise verification.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: all payloads constructed from coreason_manifest models
and serialized via .model_dump(mode="json").
"""

from typing import Any

import lancedb  # type: ignore[import-untyped]
import pytest
from coreason_manifest.spec.ontology import (
    CognitiveFormatContract,
    CognitiveReasoningTraceState,
    ConstrainedDecodingPolicy,
    EpistemicRewardGradientPolicy,
    FormalLogicPremise,
    TopologicalRewardContract,
)

from coreason_runtime.orchestration.evaluators import (
    compute_grpo_advantage,
    crystallize_reward_receipt,
    evaluate_lean4_premise,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_trace(
    trace_cid: str = "did:coreason:trace-001",
    token_length: int = 500,
    trace_payload: str = "P → Q; Q → R",
    source_proof_cid: str = "did:coreason:proof-001",
) -> CognitiveReasoningTraceState:
    """Construct a physically validated CognitiveReasoningTraceState."""
    return CognitiveReasoningTraceState(
        trace_cid=trace_cid,
        source_proof_cid=source_proof_cid,
        token_length=token_length,
        trace_payload=trace_payload,
    )


def _build_policy(
    beta_path_weight: float = 1.0,
    policy_cid: str = "did:coreason:policy-001",
    reference_graph_cid: str = "did:coreason:graph-001",
) -> EpistemicRewardGradientPolicy:
    """Construct a physically validated EpistemicRewardGradientPolicy."""
    return EpistemicRewardGradientPolicy(
        policy_cid=policy_cid,
        reference_graph_cid=reference_graph_cid,
        format_contract=CognitiveFormatContract(
            require_think_tags=False,
            decoding_policy=ConstrainedDecodingPolicy(
                enforcement_strategy="fsm_logit_mask",
                compiler_backend="urn:coreason:compiler:outlines",
                terminate_on_eos_leak=True,
            ),
        ),
        beta_path_weight=beta_path_weight,
        topological_scoring=TopologicalRewardContract(
            min_edge_criticality_score=0.3,
            min_semantic_relevance_score=0.5,
            aggregation_method="attention_gat",
        ),
    )


def _build_evaluator_trace(
    trace_id: str = "trace-001",
    reasoning_steps: list[dict[str, Any]] | None = None,
    topology_class: str = "linear",
    total_tokens_consumed: int = 500,
) -> dict[str, Any]:
    """Build an evaluator-compatible trace dict from a manifest CognitiveReasoningTraceState.

    The manifest model is instantiated for schema validation, then its fields
    are mapped into the evaluator's expected dict format with additional
    domain-specific keys required by compute_grpo_advantage.
    """
    manifest_trace = _build_trace(
        trace_cid=f"did:coreason:{trace_id}",
        token_length=total_tokens_consumed,
        trace_payload=f"topology={topology_class}",
    )

    return {
        "trace_id": trace_id,
        "trace_cid": manifest_trace.trace_cid,
        "source_proof_cid": manifest_trace.source_proof_cid,
        "reasoning_steps": reasoning_steps or [],
        "topology_class": topology_class,
        "total_tokens_consumed": manifest_trace.token_length,
    }


def _build_evaluator_policy(
    beta_path_weight: float = 1.0,
    min_confidence_threshold: float = 0.5,
    topology_bonus_map: dict[str, float] | None = None,
    token_efficiency_weight: float = 0.1,
    max_token_budget: int = 100000,
) -> dict[str, Any]:
    """Build an evaluator-compatible policy dict from a manifest EpistemicRewardGradientPolicy.

    The manifest model is instantiated for schema validation, then its fields
    are mapped into the evaluator's expected dict format with additional
    domain-specific keys.
    """
    # Manifest enforces beta_path_weight <= 1.0; clamp for validation
    clamped_beta = min(beta_path_weight, 1.0)
    manifest_policy = _build_policy(beta_path_weight=clamped_beta)

    return {
        "policy_cid": manifest_policy.policy_cid,
        "reference_graph_cid": manifest_policy.reference_graph_cid,
        # Pass original beta to evaluator (allows > 1.0); manifest validates rest
        "beta_path_weight": beta_path_weight,
        "min_confidence_threshold": min_confidence_threshold,
        "topology_bonus_map": topology_bonus_map or {"linear": 0.0, "branching": 0.1, "cyclic": -0.05},
        "token_efficiency_weight": token_efficiency_weight,
        "max_token_budget": max_token_budget,
    }


# ── GRPO Advantage Computation Tests ───────────────────────────────────


class TestComputeGrpoAdvantage:
    """Physical tests for the GRPO advantage scoring engine."""

    @pytest.mark.asyncio
    async def test_valid_high_confidence_trace(self) -> None:
        """All steps valid and above confidence threshold → positive advantage."""
        trace = _build_evaluator_trace(
            trace_id="trace-001",
            reasoning_steps=[
                {"axiom": "P → Q", "confidence": 0.9, "is_valid": True},
                {"axiom": "Q → R", "confidence": 0.85, "is_valid": True},
            ],
            topology_class="linear",
            total_tokens_consumed=500,
        )
        policy = _build_evaluator_policy(
            beta_path_weight=1.0,
            token_efficiency_weight=0.1,
            max_token_budget=10000,
        )

        receipt = await compute_grpo_advantage(trace, policy)

        assert receipt["trace_id"] == "trace-001"
        assert receipt["total_steps"] == 2
        assert receipt["topology_class"] == "linear"
        assert receipt["topological_bonus"] == 0.0
        assert receipt["tokens_consumed"] == 500
        assert receipt["policy_beta"] == 1.0
        assert len(receipt["step_rewards"]) == 2
        assert all(r > 0 for r in receipt["step_rewards"])
        assert receipt["merkle_commitment_hash"] is not None
        assert len(receipt["merkle_commitment_hash"]) == 64

    @pytest.mark.asyncio
    async def test_invalid_steps_produce_negative_rewards(self) -> None:
        """Invalid axioms produce negative rewards."""
        trace = _build_evaluator_trace(
            trace_id="trace-002",
            reasoning_steps=[
                {"axiom": "P → ⊥", "confidence": 0.8, "is_valid": False},
                {"axiom": "⊥ → Q", "confidence": 0.7, "is_valid": False},
            ],
            total_tokens_consumed=200,
        )
        policy = _build_evaluator_policy(beta_path_weight=1.0)

        receipt = await compute_grpo_advantage(trace, policy)
        assert all(r < 0 for r in receipt["step_rewards"])

    @pytest.mark.asyncio
    async def test_low_confidence_partial_credit(self) -> None:
        """Valid but low-confidence steps get partial credit (0.5x)."""
        trace = _build_evaluator_trace(
            trace_id="trace-003",
            reasoning_steps=[
                {"axiom": "P → Q", "confidence": 0.3, "is_valid": True},
            ],
            total_tokens_consumed=100,
        )
        policy = _build_evaluator_policy(
            beta_path_weight=2.0,
            min_confidence_threshold=0.5,
        )

        receipt = await compute_grpo_advantage(trace, policy)
        assert receipt["step_rewards"][0] == pytest.approx(0.3, abs=0.01)

    @pytest.mark.asyncio
    async def test_empty_trace_produces_zero_advantage(self) -> None:
        """Empty reasoning trace produces zero advantage score."""
        trace = _build_evaluator_trace(
            trace_id="trace-empty",
            reasoning_steps=[],
            total_tokens_consumed=0,
        )
        policy = _build_evaluator_policy()

        receipt = await compute_grpo_advantage(trace, policy)

        assert receipt["total_steps"] == 0
        assert receipt["raw_advantage"] == 0.0
        assert receipt["normalized_advantage"] == 0.0
        assert receipt["step_rewards"] == []

    @pytest.mark.asyncio
    async def test_branching_topology_bonus(self) -> None:
        """Branching topology receives the configured bonus."""
        trace = _build_evaluator_trace(
            trace_id="trace-branch",
            reasoning_steps=[
                {"axiom": "A", "confidence": 0.9, "is_valid": True},
            ],
            topology_class="branching",
        )
        policy = _build_evaluator_policy(
            topology_bonus_map={"linear": 0.0, "branching": 0.15, "cyclic": -0.1},
        )

        receipt = await compute_grpo_advantage(trace, policy)
        assert receipt["topological_bonus"] == 0.15

    @pytest.mark.asyncio
    async def test_cyclic_topology_penalty(self) -> None:
        """Cyclic topology receives negative bonus (penalty)."""
        trace = _build_evaluator_trace(
            trace_id="trace-cyclic",
            reasoning_steps=[
                {"axiom": "A", "confidence": 0.9, "is_valid": True},
            ],
            topology_class="cyclic",
        )
        policy = _build_evaluator_policy(
            topology_bonus_map={"cyclic": -0.05},
        )

        receipt = await compute_grpo_advantage(trace, policy)
        assert receipt["topological_bonus"] == -0.05

    @pytest.mark.asyncio
    async def test_token_efficiency_penalty(self) -> None:
        """Excessive token consumption produces efficiency penalty."""
        trace = _build_evaluator_trace(
            trace_id="trace-bloated",
            reasoning_steps=[
                {"axiom": "A", "confidence": 0.9, "is_valid": True},
            ],
            total_tokens_consumed=80000,
        )
        policy = _build_evaluator_policy(
            token_efficiency_weight=0.1,
            max_token_budget=100000,
        )

        receipt = await compute_grpo_advantage(trace, policy)
        assert receipt["efficiency_score"] == pytest.approx(0.02, abs=0.001)

    @pytest.mark.asyncio
    async def test_over_budget_efficiency_clamped(self) -> None:
        """Over-budget efficiency is clamped to -1.0 * weight."""
        trace = _build_evaluator_trace(
            trace_id="trace-over",
            reasoning_steps=[
                {"axiom": "A", "confidence": 0.9, "is_valid": True},
            ],
            total_tokens_consumed=500000,
        )
        policy = _build_evaluator_policy(
            token_efficiency_weight=0.2,
            max_token_budget=100000,
        )

        receipt = await compute_grpo_advantage(trace, policy)
        assert receipt["efficiency_score"] == pytest.approx(-0.2, abs=0.001)

    @pytest.mark.asyncio
    async def test_default_policy_values(self) -> None:
        """Verify defaults are applied when policy keys are missing."""
        manifest_policy = _build_policy()
        trace = _build_evaluator_trace(trace_id="trace-defaults")

        # Only pass beta_path_weight from the manifest model
        receipt = await compute_grpo_advantage(
            trace,
            {"beta_path_weight": manifest_policy.beta_path_weight},
        )

        assert receipt["policy_beta"] == manifest_policy.beta_path_weight
        assert receipt["topology_class"] == "linear"
        assert receipt["tokens_consumed"] == 500

    @pytest.mark.asyncio
    async def test_merkle_hash_uniqueness(self) -> None:
        """Each receipt should have a unique merkle commitment hash."""
        trace = _build_evaluator_trace(trace_id="trace-hash")
        policy = _build_evaluator_policy()

        r1 = await compute_grpo_advantage(trace, policy)
        r2 = await compute_grpo_advantage(trace, policy)

        assert r1["merkle_commitment_hash"] != r2["merkle_commitment_hash"]


# ── Gold Crystallization Tests ─────────────────────────────────────────


class TestCrystallizeRewardReceipt:
    """Physical LanceDB crystallization tests for Gold Medallion ledger."""

    @pytest.mark.asyncio
    async def test_crystallize_creates_table(self, tmp_path: Any) -> None:
        """Crystallizing to a new ledger creates the gold_reward_receipts table."""
        db = lancedb.connect(str(tmp_path / "test_ledger"))

        class StubLedger:
            def __init__(self, database: Any) -> None:
                self.db = database

        ledger = StubLedger(db)

        # Build receipt from an evaluator run using manifest-validated trace
        trace = _build_evaluator_trace(
            trace_id="trace-gold-1",
            reasoning_steps=[
                {"axiom": "A → B", "confidence": 0.95, "is_valid": True},
            ],
            topology_class="branching",
            total_tokens_consumed=1500,
        )
        policy = _build_evaluator_policy()
        receipt = await compute_grpo_advantage(trace, policy)

        await crystallize_reward_receipt(receipt, ledger)

        assert "gold_reward_receipts" in db.table_names()
        table = db.open_table("gold_reward_receipts")
        rows = table.to_arrow().to_pylist()
        assert len(rows) == 1
        assert rows[0]["trace_id"] == "trace-gold-1"

    @pytest.mark.asyncio
    async def test_crystallize_appends_to_existing(self, tmp_path: Any) -> None:
        """Subsequent crystallizations append to the existing table."""
        db = lancedb.connect(str(tmp_path / "test_ledger_append"))

        class StubLedger:
            def __init__(self, database: Any) -> None:
                self.db = database

        ledger = StubLedger(db)
        policy = _build_evaluator_policy()

        for i in range(3):
            trace = _build_evaluator_trace(
                trace_id=f"trace-{i}",
                reasoning_steps=[
                    {"axiom": f"A{i}", "confidence": 0.8, "is_valid": True},
                ],
            )
            receipt = await compute_grpo_advantage(trace, policy)
            await crystallize_reward_receipt(receipt, ledger)

        table = db.open_table("gold_reward_receipts")
        rows = table.to_arrow().to_pylist()
        assert len(rows) == 3


# ── Lean4 Premise Verification Tests ──────────────────────────────────


class TestEvaluateLean4Premise:
    """Physical tests for formal Lean4 verification bridge."""

    @pytest.mark.asyncio
    async def test_evaluates_valid_premise(self) -> None:
        """Verify that a valid premise returns a PROVED receipt."""
        premise = FormalLogicPremise(
            dialect_urn="urn:coreason:dialect:lean4",
            formal_statement="theorem foo : True := trivial",
            verification_script="exact trivial",
        )

        receipt = await evaluate_lean4_premise(premise)

        assert receipt.is_proved is True
        assert receipt.event_cid is not None
        assert receipt.timestamp > 0

    @pytest.mark.asyncio
    async def test_premise_without_premise_cid_generates_fallback(self) -> None:
        """Verify fallback CID generation when premise has no premise_cid attr."""
        premise = FormalLogicPremise(
            dialect_urn="urn:coreason:dialect:lean4",
            formal_statement="theorem bar : 1 + 1 = 2 := rfl",
            verification_script="exact rfl",
        )

        receipt = await evaluate_lean4_premise(premise)

        assert receipt.is_proved is True
        assert receipt.timestamp > 0
        assert receipt.event_cid is not None


@pytest.mark.asyncio
async def test_compute_grpo_advantage_empty_trace() -> None:
    # No reasoning steps sets n=0 matching line 109
    trace_dict = _build_evaluator_trace(
        reasoning_steps=[],
        topology_class="linear",
        total_tokens_consumed=500,
    )

    policy_dict = {
        "beta_path_weight": 1.0,
        "topology_bonus_map": {"linear": 0.5},
        "max_token_budget": 1000,  # nosec B105
        "token_efficiency_weight": 0.1,  # nosec B105
    }

    receipt = await compute_grpo_advantage(
        trace=trace_dict,
        policy=policy_dict,
    )

    assert receipt["raw_advantage"] == 0.0
    assert receipt["normalized_advantage"] == 0.0
