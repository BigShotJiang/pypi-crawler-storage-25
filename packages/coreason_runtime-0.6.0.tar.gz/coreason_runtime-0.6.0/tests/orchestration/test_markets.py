# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the Prediction Markets and Auction engine.

Tests: VCG/Vickrey auction resolution, LMSR probability settlement,
LMSR price calculation, and Brier-score-based market settlement.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: AuctionState, AuctionPolicy, PredictionMarketState,
and all constituent models constructed from coreason_manifest.
"""

import pytest
from coreason_manifest import (
    AuctionPolicy,
    AuctionState,
    PredictionMarketState,
)
from coreason_manifest.spec.ontology import (
    AgentBidIntent,
    HypothesisStakeReceipt,
    TaskAnnouncementIntent,
)

from coreason_runtime.orchestration.markets import (
    calculate_lmsr_price,
    resolve_auction,
    settle_market,
    settle_prediction_market,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_announcement(
    task_cid: str = "task-auction-001",
    max_budget: int = 10000,
) -> TaskAnnouncementIntent:
    return TaskAnnouncementIntent(
        task_cid=task_cid,
        max_budget_magnitude=max_budget,
    )


def _build_bid(
    agent_cid: str = "did:coreason:agent-1",
    cost: int = 500,
    confidence: float = 0.9,
    latency: int = 100,
    carbon: float = 5.0,
) -> AgentBidIntent:
    return AgentBidIntent(
        agent_cid=agent_cid,
        estimated_cost_magnitude=cost,
        estimated_latency_ms=latency,
        estimated_carbon_gco2eq=carbon,
        confidence_score=confidence,
    )


def _build_auction_state(
    bids: list[AgentBidIntent] | None = None,
    max_budget: int = 10000,
) -> AuctionState:
    return AuctionState(
        announcement=_build_announcement(max_budget=max_budget),
        bids=bids or [],
        clearing_timeout=5000,
        minimum_tick_size=1,
    )


def _build_auction_policy(
    auction_type: str = "vickrey",
    tie_breaker: str = "lowest_cost",
) -> AuctionPolicy:
    return AuctionPolicy(
        auction_type=auction_type,  # type: ignore[arg-type]
        tie_breaker=tie_breaker,  # type: ignore[arg-type]
        max_bidding_window_ms=30000,
    )


def _build_stake(
    agent_cid: str = "did:coreason:agent-1",
    hypothesis: str = "hyp-A",
    magnitude: int = 100,
    probability: float = 0.5,
) -> HypothesisStakeReceipt:
    return HypothesisStakeReceipt(
        agent_cid=agent_cid,
        target_hypothesis_cid=hypothesis,
        staked_magnitude=magnitude,
        implied_probability=probability,
    )


def _build_market_state(
    stakes: list[HypothesisStakeReceipt] | None = None,
    probabilities: dict[str, str] | None = None,
    b_param: str = "100.0",
) -> PredictionMarketState:
    return PredictionMarketState(
        market_cid="market-001",
        resolution_oracle_condition_cid="oracle-001",
        lmsr_b_parameter=b_param,
        order_book=stakes or [],
        current_market_probabilities=probabilities or {},
    )


# ── Auction Resolution Tests ──────────────────────────────────────────


class TestResolveAuction:
    """Physical tests for VCG/Vickrey auction resolution."""

    def test_single_bid_wins(self) -> None:
        """Single valid bid wins the auction."""
        bid = _build_bid(agent_cid="did:coreason:solo", cost=200, confidence=0.95)
        state = _build_auction_state(bids=[bid])
        policy = _build_auction_policy(auction_type="vickrey")

        receipt = resolve_auction(state, policy)

        assert receipt.task_cid == "task-auction-001"
        assert receipt.cleared_price_magnitude == 200
        assert "did:coreason:solo" in receipt.awarded_syndicate

    def test_highest_confidence_wins(self) -> None:
        """Bid with highest confidence wins when costs differ."""
        bids = [
            _build_bid(agent_cid="did:coreason:low", cost=300, confidence=0.7),
            _build_bid(agent_cid="did:coreason:high", cost=500, confidence=0.95),
        ]
        state = _build_auction_state(bids=bids)
        policy = _build_auction_policy()

        receipt = resolve_auction(state, policy)

        assert "did:coreason:high" in receipt.awarded_syndicate

    def test_vickrey_second_price(self) -> None:
        """Vickrey auction: winner pays second-lowest price."""
        bids = [
            _build_bid(agent_cid="did:coreason:winner", cost=100, confidence=0.9),
            _build_bid(agent_cid="did:coreason:runner-up", cost=300, confidence=0.8),
        ]
        state = _build_auction_state(bids=bids)
        policy = _build_auction_policy(auction_type="vickrey")

        receipt = resolve_auction(state, policy)

        assert receipt.cleared_price_magnitude == 300

    def test_tied_bids_form_syndicate(self) -> None:
        """Tied bids with equal confidence and cost form a syndicate."""
        bids = [
            _build_bid(agent_cid="did:coreason:a", cost=500, confidence=0.9),
            _build_bid(agent_cid="did:coreason:b", cost=500, confidence=0.9),
        ]
        state = _build_auction_state(bids=bids)
        # Use sealed_bid (valid Literal) — non-vickrey so cleared_price = winner cost
        policy = _build_auction_policy(auction_type="sealed_bid")

        receipt = resolve_auction(state, policy)

        assert receipt.escrow.refund_target_node_cid == "syndicate"  # type: ignore[union-attr]
        assert len(receipt.awarded_syndicate) == 2

    def test_no_bids_raises(self) -> None:
        """Empty bid list raises ValueError."""
        state = _build_auction_state(bids=[])
        policy = _build_auction_policy()

        with pytest.raises(ValueError, match="No bids available"):
            resolve_auction(state, policy)

    def test_all_bids_exceed_budget_raises(self) -> None:
        """All bids exceeding budget raises ValueError."""
        bids = [
            _build_bid(agent_cid="did:coreason:expensive", cost=20000, confidence=0.99),
        ]
        state = _build_auction_state(bids=bids, max_budget=10000)
        policy = _build_auction_policy()

        with pytest.raises(ValueError, match="No bids satisfy"):
            resolve_auction(state, policy)

    def test_escrow_matches_cleared_price(self) -> None:
        """Escrow locked magnitude matches the cleared price."""
        bid = _build_bid(cost=750)
        state = _build_auction_state(bids=[bid])
        # Use sealed_bid for non-vickrey single-bid (cleared_price = bid cost)
        policy = _build_auction_policy(auction_type="sealed_bid")

        receipt = resolve_auction(state, policy)

        assert receipt.escrow.escrow_locked_magnitude == receipt.cleared_price_magnitude  # type: ignore[union-attr]
        assert receipt.escrow.release_condition_metric == "ExecutionSuccess"  # type: ignore[union-attr]


# ── LMSR Prediction Market Settlement Tests ───────────────────────────


class TestSettlePredictionMarket:
    """Physical tests for Robin Hanson's LMSR settlement."""

    def test_single_hypothesis_full_probability(self) -> None:
        """Single hypothesis with stakes gets probability 1.0."""
        stakes = [_build_stake(hypothesis="hyp-A", magnitude=100)]
        state = _build_market_state(stakes=stakes)

        result = settle_prediction_market(state)

        assert float(result.current_market_probabilities["hyp-A"]) == pytest.approx(1.0, abs=1e-5)

    def test_two_hypotheses_lmsr_normalization(self) -> None:
        """Two hypotheses normalize to sum=1.0 via LMSR."""
        stakes = [
            _build_stake(hypothesis="hyp-A", magnitude=200),
            _build_stake(hypothesis="hyp-B", magnitude=100),
        ]
        state = _build_market_state(stakes=stakes)

        result = settle_prediction_market(state)

        probs = {k: float(v) for k, v in result.current_market_probabilities.items()}
        assert probs["hyp-A"] > probs["hyp-B"]
        assert sum(probs.values()) == pytest.approx(1.0, abs=1e-5)

    def test_empty_order_book_uniform(self) -> None:
        """Empty order book with existing probabilities returns uniform distribution."""
        state = _build_market_state(
            stakes=[],
            probabilities={"hyp-A": "0.5", "hyp-B": "0.5"},
        )

        result = settle_prediction_market(state)

        probs = {k: float(v) for k, v in result.current_market_probabilities.items()}
        assert probs["hyp-A"] == pytest.approx(0.5, abs=1e-5)

    def test_negative_b_parameter_defaults(self) -> None:
        """Negative b_parameter defaults to 100.0 inside settle logic."""
        # lmsr_b_parameter has pattern ^\d+\.\d+$ — use model_construct to bypass
        stakes = [_build_stake(hypothesis="hyp-A", magnitude=50)]
        state = PredictionMarketState.model_construct(
            market_cid="market-neg-b",
            resolution_oracle_condition_cid="oracle-001",
            lmsr_b_parameter="-1.0",
            order_book=stakes,
            current_market_probabilities={},
        )

        result = settle_prediction_market(state)

        assert "hyp-A" in result.current_market_probabilities

    def test_zero_b_parameter_defaults(self) -> None:
        """Zero b_parameter defaults to 100.0."""
        stakes = [_build_stake(hypothesis="hyp-A", magnitude=50)]
        state = PredictionMarketState.model_construct(
            market_cid="market-zero-b",
            resolution_oracle_condition_cid="oracle-001",
            lmsr_b_parameter="0.0",
            order_book=stakes,
            current_market_probabilities={},
        )

        result = settle_prediction_market(state)

        assert "hyp-A" in result.current_market_probabilities

    def test_unstaked_hypotheses_get_probability(self) -> None:
        """Hypotheses in current_market_probabilities but not in order_book get LMSR probability."""
        stakes = [_build_stake(hypothesis="hyp-A", magnitude=100)]
        state = _build_market_state(
            stakes=stakes,
            probabilities={"hyp-A": "0.5", "hyp-B": "0.5"},
        )

        result = settle_prediction_market(state)

        assert "hyp-B" in result.current_market_probabilities
        assert float(result.current_market_probabilities["hyp-A"]) > float(result.current_market_probabilities["hyp-B"])


# ── LMSR Price Calculation Tests ──────────────────────────────────────


class TestCalculateLmsrPrice:
    """Physical tests for LMSR marginal price computation."""

    def test_equal_shares_equal_price(self) -> None:
        """Equal shares produce equal prices."""
        shares = {"hyp-A": 100, "hyp-B": 100}
        price_a = calculate_lmsr_price(100.0, shares, "hyp-A")
        price_b = calculate_lmsr_price(100.0, shares, "hyp-B")

        assert price_a == pytest.approx(0.5, abs=1e-5)
        assert price_b == pytest.approx(0.5, abs=1e-5)

    def test_higher_shares_higher_price(self) -> None:
        """Hypothesis with more shares has higher LMSR price."""
        shares = {"hyp-A": 200, "hyp-B": 100}
        price_a = calculate_lmsr_price(100.0, shares, "hyp-A")
        price_b = calculate_lmsr_price(100.0, shares, "hyp-B")

        assert price_a > price_b

    def test_missing_hypothesis_returns_zero(self) -> None:
        """Hypothesis not in shares dict returns 0.0."""
        shares = {"hyp-A": 100}
        price = calculate_lmsr_price(100.0, shares, "hyp-missing")

        assert price == 0.0

    def test_negative_b_defaults(self) -> None:
        """Negative b_parameter defaults to 100.0."""
        shares = {"hyp-A": 100, "hyp-B": 100}
        price = calculate_lmsr_price(-5.0, shares, "hyp-A")

        assert price == pytest.approx(0.5, abs=1e-5)

    def test_prices_sum_to_one(self) -> None:
        """All LMSR prices sum to 1.0."""
        shares = {"hyp-A": 150, "hyp-B": 100, "hyp-C": 50}
        total = sum(calculate_lmsr_price(100.0, shares, h) for h in shares)

        assert total == pytest.approx(1.0, abs=1e-5)


# ── Brier-Score Market Settlement Tests ───────────────────────────────


class TestSettleMarket:
    """Physical tests for Brier-score-based escrow settlement."""

    def test_single_correct_agent_gets_all(self) -> None:
        """Single agent staking on the winner gets entire pool."""
        stakes = [_build_stake(agent_cid="did:coreason:alice", hypothesis="hyp-A", magnitude=1000)]
        state = _build_market_state(stakes=stakes)

        receipt = settle_market(state, "hyp-A")

        assert receipt.cleared_price_magnitude == 1000
        assert receipt.awarded_syndicate["did:coreason:alice"] == 1000
        assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude

    def test_two_agents_correct_gets_more(self) -> None:
        """Agent with correct prediction gets more than incorrect predictor."""
        stakes = [
            _build_stake(agent_cid="did:coreason:alice", hypothesis="hyp-A", magnitude=800),
            _build_stake(agent_cid="did:coreason:bob", hypothesis="hyp-B", magnitude=200),
        ]
        state = _build_market_state(stakes=stakes)

        receipt = settle_market(state, "hyp-A")

        assert receipt.awarded_syndicate["did:coreason:alice"] > receipt.awarded_syndicate["did:coreason:bob"]
        assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude

    def test_conservation_of_ledger(self) -> None:
        """Sum of awards == cleared_price_magnitude (remainder-distribution invariant)."""
        stakes = [
            _build_stake(agent_cid="did:coreason:a", hypothesis="hyp-A", magnitude=333),
            _build_stake(agent_cid="did:coreason:b", hypothesis="hyp-A", magnitude=333),
            _build_stake(agent_cid="did:coreason:c", hypothesis="hyp-B", magnitude=334),
        ]
        state = _build_market_state(stakes=stakes)

        receipt = settle_market(state, "hyp-A")

        assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude
        assert receipt.cleared_price_magnitude == 1000

    def test_escrow_bound_to_brier_settlement(self) -> None:
        """Escrow policy uses BrierScoreSettlement metric."""
        stakes = [_build_stake(hypothesis="hyp-A", magnitude=500)]
        state = _build_market_state(stakes=stakes)

        receipt = settle_market(state, "hyp-A")

        assert receipt.escrow.release_condition_metric == "BrierScoreSettlement"  # type: ignore[union-attr]
        assert receipt.escrow.refund_target_node_cid == "hyp-A"  # type: ignore[union-attr]

    def test_empty_order_book_raises(self) -> None:
        """Empty order book raises ValueError."""
        state = _build_market_state(stakes=[])

        with pytest.raises(ValueError, match="No participants"):
            settle_market(state, "hyp-A")

    def test_three_agents_fractional_remainder_distribution(self) -> None:
        """Three agents with odd pool size: remainder-distributing algorithm preserves conservation."""
        stakes = [
            _build_stake(agent_cid="did:coreason:x", hypothesis="hyp-A", magnitude=101),
            _build_stake(agent_cid="did:coreason:y", hypothesis="hyp-B", magnitude=101),
            _build_stake(agent_cid="did:coreason:z", hypothesis="hyp-C", magnitude=101),
        ]
        state = _build_market_state(stakes=stakes)

        receipt = settle_market(state, "hyp-A")

        # Conservation invariant
        assert sum(receipt.awarded_syndicate.values()) == receipt.cleared_price_magnitude
        # Correct predictor gets most
        assert receipt.awarded_syndicate["did:coreason:x"] >= receipt.awarded_syndicate["did:coreason:y"]
        assert receipt.awarded_syndicate["did:coreason:x"] >= receipt.awarded_syndicate["did:coreason:z"]
