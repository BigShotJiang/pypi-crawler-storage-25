# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for Cross-Swarm Federation Handshake.

Tests the bilateral SLA negotiation FSM: LBAC classification clearance,
geographic data residency enforcement, ESG carbon intensity limits,
ontological overlap validation, and phase transition guards.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: FederatedBilateralSLA and CrossSwarmHandshakeState
constructed from coreason_manifest models and serialized via .model_dump(mode="json").
"""

from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CrossSwarmHandshakeState,
    FederatedBilateralSLA,
    SemanticClassificationProfile,
)

from coreason_runtime.orchestration.federation_handshake import (
    negotiate_bilateral_sla,
    validate_handshake_phase_transition,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_manifest_sla(
    receiving_tenant_cid: str = "did:coreason:swarm-remote-42",
    max_class: SemanticClassificationProfile = SemanticClassificationProfile.RESTRICTED,
    permitted_regions: list[str] | None = None,
    max_carbon: float | None = 200.0,
) -> FederatedBilateralSLA:
    """Construct a physically validated FederatedBilateralSLA from the manifest."""
    regions = permitted_regions if permitted_regions is not None else ["US", "EU", "JP"]
    return FederatedBilateralSLA(
        receiving_tenant_cid=receiving_tenant_cid,
        max_permitted_classification=max_class,
        liability_limit_magnitude=1000000,
        permitted_geographic_regions=regions,
        max_permitted_grid_carbon_intensity=max_carbon,
    )


def _build_manifest_handshake(
    initiating: str = "did:coreason:swarm-local",
    receiving: str = "did:coreason:swarm-remote-42",
    status: str = "proposed",
) -> CrossSwarmHandshakeState:
    """Construct a physically validated CrossSwarmHandshakeState from the manifest."""
    sla = _build_manifest_sla(receiving_tenant_cid=receiving)
    return CrossSwarmHandshakeState(
        handshake_cid="did:coreason:hs-test-001",
        initiating_tenant_cid=initiating,
        receiving_tenant_cid=receiving,
        offered_sla=sla,
        status=status,  # type: ignore[arg-type]
    )


def _build_local_sla(**overrides: Any) -> dict[str, Any]:
    """Build a negotiation-compatible local SLA dict from a manifest FederatedBilateralSLA.

    The manifest model is instantiated for schema validation, then its fields
    are mapped into the negotiator's expected dict format with additional
    domain-specific keys required by negotiate_bilateral_sla.
    """
    max_class_map: dict[str, str] = {
        "public": "UNCLASSIFIED",
        "internal": "CUI",
        "confidential": "CONFIDENTIAL",
        "restricted": "SECRET",
    }

    manifest_sla = _build_manifest_sla(
        max_class=overrides.get("manifest_class", SemanticClassificationProfile.RESTRICTED),
        permitted_regions=overrides.get("permitted_geographic_regions"),
        max_carbon=overrides.get("max_permitted_grid_carbon_intensity", 200.0),
    )
    manifest_dump = manifest_sla.model_dump(mode="json")

    classification_str = overrides.get(
        "max_permitted_classification",
        max_class_map.get(manifest_dump["max_permitted_classification"], "SECRET"),
    )

    base: dict[str, Any] = {
        "local_swarm_id": overrides.get("local_swarm_id", "swarm-local"),
        "max_permitted_classification": classification_str,
        "permitted_geographic_regions": manifest_dump["permitted_geographic_regions"],
        "max_permitted_grid_carbon_intensity": manifest_dump["max_permitted_grid_carbon_intensity"],
        "min_ontological_overlap": overrides.get("min_ontological_overlap", 3),
        "max_latency_ms": overrides.get("max_latency_ms", 500.0),
    }
    return base


def _build_remote_beacon(**overrides: Any) -> dict[str, Any]:
    """Build a beacon dict validated via CrossSwarmHandshakeState.

    Instantiates a CrossSwarmHandshakeState to validate the structural
    integrity of the remote peer identity, then builds the beacon dict
    expected by the negotiation function.
    """
    receiving_cid = overrides.get("receiving_cid", "did:coreason:swarm-remote-42")
    handshake = _build_manifest_handshake(receiving=receiving_cid)

    base: dict[str, Any] = {
        "swarm_id": overrides.get("swarm_id", "swarm-remote-42"),
        "receiving_tenant_cid": handshake.receiving_tenant_cid,
        "max_permitted_classification": overrides.get("max_permitted_classification", "CONFIDENTIAL"),
        "geographic_region": overrides.get("geographic_region", "US"),
        "grid_carbon_intensity": overrides.get("grid_carbon_intensity", 120.0),
        "overlap_count": overrides.get("overlap_count", 5),
    }
    return base


# ── Bilateral SLA Negotiation Tests ────────────────────────────────────


class TestNegotiateBilateralSLA:
    """Physical tests for the bilateral SLA negotiation FSM."""

    @pytest.mark.asyncio
    async def test_successful_alignment(self) -> None:
        """All guards pass → handshake aligned."""
        local_sla = _build_local_sla()
        remote_beacon = _build_remote_beacon()

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "aligned"
        assert state["remote_swarm_id"] == "swarm-remote-42"
        assert state["local_swarm_id"] == "swarm-local"
        assert len(state["rejection_reasons"]) == 0
        assert "bilateral_sla" in state
        assert state["bilateral_sla"]["geographic_region"] == "US"
        assert state["bilateral_sla"]["carbon_intensity"] == 120.0
        assert state["elapsed_ms"] >= 0

    @pytest.mark.asyncio
    async def test_reject_lbac_clearance_exceeded(self) -> None:
        """Remote classification exceeds local max → rejected."""
        local_sla = _build_local_sla(
            max_permitted_classification="CONFIDENTIAL",
            manifest_class=SemanticClassificationProfile.CONFIDENTIAL,
        )
        remote_beacon = _build_remote_beacon(max_permitted_classification="TOP_SECRET")

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "rejected"
        assert any("LBAC clearance exceeded" in r for r in state["rejection_reasons"])

    @pytest.mark.asyncio
    async def test_accept_lbac_clearance_within_bounds(self) -> None:
        """Remote classification within local max → aligned."""
        local_sla = _build_local_sla(max_permitted_classification="TOP_SECRET")
        remote_beacon = _build_remote_beacon(max_permitted_classification="SECRET")

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)
        assert state["phase"] == "aligned"

    @pytest.mark.asyncio
    async def test_reject_geographic_residency_violation(self) -> None:
        """Remote region not in permitted list → rejected."""
        local_sla = _build_local_sla(permitted_geographic_regions=["US", "EU"])
        remote_beacon = _build_remote_beacon(geographic_region="CN")

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "rejected"
        assert any("Geographic residency violation" in r for r in state["rejection_reasons"])

    @pytest.mark.asyncio
    async def test_accept_empty_permitted_regions(self) -> None:
        """Empty permitted_geographic_regions means no restriction → aligned."""
        local_sla = _build_local_sla(permitted_geographic_regions=[])
        remote_beacon = _build_remote_beacon(geographic_region="CN")

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)
        assert "Geographic" not in str(state.get("rejection_reasons", []))

    @pytest.mark.asyncio
    async def test_reject_carbon_intensity_exceeded(self) -> None:
        """Remote carbon intensity exceeds local max → rejected."""
        local_sla = _build_local_sla(max_permitted_grid_carbon_intensity=100.0)
        remote_beacon = _build_remote_beacon(grid_carbon_intensity=150.0)

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "rejected"
        assert any("Carbon intensity exceeded" in r for r in state["rejection_reasons"])

    @pytest.mark.asyncio
    async def test_reject_insufficient_ontological_overlap(self) -> None:
        """Remote ontological overlap below minimum → rejected."""
        local_sla = _build_local_sla(min_ontological_overlap=10)
        remote_beacon = _build_remote_beacon(overlap_count=3)

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "rejected"
        assert any("ontological overlap" in r for r in state["rejection_reasons"])

    @pytest.mark.asyncio
    async def test_multiple_rejections_accumulated(self) -> None:
        """Multiple guard failures accumulate all rejection reasons."""
        local_sla = _build_local_sla(
            max_permitted_classification="CUI",
            manifest_class=SemanticClassificationProfile.INTERNAL,
            permitted_geographic_regions=["US"],
            max_permitted_grid_carbon_intensity=50.0,
            min_ontological_overlap=100,
        )
        remote_beacon = _build_remote_beacon(
            max_permitted_classification="TOP_SECRET",
            geographic_region="CN",
            grid_carbon_intensity=200.0,
            overlap_count=1,
        )

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "rejected"
        assert len(state["rejection_reasons"]) == 4

    @pytest.mark.asyncio
    async def test_handshake_id_generated(self) -> None:
        """Each handshake receives a unique ID."""
        local_sla = _build_local_sla()
        remote_beacon = _build_remote_beacon()

        s1 = await negotiate_bilateral_sla(remote_beacon, local_sla)
        s2 = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert s1["handshake_id"] != s2["handshake_id"]
        assert s1["handshake_id"].startswith("hs-")

    @pytest.mark.asyncio
    async def test_effective_classification_is_minimum(self) -> None:
        """Aligned SLA uses the minimum classification level."""
        local_sla = _build_local_sla(max_permitted_classification="TOP_SECRET")
        remote_beacon = _build_remote_beacon(max_permitted_classification="CONFIDENTIAL")

        state = await negotiate_bilateral_sla(remote_beacon, local_sla)

        assert state["phase"] == "aligned"
        assert state["bilateral_sla"]["effective_classification"] == "CONFIDENTIAL"

    @pytest.mark.asyncio
    async def test_default_values_for_missing_keys(self) -> None:
        """Missing keys in beacon/SLA use safe defaults."""
        state = await negotiate_bilateral_sla({}, {})

        assert state["phase"] in {"aligned", "rejected"}
        assert state["remote_swarm_id"] == "unknown"
        assert state["local_swarm_id"] == "self"

    @pytest.mark.asyncio
    async def test_timestamp_tracking(self) -> None:
        """Handshake tracks start/complete timestamps and elapsed time."""
        state = await negotiate_bilateral_sla(
            _build_remote_beacon(),
            _build_local_sla(),
        )

        assert "started_at_ns" in state
        assert "completed_at_ns" in state
        assert state["completed_at_ns"] >= state["started_at_ns"]
        assert state["elapsed_ms"] >= 0


# ── Phase Transition Validation Tests ──────────────────────────────────


class TestValidateHandshakePhaseTransition:
    """Physical tests for the FSM phase transition guards."""

    def test_proposed_to_negotiating_allowed(self) -> None:
        assert validate_handshake_phase_transition("proposed", "negotiating") is True

    def test_negotiating_to_aligned_allowed(self) -> None:
        assert validate_handshake_phase_transition("negotiating", "aligned") is True

    def test_negotiating_to_rejected_allowed(self) -> None:
        assert validate_handshake_phase_transition("negotiating", "rejected") is True

    def test_proposed_to_aligned_forbidden(self) -> None:
        assert validate_handshake_phase_transition("proposed", "aligned") is False

    def test_proposed_to_rejected_forbidden(self) -> None:
        assert validate_handshake_phase_transition("proposed", "rejected") is False

    def test_aligned_to_anything_forbidden(self) -> None:
        assert validate_handshake_phase_transition("aligned", "negotiating") is False
        assert validate_handshake_phase_transition("aligned", "rejected") is False

    def test_rejected_to_anything_forbidden(self) -> None:
        assert validate_handshake_phase_transition("rejected", "negotiating") is False
        assert validate_handshake_phase_transition("rejected", "aligned") is False
