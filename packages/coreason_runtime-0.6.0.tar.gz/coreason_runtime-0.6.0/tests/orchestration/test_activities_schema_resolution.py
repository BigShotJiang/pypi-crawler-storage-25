# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for the schema resolution pathway in activities.py.

Tests the pure-function `resolve_schema_class` which handles:
1. Direct manifest ontology lookup
2. Dynamic Pydantic model creation from domain_extensions
3. AgentResponse / VerificationYield fallback schemas
4. ValueError for unknown schema names

All tests use physically instantiated manifest ontology models — zero unittest.mock.
"""

import pydantic
import pytest
from coreason_manifest.spec.ontology import ExecutionNodeReceipt

from coreason_runtime.orchestration.activities import resolve_schema_class


class TestResolveSchemaClass:
    """Physical tests for deterministic schema resolution."""

    def test_known_manifest_schema_resolves(self) -> None:
        """Known schema name in coreason_manifest.spec.ontology resolves directly."""
        cls = resolve_schema_class("ExecutionNodeReceipt")
        assert cls is ExecutionNodeReceipt

    def test_multiple_manifest_schemas_resolve(self) -> None:
        """Multiple known manifest schemas resolve correctly."""
        from coreason_manifest.spec.ontology import (
            CognitiveAgentNodeProfile,
            TokenBurnReceipt,
        )

        assert resolve_schema_class("CognitiveAgentNodeProfile") is CognitiveAgentNodeProfile
        assert resolve_schema_class("TokenBurnReceipt") is TokenBurnReceipt

    def test_domain_extensions_creates_dynamic_model(self) -> None:
        """Schema from domain_extensions dict creates a dynamic Pydantic model."""
        extensions = {
            "CustomAnalysis": {
                "summary": "A text summary of the analysis",
                "is_valid": "Boolean flag indicating validity",
            }
        }

        cls = resolve_schema_class("CustomAnalysis", domain_extensions=extensions)

        assert issubclass(cls, pydantic.BaseModel)
        assert "summary" in cls.model_fields
        assert "is_valid" in cls.model_fields

    def test_domain_extensions_boolean_detection(self) -> None:
        """Fields starting with 'boolean' are typed as bool."""
        extensions = {
            "BoolTest": {
                "flag": "boolean value",
                "name": "string value",
            }
        }

        cls = resolve_schema_class("BoolTest", domain_extensions=extensions)

        # Verify we can instantiate with correct types
        instance = cls(flag=True, name="test")
        assert instance.flag is True
        assert instance.name == "test"

    def test_agent_response_fallback(self) -> None:
        """AgentResponse fallback creates a model with 'output' field."""
        cls = resolve_schema_class("AgentResponse")

        assert issubclass(cls, pydantic.BaseModel)
        assert "output" in cls.model_fields

        instance = cls(output="Hello world")
        assert instance.output == "Hello world"  # type: ignore[attr-defined]

    def test_verification_yield_fallback(self) -> None:
        """VerificationYield fallback creates success+justification model."""
        cls = resolve_schema_class("VerificationYield")

        assert issubclass(cls, pydantic.BaseModel)
        assert "success" in cls.model_fields
        assert "justification" in cls.model_fields

        instance = cls(success=True, justification="All checks passed")
        assert instance.success is True  # type: ignore[attr-defined]

    def test_unknown_schema_raises_value_error(self) -> None:
        """Unknown schema name without fallback raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("CompletelyUnknownSchema")

    def test_unknown_schema_with_empty_extensions_raises(self) -> None:
        """Unknown schema name with empty domain_extensions raises ValueError."""
        with pytest.raises(ValueError, match="not found"):
            resolve_schema_class("MissingSchema", domain_extensions={})

    def test_domain_extensions_takes_priority_over_fallback(self) -> None:
        """When schema name is in domain_extensions, it takes priority over fallback."""
        extensions = {
            "AgentResponse": {
                "custom_output": "Custom agent output field",
            }
        }

        cls = resolve_schema_class("AgentResponse", domain_extensions=extensions)

        # Should have the custom field, not the fallback 'output' field
        assert "custom_output" in cls.model_fields  # type: ignore[attr-defined]
