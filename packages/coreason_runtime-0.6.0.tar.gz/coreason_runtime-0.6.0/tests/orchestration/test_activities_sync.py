# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.orchestration.activities import KineticActivities


@pytest.mark.asyncio
async def test_execute_mcp_tool_state_sync_success() -> None:
    """Test 1: Mock sandbox to return success=True. Assert returned system_state has updated trace & budget."""
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    # Mock sandbox and telemetry
    receipt = {"success": True, "intent_hash": "test"}
    activities.sandbox.execute_actuator = AsyncMock(return_value=receipt)  # type: ignore[method-assign]
    activities.telemetry.emit_event = MagicMock()  # type: ignore[method-assign]

    payload = {
        "jsonrpc": "2.0",
        "method": "mcp.ui.emit_intent",
        "params": {
            "name": "test_tool",
            "arguments": {},
        },
        "kinetic_trace": ["previous_tool"],
        "remaining_budget": 100.0,
    }

    # Execute via patch to bypass coreason_manifest TypeError with string le parameter
    with patch("coreason_runtime.orchestration.activities.MCPClientIntent") as mock_intent_class:
        mock_intent_class.model_validate.return_value.params = payload["params"]
        result = await activities.execute_mcp_tool_io_activity("test_tool", payload)

    # Evaluate
    assert result["system_state"]["kinetic_trace"] == ["previous_tool", "test_tool"]
    assert result["system_state"]["remaining_budget"] == 100.0


@pytest.mark.asyncio
async def test_execute_mcp_tool_state_sync_failure() -> None:
    """Test 2: Mock sandbox to return success=False. Assert returned system_state has original budget & trace."""
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    # Mock sandbox and telemetry for a failed WASM/tool trap
    receipt = {"success": False, "intent_hash": "test", "error": "failed trap"}
    activities.sandbox.execute_actuator = AsyncMock(return_value=receipt)  # type: ignore[method-assign]
    activities.telemetry.emit_event = MagicMock()  # type: ignore[method-assign]

    payload = {
        "jsonrpc": "2.0",
        "method": "mcp.ui.emit_intent",
        "params": {
            "name": "next_tool",
            "arguments": {},
        },
        "kinetic_trace": ["previous_tool"],
        "remaining_budget": 50.0,
    }

    # Mock Agent Profile that modifies budget via Enforcer
    # We bypass actual Enforcer by not passing agent_profile_payload, or we can just pass none and see if defaults fail
    # Since Final budget = current budget if no profile is provided, the test is isolated to execute logic.

    # Execute via patch to bypass coreason_manifest TypeError with string le parameter
    with patch("coreason_runtime.orchestration.activities.MCPClientIntent") as mock_intent_class:
        mock_intent_class.model_validate.return_value.params = payload["params"]
        result = await activities.execute_mcp_tool_io_activity("next_tool", payload)

    # Evaluate (Zero-Trust Physics: trace and budget should remain unchanged!)
    assert result["system_state"]["kinetic_trace"] == ["previous_tool"]
    assert result["system_state"]["remaining_budget"] == 50.0


@pytest.mark.asyncio
async def test_execute_system_function_security_violation() -> None:
    """Test 3: Assert native host execution (subprocess/python) is securely rejected."""
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    # Subprocess execution rejected
    payload_subprocess = {"domain_extensions": {"execution_type": "subprocess", "command": "ls -l"}}

    # We test the value error is successfully trapped inside the Sandbox receipt
    result_sub = activities.execute_system_function_compute_activity(payload_subprocess)
    assert result_sub["success"] is False
    assert (
        "Security Violation: Native execution is strictly prohibited. "
        "All kinetic actions must operate inside the Zero-Trust WASM Sandbox." in result_sub["data"]
    )

    # Python execution rejected
    payload_python = {"domain_extensions": {"execution_type": "python", "script": "print('hello')"}}

    result_py = activities.execute_system_function_compute_activity(payload_python)
    assert result_py["success"] is False
    assert (
        "Security Violation: Native execution is strictly prohibited. "
        "All kinetic actions must operate inside the Zero-Trust WASM Sandbox." in result_py["data"]
    )


@pytest.mark.asyncio
async def test_execute_mcp_tool_invalid_intent() -> None:
    """Test 4: Assert invalid payload is handled gracefully and returns a failed receipt."""
    activities = KineticActivities(
        sglang_url="http://dummy", memory_path="memory://test", plugins_dir="mock_dir", telemetry_url="http://dummy"
    )

    invalid_payload = {
        "jsonrpc": "2.0",
        # missing method attribute
        "params": {},
    }

    # The source uses model_construct (no validation), so it won't raise ManifestConformanceError.
    # Instead it proceeds to sandbox execution which will fail and return a failure receipt.
    result = await activities.execute_mcp_tool_io_activity("test_tool", invalid_payload)
    assert result["receipt"]["success"] is False
