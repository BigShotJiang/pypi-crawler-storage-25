# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Tests for CoreasonRuntime engine: initialization, manifest validation, registry wiring.

Exercises the pure-function paths of the engine without requiring a live Temporal cluster.
Tests that DO require Temporal use WorkflowEnvironment.start_time_skipping().

Zero unittest.mock. Zero respx. All payloads instantiated via manifest Type Isomorphism.
"""

import json
import tempfile
from typing import Any

import pytest
from coreason_manifest import (
    DAGTopologyManifest,
    WorkflowManifest,
)
from coreason_manifest.spec.ontology import (
    CognitiveAgentNodeProfile,
    DerivationModeProfile,
    EpistemicProvenanceReceipt,
)

from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY, CoreasonRuntime, _get_manifest_key

# ── _get_manifest_key Tests ───────────────────────────────────────


class TestGetManifestKey:
    """Test the manifest key resolution helper."""

    def test_dag_topology_key(self) -> None:
        key = _get_manifest_key(DAGTopologyManifest)
        assert isinstance(key, str)
        assert len(key) > 0

    def test_registry_covers_all_known_topologies(self) -> None:
        """Verify the workflow registry has entries."""
        assert len(_WORKFLOW_REGISTRY) >= 10, f"Registry only has {len(_WORKFLOW_REGISTRY)} entries"


# ── CoreasonRuntime Init Tests ────────────────────────────────────


class TestCoreasonRuntimeInit:
    """Test engine initialization without connecting to Temporal."""

    def test_default_init(self) -> None:
        runtime = CoreasonRuntime()
        assert runtime.temporal_host == "localhost:7233"
        assert runtime.sglang_url == "http://localhost:30000"
        assert runtime.memory_path == "./lancedb_store"
        assert runtime._client is None

    def test_custom_init(self) -> None:
        runtime = CoreasonRuntime(
            temporal_host="temporal.example.com:7233",
            sglang_url="http://sglang.local:30001",
            memory_path="/data/lance",
        )
        assert runtime.temporal_host == "temporal.example.com:7233"
        assert runtime.sglang_url == "http://sglang.local:30001"
        assert runtime.memory_path == "/data/lance"


# ── Manifest Validation Tests ─────────────────────────────────────


class TestManifestValidation:
    """Test manifest validation and edge-list tuple conversion."""

    def _build_valid_manifest_dict(self) -> dict[str, Any]:
        """Build a minimal valid WorkflowManifest dictionary."""
        dag = DAGTopologyManifest(
            topology_class="dag",
            max_depth=10,
            max_fan_out=5,
            nodes={
                "did:coreason:node-alpha": CognitiveAgentNodeProfile(
                    topology_class="agent",
                    description="Test agent node.",
                ),
            },
            edges=[],
        )
        provenance = EpistemicProvenanceReceipt(
            extracted_by="did:coreason:test-user",
            source_event_cid="test-session-001",
            derivation_mode=DerivationModeProfile.DIRECT_TRANSLATION,
        )
        manifest = WorkflowManifest(
            manifest_version="1.0.0",
            tenant_cid="test-tenant",
            session_cid="test-session",
            topology=dag,
            genesis_provenance=provenance,
        )
        return manifest.model_dump(mode="json")

    def test_valid_manifest_parses(self) -> None:
        """A valid manifest dict should parse without errors."""
        data = self._build_valid_manifest_dict()
        # strict=False allows enum string → instance coercion during round-trip
        manifest = WorkflowManifest.model_validate(data, strict=False)
        assert manifest.tenant_cid == "test-tenant"

    def test_edge_list_normalization(self) -> None:
        """Edge lists should be convertible to tuples."""
        data = self._build_valid_manifest_dict()
        data["topology"]["edges"] = [["node-a", "node-b"]]
        topology = data["topology"]
        topology["edges"] = [tuple(e) if isinstance(e, list) else e for e in topology["edges"]]
        assert topology["edges"] == [("node-a", "node-b")]

    @pytest.mark.asyncio
    async def test_execute_from_dict_without_connection_auto_connects(self) -> None:
        """execute_from_dict without a client should auto-connect (and fail for no Temporal)."""
        runtime = CoreasonRuntime(temporal_host="127.0.0.1:49999")
        data = self._build_valid_manifest_dict()

        # This will fail with ConnectionRefusedError since no Temporal is running
        with pytest.raises(Exception):  # noqa: B017
            await runtime.execute_from_dict(data)

    @pytest.mark.asyncio
    async def test_execute_invalid_manifest_raises(self) -> None:
        """Invalid manifest dict raises ManifestConformanceError."""
        from coreason_runtime.utils.exceptions import ManifestConformanceError

        runtime = CoreasonRuntime(temporal_host="127.0.0.1:49999")
        invalid_data: dict[str, Any] = {"topology": {"type": "invalid"}}

        with pytest.raises((ManifestConformanceError, Exception)):
            await runtime.execute_from_dict(invalid_data)


# ── File-based Execution Tests ────────────────────────────────────


class TestExecuteFromFile:
    """Test the file-based manifest execution path."""

    @pytest.mark.asyncio
    async def test_execute_missing_file_raises(self) -> None:
        """Missing manifest file raises FileNotFoundError."""
        runtime = CoreasonRuntime(temporal_host="127.0.0.1:49999")
        with pytest.raises(FileNotFoundError):
            await runtime.execute("/nonexistent/path/to/manifest.json")

    @pytest.mark.asyncio
    async def test_execute_invalid_json_raises(self) -> None:
        """Invalid JSON file raises JSONDecodeError."""
        runtime = CoreasonRuntime(temporal_host="127.0.0.1:49999")
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
            f.write("not valid json {{{")
            f.flush()
            with pytest.raises(json.JSONDecodeError):
                await runtime.execute(f.name)
