# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from pathlib import Path
from unittest.mock import patch

import extism  # type: ignore
import pytest
from coreason_manifest.spec.ontology import ExecutionNodeReceipt, MCPClientIntent
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from coreason_runtime.sandbox.wasm_enclave import ExtismWasmEnclave
from coreason_runtime.utils.exceptions import ManifestConformanceError


@pytest.fixture
def test_wasm_path(tmp_path: Path) -> Path:
    p = tmp_path / "test.wasm"
    p.write_bytes(b"\x00asm\x01\x00\x00\x00")
    return p


@pytest.fixture
def mock_mcp_intent() -> MCPClientIntent:
    """Returns a mock strict intent payload conforming to Manifest."""
    return MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        params={},
        id="request-id-123",
        holographic_projection=None,  # type: ignore[arg-type]
    )


@pytest.fixture
def mock_receipt() -> ExecutionNodeReceipt:
    return ExecutionNodeReceipt.model_construct(
        request_cid="cid1",
        parent_request_cid="cid2",
        root_request_cid="cid3",
        inputs={},
        outputs={},
        parent_hashes=[],
        node_hash="0000000000000000000000000000000000000000000000000000000000000000",
    )


def test_initialize_plugin(test_wasm_path: Path) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        enclave.initialize_plugin(test_wasm_path)
        mock_plugin.assert_called_once()
        assert enclave.plugin is not None


@pytest.mark.asyncio
async def test_execute_intent_success(
    test_wasm_path: Path, mock_mcp_intent: MCPClientIntent, mock_receipt: ExecutionNodeReceipt
) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Mock Extism to return raw JSON byte dump for Receipt
        mock_plugin_instance.call.return_value = mock_receipt.model_dump_json().encode("utf-8")

        enclave.initialize_plugin(test_wasm_path)

        # Test Execution
        receipt = enclave.execute_intent("invoke_agent", mock_mcp_intent)
        assert isinstance(receipt, ExecutionNodeReceipt)
        assert receipt.request_cid == "cid1"
        mock_plugin_instance.call.assert_called_once_with(
            "invoke_agent", mock_mcp_intent.model_dump_json().encode("utf-8")
        )


@pytest.mark.asyncio
async def test_execute_intent_extism_trap(test_wasm_path: Path, mock_mcp_intent: MCPClientIntent) -> None:
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value
        # Trigger Extism trap
        mock_plugin_instance.call.side_effect = extism.Error("memory access out of bounds")

        enclave.initialize_plugin(test_wasm_path)

        # Test Catching
        with pytest.raises(ManifestConformanceError, match="Extism execution trap"):
            enclave.execute_intent("invoke_agent", mock_mcp_intent)


@settings(max_examples=50, suppress_health_check=[HealthCheck.function_scoped_fixture])
@given(dirty_payload=st.binary())
@pytest.mark.asyncio
async def test_execute_intent_dirty_payload(
    test_wasm_path: Path, mock_mcp_intent: MCPClientIntent, dirty_payload: bytes
) -> None:
    """AGENT INSTRUCTION: Generative fuzzing of zero-trust Extism plugin returns.
    Ensures that any malformed byte array (JSON bombs, Null bytes) safely causes a ManifestConformanceError
    and never crashes the host orchestrator process via Pydantic or UTF-8 decode exceptions.
    """
    enclave = ExtismWasmEnclave()
    with patch("coreason_runtime.sandbox.wasm_enclave.extism.Plugin") as mock_plugin:
        mock_plugin_instance = mock_plugin.return_value

        # Plugin returns dirty/garbage binary data
        mock_plugin_instance.call.return_value = dirty_payload

        enclave.initialize_plugin(test_wasm_path)

        with pytest.raises(ManifestConformanceError):
            # This must trap purely into a ManifestConformanceError (Schema or decode violation)
            enclave.execute_intent("invoke_agent", mock_mcp_intent)
