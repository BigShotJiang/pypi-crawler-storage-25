# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import pytest
from hypothesis import given
from hypothesis import strategies as st

from coreason_runtime.sandbox.security import LatticeReferenceMonitor, TaintLevel
from coreason_runtime.utils.exceptions import SecurityViolationError


@given(
    thread_taint=st.sampled_from(list(TaintLevel)),
    sink_clearance=st.sampled_from(list(TaintLevel)),
)
def test_bell_lapadula_no_write_down(thread_taint: TaintLevel, sink_clearance: TaintLevel) -> None:
    """AGENT INSTRUCTION: Fuzz test verifying the No Write Down Bell-LaPadula axiom."""
    if thread_taint.value > sink_clearance.value:
        with pytest.raises(SecurityViolationError):
            LatticeReferenceMonitor.verify_write_down(thread_taint, sink_clearance)
    else:
        # Should not raise
        LatticeReferenceMonitor.verify_write_down(thread_taint, sink_clearance)


@given(
    current_taint=st.sampled_from(list(TaintLevel)),
    payload_taint=st.sampled_from(list(TaintLevel)),
)
def test_elevate_taint_monotonically_increasing(current_taint: TaintLevel, payload_taint: TaintLevel) -> None:
    """AGENT INSTRUCTION: Test verify taint elevation strictly obeys lattice supremum."""
    elevated = LatticeReferenceMonitor.elevate_taint(current_taint, payload_taint)
    assert elevated.value >= current_taint.value
    assert elevated.value >= payload_taint.value
    assert elevated.value == max(current_taint.value, payload_taint.value)
