# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json

from coreason_manifest import MCPClientIntent

from coreason_runtime.sandbox.io import decode_wasm_output, serialize_intent


def test_serialize_intent() -> None:
    intent = MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        id="123",
        params={"key": "value"},
        holographic_projection=None,  # type: ignore[arg-type]
    )
    result = serialize_intent(intent)

    assert isinstance(result, bytes)
    decoded = json.loads(result.decode("utf-8"))
    assert decoded["jsonrpc"] == "2.0"
    assert decoded["method"] == "mcp.ui.emit_intent"
    assert decoded["id"] == "123"
    assert decoded["params"] == {"key": "value"}


def test_serialize_intent_dict() -> None:
    intent = {"jsonrpc": "2.0", "method": "test"}
    result = serialize_intent(intent)
    assert isinstance(result, bytes)
    decoded = json.loads(result.decode("utf-8"))
    assert decoded["jsonrpc"] == "2.0"
    assert decoded["method"] == "test"


def test_serialize_intent_fallback() -> None:
    # Pass an object that doesn't have model_dump and isn't a dict
    result = serialize_intent(["not_a_dict"])
    assert isinstance(result, bytes)
    decoded = json.loads(result.decode("utf-8"))
    assert decoded == {}


def test_decode_wasm_output_success() -> None:
    raw = b'{"request_cid": "test1", "inputs": {"a": 1}, "outputs": {"b": 2}}'
    parsed = decode_wasm_output(raw)
    assert isinstance(parsed, dict)
    assert parsed["request_cid"] == "test1"


def test_decode_wasm_output_non_dict_json() -> None:
    raw = b'"just a string json"'
    parsed = decode_wasm_output(raw)
    assert parsed == '"just a string json"'


def test_decode_wasm_output_invalid_json() -> None:
    raw = b"not json"
    parsed = decode_wasm_output(raw)
    assert parsed == "not json"


def test_decode_wasm_output_invalid_utf8() -> None:
    raw = b"\x80\x81\x82"
    parsed = decode_wasm_output(raw)
    assert isinstance(parsed, str)
    assert "\ufffd" in parsed
