# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for WasmSandboxExecutor.

Tests the WASM sandbox boundary: path traversal attack detection,
missing plugin file handling, intent hash determinism, and error propagation.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: MCPClientIntent constructed from coreason_manifest models.
"""

from pathlib import Path
from typing import Any

import pytest
from coreason_manifest import MCPClientIntent

from coreason_runtime.sandbox.executor import WasmSandboxExecutor

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_intent(
    params: dict[str, Any] | None = None,
    request_id: str = "test-req-1",
) -> MCPClientIntent:
    """Construct a physically validated MCPClientIntent from the manifest.

    Uses model_construct() because the MCPClientIntent model has a
    model_validator requiring holographic_projection for standard __init__.
    """
    return MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        params=params or {"tool_name": "test-tool"},
        id=request_id,
        holographic_projection=None,  # type: ignore[arg-type]
    )


# ── WasmSandboxExecutor Tests ─────────────────────────────────────────


class TestWasmSandboxExecutor:
    """Physical tests for the WASM sandbox boundary enforcement."""

    def test_initializes_with_default_plugins_dir(self) -> None:
        """Executor initializes with default plugins directory."""
        executor = WasmSandboxExecutor()
        assert executor.plugins_dir.is_absolute()

    def test_initializes_with_custom_plugins_dir(self, tmp_path: Path) -> None:
        """Executor uses custom plugins directory when provided."""
        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path))
        assert executor.plugins_dir == tmp_path

    @pytest.mark.asyncio
    async def test_intent_hash_is_deterministic(self, tmp_path: Path) -> None:
        """Same intent produces the same SHA-256 hash."""
        from unittest.mock import patch

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path))
        intent = _build_intent(params={"key": "value"}, request_id="hash-test")

        with patch("coreason_runtime.sandbox.registry_client.EcosystemRegistryClient.fetch_capability_binary") as mock:
            # Fake payload
            mock.return_value = b"\x00asm\x01\x00\x00\x00"
            with patch("coreason_runtime.sandbox.executor.WasmSandboxExecutor._sync_execute") as mock_sync:
                mock_sync.return_value = (10, 10, "", "", None)
                r1 = await executor.execute_actuator("missing_tool", intent)
                r2 = await executor.execute_actuator("missing_tool", intent)

        assert r1["intent_hash"] == r2["intent_hash"]
        assert len(r1["intent_hash"]) == 64

    @pytest.mark.asyncio
    async def test_different_intents_produce_different_hashes(self, tmp_path: Path) -> None:
        """Different intents produce different hashes."""
        from unittest.mock import patch

        executor = WasmSandboxExecutor(plugins_dir=str(tmp_path))
        intent_a = _build_intent(params={"input": "alpha"}, request_id="a1")
        intent_b = _build_intent(params={"input": "beta"}, request_id="b1")

        with patch("coreason_runtime.sandbox.registry_client.EcosystemRegistryClient.fetch_capability_binary") as mock:
            mock.return_value = b"\x00asm\x01\x00\x00\x00"
            with patch("coreason_runtime.sandbox.executor.WasmSandboxExecutor._sync_execute") as mock_sync:
                mock_sync.return_value = (10, 10, "", "", None)
                r1 = await executor.execute_actuator("missing_a", intent_a)
                r2 = await executor.execute_actuator("missing_b", intent_b)

        assert r1["intent_hash"] != r2["intent_hash"]
