# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for WasmSandboxExecutor execution paths.

Tests the WASM execution boundary using precompiled .wasm binaries in
tests/assets/wasm/. All tests physically instantiate Extism plugins —
zero unittest.mock usage enforced.
"""

from pathlib import Path
from typing import Any

import httpx
import pytest
from coreason_manifest import MCPClientIntent
from fastapi import FastAPI, Response

from coreason_runtime.sandbox.executor import WasmSandboxExecutor
from coreason_runtime.sandbox.registry_client import EcosystemRegistryClient

# ── Physical WASM fixture paths ──────────────────────────────────────

WASM_ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets" / "wasm"
VALID_RETURN_WASM = WASM_ASSETS_DIR / "valid_return.wasm"
INFINITE_LOOP_WASM = WASM_ASSETS_DIR / "infinite_loop.wasm"
MALICIOUS_MEMORY_WASM = WASM_ASSETS_DIR / "malicious_memory.wasm"


def _build_intent(
    params: dict[str, Any] | None = None,
    request_id: str = "physical-req-1",
) -> MCPClientIntent:
    """Construct a physically validated MCPClientIntent from the manifest."""
    return MCPClientIntent.model_construct(
        jsonrpc="2.0",
        method="mcp.ui.emit_intent",
        params=params or {"tool_name": "test-tool"},
        id=request_id,
        holographic_projection=None,  # type: ignore[arg-type]
    )


# ── Mock Registry Setup ──────────────────────────────────────────────


def _get_app() -> FastAPI:
    app = FastAPI()

    @app.get("/api/v1/registry/capabilities/{urn}/download")
    async def download_wasm(urn: str) -> Response:
        wasm_path = WASM_ASSETS_DIR / f"{urn}.wasm"
        if not wasm_path.exists():
            return Response(status_code=404)
        return Response(content=wasm_path.read_bytes(), media_type="application/wasm")

    return app


@pytest.fixture
def registry_client() -> EcosystemRegistryClient:
    transport = httpx.ASGITransport(app=_get_app())
    return EcosystemRegistryClient(transport=transport)


# ── execute_actuator Physical Tests ──────────────────────────────────────


class TestExecuteToolValidReturn:
    """Tests the physical execution path for a valid WASM binary."""

    def test_valid_return_wasm_exists(self) -> None:
        """Verify the compiled fixture exists on disk."""
        assert VALID_RETURN_WASM.exists(), f"Missing fixture: {VALID_RETURN_WASM}"

    @pytest.mark.asyncio
    async def test_execute_actuator_success_path(self, registry_client: EcosystemRegistryClient) -> None:
        """execute_actuator returns success == True and populates telemetry on valid WASM."""
        executor = WasmSandboxExecutor(plugins_dir=str(WASM_ASSETS_DIR), registry_client=registry_client)
        intent = _build_intent()

        result = await executor.execute_actuator("valid_return", intent)

        assert result["success"] is True
        assert "output" in result

        # Verify telemetry is populated
        assert "telemetry" in result
        assert result["telemetry"]["latency_ns"] > 0
        assert result["telemetry"]["peak_memory_bytes"] > 0

        # Ensure intent hash exists
        assert result["intent_hash"]
        assert len(result["intent_hash"]) == 64


class TestExecuteToolInfiniteLoop:
    """Tests the physical trap absorption for infinite_loop WASM."""

    def test_infinite_loop_wasm_exists(self) -> None:
        """Verify the compiled fixture exists on disk."""
        assert INFINITE_LOOP_WASM.exists(), f"Missing fixture: {INFINITE_LOOP_WASM}"

    @pytest.mark.asyncio
    async def test_execute_actuator_absorbs_infinite_loop(self, registry_client: EcosystemRegistryClient) -> None:
        """execute_actuator safely absorbs the uncatchable hardware trap without panicking."""
        executor = WasmSandboxExecutor(plugins_dir=str(WASM_ASSETS_DIR), registry_client=registry_client)
        intent = _build_intent()

        result = await executor.execute_actuator("infinite_loop", intent)

        assert result["success"] is False
        assert "error" in result
        assert "WASM Trap" in result["error"] or "Sandbox Error" in result["error"]


class TestExecuteToolMaliciousMemory:
    """Tests the physical trap absorption for memory tampering."""

    def test_malicious_memory_wasm_exists(self) -> None:
        """Verify the compiled fixture exists on disk."""
        assert MALICIOUS_MEMORY_WASM.exists(), f"Missing fixture: {MALICIOUS_MEMORY_WASM}"

    @pytest.mark.asyncio
    async def test_execute_actuator_absorbs_oob_memory(self, registry_client: EcosystemRegistryClient) -> None:
        """execute_actuator safely absorbs OOB pointer dereference without panicking."""
        executor = WasmSandboxExecutor(plugins_dir=str(WASM_ASSETS_DIR), registry_client=registry_client)
        intent = _build_intent()

        result = await executor.execute_actuator("malicious_memory", intent)

        assert result["success"] is False
        assert "error" in result
        assert "WASM Trap" in result["error"] or "Sandbox Error" in result["error"]
