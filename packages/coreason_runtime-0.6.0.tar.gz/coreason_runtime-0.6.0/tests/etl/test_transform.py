# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import warnings
from typing import Any

import pytest

# Suppress Hypothesis warnings about polars support if it appears
warnings.filterwarnings("ignore", category=UserWarning, module="hypothesis")

# Ignore Polars SchemaWarning
from hypothesis.errors import HypothesisWarning

warnings.filterwarnings("ignore", category=HypothesisWarning)
warnings.filterwarnings("ignore", category=UserWarning, module="polars")

import polars as pl
from hypothesis import given, settings
from hypothesis import strategies as st

from coreason_runtime.etl.transform import InvalidSchemaYieldError, PolarsSilverGate, process_medallion_pipeline

# Base primitive strategy for string fields
string_strategy = st.text(alphabet=st.characters(exclude_categories=["Cc", "Cs"]), min_size=1, max_size=50).map(
    lambda x: x.strip()
)


@st.composite
def dirty_telemetry_generator(draw: Any) -> pl.DataFrame:
    """
    Generates complex, potentially dirty telemetry data, varying casing and trailing whitespace
    while ensuring the core alphanumeric content is derived stochastically.
    """
    row_count = draw(st.integers(min_value=5, max_value=50))
    keys1 = draw(
        st.lists(st.text(alphabet="ABCdef123!@   ", min_size=1, max_size=15), min_size=row_count, max_size=row_count)
    )
    keys2 = draw(
        st.lists(st.text(alphabet="XYZxyz456-=   ", min_size=1, max_size=15), min_size=row_count, max_size=row_count)
    )
    noise = draw(st.lists(st.text(min_size=0, max_size=5), min_size=row_count, max_size=row_count))

    return pl.DataFrame(
        {
            "intent_id": keys1,
            "workflow_id": keys2,
            "payload": noise,
        }
    )


@given(df=dirty_telemetry_generator())
@settings(max_examples=50)  # Bounded constraints due to testing loop Gil delays
def test_polars_silver_gate_idempotence(df: pl.DataFrame) -> None:
    """Property-based generator validating deterministic UUIDv5 generation and text normalization."""
    # Pass 1
    df1 = PolarsSilverGate.transform(df.clone().lazy(), natural_keys=["intent_id", "workflow_id"]).collect()

    # Pass 2 - Idempotence requires df1 to be identical to processing df twice
    df2 = PolarsSilverGate.transform(df.clone().lazy(), natural_keys=["intent_id", "workflow_id"]).collect()

    # Pass 3 - Run transform output into transform again
    # We must reinstate the missing natural_keys since they might be dropped or modified?
    # Wait, transform(...) DOES NOT drop intent_id and workflow_id! It only drops _natural_key_composite.
    df3 = PolarsSilverGate.transform(df1.clone().lazy(), natural_keys=["intent_id", "workflow_id"]).collect()

    assert df1.equals(df2), "SilverGate failed determinism guarantee across isomorphic executions."

    # Ensure stable schemas and no double hashing issues across multiple loops
    assert "entity_uuid" in df1.columns
    assert "intent_id" in df1.columns
    assert "workflow_id" in df1.columns

    assert df1.equals(df3), "SilverGate failed idempotency test."

    # Verify canonical normalization mapping invariants
    for row in df1.iter_rows(named=True):
        assert row["intent_id"] == row["intent_id"].strip().lower()
        assert row["workflow_id"] == row["workflow_id"].strip().lower()
        assert row["entity_uuid"] is not None


@given(
    rows=st.lists(
        st.tuples(
            st.one_of(st.text(alphabet="ABCdef123 ", min_size=1, max_size=10), st.just(""), st.none()),
            st.one_of(st.text(alphabet="XYZxyz456 ", min_size=1, max_size=10), st.just(""), st.none()),
        ),
        min_size=5,
        max_size=30,
    )
)
@settings(max_examples=30)
def test_null_and_empty_handling(rows: list[tuple[str | None, str | None]]) -> None:
    """Validates that null and empty string values still produce valid, non-null entity UUIDs."""
    df = pl.DataFrame(rows, schema=["intent_id", "workflow_id"])
    result = PolarsSilverGate.transform(df.clone().lazy(), natural_keys=["intent_id", "workflow_id"]).collect()

    # Every row must have a non-null entity_uuid
    assert result["entity_uuid"].null_count() == 0, "entity_uuid column contains nulls"

    # All entity_uuid values must be non-empty strings matching UUID hex format (8-4-4-4-12)
    for row_uuid in result["entity_uuid"]:
        assert row_uuid is not None
        assert len(row_uuid) == 36, f"entity_uuid '{row_uuid}' has unexpected length {len(row_uuid)}"


@given(df=dirty_telemetry_generator())
@settings(max_examples=30)
def test_shuffle_invariant_idempotence(df: pl.DataFrame) -> None:
    """
    THE IDEMPOTENCE PROOF: proves that entity_uuid is strictly deterministic
    regardless of network arrival order.

    1. Transform the original DataFrame.
    2. Shuffle rows into a completely different arrival order.
    3. Transform the shuffled DataFrame.
    4. Assert that after re-sorting by the same key, entity_uuid columns are 100% identical.
    """
    import random

    natural_keys = ["intent_id", "workflow_id"]

    # Pass 1: original order
    df1 = PolarsSilverGate.transform(df.clone().lazy(), natural_keys=natural_keys).collect()

    # Shuffle the original DataFrame into a random arrival order
    indices = list(range(df.shape[0]))
    random.shuffle(indices)
    df_shuffled = df[indices]

    # Pass 2: shuffled order
    df2 = PolarsSilverGate.transform(df_shuffled.clone().lazy(), natural_keys=natural_keys).collect()

    # Sort both by the deterministic key columns to align rows
    sort_cols = [*natural_keys, "entity_uuid"]
    df1_sorted = df1.sort(sort_cols)
    df2_sorted = df2.sort(sort_cols)

    assert df1_sorted["entity_uuid"].equals(df2_sorted["entity_uuid"]), (
        "entity_uuid diverged across different arrival orderings — determinism violated."
    )


def test_polars_silver_gate_schema_yield_error() -> None:
    df = pl.DataFrame({"wrong_key": ["a", "b"]})

    with pytest.raises(InvalidSchemaYieldError, match="DataFrame missing required natural keys"):
        PolarsSilverGate.transform(df, ["intent_id", "workflow_id"])


def test_process_medallion_pipeline_skip(tmp_path: Any, monkeypatch: Any) -> None:
    """If no bronze data exists, simply skips."""
    from pathlib import Path

    monkeypatch.setattr(Path, "exists", lambda x: False)

    res = process_medallion_pipeline()
    assert res["status"] == "skipped"


@pytest.mark.asyncio
async def test_transform_async() -> None:
    df = pl.DataFrame({"key1": [" A "], "key2": [" B "]})
    res_lazy = await PolarsSilverGate.transform_async(df, ["key1", "key2"])
    res = res_lazy.collect()

    assert res.shape[0] == 1
    assert res["entity_uuid"][0] is not None
    assert res["key1"][0] == "a"
