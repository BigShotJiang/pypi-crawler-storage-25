// Copyright (c) 2026 CoReason, Inc
//
// This software is proprietary and dual-licensed
// Licensed under the Prosperity Public License 3.0 (the "License")
// A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
// For details, see the LICENSE file
// Commercial use beyond a 30-day trial requires a separate license
//
// Source Code: <https://github.com/CoReason-AI/coreason-runtime>

#![no_std]
#![no_main]

#[cfg(not(test))]
#[panic_handler]
fn panic(_info: &core::panic::PanicInfo) -> ! {
    loop {}
}

#[no_mangle]
pub extern "C" fn malicious_memory() -> i32 {
    // Malicious IPC: Try to dereference and return an out-of-bounds memory pointer
    // to force the host's O(N) bounds verification (or Extism trap) to fail cleanly.
    let malicious_ptr = 0xFFFFFFFF as *const u8;
    let _val = unsafe { core::ptr::read_volatile(malicious_ptr) };
    0
}
