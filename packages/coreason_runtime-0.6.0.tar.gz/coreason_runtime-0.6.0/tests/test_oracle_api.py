# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import base64
import json
from unittest.mock import AsyncMock, MagicMock, patch

from coreason_manifest import InterventionReceipt, WetwareAttestationContract
from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.oracle import router

app = FastAPI()
app.include_router(router)

client = TestClient(app)

valid_attestation = WetwareAttestationContract(
    mechanism="urn:coreason:fido2_webauthn",
    did_subject="did:example:123",
    cryptographic_payload=base64.b64encode(
        json.dumps({"pq_algorithm": "dilithium", "public_key_id": "pk1", "pq_signature_blob": "blob"}).encode()
    ).decode(),
    dag_node_nonce="req1-0000000",
    liveness_challenge_hash="a" * 64,
)

valid_receipt = InterventionReceipt(
    topology_class="verdict",
    intervention_request_cid="req1-0000000",
    target_node_cid="did:example:123",
    event_cid="test_event_cid",
    timestamp=1234567890,
    approved=True,
    feedback="Looks good",
    attestation=valid_attestation,
).model_dump(mode="json")


def test_resume_oracle_success() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True),
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = AsyncMock()
        mock_client.get_workflow_handle.return_value = mock_handle

        resume_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/test_wf", json=resume_receipt)
        assert response.status_code == 200
        assert response.json() == {"status": "success", "message": "Epistemic injection dispatched"}


def test_resume_oracle_failure() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True),
    ):
        mock_connect.side_effect = Exception("Test error")
        resume_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/test_wf", json=resume_receipt)
        assert response.status_code == 500
        assert "Failed to reach Temporal Swarm" in response.json()["detail"]


def test_resume_oracle_invalid_signature() -> None:
    with patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=False):
        resume_receipt = valid_receipt.copy()
        response = client.post("/api/v1/oracle/resume/test_wf", json=resume_receipt)
        assert response.status_code == 401
        assert "WetwareAttestationContract verification failed" in response.json()["detail"]


def test_resume_oracle_invalid_json() -> None:
    import copy

    invalid_receipt = copy.deepcopy(valid_receipt)
    invalid_receipt["attestation"]["cryptographic_payload"] = "invalid_base64_json"
    response = client.post("/api/v1/oracle/resume/test_wf", json=invalid_receipt)
    assert response.status_code == 401
    assert "WetwareAttestationContract verification failed" in response.json()["detail"]


def test_resolve_oracle_success() -> None:
    with (
        patch("coreason_runtime.api.oracle.Client.connect", new_callable=AsyncMock) as mock_connect,
        patch("coreason_runtime.api.oracle.verify_wetware_attestation", return_value=True) as _mock_verify,
    ):
        mock_client = MagicMock()
        mock_connect.return_value = mock_client
        mock_handle = AsyncMock()
        mock_client.get_workflow_handle.return_value = mock_handle

        resolve_receipt = valid_receipt.copy()
        resolve_receipt["topology_class"] = "verdict"
        response = client.post("/api/v1/oracle/resolve/test_wf", json=resolve_receipt)
        assert response.status_code == 200
        assert response.json() == {"status": "resolution_injected", "workflow_id": "test_wf"}
