# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import tempfile
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from coreason_runtime.orchestration.engine import CoreasonRuntime


@pytest.fixture
def engine() -> CoreasonRuntime:
    return CoreasonRuntime(
        temporal_host="test_host:7233",
        sglang_url="http://test_url:30000",
        memory_path="./lancedb_store",
    )


def test_init(engine: CoreasonRuntime) -> None:
    assert engine.temporal_host == "test_host:7233"
    assert engine.sglang_url == "http://test_url:30000"
    assert engine.memory_path == "./lancedb_store"
    assert engine._client is None


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_connect(mock_connect: AsyncMock) -> None:
    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    engine = await CoreasonRuntime.connect("test_host:7233", "http://test_url:30000", "./lancedb_store")

    mock_connect.assert_called_once_with("test_host:7233")
    assert engine._client == mock_client


@pytest.mark.asyncio
async def test_execute_failure(engine: CoreasonRuntime) -> None:
    with pytest.raises(FileNotFoundError, match="No such file or directory"):
        await engine.execute("/non/existent/path.json")


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_returns_pydantic_model(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    from pydantic import BaseModel

    class DummyModel(BaseModel):
        status: str
        value: int

    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {"topology_class": "dag", "max_depth": 10, "max_fan_out": 5, "nodes": {}, "edges": []},
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value={"status": "success", "value": 42})
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)

    mock_connect.return_value = mock_client

    result = await engine.execute(temp_path)

    assert result == {"status": "success", "value": 42}
    mock_client.start_workflow.assert_called_once()


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_returns_none(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {"topology_class": "dag", "max_depth": 10, "max_fan_out": 5, "nodes": {}, "edges": []},
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value=None)
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)

    mock_connect.return_value = mock_client

    result = await engine.execute(temp_path)

    assert result == {}
    mock_client.start_workflow.assert_called_once()


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_returns_other(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {"topology_class": "dag", "max_depth": 10, "max_fan_out": 5, "nodes": {}, "edges": []},
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value=[1, 2, 3])
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)

    mock_connect.return_value = mock_client

    result = await engine.execute(temp_path)

    assert result == {}
    mock_client.start_workflow.assert_called_once()


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_unknown_type(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {"type": "unknown_type", "max_depth": 10, "max_fan_out": 5, "nodes": {}, "edges": []},
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()
    mock_connect.return_value = mock_client

    with pytest.raises(ValueError, match="Invalid WorkflowManifest format:"):
        await engine.execute(temp_path)


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_with_perturbation_vector(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    """Test that exogenous_perturbation_vector is injected into agent node descriptions."""
    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {
            "topology_class": "dag",
            "max_depth": 10,
            "max_fan_out": 5,
            "nodes": {
                "did:test:node-1": {
                    "topology_class": "agent",
                    "description": "A helpful assistant.",
                }
            },
            "edges": [],
        },
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value={"status": "success"})
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)
    mock_connect.return_value = mock_client

    result = await engine.execute(temp_path, exogenous_perturbation_vector="What is the weather?")

    assert result == {"status": "success"}
    # Verify the envelope passed to start_workflow contains the injected description
    call_args = mock_client.start_workflow.call_args
    envelope_payload = call_args.args[1]  # second positional arg is the envelope dict
    node_desc = envelope_payload["payload"]["nodes"]["did:test:node-1"]["description"]
    assert "USER QUERY CONSTRAINT:" in node_desc
    assert "What is the weather?" in node_desc


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_with_governance_budget(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    """Test that governance.max_budget_magnitude overrides the default compute budget."""
    from unittest.mock import PropertyMock

    test_manifest_data = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "topology": {
            "topology_class": "dag",
            "max_depth": 10,
            "max_fan_out": 5,
            "nodes": {},
            "edges": [],
        },
    }

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value={"status": "success"})
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)
    mock_connect.return_value = mock_client

    # Mock WorkflowManifest.model_validate to inject governance with budget
    mock_governance = MagicMock()
    mock_governance.max_budget_magnitude = 500
    mock_governance.model_dump.return_value = {"max_budget_magnitude": 500}

    with patch("coreason_runtime.orchestration.engine.WorkflowManifest.model_validate") as mock_validate:
        mock_manifest = MagicMock()
        mock_manifest.genesis_provenance.model_dump.return_value = {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        }
        mock_manifest.pq_signature = None
        mock_manifest.topology.model_dump.return_value = test_manifest_data["topology"]
        mock_manifest.topology.compile_to_base_topology = None  # no macro unrolling
        type(mock_manifest.topology).compile_to_base_topology = PropertyMock(return_value=None)
        mock_manifest.allowed_semantic_classifications = None
        mock_manifest.governance = mock_governance
        mock_manifest.tenant_cid = "test-tenant"
        mock_manifest.session_cid = "test-session"
        mock_validate.return_value = mock_manifest

        result = await engine.execute_from_dict(test_manifest_data)

    assert result == {"status": "success"}
    call_args = mock_client.start_workflow.call_args
    envelope_payload = call_args.args[1]
    # The governance budget (500) should override the default
    assert envelope_payload["state_vector"]["mutable_matrix"]["compute_budget"] == 500


@pytest.mark.asyncio
@patch("coreason_runtime.orchestration.engine.Client.connect", new_callable=AsyncMock)
async def test_execute_with_semantic_classifications(mock_connect: AsyncMock, engine: CoreasonRuntime) -> None:
    """Test that allowed_semantic_classifications are forwarded into the topology payload."""
    test_manifest = {
        "manifest_version": "1.0.0",
        "genesis_provenance": {
            "source_event_cid": "0123456789abcdef",
            "derivation_mode": "direct_translation",
            "extracted_by": "did:test:agent-1",
        },
        "allowed_semantic_classifications": ["public", "internal"],
        "topology": {
            "topology_class": "dag",
            "max_depth": 10,
            "max_fan_out": 5,
            "nodes": {},
            "edges": [],
        },
    }
    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(test_manifest, f)
        temp_path = f.name

    mock_client = MagicMock()

    mock_handle = MagicMock()
    mock_handle.result = AsyncMock(return_value={"status": "success"})
    mock_client.start_workflow = AsyncMock(return_value=mock_handle)
    mock_connect.return_value = mock_client

    result = await engine.execute(temp_path)

    assert result == {"status": "success"}
    call_args = mock_client.start_workflow.call_args
    envelope_payload = call_args.args[1]
    assert "allowed_semantic_classifications" in envelope_payload["payload"]
    assert "allowed_semantic_classifications" in envelope_payload["state_vector"]["immutable_matrix"]
