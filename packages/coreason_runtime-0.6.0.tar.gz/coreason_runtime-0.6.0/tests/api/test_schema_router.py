# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from fastapi import FastAPI
from fastapi.testclient import TestClient

from coreason_runtime.api.schema.router import JSONDepthLimitMiddleware, router

app = FastAPI()
app.add_middleware(JSONDepthLimitMiddleware)
app.include_router(router)

client = TestClient(app)


def test_get_receipt_schema() -> None:
    response = client.get("/api/v1/schema/receipt")
    assert response.status_code == 200
    assert "$defs" in response.json() or "title" in response.json()


def test_get_topology_schema() -> None:
    response = client.get("/api/v1/schema/topology/dag")
    assert response.status_code == 200
    assert "$defs" in response.json() or "title" in response.json()


def test_get_topology_schema_invalid() -> None:
    response = client.get("/api/v1/schema/topology/nonexistent")
    assert response.status_code == 404


def test_get_capabilities_schema() -> None:
    response = client.get("/api/v1/schema/capabilities")
    assert response.status_code == 200
    assert "title" in response.json()
    assert response.json()["title"] == "ExecutableCapabilities"


def test_json_depth_limit_middleware_fallback() -> None:
    # Attempting to send normal JSON Depth
    response = client.post("/api/v1/schema/topology/dag", json={"test": "data"})
    assert response.status_code in [404, 405]  # just testing the middleware bypass

    # Create a deeply nested JSON to trigger the 400
    deep_json = "{" + "".join(['"a": {' for _ in range(12)]) + '"b": 1' + "".join(["}" for _ in range(12)]) + "}"
    response = client.post(
        "/api/v1/schema/topology/dag", content=deep_json, headers={"Content-Type": "application/json"}
    )
    assert response.status_code == 400
    assert "JSON Payload rejected" in response.json().get("detail", "")
