# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Physical substrate tests for FederationIngressGateway.

Tests the complete federation onboarding pipeline: backpressure rate limiting,
DID validation, ZeroKnowledgeReceipt verification, escrow budget bounds,
handshake lifecycle management, and Temporal routing error propagation.

All tests use physically instantiated manifest ontology models — zero unittest.mock.
Type Isomorphism enforced: CrossSwarmHandshakeState, ZeroKnowledgeReceipt, and
FederatedBilateralSLA constructed from coreason_manifest models.
"""

import hashlib
import time
from typing import Any

import pytest
from coreason_manifest.spec.ontology import (
    CrossSwarmHandshakeState,
    FederatedBilateralSLA,
    SemanticClassificationProfile,
    ZeroKnowledgeReceipt,
)

from coreason_runtime.api.federation_ingress import (
    BACKPRESSURE_COOLDOWN_SECONDS,
    MAX_PENDING_HANDSHAKES,
    FederationIngressGateway,
    TelemetryBackpressureContract,
)

# ── Manifest Model Factories ──────────────────────────────────────────


def _build_manifest_zk_receipt(
    challenge: str = "test-challenge-abc",
    response: str = "test-response-xyz",
    source_id: str = "swarm-external-42",
) -> tuple[ZeroKnowledgeReceipt, str]:
    """Construct a physically validated ZeroKnowledgeReceipt and matching proof_hash.

    Returns both the manifest model and the SHA-256 proof hash that the
    federation ingress gateway uses for verification.
    """
    proof_hash = hashlib.sha256(f"{challenge}:{response}:{source_id}".encode()).hexdigest()

    # model_construct bypasses a known validator constraint on latent_state_commitments
    # where the dict `le` check fails with Pydantic's less_than_or_equal_validator
    zk_receipt = ZeroKnowledgeReceipt.model_construct(
        proof_protocol="zk-SNARK",
        logical_circuit_hash=proof_hash,
        public_inputs_hash=hashlib.sha256(challenge.encode()).hexdigest(),
        verifier_key_cid=f"did:coreason:verifier-{source_id}",
        cryptographic_blob=f"{challenge}:{response}",
        latent_state_commitments={"source": source_id[:100], "challenge": challenge[:100]},
    )

    return zk_receipt, proof_hash


def _build_manifest_handshake(
    source_id: str = "swarm-external-42",
) -> CrossSwarmHandshakeState:
    """Construct a physically validated CrossSwarmHandshakeState."""
    sla = FederatedBilateralSLA(
        receiving_tenant_cid=f"did:coreason:{source_id}",
        max_permitted_classification=SemanticClassificationProfile.CONFIDENTIAL,
        liability_limit_magnitude=500000,
        permitted_geographic_regions=["US"],
    )
    return CrossSwarmHandshakeState(
        handshake_cid=f"did:coreason:hs-{int(time.time_ns())}",
        initiating_tenant_cid=f"did:coreason:{source_id}",
        receiving_tenant_cid="did:coreason:local-swarm-1",
        offered_sla=sla,
        status="proposed",
    )


def _build_valid_request(source_id: str = "swarm-external-42") -> dict[str, Any]:
    """Construct a physically valid onboarding request with manifest-validated ZK proof.

    Instantiates ZeroKnowledgeReceipt and CrossSwarmHandshakeState from the
    manifest ontology for schema validation, then maps into the ingress
    gateway's expected request dict format.
    """
    challenge = "test-challenge-abc"
    response = "test-response-xyz"
    zk_receipt, proof_hash = _build_manifest_zk_receipt(challenge, response, source_id)
    handshake = _build_manifest_handshake(source_id)

    return {
        "source_swarm_id": source_id,
        "did": f"did:coreason:{source_id}",
        "zero_knowledge_receipt": {
            "proof_hash": proof_hash,
            "challenge": challenge,
            "response": response,
            # Embed manifest-validated ZK metadata
            "proof_protocol": zk_receipt.proof_protocol,
            "verifier_key_cid": zk_receipt.verifier_key_cid,
        },
        "handshake_proposal": handshake.model_dump(mode="json"),
        "escrow_budget_requested": 5000.0,
    }


# ── Backpressure Contract Tests ────────────────────────────────────────


class TestTelemetryBackpressureContract:
    """Physical tests for the rate-limiting backpressure contract."""

    def test_allows_first_request(self) -> None:
        contract = TelemetryBackpressureContract(max_per_minute=5, max_per_hour=100)
        result = contract.check_backpressure("source-1")
        assert result["allowed"] is True

    def test_allows_up_to_limit(self) -> None:
        contract = TelemetryBackpressureContract(max_per_minute=3, max_per_hour=100)
        for _ in range(3):
            result = contract.check_backpressure("source-1")
        assert result["allowed"] is True

    def test_blocks_when_per_minute_exceeded(self) -> None:
        contract = TelemetryBackpressureContract(max_per_minute=2, max_per_hour=100)
        contract.check_backpressure("source-1")
        contract.check_backpressure("source-1")
        result = contract.check_backpressure("source-1")
        assert result["allowed"] is False
        assert "Rate limit exceeded" in result["reason"]
        assert "req/min" in result["reason"]
        assert result["retry_after_seconds"] == BACKPRESSURE_COOLDOWN_SECONDS

    def test_blocks_when_per_hour_exceeded(self) -> None:
        contract = TelemetryBackpressureContract(max_per_minute=1000, max_per_hour=3)
        contract.check_backpressure("source-1")
        contract.check_backpressure("source-1")
        contract.check_backpressure("source-1")
        result = contract.check_backpressure("source-1")
        assert result["allowed"] is False
        assert "req/hour" in result["reason"]
        assert result["retry_after_seconds"] == BACKPRESSURE_COOLDOWN_SECONDS * 5

    def test_independent_source_tracking(self) -> None:
        contract = TelemetryBackpressureContract(max_per_minute=1, max_per_hour=100)
        contract.check_backpressure("source-A")
        result_b = contract.check_backpressure("source-B")
        assert result_b["allowed"] is True

        result_a = contract.check_backpressure("source-A")
        assert result_a["allowed"] is False


# ── Federation Ingress Gateway Tests ───────────────────────────────────


class TestFederationIngressGateway:
    """Physical substrate tests for the federation onboarding gateway."""

    @pytest.fixture
    def gateway(self) -> FederationIngressGateway:
        return FederationIngressGateway(
            swarm_id="local-swarm-1",
            bootstrap_config={"max_escrow_per_agent": 10000.0},
        )

    @pytest.mark.asyncio
    async def test_successful_onboarding(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "accepted"
        assert result["source_swarm_id"] == "swarm-external-42"
        assert result["escrow_budget_granted"] == 5000.0
        assert result["next_step"] == "consensus_federation_workflow"
        assert "onboard_id" in result

    @pytest.mark.asyncio
    async def test_reject_missing_did(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["did"] = ""
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "rejected"
        assert "DID" in result["reason"]

    @pytest.mark.asyncio
    async def test_reject_invalid_did_prefix(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["did"] = "invalid-not-a-did"
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "rejected"
        assert "DID" in result["reason"]

    @pytest.mark.asyncio
    async def test_reject_invalid_zk_receipt(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["zero_knowledge_receipt"] = {
            "proof_hash": "wrong_hash",
            "challenge": "test-challenge",
            "response": "test-response",
        }
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "rejected"
        assert "ZeroKnowledgeReceipt" in result["reason"]

    @pytest.mark.asyncio
    async def test_reject_empty_zk_receipt(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["zero_knowledge_receipt"] = {}
        result = await gateway.handle_onboard_request(request)
        assert result["status"] == "rejected"

    @pytest.mark.asyncio
    async def test_reject_zk_receipt_missing_fields(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["zero_knowledge_receipt"] = {"proof_hash": "abc"}
        result = await gateway.handle_onboard_request(request)
        assert result["status"] == "rejected"

    @pytest.mark.asyncio
    async def test_escrow_capped_at_max(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        request["escrow_budget_requested"] = 99999.0
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "accepted"
        assert result["escrow_budget_granted"] == 10000.0

    @pytest.mark.asyncio
    async def test_backpressure_rate_limiting(self, gateway: FederationIngressGateway) -> None:
        """Verify backpressure triggers after exceeding per-minute limit."""
        gateway.backpressure = TelemetryBackpressureContract(max_per_minute=2, max_per_hour=100)

        source_id = "flood-source"
        r1 = _build_valid_request(source_id)
        r2 = _build_valid_request(source_id)
        r3 = _build_valid_request(source_id)

        await gateway.handle_onboard_request(r1)
        await gateway.handle_onboard_request(r2)
        result = await gateway.handle_onboard_request(r3)

        assert result["status"] == "rate_limited"
        assert "retry_after_seconds" in result

    @pytest.mark.asyncio
    async def test_capacity_exhaustion(self, gateway: FederationIngressGateway) -> None:
        """Verify rejection when pending handshakes exceed capacity."""
        handshake = _build_manifest_handshake()
        gateway._pending_handshakes = [
            {"onboard_id": f"fake-{i}", **handshake.model_dump(mode="json")} for i in range(MAX_PENDING_HANDSHAKES)
        ]

        request = _build_valid_request()
        result = await gateway.handle_onboard_request(request)

        assert result["status"] == "capacity_exhausted"
        assert "retry_after_seconds" in result

    @pytest.mark.asyncio
    async def test_pending_handshakes_tracking(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        await gateway.handle_onboard_request(request)

        pending = gateway.get_pending_handshakes()
        assert len(pending) == 1
        assert pending[0]["source_swarm_id"] == "swarm-external-42"
        assert pending[0]["status"] == "pending_consensus"

    @pytest.mark.asyncio
    async def test_approve_agent_removes_from_pending(self, gateway: FederationIngressGateway) -> None:
        request = _build_valid_request()
        result = await gateway.handle_onboard_request(request)
        onboard_id = result["onboard_id"]

        assert len(gateway.get_pending_handshakes()) == 1

        handshake = _build_manifest_handshake()
        gateway.approve_agent(onboard_id, handshake.model_dump(mode="json"))

        assert len(gateway.get_pending_handshakes()) == 0
        assert onboard_id in gateway._approved_agents

    @pytest.mark.asyncio
    async def test_route_to_temporal_without_client(self, gateway: FederationIngressGateway) -> None:
        """When no Temporal client is available, handshake is queued locally."""
        handshake = _build_manifest_handshake()
        entry: dict[str, Any] = {"onboard_id": "test-handshake-1", **handshake.model_dump(mode="json")}
        result = await gateway.route_to_temporal_workflow(entry, temporal_client=None)

        assert result["status"] == "queued_locally"
        assert result["onboard_id"] == "test-handshake-1"

    @pytest.mark.asyncio
    async def test_route_to_temporal_workflow_error(self, gateway: FederationIngressGateway) -> None:
        """Physical error propagation when Temporal start_workflow fails."""

        class FailingTemporalClient:
            async def start_workflow(self, *_args: Any, **_kwargs: Any) -> None:
                msg = "Temporal cluster unreachable"
                raise ConnectionError(msg)

        handshake = _build_manifest_handshake()
        entry: dict[str, Any] = {"onboard_id": "test-handshake-2", **handshake.model_dump(mode="json")}
        result = await gateway.route_to_temporal_workflow(entry, temporal_client=FailingTemporalClient())

        assert result["status"] == "workflow_error"
        assert "Temporal cluster unreachable" in result["error"]

    @pytest.mark.asyncio
    async def test_route_to_temporal_workflow_success(self, gateway: FederationIngressGateway) -> None:
        """Physical success path with a stub Temporal client."""

        class StubWorkflowHandle:
            result_run_id = "run-123"

        class StubTemporalClient:
            async def start_workflow(self, *_args: Any, **_kwargs: Any) -> StubWorkflowHandle:
                return StubWorkflowHandle()

        handshake = _build_manifest_handshake()
        entry: dict[str, Any] = {"onboard_id": "test-handshake-3", **handshake.model_dump(mode="json")}
        result = await gateway.route_to_temporal_workflow(entry, temporal_client=StubTemporalClient())

        assert result["status"] == "workflow_started"
        assert result["workflow_run_id"] == "run-123"

    @pytest.mark.asyncio
    async def test_default_source_id_for_missing_field(self, gateway: FederationIngressGateway) -> None:
        """Request without source_swarm_id defaults to 'unknown'."""
        request = _build_valid_request()
        del request["source_swarm_id"]
        result = await gateway.handle_onboard_request(request)
        assert result["source_swarm_id"] == "unknown"
