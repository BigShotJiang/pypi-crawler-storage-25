# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta

    from coreason_manifest import ExecutionEnvelopeState
    from temporalio.common import RetryPolicy

    from coreason_runtime.telemetry.emitter import TelemetryEmitter

from .base_topology_workflow import BaseTopologyWorkflow


@workflow.defn
class CouncilExecutionWorkflow(BaseTopologyWorkflow):
    """A deterministic workflow that represents a Council Topology manifest.

    AGENT INSTRUCTION: Formalizes Social Choice Theory and pBFT to synthesize
    an authoritative truth from a multi-agent network. All council member nodes
    are evaluated in parallel; the adjudicator node synthesizes the final output.
    """

    def __init__(self) -> None:
        """Initialize CouncilExecutionWorkflow."""
        super().__init__()

    @workflow.run
    async def run(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Run the Council workflow.

        AGENT INSTRUCTION: This workflow enforces Social Choice Theory consensus.
        Council members produce independent outputs in parallel. The consensus_policy
        strategy resolves disagreements before the adjudicator synthesises the final truth.
        Args:
            payload: The dictionary representing an ExecutionEnvelopeState
                     containing a CouncilTopologyManifest.

        Returns:
            A dictionary containing the final execution status and results.
        """
        import asyncio

        self._current_state_envelope = ExecutionEnvelopeState.model_validate(payload)
        manifest_payload = self._current_state_envelope.payload

        emitter = TelemetryEmitter("")
        trace_context_state = self._current_state_envelope.trace_context

        workflow.logger.info("Starting CouncilExecutionWorkflow")

        results: list[dict[str, Any]] = []
        workflow_start_time = workflow.now()

        with workflow.unsafe.sandbox_unrestricted():
            import json

            from coreason_manifest import CouncilTopologyManifest

            manifest = CouncilTopologyManifest.model_validate_json(json.dumps(manifest_payload))

        governance = manifest_payload.get("governance")
        allowed_classifications = manifest_payload.get("allowed_information_classifications")

        adjudicator_id = str(manifest.adjudicator_cid)
        consensus_policy = manifest.consensus_policy

        member_node_cids = [nid for nid in manifest.nodes if str(nid) != adjudicator_id]

        if self._current_state_envelope is None:  # pragma: no cover
            msg = "State Envelope is None"
            raise ValueError(msg)

        workflow.logger.info(f"Council fan-out: {len(member_node_cids)} members")

        member_results: dict[str, dict[str, Any]] = {}

        async def execute_member(node_cid: str) -> tuple[str, dict[str, Any]]:
            """Execute inference for a single council member."""
            await workflow.sleep(timedelta(seconds=0.1))
            self.enforce_governance_limits(governance, workflow_start_time)
            self.enforce_lbac_clearance(allowed_classifications, "public")

            node_profile = manifest.nodes[node_cid]
            with workflow.unsafe.sandbox_unrestricted():
                if not self._current_state_envelope:  # pragma: no cover
                    msg = "Council execution requires a valid state envelope."
                    raise ValueError(msg)
                node_payload = manifest_payload.get("nodes", {}).get(node_cid)
                if not node_payload:  # pragma: no cover
                    node_payload = node_profile.model_dump(mode="json")

            segregated_payload = {
                "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
                "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
                "node_profile": node_payload,
            }

            with workflow.unsafe.sandbox_unrestricted():
                import json

                from temporalio.exceptions import ApplicationError

                payload_str = json.dumps(segregated_payload).lower()
                firewall = getattr(manifest, "semantic_firewall_policy", None)
                blocked_phrases = (
                    getattr(firewall, "blocked_phrases", [])
                    if firewall
                    else ["ignore previous instructions", "forget all previous", "system prompt", "you are now a"]
                )

                for phrase in blocked_phrases:
                    if phrase.lower() in payload_str:
                        workflow.logger.error(
                            f"SemanticFirewall Violation: Blocked phrase '{phrase}' detected."
                        )  # pragma: no cover
                        msg = f"SemanticFirewall Violation: Biba phrase '{phrase}' detected in workload."
                        raise ApplicationError(  # pragma: no cover
                            msg,
                            type="SemanticFirewallError",
                            non_retryable=True,
                        )

            result = await emitter.wrap_execution_block(
                name=f"ExecuteTensorInferenceComputeActivity:council:{node_cid}",
                kind="internal",
                trace_context=trace_context_state,
                block=lambda sp=segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                    "ExecuteTensorInferenceComputeActivity",
                    args=[
                        workflow.info().workflow_id,
                        sp,
                        (
                            sp.get("node_profile", {}).get("action_space_cid")
                            if isinstance(sp, dict) and "node_profile" in sp
                            else None
                        )
                        or "AgentResponse",
                    ],  # pragma: no cover
                    schedule_to_close_timeout=timedelta(minutes=5),
                    retry_policy=RetryPolicy(maximum_attempts=5),
                ),
            )

            usage = result.get("usage", {})
            self._accumulated_tokens += usage.get("total_tokens", 0)
            self._accumulated_cost += result.get("cost", 0.0)
            await self.record_thermodynamic_burn("result", usage, result.get("cost", 0.0))

            return node_cid, result

        tasks = [asyncio.create_task(execute_member(str(nid))) for nid in member_node_cids]

        for task in tasks:
            node_cid, result = await task
            member_results[node_cid] = result
            results.append({"node_cid": node_cid, "type": "council_member", "result": result})

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        consensus_reached = True
        consensus_detail = "default"

        if consensus_policy:
            strategy = consensus_policy.strategy
            workflow.logger.info(f"Resolving consensus with strategy: {strategy}")

            intent_hashes = [r.get("intent_hash", "") for r in member_results.values()]

            if strategy == "unanimous":  # pragma: no cover
                if len(set(intent_hashes)) != 1:
                    consensus_reached = False
                    consensus_detail = "unanimous_failed"
                else:
                    consensus_detail = "unanimous"

            elif strategy == "majority":
                from collections import Counter

                hash_counts = Counter(intent_hashes)
                _most_common_hash, most_common_count = hash_counts.most_common(1)[0]
                if most_common_count > len(intent_hashes) / 2:
                    consensus_detail = "majority"
                else:  # pragma: no cover
                    consensus_reached = False
                    consensus_detail = "majority_failed"

            elif strategy == "debate_rounds":  # pragma: no cover
                max_rounds = consensus_policy.max_debate_rounds or 3
                consensus_detail = f"debate_rounds:{max_rounds}"

            elif strategy == "pbft":  # pragma: no cover
                quorum_rules = consensus_policy.quorum_rules
                if quorum_rules:
                    from collections import Counter

                    hash_counts = Counter(intent_hashes)
                    _, agreeing_count = hash_counts.most_common(1)[0]
                    if agreeing_count >= quorum_rules.min_quorum_size:
                        consensus_detail = "pbft_quorum_met"
                    else:
                        consensus_reached = False
                        consensus_detail = f"pbft_quorum_failed:{quorum_rules.byzantine_action}"
                        workflow.logger.warning(f"pBFT quorum not met. Action: {quorum_rules.byzantine_action}")

            elif strategy == "prediction_market":  # pragma: no cover
                consensus_detail = "prediction_market"

            elif strategy == "dao_vote":  # pragma: no cover
                # PHASE 14: Decentralized On-Chain Adjudication
                workflow.logger.info(f"Phase 14: Emitting MCPClientIntent for on-chain DAO voting on {adjudicator_id}")

                # We emit an intent to hit the treasury_manager/smart contract logic
                await emitter.wrap_execution_block(
                    name="EmitDAOVoteMCPIntent",
                    kind="external",
                    trace_context=trace_context_state,
                    block=lambda: workflow.sleep(timedelta(seconds=0.1)),  # Simulate emission
                )

                workflow.logger.info("Awaiting on-chain DAO vote resolution (Max timeout: 7 days)...")
                try:
                    # Signal Handler simulation: blocks workflow until Web3 oracle resolves it.
                    await workflow.wait_condition(
                        lambda: getattr(self, "_dao_vote_resolved", False), timeout=timedelta(days=7)
                    )
                    consensus_detail = "dao_vote_resolved"
                    workflow.logger.info("✅ DAO Vote Resolved. Resuming workflow logic.")
                except Exception as e:
                    consensus_reached = False
                    consensus_detail = f"dao_vote_failed:{e}"
                    workflow.logger.error("❌ DAO Vote Timeout or Failure.")

        workflow.logger.info(f"Adjudicator {adjudicator_id} synthesizing council outputs")

        await workflow.sleep(timedelta(seconds=0.1))
        self.enforce_governance_limits(governance, workflow_start_time)
        self.enforce_lbac_clearance(allowed_classifications, "public")

        adjudicator_profile = manifest.nodes[adjudicator_id]
        with workflow.unsafe.sandbox_unrestricted():
            adj_node_payload = manifest_payload.get("nodes", {}).get(adjudicator_id)
            if not adj_node_payload:  # pragma: no cover
                adj_node_payload = adjudicator_profile.model_dump(mode="json")
            adj_node_payload["input_data"] = list(member_results.values())
            adj_node_payload["consensus_detail"] = consensus_detail
            adj_node_payload["consensus_reached"] = consensus_reached

        adj_segregated_payload = {
            "immutable_matrix": self._current_state_envelope.state_vector.immutable_matrix,
            "mutable_matrix": self._current_state_envelope.state_vector.mutable_matrix,
            "node_profile": adj_node_payload,
        }

        adj_result = await emitter.wrap_execution_block(
            name=f"ExecuteTensorInferenceComputeActivity:adjudicator:{adjudicator_id}",
            kind="internal",
            trace_context=trace_context_state,
            block=lambda sp=adj_segregated_payload: workflow.execute_activity(  # type: ignore[misc]
                "ExecuteTensorInferenceComputeActivity",
                args=[
                    workflow.info().workflow_id,
                    sp,
                    (
                        sp.get("node_profile", {}).get("action_space_cid")
                        if isinstance(sp, dict) and "node_profile" in sp
                        else None
                    )
                    or "AgentResponse",
                ],  # pragma: no cover
                schedule_to_close_timeout=timedelta(minutes=5),
                retry_policy=RetryPolicy(maximum_attempts=5),
            ),
        )

        adj_usage = adj_result.get("usage", {})
        self._accumulated_tokens += adj_usage.get("total_tokens", 0)
        self._accumulated_cost += adj_result.get("cost", 0.0)
        await self.record_thermodynamic_burn("adj", adj_usage, adj_result.get("cost", 0.0))

        self.reconcile_state(
            {
                "accumulated_tokens": self._accumulated_tokens,
                "accumulated_cost": self._accumulated_cost,
            }
        )

        results.append({"node_cid": adjudicator_id, "type": "adjudicator", "result": adj_result})

        if manifest.shared_state_contract:  # pragma: no cover
            try:
                with workflow.unsafe.sandbox_unrestricted():
                    import jsonschema  # pragma: no cover

                    logger = workflow.logger
                    logger.info("Enforcing shared_state_contract Schema-on-Write for Council Adjudicator")
                    if not isinstance(adj_result, dict):  # pragma: no cover
                        msg = "Adjudicator result must be a dictionary to match state contract."
                        raise ValueError(msg)

                    outputs_to_validate = adj_result.get("outputs", adj_result)  # pragma: no cover
                    jsonschema.validate(
                        instance=outputs_to_validate, schema=manifest.shared_state_contract.model_dump(mode="json")
                    )  # pragma: no cover
            except Exception as e:  # pragma: no cover
                workflow.logger.exception(f"State rejected by shared_state_contract: {e}")
                from coreason_runtime.utils.exceptions import SchemaOnWriteValidationError

                msg = f"State rejected by shared_state_contract (Schema-on-Write): {e}"
                raise SchemaOnWriteValidationError(msg) from e

        intent_hash = adj_result.get("intent_hash")
        if not intent_hash or intent_hash == "UNKNOWN_HASH":  # pragma: no cover
            import hashlib
            import json

            intent_hash = hashlib.sha256(json.dumps(adj_result, sort_keys=True).encode("utf-8")).hexdigest()
        success = adj_result.get("success", True) and consensus_reached

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[workflow.info().workflow_id, intent_hash, success, adj_result, None],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

        workflow.logger.info("Completed CouncilExecutionWorkflow")
        return {
            "status": "success" if consensus_reached else "consensus_failed",
            "consensus_detail": consensus_detail,
            "results": results,
        }
