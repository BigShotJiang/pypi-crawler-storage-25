# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from typing import Any

from temporalio import workflow

with workflow.unsafe.imports_passed_through():
    from coreason_manifest import ExecutionEnvelopeState, TokenBurnReceipt
    from coreason_manifest.spec.ontology import BargeInInterruptEvent, EpistemicRejectionReceipt

with workflow.unsafe.imports_passed_through():
    from datetime import timedelta


class BaseTopologyWorkflow:
    """An abstract deterministic workflow base for coreason-manifest topologies."""

    def __init__(self) -> None:
        """Initialize BaseTopologyWorkflow."""
        self._current_state_envelope: ExecutionEnvelopeState[dict[str, Any]] | None = None
        self._pending_oracle_override: dict[str, Any] | None = None
        self._current_oracle_resolution: dict[str, Any] | None = None
        self._accumulated_tokens: int = 0
        self._accumulated_cost: float = 0.0
        self._is_interrupted: bool = False
        self._interrupt_disposition: str | None = None
        self._interrupt_event: dict[str, Any] | None = None

    @workflow.query(name="is_interrupted")
    def is_interrupted(self) -> bool:
        """Query if the workflow has received a barge-in interrupt."""
        return self._is_interrupted

    @workflow.signal(name="barge_in_interrupt")
    async def barge_in_interrupt(self, event_payload: dict[str, Any]) -> None:
        """Handle a BargeInInterruptEvent signaling premature probability wave collapse."""
        import uuid

        workflow.logger.warning("Barge-In Interrupt Signal Received! Halting generative sequences.")

        # Validating signal bounds using strictly typed ontology restrictions
        interrupt_event = BargeInInterruptEvent.model_validate(event_payload)

        self._is_interrupted = True
        self._interrupt_disposition = interrupt_event.epistemic_disposition
        self._interrupt_event = event_payload

        # State Management: Emit Rejection Receipt resolving logic dispositions
        with workflow.unsafe.sandbox_unrestricted():
            receipt = EpistemicRejectionReceipt(
                event_cid=f"rejection-event-{uuid.uuid4()}",
                timestamp=workflow.now().timestamp(),
                receipt_cid=f"rejection-{uuid.uuid4()}",
                failed_projection_cid=interrupt_event.target_event_cid,
                violated_algebraic_constraint=f"BargeInInterrupt forced wave collapse (Disposition: {self._interrupt_disposition})",
                kl_divergence_to_validity=1.0,
                stochastic_mutation_gradient="ABORT_SEQUENCE_IMMEDIATELY",
            )
            receipt_dict = receipt.model_dump(mode="json")

        await workflow.execute_activity(
            "StoreEpistemicStateIOActivity",
            args=[
                workflow.info().workflow_id,
                receipt.receipt_cid,
                False,
                {"barge_in": True, "payload": event_payload},
                receipt_dict,
            ],
            schedule_to_close_timeout=timedelta(minutes=1),
        )

    async def record_thermodynamic_burn(self, node_cid: str, usage: dict[str, Any], cost: float) -> None:
        """Commit a TokenBurnReceipt dynamically caching thermodynamic state."""
        import hashlib
        import uuid

        try:
            input_tokens = usage.get("prompt_tokens", 0)
            output_tokens = usage.get("completion_tokens", 0)
        except AttributeError:  # pragma: no cover
            input_tokens = 0  # pragma: no cover
            output_tokens = usage.get("total_tokens", 0) if isinstance(usage, dict) else 0  # pragma: no cover

        if input_tokens > 0 or output_tokens > 0 or cost > 0:
            import hashlib

            hashlib.sha256(workflow.info().workflow_id.encode("utf-8")).hexdigest()
            receipt = TokenBurnReceipt(
                event_cid=f"burn-{uuid.uuid4()}",
                prior_event_hash=hashlib.sha256(workflow.info().workflow_id.encode("utf-8")).hexdigest(),
                timestamp=workflow.now().timestamp(),
                tool_invocation_cid=node_cid,
                input_tokens=int(input_tokens),
                output_tokens=int(output_tokens),
                burn_magnitude=int(cost),
            )
            await workflow.execute_activity(
                "RecordTokenBurnIOActivity",
                args=[workflow.info().workflow_id, receipt.model_dump(mode="json")],
                schedule_to_close_timeout=timedelta(minutes=1),
            )

    def reconcile_state(self, new_mutable_state: dict[str, Any]) -> None:
        """Reconcile the mutated state updates."""
        if self._current_state_envelope is None:
            msg = "No current state envelope available."
            raise ValueError(msg)

        for key in new_mutable_state:
            if key in self._current_state_envelope.state_vector.immutable_matrix:
                msg = f"CRITICAL STATE VIOLATION: Attempted to modify read-only context key '{key}'."
                raise ValueError(msg)

        import copy

        mut_mem_copy = copy.deepcopy(self._current_state_envelope.state_vector.mutable_matrix or {})
        for key, value in new_mutable_state.items():
            mut_mem_copy[key] = value

        new_state_vector = copy.deepcopy(self._current_state_envelope.state_vector)
        object.__setattr__(new_state_vector, "mutable_matrix", mut_mem_copy)
        object.__setattr__(self._current_state_envelope, "state_vector", new_state_vector)

        new_clock = self._current_state_envelope.trace_context.causal_clock + 1
        new_trace_context = copy.deepcopy(self._current_state_envelope.trace_context)
        object.__setattr__(new_trace_context, "causal_clock", new_clock)
        object.__setattr__(self._current_state_envelope, "trace_context", new_trace_context)

    def enforce_governance_limits(self, governance: dict[str, Any] | None, start_time: Any) -> None:
        """Enforces the economic constraints.

        Args:
            governance: The governance dictionary injected from the manifest.
            start_time: The start time of the workflow from `workflow.now()`.
        """
        if not governance:
            return

        max_global_tokens = governance.get("max_global_tokens")
        if max_global_tokens is not None and self._accumulated_tokens > max_global_tokens:
            msg = f"Global token budget breached: {self._accumulated_tokens} > {max_global_tokens}"
            raise ValueError(msg)

        max_budget_magnitude = governance.get("max_budget_magnitude")
        if max_budget_magnitude is not None and self._accumulated_cost > max_budget_magnitude:
            msg = f"Global budget magnitude breached: {self._accumulated_cost} > {max_budget_magnitude}"
            raise ValueError(msg)

        global_timeout_seconds = governance.get("global_timeout_seconds")
        if global_timeout_seconds is not None:
            elapsed_seconds = (workflow.now() - start_time).total_seconds()  # pragma: no cover
            if elapsed_seconds > global_timeout_seconds:  # pragma: no cover
                msg = f"Global TTL breached: {elapsed_seconds} > {global_timeout_seconds}"  # pragma: no cover
                raise ValueError(msg)  # pragma: no cover

    def enforce_lbac_clearance(
        self,
        allowed_classifications: list[str] | None,
        tool_classification: str | None = None,
    ) -> None:
        """Enforces the LBAC logical isolation clearance.

        AGENT INSTRUCTION: Enforces strict Logical Based Access Control (LBAC) isolation.
        The clearance hierarchy is mathematically bounded as:
        public < internal < confidential < restricted.
        """
        hierarchy = {"public": 0, "internal": 1, "confidential": 2, "restricted": 3}

        max_allowed_level = 0
        if allowed_classifications:
            for cls in allowed_classifications:
                level_str = str(cls).lower()
                level_val = hierarchy.get(level_str, 3)
                if level_val > max_allowed_level:
                    max_allowed_level = level_val
        else:
            max_allowed_level = 3

        target_level_str = (tool_classification or "restricted").lower()
        target_level_val = hierarchy.get(target_level_str, 3)

        if target_level_val > max_allowed_level:
            msg = f"LBAC clearance breached. Tool level '{target_level_str}' exceeds allowed clearance."
            raise PermissionError(msg)

    @workflow.query(name="get_current_state")
    def get_current_state(self) -> dict[str, Any]:
        """Query the current state of the workflow."""
        if self._current_state_envelope:
            return self._current_state_envelope.model_dump(mode="json")
        return {}

    @workflow.signal(name="apply_state_delta")
    async def apply_state_delta(self, delta_payload: dict[str, Any]) -> None:
        """Apply a CRDT state delta and echo the state."""
        workflow.logger.info("Received CRDT delta signal.")  # pragma: no cover
        if self._current_state_envelope is None:  # pragma: no cover
            msg = "Cannot apply state delta without an active envelope."  # pragma: no cover
            raise ValueError(msg)  # pragma: no cover
        # pragma: no cover
        self.reconcile_state(delta_payload)  # pragma: no cover
        # pragma: no cover
        await workflow.execute_activity(  # pragma: no cover
            "BroadcastStateEchoIOActivity",
            args=[workflow.info().workflow_id, self._current_state_envelope.model_dump(mode="json")],
            schedule_to_close_timeout=timedelta(seconds=10),
        )

    @workflow.signal(name="receive_oracle_override")
    def receive_oracle_override(self, corrected_intent: dict[str, Any]) -> None:
        """Receive the absolute ground-truth injection from the Oracle."""
        workflow.logger.info("Received Epistemic Injection (Oracle Override).")
        self._pending_oracle_override = corrected_intent

    @workflow.signal(name="inject_oracle_resolution")
    async def inject_oracle_resolution(self, payload: dict[str, Any]) -> None:
        """Inject the resolving priors from the human Oracle."""
        workflow.logger.info("Received Oracle resolution priors.")  # pragma: no cover
        self._current_oracle_resolution = payload  # pragma: no cover

    async def emit_mcp_ui_intent(
        self,
        intent_type: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        """Compile and emit an MCPClientIntent to the telemetry broker dynamically.

        Emits diagnostic UI intents without coupling to UI rendering code.
        """
        from datetime import timedelta  # pragma: no cover

        # pragma: no cover
        ctx = context or {}  # pragma: no cover
        mcp_intent = {"intent_type": intent_type, "raw_payload": ctx}  # pragma: no cover
        # pragma: no cover
        # Emit to telemetry broker  # pragma: no cover
        await workflow.execute_activity(  # pragma: no cover
            "BroadcastStateEchoIOActivity",  # pragma: no cover
            args=[  # pragma: no cover
                workflow.info().workflow_id,  # pragma: no cover
                {"type": "MCPClientIntent", "intent": mcp_intent},  # pragma: no cover
            ],  # pragma: no cover
            schedule_to_close_timeout=timedelta(seconds=10),  # pragma: no cover
        )  # pragma: no cover
        workflow.logger.info(f"Emitted MCPClientIntent ({intent_type}) as raw telemetry.")  # pragma: no cover

    async def intercept_kinematic_intent(
        self,
        tool_name: str,
        intent_payload: dict[str, Any],
    ) -> dict[str, Any]:
        """Intercept SpatialKinematicActionIntent before ROS2 actuation.

        If the target tool maps to a ros2_bridge MCP, dynamically injects
        a LifecycleTriggerEvent demanding a WetwareAttestationContract
        (biometric sign-off) from the on-site operator.

        Args:
            tool_name: The MCP tool name being invoked.
            intent_payload: The SpatialKinematicActionIntent dict.

        Returns:
            The intent payload (possibly enriched with attestation receipt)
            or raises if safety guillotine is not met.
        """
        # Detect if this is a cyber-physical actuation target
        ros2_tool_prefixes = ("ros2_bridge", "execute_se3", "cyber_physical", "actuator")  # pragma: no cover
        # pragma: no cover
        is_kinematic = any(tool_name.lower().startswith(prefix) for prefix in ros2_tool_prefixes)  # pragma: no cover
        # pragma: no cover
        if not is_kinematic:  # pragma: no cover
            return intent_payload  # pragma: no cover
        # pragma: no cover
        workflow.logger.warning(  # pragma: no cover
            f"⚠️ KINEMATIC SAFETY GUILLOTINE: Physical actuation detected "  # pragma: no cover
            f"for tool '{tool_name}'. Demanding WetwareAttestationContract."  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        # Emit a LifecycleTriggerEvent requesting biometric intervention  # pragma: no cover
        await self.emit_mcp_ui_intent(  # pragma: no cover
            intent_type="wetware_attestation",  # pragma: no cover
            context={  # pragma: no cover
                "tool_name": tool_name,  # pragma: no cover
                "target_coordinate": intent_payload.get("target_coordinate"),  # pragma: no cover
                "se3_transform": intent_payload.get("se3_transform"),  # pragma: no cover
                "safety_level": "PHYSICAL_ACTUATION",  # pragma: no cover
            },  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        # Halt: Wait for Oracle resolution (biometric sign-off)  # pragma: no cover
        attestation = await self.enforce_physical_safety_guillotine()  # pragma: no cover
        # pragma: no cover
        if attestation is None:  # pragma: no cover
            msg = (  # pragma: no cover
                f"Physical Safety Guillotine: WetwareAttestationContract not fulfilled "  # pragma: no cover
                f"for tool '{tool_name}'. Actuation blocked."  # pragma: no cover
            )  # pragma: no cover
            raise PermissionError(msg)  # pragma: no cover
        # pragma: no cover
        # Enrich the intent with the attestation receipt  # pragma: no cover
        intent_payload["wetware_attestation"] = attestation  # pragma: no cover
        intent_payload["safety_guillotine_passed"] = True  # pragma: no cover
        # pragma: no cover
        workflow.logger.info(  # pragma: no cover
            f"✅ WetwareAttestationContract fulfilled for '{tool_name}'. Proceeding with physical actuation."  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        return intent_payload  # pragma: no cover

    async def enforce_physical_safety_guillotine(
        self,
        timeout_seconds: int = 300,
    ) -> dict[str, Any] | None:
        """Block execution until a WetwareAttestationContract is received.

        Waits for the Oracle to inject a resolution containing the
        biometric attestation. Times out after the specified duration.

        Args:
            timeout_seconds: Maximum wait time for human attestation.

        Returns:
            The attestation dict if fulfilled, None if timed out.
        """
        from datetime import timedelta  # pragma: no cover

        # pragma: no cover
        workflow.logger.info(  # pragma: no cover
            f"🔒 Physical Safety Guillotine ENGAGED. Awaiting biometric attestation (timeout: {timeout_seconds}s)..."  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        # Clear any prior resolution  # pragma: no cover
        self._current_oracle_resolution = None  # pragma: no cover
        # pragma: no cover
        # Wait for the Oracle to inject the attestation  # pragma: no cover
        await workflow.wait_condition(  # pragma: no cover
            lambda: self._current_oracle_resolution is not None,  # pragma: no cover
            timeout=timedelta(seconds=timeout_seconds),  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        if self._current_oracle_resolution is None:  # pragma: no cover
            workflow.logger.error(
                "Physical Safety Guillotine: Attestation timeout. Motor actuation BLOCKED."
            )  # pragma: no cover
            return None  # pragma: no cover
        # pragma: no cover
        attestation = self._current_oracle_resolution  # pragma: no cover
        self._current_oracle_resolution = None  # pragma: no cover
        # pragma: no cover
        # Log the InterventionReceipt to the Epistemic Ledger  # pragma: no cover
        await workflow.execute_activity(  # pragma: no cover
            "StoreEpistemicStateIOActivity",  # pragma: no cover
            args=[  # pragma: no cover
                workflow.info().workflow_id,  # pragma: no cover
                f"wetware-attestation-{int(workflow.now().timestamp())}",  # pragma: no cover
                False,  # pragma: no cover
                {"type": "WetwareAttestationContract", "attestation": attestation},  # pragma: no cover
                {
                    "attestation_fulfilled": True,
                    "operator": (attestation or {}).get("operator_id", "unknown"),
                },  # pragma: no cover
            ],  # pragma: no cover
            schedule_to_close_timeout=timedelta(minutes=1),  # pragma: no cover
        )  # pragma: no cover
        # pragma: no cover
        return attestation  # pragma: no cover
