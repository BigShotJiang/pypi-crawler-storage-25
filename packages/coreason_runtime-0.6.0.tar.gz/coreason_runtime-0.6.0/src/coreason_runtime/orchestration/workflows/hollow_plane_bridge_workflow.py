# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

"""Hollow Plane Bridging Engine logic.

AGENT INSTRUCTION: This workflow securely transfers agent state across non-intersecting ontologies.
"""

from datetime import timedelta
from typing import TypedDict

from temporalio import activity, workflow

from coreason_runtime.utils.exceptions import ManifestConformanceError


class BridgeRequestDict(TypedDict, total=False):
    target_plane: str


class ObserverPhysicsDict(TypedDict, total=False):
    optical_center_x: float


class TensorDict(TypedDict, total=False):
    tensor_hash: str


class TensorBoundaryPayload(TypedDict, total=False):
    bridge_request: BridgeRequestDict
    observer: ObserverPhysicsDict
    tensor: TensorDict
    boundary_verified: bool


class TensorBoundaryResult(TypedDict, total=False):
    boundary_verified: bool
    target_plane: str


class ProjectorResult(TypedDict, total=False):
    projection_status: str
    transported: bool


@activity.defn
async def verify_tensor_boundary_activity(payload: TensorBoundaryPayload) -> TensorBoundaryResult:
    """Verify semantic boundaries before bridging.

    AGENT INSTRUCTION: Validate the ObserverPhysics payload using the
    NDimensionalTensorManifest to determine crossing constraints.

    Mocks lancedb / latent verification semantic checks.
    Requires compatible dimensions or mathematically sound projections.
    """
    activity.logger.info("Verifying semantic bounding constraints across tensor manifest")
    bridge_req = payload.get("bridge_request", {})
    if (bridge_req or {}).get("target_plane") is None:
        msg = "Hollow Plane Boundary Violation: Missing target plane"
        raise ManifestConformanceError(msg)

    target_plane = (bridge_req or {}).get("target_plane", "unknown")

    return TensorBoundaryResult(boundary_verified=True, target_plane=target_plane)


@activity.defn
async def cross_dimensional_state_projector_activity(payload: TensorBoundaryPayload) -> ProjectorResult:
    """Execute the multi-dimensional transport.

    AGENT INSTRUCTION: Mathematically reshape the tensor for the target topology plane.
    Mocks state projection math mapped into target ontology.
    """
    activity.logger.info("Executing cross-dimensional hollow plane transfer")
    if not payload.get("boundary_verified"):
        msg = "Hollow Plane Boundary Violation: unverified projection"
        raise ManifestConformanceError(msg)

    return ProjectorResult(projection_status="complete", transported=True)


@workflow.defn
class HollowPlaneBridgeWorkflow:
    """Orchestrate N-dimensional hollow plane bridging."""

    @workflow.run
    async def run(self, payload: TensorBoundaryPayload) -> ProjectorResult:
        """Bridging lifecycle."""
        workflow.logger.info("Transition: orchestrate verify_tensor_boundary_activity")
        verify_result = await workflow.execute_activity(
            verify_tensor_boundary_activity,
            payload,
            schedule_to_close_timeout=timedelta(seconds=60),
        )

        projector_payload = TensorBoundaryPayload(**payload)
        projector_payload.update(verify_result)  # type: ignore

        workflow.logger.info("Transition: orchestrate cross_dimensional_state_projector")
        return await workflow.execute_activity(
            cross_dimensional_state_projector_activity,
            projector_payload,
            schedule_to_close_timeout=timedelta(seconds=120),
        )
