# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
from typing import Any

from coreason_manifest import AnyTopologyManifest, MCPClientIntent
from fastapi import APIRouter, HTTPException, Request
from pydantic import TypeAdapter, ValidationError
from temporalio.client import Client, WorkflowExecutionStatus

from coreason_runtime.orchestration.engine import CoreasonRuntime
from coreason_runtime.sandbox.executor import WasmSandboxExecutor
from coreason_runtime.utils.settings import COREASON_TEMPORAL_HOST

sandbox_router = APIRouter(prefix="/api/v1/sandbox", tags=["Sandbox"])
state_router = APIRouter(prefix="/api/v1/state", tags=["State"])

AnyTopologyManifestAdapter: TypeAdapter[Any] = TypeAdapter(AnyTopologyManifest)


@sandbox_router.post("/execute")
async def execute_sandbox(tool_name: str, intent: MCPClientIntent) -> dict[str, Any]:
    """Execute a WASM capability in the Extism physics engine.

    Args:
        tool_name: The name of the WASM tool to execute.
        intent: The capability payload (MCP client intent).

    Returns:
        A dictionary containing deterministic physical profiling metrics, logs, and cryptographic provenance.
    """
    executor = WasmSandboxExecutor()
    return await executor.execute_actuator(tool_name, intent)


@state_router.post("/sync/{workflow_id}")
async def sync_state(
    workflow_id: str, delta_payload: dict[str, Any], request: Request
) -> dict[str, str]:  # pragma: no cover
    """Sync state by signaling the workflow with a CRDT delta.

    Args:
        workflow_id: The Temporal workflow ID.
        delta_payload: The state delta.
        request: The FastAPI request object.

    Returns:
        Status indicating whether the signal was accepted.
    """
    content_length = request.headers.get("content-length")
    max_size = 256 * 1024
    if content_length and int(content_length) > max_size:
        raise HTTPException(status_code=413, detail="Payload Too Large")

    if not content_length:
        raw_size = len(json.dumps(delta_payload).encode("utf-8"))
        if raw_size > max_size:
            raise HTTPException(status_code=413, detail="Payload Too Large")
    try:
        # Pre-flight validation using pydantic TypeAdapter
        AnyTopologyManifestAdapter.validate_python(delta_payload)
    except ValidationError as err:
        raise HTTPException(status_code=422, detail="Invalid state delta payload") from err

    temporal_host = COREASON_TEMPORAL_HOST
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)
        desc = await handle.describe()
        if desc.status != WorkflowExecutionStatus.RUNNING:
            raise HTTPException(status_code=410, detail="Workflow has already finished")

        await handle.signal("apply_state_delta", delta_payload)
        return {"status": "signal_accepted"}
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) from e


@state_router.get("/sync/{workflow_id}")
async def read_state(workflow_id: str) -> dict[str, Any]:  # pragma: no cover
    """Read the current state of the workflow by querying it.

    Args:
        workflow_id: The Temporal workflow ID.

    Returns:
        The current state payload of the workflow.
    """
    temporal_host = COREASON_TEMPORAL_HOST
    try:
        client = await Client.connect(temporal_host)
        handle = client.get_workflow_handle(workflow_id)
        state = await handle.query("get_current_state")
        return {"workflow_id": workflow_id, "state": state}
    except Exception as err:
        raise HTTPException(status_code=404, detail="Workflow not found or query failed.") from err


@state_router.post("/execute")
async def execute_manifest(payload: dict[str, Any]) -> dict[str, Any]:  # pragma: no cover
    """Execute a complete Swarm/DAG manifest directly via the API.

    Args:
        payload: Dictionary containing the loaded 'manifest' and optional 'query'.

    Returns:
        The final execution dictionary.
    """
    try:
        engine = CoreasonRuntime()
        await engine.connect()

        # Retrofit legacy REST/Client topologies transparently
        raw_manifest: dict[str, Any] = payload.get("manifest", {})
        for topo_data in raw_manifest.get("topology", {}).values():
            if isinstance(topo_data, dict) and "nodes" in topo_data:
                for _node_id, node_data in list(topo_data["nodes"].items()):
                    if isinstance(node_data, dict):
                        if "type" in node_data and "topology_class" not in node_data:
                            node_data["topology_class"] = node_data.pop("type")
                        if "runtime_context" in node_data:
                            del node_data["runtime_context"]

        result = await engine.execute_from_dict(raw_manifest, exogenous_perturbation_vector=payload.get("query"))
        return {"status": "success", "result": result}
    except Exception as e:
        import traceback

        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e)) from e
