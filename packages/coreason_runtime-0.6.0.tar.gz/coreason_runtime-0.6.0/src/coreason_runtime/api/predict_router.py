# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

import json
import os
import uuid
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse

# Load .env so CLOUD_ORACLE_* vars are available whether the server is
# started via `coreason serve` (which doesn't call load_dotenv) or directly.
try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover
    pass  # python-dotenv is optional; env vars may be set externally

from coreason_runtime.api.schema import TopologySynthesisRequest, _generate_cached_schema
from coreason_runtime.tensor.client import CloudOracleClient
from coreason_runtime.utils.logger import logger
from coreason_runtime.utils.settings import COREASON_COMPUTE_BUDGET

predict_router = APIRouter(prefix="/api/v1/predict", tags=["Topology Synthesis"])


def _build_synthesis_prompt(topology_dict: dict[str, Any] | None, user_prompt: str, discovery_context: str = "") -> str:
    """Build the LLM prompt for agent synthesis, topology-aware."""
    topology_dict = topology_dict or {}
    topology_section = topology_dict.get("topology", {})
    existing_nodes = topology_section.get("nodes", {})
    topology_type = topology_section.get("type", "unknown")
    existing_summary = (
        "\n".join(f"  - {nid}: {props.get('description', '(no description)')}" for nid, props in existing_nodes.items())
        if existing_nodes
        else "  (No existing agents. This is a blank canvas.)"
    )

    import json

    from coreason_manifest import CognitiveAgentNodeProfile

    # Because tokens are not an issue, we supply the full ontology constraint directly inline
    # to maximize semantic reasoning alongside structural constrained decoding.
    schema_hint = json.dumps(CognitiveAgentNodeProfile.model_json_schema(), indent=2)
    user_prompt = user_prompt.strip() if isinstance(user_prompt, str) else ""
    user_hint = f"\nUser intent: {user_prompt}" if user_prompt else ""

    if user_prompt:
        rule_3 = (
            "The 'description' field MUST contain the exact, full instruction set provided "
            "in the User intent, preserving all formatting and rules without summarizing them."
        )
    else:
        rule_3 = (
            "The 'description' field MUST provide a detailed, autonomous instruction "
            "for the NEXT logical step in the sequence based on the existing agents."
        )

    topology_context = (
        f"You are currently building within a '{topology_type}' topology domain.\n"
        f"Ensure the new agent strictly adheres to the physical constraints of this domain."
    )

    return (
        f"You are a CoReason topology architect. "
        f"Given the existing swarm topology below, predict the single best NEXT agent node to add.{user_hint}\n"
        f"IMPORTANT DIAGNOSTICS: {discovery_context}\n\n"
        f"{topology_context}\n"
        f"Existing nodes:\n{existing_summary}\n\n"
        f"Rules:\n"
        f"1. node_cid MUST match the DID pattern: ^did:[a-z0-9]+:[a-zA-Z0-9.\\-_:]+$\n"
        f"2. type MUST be 'agent'.\n"
        f"3. {rule_3}\n"
        f"4. The node_cid must be unique and not duplicate any existing node.\n"
        f"5. The new agent MUST be contextually appropriate for the '{topology_type}' topology domain.\n"
        f"6. ANTI-CRUD: Do NOT use legacy terms like 'Create', 'Update', 'Delete', 'Manager' in node names. Use causal terms (e.g., 'Synthesizer', 'Transmuter', 'Validator').\n"
        f"7. When generating the 'description' field, you MUST explicitly instruct the agent "
        f"that its final JSON response must be a stringified JSON block "
        f"wrapped inside a required root 'output' key.\n\n"
        f"Return ONLY a JSON object matching this schema:\n{schema_hint}"
    )


async def _synthesize_expansion(request: TopologySynthesisRequest) -> PlainTextResponse:  # pragma: no cover
    """Synthesize the next agent node for a given topology.

    Accepts the current manifest as raw text (JSON or YAML), uses the Cloud
    Oracle to predict the optimal next agent, merges it into the topology,
    and returns the updated document in the same format (JSON or YAML).
    """
    if isinstance(request.topology, str):
        raw = request.topology.strip()
    elif isinstance(request.topology, dict):
        raw = json.dumps(request.topology)
    else:
        raw = "{}"
    is_json = raw.startswith("{")

    # Parse current topology
    try:
        if is_json:
            topology_dict = json.loads(raw)
        else:
            import yaml

            topology_dict = yaml.safe_load(raw)
    except Exception as exc:
        logger.error(f"Failed to extract metric vector metadata: {exc}")
        raise HTTPException(status_code=422, detail=f"Failed to parse topology: {exc}") from exc

    discovery_context = ""
    is_deficit = False
    discovery_results = []
    if request.user_prompt:  # pragma: no cover
        from coreason_runtime.sandbox.discovery import DiscoveryIndexer
        from coreason_runtime.sandbox.mcp.mcp_client_manager import MCPClientManager

        try:
            indexer = DiscoveryIndexer()
            indexer.sync_local_wasm()
            mcp_manager = MCPClientManager()
            for server_cid in mcp_manager.profiles:
                mcp_manager.get_client(server_cid)
            await indexer.sync_remote_mcp(mcp_manager)

            discovery_results = indexer.search_capabilities(request.user_prompt, limit=1)
            is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 1.65

            prompt_lower = request.user_prompt.lower() if request.user_prompt else ""
            intent_builds_tool = (
                ("build" in prompt_lower and "tool" in prompt_lower)
                or "create tool" in prompt_lower
                or "make tool" in prompt_lower
            )

            if is_deficit and intent_builds_tool:
                discovery_context = "Semantic deficit! We MUST synthesize a 'system' node mapped explicitly to 'macro_forge' to build/compile missing capabilities."
            elif not is_deficit and discovery_results:
                top_tool = discovery_results[0].get("name", "unknown_tool")
                discovery_context = f"Found MCP/Native capabilities: '{top_tool}'. Output MUST confidently hook into this existing tool pipeline."
            else:
                discovery_context = "No specific isomorphic tools matched. Proceed with standard autonomous reasoning."
        except Exception as e:
            logger.warning(f"Semantic discovery failed during expansion pipeline: {e}")

    # Build synthesis prompt and call Cloud Oracle directly
    prompt = _build_synthesis_prompt(topology_dict, request.user_prompt or "", discovery_context)
    # Fetch the full workflow schema to extract CognitiveAgentNodeProfile definitions
    workflow_schema = _generate_cached_schema("workflow")
    agent_profile_schema = workflow_schema.get("$defs", {}).get("CognitiveAgentNodeProfile", {})

    # Safely copy properties to avoid mutating the cached schema
    agent_props = agent_profile_schema.get("properties", {}).copy()

    # Strictly strip advanced nested ontological types so the LLM doesn't try to hallucinate them and trigger Pydantic validation crashes
    for strict_key in [
        "peft_adapters",
        "logit_steganography",
        "agent_attestation",
        "compute_frontier",
        "active_attention_ray",
        "secure_sub_session",
        "baseline_cognitive_state",
        "reflex_policy",
        "epistemic_policy",
        "correction_policy",
        "escalation_policy",
        "prm_policy",
        "active_inference_policy",
        "analogical_policy",
        "interventional_policy",
        "symbolic_handoff_policy",
        "audit_policy",
        "anchoring_policy",
        "grpo_reward_policy",
        "emulation_profile",
        "gflownet_balance_policy",
        "hardware",
        "security",
    ]:
        agent_props.pop(strict_key, None)
    agent_props["node_cid"] = {
        "type": "string",
        "description": "The unique Decentralized Identifier (DID) for this agent.",
    }

    agent_reqs = list(agent_profile_schema.get("required", []))
    if "node_cid" not in agent_reqs:
        agent_reqs.append("node_cid")

    schema_dict = {
        "type": "object",
        "required": ["new_node"],
        "properties": {
            "new_node": {
                "type": "object",
                "required": agent_reqs,
                "properties": agent_props,
                "additionalProperties": False,
            }
        },
        "$defs": workflow_schema.get("$defs", {}),
        "additionalProperties": False,
    }

    oracle = CloudOracleClient(
        api_key=os.getenv("CLOUD_ORACLE_API_KEY"),
        base_url=os.getenv("CLOUD_ORACLE_BASE_URL"),
        model=os.getenv("CLOUD_ORACLE_MODEL"),
    )

    try:
        raw_json, usage, _ = await oracle.generate(prompt, schema_dict)

        # Strip potential markdown formatting (```json ... ```)
        out_text = raw_json.strip()
        if out_text.startswith("```"):  # pragma: no cover
            lines = out_text.split("\n")
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].startswith("```"):
                lines = lines[:-1]
            out_text = "\n".join(lines).strip()

        # Find the first { and last } to handle prepended/appended conversational text
        start_idx = out_text.find("{")
        end_idx = out_text.rfind("}")
        if start_idx != -1 and end_idx != -1 and end_idx >= start_idx:
            out_text = out_text[start_idx : end_idx + 1]

        result = json.loads(out_text)
    except Exception as e:
        logger.exception(f"Topology synthesis LLM call failed: {e}")
        raise HTTPException(
            status_code=503,
            detail=f"Synthesis engine failure: LLM inference did not return a valid response. {e}",
        ) from e

    # Extract and validate the new node (handle both wrapped and unwrapped LLM outputs)
    new_node_raw = result.get("new_node", result)
    if not isinstance(new_node_raw, dict):
        raise HTTPException(  # pragma: no cover
            status_code=503,
            detail="Synthesis engine returned malformed output: 'new_node' key missing or not an object.",
        )

    node_cid = new_node_raw.get("node_cid")
    if not node_cid or not str(node_cid).startswith("did:"):
        # Generate a safe fallback DID if the LLM produced an invalid one
        node_cid = f"did:coreason:synthesized-agent-{uuid.uuid4().hex[:8]}"
        logger.warning(f"LLM produced invalid node_cid; using generated fallback: {node_cid}")

    # Preserve all strictly generated ontology attributes, removing node_cid so it acts as the dict key
    node_payload = new_node_raw.copy()
    node_payload.pop("node_cid", None)

    # Remove incompatible/hallucinated dicts that fail Pydantic strict Enum instantiations and forbidden properties
    for strict_key in [
        "peft_adapters",
        "logit_steganography",
        "agent_attestation",
        "compute_frontier",
        "active_attention_ray",
        "secure_sub_session",
        "baseline_cognitive_state",
        "reflex_policy",
        "epistemic_policy",
        "correction_policy",
        "escalation_policy",
        "prm_policy",
        "active_inference_policy",
        "analogical_policy",
        "interventional_policy",
        "symbolic_handoff_policy",
        "audit_policy",
        "anchoring_policy",
        "grpo_reward_policy",
        "emulation_profile",
        "gflownet_balance_policy",
        "hardware",
        "security",
        "type",
    ]:
        node_payload.pop(strict_key, None)

    # Default required fields if LLM missed them
    node_payload["topology_class"] = node_payload.get("topology_class", "agent")
    node_payload["description"] = node_payload.get("description", "Synthesized agent.")

    # Remove nulls for cleaner YAML/JSON payloads
    node_payload = {k: v for k, v in node_payload.items() if v is not None}

    from coreason_manifest import CognitiveAgentNodeProfile
    from pydantic import ValidationError

    try:
        CognitiveAgentNodeProfile.model_validate(node_payload)
    except ValidationError as e:
        logger.exception(f"Synthesis engine hallucinated invalid ontology: {e}")
        raise HTTPException(
            status_code=503,
            detail=f"Synthesis engine hallucinated invalid ontology structure for agent node: {e}",
        ) from e

    if topology_dict is None:  # pragma: no cover
        topology_dict = {}

    if "topology" not in topology_dict:
        topology_dict["topology"] = {}
    if "nodes" not in topology_dict["topology"]:
        topology_dict["topology"]["nodes"] = {}

    topology_dict["topology"]["nodes"][node_cid] = node_payload

    logger.info(f"Synthesis complete — new node '{node_cid}' added ({'prompt' if usage else 'no'} usage tracked). ")

    # Re-serialise in the original format
    if is_json:
        return PlainTextResponse(content=json.dumps(topology_dict, indent=2))
    import yaml

    return PlainTextResponse(content=yaml.dump(topology_dict, default_flow_style=False, allow_unicode=True))


async def _synthesize_scratch(request: TopologySynthesisRequest) -> dict[str, Any]:  # pragma: no cover
    """Synthesize a complete topology manifest from a raw user prompt, then dispatch.

    Uses a two-phase FSM-constrained approach:
    1. Phase 1: LLM selects the optimal topology type (dag, swarm, council,
       evolutionary, smpc, evaluator_optimizer, digital_twin, macro_adversarial,
       macro_federation, macro_forge, macro_elicitation) based on the user's intent.
    2. Phase 2: Generates the full manifest against the resolved Pydantic schema.
    3. Wraps the manifest in an ExecutionEnvelopeState.
    4. Dispatches the appropriate Temporal workflow.

    Returns:
        A dict with workflow_id, manifest_type, and node_count.
    """
    from coreason_runtime.tensor.router.tensor_router import TensorRouter

    # Step 0: Semantic Interrogation & Zero-Day Forge Fallback
    if "forge" not in (request.topological_manifold_bias or "") and "elicitation" not in (
        request.topological_manifold_bias or ""
    ):
        from coreason_runtime.sandbox.discovery import DiscoveryIndexer

        try:
            indexer = DiscoveryIndexer()
            indexer.sync_local_wasm()

            # Hook the remote MCP server capabilities into the local Discovery namespace
            from coreason_runtime.sandbox.mcp.mcp_client_manager import MCPClientManager

            mcp_manager = MCPClientManager()
            # Hydrate clients for all configured servers manually
            for server_cid in mcp_manager.profiles:
                mcp_manager.get_client(server_cid)
            await indexer.sync_remote_mcp(mcp_manager)

            discovery_results = indexer.search_capabilities(request.user_prompt or "", limit=1)
            is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 1.25

            prompt_lower = request.user_prompt.lower() if request.user_prompt else ""
            intent_builds_tool = (
                ("build" in prompt_lower and "tool" in prompt_lower)
                or "create tool" in prompt_lower
                or "make tool" in prompt_lower
            )

            if is_deficit and intent_builds_tool:
                logger.warning(
                    "[ZERO-DAY FORGE] Semantic Discovery deficit! No isomorphic tools found for intent. "
                    "Triggering macro_forge..."
                )

                router_forge = TensorRouter(os.getenv("KINETIC_BASE_URL", "http://localhost:8001"))
                forge_manifest, _ = await router_forge.synthesize_hybrid_workflow(
                    user_prompt=f"Create a native zero-day robust tool that solves: {request.user_prompt}",
                    topology_hint="macro_forge",
                )

                import typing
                import uuid

                from coreason_manifest import (
                    ExecutionEnvelopeState,
                    JsonPrimitiveState,
                    StateVectorProfile,
                    TraceContextState,
                )
                from temporalio.client import Client

                from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY
                from coreason_runtime.orchestration.worker import TASK_QUEUE

                forge_payload = forge_manifest.model_dump(mode="json", exclude_none=True)

                # Securely extract inner topology regardless of LLM wrapper hallucinations
                inner_topology = forge_payload.get("topology", forge_payload)

                u = str(uuid.uuid4())
                forge_trace_id = u[:14] + "7" + u[15:]

                for node_cid, node_data in inner_topology.get("nodes", {}).items():
                    node_type = str(node_data.get("type", ""))
                    if node_type == "agent" and "generator" in str(node_cid).lower():
                        node_data["action_space_cid"] = "CodeGeneratorYield"
                        dom_ext = node_data.get("domain_extensions", {})
                        dom_ext["CodeGeneratorYield"] = {
                            "tool_code": "The full source code of the tool inside a codeblock",
                            "tool_name": "The display name of the tool",
                            "tool_description": "A description of the tool",
                        }
                        node_data["domain_extensions"] = dom_ext
                    elif node_type == "system" and (
                        "verifier" in str(node_cid).lower() or "fuzz" in str(node_cid).lower()
                    ):
                        dom_ext = node_data.get("domain_extensions", {})
                        dom_ext["VerificationYield"] = {
                            "success": (
                                "BOOLEAN flag set to true if the code successfully passes "
                                "formal verification or fuzzing without critical errors."
                            ),
                            "justification": "Text description of the test results",
                        }
                        node_data["domain_extensions"] = dom_ext

                forge_envelope = ExecutionEnvelopeState[dict[str, Any]](
                    trace_context=TraceContextState(trace_cid=forge_trace_id, span_cid=forge_trace_id, causal_clock=0),
                    state_vector=StateVectorProfile(
                        immutable_matrix=typing.cast(
                            "dict[str, JsonPrimitiveState]",
                            {
                                "tenant_cid": getattr(request, "tenant_cid", "default-tenant"),
                                "session_cid": forge_trace_id,
                                "instruction": getattr(request, "user_prompt", None),
                            },
                        ),
                        mutable_matrix=typing.cast(
                            "dict[str, JsonPrimitiveState]",
                            {
                                "accumulated_tokens": 0,
                                "accumulated_cost": 0.0,
                                "iterations": 0,
                                "compute_budget": COREASON_COMPUTE_BUDGET,
                            },
                        ),
                        is_delta=False,
                    ),
                    payload=inner_topology,
                )

                temporal_client = await Client.connect("localhost:7233")
                workflow_func = _WORKFLOW_REGISTRY.get("macro_forge")

                logger.info("Dispatching Forge Workflow to Temporal to explicitly build missing capability...")
                forge_result = await temporal_client.execute_workflow(
                    typing.cast("Any", workflow_func),
                    forge_envelope.model_dump(mode="json"),
                    id=f"forge-{forge_trace_id}",
                    task_queue=TASK_QUEUE,
                )
                logger.info(f"Forge executed successfully: {forge_result}. Resyncing WASM memory...")
                indexer.sync_local_wasm()

                logger.info("Re-evaluating Semantic Discovery against newly forged tools...")
                discovery_results = indexer.search_capabilities(request.user_prompt or "", limit=1)
                is_deficit = not discovery_results or discovery_results[0].get("distance", 2.0) > 1.25

        except Exception as e:
            logger.exception(f"Semantic Discovery / Forge Fallback failed: {e}. Bypassing to blind DAG execution.")

    if not is_deficit and discovery_results:
        tool_match = discovery_results[0]
        actual_tool_cid = tool_match.get("capability_id") or tool_match.get("name") or str(tool_match)
        logger.info(f"Local Isomorphic Tool matched! injecting '{actual_tool_cid}' directly into LLM Latent Context.")
        forced_ctx = (request.epistemic_boundary_state or "") + (
            f"\n\nCRITICAL ARCHITECTURAL DIRECTIVE:\n"
            f"You MUST ensure at least one agent utilizes the following discovered capability:\n"
            f'action_space_cid: "{actual_tool_cid}"\n'
            f"Description: {tool_match.get('description')}\n"
            f"Integrate this tool into the most appropriate topology for the user's task."
        )
        request.epistemic_boundary_state = forced_ctx

    # Step 1: Synthesize manifest via TensorRouter FSM loop
    try:
        router = TensorRouter(os.getenv("KINETIC_BASE_URL", "http://localhost:8001"))
        prompt = request.user_prompt or ""
        if request.epistemic_boundary_state:
            prompt = f"{request.epistemic_boundary_state}\n\nTask: {prompt}"

        manifest_instance, usage = await router.synthesize_hybrid_workflow(
            user_prompt=prompt,
            topology_hint=request.topological_manifold_bias,
        )
    except (ValueError, Exception) as e:
        logger.error(f"Manifest synthesis failed: {e}")
        raise HTTPException(
            status_code=503,
            detail=f"Manifest synthesis engine failure: {e}",
        ) from e

    # Step 2: Wrap in ExecutionEnvelopeState (mirrors engine.py dispatch pattern)
    import typing
    import uuid

    from coreason_manifest import (
        ExecutionEnvelopeState,
        JsonPrimitiveState,
        StateVectorProfile,
        TraceContextState,
    )
    from temporalio.client import Client

    from coreason_runtime.orchestration.engine import _WORKFLOW_REGISTRY
    from coreason_runtime.orchestration.worker import TASK_QUEUE

    # Convert the generated end-to-end WorkflowManifest into a dictionary safely
    is_valid = hasattr(manifest_instance, "model_dump")
    if is_valid:
        full_manifest_payload = manifest_instance.model_dump(mode="json", exclude_none=True)
    else:
        full_manifest_payload = manifest_instance

    # Safely abstract the inner topology structural block for Temporal worker dispatch
    topology_payload = full_manifest_payload.get("topology", {})
    manifest_type = topology_payload.get("topology_class", topology_payload.get("type", "dag"))

    # Force inject topology_class if pydantic model_dump stripped it due to default inclusion behavior
    for node_data in topology_payload.get("nodes", {}).values():
        if isinstance(node_data, dict) and "topology_class" not in node_data:
            node_data["topology_class"] = "agent"

    # Aggressively strip self-cycles from the final topology edges payload
    raw_edges = topology_payload.get("edges")
    if isinstance(raw_edges, list):
        clean_edges = []
        for edge in raw_edges:
            if (isinstance(edge, list) and len(edge) >= 2 and edge[0] == edge[1]) or (
                isinstance(edge, tuple) and len(edge) >= 2 and edge[0] == edge[1]
            ):
                continue
            if isinstance(edge, dict) and edge.get("source") == edge.get("target"):
                continue
            clean_edges.append(edge)
        topology_payload["edges"] = clean_edges

    u = str(uuid.uuid4())
    trace_id = u[:14] + "7" + u[15:]
    workflow_id = f"synthesis-{trace_id}"

    # Strictly override hallucinatable system variables
    tenant_cid = getattr(request, "tenant_cid", "default-tenant")

    envelope = ExecutionEnvelopeState[dict[str, Any]](
        trace_context=TraceContextState(trace_cid=trace_id, span_cid=trace_id, causal_clock=0),
        state_vector=StateVectorProfile(
            immutable_matrix=typing.cast(
                "dict[str, JsonPrimitiveState]",
                {
                    "tenant_cid": tenant_cid,
                    "session_cid": trace_id,
                    "instruction": getattr(request, "user_prompt", None),
                },
            ),
            mutable_matrix=typing.cast(
                "dict[str, JsonPrimitiveState]",
                {
                    "accumulated_tokens": 0,
                    "accumulated_cost": 0.0,
                    "iterations": 0,
                    "compute_budget": COREASON_COMPUTE_BUDGET,
                },
            ),
            is_delta=False,
        ),
        payload=topology_payload,
    )

    # Step 3: Dispatch to Temporal
    if not is_valid:
        logger.warning(f"Manifest failed schema validation! Skipping Temporal dispatch for trace {trace_id}.")
        return typing.cast("dict[str, Any]", full_manifest_payload)

    workflow_run_func = _WORKFLOW_REGISTRY.get(str(manifest_type))
    if not workflow_run_func:
        raise HTTPException(  # pragma: no cover
            status_code=422,
            detail=f"Synthesized manifest type '{manifest_type}' has no registered workflow.",
        )

    temporal_host = os.getenv("TEMPORAL_HOST", "localhost:7233")
    try:
        client = await Client.connect(temporal_host)
        await client.start_workflow(
            typing.cast("Any", workflow_run_func),
            envelope.model_dump(mode="json"),
            id=workflow_id,
            task_queue=TASK_QUEUE,
        )
    except Exception as e:  # pragma: no cover
        logger.exception(f"Temporal dispatch failed: {e}")  # pragma: no cover
        raise HTTPException(  # pragma: no cover
            status_code=503,
            detail=f"Workflow dispatch failure: {e}",
        ) from e

    node_count = len(topology_payload.get("nodes", {}))
    logger.info(
        f"Synthesis + dispatch complete — workflow_id={workflow_id}, "
        f"type={manifest_type}, nodes={node_count}, "
        f"usage={usage}"
    )

    full_manifest_payload["workflow_id"] = workflow_id
    full_manifest_payload["manifest_type"] = manifest_type
    full_manifest_payload["node_count"] = node_count
    return typing.cast("dict[str, Any]", full_manifest_payload)


@predict_router.post("/synthesize")
@predict_router.post("/topology")
async def synthesize_topology(request: TopologySynthesisRequest) -> Any:
    """Synthesize a complete manifesto from scratch OR expand the next agent.
    If 'topology' is present, performs expansion. If missing, performs scratch generation.
    """
    if request.topology:
        return await _synthesize_expansion(request)
    scratch_res = await _synthesize_scratch(request)

    import json

    from fastapi import Response

    return Response(content=json.dumps(scratch_res, indent=4), media_type="application/json")
