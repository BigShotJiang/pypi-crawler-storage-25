# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

import hashlib
import re
from typing import Any

from coreason_runtime.utils.logger import logger


class StreamBufferManager:
    """Manages continuous observation stream buffers with probabilistic forget gates.

    Applies StreamingDisfluencyContract rules to aggressively prune noise,
    stutters, and repetitions from token buffers before they exhaust the
    LLM context window.
    """

    @staticmethod
    def apply_forget_gate(
        state: Any,
        contract: Any,
    ) -> Any:
        """Apply the forget gate to a ContinuousObservationState.

        Iterates backward through the token_buffer up to max_lookback_window.
        Uses re.search with repair_marker_regex. If matched, and random decay
        chance is below decay_threshold, pops the offending tokens.

        Args:
            state: A ContinuousObservationState instance with a token_buffer.
            contract: A StreamingDisfluencyContract with decay_threshold,
                      repair_marker_regex, and max_lookback_window.

        Returns:
            The pruned ContinuousObservationState.
        """
        token_buffer: list[str] = list(getattr(state, "token_buffer", []))
        if not token_buffer:
            return state

        decay_threshold: float = float(getattr(contract, "decay_threshold", 0.5))
        repair_regex: str = str(getattr(contract, "repair_marker_regex", ""))
        max_lookback: int = int(getattr(contract, "max_lookback_window", len(token_buffer)))

        if not repair_regex:
            return state

        try:
            pattern = re.compile(repair_regex)
        except re.error as e:
            logger.warning(f"Invalid repair_marker_regex '{repair_regex}': {e}")
            return state

        pruned_buffer: list[str] = []
        lookback_start = max(0, len(token_buffer) - max_lookback)

        tokens_pruned = 0
        for idx, token in enumerate(token_buffer):
            if idx < lookback_start:
                pruned_buffer.append(token)
                continue

            if pattern.search(token):
                # Deterministic pseudo-random generation to prevent CRDT state forks
                seed = f"{idx}:{token}".encode()
                hash_digest = hashlib.sha1(seed, usedforsecurity=False).hexdigest()
                deterministic_float = int(hash_digest[:8], 16) / 0xFFFFFFFF

                if deterministic_float < decay_threshold:
                    tokens_pruned += 1
                    continue

            pruned_buffer.append(token)

        if tokens_pruned > 0:
            logger.info(
                f"StreamBufferManager: Pruned {tokens_pruned} disfluent tokens "
                f"from buffer of {len(token_buffer)} (lookback={max_lookback})."
            )

        return state.model_copy(update={"token_buffer": pruned_buffer})
