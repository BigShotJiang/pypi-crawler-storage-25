# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import TYPE_CHECKING, Any

import extism  # type: ignore

if getattr(extism, "Manifest", None) is None:
    extism.Manifest = dict[str, Any]

from coreason_runtime.utils.exceptions import PayloadTooLargeError

if TYPE_CHECKING:
    from coreason_manifest import CognitiveActionSpaceManifest


def build_extism_manifest(intent: Any) -> extism.Manifest:
    """
    Translate abstract manifest constraints into physical WebAssembly memory and network bounds.

    Args:
        intent: The MCPClientIntent specifying the tool invocation, or a raw dictionary payload.

    Returns:
        A dictionary representing an Extism manifest.
    """
    # Default Posture: Deny all.
    allowed_hosts: list[str] = []
    allowed_paths: dict[str, str] = {}

    # Policy Parsing: Inspect the intent.
    if hasattr(intent, "params"):
        intent_params = intent.params
    elif isinstance(intent, dict):
        intent_params = intent.get("params")
    else:
        intent_params = None

    if intent_params and isinstance(intent_params, dict):
        if "allowed_hosts" in intent_params and isinstance(intent_params["allowed_hosts"], list):
            for host in intent_params["allowed_hosts"]:
                if isinstance(host, str):
                    if len(host) > 1048576:  # pragma: no cover
                        msg = "Dictionary Bombing Prevented: 'allowed_hosts' string exceeds 1MB cap."
                        raise PayloadTooLargeError(msg)
                    allowed_hosts.append(host)

        if "allowed_paths" in intent_params and isinstance(intent_params["allowed_paths"], dict):
            for path, mapping in intent_params["allowed_paths"].items():
                if isinstance(path, str) and isinstance(mapping, str):
                    if len(path) > 1048576 or len(mapping) > 1048576:  # pragma: no cover
                        msg = "Dictionary Bombing Prevented: 'allowed_paths' string exceeds 1MB cap."
                        raise PayloadTooLargeError(msg)
                    allowed_paths[path] = mapping

    manifest: extism.Manifest = {
        "allowed_hosts": allowed_hosts,
        "allowed_paths": allowed_paths,
        "timeout_ms": 1000,
    }

    return manifest


def dynamic_capability_injection(  # pragma: no cover
    action_space: CognitiveActionSpaceManifest, mounted_capability: dict[str, Any]
) -> CognitiveActionSpaceManifest:
    """
    Dynamically appends a discovered capability to the agent's CognitiveActionSpaceManifest at runtime.
    Do not require a restart of the node.
    """
    from coreason_manifest import MCPCapabilityWhitelistPolicy, MCPServerManifest, StdioTransportProfile

    capability_name = mounted_capability.get("name", "dynamic_tool")

    action_space.capabilities[capability_name] = MCPServerManifest(
        server_cid="dynamic_mcp_pool",
        binary_hash=str(mounted_capability.get("binary_hash", "")),
        transport=StdioTransportProfile(command="extism", args=[]),
        capability_whitelist=MCPCapabilityWhitelistPolicy(),
        attestation_receipt=None,  # type: ignore[arg-type]
    )

    return action_space
