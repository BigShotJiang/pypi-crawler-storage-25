# Copyright (c) 2026 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_runtime

from typing import TYPE_CHECKING, Any

import extism  # type: ignore
from coreason_manifest.spec.ontology import (
    BoundedJSONRPCIntent,
    ExecutionNodeReceipt,
    MCPClientIntent,
)
from loguru import logger
from pydantic import ValidationError

from coreason_runtime.utils.exceptions import ManifestConformanceError

if TYPE_CHECKING:
    from pathlib import Path


class ExtismWasmEnclave:
    """AGENT INSTRUCTION: Zero-trust Wasm enclave executing arbitrary payload binaries."""

    def __init__(self) -> None:
        """Initialize the Enclave structure."""
        self.plugin: extism.Plugin | None = None

    def initialize_plugin(self, wasm_path: Path, manifest: dict[str, Any] | None = None) -> None:
        """Scaffold and initialize the extism plugin natively."""
        try:
            with open(wasm_path, "rb") as f:
                wasm_bytes = f.read()

            self.initialize_from_bytes(wasm_bytes, manifest)
        except Exception as e:
            msg = f"Plugin initialization trap: {e}"
            raise ManifestConformanceError(msg) from e

    def initialize_from_bytes(self, wasm_bytes: bytes, manifest: dict[str, Any] | None = None) -> None:
        """Scaffold and initialize the extism plugin natively directly from bytes."""
        try:
            plugin_manifest = {"wasm": [{"data": wasm_bytes}]}
            if manifest:
                plugin_manifest.update(manifest)

            self.plugin = extism.Plugin(plugin_manifest)
            logger.info("Initialized Extism plugin from bytes")
        except extism.Error as e:
            logger.error(f"Failed to initialize extism plugin: {e}")
            msg = f"Plugin initialization trap: {e}"
            raise ManifestConformanceError(msg) from e

    def execute_intent(
        self,
        function_name: str,
        intent: MCPClientIntent | BoundedJSONRPCIntent,
        **kwargs: Any,  # noqa: ARG002
    ) -> ExecutionNodeReceipt:
        """AGENT INSTRUCTION: Execute SOTA intent mappings bridging zero-trust execution bounds."""
        if not self.plugin:
            msg = "Extism plugin not initialized."
            raise ManifestConformanceError(msg)

        try:
            intent_json = intent.model_dump_json()
            logger.debug(f"Executing intent across Wasm boundary into function {function_name}")
            output_bytes = self.plugin.call(function_name, intent_json.encode("utf-8"))

            return ExecutionNodeReceipt.model_validate_json(output_bytes.decode("utf-8"))

        except extism.Error as e:
            logger.error(f"Wasm guest trapped or panicked: {e}")
            msg = f"Extism execution trap: {e}"
            raise ManifestConformanceError(msg) from e
        except ValidationError as e:
            logger.error(f"Wasm guest returned invalid ExecutionNodeReceipt payload: {e}")
            msg = f"Schema violation returning from Wasm: {e}"
            raise ManifestConformanceError(msg) from e
        except Exception as e:
            logger.error(f"Unexpected execution wrapper violation: {e}")
            msg = f"Execution wrapped failure: {e}"
            raise ManifestConformanceError(msg) from e
