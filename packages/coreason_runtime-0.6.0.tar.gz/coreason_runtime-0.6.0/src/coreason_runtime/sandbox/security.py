# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-runtime>

from enum import IntEnum

from coreason_runtime.utils.exceptions import SecurityViolationError


class TaintLevel(IntEnum):
    """Lattice-Based Access Control Taint Levels."""

    PUBLIC = 0
    CONFIDENTIAL = 1
    RESTRICTED = 2
    TOP_SECRET = 3


class LatticeReferenceMonitor:
    """AGENT INSTRUCTION: Reference monitor enforcing Bell-LaPadula Lattice-Based Access Control."""

    @staticmethod
    def elevate_taint(current_taint: TaintLevel, payload_taint: TaintLevel) -> TaintLevel:
        """Elevate the thread's taint to the max of current and payload."""
        return TaintLevel(max(current_taint, payload_taint))

    @staticmethod
    def verify_write_down(thread_taint: TaintLevel, sink_clearance: TaintLevel) -> None:
        """Enforce the 'No Write Down' axiom."""
        if thread_taint > sink_clearance:
            msg = f"Security Clearance Violation: thread taint '{thread_taint.name}' exceeds sink clearance '{sink_clearance.name}'."
            raise SecurityViolationError(msg)
