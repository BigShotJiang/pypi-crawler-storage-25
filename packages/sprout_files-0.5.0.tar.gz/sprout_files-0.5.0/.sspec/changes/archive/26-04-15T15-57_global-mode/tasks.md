---
change: "global-mode"
updated: "2026-04-15"
---

# Tasks

## Legend
`[ ]` Todo | `[x]` Done

## Tasks

### Phase 1: Data Model & Core Constants ✅
- [x] **1.1** Add `root` field to `CommandSpec`, `is_global` field to `CommandRegistry` `sprout/models.py`
- [x] **1.2** Add `GLOBAL_SPROUT_DIR` constant, `discover_global_dir()`, `iter_global_command_package_dirs()` `sprout/core.py`
- [x] **1.3** Add `root` parsing in `load_command_spec()` `sprout/core.py`

### Phase 2: Global Loading Pipeline ✅
- [x] **2.1** Implement `load_global_registry()` `sprout/core.py`
- [x] **2.2** Root field parsing in manifest `sprout/core.py`

### Phase 3: Global Variable Context ✅
- [x] **3.1** Extract `_build_builtin_time_context()` `sprout/core.py`
- [x] **3.2** Implement `_build_global_context()` `sprout/core.py`
- [x] **3.3** Modify `build_variable_context()` with `mode` param `sprout/core.py`
- [x] **3.4** Mode-aware template validation `sprout/core.py`

### Phase 4: Generation Pipeline Adaptation ✅
- [x] **4.1** `build_generation_plan()` — `allow_absolute` param `sprout/core.py`
- [x] **4.2** `build_generation_plan()` — root field resolution `sprout/core.py`
- [x] **4.3** `_resolve_action_cwd()` — `allow_absolute` param `sprout/core.py`
- [x] **4.4** `plan_post_actions()` / `build_action_context()` — global mode `sprout/core.py`

### Phase 5: CLI Integration ✅
- [x] **5.1** `-g/--global` flags for `new`, `list`, `doctor`; `--global` for `init` `sprout/cli.py`
- [x] **5.2** `_run_new()` global dispatch `sprout/cli.py`
- [x] **5.3** `_run_list()` / `_run_doctor()` global mode `sprout/cli.py`
- [x] **5.4** `initialize_global_workspace()` `sprout/scaffold.py`
- [x] **5.5** `_run_init()` global mode `sprout/cli.py`

### Phase 6: Tests & Documentation ✅
- [x] **6.1** Unit tests: global registry, variable context, root field `tests/test_core.py`
- [x] **6.2** CLI integration tests for `-g` flag `tests/test_cli_interaction.py`
- [x] **6.3** Update `user-guide.md` — global mode section `sprout/docs/user-guide.md`
- [x] **6.4** Update `command-authoring-guide.md` — global manifest, `root` field, variables `sprout/docs/command-authoring-guide.md`
- [x] **6.5** Update `spec-docs/sprout-architecture.md` — global mode section `.sspec/spec-docs/sprout-architecture.md`

### Feedback Tasks (→ [NNN-description](./revisions/NNN-description.md))

---

## Progress

**Overall**: 100%

| Phase | Progress | Status |
|-------|----------|--------|
| Phase 1 | 100% | ✅ |
| Phase 2 | 100% | ✅ |
| Phase 3 | 100% | ✅ |
| Phase 4 | 100% | ✅ |
| Phase 5 | 100% | ✅ |
| Phase 6 | 100% | ✅ |

**Recent**:
- 52 tests all passing
- Global mode end-to-end verified: `sprout init --global`, `sprout list -g`, `sprout new -g`, `sprout doctor -g`
- Documentation updated (user-guide, command-authoring-guide, architecture spec-doc)