---
change: "global-mode"
created: 2026-04-15T15-57:05
updated: 2026-04-15T16:05
---

# Memory: global-mode

## State
DOING — Plan approved, entering implementation

## Key Decisions
- **两套注册表，完全隔离**：`-g/--global` 是编译时决策，不混合项目级和全局命令
- **全局目录**：`~/.config/sprout/`，结构镜像项目级 `.sprout/`
- **绝对路径支持**：全局模式 asset path 允许绝对路径（通过 `home`/`cwd` 等变量）， `_ensure_within_root` 跳过
- **root 字段**：全局 manifest 可选 `root` 字段声明生成基座，无声明时默认 cwd
- **沙箱策略**：项目级零修改；全局模式绝对路径不做沙箱检查，相对路径仍用 sandbox_root
- **安全**：信任用户——全局 action 不加额外确认机制
- **配置**：全局 config.yaml 格式与项目级完全相同，支持 conflict 策略等
- **变量**：全局模式注入 `home`/`cwd`/`platform`，渐进式扩展

## Milestones
- [x] Clarify 完成：Problem Statement + Direction 对齐
- [x] Design spec + design.md 草案完成
- [x] @align gate 通过
- [x] Plan (tasks.md) 完成
- [ ] Implement
- [ ] Review

## Knowledge
- `discover_project_root()` 设计上不支持全局模式（也不需要改），全局走独立入口 `discover_global_dir()`
- `_ensure_within_root()` 签名不变，全局模式只是传不同的 root 参数
- `build_variable_context()` 需要重构：当前内联时间变量，需要提取为独立函数以支持模式分派
- `CommandSpec.root` 字段项目级不报错（兼容性考虑），但也不生效
- 用户的明确需求：全局模式支持绝对路径是刚需，限制自由度就没意义