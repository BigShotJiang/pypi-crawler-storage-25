#!python3
# -*- coding: utf-8 -*-
"""
Code to upload metadata to the CKAN server to create/update an existing package
The metadata is defined by the user in an Excel worksheet
This file implements the field definition
"""
from typing import Union, Set
import pandas as pd
from collections import OrderedDict
from warnings import warn

from ckanapi_harvesters.auxiliary.ckan_field_types import CkanFieldType
from ckanapi_harvesters.auxiliary.ckan_model import CkanField
from ckanapi_harvesters.auxiliary.ckan_auxiliary import CkanFieldInternalAttrs
from ckanapi_harvesters.auxiliary.ckan_auxiliary import _string_from_element, _bool_from_string


field_allowed_user_fields: Set[str] = {
    "name", "type override", "label", "description",
    "index", "unique", "not null",
    "options", "comment",
}



class BuilderField:
    def __init__(self, *, name:str=None, type_override:CkanFieldType=None,
                 description:str=None, label:str=None):
        self.name: str = name
        self.type_override: Union[CkanFieldType,None] = type_override
        self.label: Union[str,None] = label
        self.description: Union[str,None] = description
        self.is_index: Union[bool,None] = None
        self.uniquekey: Union[bool,None] = None
        self.notnull: Union[bool,None] = None
        self.options_string: Union[str,None] = None
        self.internal_attrs: CkanFieldInternalAttrs = CkanFieldInternalAttrs()
        self.comment: Union[str,None] = None
        self._user_fields_used: Set[str] = set()

    def update_missing(self, other: "BuilderField") -> None:
        if self.name is None:
            self.name = other.name
        if self.type_override is None:
            self.type_override = other.type_override
        if self.label is None:
            self.label = other.label
        if self.description is None:
            self.description = other.description
        if self.is_index is None:
            self.is_index = other.is_index
        if self.uniquekey is None:
            self.uniquekey = other.uniquekey
        if self.notnull is None:
            self.notnull = other.notnull
        if self.options_string is None:
            self.options_string = other.options_string
        if self.internal_attrs is None:
            self.internal_attrs = other.internal_attrs
        elif other.internal_attrs is not None:
            self.internal_attrs = self.internal_attrs.merge(other.internal_attrs)
        if self.comment is None:
            self.comment = other.comment

    def __str__(self):
        return f"Field builder for {self.name}"

    def copy(self, *, dest=None):
        if dest is None:
            dest = BuilderField()
        dest.name = self.name
        dest.type_override = self.type_override
        dest.label = self.label
        dest.description = self.description
        dest.is_index = self.is_index
        dest.uniquekey = self.uniquekey
        dest.notnull = self.notnull
        dest.options_string = self.options_string
        dest.internal_attrs = self.internal_attrs.copy()
        dest.comment = self.comment
        return dest

    def _load_from_df_row(self, row: pd.Series):
        extra_fields = set(row.keys()) - field_allowed_user_fields
        if extra_fields:
            msg = f"The following field attributes were not recognized: {', '.join(extra_fields)}"
            warn(msg)
        self.name = _string_from_element(row["field name"]).strip()
        # if self.name is None:
        #     raise MandatoryAttributeError("Field", "name")
        self._user_fields_used.add("name")
        type_override_string = None
        if "type override" in row.keys():
            type_override_string = _string_from_element(row["type override"])
            self._user_fields_used.add("type override")
        self.type_override = None
        if type_override_string is not None:
            self.type_override = CkanFieldType.from_str(type_override_string)
        else:
            self.type_override = None
        self.label = None
        self.description = None
        if "label" in row.keys():
            self.label = _string_from_element(row["label"])
            self._user_fields_used.add("label")
        if "description" in row.keys():
            self.description = _string_from_element(row["description"])
            self._user_fields_used.add("description")
        if "index" in row.keys():
            self.is_index = _bool_from_string(row["index"], default_value=None)
            self._user_fields_used.add("index")
        if "unique" in row.keys():
            self.uniquekey = _bool_from_string(row["unique"], default_value=None)
            self._user_fields_used.add("unique")
        if "not null" in row.keys():
            self.notnull = _bool_from_string(row["not null"], default_value=None)
            self._user_fields_used.add("not null")
        if "options" in row.keys():
            self.options_string = _string_from_element(row["options"])
            self._user_fields_used.add("options")
        if "comment" in row.keys():
            self.comment = _string_from_element(row["comment"])
            self._user_fields_used.add("comment")
        self.internal_attrs.init_from_native_type(self.type_override)
        self.internal_attrs.init_from_options_string(self.options_string)

    @staticmethod
    def from_df_row(row: pd.Series) -> "BuilderField":
        field_builder = BuilderField()
        field_builder._load_from_df_row(row)
        return field_builder

    def _to_dict(self) -> dict:
        return OrderedDict([
            ("Field Name", self.name),
            ("Type override", str(self.type_override) if self.type_override is not None else ""),
            ("Label", self.label if self.label else ""),
            ("Description", self.description if self.description else ""),
            ("Index", str(self.is_index) if self.is_index is not None else ""),
            ("Unique", str(self.uniquekey) if self.uniquekey is not None else ""),
            ("Not null", str(self.notnull) if self.notnull is not None else ""),
            ("Options", self.options_string if self.options_string else ""),
            ("Comment", self.comment if self.comment else ""),
        ])

    def _to_ckan_field(self) -> CkanField:
        field_info = CkanField(name=self.name, data_type=str(self.type_override) if self.type_override is not None else None,
                               notes=self.description, label=self.label)
        field_info.is_index = self.is_index
        field_info.uniquekey = self.uniquekey
        field_info.notnull = self.notnull
        field_info.internal_attrs = self.internal_attrs.copy()
        field_info.type_override = self.type_override is not None
        return field_info

    def _to_ckan_dict(self) -> dict:
        return self._to_ckan_field().to_ckan_dict()

    @staticmethod
    def _from_ckan_field(field_info: CkanField) -> "BuilderField":
        field_builder = BuilderField()
        field_builder.update_from_ckan(field_info)
        return field_builder

    def update_from_ckan(self, field_info: CkanField) -> None:
        field_row = pd.Series({"field name": field_info.name,
                               "type override": str(field_info.data_type),  # if field_info.type_override else "",
                               "label": field_info.label,
                               "description": field_info.notes,
                               "index": field_info.is_index,
                               "unique": field_info.uniquekey,
                               "not null": field_info.notnull,
                               })
        self._load_from_df_row(field_row)
        self.internal_attrs = field_info.internal_attrs.copy()


