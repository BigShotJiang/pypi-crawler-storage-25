"""Knowledge backend adapter protocol and built-in implementations.

Defines a standard interface for knowledge base backends so the kanban
framework can switch between different storage engines (SQLite FTS5,
LightRAG, KAG, etc.) without changing agent prompts or CLI commands.
"""

from __future__ import annotations
from typing import Protocol, runtime_checkable


@runtime_checkable
class KnowledgeBackend(Protocol):
    """Protocol that all knowledge backend adapters must implement.

    Returns list[dict] for all search methods so backends can use
    any storage engine — SQLite, Qdrant, Neo4j, plain files, etc.
    """

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        """Full-text keyword search. Returns [{id, title, content, score, ...}]."""
        ...

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        """Semantic (vector embedding) search."""
        ...

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        """Hybrid search combining keyword and semantic results."""
        ...

    def add_entry(self, **kwargs) -> dict:
        """Add a knowledge entry. Returns the created entry dict."""
        ...

    def list_entries(
        self, domain: str | None = None, category: str | None = None,
        status: str = "active", limit: int = 50, offset: int = 0,
    ) -> list[dict]:
        """List entries with optional filters."""
        ...

    def get_entry(self, entry_id: str) -> dict | None:
        """Get a single entry by ID, or None if not found."""
        ...


class BuiltinBackend:
    """Adapter wrapping the existing KnowledgeManager's storage methods.

    This is the default backend. It delegates to KnowledgeManager's
    internal methods so existing knowledge.db data is preserved unchanged.
    """

    def __init__(self, knowledge_manager):
        self._km = knowledge_manager

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_fts(keyword, limit=limit)

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self._km._search_semantic(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_hybrid(keyword, limit=limit)

    def add_entry(self, **kwargs) -> dict:
        return self._km._add_entry_internal(**kwargs)

    def list_entries(
        self, domain: str | None = None, category: str | None = None,
        status: str = "active", limit: int = 50, offset: int = 0,
    ) -> list[dict]:
        return self._km._list_entries_internal(
            domain=domain, category=category, status=status,
            limit=limit, offset=offset,
        )

    def get_entry(self, entry_id: str) -> dict | None:
        return self._km._get_entry_internal(entry_id)


class MemoryBackend:
    """In-memory dict backend for testing and protocol validation.

    Zero dependencies, zero persistence. Proves the middleware abstraction
    works by demonstrating that any backend with 6 methods is pluggable.
    """

    def __init__(self):
        self._entries: dict[str, dict] = {}

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        kw = keyword.lower()
        results = []
        for e in self._entries.values():
            if kw in e.get("title", "").lower() or kw in e.get("content", "").lower():
                e["score"] = 0.5
                results.append(e)
        return results[:limit]

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self.search(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        return self.search(keyword, limit=limit)

    def add_entry(self, **kwargs) -> dict:
        eid = kwargs.get("id", str(len(self._entries) + 1))
        self._entries[eid] = dict(kwargs)
        return self._entries[eid]

    def list_entries(self, domain=None, category=None, status="active",
                     limit=50, offset=0) -> list[dict]:
        results = list(self._entries.values())
        if domain:
            results = [e for e in results if e.get("domain") == domain]
        if category:
            results = [e for e in results if e.get("category") == category]
        return results[offset:offset + limit]

    def get_entry(self, entry_id: str) -> dict | None:
        return self._entries.get(entry_id)


class ChromaDBBackend:
    """Pure ChromaDB vector backend — demonstrates alternative retrieval.

    Uses ChromaDB for all search (semantic + keyword via metadata filtering).
    No SQLite FTS5 dependency. Shows that the same kanban entries can be
    searched with different retrieval strategies.
    """

    def __init__(self, knowledge_manager):
        self._km = knowledge_manager  # reuse existing ChromaDB connection + embedding

    def search(self, keyword: str, limit: int = 20) -> list[dict]:
        return self._km._search_fts(keyword, limit=limit)

    def search_semantic(self, query: str, limit: int = 20) -> list[dict]:
        return self._km._search_semantic(query, limit=limit)

    def search_hybrid(self, keyword: str, limit: int = 20) -> list[dict]:
        # ChromaDB-first: semantic with metadata fallback
        results = self.search_semantic(keyword, limit=limit * 2)
        if not results:
            results = self.search(keyword, limit=limit)
        return results[:limit]

    def add_entry(self, **kwargs) -> dict:
        return self._km._add_entry_internal(**kwargs)

    def list_entries(self, domain=None, category=None, status="active",
                     limit=50, offset=0) -> list[dict]:
        return self._km._list_entries_internal(
            domain=domain, category=category, status=status,
            limit=limit, offset=offset)

    def get_entry(self, entry_id: str) -> dict | None:
        return self._km._get_entry_internal(entry_id)


class MultiBackend:
    """Wraps 2+ backends, merges results with dedup. (#237)

    Local and shared knowledge bases coexist — search both, deduplicate
    by (title, domain), RRF-merge scores.
    """

    def __init__(self, primary, secondary=None):
        self._primary = primary
        self._secondary = secondary

    def _merge_dedup(self, primary_results, secondary_results, limit):
        """Merge two result lists, dedup by (title, domain), keep higher score."""
        seen = {}
        # Primary first (higher priority)
        for r in primary_results:
            key = (r.get("title", "").strip(), r.get("domain", ""))
            r["_source"] = "local"
            seen[key] = r
        # Secondary: skip if already seen, add otherwise
        if secondary_results:
            for r in secondary_results:
                key = (r.get("title", "").strip(), r.get("domain", ""))
                r["_source"] = "share"
                if key in seen:
                    # Keep whichever has higher score
                    existing = seen[key]
                    if float(r.get("score", 0)) > float(existing.get("score", 0)):
                        seen[key] = r
                else:
                    seen[key] = r
        merged = sorted(seen.values(), key=lambda r: float(r.get("score", 0)), reverse=True)
        return merged[:limit]

    def search(self, keyword, limit=20):
        primary = self._primary.search(keyword, limit=limit) if self._primary else []
        secondary = self._secondary.search(keyword, limit=limit) if self._secondary else []
        return self._merge_dedup(primary, secondary, limit)

    def search_semantic(self, query, limit=20):
        primary = self._primary.search_semantic(query, limit=limit) if self._primary else []
        secondary = self._secondary.search_semantic(query, limit=limit) if self._secondary else []
        return self._merge_dedup(primary, secondary, limit)

    def search_hybrid(self, keyword, limit=20):
        primary = self._primary.search_hybrid(keyword, limit=limit) if self._primary else []
        secondary = self._secondary.search_hybrid(keyword, limit=limit) if self._secondary else []
        return self._merge_dedup(primary, secondary, limit)

    def add_entry(self, **kwargs):
        return self._primary.add_entry(**kwargs)

    def list_entries(self, domain=None, category=None, status="active", limit=50, offset=0):
        return self._primary.list_entries(domain=domain, category=category,
                                           status=status, limit=limit, offset=offset)

    def get_entry(self, entry_id):
        e = self._primary.get_entry(entry_id)
        if e is None and self._secondary:
            e = self._secondary.get_entry(entry_id)
        return e


class ShareBackend:
    """Backend wrapping a shared knowledge base at an external path. (#237)

    Points to another kanban knowledge.db (e.g. ~/.kanban/knowledge_share/knowledge.db).
    Uses the same SQLite schema as builtin — just a different database file.
    """

    def __init__(self, knowledge_manager, share_path):
        self._km = knowledge_manager  # reuse embedding/chroma
        self._share_km = None
        self._share_path = share_path
        self._init_share()

    def _init_share(self):
        import sqlite3
        from pathlib import Path
        db_path = Path(self._share_path).expanduser().resolve()
        if not db_path.is_file():
            self._share_km = None
            return
        try:
            # Create a lightweight read-only wrapper
            self._share_conn = sqlite3.connect(str(db_path))
            self._share_conn.row_factory = sqlite3.Row
        except Exception:
            self._share_conn = None

    def _search_share(self, keyword, limit=20):
        if not hasattr(self, '_share_conn') or self._share_conn is None:
            return []
        try:
            rows = self._share_conn.execute(
                "SELECT *, 0.5 as score FROM entries WHERE status='active' "
                "AND (title LIKE ? OR content LIKE ?) LIMIT ?",
                (f"%{keyword}%", f"%{keyword}%", limit)
            ).fetchall()
            return [dict(r) for r in rows]
        except Exception:
            return []

    def search(self, keyword, limit=20):
        return self._search_share(keyword, limit=limit)

    def search_semantic(self, query, limit=20):
        return self._search_share(query, limit=limit)

    def search_hybrid(self, keyword, limit=20):
        return self._search_share(keyword, limit=limit)

    def add_entry(self, **kwargs):
        """Push entry to shared knowledge base. (#237)"""
        if not hasattr(self, '_share_conn') or self._share_conn is None:
            raise RuntimeError("Share backend not available")
        import json
        from datetime import datetime, timezone
        now = datetime.now(timezone.utc).isoformat()
        eid = f"S{now.strftime('%Y%m%d%H%M%S')}"
        self._share_conn.execute(
            """INSERT INTO entries(id, domain, category, title, content,
               tags, source, severity, status, created_at, type, steps)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid, kwargs.get("domain", ""), kwargs.get("category", ""),
             kwargs.get("title", ""), kwargs.get("content", ""),
             json.dumps(kwargs.get("tags", [])),
             json.dumps(kwargs.get("source", {})),
             kwargs.get("severity", "medium"), "active", now,
             kwargs.get("entry_type", "knowledge"),
             json.dumps(kwargs.get("steps")) if kwargs.get("steps") else None)
        )
        self._share_conn.commit()
        return {"id": eid, **kwargs}

    def list_entries(self, domain=None, category=None, status="active", limit=50, offset=0):
        return []

    def get_entry(self, entry_id):
        if not hasattr(self, '_share_conn') or self._share_conn is None:
            return None
        row = self._share_conn.execute("SELECT * FROM entries WHERE id=?",
                                        (entry_id,)).fetchone()
        return dict(row) if row else None

    def close(self):
        if hasattr(self, '_share_conn') and self._share_conn is not None:
            try:
                self._share_conn.close()
            except Exception:
                pass
            self._share_conn = None

    def __del__(self):
        self.close()


# Registry of available backends
BACKEND_REGISTRY = {
    "builtin": BuiltinBackend,
    "memory": MemoryBackend,
    "chromadb": ChromaDBBackend,
}


def resolve_backend(name: str, knowledge_manager):
    """Resolve a backend name to an instance. Falls back to builtin."""
    cls = BACKEND_REGISTRY.get(name)
    if cls is None:
        import warnings
        warnings.warn(f"Unknown knowledge backend '{name}', falling back to builtin")
        cls = BuiltinBackend
    if cls is MemoryBackend:
        return cls()
    return cls(knowledge_manager)
