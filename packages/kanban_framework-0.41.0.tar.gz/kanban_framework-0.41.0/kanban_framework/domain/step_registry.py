"""Flat step registry — exposes phase steps as a unified DAG.

All step IDs are flat: {phase}.{step_name}
Dependencies are derived from:
- Intra-phase: steps in order (step N depends on step N-1)
- Inter-phase: first step of phase P depends on last step of previous phase
- Lightweight: skipped phases are removed from the DAG entirely
"""

from __future__ import annotations
from kanban_framework.domain.state_machine import FULL_STEPS, LIGHTWEIGHT_STEPS, StepDef
from kanban_framework.infra.scheduler import Scheduler


def build_step_dag(lightweight: bool = False) -> dict:
    """Build a flat step DAG from phase step definitions.

    Returns:
        {"steps": [{"id": "plan.plan_A", "dependencies": [], "description": "...",
                    "agent_type": None, "parallel": False, "user_action": True,
                    "interactive": True, "skippable": True, "phase": "plan"}, ...]}
    """
    steps_map = LIGHTWEIGHT_STEPS if lightweight else FULL_STEPS
    phase_order = (Scheduler.LIGHTWEIGHT_PHASE_ORDER if lightweight
                   else Scheduler.PHASE_ORDER)

    steps: list[dict] = []
    prev_step_id: str | None = None

    for phase in phase_order:
        phase_steps = steps_map.get(phase.value, [])
        for i, step in enumerate(phase_steps):
            deps = []
            if i == 0 and prev_step_id:
                # Inter-phase dependency
                deps.append(prev_step_id)
            elif i > 0:
                # Intra-phase dependency
                deps.append(phase_steps[i - 1].id)

            steps.append({
                "id": step.id,
                "phase": phase.value,
                "description": step.description,
                "dependencies": deps,
                "agent_type": step.agent_type,
                "parallel": step.parallel,
                "user_action": step.user_action,
                "interactive": step.interactive,
                "spawn_prompt": step.spawn_prompt,
                "skippable": step.user_action,
            })
            prev_step_id = step.id

    return {"steps": steps, "lightweight": lightweight}


def get_available_steps(dag: dict, completed: set[str],
                        skipped: set[str] | None = None) -> list[dict]:
    """Return steps whose dependencies are all satisfied and not completed/skipped.

    A dependency is satisfied if it's completed OR skipped.
    """
    skipped = skipped or set()
    satisfied = completed | skipped
    available = []
    for step in dag["steps"]:
        if step["id"] in completed or step["id"] in skipped:
            continue
        if all(dep in satisfied for dep in step["dependencies"]):
            available.append(step)
    return available


def get_all_steps(dag: dict) -> list[dict]:
    """Return a shallow copy of all steps in the DAG."""
    return list(dag["steps"])


def resolve_step(step_id: str) -> tuple[str, str]:
    """Split flat step ID into (phase, step_name)."""
    parts = step_id.split(".", 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return parts[0], ""


def find_step_def(step_id: str, lightweight: bool = False) -> StepDef | None:
    """Find the StepDef for a given flat step ID."""
    steps_map = LIGHTWEIGHT_STEPS if lightweight else FULL_STEPS
    for phase_steps in steps_map.values():
        for step in phase_steps:
            if step.id == step_id:
                return step
    return None
