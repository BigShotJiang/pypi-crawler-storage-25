from __future__ import annotations
import json
from pathlib import Path


class TokenTracker:
    def __init__(self, data_file: Path, budget: int = 200000):
        self._file = Path(data_file)
        self._budget = budget
        self._data = self._load()

    def track(self, task_id: str, tokens: int, phase: str, agent: str = "",
              model: str = "", duration_seconds: float = 0.0) -> None:
        entry = self._data.setdefault(task_id, {"by_phase": {}, "by_agent": {}})
        entry["by_phase"][phase] = entry["by_phase"].get(phase, 0) + tokens
        entry["total_tokens"] = entry.get("total_tokens", 0) + tokens
        # Prompt count: each track() call = one agent spawn (#222)
        entry.setdefault("prompt_count", {})
        entry["prompt_count"][phase] = entry["prompt_count"].get(phase, 0) + 1
        entry["total_prompts"] = entry.get("total_prompts", 0) + 1
        # Duration tracking
        if duration_seconds > 0:
            entry.setdefault("phase_duration", {})
            entry["phase_duration"][phase] = entry["phase_duration"].get(phase, 0) + duration_seconds
        # Model tracking
        if model:
            entry.setdefault("by_model", {})
            entry["by_model"][model] = entry["by_model"].get(model, 0) + tokens
        if agent:
            by_ag = entry.setdefault("by_agent", {})
            by_ag.setdefault(phase, {})
            by_ag[phase][agent] = by_ag[phase].get(agent, 0) + tokens
            ag_totals = entry.setdefault("agent_totals", {})
            ag_totals[agent] = ag_totals.get(agent, 0) + tokens
        self._save()

    def report(self, task_id: str) -> dict:
        entry = self._data.get(task_id, {"total_tokens": 0, "by_phase": {}, "by_agent": {},
              "agent_totals": {}, "prompt_count": {}, "total_prompts": 0, "by_model": {},
              "phase_duration": {}})
        entry["within_budget"] = entry.get("total_tokens", 0) <= self._budget
        return entry

    def check_budget(self, task_id: str) -> bool:
        return self.report(task_id)["total_tokens"] <= self._budget

    def _load(self) -> dict:
        if self._file.exists():
            return json.loads(self._file.read_text(encoding="utf-8"))
        return {}

    def _save(self) -> None:
        self._file.parent.mkdir(parents=True, exist_ok=True)
        self._file.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
