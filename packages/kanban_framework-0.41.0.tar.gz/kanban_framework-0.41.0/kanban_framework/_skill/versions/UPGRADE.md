# Kanban 升级指南

`pip install --upgrade kanban-framework` 后，执行 `kanban init` 即可自动处理大部分迁移。以下按版本说明。

## 通用升级步骤

```bash
pip install --upgrade kanban-framework
kanban init                        # 同步 skill 文件 + 检测孤儿链接
```

---

## v0.13.x → v0.13.28+

### 1. Agent/Rule 孤儿链接

**现象：** `.claude/agents/` 和 `.claude/rules/` 下有 `kanban-*.md` 等 symlink

**影响：** 每次 Claude Code 启动都加载这些文件，浪费上下文。新版已改为按需加载（skill 目录内），不再需要这些 symlink。

**处理：**
```bash
kanban init                           # 先查看报告
kanban init --clean-orphaned          # 确认后清理
```

### 2. Skill 文件自动同步

`kanban init` 会自动检测并更新 `.claude/skills/kanban/` 下的文件：
- `SKILL.md`、`agents/`、`rules/`、`references/`、`versions/`
- 新增 → 自动创建
- 不一致 → 自动覆盖
- 源已删除但本地存在 → **报告为 stale，不自动删除**

### 3. 产物目录结构

**变化：** `iteration-N/` 下拆分为 `reviews/` 和 `execute/` 子目录

| 旧路径 | 新路径 |
|--------|--------|
| `iteration-1/code_reviewer_report.json` | `iteration-1/reviews/code_reviewer_report.json` |
| `iteration-1/execution_summary.md` | `iteration-1/execute/execution_summary.md` |

Guard 兼容旧格式，旧任务无需迁移。新任务自动使用新路径。

### 4. Plan 文件拆分

**变化：** 旧版 `plan.md`（单文件）→ 新版 `plan/index.md` + `plan/ST-NNN_{slug}.md`（每 subtask 独立）

Executor 启动时自动检测旧 `plan.md` 并拆分为新格式，备份原文件为 `plan.md.bak`。

### 5. test_spec.md 位置

**修正：** test_spec.md 是任务级产物，放在 `{task_dir}/test_spec.md`，非 `iteration-N/` 下。

旧任务如位置不对，手动移动到任务根目录即可。

### 6. 知识库 Schema

升级后首次访问知识库自动执行：
- 新增 `content_segmented` 列（jieba 中文分词，需 `pip install jieba`）
- 新增 `embedding` 列（语义搜索，需 `pip install fastembed`）
- 旧条目自动回填分词和向量

### 7. ID 计数器

`kanban clean` 后不再复用已归档 ID。`.kanban/next_id.txt` 只增不减。

---

## 手动检查清单

| 检查项 | 命令 |
|--------|------|
| 孤儿 agent/rules symlink | `ls .claude/agents/ .claude/rules/` |
| 版本 | `kanban --version` |
| 配置完整 | `cat .kanban/config.json` |
| 知识库健康 | `kanban knowledge health` |
| 依赖检查 | `kanban init` 输出中的 scan 报告 |
| 回归测试 | `pytest .claude/skills/kanban/test/` |
