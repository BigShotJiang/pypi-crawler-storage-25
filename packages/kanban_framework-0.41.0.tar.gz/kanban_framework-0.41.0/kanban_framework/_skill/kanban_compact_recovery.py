#!/usr/bin/env python3
"""PostCompaction hook: only fires when a kanban task is actively being worked on.

Orchestrator writes current task ID to .kanban/current_task before work.
On compaction, this hook reads only that task. No current_task → silent.
Prevents context-switching to kanban during non-kanban work.
"""
import json, sys
from pathlib import Path


def find_project_root() -> Path | None:
    cwd = Path.cwd()
    for p in [cwd] + list(cwd.parents):
        if (p / ".kanban" / "config.json").is_file():
            return p
    return None


def main():
    root = find_project_root()
    if not root:
        sys.exit(0)

    # Only report if orchestrator explicitly set the current task
    current_file = root / ".kanban" / "current_task"
    if not current_file.is_file():
        sys.exit(0)

    task_id = current_file.read_text(encoding="utf-8").strip()
    if not task_id:
        sys.exit(0)

    task_json = root / ".kanban" / "tasks" / task_id / "task.json"
    if not task_json.is_file():
        sys.exit(0)

    try:
        data = json.loads(task_json.read_text(encoding="utf-8"))
    except Exception:
        sys.exit(0)

    phase = data.get("phase", "?")
    iteration = data.get("iteration", 1)
    title = data.get("title", "")[:60]

    # Determine next step
    p = phase
    history = data.get("history", [])
    completed = {h["phase"] for h in history if h.get("status") == "completed"}

    if p == "plan":
        if "plan" not in completed:
            next_step = f"继续 Plan A (brainstorming → spec.md)"
        else:
            next_step = f"继续 Plan B (writing-plans → plan/index.md)"
    elif p in ("plan_review", "qa_spec", "spec_review"):
        next_step = f"继续 {p}: kanban run {task_id}"
    elif p == "execute":
        next_step = f"继续 Execute: kanban run {task_id}"
    elif p == "evaluate":
        next_step = f"等待 evaluate 完成后决策"
    elif p == "retrospective":
        next_step = f"完成 retrospective 后等待用户决策"
    elif p == "archive":
        next_step = f"归档进行中"
    else:
        next_step = f"kanban run {task_id}"

    print(f"<kanban-recovery>", file=sys.stderr)
    print(f"上下文已压缩。当前 kanban 任务: {task_id} ({title})", file=sys.stderr)
    print(f"phase={phase} iteration={iteration} → {next_step}", file=sys.stderr)
    print(f"恢复: kanban show {task_id} --json", file=sys.stderr)
    print(f"</kanban-recovery>", file=sys.stderr)


if __name__ == "__main__":
    main()
