from __future__ import annotations
import importlib
import json
import sys

_CMD_MAP: dict[str, tuple[str, str]] = {
    "check-env":  ("kanban_framework.cli.main", "_cmd_check_env"),
    "init":       ("kanban_framework.cli.task", "cmd_init"),
    "scan":       ("kanban_framework.cli.task", "cmd_scan"),
    "create":     ("kanban_framework.cli.task", "cmd_create"),
    "task":       ("kanban_framework.cli.task", "cmd_task"),
    "status":     ("kanban_framework.cli.task", "cmd_status"),
    "show":       ("kanban_framework.cli.task", "cmd_show"),
    "clean":      ("kanban_framework.cli.task", "cmd_clean"),
    "promote":    ("kanban_framework.cli.task", "cmd_promote"),
    "run":        ("kanban_framework.cli.run", "cmd_run"),
    "decide":     ("kanban_framework.cli.run", "cmd_decide"),
    "guard":      ("kanban_framework.cli.run", "cmd_guard"),
    "workflow":   ("kanban_framework.cli.run", "cmd_workflow"),
    "worktree":   ("kanban_framework.cli.run", "cmd_worktree"),
    "nlp":        ("kanban_framework.cli.run", "cmd_nlp"),
    "recover":    ("kanban_framework.cli.run", "cmd_recover"),
    "rollback":   ("kanban_framework.cli.run", "cmd_rollback"),
    "resume":     ("kanban_framework.cli.run", "cmd_resume"),
    "subtask":    ("kanban_framework.cli.subtask", "dispatch"),
    "score":      ("kanban_framework.cli.query", "cmd_score"),
    "summary":    ("kanban_framework.cli.query", "cmd_summary"),
    "progress":   ("kanban_framework.cli.query", "cmd_progress"),
    "time":       ("kanban_framework.cli.query", "cmd_time"),
    "tokens":     ("kanban_framework.cli.query", "cmd_tokens"),
    "dashboard":  ("kanban_framework.cli.query", "cmd_dashboard"),
    "inbox":      ("kanban_framework.cli.inbox", "dispatch"),
    "knowledge":  ("kanban_framework.cli.knowledge", "dispatch"),
    "feedback":   ("kanban_framework.cli.inbox", "cmd_feedback"),
    "version":    ("kanban_framework.cli.version", "dispatch"),
    "plan":           ("kanban_framework.cli.plan", "dispatch"),
    "evolve-skills":  ("kanban_framework.cli.skills", "dispatch"),
    "framework":      ("kanban_framework.cli.framework", "dispatch"),
    "evaluator":      ("kanban_framework.cli.evaluator", "dispatch"),
    "help":           ("kanban_framework.cli.main", "_cmd_help"),
    "sync-agents":    ("kanban_framework.cli.main", "_cmd_sync_agents"),
    "update":         ("kanban_framework.cli.main", "_cmd_update"),
    "stats":          ("kanban_framework.cli.main", "_cmd_stats"),
    "track":          ("kanban_framework.cli.main", "_cmd_track"),
    "hook":           ("kanban_framework.cli.hook", "cmd_hook"),
    "install-codeburn": ("kanban_framework.cli.task", "cmd_install_codeburn"),
}

_USE_JSON = False


def _ensure_utf8_stdout() -> None:
    """Reconfigure stdout/stderr to UTF-8 for cross-platform encoding safety.

    On Windows the default console encoding is the system ANSI code page
    (e.g. cp936 for Chinese), which corrupts non-ASCII output. This is a
    best-effort call — failures are silently ignored so the CLI never
    crashes on encoding setup.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            if hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


_ensure_utf8_stdout()


def main() -> None:
    global _USE_JSON
    args = sys.argv[1:]

    # Extract --json / -o json before command dispatch
    if "--json" in args or "-o" in args:
        _USE_JSON = True
        args = [a for a in args if a not in ("--json", "-o")]

    if not args or args[0] in ("--help", "-h", "help"):
        if _USE_JSON:
            _output({"success": True, "data": _cmd_help(args[1:] if len(args) > 1 else [])})
        else:
            _render_help()
        return

    if args[0] in ("--version", "-V"):
        _output_version()
        return

    cmd = args[0]
    entry = _CMD_MAP.get(cmd)
    if entry is None:
        _output({"success": False, "error": f"unknown command: {cmd}", "code": "UNKNOWN_COMMAND"})
        sys.exit(1)

    mod_name, fn_name = entry
    mod = importlib.import_module(mod_name)
    fn = getattr(mod, fn_name)
    try:
        result = fn(args[1:])
        if _USE_JSON:
            _output({"success": True, "data": result})
        else:
            _render(cmd, result)
    except Exception as e:
        _output({"success": False, "error": str(e), "code": type(e).__name__})


def _render(cmd: str, data: dict) -> None:
    """Human-readable renderer dispatcher."""
    renderers = {
        "status": _render_status,
        "show": _render_show,
        "create": _render_create,
        "init": _render_init,
        "score": _render_score,
        "summary": _render_summary,
        "time": _render_time,
        "tokens": _render_tokens,
        "nlp": _render_nlp,
        "dashboard": _render_dashboard,
        "update": _render_update,
        "knowledge": _render_knowledge,
    }
    renderer = renderers.get(cmd)
    if renderer:
        renderer(data)
    else:
        # Fallback: pretty-print JSON-like summary
        _render_json_fallback(cmd, data)


def _output(data: dict) -> None:
    print(json.dumps(data, ensure_ascii=False))


def _format_table(rows: list[list[str]], headers: list[str]) -> str:
    """Format aligned table."""
    cols = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            cols[i] = max(cols[i], len(str(cell)))
    lines = ["  ".join(h.ljust(cols[i]) for i, h in enumerate(headers))]
    lines.append("  ".join("─" * cols[i] for i in range(len(headers))))
    for row in rows:
        lines.append("  ".join(str(row[i]).ljust(cols[i]) for i in range(len(row))))
    return "\n".join(lines)


# ── Renderers ──

def _render_help():
    print("Usage: kanban <command> [options]\n")
    groups = [
        ("Tasks", [
            ("create   <title>", "Create a new task"),
            ("task edit <id>", "Edit task mode/priority/auto-mode"),
            ("status", "Show kanban board summary"),
            ("show     <id>", "Show task details"),
            ("promote  <id>", "Advance draft to active"),
            ("clean    <id>", "Clean up archived task"),
        ]),
        ("Execution", [
            ("run      <id>", "Execute current phase"),
            ("decide   <id>", "Make a decision"),
            ("subtask  <action>", "Manage subtasks"),
        ]),
        ("Knowledge", [
            ("knowledge search  <kw>", "Search knowledge base"),
            ("knowledge learn   <path>", "Learn from code"),
            ("knowledge backup", "Manual backup of knowledge.db"),
            ("knowledge list", "List knowledge entries"),
            ("knowledge review", "Review draft entries"),
        ]),
        ("Query", [
            ("score    <id>", "Evaluation scores"),
            ("summary  <id>", "Task summary"),
            ("progress <id>", "Subtask progress"),
            ("time     <id>", "Time tracking"),
            ("tokens   <id>", "Token usage"),
        ]),
        ("Inbox", [
            ("inbox add    <id> <text>", "Add feedback"),
            ("inbox analyze <id>", "Analyze inbox items"),
        ]),
    ]
    for group, cmds in groups:
        print(f"[{group}]")
        for cmd, desc in cmds:
            print(f"  {cmd.ljust(26)}{desc}")
        print()
    print("[Options]")
    print("  --json, -o json         Output raw JSON")
    print("  --help, -h              Show this help")
    print()
    print("[Maintenance]")
    print("  update [version]        Upgrade to latest or specified PyPI version")


def _render_status(data: dict):
    tasks = data.get("tasks", [])
    by_status = data.get("by_status", {})
    total = data.get("total", 0)

    print(f"\n  Kanban Board — {total} tasks\n")
    print(f"  In Progress: {by_status.get('in_progress', 0)}")
    print(f"  Completed:   {by_status.get('completed', 0)}")

    if not tasks:
        print("\n  No active tasks.")
        return

    print()
    print(_format_table(
        [[t.get("id",""), t.get("title","")[:30], t.get("phase",""),
          f"v{t.get('iteration',1)}", t.get("status","")]
         for t in tasks if t.get("status") != "archived"],
        ["ID", "TITLE", "PHASE", "ITER", "STATUS"]
    ))


def _render_show(data: dict):
    print(f"\n  Task: {data.get('id', '?')} — {data.get('title', '?')}")
    print(f"  Phase: {data.get('phase', '?')} | Iteration: {data.get('iteration', 1)}")
    print(f"  Status: {data.get('status', '?')}")
    if data.get("description"):
        print(f"\n  {data['description']}")


def _render_create(data: dict):
    print(f"  Created {data.get('id', '?')}: {data.get('title', '?')}")
    print(f"  Phase: {data.get('phase', '?')} | Status: {data.get('status', '?')}")

    assessment = data.get("assessment", {})
    if assessment:
        mode = assessment.get("recommended_mode", "?")
        reason = assessment.get("reason", "")
        risks = assessment.get("risk_factors", [])
        mode_label = "lightweight" if mode == "lightweight" else "full"
        print(f"  Mode: {mode_label}")
        print(f"  Reason: {reason}")
        if risks:
            print(f"  Risks: {', '.join(risks)}")

    tc = data.get("test_config")
    if tc:
        level = tc.get("level", "full")
        level_labels = {"full": "完整测试", "quick": "快速验证", "manual": "手动检查"}
        parts = [level_labels.get(level, "full")]
        if tc.get("framework"): parts.append(tc["framework"])
        if tc.get("command"): parts.append(tc["command"])
        if tc.get("coverage"): parts.append(f"coverage {tc['coverage']}")
        print(f"  Test: {' | '.join(parts)}")

    task_id = data.get("id", "")
    desc = data.get("description", "") or "(无)"
    print(f"\n  ── 确认检查点 ──")
    print(f"  标题: {data.get('title', '?')}")
    if desc and desc != "(无)":
        print(f"  描述: {desc[:80]}{'...' if len(desc) > 80 else ''}")
    print(f"  模式: {data.get('mode', 'full')}")
    tc = data.get("test_config")
    if tc:
        print(f"  测试: {tc.get('level', 'full')}")
    print(f"\n  → 确认无误？ kanban run {task_id}")
    if not data.get("user_specified_mode", False):
        override = f"kanban task edit {task_id} --mode full" if data.get("mode") == "lightweight" else f"kanban task edit {task_id} --mode lightweight"
        print(f"  → 修改模式: {override}")
    print(f"  → 修改需求: 编辑 .kanban/tasks/{task_id}/spec.md 后运行")


def _render_init(data: dict):
    sync = data.get("sync", {})
    added = sync.get("added", [])
    updated = sync.get("updated", [])
    stale = sync.get("stale", [])
    created = data.get("created", []) or added + updated

    parts = []
    if added:
        parts.append(f"{len(added)} added")
    if updated:
        parts.append(f"{len(updated)} updated")
    if stale:
        parts.append(f"{len(stale)} stale")

    status = ", ".join(parts) if parts else f"{len(created)} items created"
    print(f"  kanban env ready — {status}")

    agent_sync = data.get("agent_sync", {})
    if agent_sync.get("synced"):
        print(f"  Agents: {len(agent_sync['synced'])} synced to .claude/agents/")
    if agent_sync.get("updated"):
        print(f"  Agents: {len(agent_sync['updated'])} updated in .claude/agents/")

    lang = data.get("language", "unknown")
    if lang and lang != "unknown":
        lang_labels = {"python": "Python", "javascript": "JavaScript", "typescript": "TypeScript", "go": "Go", "rust": "Rust"}
        print(f"  Language: {lang_labels.get(lang, lang)} (auto-detected)")

    if updated:
        for f in updated[:5]:
            print(f"    ~ {f}")
    pending = sync.get("pending_updates", [])
    if pending:
        print(f"\n  ⚠  {len(pending)} files have updates available (not applied)")
        for f in pending[:5]:
            print(f"    → {f}")
        if len(pending) > 5:
            print(f"    ... and {len(pending) - 5} more")
        print(f"  Review changes and run: kanban init --apply")
    if stale:
        print(f"  ⚠  {len(stale)} stale files (not in framework source)")
        for f in stale[:3]:
            print(f"    ? {f}")

    orphaned = data.get("orphaned_links", [])
    if orphaned:
        print(f"\n  ⚠  {len(orphaned)} orphaned agent/rule symlinks from older version")
        print(f"     These waste context in non-kanban sessions.")
        print(f"     Remove with: kanban init --clean-orphaned")

    if data.get("pip_warning"):
        print(f"  ⚠️  {data['pip_warning']}")


def _render_score(data: dict):
    scores = data.get("scores", [])
    avg = data.get("average")
    print(f"\n  Average: {avg}/10" if avg else "\n  No scores yet")
    if scores:
        print(_format_table(
            [[s["role"], f"{s['total']}/10", f"iter {s['iteration']}"] for s in scores],
            ["ROLE", "SCORE", "ITER"]
        ))


def _render_summary(data: dict):
    print(f"\n  Task: {data.get('title', data.get('task_id', '?'))}")
    print(f"  Phase: {data.get('phase', '?')} | Status: {data.get('status', '?')}")
    print(f"  Progress: {data.get('progress', {})}")


def _render_nlp(data: dict):
    print(f"\n  Input: {data.get('input', '')}")
    print(f"  Task ID: {data.get('task_id', '-')}")
    guidance = data.get("routing_guidance", {})
    print(f"  Intent: {guidance.get('intent', '?')}")
    print(f"  Suggested: {guidance.get('suggested_command', '?')}")
    print(f"  Rule: {guidance.get('rule', '')[:120]}")
    cmds = data.get("available_commands", [])
    print(f"\n  Commands ({len(cmds)} total):")
    for c in cmds:
        print(f"    {c.get('command', ''):<24} {c.get('example', '')}")


def _render_time(data: dict):
    t = data.get("time", data)
    print(f"\n  Total: {t.get('total_seconds', 0):.0f}s")
    for phase, info in t.get("phases", {}).items():
        print(f"  {phase}: {info.get('elapsed_seconds', 0):.0f}s")


def _render_tokens(data: dict):
    t = data.get("tokens", data)

    if "text_output" in data:
        print(f"\n{data['text_output']}")
        return

    if "today" in data:
        print(f"\n  Today: {data.get('today',{}).get('cost','?')}  |  Month: {data.get('month',{}).get('cost','?')}")
        return

    if "overview" in data:
        o = data["overview"]
        print(f"\n  Period: {data.get('period','?')}")
        print(f"  Tokens: {o.get('totalTokens',0):,}  |  Cost: {o.get('cost','0')}  |  Sessions: {o.get('sessions',0)}")
        return

    total = t.get("total_tokens", 0)
    budget = "within budget" if t.get("within_budget", True) else "over budget"
    print(f"\n  Total: {total:,} tokens ({budget})")
    for phase, tokens in t.get("by_phase", {}).items():
        print(f"  {phase}: {tokens}")


def _render_update(data: dict):
    if data.get("action") == "channels":
        if "error" in data:
            print(f"  Error: {data['error']}")
        else:
            print(f"  Stable (latest 10):")
            for v in data.get("stable", []):
                print(f"    v{v}")
            print(f"  Dev / Pre-release (latest 10):")
            dev = data.get("dev", [])
            if dev:
                for v in dev:
                    print(f"    v{v}")
            else:
                print(f"    (none)")
        return
    if data.get("action") == "list_versions":
        if "error" in data:
            print(f"  Error: {data['error']}")
        else:
            print(f"  All versions ({data.get('count', 0)} total, showing latest 20):")
            for v in data.get("versions", []):
                marker = " [dev]" if _is_pre_release(v) else ""
                print(f"    v{v}{marker}")
        return
    if data.get("success"):
        print(f"  Updated to kanban-framework v{data.get('version', '?')}")
        sync = data.get("skill_sync", {})
        if isinstance(sync, dict) and sync.get("synced"):
            print(f"  Skill files synced to .claude/skills/kanban/")
    else:
        print(f"  Update failed: {data.get('pip_output', data.get('error', 'unknown error'))}")
        print(f"  Try: pip install --upgrade kanban-framework")


def _render_json_fallback(cmd: str, data: dict):
    """Fallback: show key fields in readable format."""
    if isinstance(data, dict):
        for k, v in data.items():
            if k in ("success", "code"):
                continue
            if isinstance(v, (str, int, float, bool)):
                print(f"  {k}: {v}")
            elif isinstance(v, list):
                if len(v) <= 5 and all(isinstance(x, str) for x in v):
                    for x in v:
                        print(f"  - {x}")
                else:
                    print(f"  {k}: [{len(v)} items]")
            elif isinstance(v, dict):
                if len(v) <= 5:
                    for dk, dv in v.items():
                        if isinstance(dv, (str, int, float, bool)):
                            print(f"  {dk}: {dv}")
                        else:
                            print(f"  {dk}: {type(dv).__name__}")
                else:
                    print(f"  {k}: {{{len(v)} keys}}")
    else:
        print(f"  {data}")


def _render_dashboard(data: dict):
    """Render dashboard command results."""
    d = data.get("dashboard", data)

    # Deploy result
    if "deployed_to" in d:
        print(f"  Deployed to: {d['deployed_to']}")
        print(f"  Files copied: {d.get('copied', 0)}, skipped: {d.get('skipped', 0)}")
        return

    # Start result
    if "started" in d:
        if d["started"]:
            print(f"  Dashboard started (pid {d.get('pid', '?')}, port {d.get('port', 3000)})")
            print(f"  Open http://localhost:{d.get('port', 3000)}")
        else:
            print(f"  Dashboard already running (pid {d.get('pid', '?')})")
        return

    # Stop result
    if "stopped" in d:
        if d["stopped"]:
            print(f"  Dashboard stopped (pid {d.get('pid', '?')})")
        else:
            print(f"  Dashboard not running ({d.get('reason', '')})")
        return

    # Help result
    if d.get("help"):
        print(f"\n  {d.get('message', '')}")
        print()
        for cmd, desc in d.get("commands", {}).items():
            print(f"    {cmd.ljust(10)} {desc}")
        if d.get("default"):
            print(f"\n  {d['default']}")
        return

    # Error result
    if "error" in d:
        print(f"  Error: {d['error']}")
        if d.get("help_hint"):
            print(f"  {d['help_hint']}")
        return

    # Status result
    if "deployed" in d and "running" in d:
        dep = "yes" if d.get("deployed") else "no"
        run = "running" if d.get("running") else "stopped"
        pid = d.get("pid")
        print(f"  Deployed: {dep} | Status: {run}")
        if pid:
            print(f"  PID: {pid}")
        print(f"  Dir: {d.get('deploy_dir', '?')}")
        return

    # Backward compat: data query
    total = d.get("total", 0)
    by_phase = d.get("by_phase", {})
    print(f"\n  Dashboard — {total} tasks")
    for phase, count in by_phase.items():
        print(f"    {phase}: {count}")


def _render_knowledge(data: dict) -> None:
    """Render kanban knowledge help and command results."""
    # Detect help output (has subcommands key)
    if "subcommands" in data:
        print(f"\n  {data.get('description', '')}")
        token_guide = data.get("token_guide")
        subs = data["subcommands"]
        max_len = max(len(k) for k in subs.keys())
        for cmd, desc in sorted(subs.items()):
            print(f"  {cmd.ljust(max_len + 2)} {desc}")
        if token_guide:
            print(f"\n  Token: {token_guide}")
        print(f"\n  kanban knowledge help <subcommand> 查看单条命令详细帮助")
        print(f"  完整参考: references/knowledge-cli-reference.md")
        return

    # Detect single command help (has usage + examples)
    if "usage" in data and "examples" in data:
        print(f"\n  {data.get('description', '')}")
        print(f"\n  Usage: {data['usage']}")
        if data.get("examples"):
            print(f"\n  Examples:")
            for ex in data["examples"]:
                print(f"    $ {ex}")
        return

    # Entry detail (kanban knowledge get <id>)
    if "entry" in data:
        e = data["entry"]
        print(f"\n  {e.get('id', '?')} — {e.get('title', '?')}")
        print(f"  Domain: {e.get('domain', '?')} | Category: {e.get('category', '?')}")
        print(f"  Severity: {e.get('severity', '?')} | Status: {e.get('status', '?')}")
        tags = e.get("tags", [])
        if tags:
            print(f"  Tags: {', '.join(tags) if isinstance(tags, list) else tags}")
        content = e.get("content", "")
        if content:
            print(f"\n  {content}")
        code = e.get("code_example", "")
        if code:
            print(f"\n  --- code_example ---")
            for line in code.split("\n"):
                print(f"  {line}")
        refs = e.get("referenced_count", 0)
        if refs:
            print(f"\n  Referenced: {refs} times, last by {e.get('last_referenced_by', '-')}")
        return

    # Fallback: normal result rendering
    _render_json_fallback("knowledge", data)


# ── Legacy commands ──

def _is_pre_release(version: str) -> bool:
    """Check if a version string is a pre-release (PEP 440)."""
    import re
    return bool(re.search(r'(a|b|rc|alpha|beta|dev)\d*', version))


def _cmd_track(args: list[str]) -> dict:
    """Record token/time tracking for a task phase.

    Usage:
        kanban track <task_id> <phase> <tokens> [--agent <name>]
        kanban track <task_id> <phase> <tokens> --duration <seconds>
    """
    from kanban_framework.infra.filesystem import Filesystem
    from kanban_framework.infra.token_tracking import TokenTracker

    fs = Filesystem(Filesystem.find_project_root())
    reports_dir = fs.kanban_dir / "reports"
    fs.ensure_dir(reports_dir)

    task_id = args[0] if len(args) > 0 else ""
    phase = args[1] if len(args) > 1 else ""
    tokens = int(args[2]) if len(args) > 2 else 0
    agent = ""
    model = ""
    duration = 0.0
    step_id = ""
    for i, a in enumerate(args):
        if a == "--agent" and i + 1 < len(args):
            agent = args[i + 1]
        elif a == "--model" and i + 1 < len(args):
            model = args[i + 1]
        elif a == "--duration" and i + 1 < len(args):
            try: duration = float(args[i + 1])
            except ValueError: pass
        elif a == "--step" and i + 1 < len(args):
            step_id = args[i + 1]

    if not task_id or not phase:
        return {"error": "usage: kanban track <task_id> <phase> <tokens> [--agent <name>] [--step <step_id>] [--model <model>] [--duration <seconds>]"}

    # Record subagent session for accurate per-task API call counting.
    # Each Agent tool spawn creates an independent subagent session.
    # The orchestrator passes the subagent session ID via --session.
    import os as _os
    session_id = _os.environ.get("CLAUDE_CODE_SESSION_ID", "")
    # --session flag overrides env (for subagent IDs)
    for i, a in enumerate(args):
        if a == "--session" and i + 1 < len(args):
            session_id = args[i + 1]

    tt = TokenTracker(reports_dir / "token_tracking.json")
    tt.track(task_id, tokens, phase, agent, model, duration)

    if session_id:
        entry = tt._data.setdefault(task_id, tt._data.get(task_id, {}))
        entry.setdefault("sessions", [])
        if session_id not in entry["sessions"]:
            entry["sessions"].append(session_id)
        # Map session → phase/step for per-step API call attribution
        entry.setdefault("session_phases", {})
        entry["session_phases"].setdefault(phase, [])
        if session_id not in entry["session_phases"][phase]:
            entry["session_phases"][phase].append(session_id)
        # Also track by step for per-step precision
        if step_id:
            entry.setdefault("session_steps", {})
            entry["session_steps"].setdefault(step_id, [])
            if session_id not in entry["session_steps"][step_id]:
                entry["session_steps"][step_id].append(session_id)
        tt._save()

    return {"tracked": task_id, "phase": phase, "tokens": tokens,
            "agent": agent, "model": model, "duration": duration,
            "session_id": session_id, "step": step_id}


def _cmd_stats(args: list[str]) -> dict:
    """Return token/time stats via the configured StatsBackend.

    Usage:
        kanban stats            # human-readable summary
        kanban stats --json     # JSON output (used by dashboard API)
    """
    from kanban_framework.infra.filesystem import Filesystem
    from kanban_framework.infra.stats_backend import resolve_stats_backend

    fs = Filesystem(Filesystem.find_project_root())
    cfg = {}
    try:
        cfg_path = fs.config_file()
        if cfg_path.is_file():
            import json
            cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        pass

    stats_cfg = cfg.get("stats", {}) if isinstance(cfg, dict) else {}
    backend_name = stats_cfg.get("backend", "native")
    backend = resolve_stats_backend(backend_name, fs.kanban_dir.parent)

    # Per-task stats: kanban stats --task <task_id>
    for i, a in enumerate(args):
        if a == "--task" and i + 1 < len(args):
            return backend.get_task_stats(args[i + 1])

    days = int(stats_cfg.get("days", 30))
    return backend.get_stats(days=days)


def _cmd_help(args: list[str]) -> dict:
    return {"commands": sorted(_CMD_MAP.keys())}


def _cmd_update(args: list[str]) -> dict:
    """Upgrade kanban-framework and sync skill files.

    Usage:
        kanban update                  # upgrade to latest stable
        kanban update 0.27.0           # install specific version
        kanban update --channel dev    # upgrade to latest dev (pre-release)
        kanban update --list           # list all available versions
        kanban update --channels       # list stable + dev channels
    """
    import subprocess

    # --list: show available versions from PyPI
    if args and args[0] == "--list":
        try:
            import json, urllib.request
            url = "https://pypi.org/pypi/kanban-framework/json"
            data = json.loads(urllib.request.urlopen(url, timeout=10).read())
            versions = sorted(data.get("releases", {}).keys(), reverse=True)[:20]
            return {"action": "list_versions", "count": len(versions), "versions": versions}
        except Exception as e:
            return {"action": "list_versions", "error": str(e)}

    # --channels: show stable + dev versions
    if args and args[0] == "--channels":
        try:
            import json, urllib.request
            url = "https://pypi.org/pypi/kanban-framework/json"
            data = json.loads(urllib.request.urlopen(url, timeout=10).read())
            all_v = sorted(data.get("releases", {}).keys(), reverse=True)
            stable = [v for v in all_v if not _is_pre_release(v)][:10]
            dev = [v for v in all_v if _is_pre_release(v)][:10]
            return {"action": "channels", "stable": stable, "dev": dev}
        except Exception as e:
            return {"action": "channels", "error": str(e)}

    # Parse args
    use_pre = False
    target = None
    for a in args:
        if a in ("--channel", "-c"):
            pass  # next arg is channel name
        elif a == "dev":
            use_pre = True
        elif not a.startswith("-"):
            target = a

    # Step 1: upgrade pip package
    if target:
        cmd = [sys.executable, "-m", "pip", "install", f"kanban-framework=={target}"]
    elif use_pre:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "--pre", "kanban-framework"]
    else:
        cmd = [sys.executable, "-m", "pip", "install", "--upgrade", "kanban-framework"]

    from kanban_framework.infra.filesystem import Filesystem
    result = Filesystem.run_no_window(cmd)
    from importlib.metadata import version as _pkg_version
    try:
        new_ver = _pkg_version("kanban-framework")
    except Exception:
        new_ver = "unknown"

    # Step 2: sync skill files (agents, rules, references) to project
    init_result = None
    if result.returncode == 0:
        init_result = Filesystem.run_no_window(
            [sys.executable, "-m", "kanban_framework", "init", "--apply"]
        )
        if init_result.returncode != 0:
            init_result = {"error": init_result.stderr.strip()}
        else:
            init_result = {"synced": True}

    # Step 3: always re-deploy dashboard files (version marker handles skip-if-current)
    from pathlib import Path
    dashboard_updated = False
    try:
        from kanban_framework.infra.filesystem import Filesystem
        root = Filesystem.find_project_root()
        fs = Filesystem(root)
        from kanban_framework.infra.dashboard import DashboardManager
        DashboardManager(fs.kanban_dir).deploy()
        dashboard_updated = True
    except Exception:
        pass

    return {
        "success": result.returncode == 0,
        "version": new_ver,
        "pip_output": result.stdout.strip().split("\n")[-1] if result.stdout else "",
        "skill_sync": init_result,
        "dashboard_redeployed": dashboard_updated,
    }


def _cmd_check_env(args: list[str]) -> dict:
    import os
    from pathlib import Path
    from kanban_framework.infra.filesystem import Filesystem
    from kanban_framework.infra.config import Config
    root = Filesystem.find_project_root()
    kanban_dir = root / ".kanban"

    agent_sync_issues = _check_agent_sync()

    # Read task_id_base status for config suggestions
    task_id_base = 0
    if kanban_dir.is_dir():
        try:
            fs = Filesystem(root)
            cfg = Config(fs)
            task_id_base = cfg.task_id_base
        except Exception:
            pass

    return {
        "project_root": str(root),
        "has_kanban": kanban_dir.is_dir(),
        "kanban_dir": str(kanban_dir),
        "ok": kanban_dir.is_dir(),
        "python": sys.executable,
        "agent_sync": {"in_sync": len(agent_sync_issues) == 0, "issues": agent_sync_issues},
        "config_suggestions": [] if task_id_base else ["task_id_base not set — run kanban init and enter your worker ID (e.g. worker ID 6696 → TASK-669601)"],
    }


def _check_agent_sync() -> list[str]:
    from pathlib import Path
    # kanban_framework/cli/main.py → kanban_framework/cli/ → kanban_framework/ → kanban root
    kanban_root = Path(__file__).resolve().parent.parent.parent
    agents_dir = kanban_root / "agents"
    skill_dir = kanban_root / "kanban_framework" / "_skill" / "agents"
    issues = []
    if not agents_dir.is_dir() or not skill_dir.is_dir():
        return issues
    for f in agents_dir.glob("*.md"):
        other = skill_dir / f.name
        if not other.is_file():
            issues.append(f"{f.name}: missing in _skill/agents/")
        elif not _files_equal(f, other):
            issues.append(f"{f.name}: out of sync")
    return issues


def _files_equal(a: 'Path', b: 'Path') -> bool:
    import hashlib
    return hashlib.md5(a.read_bytes()).hexdigest() == hashlib.md5(b.read_bytes()).hexdigest()


def _cmd_sync_agents(args: list[str]) -> dict:
    from pathlib import Path
    kanban_root = Path(__file__).resolve().parent.parent.parent
    agents_dir = kanban_root / "agents"
    skill_dir = kanban_root / "kanban_framework" / "_skill" / "agents"
    if not agents_dir.is_dir():
        return {"error": "agents/ directory not found"}

    skill_dir.mkdir(parents=True, exist_ok=True)
    synced = []
    for f in agents_dir.glob("*.md"):
        target = skill_dir / f.name
        target.write_bytes(f.read_bytes())
        synced.append(f.name)
    return {"synced": synced, "count": len(synced)}


def _output_version() -> None:
    ver = _get_version()
    if _USE_JSON:
        _output({"success": True, "data": {"version": ver}})
    else:
        print(f"kanban {ver}")


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("kanban-framework")
    except Exception:
        pass
    try:
        from pathlib import Path
        cfg = Path(__file__).resolve().parent.parent / "pyproject.toml"
        if cfg.is_file():
            import re
            text = cfg.read_text(encoding="utf-8")
            m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
            if m:
                return m.group(1)
    except Exception:
        pass
    return "unknown"


if __name__ == "__main__":
    main()
