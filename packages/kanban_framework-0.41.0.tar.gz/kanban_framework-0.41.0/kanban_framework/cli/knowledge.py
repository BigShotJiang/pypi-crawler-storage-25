from __future__ import annotations
from pathlib import Path
from kanban_framework.infra.filesystem import Filesystem
from kanban_framework.domain.knowledge import KnowledgeManager


def _build_summary(results: list[dict], limit: int = 10) -> list[dict]:
    """Build a lightweight summary list from search results.

    Each summary entry contains id, title, and relevance (score).
    Used by search/hybrid/semantic/list commands for quick overview.
    """
    return [
        {"id": r["id"], "title": r.get("title", ""), "relevance": r.get("score", 0)}
        for r in results[:limit]
    ]


def _strip_heavy_fields(results: list[dict]) -> list[dict]:
    """Remove heavy text fields from results for token-efficient output.

    Strips content, code_example, content_segmented, and steps from each
    result dict. Used with --summary-only to avoid wasting tokens on full
    content that should be fetched via `kanban knowledge get <id>` instead.
    """
    heavy = {"content", "code_example", "content_segmented", "steps", "embedding"}
    return [
        {k: v for k, v in r.items() if k not in heavy}
        for r in results
    ]


def dispatch(args: list[str]) -> dict:
    sub = args[0] if args else "search"

    if sub in ("--help", "-h", "help"):
        root = Filesystem.find_project_root()
        fs = Filesystem(root=root)
        km = KnowledgeManager(fs)
        return _handle_help(km, args[1:] if len(args) > 1 else [])

    root = Filesystem.find_project_root()
    fs = Filesystem(root=root)
    km = KnowledgeManager(fs)

    if sub == "search":
        return _handle_search(km, args[1:])
    if sub == "semantic":
        return _handle_semantic(km, args[1:])
    if sub == "hybrid":
        return _handle_hybrid(km, args[1:])
    if sub == "add":
        return _handle_add(km, args[1:])
    if sub == "domains":
        return {"domains": km.get_domains()}
    if sub == "match":
        return _handle_match(km, args[1:])
    if sub == "stale":
        return {"stale_ids": km.mark_stale_entries()}
    if sub == "gaps":
        return {"gaps": km.get_knowledge_gap_report()}
    if sub == "migrate":
        return {"migrated": km.migrate_legacy_log()}
    if sub == "import":
        return _handle_import(km, args[1:])
    if sub == "learn":
        return _handle_learn(km, args[1:])
    if sub == "similar":
        return _handle_similar(km, args[1:])
    if sub == "usage":
        return _handle_usage(km, args[1:])
    if sub == "teach":
        return _handle_teach(km, args[1:])
    if sub == "categories":
        return _handle_categories()
    if sub == "health":
        return _handle_health(km)
    if sub == "share":
        return _handle_share(km, args[1:])
    if sub == "backup":
        return _handle_backup(km)
    if sub == "conflicts":
        return _handle_conflicts(km, args[1:])
    if sub == "choose":
        return _handle_choose(km, args[1:])
    if sub == "list":
        return _handle_list(km, args[1:])
    if sub == "get":
        return _handle_get(km, args[1:])
    if sub == "delete":
        return _handle_delete(km, args[1:])
    return {"subcommand": sub, "results": []}


def _summary_only(args: list[str]) -> tuple[list[str], bool]:
    """Extract --summary-only flag from args. Returns (remaining_args, enabled)."""
    if "--summary-only" in args:
        return [a for a in args if a != "--summary-only"], True
    return args, False


def _handle_search(km: KnowledgeManager, args: list[str]) -> dict:
    args, summary_only = _summary_only(args)
    domain = None
    tag = None
    task = None
    intent = None
    keyword = ""
    i = 0
    while i < len(args):
        if args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--tag" and i + 1 < len(args):
            tag = args[i + 1]; i += 2
        elif args[i] == "--task" and i + 1 < len(args):
            task = args[i + 1]; i += 2
        elif args[i] == "--intent" and i + 1 < len(args):
            intent = args[i + 1]; i += 2
        else:
            keyword = args[i]; i += 1

    if tag:
        results = km.search_by_tag(tag)
        return {"tag": tag, "results": _strip_heavy_fields(results) if summary_only else results,
                "count": len(results), "summary": _build_summary(results),
                "summary_only": summary_only}
    if task:
        results = km.search_by_task(task)
        return {"task": task, "results": _strip_heavy_fields(results) if summary_only else results,
                "count": len(results), "summary": _build_summary(results),
                "summary_only": summary_only}
    if intent and keyword:
        results = km.search_by_intent(intent, keyword, domain=domain)
        return {"intent": intent, "keyword": keyword,
                "results": _strip_heavy_fields(results) if summary_only else results,
                "count": len(results), "summary": _build_summary(results),
                "summary_only": summary_only}
    if domain and keyword:
        domain_results = km.search_by_domain(domain)
        results = [r for r in domain_results if keyword.lower() in r.get("title", "").lower()
                   or keyword.lower() in r.get("content", "").lower()]
        return {"domain": domain, "keyword": keyword,
                "results": _strip_heavy_fields(results) if summary_only else results,
                "count": len(results), "summary": _build_summary(results),
                "summary_only": summary_only}
    if domain:
        results = km.search_by_domain(domain)
        return {"domain": domain, "results": _strip_heavy_fields(results) if summary_only else results,
                "count": len(results), "summary": _build_summary(results),
                "summary_only": summary_only}
    # Default: hybrid search (keyword + semantic) for better recall (#242)
    results = km.search_hybrid(keyword) if keyword else []
    return {"keyword": keyword, "mode": "hybrid",
            "results": _strip_heavy_fields(results) if summary_only else results,
            "count": len(results), "summary": _build_summary(results),
            "summary_only": summary_only}


def _handle_semantic(km: KnowledgeManager, args: list[str]) -> dict:
    args, summary_only = _summary_only(args)
    query = " ".join(args)
    limit = 20
    results = km.search_semantic(query, limit=limit)
    return {"query": query, "mode": "semantic",
            "results": _strip_heavy_fields(results) if summary_only else results,
            "count": len(results), "summary": _build_summary(results),
            "summary_only": summary_only}


def _handle_hybrid(km: KnowledgeManager, args: list[str]) -> dict:
    args, summary_only = _summary_only(args)
    query = " ".join(args)
    limit = 20
    results = km.search_hybrid(query, limit=limit)
    return {"query": query, "mode": "hybrid",
            "results": _strip_heavy_fields(results) if summary_only else results,
            "count": len(results), "summary": _build_summary(results),
            "summary_only": summary_only}


def _handle_add(km: KnowledgeManager, args: list[str]) -> dict:
    kwargs: dict = {"domain": "infra", "category": "工具", "title": "", "content": "",
                     "code_example": "", "source": {}, "status": "active"}
    ttl_days = None
    verify = False
    i = 0
    while i < len(args):
        if args[i] == "--verify":
            verify = True; i += 1
        elif args[i] == "--ttl" and i + 1 < len(args):
            try:
                ttl_days = int(args[i + 1])
            except ValueError:
                pass
            i += 2
        elif args[i] in ("--domain", "--category", "--title", "--severity", "--status"):
            key = args[i][2:]
            kwargs[key] = args[i + 1]; i += 2
        elif args[i] == "--tags":
            kwargs["tags"] = args[i + 1].split(","); i += 2
        elif args[i] == "--content":
            kwargs["content"] = args[i + 1]; i += 2
        elif args[i] == "--code-example":
            kwargs["code_example"] = args[i + 1]; i += 2
        elif args[i] == "--source" and i + 1 < len(args):
            import json as _json
            try:
                kwargs["source"] = _json.loads(args[i + 1])
            except _json.JSONDecodeError:
                kwargs["source"] = {"raw": args[i + 1]}
            i += 2
        else:
            # Positional argument: use as content shortcut (#186)
            if not kwargs.get("_positional_used"):
                if not kwargs["content"]:
                    kwargs["content"] = args[i]
                elif not kwargs["title"]:
                    kwargs["title"] = args[i]
                kwargs["_positional_used"] = True
            i += 1
    kwargs.pop("_positional_used", None)
    if ttl_days is not None and ttl_days > 0:
        kwargs["ttl_days"] = ttl_days
    try:
        entry = km.add_entry(**kwargs)
    except ValueError as e:
        return {"error": str(e)}
    if entry.get("skipped"):
        return {"skipped": True, "existing_id": entry.get("existing_id"), "reason": entry.get("reason")}
    result = {"added": entry["id"], "title": entry.get("title", ""), "ttl_days": ttl_days}
    if verify:
        stored = km.get_entry(entry["id"])
        result["verify"] = {
            "title_ok": bool(stored.get("title", "").strip()),
            "content_ok": bool(stored.get("content", "").strip()),
            "tags_ok": isinstance(stored.get("tags"), list),
            "all_ok": bool(stored.get("title", "").strip() or stored.get("content", "").strip()),
        }
    return result


def _handle_import(km: KnowledgeManager, args: list[str]) -> dict:
    import json as _json
    file_path = None
    i = 0
    while i < len(args):
        if args[i] == "--entry-file" and i + 1 < len(args):
            file_path = args[i + 1]; i += 2
        else:
            i += 1
    if not file_path:
        return {"error": "--entry-file required"}
    data = _json.loads(Path(file_path).read_text(encoding="utf-8"))
    entries = data.get("entries", [])
    added = []
    for e in entries:
        entry = km.add_entry(
            domain=e.get("domain", "infra"),
            category=e.get("category", "工具"),
            title=e["title"],
            content=e["content"],
            tags=e.get("tags", []),
            severity=e.get("severity", "medium"),
            source=e.get("source", {}),
        )
        added.append(entry["id"])
    return {"imported": len(added), "ids": added}


def _auto_extract_entry(file_path: str, content: str, domain: str, status: str) -> dict | None:
    """Static analysis: extract module knowledge from Python source code."""
    import re
    from pathlib import Path as _Path

    module_name = _Path(file_path).stem
    if module_name in ("__init__", "__pycache__"):
        return None

    # Extract module docstring
    doc_match = re.search(r'(?:"""(.*?)"""|\'\'\'(.*?)\'\'\')', content, re.DOTALL)
    doc = ""
    if doc_match:
        doc = (doc_match.group(1) or doc_match.group(2) or "").strip()
        doc = " ".join(doc.split())[:300]

    # Extract function and class definitions
    funcs = re.findall(r'^\s*def\s+(\w+)', content, re.MULTILINE)
    classes = re.findall(r'^\s*class\s+(\w+)', content, re.MULTILINE)

    # Extract meaningful imports (non-stdlib)
    imports = re.findall(
        r'^\s*(?:from|import)\s+(\S+)', content, re.MULTILINE
    )
    local_imports = [m for m in imports
                     if m.split(".")[0] not in (
                         "__future__", "os", "sys", "json", "re", "math",
                         "pathlib", "datetime", "time", "collections",
                         "typing", "dataclasses", "random", "enum", "abc",
                         "itertools", "functools", "io", "subprocess",
                         "logging", "hashlib", "shutil", "tempfile", "argparse",
                     )]

    # Build content
    parts = []
    if doc:
        parts.append(doc)
    if funcs:
        parts.append(f"关键函数({len(funcs)}): {', '.join(funcs[:6])}")
    if classes:
        parts.append(f"关键类({len(classes)}): {', '.join(classes[:4])}")
    if local_imports:
        parts.append(f"依赖模块: {', '.join(local_imports[:8])}")

    if not parts:
        return None

    content_text = "。".join(parts) + "。"

    # Generate tags
    tags = [f"biz:{domain}", f"module:{module_name}", "stack:python"]
    if "test" in module_name.lower():
        tags.append("pattern:testing")

    # Code example: first function signature
    code_example = ""
    for fn in funcs[:2]:
        sig = re.search(rf'def {fn}\((.*?)\):', content)
        if sig:
            code_example += f"def {fn}({sig.group(1)}): ...\n"
    if not code_example and classes:
        code_example = f"class {classes[0]}(...): ..."

    return {
        "domain": domain,
        "category": "架构",
        "title": f"{module_name} 模块",
        "content": content_text,
        "code_example": code_example.strip(),
        "tags": tags,
    }


def _handle_learn(km: KnowledgeManager, args: list[str]) -> dict:
    path = ""
    domain = ""
    follow_deps = True  # default: follow imports
    activate = False
    auto = False
    i = 0
    while i < len(args):
        if args[i] == "--path" and i + 1 < len(args):
            path = args[i + 1]; i += 2
        elif args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--no-follow-deps":
            follow_deps = False; i += 1
        elif args[i] == "--activate":
            activate = True; i += 1
        elif args[i] == "--auto":
            auto = True; i += 1
        else:
            i += 1
    if not path:
        return {"error": "--path required"}
    if not domain:
        return {"error": "--domain required"}

    from pathlib import Path as _Path
    import re as _re
    p = _Path(path)
    if not p.exists():
        return {"error": f"path not found: {path}"}

    # Collect code files
    code_files: list[dict] = []
    deps_found: list[str] = []
    if p.is_file():
        code_files.append({"path": str(p), "content": p.read_text(encoding="utf-8")[:3000]})
        deps_found = _find_imports(p.read_text(encoding="utf-8"), p.parent)
    elif p.is_dir():
        for f in sorted(p.rglob("*.py")):
            if f.is_file():
                content = f.read_text(encoding="utf-8")[:3000]
                code_files.append({"path": str(f), "content": content})
                if follow_deps:
                    deps_found.extend(_find_imports(content, f.parent))

    # Deduplicate and resolve dependency paths
    deps_found = sorted(set(deps_found))
    dep_files: list[dict] = []
    for dep_path in deps_found:
        dep_p = _Path(dep_path)
        if dep_p.is_file() and dep_p.suffix == ".py":
            dep_files.append({"path": dep_path, "content": dep_p.read_text(encoding="utf-8")[:3000]})

    # Check what's already in KB for these modules
    known_modules: list[str] = []
    new_modules: list[str] = []
    for cf in code_files + dep_files:
        module_name = _Path(cf["path"]).stem
        existing = km.search_by_tag(f"module:{module_name}")
        if existing:
            known_modules.append(module_name)
        else:
            new_modules.append(module_name)

    entry_status = "active" if activate else "draft"

    # --auto: create knowledge entries automatically via static analysis
    added_ids: list[str] = []
    if auto and new_modules:
        for cf in code_files + dep_files:
            module_name = _Path(cf["path"]).stem
            if module_name in known_modules:
                continue
            entry = _auto_extract_entry(cf["path"], cf["content"], domain, entry_status)
            if entry:
                try:
                    eid = km.add_entry(
                        domain=entry["domain"],
                        category=entry["category"],
                        title=entry["title"],
                        content=entry["content"],
                        code_example=entry.get("code_example", ""),
                        tags=entry.get("tags", []),
                        status=entry_status,
                        upsert=True,
                    )
                    added_ids.append(eid)
                except Exception:
                    pass

    return {
        "action": "learn",
        "domain": domain,
        "path": str(p),
        "target_files": len(code_files),
        "dependency_files": len(dep_files),
        "deps_found": deps_found[:20],
        "known_modules": known_modules,
        "new_modules": new_modules,
        "code_files": code_files + dep_files if not auto else [],
        "activate": activate,
        "auto": auto,
        "auto_added": added_ids,
        "instruction": (
            f"Read the code files above. For each file, check if the module is already in known_modules. "
            f"Only extract NEW understanding for modules in new_modules={new_modules}. "
            f"For each new module, call knowledge add with domain='{domain}', status='{entry_status}', "
            f"category=架构, title='<module_name> 模块结构与职责', "
            f"content='模块职责、关键函数/类、依赖关系', "
            f"tags=['biz:{domain}', 'module:<name>', 'stack:python'], "
            f"code_example='关键接口代码片段'. "
            f"Follow knowledge-accumulation-guide.md boundary rules."
        ),
    }


def _find_imports(content: str, parent_dir) -> list[str]:
    """Find local/relative module imports in Python code. Returns resolved file paths."""
    import re

    # Find project root (where .kanban/ lives)
    root = parent_dir
    while root.parent != root and not (root / ".kanban").is_dir():
        root = root.parent

    deps = []
    for m in re.finditer(
        r'(?:^from\s+(\S+)\s+import)|(?:^import\s+(\S+))',
        content, re.MULTILINE
    ):
        mod_path = m.group(1) or m.group(2)
        if not mod_path:
            continue

        # Skip stdlib
        if mod_path.split(".")[0] in ("__future__", "os", "sys", "json", "re", "math",
                                        "pathlib", "datetime", "time", "collections",
                                        "typing", "dataclasses", "random", "enum", "abc",
                                        "itertools", "functools", "io", "subprocess",
                                        "logging", "hashlib", "shutil", "tempfile"):
            continue

        # Relative import: from .xxx import → xxx.py in same dir
        if mod_path.startswith("."):
            clean = mod_path.lstrip(".")
            candidate = parent_dir / f"{clean}.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue
            candidate = parent_dir / clean / "__init__.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue

        # Absolute or sibling import: try resolve relative to project root
        parts = mod_path.split(".")
        # Try as file path relative to root parent
        candidate = root.parent / f"{'/'.join(parts)}.py"
        if candidate.is_file():
            deps.append(str(candidate))
            continue

        # Simple sibling import: import xxx
        if len(parts) == 1:
            candidate = parent_dir / f"{parts[0]}.py"
            if candidate.is_file():
                deps.append(str(candidate))
                continue
    return deps


def _handle_similar(km: KnowledgeManager, args: list[str]) -> dict:
    tags: list[str] = []
    i = 0
    while i < len(args):
        if args[i] == "--tags" and i + 1 < len(args):
            tags = args[i + 1].split(","); i += 2
        else:
            i += 1
    results = km.find_similar_pitfalls(tags)
    return {"tags": tags, "similar": results, "count": len(results)}


def _handle_usage(km: KnowledgeManager, args: list[str]) -> dict:
    entry_id = ""
    task_id = ""
    i = 0
    while i < len(args):
        if args[i] == "--entry-id" and i + 1 < len(args):
            entry_id = args[i + 1]; i += 2
        elif args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        else:
            i += 1
    km.record_usage(entry_id, task_id)
    return {"entry_id": entry_id, "task_id": task_id, "recorded": True}


def _handle_teach(km: KnowledgeManager, args: list[str]) -> dict:
    """Teach the framework a procedural business workflow. (#239)

    Usage:
        kanban knowledge teach "红点功能开发" \
            --domain "web" --category "流程" \
            --step "1. 数据模型添加 unread 字段" \
            --step "2. API 返回未读数" \
            --step "3. 前端组件显示红点" \
            --step "4. 消息推送触发清除"
    """
    title = ""
    steps = []
    domain = "infra"
    category = "流程"
    i = 0
    while i < len(args):
        if args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--category" and i + 1 < len(args):
            category = args[i + 1]; i += 2
        elif args[i] == "--step" and i + 1 < len(args):
            steps.append(args[i + 1]); i += 2
        elif not title:
            title = args[i]; i += 1
        else:
            i += 1

    if not title or not steps:
        return {"error": "usage: kanban knowledge teach \"<title>\" --step \"<step1>\" --step \"<step2>\" ..."}

    # Build procedure content from steps (strip leading digits + dot)
    content_lines = [f"# {title}", "", "## 步骤"]
    import re
    for j, s in enumerate(steps, 1):
        clean = re.sub(r'^\d+[\.\)、]\s*', '', s)
        content_lines.append(f"{j}. {clean}")
    content = "\n".join(content_lines)

    entry = km.add_entry(
        domain=domain, category=category, title=title,
        content=content, severity="medium", status="active",
        entry_type="procedure", steps=steps,
    )
    return {"taught": entry["id"], "title": title, "steps": len(steps)}


def _handle_categories() -> dict:
    from kanban_framework.domain.knowledge import VALID_CATEGORIES, VALID_SEVERITIES
    return {
        "categories": {k: v["desc"] for k, v in VALID_CATEGORIES.items()},
        "severities": {k: v["desc"] for k, v in VALID_SEVERITIES.items()},
    }


def _handle_health(km: KnowledgeManager) -> dict:
    from collections import Counter
    from datetime import datetime, timezone, timedelta

    entries = km.list_entries(limit=500, status="active")
    total = len(entries)

    # 1. Category distribution
    cat_counts = Counter(e.get("category", "(uncategorized)") for e in entries)

    # 2. Expired / expiring soon
    now = datetime.now(timezone.utc)
    week = now + timedelta(days=7)
    expired = []
    expiring_soon = []
    for e in entries:
        sa = e.get("stale_at")
        if not sa:
            continue
        try:
            stale_time = datetime.fromisoformat(sa)
            if stale_time.tzinfo is None:
                stale_time = stale_time.replace(tzinfo=timezone.utc)
            if stale_time < now:
                expired.append({"id": e["id"], "title": e.get("title", ""), "stale_at": sa})
            elif stale_time < week:
                expiring_soon.append({"id": e["id"], "title": e.get("title", ""), "stale_at": sa})
        except (ValueError, TypeError):
            pass

    # 3. Duplicate detection (common prefix ratio > 0.6)
    duplicates = []
    for i, e1 in enumerate(entries):
        t1 = e1.get("title", "")
        if not t1:
            continue
        for e2 in entries[i + 1:]:
            t2 = e2.get("title", "")
            if not t2:
                continue
            ratio = _title_similarity(t1, t2)
            if ratio > 0.6:
                duplicates.append({
                    "pair": [e1["id"], e2["id"]],
                    "titles": [t1, t2],
                    "similarity": round(ratio, 2),
                })

    # 4. Low quality entries
    low_quality = []
    for e in entries:
        content = (e.get("content") or "").strip()
        if not content or len(content) < 20:
            low_quality.append({"id": e["id"], "title": e.get("title", ""), "content_length": len(content)})

    # Legacy fields
    stale_ids = km.mark_stale_entries()
    gaps = km.get_knowledge_gap_report()

    return {
        "total_entries": total,
        "category_distribution": dict(cat_counts.most_common()),
        "expired": expired,
        "expiring_soon": expiring_soon,
        "duplicates": duplicates,
        "low_quality": low_quality,
        "stale_count": len(stale_ids),
        "knowledge_gaps": gaps,
    }


def _title_similarity(a: str, b: str) -> float:
    """Simple character-level common prefix ratio for duplicate detection."""
    if not a or not b:
        return 0.0
    # Count matching characters in order
    matches = 0
    bi = 0
    for ch in a:
        pos = b.find(ch, bi)
        if pos >= 0:
            matches += 1
            bi = pos + 1
    return 2.0 * matches / (len(a) + len(b))


def _handle_share(km: KnowledgeManager, args: list[str]) -> dict:
    """Push knowledge entries to team shared knowledge base. (#237)

    Usage:
        kanban knowledge share --push <entry_id>   # Push single entry
        kanban knowledge share --push --all         # Push all active entries
        kanban knowledge share --status             # Check share config
    """
    if not args:
        return {"error": "usage: kanban knowledge share --push <entry_id> | --status"}

    if args[0] == "--status":
        backend = getattr(km, '_backend', None)
        if hasattr(backend, '_secondary') and backend._secondary is not None:
            return {"share_enabled": True, "type": type(backend._secondary).__name__}
        return {"share_enabled": False}

    if args[0] == "--push":
        share_be = None
        backend = getattr(km, '_backend', None)
        if hasattr(backend, '_secondary'):
            share_be = backend._secondary

        if share_be is None:
            return {"error": "Share not configured. Set knowledge.share.enabled=true in config.json"}

        if "--all" in args:
            entries = km.list_entries(status="active")
            pushed = 0
            for e in entries:
                try:
                    share_be.add_entry(**e)
                    pushed += 1
                except Exception:
                    pass
            return {"pushed_all": True, "count": pushed, "total": len(entries)}
        else:
            entry_id = args[1] if len(args) > 1 else ""
            if not entry_id:
                return {"error": "entry_id required"}
            entry = km.get_entry(entry_id)
            if entry is None:
                return {"error": f"entry {entry_id} not found"}
            result = share_be.add_entry(**entry)
            return {"pushed": True, "id": result.get("id", entry_id)}


def _handle_backup(km: KnowledgeManager) -> dict:
    """Manually trigger knowledge database backup."""
    km._auto_backup()
    bak_dir = km._db_path.parent
    backups = sorted(
        [f.name for f in bak_dir.glob("knowledge.db.bak.*")],
        key=lambda x: int(x.rsplit(".", 1)[-1])
    )
    return {
        "backed_up": True,
        "db_path": str(km._db_path),
        "backup_dir": str(bak_dir),
        "max_backups": km.MAX_BACKUPS,
        "existing_backups": backups,
    }


def _handle_conflicts(km: KnowledgeManager, args: list[str]) -> dict:
    task_id = ""
    i = 0
    while i < len(args):
        if args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        else:
            i += 1
    if not task_id:
        return {"error": "--task-id required"}
    conflicts = km.find_conflicting_solutions(task_id)
    return {"task_id": task_id, "conflicts": conflicts, "count": len(conflicts)}


def _handle_choose(km: KnowledgeManager, args: list[str]) -> dict:
    from datetime import datetime, timezone
    task_id = ""
    choice_id = ""
    selected = ""
    rationale = ""
    i = 0
    while i < len(args):
        if args[i] == "--task-id" and i + 1 < len(args):
            task_id = args[i + 1]; i += 2
        elif args[i] == "--choice-id" and i + 1 < len(args):
            choice_id = args[i + 1]; i += 2
        elif args[i] == "--selected" and i + 1 < len(args):
            selected = args[i + 1]; i += 2
        elif args[i] == "--rationale" and i + 1 < len(args):
            rationale = args[i + 1]; i += 2
        else:
            i += 1
    if not task_id or not choice_id or not selected:
        return {"error": "--task-id, --choice-id, --selected required"}

    fs = km._fs
    task_dir = fs.task_dir(task_id)
    fs.ensure_dir(task_dir)
    choices_path = task_dir / "plan_choices.json"
    choices = fs.read_json(choices_path) if fs.file_exists(choices_path) else {"choices": []}

    now = datetime.now(timezone.utc).isoformat()
    choices["choices"].append({
        "id": choice_id,
        "selected": selected,
        "rationale": rationale,
        "selected_at": now,
    })
    fs.write_json(choices_path, choices)
    return {"task_id": task_id, "choice_id": choice_id, "selected": selected, "recorded": True}


def _handle_list(km: KnowledgeManager, args: list[str]) -> dict:
    args, summary_only = _summary_only(args)
    domain = None
    category = None
    status = "active"
    i = 0
    while i < len(args):
        if args[i] == "--domain" and i + 1 < len(args):
            domain = args[i + 1]; i += 2
        elif args[i] == "--category" and i + 1 < len(args):
            category = args[i + 1]; i += 2
        elif args[i] == "--status" and i + 1 < len(args):
            status = args[i + 1]; i += 2
        else:
            i += 1
    results = km.list_entries(domain=domain, category=category, status=status)
    return {
        "domain": domain, "category": category, "status": status,
        "results": _strip_heavy_fields(results) if summary_only else results,
        "count": len(results), "summary": _build_summary(results),
        "summary_only": summary_only,
    }


def _handle_get(km: KnowledgeManager, args: list[str]) -> dict:
    entry_id = args[0] if args else ""
    if not entry_id:
        return {"error": "entry ID required (e.g. K001)"}
    entry = km.get_entry(entry_id)
    if entry is None:
        return {"error": f"entry {entry_id} not found"}
    return {"entry": entry}


def _handle_delete(km: KnowledgeManager, args: list[str]) -> dict:
    entry_id = args[0] if args else ""
    if not entry_id:
        return {"error": "entry ID required (e.g. K001)"}
    entry = km.get_entry(entry_id)
    if entry is None:
        return {"error": f"entry {entry_id} not found"}
    km.delete_entry(entry_id)
    return {"deleted": entry_id, "title": entry.get("title", "")}


def _handle_match(km: KnowledgeManager, args: list[str]) -> dict:
    text = " ".join(args)
    domains = km.match_domain(text)
    return {"text": text, "matched_domains": domains}


def _handle_help(km: KnowledgeManager, args: list[str]) -> dict:
    """Show help for a specific knowledge subcommand or list all commands."""
    if args:
        return _help_for_command(args[0])

    # When no subcommand is specified, return a concise overview.
    # Detailed reference: .claude/skills/kanban/references/knowledge-cli-reference.md
    return {
        "usage": "kanban knowledge <subcommand> [options]",
        "description": "知识库管理 — 搜索、添加、导入、导出、健康检查",
        "token_guide": "search/hybrid/semantic --json 先用 .data.summary 筛选，再用 get <id> 取详情",
        "subcommands": {
            "search": "多模式搜索（--domain/--tag/--task/--intent）",
            "hybrid": "混合搜索 FTS5 + 语义",
            "semantic": "纯语义搜索（embedding 向量）",
            "match": "精确 FTS5 关键词匹配",
            "list": "按 domain/category/status 过滤列表",
            "get": "获取单条完整详情 K001",
            "add": "添加知识条目",
            "import": "从 JSON 文件批量导入",
            "learn": "从复盘文档提取知识",
            "teach": "创建步骤化教程条目",
            "delete": "删除条目",
            "domains": "列出所有领域",
            "categories": "列出所有分类",
            "health": "健康检查（过期/重复/低质量）",
            "stale": "标记过期条目",
            "gaps": "知识缺口报告",
            "similar": "检测相似条目",
            "usage": "查询任务引用记录",
            "share": "推送到团队共享知识库",
            "backup": "备份 knowledge.db",
            "conflicts": "合并冲突检测",
            "choose": "冲突解决选择",
            "migrate": "迁移旧格式数据",
        },
    }


def _help_for_command(sub: str) -> dict:
    """Detailed help for a single knowledge subcommand."""
    helps = {
        "search": {
            "usage": "kanban knowledge search [keyword] [--domain D] [--tag T] [--task ID] [--intent I] [--json]",
            "description": "多模式搜索。无参数时默认 hybrid 搜索。intent 选项: pitfall_check / constraint_lookup / experience_reuse / general",
            "examples": [
                "kanban knowledge search 架构",
                "kanban knowledge search --domain python 性能",
                "kanban knowledge search --intent pitfall_check auth",
                "kanban knowledge search --tag biz:rpg",
                "kanban knowledge search --task TASK-001",
            ],
        },
        "hybrid": {
            "usage": "kanban knowledge hybrid <query> [--json]",
            "description": "混合搜索 — FTS5 关键词 + 语义向量 RRF 融合排序。默认 limit=20",
            "examples": ["kanban knowledge hybrid Python PyQt 任务管理"],
        },
        "semantic": {
            "usage": "kanban knowledge semantic <query> [--json]",
            "description": "语义搜索 — 基于 embedding 向量的 ANN 检索。即使关键词不匹配也能召回语义相关条目",
            "examples": ["kanban knowledge semantic 组件化架构设计"],
        },
        "match": {
            "usage": "kanban knowledge match <text>",
            "description": "精确 FTS5 关键词匹配，跳过缩写展开，直接分词查询。返回匹配的领域",
            "examples": ["kanban knowledge match combat module"],
        },
        "list": {
            "usage": "kanban knowledge list [--domain D] [--category C] [--status active|draft|stale]",
            "description": "按过滤条件列出条目。默认 status=active，最多 50 条",
            "examples": [
                "kanban knowledge list",
                "kanban knowledge list --domain python --category 架构",
                "kanban knowledge list --status draft",
            ],
        },
        "get": {
            "usage": "kanban knowledge get <id>",
            "description": "获取单条知识条目的完整详情（含 content/code_example/tags/source 等全字段）",
            "examples": ["kanban knowledge get K001", "kanban knowledge get K021"],
        },
        "add": {
            "usage": "kanban knowledge add [--domain D] [--category C] [--title T] [--content C] [--tags T1,T2] [--severity S] [--status active|draft] [--ttl N] [--code-example E] [--source JSON]",
            "description": "添加知识条目到 knowledge.db。domain 默认 infra，category 默认 工具",
            "examples": [
                'kanban knowledge add --domain python --category 踩坑 --title "GIL 死锁" --content "多线程注意..." --severity high --ttl 90',
                'kanban knowledge add --title "SQL 优化" --content "EXPLAIN 分析..." --tags sql,performance',
            ],
        },
        "import": {
            "usage": "kanban knowledge import <file.json>",
            "description": "从 JSON 文件批量导入知识条目。格式: [{\"domain\":..., \"title\":..., \"content\":...}, ...]",
            "examples": ["kanban knowledge import extracted.json"],
        },
        "learn": {
            "usage": "kanban knowledge learn <path> --task-id TASK-NNN",
            "description": "从复盘文档或代码目录提取结构化知识条目",
            "examples": ["kanban knowledge learn .kanban/tasks/TASK-001/iteration-1/retrospective.md --task-id TASK-001"],
        },
        "teach": {
            "usage": "kanban knowledge teach --title T --domain D --category C --step S1 --step S2 ...",
            "description": "创建步骤化教程条目（type=procedure），适用于操作流程类知识",
            "examples": ["kanban knowledge teach --title \"部署流程\" --domain infra --category 工具 --step \"构建镜像\" --step \"推送仓库\" --step \"重启服务\""],
        },
        "delete": {
            "usage": "kanban knowledge delete <id>",
            "description": "删除指定条目",
            "examples": ["kanban knowledge delete K001"],
        },
        "domains": {
            "usage": "kanban knowledge domains",
            "description": "列出所有已注册的知识领域及标签",
            "examples": ["kanban knowledge domains"],
        },
        "categories": {
            "usage": "kanban knowledge categories",
            "description": "列出所有标准分类（架构/踩坑/工具/最佳实践 等）",
            "examples": ["kanban knowledge categories"],
        },
        "health": {
            "usage": "kanban knowledge health",
            "description": "健康检查 — 分类分布、过期条目、即将过期、疑似重复、低质量条目",
            "examples": ["kanban knowledge health"],
        },
        "stale": {
            "usage": "kanban knowledge stale",
            "description": "标记已超过 stale_at 的条目为 stale 状态",
            "examples": ["kanban knowledge stale"],
        },
        "gaps": {
            "usage": "kanban knowledge gaps",
            "description": "知识缺口报告 — 各 domain 的条目密度和缺失分析",
            "examples": ["kanban knowledge gaps"],
        },
        "similar": {
            "usage": "kanban knowledge similar --title T --content C",
            "description": "检测与给定内容相似的已有条目，用于去重参考",
            "examples": ["kanban knowledge similar --title \"JWT 认证\" --content \"使用 PyJWT 实现 token 刷新\""],
        },
        "usage": {
            "usage": "kanban knowledge usage <id>",
            "description": "查询哪些任务引用过该条目",
            "examples": ["kanban knowledge usage K001"],
        },
        "share": {
            "usage": "kanban knowledge share [--push] [--pull] [--list]",
            "description": "团队知识库共享。--push 推送本地条目，--pull 拉取远程条目",
            "examples": ["kanban knowledge share --push", "kanban knowledge share --list"],
        },
        "backup": {
            "usage": "kanban knowledge backup",
            "description": "手动备份 knowledge.db（最多保留 5 个轮转备份）",
            "examples": ["kanban knowledge backup"],
        },
        "conflicts": {
            "usage": "kanban knowledge conflicts --task-id TASK-NNN",
            "description": "检测任务关联的知识条目合并冲突",
            "examples": ["kanban knowledge conflicts --task-id TASK-001"],
        },
        "choose": {
            "usage": "kanban knowledge choose --task-id TASK-NNN --choice-id C --selected K001 --rationale R",
            "description": "解决知识条目合并冲突，选择一个版本",
            "examples": ["kanban knowledge choose --task-id TASK-001 --choice-id C01 --selected K005 --rationale \"版本更新\""],
        },
        "migrate": {
            "usage": "kanban knowledge migrate",
            "description": "迁移旧格式数据（legacy logs → knowledge.db 条目）",
            "examples": ["kanban knowledge migrate"],
        },
    }
    info = helps.get(sub, {"error": f"unknown subcommand: {sub}", "hint": "kanban knowledge help 查看全部"})
    if "subcommand" not in info:
        info["subcommand"] = sub
    return info
