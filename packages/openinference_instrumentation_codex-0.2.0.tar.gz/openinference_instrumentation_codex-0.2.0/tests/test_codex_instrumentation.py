from __future__ import annotations

import importlib
import sys
from pathlib import Path

import pytest
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace.status import StatusCode

from openinference.instrumentation.codex import CodexInstrumentor
from openinference.instrumentation.codex._attributes import map_codex_attributes
from openinference.instrumentation.codex._config import CodexConfig

MOCKS_ROOT = Path(__file__).resolve().parent / "mocks"


@pytest.fixture
def codex_module(monkeypatch):
    monkeypatch.syspath_prepend(str(MOCKS_ROOT))
    sys.modules.pop("codex", None)
    yield importlib.import_module("codex")
    sys.modules.pop("codex", None)


@pytest.fixture
def tracer_provider():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    previous = trace.get_tracer_provider()
    trace.set_tracer_provider(provider)
    yield provider, exporter
    trace.set_tracer_provider(previous)


def _names(spans):
    return [span.name for span in spans]


def test_instrumentation_emits_lightweight_fallback_span(codex_module, tracer_provider):
    provider, exporter = tracer_provider
    config = CodexConfig(
        capture_inputs=False,
        capture_outputs=False,
        methods_to_wrap=(("codex", "Client.run"),),
    )
    instrumentor = CodexInstrumentor()
    instrumentor.instrument(config=config, tracer_provider=provider)

    payload = codex_module.Client().run("hello")

    spans = exporter.get_finished_spans()
    assert len(spans) == 1
    assert _names(spans) == ["codex.Client.run"]

    op_span = spans[0]
    assert op_span.parent is None
    assert op_span.attributes["openinference.span.kind"] == "CHAIN"
    assert op_span.attributes["llm.model_name"] == "smollm2-mock"
    assert op_span.attributes["tool.name"] == "mock_tool"
    assert "input.value" not in op_span.attributes
    assert "output.value" not in op_span.attributes
    assert "llm.invocation_parameters" not in op_span.attributes
    assert "codex.original.input" not in op_span.attributes
    assert "codex.original.output" not in op_span.attributes
    assert payload["output"] == "mock-response"

    instrumentor.uninstrument()


def test_error_sets_span_status_and_records_exception(codex_module, tracer_provider, monkeypatch):
    provider, exporter = tracer_provider

    def boom(self, prompt: str):
        raise RuntimeError(f"boom:{prompt}")

    monkeypatch.setattr(codex_module.Client, "run", boom)

    config = CodexConfig(methods_to_wrap=(("codex", "Client.run"),))
    instrumentor = CodexInstrumentor()
    instrumentor.instrument(config=config, tracer_provider=provider)

    with pytest.raises(RuntimeError):
        codex_module.Client().run("x")

    spans = exporter.get_finished_spans()
    assert len(spans) == 1
    assert spans[0].status.status_code is StatusCode.ERROR
    assert spans[0].events
    instrumentor.uninstrument()


def test_instrument_idempotent_and_uninstrument_restores(codex_module, tracer_provider):
    provider, exporter = tracer_provider
    instrumentor = CodexInstrumentor()
    original = codex_module.Client.run

    instrumentor.instrument(
        config=CodexConfig(methods_to_wrap=(("codex", "Client.run"),)),
        tracer_provider=provider,
    )
    first_wrapped = codex_module.Client.run
    instrumentor.instrument(tracer_provider=provider)
    second_wrapped = codex_module.Client.run
    assert first_wrapped is second_wrapped

    codex_module.Client().run("once")
    assert len(exporter.get_finished_spans()) == 1

    instrumentor.uninstrument()
    assert codex_module.Client.run is original


def test_capture_and_redaction_config(codex_module, tracer_provider):
    provider, exporter = tracer_provider
    instrumentor = CodexInstrumentor()
    config = CodexConfig(
        capture_inputs=True,
        capture_outputs=True,
        redact_inputs=True,
        methods_to_wrap=(("codex", "Client.run"),),
    )
    instrumentor.instrument(config=config, tracer_provider=provider)

    codex_module.Client().run("api_key=sk-12345678901234567890")
    op_span = [s for s in exporter.get_finished_spans() if s.name == "codex.Client.run"][0]
    assert "[REDACTED]" in op_span.attributes["input.value"]
    assert op_span.attributes["output.value"] == "mock-response"
    assert "[REDACTED]" in op_span.attributes["codex.original.input"]
    assert op_span.attributes["codex.original.output"] == "mock-response"

    instrumentor.uninstrument()


def test_invocation_parameters_suppressed_when_input_capture_off():
    attrs = {"invocation_parameters": {"prompt": "secret prompt"}}
    mapped = map_codex_attributes(
        "codex.Client.responses.create",
        attrs,
        CodexConfig(capture_inputs=False, preserve_original_attributes=True),
    )
    assert "llm.invocation_parameters" not in mapped
    assert "codex.original.invocation_parameters" not in mapped


def test_invocation_parameters_emitted_when_input_capture_on():
    attrs = {"invocation_parameters": {"prompt": "api_key=sk-12345678901234567890"}}
    mapped = map_codex_attributes(
        "codex.Client.responses.create",
        attrs,
        CodexConfig(capture_inputs=True, preserve_original_attributes=True, redact_inputs=True),
    )
    assert "[REDACTED]" in mapped["llm.invocation_parameters"]
    assert "[REDACTED]" in mapped["codex.original.invocation_parameters"]


def test_instance_responses_create_is_patched(codex_module, tracer_provider):
    provider, exporter = tracer_provider
    instrumentor = CodexInstrumentor()
    instrumentor.instrument(
        config=CodexConfig(methods_to_wrap=(("codex", "Client.responses.create"),)),
        tracer_provider=provider,
    )

    codex_module.Client().responses.create("hello")

    spans = exporter.get_finished_spans()
    assert _names(spans) == ["codex.Client.responses.create"]
    instrumentor.uninstrument()
