from __future__ import annotations

import subprocess

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace.status import StatusCode

from openinference.instrumentation.codex import CodexCliInstrumentor, CodexConfig


def _provider_and_exporter():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


def test_cli_instrumentor_emits_spans_for_codex(monkeypatch):
    provider, exporter = _provider_and_exporter()

    class _Result:
        returncode = 0

    def fake_run(*args, **kwargs):
        return _Result()

    monkeypatch.setattr(subprocess, "run", fake_run)
    inst = CodexCliInstrumentor()
    inst.instrument(config=CodexConfig(capture_inputs=True), tracer_provider=provider)

    subprocess.run(["codex", "exec", "hello"], capture_output=True)
    spans = exporter.get_finished_spans()
    assert [s.name for s in spans] == ["codex.cli.run"]
    assert spans[0].attributes["input.value"] == '["codex", "exec", "hello"]'

    inst.uninstrument()


def test_cli_instrumentor_non_codex_passthrough(monkeypatch):
    provider, exporter = _provider_and_exporter()

    called = {"count": 0}

    class _Result:
        returncode = 0

    def fake_run(*args, **kwargs):
        called["count"] += 1
        return _Result()

    monkeypatch.setattr(subprocess, "run", fake_run)
    inst = CodexCliInstrumentor()
    inst.instrument(tracer_provider=provider)

    subprocess.run(["python", "-V"])
    assert called["count"] == 1
    assert len(exporter.get_finished_spans()) == 0
    inst.uninstrument()


def test_cli_instrumentor_sets_error_status_on_nonzero_exit(monkeypatch):
    provider, exporter = _provider_and_exporter()

    class _Result:
        returncode = 2

    monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: _Result())
    inst = CodexCliInstrumentor()
    inst.instrument(tracer_provider=provider)

    subprocess.run(["codex", "exec", "fail"], capture_output=True)
    spans = exporter.get_finished_spans()
    for span in spans:
        assert span.status.status_code is StatusCode.ERROR
    inst.uninstrument()


def test_cli_instrumentor_malformed_string_command_passthrough(monkeypatch):
    provider, exporter = _provider_and_exporter()

    called = {"count": 0}

    class _Result:
        returncode = 0

    def fake_run(*args, **kwargs):
        called["count"] += 1
        return _Result()

    monkeypatch.setattr(subprocess, "run", fake_run)
    inst = CodexCliInstrumentor()
    inst.instrument(tracer_provider=provider)

    subprocess.run('codex "unterminated', shell=True)
    assert called["count"] == 1
    assert len(exporter.get_finished_spans()) == 0
    inst.uninstrument()
