from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class _Responses:
    def create(self, prompt: str) -> dict[str, Any]:
        return {
            "output": "mock-response",
            "prompt": prompt,
            "tool_name": "mock_tool",
            "tool_arguments": {"path": "README.md"},
            "tool_result": "ok",
            "provider": "mock-codex",
            "model": "smollm2-mock",
            "prompt_tokens": 7,
            "completion_tokens": 9,
            "total_tokens": 16,
            "codex.primitive.read": True,
            "codex.primitive.write": True,
            "codex.primitive.mcp": True,
            "codex.primitive.skill": True,
            "codex.primitive.hook": True,
            "codex.primitive.rule": True,
            "codex.primitive.tool": True,
            "codex.hooks.invoked": ["pre_tool", "post_tool"],
            "codex.skills.invoked": ["repo_navigator"],
            "codex.mcp.servers": ["filesystem", "git"],
            "codex.rules.applied": ["secure-defaults", "no-secrets"],
        }


class Client:
    def __init__(self, *_: Any, **__: Any) -> None:
        self.responses = _Responses()

    def run(self, prompt: str) -> dict[str, Any]:
        return self.responses.create(prompt)

    def create_task(self, prompt: str) -> dict[str, Any]:
        return self.responses.create(prompt)
