from __future__ import annotations

import importlib
import importlib.util
import os
from pathlib import Path

import pytest

SCRIPT_PATH = Path(__file__).resolve().parents[2] / "scripts" / "run_live_codex_smoke.py"
MOCKS_ROOT = Path(__file__).resolve().parents[1] / "mocks"


def _load_script_module():
    spec = importlib.util.spec_from_file_location("run_live_codex_smoke", SCRIPT_PATH)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.mark.integration
def test_integration_sdk_and_cli_with_mocks(monkeypatch):
    module = _load_script_module()
    monkeypatch.setenv("CODEX_LIVE_REQUIRED", "true")
    monkeypatch.setenv("PYTHONPATH", str(MOCKS_ROOT))
    monkeypatch.setenv("PATH", f"{MOCKS_ROOT / 'bin'}:{os.environ['PATH']}")
    monkeypatch.syspath_prepend(str(MOCKS_ROOT))

    assert module.run_sdk_call() is True
    assert module.run_cli_call() is True

    codex = importlib.import_module("codex")
    payload = codex.Client().run("test")
    for primitive in (
        "codex.primitive.hook",
        "codex.primitive.skill",
        "codex.primitive.mcp",
        "codex.primitive.rule",
        "codex.primitive.read",
        "codex.primitive.write",
        "codex.primitive.tool",
    ):
        assert payload[primitive] is True
