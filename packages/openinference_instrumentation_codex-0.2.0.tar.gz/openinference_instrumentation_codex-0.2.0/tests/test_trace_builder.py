from __future__ import annotations

import json
from pathlib import Path

from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
from opentelemetry.trace.status import StatusCode

from openinference.instrumentation.codex import (
    CodexAppServerEventAdapter,
    CodexCliJsonlAdapter,
    CodexConfig,
    CodexTraceBuilder,
)

FIXTURES = Path(__file__).resolve().parent / "fixtures"


def _provider_and_exporter():
    exporter = InMemorySpanExporter()
    provider = TracerProvider()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    return provider, exporter


def _span_map(spans):
    return {span.name: span for span in spans}


def _feed_cli_fixture(name: str, config: CodexConfig | None = None):
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(tracer_provider=provider, config=config)
    adapter = CodexCliJsonlAdapter(builder)
    for index, line in enumerate((FIXTURES / "cli" / name).read_text().splitlines(), start=1):
        adapter.observe_line(line, observed_at_ns=index * 1_000_000)
    builder.finish()
    return exporter.get_finished_spans()


def _feed_app_fixture(name: str, config: CodexConfig | None = None):
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(tracer_provider=provider, config=config)
    adapter = CodexAppServerEventAdapter(builder)
    payload = json.loads((FIXTURES / "app_server" / name).read_text())
    for index, notification in enumerate(payload, start=1):
        adapter.observe_notification(notification, observed_at_ns=index * 1_000_000)
    builder.finish()
    return exporter.get_finished_spans()


def test_cli_fixture_builds_one_root_turn_and_real_tool_children():
    spans = _feed_cli_fixture(
        "simple_success.jsonl",
        CodexConfig(capture_inputs=True, capture_outputs=True),
    )
    names = [span.name for span in spans]
    assert names.count("codex.session") == 1
    assert "codex.turn" in names
    assert "codex.tool.command_execution" in names
    assert "codex.file_change" in names
    assert "codex.tool.mcp" in names
    assert "codex.tool.web_search" in names

    span_by_name = _span_map(spans)
    root = span_by_name["codex.session"]
    turn = span_by_name["codex.turn"]
    command = span_by_name["codex.tool.command_execution"]
    assert turn.parent.span_id == root.context.span_id
    assert command.parent.span_id == turn.context.span_id
    assert command.end_time - command.start_time == 1_000_000
    assert root.attributes["session.id"] == "thread-cli-1"
    assert root.attributes["codex.usage.prompt_tokens"] == 10
    assert root.attributes["codex.usage.cached_input_tokens"] == 3
    assert root.attributes["codex.usage.completion_tokens"] == 4
    assert root.attributes["codex.usage.total_tokens"] == 14
    assert "llm.token_count.prompt" not in root.attributes
    assert "llm.token_count.completion" not in root.attributes
    assert "llm.token_count.total" not in root.attributes
    assert command.attributes["tool.name"] == "command_execution"
    assert root.attributes["output.value"] == "done"
    assert turn.attributes["openinference.span.kind"] == "LLM"
    assert turn.attributes["output.value"] == "done"
    assert turn.attributes["llm.output_messages.0.message.role"] == "assistant"
    assert turn.attributes["llm.output_messages.0.message.content"] == "done"


def test_cli_failure_marks_tool_turn_and_root():
    spans = _feed_cli_fixture("tool_failure.jsonl")
    span_by_name = _span_map(spans)
    assert span_by_name["codex.tool.command_execution"].status.status_code is StatusCode.ERROR
    assert span_by_name["codex.turn"].status.status_code is StatusCode.ERROR
    assert span_by_name["codex.session"].status.status_code is StatusCode.ERROR


def test_cli_redaction_is_preserved():
    spans = _feed_cli_fixture(
        "redaction.jsonl",
        CodexConfig(capture_inputs=True, capture_outputs=True, redact_inputs=True),
    )
    command = _span_map(spans)["codex.tool.command_execution"]
    assert "[REDACTED]" in command.attributes["input.value"]
    assert "[REDACTED]" in command.attributes["tool.parameters"]


def test_cli_adapter_stabilizes_implicit_turn_ids():
    spans = _feed_cli_fixture("implicit_turn_ids.jsonl")
    span_by_name = _span_map(spans)
    assert span_by_name["codex.turn"].attributes["codex.turn.id"] == "turn-1"
    assert span_by_name["codex.tool.command_execution"].parent.span_id == span_by_name[
        "codex.turn"
    ].context.span_id


def test_app_server_fixture_normalizes_richer_items_and_usage_snapshot():
    spans = _feed_app_fixture(
        "rich_turn.json",
        CodexConfig(
            capture_inputs=True,
            capture_outputs=True,
            capture_tool_outputs=True,
            capture_raw_response_events=True,
        ),
    )
    span_by_name = _span_map(spans)
    assert "codex.tool.dynamic" in span_by_name
    assert "codex.agent.subagent" in span_by_name
    assert "codex.file_change" in span_by_name
    assert "codex.tool.image_view" in span_by_name
    assert "codex.context_compaction" in span_by_name
    assert "codex.hook" in span_by_name
    assert span_by_name["codex.agent.subagent"].attributes["openinference.span.kind"] == "AGENT"
    assert span_by_name["codex.file_change"].attributes["output.value"] == "Applied patch"
    assert span_by_name["codex.session"].attributes["codex.usage.total_tokens"] == 27
    assert "llm.token_count.total" not in span_by_name["codex.session"].attributes
    assert span_by_name["codex.hook"].attributes["tool.name"] == "hook.PreToolUse"
    assert span_by_name["codex.hook"].attributes["output.value"] == (
        '[{"kind": "stdout", "text": "allowed"}]'
    )
    assert span_by_name["codex.turn"].attributes["output.value"] == "Final answer"
    assert span_by_name["codex.turn"].events[0].name == "codex.raw_response_item.completed"


def test_app_server_unknown_and_orphan_completion_are_tolerated():
    spans = _feed_app_fixture("malformed_unknown.json")
    span_by_name = _span_map(spans)
    assert "codex.tool.mcp" in span_by_name
    assert (
        span_by_name["codex.tool.mcp"].parent.span_id
        == span_by_name["codex.turn"].context.span_id
    )
    assert span_by_name["codex.session"].events


def test_app_server_completion_without_tracer_provider_is_tolerated():
    builder = CodexTraceBuilder()
    adapter = CodexAppServerEventAdapter(builder)

    adapter.observe_notification(
        {
            "method": "item/completed",
            "params": {
                "item": {
                    "id": "cmd-1",
                    "type": "commandExecution",
                    "command": "kubectl get pods",
                    "status": "completed",
                }
            },
        }
    )
    builder.finish()


def test_root_seed_attributes_flow_into_turn_llm_cost_fields():
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(
        tracer_provider=provider,
        config=CodexConfig(capture_inputs=True),
        root_attributes={
            "input": "Inspect the cluster",
            "model": "gpt-5.3-codex-spark-preview",
            "provider": "openai",
            "llm_input_messages": [{"role": "user", "content": "Inspect the cluster"}],
        },
    )
    adapter = CodexCliJsonlAdapter(builder)
    adapter.observe_line('{"type":"thread.started","thread_id":"thread-1"}')
    adapter.observe_line('{"type":"turn.started","turn_id":"turn-1","thread_id":"thread-1"}')
    builder.finish()

    span_by_name = _span_map(exporter.get_finished_spans())
    turn = span_by_name["codex.turn"]
    assert turn.attributes["input.value"] == "Inspect the cluster"
    assert turn.attributes["llm.model_name"] == "gpt-5.3-codex-spark-preview"
    assert turn.attributes["llm.provider"] == "openai"
    assert turn.attributes["llm.input_messages.0.message.role"] == "user"


def test_codexops_job_identity_is_preserved_on_root_span():
    provider, exporter = _provider_and_exporter()
    builder = CodexTraceBuilder(
        tracer_provider=provider,
        root_attributes={
            "codexops.investigation.name": "investigation-otel",
            "codexops.job.name": "investigation-otel-job",
            "codexops.result.source.name": "result-otel",
            "k8s.pod.name": "investigation-otel-job-abcde",
        },
    )
    builder.finish()

    root = _span_map(exporter.get_finished_spans())["codex.session"]
    assert root.attributes["codexops.investigation.name"] == "investigation-otel"
    assert root.attributes["codexops.job.name"] == "investigation-otel-job"
    assert root.attributes["codexops.result.source.name"] == "result-otel"
    assert root.attributes["k8s.pod.name"] == "investigation-otel-job-abcde"
