from __future__ import annotations

import io

from openinference.instrumentation.codex import proxy
from openinference.instrumentation.codex.proxy import (
    _normalize_transport,
    _parse_key_value_attributes,
    _parse_resource_attributes,
    _read_exit_status,
    _root_attributes,
    _trace_endpoint,
)


def test_traces_are_disabled_by_default(monkeypatch):
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)

    assert proxy._configure_tracer_provider() is None


def test_trace_endpoint_prefers_signal_specific_value():
    env = {
        "OTEL_EXPORTER_OTLP_ENDPOINT": "http://collector:4318",
        "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT": "http://collector:4318/custom/traces",
    }
    assert _trace_endpoint(env) == "http://collector:4318/custom/traces"


def test_trace_endpoint_derives_standard_trace_path():
    assert _trace_endpoint({"OTEL_EXPORTER_OTLP_ENDPOINT": "http://collector:4318"}) == (
        "http://collector:4318/v1/traces"
    )


def test_resource_attributes_parse_escaped_delimiters():
    attrs = _parse_resource_attributes(
        r"openinference.project.name=codexops-dev,deployment.environment.name=dev\,local,"
        r"custom.attr=hello\=world"
    )
    assert attrs == {
        "openinference.project.name": "codexops-dev",
        "deployment.environment.name": "dev,local",
        "custom.attr": "hello=world",
    }


def test_normalize_transport_rejects_unknown_values():
    try:
        _normalize_transport("grpc")
    except RuntimeError as exc:
        assert "unsupported Codex event transport: grpc" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected unsupported transport")


def test_root_attributes_read_prompt_file(tmp_path):
    prompt_file = tmp_path / "prompt.md"
    prompt_file.write_text("investigate from file", encoding="utf-8")

    attrs = _root_attributes(
        transport="cli-jsonl",
        prompt_file=str(prompt_file),
        env={"CODEX_MODEL": "gpt-5", "OPENINFERENCE_CODEX_PROVIDER": "openai"},
        extra={"codexops.test": "true"},
    )

    assert attrs["codex.emission.transport"] == "cli-jsonl"
    assert attrs["codex.observer.name"] == "codex-otel-proxy"
    assert attrs["input"] == "investigate from file"
    assert attrs["llm_input_messages"] == [{"role": "user", "content": "investigate from file"}]
    assert attrs["model"] == "gpt-5"
    assert attrs["provider"] == "openai"
    assert attrs["codexops.test"] == "true"


def test_parse_key_value_attributes_rejects_invalid_items():
    assert _parse_key_value_attributes(["a=b", "c=d=e"]) == {"a": "b", "c": "d=e"}
    try:
        _parse_key_value_attributes(["missing-separator"])
    except RuntimeError as exc:
        assert "invalid root attribute" in str(exc)
    else:  # pragma: no cover
        raise AssertionError("expected invalid root attribute")


def test_read_exit_status_defaults_to_success(tmp_path):
    assert _read_exit_status(None) == 0
    assert _read_exit_status(str(tmp_path / "missing")) == 0

    status_file = tmp_path / "status"
    status_file.write_text("17", encoding="utf-8")
    assert _read_exit_status(str(status_file)) == 17


def test_observe_stream_can_forward_cli_jsonl(monkeypatch):
    monkeypatch.delenv("OTEL_TRACES_EXPORTER", raising=False)
    stream = io.StringIO('{"type":"thread.started","thread_id":"thread-1"}\n')
    forwarded = io.StringIO()

    assert proxy.observe_stream(stream, forward_to=forwarded) == 0

    assert forwarded.getvalue() == '{"type":"thread.started","thread_id":"thread-1"}\n'
