from __future__ import annotations

import importlib
import os
import shutil
import subprocess
from typing import Any

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from openinference.instrumentation.codex import CodexInstrumentor

PROMPT = (
    "Run a compact task exercising hooks, skills, MCP, rules, read/write, and tool turns. "
    "Use deterministic output."
)


def _env(key: str, default: str) -> str:
    return os.getenv(key, default)


def _required() -> bool:
    return _env("CODEX_LIVE_REQUIRED", "false").lower() in {"1", "true", "yes", "on"}


def _fail_or_warn(message: str) -> None:
    if _required():
        raise RuntimeError(message)
    print(f"[warn] {message}")


def configure_tracing() -> None:
    endpoint = _env("PHOENIX_COLLECTOR_ENDPOINT", "http://localhost:6006/v1/traces")
    try:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    except Exception:
        _fail_or_warn("OTLP exporter not installed; tracing export disabled for smoke script.")
        return
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter(endpoint=endpoint)))
    trace.set_tracer_provider(provider)
    CodexInstrumentor().instrument(tracer_provider=provider)


def _codex_client() -> Any | None:
    try:
        module = importlib.import_module("codex")
    except Exception:
        return None
    client_cls = getattr(module, "Client", None)
    if client_cls is None:
        return None
    try:
        return client_cls(
            model=_env("CODEX_MODEL", "mock-codex"),
            base_url=_env("CODEX_BASE_URL", "http://localhost/mock"),
            api_key=_env("OPENAI_API_KEY", "local-no-auth"),
        )
    except TypeError:
        return client_cls()


def run_sdk_call() -> bool:
    client = _codex_client()
    if client is None:
        _fail_or_warn("Codex SDK not importable; skipping live SDK smoke call.")
        return False

    if hasattr(client, "run"):
        client.run(PROMPT)
        print("[ok] codex sdk client.run executed")
        return True
    if hasattr(client, "create_task"):
        client.create_task(PROMPT)
        print("[ok] codex sdk client.create_task executed")
        return True
    responses = getattr(client, "responses", None)
    if responses and hasattr(responses, "create"):
        responses.create(prompt=PROMPT)
        print("[ok] codex sdk client.responses.create executed")
        return True

    _fail_or_warn("Codex SDK found but no supported methods were available.")
    return False


def run_cli_call() -> bool:
    codex_bin = shutil.which("codex")
    if codex_bin is None:
        _fail_or_warn("Codex CLI not found in PATH; skipping live CLI smoke call.")
        return False

    cmd = [codex_bin, "exec", "--model", _env("CODEX_MODEL", "mock-codex"), PROMPT]
    env = {
        **os.environ,
        "OPENAI_BASE_URL": _env("OPENAI_BASE_URL", "http://localhost/mock"),
        "OPENAI_API_KEY": _env("OPENAI_API_KEY", "local-no-auth"),
    }
    proc = subprocess.run(cmd, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        detail = proc.stderr.strip() or proc.stdout.strip()
        _fail_or_warn(f"Codex CLI failed with exit={proc.returncode}: {detail}")
        return False
    print("[ok] codex cli exec executed")
    return True


def main() -> int:
    configure_tracing()
    sdk_ok = run_sdk_call()
    cli_ok = run_cli_call()

    if _required() and not (sdk_ok and cli_ok):
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
