from opentelemetry.sdk.trace import TracerProvider

from openinference.instrumentation.codex import CodexSpanProcessor

provider = TracerProvider()
provider.add_span_processor(CodexSpanProcessor())
print("Codex span processor registered")
