from __future__ import annotations

import subprocess

from openinference.instrumentation.codex import CodexCliJsonlAdapter, CodexTraceBuilder

builder = CodexTraceBuilder()
adapter = CodexCliJsonlAdapter(builder)

proc = subprocess.Popen(
    ["codex", "exec", "--json", "--model", "gpt-5", "Summarize this repository"],
    stdout=subprocess.PIPE,
    text=True,
)
assert proc.stdout is not None
for line in proc.stdout:
    adapter.observe_line(line)
proc.wait()
builder.finish()
