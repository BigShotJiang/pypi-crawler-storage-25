from openinference.instrumentation.codex import CodexInstrumentor

CodexInstrumentor().instrument()
print("Codex instrumentation enabled")
