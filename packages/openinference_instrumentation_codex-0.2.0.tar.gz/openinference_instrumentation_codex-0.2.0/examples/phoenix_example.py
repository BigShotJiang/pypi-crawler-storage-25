from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor

from openinference.instrumentation.codex import CodexCliJsonlAdapter, CodexTraceBuilder

provider = TracerProvider(
    resource=Resource.create(
        {
            "service.name": "codex-observer",
            "openinference.project.name": "codex-demo",
        }
    )
)
provider.add_span_processor(
    BatchSpanProcessor(OTLPSpanExporter(endpoint="http://localhost:6006/v1/traces"))
)
trace.set_tracer_provider(provider)

builder = CodexTraceBuilder(tracer_provider=provider)
adapter = CodexCliJsonlAdapter(builder)

# Feed `codex exec --json` lines to `adapter.observe_line(...)`, then close the run:
# builder.finish()
