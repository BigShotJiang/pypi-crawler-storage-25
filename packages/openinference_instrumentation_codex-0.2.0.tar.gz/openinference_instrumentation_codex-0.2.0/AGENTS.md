# openinference-instrumentation-codex Repo Guide

Always read [README.md](README.md) first.

## Boundary

- Own the runner and instrumentation package
- Treat `codexops` as an external caller of the published runner
- Treat sink behavior as external to this repo

## Where To Work

| Path | Purpose |
| --- | --- |
| `src/openinference/instrumentation/codex/` | Library and runner source |
| `tests/` | Test coverage |
| `examples/`, `scripts/` | Usage examples and helpers |
| `docs/` | Human docs |

## Workflow

- Use `uv` for dependency and test workflows
- Update docs when public surfaces or integration contracts change
- Keep fallback paths clearly marked as fallback-only
- Keep secrets and environment-specific values out of prompts and committed files

## Required Checks

- `uv run ruff check .`
- `uv run pytest`
