# Maintainer Contact

Use this private maintainer contact only for reports described in the [Security Policy Reporting a Vulnerability section](SECURITY.md#reporting-a-vulnerability) and the [Code of Conduct Reporting section](CODE_OF_CONDUCT.md#reporting).

Preferred private channel:

- Email `justin.law [@] theaicompany.org`

Fallback for initial coordination if email is unavailable:

- GitHub [@justinthelaw-oai](https://github.com/justinthelaw-oai)
