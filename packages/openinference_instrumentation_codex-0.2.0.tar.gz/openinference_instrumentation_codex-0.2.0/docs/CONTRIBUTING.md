# Contributing

Start with [README.md](../README.md), then read [AGENTS.md](../AGENTS.md).

## Pull Requests

- Keep scope narrow
- Reflect public surface and contract changes in docs
- Keep the split between this repo, `codexops`, and sink repos explicit
- Use Conventional Commit PR titles
- Squash merge so the PR title becomes the release commit
- Keep secrets and environment-specific values out of the repo

## Validation

| Change | Minimum check |
| --- | --- |
| Source change | `uv run ruff check .` |
| Behavior change | `uv run pytest` |
| Live smoke path | `docker compose -f docker-compose.phoenix.yml up --build --abort-on-container-exit --exit-code-from codex-live-smoke` |
