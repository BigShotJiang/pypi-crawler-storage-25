# openinference-instrumentation-codex Diagrams

## System

```mermaid
flowchart LR
    codex["Codex events"] --> adapter["CLI or app-server adapter"]
    adapter --> builder["CodexTraceBuilder"]
    builder --> spans["codex.session tree"]
    spans --> otlp["OTLP exporter"]
```

## Boundary Notes

| Surface | Owned by this repo | External black box |
| --- | --- | --- |
| Event normalization | CLI JSONL and app-server adapters | Codex event production |
| Trace model | `codex.session`, turns, and item spans | caller-specific parent context |
| Export | proxy wiring to the active OTel SDK exporter | sink behavior in `codexops-otel` or another collector |
| Caller integration | stable `codex-otel-proxy` CLI | orchestration in `codexops` or other callers |
