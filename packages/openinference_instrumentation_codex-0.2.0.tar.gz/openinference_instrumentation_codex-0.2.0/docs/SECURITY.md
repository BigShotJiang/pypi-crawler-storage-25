# Security Policy

## Release Status

`openinference-instrumentation-codex` does not have a stable public release yet. Treat `main` as development only until versioned releases and support windows are defined.

## Supported Versions

There is no supported-version matrix until versioned releases and support windows exist.

## Reporting a Vulnerability

Do not report security issues in public GitHub issues, pull requests, or discussions.

Report vulnerabilities privately through [docs/CONTACT.md](CONTACT.md).

Include:

- Affected commit, branch, or tag
- Impact and attacker prerequisites
- Reproduction steps or proof of concept
- Suggested mitigation or workaround

We review reports privately, assess impact, and coordinate disclosure around a fix when possible.

## Security Scope

Evaluate the project against the current repository state, especially:

- Event normalization and span-shaping behavior
- Public proxy stream handling
- OTLP exporter wiring and content-capture configuration
- Public docs linked from the [README Project Docs section](../README.md#project-docs)
