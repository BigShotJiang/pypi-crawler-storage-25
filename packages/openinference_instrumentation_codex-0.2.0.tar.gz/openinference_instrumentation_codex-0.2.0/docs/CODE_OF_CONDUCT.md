# Code of Conduct

## Standard

`openinference-instrumentation-codex` is a respectful, technically rigorous project. Participants are expected to:

- Be respectful, direct, and professional
- Critique ideas, code, and decisions without attacking people
- Assume good intent and ask for clarification when something is unclear
- Keep discussions constructive, relevant, and welcoming
- Respect different backgrounds, identities, and experience levels

## Unacceptable Behavior

The following behaviors are not acceptable in project spaces or related private communication:

- Harassment, threats, or personal attacks
- Discriminatory language or conduct
- Sexualized language or imagery
- Doxxing or sharing private information without permission
- Repeated bad-faith disruption, trolling, or intimidation
- Publishing private security reports without coordination

## Enforcement

Maintainers may edit, hide, lock, or remove content that violates this code of conduct.

Repeated or severe violations may lead to temporary or permanent restrictions from project spaces.

## Reporting

Report concerns privately through [docs/CONTACT.md](CONTACT.md).

Include:

- GitHub accounts of the reported people
- Why the behavior violates the code of conduct
- Links or screenshots when relevant
