# Changelog

## [0.2.0](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/compare/v0.1.0...v0.2.0) (2026-04-29)


### Features

* add codex otel proxy ([481848f](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/commit/481848f2829a7d4bceaf7e99c6982a4fa8726aa0))
* add rich app-server runner transport ([57813c8](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/commit/57813c855c072c326ec538998510839ecde25f6a))


### Bug Fixes

* publish with tagged pypi action ([a795017](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/commit/a7950177322c19ad0b67318e91a5216b455ece73))
* restore dedicated publish workflow ([0581bca](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/commit/0581bcac221c75400fcbccef5a859e087f137c9f))

## 0.1.0 (2026-04-27)


### Features

* add event-native codex tracing ([4e1f616](https://github.com/justinthelaw-oai/openinference-instrumentation-codex/commit/4e1f6163b00cbf5a66a72548ee35f613db896b74))

## Changelog

## Unreleased

- Added an event-native Codex trace builder with normalized CLI JSONL and app-server adapters.
- Added fixture-backed coverage for turn/item lifecycle, failures, redaction, richer item types, and usage aggregation.
- Reworked SDK and CLI monkey patches into fallback-only spans instead of synthetic session/tool trees.
- Added the public `codex-otel-proxy` observer and installable `otlp` runtime extra.
- Added wheel-install e2e coverage that validates the exported OTLP session tree from a clean install.
- Updated docs and examples for current `codex exec` usage and Phoenix project routing.
