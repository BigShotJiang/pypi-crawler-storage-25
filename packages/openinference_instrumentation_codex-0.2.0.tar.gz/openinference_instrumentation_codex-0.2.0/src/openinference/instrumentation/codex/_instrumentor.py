from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Any

from opentelemetry.instrumentation.instrumentor import BaseInstrumentor

from ._config import CodexConfig
from ._wrappers import WRAPPED_MARKER, build_wrapper


@dataclass
class _PatchedTarget:
    module_name: str
    attr_path: str
    original: Any


class CodexInstrumentor(BaseInstrumentor):
    _patched: list[_PatchedTarget]

    def __init__(self) -> None:
        super().__init__()
        self._patched = []
        self._config = CodexConfig.from_env()

    def instrumentation_dependencies(self) -> list[str]:
        return []

    def _instrument(self, **kwargs: Any) -> None:
        config = kwargs.get("config") or self._config
        tracer_provider = kwargs.get("tracer_provider")
        if not config.enabled:
            return

        for module_name, path in config.methods_to_wrap:
            self._patch_target(module_name, path, config, tracer_provider)

    def _uninstrument(self, **kwargs: Any) -> None:
        while self._patched:
            target = self._patched.pop()
            try:
                module = importlib.import_module(target.module_name)
                obj, attr = _resolve_parent(module, target.attr_path)
                current = getattr(obj, attr, None)
                if getattr(current, WRAPPED_MARKER, False):
                    setattr(obj, attr, target.original)
            except Exception:
                continue

    def _patch_target(
        self, module_name: str, path: str, config: CodexConfig, tracer_provider: Any = None
    ) -> None:
        try:
            module = importlib.import_module(module_name)
            obj, attr = _resolve_parent(module, path)
            original = getattr(obj, attr)
        except Exception:
            self._patch_dynamic_instance_target(module_name, path, config, tracer_provider)
            return

        if any(p.module_name == module_name and p.attr_path == path for p in self._patched):
            return
        if getattr(original, WRAPPED_MARKER, False):
            return

        wrapped = build_wrapper(f"{module_name}.{path}", original, config, tracer_provider)
        if wrapped is original:
            return
        setattr(obj, attr, wrapped)
        self._patched.append(
            _PatchedTarget(module_name=module_name, attr_path=path, original=original)
        )

    def _patch_dynamic_instance_target(
        self,
        module_name: str,
        path: str,
        config: CodexConfig,
        tracer_provider: Any = None,
    ) -> None:
        parts = path.split(".")
        if len(parts) < 3:
            return
        try:
            module = importlib.import_module(module_name)
            owner = getattr(module, parts[0])
            original_init = owner.__init__
        except Exception:
            return
        init_path = f"{parts[0]}.__init__"
        if any(p.module_name == module_name and p.attr_path == init_path for p in self._patched):
            return

        def _wrapped_init(instance: Any, *args: Any, **kwargs: Any) -> Any:
            result = original_init(instance, *args, **kwargs)
            try:
                parent = instance
                for part in parts[1:-1]:
                    parent = getattr(parent, part)
                attr = parts[-1]
                original = getattr(parent, attr)
                if not getattr(original, WRAPPED_MARKER, False):
                    setattr(
                        parent,
                        attr,
                        build_wrapper(f"{module_name}.{path}", original, config, tracer_provider),
                    )
            except Exception:
                return result
            return result

        owner.__init__ = _wrapped_init
        self._patched.append(
            _PatchedTarget(module_name=module_name, attr_path=init_path, original=original_init)
        )


def _resolve_parent(module: Any, dotted: str) -> tuple[Any, str]:
    parts = dotted.split(".")
    parent = module
    for part in parts[:-1]:
        parent = getattr(parent, part)
    return parent, parts[-1]


def instrument_codex(**kwargs: Any) -> CodexInstrumentor:
    instrumentor = CodexInstrumentor()
    instrumentor.instrument(**kwargs)
    return instrumentor
