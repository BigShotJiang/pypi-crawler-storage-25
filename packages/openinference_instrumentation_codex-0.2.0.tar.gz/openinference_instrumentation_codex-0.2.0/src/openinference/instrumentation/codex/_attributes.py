from __future__ import annotations

from typing import Any

from ._config import CodexConfig
from ._utils import serialize_attribute

try:
    from openinference.semconv.trace import (
        OpenInferenceMimeTypeValues,
        OpenInferenceSpanKindValues,
        SpanAttributes,
    )
except Exception:  # pragma: no cover
    class OpenInferenceSpanKindValues:  # type: ignore[no-redef]
        LLM = "LLM"
        AGENT = "AGENT"
        TOOL = "TOOL"
        CHAIN = "CHAIN"

    class OpenInferenceMimeTypeValues:  # type: ignore[no-redef]
        TEXT = "text/plain"
        JSON = "application/json"

    class SpanAttributes:  # type: ignore[no-redef]
        OPENINFERENCE_SPAN_KIND = "openinference.span.kind"
        INPUT_VALUE = "input.value"
        INPUT_MIME_TYPE = "input.mime_type"
        OUTPUT_VALUE = "output.value"
        OUTPUT_MIME_TYPE = "output.mime_type"
        LLM_MODEL_NAME = "llm.model_name"
        LLM_PROVIDER = "llm.provider"
        LLM_INVOCATION_PARAMETERS = "llm.invocation_parameters"
        LLM_INPUT_MESSAGES = "llm.input_messages"
        LLM_OUTPUT_MESSAGES = "llm.output_messages"
        LLM_TOKEN_COUNT_PROMPT = "llm.token_count.prompt"
        LLM_TOKEN_COUNT_COMPLETION = "llm.token_count.completion"
        LLM_TOKEN_COUNT_TOTAL = "llm.token_count.total"
        LLM_TOKEN_COUNT_PROMPT_DETAILS_CACHE_READ = "llm.token_count.prompt_details.cache_read"
        TOOL_NAME = "tool.name"
        TOOL_PARAMETERS = "tool.parameters"
        TOOL_ID = "tool.id"
        SESSION_ID = "session.id"
        AGENT_NAME = "agent.name"
        GRAPH_NODE_ID = "graph.node.id"
        GRAPH_NODE_NAME = "graph.node.name"
        GRAPH_NODE_PARENT_ID = "graph.node.parent_id"


OI_SPAN_KIND = SpanAttributes.OPENINFERENCE_SPAN_KIND
INPUT_VALUE = SpanAttributes.INPUT_VALUE
INPUT_MIME_TYPE = SpanAttributes.INPUT_MIME_TYPE
OUTPUT_VALUE = SpanAttributes.OUTPUT_VALUE
OUTPUT_MIME_TYPE = SpanAttributes.OUTPUT_MIME_TYPE
LLM_MODEL_NAME = SpanAttributes.LLM_MODEL_NAME
LLM_PROVIDER = SpanAttributes.LLM_PROVIDER
LLM_INVOCATION_PARAMETERS = SpanAttributes.LLM_INVOCATION_PARAMETERS
LLM_INPUT_MESSAGES = SpanAttributes.LLM_INPUT_MESSAGES
LLM_OUTPUT_MESSAGES = SpanAttributes.LLM_OUTPUT_MESSAGES
LLM_TOKEN_PROMPT = SpanAttributes.LLM_TOKEN_COUNT_PROMPT
LLM_TOKEN_COMPLETION = SpanAttributes.LLM_TOKEN_COUNT_COMPLETION
LLM_TOKEN_TOTAL = SpanAttributes.LLM_TOKEN_COUNT_TOTAL
LLM_TOKEN_CACHE_READ = SpanAttributes.LLM_TOKEN_COUNT_PROMPT_DETAILS_CACHE_READ
TOOL_NAME = SpanAttributes.TOOL_NAME
TOOL_PARAMETERS = SpanAttributes.TOOL_PARAMETERS
TOOL_ID = SpanAttributes.TOOL_ID
SESSION_ID = SpanAttributes.SESSION_ID
AGENT_NAME = SpanAttributes.AGENT_NAME
GRAPH_NODE_ID = SpanAttributes.GRAPH_NODE_ID
GRAPH_NODE_NAME = SpanAttributes.GRAPH_NODE_NAME
GRAPH_NODE_PARENT_ID = SpanAttributes.GRAPH_NODE_PARENT_ID
_INPUT_KEYS = {"input", "prompt", "codex.input", "codex.prompt"}
_INVOCATION_PARAMETER_KEYS = {"invocation_parameters", "codex.invocation_parameters"}
_INPUT_MESSAGE_KEYS = {"llm_input_messages", "codex.llm_input_messages"}
_OUTPUT_KEYS = {"output", "completion", "codex.output", "codex.completion"}
_OUTPUT_MESSAGE_KEYS = {"llm_output_messages", "codex.llm_output_messages"}
_TOOL_OUTPUT_KEYS = {"tool_result", "codex.tool.result"}
_SAFE_PASSTHROUGH_KEYS = {
    "codex.thread.id",
    "codex.turn.id",
    "codex.item.id",
    "codex.item.type",
    "codex.item.status",
    "codex.command.exit_code",
    "codex.mcp.server",
    "codex.collab.sender_thread_id",
    "codex.collab.receiver_thread_id",
    "codex.collab.new_thread_id",
    "codex.collab.agent_status",
    "codex.events.count",
    "codex.turns.count",
    "codex.items.count",
    "codex.tool_calls.count",
    "codex.command_executions.count",
    "codex.reasoning_output_tokens",
    "codex.usage.prompt_tokens",
    "codex.usage.cached_input_tokens",
    "codex.usage.completion_tokens",
    "codex.usage.total_tokens",
    "codex.emission.transport",
    "codex.observer.name",
    "codex.runner.transport",
    "codex.runner.degraded",
    "codex.runner.fallback_reason",
    "codexops.surface",
    "codexops.investigation.name",
    "codexops.investigation.namespace",
    "codexops.job.name",
    "codexops.job.namespace",
    "codexops.result.source.namespace",
    "codexops.result.source.name",
    "codexops.result.source.uid",
    "codexops.result.fingerprint",
    "codexops.codex.surface",
    "codexops.codex.model",
    "codexops.codex.reasoning_effort",
    "k8s.job.name",
    "k8s.namespace.name",
    "k8s.pod.name",
    "codex.hook.event_name",
    "codex.hook.handler_type",
    "codex.hook.execution_mode",
    "codex.hook.scope",
    "codex.hook.source_path",
    "codex.hook.status_message",
    "codex.hook.duration_ms",
}


def classify_span_kind(span_name: str, attributes: dict[str, Any]) -> str:
    explicit = attributes.get("span_kind") or attributes.get(OI_SPAN_KIND)
    if explicit is not None:
        return _enum_value(explicit)
    name = span_name.lower()
    if "tool" in name or "shell" in name or "command" in name:
        return _enum_value(OpenInferenceSpanKindValues.TOOL)
    if "session" in name or "agent" in name or "task" in name:
        return _enum_value(OpenInferenceSpanKindValues.AGENT)
    if any(k in attributes for k in ("tool_name", "codex.tool.name")):
        return _enum_value(OpenInferenceSpanKindValues.TOOL)
    return _enum_value(OpenInferenceSpanKindValues.LLM)


def map_codex_attributes(
    span_name: str,
    attributes: dict[str, Any],
    config: CodexConfig,
) -> dict[str, Any]:
    mapped: dict[str, Any] = {OI_SPAN_KIND: classify_span_kind(span_name, attributes)}

    def first(*keys: str) -> Any:
        for key in keys:
            if key in attributes and attributes[key] is not None:
                return attributes[key]
        return None

    if config.capture_inputs:
        if (val := first("input", "prompt", "codex.input", "codex.prompt")) is not None:
            mapped[INPUT_VALUE] = serialize_attribute(
                val, max_len=config.max_attribute_length, redact=config.redact_inputs
            )
            mapped[INPUT_MIME_TYPE] = _mime_type_for(val)

    if config.capture_outputs:
        if (val := first("output", "completion", "codex.output", "codex.completion")) is not None:
            mapped[OUTPUT_VALUE] = serialize_attribute(
                val, max_len=config.max_attribute_length, redact=False
            )
            mapped[OUTPUT_MIME_TYPE] = _mime_type_for(val)

    if (val := first("model", "model_name", "codex.model", "codex.model_name")) is not None:
        mapped[LLM_MODEL_NAME] = str(val)
    if (val := first("provider", "codex.provider")) is not None:
        mapped[LLM_PROVIDER] = str(val)
    if config.capture_inputs and (
        val := first("invocation_parameters", "codex.invocation_parameters")
    ) is not None:
        mapped[LLM_INVOCATION_PARAMETERS] = serialize_attribute(
            val, max_len=config.max_attribute_length, redact=config.redact_inputs
        )
    if config.capture_inputs and (
        val := first("llm_input_messages", "codex.llm_input_messages")
    ) is not None:
        _map_messages(
            mapped,
            LLM_INPUT_MESSAGES,
            val,
            config=config,
            redact=config.redact_inputs,
        )
    if config.capture_outputs and (
        val := first("llm_output_messages", "codex.llm_output_messages")
    ) is not None:
        _map_messages(
            mapped,
            LLM_OUTPUT_MESSAGES,
            val,
            config=config,
            redact=False,
        )

    token_map = {
        LLM_TOKEN_PROMPT: first("prompt_tokens", "codex.prompt_tokens"),
        LLM_TOKEN_COMPLETION: first("completion_tokens", "codex.completion_tokens"),
        LLM_TOKEN_TOTAL: first("total_tokens", "codex.total_tokens"),
        LLM_TOKEN_CACHE_READ: first("cached_input_tokens", "codex.cached_input_tokens"),
    }
    for key, value in token_map.items():
        if value is None:
            continue
        try:
            mapped[key] = int(value)
        except (TypeError, ValueError):
            pass

    if (val := first("tool_name", "codex.tool.name")) is not None:
        mapped[TOOL_NAME] = str(val)
    if (val := first("tool_id", "codex.tool.id")) is not None:
        mapped[TOOL_ID] = str(val)
    if (val := first("tool_arguments", "codex.tool.arguments")) is not None:
        mapped[TOOL_PARAMETERS] = serialize_attribute(
            val, max_len=config.max_attribute_length, redact=config.redact_inputs
        )
    if config.capture_tool_outputs and (
        val := first("tool_result", "codex.tool.result")
    ) is not None:
        mapped.setdefault(
            OUTPUT_VALUE,
            serialize_attribute(val, max_len=config.max_attribute_length, redact=False),
        )
        mapped.setdefault(OUTPUT_MIME_TYPE, _mime_type_for(val))

    passthrough = {
        SESSION_ID: first("session.id"),
        AGENT_NAME: first("agent_name", "agent.name"),
        GRAPH_NODE_ID: first("graph.node.id"),
        GRAPH_NODE_NAME: first("graph.node.name"),
        GRAPH_NODE_PARENT_ID: first("graph.node.parent_id"),
    }
    for key, value in passthrough.items():
        if value is not None:
            mapped[key] = str(value)
    for key in _SAFE_PASSTHROUGH_KEYS:
        if key in attributes and attributes[key] is not None:
            mapped[key] = attributes[key]

    if config.preserve_original_attributes:
        for key, value in attributes.items():
            if not config.capture_inputs and key in _INPUT_KEYS:
                continue
            if not config.capture_inputs and key in _INVOCATION_PARAMETER_KEYS:
                continue
            if not config.capture_inputs and key in _INPUT_MESSAGE_KEYS:
                continue
            if not config.capture_outputs and key in _OUTPUT_KEYS:
                continue
            if not config.capture_outputs and key in _OUTPUT_MESSAGE_KEYS:
                continue
            if not config.capture_tool_outputs and key in _TOOL_OUTPUT_KEYS:
                continue
            mapped.setdefault(
                f"codex.original.{key}",
                serialize_attribute(
                    value,
                    max_len=config.max_attribute_length,
                    redact=config.redact_inputs,
                ),
            )

    return mapped


def _mime_type_for(value: Any) -> str:
    if isinstance(value, (dict, list, tuple)):
        return _enum_value(OpenInferenceMimeTypeValues.JSON)
    return _enum_value(OpenInferenceMimeTypeValues.TEXT)


def _enum_value(value: Any) -> str:
    return str(getattr(value, "value", value))


def _map_messages(
    mapped: dict[str, Any],
    prefix: str,
    value: Any,
    *,
    config: CodexConfig,
    redact: bool,
) -> None:
    if not isinstance(value, (list, tuple)):
        return
    for index, message in enumerate(value):
        if not isinstance(message, dict):
            continue
        if (role := message.get("role")) is not None:
            mapped[f"{prefix}.{index}.message.role"] = str(role)
        if (content := message.get("content")) is not None:
            mapped[f"{prefix}.{index}.message.content"] = serialize_attribute(
                content,
                max_len=config.max_attribute_length,
                redact=redact,
            )
