from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, TextIO

from opentelemetry import trace
from opentelemetry.context import Context
from opentelemetry.trace import StatusCode
from opentelemetry.trace.propagation.tracecontext import TraceContextTextMapPropagator

from ._app_server_events import CodexAppServerEventAdapter
from ._cli_events import CodexCliJsonlAdapter
from ._config import CodexConfig
from ._trace_builder import CodexTraceBuilder

_TRACE_EXPORTER_NONE = "none"
_TRACE_EXPORTER_OTLP = "otlp"
_HTTP_PROTOCOLS = {"", "http/protobuf"}
_TRANSPORT_CLI_JSONL = "cli-jsonl"
_TRANSPORT_APP_SERVER = "app-server"
_SUPPORTED_TRANSPORTS = {_TRANSPORT_CLI_JSONL, _TRANSPORT_APP_SERVER}


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="codex-otel-proxy",
        description="Observe Codex event streams and export OpenInference spans over OTLP.",
    )
    parser.add_argument("--transport", choices=sorted(_SUPPORTED_TRANSPORTS), default="cli-jsonl")
    parser.add_argument("--input-file", help="Read Codex event lines from a file instead of stdin.")
    parser.add_argument("--prompt-file", help="Attach the original prompt to the root span.")
    parser.add_argument(
        "--exit-status-file",
        help="Read the Codex process exit status after the event stream reaches EOF.",
    )
    parser.add_argument(
        "--no-forward",
        action="store_true",
        help="Do not forward observed event lines to stdout.",
    )
    parser.add_argument(
        "--root-attribute",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Attach an additional string attribute to the root span.",
    )
    args = parser.parse_args(argv)

    try:
        with _open_input(args.input_file) as stream:
            return observe_stream(
                stream,
                transport=args.transport,
                forward_to=None if args.no_forward else sys.stdout,
                prompt_file=args.prompt_file,
                exit_status_file=args.exit_status_file,
                root_attributes=_parse_key_value_attributes(args.root_attribute),
            )
    except Exception as exc:
        print(f"codex-otel-proxy: {exc}", file=sys.stderr)
        return 1


def observe_stream(
    stream: TextIO,
    *,
    transport: str = _TRANSPORT_CLI_JSONL,
    forward_to: TextIO | None = sys.stdout,
    prompt_file: str | None = None,
    exit_status_file: str | None = None,
    root_attributes: Mapping[str, Any] | None = None,
) -> int:
    transport = _normalize_transport(transport)
    provider = _configure_tracer_provider()
    config = CodexConfig.from_env()
    builder = CodexTraceBuilder(
        tracer_provider=provider,
        config=config,
        root_attributes=_root_attributes(
            transport=transport,
            prompt_file=prompt_file,
            env=os.environ,
            extra=root_attributes or {},
        ),
        root_context=_extract_parent_context(os.environ),
    )
    adapter: Any
    if transport == _TRANSPORT_APP_SERVER:
        adapter = CodexAppServerEventAdapter(builder)
    else:
        adapter = CodexCliJsonlAdapter(builder)

    try:
        for line in stream:
            if forward_to is not None:
                forward_to.write(line)
                forward_to.flush()
            if transport == _TRANSPORT_APP_SERVER:
                _observe_app_server_line(adapter, line)
            else:
                adapter.observe_line(line)

        exit_status = _read_exit_status(exit_status_file)
        builder.finish(
            status=StatusCode.OK if exit_status == 0 else StatusCode.ERROR,
            message="" if exit_status == 0 else f"codex exec exited with status {exit_status}",
        )
        return 0
    finally:
        if provider is not None:
            provider.force_flush()
            provider.shutdown()


def _observe_app_server_line(adapter: CodexAppServerEventAdapter, line: str) -> None:
    try:
        payload = json.loads(line.strip())
    except json.JSONDecodeError:
        return
    if isinstance(payload, Mapping) and "method" in payload:
        adapter.observe_notification(payload)


def _root_attributes(
    *,
    transport: str,
    prompt_file: str | None,
    env: Mapping[str, str],
    extra: Mapping[str, Any],
) -> dict[str, Any]:
    attrs: dict[str, Any] = {
        "codex.emission.transport": transport,
        "codex.observer.name": "codex-otel-proxy",
    }
    attrs.update(extra)
    if prompt_file:
        try:
            prompt = Path(prompt_file).read_text(encoding="utf-8")
        except OSError as exc:
            raise RuntimeError(f"unable to read prompt file {prompt_file}: {exc}") from exc
        attrs["input"] = prompt
        attrs["llm_input_messages"] = [{"role": "user", "content": prompt}]
    if model := env.get("CODEX_MODEL", "").strip():
        attrs["model"] = model
        attrs["invocation_parameters"] = {"model": model}
    if provider := env.get("OPENINFERENCE_CODEX_PROVIDER", "").strip():
        attrs["provider"] = provider
    return attrs


def _read_exit_status(path: str | None) -> int:
    if not path:
        return 0
    try:
        raw = Path(path).read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return 0
    except OSError as exc:
        raise RuntimeError(f"unable to read Codex exit status file {path}: {exc}") from exc
    if raw == "":
        return 0
    try:
        return int(raw)
    except ValueError as exc:
        raise RuntimeError(f"invalid Codex exit status in {path}: {raw}") from exc


def _open_input(path: str | None) -> TextIO:
    if not path:
        return sys.stdin
    return Path(path).open("r", encoding="utf-8")


def _normalize_transport(raw: str) -> str:
    transport = raw.strip().lower()
    if transport not in _SUPPORTED_TRANSPORTS:
        raise RuntimeError(f"unsupported Codex event transport: {transport}")
    return transport


def _parse_key_value_attributes(items: Sequence[str]) -> dict[str, str]:
    attrs: dict[str, str] = {}
    for item in items:
        key, sep, value = item.partition("=")
        key = key.strip()
        if not sep or not key:
            raise RuntimeError(f"invalid root attribute: {item}")
        attrs[key] = value
    return attrs


def _configure_tracer_provider() -> Any:
    exporter_name = os.getenv("OTEL_TRACES_EXPORTER", _TRACE_EXPORTER_NONE).strip().lower()
    if exporter_name == _TRACE_EXPORTER_NONE:
        return None
    if exporter_name not in {"", _TRACE_EXPORTER_OTLP}:
        raise RuntimeError(
            f"unsupported OTEL_TRACES_EXPORTER for codex-otel-proxy: {exporter_name}"
        )

    protocol = _trace_protocol(os.environ)
    if protocol not in _HTTP_PROTOCOLS:
        raise RuntimeError(
            "codex-otel-proxy currently supports OTLP traces over http/protobuf only"
        )

    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    provider = TracerProvider(resource=Resource.create(_resource_attributes(os.environ)))
    provider.add_span_processor(
        BatchSpanProcessor(OTLPSpanExporter(endpoint=_trace_endpoint(os.environ)))
    )
    trace.set_tracer_provider(provider)
    return provider


def _trace_endpoint(env: Mapping[str, str]) -> str | None:
    endpoint = env.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", "").strip()
    if endpoint:
        return endpoint
    generic = env.get("OTEL_EXPORTER_OTLP_ENDPOINT", "").strip()
    if not generic:
        return None
    return generic.rstrip("/") + "/v1/traces"


def _trace_protocol(env: Mapping[str, str]) -> str:
    return (
        env.get("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL")
        or env.get("OTEL_EXPORTER_OTLP_PROTOCOL")
        or "http/protobuf"
    ).strip().lower()


def _resource_attributes(env: Mapping[str, str]) -> dict[str, str]:
    attrs = _parse_resource_attributes(env.get("OTEL_RESOURCE_ATTRIBUTES", ""))
    service_name = env.get("OTEL_SERVICE_NAME", "").strip()
    if service_name:
        attrs["service.name"] = service_name
    return attrs


def _parse_resource_attributes(raw: str) -> dict[str, str]:
    attrs: dict[str, str] = {}
    for part in _split_escaped(raw, ","):
        key, sep, value = part.partition("=")
        if not sep:
            continue
        key = key.strip()
        if key:
            attrs[key] = _unescape(value.strip())
    return attrs


def _split_escaped(raw: str, delimiter: str) -> list[str]:
    parts: list[str] = []
    current: list[str] = []
    escaped = False
    for char in raw:
        if escaped:
            current.append("\\")
            current.append(char)
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == delimiter:
            parts.append("".join(current))
            current = []
        else:
            current.append(char)
    if escaped:
        current.append("\\")
    parts.append("".join(current))
    return parts


def _unescape(value: str) -> str:
    return value.replace(r"\,", ",").replace(r"\=", "=").replace(r"\\", "\\")


def _extract_parent_context(env: Mapping[str, str]) -> Context:
    carrier = {}
    if traceparent := env.get("TRACEPARENT", "").strip():
        carrier["traceparent"] = traceparent
    if tracestate := env.get("TRACESTATE", "").strip():
        carrier["tracestate"] = tracestate
    return TraceContextTextMapPropagator().extract(carrier=carrier)


if __name__ == "__main__":
    raise SystemExit(main())
