from __future__ import annotations

import json
import re
from typing import Any

SENSITIVE_PATTERNS: tuple[re.Pattern[str], ...] = (
    re.compile(r"(sk-[A-Za-z0-9]{16,})"),
    re.compile(r"(ghp_[A-Za-z0-9]{20,})"),
    re.compile(r"(?i)(bearer\s+[A-Za-z0-9._-]+)"),
    re.compile(r"(?i)(api[_-]?key\s*[:=]\s*[^\s,;]+)"),
    re.compile(r"(?i)(password\s*[:=]\s*[^\s,;]+)"),
    re.compile(r"(-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----)"),
    re.compile(r"(AKIA[0-9A-Z]{16})"),
)


def redact_text(value: str) -> str:
    redacted = value
    for pattern in SENSITIVE_PATTERNS:
        redacted = pattern.sub("[REDACTED]", redacted)
    return redacted


def safe_json_dumps(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
    except Exception:
        return str(value)


def serialize_attribute(value: Any, *, max_len: int, redact: bool) -> str:
    if isinstance(value, str):
        result = value
    elif isinstance(value, (dict, list, tuple)):
        result = safe_json_dumps(value)
    else:
        result = str(value)
    if redact:
        result = redact_text(result)
    if max_len > 0 and len(result) > max_len:
        return f"{result[:max_len]}...<truncated>"
    return result
