from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

from ._events import (
    CodexEvent,
    CodexItem,
    CodexUsage,
    ItemCompleted,
    ItemDelta,
    ItemStarted,
    RawResponseItemCompleted,
    RuntimeErrorEvent,
    ThreadStarted,
    TurnCompleted,
    TurnStarted,
    UnknownEvent,
    UsageUpdated,
)
from ._trace_builder import CodexTraceBuilder


class CodexAppServerEventAdapter:
    def __init__(self, builder: CodexTraceBuilder) -> None:
        self._builder = builder

    def observe_notification(
        self,
        notification: Mapping[str, Any],
        *,
        observed_at_ns: int | None = None,
    ) -> None:
        self._builder.ingest(
            normalize_app_server_event(notification, observed_at_ns=observed_at_ns)
        )

    def observe_notifications(self, notifications: Iterable[Mapping[str, Any]]) -> None:
        for notification in notifications:
            self.observe_notification(notification)


def normalize_app_server_event(
    raw: Mapping[str, Any],
    *,
    observed_at_ns: int | None = None,
) -> CodexEvent:
    event_type = str(raw.get("method") or raw.get("type") or "")
    params = _mapping(raw.get("params")) or raw
    if event_type == "thread/started":
        thread = _mapping(params.get("thread"))
        return ThreadStarted(
            thread_id=str(
                params.get("threadId") or params.get("thread_id") or thread.get("id") or ""
            ),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "turn/started":
        turn = _mapping(params.get("turn"))
        return TurnStarted(
            turn_id=str(params.get("turnId") or turn.get("id") or "turn"),
            thread_id=_optional_str(params.get("threadId") or params.get("thread_id")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "turn/completed":
        turn = _mapping(params.get("turn"))
        error = _mapping(turn.get("error"))
        return TurnCompleted(
            turn_id=str(params.get("turnId") or turn.get("id") or "turn"),
            thread_id=_optional_str(params.get("threadId") or params.get("thread_id")),
            status=str(turn.get("status") or params.get("status") or "completed"),
            usage=CodexUsage.from_mapping(
                _mapping(turn.get("usage"))
                or _mapping(turn.get("tokenUsage"))
                or _mapping(params.get("usage"))
            ),
            error_message=_error_message(error),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "turn/failed":
        turn = _mapping(params.get("turn"))
        return TurnCompleted(
            turn_id=str(params.get("turnId") or turn.get("id") or "turn"),
            thread_id=_optional_str(params.get("threadId") or params.get("thread_id")),
            status="failed",
            usage=CodexUsage.from_mapping(_mapping(params.get("usage"))),
            error_message=_error_message(params.get("error") or turn.get("error")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type in {"item/started", "item/completed"}:
        item = _normalize_app_server_item(_mapping(params.get("item")), params)
        event_cls = ItemStarted if event_type == "item/started" else ItemCompleted
        return event_cls(item=item, observed_at_ns=observed_at_ns, raw=raw)
    if event_type in {"hook/started", "hook/completed"}:
        item = _normalize_hook_item(_mapping(params.get("run")), params)
        event_cls = ItemStarted if event_type == "hook/started" else ItemCompleted
        return event_cls(item=item, observed_at_ns=observed_at_ns, raw=raw)
    if event_type == "rawResponseItem/completed":
        return RawResponseItemCompleted(
            item=_mapping(params.get("item")),
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "item/agentMessage/delta":
        return ItemDelta(
            item_id=str(params.get("itemId") or ""),
            delta_kind="agent_message",
            delta=params.get("delta") or "",
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "item/commandExecution/outputDelta":
        return ItemDelta(
            item_id=str(params.get("itemId") or ""),
            delta_kind="command_output",
            delta=params.get("delta") or params.get("outputDelta") or "",
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "item/fileChange/outputDelta":
        return ItemDelta(
            item_id=str(params.get("itemId") or ""),
            delta_kind="file_change_output",
            delta=params.get("delta") or params.get("outputDelta") or "",
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "item/mcpToolCall/progress":
        return ItemDelta(
            item_id=str(params.get("itemId") or ""),
            delta_kind="mcp_progress",
            delta=params.get("progress") or params,
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type == "thread/tokenUsage/updated":
        return UsageUpdated(
            usage=CodexUsage.from_mapping(_mapping(params.get("usage"))),
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            cumulative=True,
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    if event_type in {"error", "turn/error"}:
        return RuntimeErrorEvent(
            message=_error_message(params.get("error"))
            or str(params.get("message") or "codex error"),
            thread_id=_optional_str(params.get("threadId")),
            turn_id=_optional_str(params.get("turnId")),
            item_id=_optional_str(params.get("itemId")),
            observed_at_ns=observed_at_ns,
            raw=raw,
        )
    return UnknownEvent(event_type=event_type or "unknown", observed_at_ns=observed_at_ns, raw=raw)


def _normalize_app_server_item(item: Mapping[str, Any], params: Mapping[str, Any]) -> CodexItem:
    return CodexItem(
        item_id=str(item.get("id") or ""),
        item_type=_normalize_item_type(str(item.get("type") or "")),
        status=_optional_str(item.get("status")),
        thread_id=_optional_str(params.get("threadId") or params.get("thread_id")),
        turn_id=_optional_str(params.get("turnId") or params.get("turn_id")),
        parent_item_id=_optional_str(item.get("parentItemId") or item.get("parent_item_id")),
        raw=item,
    )


def _normalize_hook_item(run: Mapping[str, Any], params: Mapping[str, Any]) -> CodexItem:
    return CodexItem(
        item_id=f"hook:{run.get('id') or ''}",
        item_type="hook",
        status=_optional_str(run.get("status")),
        thread_id=_optional_str(params.get("threadId") or params.get("thread_id")),
        turn_id=_optional_str(params.get("turnId") or params.get("turn_id")),
        raw=run,
    )


def _normalize_item_type(item_type: str) -> str:
    snake: list[str] = []
    for index, char in enumerate(item_type.strip()):
        if char.isupper() and index:
            snake.append("_")
        snake.append(char.lower())
    return "".join(snake).replace("-", "_")


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _optional_str(value: Any) -> str | None:
    if value is None or value == "":
        return None
    return str(value)


def _error_message(value: Any) -> str | None:
    if isinstance(value, Mapping):
        if value.get("message"):
            return str(value["message"])
    if value is None or value == "":
        return None
    return str(value)
