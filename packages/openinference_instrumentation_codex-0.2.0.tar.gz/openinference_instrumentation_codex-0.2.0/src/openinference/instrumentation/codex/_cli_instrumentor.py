from __future__ import annotations

import os
import shlex
import subprocess
from dataclasses import dataclass
from functools import wraps
from typing import Any

from opentelemetry import trace
from opentelemetry.instrumentation.instrumentor import BaseInstrumentor
from opentelemetry.trace import SpanKind, Status, StatusCode

from ._attributes import map_codex_attributes
from ._config import CodexConfig
from ._version import __version__

WRAPPED_MARKER = "__openinference_codex_cli_wrapped__"


@dataclass
class _PatchState:
    original_run: Any


class CodexCliInstrumentor(BaseInstrumentor):
    def __init__(self) -> None:
        super().__init__()
        self._patch_state: _PatchState | None = None
        self._config = CodexConfig.from_env()

    def instrumentation_dependencies(self) -> list[str]:
        return []

    def _instrument(self, **kwargs: Any) -> None:
        if self._patch_state is not None:
            return
        config = kwargs.get("config") or self._config
        if not config.enabled:
            return

        tracer_provider = kwargs.get("tracer_provider")
        tracer = trace.get_tracer(
            "openinference.instrumentation.codex.cli",
            __version__,
            tracer_provider,
        )
        original_run = subprocess.run
        if getattr(original_run, WRAPPED_MARKER, False):
            return

        @wraps(original_run)
        def _wrapped_run(*args: Any, **run_kwargs: Any) -> Any:
            cmd = run_kwargs.get("args", args[0] if args else None)
            if not _is_codex_command(cmd):
                return original_run(*args, **run_kwargs)

            base_attrs = _command_attributes(cmd, config)
            with tracer.start_as_current_span("codex.cli.run", kind=SpanKind.CLIENT) as run_span:
                _set_attrs(run_span, "codex.cli.run", {"span_kind": "CHAIN", **base_attrs}, config)
                try:
                    result = original_run(*args, **run_kwargs)
                except Exception as exc:
                    run_span.record_exception(exc)
                    run_span.set_status(Status(StatusCode.ERROR, str(exc)))
                    raise

                run_span.set_attribute(
                    "codex.cli.returncode",
                    int(getattr(result, "returncode", 0)),
                )
                if int(getattr(result, "returncode", 0)) != 0:
                    run_span.set_status(Status(StatusCode.ERROR, "codex CLI non-zero exit"))
                return result

        setattr(_wrapped_run, WRAPPED_MARKER, True)
        subprocess.run = _wrapped_run
        self._patch_state = _PatchState(original_run=original_run)

    def _uninstrument(self, **kwargs: Any) -> None:
        if self._patch_state is None:
            return
        subprocess.run = self._patch_state.original_run
        self._patch_state = None


def _is_codex_command(cmd: Any) -> bool:
    if not cmd:
        return False
    if isinstance(cmd, str):
        if not cmd.strip():
            return False
        try:
            parts = shlex.split(cmd)
        except ValueError:
            return False
        head = parts[0] if parts else ""
        return os.path.basename(head) == "codex"
    if isinstance(cmd, (list, tuple)) and cmd:
        return os.path.basename(str(cmd[0])) == "codex"
    return False


def _command_attributes(cmd: Any, config: CodexConfig) -> dict[str, Any]:
    attrs: dict[str, Any] = {"codex.interface": "cli"}
    if config.capture_inputs:
        if isinstance(cmd, str):
            attrs["input"] = cmd
        elif isinstance(cmd, (list, tuple)):
            attrs["input"] = [str(part) for part in cmd]
    return attrs


def _set_attrs(span: Any, span_name: str, attrs: dict[str, Any], config: CodexConfig) -> None:
    mapped = map_codex_attributes(span_name, attrs, config)
    for key, value in mapped.items():
        span.set_attribute(key, value)
