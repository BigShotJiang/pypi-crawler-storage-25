from __future__ import annotations

from typing import Any, Callable

from opentelemetry.sdk.trace import ReadableSpan, Span, SpanProcessor

from ._attributes import map_codex_attributes
from ._config import CodexConfig


class CodexSpanProcessor(SpanProcessor):
    def __init__(
        self,
        config: CodexConfig | None = None,
        predicate: Callable[[Any], bool] | None = None,
    ) -> None:
        self._config = config or CodexConfig.from_env()
        self._predicate = predicate

    def on_start(self, span: Span, parent_context: Any = None) -> None:
        if not self._config.enabled or not is_codex_span(span, self._predicate):
            return
        attributes = dict(getattr(span, "attributes", {}) or {})
        mapped = map_codex_attributes(getattr(span, "name", ""), attributes, self._config)
        for key, value in mapped.items():
            span.set_attribute(key, value)

    def on_end(self, span: ReadableSpan) -> None:
        return

    def shutdown(self) -> None:
        return

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        return True


def is_codex_span(span: Any, predicate: Callable[[Any], bool] | None = None) -> bool:
    if predicate is not None:
        try:
            return bool(predicate(span))
        except Exception:
            return False

    name = str(getattr(span, "name", "")).lower()
    if "codex" in name:
        return True

    scope = getattr(span, "instrumentation_scope", None) or getattr(
        span, "instrumentation_info", None
    )
    scope_name = str(getattr(scope, "name", "")).lower()
    if "codex" in scope_name:
        return True

    resource = getattr(span, "resource", None)
    resource_attrs = getattr(resource, "attributes", {}) if resource else {}
    if any(
        "codex" in str(k).lower() or "codex" in str(v).lower()
        for k, v in resource_attrs.items()
    ):
        return True

    attributes = dict(getattr(span, "attributes", {}) or {})
    codex_keys = (
        "codex.",
        "codex_",
        "codex",
        "tool_name",
        "prompt_tokens",
        "completion_tokens",
    )
    return any(any(token in str(key).lower() for token in codex_keys) for key in attributes)
