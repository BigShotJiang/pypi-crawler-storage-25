* EasyNewsletter version:
* Plone Version:
* Python version: 3.7
* Operating System: Linux

### Description

Describe what you were trying to get done.
Tell us what happened, what went wrong, and what you expected to happen.

### What I Did

```
Paste the command(s) you ran and the output.
If there was a crash, please include the traceback here.
```
