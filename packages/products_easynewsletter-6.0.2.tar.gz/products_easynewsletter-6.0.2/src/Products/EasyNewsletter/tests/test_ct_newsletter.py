import unittest

from plone import api
from plone.api.exc import InvalidParameterError
from plone.app.testing import TEST_USER_ID, setRoles
from plone.dexterity.interfaces import IDexterityFTI
from zope.component import createObject, queryUtility

from Products.EasyNewsletter.content.newsletter import INewsletter
from Products.EasyNewsletter.testing import PRODUCTS_EASYNEWSLETTER_INTEGRATION_TESTING


class NewsletterIntegrationTest(unittest.TestCase):
    layer = PRODUCTS_EASYNEWSLETTER_INTEGRATION_TESTING

    def setUp(self):
        """Custom shared utility setup for tests."""
        self.portal = self.layer["portal"]
        setRoles(self.portal, TEST_USER_ID, ["Manager"])

    def test_ct_newsletter_schema(self):
        fti = queryUtility(IDexterityFTI, name="Newsletter")
        schema = fti.lookupSchema()
        self.assertEqual(INewsletter, schema)

    def test_ct_newsletter_fti(self):
        fti = queryUtility(IDexterityFTI, name="Newsletter")
        self.assertTrue(fti)

    def test_ct_newsletter_factory(self):
        fti = queryUtility(IDexterityFTI, name="Newsletter")
        factory = fti.factory
        obj = createObject(factory)

        self.assertTrue(
            INewsletter.providedBy(obj),
            f"INewsletter not provided by {obj}!",
        )

    def test_ct_newsletter_adding(self):
        setRoles(self.portal, TEST_USER_ID, ["Contributor"])
        obj = api.content.create(
            container=self.portal,
            type="Newsletter",
            id="newsletter",
        )

        self.assertTrue(
            INewsletter.providedBy(obj),
            f"INewsletter not provided by {obj.id}!",
        )

        parent = obj.__parent__
        self.assertIn("newsletter", parent.objectIds())

        # check that deleting the object works too
        api.content.delete(obj=obj)
        self.assertNotIn("newsletter", parent.objectIds())

    def test_ct_newsletter_globally_addable(self):
        setRoles(self.portal, TEST_USER_ID, ["Contributor"])
        fti = queryUtility(IDexterityFTI, name="Newsletter")
        self.assertTrue(fti.global_allow, f"{fti.id} is not globally addable!")

    def test_ct_newsletter_filter_content_type_true(self):
        setRoles(self.portal, TEST_USER_ID, ["Contributor"])
        fti = queryUtility(IDexterityFTI, name="Newsletter")
        portal_types = self.portal.portal_types
        parent_id = portal_types.constructContent(
            fti.id,
            self.portal,
            "newsletter_id",
            title="Newsletter container",
        )
        parent = self.portal[parent_id]
        with self.assertRaises(InvalidParameterError):
            api.content.create(
                container=parent,
                type="Document",
                title="My Content",
            )
