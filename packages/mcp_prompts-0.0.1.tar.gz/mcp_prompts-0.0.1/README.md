# mcp-prompts

Placeholder package reserving the `mcp-prompts` namespace on PyPI.

Real release is in development. Visit https://gildara.io for status.

Contact: accounts@gildara.io
