============
BioInterface
============


.. image:: https://img.shields.io/pypi/v/biointerface.svg
        :target: https://pypi.python.org/pypi/biointerface

.. image:: https://readthedocs.org/projects/biointerface/badge/?version=latest
        :target: https://biointerface.readthedocs.io/en/latest/?version=latest
        :alt: Documentation Status

.. image:: https://gitlab.com/MorfeoRenai/biointerface/badges/main/coverage.svg
        :target: https://gitlab.com/MorfeoRenai/biointerface/-/commits/main
        :alt: Coverage Status


BioInterface is a `Biopython <https://biopython.org/>`_ based package that extracts Protein-DNA
interfaces in a PDB structures.

* Free software: MIT license
* Documentation: https://biointerface.readthedocs.io.


Get Started
-----------

This is a little tutorial on how to use the BioInterface package.

The official release is found in the Python Package Index (PyPI)

.. code-block:: console

    $ pip install biointerface

You can extract all Protein-Nucleic acids interfaces from an entire structure.

.. code-block:: python

    from Bio.PDB.PDBList import PDBList
    from Bio.PDB.MMCIFParser import MMCIFParser
    from biointerface import InterfaceBuilder

    # retrive file from PDB using Biopython
    pdbl = PDBList()
    pdbl.retrieve_assembly_file(pdb_code="1A02", assembly_num=1, pdir=".")
    # ... or else use your own

    # parse and build structure with Biopython
    parser = MMCIFParser()
    structure = parser.get_structure(
        structure_id="1A02", filename="1a02-assembly1.cif"
    )

    face_builder = InterfaceBuilder(search_radius=4.0)
    face_list = face_builder.build_interfaces(entity=structure)
    face_list

.. code-block:: console

    [<Interface chains=N:B contacts=143 search_radius=4.0>,
     <Interface chains=F:AB contacts=73 search_radius=4.0>,
     <Interface chains=J:AB contacts=59 search_radius=4.0>]

Check the official documentation for more information.


Features
--------

* Extract all Protein-DNA interfaces in a PDB entity, be it structure, model or chain;
* Get all interacting residues in a interface, from protein and nucleic acids;
* Get all interacting atoms in a interface, from protein and nucleic acids;
* Interface data as ``pandas`` DataFrame;
* Get nucleic acid binding protein;
* Get nucleic acid binding domain;
* Get all protein-bound nucleic acids;
* Get all protein-bound double stranded nucleic acids;
* Get all continous protein-bound nucleic acids.
  The minimum nucleic subsequence, which contains all protein-bound nucleotides;
* Get all continous protein-bound double strand nucleic acids.
  The minimum nucleic subsequence, which contains all protein-bound base pairs;


To Do
--------



Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
