"""Top-level package for BioInterface."""

from biointerface.core import InterfaceBuilder, Interface

__author__ = """Alessandro Pandolfi"""
__email__ = "alessandro.pandolfi@protonmail.com"
__version__ = "1.1.0"

__all__ = ["InterfaceBuilder", "Interface"]
