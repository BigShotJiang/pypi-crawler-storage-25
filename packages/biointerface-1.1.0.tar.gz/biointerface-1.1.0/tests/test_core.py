"""Test core module of biointerface."""

import pytest
from Bio.PDB.MMCIFParser import MMCIFParser
from Bio.PDB.PDBExceptions import PDBConstructionException
from Bio.PDB.Structure import Structure
from Bio.PDB.Polypeptide import Polypeptide
from PDBNucleicAcids.NucleicAcid import NucleicAcid, DoubleStrandNucleicAcid

# to be tested
from biointerface import InterfaceBuilder, Interface


def get_test_structure():
    filepath = "tests/data/gattaca.cif"
    parser = MMCIFParser(QUIET=True)
    structure = parser.get_structure("gattaca", filepath)

    return structure


def test_InterfaceBuilder():
    structure = get_test_structure()
    assert isinstance(structure, Structure)

    face_builder = InterfaceBuilder()
    face_list = face_builder.build_interfaces(entity=structure)
    face = face_list[0]

    assert isinstance(face_list, list)
    assert len(face_list) == 1
    assert isinstance(face, Interface)
    print(face)

    assert isinstance(face.get_atomic_contacts(), list)
    assert all(len(contact) == 2 for contact in face._contacts)
    assert all(contact[0] != contact[1] for contact in face._contacts)

    bd = face.get_binding_domain()
    assert isinstance(bd, Polypeptide)
    assert str(bd.get_sequence()) == "HV"

    na_list = face.get_bound_nucleic_acids()
    assert isinstance(na_list, list)
    assert isinstance(na_list[0], NucleicAcid)

    dsna_list = face.get_bound_double_strands()
    assert isinstance(dsna_list, list)
    assert isinstance(dsna_list[0], DoubleStrandNucleicAcid)


def test_get_atoms():
    structure = get_test_structure()
    assert isinstance(structure, Structure)

    face_builder = InterfaceBuilder()
    face_list = face_builder.build_interfaces(entity=structure)
    face = face_list[0]

    atoms = face.get_protein_atoms()
    assert isinstance(atoms, list)
    assert all(
        hasattr(atom, "coord") for atom in atoms
    )  # Controlla se hanno coordinate

    atoms = face.get_nucleic_acid_atoms()
    assert isinstance(atoms, list)
    assert all(
        hasattr(atom, "coord") for atom in atoms
    )  # Controlla se hanno coordinate


def test_get_residues():
    structure = get_test_structure()
    assert isinstance(structure, Structure)

    face_builder = InterfaceBuilder()
    face_list = face_builder.build_interfaces(entity=structure)
    face = face_list[0]

    residues = face.get_aminoacids()
    assert isinstance(residues, list)
    assert all(
        hasattr(residue, "get_resname") for residue in residues
    )  # Devono avere nomi di residui

    residues = face.get_nucleotides()
    assert isinstance(residues, list)
    assert all(
        hasattr(residue, "get_resname") for residue in residues
    )  # Devono avere nomi di residui


def test_as_dataframe():
    structure = get_test_structure()
    assert isinstance(structure, Structure)

    face_builder = InterfaceBuilder()
    face_list = face_builder.build_interfaces(entity=structure)
    face = face_list[0]

    df = face.as_dataframe()
    assert df is not None
    assert not df.empty
    assert set(
        ["prot_atom_name", "dna_atom_name", "euclidean_distance"]
    ).issubset(df.columns)

    # # padding is already at the start of the protein
    # bd = face.get_binding_domain(upstream_pad=1)
    # assert str(bd.get_sequence()) == "HV"

    # # padding is not yet at the end of the protein
    # bd = face.get_binding_domain(downstream_pad=1)
    # assert str(bd.get_sequence()) == "HVM"

    # # padding is finally at the end of the protein
    # bd = face.get_binding_domain(downstream_pad=2)
    # assert str(bd.get_sequence()) == "HVMS"

    # # padding is over the end of the protein
    # bd = face.get_binding_domain(downstream_pad=10)
    # assert str(bd.get_sequence()) == "HVMS"

    # # negative padding?
    # bd = face.get_binding_domain(upstream_pad=-1, downstream_pad=-1)
    # assert str(bd.get_sequence()) == ""
    # bd = face.get_binding_domain(upstream_pad=0, downstream_pad=-10)
    # assert str(bd.get_sequence()) == ""


def test_no_protein():
    structure = get_test_structure()

    # should raise an error
    with pytest.raises(PDBConstructionException):
        structure = get_test_structure()
        assert isinstance(structure, Structure)
        chain = structure[0]["A"]

        face_builder = InterfaceBuilder()
        face_builder.build_interfaces(entity=chain)


def test_no_na():
    structure = get_test_structure()

    # should raise an error
    with pytest.raises(PDBConstructionException):
        structure = get_test_structure()
        assert isinstance(structure, Structure)
        chain = structure[0]["C"]

        face_builder = InterfaceBuilder()
        face_builder.build_interfaces(entity=chain)


def test_no_contacts():
    structure = get_test_structure()
    assert isinstance(structure, Structure)

    face_builder = InterfaceBuilder(search_radius=1.0)
    face_list = face_builder.build_interfaces(entity=structure)
    assert len(face_list) == 0
