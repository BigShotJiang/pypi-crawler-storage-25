"""
Initialize migrations
"""
