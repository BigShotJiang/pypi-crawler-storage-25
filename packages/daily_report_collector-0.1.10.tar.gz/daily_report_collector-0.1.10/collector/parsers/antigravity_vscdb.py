"""Antigravity vscdb parser — extracts conversation fragments from state.vscdb."""

from __future__ import annotations

import base64
import json
import platform
import re
import sqlite3
import subprocess
from pathlib import Path


def extract_antigravity_conversations(vscdb_path: Path | None = None) -> list[dict]:
    """Extract conversation fragments from Antigravity's globalStorage/state.vscdb.

    Returns a list of dicts with keys: session_id, title, content, source_key.
    """
    if vscdb_path is None:
        home = Path.home()
        system = platform.system()
        if system == "Darwin":
            vscdb_path = home / "Library" / "Application Support" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
        elif system == "Windows":
            import os
            appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
            vscdb_path = appdata / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
        else:
            vscdb_path = home / ".config" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"

    if not vscdb_path.exists():
        return []

    conversations: list[dict] = []

    try:
        db = sqlite3.connect(f"file:{vscdb_path}?mode=ro", uri=True)

        for key in [
            "jetskiStateSync.agentManagerInitState",
            "unifiedStateSync.trajectorySummaries",
            "antigravityUnifiedStateSync.trajectorySummaries",
        ]:
            val = db.execute("SELECT value FROM ItemTable WHERE key = ?", (key,)).fetchone()
            if not val:
                continue

            raw = val[0]
            # Try base64 decode
            try:
                decoded = base64.b64decode(raw)
            except Exception:
                decoded = raw.encode("utf-8") if isinstance(raw, str) else raw

            # Try protoc decode
            try:
                result = subprocess.run(
                    ["protoc", "--decode_raw"],
                    input=decoded,
                    capture_output=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    continue
                output = result.stdout.decode("utf-8", errors="replace")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue

            # Extract session IDs
            session_ids = re.findall(
                r'1: "([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"',
                output,
            )

            # Extract all meaningful string fields
            strings = re.findall(r'\d+: "(.+?)"', output)
            fragments = []
            for s in strings:
                if len(s) < 30:
                    continue
                # Skip file:// URLs, base64 blobs, hex strings
                if s.startswith("file://") or s.startswith("http"):
                    continue
                if re.match(r'^[A-Za-z0-9+/=]{60,}$', s):
                    continue
                # Decode octal-escaped UTF-8
                try:
                    decoded_s = s.encode().decode("unicode_escape").encode("latin1").decode("utf-8")
                except Exception:
                    decoded_s = s
                if len(decoded_s) > 30:
                    fragments.append(decoded_s)

            if fragments:
                conversations.append({
                    "source_key": key,
                    "session_ids": session_ids,
                    "fragments": fragments,
                    "fragment_count": len(fragments),
                })

        db.close()
    except Exception:
        pass

    return conversations


def extract_session_workspace_map(vscdb_path: Path | None = None) -> dict[str, str]:
    """Extract session UUID → workspace folder path mapping from vscdb.

    Returns a dict like {"48924c0a-...": "quant_future", "af376bab-...": "pubchem"}.
    The workspace path is simplified to the last meaningful directory name.
    """
    if vscdb_path is None:
        home = Path.home()
        system = platform.system()
        if system == "Darwin":
            vscdb_path = home / "Library" / "Application Support" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
        elif system == "Windows":
            import os
            appdata = Path(os.environ.get("APPDATA", str(home / "AppData" / "Roaming")))
            vscdb_path = appdata / "Antigravity" / "User" / "globalStorage" / "state.vscdb"
        else:
            vscdb_path = home / ".config" / "Antigravity" / "User" / "globalStorage" / "state.vscdb"

    if not vscdb_path.exists():
        return {}

    session_map: dict[str, str] = {}
    uuid_pattern = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")

    try:
        db = sqlite3.connect(f"file:{vscdb_path}?mode=ro", uri=True, timeout=5)

        for key in [
            "antigravityUnifiedStateSync.trajectorySummaries",
            "unifiedStateSync.trajectorySummaries",
            "jetskiStateSync.agentManagerInitState",
        ]:
            val = db.execute("SELECT value FROM ItemTable WHERE key = ?", (key,)).fetchone()
            if not val:
                continue

            raw = val[0]
            try:
                decoded = base64.b64decode(raw)
            except Exception:
                decoded = raw.encode("utf-8") if isinstance(raw, str) else raw

            try:
                result = subprocess.run(
                    ["protoc", "--decode_raw"],
                    input=decoded,
                    capture_output=True,
                    timeout=10,
                )
                if result.returncode != 0:
                    continue
                output = result.stdout.decode("utf-8", errors="replace")
            except (subprocess.TimeoutExpired, FileNotFoundError):
                continue

            # Parse protobuf text output to extract session → workspace mapping
            # Structure: each top-level "1 { ... }" block has:
            #   1: "session-uuid"   (the brain session ID)
            #   2 { ... 1: "file:///path/to/workspace" ... }  (workspace URI)
            current_session = None
            for line in output.splitlines():
                stripped = line.strip()

                # Top-level session UUID
                if stripped.startswith('1: "') and uuid_pattern.search(stripped):
                    match = uuid_pattern.search(stripped)
                    if match:
                        candidate = match.group(0)
                        # Only set if at low indent level (top-level field)
                        indent = len(line) - len(line.lstrip())
                        if indent <= 4:
                            current_session = candidate

                # Workspace URI inside the session block
                if current_session and "file:///" in stripped and "/antigravity/" not in stripped:
                    uri_match = re.search(r'file:///([^"]+)', stripped)
                    if uri_match and current_session not in session_map:
                        raw_path = uri_match.group(1)
                        # Extract last meaningful directory name as project identifier
                        parts = raw_path.replace("\\", "/").rstrip("/").split("/")
                        # Skip common prefixes
                        skip = {"users", "user", "home", "desktop", "dev", "documents",
                                "python", "projects", "src", "code", "admin", "appdata",
                                "roaming", "local"}
                        meaningful = [p for p in parts if p.lower() not in skip and len(p) > 1]
                        if meaningful:
                            session_map[current_session] = meaningful[-1]

        db.close()
    except Exception:
        pass

    return session_map


def format_as_markdown(conversations: list[dict]) -> str:
    """Format extracted conversations as a readable markdown document."""
    lines = ["# Antigravity Conversation Extracts\n"]

    for conv in conversations:
        lines.append(f"## Source: {conv['source_key']}")
        if conv["session_ids"]:
            lines.append(f"Sessions: {', '.join(conv['session_ids'][:5])}")
        lines.append(f"Fragments: {conv['fragment_count']}\n")

        for i, frag in enumerate(conv["fragments"]):
            lines.append(f"### Fragment {i + 1}")
            lines.append(frag)
            lines.append("")

    return "\n".join(lines)
