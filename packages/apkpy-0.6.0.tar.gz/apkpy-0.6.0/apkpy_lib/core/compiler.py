import ast
import re
import os

from .style_parser import parse_css

def _parse_radius(style_dict):
    raw = style_dict.get('border-radius', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _parse_border_width(style_dict):
    raw = style_dict.get('border-width', '0')
    cleaned = re.sub(r'[^0-9.]', '', str(raw))
    try:
        return int(float(cleaned))
    except (ValueError, TypeError):
        return 0

def _get_style_bg(style_dict):
    return style_dict.get('background-color') or style_dict.get('backgroundcolor')

def _get_style_fg(style_dict):
    return style_dict.get('color')

def _get_style_pressed_color(style_dict):
    val = style_dict.get('pressed-color')
    return _resolve_color(val) if val else None

def _get_style_border_color(style_dict):
    val = style_dict.get('border-color')
    if val and val.lower() == 'none':
        return 'none'
    elif val:
        return _resolve_color(val)
    return None

def _get_style_focus_border_color(style_dict):
    val = style_dict.get('focus-border-color') or style_dict.get('focus-color')
    if val:
        return _resolve_color(val)
    return None

def _parse_padding(style_dict):
    raw = style_dict.get('padding')
    if not raw:
        return (5, 10, 5, 10) # top, right, bottom, left
    parts = re.findall(r'(\d+)', raw)
    if len(parts) == 1:
        v = int(parts[0])
        return (v, v, v, v)
    elif len(parts) >= 2:
        v1, v2 = int(parts[0]), int(parts[1])
        return (v1, v2, v1, v2)
    return (5, 10, 5, 10)

def _resolve_color(c):
    if not c: return "#d9d9d9"
    c_lower = c.lower()
    mapping = {
        'blue': '#0000FF', 'red': '#FF0000', 'green': '#00FF00',
        'yellow': '#FFFF00', 'black': '#000000', 'white': '#FFFFFF',
        'grey': '#808080', 'gray': '#808080', 'darkblue': '#00008B'
    }
    return mapping.get(c_lower, c)

def _generate_drawable_xml(bg_color, radius_px, border_color=None, border_width=0, pressed_color=None, focus_color=None, padding=None):
    stroke_w = border_width if border_width > 0 else 1
    
    stroke_xml = ""
    if border_color is None:
        stroke_xml = f'        <stroke android:width="{stroke_w}dp" android:color="#808080" />'
    elif border_color != 'none':
        stroke_xml = f'        <stroke android:width="{stroke_w}dp" android:color="{border_color}" />'

    if padding is None:
        padding = (5, 10, 5, 10)
    padding_xml = f'        <padding android:left="{padding[3]}dp" android:top="{padding[0]}dp" android:right="{padding[1]}dp" android:bottom="{padding[2]}dp" />'

    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        '<selector xmlns:android="http://schemas.android.com/apk/res/android">' if (pressed_color or focus_color) else '<shape xmlns:android="http://schemas.android.com/apk/res/android">',
    ]

    if pressed_color:
        lines += [
            '    <item android:state_pressed="true">',
            '        <shape>',
            f'            <solid android:color="{pressed_color}" />',
            f'            <corners android:radius="{radius_px}dp" />'
        ]
        if stroke_xml: lines.append(stroke_xml)
        lines.append(padding_xml)
        lines += [
            '        </shape>',
            '    </item>'
        ]

    if focus_color:
        f_stroke = f'        <stroke android:width="{stroke_w}dp" android:color="{focus_color}" />'
        lines += [
            '    <item android:state_focused="true">',
            '        <shape>',
            f'            <solid android:color="{bg_color}" />',
            f'            <corners android:radius="{radius_px}dp" />',
            f_stroke,
            padding_xml,
            '        </shape>',
            '    </item>'
        ]

    if pressed_color or focus_color:
        lines += [
            '    <item>',
            '        <shape>',
            f'            <solid android:color="{bg_color}" />',
            f'            <corners android:radius="{radius_px}dp" />'
        ]
        if stroke_xml: lines.append(stroke_xml)
        lines.append(padding_xml)
        lines += [
            '        </shape>',
            '    </item>',
            '</selector>'
        ]
    else:
        lines += [
            f'    <solid android:color="{bg_color}" />',
            f'    <corners android:radius="{radius_px}dp" />'
        ]
        if stroke_xml: lines.append(stroke_xml[4:])
        lines.append(padding_xml[4:])
        lines.append('</shape>')

    return "\n".join(lines)


# ─── Legacy Single-Screen Transpiler ──────────────────────────────────────────

class JavaTranspiler(ast.NodeVisitor):
    def __init__(self, styles=None):
        self.java_lines = []
        self.counter = 0
        self.input_counter = 0
        self.styles = styles or {}
        self.drawables = {}

    def visit_Call(self, node):
        # ── BUTTON ────────────────────────────────────────────────────────────
        if isinstance(node.func, ast.Name) and node.func.id == 'button':
            self.counter += 1
            button_id = None
            for kw in node.keywords:
                if kw.arg == 'id':
                    button_id = kw.value.value

            label = node.args[0].value
            var_name = f"btn{self.counter}"

            java_code  = f'\n        Button {var_name} = new Button(this);'
            java_code += f'\n        {var_name}.setText("{label}");'

            if button_id in self.styles:
                s = self.styles[button_id]
                radius = _parse_radius(s)
                if radius > 0:
                    bg = _get_style_bg(s)
                    color = _resolve_color(bg)
                    bc = _get_style_border_color(s)
                    bw = _parse_border_width(s)
                    pc = _get_style_pressed_color(s)
                    fc = _get_style_focus_border_color(s)
                    pd = _parse_padding(s)
                    drawable_name = f"{button_id}_shape"
                    self.drawables[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc, border_width=bw, pressed_color=pc, focus_color=fc, padding=pd)
                    java_code += f'\n        {var_name}.setBackgroundResource(R.drawable.{drawable_name});'
                elif 'background-color' in s or 'backgroundcolor' in s:
                    bg = _get_style_bg(s)
                    color_macro = bg.upper() if bg.lower() in ('blue', 'red', 'green', 'black', 'white', 'yellow') else 'BLUE'
                    java_code += f'\n        {var_name}.setBackgroundColor(android.graphics.Color.{color_macro});'
                    
                if 'color' in s:
                    java_code += f'\n        {var_name}.setTextColor(android.graphics.Color.WHITE);'

            java_code += f'\n        layout.addView({var_name});'
            self.java_lines.append(java_code)

        # ── INPUTS ────────────────────────────────────────────────────────────
        elif isinstance(node.func, ast.Name) and node.func.id in ('inputs', 'input_field'):
            self.input_counter += 1
            placeholder = node.args[0].value if node.args else ""
            input_id   = None
            input_type = "text"

            for kw in node.keywords:
                if kw.arg == 'id':
                    input_id = kw.value.value
                elif kw.arg == 'type':
                    input_type = kw.value.value

            var_name   = f"input{self.input_counter}"
            style_code = ""
            if input_id and input_id in self.styles:
                s = self.styles[input_id]
                radius = _parse_radius(s)
                if radius > 0:
                    bg = _get_style_bg(s)
                    color = _resolve_color(bg)
                    bc = _get_style_border_color(s)
                    bw = _parse_border_width(s)
                    pc = _get_style_pressed_color(s)
                    fc = _get_style_focus_border_color(s)
                    pd = _parse_padding(s)
                    drawable_name = f"{input_id}_shape"
                    self.drawables[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc, border_width=bw, pressed_color=pc, focus_color=fc, padding=pd)
                    style_code += f'\n        {var_name}.setBackgroundResource(R.drawable.{drawable_name});'
                elif 'background-color' in s or 'backgroundcolor' in s:
                    bg = _get_style_bg(s)
                    color_macro = bg.upper() if bg.lower() in ('blue', 'red', 'green', 'black', 'white', 'yellow') else 'BLUE'
                    style_code += f'\n        {var_name}.setBackgroundColor(android.graphics.Color.{color_macro});'
                    
                if 'color' in s:
                    style_code += f'\n        {var_name}.setTextColor(android.graphics.Color.BLACK);'

            if input_type in ("text", "password", "search"):
                java_code  = f'\n        EditText {var_name} = new EditText(this);'
                java_code += f'\n        {var_name}.setHint("{placeholder}");'
                if input_type == "password":
                    java_code += (f'\n        {var_name}.setInputType('
                                  f'android.text.InputType.TYPE_CLASS_TEXT | '
                                  f'android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);')
                else:
                    java_code += f'\n        {var_name}.setInputType(android.text.InputType.TYPE_CLASS_TEXT);'
            elif input_type == "checkbox":
                java_code  = f'\n        CheckBox {var_name} = new CheckBox(this);'
                java_code += f'\n        {var_name}.setText("{placeholder}");'
            elif input_type == "range":
                java_code  = f'\n        SeekBar {var_name} = new SeekBar(this);'
                java_code += f'\n        {var_name}.setMax(100);'
            elif input_type == "radio":
                options   = [o.strip() for o in placeholder.split("|")] if placeholder else ["Opção 1", "Opção 2"]
                java_code = f'\n        RadioGroup {var_name}Group = new RadioGroup(this);'
                for i, opt in enumerate(options):
                    rb_var = f"{var_name}_rb{i}"
                    java_code += f'\n        RadioButton {rb_var} = new RadioButton(this);'
                    java_code += f'\n        {rb_var}.setText("{opt}");'
                    java_code += f'\n        {var_name}Group.addView({rb_var});'
                java_code += f'\n        layout.addView({var_name}Group);'
                self.java_lines.append(java_code)
                self.generic_visit(node)
                return
            else:
                java_code  = f'\n        EditText {var_name} = new EditText(this);'
                java_code += f'\n        {var_name}.setHint("{placeholder}");'

            java_code += style_code
            java_code += f'\n        layout.addView({var_name});'
            self.java_lines.append(java_code)

        self.generic_visit(node)


def translate_python_to_java(python_code):
    """Traduz código Python single-screen para o corpo de uma MainActivity Java."""
    try:
        import re
        style_match = re.search(r'style\s*=\s*"""(.*?)"""', python_code, re.DOTALL)
        styles = {}
        clean_code = python_code

        if style_match:
            styles     = parse_css(style_match.group(1))
            clean_code = python_code.replace(style_match.group(0), "")

        tree = ast.parse(clean_code)
        transpiler = JavaTranspiler(styles=styles)
        transpiler.visit(tree)

        if not transpiler.java_lines:
            return "        // Nenhum componente detectado", transpiler.drawables
        return "\n".join(transpiler.java_lines), transpiler.drawables

    except Exception as e:
        return f"        // Erro na tradução: {str(e)}", {}


# ─── Multi-Screen Transpiler ──────────────────────────────────────────────────

class MultiScreenTranspiler(ast.NodeVisitor):
    """
    Analisa código Python com Screens e constrói um modelo de dados
    que depois é usado para gerar múltiplos ficheiros Java/XML.
    """

    def __init__(self, styles=None):
        self.styles = styles or {}
        # var_name (Python) -> screen_id
        self.screens = {}
        self.screen_bg_images = {}
        # screen_id -> lista de dicts de componentes
        self.screen_components = {}
        # var_name -> dict do componente (para resolver on_click_navigate)
        self.component_vars = {}
        # lista de {from_screen_id, button_py_var, to_screen_id}
        self.navigations = []
        self.start_screen_id = None
        self.functions = {}
        self.declared_permissions = []
        self.permission_callbacks = {}

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _kw(self, keywords, name, default=None):
        """Extrai o valor de um keyword argument por nome."""
        for kw in keywords:
            if kw.arg == name:
                if isinstance(kw.value, ast.Constant):
                    return kw.value.value
                elif isinstance(kw.value, ast.Name):
                    return kw.value.id  # devolve o nome da variável
        return default

    def _parse_component_call(self, comp_type, call, py_var=None):
        """
        Extrai info de uma chamada de componente e associa ao Screen correto.
        Devolve o dict do componente ou None se não tiver screen=.
        """
        screen_var = self._kw(call.keywords, 'screen')
        if screen_var is None:
            return None  # modo legado, sem Screen

        screen_id = self.screens.get(screen_var)
        if screen_id is None:
            return None

        comp = {'comp_type': comp_type, 'screen_id': screen_id, '_py_var': py_var}

        if comp_type == 'button':
            comp['text']       = call.args[0].value if call.args else ''
            comp['id']         = self._kw(call.keywords, 'id')
            comp['command']    = self._kw(call.keywords, 'command')
            comp['on_click']   = self._kw(call.keywords, 'on_click')
        elif comp_type in ('inputs', 'input_field'):
            comp['placeholder'] = call.args[0].value if call.args else ''
            comp['id']          = self._kw(call.keywords, 'id')
            comp['input_type']  = self._kw(call.keywords, 'type', 'text')
            # Suporte a password=True (sintaxe alternativa)
            for kw in call.keywords:
                if kw.arg == 'password' and isinstance(kw.value, ast.Constant) and kw.value.value:
                    comp['input_type'] = 'password'
        elif comp_type == 'label':
            comp['text'] = call.args[0].value if call.args else ''
            comp['id']   = self._kw(call.keywords, 'id')

        self.screen_components.setdefault(screen_id, []).append(comp)

        if py_var:
            self.component_vars[py_var] = comp

        return comp

    # ── Visitors ──────────────────────────────────────────────────────────────

    def _parse_statements(self, statements):
        cmds = []
        for stmt in statements:
            if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
                call = stmt.value
                func_id = getattr(call.func, 'id', getattr(call.func, 'attr', ''))
                if func_id == 'toast':
                    msg = call.args[0].value if call.args and hasattr(call.args[0], 'value') else ""
                    cmds.append({'type': 'toast', 'msg': msg})
                elif func_id == 'request':
                    perm = call.args[0].value if call.args and hasattr(call.args[0], 'value') else ""
                    callback = self._kw(call.keywords, 'on_response')
                    cmds.append({'type': 'request_permission', 'perm': perm, 'callback': callback})
                    if callback and perm:
                        self.permission_callbacks[perm] = callback
            elif isinstance(stmt, ast.If):
                test = stmt.test
                if isinstance(test, ast.Call) and getattr(test.func, 'attr', '') == 'has':
                    perm = test.args[0].value if test.args and hasattr(test.args[0], 'value') else ""
                    cmds.append({
                        'type': 'if_has_permission',
                        'perm': perm,
                        'true_body': self._parse_statements(stmt.body),
                        'false_body': self._parse_statements(stmt.orelse)
                    })
                elif isinstance(test, ast.Name):
                    cmds.append({
                        'type': 'if_var',
                        'var': test.id,
                        'true_body': self._parse_statements(stmt.body),
                        'false_body': self._parse_statements(stmt.orelse)
                    })
        return cmds

    def visit_FunctionDef(self, node):
        arg_names = [arg.arg for arg in node.args.args]
        self.functions[node.name] = {
            'args': arg_names,
            'cmds': self._parse_statements(node.body)
        }
        self.generic_visit(node)

    def visit_Assign(self, node):
        if not node.targets or not isinstance(node.targets[0], ast.Name):
            self.generic_visit(node)
            return

        var_name = node.targets[0].id
        value    = node.value

        if not isinstance(value, ast.Call):
            self.generic_visit(node)
            return

        func = value.func

        # login_screen = Screen(id="login")
        if isinstance(func, ast.Name) and func.id == 'Screen':
            screen_id = self._kw(value.keywords, 'id', var_name)
            bg_image = self._kw(value.keywords, 'background_image')
            self.screens[var_name] = screen_id
            if bg_image:
                self.screen_bg_images[screen_id] = bg_image
            self.screen_components.setdefault(screen_id, [])

        # btn = button("Entrar", screen=login_screen)
        elif isinstance(func, ast.Name) and func.id in ('button', 'inputs', 'input_field', 'label'):
            self._parse_component_call(func.id, value, py_var=var_name)

        self.generic_visit(node)

    def visit_Expr(self, node):
        if not isinstance(node.value, ast.Call):
            self.generic_visit(node)
            return

        call = node.value
        func = call.func

        # Chamadas standalone: label("...", screen=x), inputs("...", screen=x)
        if isinstance(func, ast.Name) and func.id in ('button', 'inputs', 'input_field', 'label'):
            self._parse_component_call(func.id, call)

        # apkpy.declare_permissions(...)
        elif (isinstance(func, ast.Name) and func.id == 'declare_permissions') or \
             (isinstance(func, ast.Attribute) and func.attr == 'declare_permissions'):
            if call.args and isinstance(call.args[0], ast.List):
                for elt in call.args[0].elts:
                    if hasattr(elt, 'value'):
                        self.declared_permissions.append(elt.value)

        # login_screen.on_click_navigate(button=btn_entrar, to=dashboard_screen)
        elif isinstance(func, ast.Attribute) and func.attr == 'on_click_navigate':
            from_screen_var = func.value.id if isinstance(func.value, ast.Name) else None
            button_py_var   = self._kw(call.keywords, 'button')
            to_screen_var   = self._kw(call.keywords, 'to')

            if from_screen_var and button_py_var and to_screen_var:
                from_screen_id = self.screens.get(from_screen_var)
                to_screen_id   = self.screens.get(to_screen_var)
                if from_screen_id and to_screen_id:
                    self.navigations.append({
                        'from_screen_id': from_screen_id,
                        'button_py_var':  button_py_var,
                        'to_screen_id':   to_screen_id,
                    })

        # run(start_screen=login_screen)
        elif isinstance(func, ast.Name) and func.id == 'run':
            start_var = self._kw(call.keywords, 'start_screen')
            if start_var:
                self.start_screen_id = self.screens.get(start_var)

        self.generic_visit(node)


# ─── Java / XML / Manifest generators ────────────────────────────────────────

def _generate_activity_java(screen_id, components, navigations, start_screen_id,
                             package="com.apkpy.app", functions_map=None, declared_permissions=None, permission_callbacks=None):
    """Gera o conteúdo completo de um ficheiro *Activity.java para um Screen."""

    class_name = f"Screen_{screen_id}Activity"
    functions_map = functions_map or {}
    declared_permissions = declared_permissions or []
    permission_callbacks = permission_callbacks or {}

    # Descobrir quais imports são necessários
    types = {c.get('input_type', '') for c in components if c['comp_type'] in ('inputs', 'input_field')}
    has_button    = any(c['comp_type'] == 'button' for c in components)
    has_edittext  = bool(types & {'text', 'password', 'search'})
    has_textview  = any(c['comp_type'] == 'label' for c in components)
    has_checkbox  = 'checkbox' in types
    has_seekbar   = 'range' in types
    has_radio     = 'radio' in types
    has_nav       = any(n['from_screen_id'] == screen_id for n in navigations)
    
    has_toast = False
    for comp in components:
        if comp['comp_type'] == 'button':
            cmd = comp.get('command') or comp.get('on_click')
            if cmd and cmd in functions_map and functions_map[cmd]:
                has_toast = True
                break

    imports = [
        f"import {package}.R;",
        "import android.os.Bundle;",
        "import android.view.View;",
        "import android.widget.LinearLayout;",
        "import androidx.appcompat.app.AppCompatActivity;",
        "import android.Manifest;",
        "import android.content.pm.PackageManager;",
        "import androidx.core.app.ActivityCompat;",
        "import androidx.core.content.ContextCompat;",
        "import androidx.annotation.NonNull;",
    ]
    if has_button:    imports.append("import android.widget.Button;")
    if has_edittext:  imports.append("import android.widget.EditText;")
    if has_textview:  imports.append("import android.widget.TextView;")
    if has_checkbox:  imports.append("import android.widget.CheckBox;")
    if has_seekbar:   imports.append("import android.widget.SeekBar;")
    if has_radio:
        imports += ["import android.widget.RadioGroup;", "import android.widget.RadioButton;"]
    if has_nav:       imports.append("import android.content.Intent;")
    if has_toast or functions_map: imports.append("import android.widget.Toast;")

    lines = []
    lines.append(f"package {package};")
    lines.append("")
    lines.extend(sorted(set(imports)))
    lines.append("")
    lines.append(f"public class {class_name} extends AppCompatActivity {{")
    lines.append("")
    for i, perm in enumerate(declared_permissions):
        lines.append(f"    private static final int PERMISSION_REQ_{perm} = {100 + i};")
    if declared_permissions:
        lines.append("")
        
    lines.append("    @Override")
    lines.append("    protected void onCreate(Bundle savedInstanceState) {")
    lines.append("        super.onCreate(savedInstanceState);")
    lines.append("")
    lines.append("        LinearLayout layout = new LinearLayout(this);")
    lines.append("        layout.setOrientation(LinearLayout.VERTICAL);")
    lines.append("        layout.setPadding(40, 40, 40, 40);")
    lines.append("        setContentView(layout);")
    lines.append("")

    # Contadores para nomes de variáveis Java
    btn_n = lbl_n = inp_n = 0

    for comp in components:
        ctype = comp['comp_type']

        if ctype == 'button':
            btn_n += 1
            jv = f"btn{btn_n}"
            comp['_java_var'] = jv
            lines.append(f"        Button {jv} = new Button(this);")
            lines.append(f"        {jv}.setText(\"{comp['text']}\");")
            if comp.get('_drawable'):
                lines.append(f"        {jv}.setBackgroundResource(R.drawable.{comp['_drawable']});")
            lines.append(f"        layout.addView({jv});")
            lines.append("")

        elif ctype == 'label':
            lbl_n += 1
            jv = f"lbl{lbl_n}"
            comp['_java_var'] = jv
            lines.append(f"        TextView {jv} = new TextView(this);")
            lines.append(f"        {jv}.setText(\"{comp['text']}\");")
            lines.append(f"        {jv}.setTextSize(16);")
            lines.append(f"        layout.addView({jv});")
            lines.append("")

        elif ctype in ('inputs', 'input_field'):
            inp_n += 1
            jv          = f"inp{inp_n}"
            comp['_java_var'] = jv
            itype       = comp.get('input_type', 'text')
            placeholder = comp.get('placeholder', '')

            if itype in ('text', 'password', 'search'):
                lines.append(f"        EditText {jv} = new EditText(this);")
                lines.append(f"        {jv}.setHint(\"{placeholder}\");")
                if itype == 'password':
                    lines.append(f"        {jv}.setInputType(android.text.InputType.TYPE_CLASS_TEXT "
                                 f"| android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);")
                else:
                    lines.append(f"        {jv}.setInputType(android.text.InputType.TYPE_CLASS_TEXT);")
                if comp.get('_drawable'):
                    lines.append(f"        {jv}.setBackgroundResource(R.drawable.{comp['_drawable']});")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'checkbox':
                lines.append(f"        CheckBox {jv} = new CheckBox(this);")
                lines.append(f"        {jv}.setText(\"{placeholder}\");")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'range':
                lines.append(f"        SeekBar {jv} = new SeekBar(this);")
                lines.append(f"        {jv}.setMax(100);")
                lines.append(f"        layout.addView({jv});")
                lines.append("")

            elif itype == 'radio':
                options = [o.strip() for o in placeholder.split('|')] if placeholder else ['Opção 1', 'Opção 2']
                lines.append(f"        RadioGroup {jv}Group = new RadioGroup(this);")
                for i, opt in enumerate(options):
                    rb = f"{jv}_rb{i}"
                    lines.append(f"        RadioButton {rb} = new RadioButton(this);")
                    lines.append(f"        {rb}.setText(\"{opt}\");")
                    lines.append(f"        {rb}Group.addView({rb});")
                lines.append(f"        layout.addView({jv}Group);")
                lines.append("")

    # OnClickListeners (navegação e custom functions combinados)
    for comp in components:
        if comp['comp_type'] != 'button':
            continue

        btn_py_var   = comp.get('_py_var')
        btn_java_var = comp.get('_java_var')
        cmd          = comp.get('command') or comp.get('on_click')

        nav_info = None
        for n in navigations:
            if n['from_screen_id'] == screen_id and n['button_py_var'] == btn_py_var:
                nav_info = n
                break

        func_info = functions_map.get(cmd) if cmd else None
        cmds = func_info['cmds'] if func_info else []

        if (nav_info or cmds) and btn_java_var:
            lines.append(f"        {btn_java_var}.setOnClickListener(new View.OnClickListener() {{")
            lines.append(f"            @Override")
            lines.append(f"            public void onClick(View v) {{")
            
            def _gen_cmds(cmds_list, indent):
                for c in cmds_list:
                    if isinstance(c, str):
                        lines.append(f"{indent}Toast.makeText(getApplicationContext(), \"{c}\", Toast.LENGTH_SHORT).show();")
                    elif c['type'] == 'toast':
                        lines.append(f"{indent}Toast.makeText(getApplicationContext(), \"{c['msg']}\", Toast.LENGTH_SHORT).show();")
                    elif c['type'] == 'request_permission':
                        lines.append(f"{indent}ActivityCompat.requestPermissions({class_name}.this, new String[]{{Manifest.permission.{c['perm']}}}, PERMISSION_REQ_{c['perm']});")
                    elif c['type'] == 'if_has_permission':
                        lines.append(f"{indent}if (ContextCompat.checkSelfPermission({class_name}.this, Manifest.permission.{c['perm']}) == PackageManager.PERMISSION_GRANTED) {{")
                        _gen_cmds(c['true_body'], indent + "    ")
                        lines.append(f"{indent}}} else {{")
                        _gen_cmds(c['false_body'], indent + "    ")
                        lines.append(f"{indent}}}")
                    elif c['type'] == 'if_var':
                        lines.append(f"{indent}if ({c['var']}) {{")
                        _gen_cmds(c['true_body'], indent + "    ")
                        lines.append(f"{indent}}} else {{")
                        _gen_cmds(c['false_body'], indent + "    ")
                        lines.append(f"{indent}}}")
            
            _gen_cmds(cmds, "                ")
                
            if nav_info:
                to_class = f"Screen_{nav_info['to_screen_id']}Activity"
                lines.append(f"                Intent intent = new Intent({class_name}.this, {to_class}.class);")
                lines.append(f"                startActivity(intent);")
                
            lines.append(f"            }}")
            lines.append(f"        }});")
            lines.append("")

    lines.append("    }")

    if declared_permissions:
        lines.append("")
        lines.append("    @Override")
        lines.append("    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {")
        lines.append("        super.onRequestPermissionsResult(requestCode, permissions, grantResults);")
        lines.append("        if (grantResults.length == 0) return;")
        lines.append("        boolean granted = (grantResults[0] == PackageManager.PERMISSION_GRANTED);")
        lines.append("        switch (requestCode) {")
        for perm in declared_permissions:
            if perm in permission_callbacks:
                cb = permission_callbacks[perm]
                lines.append(f"            case PERMISSION_REQ_{perm}:")
                lines.append(f"                pythonCallback_{cb}(granted);")
                lines.append(f"                break;")
        lines.append("        }")
        lines.append("    }")

    for f_name, f_info in functions_map.items():
        args_str = ", ".join([f"boolean {arg}" if arg in ('granted', 'is_granted', 'is_checked') else "Object " + arg for arg in f_info['args']])
        lines.append("")
        lines.append(f"    private void pythonCallback_{f_name}({args_str}) {{")
        def _gen_cmds_local(cmds_list, indent):
            for c in cmds_list:
                if isinstance(c, str):
                    lines.append(f"{indent}Toast.makeText(getApplicationContext(), \"{c}\", Toast.LENGTH_SHORT).show();")
                elif c['type'] == 'toast':
                    lines.append(f"{indent}Toast.makeText(getApplicationContext(), \"{c['msg']}\", Toast.LENGTH_SHORT).show();")
                elif c['type'] == 'request_permission':
                    lines.append(f"{indent}ActivityCompat.requestPermissions({class_name}.this, new String[]{{Manifest.permission.{c['perm']}}}, PERMISSION_REQ_{c['perm']});")
                elif c['type'] == 'if_has_permission':
                    lines.append(f"{indent}if (ContextCompat.checkSelfPermission({class_name}.this, Manifest.permission.{c['perm']}) == PackageManager.PERMISSION_GRANTED) {{")
                    _gen_cmds_local(c['true_body'], indent + "    ")
                    lines.append(f"{indent}}} else {{")
                    _gen_cmds_local(c['false_body'], indent + "    ")
                    lines.append(f"{indent}}}")
                elif c['type'] == 'if_var':
                    lines.append(f"{indent}if ({c['var']}) {{")
                    _gen_cmds_local(c['true_body'], indent + "    ")
                    lines.append(f"{indent}}} else {{")
                    _gen_cmds_local(c['false_body'], indent + "    ")
                    lines.append(f"{indent}}}")
        _gen_cmds_local(f_info['cmds'], "        ")
        lines.append("    }")

    lines.append("}")
    return "\n".join(lines)


def _generate_layout_xml(screen_id, components, has_bg=False, styles=None):
    """Gera o conteúdo de um ficheiro activity_screen_<id>.xml."""
    styles = styles or {}
    s = styles.get(screen_id, {})
    
    gap_raw = s.get('gap', '0')
    gap_match = re.search(r'(\d+)', str(gap_raw))
    gap = int(gap_match.group(1)) if gap_match else 0
    
    flex_dir = s.get('flex-direction', 'column')
    orientation = 'horizontal' if flex_dir == 'row' else 'vertical'
    
    lines = ['<?xml version="1.0" encoding="utf-8"?>']

    if has_bg:
        lines += [
            '<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"',
            '    android:layout_width="match_parent"',
            '    android:layout_height="match_parent">',
            f'    <ImageView',
            f'        android:layout_width="match_parent"',
            f'        android:layout_height="match_parent"',
            f'        android:src="@drawable/screen_{screen_id}_bg"',
            f'        android:scaleType="centerCrop" />',
            f'    <LinearLayout',
            f'        android:layout_width="match_parent"',
            f'        android:layout_height="match_parent"',
            f'        android:orientation="{orientation}"',
            f'        android:padding="16dp">',
            '',
        ]
    else:
        lines += [
            f'<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"',
            f'    android:layout_width="match_parent"',
            f'    android:layout_height="match_parent"',
            f'    android:orientation="{orientation}"',
            f'    android:padding="16dp">',
            '',
        ]

    lbl_n = btn_n = inp_n = 0
    first = True

    for comp in components:
        ctype = comp['comp_type']
        
        spacing = ''
        if not first and gap > 0:
            if orientation == 'vertical':
                spacing = f'\n        android:layout_marginTop="{gap}dp"'
            else:
                spacing = f'\n        android:layout_marginLeft="{gap}dp"'
        first = False

        if ctype == 'label':
            lbl_n += 1
            lines += [
                f'    <TextView',
                f'        android:id="@+id/lbl{lbl_n}"',
                f'        android:layout_width="match_parent"',
                f'        android:layout_height="wrap_content"{spacing}',
                f'        android:text="{comp["text"]}"',
                f'        android:textSize="16sp" />',
                '',
            ]

        elif ctype == 'button':
            btn_n += 1
            attr_bg = f'\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
            lines += [
                f'    <Button',
                f'        android:id="@+id/btn{btn_n}"',
                f'        android:layout_width="match_parent"',
                f'        android:layout_height="wrap_content"{spacing}',
                f'        android:text="{comp["text"]}"{attr_bg} />',
                '',
            ]

        elif ctype in ('inputs', 'input_field'):
            inp_n += 1
            itype       = comp.get('input_type', 'text')
            placeholder = comp.get('placeholder', '')

            if itype in ('text', 'search'):
                attr_bg = f'\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
                lines += [
                    f'    <EditText',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"{spacing}',
                    f'        android:hint="{placeholder}"{attr_bg} />',
                    '',
                ]
            elif itype == 'password':
                attr_bg = f'\n        android:background="@drawable/{comp["_drawable"]}"' if comp.get('_drawable') else ''
                lines += [
                    f'    <EditText',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"{spacing}',
                    f'        android:hint="{placeholder}"',
                    f'        android:inputType="textPassword"{attr_bg} />',
                    '',
                ]
            elif itype == 'checkbox':
                lines += [
                    f'    <CheckBox',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"{spacing}',
                    f'        android:text="{placeholder}" />',
                    '',
                ]
            elif itype == 'range':
                lines += [
                    f'    <SeekBar',
                    f'        android:id="@+id/inp{inp_n}"',
                    f'        android:layout_width="match_parent"',
                    f'        android:layout_height="wrap_content"{spacing}',
                    f'        android:max="100" />',
                    '',
                ]
            elif itype == 'radio':
                options = [o.strip() for o in placeholder.split('|')] if placeholder else ['Opção 1', 'Opção 2']
                lines.append(f'    <RadioGroup')
                lines.append(f'        android:id="@+id/inp{inp_n}Group"')
                lines.append(f'        android:layout_width="match_parent"')
                lines.append(f'        android:layout_height="wrap_content"{spacing}>')
                for i, opt in enumerate(options):
                    lines += [
                        f'        <RadioButton',
                        f'            android:id="@+id/inp{inp_n}_rb{i}"',
                        f'            android:layout_width="wrap_content"',
                        f'            android:layout_height="wrap_content"',
                        f'            android:text="{opt}" />',
                    ]
                lines += ['    </RadioGroup>', '']

    if has_bg:
        lines.append('    </LinearLayout>')
        lines.append('</RelativeLayout>')
    else:
        lines.append('</LinearLayout>')
    return "\n".join(lines)


def _generate_manifest(screen_ids, start_screen_id, package="com.apkpy.app", declared_permissions=None):
    """Gera o conteúdo do AndroidManifest.xml com todas as Activities e permissões."""
    declared_permissions = declared_permissions or []
    lines = [
        '<?xml version="1.0" encoding="utf-8"?>',
        f'<manifest xmlns:android="http://schemas.android.com/apk/res/android"',
        f'    package="{package}">',
        '',
    ]
    
    for perm in declared_permissions:
        lines.append(f'    <uses-permission android:name="android.permission.{perm}" />')
    if declared_permissions:
        lines.append('')

    lines += [
        '    <application',
        '        android:allowBackup="true"',
        '        android:label="ApkPy App"',
        '        android:supportsRtl="true"',
        '        android:theme="@style/Theme.AppCompat.Light.DarkActionBar">',
        '',
    ]

    for sid in screen_ids:
        class_name = f"Screen_{sid}Activity"
        if sid == start_screen_id:
            lines += [
                f'        <activity android:name=".{class_name}" android:exported="true">',
                f'            <intent-filter>',
                f'                <action android:name="android.intent.action.MAIN" />',
                f'                <category android:name="android.intent.category.LAUNCHER" />',
                f'            </intent-filter>',
                f'        </activity>',
                '',
            ]
        else:
            lines.append(f'        <activity android:name=".{class_name}" />')
            lines.append('')

    lines += ['    </application>', '', '</manifest>']
    return "\n".join(lines)


# ─── Public multi-screen entry point ─────────────────────────────────────────

def translate_python_to_android(python_code, package="com.apkpy.app"):
    """
    Analisa código Python com múltiplos Screens e devolve um dicionário
    com todos os ficheiros gerados:

        {
          "java/Screen_loginActivity.java":     "...",
          "java/Screen_dashboardActivity.java": "...",
          "res/layout/activity_screen_login.xml": "...",
          "res/layout/activity_screen_dashboard.xml": "...",
          "AndroidManifest.xml": "...",
        }

    Retorna None se não encontrar nenhum Screen no código.
    """
    try:
        # Remover bloco style = \"\"\" ... \"\"\" antes de parsear o AST
        style_match = re.search(r'style\s*=\s*"""(.*?)"""', python_code, re.DOTALL)
        styles     = {}
        clean_code = python_code
        if style_match:
            styles     = parse_css(style_match.group(1))
            clean_code = python_code.replace(style_match.group(0), "")

        tree        = ast.parse(clean_code)
        transpiler  = MultiScreenTranspiler(styles=styles)
        transpiler.visit(tree)

        if not transpiler.screens:
            return None  # sem Screens → modo legado

        screen_ids      = list(transpiler.screens.values())
        start_screen_id = transpiler.start_screen_id or screen_ids[0]
        output_files    = {}

        for sid in screen_ids:
            components = transpiler.screen_components.get(sid, [])
            
            for comp in components:
                comp_id = comp.get('id')
                if comp_id and comp_id in styles:
                    radius = _parse_radius(styles[comp_id])
                    if radius > 0:
                        bg = _get_style_bg(styles[comp_id])
                        color = _resolve_color(bg)
                        bc = _get_style_border_color(styles[comp_id])
                        bw = _parse_border_width(styles[comp_id])
                        pc = _get_style_pressed_color(styles[comp_id])
                        fc = _get_style_focus_border_color(styles[comp_id])
                        pd = _parse_padding(styles[comp_id])
                        drawable_name = f"{comp_id}_shape"
                        comp['_drawable'] = drawable_name
                        output_files[f"res/drawable/{drawable_name}.xml"] = _generate_drawable_xml(color, radius, border_color=bc, border_width=bw, pressed_color=pc, focus_color=fc, padding=pd)

            # Java Activity
            java_content = _generate_activity_java(
                sid, components, transpiler.navigations, start_screen_id, package, transpiler.functions, transpiler.declared_permissions, transpiler.permission_callbacks
            )
            output_files[f"java/Screen_{sid}Activity.java"] = java_content

            # XML Layout
            bg_image = transpiler.screen_bg_images.get(sid)
            xml_content = _generate_layout_xml(sid, components, bool(bg_image), styles)
            output_files[f"res/layout/activity_screen_{sid}.xml"] = xml_content

            if bg_image:
                ext = bg_image.split('.')[-1]
                output_files[f"res/drawable/screen_{sid}_bg.{ext}"] = ("COPY_FILE", bg_image)

        # AndroidManifest
        output_files["AndroidManifest.xml"] = _generate_manifest(
            screen_ids, start_screen_id, package, transpiler.declared_permissions
        )

        return output_files

    except Exception as e:
        return {"error.txt": f"Erro na tradução multi-screen: {str(e)}"}