import click
import os
import zipfile
import shutil

from .core.compiler import translate_python_to_java, translate_python_to_android

def generate_gradle_files(base_path, package_name, project_name):
    """
    Generates fundamental Gradle configuration files for an Android project.
    """
    app_dir = os.path.join(base_path, "app")
    os.makedirs(app_dir, exist_ok=True)
    
    settings_gradle_content = f"""pluginManagement {{
    repositories {{
        google()
        mavenCentral()
        gradlePluginPortal()
    }}
}}
dependencyResolutionManagement {{
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {{
        google()
        mavenCentral()
    }}
}}
rootProject.name = "{project_name}"
include ':app'
"""
    settings_path = os.path.join(base_path, "settings.gradle")
    with open(settings_path, "w", encoding="utf-8") as f:
        f.write(settings_gradle_content)

    root_build_gradle_content = """plugins {
    id 'com.android.application' version '8.2.0' apply false
}
"""
    root_build_path = os.path.join(base_path, "build.gradle")
    with open(root_build_path, "w", encoding="utf-8") as f:
        f.write(root_build_gradle_content)

    app_build_gradle_content = f"""plugins {{
    id 'com.android.application'
}}

android {{
    namespace '{package_name}'
    compileSdk 34

    defaultConfig {{
        applicationId "{package_name}"
        minSdk 24
        targetSdk 34
        versionCode 1
        versionName "1.0"
    }}

    compileOptions {{
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }}
}}

dependencies {{
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
}}
"""
    app_build_path = os.path.join(app_dir, "build.gradle")
    with open(app_build_path, "w", encoding="utf-8") as f:
        f.write(app_build_gradle_content)

    # gradle.properties — required for AndroidX dependencies to work
    gradle_properties_content = """android.useAndroidX=true
android.enableJetifier=true
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
"""
    gradle_properties_path = os.path.join(base_path, "gradle.properties")
    with open(gradle_properties_path, "w", encoding="utf-8") as f:
        f.write(gradle_properties_content)

    # gradle/wrapper/gradle-wrapper.properties — pins Gradle 8.6 (compatible with AGP 8.2.0)
    # Gradle 9.x is INCOMPATIBLE with AGP 8.2.0 and causes the "cannot mutate resolved configuration" error
    wrapper_dir = os.path.join(base_path, "gradle", "wrapper")
    os.makedirs(wrapper_dir, exist_ok=True)
    gradle_wrapper_content = """distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.6-bin.zip
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
"""
    wrapper_path = os.path.join(wrapper_dir, "gradle-wrapper.properties")
    with open(wrapper_path, "w", encoding="utf-8") as f:
        f.write(gradle_wrapper_content)


@click.group()
def main():
    """APKPy: Transform Python into Android Projects (APK)"""
    pass


@main.command()
@click.argument('name')
def start(name):
    """Creates a new project: apkpy start my_project"""
    click.echo(f"Creating project: {name}...")

    current_dir  = os.getcwd()
    project_path = os.path.join(current_dir, name)

    if not os.path.exists(project_path):
        os.makedirs(project_path)
        with open(os.path.join(project_path, "writehere.py"), "w") as f:
            f.write(
                "from apkpy_lib.ui import Screen, button, label, inputs, run\n\n"
                "# --- Start Screen ---\n"
                "home = Screen(id=\"home\")\n"
                "label(\"Hello, ApkPy!\", screen=home)\n"
                "button(\"Continue\", screen=home)\n\n"
                "run(start_screen=home)\n"
            )
        click.echo(f"Success! Enter the '{name}' folder and edit writehere.py")
    else:
        click.echo("Error: This folder already exists.")


@main.command()
def build():
    """Compiles the code and generates a ZIP ready for Android Studio"""
    file_path    = "writehere.py"
    template_path = os.path.join(os.path.dirname(__file__), "templates/android_project")
    build_dir    = "build_temp"

    if not os.path.exists(file_path):
        click.echo("Error: writehere.py not found.")
        return

    with open(file_path, "r", encoding="utf-8") as f:
        python_code = f.read()

    # ── Tenta o modo Multi-Screen primeiro ────────────────────────────────────
    multi_files = translate_python_to_android(python_code)

    if multi_files and "error.txt" not in multi_files:
        click.echo("📱  Multi-Screen Mode detected — generating separate Activities...")

        if os.path.exists(build_dir):
            shutil.rmtree(build_dir)
        shutil.copytree(template_path, build_dir)

        java_dir     = os.path.join(build_dir, "app/src/main/java/com/apkpy/app")
        layout_dir   = os.path.join(build_dir, "app/src/main/res/layout")
        drawable_dir = os.path.join(build_dir, "app/src/main/res/drawable")
        os.makedirs(java_dir,   exist_ok=True)
        os.makedirs(layout_dir, exist_ok=True)
        os.makedirs(drawable_dir, exist_ok=True)

        for rel_path, content in multi_files.items():
            if rel_path.startswith("java/"):
                out = os.path.join(java_dir, os.path.basename(rel_path))
            elif rel_path.startswith("res/layout/"):
                out = os.path.join(layout_dir, os.path.basename(rel_path))
            elif rel_path.startswith("res/drawable/"):
                out = os.path.join(drawable_dir, os.path.basename(rel_path))
            elif rel_path == "AndroidManifest.xml":
                out = os.path.join(build_dir, "app/src/main/AndroidManifest.xml")
            else:
                out = os.path.join(build_dir, rel_path)

            if isinstance(content, tuple) and content[0] == "COPY_FILE":
                source_path = content[1]
                if os.path.exists(source_path):
                    shutil.copyfile(source_path, out)
                    click.echo(f"   🖼️  {os.path.basename(out)} (copied from {source_path})")
                else:
                    click.echo(f"   ⚠️  Warning: Image not found: {source_path}")
            else:
                with open(out, "w", encoding="utf-8") as f:
                    f.write(content)
                click.echo(f"   ✅  {os.path.basename(out)}")

    else:
        # ── Fallback: Single-Screen (MainActivity) ────────────────────────────
        click.echo("📄  Single-Screen Mode — generating MainActivity...")

        java_code, drawables = translate_python_to_java(python_code)

        if os.path.exists(build_dir):
            shutil.rmtree(build_dir)
        shutil.copytree(template_path, build_dir)

        drawable_dir = os.path.join(build_dir, "app/src/main/res/drawable")
        if drawables:
            os.makedirs(drawable_dir, exist_ok=True)
            for path, content in drawables.items():
                out = os.path.join(build_dir, "app/src/main", path)
                with open(out, "w", encoding="utf-8") as f:
                    f.write(content)
                click.echo(f"   🎨  {os.path.basename(out)}")

        main_activity_path = os.path.join(
            build_dir,
            "app/src/main/java/com/exemplo/MainActivity.java"
        )
        with open(main_activity_path, "r") as f:
            content = f.read()

        new_content = content.replace("// INJECT_CODE_HERE", java_code)

        with open(main_activity_path, "w") as f:
            f.write(new_content)

    # ── Generate ZIP final ───────────────────────────────────────────────────────
    generate_gradle_files(build_dir, "com.apkpy.app", "my_app_android")
    shutil.make_archive("my_app_android", 'zip', build_dir)
    shutil.rmtree(build_dir)

    click.echo("\n🚀  Success! 'my_app_android.zip' file generated.")
    click.echo("     Now just extract and open it in Android Studio.")