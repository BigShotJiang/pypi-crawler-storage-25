# MCP Servers Guide

Простой гайд по 4 MCP-серверам, которые уже собраны и опубликованы.

Для кого это:

- для обычного пользователя Claude Desktop
- для тех, кто не хочет разбираться в куче файлов
- для тех, кому нужен самый простой способ запустить сервер

---

## Что у тебя уже есть

### 1. Nano Banana 2 Polza MCP

Что делает:

- генерирует изображения через Nano Banana 2 / Polza.ai
- умеет image-to-image
- умеет работать с файлами и сохранением результатов
- подходит для генерации картинок, концептов, превью, визуалов

Когда нужен:

- если хочешь генерировать картинки внутри Claude
- если хочешь делать image-to-image
- если нужен отдельный MCP именно под изображения

Репозиторий:

- https://github.com/ivanantigravity-lgtm/nanobanana-2-polzaia-mcp-server

PyPI:

- https://pypi.org/project/nanobanana-2-polzaia-mcp-server/

MCP Registry name:

- `io.github.ivanantigravity-lgtm/nanobanana-2-polzaia-mcp-server`

---

### 2. Seedance Polza MCP

Что делает:

- запускает генерацию видео через Seedance / Polza Media API
- получает статус генерации
- умеет ждать завершения

Когда нужен:

- если хочешь text-to-video
- если хочешь image-to-video
- если хочешь управлять видео-генерацией из Claude

Репозиторий:

- https://github.com/ivanantigravity-lgtm/seedance-polza-mcp-server

PyPI:

- https://pypi.org/project/seedance-polza-mcp-server/

MCP Registry name:

- `io.github.ivanantigravity-lgtm/seedance-polza-mcp-server`

---

### 3. Perplexity Polza MCP

Что делает:

- даёт доступ к моделям Perplexity через Polza.ai
- умеет обычные запросы
- умеет более глубокий ресерч
- умеет показать доступные Perplexity-модели

Когда нужен:

- если хочешь быстрый поиск и ответы
- если хочешь ресерч по теме
- если нужен Perplexity внутри Claude

Репозиторий:

- https://github.com/ivanantigravity-lgtm/perplexity-polza-mcp-server

PyPI:

- https://pypi.org/project/perplexity-polza-mcp-server/

MCP Registry name:

- `io.github.ivanantigravity-lgtm/perplexity-polza-mcp-server`

---

### 4. Model Council MCP

Что делает:

- отправляет один и тот же вопрос сразу в 3 модели
- есть 2 режима:
  - `china`
  - `usa`
- Claude потом сам читает 3 ответа и делает финальную выжимку

Когда нужен:

- если хочешь сравнивать ответы моделей
- если хочешь делать контент про “китайцы vs американцы”
- если нужна не одна версия ответа, а 3 короткие перспективы

Репозиторий:

- https://github.com/ivanantigravity-lgtm/model-council-mcp-server

PyPI:

- https://pypi.org/project/model-council-mcp-server/

MCP Registry name:

- `io.github.ivanantigravity-lgtm/model-council-mcp-server`

---

## Какой сервер для чего

`Nano Banana 2 Polza MCP`

Это сервер для генерации изображений.

`Seedance Polza MCP`

Это сервер для генерации видео.

`Perplexity Polza MCP`

Это сервер для поиска, ресерча и ответов.

`Model Council MCP`

Это сервер для сравнения 3 моделей.
Там 2 команды:
- `china`
- `usa`

---

## Самый простой способ установки

Ниже самый понятный вариант для `Claude Desktop` на macOS.

### Шаг 1. Установить uv

Если `uv` ещё нет:

```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Потом перезапусти терминал.

Проверь:

```bash
uv --version
```

---

### Шаг 2. Открыть конфиг Claude Desktop

Файл:

`~/Library/Application Support/Claude/claude_desktop_config.json`

---

### Шаг 3. Добавить MCP-сервер

Ниже готовые примеры.

---

## Пример: Nano Banana 2 Polza MCP

```json
{
  "mcpServers": {
    "nanobanana-polza": {
      "command": "uvx",
      "args": [
        "nanobanana-2-polzaia-mcp-server"
      ],
      "env": {
        "POLZA_AI_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api",
        "LOG_LEVEL": "INFO",
        "LOG_FORMAT": "standard"
      }
    }
  }
}
```

---

## Пример: Seedance Polza MCP

```json
{
  "mcpServers": {
    "seedance-polza": {
      "command": "uvx",
      "args": [
        "seedance-polza-mcp-server"
      ],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "SEEDANCE_MODEL": "bytedance/seedance-2",
        "SEEDANCE_POLL_INTERVAL": "8",
        "SEEDANCE_MAX_WAIT": "900",
        "LOG_LEVEL": "INFO"
      }
    }
  }
}
```

---

## Пример: Perplexity Polza MCP

```json
{
  "mcpServers": {
    "perplexity-polza": {
      "command": "uvx",
      "args": [
        "perplexity-polza-mcp-server"
      ],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "PERPLEXITY_MODEL": "perplexity/sonar",
        "PERPLEXITY_RESEARCH_MODEL": "perplexity/sonar-deep-research",
        "LOG_LEVEL": "INFO"
      }
    }
  }
}
```

---

## Пример: Model Council MCP

```json
{
  "mcpServers": {
    "model-council": {
      "command": "uvx",
      "args": [
        "model-council-mcp-server"
      ],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "COUNCIL_CHINA_MOONSHOT_MODEL": "moonshotai/kimi-k2.5",
        "COUNCIL_CHINA_QWEN_MODEL": "qwen/qwen3.6-plus",
        "COUNCIL_CHINA_DEEPSEEK_MODEL": "deepseek/deepseek-v3.2",
        "COUNCIL_USA_GEMINI_MODEL": "google/gemini-3.1-flash-lite-preview",
        "COUNCIL_USA_GROK_MODEL": "x-ai/grok-4.1-fast",
        "COUNCIL_USA_OPENAI_MODEL": "openai/gpt-5.4-nano",
        "LOG_LEVEL": "INFO"
      }
    }
  }
}
```

---

## Как подключить все 4 сразу

```json
{
  "mcpServers": {
    "nanobanana-polza": {
      "command": "uvx",
      "args": ["nanobanana-2-polzaia-mcp-server"],
      "env": {
        "POLZA_AI_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api",
        "LOG_LEVEL": "INFO",
        "LOG_FORMAT": "standard"
      }
    },
    "seedance-polza": {
      "command": "uvx",
      "args": ["seedance-polza-mcp-server"],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "SEEDANCE_MODEL": "bytedance/seedance-2",
        "SEEDANCE_POLL_INTERVAL": "8",
        "SEEDANCE_MAX_WAIT": "900",
        "LOG_LEVEL": "INFO"
      }
    },
    "perplexity-polza": {
      "command": "uvx",
      "args": ["perplexity-polza-mcp-server"],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "PERPLEXITY_MODEL": "perplexity/sonar",
        "PERPLEXITY_RESEARCH_MODEL": "perplexity/sonar-deep-research",
        "LOG_LEVEL": "INFO"
      }
    },
    "model-council": {
      "command": "uvx",
      "args": ["model-council-mcp-server"],
      "env": {
        "POLZA_API_KEY": "YOUR_POLZA_API_KEY",
        "POLZA_BASE_URL": "https://polza.ai/api/v1",
        "COUNCIL_CHINA_MOONSHOT_MODEL": "moonshotai/kimi-k2.5",
        "COUNCIL_CHINA_QWEN_MODEL": "qwen/qwen3.6-plus",
        "COUNCIL_CHINA_DEEPSEEK_MODEL": "deepseek/deepseek-v3.2",
        "COUNCIL_USA_GEMINI_MODEL": "google/gemini-3.1-flash-lite-preview",
        "COUNCIL_USA_GROK_MODEL": "x-ai/grok-4.1-fast",
        "COUNCIL_USA_OPENAI_MODEL": "openai/gpt-5.4-nano",
        "LOG_LEVEL": "INFO"
      }
    }
  }
}
```

---

## После установки

1. Сохрани `claude_desktop_config.json`
2. Полностью перезапусти Claude Desktop
3. Проверь, что новые tools появились

---

## Что говорить Claude

### Для Nano Banana 2

- “Сгенерируй изображение по такому prompt ...”
- “Сделай вариацию этой картинки”
- “Сделай более реалистичную версию”

### Для Seedance

- “Запусти `seedance_create_video` с таким prompt ...”
- “Проверь статус генерации по id ...”

### Для Perplexity

- “Используй `perplexity_ask` и найди, что нового в ...”
- “Запусти `perplexity_research` по теме ...”

### Для Model Council

- “Запусти `tri_model_scan` с preset `china`”
- “Запусти `tri_model_scan` с preset `usa`”
- “Сравни ответ китайских и американских моделей”

---

## Если что-то не работает

Проверь:

- установлен ли `uv`
- правильно ли вставлен `POLZA_API_KEY`
- точно ли перезапущен Claude Desktop
- нет ли ошибки в JSON-конфиге

---

## Самый короткий вывод

- `Nano Banana 2 MCP` = генерация изображений
- `Seedance MCP` = генерация видео
- `Perplexity MCP` = поиск и ресерч
- `Model Council MCP` = сравнение моделей `china` vs `usa`

Если нужен один сервер для начала:

- для картинок бери `Nano Banana 2 MCP`
- для видео бери `Seedance MCP`
- для текста бери `Perplexity MCP`
- для контента про модели бери `Model Council MCP`
