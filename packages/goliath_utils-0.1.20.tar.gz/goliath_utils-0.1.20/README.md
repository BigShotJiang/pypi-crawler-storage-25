# goliath-utils

Lightweight internal utilities for the Goliath platform.

## Install

```bash
uv add goliath-utils
```

## S3 Client

A minimal S3 client using httpx — no boto3 required.

```python
from goliath_utils.s3 import S3Client

# Reads AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_REGION from env
with S3Client() as s3:
    s3.create_bucket("my-bucket")
    s3.upload_file("my-bucket", "data/file.csv", "./file.csv")
    s3.download_file("my-bucket", "data/file.csv", "./downloaded.csv")
    keys = s3.list_objects("my-bucket", prefix="data/")
    s3.delete_bucket("my-bucket")
```
