"""Tests for goliath_utils.env — custom load_dotenv replacement."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from goliath_utils.env import _find_dotenv, _parse_line, load_dotenv


# ---------------------------------------------------------------------------
# _parse_line
# ---------------------------------------------------------------------------

class TestParseLine:
    def test_basic(self):
        assert _parse_line("KEY=value") == ("KEY", "value")

    def test_spaces_around_equals(self):
        assert _parse_line("KEY = value") == ("KEY", "value")

    def test_empty_value(self):
        assert _parse_line("KEY=") == ("KEY", "")

    def test_blank_line(self):
        assert _parse_line("") is None
        assert _parse_line("   ") is None

    def test_comment(self):
        assert _parse_line("# this is a comment") is None
        assert _parse_line("  # indented comment") is None

    def test_inline_comment(self):
        assert _parse_line("KEY=value # comment") == ("KEY", "value")

    def test_double_quoted(self):
        assert _parse_line('KEY="hello world"') == ("KEY", "hello world")

    def test_single_quoted(self):
        assert _parse_line("KEY='hello world'") == ("KEY", "hello world")

    def test_quoted_preserves_hash(self):
        assert _parse_line('KEY="value # not a comment"') == ("KEY", "value # not a comment")

    def test_double_quote_escapes(self):
        assert _parse_line(r'KEY="line1\nline2"') == ("KEY", "line1\nline2")
        assert _parse_line(r'KEY="tab\there"') == ("KEY", "tab\there")

    def test_export_prefix(self):
        assert _parse_line("export KEY=value") == ("KEY", "value")
        assert _parse_line("export  KEY=value") == ("KEY", "value")

    def test_no_equals(self):
        assert _parse_line("JUST_A_KEY") is None


# ---------------------------------------------------------------------------
# _find_dotenv
# ---------------------------------------------------------------------------

class TestFindDotenv:
    def test_finds_in_cwd(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("A=1\n")
        monkeypatch.chdir(tmp_path)
        assert _find_dotenv() == env_file

    def test_finds_in_parent(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("A=1\n")
        child = tmp_path / "sub"
        child.mkdir()
        monkeypatch.chdir(child)
        assert _find_dotenv() == env_file

    def test_returns_none_when_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        assert _find_dotenv() is None


# ---------------------------------------------------------------------------
# load_dotenv
# ---------------------------------------------------------------------------

class TestLoadDotenv:
    def test_returns_false_no_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        assert load_dotenv() is False

    def test_loads_vars(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("TEST_GOLIATH_A=hello\nTEST_GOLIATH_B=world\n")
        monkeypatch.chdir(tmp_path)
        # Ensure clean
        monkeypatch.delenv("TEST_GOLIATH_A", raising=False)
        monkeypatch.delenv("TEST_GOLIATH_B", raising=False)

        result = load_dotenv()
        assert result is True
        assert os.environ["TEST_GOLIATH_A"] == "hello"
        assert os.environ["TEST_GOLIATH_B"] == "world"

    def test_does_not_override(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("TEST_GOLIATH_X=from_file\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("TEST_GOLIATH_X", "already_set")

        load_dotenv()
        assert os.environ["TEST_GOLIATH_X"] == "already_set"

    def test_skips_comments_and_blanks(self, tmp_path, monkeypatch):
        env_file = tmp_path / ".env"
        env_file.write_text("# comment\n\nTEST_GOLIATH_Y=yes\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("TEST_GOLIATH_Y", raising=False)

        load_dotenv()
        assert os.environ["TEST_GOLIATH_Y"] == "yes"
