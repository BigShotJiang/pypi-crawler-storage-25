"""Train/test splitting utilities for time series data.

Time series data cannot be split randomly like cross-sectional data —
the training set must always come *before* the test set in time to avoid
data leakage.

Two splitting strategies are provided:

- :func:`train_test_split` — single split by a cutoff date
- :func:`time_series_cv` — rolling-window cross-validation with multiple folds

Example::

    from goliath_utils.algorithms import train_test_split

    train, test = train_test_split(sales_ds, "sale_date", "2026-03-01")
    # train: all rows before March 1
    # test: all rows from March 1 onwards
"""

from __future__ import annotations

from typing import Any, Iterator

from goliath_utils.atrax import DataSet


def train_test_split(
    ds: DataSet,
    date_col: str,
    split_date: str,
) -> tuple[DataSet, DataSet]:
    """Split a DataSet into train and test sets by date.

    All rows where ``date_col < split_date`` go into train.
    All rows where ``date_col >= split_date`` go into test.

    Parameters:
        ds: The DataSet to split.
        date_col: Name of the date column (values must be comparable strings
                  in ISO format, e.g. ``"2026-03-01"``).
        split_date: The cutoff date string.  Test set starts here.

    Returns:
        A tuple of ``(train, test)`` DataSets.
    """
    train = ds[ds[date_col].apply(lambda d: str(d) < split_date)]
    test = ds[ds[date_col].apply(lambda d: str(d) >= split_date)]
    return train, test


def time_series_cv(
    ds: DataSet,
    date_col: str,
    n_splits: int = 3,
    horizon: int = 7,
) -> Iterator[tuple[DataSet, DataSet]]:
    """Rolling-window cross-validation for time series.

    Yields ``(train, test)`` pairs where each fold uses a progressively
    larger training window and a fixed-size test horizon.

    Parameters:
        ds: The DataSet to split (must be sorted by date_col).
        date_col: Name of the date column.
        n_splits: Number of train/test folds to generate.
        horizon: Number of unique dates in each test fold.

    Yields:
        Tuples of ``(train_ds, test_ds)``.
    """
    dates = sorted(set(str(d) for d in ds[date_col].values))
    total = len(dates)

    if total < n_splits + horizon:
        raise ValueError(
            f"Not enough dates ({total}) for {n_splits} splits "
            f"with horizon {horizon}. Need at least {n_splits + horizon}."
        )

    # Work backwards from the end
    for i in range(n_splits):
        test_end_idx = total - (i * horizon)
        test_start_idx = test_end_idx - horizon
        if test_start_idx < 1:
            break

        split_date = dates[test_start_idx]
        test_end_date = dates[test_end_idx - 1] if test_end_idx <= total else dates[-1]

        train = ds[ds[date_col].apply(lambda d, sd=split_date: str(d) < sd)]
        test = ds[ds[date_col].apply(
            lambda d, sd=split_date, ed=test_end_date: sd <= str(d) <= ed
        )]

        if len(train) > 0 and len(test) > 0:
            yield train, test
