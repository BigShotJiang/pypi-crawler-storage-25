"""Time series forecasting algorithms — pure Python, zero dependencies.

All forecasters share a common interface inherited from
:class:`~goliath_utils.algorithms.BaseForecaster`:

- ``fit(series)`` — train the model on historical data
- ``predict(steps)`` — generate future forecasts
- ``fit_predict(series, steps)`` — convenience: fit + predict in one call
- ``evaluate(actual, predicted)`` — compute all accuracy metrics

Available forecasters:

+---------------------------+-----------------------------------------------+
| Algorithm                 | Best for                                      |
+===========================+===============================================+
| ``SMA(window)``           | Stable, non-trending products (baseline)      |
+---------------------------+-----------------------------------------------+
| ``WMA(window)``           | Recent data matters more than old data         |
+---------------------------+-----------------------------------------------+
| ``SimpleExpSmoothing()``  | Stationary series, auto-optimized smoothing   |
+---------------------------+-----------------------------------------------+
| ``HoltForecaster()``      | Data with a clear upward or downward trend    |
+---------------------------+-----------------------------------------------+
| ``HoltWintersForecaster()`` | Trend + weekly seasonality (daily retail)   |
+---------------------------+-----------------------------------------------+
| ``LinearForecaster()``    | Simple linear trend extrapolation             |
+---------------------------+-----------------------------------------------+

The :class:`ForecastWorkbench` orchestrates the full pipeline: load data from
the Goliath ``sales`` table, run all algorithms, and compare accuracy.
"""

from ._sma import SMA
from ._wma import WMA
from ._ses import SimpleExpSmoothing
from ._holt import HoltForecaster
from ._holt_winters import HoltWintersForecaster
from ._linear import LinearForecaster
from ._workbench import ForecastWorkbench

__all__ = [
    "SMA",
    "WMA",
    "SimpleExpSmoothing",
    "HoltForecaster",
    "HoltWintersForecaster",
    "LinearForecaster",
    "ForecastWorkbench",
]
