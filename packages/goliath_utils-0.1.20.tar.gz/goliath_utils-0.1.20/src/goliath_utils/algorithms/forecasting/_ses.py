"""Simple Exponential Smoothing (SES) forecaster.

Exponential smoothing assigns exponentially decreasing weights to older
observations.  The smoothing parameter *alpha* controls how fast the
weights decay: ``alpha=1.0`` uses only the last observation, ``alpha=0.01``
gives nearly equal weight to all history.

**How it works:**

The smoothed level is updated recursively::

    level_t = alpha * value_t + (1 - alpha) * level_{t-1}

The forecast for all future periods is the final level (flat forecast).

**Auto-optimization:** If alpha is not provided, the model searches over
alpha values from 0.01 to 0.99 (in steps of 0.01) and picks the one that
minimises in-sample RMSE.

**Strengths:** Adapts to level changes, single parameter, auto-optimizable.
**Weaknesses:** Flat forecast — cannot capture trend or seasonality.

**When to use:** Stationary time series (no trend, no seasonality).  Good
for short-term forecasts of stable products.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class SimpleExpSmoothing(BaseForecaster):
    """Simple Exponential Smoothing — exponentially decaying weights.

    Each forecast is a weighted combination of the previous forecast and the
    most recent observation.  Alpha controls the decay rate: higher alpha
    reacts faster to changes, lower alpha is smoother.

    If *alpha* is ``None``, it is auto-optimized by grid search to minimise
    RMSE on the training data.

    Parameters:
        alpha: Smoothing parameter in [0, 1].  ``None`` for auto-optimization.

    Example::

        model = SimpleExpSmoothing(alpha=0.3)
        model.fit(Series([10, 20, 30, 40, 50]))
        model.predict(3)
    """

    def __init__(self, alpha: float | None = None):
        super().__init__()
        self.alpha = alpha
        self._level: float = 0.0
        self.name = f"SES(alpha={alpha})" if alpha else "SES(auto)"

    def fit(self, series: Series) -> None:
        """Fit the model.  Auto-optimizes alpha if not provided."""
        self._train_values = self._extract_values(series)
        if len(self._train_values) < 2:
            raise InsufficientDataError("SES requires at least 2 data points")

        if self.alpha is None:
            self.alpha = self._optimize_alpha(self._train_values)
            self.name = f"SES(alpha={self.alpha:.3f})"

        self._level = self._smooth(self._train_values, self.alpha)
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """SES flat forecast — all future values equal the last smoothed level."""
        self._check_fitted()
        return Series([round(self._level, 4)] * steps)

    def _smooth(self, values: list[float], alpha: float) -> float:
        """Run exponential smoothing and return the final level."""
        level = values[0]
        for v in values[1:]:
            level = alpha * v + (1 - alpha) * level
        return level

    def _optimize_alpha(self, values: list[float]) -> float:
        """Find the alpha that minimizes RMSE via grid search."""
        best_alpha = 0.5
        best_rmse = float("inf")

        for a_int in range(1, 100):
            alpha = a_int / 100
            level = values[0]
            sq_errors: list[float] = []
            for i in range(1, len(values)):
                forecast = level
                actual = values[i]
                sq_errors.append((actual - forecast) ** 2)
                level = alpha * actual + (1 - alpha) * level

            if sq_errors:
                current_rmse = math.sqrt(sum(sq_errors) / len(sq_errors))
                if current_rmse < best_rmse:
                    best_rmse = current_rmse
                    best_alpha = alpha

        return best_alpha
