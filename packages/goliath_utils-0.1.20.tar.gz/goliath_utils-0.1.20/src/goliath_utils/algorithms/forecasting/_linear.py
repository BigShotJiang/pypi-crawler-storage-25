"""Linear Regression forecaster — pure Python OLS (Ordinary Least Squares).

Fits a straight line ``y = slope * t + intercept`` to the data, where ``t``
is the integer time index (0, 1, 2, ...).  Predictions extrapolate this
line into the future.

**How it works:**

Uses the normal equations (closed-form solution, no iteration)::

    slope     = (n * sum(x*y) - sum(x) * sum(y)) / (n * sum(x²) - sum(x)²)
    intercept = mean(y) - slope * mean(x)

**Strengths:** Fast, interpretable (slope tells you the per-period change),
no hyperparameters to tune.
**Weaknesses:** Assumes a perfectly linear trend.  Cannot capture
seasonality, level shifts, or nonlinear patterns.

**When to use:** As a quick trend indicator.  The slope value is useful
even if the forecasts aren't — it tells you the direction and rate of change.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class LinearForecaster(BaseForecaster):
    """Ordinary Least Squares linear regression on a time index.

    Fits a straight line ``y = slope * t + intercept`` where ``t`` is the
    integer time index (0, 1, 2, ...).  Predictions extrapolate the line
    into the future.

    Good for capturing simple linear trends.  Does not capture seasonality.

    Attributes:
        slope: The fitted slope (units per period).
        intercept: The fitted y-intercept.

    Example::

        model = LinearForecaster()
        model.fit(Series([100, 110, 120, 130, 140]))
        model.predict(3)  # → Series([150, 160, 170])
        print(model.slope)      # 10.0
        print(model.intercept)  # 100.0
    """

    def __init__(self):
        super().__init__()
        self.slope: float = 0.0
        self.intercept: float = 0.0
        self.name = "Linear"

    def fit(self, series: Series) -> None:
        """Fit OLS regression using the normal equations.

        slope = (n * sum(x*y) - sum(x) * sum(y)) / (n * sum(x²) - sum(x)²)
        intercept = mean(y) - slope * mean(x)
        """
        self._train_values = self._extract_values(series)
        n = len(self._train_values)
        if n < 2:
            raise InsufficientDataError("Linear regression requires at least 2 data points")

        # x = [0, 1, 2, ..., n-1]
        sum_x = n * (n - 1) / 2
        sum_x2 = n * (n - 1) * (2 * n - 1) / 6
        sum_y = sum(self._train_values)
        sum_xy = sum(i * y for i, y in enumerate(self._train_values))

        denom = n * sum_x2 - sum_x * sum_x
        if denom == 0:
            self.slope = 0.0
            self.intercept = sum_y / n
        else:
            self.slope = (n * sum_xy - sum_x * sum_y) / denom
            self.intercept = (sum_y / n) - self.slope * (sum_x / n)

        self.name = f"Linear(slope={self.slope:.4f})"
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """Extrapolate the fitted line into the future."""
        self._check_fitted()
        n = len(self._train_values)
        predictions: list[float] = []
        for i in range(steps):
            t = n + i
            predictions.append(round(self.slope * t + self.intercept, 4))
        return Series(predictions)
