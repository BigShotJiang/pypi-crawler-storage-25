"""Weighted Moving Average (WMA) forecaster.

Like SMA but assigns different weights to each observation in the window.
By default, more recent observations get higher weight (linearly increasing:
``[1, 2, 3, ..., window]``).

**How it works:**

Given weights ``[w₁, w₂, ..., wₖ]`` and the last *k* values, the forecast is::

    forecast = (v₁*w₁ + v₂*w₂ + ... + vₖ*wₖ) / (w₁ + w₂ + ... + wₖ)

**Strengths:** Reacts faster to recent changes than SMA.  Custom weights
allow domain-specific tuning (e.g. downweight weekends).
**Weaknesses:** Still cannot capture trend or seasonality explicitly.

**When to use:** When recent observations are more relevant than older ones,
but you don't need the complexity of exponential smoothing.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class WMA(BaseForecaster):
    """Weighted Moving Average — gives more weight to recent observations.

    By default uses linearly increasing weights (most recent observation
    gets the highest weight).  Custom weights can be passed.

    Parameters:
        window: Number of recent periods to average over.  Default 7.
        weights: Optional list of weights (length must equal *window*).
                 If ``None``, uses linearly increasing weights ``[1, 2, ..., window]``.

    Example::

        model = WMA(window=3)
        model.fit(Series([10, 20, 30, 40, 50]))
        # weights [1, 2, 3] → (30*1 + 40*2 + 50*3) / 6 = 43.33
        model.predict(1)  # → Series([43.3333])
    """

    def __init__(self, window: int = 7, weights: list[float] | None = None):
        super().__init__()
        self.window = window
        if weights is not None:
            if len(weights) != window:
                raise ValueError(
                    f"weights length ({len(weights)}) must equal window ({window})"
                )
            self.weights = weights
        else:
            self.weights = [float(i + 1) for i in range(window)]
        self._weight_sum = sum(self.weights)
        self.name = f"WMA({window})"

    def fit(self, series: Series) -> None:
        """Fit by storing the training values."""
        self._train_values = self._extract_values(series)
        if len(self._train_values) < self.window:
            raise InsufficientDataError(
                f"WMA({self.window}) requires at least {self.window} data points, "
                f"got {len(self._train_values)}"
            )
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """Predict by rolling the weighted average forward."""
        self._check_fitted()
        values = list(self._train_values)
        predictions: list[float] = []
        for _ in range(steps):
            recent = values[-self.window :]
            wavg = sum(v * w for v, w in zip(recent, self.weights)) / self._weight_sum
            predictions.append(round(wavg, 4))
            values.append(wavg)
        return Series(predictions)
