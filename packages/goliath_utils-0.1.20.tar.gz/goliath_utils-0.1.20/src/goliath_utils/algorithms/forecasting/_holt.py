"""Holt's Double Exponential Smoothing — captures trend.

Extends SES with a separate trend component, allowing the forecast to
follow an upward or downward trajectory instead of flattening out.

**How it works:**

Two equations are updated recursively::

    level_t = alpha * value_t + (1 - alpha) * (level_{t-1} + trend_{t-1})
    trend_t = beta * (level_t - level_{t-1}) + (1 - beta) * trend_{t-1}

The forecast for *h* steps ahead is::

    forecast_{t+h} = level_t + h * trend_t

**Auto-optimization:** If alpha or beta is not provided, a two-stage grid
search finds the combination that minimises in-sample RMSE (coarse grid
at 5% intervals, then fine grid at 1% intervals around the best).

**Strengths:** Captures linear trend.  Two-parameter model is still simple.
**Weaknesses:** Cannot capture seasonality.  Trend extrapolation can
overshoot for long horizons.

**When to use:** Data with a clear upward or downward trend but no
repeating seasonal pattern.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class HoltForecaster(BaseForecaster):
    """Double Exponential Smoothing (Holt's method) — captures trend.

    Extends simple exponential smoothing with a separate trend component.
    Good for data that has an upward or downward trend but no seasonality.

    If *alpha* or *beta* is ``None``, they are auto-optimized by grid search
    to minimise RMSE on the training data.

    Parameters:
        alpha: Level smoothing parameter in [0, 1].  ``None`` for auto.
        beta: Trend smoothing parameter in [0, 1].  ``None`` for auto.

    Example::

        model = HoltForecaster()
        model.fit(Series([100, 110, 120, 130, 140]))
        model.predict(5)  # forecasts with trend continuation
    """

    def __init__(self, alpha: float | None = None, beta: float | None = None):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self._level: float = 0.0
        self._trend: float = 0.0
        self.name = "Holt(auto)"

    def fit(self, series: Series) -> None:
        """Fit the model.  Auto-optimizes alpha/beta if not provided."""
        self._train_values = self._extract_values(series)
        if len(self._train_values) < 3:
            raise InsufficientDataError("Holt requires at least 3 data points")

        if self.alpha is None or self.beta is None:
            self.alpha, self.beta = self._optimize(self._train_values)

        self.name = f"Holt(a={self.alpha:.2f},b={self.beta:.2f})"
        self._level, self._trend = self._smooth(
            self._train_values, self.alpha, self.beta
        )
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """Predict by extrapolating level + trend."""
        self._check_fitted()
        predictions: list[float] = []
        for i in range(1, steps + 1):
            predictions.append(round(self._level + i * self._trend, 4))
        return Series(predictions)

    def _smooth(
        self, values: list[float], alpha: float, beta: float
    ) -> tuple[float, float]:
        """Run Holt smoothing and return (level, trend)."""
        level = values[0]
        trend = values[1] - values[0]

        for v in values[1:]:
            prev_level = level
            level = alpha * v + (1 - alpha) * (level + trend)
            trend = beta * (level - prev_level) + (1 - beta) * trend

        return level, trend

    def _optimize(self, values: list[float]) -> tuple[float, float]:
        """Grid search for best alpha and beta."""
        best_alpha, best_beta = 0.5, 0.1
        best_rmse = float("inf")

        # Coarse grid then fine grid around best
        for a_int in range(5, 100, 5):
            for b_int in range(1, 50, 5):
                alpha = a_int / 100
                beta = b_int / 100
                rmse_val = self._calc_rmse(values, alpha, beta)
                if rmse_val < best_rmse:
                    best_rmse = rmse_val
                    best_alpha = alpha
                    best_beta = beta

        # Fine grid around best
        for a_int in range(max(1, int(best_alpha * 100) - 5), min(99, int(best_alpha * 100) + 6)):
            for b_int in range(max(1, int(best_beta * 100) - 5), min(99, int(best_beta * 100) + 6)):
                alpha = a_int / 100
                beta = b_int / 100
                rmse_val = self._calc_rmse(values, alpha, beta)
                if rmse_val < best_rmse:
                    best_rmse = rmse_val
                    best_alpha = alpha
                    best_beta = beta

        return best_alpha, best_beta

    def _calc_rmse(self, values: list[float], alpha: float, beta: float) -> float:
        """Calculate in-sample RMSE for given parameters."""
        level = values[0]
        trend = values[1] - values[0]
        sq_errors: list[float] = []

        for i in range(1, len(values)):
            forecast = level + trend
            sq_errors.append((values[i] - forecast) ** 2)
            prev_level = level
            level = alpha * values[i] + (1 - alpha) * (level + trend)
            trend = beta * (level - prev_level) + (1 - beta) * trend

        if not sq_errors:
            return float("inf")
        return math.sqrt(sum(sq_errors) / len(sq_errors))
