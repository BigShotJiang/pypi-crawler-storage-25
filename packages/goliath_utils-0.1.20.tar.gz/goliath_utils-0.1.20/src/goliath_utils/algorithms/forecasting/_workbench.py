"""ForecastWorkbench — the high-level orchestrator for forecasting workflows.

The workbench handles the full forecasting lifecycle:

1. **Load** — query the Goliath ``sales`` table with parameterised filters
2. **Split** — divide data into training and test periods by date
3. **Run** — fit all algorithms on training data, predict into the test period
4. **Evaluate** — compare predictions against actuals using shared metrics
5. **Rank** — sort algorithms by RMSE (or any metric) to find the best one

Three main entry points:

- :meth:`backtest` — full pipeline with separate train/test date ranges
- :meth:`forecast` — train on all data, predict N steps into the future
- :meth:`run_all` — lower-level: pass your own train/test Series

The workbench runs all built-in algorithms by default (SMA, WMA, SES, Holt,
Holt-Winters, Linear) but you can pass a custom list of forecasters.

Example::

    from goliath_utils.algorithms import ForecastWorkbench, SMA, HoltWintersForecaster

    wb = ForecastWorkbench()

    # Backtest: how would each algorithm have performed in March?
    results = wb.backtest(
        product_codes=["0001234567890"],
        store_ids=[111, 1185, 1397],
        train_start="2026-01-01",
        train_end="2026-02-28",
        test_start="2026-03-01",
        test_end="2026-03-21",
        target="qty",
    )
    print(results)  # ranked by RMSE

    # Forecast: predict the next 14 days
    forecast = wb.forecast(
        product_codes=["0001234567890"],
        store_ids=[111],
        start_date="2026-01-01",
        end_date="2026-03-21",
        steps=14,
        target="qty",
    )
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import DataSet, Series
from .._base import BaseForecaster
from .._errors import AlgorithmError, InsufficientDataError
from .._metrics import all_metrics
from .._split import train_test_split


def _default_forecasters() -> list[BaseForecaster]:
    """Return one instance of each built-in forecaster with sensible defaults."""
    from ._sma import SMA
    from ._wma import WMA
    from ._ses import SimpleExpSmoothing
    from ._holt import HoltForecaster
    from ._holt_winters import HoltWintersForecaster
    from ._linear import LinearForecaster

    return [
        SMA(window=7),
        SMA(window=14),
        WMA(window=7),
        SimpleExpSmoothing(),
        HoltForecaster(),
        HoltWintersForecaster(season_length=7),
        LinearForecaster(),
    ]


class ForecastWorkbench:
    """High-level forecasting workbench for Goliath sales data.

    Loads data from the ``sales`` table, runs multiple forecasting algorithms,
    and compares their accuracy — all in pure Python with zero dependencies.

    Parameters:
        db: A :class:`~goliath_utils.db.Database` instance.  If ``None``,
            calls ``get_db()`` to create one from Goliath secrets.

    Example::

        from goliath_utils.algorithms import ForecastWorkbench

        wb = ForecastWorkbench()
        results = wb.backtest(
            product_codes=["0001234567890"],
            store_ids=[111, 1185, 1397],
            train_start="2026-01-01",
            train_end="2026-02-28",
            test_start="2026-03-01",
            test_end="2026-03-21",
            target="qty",
        )
        print(results)  # comparison of all algorithms with metrics
    """

    def __init__(self, db: Any = None):
        if db is None:
            from goliath_utils.db import get_db
            db = get_db()
        self.db = db

    def load_sales(
        self,
        product_codes: list[str],
        store_ids: list[int],
        start_date: str,
        end_date: str,
        target: str = "qty",
        group_by: str | None = None,
    ) -> DataSet:
        """Query the sales table and return aggregated daily data.

        Parameters:
            product_codes: List of UPC/product codes to include.
            store_ids: List of store IDs to include.
            start_date: Start date (inclusive), e.g. ``"2026-01-01"``.
            end_date: End date (inclusive), e.g. ``"2026-03-21"``.
            target: Column to forecast — ``"qty"`` or ``"total_sales"``.
            group_by: Grouping granularity:

                - ``None``: aggregate all stores+products into one time series
                - ``"store"``: one time series per ``storeid``
                - ``"product"``: one time series per ``product_code``

        Returns:
            A DataSet with ``sale_date``, the target column, and optionally
            the group_by column.
        """
        if target not in ("qty", "total_sales"):
            raise AlgorithmError(f"target must be 'qty' or 'total_sales', got {target!r}")

        if group_by is None:
            sql = """
                SELECT sale_date::date AS sale_date,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date
                ORDER BY sale_date::date
            """
        elif group_by == "store":
            sql = """
                SELECT sale_date::date AS sale_date,
                       storeid,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date, storeid
                ORDER BY storeid, sale_date::date
            """
        elif group_by == "product":
            sql = """
                SELECT sale_date::date AS sale_date,
                       product_code,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date, product_code
                ORDER BY product_code, sale_date::date
            """
        else:
            raise AlgorithmError(
                f"group_by must be None, 'store', or 'product', got {group_by!r}"
            )

        rows = self.db.fetch_all(sql, {
            "product_codes": product_codes,
            "store_ids": store_ids,
            "start_date": start_date,
            "end_date": end_date,
        })

        if not rows:
            raise InsufficientDataError(
                "No sales data found for the given filters. "
                "Check product_codes, store_ids, and date range."
            )

        return DataSet(rows)

    def split(
        self, ds: DataSet, split_date: str
    ) -> tuple[DataSet, DataSet]:
        """Split a DataSet into train and test by date.

        Parameters:
            ds: DataSet with a ``sale_date`` column.
            split_date: Cutoff date — test set starts here.

        Returns:
            ``(train, test)`` tuple of DataSets.
        """
        return train_test_split(ds, "sale_date", split_date)

    def run_all(
        self,
        train: Series,
        test: Series,
        forecasters: list[BaseForecaster] | None = None,
    ) -> DataSet:
        """Run multiple forecasters and compare their accuracy.

        Parameters:
            train: Training time series (target column values).
            test: Actual test values to compare predictions against.
            forecasters: List of forecaster instances.  If ``None``, uses
                         all built-in algorithms with default settings.

        Returns:
            A DataSet with one row per algorithm and columns for each metric
            (algorithm, rmse, mae, mape, smape, r_squared, bias).
        """
        if forecasters is None:
            forecasters = _default_forecasters()

        steps = len(test)
        results: list[dict] = []

        for fc in forecasters:
            try:
                fc.fit(train)
                predicted = fc.predict(steps)
                metrics = fc.evaluate(test, predicted)
                metrics["algorithm"] = fc.name
                results.append(metrics)
            except (InsufficientDataError, AlgorithmError) as e:
                # Skip algorithms that can't handle this data
                results.append({
                    "algorithm": fc.name,
                    "rmse": float("nan"),
                    "mae": float("nan"),
                    "mape": float("nan"),
                    "smape": float("nan"),
                    "r_squared": float("nan"),
                    "bias": float("nan"),
                    "error": str(e),
                })

        # Reorder columns: algorithm first
        ds = DataSet(results)
        cols = ["algorithm"] + [c for c in ds.columns if c != "algorithm"]
        return ds[cols].sort_values("rmse")

    def backtest(
        self,
        product_codes: list[str],
        store_ids: list[int],
        train_start: str,
        train_end: str,
        test_start: str,
        test_end: str,
        target: str = "qty",
        forecasters: list[BaseForecaster] | None = None,
    ) -> DataSet:
        """Full backtesting pipeline: load data, train, predict, evaluate.

        Trains on the ``train_start`` to ``train_end`` period, predicts into
        the ``test_start`` to ``test_end`` period, and compares predictions
        against actuals already in the database.

        Parameters:
            product_codes: UPCs to include.
            store_ids: Store IDs to include.
            train_start: Training period start date.
            train_end: Training period end date.
            test_start: Test period start date.
            test_end: Test period end date.
            target: ``"qty"`` or ``"total_sales"``.
            forecasters: Algorithms to compare.  ``None`` for all defaults.

        Returns:
            A DataSet with algorithm names and all metrics, sorted by RMSE.
        """
        # Load train and test data separately
        train_ds = self.load_sales(
            product_codes, store_ids, train_start, train_end, target
        )
        test_ds = self.load_sales(
            product_codes, store_ids, test_start, test_end, target
        )

        train_series = Series(
            [float(v) for v in train_ds[target].values],
            name=target,
        )
        test_series = Series(
            [float(v) for v in test_ds[target].values],
            name=target,
        )

        return self.run_all(train_series, test_series, forecasters)

    def forecast(
        self,
        product_codes: list[str],
        store_ids: list[int],
        start_date: str,
        end_date: str,
        steps: int = 14,
        target: str = "qty",
        forecasters: list[BaseForecaster] | None = None,
    ) -> DataSet:
        """Train on all available data and predict N steps into the future.

        Parameters:
            product_codes: UPCs to include.
            store_ids: Store IDs to include.
            start_date: Historical data start date.
            end_date: Historical data end date.
            steps: Number of future periods to forecast.
            target: ``"qty"`` or ``"total_sales"``.
            forecasters: Algorithms to use.  ``None`` for all defaults.

        Returns:
            A DataSet with one row per algorithm, columns: algorithm,
            step_1, step_2, ..., step_N with the predicted values.
        """
        if forecasters is None:
            forecasters = _default_forecasters()

        ds = self.load_sales(product_codes, store_ids, start_date, end_date, target)
        train_series = Series(
            [float(v) for v in ds[target].values],
            name=target,
        )

        results: list[dict] = []
        for fc in forecasters:
            row: dict[str, Any] = {"algorithm": fc.name}
            try:
                fc.fit(train_series)
                predicted = fc.predict(steps)
                for i, val in enumerate(predicted.values):
                    row[f"step_{i + 1}"] = round(float(val), 2)
            except (InsufficientDataError, AlgorithmError) as e:
                row["error"] = str(e)
                for i in range(steps):
                    row[f"step_{i + 1}"] = float("nan")
            results.append(row)

        return DataSet(results)
