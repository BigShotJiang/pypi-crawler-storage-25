"""Holt-Winters Triple Exponential Smoothing — trend + seasonality.

The most powerful of the exponential smoothing family.  Extends Holt's
method with a seasonal component that captures repeating patterns (e.g.
higher sales on weekends, dips on Mondays).

**How it works (additive seasonality):**

Three equations are updated recursively::

    level_t    = alpha * (value_t - seasonal_{t-m}) + (1-alpha) * (level_{t-1} + trend_{t-1})
    trend_t    = beta  * (level_t - level_{t-1})    + (1-beta)  * trend_{t-1}
    seasonal_t = gamma * (value_t - level_t)         + (1-gamma) * seasonal_{t-m}

Where *m* is the season length (default 7 for daily data with weekly patterns).

The forecast for *h* steps ahead is::

    forecast_{t+h} = level_t + h * trend_t + seasonal_{t+h mod m}

**Auto-optimization:** If any of alpha, beta, gamma is ``None``, a two-stage
grid search (coarse then fine) finds the combination that minimises in-sample
RMSE.

**Minimum data:** Requires at least 2 full seasonal cycles (e.g. 14 days
for ``season_length=7``).

**Strengths:** Captures both trend and seasonality.  The gold standard for
retail daily forecasting.
**Weaknesses:** More parameters = more data needed.  Additive seasonality
assumes constant seasonal amplitude.

**When to use:** Daily retail sales data with weekly patterns.  This is
typically the best-performing algorithm for grocery/retail forecasting.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class HoltWintersForecaster(BaseForecaster):
    """Triple Exponential Smoothing (Holt-Winters) — trend + seasonality.

    Extends Holt's method with a seasonal component.  Uses additive
    seasonality by default (suitable for data where seasonal swings are
    roughly constant in magnitude).

    If parameters are ``None``, they are auto-optimized by grid search
    to minimise RMSE on the training data.

    Parameters:
        alpha: Level smoothing parameter in [0, 1].  ``None`` for auto.
        beta: Trend smoothing parameter in [0, 1].  ``None`` for auto.
        gamma: Seasonal smoothing parameter in [0, 1].  ``None`` for auto.
        season_length: Length of one seasonal cycle.  Default 7 (weekly
                       pattern for daily data).  Configurable for any period.

    Example::

        model = HoltWintersForecaster(season_length=7)
        model.fit(daily_sales_series)  # needs >= 2 full seasons
        model.predict(14)  # forecast 2 weeks ahead
    """

    def __init__(
        self,
        alpha: float | None = None,
        beta: float | None = None,
        gamma: float | None = None,
        season_length: int = 7,
    ):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma
        self.season_length = season_length
        self._level: float = 0.0
        self._trend: float = 0.0
        self._seasonals: list[float] = []
        self.name = f"HoltWinters(s={season_length})"

    def fit(self, series: Series) -> None:
        """Fit the model.  Requires at least 2 full seasonal cycles."""
        self._train_values = self._extract_values(series)
        n = len(self._train_values)
        m = self.season_length

        if n < 2 * m:
            raise InsufficientDataError(
                f"HoltWinters(season_length={m}) requires at least {2 * m} data points, "
                f"got {n}"
            )

        if self.alpha is None or self.beta is None or self.gamma is None:
            self.alpha, self.beta, self.gamma = self._optimize(self._train_values)

        self.name = (
            f"HoltWinters(a={self.alpha:.2f},b={self.beta:.2f},"
            f"g={self.gamma:.2f},s={m})"
        )

        self._level, self._trend, self._seasonals = self._smooth(
            self._train_values, self.alpha, self.beta, self.gamma
        )
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """Predict by extrapolating level + trend + seasonal component."""
        self._check_fitted()
        m = self.season_length
        predictions: list[float] = []
        for i in range(1, steps + 1):
            seasonal = self._seasonals[(i - 1) % m]
            predictions.append(round(self._level + i * self._trend + seasonal, 4))
        return Series(predictions)

    def _initial_seasonals(self, values: list[float]) -> list[float]:
        """Compute initial seasonal components from the first two cycles."""
        m = self.season_length
        n_cycles = len(values) // m

        # Average each season position across available full cycles
        seasonals: list[float] = []
        for i in range(m):
            cycle_vals = [values[c * m + i] for c in range(min(n_cycles, 2))]
            seasonals.append(sum(cycle_vals) / len(cycle_vals))

        # Normalize: subtract the overall mean of the seasonal values
        mean_s = sum(seasonals) / m
        return [s - mean_s for s in seasonals]

    def _smooth(
        self,
        values: list[float],
        alpha: float,
        beta: float,
        gamma: float,
    ) -> tuple[float, float, list[float]]:
        """Run Holt-Winters additive smoothing."""
        m = self.season_length
        seasonals = self._initial_seasonals(values)

        # Initial level: mean of first season
        level = sum(values[:m]) / m
        # Initial trend: average change between first two seasons
        trend = (sum(values[m : 2 * m]) - sum(values[:m])) / (m * m)

        for i in range(len(values)):
            v = values[i]
            s_idx = i % m
            prev_level = level

            level = alpha * (v - seasonals[s_idx]) + (1 - alpha) * (level + trend)
            trend = beta * (level - prev_level) + (1 - beta) * trend
            seasonals[s_idx] = gamma * (v - level) + (1 - gamma) * seasonals[s_idx]

        return level, trend, seasonals

    def _optimize(
        self, values: list[float]
    ) -> tuple[float, float, float]:
        """Grid search for best alpha, beta, gamma."""
        best = (0.5, 0.1, 0.1)
        best_rmse = float("inf")

        # Coarse grid
        for a in range(10, 90, 10):
            for b in range(5, 50, 10):
                for g in range(5, 50, 10):
                    alpha, beta, gamma = a / 100, b / 100, g / 100
                    rmse_val = self._calc_rmse(values, alpha, beta, gamma)
                    if rmse_val < best_rmse:
                        best_rmse = rmse_val
                        best = (alpha, beta, gamma)

        # Fine grid around best
        ba, bb, bg = best
        for a in range(max(1, int(ba * 100) - 10), min(99, int(ba * 100) + 11), 2):
            for b in range(max(1, int(bb * 100) - 10), min(99, int(bb * 100) + 11), 2):
                for g in range(max(1, int(bg * 100) - 10), min(99, int(bg * 100) + 11), 2):
                    alpha, beta, gamma = a / 100, b / 100, g / 100
                    rmse_val = self._calc_rmse(values, alpha, beta, gamma)
                    if rmse_val < best_rmse:
                        best_rmse = rmse_val
                        best = (alpha, beta, gamma)

        return best

    def _calc_rmse(
        self, values: list[float], alpha: float, beta: float, gamma: float
    ) -> float:
        """Calculate in-sample RMSE for given parameters."""
        m = self.season_length
        seasonals = self._initial_seasonals(values)
        level = sum(values[:m]) / m
        trend = (sum(values[m : 2 * m]) - sum(values[:m])) / (m * m)
        sq_errors: list[float] = []

        for i in range(len(values)):
            s_idx = i % m
            forecast = level + trend + seasonals[s_idx]
            sq_errors.append((values[i] - forecast) ** 2)

            prev_level = level
            level = alpha * (values[i] - seasonals[s_idx]) + (1 - alpha) * (level + trend)
            trend = beta * (level - prev_level) + (1 - beta) * trend
            seasonals[s_idx] = gamma * (values[i] - level) + (1 - gamma) * seasonals[s_idx]

        if not sq_errors:
            return float("inf")
        return math.sqrt(sum(sq_errors) / len(sq_errors))
