"""Simple Moving Average (SMA) forecaster.

The simplest forecasting method: the predicted value is the arithmetic mean
of the last *window* observations.  Each new prediction is appended to the
window so the average rolls forward.

**How it works:**

Given a window of size *k* and the last *k* values ``[v₁, v₂, ..., vₖ]``,
the forecast is::

    forecast = (v₁ + v₂ + ... + vₖ) / k

**Strengths:** Simple, fast, no parameters to tune, robust baseline.
**Weaknesses:** Cannot capture trend or seasonality.  Lags behind
directional changes by ~window/2 periods.

**When to use:** Stable, non-trending products.  Always include SMA as a
baseline to compare more complex models against.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._base import BaseForecaster
from .._errors import InsufficientDataError


class SMA(BaseForecaster):
    """Simple Moving Average — the baseline forecaster.

    Predicts future values as the average of the last *window* observations.
    Good for stable, non-trending products.

    Parameters:
        window: Number of recent periods to average over.  Default 7 (one week).

    Example::

        model = SMA(window=7)
        model.fit(Series([10, 20, 30, 40, 50, 60, 70]))
        model.predict(3)  # → Series([50.0, 50.0, 50.0])
    """

    def __init__(self, window: int = 7):
        super().__init__()
        self.window = window
        self.name = f"SMA({window})"

    def fit(self, series: Series) -> None:
        """Store the training values for the moving average window.

        Parameters:
            series: Historical time series (chronological order).

        Raises:
            InsufficientDataError: If the series has fewer values than *window*.
        """
        self._train_values = self._extract_values(series)
        if len(self._train_values) < self.window:
            raise InsufficientDataError(
                f"SMA({self.window}) requires at least {self.window} data points, "
                f"got {len(self._train_values)}"
            )
        self.fitted = True

    def predict(self, steps: int) -> Series:
        """Generate forecasts by rolling the moving average forward.

        Each step appends the previous prediction to the window, so the
        forecast gradually converges to a flat line.

        Parameters:
            steps: Number of future periods to forecast.

        Returns:
            A Series of length *steps* with the predicted values.
        """
        self._check_fitted()
        values = list(self._train_values)
        predictions: list[float] = []
        for _ in range(steps):
            avg = sum(values[-self.window :]) / self.window
            predictions.append(round(avg, 4))
            values.append(avg)
        return Series(predictions)
