"""Base clusterer interface — all clustering algorithms inherit from this.

Defines the standard lifecycle for clustering:

1. **Create** — instantiate with algorithm-specific parameters
2. **Fit** — call ``fit(data)`` to assign data points to clusters
3. **Predict** — call ``predict(data)`` to assign new points to existing clusters
4. **Summarize** — call ``summary()`` to get cluster statistics

Key difference from forecasting/anomaly: clustering operates on
**multivariate data** (multiple features per point), not just a single Series.

Data can be passed as:
- A ``list[list[float]]`` — each inner list is one data point's features
- A ``DataSet`` — each row is a data point, numeric columns are features

To create a custom clusterer, subclass :class:`BaseClusterer` and implement
``fit()`` and ``predict()``::

    class MyClusterer(BaseClusterer):
        name = "MyClusterer"

        def fit(self, data):
            points = self._to_points(data)
            # ... your clustering logic ...
            self.labels = [...]
            self.fitted = True

        def predict(self, data):
            points = self._to_points(data)
            # ... assign to nearest cluster ...
            return Series([...])
"""

from __future__ import annotations

import math
from typing import Any

from goliath_utils.atrax import DataSet, Series
from ._errors import NotFittedError, InsufficientDataError


class BaseClusterer:
    """Abstract base class for all clustering algorithms.

    Subclasses must implement :meth:`fit` and :meth:`predict`.

    Attributes:
        name: Human-readable name (e.g. ``"KMeans(k=3)"``).
        fitted: Whether :meth:`fit` has been called.
        labels: Cluster assignment for each point after fitting (list of ints).
        centroids: Cluster centers after fitting (list of lists).
        n_clusters: Number of clusters found.
    """

    name: str = "BaseClusterer"

    def __init__(self):
        self.fitted = False
        self.labels: list[int] = []
        self.centroids: list[list[float]] = []
        self.n_clusters: int = 0

    def fit(self, data: Any) -> None:
        """Assign data points to clusters.

        Parameters:
            data: A ``list[list[float]]`` or a ``DataSet`` with numeric columns.
        """
        raise NotImplementedError

    def predict(self, data: Any) -> Series:
        """Assign new data points to the nearest existing cluster.

        Parameters:
            data: New data in the same format/features as the training data.

        Returns:
            A Series of cluster labels (integers).

        Raises:
            NotFittedError: If :meth:`fit` has not been called yet.
        """
        raise NotImplementedError

    def fit_predict(self, data: Any) -> Series:
        """Fit the model and return cluster labels.

        Parameters:
            data: A ``list[list[float]]`` or a ``DataSet``.

        Returns:
            A Series of cluster labels.
        """
        self.fit(data)
        return Series(self.labels)

    def get_cluster(self, label: int) -> list[int]:
        """Return the indices of data points in the given cluster.

        Parameters:
            label: The cluster label (integer).

        Returns:
            A list of point indices belonging to that cluster.
        """
        return [i for i, l in enumerate(self.labels) if l == label]

    def summary(self) -> DataSet:
        """Return a summary DataSet with one row per cluster.

        Columns: cluster, size, and centroid coordinates (dim_0, dim_1, ...).
        """
        self._check_fitted()
        rows: list[dict] = []
        for k in range(self.n_clusters):
            indices = self.get_cluster(k)
            row: dict[str, Any] = {
                "cluster": k,
                "size": len(indices),
            }
            if k < len(self.centroids):
                for d, val in enumerate(self.centroids[k]):
                    row[f"dim_{d}"] = round(val, 4)
            rows.append(row)
        return DataSet(rows)

    def _check_fitted(self) -> None:
        """Raise NotFittedError if the model has not been fitted."""
        if not self.fitted:
            raise NotFittedError(
                f"{self.name} has not been fitted yet. Call fit() first."
            )

    def _to_points(self, data: Any) -> list[list[float]]:
        """Convert input data to a list of numeric point vectors."""
        if isinstance(data, DataSet):
            points: list[list[float]] = []
            for i in range(len(data.index)):
                row: list[float] = []
                for col in data.columns:
                    v = data[col].values[i]
                    if isinstance(v, (int, float)):
                        row.append(float(v))
                points.append(row)
            return points
        # Assume list of lists
        return [[float(v) for v in point] for point in data]

    @staticmethod
    def _euclidean(a: list[float], b: list[float]) -> float:
        """Euclidean distance between two points."""
        return math.sqrt(sum((ai - bi) ** 2 for ai, bi in zip(a, b)))

    @staticmethod
    def _nearest_centroid(point: list[float], centroids: list[list[float]]) -> int:
        """Return the index of the nearest centroid."""
        best = 0
        best_dist = float("inf")
        for i, c in enumerate(centroids):
            d = math.sqrt(sum((a - b) ** 2 for a, b in zip(point, c)))
            if d < best_dist:
                best_dist = d
                best = i
        return best

    def __repr__(self) -> str:
        return f"<{self.name}>"
