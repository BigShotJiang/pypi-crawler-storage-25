"""Base anomaly detector interface — all anomaly algorithms inherit from this.

Defines the standard lifecycle for anomaly detection:

1. **Create** — instantiate with algorithm-specific parameters
2. **Fit** — call ``fit(series)`` to learn what "normal" looks like
3. **Predict** — call ``predict(series)`` to get anomaly scores (0.0–1.0)
4. **Detect** — call ``detect(series)`` to get binary True/False labels

Key difference from :class:`BaseForecaster`: ``predict()`` takes a Series
of values to *score* (not a step count to predict forward).

To create a custom detector, subclass :class:`BaseAnomalyDetector` and
implement ``fit()`` and ``predict()``::

    class MyDetector(BaseAnomalyDetector):
        name = "MyDetector"

        def fit(self, series: Series) -> None:
            self._mean = series.mean()
            self.fitted = True

        def predict(self, series: Series) -> Series:
            self._check_fitted()
            return Series([abs(v - self._mean) for v in series.values])
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import Series
from ._errors import NotFittedError


class BaseAnomalyDetector:
    """Abstract base class for all anomaly detection algorithms.

    Subclasses must implement :meth:`fit` and :meth:`predict`.

    Attributes:
        name: Human-readable name (e.g. ``"ZScore(2.5)"``).
        fitted: Whether :meth:`fit` has been called.
        threshold: Score threshold for binary detection.  Points with
                   scores above this are flagged as anomalies.
    """

    name: str = "BaseAnomalyDetector"

    def __init__(self, threshold: float = 0.5):
        self.fitted = False
        self.threshold = threshold

    def fit(self, series: Series) -> None:
        """Learn the normal/baseline pattern from training data.

        Parameters:
            series: A Series of numeric values representing normal behaviour.
        """
        raise NotImplementedError

    def predict(self, series: Series) -> Series:
        """Score each point in the series.

        Higher scores indicate more anomalous points.  The scale depends
        on the algorithm (some return 0–1, others return unbounded scores).

        Parameters:
            series: A Series of numeric values to score.

        Returns:
            A Series of anomaly scores (same length as input).

        Raises:
            NotFittedError: If :meth:`fit` has not been called yet.
        """
        raise NotImplementedError

    def fit_predict(self, series: Series) -> Series:
        """Fit the model and immediately score the same data.

        Convenience method for one-shot anomaly detection.

        Parameters:
            series: A Series of numeric values.

        Returns:
            A Series of anomaly scores.
        """
        self.fit(series)
        return self.predict(series)

    def detect(self, series: Series, threshold: float | None = None) -> Series:
        """Score the series and return binary anomaly labels.

        Parameters:
            series: A Series of numeric values to check.
            threshold: Override the default threshold.  Points with scores
                       above this are flagged as anomalies.

        Returns:
            A Series of booleans (``True`` = anomaly, ``False`` = normal).
        """
        t = threshold if threshold is not None else self.threshold
        scores = self.predict(series)
        return Series([s > t for s in scores.values])

    def _check_fitted(self) -> None:
        """Raise NotFittedError if the model has not been fitted."""
        if not self.fitted:
            raise NotFittedError(
                f"{self.name} has not been fitted yet. Call fit() first."
            )

    def _extract_values(self, series: Series) -> list[float]:
        """Extract float values from a Series, replacing NA with 0."""
        from goliath_utils.atrax import is_na

        values: list[float] = []
        for v in series.values:
            if v is None or is_na(v):
                values.append(0.0)
            else:
                values.append(float(v))
        return values

    def __repr__(self) -> str:
        return f"<{self.name}>"
