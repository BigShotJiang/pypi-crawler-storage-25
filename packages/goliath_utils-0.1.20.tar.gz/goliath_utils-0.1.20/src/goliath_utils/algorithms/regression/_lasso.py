"""Lasso Regression — L1 regularization via coordinate descent, pure Python.

Unlike Ridge, Lasso can drive coefficients to exactly zero, performing
automatic feature selection.  Useful when you have many features and
want to know which ones actually matter.

**How it works (coordinate descent):**

For each feature *j*, update its coefficient while holding others fixed::

    β_j = soft_threshold(ρ_j, α) / z_j

Where ``soft_threshold(x, α) = sign(x) * max(|x| - α, 0)``

**Strengths:** Automatic feature selection (zeroes out irrelevant features),
interpretable sparse models.
**Weaknesses:** Slower than OLS (iterative), can be unstable when features
are highly correlated (tends to pick one and zero the rest).

**When to use:** When you have many features and want to automatically
identify the most important ones.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._regression_base import BaseRegressor
from .._errors import InsufficientDataError


class LassoRegression(BaseRegressor):
    """Lasso Regression (L1 regularized) via coordinate descent.

    Parameters:
        alpha: Regularization strength.  Larger = more coefficients zeroed.
               Default 1.0.
        max_iter: Maximum coordinate descent iterations.  Default 1000.
        tol: Convergence tolerance.  Default 1e-6.

    Attributes:
        n_nonzero: Number of non-zero coefficients after fitting.

    Example::

        model = LassoRegression(alpha=0.5)
        model.fit(X_train, y_train)
        print(f"Non-zero features: {model.n_nonzero} / {len(model.coefficients)}")
    """

    def __init__(self, alpha: float = 1.0, max_iter: int = 1000, tol: float = 1e-6):
        super().__init__()
        self.alpha = alpha
        self.max_iter = max_iter
        self.tol = tol
        self.n_nonzero: int = 0
        self.name = f"Lasso(alpha={alpha})"

    def fit(self, X, y) -> None:
        """Fit using coordinate descent.

        Parameters:
            X: Feature matrix.
            y: Target values.
        """
        X_raw = self._to_matrix(X)
        y_vec = self._to_vector(y)
        n = len(X_raw)
        p = len(X_raw[0]) if X_raw else 0

        # Center X and y for coordinate descent (handle intercept separately)
        x_means = [sum(X_raw[i][j] for i in range(n)) / n for j in range(p)]
        y_mean = sum(y_vec) / n

        X_c = [[X_raw[i][j] - x_means[j] for j in range(p)] for i in range(n)]
        y_c = [y_vec[i] - y_mean for i in range(n)]

        # Precompute z_j = sum(x_ij²) for each feature
        z = [sum(X_c[i][j] ** 2 for i in range(n)) for j in range(p)]

        beta = [0.0] * p

        for iteration in range(self.max_iter):
            max_change = 0.0

            for j in range(p):
                if z[j] == 0:
                    continue

                # Compute partial residual
                rho = sum(
                    X_c[i][j] * (y_c[i] - sum(beta[k] * X_c[i][k] for k in range(p) if k != j))
                    for i in range(n)
                )

                # Soft threshold
                old_beta = beta[j]
                if rho > self.alpha:
                    beta[j] = (rho - self.alpha) / z[j]
                elif rho < -self.alpha:
                    beta[j] = (rho + self.alpha) / z[j]
                else:
                    beta[j] = 0.0

                max_change = max(max_change, abs(beta[j] - old_beta))

            if max_change < self.tol:
                break

        self.coefficients = [round(b, 8) for b in beta]
        self.intercept = y_mean - sum(beta[j] * x_means[j] for j in range(p))
        self.n_nonzero = sum(1 for b in self.coefficients if abs(b) > 1e-10)
        self.fitted = True

    def predict(self, X) -> Series:
        """Predict using the fitted Lasso model."""
        self._check_fitted()
        X_raw = self._to_matrix(X)
        predictions = []
        for row in X_raw:
            val = self.intercept + sum(c * x for c, x in zip(self.coefficients, row))
            predictions.append(round(val, 6))
        return Series(predictions)
