"""Regression algorithms — pure Python, zero dependencies.

All regressors share a common interface inherited from
:class:`~goliath_utils.algorithms.BaseRegressor`:

- ``fit(X, y)`` — fit the model to training features and target
- ``predict(X)`` — predict target values for new data
- ``evaluate(y_actual, y_predicted)`` — compute accuracy metrics
- ``score(X, y)`` — shortcut: predict + R²

Available regressors:

+---------------------------+-----------------------------------------------+
| Algorithm                 | Best for                                      |
+===========================+===============================================+
| ``LinearRegression``      | General purpose, interpretable coefficients   |
+---------------------------+-----------------------------------------------+
| ``RidgeRegression``       | Correlated features (L2 regularization)       |
+---------------------------+-----------------------------------------------+
| ``LassoRegression``       | Feature selection (L1, zeros out features)    |
+---------------------------+-----------------------------------------------+
| ``PolynomialRegression``  | Nonlinear/curved relationships                |
+---------------------------+-----------------------------------------------+
| ``KNNRegressor``          | Complex patterns, no assumptions              |
+---------------------------+-----------------------------------------------+
"""

from ._linear import LinearRegression
from ._ridge import RidgeRegression
from ._lasso import LassoRegression
from ._polynomial import PolynomialRegression
from ._knn import KNNRegressor
from ._workbench import RegressionWorkbench

__all__ = [
    "LinearRegression",
    "RidgeRegression",
    "LassoRegression",
    "PolynomialRegression",
    "KNNRegressor",
    "RegressionWorkbench",
]
