"""Ridge Regression — OLS with L2 regularization, pure Python.

Adds a penalty on the squared magnitude of coefficients to prevent
overfitting, especially when features are correlated (multicollinearity).

**Formula:** β = (XᵀX + αI)⁻¹ Xᵀy

The penalty ``αI`` makes the matrix invertible even when XᵀX is
singular or near-singular, and shrinks coefficients toward zero.

**Strengths:** Handles multicollinearity, more stable than plain OLS,
single hyperparameter (alpha).
**Weaknesses:** Doesn't zero out coefficients (no feature selection).

**When to use:** When you have correlated features (e.g. qty and total_sales
both included) and plain LinearRegression is unstable.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._regression_base import BaseRegressor
from .._errors import InsufficientDataError


class RidgeRegression(BaseRegressor):
    """Ridge Regression (L2 regularized OLS).

    Parameters:
        alpha: Regularization strength.  Larger alpha = more shrinkage.
               Default 1.0.

    Example::

        model = RidgeRegression(alpha=1.0)
        model.fit([[1],[2],[3],[4],[5]], [2.1, 4.0, 5.9, 8.1, 9.9])
        pred = model.predict([[6]])
    """

    def __init__(self, alpha: float = 1.0):
        super().__init__()
        self.alpha = alpha
        self.name = f"Ridge(alpha={alpha})"

    def fit(self, X, y) -> None:
        """Fit using the Ridge normal equations: β = (XᵀX + αI)⁻¹Xᵀy.

        Parameters:
            X: Feature matrix.
            y: Target values.
        """
        X_raw = self._to_matrix(X)
        y_vec = self._to_vector(y)
        n = len(X_raw)

        X_aug = self._add_intercept_column(X_raw)
        p = len(X_aug[0])
        Xt = self._mat_transpose(X_aug)
        XtX = self._mat_mul(Xt, X_aug)

        # Add αI (but don't penalize the intercept — index 0)
        for i in range(p):
            if i > 0:
                XtX[i][i] += self.alpha

        XtX_inv = self._mat_inverse(XtX)
        Xty = self._mat_vec_mul(Xt, y_vec)
        beta = self._mat_vec_mul(XtX_inv, Xty)

        self.intercept = beta[0]
        self.coefficients = beta[1:]
        self.fitted = True

    def predict(self, X) -> Series:
        """Predict using the fitted Ridge model."""
        self._check_fitted()
        X_raw = self._to_matrix(X)
        predictions = []
        for row in X_raw:
            val = self.intercept + sum(c * x for c, x in zip(self.coefficients, row))
            predictions.append(round(val, 6))
        return Series(predictions)
