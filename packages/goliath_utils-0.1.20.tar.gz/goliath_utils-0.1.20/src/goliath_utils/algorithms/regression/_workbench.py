"""RegressionWorkbench — orchestrator for regression workflows.

Loads sales data with features, runs multiple regression algorithms,
and compares their accuracy.

Example::

    from goliath_utils.algorithms.regression import RegressionWorkbench

    wb = RegressionWorkbench()
    ds = wb.load_features([111], ["0001234567890"], "2026-01-01", "2026-03-21")
    # Split, train, evaluate...
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import DataSet, Series
from .._regression_base import BaseRegressor
from .._errors import AlgorithmError, InsufficientDataError
from .._metrics import all_metrics


def _default_regressors() -> list[BaseRegressor]:
    """Return one instance of each built-in regressor."""
    from ._linear import LinearRegression
    from ._ridge import RidgeRegression
    from ._lasso import LassoRegression
    from ._polynomial import PolynomialRegression
    from ._knn import KNNRegressor

    return [
        LinearRegression(),
        RidgeRegression(alpha=1.0),
        RidgeRegression(alpha=10.0),
        LassoRegression(alpha=0.1),
        LassoRegression(alpha=1.0),
        PolynomialRegression(degree=2),
        KNNRegressor(k=3),
        KNNRegressor(k=5),
    ]


class RegressionWorkbench:
    """High-level regression workbench for Goliath data.

    Parameters:
        db: A :class:`~goliath_utils.db.Database` instance.  If ``None``,
            calls ``get_db()`` to create one.

    Example::

        wb = RegressionWorkbench()
        ds = wb.load_features([111], ["0001234567890"], "2026-01-01", "2026-03-21")
    """

    def __init__(self, db: Any = None):
        if db is None:
            from goliath_utils.db import get_db
            db = get_db()
        self.db = db

    def load_features(
        self,
        store_ids: list[int],
        product_codes: list[str],
        start_date: str,
        end_date: str,
    ) -> DataSet:
        """Load daily sales data with engineered features.

        Returns a DataSet with columns: sale_date, storeid, store_name,
        qty, total_sales, transaction_count, day_of_week, month.

        Parameters:
            store_ids: Store IDs to include.
            product_codes: UPC/product codes to include.
            start_date: Start date (inclusive).
            end_date: End date (inclusive).
        """
        sql = """
            SELECT sale_date::date AS sale_date,
                   storeid, store_name,
                   SUM(qty) AS qty,
                   SUM(total_sales) AS total_sales,
                   COUNT(DISTINCT sale_id) AS transaction_count,
                   EXTRACT(DOW FROM sale_date) AS day_of_week,
                   EXTRACT(MONTH FROM sale_date) AS month
            FROM sales
            WHERE storeid = ANY(:store_ids)
              AND product_code = ANY(:product_codes)
              AND sale_date BETWEEN :start_date AND :end_date
              AND sale_type IN ('Refunded', 'Sale')
              AND item_ring_type IN ('ITEM', 'SUBD')
            GROUP BY sale_date::date, storeid, store_name
            ORDER BY sale_date::date
        """
        rows = self.db.fetch_all(sql, {
            "store_ids": store_ids,
            "product_codes": product_codes,
            "start_date": start_date,
            "end_date": end_date,
        })
        if not rows:
            raise InsufficientDataError("No sales data found for the given filters.")
        return DataSet(rows)

    def run_all(
        self,
        X_train: Any,
        y_train: Any,
        X_test: Any,
        y_test: Any,
        regressors: list[BaseRegressor] | None = None,
    ) -> DataSet:
        """Run multiple regressors and compare accuracy.

        Parameters:
            X_train: Training features.
            y_train: Training targets.
            X_test: Test features.
            y_test: Test targets.
            regressors: List of regressor instances.  ``None`` for all defaults.

        Returns:
            A DataSet with one row per algorithm and metric columns,
            sorted by RMSE.
        """
        if regressors is None:
            regressors = _default_regressors()

        results: list[dict] = []
        for reg in regressors:
            try:
                reg.fit(X_train, y_train)
                pred = reg.predict(X_test)
                metrics = reg.evaluate(y_test, pred)
                metrics["algorithm"] = reg.name
                results.append(metrics)
            except (InsufficientDataError, AlgorithmError, Exception) as e:
                results.append({
                    "algorithm": reg.name,
                    "rmse": float("nan"),
                    "mae": float("nan"),
                    "mape": float("nan"),
                    "smape": float("nan"),
                    "r_squared": float("nan"),
                    "bias": float("nan"),
                    "error": str(e),
                })

        ds = DataSet(results)
        cols = ["algorithm"] + [c for c in ds.columns if c != "algorithm"]
        return ds[cols].sort_values("rmse")
