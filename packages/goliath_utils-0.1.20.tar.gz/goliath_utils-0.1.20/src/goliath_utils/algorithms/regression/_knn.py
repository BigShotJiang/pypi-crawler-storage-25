"""K-Nearest Neighbors Regression — non-parametric, pure Python.

Predicts the target value as the average of the *k* nearest training
points (by Euclidean distance).  No assumptions about data shape.

**How it works:**

1. Store all training data
2. For a new point, compute distance to every training point
3. Find the *k* closest training points
4. Predict = mean of their target values

**Strengths:** No assumptions (works on any pattern), simple, no training
time (lazy learner), handles nonlinear relationships naturally.
**Weaknesses:** Slow at prediction time (O(n) per prediction), sensitive
to irrelevant features and scale, needs feature normalization.

**When to use:** When the relationship is complex/unknown and you have
enough training data.  Good for exploring whether a nonlinear pattern exists.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._regression_base import BaseRegressor
from .._errors import InsufficientDataError


class KNNRegressor(BaseRegressor):
    """K-Nearest Neighbors Regression.

    Parameters:
        k: Number of neighbours to average.  Default 5.

    Example::

        model = KNNRegressor(k=3)
        model.fit([[1],[2],[3],[4],[5]], [10, 20, 30, 40, 50])
        pred = model.predict([[2.5]])  # avg of k=3 nearest → ~20 or ~30
    """

    def __init__(self, k: int = 5):
        super().__init__()
        self.k = k
        self._X_train: list[list[float]] = []
        self._y_train: list[float] = []
        self.name = f"KNN(k={k})"

    def fit(self, X, y) -> None:
        """Store training data (lazy learner — no computation at fit time).

        Parameters:
            X: Feature matrix.
            y: Target values.

        Raises:
            InsufficientDataError: If fewer samples than k.
        """
        self._X_train = self._to_matrix(X)
        self._y_train = self._to_vector(y)
        if len(self._X_train) < self.k:
            raise InsufficientDataError(
                f"KNN(k={self.k}) needs at least {self.k} training points, "
                f"got {len(self._X_train)}"
            )
        self.fitted = True

    def predict(self, X) -> Series:
        """Predict by averaging the k nearest training targets.

        Parameters:
            X: Feature matrix.

        Returns:
            Series of predicted values.
        """
        self._check_fitted()
        X_raw = self._to_matrix(X)
        predictions: list[float] = []

        for point in X_raw:
            # Compute distances to all training points
            dists = []
            for i, train_point in enumerate(self._X_train):
                d = math.sqrt(sum(
                    (a - b) ** 2 for a, b in zip(point, train_point)
                ))
                dists.append((d, self._y_train[i]))

            # Sort by distance, take k nearest
            dists.sort(key=lambda x: x[0])
            k_nearest = dists[:self.k]
            avg = sum(y for _, y in k_nearest) / self.k
            predictions.append(round(avg, 6))

        return Series(predictions)
