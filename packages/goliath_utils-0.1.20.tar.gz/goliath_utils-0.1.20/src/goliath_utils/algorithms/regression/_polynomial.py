"""Polynomial Regression — fits nonlinear curves, pure Python.

Expands features to polynomial terms then fits OLS.  For example, with
degree=2 and one feature x, the model becomes ``y = β₀ + β₁x + β₂x²``.

**How it works:**

1. Expand features: ``[x₁, x₂]`` with degree=2 → ``[x₁, x₂, x₁², x₁x₂, x₂²]``
2. Fit ordinary linear regression on the expanded features
3. Predictions use the same expansion

**Strengths:** Captures nonlinear relationships with a simple extension of
linear regression.  Interpretable polynomial terms.
**Weaknesses:** High degrees overfit easily.  Feature count grows
combinatorially with degree and number of features.

**When to use:** When the relationship between features and target is
curved (e.g. diminishing returns — sales vs price).
"""

from __future__ import annotations

from itertools import combinations_with_replacement

from goliath_utils.atrax import Series
from .._regression_base import BaseRegressor
from .._errors import InsufficientDataError
from ._linear import LinearRegression


class PolynomialRegression(BaseRegressor):
    """Polynomial Regression — expands features then fits OLS.

    Parameters:
        degree: Maximum polynomial degree.  Default 2.

    Example::

        model = PolynomialRegression(degree=2)
        model.fit([[1],[2],[3],[4],[5]], [1, 4, 9, 16, 25])  # y = x²
        pred = model.predict([[6]])  # → ~36
    """

    def __init__(self, degree: int = 2):
        super().__init__()
        self.degree = degree
        self._inner = LinearRegression()
        self._n_features: int = 0
        self.name = f"Polynomial(degree={degree})"

    def fit(self, X, y) -> None:
        """Expand features to polynomial terms and fit OLS.

        Parameters:
            X: Feature matrix.
            y: Target values.
        """
        X_raw = self._to_matrix(X)
        self._n_features = len(X_raw[0]) if X_raw else 0
        X_poly = [self._expand(row) for row in X_raw]
        self._inner.fit(X_poly, y)
        self.coefficients = self._inner.coefficients
        self.intercept = self._inner.intercept
        self.fitted = True

    def predict(self, X) -> Series:
        """Expand features and predict."""
        self._check_fitted()
        X_raw = self._to_matrix(X)
        X_poly = [self._expand(row) for row in X_raw]
        return self._inner.predict(X_poly)

    def _expand(self, row: list[float]) -> list[float]:
        """Expand a single row to polynomial features.

        For degree=2 with features [a, b]:
        returns [a, b, a², ab, b²]
        """
        expanded = list(row)  # degree 1 terms
        for d in range(2, self.degree + 1):
            for combo in combinations_with_replacement(range(len(row)), d):
                val = 1.0
                for idx in combo:
                    val *= row[idx]
                expanded.append(val)
        return expanded
