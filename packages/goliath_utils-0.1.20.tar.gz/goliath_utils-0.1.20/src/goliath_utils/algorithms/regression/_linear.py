"""Multiple Linear Regression — OLS via normal equations, pure Python.

Fits the model ``y = X @ β + intercept`` by solving the normal equations::

    β = (XᵀX)⁻¹ Xᵀy

Supports any number of features (multiple regression).

**Strengths:** Fast (closed-form, no iteration), interpretable coefficients,
no hyperparameters.
**Weaknesses:** Assumes linear relationship, sensitive to multicollinearity,
no regularization (can overfit with many features).

**When to use:** Predicting sales from price, quantity, day of week, etc.
The coefficients tell you exactly how much each feature contributes.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._regression_base import BaseRegressor
from .._errors import InsufficientDataError


class LinearRegression(BaseRegressor):
    """Multiple Linear Regression via OLS normal equations.

    Attributes:
        coefficients: Fitted coefficients (one per feature).
        intercept: Fitted intercept (bias term).
        feature_names: Names of features if fit with a DataSet.

    Example::

        model = LinearRegression()
        model.fit([[1,10],[2,20],[3,30],[4,40]], [12, 22, 33, 42])
        pred = model.predict([[5,50]])
        print(model.coefficients, model.intercept)
    """

    def __init__(self):
        super().__init__()
        self.feature_names: list[str] = []
        self.name = "LinearRegression"

    def fit(self, X, y) -> None:
        """Fit using the normal equations: β = (XᵀX)⁻¹Xᵀy.

        Parameters:
            X: Feature matrix (list of lists or DataSet).
            y: Target values (list or Series).

        Raises:
            InsufficientDataError: If fewer samples than features + 1.
        """
        from goliath_utils.atrax import DataSet
        if isinstance(X, DataSet):
            self.feature_names = list(X.columns)

        X_raw = self._to_matrix(X)
        y_vec = self._to_vector(y)
        n = len(X_raw)
        p = len(X_raw[0]) if X_raw else 0

        if n < p + 1:
            raise InsufficientDataError(
                f"Need at least {p + 1} samples for {p} features, got {n}"
            )

        # Add intercept column
        X_aug = self._add_intercept_column(X_raw)
        Xt = self._mat_transpose(X_aug)
        XtX = self._mat_mul(Xt, X_aug)
        XtX_inv = self._mat_inverse(XtX)
        Xty = self._mat_vec_mul(Xt, y_vec)
        beta = self._mat_vec_mul(XtX_inv, Xty)

        self.intercept = beta[0]
        self.coefficients = beta[1:]
        self.fitted = True

    def predict(self, X) -> Series:
        """Predict using the fitted linear model.

        Parameters:
            X: Feature matrix.

        Returns:
            Series of predicted values.
        """
        self._check_fitted()
        X_raw = self._to_matrix(X)
        predictions = []
        for row in X_raw:
            val = self.intercept + sum(c * x for c, x in zip(self.coefficients, row))
            predictions.append(round(val, 6))
        return Series(predictions)
