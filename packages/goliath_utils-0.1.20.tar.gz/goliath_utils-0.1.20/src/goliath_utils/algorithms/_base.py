"""Base forecaster interface — all forecasting algorithms inherit from this.

Defines the standard lifecycle that every forecaster follows:

1. **Create** — instantiate with algorithm-specific hyperparameters
2. **Fit** — call ``fit(series)`` with historical data
3. **Predict** — call ``predict(steps)`` to generate future forecasts
4. **Evaluate** — call ``evaluate(actual, predicted)`` to compute accuracy metrics

This ensures that the :class:`~goliath_utils.algorithms.forecasting.ForecastWorkbench`
can run *any* forecaster without knowing its internals.

To create a custom forecaster, subclass :class:`BaseForecaster` and implement
``fit()`` and ``predict()``::

    from goliath_utils.algorithms import BaseForecaster
    from goliath_utils.atrax import Series

    class MyForecaster(BaseForecaster):
        name = "MyForecaster"

        def fit(self, series: Series) -> None:
            self._train_values = self._extract_values(series)
            # ... your training logic ...
            self.fitted = True

        def predict(self, steps: int) -> Series:
            self._check_fitted()
            # ... your prediction logic ...
            return Series([...])
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import Series
from ._errors import NotFittedError
from ._metrics import all_metrics


class BaseForecaster:
    """Abstract base class for all forecasting algorithms.

    Subclasses must implement :meth:`fit` and :meth:`predict`.
    The :meth:`evaluate` method is shared across all forecasters.

    Attributes:
        name: Human-readable name (e.g. ``"SMA(7)"``).
        fitted: Whether :meth:`fit` has been called.
    """

    name: str = "BaseForecaster"

    def __init__(self):
        self.fitted = False
        self._train_values: list[float] = []

    def fit(self, series: Series) -> None:
        """Fit the model to a time series.

        Parameters:
            series: A Series of numeric values in chronological order.
        """
        raise NotImplementedError

    def predict(self, steps: int) -> Series:
        """Generate forecasts for *steps* periods into the future.

        Parameters:
            steps: Number of future periods to predict.

        Returns:
            A Series of length *steps* with the forecasted values.

        Raises:
            NotFittedError: If :meth:`fit` has not been called yet.
        """
        raise NotImplementedError

    def fit_predict(self, series: Series, steps: int) -> Series:
        """Fit the model and immediately generate forecasts.

        Convenience method that calls :meth:`fit` then :meth:`predict`.

        Parameters:
            series: A Series of numeric values in chronological order.
            steps: Number of future periods to predict.

        Returns:
            A Series of length *steps* with the forecasted values.
        """
        self.fit(series)
        return self.predict(steps)

    def evaluate(self, actual: Series, predicted: Series) -> dict[str, float]:
        """Compute all accuracy metrics between actual and predicted values.

        Returns a dict with: rmse, mae, mape, smape, r_squared, bias.

        Parameters:
            actual: The true observed values.
            predicted: The model's predictions (same length as actual).
        """
        return all_metrics(actual, predicted)

    def _check_fitted(self) -> None:
        """Raise NotFittedError if the model has not been fitted."""
        if not self.fitted:
            raise NotFittedError(
                f"{self.name} has not been fitted yet. Call fit() first."
            )

    def _extract_values(self, series: Series) -> list[float]:
        """Extract non-NA float values from a Series."""
        from goliath_utils.atrax import is_na

        values: list[float] = []
        for v in series.values:
            if v is None or is_na(v):
                values.append(0.0)  # fill gaps with 0 for time series
            else:
                values.append(float(v))
        return values

    def __repr__(self) -> str:
        return f"<{self.name}>"
