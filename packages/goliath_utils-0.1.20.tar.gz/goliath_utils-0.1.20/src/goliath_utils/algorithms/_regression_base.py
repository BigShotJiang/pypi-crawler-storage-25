"""Base regressor interface and pure-Python matrix math.

All regression algorithms inherit from :class:`BaseRegressor`.  The matrix
operations (multiply, transpose, inverse) are implemented here in pure
Python so that OLS, Ridge, and Polynomial regression work without numpy.

Lifecycle:

1. **Create** — instantiate with hyperparameters
2. **Fit** — call ``fit(X, y)`` with feature matrix and target values
3. **Predict** — call ``predict(X)`` to get predicted target values
4. **Evaluate** — call ``evaluate(y_actual, y_predicted)`` for metrics

X can be ``list[list[float]]`` or a ``DataSet``.
y can be ``list[float]`` or a ``Series``.
"""

from __future__ import annotations

import math
from typing import Any

from goliath_utils.atrax import DataSet, Series
from ._errors import NotFittedError, InsufficientDataError, AlgorithmError
from ._metrics import all_metrics, r_squared


class BaseRegressor:
    """Abstract base class for all regression algorithms.

    Subclasses must implement :meth:`fit` and :meth:`predict`.

    Attributes:
        name: Human-readable name (e.g. ``"LinearRegression"``).
        fitted: Whether :meth:`fit` has been called.
        coefficients: Fitted coefficients (one per feature).
        intercept: Fitted intercept (bias term).
    """

    name: str = "BaseRegressor"

    def __init__(self):
        self.fitted = False
        self.coefficients: list[float] = []
        self.intercept: float = 0.0

    def fit(self, X: Any, y: Any) -> None:
        """Fit the model to training data.

        Parameters:
            X: Feature matrix — ``list[list[float]]`` or ``DataSet``.
            y: Target values — ``list[float]`` or ``Series``.
        """
        raise NotImplementedError

    def predict(self, X: Any) -> Series:
        """Predict target values for new data.

        Parameters:
            X: Feature matrix in the same format as training data.

        Returns:
            A Series of predicted values.
        """
        raise NotImplementedError

    def fit_predict(self, X: Any, y: Any) -> Series:
        """Fit and predict on the same data."""
        self.fit(X, y)
        return self.predict(X)

    def evaluate(self, y_actual: Any, y_predicted: Any) -> dict[str, float]:
        """Compute all regression metrics.

        Returns a dict with: rmse, mae, mape, smape, r_squared, bias.
        """
        return all_metrics(y_actual, y_predicted)

    def score(self, X: Any, y: Any) -> float:
        """Predict on X and return R² against y.

        Convenience method for quick model evaluation.
        """
        self._check_fitted()
        pred = self.predict(X)
        return r_squared(y, pred)

    def _check_fitted(self) -> None:
        if not self.fitted:
            raise NotFittedError(
                f"{self.name} has not been fitted yet. Call fit() first."
            )

    @staticmethod
    def _to_matrix(X: Any) -> list[list[float]]:
        """Convert input to a list of float vectors."""
        if isinstance(X, DataSet):
            rows: list[list[float]] = []
            for i in range(len(X.index)):
                row = [float(X[c].values[i] or 0) for c in X.columns]
                rows.append(row)
            return rows
        return [[float(v) for v in row] for row in X]

    @staticmethod
    def _to_vector(y: Any) -> list[float]:
        """Convert target to a list of floats."""
        if isinstance(y, Series):
            return [float(v) if v is not None else 0.0 for v in y.values]
        return [float(v) for v in y]

    # ── Pure Python matrix operations ────────────────────────────────

    @staticmethod
    def _mat_transpose(A: list[list[float]]) -> list[list[float]]:
        """Transpose a matrix."""
        if not A:
            return []
        rows, cols = len(A), len(A[0])
        return [[A[i][j] for i in range(rows)] for j in range(cols)]

    @staticmethod
    def _mat_mul(A: list[list[float]], B: list[list[float]]) -> list[list[float]]:
        """Multiply two matrices."""
        rows_a, cols_a = len(A), len(A[0])
        rows_b, cols_b = len(B), len(B[0])
        if cols_a != rows_b:
            raise AlgorithmError(
                f"Matrix dimensions don't match: {rows_a}x{cols_a} * {rows_b}x{cols_b}"
            )
        result = [[0.0] * cols_b for _ in range(rows_a)]
        for i in range(rows_a):
            for j in range(cols_b):
                s = 0.0
                for k in range(cols_a):
                    s += A[i][k] * B[k][j]
                result[i][j] = s
        return result

    @staticmethod
    def _mat_vec_mul(A: list[list[float]], v: list[float]) -> list[float]:
        """Multiply a matrix by a column vector."""
        return [sum(A[i][j] * v[j] for j in range(len(v))) for i in range(len(A))]

    @staticmethod
    def _mat_inverse(A: list[list[float]]) -> list[list[float]]:
        """Invert a square matrix using Gauss-Jordan elimination.

        Raises AlgorithmError if the matrix is singular.
        """
        n = len(A)
        # Augment with identity
        aug = [row[:] + [1.0 if i == j else 0.0 for j in range(n)] for i, row in enumerate(A)]

        for col in range(n):
            # Partial pivoting
            max_row = col
            for row in range(col + 1, n):
                if abs(aug[row][col]) > abs(aug[max_row][col]):
                    max_row = row
            aug[col], aug[max_row] = aug[max_row], aug[col]

            pivot = aug[col][col]
            if abs(pivot) < 1e-12:
                raise AlgorithmError("Matrix is singular — cannot invert")

            # Scale pivot row
            for j in range(2 * n):
                aug[col][j] /= pivot

            # Eliminate column
            for row in range(n):
                if row == col:
                    continue
                factor = aug[row][col]
                for j in range(2 * n):
                    aug[row][j] -= factor * aug[col][j]

        return [row[n:] for row in aug]

    @staticmethod
    def _add_intercept_column(X: list[list[float]]) -> list[list[float]]:
        """Prepend a column of 1s for the intercept term."""
        return [[1.0] + row for row in X]

    def __repr__(self) -> str:
        return f"<{self.name}>"
