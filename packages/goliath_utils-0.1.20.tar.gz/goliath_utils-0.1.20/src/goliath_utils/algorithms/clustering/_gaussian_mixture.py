"""Gaussian Mixture Model (GMM) — soft clustering via EM algorithm.

Unlike K-Means which makes hard assignments, GMM computes the *probability*
that each point belongs to each cluster.  Each cluster is modeled as a
Gaussian (normal) distribution with its own mean and variance.

**How it works (Expectation-Maximization):**

1. Initialize: random means, equal variances, equal mixture weights
2. **E-step:** for each point, compute P(cluster k | point) using Bayes' rule
3. **M-step:** recompute each cluster's mean, variance, and weight using
   the soft assignments from the E-step
4. Repeat until convergence (log-likelihood stops improving)

Note: This is a **diagonal covariance** implementation (features are assumed
independent within each cluster).  This keeps it simple and fast for the
common case of normalized feature vectors.

**Strengths:** Soft assignments (probabilities), handles overlapping clusters,
probabilistic framework.
**Weaknesses:** Assumes Gaussian clusters, sensitive to initialization,
can converge to local optima.

**When to use:** When clusters overlap and you want probability memberships.
"""

from __future__ import annotations

import math
import random

from goliath_utils.atrax import Series
from .._clustering_base import BaseClusterer
from .._errors import InsufficientDataError


class GaussianMixture(BaseClusterer):
    """Gaussian Mixture Model with diagonal covariance.

    Parameters:
        n_clusters: Number of Gaussian components.
        max_iter: Maximum EM iterations.  Default 100.
        tol: Convergence tolerance on log-likelihood change.  Default 1e-6.
        random_seed: Seed for reproducible initialization.

    Attributes:
        weights: Mixture weights (sum to 1.0).
        means: Mean of each component (list of lists).
        variances: Variance of each component per dimension.
        responsibilities: After fit, the soft assignment matrix
                          (n_points × n_clusters).

    Example::

        gmm = GaussianMixture(n_clusters=2, random_seed=42)
        labels = gmm.fit_predict([[1,1],[1.5,1],[1,1.5], [8,8],[8.5,8],[8,8.5]])
        print(gmm.weights)           # [0.5, 0.5]
        print(gmm.responsibilities)  # soft assignments
    """

    def __init__(
        self,
        n_clusters: int = 3,
        max_iter: int = 100,
        tol: float = 1e-6,
        random_seed: int | None = None,
    ):
        super().__init__()
        self._k = n_clusters
        self.max_iter = max_iter
        self.tol = tol
        self.random_seed = random_seed
        self.weights: list[float] = []
        self.means: list[list[float]] = []
        self.variances: list[list[float]] = []
        self.responsibilities: list[list[float]] = []
        self.name = f"GMM(k={n_clusters})"

    def fit(self, data) -> None:
        """Run the EM algorithm.

        Parameters:
            data: ``list[list[float]]`` or ``DataSet``.

        Raises:
            InsufficientDataError: If fewer points than clusters.
        """
        points = self._to_points(data)
        n = len(points)
        k = self._k
        if n < k:
            raise InsufficientDataError(
                f"GMM(k={k}) requires at least {k} points, got {n}"
            )

        dims = len(points[0])
        if self.random_seed is not None:
            random.seed(self.random_seed)

        # Initialize
        indices = random.sample(range(n), k)
        self.means = [list(points[i]) for i in indices]
        self.variances = [[1.0] * dims for _ in range(k)]
        self.weights = [1.0 / k] * k

        prev_ll = float("-inf")

        for iteration in range(self.max_iter):
            # E-step: compute responsibilities
            resp = [[0.0] * k for _ in range(n)]
            for i in range(n):
                probs = []
                for j in range(k):
                    p = self.weights[j] * self._gaussian_pdf(
                        points[i], self.means[j], self.variances[j]
                    )
                    probs.append(p)
                total = sum(probs)
                if total > 0:
                    resp[i] = [p / total for p in probs]
                else:
                    resp[i] = [1.0 / k] * k

            # M-step: update parameters
            for j in range(k):
                n_k = sum(resp[i][j] for i in range(n))
                if n_k < 1e-10:
                    continue

                self.weights[j] = n_k / n

                # Update mean
                self.means[j] = [
                    sum(resp[i][j] * points[i][d] for i in range(n)) / n_k
                    for d in range(dims)
                ]

                # Update variance (diagonal)
                self.variances[j] = [
                    max(
                        sum(resp[i][j] * (points[i][d] - self.means[j][d]) ** 2
                            for i in range(n)) / n_k,
                        1e-6,  # floor to avoid zero variance
                    )
                    for d in range(dims)
                ]

            # Check convergence via log-likelihood
            ll = 0.0
            for i in range(n):
                p = sum(
                    self.weights[j] * self._gaussian_pdf(
                        points[i], self.means[j], self.variances[j]
                    )
                    for j in range(k)
                )
                ll += math.log(max(p, 1e-300))

            if abs(ll - prev_ll) < self.tol:
                break
            prev_ll = ll

        self.responsibilities = resp
        self.labels = [max(range(k), key=lambda j: resp[i][j]) for i in range(n)]
        self.centroids = [list(m) for m in self.means]
        self.n_clusters = k
        self.fitted = True

    def predict(self, data) -> Series:
        """Assign new points to the most probable component."""
        self._check_fitted()
        points = self._to_points(data)
        labels: list[int] = []
        for point in points:
            probs = [
                self.weights[j] * self._gaussian_pdf(
                    point, self.means[j], self.variances[j]
                )
                for j in range(self._k)
            ]
            labels.append(max(range(self._k), key=lambda j: probs[j]))
        return Series(labels)

    @staticmethod
    def _gaussian_pdf(
        x: list[float], mean: list[float], var: list[float]
    ) -> float:
        """Compute the diagonal Gaussian probability density."""
        dims = len(x)
        log_p = -0.5 * dims * math.log(2 * math.pi)
        for d in range(dims):
            v = max(var[d], 1e-10)
            log_p -= 0.5 * math.log(v)
            log_p -= 0.5 * ((x[d] - mean[d]) ** 2) / v
        return math.exp(max(log_p, -700))  # clamp to avoid underflow
