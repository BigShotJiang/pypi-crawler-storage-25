"""K-Medoids (PAM) clustering — robust to outliers.

Like K-Means but cluster centers (medoids) are always actual data points,
not computed means.  This makes K-Medoids much more robust to outliers.

**How it works (PAM — Partitioning Around Medoids):**

1. Initialize by selecting *k* random points as medoids
2. **Assign:** each point → nearest medoid
3. **Swap:** for each medoid, try swapping it with each non-medoid point.
   Keep the swap if it reduces the total distance (cost).
4. Repeat until no improvement

**Strengths:** Robust to outliers (means can be pulled by extremes,
medoids can't).  Cluster centers are interpretable (they're real data points).
**Weaknesses:** Slower than K-Means (O(k*n²) per iteration).

**When to use:** When your data has outliers that would distort K-Means
centroids.  Good for cashier risk metrics where a few extreme values
shouldn't move the cluster center.
"""

from __future__ import annotations

import random

from goliath_utils.atrax import Series
from .._clustering_base import BaseClusterer
from .._errors import InsufficientDataError


class KMedoids(BaseClusterer):
    """K-Medoids (PAM) clustering.

    Parameters:
        n_clusters: Number of clusters to form.
        max_iter: Maximum swap iterations.  Default 100.
        random_seed: Seed for reproducible initialization.

    Example::

        km = KMedoids(n_clusters=3, random_seed=42)
        labels = km.fit_predict([[1,1],[2,1],[1,2], [8,8],[9,8],[8,9]])
        print(km.centroids)  # actual data points, not means
    """

    def __init__(
        self,
        n_clusters: int = 3,
        max_iter: int = 100,
        random_seed: int | None = None,
    ):
        super().__init__()
        self._k = n_clusters
        self.max_iter = max_iter
        self.random_seed = random_seed
        self.name = f"KMedoids(k={n_clusters})"

    def fit(self, data) -> None:
        """Run PAM clustering.

        Parameters:
            data: ``list[list[float]]`` or ``DataSet``.

        Raises:
            InsufficientDataError: If fewer points than clusters.
        """
        points = self._to_points(data)
        n = len(points)
        if n < self._k:
            raise InsufficientDataError(
                f"KMedoids(k={self._k}) requires at least {self._k} points, got {n}"
            )

        if self.random_seed is not None:
            random.seed(self.random_seed)

        # Initialize medoid indices
        medoid_indices = random.sample(range(n), self._k)

        # Precompute distance matrix
        dist = [[0.0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n):
                d = self._euclidean(points[i], points[j])
                dist[i][j] = d
                dist[j][i] = d

        def _total_cost(medoids: list[int]) -> float:
            return sum(min(dist[i][m] for m in medoids) for i in range(n))

        best_cost = _total_cost(medoid_indices)

        for _ in range(self.max_iter):
            improved = False
            for mi, m in enumerate(medoid_indices):
                for candidate in range(n):
                    if candidate in medoid_indices:
                        continue
                    # Try swapping medoid m with candidate
                    new_medoids = list(medoid_indices)
                    new_medoids[mi] = candidate
                    new_cost = _total_cost(new_medoids)
                    if new_cost < best_cost:
                        medoid_indices = new_medoids
                        best_cost = new_cost
                        improved = True
                        break
                if improved:
                    break
            if not improved:
                break

        # Assign labels
        self.labels = [
            min(range(self._k), key=lambda ki: dist[i][medoid_indices[ki]])
            for i in range(n)
        ]
        self.centroids = [list(points[m]) for m in medoid_indices]
        self.n_clusters = self._k
        self.fitted = True

    def predict(self, data) -> Series:
        """Assign new points to nearest medoid."""
        self._check_fitted()
        points = self._to_points(data)
        return Series([self._nearest_centroid(p, self.centroids) for p in points])
