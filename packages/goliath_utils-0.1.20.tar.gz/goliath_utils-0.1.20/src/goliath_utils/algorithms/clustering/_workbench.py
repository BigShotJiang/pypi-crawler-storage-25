"""ClusteringWorkbench — orchestrator for clustering workflows.

Loads data from the Goliath ``sales`` table, runs multiple clustering
algorithms, and compares their quality using silhouette scores.

Example::

    from goliath_utils.algorithms.clustering import ClusteringWorkbench

    wb = ClusteringWorkbench()
    results = wb.cluster_stores(
        store_ids=[111, 1185, 1397, 200, 305],
        start_date="2026-01-01",
        end_date="2026-03-21",
        n_clusters=3,
    )
    print(results)  # DataSet with store_id, cluster label, features
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import DataSet, Series
from .._clustering_base import BaseClusterer
from .._errors import AlgorithmError, InsufficientDataError
from .._metrics import silhouette_score, inertia, cluster_sizes


def _default_clusterers(k: int = 3) -> list[BaseClusterer]:
    """Return one instance of each built-in clusterer."""
    from ._kmeans import KMeans
    from ._kmedoids import KMedoids
    from ._hierarchical import HierarchicalClustering
    from ._dbscan_cluster import DBSCANClustering
    from ._gaussian_mixture import GaussianMixture

    return [
        KMeans(n_clusters=k, random_seed=42),
        KMedoids(n_clusters=k, random_seed=42),
        HierarchicalClustering(n_clusters=k, linkage="average"),
        DBSCANClustering(),
        GaussianMixture(n_clusters=k, random_seed=42),
    ]


class ClusteringWorkbench:
    """High-level clustering workbench for Goliath data.

    Parameters:
        db: A :class:`~goliath_utils.db.Database` instance.  If ``None``,
            calls ``get_db()`` to create one.

    Example::

        wb = ClusteringWorkbench()
        result = wb.cluster_stores([111, 1185, 1397], "2026-01-01", "2026-03-21")
    """

    def __init__(self, db: Any = None):
        if db is None:
            from goliath_utils.db import get_db
            db = get_db()
        self.db = db

    def load_store_features(
        self,
        store_ids: list[int],
        start_date: str,
        end_date: str,
    ) -> DataSet:
        """Load per-store aggregated features from the sales table.

        Returns a DataSet with columns: storeid, store_name, total_sales,
        total_qty, days_active, transaction_count, avg_daily_sales, avg_daily_qty.

        Parameters:
            store_ids: Store IDs to include.
            start_date: Start date (inclusive).
            end_date: End date (inclusive).
        """
        sql = """
            SELECT storeid, store_name,
                   SUM(total_sales) AS total_sales,
                   SUM(qty) AS total_qty,
                   COUNT(DISTINCT sale_date::date) AS days_active,
                   COUNT(DISTINCT sale_id) AS transaction_count,
                   SUM(total_sales) / NULLIF(COUNT(DISTINCT sale_date::date), 0) AS avg_daily_sales,
                   SUM(qty) / NULLIF(COUNT(DISTINCT sale_date::date), 0) AS avg_daily_qty
            FROM sales
            WHERE storeid = ANY(:store_ids)
              AND sale_date BETWEEN :start_date AND :end_date
              AND sale_type IN ('Refunded', 'Sale')
              AND item_ring_type IN ('ITEM', 'SUBD')
            GROUP BY storeid, store_name
            ORDER BY storeid
        """
        rows = self.db.fetch_all(sql, {
            "store_ids": store_ids,
            "start_date": start_date,
            "end_date": end_date,
        })
        if not rows:
            raise InsufficientDataError("No sales data found for the given stores/dates.")
        return DataSet(rows)

    def run_all(
        self,
        data: list[list[float]],
        clusterers: list[BaseClusterer] | None = None,
        n_clusters: int = 3,
    ) -> DataSet:
        """Run multiple clustering algorithms and compare quality.

        Parameters:
            data: List of feature vectors (one per data point).
            clusterers: List of clusterer instances.  ``None`` for all defaults.
            n_clusters: Number of clusters (used for default clusterers).

        Returns:
            A DataSet with one row per algorithm and columns: algorithm,
            n_clusters, silhouette, inertia, cluster_sizes.
        """
        if clusterers is None:
            clusterers = _default_clusterers(n_clusters)

        results: list[dict] = []
        for cl in clusterers:
            try:
                cl.fit(data)
                sil = silhouette_score(data, cl.labels)
                ine = inertia(data, cl.labels, cl.centroids) if cl.centroids else float("nan")
                sizes = cluster_sizes(cl.labels)
                results.append({
                    "algorithm": cl.name,
                    "n_clusters": cl.n_clusters,
                    "silhouette": round(sil, 4),
                    "inertia": round(ine, 2),
                    "cluster_sizes": str(sizes),
                })
            except (InsufficientDataError, AlgorithmError) as e:
                results.append({
                    "algorithm": cl.name,
                    "n_clusters": 0,
                    "silhouette": float("nan"),
                    "inertia": float("nan"),
                    "error": str(e),
                })

        return DataSet(results)

    def cluster_stores(
        self,
        store_ids: list[int],
        start_date: str,
        end_date: str,
        n_clusters: int = 3,
        algorithm: str = "kmeans",
    ) -> DataSet:
        """Full pipeline: load store features, cluster, return annotated results.

        Parameters:
            store_ids: Store IDs to cluster.
            start_date: Start date.
            end_date: End date.
            n_clusters: Number of clusters.
            algorithm: Which algorithm — ``"kmeans"``, ``"kmedoids"``,
                       ``"hierarchical"``, ``"dbscan"``, or ``"gmm"``.

        Returns:
            The store features DataSet with an added ``cluster`` column.
        """
        ds = self.load_store_features(store_ids, start_date, end_date)

        # Extract numeric features for clustering
        feature_cols = ["total_sales", "total_qty", "days_active",
                        "transaction_count", "avg_daily_sales", "avg_daily_qty"]
        available = [c for c in feature_cols if c in ds.columns]
        points = []
        for i in range(len(ds.index)):
            row = [float(ds[c].values[i] or 0) for c in available]
            points.append(row)

        # Normalize features (min-max) so they're on comparable scales
        if points:
            dims = len(points[0])
            for d in range(dims):
                vals = [p[d] for p in points]
                lo, hi = min(vals), max(vals)
                rng = hi - lo if hi != lo else 1.0
                for p in points:
                    p[d] = (p[d] - lo) / rng

        clusterer = self._get_algorithm(algorithm, n_clusters)
        clusterer.fit(points)

        ds["cluster"] = clusterer.labels
        return ds

    def elbow_plot(
        self,
        data: list[list[float]],
        max_k: int = 10,
    ) -> DataSet:
        """Run K-Means for k=2..max_k and return inertia per k.

        Use this to find the optimal number of clusters via the "elbow method":
        plot k vs inertia and look for the point where adding more clusters
        stops significantly reducing inertia.

        Parameters:
            data: Feature vectors.
            max_k: Maximum k to test.

        Returns:
            A DataSet with columns: k, inertia, silhouette.
        """
        from ._kmeans import KMeans

        results: list[dict] = []
        for k in range(2, max_k + 1):
            if k > len(data):
                break
            km = KMeans(n_clusters=k, random_seed=42)
            km.fit(data)
            ine = inertia(data, km.labels, km.centroids)
            sil = silhouette_score(data, km.labels)
            results.append({
                "k": k,
                "inertia": round(ine, 2),
                "silhouette": round(sil, 4),
            })
        return DataSet(results)

    @staticmethod
    def _get_algorithm(name: str, k: int) -> BaseClusterer:
        """Instantiate a clusterer by name."""
        from ._kmeans import KMeans
        from ._kmedoids import KMedoids
        from ._hierarchical import HierarchicalClustering
        from ._dbscan_cluster import DBSCANClustering
        from ._gaussian_mixture import GaussianMixture

        algos = {
            "kmeans": lambda: KMeans(n_clusters=k, random_seed=42),
            "kmedoids": lambda: KMedoids(n_clusters=k, random_seed=42),
            "hierarchical": lambda: HierarchicalClustering(n_clusters=k),
            "dbscan": lambda: DBSCANClustering(),
            "gmm": lambda: GaussianMixture(n_clusters=k, random_seed=42),
        }
        if name not in algos:
            raise AlgorithmError(
                f"Unknown algorithm {name!r}. Choose from: {', '.join(algos)}"
            )
        return algos[name]()
