"""Unsupervised clustering algorithms — pure Python, zero dependencies.

All clusterers share a common interface inherited from
:class:`~goliath_utils.algorithms.BaseClusterer`:

- ``fit(data)`` — assign data points to clusters
- ``predict(data)`` — assign new points to existing clusters
- ``fit_predict(data)`` — fit and return labels in one call
- ``summary()`` — cluster statistics (size, centroid)

Available clusterers:

+---------------------------+-----------------------------------------------+
| Algorithm                 | Best for                                      |
+===========================+===============================================+
| ``KMeans``                | General purpose, fast, known k                |
+---------------------------+-----------------------------------------------+
| ``KMedoids``              | Robust to outliers (uses real points as centers)|
+---------------------------+-----------------------------------------------+
| ``HierarchicalClustering``| Exploring different k values, small datasets  |
+---------------------------+-----------------------------------------------+
| ``DBSCANClustering``      | Unknown k, arbitrary cluster shapes           |
+---------------------------+-----------------------------------------------+
| ``GaussianMixture``       | Overlapping clusters, soft membership         |
+---------------------------+-----------------------------------------------+

The :class:`ClusteringWorkbench` loads store/product features from the
Goliath ``sales`` table and clusters them.
"""

from ._kmeans import KMeans
from ._kmedoids import KMedoids
from ._hierarchical import HierarchicalClustering
from ._dbscan_cluster import DBSCANClustering
from ._gaussian_mixture import GaussianMixture
from ._workbench import ClusteringWorkbench

__all__ = [
    "KMeans",
    "KMedoids",
    "HierarchicalClustering",
    "DBSCANClustering",
    "GaussianMixture",
    "ClusteringWorkbench",
]
