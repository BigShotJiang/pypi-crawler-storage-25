"""DBSCAN clustering — density-based, no need to specify k.

Unlike K-Means, DBSCAN discovers the number of clusters automatically
based on data density.  Points in sparse regions are labeled as noise (-1).

**How it works:**

1. For each point, find all neighbours within distance *eps*
2. Core points: have >= *min_samples* neighbours
3. BFS from core points to form clusters
4. Non-core points reachable from a core point join its cluster
5. Unreachable points are noise (label = -1)

**Strengths:** Finds arbitrary-shaped clusters, automatically determines k,
identifies noise points.
**Weaknesses:** Sensitive to *eps* — too small fragments clusters, too
large merges everything.  Struggles with varying-density clusters.

**When to use:** When you don't know how many clusters exist, or when
clusters have irregular shapes.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._clustering_base import BaseClusterer
from .._errors import InsufficientDataError


class DBSCANClustering(BaseClusterer):
    """DBSCAN density-based clustering (multivariate).

    Parameters:
        eps: Maximum distance between two points to be neighbours.
             Default ``None`` — auto-computed from the data.
        min_samples: Minimum neighbours to form a dense region.  Default 5.

    Attributes:
        noise_indices: List of point indices labeled as noise (-1).

    Example::

        db = DBSCANClustering(eps=2.0, min_samples=2)
        labels = db.fit_predict([[1,1],[1.5,1],[1,1.5], [10,10],[10.5,10], [100,100]])
        print(labels.values)  # [0,0,0, 1,1, -1]  (100,100 is noise)
    """

    def __init__(self, eps: float | None = None, min_samples: int = 5):
        super().__init__()
        self.eps = eps
        self.min_samples = min_samples
        self._auto_eps: float = 0.0
        self.noise_indices: list[int] = []
        self.name = f"DBSCAN(eps={eps},min={min_samples})"

    def fit(self, data) -> None:
        """Run DBSCAN clustering.

        Parameters:
            data: ``list[list[float]]`` or ``DataSet``.

        Raises:
            InsufficientDataError: If fewer than min_samples points.
        """
        points = self._to_points(data)
        n = len(points)
        if n < self.min_samples:
            raise InsufficientDataError(
                f"DBSCAN requires at least {self.min_samples} points, got {n}"
            )

        # Auto-compute eps if not set
        if self.eps is None:
            # Use mean nearest-neighbour distance as heuristic
            nn_dists: list[float] = []
            for i in range(n):
                dists = sorted(
                    self._euclidean(points[i], points[j])
                    for j in range(n) if j != i
                )
                if dists:
                    nn_dists.append(dists[0])
            self._auto_eps = sum(nn_dists) / len(nn_dists) * 2 if nn_dists else 1.0
            self.name = f"DBSCAN(eps={self._auto_eps:.2f},min={self.min_samples})"
        else:
            self._auto_eps = self.eps

        eps = self._auto_eps

        # Find neighbours
        neighbours: list[list[int]] = []
        for i in range(n):
            nb = [j for j in range(n) if self._euclidean(points[i], points[j]) <= eps]
            neighbours.append(nb)

        core = [len(nb) >= self.min_samples for nb in neighbours]

        # BFS clustering
        labels = [-1] * n
        cluster_id = 0

        for i in range(n):
            if labels[i] != -1 or not core[i]:
                continue
            queue = [i]
            labels[i] = cluster_id
            while queue:
                current = queue.pop(0)
                for nb_idx in neighbours[current]:
                    if labels[nb_idx] != -1:
                        continue
                    labels[nb_idx] = cluster_id
                    if core[nb_idx]:
                        queue.append(nb_idx)
            cluster_id += 1

        self.labels = labels
        self.n_clusters = cluster_id
        self.noise_indices = [i for i, l in enumerate(labels) if l == -1]

        # Compute centroids for non-noise clusters
        dims = len(points[0]) if points else 0
        self.centroids = []
        for k in range(cluster_id):
            cluster_points = [points[i] for i in range(n) if labels[i] == k]
            if cluster_points:
                centroid = [
                    sum(p[d] for p in cluster_points) / len(cluster_points)
                    for d in range(dims)
                ]
                self.centroids.append(centroid)

        self.fitted = True

    def predict(self, data) -> Series:
        """Assign new points to nearest cluster (or -1 if too far from all)."""
        self._check_fitted()
        points = self._to_points(data)
        labels: list[int] = []
        for p in points:
            if not self.centroids:
                labels.append(-1)
                continue
            nearest = self._nearest_centroid(p, self.centroids)
            dist = self._euclidean(p, self.centroids[nearest])
            labels.append(nearest if dist <= self._auto_eps else -1)
        return Series(labels)
