"""Agglomerative hierarchical clustering — bottom-up merge approach.

Starts with each point as its own cluster and iteratively merges the two
closest clusters until the desired number of clusters is reached.

**How it works:**

1. Start: each point is a singleton cluster
2. Compute the distance between all pairs of clusters
3. Merge the two closest clusters
4. Repeat until ``n_clusters`` remain

**Linkage methods** control how "distance between clusters" is defined:

- ``"single"`` — minimum distance between any pair of points (one from each cluster)
- ``"complete"`` — maximum distance between any pair of points
- ``"average"`` — mean distance between all pairs of points

**Strengths:** Produces a hierarchy (dendrogram), doesn't need spherical
cluster assumption, deterministic.
**Weaknesses:** O(n³) time, O(n²) memory for the distance matrix.

**When to use:** Smaller datasets where you want to explore different
numbers of clusters without re-running, or when the cluster hierarchy
itself is informative.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._clustering_base import BaseClusterer
from .._errors import InsufficientDataError


class HierarchicalClustering(BaseClusterer):
    """Agglomerative hierarchical clustering.

    Parameters:
        n_clusters: Number of clusters to form.
        linkage: Distance measure between clusters — ``"single"``,
                 ``"complete"``, or ``"average"``.  Default ``"average"``.

    Example::

        hc = HierarchicalClustering(n_clusters=3, linkage="average")
        labels = hc.fit_predict([[1,1],[2,1],[1,2], [8,8],[9,8],[8,9]])
        print(labels.values)
    """

    def __init__(self, n_clusters: int = 3, linkage: str = "average"):
        super().__init__()
        self._k = n_clusters
        self.linkage = linkage
        self.name = f"Hierarchical(k={n_clusters},{linkage})"

    def fit(self, data) -> None:
        """Run agglomerative clustering.

        Parameters:
            data: ``list[list[float]]`` or ``DataSet``.

        Raises:
            InsufficientDataError: If fewer points than clusters.
        """
        points = self._to_points(data)
        n = len(points)
        if n < self._k:
            raise InsufficientDataError(
                f"Hierarchical(k={self._k}) requires at least {self._k} points, got {n}"
            )

        # Each point starts as its own cluster
        # clusters[i] = list of point indices in cluster i
        clusters: dict[int, list[int]] = {i: [i] for i in range(n)}
        next_id = n

        # Precompute point-to-point distances
        pdist = {}
        for i in range(n):
            for j in range(i + 1, n):
                pdist[(i, j)] = self._euclidean(points[i], points[j])
                pdist[(j, i)] = pdist[(i, j)]

        while len(clusters) > self._k:
            # Find the two closest clusters
            best_dist = float("inf")
            best_pair = (0, 0)

            cluster_ids = list(clusters.keys())
            for ci in range(len(cluster_ids)):
                for cj in range(ci + 1, len(cluster_ids)):
                    c1, c2 = cluster_ids[ci], cluster_ids[cj]
                    d = self._cluster_distance(
                        clusters[c1], clusters[c2], pdist
                    )
                    if d < best_dist:
                        best_dist = d
                        best_pair = (c1, c2)

            # Merge
            c1, c2 = best_pair
            merged = clusters[c1] + clusters[c2]
            del clusters[c1]
            del clusters[c2]
            clusters[next_id] = merged
            next_id += 1

        # Assign labels
        self.labels = [0] * n
        label = 0
        centroid_list: list[list[float]] = []
        for cluster_points in clusters.values():
            dims = len(points[0])
            centroid = [
                sum(points[i][d] for i in cluster_points) / len(cluster_points)
                for d in range(dims)
            ]
            centroid_list.append(centroid)
            for i in cluster_points:
                self.labels[i] = label
            label += 1

        self.centroids = centroid_list
        self.n_clusters = label
        self.fitted = True

    def predict(self, data) -> Series:
        """Assign new points to nearest cluster centroid."""
        self._check_fitted()
        points = self._to_points(data)
        return Series([self._nearest_centroid(p, self.centroids) for p in points])

    def _cluster_distance(
        self,
        c1: list[int],
        c2: list[int],
        pdist: dict,
    ) -> float:
        """Compute distance between two clusters using the linkage method."""
        distances = []
        for i in c1:
            for j in c2:
                key = (min(i, j), max(i, j))
                distances.append(pdist.get(key, pdist.get((j, i), 0.0)))

        if not distances:
            return float("inf")

        if self.linkage == "single":
            return min(distances)
        elif self.linkage == "complete":
            return max(distances)
        else:  # average
            return sum(distances) / len(distances)
