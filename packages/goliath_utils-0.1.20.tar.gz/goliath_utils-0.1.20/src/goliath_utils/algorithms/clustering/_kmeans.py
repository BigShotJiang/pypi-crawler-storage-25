"""K-Means clustering — the classic partitioning algorithm.

Partitions data into *k* clusters by iteratively assigning points to the
nearest centroid and recomputing centroids as cluster means.

**How it works (Lloyd's algorithm):**

1. Initialize *k* centroids (random selection from data points)
2. **Assign:** each point → nearest centroid (Euclidean distance)
3. **Update:** recompute each centroid as the mean of its assigned points
4. Repeat steps 2-3 until convergence or max_iter

**Strengths:** Simple, fast, scales well, works on any numeric features.
**Weaknesses:** Must specify *k* upfront, sensitive to initialization
and outliers, assumes roughly spherical clusters.

**When to use:** Grouping stores by sales metrics, product segmentation,
customer tiers — any situation where you know (or can estimate) the
number of groups.
"""

from __future__ import annotations

import random

from goliath_utils.atrax import Series
from .._clustering_base import BaseClusterer
from .._errors import InsufficientDataError


class KMeans(BaseClusterer):
    """K-Means clustering.

    Parameters:
        n_clusters: Number of clusters to form.
        max_iter: Maximum iterations.  Default 100.
        random_seed: Seed for reproducible centroid initialization.

    Example::

        km = KMeans(n_clusters=3, random_seed=42)
        labels = km.fit_predict([[1,1],[2,1],[1,2], [8,8],[9,8],[8,9]])
        print(labels.values)  # [0,0,0, 1,1,1]
        print(km.centroids)
    """

    def __init__(
        self,
        n_clusters: int = 3,
        max_iter: int = 100,
        random_seed: int | None = None,
    ):
        super().__init__()
        self._k = n_clusters
        self.max_iter = max_iter
        self.random_seed = random_seed
        self.name = f"KMeans(k={n_clusters})"

    def fit(self, data) -> None:
        """Run K-Means clustering on the data.

        Parameters:
            data: ``list[list[float]]`` or ``DataSet`` with numeric columns.

        Raises:
            InsufficientDataError: If fewer points than clusters.
        """
        points = self._to_points(data)
        n = len(points)
        if n < self._k:
            raise InsufficientDataError(
                f"KMeans(k={self._k}) requires at least {self._k} data points, got {n}"
            )

        if self.random_seed is not None:
            random.seed(self.random_seed)

        # Initialize centroids by random selection
        indices = random.sample(range(n), self._k)
        centroids = [list(points[i]) for i in indices]

        labels = [0] * n
        for _ in range(self.max_iter):
            # Assign
            new_labels = [self._nearest_centroid(p, centroids) for p in points]

            # Check convergence
            if new_labels == labels:
                break
            labels = new_labels

            # Update centroids
            dims = len(points[0])
            for k in range(self._k):
                cluster_points = [points[i] for i in range(n) if labels[i] == k]
                if cluster_points:
                    centroids[k] = [
                        sum(p[d] for p in cluster_points) / len(cluster_points)
                        for d in range(dims)
                    ]

        self.labels = labels
        self.centroids = centroids
        self.n_clusters = self._k
        self.fitted = True

    def predict(self, data) -> Series:
        """Assign new points to the nearest existing centroid.

        Parameters:
            data: New data in the same feature space.

        Returns:
            Series of cluster labels.
        """
        self._check_fitted()
        points = self._to_points(data)
        return Series([self._nearest_centroid(p, self.centroids) for p in points])
