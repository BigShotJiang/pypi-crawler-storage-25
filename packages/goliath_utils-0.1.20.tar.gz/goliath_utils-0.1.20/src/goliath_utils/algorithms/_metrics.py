"""Forecast accuracy metrics — pure Python, zero dependencies.

All metric functions take two aligned lists or Series (actual, predicted)
and return a single float.  ``all_metrics()`` returns every metric in one call.

These metrics are shared across all algorithm types (forecasting, regression,
anomaly detection, etc.).  Each function automatically filters out NaN/None
pairs before computing.

Available metrics:

+----------------+-----------------------------------------------------------+-------------+
| Function       | Description                                               | Ideal value |
+================+===========================================================+=============+
| ``rmse()``     | Root Mean Squared Error — penalises large errors          | 0           |
+----------------+-----------------------------------------------------------+-------------+
| ``mae()``      | Mean Absolute Error — average error magnitude             | 0           |
+----------------+-----------------------------------------------------------+-------------+
| ``mape()``     | Mean Absolute Percentage Error (%)                        | 0%          |
+----------------+-----------------------------------------------------------+-------------+
| ``smape()``    | Symmetric MAPE (%) — handles zeros better than MAPE      | 0%          |
+----------------+-----------------------------------------------------------+-------------+
| ``r_squared()``| Coefficient of determination — variance explained         | 1.0         |
+----------------+-----------------------------------------------------------+-------------+
| ``bias()``     | Mean forecast bias — positive = over-forecasting          | 0           |
+----------------+-----------------------------------------------------------+-------------+

Example::

    from goliath_utils.atrax import Series
    from goliath_utils.algorithms import all_metrics

    actual = Series([100, 200, 300, 400, 500])
    predicted = Series([110, 190, 310, 380, 520])
    print(all_metrics(actual, predicted))
    # {'rmse': 14.14, 'mae': 12.0, 'mape': 4.53, ...}
"""

from __future__ import annotations

import math
from typing import Any, Sequence


def _to_lists(
    actual: Any, predicted: Any
) -> tuple[list[float], list[float]]:
    """Coerce inputs to plain lists, filtering out paired NaN/None."""
    a = list(actual.values) if hasattr(actual, "values") else list(actual)
    p = list(predicted.values) if hasattr(predicted, "values") else list(predicted)
    if len(a) != len(p):
        raise ValueError(
            f"Length mismatch: actual has {len(a)} values, predicted has {len(p)}"
        )
    # Filter out pairs where either side is NaN/None
    clean_a: list[float] = []
    clean_p: list[float] = []
    for ai, pi in zip(a, p):
        if ai is None or pi is None:
            continue
        if isinstance(ai, float) and math.isnan(ai):
            continue
        if isinstance(pi, float) and math.isnan(pi):
            continue
        clean_a.append(float(ai))
        clean_p.append(float(pi))
    return clean_a, clean_p


def rmse(actual: Any, predicted: Any) -> float:
    """Root Mean Squared Error.

    Penalises large errors more heavily than MAE.  Lower is better.

    Formula: sqrt(mean((actual - predicted)²))
    """
    a, p = _to_lists(actual, predicted)
    if not a:
        return float("nan")
    sq_errors = [(ai - pi) ** 2 for ai, pi in zip(a, p)]
    return math.sqrt(sum(sq_errors) / len(sq_errors))


def mae(actual: Any, predicted: Any) -> float:
    """Mean Absolute Error.

    Average magnitude of errors regardless of direction.  Lower is better.

    Formula: mean(|actual - predicted|)
    """
    a, p = _to_lists(actual, predicted)
    if not a:
        return float("nan")
    abs_errors = [abs(ai - pi) for ai, pi in zip(a, p)]
    return sum(abs_errors) / len(abs_errors)


def mape(actual: Any, predicted: Any) -> float:
    """Mean Absolute Percentage Error.

    Expressed as a percentage.  Skips data points where actual is zero
    to avoid division by zero.  Lower is better.

    Formula: mean(|actual - predicted| / |actual|) * 100
    """
    a, p = _to_lists(actual, predicted)
    pct_errors: list[float] = []
    for ai, pi in zip(a, p):
        if ai == 0:
            continue
        pct_errors.append(abs(ai - pi) / abs(ai))
    if not pct_errors:
        return float("nan")
    return (sum(pct_errors) / len(pct_errors)) * 100


def smape(actual: Any, predicted: Any) -> float:
    """Symmetric Mean Absolute Percentage Error.

    Handles zero actuals better than MAPE by dividing by the average
    of actual and predicted.  Range: 0% (perfect) to 200%.  Lower is better.

    Formula: mean(2 * |actual - predicted| / (|actual| + |predicted|)) * 100
    """
    a, p = _to_lists(actual, predicted)
    vals: list[float] = []
    for ai, pi in zip(a, p):
        denom = abs(ai) + abs(pi)
        if denom == 0:
            continue
        vals.append(2 * abs(ai - pi) / denom)
    if not vals:
        return float("nan")
    return (sum(vals) / len(vals)) * 100


def r_squared(actual: Any, predicted: Any) -> float:
    """Coefficient of determination (R²).

    Measures how much variance in the actual values is explained by the
    predictions.  1.0 is perfect, 0.0 means the model is no better than
    predicting the mean, negative means worse than the mean.

    Formula: 1 - SS_res / SS_tot
    """
    a, p = _to_lists(actual, predicted)
    if len(a) < 2:
        return float("nan")
    mean_a = sum(a) / len(a)
    ss_tot = sum((ai - mean_a) ** 2 for ai in a)
    ss_res = sum((ai - pi) ** 2 for ai, pi in zip(a, p))
    if ss_tot == 0:
        return float("nan")
    return 1 - (ss_res / ss_tot)


def bias(actual: Any, predicted: Any) -> float:
    """Mean Forecast Bias.

    Positive bias means the model over-forecasts on average.
    Negative bias means under-forecasting.  Zero is ideal.

    Formula: mean(predicted - actual)
    """
    a, p = _to_lists(actual, predicted)
    if not a:
        return float("nan")
    errors = [pi - ai for ai, pi in zip(a, p)]
    return sum(errors) / len(errors)


def all_metrics(actual: Any, predicted: Any) -> dict[str, float]:
    """Compute all forecast accuracy metrics in one call.

    Returns a dict with keys: rmse, mae, mape, smape, r_squared, bias.
    """
    return {
        "rmse": rmse(actual, predicted),
        "mae": mae(actual, predicted),
        "mape": mape(actual, predicted),
        "smape": smape(actual, predicted),
        "r_squared": r_squared(actual, predicted),
        "bias": bias(actual, predicted),
    }


# ---------------------------------------------------------------------------
# Classification / Anomaly Detection Metrics
# ---------------------------------------------------------------------------


def _to_binary_lists(
    actual: Any, predicted: Any
) -> tuple[list[int], list[int]]:
    """Coerce inputs to binary int lists (0 or 1)."""
    a = list(actual.values) if hasattr(actual, "values") else list(actual)
    p = list(predicted.values) if hasattr(predicted, "values") else list(predicted)
    if len(a) != len(p):
        raise ValueError(
            f"Length mismatch: actual has {len(a)} values, predicted has {len(p)}"
        )
    return [int(bool(v)) for v in a], [int(bool(v)) for v in p]


def confusion_matrix(actual: Any, predicted: Any) -> dict[str, int]:
    """Compute the confusion matrix for binary classification.

    Returns a dict with keys: ``tp`` (true positives), ``fp`` (false positives),
    ``tn`` (true negatives), ``fn`` (false negatives).

    Parameters:
        actual: Ground truth binary labels (0/1, True/False).
        predicted: Predicted binary labels.
    """
    a, p = _to_binary_lists(actual, predicted)
    tp = sum(1 for ai, pi in zip(a, p) if ai == 1 and pi == 1)
    fp = sum(1 for ai, pi in zip(a, p) if ai == 0 and pi == 1)
    tn = sum(1 for ai, pi in zip(a, p) if ai == 0 and pi == 0)
    fn = sum(1 for ai, pi in zip(a, p) if ai == 1 and pi == 0)
    return {"tp": tp, "fp": fp, "tn": tn, "fn": fn}


def precision(actual: Any, predicted: Any) -> float:
    """Precision — of all predicted positives, how many are correct?

    Formula: TP / (TP + FP).  Returns 0.0 if no positives were predicted.
    """
    cm = confusion_matrix(actual, predicted)
    denom = cm["tp"] + cm["fp"]
    return cm["tp"] / denom if denom > 0 else 0.0


def recall(actual: Any, predicted: Any) -> float:
    """Recall (sensitivity) — of all actual positives, how many did we catch?

    Formula: TP / (TP + FN).  Returns 0.0 if there are no actual positives.
    """
    cm = confusion_matrix(actual, predicted)
    denom = cm["tp"] + cm["fn"]
    return cm["tp"] / denom if denom > 0 else 0.0


def f1_score(actual: Any, predicted: Any) -> float:
    """F1 Score — harmonic mean of precision and recall.

    Balances the trade-off between catching all anomalies (recall) and
    not crying wolf (precision).  Range: 0.0 (worst) to 1.0 (perfect).
    """
    p = precision(actual, predicted)
    r = recall(actual, predicted)
    if p + r == 0:
        return 0.0
    return 2 * (p * r) / (p + r)


def anomaly_count(scores: Any, threshold: float = 0.5) -> int:
    """Count the number of points scoring above the threshold.

    Parameters:
        scores: Anomaly scores (Series or list of floats).
        threshold: Score cutoff for flagging anomalies.
    """
    vals = list(scores.values) if hasattr(scores, "values") else list(scores)
    return sum(1 for v in vals if v > threshold)


def anomaly_rate(scores: Any, threshold: float = 0.5) -> float:
    """Percentage of points scoring above the threshold.

    Parameters:
        scores: Anomaly scores (Series or list of floats).
        threshold: Score cutoff for flagging anomalies.

    Returns:
        A float between 0.0 and 100.0.
    """
    vals = list(scores.values) if hasattr(scores, "values") else list(scores)
    if not vals:
        return 0.0
    return (sum(1 for v in vals if v > threshold) / len(vals)) * 100


def all_classification_metrics(actual: Any, predicted: Any) -> dict[str, float]:
    """Compute all classification metrics in one call.

    Returns a dict with keys: precision, recall, f1_score, tp, fp, tn, fn.
    """
    cm = confusion_matrix(actual, predicted)
    return {
        "precision": precision(actual, predicted),
        "recall": recall(actual, predicted),
        "f1_score": f1_score(actual, predicted),
        **cm,
    }


# ---------------------------------------------------------------------------
# Clustering Metrics
# ---------------------------------------------------------------------------


def _euclidean(a: list[float], b: list[float]) -> float:
    """Euclidean distance between two points."""
    return math.sqrt(sum((ai - bi) ** 2 for ai, bi in zip(a, b)))


def silhouette_score(
    data: list[list[float]], labels: list[int]
) -> float:
    """Silhouette score — how well-separated are the clusters?

    For each point, computes how similar it is to its own cluster (cohesion)
    versus the nearest other cluster (separation).

    Range: -1 (wrong cluster) to +1 (well-clustered).  0 means overlapping.

    Parameters:
        data: List of data points (each a list of floats).
        labels: Cluster label for each point.

    Returns:
        The mean silhouette score across all points.
    """
    n = len(data)
    if n < 2:
        return 0.0

    unique_labels = sorted(set(labels))
    if len(unique_labels) < 2:
        return 0.0

    scores: list[float] = []
    for i in range(n):
        # a(i) = mean distance to other points in same cluster
        same = [j for j in range(n) if labels[j] == labels[i] and j != i]
        if not same:
            scores.append(0.0)
            continue
        a_i = sum(_euclidean(data[i], data[j]) for j in same) / len(same)

        # b(i) = min mean distance to points in any other cluster
        b_i = float("inf")
        for k in unique_labels:
            if k == labels[i]:
                continue
            others = [j for j in range(n) if labels[j] == k]
            if others:
                mean_dist = sum(_euclidean(data[i], data[j]) for j in others) / len(others)
                b_i = min(b_i, mean_dist)

        if b_i == float("inf"):
            scores.append(0.0)
        else:
            s_i = (b_i - a_i) / max(a_i, b_i) if max(a_i, b_i) > 0 else 0.0
            scores.append(s_i)

    return sum(scores) / len(scores)


def inertia(
    data: list[list[float]],
    labels: list[int],
    centroids: list[list[float]],
) -> float:
    """Inertia — sum of squared distances from each point to its centroid.

    Lower inertia means tighter clusters.  Used for the elbow method:
    plot inertia vs k and look for the "elbow" where adding more clusters
    stops helping.

    Parameters:
        data: List of data points.
        labels: Cluster label for each point.
        centroids: Cluster centers.

    Returns:
        Total inertia (sum of squared distances).
    """
    total = 0.0
    for i, point in enumerate(data):
        c = centroids[labels[i]]
        total += sum((a - b) ** 2 for a, b in zip(point, c))
    return total


def cluster_sizes(labels: list[int]) -> dict[int, int]:
    """Count the number of points in each cluster.

    Parameters:
        labels: Cluster label for each point.

    Returns:
        Dict mapping cluster label to count.
    """
    counts: dict[int, int] = {}
    for l in labels:
        counts[l] = counts.get(l, 0) + 1
    return dict(sorted(counts.items()))
