"""Isolation Forest — pure Python implementation.

Detects anomalies by measuring how easily a data point can be "isolated"
via random partitioning.  Anomalies are few and different, so they get
isolated in fewer splits (shorter path lengths in random trees).

**How it works:**

1. Build *n_trees* random binary trees (isolation trees):
   - Each tree randomly selects a feature and a split value
   - Recursively partition the data until each point is isolated
   - Stop at *max_depth* = ceil(log2(max_samples))
2. For each point, compute its average path length across all trees
3. Anomaly score = ``2^(-avg_path_length / c(n))`` where ``c(n)`` is the
   expected path length in a binary search tree of *n* items

Points with shorter average paths (easier to isolate) get higher anomaly
scores closer to 1.0.  Normal points buried in dense regions get scores
closer to 0.0.

**Strengths:** Handles multivariate data, no distribution assumptions,
scales well, good theoretical foundation (Liu et al., 2008).
**Weaknesses:** Random — results vary slightly between runs.  Less
interpretable than Z-Score ("why is this anomalous?").

**When to use:** Complex anomaly detection where simple statistical methods
aren't enough.  Works on single features (univariate) or multiple features.

Reference: Liu, F.T., Ting, K.M. and Zhou, Z.H., 2008.
Isolation forest. In ICDM.
"""

from __future__ import annotations

import math
import random

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class _IsolationTree:
    """A single isolation tree (internal, not part of the public API)."""

    def __init__(
        self,
        data: list[float],
        max_depth: int,
        depth: int = 0,
    ):
        self.size = len(data)
        self.split_value: float | None = None
        self.left: _IsolationTree | None = None
        self.right: _IsolationTree | None = None
        self.is_leaf = False

        if depth >= max_depth or len(data) <= 1:
            self.is_leaf = True
            return

        lo, hi = min(data), max(data)
        if lo == hi:
            self.is_leaf = True
            return

        self.split_value = lo + random.random() * (hi - lo)
        left_data = [v for v in data if v < self.split_value]
        right_data = [v for v in data if v >= self.split_value]

        # Prevent empty splits
        if not left_data or not right_data:
            self.is_leaf = True
            return

        self.left = _IsolationTree(left_data, max_depth, depth + 1)
        self.right = _IsolationTree(right_data, max_depth, depth + 1)

    def path_length(self, value: float, depth: int = 0) -> float:
        """Compute the path length for a single value."""
        if self.is_leaf:
            return depth + _c(self.size)
        if self.split_value is None:
            return depth
        if value < self.split_value:
            return self.left.path_length(value, depth + 1) if self.left else depth
        else:
            return self.right.path_length(value, depth + 1) if self.right else depth


def _c(n: int) -> float:
    """Expected path length in a binary search tree of n items.

    c(n) = 2 * H(n-1) - 2*(n-1)/n, where H(i) is the harmonic number.
    """
    if n <= 1:
        return 0.0
    if n == 2:
        return 1.0
    h = math.log(n - 1) + 0.5772156649  # Euler-Mascheroni constant
    return 2.0 * h - 2.0 * (n - 1) / n


class IsolationForest(BaseAnomalyDetector):
    """Isolation Forest anomaly detector — pure Python, no sklearn.

    Parameters:
        n_trees: Number of isolation trees to build.  Default 100.
        max_samples: Maximum number of samples to use per tree.  Default 256.
                     If the data has fewer points, all points are used.
        threshold: Anomaly score threshold for binary detection.  Default 0.6.
                   Scores range from ~0.0 (normal) to ~1.0 (anomaly).
        random_seed: Seed for reproducibility.  Default ``None`` (random).

    Example::

        detector = IsolationForest(n_trees=100, threshold=0.6)
        detector.fit(Series([10, 12, 11, 13, 10, 12, 11]))
        scores = detector.predict(Series([10, 100, 11]))
        # score for 100 will be close to 1.0 (easily isolated)
    """

    def __init__(
        self,
        n_trees: int = 100,
        max_samples: int = 256,
        threshold: float = 0.6,
        random_seed: int | None = None,
    ):
        super().__init__(threshold=threshold)
        self.n_trees = n_trees
        self.max_samples = max_samples
        self.random_seed = random_seed
        self._trees: list[_IsolationTree] = []
        self._n_samples: int = 0
        self.name = f"IsolationForest(trees={n_trees})"

    def fit(self, series: Series) -> None:
        """Build the isolation forest from training data.

        Parameters:
            series: Historical data representing normal behaviour.

        Raises:
            InsufficientDataError: If fewer than 4 data points.
        """
        values = self._extract_values(series)
        if len(values) < 4:
            raise InsufficientDataError("IsolationForest requires at least 4 data points")

        if self.random_seed is not None:
            random.seed(self.random_seed)

        self._n_samples = min(len(values), self.max_samples)
        max_depth = int(math.ceil(math.log2(max(self._n_samples, 2))))

        self._trees = []
        for _ in range(self.n_trees):
            sample = random.sample(values, self._n_samples)
            tree = _IsolationTree(sample, max_depth)
            self._trees.append(tree)

        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Compute anomaly scores for each point.

        Scores range from approximately 0 (normal) to 1 (anomaly).
        The score is based on the average path length across all trees.

        Parameters:
            series: Data to score.

        Returns:
            Series of anomaly scores.
        """
        self._check_fitted()
        values = self._extract_values(series)
        c_n = _c(self._n_samples)

        scores: list[float] = []
        for v in values:
            avg_path = sum(t.path_length(v) for t in self._trees) / self.n_trees
            score = 2.0 ** (-avg_path / c_n) if c_n > 0 else 0.5
            scores.append(score)

        return Series(scores)
