"""Unsupervised anomaly detection algorithms — pure Python, zero dependencies.

All detectors share a common interface inherited from
:class:`~goliath_utils.algorithms.BaseAnomalyDetector`:

- ``fit(series)`` — learn what "normal" looks like
- ``predict(series)`` — score each point (higher = more anomalous)
- ``detect(series)`` — return binary True/False labels
- ``fit_predict(series)`` — convenience: fit + score in one call

Available detectors:

+--------------------------+-----------------------------------------------+
| Algorithm                | Best for                                      |
+==========================+===============================================+
| ``ZScoreDetector``       | Quick baseline, daily totals                  |
+--------------------------+-----------------------------------------------+
| ``MADDetector``          | Robust to existing outliers in training data   |
+--------------------------+-----------------------------------------------+
| ``IQRDetector``          | Simple, interpretable (box plot method)       |
+--------------------------+-----------------------------------------------+
| ``RollingZScoreDetector``| Trending or non-stationary data               |
+--------------------------+-----------------------------------------------+
| ``IsolationForest``      | Complex patterns, multivariate data           |
+--------------------------+-----------------------------------------------+
| ``DBSCANDetector``       | Finding outliers in clustered data            |
+--------------------------+-----------------------------------------------+

The :class:`AnomalyWorkbench` loads data from the Goliath ``sales`` table
and runs all detectors in one call.
"""

from ._zscore import ZScoreDetector
from ._mad import MADDetector
from ._iqr import IQRDetector
from ._rolling_zscore import RollingZScoreDetector
from ._isolation_forest import IsolationForest
from ._dbscan import DBSCANDetector
from ._workbench import AnomalyWorkbench

__all__ = [
    "ZScoreDetector",
    "MADDetector",
    "IQRDetector",
    "RollingZScoreDetector",
    "IsolationForest",
    "DBSCANDetector",
    "AnomalyWorkbench",
]
