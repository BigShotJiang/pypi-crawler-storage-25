"""Interquartile Range (IQR) anomaly detector — the box plot method.

Flags points that fall outside the "fences" defined by Q1 and Q3.
This is the same logic used to draw whiskers on a box plot.

**How it works:**

1. Fit: compute ``Q1`` (25th percentile), ``Q3`` (75th percentile), ``IQR = Q3 - Q1``
2. Fences: ``lower = Q1 - k * IQR``, ``upper = Q3 + k * IQR``
3. Score: distance outside the nearest fence (0 if inside)
4. Detect: anomaly if score > 0 (i.e. outside the fences)

**Default k:** 1.5 (standard box plot whiskers).  Use k=3.0 for only
extreme outliers.

**Strengths:** Simple, non-parametric (no normality assumption), easy to
explain ("this value is outside the box plot whiskers").
**Weaknesses:** Doesn't account for trend or seasonality.

**When to use:** Quick screening for extreme values in any numeric column.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class IQRDetector(BaseAnomalyDetector):
    """IQR-based anomaly detection (the box plot method).

    Parameters:
        k: IQR multiplier for the fence distance.  Default 1.5.
           Use 3.0 for only extreme outliers.

    Attributes:
        q1: The 25th percentile of the training data.
        q3: The 75th percentile of the training data.
        iqr: The interquartile range (Q3 - Q1).
        lower_fence: Q1 - k * IQR.
        upper_fence: Q3 + k * IQR.

    Example::

        detector = IQRDetector(k=1.5)
        detector.fit(Series([10, 12, 11, 13, 10, 12, 11]))
        flags = detector.detect(Series([10, 100, -50]))  # [False, True, True]
    """

    def __init__(self, k: float = 1.5):
        # IQR uses 0 as threshold since scores are "distance outside fence"
        super().__init__(threshold=0.0)
        self.k = k
        self.q1: float = 0.0
        self.q3: float = 0.0
        self.iqr: float = 0.0
        self.lower_fence: float = 0.0
        self.upper_fence: float = 0.0
        self.name = f"IQR(k={k})"

    def fit(self, series: Series) -> None:
        """Compute Q1, Q3, IQR, and fences from training data.

        Parameters:
            series: Historical data representing normal behaviour.

        Raises:
            InsufficientDataError: If fewer than 4 data points.
        """
        values = self._extract_values(series)
        if len(values) < 4:
            raise InsufficientDataError("IQR requires at least 4 data points")

        s = sorted(values)
        n = len(s)
        self.q1 = self._percentile(s, 0.25)
        self.q3 = self._percentile(s, 0.75)
        self.iqr = self.q3 - self.q1

        self.lower_fence = self.q1 - self.k * self.iqr
        self.upper_fence = self.q3 + self.k * self.iqr
        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Return the distance outside the IQR fences for each point.

        Points inside the fences get a score of 0.  Points outside get
        their distance from the nearest fence.

        Parameters:
            series: Data to score.

        Returns:
            Series of distances outside fences (0 = normal).
        """
        self._check_fitted()
        values = self._extract_values(series)
        scores: list[float] = []
        for v in values:
            if v < self.lower_fence:
                scores.append(self.lower_fence - v)
            elif v > self.upper_fence:
                scores.append(v - self.upper_fence)
            else:
                scores.append(0.0)
        return Series(scores)

    @staticmethod
    def _percentile(sorted_values: list[float], q: float) -> float:
        """Compute the q-th percentile using linear interpolation."""
        n = len(sorted_values)
        pos = q * (n - 1)
        lo = int(pos)
        hi = min(lo + 1, n - 1)
        frac = pos - lo
        return sorted_values[lo] * (1 - frac) + sorted_values[hi] * frac
