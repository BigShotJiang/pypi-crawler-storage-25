"""Z-Score anomaly detector — the simplest statistical baseline.

Flags points that are more than *threshold* standard deviations from the mean.

**How it works:**

1. Fit: compute ``mean`` and ``std`` from training data
2. Score: ``score = |value - mean| / std``
3. Detect: ``anomaly = score > threshold``

**Strengths:** Dead simple, fast, interpretable ("this value is 3.2 sigma
from the mean").
**Weaknesses:** Assumes roughly normal distribution.  Sensitive to existing
outliers in the training data (they inflate the mean and std).

**When to use:** Quick baseline for daily sales totals, transaction counts,
or any roughly bell-curved metric.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class ZScoreDetector(BaseAnomalyDetector):
    """Z-Score based anomaly detection.

    Parameters:
        threshold: Number of standard deviations to flag as anomalous.
                   Default 2.5 (catches ~1.2% of normally distributed data).

    Example::

        detector = ZScoreDetector(threshold=2.5)
        detector.fit(Series([10, 12, 11, 13, 10, 12, 11]))
        scores = detector.predict(Series([10, 100, 11]))  # 100 gets high score
        flags = detector.detect(Series([10, 100, 11]))     # [False, True, False]
    """

    def __init__(self, threshold: float = 2.5):
        super().__init__(threshold=threshold)
        self._mean: float = 0.0
        self._std: float = 1.0
        self.name = f"ZScore({threshold})"

    def fit(self, series: Series) -> None:
        """Compute mean and standard deviation from training data.

        Parameters:
            series: Historical data representing normal behaviour.

        Raises:
            InsufficientDataError: If fewer than 2 data points.
        """
        values = self._extract_values(series)
        if len(values) < 2:
            raise InsufficientDataError("ZScore requires at least 2 data points")
        self._mean = sum(values) / len(values)
        variance = sum((v - self._mean) ** 2 for v in values) / (len(values) - 1)
        self._std = math.sqrt(variance) if variance > 0 else 1.0
        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Return Z-Score for each point (higher = more anomalous).

        Parameters:
            series: Data to score.

        Returns:
            Series of absolute Z-Scores.
        """
        self._check_fitted()
        values = self._extract_values(series)
        scores = [abs(v - self._mean) / self._std for v in values]
        return Series(scores)
