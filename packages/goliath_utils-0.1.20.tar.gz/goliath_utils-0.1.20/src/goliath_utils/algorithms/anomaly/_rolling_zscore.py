"""Rolling Z-Score anomaly detector — catches anomalies relative to recent history.

Unlike the global Z-Score which compares against the overall mean, the rolling
Z-Score computes statistics over a sliding window.  This means it can detect
anomalies in trending or non-stationary data where the global mean is meaningless.

**How it works:**

For each point at index *i*, compute the mean and std of the preceding
*window* values, then compute the Z-Score relative to that local context.

**Strengths:** Works on trending data, adapts to level shifts, captures
local anomalies that global methods miss.
**Weaknesses:** The first *window* points cannot be scored (no history).
Sensitive to window size — too small is noisy, too large is sluggish.

**When to use:** Time series with trends, seasonality, or level shifts.
Daily retail sales where the baseline changes over time.
"""

from __future__ import annotations

import math

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class RollingZScoreDetector(BaseAnomalyDetector):
    """Rolling-window Z-Score anomaly detection.

    Parameters:
        window: Number of preceding values to use for local statistics.
                Default 14 (two weeks for daily data).
        threshold: Number of local standard deviations to flag.  Default 2.5.

    Example::

        detector = RollingZScoreDetector(window=7, threshold=3.0)
        detector.fit(Series([...]))  # optional — just stores config
        scores = detector.predict(Series([10, 12, 11, 13, 10, 12, 11, 100, 10]))
        # score for index 7 (value=100) will be high relative to preceding 7 values
    """

    def __init__(self, window: int = 14, threshold: float = 2.5):
        super().__init__(threshold=threshold)
        self.window = window
        self.name = f"RollingZScore(w={window},t={threshold})"

    def fit(self, series: Series) -> None:
        """Store configuration.  Rolling Z-Score doesn't need a separate fit.

        The fit step is a no-op — all computation happens in ``predict()``.
        It exists for API consistency with other detectors.

        Parameters:
            series: Ignored (kept for interface compatibility).
        """
        values = self._extract_values(series)
        if len(values) < self.window + 1:
            raise InsufficientDataError(
                f"RollingZScore(window={self.window}) requires at least "
                f"{self.window + 1} data points, got {len(values)}"
            )
        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Compute rolling Z-Score for each point.

        The first *window* points get a score of 0 (insufficient history).

        Parameters:
            series: Data to score.

        Returns:
            Series of rolling Z-Scores (higher = more anomalous).
        """
        self._check_fitted()
        values = self._extract_values(series)
        scores: list[float] = []

        for i in range(len(values)):
            if i < self.window:
                scores.append(0.0)
                continue

            window_values = values[i - self.window : i]
            mean = sum(window_values) / self.window
            variance = sum((v - mean) ** 2 for v in window_values) / (self.window - 1)
            std = math.sqrt(variance) if variance > 0 else 1.0
            scores.append(abs(values[i] - mean) / std)

        return Series(scores)
