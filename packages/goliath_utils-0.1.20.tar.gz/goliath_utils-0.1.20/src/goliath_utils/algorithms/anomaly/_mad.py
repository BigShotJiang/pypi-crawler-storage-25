"""Modified Z-Score using Median Absolute Deviation (MAD).

Much more robust than standard Z-Score because it uses the median instead
of the mean.  Existing outliers in the training data do NOT inflate the
baseline — MAD ignores them.

**How it works:**

1. Fit: compute ``median`` and ``MAD = median(|values - median|)``
2. Score: ``score = 0.6745 * |value - median| / MAD``
3. The 0.6745 constant makes the score comparable to standard Z-Scores
   for normally distributed data

**Default threshold:** 3.5 (recommended by Iglewicz & Hoaglin, 1993).

**Strengths:** Robust to outliers in training data, works well when the
data isn't perfectly normal.
**Weaknesses:** Slightly less intuitive than Z-Score.

**When to use:** When your training data might already contain anomalies
(common in retail — you rarely have a "perfectly clean" baseline).
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class MADDetector(BaseAnomalyDetector):
    """Modified Z-Score anomaly detector using Median Absolute Deviation.

    Parameters:
        threshold: Modified Z-Score threshold.  Default 3.5.

    Example::

        detector = MADDetector(threshold=3.5)
        detector.fit(Series([10, 12, 11, 13, 10, 12, 11]))
        flags = detector.detect(Series([10, 100, 11]))  # [False, True, False]
    """

    def __init__(self, threshold: float = 3.5):
        super().__init__(threshold=threshold)
        self._median: float = 0.0
        self._mad: float = 1.0
        self.name = f"MAD({threshold})"

    def fit(self, series: Series) -> None:
        """Compute median and MAD from training data.

        Parameters:
            series: Historical data representing normal behaviour.

        Raises:
            InsufficientDataError: If fewer than 2 data points.
        """
        values = self._extract_values(series)
        if len(values) < 2:
            raise InsufficientDataError("MAD requires at least 2 data points")

        self._median = self._calc_median(values)
        abs_devs = [abs(v - self._median) for v in values]
        self._mad = self._calc_median(abs_devs)
        if self._mad == 0:
            self._mad = 1.0  # avoid division by zero
        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Return Modified Z-Scores for each point.

        Parameters:
            series: Data to score.

        Returns:
            Series of modified Z-Scores (higher = more anomalous).
        """
        self._check_fitted()
        values = self._extract_values(series)
        scores = [0.6745 * abs(v - self._median) / self._mad for v in values]
        return Series(scores)

    @staticmethod
    def _calc_median(values: list[float]) -> float:
        """Compute the median of a list of values."""
        s = sorted(values)
        n = len(s)
        if n % 2 == 1:
            return s[n // 2]
        return (s[n // 2 - 1] + s[n // 2]) / 2
