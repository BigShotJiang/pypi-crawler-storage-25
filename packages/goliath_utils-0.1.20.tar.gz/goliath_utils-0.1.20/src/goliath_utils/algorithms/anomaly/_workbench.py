"""AnomalyWorkbench — orchestrator for anomaly detection workflows.

Loads data from the Goliath ``sales`` table, runs multiple anomaly detection
algorithms, and returns the original data annotated with anomaly scores and
flags from each algorithm.

Example::

    from goliath_utils.algorithms.anomaly import AnomalyWorkbench

    wb = AnomalyWorkbench()
    results = wb.scan(
        product_codes=["0001234567890"],
        store_ids=[111, 1185, 1397],
        start_date="2026-01-01",
        end_date="2026-03-21",
        target="qty",
    )
    # Returns a DataSet with sale_date, qty, and anomaly columns per algorithm
"""

from __future__ import annotations

from typing import Any

from goliath_utils.atrax import DataSet, Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import AlgorithmError, InsufficientDataError
from .._metrics import anomaly_count, anomaly_rate


def _default_detectors() -> list[BaseAnomalyDetector]:
    """Return one instance of each built-in detector with sensible defaults."""
    from ._zscore import ZScoreDetector
    from ._mad import MADDetector
    from ._iqr import IQRDetector
    from ._rolling_zscore import RollingZScoreDetector
    from ._isolation_forest import IsolationForest
    from ._dbscan import DBSCANDetector

    return [
        ZScoreDetector(threshold=2.5),
        MADDetector(threshold=3.5),
        IQRDetector(k=1.5),
        RollingZScoreDetector(window=14, threshold=2.5),
        IsolationForest(n_trees=100, threshold=0.6),
        DBSCANDetector(),
    ]


class AnomalyWorkbench:
    """High-level anomaly detection workbench for Goliath sales data.

    Loads data from the ``sales`` table, runs multiple anomaly detectors,
    and returns annotated results — all in pure Python.

    Parameters:
        db: A :class:`~goliath_utils.db.Database` instance.  If ``None``,
            calls ``get_db()`` to create one from Goliath secrets.

    Example::

        from goliath_utils.algorithms.anomaly import AnomalyWorkbench

        wb = AnomalyWorkbench()

        # Scan for anomalous daily sales
        results = wb.scan(
            product_codes=["0001234567890"],
            store_ids=[111],
            start_date="2026-01-01",
            end_date="2026-03-21",
            target="qty",
        )
        print(results)  # DataSet with anomaly scores per algorithm
    """

    def __init__(self, db: Any = None):
        if db is None:
            from goliath_utils.db import get_db
            db = get_db()
        self.db = db

    def load_sales(
        self,
        product_codes: list[str],
        store_ids: list[int],
        start_date: str,
        end_date: str,
        target: str = "qty",
        group_by: str | None = None,
    ) -> DataSet:
        """Query the sales table and return aggregated daily data.

        Parameters:
            product_codes: List of UPC/product codes to include.
            store_ids: List of store IDs to include.
            start_date: Start date (inclusive).
            end_date: End date (inclusive).
            target: Column to analyse — ``"qty"`` or ``"total_sales"``.
            group_by: ``None`` (aggregate all), ``"store"``, or ``"product"``.

        Returns:
            A DataSet with ``sale_date``, the target column, and optionally
            the group_by column.
        """
        if target not in ("qty", "total_sales"):
            raise AlgorithmError(f"target must be 'qty' or 'total_sales', got {target!r}")

        if group_by is None:
            sql = """
                SELECT sale_date::date AS sale_date,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date
                ORDER BY sale_date::date
            """
        elif group_by == "store":
            sql = """
                SELECT sale_date::date AS sale_date,
                       storeid,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date, storeid
                ORDER BY storeid, sale_date::date
            """
        elif group_by == "product":
            sql = """
                SELECT sale_date::date AS sale_date,
                       product_code,
                       SUM(qty) AS qty,
                       SUM(total_sales) AS total_sales
                FROM sales
                WHERE product_code = ANY(:product_codes)
                  AND storeid = ANY(:store_ids)
                  AND sale_date BETWEEN :start_date AND :end_date
                  AND sale_type IN ('Refunded', 'Sale')
                  AND item_ring_type IN ('ITEM', 'SUBD')
                GROUP BY sale_date::date, product_code
                ORDER BY product_code, sale_date::date
            """
        else:
            raise AlgorithmError(
                f"group_by must be None, 'store', or 'product', got {group_by!r}"
            )

        rows = self.db.fetch_all(sql, {
            "product_codes": product_codes,
            "store_ids": store_ids,
            "start_date": start_date,
            "end_date": end_date,
        })

        if not rows:
            raise InsufficientDataError(
                "No sales data found for the given filters."
            )

        return DataSet(rows)

    def run_all(
        self,
        series: Series,
        detectors: list[BaseAnomalyDetector] | None = None,
    ) -> DataSet:
        """Run multiple detectors and compare their results.

        Parameters:
            series: The time series to scan for anomalies.
            detectors: List of detector instances.  ``None`` for all defaults.

        Returns:
            A DataSet with one row per detector and columns: algorithm,
            anomaly_count, anomaly_rate, threshold.
        """
        if detectors is None:
            detectors = _default_detectors()

        results: list[dict] = []
        for det in detectors:
            try:
                det.fit(series)
                scores = det.predict(series)
                flags = det.detect(series)
                n_anomalies = sum(1 for f in flags.values if f)
                rate = (n_anomalies / len(flags)) * 100 if len(flags) > 0 else 0

                results.append({
                    "algorithm": det.name,
                    "anomaly_count": n_anomalies,
                    "anomaly_rate": round(rate, 2),
                    "threshold": det.threshold,
                })
            except (InsufficientDataError, AlgorithmError) as e:
                results.append({
                    "algorithm": det.name,
                    "anomaly_count": 0,
                    "anomaly_rate": 0.0,
                    "threshold": det.threshold,
                    "error": str(e),
                })

        return DataSet(results)

    def scan(
        self,
        product_codes: list[str],
        store_ids: list[int],
        start_date: str,
        end_date: str,
        target: str = "qty",
        detectors: list[BaseAnomalyDetector] | None = None,
    ) -> DataSet:
        """Full pipeline: load data, run all detectors, annotate results.

        Returns the original daily data with additional columns for each
        detector's anomaly score and binary flag.

        Parameters:
            product_codes: UPCs to include.
            store_ids: Store IDs to include.
            start_date: Start date.
            end_date: End date.
            target: ``"qty"`` or ``"total_sales"``.
            detectors: Algorithms to run.  ``None`` for all defaults.

        Returns:
            A DataSet with columns: sale_date, target, and for each detector:
            ``<name>_score`` and ``<name>_flag``.
        """
        if detectors is None:
            detectors = _default_detectors()

        ds = self.load_sales(product_codes, store_ids, start_date, end_date, target)
        series = Series([float(v) for v in ds[target].values], name=target)

        # Start with the original data
        result_data: dict[str, list] = {
            "sale_date": list(ds["sale_date"].values),
            target: list(ds[target].values),
        }

        for det in detectors:
            safe_name = det.name.replace("(", "").replace(")", "").replace(",", "_").replace("=", "").replace(".", "")
            try:
                det.fit(series)
                scores = det.predict(series)
                flags = det.detect(series)
                result_data[f"{safe_name}_score"] = [round(s, 4) for s in scores.values]
                result_data[f"{safe_name}_flag"] = list(flags.values)
            except (InsufficientDataError, AlgorithmError):
                result_data[f"{safe_name}_score"] = [0.0] * len(series)
                result_data[f"{safe_name}_flag"] = [False] * len(series)

        return DataSet(result_data)
