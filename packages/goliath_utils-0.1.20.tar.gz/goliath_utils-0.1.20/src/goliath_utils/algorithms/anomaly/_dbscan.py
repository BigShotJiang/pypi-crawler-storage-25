"""DBSCAN density-based anomaly detector — pure Python implementation.

Clusters data points by density: points in dense regions are "normal",
points that don't belong to any cluster are anomalies (noise points).

**How it works:**

1. For each point, find all neighbours within distance *eps*
2. If a point has >= *min_samples* neighbours, it's a **core point**
3. Core points and their neighbours form clusters
4. Points that aren't in any cluster are **noise** = anomalies

For univariate time series, the "distance" is simply the absolute
difference between values.  DBSCAN is particularly good at finding
groups of normal values and flagging isolated extreme values.

**Strengths:** No distribution assumptions, finds arbitrary-shaped clusters,
directly identifies noise points as anomalies.
**Weaknesses:** Sensitive to *eps* parameter — too small flags everything,
too large flags nothing.  O(n²) distance computation.

**When to use:** When you expect data to cluster into groups and want to
find points that don't fit any group.  Good for cashier metrics where
you want to find cashiers that behave differently from their peers.
"""

from __future__ import annotations

from goliath_utils.atrax import Series
from .._anomaly_base import BaseAnomalyDetector
from .._errors import InsufficientDataError


class DBSCANDetector(BaseAnomalyDetector):
    """DBSCAN density-based anomaly detector.

    Parameters:
        eps: Maximum distance between two points to be considered neighbours.
             Default ``None`` — auto-computed as ``0.5 * std`` of training data.
        min_samples: Minimum number of neighbours to form a dense region.
                     Default 5.
        threshold: Not used directly — DBSCAN produces binary labels.
                   Points not in any cluster are anomalies (score = 1.0).

    Attributes:
        labels: After ``predict()``, a list of cluster labels per point.
                ``-1`` means noise (anomaly).
        n_clusters: Number of clusters found.

    Example::

        detector = DBSCANDetector(eps=5.0, min_samples=3)
        detector.fit(Series([10, 12, 11, 13, 10, 12, 11]))
        scores = detector.predict(Series([10, 100, 11]))
        # 100 gets score 1.0 (noise), 10 and 11 get 0.0 (in cluster)
    """

    def __init__(
        self,
        eps: float | None = None,
        min_samples: int = 5,
    ):
        super().__init__(threshold=0.5)
        self.eps = eps
        self.min_samples = min_samples
        self._auto_eps: float = 0.0
        self.labels: list[int] = []
        self.n_clusters: int = 0
        self.name = f"DBSCAN(eps={eps},min={min_samples})"

    def fit(self, series: Series) -> None:
        """Learn eps from training data if not provided.

        Parameters:
            series: Historical data representing normal behaviour.

        Raises:
            InsufficientDataError: If fewer than min_samples data points.
        """
        values = self._extract_values(series)
        if len(values) < self.min_samples:
            raise InsufficientDataError(
                f"DBSCAN requires at least {self.min_samples} data points"
            )

        if self.eps is None:
            # Auto-compute eps as 0.5 * std
            import math
            mean = sum(values) / len(values)
            variance = sum((v - mean) ** 2 for v in values) / (len(values) - 1)
            self._auto_eps = 0.5 * math.sqrt(variance) if variance > 0 else 1.0
            self.name = f"DBSCAN(eps={self._auto_eps:.2f},min={self.min_samples})"
        else:
            self._auto_eps = self.eps

        self.fitted = True

    def predict(self, series: Series) -> Series:
        """Run DBSCAN clustering and return anomaly scores.

        Points in a cluster get score 0.0 (normal).
        Noise points (not in any cluster) get score 1.0 (anomaly).

        Parameters:
            series: Data to score.

        Returns:
            Series of scores (0.0 = in cluster, 1.0 = noise/anomaly).
        """
        self._check_fitted()
        values = self._extract_values(series)
        eps = self._auto_eps
        n = len(values)

        # Find neighbours for each point
        neighbours: list[list[int]] = []
        for i in range(n):
            nb = [j for j in range(n) if abs(values[i] - values[j]) <= eps]
            neighbours.append(nb)

        # Identify core points
        core = [len(nb) >= self.min_samples for nb in neighbours]

        # Assign clusters via BFS from core points
        labels = [-1] * n  # -1 = noise
        cluster_id = 0

        for i in range(n):
            if labels[i] != -1 or not core[i]:
                continue

            # BFS from this core point
            queue = [i]
            labels[i] = cluster_id
            while queue:
                current = queue.pop(0)
                for nb_idx in neighbours[current]:
                    if labels[nb_idx] != -1:
                        continue
                    labels[nb_idx] = cluster_id
                    if core[nb_idx]:
                        queue.append(nb_idx)

            cluster_id += 1

        self.labels = labels
        self.n_clusters = cluster_id

        # Noise points (-1) get score 1.0, clustered points get 0.0
        scores = [1.0 if l == -1 else 0.0 for l in labels]
        return Series(scores)
