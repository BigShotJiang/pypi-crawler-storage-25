"""Exception classes for the algorithms module.

All exceptions inherit from :class:`AlgorithmError`, so you can catch
everything with a single ``except AlgorithmError`` or be specific.

Exception hierarchy::

    AlgorithmError
    ├── InsufficientDataError  — not enough data points to fit/predict
    ├── NotFittedError         — predict() called before fit()
    └── OptimizationError      — parameter auto-optimization failed
"""


class AlgorithmError(Exception):
    """Base exception for all algorithm errors.

    Catch this to handle any error from the algorithms module in a single
    except block.
    """


class InsufficientDataError(AlgorithmError):
    """Raised when there is not enough data to fit or predict.

    Each algorithm has minimum data requirements.  For example,
    ``SMA(window=7)`` needs at least 7 data points, and
    ``HoltWintersForecaster(season_length=7)`` needs at least 14
    (two full seasonal cycles).
    """


class NotFittedError(AlgorithmError):
    """Raised when ``predict()`` is called before ``fit()``.

    Always call ``fit(series)`` or use ``fit_predict(series, steps)``
    before calling ``predict(steps)``.
    """


class OptimizationError(AlgorithmError):
    """Raised when automatic parameter optimization fails to converge.

    This can happen when the training data is too noisy or too short
    for the grid search to find a good parameter combination.
    """
