"""Pure-Python algorithms and analytics — zero external dependencies.

A growing collection of algorithm modules built entirely on the Python
standard library and Atrax DataSet/Series.

Submodules:

- **forecasting** — Time series forecasting (SMA, WMA, Exponential Smoothing,
  Holt, Holt-Winters, Linear Regression) with a ForecastWorkbench.
- **anomaly** — Unsupervised anomaly detection (Z-Score, MAD, IQR, Rolling
  Z-Score, Isolation Forest, DBSCAN) with an AnomalyWorkbench.
- **clustering** — Unsupervised clustering (K-Means, K-Medoids, Hierarchical,
  DBSCAN, Gaussian Mixture) with a ClusteringWorkbench.
- **regression** — Supervised regression (Linear, Ridge, Lasso, Polynomial,
  KNN) with a RegressionWorkbench.

Shared infrastructure:

- **Metrics** — Regression (RMSE, MAE, MAPE), classification (precision,
  recall, F1), and clustering (silhouette, inertia) metrics.
- **Train/test splitting** — Date-based splitting and rolling-window CV.
- **Base classes** — BaseForecaster, BaseAnomalyDetector, BaseClusterer, BaseRegressor.

Architecture::

    algorithms/
    ├── __init__.py            — Top-level re-exports
    ├── _errors.py             — Shared exception hierarchy
    ├── _metrics.py            — Shared metrics
    ├── _split.py              — Train/test splitting utilities
    ├── _base.py               — BaseForecaster
    ├── _anomaly_base.py       — BaseAnomalyDetector
    ├── _clustering_base.py    — BaseClusterer
    ├── _regression_base.py    — BaseRegressor (with matrix math)
    ├── forecasting/           — Time series forecasting
    ├── anomaly/               — Anomaly detection
    ├── clustering/            — Unsupervised clustering
    └── regression/            — Supervised regression
"""

# Shared infrastructure
from ._errors import (
    AlgorithmError,
    InsufficientDataError,
    NotFittedError,
    OptimizationError,
)
from ._metrics import (
    # Regression
    all_metrics, bias, mae, mape, r_squared, rmse, smape,
    # Classification
    confusion_matrix, precision, recall, f1_score,
    anomaly_count, anomaly_rate, all_classification_metrics,
    # Clustering
    silhouette_score, inertia, cluster_sizes,
)
from ._split import time_series_cv, train_test_split
from ._base import BaseForecaster
from ._anomaly_base import BaseAnomalyDetector
from ._clustering_base import BaseClusterer
from ._regression_base import BaseRegressor

# Forecasting
from .forecasting import (
    SMA, WMA, SimpleExpSmoothing,
    HoltForecaster, HoltWintersForecaster, LinearForecaster,
    ForecastWorkbench,
)

# Anomaly detection
from .anomaly import (
    ZScoreDetector, MADDetector, IQRDetector,
    RollingZScoreDetector, IsolationForest, DBSCANDetector,
    AnomalyWorkbench,
)

# Clustering
from .clustering import (
    KMeans, KMedoids, HierarchicalClustering,
    DBSCANClustering, GaussianMixture,
    ClusteringWorkbench,
)

# Regression
from .regression import (
    LinearRegression, RidgeRegression, LassoRegression,
    PolynomialRegression, KNNRegressor,
    RegressionWorkbench,
)

__all__ = [
    # Errors
    "AlgorithmError", "InsufficientDataError", "NotFittedError", "OptimizationError",
    # Regression Metrics
    "rmse", "mae", "mape", "smape", "r_squared", "bias", "all_metrics",
    # Classification Metrics
    "confusion_matrix", "precision", "recall", "f1_score",
    "anomaly_count", "anomaly_rate", "all_classification_metrics",
    # Clustering Metrics
    "silhouette_score", "inertia", "cluster_sizes",
    # Splitting
    "train_test_split", "time_series_cv",
    # Base Classes
    "BaseForecaster", "BaseAnomalyDetector", "BaseClusterer", "BaseRegressor",
    # Forecasters
    "SMA", "WMA", "SimpleExpSmoothing",
    "HoltForecaster", "HoltWintersForecaster", "LinearForecaster",
    "ForecastWorkbench",
    # Anomaly Detectors
    "ZScoreDetector", "MADDetector", "IQRDetector",
    "RollingZScoreDetector", "IsolationForest", "DBSCANDetector",
    "AnomalyWorkbench",
    # Clusterers
    "KMeans", "KMedoids", "HierarchicalClustering",
    "DBSCANClustering", "GaussianMixture",
    "ClusteringWorkbench",
    # Regressors
    "LinearRegression", "RidgeRegression", "LassoRegression",
    "PolynomialRegression", "KNNRegressor",
    "RegressionWorkbench",
]
