"""SNS client for the Goliath notification API."""

from __future__ import annotations

import os

import httpx
from goliath_utils.env import load_dotenv

from ._errors import SNSAuthError, SNSNotFoundError, SNSRequestError


class SNSClient:
    """Client for the Goliath SNS API.

    Reads configuration from constructor args or environment variables:
    GOLIATH_API_URL, GOLIATH_API_KEY.
    """

    def __init__(
        self,
        *,
        api_url: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ):
        dotenv_loaded = load_dotenv()

        self.api_url = (api_url or os.environ.get("GOLIATH_API_URL", "")).rstrip("/")
        self.api_key = api_key or os.environ.get("GOLIATH_API_KEY", "")

        if not self.api_url or not self.api_key:
            missing = [
                name
                for name, val in [("GOLIATH_API_URL", self.api_url), ("GOLIATH_API_KEY", self.api_key)]
                if not val
            ]
            env_hint = (
                " No .env file was found — create one with these variables"
                " or export them in your shell."
                if not dotenv_loaded
                else " A .env file was loaded but these variables were not set in it."
            )
            raise SNSAuthError(
                f"Missing required environment variable(s): {', '.join(missing)}.{env_hint}"
            )

        self._base = self.api_url.rstrip("/")
        self._http = httpx.Client(
            headers={"X-API-Key": self.api_key},
            timeout=timeout,
        )

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal helpers --------------------------------------------------

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Send request and handle errors at both HTTP and API level."""
        resp = self._http.request(method, f"{self._base}/sns{path}", **kwargs)

        if resp.status_code == 404:
            detail = resp.text
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                pass
            raise SNSNotFoundError(detail)

        if resp.status_code >= 400:
            raise SNSRequestError(resp.status_code, resp.text)

        data = resp.json()
        if data.get("error") == 1:
            raise SNSRequestError(resp.status_code, data.get("msg", "Unknown error"))

        return data

    # -- setup -------------------------------------------------------------

    def setup(self) -> dict:
        """Initialize SNS tables. Idempotent."""
        return self._request("POST", "/setup")

    # -- topics ------------------------------------------------------------

    def create_topic(
        self,
        name: str,
        *,
        display_name: str | None = None,
        description: str | None = None,
    ) -> dict:
        """Create a notification topic. Returns the topic record dict."""
        body: dict = {"name": name}
        if display_name is not None:
            body["display_name"] = display_name
        if description is not None:
            body["description"] = description
        data = self._request("POST", "/topics", json=body)
        return data["topic"]

    def list_topics(self, *, limit: int = 100) -> list[dict]:
        """List all topics."""
        data = self._request("GET", "/topics", params={"limit": limit})
        return data["topics"]

    def get_topic(self, topic_id: int) -> dict:
        """Get a single topic by ID."""
        data = self._request("GET", f"/topics/{topic_id}")
        return data["topic"]

    def update_topic(
        self,
        topic_id: int,
        *,
        name: str | None = None,
        display_name: str | None = None,
        description: str | None = None,
    ) -> dict:
        """Update a topic. Only provided fields are changed."""
        body = {
            k: v
            for k, v in {"name": name, "display_name": display_name, "description": description}.items()
            if v is not None
        }
        data = self._request("PUT", f"/topics/{topic_id}", json=body)
        return data["topic"]

    def delete_topic(self, topic_id: int) -> None:
        """Delete a topic and all its subscriptions (cascade)."""
        self._request("DELETE", f"/topics/{topic_id}")

    # -- subscriptions -----------------------------------------------------

    def subscribe(
        self,
        topic_id: int,
        user_identifier: str,
        protocol: str,
        endpoint: str,
    ) -> dict:
        """Subscribe to a topic. Returns the subscription record dict."""
        data = self._request(
            "POST",
            "/subscriptions",
            json={
                "topic_id": topic_id,
                "user_identifier": user_identifier,
                "protocol": protocol,
                "endpoint": endpoint,
            },
        )
        return data["subscription"]

    def list_subscriptions(
        self,
        *,
        topic_id: int | None = None,
        user_identifier: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """List subscriptions with optional filters."""
        params: dict[str, str | int] = {"limit": limit}
        if topic_id is not None:
            params["topic_id"] = topic_id
        if user_identifier is not None:
            params["user_identifier"] = user_identifier
        data = self._request("GET", "/subscriptions", params=params)
        return data["subscriptions"]

    def get_topic_subscriptions(self, topic_id: int, *, limit: int = 100) -> list[dict]:
        """List all subscriptions for a specific topic."""
        data = self._request(
            "GET", f"/topics/{topic_id}/subscriptions", params={"limit": limit}
        )
        return data["subscriptions"]

    def unsubscribe(self, subscription_id: int) -> None:
        """Delete a subscription."""
        self._request("DELETE", f"/subscriptions/{subscription_id}")

    # -- publish -----------------------------------------------------------

    def publish(
        self,
        topic_arn: str,
        message: str,
        *,
        subject: str = "Notification",
    ) -> dict:
        """Publish a message to a topic. Returns delivery summary.

        Parameters:
            topic_arn: The ARN of the topic to publish to.
            message: The message body to deliver to subscribers.
            subject: The subject line for the notification.  Defaults to
                     ``"Notification"``.  **If the topic has email subscribers,
                     always provide a meaningful subject** — it becomes the
                     email subject line and a missing or generic subject makes
                     the message look like spam.  For SMS or Lambda subscribers
                     the subject is ignored by the endpoint but still logged.

        Returns:
            A dict with the delivery summary from the server.

        Example::

            sns.publish(
                topic_arn="arn:goliath:sns:us-east-1:12345:alerts",
                message="Store 111 sales dropped 20% vs last week.",
                subject="Sales Alert — Store 111",
            )
        """
        body: dict = {"arn": topic_arn, "message": message, "subject": subject}
        return self._request("POST", "/publish", json=body)

    # -- convenience -------------------------------------------------------

    def get_topic_by_name(self, name: str) -> dict:
        """Find a topic by its unique name.

        Raises SNSNotFoundError if no topic matches.
        """
        topics = self.list_topics()
        for t in topics:
            if t["name"] == name:
                return t
        raise SNSNotFoundError(f"No topic found with name={name!r}")

    def subscribe_email(self, topic_id: int, email: str) -> dict:
        """Subscribe an email address to a topic."""
        return self.subscribe(topic_id, email, "email", email)

    def subscribe_http(self, topic_id: int, user: str, url: str) -> dict:
        """Subscribe an HTTPS webhook to a topic."""
        return self.subscribe(topic_id, user, "https", url)
