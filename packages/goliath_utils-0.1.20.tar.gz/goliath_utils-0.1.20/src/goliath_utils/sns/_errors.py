class SNSError(Exception):
    """Base exception for SNS operations."""


class SNSAuthError(SNSError):
    """Raised when API URL or API key is missing or invalid."""


class SNSRequestError(SNSError):
    """Raised when the SNS API returns an error response."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"SNS API error {status_code}: {message}")


class SNSNotFoundError(SNSRequestError):
    """Raised when a topic or subscription is not found."""

    def __init__(self, message: str = "Not found"):
        super().__init__(404, message)
