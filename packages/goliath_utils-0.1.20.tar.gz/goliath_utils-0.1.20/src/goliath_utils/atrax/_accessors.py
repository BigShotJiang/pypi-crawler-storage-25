"""Vectorized string operations for Atrax Series."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from ._types import AtraxTypeError, is_na

if TYPE_CHECKING:
    from ._series import Series


class StringAccessor:
    """Vectorized string methods accessed via ``Series.str``.

    Every method returns a new Series with the same index.
    NA values propagate (the result is NA/None at those positions).
    """

    __slots__ = ("_s",)

    def __init__(self, series: Series) -> None:
        for v in series._data:
            if not is_na(v) and not isinstance(v, str):
                raise AtraxTypeError(
                    f".str accessor requires string dtype, got {type(v).__name__}"
                )
        self._s = series

    def _apply(self, func: Any) -> Series:
        from ._series import Series

        s = self._s
        data = [None if is_na(v) else func(v) for v in s._data]
        return s._build(data, list(s._index))

    def lower(self) -> Series:
        return self._apply(str.lower)

    def upper(self) -> Series:
        return self._apply(str.upper)

    def strip(self) -> Series:
        return self._apply(str.strip)

    def contains(self, pat: str) -> Series:
        from ._series import Series

        s = self._s
        data = [False if is_na(v) else pat in v for v in s._data]
        return Series(data, index=list(s._index), dtype=bool, name=s.name)

    def replace(self, pat: str, repl: str) -> Series:
        return self._apply(lambda v: v.replace(pat, repl))

    def len(self) -> Series:
        from ._series import Series

        s = self._s
        data = [float("nan") if is_na(v) else builtins_len(v) for v in s._data]
        return s._build(data, list(s._index))

    def startswith(self, prefix: str) -> Series:
        from ._series import Series

        s = self._s
        data = [False if is_na(v) else v.startswith(prefix) for v in s._data]
        return Series(data, index=list(s._index), dtype=bool, name=s.name)

    def endswith(self, suffix: str) -> Series:
        from ._series import Series

        s = self._s
        data = [False if is_na(v) else v.endswith(suffix) for v in s._data]
        return Series(data, index=list(s._index), dtype=bool, name=s.name)

    def split(self, sep: str | None = None) -> Series:
        return self._apply(lambda v: v.split(sep))


builtins_len = len
