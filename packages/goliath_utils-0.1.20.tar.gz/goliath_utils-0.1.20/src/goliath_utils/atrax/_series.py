"""Atrax Series — a lightweight, pure-Python alternative to pandas Series."""

from __future__ import annotations

import math
import operator
import statistics
from collections import defaultdict
from typing import Any, Callable, Iterator

from ._types import NA, AtraxError, AtraxIndexError, AtraxTypeError, is_na, _coerce_dtype, _infer_dtype


# ---------------------------------------------------------------------------
# Indexer helpers
# ---------------------------------------------------------------------------


class _LocIndexer:
    """Label-based indexer accessed via ``Series.loc``."""

    __slots__ = ("_s",)

    def __init__(self, series: Series) -> None:
        self._s = series

    def __getitem__(self, key: Any) -> Any | Series:
        s = self._s
        if isinstance(key, Series):
            return s._boolean_mask(key)
        if isinstance(key, list):
            return s._label_select(key)
        if isinstance(key, slice):
            return s._label_slice(key)
        return s._label_scalar(key)


class _ILocIndexer:
    """Position-based indexer accessed via ``Series.iloc``."""

    __slots__ = ("_s",)

    def __init__(self, series: Series) -> None:
        self._s = series

    def __getitem__(self, key: Any) -> Any | Series:
        s = self._s
        if isinstance(key, list):
            return s._pos_select(key)
        if isinstance(key, slice):
            return s._pos_slice(key)
        if isinstance(key, int):
            return s._pos_scalar(key)
        raise AtraxIndexError(f"Invalid iloc key type: {type(key).__name__}")


# ---------------------------------------------------------------------------
# Series
# ---------------------------------------------------------------------------


class Series:
    """A one-dimensional labelled array.

    Construct from a list, dict, scalar (with index), or another Series.
    Pure Python — zero external dependencies.
    """

    __hash__ = None  # unhashable, like pandas

    def __init__(
        self,
        data: Any = None,
        index: list | None = None,
        dtype: type | None = None,
        name: str | None = None,
    ) -> None:
        if isinstance(data, Series):
            raw = list(data._data)
            idx = list(data._index) if index is None else list(index)
            name = name if name is not None else data.name
        elif isinstance(data, dict):
            idx = list(data.keys()) if index is None else list(index)
            raw = list(data.values()) if index is None else [
                data.get(k, NA) for k in idx
            ]
        elif isinstance(data, list):
            raw = list(data)
            idx = list(range(len(raw))) if index is None else list(index)
        elif data is None:
            raw = []
            idx = [] if index is None else list(index)
            if idx:
                raw = [NA] * len(idx)
        else:
            # scalar broadcast
            if index is None:
                idx = [0]
                raw = [data]
            else:
                idx = list(index)
                raw = [data] * len(idx)

        if len(raw) != len(idx):
            raise AtraxError(
                f"Length mismatch: data has {len(raw)} elements, "
                f"index has {len(idx)}"
            )

        # Normalise None → NA for non-str dtypes
        inferred = dtype or _infer_dtype(raw)
        if inferred is not str:
            raw = [NA if v is None else v for v in raw]

        self._data: list = _coerce_dtype(raw, dtype)
        self._index: list = idx
        self.name: str | None = name
        self.dtype: type | None = dtype or _infer_dtype(self._data)

    # -- properties --------------------------------------------------------

    @property
    def values(self) -> list:
        return list(self._data)

    @property
    def index(self) -> list:
        return list(self._index)

    @property
    def shape(self) -> tuple[int]:
        return (len(self._data),)

    @property
    def size(self) -> int:
        return len(self._data)

    @property
    def empty(self) -> bool:
        return len(self._data) == 0

    # -- indexers ----------------------------------------------------------

    @property
    def loc(self) -> _LocIndexer:
        return _LocIndexer(self)

    @property
    def iloc(self) -> _ILocIndexer:
        return _ILocIndexer(self)

    @property
    def str(self) -> Any:
        from ._accessors import StringAccessor
        return StringAccessor(self)

    # -- internal indexing helpers ------------------------------------------

    def _label_scalar(self, label: Any) -> Any:
        positions = [i for i, l in enumerate(self._index) if l == label]
        if not positions:
            raise AtraxIndexError(f"Label {label!r} not in index")
        if len(positions) == 1:
            return self._data[positions[0]]
        return self._build(
            [self._data[i] for i in positions],
            [self._index[i] for i in positions],
        )

    def _label_select(self, labels: list) -> Series:
        data, idx = [], []
        label_map = self._label_positions()
        for lab in labels:
            if lab not in label_map:
                raise AtraxIndexError(f"Label {lab!r} not in index")
            for pos in label_map[lab]:
                data.append(self._data[pos])
                idx.append(self._index[pos])
        return self._build(data, idx)

    def _label_slice(self, slc: slice) -> Series:
        start_idx = 0
        stop_idx = len(self._index)
        if slc.start is not None:
            for i, lab in enumerate(self._index):
                if lab == slc.start:
                    start_idx = i
                    break
            else:
                raise AtraxIndexError(f"Label {slc.start!r} not in index")
        if slc.stop is not None:
            for i in range(len(self._index) - 1, -1, -1):
                if self._index[i] == slc.stop:
                    stop_idx = i + 1  # inclusive for label slicing
                    break
            else:
                raise AtraxIndexError(f"Label {slc.stop!r} not in index")
        return self._build(
            self._data[start_idx:stop_idx],
            self._index[start_idx:stop_idx],
        )

    def _pos_scalar(self, pos: int) -> Any:
        try:
            return self._data[pos]
        except IndexError:
            raise AtraxIndexError(f"Position {pos} out of range for length {len(self._data)}") from None

    def _pos_select(self, positions: list[int]) -> Series:
        n = len(self._data)
        data, idx = [], []
        for p in positions:
            if p < -n or p >= n:
                raise AtraxIndexError(f"Position {p} out of range for length {n}")
            data.append(self._data[p])
            idx.append(self._index[p])
        return self._build(data, idx)

    def _pos_slice(self, slc: slice) -> Series:
        data = self._data[slc]
        idx = self._index[slc]
        return self._build(data, idx)

    def _boolean_mask(self, mask: Series) -> Series:
        if len(mask) != len(self):
            raise AtraxError(
                f"Boolean mask length {len(mask)} doesn't match Series length {len(self)}"
            )
        data, idx = [], []
        for m, d, i in zip(mask._data, self._data, self._index):
            if m is True:
                data.append(d)
                idx.append(i)
        return self._build(data, idx)

    def _label_positions(self) -> dict[Any, list[int]]:
        result: dict[Any, list[int]] = defaultdict(list)
        for i, lab in enumerate(self._index):
            result[lab].append(i)
        return result

    # -- __getitem__ -------------------------------------------------------

    def __getitem__(self, key: Any) -> Any | Series:
        if isinstance(key, Series):
            return self._boolean_mask(key)
        if isinstance(key, list):
            return self._label_select(key)
        if isinstance(key, slice):
            return self._label_slice(key)
        return self._label_scalar(key)

    def head(self, n: int = 5) -> Series:
        return self._build(self._data[:n], self._index[:n])

    def tail(self, n: int = 5) -> Series:
        if n == 0:
            return self._build([], [])
        return self._build(self._data[-n:], self._index[-n:])

    # -- alignment ---------------------------------------------------------

    @staticmethod
    def _align(left: Series, right: Series) -> tuple[list, list, list]:
        left_map: dict[Any, list[int]] = defaultdict(list)
        right_map: dict[Any, list[int]] = defaultdict(list)
        for i, lab in enumerate(left._index):
            left_map[lab].append(i)
        for i, lab in enumerate(right._index):
            right_map[lab].append(i)

        all_labels: list = []
        seen: set = set()
        for lab in left._index:
            if lab not in seen:
                all_labels.append(lab)
                seen.add(lab)
        for lab in right._index:
            if lab not in seen:
                all_labels.append(lab)
                seen.add(lab)

        out_index, out_left, out_right = [], [], []
        for lab in all_labels:
            lp = left_map.get(lab, [])
            rp = right_map.get(lab, [])
            n = max(len(lp), len(rp))
            for i in range(n):
                out_index.append(lab)
                out_left.append(left._data[lp[i]] if i < len(lp) else NA)
                out_right.append(right._data[rp[i]] if i < len(rp) else NA)

        return out_index, out_left, out_right

    # -- arithmetic --------------------------------------------------------

    def _binary_op(self, other: Any, op: Callable) -> Series:
        if isinstance(other, Series):
            idx, left_vals, right_vals = self._align(self, other)
            data = []
            for lv, rv in zip(left_vals, right_vals):
                if is_na(lv) or is_na(rv):
                    data.append(NA)
                else:
                    data.append(op(lv, rv))
            return self._build(data, idx)
        # scalar
        data = []
        for v in self._data:
            if is_na(v):
                data.append(NA)
            else:
                data.append(op(v, other))
        return self._build(data, list(self._index))

    def _rbinary_op(self, other: Any, op: Callable) -> Series:
        data = []
        for v in self._data:
            if is_na(v):
                data.append(NA)
            else:
                data.append(op(other, v))
        return self._build(data, list(self._index))

    def __add__(self, other: Any) -> Series:
        return self._binary_op(other, operator.add)

    def __radd__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.add)

    def __sub__(self, other: Any) -> Series:
        return self._binary_op(other, operator.sub)

    def __rsub__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.sub)

    def __mul__(self, other: Any) -> Series:
        return self._binary_op(other, operator.mul)

    def __rmul__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.mul)

    def __truediv__(self, other: Any) -> Series:
        return self._binary_op(other, operator.truediv)

    def __rtruediv__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.truediv)

    def __floordiv__(self, other: Any) -> Series:
        return self._binary_op(other, operator.floordiv)

    def __rfloordiv__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.floordiv)

    def __mod__(self, other: Any) -> Series:
        return self._binary_op(other, operator.mod)

    def __rmod__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.mod)

    def __pow__(self, other: Any) -> Series:
        return self._binary_op(other, operator.pow)

    def __rpow__(self, other: Any) -> Series:
        return self._rbinary_op(other, operator.pow)

    def __neg__(self) -> Series:
        data = [NA if is_na(v) else -v for v in self._data]
        return self._build(data, list(self._index))

    # -- comparison --------------------------------------------------------

    def _compare_op(self, other: Any, op: Callable) -> Series:
        if isinstance(other, Series):
            idx, left_vals, right_vals = self._align(self, other)
            data = []
            for lv, rv in zip(left_vals, right_vals):
                if is_na(lv) or is_na(rv):
                    data.append(False)
                else:
                    data.append(op(lv, rv))
            return Series(data, index=idx, dtype=bool, name=self.name)
        data = []
        for v in self._data:
            if is_na(v):
                data.append(False)
            else:
                data.append(op(v, other))
        return Series(data, index=list(self._index), dtype=bool, name=self.name)

    def __eq__(self, other: Any) -> Series:  # type: ignore[override]
        return self._compare_op(other, operator.eq)

    def __ne__(self, other: Any) -> Series:  # type: ignore[override]
        return self._compare_op(other, operator.ne)

    def __lt__(self, other: Any) -> Series:
        return self._compare_op(other, operator.lt)

    def __gt__(self, other: Any) -> Series:
        return self._compare_op(other, operator.gt)

    def __le__(self, other: Any) -> Series:
        return self._compare_op(other, operator.le)

    def __ge__(self, other: Any) -> Series:
        return self._compare_op(other, operator.ge)

    # -- boolean ops -------------------------------------------------------

    def __and__(self, other: Any) -> Series:
        if isinstance(other, Series):
            idx, left_vals, right_vals = self._align(self, other)
            data = [bool(lv and rv) for lv, rv in zip(left_vals, right_vals)]
            return Series(data, index=idx, dtype=bool, name=self.name)
        data = [bool(v and other) for v in self._data]
        return Series(data, index=list(self._index), dtype=bool, name=self.name)

    def __or__(self, other: Any) -> Series:
        if isinstance(other, Series):
            idx, left_vals, right_vals = self._align(self, other)
            data = [bool(lv or rv) for lv, rv in zip(left_vals, right_vals)]
            return Series(data, index=idx, dtype=bool, name=self.name)
        data = [bool(v or other) for v in self._data]
        return Series(data, index=list(self._index), dtype=bool, name=self.name)

    def __invert__(self) -> Series:
        data = [not v for v in self._data]
        return Series(data, index=list(self._index), dtype=bool, name=self.name)

    def any(self) -> bool:
        return any(v for v in self._data if not is_na(v))

    def all(self) -> bool:
        non_na = [v for v in self._data if not is_na(v)]
        if not non_na:
            return True
        return all(non_na)

    def __bool__(self) -> bool:
        raise AtraxTypeError(
            "The truth value of a Series is ambiguous. Use .any() or .all()."
        )

    # -- aggregations ------------------------------------------------------

    def _non_na(self) -> list:
        return [v for v in self._data if not is_na(v)]

    def sum(self) -> Any:
        vals = self._non_na()
        if not vals:
            return 0
        return sum(vals)

    def mean(self) -> float:
        vals = self._non_na()
        if not vals:
            return NA
        return sum(vals) / len(vals)

    def median(self) -> float:
        vals = sorted(self._non_na())
        if not vals:
            return NA
        return statistics.median(vals)

    def min(self) -> Any:
        vals = self._non_na()
        if not vals:
            return NA
        return builtins_min(vals)

    def max(self) -> Any:
        vals = self._non_na()
        if not vals:
            return NA
        return builtins_max(vals)

    def std(self, ddof: int = 1) -> float:
        vals = self._non_na()
        if len(vals) <= ddof:
            return NA
        mean = sum(vals) / len(vals)
        ss = sum((v - mean) ** 2 for v in vals)
        return math.sqrt(ss / (len(vals) - ddof))

    def var(self, ddof: int = 1) -> float:
        vals = self._non_na()
        if len(vals) <= ddof:
            return NA
        mean = sum(vals) / len(vals)
        ss = sum((v - mean) ** 2 for v in vals)
        return ss / (len(vals) - ddof)

    def quantile(self, q: float | list[float] = 0.5) -> float | Series:
        vals = sorted(self._non_na())
        if not vals:
            if isinstance(q, list):
                return Series([NA] * len(q), index=list(q))
            return NA

        def _interp(quantile: float) -> float:
            if quantile < 0.0 or quantile > 1.0:
                raise AtraxError(f"Quantile must be between 0 and 1, got {quantile}")
            pos = quantile * (len(vals) - 1)
            lo = int(pos)
            hi = min(lo + 1, len(vals) - 1)
            frac = pos - lo
            return vals[lo] + (vals[hi] - vals[lo]) * frac

        if isinstance(q, list):
            data = [_interp(qi) for qi in q]
            return Series(data, index=list(q))
        return _interp(q)

    def count(self) -> int:
        return len(self._non_na())

    def nunique(self) -> int:
        seen: set = set()
        for v in self._data:
            if is_na(v):
                continue
            seen.add(v)
        return len(seen)

    def unique(self) -> list:
        """Return a list of unique non-NA values, preserving first-seen order.

        Example::

            Series(["a", "b", "a", "c", "b"]).unique()  # ["a", "b", "c"]
        """
        seen: set = set()
        result: list = []
        for v in self._data:
            if is_na(v):
                continue
            if v not in seen:
                seen.add(v)
                result.append(v)
        return result

    def isna(self) -> Series:
        """Return a boolean Series where ``True`` indicates NA/None values.

        Example::

            Series([1, NA, 3, None]).isna()  # [False, True, False, True]
        """
        return Series([is_na(v) for v in self._data], index=list(self._index), name=self.name)

    def notna(self) -> Series:
        """Return a boolean Series where ``True`` indicates non-NA values.

        Example::

            Series([1, NA, 3, None]).notna()  # [True, False, True, False]
        """
        return Series([not is_na(v) for v in self._data], index=list(self._index), name=self.name)

    def value_counts(self) -> Series:
        counts: dict[Any, int] = {}
        for v in self._data:
            if is_na(v):
                continue
            counts[v] = counts.get(v, 0) + 1
        sorted_items = sorted(counts.items(), key=lambda x: (-x[1], str(x[0])))
        return Series(
            [c for _, c in sorted_items],
            index=[v for v, _ in sorted_items],
            name=self.name,
        )

    # -- transformations ---------------------------------------------------

    def apply(self, func: Callable) -> Series:
        data = [NA if is_na(v) else func(v) for v in self._data]
        return Series(data, index=list(self._index), name=self.name)

    def map(self, arg: dict | Callable) -> Series:
        if isinstance(arg, dict):
            data = [
                NA if is_na(v) else arg.get(v, NA) for v in self._data
            ]
        else:
            data = [NA if is_na(v) else arg(v) for v in self._data]
        return Series(data, index=list(self._index), name=self.name)

    def sort_values(self, ascending: bool = True) -> Series:
        paired = list(zip(self._data, self._index))
        na_pairs = [(d, i) for d, i in paired if is_na(d)]
        val_pairs = [(d, i) for d, i in paired if not is_na(d)]
        val_pairs.sort(key=lambda x: x[0], reverse=not ascending)
        ordered = val_pairs + na_pairs
        return self._build([d for d, _ in ordered], [i for _, i in ordered])

    def sort_index(self, ascending: bool = True) -> Series:
        paired = sorted(
            zip(self._index, self._data),
            key=lambda x: x[0],
            reverse=not ascending,
        )
        return self._build([d for _, d in paired], [i for i, _ in paired])

    def rank(self, method: str = "average", ascending: bool = True) -> Series:
        n = len(self._data)
        ranks = [NA] * n

        # get positions of non-NA values
        valid = [(i, self._data[i]) for i in range(n) if not is_na(self._data[i])]
        valid.sort(key=lambda x: x[1], reverse=not ascending)

        # group by value
        i = 0
        while i < len(valid):
            j = i
            while j < len(valid) and valid[j][1] == valid[i][1]:
                j += 1
            ordinal_ranks = list(range(i + 1, j + 1))
            if method == "average":
                avg = sum(ordinal_ranks) / len(ordinal_ranks)
                for k in range(i, j):
                    ranks[valid[k][0]] = avg
            elif method == "min":
                for k in range(i, j):
                    ranks[valid[k][0]] = float(ordinal_ranks[0])
            elif method == "max":
                for k in range(i, j):
                    ranks[valid[k][0]] = float(ordinal_ranks[-1])
            elif method == "first":
                for k in range(i, j):
                    ranks[valid[k][0]] = float(ordinal_ranks[k - i])
            elif method == "dense":
                dense_rank = float(i + 1) if i == 0 else ranks[valid[i - 1][0]]
                if i > 0 and valid[i][1] != valid[i - 1][1]:
                    dense_rank = ranks[valid[i - 1][0]] + 1.0
                elif i == 0:
                    dense_rank = 1.0
                for k in range(i, j):
                    ranks[valid[k][0]] = dense_rank
            i = j

        return Series(ranks, index=list(self._index), dtype=float, name=self.name)

    def drop_duplicates(self, keep: str = "first") -> Series:
        if keep == "first":
            seen: set = set()
            data, idx = [], []
            for d, i in zip(self._data, self._index):
                key = None if is_na(d) else d
                if key not in seen:
                    seen.add(key)
                    data.append(d)
                    idx.append(i)
            return self._build(data, idx)
        elif keep == "last":
            seen: set = set()  # type: ignore[no-redef]
            data, idx = [], []
            for d, i in reversed(list(zip(self._data, self._index))):
                key = None if is_na(d) else d
                if key not in seen:
                    seen.add(key)
                    data.append(d)
                    idx.append(i)
            data.reverse()
            idx.reverse()
            return self._build(data, idx)
        elif keep is False:
            from collections import Counter
            counter: Counter = Counter()
            for d in self._data:
                key = None if is_na(d) else d
                counter[key] += 1
            data, idx = [], []
            for d, i in zip(self._data, self._index):
                key = None if is_na(d) else d
                if counter[key] == 1:
                    data.append(d)
                    idx.append(i)
            return self._build(data, idx)
        raise AtraxError(f"Invalid keep value: {keep!r}")

    def fillna(self, value: Any) -> Series:
        data = [value if is_na(v) else v for v in self._data]
        return self._build(data, list(self._index))

    def dropna(self) -> Series:
        data, idx = [], []
        for d, i in zip(self._data, self._index):
            if not is_na(d):
                data.append(d)
                idx.append(i)
        return self._build(data, idx)

    def astype(self, dtype: type) -> Series:
        return Series(list(self._data), index=list(self._index), dtype=dtype, name=self.name)

    def rename(self, name: str | None) -> Series:
        return Series(list(self._data), index=list(self._index), dtype=self.dtype, name=name)

    def reset_index(self, drop: bool = False) -> Series | tuple[Series, Series]:
        if drop:
            return self._build(list(self._data), list(range(len(self._data))))
        index_series = Series(list(self._index), name="index")
        value_series = self._build(list(self._data), list(range(len(self._data))))
        return index_series, value_series

    def copy(self) -> Series:
        return Series(list(self._data), index=list(self._index), dtype=self.dtype, name=self.name)

    # -- display -----------------------------------------------------------

    def __repr__(self) -> str:
        if self.empty:
            dtype_str = self.dtype.__name__ if self.dtype else "object"
            return f"Series([], dtype={dtype_str})"

        max_rows = 60
        n = len(self._data)
        truncated = n > max_rows

        if truncated:
            head_n = max_rows // 2
            tail_n = max_rows // 2
            show_idx = self._index[:head_n] + self._index[-tail_n:]
            show_data = self._data[:head_n] + self._data[-tail_n:]
        else:
            show_idx = self._index
            show_data = self._data

        idx_strs = [str(i) for i in show_idx]
        val_strs = [_format_value(v) for v in show_data]
        idx_width = max(len(s) for s in idx_strs)

        lines = []
        for i, (is_, vs) in enumerate(zip(idx_strs, val_strs)):
            if truncated and i == max_rows // 2:
                lines.append("...")
            lines.append(f"{is_:>{idx_width}}    {vs}")

        dtype_str = self.dtype.__name__ if self.dtype else "object"
        if self.name is not None:
            lines.append(f"Name: {self.name}, dtype: {dtype_str}")
        else:
            lines.append(f"dtype: {dtype_str}")
        return "\n".join(lines)

    # -- iteration ---------------------------------------------------------

    def __iter__(self) -> Iterator:
        return iter(self._data)

    def items(self) -> Iterator[tuple[Any, Any]]:
        return zip(self._index, self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __contains__(self, value: Any) -> bool:
        if is_na(value):
            return any(is_na(v) for v in self._data)
        return value in self._data

    # -- internal builder --------------------------------------------------

    def _build(self, data: list, index: list) -> Series:
        s = Series.__new__(Series)
        s._data = data
        s._index = index
        s.name = self.name
        s.dtype = self.dtype
        return s


# ---------------------------------------------------------------------------
# Module-level helpers (avoid shadowing builtins inside the class)
# ---------------------------------------------------------------------------

builtins_min = min
builtins_max = max


def _format_value(v: Any) -> str:
    if is_na(v):
        return "NaN"
    return str(v)
