"""Module-level functions for Atrax — qcut, cut, and related utilities."""

from __future__ import annotations

import bisect
from typing import Any

from ._series import Series
from ._types import NA, AtraxError, is_na


def qcut(
    series: Series,
    q: int,
    labels: list[str] | None = None,
) -> Series:
    """Quantile-based binning. Splits *series* into *q* equal-frequency bins.

    Parameters
    ----------
    series : Series
        Numeric Series to bin.
    q : int
        Number of quantile bins (e.g. 4 for quartiles).
    labels : list[str] | None
        Labels for the bins. Must have length *q* if provided.
        If None, generates interval strings like ``"(0.0, 25.0]"``.

    Returns
    -------
    Series
        String Series with bin labels (same index as input). NA values propagate.
    """
    if q < 1:
        raise AtraxError(f"q must be >= 1, got {q}")
    if labels is not None and len(labels) != q:
        raise AtraxError(f"labels must have length {q}, got {len(labels)}")

    quantiles = [i / q for i in range(q + 1)]
    edges = [series.quantile(qi) for qi in quantiles]

    # deduplicate edges (happens when many values are identical)
    unique_edges = [edges[0]]
    for e in edges[1:]:
        if e != unique_edges[-1]:
            unique_edges.append(e)

    # if all edges collapsed to one point, create a single bin around it
    if len(unique_edges) == 1:
        val = unique_edges[0]
        unique_edges = [val - 0.5, val + 0.5]

    if labels is None:
        bin_labels = _make_interval_labels(unique_edges)
    else:
        bin_labels = list(labels)

    return _assign_bins(series, unique_edges, bin_labels)


def cut(
    series: Series,
    bins: int | list[float],
    labels: list[str] | None = None,
) -> Series:
    """Bin values into discrete intervals.

    Parameters
    ----------
    series : Series
        Numeric Series to bin.
    bins : int or list[float]
        If int, divides the range into *bins* equal-width intervals.
        If list, explicit bin edges (must be sorted, length >= 2).
    labels : list[str] | None
        Labels for the bins. Must have length ``len(edges) - 1`` if provided.
        If None, generates interval strings.

    Returns
    -------
    Series
        String Series with bin labels (same index as input). NA and out-of-range
        values get NA.
    """
    if isinstance(bins, int):
        if bins < 1:
            raise AtraxError(f"bins must be >= 1, got {bins}")
        vals = series._non_na()
        if not vals:
            return Series([None] * len(series), index=list(series._index), name=series.name)
        lo = min(vals)
        hi = max(vals)
        rng = hi - lo
        if rng == 0:
            # all values identical — single bin
            edges = [lo - 0.5, lo + 0.5]
        else:
            # extend left edge slightly so minimum is included
            edges = [lo - rng * 0.001] + [lo + rng * i / bins for i in range(1, bins)] + [hi]
    elif isinstance(bins, list):
        if len(bins) < 2:
            raise AtraxError("bins list must have at least 2 edges")
        edges = list(bins)
    else:
        raise AtraxError(f"bins must be int or list, got {type(bins).__name__}")

    n_bins = len(edges) - 1
    if labels is not None and len(labels) != n_bins:
        raise AtraxError(f"labels must have length {n_bins}, got {len(labels)}")

    if labels is None:
        bin_labels = _make_interval_labels(edges)
    else:
        bin_labels = list(labels)

    return _assign_bins(series, edges, bin_labels)


def _make_interval_labels(edges: list[float]) -> list[str]:
    """Generate interval labels like '(0.0, 25.0]' from bin edges."""
    labels = []
    for i in range(len(edges) - 1):
        left = edges[i]
        right = edges[i + 1]
        # format nicely — drop decimal if integer
        lf = f"{left:g}"
        rf = f"{right:g}"
        labels.append(f"({lf}, {rf}]")
    return labels


def _assign_bins(series: Series, edges: list[float], labels: list[str]) -> Series:
    """Assign each value in *series* to a bin based on *edges*."""
    n_bins = len(edges) - 1
    # ensure labels matches actual number of bins
    if len(labels) < n_bins:
        # when qcut deduplicates edges, we may have fewer labels than expected
        labels = labels + [labels[-1]] * (n_bins - len(labels))
    elif len(labels) > n_bins:
        labels = labels[:n_bins]

    data: list[Any] = []
    for v in series._data:
        if is_na(v):
            data.append(None)
            continue
        # find the bin: right-closed intervals (left, right]
        # first bin also includes left edge (closed on both sides)
        if v < edges[0] or v > edges[-1]:
            data.append(None)
            continue
        # use bisect to find the right bin
        idx = bisect.bisect_right(edges, v) - 1
        # clamp to valid range
        idx = max(0, min(idx, n_bins - 1))
        data.append(labels[idx])

    return Series(data, index=list(series._index), name=series.name)
