"""Type helpers, missing-value sentinel, and error hierarchy for Atrax."""

from __future__ import annotations

import math
from typing import Any


# ---------------------------------------------------------------------------
# Missing-value sentinel
# ---------------------------------------------------------------------------

NA = float("nan")


def is_na(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return False


# ---------------------------------------------------------------------------
# Dtype helpers
# ---------------------------------------------------------------------------

_SUPPORTED_DTYPES = (int, float, str, bool)


def _infer_dtype(values: list) -> type | None:
    seen: set[type] = set()
    for v in values:
        if is_na(v):
            continue
        seen.add(type(v))
    if not seen:
        return None
    if len(seen) == 1:
        return seen.pop()
    # bool is subclass of int — if we see both, call it int
    if seen == {bool, int}:
        return int
    # int + float → float
    if seen <= {int, float, bool}:
        return float
    return object


def _coerce_value(value: Any, dtype: type) -> Any:
    if is_na(value):
        if dtype is str:
            return None
        return NA
    try:
        return dtype(value)
    except (ValueError, TypeError) as exc:
        raise AtraxTypeError(
            f"Cannot cast {value!r} ({type(value).__name__}) to {dtype.__name__}"
        ) from exc


def _coerce_dtype(values: list, dtype: type | None) -> list:
    if dtype is None:
        return list(values)
    if dtype not in _SUPPORTED_DTYPES and dtype is not object:
        raise AtraxTypeError(f"Unsupported dtype: {dtype}")
    if dtype is object:
        return list(values)
    return [_coerce_value(v, dtype) for v in values]


# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------


class AtraxError(Exception):
    """Base exception for all Atrax errors."""


class AtraxIndexError(AtraxError):
    """Raised for invalid label or positional lookups."""


class AtraxTypeError(AtraxError):
    """Raised for invalid dtype coercion or type mismatches."""


class AtraxKeyError(AtraxError):
    """Raised for missing column names in a DataSet."""
