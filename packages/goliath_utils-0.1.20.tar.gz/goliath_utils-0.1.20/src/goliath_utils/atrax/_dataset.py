"""Atrax DataSet — a lightweight, pure-Python alternative to pandas DataFrame."""

from __future__ import annotations

import operator
from typing import Any, Callable, Iterator

from ._series import Series
from ._types import (
    NA,
    AtraxError,
    AtraxIndexError,
    AtraxKeyError,
    AtraxTypeError,
    is_na,
    _infer_dtype,
)


# ---------------------------------------------------------------------------
# Indexer helpers
# ---------------------------------------------------------------------------


class _DSLocIndexer:
    """Label-based indexer accessed via ``DataSet.loc``."""

    __slots__ = ("_ds",)

    def __init__(self, ds: DataSet) -> None:
        self._ds = ds

    def __getitem__(self, key: Any) -> Any:
        if isinstance(key, tuple):
            row_key, col_key = key
            result = self._ds._row_loc(row_key)
            if isinstance(result, Series):
                # single row → select from the row Series by column name
                if isinstance(col_key, str):
                    return result._label_scalar(col_key)
                if isinstance(col_key, list):
                    return result._label_select(col_key)
                return result
            return result._col_select(col_key)
        return self._ds._row_loc(key)

    def __setitem__(self, key: Any, value: Any) -> None:
        if isinstance(key, tuple):
            row_key, col_key = key
            if not isinstance(col_key, str):
                raise AtraxKeyError("Column key for .loc assignment must be a string")
            self._ds._loc_set(row_key, col_key, value)
        else:
            raise AtraxError(".loc assignment requires a (row, column) tuple key")


class _DSILocIndexer:
    """Position-based indexer accessed via ``DataSet.iloc``."""

    __slots__ = ("_ds",)

    def __init__(self, ds: DataSet) -> None:
        self._ds = ds

    def __getitem__(self, key: Any) -> Any:
        if isinstance(key, tuple):
            row_key, col_key = key
            result = self._ds._row_iloc(row_key)
            if isinstance(result, Series):
                # single row → select by position from the row Series
                if isinstance(col_key, int):
                    return result._pos_scalar(col_key)
                if isinstance(col_key, list):
                    return result._pos_select(col_key)
                if isinstance(col_key, slice):
                    return result._pos_slice(col_key)
                return result
            return result._col_iselect(col_key)
        return self._ds._row_iloc(key)


# ---------------------------------------------------------------------------
# DataSet
# ---------------------------------------------------------------------------


class DataSet:
    """A two-dimensional labelled data structure with columns of potentially
    different types.

    Construct from a dict of lists/Series, a list of dicts, or another DataSet.
    Pure Python — zero external dependencies.
    """

    __hash__ = None  # unhashable

    def __init__(
        self,
        data: Any = None,
        index: list | None = None,
        columns: list[str] | None = None,
    ) -> None:
        if isinstance(data, DataSet):
            self._col_order = list(data._col_order)
            self._index = list(data._index) if index is None else list(index)
            self._columns: dict[str, Series] = {}
            for col in self._col_order:
                s = data._columns[col]
                self._columns[col] = Series(
                    list(s._data), index=list(self._index), dtype=s.dtype, name=col,
                )

        elif isinstance(data, dict):
            self._col_order = list(columns) if columns is not None else list(data.keys())
            # figure out length
            n = None
            for k in self._col_order:
                v = data.get(k)
                if v is None:
                    continue
                if isinstance(v, Series):
                    n = len(v)
                    break
                if isinstance(v, list):
                    n = len(v)
                    break

            if index is not None:
                self._index = list(index)
            elif n is not None:
                self._index = list(range(n))
            else:
                self._index = []

            self._columns = {}
            for col in self._col_order:
                v = data.get(col)
                if v is None:
                    self._columns[col] = Series(
                        [NA] * len(self._index), index=list(self._index), name=col,
                    )
                elif isinstance(v, Series):
                    self._columns[col] = Series(
                        list(v._data), index=list(self._index), dtype=v.dtype, name=col,
                    )
                elif isinstance(v, list):
                    if len(v) != len(self._index):
                        raise AtraxError(
                            f"Column {col!r} has {len(v)} elements, "
                            f"expected {len(self._index)}"
                        )
                    self._columns[col] = Series(v, index=list(self._index), name=col)
                else:
                    # scalar broadcast
                    self._columns[col] = Series(
                        [v] * len(self._index), index=list(self._index), name=col,
                    )

        elif isinstance(data, list):
            # list of dicts
            if not data:
                self._col_order = list(columns) if columns is not None else []
                self._index = list(index) if index is not None else []
                self._columns = {}
                for col in self._col_order:
                    self._columns[col] = Series([], name=col)
            else:
                # collect column names preserving first-seen order
                if columns is not None:
                    self._col_order = list(columns)
                else:
                    seen: set[str] = set()
                    col_order: list[str] = []
                    for row in data:
                        for k in row:
                            if k not in seen:
                                seen.add(k)
                                col_order.append(k)
                    self._col_order = col_order

                self._index = list(index) if index is not None else list(range(len(data)))
                if len(self._index) != len(data):
                    raise AtraxError(
                        f"Index length {len(self._index)} doesn't match "
                        f"data length {len(data)}"
                    )

                self._columns = {}
                for col in self._col_order:
                    vals = [row.get(col, NA) for row in data]
                    self._columns[col] = Series(vals, index=list(self._index), name=col)

        elif data is None:
            self._col_order = list(columns) if columns is not None else []
            self._index = list(index) if index is not None else []
            self._columns = {}
            for col in self._col_order:
                self._columns[col] = Series(
                    [NA] * len(self._index), index=list(self._index), name=col,
                )
        else:
            raise AtraxTypeError(
                f"DataSet does not support construction from {type(data).__name__}"
            )

    # -- class-level builder ------------------------------------------------

    @classmethod
    def _build(
        cls,
        columns: dict[str, Series],
        index: list,
        col_order: list[str],
    ) -> DataSet:
        """Fast DataSet constructor that bypasses __init__."""
        ds = cls.__new__(cls)
        ds._columns = columns
        ds._index = index
        ds._col_order = col_order
        return ds

    # -- properties --------------------------------------------------------

    @property
    def columns(self) -> list[str]:
        return list(self._col_order)

    @property
    def index(self) -> list:
        return list(self._index)

    @property
    def shape(self) -> tuple[int, int]:
        return (len(self._index), len(self._col_order))

    @property
    def size(self) -> int:
        return len(self._index) * len(self._col_order)

    @property
    def empty(self) -> bool:
        return len(self._index) == 0 or len(self._col_order) == 0

    @property
    def dtypes(self) -> Series:
        data = [self._columns[c].dtype for c in self._col_order]
        return Series(data, index=list(self._col_order), name="dtypes")

    @property
    def values(self) -> list[list]:
        n = len(self._index)
        result = []
        for i in range(n):
            row = [self._columns[c]._data[i] for c in self._col_order]
            result.append(row)
        return result

    # -- indexers ----------------------------------------------------------

    @property
    def loc(self) -> _DSLocIndexer:
        return _DSLocIndexer(self)

    @property
    def iloc(self) -> _DSILocIndexer:
        return _DSILocIndexer(self)

    # -- column selection / mutation ---------------------------------------

    def __getitem__(self, key: Any) -> Series | DataSet:
        if isinstance(key, str):
            if key not in self._columns:
                raise AtraxKeyError(f"Column {key!r} not found")
            return self._columns[key]
        if isinstance(key, list):
            # list of column names
            return self._col_select(key)
        if isinstance(key, Series):
            # boolean mask on rows
            return self._row_mask(key)
        raise AtraxKeyError(f"Invalid key type: {type(key).__name__}")

    def __setitem__(self, key: str, value: Any) -> None:
        if not isinstance(key, str):
            raise AtraxKeyError("Column key must be a string")
        if isinstance(value, Series):
            if len(value) != len(self._index):
                raise AtraxError(
                    f"Length mismatch: value has {len(value)} elements, "
                    f"DataSet has {len(self._index)} rows"
                )
            col = Series(list(value._data), index=list(self._index), dtype=value.dtype, name=key)
        elif isinstance(value, list):
            if len(value) != len(self._index):
                raise AtraxError(
                    f"Length mismatch: value has {len(value)} elements, "
                    f"DataSet has {len(self._index)} rows"
                )
            col = Series(value, index=list(self._index), name=key)
        else:
            # scalar broadcast
            col = Series([value] * len(self._index), index=list(self._index), name=key)

        self._columns[key] = col
        if key not in self._col_order:
            self._col_order.append(key)

    def __delitem__(self, key: str) -> None:
        if key not in self._columns:
            raise AtraxKeyError(f"Column {key!r} not found")
        del self._columns[key]
        self._col_order.remove(key)

    def __contains__(self, key: Any) -> bool:
        return key in self._columns

    # -- internal row selection helpers ------------------------------------

    def _row_loc(self, key: Any) -> DataSet | Series:
        if isinstance(key, Series):
            return self._row_mask(key)
        if isinstance(key, list):
            return self._row_label_select(key)
        if isinstance(key, slice):
            return self._row_label_slice(key)
        # scalar label — return a Series keyed by column names
        return self._row_scalar_loc(key)

    def _row_scalar_loc(self, label: Any) -> Series:
        positions = [i for i, l in enumerate(self._index) if l == label]
        if not positions:
            raise AtraxIndexError(f"Label {label!r} not in index")
        if len(positions) == 1:
            pos = positions[0]
            data = [self._columns[c]._data[pos] for c in self._col_order]
            return Series(data, index=list(self._col_order), name=label)
        # duplicate labels — return DataSet
        new_index = [self._index[p] for p in positions]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[p] for p in positions]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def _row_label_select(self, labels: list) -> DataSet:
        label_map: dict[Any, list[int]] = {}
        for i, lab in enumerate(self._index):
            label_map.setdefault(lab, []).append(i)

        positions = []
        for lab in labels:
            if lab not in label_map:
                raise AtraxIndexError(f"Label {lab!r} not in index")
            positions.extend(label_map[lab])

        new_index = [self._index[p] for p in positions]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[p] for p in positions]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def _row_label_slice(self, slc: slice) -> DataSet:
        start_idx = 0
        stop_idx = len(self._index)
        if slc.start is not None:
            for i, lab in enumerate(self._index):
                if lab == slc.start:
                    start_idx = i
                    break
            else:
                raise AtraxIndexError(f"Label {slc.start!r} not in index")
        if slc.stop is not None:
            for i in range(len(self._index) - 1, -1, -1):
                if self._index[i] == slc.stop:
                    stop_idx = i + 1  # inclusive
                    break
            else:
                raise AtraxIndexError(f"Label {slc.stop!r} not in index")

        new_index = self._index[start_idx:stop_idx]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = self._columns[c]._data[start_idx:stop_idx]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def _row_mask(self, mask: Series) -> DataSet:
        if len(mask) != len(self._index):
            raise AtraxError(
                f"Boolean mask length {len(mask)} doesn't match "
                f"DataSet length {len(self._index)}"
            )
        positions = [i for i, m in enumerate(mask._data) if m is True]
        new_index = [self._index[p] for p in positions]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[p] for p in positions]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def _row_iloc(self, key: Any) -> DataSet | Series:
        if isinstance(key, list):
            return self._row_pos_select(key)
        if isinstance(key, slice):
            return self._row_pos_slice(key)
        if isinstance(key, int):
            return self._row_scalar_iloc(key)
        raise AtraxIndexError(f"Invalid iloc row key type: {type(key).__name__}")

    def _row_scalar_iloc(self, pos: int) -> Series:
        n = len(self._index)
        if pos < -n or pos >= n:
            raise AtraxIndexError(f"Position {pos} out of range for length {n}")
        data = [self._columns[c]._data[pos] for c in self._col_order]
        return Series(data, index=list(self._col_order), name=self._index[pos])

    def _row_pos_select(self, positions: list[int]) -> DataSet:
        n = len(self._index)
        for p in positions:
            if p < -n or p >= n:
                raise AtraxIndexError(f"Position {p} out of range for length {n}")
        new_index = [self._index[p] for p in positions]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[p] for p in positions]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def _row_pos_slice(self, slc: slice) -> DataSet:
        new_index = self._index[slc]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = self._columns[c]._data[slc]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    # -- column selection helpers ------------------------------------------

    def _col_select(self, key: Any) -> Series | DataSet:
        if isinstance(key, str):
            if key not in self._columns:
                raise AtraxKeyError(f"Column {key!r} not found")
            return self._columns[key]
        if isinstance(key, list):
            for k in key:
                if k not in self._columns:
                    raise AtraxKeyError(f"Column {k!r} not found")
            cols = {k: self._columns[k] for k in key}
            return DataSet._build(cols, list(self._index), list(key))
        raise AtraxKeyError(f"Invalid column key type: {type(key).__name__}")

    def _col_iselect(self, key: Any) -> Series | DataSet:
        ncols = len(self._col_order)
        if isinstance(key, int):
            if key < -ncols or key >= ncols:
                raise AtraxIndexError(
                    f"Column position {key} out of range for {ncols} columns"
                )
            col_name = self._col_order[key]
            return self._columns[col_name]
        if isinstance(key, list):
            col_names = []
            for k in key:
                if k < -ncols or k >= ncols:
                    raise AtraxIndexError(
                        f"Column position {k} out of range for {ncols} columns"
                    )
                col_names.append(self._col_order[k])
            cols = {c: self._columns[c] for c in col_names}
            return DataSet._build(cols, list(self._index), col_names)
        if isinstance(key, slice):
            col_names = self._col_order[key]
            cols = {c: self._columns[c] for c in col_names}
            return DataSet._build(cols, list(self._index), list(col_names))
        raise AtraxIndexError(f"Invalid iloc column key type: {type(key).__name__}")

    # -- loc assignment helper ---------------------------------------------

    def _loc_set(self, row_key: Any, col_name: str, value: Any) -> None:
        # Ensure column exists, create if needed
        if col_name not in self._columns:
            self[col_name] = [NA] * len(self._index)

        if isinstance(row_key, slice):
            start_idx = 0
            stop_idx = len(self._index)
            if row_key.start is not None:
                for i, lab in enumerate(self._index):
                    if lab == row_key.start:
                        start_idx = i
                        break
                else:
                    raise AtraxIndexError(f"Label {row_key.start!r} not in index")
            if row_key.stop is not None:
                for i in range(len(self._index) - 1, -1, -1):
                    if self._index[i] == row_key.stop:
                        stop_idx = i + 1
                        break
                else:
                    raise AtraxIndexError(f"Label {row_key.stop!r} not in index")
            positions = list(range(start_idx, stop_idx))
        else:
            positions = [i for i, l in enumerate(self._index) if l == row_key]
            if not positions:
                raise AtraxIndexError(f"Label {row_key!r} not in index")

        col_data = self._columns[col_name]._data
        if isinstance(value, (list, Series)):
            vals = list(value._data) if isinstance(value, Series) else value
            if len(vals) != len(positions):
                raise AtraxError(
                    f"Length mismatch: value has {len(vals)} elements, "
                    f"target has {len(positions)} rows"
                )
            for p, v in zip(positions, vals):
                col_data[p] = v
        else:
            for p in positions:
                col_data[p] = value

    # -- aggregation -------------------------------------------------------

    def _agg_axis0(self, method: str, **kwargs: Any) -> Series:
        data = []
        idx = []
        for c in self._col_order:
            s = self._columns[c]
            try:
                data.append(getattr(s, method)(**kwargs))
                idx.append(c)
            except (TypeError, AtraxTypeError):
                continue
        return Series(data, index=idx)

    def _agg_axis1(self, method: str, **kwargs: Any) -> Series:
        data = []
        for i in range(len(self._index)):
            row_vals = [self._columns[c]._data[i] for c in self._col_order]
            row_series = Series(row_vals, index=list(self._col_order))
            try:
                data.append(getattr(row_series, method)(**kwargs))
            except (TypeError, AtraxTypeError):
                data.append(NA)
        return Series(data, index=list(self._index))

    def sum(self, axis: int = 0) -> Series:
        return self._agg_axis0("sum") if axis == 0 else self._agg_axis1("sum")

    def mean(self, axis: int = 0) -> Series:
        return self._agg_axis0("mean") if axis == 0 else self._agg_axis1("mean")

    def median(self, axis: int = 0) -> Series:
        return self._agg_axis0("median") if axis == 0 else self._agg_axis1("median")

    def min(self, axis: int = 0) -> Series:
        return self._agg_axis0("min") if axis == 0 else self._agg_axis1("min")

    def max(self, axis: int = 0) -> Series:
        return self._agg_axis0("max") if axis == 0 else self._agg_axis1("max")

    def std(self, axis: int = 0, ddof: int = 1) -> Series:
        return self._agg_axis0("std", ddof=ddof) if axis == 0 else self._agg_axis1("std", ddof=ddof)

    def var(self, axis: int = 0, ddof: int = 1) -> Series:
        return self._agg_axis0("var", ddof=ddof) if axis == 0 else self._agg_axis1("var", ddof=ddof)

    def count(self, axis: int = 0) -> Series:
        return self._agg_axis0("count") if axis == 0 else self._agg_axis1("count")

    def nunique(self, axis: int = 0) -> Series:
        return self._agg_axis0("nunique") if axis == 0 else self._agg_axis1("nunique")

    def any(self, axis: int = 0) -> Series:
        return self._agg_axis0("any") if axis == 0 else self._agg_axis1("any")

    def all(self, axis: int = 0) -> Series:
        return self._agg_axis0("all") if axis == 0 else self._agg_axis1("all")

    def unique(self, column: str) -> list:
        """Return a list of unique non-NA values in a column, preserving first-seen order.

        Parameters:
            column: The column name.

        Returns:
            A list of unique values.

        Example::

            ds.unique("category_description")
            # ["GROCERY", "DAIRY", "MEAT", "PRODUCE"]
        """
        if column not in self._columns:
            raise AtraxKeyError(f"Column not found: {column!r}")
        return self._columns[column].unique()

    def describe(self) -> DataSet:
        stats = ["count", "mean", "std", "min", "median", "max"]
        result_cols: dict[str, Series] = {}
        col_order: list[str] = []
        for c in self._col_order:
            s = self._columns[c]
            if s.dtype not in (int, float):
                continue
            vals = [
                float(s.count()),
                s.mean(),
                s.std(),
                s.min(),
                s.median(),
                s.max(),
            ]
            result_cols[c] = Series(vals, index=list(stats), name=c)
            col_order.append(c)
        return DataSet._build(result_cols, list(stats), col_order)

    def info(self) -> str:
        """Print a concise summary of the DataSet (like ``pandas.DataFrame.info``).

        Shows the number of rows, columns, column names with their dtype,
        non-null count, and memory estimate.

        Returns:
            A formatted string with the summary.  Also prints it.

        Example::

            ds.info()
            # <DataSet: 50 rows x 5 columns>
            # Column               Dtype    Non-Null
            # ─────────────────────────────────────────
            # sale_date             str      50
            # storeid               int      50
            # total_sales           float    48
            # discount_amount       float    35
            # customer_name         str      42
            # ─────────────────────────────────────────
            # Memory: ~2.0 KB
        """
        import sys

        rows = len(self._index)
        cols = len(self._col_order)
        lines: list[str] = []
        lines.append(f"<DataSet: {rows} rows x {cols} columns>")
        lines.append(f"{'Column':<22s} {'Dtype':<9s} {'Non-Null':>8s}")
        lines.append("─" * 42)

        total_bytes = 0
        for c in self._col_order:
            s = self._columns[c]
            dtype_name = s.dtype.__name__ if s.dtype else "object"
            non_null = s.count()
            lines.append(f"{c:<22s} {dtype_name:<9s} {non_null:>8d}")
            # Rough memory estimate
            for v in s._data:
                total_bytes += sys.getsizeof(v)

        lines.append("─" * 42)
        if total_bytes < 1024:
            mem = f"{total_bytes} B"
        elif total_bytes < 1024 * 1024:
            mem = f"~{total_bytes / 1024:.1f} KB"
        else:
            mem = f"~{total_bytes / (1024 * 1024):.1f} MB"
        lines.append(f"Memory: {mem}")

        result = "\n".join(lines)
        print(result)
        return result

    # -- arithmetic --------------------------------------------------------

    def _binary_op(self, other: Any, op: Callable) -> DataSet:
        if isinstance(other, DataSet):
            # align on columns
            all_cols = list(dict.fromkeys(self._col_order + other._col_order))
            cols: dict[str, Series] = {}
            for c in all_cols:
                left = self._columns.get(c)
                right = other._columns.get(c)
                if left is not None and right is not None:
                    cols[c] = left._binary_op(right, op)
                    cols[c].name = c
                elif left is not None:
                    na_s = Series([NA] * len(other._index), index=list(other._index), name=c)
                    cols[c] = left._binary_op(na_s, op)
                    cols[c].name = c
                else:
                    na_s = Series([NA] * len(self._index), index=list(self._index), name=c)
                    cols[c] = na_s._binary_op(right, op)
                    cols[c].name = c
            new_index = cols[all_cols[0]].index if all_cols else list(self._index)
            return DataSet._build(cols, new_index, all_cols)

        if isinstance(other, Series):
            # broadcast Series across columns by matching column names to Series index
            cols = {}
            for c in self._col_order:
                try:
                    scalar = other._label_scalar(c)
                except AtraxIndexError:
                    scalar = NA
                cols[c] = self._columns[c]._binary_op(scalar, op)
                cols[c].name = c
            return DataSet._build(cols, list(self._index), list(self._col_order))

        # scalar
        cols = {}
        for c in self._col_order:
            cols[c] = self._columns[c]._binary_op(other, op)
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def _rbinary_op(self, other: Any, op: Callable) -> DataSet:
        cols = {}
        for c in self._col_order:
            cols[c] = self._columns[c]._rbinary_op(other, op)
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def __add__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.add)

    def __radd__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.add)

    def __sub__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.sub)

    def __rsub__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.sub)

    def __mul__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.mul)

    def __rmul__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.mul)

    def __truediv__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.truediv)

    def __rtruediv__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.truediv)

    def __floordiv__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.floordiv)

    def __rfloordiv__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.floordiv)

    def __mod__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.mod)

    def __rmod__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.mod)

    def __pow__(self, other: Any) -> DataSet:
        return self._binary_op(other, operator.pow)

    def __rpow__(self, other: Any) -> DataSet:
        return self._rbinary_op(other, operator.pow)

    def __neg__(self) -> DataSet:
        cols = {}
        for c in self._col_order:
            cols[c] = -self._columns[c]
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    # -- comparison --------------------------------------------------------

    def _compare_op(self, other: Any, op: Callable) -> DataSet:
        if isinstance(other, DataSet):
            all_cols = list(dict.fromkeys(self._col_order + other._col_order))
            cols: dict[str, Series] = {}
            for c in all_cols:
                left = self._columns.get(c)
                right = other._columns.get(c)
                if left is not None and right is not None:
                    cols[c] = left._compare_op(right, op)
                    cols[c].name = c
                else:
                    n = len(self._index)
                    cols[c] = Series([False] * n, index=list(self._index), dtype=bool, name=c)
            new_index = list(self._index)
            return DataSet._build(cols, new_index, all_cols)

        if isinstance(other, Series):
            cols = {}
            for c in self._col_order:
                try:
                    scalar = other._label_scalar(c)
                except AtraxIndexError:
                    scalar = NA
                cols[c] = self._columns[c]._compare_op(scalar, op)
                cols[c].name = c
            return DataSet._build(cols, list(self._index), list(self._col_order))

        # scalar
        cols = {}
        for c in self._col_order:
            cols[c] = self._columns[c]._compare_op(other, op)
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def __eq__(self, other: Any) -> DataSet:  # type: ignore[override]
        return self._compare_op(other, operator.eq)

    def __ne__(self, other: Any) -> DataSet:  # type: ignore[override]
        return self._compare_op(other, operator.ne)

    def __lt__(self, other: Any) -> DataSet:
        return self._compare_op(other, operator.lt)

    def __gt__(self, other: Any) -> DataSet:
        return self._compare_op(other, operator.gt)

    def __le__(self, other: Any) -> DataSet:
        return self._compare_op(other, operator.le)

    def __ge__(self, other: Any) -> DataSet:
        return self._compare_op(other, operator.ge)

    # -- boolean ops -------------------------------------------------------

    def __and__(self, other: Any) -> DataSet:
        cols = {}
        if isinstance(other, DataSet):
            for c in self._col_order:
                if c in other._columns:
                    cols[c] = self._columns[c] & other._columns[c]
                else:
                    cols[c] = Series([False] * len(self._index), index=list(self._index), dtype=bool, name=c)
                cols[c].name = c
        else:
            for c in self._col_order:
                cols[c] = self._columns[c] & other
                cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def __or__(self, other: Any) -> DataSet:
        cols = {}
        if isinstance(other, DataSet):
            for c in self._col_order:
                if c in other._columns:
                    cols[c] = self._columns[c] | other._columns[c]
                else:
                    cols[c] = self._columns[c]
                cols[c].name = c
        else:
            for c in self._col_order:
                cols[c] = self._columns[c] | other
                cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def __invert__(self) -> DataSet:
        cols = {}
        for c in self._col_order:
            cols[c] = ~self._columns[c]
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def __bool__(self) -> bool:
        raise AtraxTypeError(
            "The truth value of a DataSet is ambiguous. Use .any() or .all()."
        )

    # -- transforms --------------------------------------------------------

    def sort_values(self, by: str | list[str], ascending: bool = True) -> DataSet:
        if isinstance(by, str):
            by = [by]
        for col in by:
            if col not in self._columns:
                raise AtraxKeyError(f"Column {col!r} not found")

        indices = list(range(len(self._index)))

        def sort_key(i: int) -> tuple:
            vals = []
            for col in by:
                v = self._columns[col]._data[i]
                # NA sorts last
                vals.append((1 if is_na(v) else 0, v if not is_na(v) else 0))
            return tuple(vals)

        indices.sort(key=sort_key, reverse=not ascending)

        new_index = [self._index[i] for i in indices]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[i] for i in indices]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def sort_index(self, ascending: bool = True) -> DataSet:
        indices = list(range(len(self._index)))
        indices.sort(key=lambda i: self._index[i], reverse=not ascending)
        new_index = [self._index[i] for i in indices]
        cols: dict[str, Series] = {}
        for c in self._col_order:
            vals = [self._columns[c]._data[i] for i in indices]
            cols[c] = Series(vals, index=list(new_index), name=c)
        return DataSet._build(cols, new_index, list(self._col_order))

    def isna(self) -> DataSet:
        """Return a boolean DataSet where ``True`` indicates NA/None values.

        Example::

            ds.isna()
            # Shows True for every cell that is NA or None
        """
        cols = {c: self._columns[c].isna() for c in self._col_order}
        for c in cols:
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def notna(self) -> DataSet:
        """Return a boolean DataSet where ``True`` indicates non-NA values.

        Example::

            ds.notna()
            # Shows True for every cell that has a value
        """
        cols = {c: self._columns[c].notna() for c in self._col_order}
        for c in cols:
            cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def fillna(self, value: Any) -> DataSet:
        cols = {}
        if isinstance(value, dict):
            for c in self._col_order:
                if c in value:
                    cols[c] = self._columns[c].fillna(value[c])
                else:
                    cols[c] = self._columns[c].copy()
                cols[c].name = c
        else:
            for c in self._col_order:
                cols[c] = self._columns[c].fillna(value)
                cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def dropna(self, axis: int = 0, how: str = "any") -> DataSet:
        if axis == 0:
            # drop rows
            keep = []
            for i in range(len(self._index)):
                na_count = sum(
                    1 for c in self._col_order if is_na(self._columns[c]._data[i])
                )
                if how == "any" and na_count == 0:
                    keep.append(i)
                elif how == "all" and na_count < len(self._col_order):
                    keep.append(i)
            new_index = [self._index[i] for i in keep]
            cols: dict[str, Series] = {}
            for c in self._col_order:
                vals = [self._columns[c]._data[i] for i in keep]
                cols[c] = Series(vals, index=list(new_index), name=c)
            return DataSet._build(cols, new_index, list(self._col_order))
        else:
            # drop columns
            keep_cols = []
            for c in self._col_order:
                na_count = sum(1 for v in self._columns[c]._data if is_na(v))
                if how == "any" and na_count == 0:
                    keep_cols.append(c)
                elif how == "all" and na_count < len(self._index):
                    keep_cols.append(c)
            cols = {c: self._columns[c].copy() for c in keep_cols}
            return DataSet._build(cols, list(self._index), keep_cols)

    def apply(self, func: Callable, axis: int = 0) -> Series | DataSet:
        if axis == 0:
            # apply to each column
            results = {}
            for c in self._col_order:
                result = func(self._columns[c])
                results[c] = result
            # if results are scalars, return a Series
            if results and not isinstance(next(iter(results.values())), Series):
                return Series(
                    list(results.values()),
                    index=list(self._col_order),
                )
            # results are Series — build DataSet
            cols = {}
            for c in self._col_order:
                r = results[c]
                cols[c] = r if isinstance(r, Series) else Series([r], name=c)
                cols[c].name = c
            return DataSet._build(cols, list(self._index), list(self._col_order))
        else:
            # apply to each row
            data = []
            for i in range(len(self._index)):
                row = Series(
                    [self._columns[c]._data[i] for c in self._col_order],
                    index=list(self._col_order),
                )
                data.append(func(row))
            return Series(data, index=list(self._index))

    def astype(self, dtype: type | dict[str, type]) -> DataSet:
        cols = {}
        if isinstance(dtype, dict):
            for c in self._col_order:
                if c in dtype:
                    cols[c] = self._columns[c].astype(dtype[c])
                else:
                    cols[c] = self._columns[c].copy()
                cols[c].name = c
        else:
            for c in self._col_order:
                cols[c] = self._columns[c].astype(dtype)
                cols[c].name = c
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def rename(self, columns: dict[str, str]) -> DataSet:
        new_col_order = [columns.get(c, c) for c in self._col_order]
        cols = {}
        for old, new in zip(self._col_order, new_col_order):
            s = self._columns[old].copy()
            s.name = new
            cols[new] = s
        return DataSet._build(cols, list(self._index), new_col_order)

    def reset_index(self, drop: bool = False) -> DataSet:
        new_index = list(range(len(self._index)))
        if drop:
            cols = {}
            for c in self._col_order:
                cols[c] = Series(list(self._columns[c]._data), index=list(new_index), name=c)
            return DataSet._build(cols, new_index, list(self._col_order))
        # add old index as a column
        cols = {"index": Series(list(self._index), index=list(new_index), name="index")}
        new_col_order = ["index"] + list(self._col_order)
        for c in self._col_order:
            cols[c] = Series(list(self._columns[c]._data), index=list(new_index), name=c)
        return DataSet._build(cols, new_index, new_col_order)

    def drop(self, columns: str | list[str]) -> DataSet:
        if isinstance(columns, str):
            columns = [columns]
        for c in columns:
            if c not in self._columns:
                raise AtraxKeyError(f"Column {c!r} not found")
        new_col_order = [c for c in self._col_order if c not in columns]
        cols = {c: self._columns[c] for c in new_col_order}
        return DataSet._build(cols, list(self._index), new_col_order)

    def select_dtypes(self, include: type | list[type]) -> DataSet:
        if isinstance(include, type):
            include = [include]
        keep = [c for c in self._col_order if self._columns[c].dtype in include]
        cols = {c: self._columns[c] for c in keep}
        return DataSet._build(cols, list(self._index), keep)

    def copy(self) -> DataSet:
        cols = {c: self._columns[c].copy() for c in self._col_order}
        return DataSet._build(cols, list(self._index), list(self._col_order))

    def head(self, n: int = 5) -> DataSet:
        return self._row_pos_slice(slice(None, n))

    def tail(self, n: int = 5) -> DataSet:
        if n == 0:
            return self._row_pos_slice(slice(0, 0))
        return self._row_pos_slice(slice(-n, None))

    def to_dict(self, orient: str = "dict") -> dict:
        if orient == "dict":
            return {c: dict(zip(self._index, self._columns[c]._data)) for c in self._col_order}
        elif orient == "list":
            return {c: list(self._columns[c]._data) for c in self._col_order}
        elif orient == "records":
            records = []
            for i in range(len(self._index)):
                row = {c: self._columns[c]._data[i] for c in self._col_order}
                records.append(row)
            return records
        raise AtraxError(f"Invalid orient: {orient!r}")

    def to_json(self, nan_value: Any = None) -> list[dict]:
        """Return a list of dicts with all values safe for ``json.dumps()``.

        This is the recommended way to return DataSet results from a FastAPI
        endpoint, Lambda handler, or any context that needs JSON-safe output.

        - ``NA``, ``NaN``, ``None`` → *nan_value* (default ``None`` → JSON ``null``)
        - ``inf`` / ``-inf`` → ``None``
        - ``datetime``, ``date``, ``time`` → ISO 8601 string
        - ``Decimal`` → ``float``
        - ``bytes`` → hex string
        - Everything else that isn't a basic JSON type → ``str(value)``

        Parameters:
            nan_value: Replacement for missing values.  Defaults to ``None``
                       (JSON ``null``).  Pass ``0`` to replace with zeros.

        Example::

            # In a FastAPI endpoint:
            @app.get("/sales")
            def get_sales():
                ds = DataSet(db.fetch_all("SELECT * FROM sales LIMIT 100"))
                return ds.to_json()

            # Replace NaN with 0 instead of null:
            ds.to_json(nan_value=0)
        """
        import math
        from datetime import date, datetime, time
        from decimal import Decimal

        def _safe(v: Any) -> Any:
            if v is None:
                return nan_value
            if isinstance(v, float):
                if math.isnan(v):
                    return nan_value
                if math.isinf(v):
                    return None
                return v
            if isinstance(v, bool):
                return v
            if isinstance(v, int):
                return v
            if isinstance(v, str):
                return v
            if isinstance(v, Decimal):
                return float(v)
            if isinstance(v, datetime):
                return v.isoformat()
            if isinstance(v, date):
                return v.isoformat()
            if isinstance(v, time):
                return v.isoformat()
            if isinstance(v, bytes):
                return v.hex()
            if isinstance(v, (list, tuple)):
                return [_safe(item) for item in v]
            if isinstance(v, dict):
                return {k: _safe(val) for k, val in v.items()}
            return str(v)

        records: list[dict] = []
        for i in range(len(self._index)):
            row = {c: _safe(self._columns[c]._data[i]) for c in self._col_order}
            records.append(row)
        return records

    def to_series(self) -> Series:
        if len(self._col_order) != 1:
            raise AtraxError(
                f"to_series() requires exactly 1 column, got {len(self._col_order)}"
            )
        return self._columns[self._col_order[0]].copy()

    def equals(self, other: DataSet) -> bool:
        if not isinstance(other, DataSet):
            return False
        if self._col_order != other._col_order:
            return False
        if self._index != other._index:
            return False
        for c in self._col_order:
            a = self._columns[c]._data
            b = other._columns[c]._data
            for av, bv in zip(a, b):
                if is_na(av) and is_na(bv):
                    continue
                if av != bv:
                    return False
        return True

    # -- merge -------------------------------------------------------------

    def merge(
        self,
        other: DataSet,
        on: str | list[str] | None = None,
        how: str = "inner",
        left_on: str | list[str] | None = None,
        right_on: str | list[str] | None = None,
        suffixes: tuple[str, str] = ("_x", "_y"),
    ) -> DataSet:
        if on is not None:
            left_keys = [on] if isinstance(on, str) else list(on)
            right_keys = left_keys
        elif left_on is not None and right_on is not None:
            left_keys = [left_on] if isinstance(left_on, str) else list(left_on)
            right_keys = [right_on] if isinstance(right_on, str) else list(right_on)
        else:
            raise AtraxError("Must specify 'on' or both 'left_on' and 'right_on'")

        for k in left_keys:
            if k not in self._columns:
                raise AtraxKeyError(f"Left key {k!r} not found")
        for k in right_keys:
            if k not in other._columns:
                raise AtraxKeyError(f"Right key {k!r} not found")

        # build right index: key_tuple -> list[row positions]
        right_map: dict[tuple, list[int]] = {}
        for i in range(len(other._index)):
            key = tuple(other._columns[k]._data[i] for k in right_keys)
            right_map.setdefault(key, []).append(i)

        # figure out result columns
        # key columns come from left
        left_non_key = [c for c in self._col_order if c not in left_keys]
        right_non_key = [c for c in other._col_order if c not in right_keys]

        # handle column name conflicts
        left_suffix, right_suffix = suffixes
        conflict = set(left_non_key) & set(right_non_key)

        result_data: dict[str, list] = {}
        for k in left_keys:
            result_data[k] = []
        for c in left_non_key:
            name = c + left_suffix if c in conflict else c
            result_data[name] = []
        for c in right_non_key:
            name = c + right_suffix if c in conflict else c
            result_data[name] = []

        result_index: list = []
        right_matched: set[int] = set()
        row_counter = 0

        # probe
        for i in range(len(self._index)):
            left_key = tuple(self._columns[k]._data[i] for k in left_keys)
            matches = right_map.get(left_key, [])

            if matches:
                for j in matches:
                    right_matched.add(j)
                    result_index.append(row_counter)
                    row_counter += 1
                    for k in left_keys:
                        result_data[k].append(self._columns[k]._data[i])
                    for c in left_non_key:
                        name = c + left_suffix if c in conflict else c
                        result_data[name].append(self._columns[c]._data[i])
                    for c in right_non_key:
                        name = c + right_suffix if c in conflict else c
                        result_data[name].append(other._columns[c]._data[j])
            elif how in ("left", "outer"):
                result_index.append(row_counter)
                row_counter += 1
                for k in left_keys:
                    result_data[k].append(self._columns[k]._data[i])
                for c in left_non_key:
                    name = c + left_suffix if c in conflict else c
                    result_data[name].append(self._columns[c]._data[i])
                for c in right_non_key:
                    name = c + right_suffix if c in conflict else c
                    result_data[name].append(NA)

        # unmatched right rows
        if how in ("right", "outer"):
            for j in range(len(other._index)):
                if j not in right_matched:
                    result_index.append(row_counter)
                    row_counter += 1
                    for k_left, k_right in zip(left_keys, right_keys):
                        result_data[k_left].append(other._columns[k_right]._data[j])
                    for c in left_non_key:
                        name = c + left_suffix if c in conflict else c
                        result_data[name].append(NA)
                    for c in right_non_key:
                        name = c + right_suffix if c in conflict else c
                        result_data[name].append(other._columns[c]._data[j])

        col_order = list(result_data.keys())
        cols = {}
        for c in col_order:
            cols[c] = Series(result_data[c], index=list(result_index), name=c)
        return DataSet._build(cols, result_index, col_order)

    # -- groupby -----------------------------------------------------------

    def groupby(self, by: str | list[str]) -> _GroupBy:
        return _GroupBy(self, by)

    # -- reshape -----------------------------------------------------------

    @property
    def T(self) -> DataSet:
        new_col_order = [str(lab) for lab in self._index]
        new_index = list(self._col_order)
        cols: dict[str, Series] = {}
        for i, lab in enumerate(self._index):
            col_name = str(lab)
            vals = [self._columns[c]._data[i] for c in self._col_order]
            cols[col_name] = Series(vals, index=list(new_index), name=col_name)
        return DataSet._build(cols, new_index, new_col_order)

    def melt(
        self,
        id_vars: str | list[str] | None = None,
        value_vars: str | list[str] | None = None,
        var_name: str = "variable",
        value_name: str = "value",
    ) -> DataSet:
        if id_vars is None:
            id_vars = []
        elif isinstance(id_vars, str):
            id_vars = [id_vars]
        if value_vars is None:
            value_vars = [c for c in self._col_order if c not in id_vars]
        elif isinstance(value_vars, str):
            value_vars = [value_vars]

        result_data: dict[str, list] = {c: [] for c in id_vars}
        result_data[var_name] = []
        result_data[value_name] = []

        for val_col in value_vars:
            for i in range(len(self._index)):
                for c in id_vars:
                    result_data[c].append(self._columns[c]._data[i])
                result_data[var_name].append(val_col)
                result_data[value_name].append(self._columns[val_col]._data[i])

        n = len(result_data[var_name])
        new_index = list(range(n))
        col_order = list(id_vars) + [var_name, value_name]
        cols = {}
        for c in col_order:
            cols[c] = Series(result_data[c], index=list(new_index), name=c)
        return DataSet._build(cols, new_index, col_order)

    def pivot(
        self,
        index: str,
        columns: str,
        values: str,
    ) -> DataSet:
        if index not in self._columns:
            raise AtraxKeyError(f"Column {index!r} not found")
        if columns not in self._columns:
            raise AtraxKeyError(f"Column {columns!r} not found")
        if values not in self._columns:
            raise AtraxKeyError(f"Column {values!r} not found")

        # collect unique index values (preserving order) and column values
        idx_vals: list = []
        idx_seen: set = set()
        col_vals: list[str] = []
        col_seen: set = set()
        for i in range(len(self._index)):
            iv = self._columns[index]._data[i]
            cv = self._columns[columns]._data[i]
            if iv not in idx_seen:
                idx_seen.add(iv)
                idx_vals.append(iv)
            if cv not in col_seen:
                col_seen.add(cv)
                col_vals.append(str(cv))

        # build lookup
        lookup: dict[tuple, Any] = {}
        for i in range(len(self._index)):
            iv = self._columns[index]._data[i]
            cv = str(self._columns[columns]._data[i])
            lookup[(iv, cv)] = self._columns[values]._data[i]

        new_col_order = [str(cv) for cv in col_vals]
        cols = {}
        for cv in new_col_order:
            vals = [lookup.get((iv, cv), NA) for iv in idx_vals]
            cols[cv] = Series(vals, index=list(idx_vals), name=cv)
        return DataSet._build(cols, list(idx_vals), new_col_order)

    # -- display -----------------------------------------------------------

    def __repr__(self) -> str:
        if self.empty:
            return f"DataSet(columns={self._col_order})"

        max_rows = 60
        max_cols = 10
        n_rows = len(self._index)
        n_cols = len(self._col_order)

        # determine which rows to show
        if n_rows > max_rows:
            head_n = max_rows // 2
            tail_n = max_rows // 2
            show_rows = list(range(head_n)) + list(range(n_rows - tail_n, n_rows))
            row_truncated = True
        else:
            show_rows = list(range(n_rows))
            row_truncated = False

        # determine which columns to show
        if n_cols > max_cols:
            left_c = max_cols // 2
            right_c = max_cols // 2
            show_cols = self._col_order[:left_c] + self._col_order[-right_c:]
            col_truncated = True
        else:
            show_cols = list(self._col_order)
            col_truncated = False

        # build column widths
        col_widths: dict[str, int] = {}
        for c in show_cols:
            col_widths[c] = len(c)
            for i in show_rows:
                val_str = _format_value(self._columns[c]._data[i])
                col_widths[c] = builtins_max(col_widths[c], len(val_str))

        idx_strs = [str(self._index[i]) for i in show_rows]
        idx_width = builtins_max((len(s) for s in idx_strs), default=0)

        lines = []

        # header
        header_parts = [" " * idx_width]
        for ci, c in enumerate(show_cols):
            if col_truncated and ci == len(show_cols) // 2:
                header_parts.append("...")
            header_parts.append(f"{c:>{col_widths[c]}}")
        lines.append("    ".join(header_parts))

        # rows
        for ri, row_idx in enumerate(show_rows):
            if row_truncated and ri == len(show_rows) // 2:
                lines.append("...")
            parts = [f"{idx_strs[ri]:>{idx_width}}"]
            for ci, c in enumerate(show_cols):
                if col_truncated and ci == len(show_cols) // 2:
                    parts.append("...")
                val_str = _format_value(self._columns[c]._data[row_idx])
                parts.append(f"{val_str:>{col_widths[c]}}")
            lines.append("    ".join(parts))

        lines.append(f"\n[{n_rows} rows x {n_cols} columns]")
        return "\n".join(lines)

    # -- iteration ---------------------------------------------------------

    def __len__(self) -> int:
        return len(self._index)

    def __iter__(self) -> Iterator[str]:
        return iter(self._col_order)

    def items(self) -> Iterator[tuple[str, Series]]:
        for c in self._col_order:
            yield c, self._columns[c]

    def iterrows(self) -> Iterator[tuple[Any, Series]]:
        for i in range(len(self._index)):
            label = self._index[i]
            data = [self._columns[c]._data[i] for c in self._col_order]
            yield label, Series(data, index=list(self._col_order), name=label)

    def itertuples(self, name: str = "Row") -> Iterator[tuple]:
        for i in range(len(self._index)):
            vals = [self._index[i]] + [
                self._columns[c]._data[i] for c in self._col_order
            ]
            yield tuple(vals)


# ---------------------------------------------------------------------------
# GroupBy
# ---------------------------------------------------------------------------


class _GroupBy:
    """Grouped DataSet for split-apply-combine operations."""

    __slots__ = ("_ds", "_by", "_groups")

    def __init__(self, ds: DataSet, by: str | list[str]) -> None:
        self._ds = ds
        self._by = [by] if isinstance(by, str) else list(by)
        for k in self._by:
            if k not in ds._columns:
                raise AtraxKeyError(f"Column {k!r} not found")

        # build groups: key_tuple -> list[row_indices]
        groups: dict[tuple, list[int]] = {}
        for i in range(len(ds._index)):
            key = tuple(ds._columns[k]._data[i] for k in self._by)
            groups.setdefault(key, []).append(i)
        self._groups = groups

    def _agg_method(self, method: str, **kwargs: Any) -> DataSet:
        non_key_cols = [c for c in self._ds._col_order if c not in self._by]
        result_data: dict[str, list] = {k: [] for k in self._by}
        for c in non_key_cols:
            result_data[c] = []

        result_index: list = []
        row_counter = 0
        for key, positions in self._groups.items():
            result_index.append(row_counter)
            row_counter += 1
            for ki, k in enumerate(self._by):
                result_data[k].append(key[ki])
            for c in non_key_cols:
                vals = [self._ds._columns[c]._data[p] for p in positions]
                col_series = Series(vals)
                try:
                    result_data[c].append(getattr(col_series, method)(**kwargs))
                except (TypeError, AtraxTypeError):
                    result_data[c].append(NA)

        col_order = list(self._by) + non_key_cols
        cols = {}
        for c in col_order:
            cols[c] = Series(result_data[c], index=list(result_index), name=c)
        return DataSet._build(cols, result_index, col_order)

    def sum(self) -> DataSet:
        return self._agg_method("sum")

    def mean(self) -> DataSet:
        return self._agg_method("mean")

    def median(self) -> DataSet:
        return self._agg_method("median")

    def min(self) -> DataSet:
        return self._agg_method("min")

    def max(self) -> DataSet:
        return self._agg_method("max")

    def std(self, ddof: int = 1) -> DataSet:
        return self._agg_method("std", ddof=ddof)

    def var(self, ddof: int = 1) -> DataSet:
        return self._agg_method("var", ddof=ddof)

    def count(self) -> DataSet:
        return self._agg_method("count")

    def agg(self, func: str | Callable | dict[str, str | Callable]) -> DataSet:
        if isinstance(func, str):
            return self._agg_method(func)

        if isinstance(func, dict):
            non_key_cols = [c for c in self._ds._col_order if c not in self._by]
            result_data: dict[str, list] = {k: [] for k in self._by}
            agg_cols = [c for c in non_key_cols if c in func]
            for c in agg_cols:
                result_data[c] = []

            result_index: list = []
            row_counter = 0
            for key, positions in self._groups.items():
                result_index.append(row_counter)
                row_counter += 1
                for ki, k in enumerate(self._by):
                    result_data[k].append(key[ki])
                for c in agg_cols:
                    vals = [self._ds._columns[c]._data[p] for p in positions]
                    col_series = Series(vals)
                    f = func[c]
                    if isinstance(f, str):
                        result_data[c].append(getattr(col_series, f)())
                    else:
                        result_data[c].append(f(col_series))

            col_order = list(self._by) + agg_cols
            cols = {}
            for c in col_order:
                cols[c] = Series(result_data[c], index=list(result_index), name=c)
            return DataSet._build(cols, result_index, col_order)

        # callable
        non_key_cols = [c for c in self._ds._col_order if c not in self._by]
        result_data = {k: [] for k in self._by}
        for c in non_key_cols:
            result_data[c] = []

        result_index = []
        row_counter = 0
        for key, positions in self._groups.items():
            result_index.append(row_counter)
            row_counter += 1
            for ki, k in enumerate(self._by):
                result_data[k].append(key[ki])
            for c in non_key_cols:
                vals = [self._ds._columns[c]._data[p] for p in positions]
                col_series = Series(vals)
                try:
                    result_data[c].append(func(col_series))
                except (TypeError, AtraxTypeError):
                    result_data[c].append(NA)

        col_order = list(self._by) + non_key_cols
        cols = {}
        for c in col_order:
            cols[c] = Series(result_data[c], index=list(result_index), name=c)
        return DataSet._build(cols, result_index, col_order)

    def __len__(self) -> int:
        return len(self._groups)

    def __iter__(self) -> Iterator[tuple[tuple, DataSet]]:
        for key, positions in self._groups.items():
            new_index = [self._ds._index[p] for p in positions]
            cols = {}
            for c in self._ds._col_order:
                vals = [self._ds._columns[c]._data[p] for p in positions]
                cols[c] = Series(vals, index=list(new_index), name=c)
            yield key, DataSet._build(cols, new_index, list(self._ds._col_order))


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

builtins_max = max


def _format_value(v: Any) -> str:
    if is_na(v):
        return "NaN"
    return str(v)
