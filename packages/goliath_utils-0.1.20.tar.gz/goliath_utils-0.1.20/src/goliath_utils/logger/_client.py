"""Structured logger that writes to Python logging and PostgreSQL."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

_TABLE = "core_lambda_logs"

_CREATE_TABLE_DDL = f"""\
CREATE TABLE IF NOT EXISTS {_TABLE} (
    id BIGSERIAL PRIMARY KEY,
    logged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    lambda_name TEXT NOT NULL,
    log_level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,

    request_id TEXT,
    job_id BIGINT,
    worker_name TEXT,
    source TEXT,
    logger_name TEXT,
    event_name TEXT,
    status TEXT,
    error_type TEXT,
    stack_trace TEXT,
    metadata JSONB,
    event TEXT,
    context TEXT,

    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
)"""

_OPTIONAL_FIELDS = (
    "request_id",
    "job_id",
    "worker_name",
    "source",
    "logger_name",
    "event_name",
    "status",
    "error_type",
    "stack_trace",
    "metadata",
    "event",
    "context",
)

_LEVEL_MAP = {
    "DEBUG": logging.DEBUG,
    "INFO": logging.INFO,
    "WARNING": logging.WARNING,
    "ERROR": logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}

_MAX_DB_FAILURES = 3


class Logger:
    """Structured logger that writes to Python logging and PostgreSQL.

    Every log call emits to Python's standard :mod:`logging` (for
    console / CloudWatch) **and** inserts a row into the
    ``core_lambda_logs`` table so logs are queryable from the database.

    Usage::

        from goliath_utils.logger import Logger

        log = Logger("my-lambda")
        log.info("Processing started", job_id=42, worker_name="wk-1")
        log.error("Failed", error_type="ValueError",
                  stack_trace=traceback.format_exc())
        log.close()

    Parameters:
        lambda_name: Identifies the Lambda / service.  Stored in every
            log row and used as part of the Python logger name.
        db: Optional pre-built :class:`~goliath_utils.db.Database`.  When
            *None* and *db_enabled* is ``True``, a connection is created
            lazily via :func:`~goliath_utils.db.get_db` on the first
            log call.
        db_enabled: Set to ``False`` to skip all database inserts (useful
            for local development or tests).
        logger_name: Name passed to :func:`logging.getLogger`.  Defaults
            to ``"goliath.<lambda_name>"``.
    """

    def __init__(
        self,
        lambda_name: str,
        *,
        db: Any | None = None,
        db_enabled: bool = True,
        logger_name: str | None = None,
    ):
        if not lambda_name:
            from ._errors import LoggerError

            raise LoggerError("lambda_name is required")

        self._lambda_name = lambda_name
        self._db = db
        self._owns_db = db is None
        self._db_enabled = db_enabled
        self._db_failures = 0

        name = logger_name or f"goliath.{lambda_name}"
        self._logger = logging.getLogger(name)

        if not self._logger.handlers:
            handler = logging.StreamHandler(sys.stderr)
            handler.setFormatter(
                logging.Formatter("%(asctime)s [%(name)s] %(levelname)s %(message)s")
            )
            self._logger.addHandler(handler)

        if self._logger.level == logging.NOTSET:
            self._logger.setLevel(logging.DEBUG)

    # -- public log methods -------------------------------------------------

    def debug(self, message: str, **kwargs: Any) -> None:
        self._log("DEBUG", message, **kwargs)

    def info(self, message: str, **kwargs: Any) -> None:
        self._log("INFO", message, **kwargs)

    def warning(self, message: str, **kwargs: Any) -> None:
        self._log("WARNING", message, **kwargs)

    def error(self, message: str, **kwargs: Any) -> None:
        self._log("ERROR", message, **kwargs)

    def critical(self, message: str, **kwargs: Any) -> None:
        self._log("CRITICAL", message, **kwargs)

    # -- setup / lifecycle --------------------------------------------------

    def setup(self) -> None:
        """Create the ``core_lambda_logs`` table if it does not exist.

        Idempotent -- safe to call on every cold start.
        """
        self._ensure_db()
        self._db.execute(_CREATE_TABLE_DDL)

    def close(self) -> None:
        """Close the database connection if this logger created it."""
        if self._owns_db and self._db is not None:
            self._db.close()
            self._db = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internals ----------------------------------------------------------

    def _log(
        self,
        level: str,
        message: str,
        *,
        request_id: str | None = None,
        job_id: int | None = None,
        worker_name: str | None = None,
        source: str | None = None,
        logger_name: str | None = None,
        event_name: str | None = None,
        status: str | None = None,
        error_type: str | None = None,
        stack_trace: str | None = None,
        metadata: dict | None = None,
        event: dict | None = None,
        context: dict | None = None,
    ) -> None:
        extras = {
            "request_id": request_id,
            "job_id": job_id,
            "worker_name": worker_name,
            "source": source,
            "logger_name": logger_name,
            "event_name": event_name,
            "status": status,
            "error_type": error_type,
            "stack_trace": stack_trace,
            "metadata": metadata,
            "event": event,
            "context": context,
        }
        extras = {k: v for k, v in extras.items() if v is not None}

        # 1. Emit to Python logging
        if extras:
            parts = " ".join(f"{k}={v!r}" for k, v in extras.items())
            formatted = f"{message} | {parts}"
        else:
            formatted = message

        self._logger.log(_LEVEL_MAP[level], formatted)

        # 2. Insert into database
        if self._db_enabled:
            self._insert_log(level, message, extras)

    def _ensure_db(self) -> None:
        """Lazily create a database connection via get_db()."""
        if self._db is None:
            from goliath_utils.db import get_db

            self._db = get_db()
            self._owns_db = True

    def _insert_log(self, level: str, message: str, extras: dict) -> None:
        try:
            self._ensure_db()

            columns = ["lambda_name", "log_level", "message"]
            params: dict[str, Any] = {
                "lambda_name": self._lambda_name,
                "log_level": level,
                "message": message,
            }

            for field in _OPTIONAL_FIELDS:
                value = extras.get(field)
                if value is not None:
                    columns.append(field)
                    if field == "metadata":
                        try:
                            params[field] = json.dumps(value)
                        except TypeError:
                            params[field] = str(value)
                    elif field in ("event", "context"):
                        params[field] = json.dumps(value) if isinstance(value, dict) else str(value)
                    else:
                        params[field] = value

            col_str = ", ".join(columns)
            val_str = ", ".join(f":{c}" for c in columns)
            query = f"INSERT INTO {_TABLE} ({col_str}) VALUES ({val_str})"

            self._db.execute(query, params)
            self._db_failures = 0

        except Exception as exc:
            self._db_failures += 1
            print(
                f"[goliath_utils.logger] WARNING: failed to insert log to DB: {exc}",
                file=sys.stderr,
                flush=True,
            )
            if self._db_failures >= _MAX_DB_FAILURES:
                self._db_enabled = False
                print(
                    f"[goliath_utils.logger] DB logging disabled after "
                    f"{_MAX_DB_FAILURES} consecutive failures",
                    file=sys.stderr,
                    flush=True,
                )
