"""Exception hierarchy for the logger module."""


class LoggerError(Exception):
    """Base exception for logger operations."""


class LoggerDatabaseError(LoggerError):
    """Raised when the logger cannot write to the database."""

    def __init__(self, message: str, original: Exception | None = None):
        self.message = message
        self.original = original
        super().__init__(f"Logger DB error: {message}")
