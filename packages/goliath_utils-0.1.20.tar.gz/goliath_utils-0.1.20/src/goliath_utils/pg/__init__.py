"""Pure-Python PostgreSQL driver — zero C dependencies.

A lightweight, self-contained PostgreSQL client that speaks the Postgres v3
wire protocol directly over a TCP socket.  No psycopg2, no compiled
extensions, no external dependencies.

This is the default driver used by :func:`goliath_utils.db.get_db`.

Features:

- **Zero dependencies** — uses only the Python standard library
- **Named parameters** — ``:param`` style, converted to ``$N`` automatically
- **Positional parameters** — ``$1, $2, ...`` style (native Postgres)
- **Native arrays** — pass Python lists as parameters for ``ANY()`` queries
- **SCRAM-SHA-256 auth** — the default for PostgreSQL 10+ (RFC 5802)
- **MD5 and cleartext auth** — for older or differently configured servers
- **SSL/TLS** — automatic negotiation with ``sslmode=prefer`` (default)
- **Automatic type coercion** — int, float, Decimal, bool, date, datetime,
  time, json/jsonb, uuid, and arrays are all handled automatically
- **Lazy connections** — no database contact until the first query
- **Context manager** — ``with Connection(...) as conn:`` for auto-cleanup

Quick start::

    from goliath_utils.pg import Connection

    with Connection(dsn="postgresql://user:pass@host/db") as conn:
        rows = conn.fetch_all(
            "SELECT * FROM t WHERE store_id = ANY(:ids) AND sale_date BETWEEN :start AND :end",
            {"ids": [1, 2, 3], "start": "2024-01-01", "end": "2024-12-31"},
        )

Architecture::

    pg/
    ├── __init__.py      — Public API (this file)
    ├── _client.py       — Connection class, DSN parsing, named-param rewriting
    ├── _protocol.py     — Wire protocol: message framing, startup, query execution
    ├── _auth.py         — SCRAM-SHA-256 (RFC 5802) and MD5 authentication
    ├── _types.py        — Type OID registry, encode (Python → Postgres), decode (Postgres → Python)
    └── _errors.py       — Exception hierarchy (PgError → ConnectionError, AuthenticationError, etc.)
"""

from ._client import Connection
from ._errors import (
    AuthenticationError,
    ConnectionError,
    PgError,
    ProtocolError,
    QueryError,
)

__all__ = [
    "Connection",
    "PgError",
    "ConnectionError",
    "AuthenticationError",
    "ProtocolError",
    "QueryError",
]
