"""PostgreSQL v3 wire protocol — message framing, startup, and query execution.

This module handles the low-level byte wrangling: packing/unpacking messages,
driving the startup + authentication handshake, and running simple and extended
(parameterised) queries.

The PostgreSQL wire protocol (version 3.0, stable since Postgres 7.4 / 2003)
is a message-based TCP protocol.  Each message has:

- A **type byte** (1 byte) identifying the message kind
- A **length** (4 bytes, big-endian int32) including itself but not the type byte
- A **payload** of (length - 4) bytes

Two query sub-protocols are implemented:

**Simple Query Protocol** — used when there are no parameters.  The client sends
a single ``Query`` message containing the raw SQL, and the server responds with
``RowDescription``, ``DataRow`` (one per row), ``CommandComplete``, and finally
``ReadyForQuery``.

**Extended Query Protocol** — used for parameterised queries.  The client sends
``Parse`` (compile SQL with ``$1, $2, ...`` placeholders), ``Bind`` (attach
parameter values), ``Describe`` (request column metadata), ``Execute`` (run it),
and ``Sync`` (flush).  The server responds with ``ParseComplete``, ``BindComplete``,
``RowDescription``, ``DataRow`` messages, ``CommandComplete``, and ``ReadyForQuery``.

This module is internal — use :class:`goliath_utils.pg.Connection` instead.
"""

from __future__ import annotations

import socket
import ssl
import struct
from typing import Any

from ._auth import ScramClient, md5_password
from ._errors import AuthenticationError, ConnectionError, ProtocolError, QueryError
from ._types import decode_value, encode_value

# Protocol version 3.0
_PROTO_VERSION = (3 << 16) | 0

# ---------------------------------------------------------------------------
# Message framing helpers
# ---------------------------------------------------------------------------


def _pack_int32(n: int) -> bytes:
    return struct.pack("!i", n)


def _pack_int16(n: int) -> bytes:
    return struct.pack("!h", n)


def _cstring(s: str) -> bytes:
    return s.encode("utf-8") + b"\x00"


def _read_exactly(sock: socket.socket, n: int) -> bytes:
    """Read exactly *n* bytes from *sock*, or raise on short read."""
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("Connection closed by server")
        buf.extend(chunk)
    return bytes(buf)


def _read_message(sock: socket.socket) -> tuple[str, bytes]:
    """Read one backend message: returns (type_char, payload)."""
    header = _read_exactly(sock, 5)
    msg_type = chr(header[0])
    length = struct.unpack("!i", header[1:5])[0]
    payload = _read_exactly(sock, length - 4) if length > 4 else b""
    return msg_type, payload


def _read_cstring(data: bytes, offset: int) -> tuple[str, int]:
    """Read a null-terminated string starting at *offset*."""
    end = data.index(b"\x00", offset)
    return data[offset:end].decode("utf-8"), end + 1


# ---------------------------------------------------------------------------
# Startup
# ---------------------------------------------------------------------------


def build_startup_message(user: str, database: str) -> bytes:
    """Build the initial StartupMessage packet (no type byte)."""
    body = _pack_int32(_PROTO_VERSION)
    body += _cstring("user") + _cstring(user)
    body += _cstring("database") + _cstring(database)
    body += b"\x00"  # terminator
    length = len(body) + 4  # include the length field itself
    return _pack_int32(length) + body


def build_ssl_request() -> bytes:
    """Build the SSLRequest message."""
    # Magic number 80877103 = (1234 << 16) | 5679
    code = (1234 << 16) | 5679
    return _pack_int32(8) + _pack_int32(code)


# ---------------------------------------------------------------------------
# Authentication
# ---------------------------------------------------------------------------


def handle_authentication(
    sock: socket.socket,
    user: str,
    password: str,
) -> dict[str, str]:
    """Drive the authentication exchange after StartupMessage.

    Reads messages until AuthenticationOk (or error).  Returns a dict of
    server parameters received during startup (e.g. server_version).
    """
    params: dict[str, str] = {}
    scram: ScramClient | None = None

    while True:
        msg_type, payload = _read_message(sock)

        if msg_type == "R":  # Authentication
            auth_code = struct.unpack("!i", payload[:4])[0]

            if auth_code == 0:
                # AuthenticationOk
                break

            elif auth_code == 3:
                # Cleartext password
                pw_msg = _cstring(password)
                _send_message(sock, "p", pw_msg)

            elif auth_code == 5:
                # MD5 password
                salt = payload[4:8]
                md5_resp = md5_password(user, password, salt) + b"\x00"
                _send_message(sock, "p", md5_resp)

            elif auth_code == 10:
                # SASL — server lists supported mechanisms
                mechanisms = []
                offset = 4
                while offset < len(payload):
                    mech, offset = _read_cstring(payload, offset)
                    if not mech:
                        break
                    mechanisms.append(mech)

                if "SCRAM-SHA-256" not in mechanisms:
                    raise AuthenticationError(
                        f"Server requires unsupported SASL mechanism: {mechanisms}"
                    )
                scram = ScramClient(user=user, password=password)
                client_first = scram.client_first_message()

                # SASLInitialResponse
                body = _cstring("SCRAM-SHA-256")
                body += _pack_int32(len(client_first))
                body += client_first
                _send_message(sock, "p", body)

            elif auth_code == 11:
                # SASLContinue — server-first-message
                if scram is None:
                    raise ProtocolError("Unexpected SASLContinue")
                server_first = payload[4:]
                client_final = scram.client_final_message(server_first)

                # SASLResponse
                _send_message(sock, "p", client_final)

            elif auth_code == 12:
                # SASLFinal — server-final-message
                if scram is None:
                    raise ProtocolError("Unexpected SASLFinal")
                scram.verify_server_final(payload[4:])

            else:
                raise AuthenticationError(
                    f"Unsupported authentication method: {auth_code}"
                )

        elif msg_type == "E":  # ErrorResponse
            raise AuthenticationError(_parse_error_fields(payload).get("M", "Authentication failed"))

        elif msg_type == "S":  # ParameterStatus
            key, off = _read_cstring(payload, 0)
            val, _ = _read_cstring(payload, off)
            params[key] = val

        elif msg_type == "K":  # BackendKeyData — ignore
            pass

        elif msg_type == "Z":  # ReadyForQuery — startup complete
            params["_txn_status"] = chr(payload[0])
            return params

        elif msg_type == "N":  # NoticeResponse — ignore
            pass

        else:
            raise ProtocolError(f"Unexpected message during auth: {msg_type!r}")

    # After AuthenticationOk, continue reading until ReadyForQuery
    while True:
        msg_type, payload = _read_message(sock)
        if msg_type == "S":
            key, off = _read_cstring(payload, 0)
            val, _ = _read_cstring(payload, off)
            params[key] = val
        elif msg_type == "K":
            pass
        elif msg_type == "Z":
            params["_txn_status"] = chr(payload[0])
            return params
        elif msg_type == "E":
            raise AuthenticationError(_parse_error_fields(payload).get("M", "Startup failed"))
        elif msg_type == "N":
            pass
        else:
            raise ProtocolError(f"Unexpected message during startup: {msg_type!r}")


# ---------------------------------------------------------------------------
# Simple query (no parameters)
# ---------------------------------------------------------------------------


def simple_query(
    sock: socket.socket, sql: str
) -> tuple[list[dict[str, Any]], int]:
    """Execute a query using the Simple Query protocol.

    Returns (rows, rowcount) where rows is a list of dicts.
    """
    _send_message(sock, "Q", _cstring(sql))

    columns: list[tuple[str, int]] = []  # (name, oid)
    rows: list[dict[str, Any]] = []
    rowcount = -1

    while True:
        msg_type, payload = _read_message(sock)

        if msg_type == "T":  # RowDescription
            columns = _parse_row_description(payload)

        elif msg_type == "D":  # DataRow
            rows.append(_parse_data_row(payload, columns))

        elif msg_type == "C":  # CommandComplete
            tag = payload[:-1].decode("utf-8")  # strip null terminator
            rowcount = _parse_command_tag(tag)

        elif msg_type == "Z":  # ReadyForQuery
            return rows, rowcount

        elif msg_type == "E":  # ErrorResponse
            fields = _parse_error_fields(payload)
            # Drain until ReadyForQuery
            _drain_until_ready(sock)
            raise QueryError(
                sql,
                severity=fields.get("S", "ERROR"),
                code=fields.get("C", ""),
                message=fields.get("M", ""),
                detail=fields.get("D", ""),
            )

        elif msg_type == "N":  # NoticeResponse — ignore
            pass

        elif msg_type == "I":  # EmptyQueryResponse
            pass

        else:
            pass  # Ignore unknown messages gracefully


# ---------------------------------------------------------------------------
# Extended query (parameterised — supports $1, $2, ... placeholders)
# ---------------------------------------------------------------------------


def extended_query(
    sock: socket.socket,
    sql: str,
    param_values: list[bytes | None],
) -> tuple[list[dict[str, Any]], int]:
    """Execute a parameterised query using the Extended Query protocol.

    *param_values* is a list of text-encoded parameter values (or None for NULL).
    The SQL must use ``$1``, ``$2``, … placeholders.

    Returns (rows, rowcount).
    """
    # Parse (unnamed statement)
    parse_body = _cstring("")  # unnamed statement
    parse_body += _cstring(sql)
    parse_body += _pack_int16(0)  # no parameter type OIDs (let server infer)
    _send_message(sock, "P", parse_body)

    # Bind (unnamed portal ← unnamed statement)
    bind_body = _cstring("")  # unnamed portal
    bind_body += _cstring("")  # unnamed statement
    bind_body += _pack_int16(0)  # all parameters use text format
    bind_body += _pack_int16(len(param_values))
    for val in param_values:
        if val is None:
            bind_body += _pack_int32(-1)  # NULL
        else:
            bind_body += _pack_int32(len(val))
            bind_body += val
    bind_body += _pack_int16(0)  # all result columns in text format
    _send_message(sock, "B", bind_body)

    # Describe (portal)
    _send_message(sock, "D", b"P" + _cstring(""))

    # Execute (unnamed portal, no row limit)
    _send_message(sock, "E", _cstring("") + _pack_int32(0))

    # Sync
    _send_message(sock, "S", b"")

    # Read responses
    columns: list[tuple[str, int]] = []
    rows: list[dict[str, Any]] = []
    rowcount = -1
    error_fields: dict[str, str] | None = None

    while True:
        msg_type, payload = _read_message(sock)

        if msg_type == "1":  # ParseComplete
            pass
        elif msg_type == "2":  # BindComplete
            pass
        elif msg_type == "T":  # RowDescription
            columns = _parse_row_description(payload)
        elif msg_type == "n":  # NoData
            pass
        elif msg_type == "D":  # DataRow
            rows.append(_parse_data_row(payload, columns))
        elif msg_type == "C":  # CommandComplete
            tag = payload[:-1].decode("utf-8")
            rowcount = _parse_command_tag(tag)
        elif msg_type == "E":  # ErrorResponse
            error_fields = _parse_error_fields(payload)
        elif msg_type == "Z":  # ReadyForQuery
            if error_fields is not None:
                raise QueryError(
                    sql,
                    severity=error_fields.get("S", "ERROR"),
                    code=error_fields.get("C", ""),
                    message=error_fields.get("M", ""),
                    detail=error_fields.get("D", ""),
                )
            return rows, rowcount
        elif msg_type == "N":  # NoticeResponse
            pass
        else:
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _send_message(sock: socket.socket, msg_type: str, body: bytes) -> None:
    """Send a frontend message: type byte + int32 length + body."""
    length = len(body) + 4
    sock.sendall(msg_type.encode() + _pack_int32(length) + body)


def _parse_row_description(payload: bytes) -> list[tuple[str, int]]:
    """Parse a RowDescription message → list of (column_name, type_oid)."""
    num_fields = struct.unpack("!h", payload[:2])[0]
    offset = 2
    columns: list[tuple[str, int]] = []
    for _ in range(num_fields):
        name, offset = _read_cstring(payload, offset)
        # table_oid (4) + col_attr (2) + type_oid (4) + type_size (2) + type_mod (4) + format (2) = 18
        type_oid = struct.unpack("!i", payload[offset + 6 : offset + 10])[0]
        offset += 18
        columns.append((name, type_oid))
    return columns


def _parse_data_row(
    payload: bytes, columns: list[tuple[str, int]]
) -> dict[str, Any]:
    """Parse a DataRow message into a dict using column metadata."""
    num_cols = struct.unpack("!h", payload[:2])[0]
    offset = 2
    row: dict[str, Any] = {}
    for i in range(num_cols):
        col_len = struct.unpack("!i", payload[offset : offset + 4])[0]
        offset += 4
        if col_len == -1:
            raw = None
        else:
            raw = payload[offset : offset + col_len]
            offset += col_len
        name, oid = columns[i]
        row[name] = decode_value(oid, raw)
    return row


def _parse_error_fields(payload: bytes) -> dict[str, str]:
    """Parse an ErrorResponse / NoticeResponse into a dict of field code → value."""
    fields: dict[str, str] = {}
    offset = 0
    while offset < len(payload):
        code = payload[offset]
        if code == 0:
            break
        offset += 1
        val, offset = _read_cstring(payload, offset)
        fields[chr(code)] = val
    return fields


def _parse_command_tag(tag: str) -> int:
    """Extract the affected row count from a CommandComplete tag.

    Examples: "INSERT 0 5" → 5, "UPDATE 3" → 3, "SELECT 10" → 10
    """
    parts = tag.split()
    if len(parts) >= 2:
        try:
            return int(parts[-1])
        except ValueError:
            pass
    return -1


def _drain_until_ready(sock: socket.socket) -> None:
    """Read and discard messages until ReadyForQuery."""
    while True:
        msg_type, _ = _read_message(sock)
        if msg_type == "Z":
            return


# ---------------------------------------------------------------------------
# SSL negotiation
# ---------------------------------------------------------------------------

def negotiate_ssl(
    sock: socket.socket,
    server_hostname: str,
    verify: bool = False,
) -> socket.socket:
    """Attempt SSL upgrade.  Returns the (possibly wrapped) socket.

    If the server declines SSL, the original socket is returned unchanged.

    When *verify* is ``False`` (the default, matching ``sslmode=prefer``
    behaviour), certificate verification is disabled — the connection is
    encrypted but the server's identity is not checked.  Set *verify* to
    ``True`` for full certificate validation (``sslmode=verify-full``).
    """
    sock.sendall(build_ssl_request())
    resp = _read_exactly(sock, 1)

    if resp == b"S":
        if verify:
            ctx = ssl.create_default_context()
        else:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        return ctx.wrap_socket(sock, server_hostname=server_hostname)
    else:
        # Server declined — continue unencrypted
        return sock
