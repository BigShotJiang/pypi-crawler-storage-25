"""Pure-Python PostgreSQL client — zero C dependencies.

Usage::

    from goliath_utils.pg import Connection

    conn = Connection(host="localhost", database="mydb", user="me", password="secret")
    conn.connect()

    rows = conn.fetch_all("SELECT * FROM t WHERE id = $1", [42])
    rows = conn.fetch_all("SELECT * FROM t WHERE id = ANY($1)", [[1,2,3]])

    conn.close()

Array parameters work natively — pass a Python list and it gets encoded as
a Postgres array literal, so ``ANY($1)`` with ``[1, 2, 3]`` just works.
"""

from __future__ import annotations

import re
import socket
from typing import Any
from urllib.parse import urlparse, parse_qs, unquote

from ._errors import ConnectionError, QueryError
from ._protocol import (
    build_startup_message,
    extended_query,
    handle_authentication,
    negotiate_ssl,
    simple_query,
)
from ._types import encode_value


def _rewrite_named_params(
    query: str, params: dict[str, Any]
) -> tuple[str, list[Any]]:
    """Convert ``:name`` placeholders to ``$N`` positional placeholders.

    Returns the rewritten SQL and an ordered list of parameter values.

    This lets callers write::

        conn.fetch_all(
            "SELECT * FROM t WHERE store_id = ANY(:storeids) AND d BETWEEN :start AND :end",
            {"storeids": [1,2,3], "start": "2024-01-01", "end": "2024-12-31"},
        )
    """
    seen: dict[str, int] = {}
    values: list[Any] = []

    def _replacer(match: re.Match) -> str:
        name = match.group(1)
        if name not in seen:
            values.append(params[name])
            seen[name] = len(values)
        return f"${seen[name]}"

    rewritten = re.sub(r":(\w+)", _replacer, query)
    return rewritten, values


class Connection:
    """Pure-Python PostgreSQL connection — zero C dependencies.

    Speaks the PostgreSQL v3 wire protocol directly over a TCP socket.
    No psycopg2, no compiled extensions, no external dependencies beyond
    the Python standard library.

    Supports both ``:name`` and ``$N`` parameter styles.  Array parameters
    work natively — pass a Python list and it becomes a Postgres array::

        conn.fetch_all(
            "SELECT * FROM t WHERE id = ANY(:ids)",
            {"ids": [1, 2, 3]},
        )

    Connections are lazy — the database is not contacted until the first
    query or an explicit call to :meth:`connect`.  Use as a context manager
    for automatic cleanup::

        with Connection(dsn="postgresql://user:pass@host/db") as conn:
            rows = conn.fetch_all("SELECT 1")

    Authentication methods supported:

    - **SCRAM-SHA-256** — default for PostgreSQL 10+ (RFC 5802)
    - **MD5** — legacy password hashing
    - **Cleartext** — plain password (typically only over SSL)

    SSL/TLS is negotiated automatically when *sslmode* is ``"prefer"``
    (the default) or ``"require"``.
    """

    def __init__(
        self,
        dsn: str | None = None,
        *,
        host: str = "localhost",
        port: int = 5432,
        database: str = "",
        user: str = "",
        password: str = "",
        sslmode: str = "prefer",
    ):
        """Create a new connection (does not connect yet).

        Parameters:
            dsn: Full PostgreSQL connection URI.
                 Example: ``postgresql://user:pass@host:5432/dbname?sslmode=require``
                 When provided, individual parameters are ignored.
            host: Database server hostname or IP address.
            port: Database server port number.
            database: Name of the database to connect to.
            user: PostgreSQL username.
            password: Password for authentication.
            sslmode: SSL negotiation mode — ``"prefer"`` (try SSL, fall back to
                     plain), ``"require"`` (SSL required, fail if unavailable),
                     or ``"disable"`` (no SSL).
        """
        if dsn:
            parsed = _parse_dsn(dsn)
            host = parsed.get("host", host)
            port = int(parsed.get("port", port))
            database = parsed.get("database", database)
            user = parsed.get("user", user)
            password = parsed.get("password", password)
            sslmode = parsed.get("sslmode", sslmode)

        self._host = host
        self._port = port
        self._database = database
        self._user = user
        self._password = password
        self._sslmode = sslmode
        self._sock: socket.socket | None = None
        self._server_params: dict[str, str] = {}
        self._autocommit = True

    @property
    def autocommit(self) -> bool:
        """Whether the connection auto-commits each statement.

        Defaults to ``True``, which is the recommended mode for Lambda
        and serverless environments where each invocation runs a small
        number of independent queries.
        """
        return self._autocommit

    @autocommit.setter
    def autocommit(self, value: bool) -> None:
        self._autocommit = value

    @property
    def server_params(self) -> dict[str, str]:
        """Server parameters received during the startup handshake.

        Contains keys like ``server_version``, ``server_encoding``,
        ``client_encoding``, ``TimeZone``, etc.  Useful for diagnostics
        or adapting behaviour to the server's capabilities.
        """
        return dict(self._server_params)

    # -- connection lifecycle -----------------------------------------------

    def connect(self) -> None:
        """Open the TCP connection, negotiate SSL, and authenticate.

        Called automatically on the first query if the connection is not
        yet open.  Call explicitly to fail fast during initialisation.

        Raises:
            ConnectionError: If the TCP connection cannot be established.
            AuthenticationError: If the server rejects the credentials.
        """
        if self._sock is not None:
            return

        try:
            sock = socket.create_connection((self._host, self._port), timeout=10)
        except OSError as exc:
            raise ConnectionError(
                f"Could not connect to {self._host}:{self._port}: {exc}"
            ) from exc

        # SSL negotiation
        if self._sslmode in ("prefer", "require"):
            try:
                sock = negotiate_ssl(sock, self._host)
            except Exception:
                if self._sslmode == "require":
                    sock.close()
                    raise
                # prefer — SSL failed, reconnect without it.
                # After a failed SSL handshake the socket is dead
                # (especially on Windows), so we must start fresh.
                try:
                    sock.close()
                except OSError:
                    pass
                try:
                    sock = socket.create_connection(
                        (self._host, self._port), timeout=10
                    )
                except OSError as exc:
                    raise ConnectionError(
                        f"Could not reconnect to {self._host}:{self._port}: {exc}"
                    ) from exc

        # Startup + auth
        sock.sendall(build_startup_message(self._user, self._database))
        self._server_params = handle_authentication(
            sock, self._user, self._password
        )
        self._sock = sock

    def close(self) -> None:
        """Send a Terminate message to the server and close the socket.

        Safe to call multiple times — subsequent calls are no-ops.
        """
        if self._sock is not None:
            try:
                # Terminate message: 'X' + int32(4)
                self._sock.sendall(b"X\x00\x00\x00\x04")
            except OSError:
                pass
            self._sock.close()
            self._sock = None

    def __enter__(self):
        self.connect()
        return self

    def __exit__(self, *exc):
        self.close()

    # -- internal -----------------------------------------------------------

    def _ensure_connected(self) -> None:
        if self._sock is None:
            self.connect()

    def _exec(
        self, query: str, params: dict | list | None = None
    ) -> tuple[list[dict[str, Any]], int]:
        """Execute a query and return (rows, rowcount).

        Supports three calling styles:

        1. No params:  ``_exec("SELECT 1")``
        2. Dict params: ``_exec("SELECT :x", {"x": 1})`` — converted to ``$N``
        3. List params: ``_exec("SELECT $1", [1])`` — used as-is
        """
        self._ensure_connected()
        assert self._sock is not None

        if params is None:
            return simple_query(self._sock, query)

        # Convert :name → $N if dict params
        if isinstance(params, dict):
            query, param_list = _rewrite_named_params(query, params)
        else:
            param_list = list(params)

        # Encode values for the wire
        encoded = [encode_value(v) for v in param_list]
        return extended_query(self._sock, query, encoded)

    # -- public query interface ---------------------------------------------

    def fetch_all(self, query: str, params: dict | list | None = None) -> list[dict]:
        """Execute a query and return all rows as a list of dicts.

        Parameters:
            query: SQL string with ``:name`` or ``$N`` placeholders.
            params: A dict for named params or a list for positional params.
                    Pass ``None`` (default) for queries without parameters.

        Returns:
            A list of dictionaries, one per row.  Column names are the keys.
            Returns an empty list if the query produces no rows.

        Example::

            rows = conn.fetch_all(
                "SELECT * FROM t WHERE storeid = ANY(:ids)",
                {"ids": [1, 2, 3]},
            )
            # [{"storeid": 1, "name": "..."}, ...]

        Raises:
            QueryError: If the SQL is invalid or the server returns an error.
        """
        rows, _ = self._exec(query, params)
        return rows

    def fetch_one(self, query: str, params: dict | list | None = None) -> dict | None:
        """Execute a query and return the first row, or ``None``.

        Useful for queries that are expected to return exactly one row,
        such as lookups by primary key::

            store = conn.fetch_one(
                "SELECT * FROM stores WHERE id = :id", {"id": 42}
            )

        Parameters:
            query: SQL string with ``:name`` or ``$N`` placeholders.
            params: A dict for named params or a list for positional params.

        Returns:
            A single dict representing the first row, or ``None`` if the
            query returned no results.

        Raises:
            QueryError: If the SQL is invalid or the server returns an error.
        """
        rows, _ = self._exec(query, params)
        return rows[0] if rows else None

    def fetch_val(self, query: str, params: dict | list | None = None) -> Any | None:
        """Execute a query and return the first column of the first row.

        Ideal for scalar queries::

            count = conn.fetch_val("SELECT count(*) FROM stores")

        Parameters:
            query: SQL string with ``:name`` or ``$N`` placeholders.
            params: A dict for named params or a list for positional params.

        Returns:
            The scalar value, or ``None`` if the query returned no rows.

        Raises:
            QueryError: If the SQL is invalid or the server returns an error.
        """
        row = self.fetch_one(query, params)
        if row is None:
            return None
        return next(iter(row.values()))

    def execute(self, query: str, params: dict | list | None = None) -> int:
        """Execute a statement and return the number of affected rows.

        Use for INSERT, UPDATE, and DELETE statements::

            affected = conn.execute(
                "UPDATE stores SET active = :active WHERE region = :region",
                {"active": True, "region": "east"},
            )

        Parameters:
            query: SQL string with ``:name`` or ``$N`` placeholders.
            params: A dict for named params or a list for positional params.

        Returns:
            The number of rows affected by the statement.

        Raises:
            QueryError: If the SQL is invalid or the server returns an error.
        """
        _, rowcount = self._exec(query, params)
        return rowcount


# ---------------------------------------------------------------------------
# DSN parsing
# ---------------------------------------------------------------------------


def _parse_dsn(dsn: str) -> dict[str, str]:
    """Parse a PostgreSQL connection string into a dict.

    Supports ``postgresql://user:pass@host:port/dbname?sslmode=require``.
    """
    parsed = urlparse(dsn)
    result: dict[str, str] = {}
    if parsed.hostname:
        result["host"] = parsed.hostname
    if parsed.port:
        result["port"] = str(parsed.port)
    if parsed.username:
        result["user"] = unquote(parsed.username)
    if parsed.password:
        result["password"] = unquote(parsed.password)
    if parsed.path and parsed.path != "/":
        result["database"] = parsed.path.lstrip("/")
    qs = parse_qs(parsed.query)
    if "sslmode" in qs:
        result["sslmode"] = qs["sslmode"][0]
    return result
