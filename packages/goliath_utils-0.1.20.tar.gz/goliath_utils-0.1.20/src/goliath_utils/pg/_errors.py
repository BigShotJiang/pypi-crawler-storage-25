"""Exception classes for the pure-Python PostgreSQL driver.

All exceptions inherit from :class:`PgError`, so you can catch everything
with a single ``except PgError`` or be specific with the subclasses.

Exception hierarchy::

    PgError
    ├── ConnectionError    — TCP/socket-level failures
    ├── AuthenticationError — credential or auth protocol failures
    ├── ProtocolError       — unexpected wire-protocol messages
    └── QueryError          — SQL execution errors from the server
"""


class PgError(Exception):
    """Base exception for all pg module errors.

    Catch this to handle any error from the pure-Python PostgreSQL driver
    in a single except block.
    """


class ConnectionError(PgError):
    """Raised when the TCP connection to PostgreSQL fails.

    Common causes: server not running, wrong host/port, network unreachable,
    firewall blocking the connection, or the server closing the connection
    unexpectedly.
    """


class AuthenticationError(PgError):
    """Raised when authentication with the PostgreSQL server fails.

    Common causes: wrong username or password, the server requiring an
    authentication method we don't support, or SCRAM signature verification
    failure (possible MITM).
    """


class ProtocolError(PgError):
    """Raised when an unexpected message is received from the server.

    This typically indicates a bug in the driver or an incompatible server
    version.  If you see this error, please report it.
    """


class QueryError(PgError):
    """Raised when a SQL query fails on the server.

    Contains structured error information from the PostgreSQL ErrorResponse
    message, including the SQLSTATE code for programmatic error handling.

    Attributes:
        query: The SQL that was executed.
        severity: PostgreSQL error severity (``ERROR``, ``FATAL``, ``PANIC``).
        code: The 5-character SQLSTATE error code (e.g. ``42P01`` for
              "undefined table").  See the PostgreSQL docs for the full list.
        message: Human-readable error message from the server.
        detail: Optional additional detail from the server.

    Example::

        try:
            conn.fetch_all("SELECT * FROM nonexistent")
        except QueryError as e:
            print(e.severity)  # "ERROR"
            print(e.code)      # "42P01"
            print(e.message)   # 'relation "nonexistent" does not exist'
            print(e.query)     # "SELECT * FROM nonexistent"
    """

    def __init__(
        self,
        query: str,
        *,
        severity: str = "ERROR",
        code: str = "",
        message: str = "",
        detail: str = "",
    ):
        self.query = query
        self.severity = severity
        self.code = code
        self.message = message
        self.detail = detail
        parts = [f"{severity}: {message}"]
        if detail:
            parts.append(f"DETAIL: {detail}")
        if code:
            parts.append(f"[SQLSTATE {code}]")
        super().__init__(" | ".join(parts))
