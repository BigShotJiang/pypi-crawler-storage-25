"""AWS Signature Version 4 signing — stdlib only."""

from __future__ import annotations

import hashlib
import hmac
from datetime import datetime, timezone
from urllib.parse import parse_qsl, quote, urlparse


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _uri_encode(value: str, encode_slash: bool = True) -> str:
    safe = "" if encode_slash else "/"
    return quote(value, safe=safe)


def _canonical_query_string(query: str) -> str:
    """Parse, URI-encode, and sort query parameters per SigV4 spec."""
    if not query:
        return ""
    params = parse_qsl(query, keep_blank_values=True)
    encoded = sorted((_uri_encode(k), _uri_encode(v)) for k, v in params)
    return "&".join(f"{k}={v}" for k, v in encoded)


def _derive_signing_key(
    secret_key: str, date_stamp: str, region: str, service: str
) -> bytes:
    k_date = hmac.new(
        f"AWS4{secret_key}".encode("utf-8"),
        date_stamp.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    k_region = hmac.new(k_date, region.encode("utf-8"), hashlib.sha256).digest()
    k_service = hmac.new(k_region, service.encode("utf-8"), hashlib.sha256).digest()
    k_signing = hmac.new(k_service, b"aws4_request", hashlib.sha256).digest()
    return k_signing


def _make_canonical_request(
    method: str,
    path: str,
    query_string: str,
    headers: dict[str, str],
    signed_header_names: str,
    payload_hash: str,
) -> str:
    canonical_headers = ""
    for name in signed_header_names.split(";"):
        canonical_headers += f"{name}:{headers[name]}\n"

    return "\n".join([
        method,
        _uri_encode(path, encode_slash=False),
        query_string,
        canonical_headers,
        signed_header_names,
        payload_hash,
    ])


def _make_string_to_sign(
    datetime_stamp: str,
    credential_scope: str,
    canonical_request: str,
) -> str:
    return "\n".join([
        "AWS4-HMAC-SHA256",
        datetime_stamp,
        credential_scope,
        _sha256_hex(canonical_request.encode("utf-8")),
    ])


def sign_request(
    method: str,
    url: str,
    headers: dict[str, str],
    payload: bytes,
    *,
    access_key: str,
    secret_key: str,
    region: str,
    service: str = "s3",
) -> dict[str, str]:
    """Sign an HTTP request with AWS SigV4. Returns updated headers dict."""
    now = datetime.now(timezone.utc)
    datetime_stamp = now.strftime("%Y%m%dT%H%M%SZ")
    date_stamp = now.strftime("%Y%m%d")

    parsed = urlparse(url)
    host = parsed.hostname
    path = parsed.path or "/"
    query_string = _canonical_query_string(parsed.query)

    payload_hash = _sha256_hex(payload)

    # Build headers to sign
    headers = dict(headers)
    headers["host"] = host
    headers["x-amz-date"] = datetime_stamp
    headers["x-amz-content-sha256"] = payload_hash

    signed_header_names = ";".join(sorted(headers.keys()))

    canonical_request = _make_canonical_request(
        method, path, query_string, headers, signed_header_names, payload_hash
    )

    credential_scope = f"{date_stamp}/{region}/{service}/aws4_request"
    string_to_sign = _make_string_to_sign(
        datetime_stamp, credential_scope, canonical_request
    )

    signing_key = _derive_signing_key(secret_key, date_stamp, region, service)
    signature = hmac.new(
        signing_key, string_to_sign.encode("utf-8"), hashlib.sha256
    ).hexdigest()

    headers["authorization"] = (
        f"AWS4-HMAC-SHA256 "
        f"Credential={access_key}/{credential_scope}, "
        f"SignedHeaders={signed_header_names}, "
        f"Signature={signature}"
    )

    # Remove host header — httpx sets it automatically
    del headers["host"]

    return headers
