"""S3 event notification parsing."""

from __future__ import annotations


def extract_s3_event(event: dict) -> tuple[str, str, str]:
    """Parse an S3 event notification and return (bucket, key, mode).

    Mode defaults to '' if not present in the event options.
    Raises ValueError if the event structure is invalid.
    """
    try:
        record = event["Records"][0]["s3"]
        bucket = record["bucket"]["name"]
        key = record["object"]["key"]
    except (KeyError, IndexError, TypeError) as e:
        raise ValueError(f"Invalid S3 event structure: {e}") from e

    mode = ""
    try:
        mode = record["options"]["mode"]
    except (KeyError, TypeError):
        pass

    return bucket, key, mode
