"""S3 read/write helpers for Atrax DataSet."""

from __future__ import annotations

import csv
import io
import json

from goliath_utils.atrax import DataSet
from goliath_utils.s3 import S3Client


def _decode_bytes(data: bytes) -> str:
    """Decode bytes as UTF-8, falling back to cp1252."""
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("cp1252")


# -- readers ---------------------------------------------------------------


def read_csv(client: S3Client, bucket: str, key: str) -> DataSet:
    """Read a comma-delimited CSV from S3 into a DataSet."""
    data = client.get_object(bucket, key)
    text = _decode_bytes(data)
    reader = csv.DictReader(io.StringIO(text))
    records = list(reader)
    if not records and reader.fieldnames:
        return DataSet(columns=reader.fieldnames)
    return DataSet(records)


def read_csv_pipe(client: S3Client, bucket: str, key: str) -> DataSet:
    """Read a pipe-delimited CSV from S3 into a DataSet.

    Handles UTF-8 with cp1252 fallback, backslash escaping, no quoting.
    """
    data = client.get_object(bucket, key)
    text = _decode_bytes(data)
    reader = csv.reader(
        io.StringIO(text),
        delimiter="|",
        quoting=csv.QUOTE_NONE,
        escapechar="\\",
    )
    rows = list(reader)
    if not rows:
        return DataSet()
    headers = rows[0]
    records = [dict(zip(headers, row)) for row in rows[1:]]
    return DataSet(records)


def read_json(client: S3Client, bucket: str, key: str) -> DataSet:
    """Read a JSON array from S3 into a DataSet.

    Expects a JSON array of objects: [{"col": "val", ...}, ...].
    """
    data = client.get_object(bucket, key)
    text = _decode_bytes(data)
    records = json.loads(text)
    return DataSet(records)


def read_parquet(client: S3Client, bucket: str, key: str) -> DataSet:
    """Read a Parquet file from S3 into a DataSet.

    Requires pyarrow to be installed.
    """
    try:
        import pyarrow.parquet as pq
    except ImportError:
        raise ImportError(
            "pyarrow is required for read_parquet. "
            "Install it with: pip install pyarrow"
        )

    data = client.get_object(bucket, key)
    table = pq.read_table(io.BytesIO(data))
    records = table.to_pydict()
    return DataSet(records)


# -- writers ---------------------------------------------------------------


def write_csv(client: S3Client, bucket: str, key: str, ds: DataSet) -> None:
    """Write a DataSet to S3 as comma-delimited CSV."""
    buf = io.StringIO()
    records = ds.to_dict(orient="records")
    if records:
        writer = csv.DictWriter(buf, fieldnames=ds.columns)
        writer.writeheader()
        writer.writerows(records)
    client.put_object(bucket, key, buf.getvalue().encode("utf-8"))


def write_json(client: S3Client, bucket: str, key: str, ds: DataSet) -> None:
    """Write a DataSet to S3 as a JSON array."""
    records = ds.to_dict(orient="records")
    payload = json.dumps(records, default=str).encode("utf-8")
    client.put_object(bucket, key, payload)
