"""Catalogues for kaos-agents core concepts.

Mirrors :mod:`kaos_core.registry`. Each registry holds instances or
classes keyed by their identity (``metadata.name`` for tools,
``event_type()`` for events) and surfaces lookup, listing, and
filtering helpers.

Subpackages added incrementally across the refactor:

- :mod:`kaos_agents.registry.event_registry` — :class:`EventRegistry`
  (chunk 3)
- :mod:`kaos_agents.registry.hook_registry` — :class:`HookRegistry`
  (chunk 5)
- :mod:`kaos_agents.registry.pattern_registry` — :class:`PatternRegistry`
  (Track 2)
- :mod:`kaos_agents.registry.recipe_registry` — :class:`RecipeRegistry`
  (Track 4)
"""

from __future__ import annotations

from kaos_agents.registry.event_registry import (
    EventRegistry,
    default_event_registry,
)
from kaos_agents.registry.hook_registry import (
    HookRegistry,
    default_hook_registry,
)
from kaos_agents.registry.pattern_registry import (
    PatternRegistry,
    default_pattern_registry,
)
from kaos_agents.registry.tool_data_type_registry import (
    ToolDataTypeRegistry,
    default_tool_data_type_registry,
)
from kaos_agents.registry.tool_group_classifier import (
    KAOS_TOOL_GROUP_DESCRIPTIONS,
    RECOGNIZED_TAGS,
    derive_group,
    register_kaos_tool_groups,
)
from kaos_agents.registry.tool_group_registry import (
    ToolGroupRegistry,
    default_tool_group_registry,
)
from kaos_agents.registry.tool_spec_registry import (
    AgentToolSpecRegistry,
    default_tool_spec_registry,
)

__all__ = [
    "KAOS_TOOL_GROUP_DESCRIPTIONS",
    "RECOGNIZED_TAGS",
    "AgentToolSpecRegistry",
    "EventRegistry",
    "HookRegistry",
    "PatternRegistry",
    "ToolDataTypeRegistry",
    "ToolGroupRegistry",
    "default_event_registry",
    "default_hook_registry",
    "default_pattern_registry",
    "default_tool_data_type_registry",
    "default_tool_group_registry",
    "default_tool_spec_registry",
    "derive_group",
    "register_kaos_tool_groups",
]
