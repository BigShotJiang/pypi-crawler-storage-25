"""CardShowData MCP server.

Exposes CardShowData API tools to AI assistants via the Model Context Protocol.
Configure with CSD_API_KEY and CSD_BASE_URL environment variables.

Usage:
    CSD_API_KEY=your_key cardshowdata-mcp
"""

import json
import os

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from cardshowdata_mcp.error_reference import DOC_BASE, ERRORS, HANDLING_GUIDANCE

BASE_URL = os.environ.get("CSD_BASE_URL", "https://api.cardshowdata.com")
API_KEY = os.environ.get("CSD_API_KEY", "")

server = Server("cardshowdata")


def _client() -> httpx.Client:
    return httpx.Client(
        base_url=BASE_URL,
        headers={"X-API-Key": API_KEY},
        timeout=30,
    )


def _format_response(data) -> str:
    return json.dumps(data, indent=2, default=str)


def _explain_error(code: str | None) -> str:
    """Render an error-code reference lookup. Called by the explain_api_error tool."""
    if not code:
        lines = ["CardShowData API error codes (40 total). Pass `code` to this tool for a single entry.\n"]
        by_cat: dict[str, list[str]] = {}
        for c, spec in ERRORS.items():
            by_cat.setdefault(spec["category"], []).append(c)
        for cat in sorted(by_cat):
            lines.append(f"## {cat}")
            for c in sorted(by_cat[cat]):
                spec = ERRORS[c]
                lines.append(f"  {spec['status']}  {c}")
            lines.append("")
        return "\n".join(lines)

    spec = ERRORS.get(code)
    if not spec:
        return (
            f"Unknown error code: {code!r}. Call explain_api_error with no code "
            f"to list every registered code, or see {DOC_BASE}."
        )
    return (
        f"{spec['status']} {code} [{spec['category']}]\n"
        f"message:    {spec['message']}\n"
        f"retryable:  {spec['retryable']}\n"
        f"handling:   {HANDLING_GUIDANCE.get(spec['category'], '')}\n"
        f"reference:  {DOC_BASE}/{code}"
    )


def _format_api_error(response: httpx.Response) -> str:
    """Render a CardShowData error response into a concise, actionable message.

    Every 4xx/5xx from the API uses a unified envelope:
        {"error": {"type", "code", "message", "status", "request_id", "doc_url", "details"}}

    We surface code/message/doc_url prominently so the assistant can give the
    user specific guidance (e.g. 'upgrade your plan' vs 'retry after 30s').
    """
    request_id = response.headers.get("x-request-id", "unknown")
    try:
        body = response.json()
    except Exception:
        return (
            f"API error {response.status_code} (request_id={request_id}): "
            f"{response.text[:300]}"
        )

    err = body.get("error") if isinstance(body, dict) else None
    if not isinstance(err, dict):
        return f"API error {response.status_code} (request_id={request_id}): {body}"

    lines = [
        f"API error {err.get('status', response.status_code)} "
        f"[{err.get('code', 'unknown')}] — {err.get('message', '')}",
        f"request_id: {err.get('request_id', request_id)}",
        f"reference:  {err.get('doc_url', '')}",
    ]
    details = err.get("details")
    if details:
        lines.append(f"details: {json.dumps(details, default=str)}")
    return "\n".join(line for line in lines if line.strip())


@server.list_tools()
async def list_tools():
    return [
        Tool(
            name="search_cards",
            description="Search for TCG cards by name. Returns card details, pricing in USD and EUR, and graded values.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Card name to search for (e.g., 'Charizard', 'Black Lotus')"},
                    "tcg": {"type": "string", "description": "Filter by 2-letter TCG code: pk=Pokemon, mt=Magic, yg=Yu-Gi-Oh, lc=Lorcana, op=One Piece, dg=Digimon. Call list_tcgs for the full list."},
                },
                "required": ["query"],
            },
        ),
        Tool(
            name="get_card",
            description="Get full details and pricing for a specific card by its pretty_id (e.g., pk_bs_004) or csd_product_id UUID. Pricing is scoped per printing — each entry in variants[] has its own raw/graded pricing, recommended_sell {price_cents, approach, confidence, show_sales_count, lifecycle_state, adjustment_pct}, and price trends {7d/30d/90d/180d change_cents+pct}. Always look at every variant; a Base Set Charizard's 1st-edition holofoil can recommend a very different sell price than the unlimited holofoil. variants[].image and variants[].population are placeholders (null in v2.2.0, populated by a future release). Card-level population (Starter+) rolls up grades across ALL of a product's variants; use it for aggregate scarcity.",
            inputSchema={
                "type": "object",
                "properties": {
                    "card_id": {"type": "string", "description": "pretty_id (e.g., pk_bs_004) or csd_product_id UUID"},
                    "include": {"type": "string", "description": "Comma-separated: details, trends"},
                },
                "required": ["card_id"],
            },
        ),
        Tool(
            name="get_pricing",
            description="Get latest pricing for a product by csd_product_id UUID. Returns one entry per printing (normal, holofoil, 1st-edition, etc.) in a `variants[]` array — each with its own market_price_cents / fair_value_cents / lifecycle_state / confidence. Always inspect every variant; a Base Set Charizard's 1st-edition holofoil can be ~100× the unlimited normal.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string", "description": "csd_product_id UUID"},
                },
                "required": ["product_id"],
            },
        ),
        Tool(
            name="get_grading",
            description="Get graded card pricing (PSA, BGS, CGC, etc.) with high/median/low for a product.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string", "description": "csd_product_id UUID"},
                    "grader": {"type": "string", "description": "Filter by grader (psa, bgs, cgc, sgc)"},
                },
                "required": ["product_id"],
            },
        ),
        Tool(
            name="list_tcgs",
            description="List all available TCGs (Pokemon, Magic, Yu-Gi-Oh, Lorcana, One Piece, Digimon, etc.) with product and set counts. Each entry includes a full `tcg_slug` (e.g. 'pokemon', 'magic-the-gathering' — used in /v1/catalog/{tcg_slug}/sets) and a 2-letter `tcg_code` (e.g. 'pk', 'mt' — used in pretty_ids and the `tcg` filter on /v1/cards).",
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="list_sets",
            description="List all sets/expansions for a TCG with set codes and product counts.",
            inputSchema={
                "type": "object",
                "properties": {
                    "tcg": {"type": "string", "description": "Full TCG slug (e.g., pokemon, magic-the-gathering, disney-lorcana). Use list_tcgs to discover slugs."},
                },
                "required": ["tcg"],
            },
        ),
        Tool(
            name="get_pricing_history",
            description="Get pricing history for a product over time. Returns `{product_id, variants: [{subtype, history: [daily snapshots...]}, ...]}` — per-variant so different printings don't mix into one misleading time series.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string", "description": "csd_product_id UUID"},
                    "days": {"type": "integer", "description": "Number of days of history (default 30, max 365)"},
                },
                "required": ["product_id"],
            },
        ),
        Tool(
            name="get_ebay_sales",
            description="Get recent eBay sold listings for a graded card. Shows actual transaction prices, dates, and formats.",
            inputSchema={
                "type": "object",
                "properties": {
                    "card_id": {"type": "string", "description": "pretty_id (e.g., pk_bs_004) or csd_product_id UUID"},
                    "company": {"type": "string", "description": "Grading company (default PSA)"},
                    "grade": {"type": "string", "description": "Grade (default 10)"},
                    "limit": {"type": "integer", "description": "Max results (1-20, default 5)"},
                },
                "required": ["card_id"],
            },
        ),
        Tool(
            name="get_lifecycle",
            description="Get lifecycle analytics for a product: first/last seen, peak price, days since peak, decay half-life. Returns a `variants[]` array — each printing has its own lifecycle (a 1st-edition holofoil peaks on a different curve than its unlimited normal). Tells you if each printing is rising, stable, peak_risk, or declining.",
            inputSchema={
                "type": "object",
                "properties": {
                    "product_id": {"type": "string", "description": "csd_product_id UUID"},
                },
                "required": ["product_id"],
            },
        ),
        Tool(
            name="get_pricing_changes",
            description="Get variants whose price changed recently. Returns old/new prices and % change per printing — each item carries a `subtype` field so a 1st-edition spike doesn't get attributed to the unlimited printing. Great for finding cards that spiked or dropped.",
            inputSchema={
                "type": "object",
                "properties": {
                    "since": {"type": "string", "description": "ISO 8601 timestamp (e.g., 2026-04-07T00:00:00Z)"},
                    "tcg": {"type": "string", "description": "Filter by 2-letter TCG code (e.g., pk, mt, lc) — same code surfaced by list_tcgs as `tcg_code`."},
                    "min_pct": {"type": "number", "description": "Minimum % change to include (default 5)"},
                    "limit": {"type": "integer", "description": "Max results (default 50)"},
                },
                "required": ["since"],
            },
        ),
        Tool(
            name="refresh_population",
            description="Trigger an on-demand population refresh for a specific card. Returns fresh grading population counts from PSA, CGC, TAG, AGS. Requires Pro or Business plan. Limited to 10 refreshes/day per account.",
            inputSchema={
                "type": "object",
                "properties": {
                    "card_id": {"type": "string", "description": "pretty_id (e.g., pk_bs_004) or csd_product_id UUID"},
                },
                "required": ["card_id"],
            },
        ),
        Tool(
            name="search_catalog",
            description="Search products by name across all TCGs. Faster than search_cards for quick lookups.",
            inputSchema={
                "type": "object",
                "properties": {
                    "q": {"type": "string", "description": "Search query (min 2 characters)"},
                    "tcg_slug": {"type": "string", "description": "Filter by full TCG slug (e.g., pokemon, magic-the-gathering)"},
                    "limit": {"type": "integer", "description": "Max results (1-100, default 25)"},
                },
                "required": ["q"],
            },
        ),
        Tool(
            name="get_usage",
            description="Return the caller's current account usage: rate limits, daily/monthly call counts, tier, and billing info. Useful before retrying after a rate_limit_exceeded error.",
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="explain_api_error",
            description=(
                "Explain a CardShowData API error code. The CSD API returns a stable "
                "envelope {\"error\": {code, message, status, request_id, doc_url, details}}. "
                "Pass the `code` from any error response to get the human-readable "
                "description, HTTP status, and recommended handling. Use when you see "
                "codes like rate_limit_exceeded, tier_upgrade_required, invalid_api_key, "
                "product_not_found, validation_failed, etc."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Stable error code from error.code (e.g. 'rate_limit_exceeded'). Omit to list all 40 codes.",
                    },
                },
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict):
    with _client() as client:
        try:
            if name == "search_cards":
                params = {"q": f"name:{arguments['query']}", "page_size": 10}
                if arguments.get("tcg"):
                    params["tcg"] = arguments["tcg"]
                r = client.get("/v1/cards", params=params)

            elif name == "get_card":
                params = {}
                if arguments.get("include"):
                    params["include"] = arguments["include"]
                r = client.get(f"/v1/cards/{arguments['card_id']}", params=params)

            elif name == "get_pricing":
                r = client.get(f"/v1/pricing/{arguments['product_id']}")

            elif name == "get_grading":
                params = {}
                if arguments.get("grader"):
                    params["grader"] = arguments["grader"]
                r = client.get(f"/v1/grading/{arguments['product_id']}", params=params)

            elif name == "list_tcgs":
                r = client.get("/v1/catalog/tcgs")

            elif name == "list_sets":
                r = client.get(f"/v1/catalog/{arguments['tcg']}/sets")

            elif name == "get_pricing_history":
                params = {"days": arguments.get("days", 30)}
                r = client.get(f"/v1/pricing/history/{arguments['product_id']}", params=params)

            elif name == "get_ebay_sales":
                params = {}
                if arguments.get("company"):
                    params["company"] = arguments["company"]
                if arguments.get("grade"):
                    params["grade"] = arguments["grade"]
                if arguments.get("limit"):
                    params["limit"] = arguments["limit"]
                r = client.get(f"/v1/cards/{arguments['card_id']}/ebay-sales", params=params)

            elif name == "get_lifecycle":
                r = client.get(f"/v1/lifecycle/{arguments['product_id']}")

            elif name == "get_pricing_changes":
                params = {"since": arguments["since"]}
                if arguments.get("tcg"):
                    params["tcg"] = arguments["tcg"]
                if arguments.get("min_pct"):
                    params["min_pct"] = arguments["min_pct"]
                if arguments.get("limit"):
                    params["limit"] = arguments["limit"]
                r = client.get("/v1/pricing/changes", params=params)

            elif name == "refresh_population":
                r = client.post(f"/v1/cards/{arguments['card_id']}/population/refresh")

            elif name == "search_catalog":
                params = {"q": arguments["q"]}
                if arguments.get("tcg_slug"):
                    params["tcg_slug"] = arguments["tcg_slug"]
                if arguments.get("limit"):
                    params["limit"] = arguments["limit"]
                r = client.get("/v1/catalog/search", params=params)

            elif name == "get_usage":
                r = client.get("/v1/usage")

            elif name == "explain_api_error":
                return [TextContent(type="text", text=_explain_error(arguments.get("code")))]

            else:
                return [TextContent(type="text", text=f"Unknown tool: {name}")]

            if r.is_error:
                return [TextContent(type="text", text=_format_api_error(r))]

            return [TextContent(type="text", text=_format_response(r.json()))]

        except httpx.HTTPError as e:
            return [TextContent(type="text", text=f"Network error reaching CardShowData API: {e}")]
        except Exception as e:
            return [TextContent(type="text", text=f"Unexpected MCP tool error: {e}")]


async def _serve() -> None:
    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    import asyncio
    asyncio.run(_serve())


if __name__ == "__main__":
    main()
