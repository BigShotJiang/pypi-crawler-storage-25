"""CardShowData MCP server — lets AI assistants query TCG pricing data."""

__version__ = "1.0.1"
