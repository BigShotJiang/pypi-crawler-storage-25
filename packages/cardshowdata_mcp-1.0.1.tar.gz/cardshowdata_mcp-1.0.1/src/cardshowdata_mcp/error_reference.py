"""Static snapshot of the CardShowData API error-code registry.

This mirrors the canonical registry in
``apps/api/src/cardshowdata_api/errors.py`` so the MCP server can answer
``explain_api_error`` without a network call. When the canonical registry
changes, regenerate this file via scripts/generate_mcp_error_reference.py
(or update by hand — it is small and stable).

Every entry: code → (category, status, retryable, default_message)
"""

from __future__ import annotations

DOC_BASE = "https://cardshowdata.com/docs/errors"

ERRORS: dict[str, dict] = {
    # Auth
    "missing_api_key":            {"category": "auth_error", "status": 401, "retryable": False, "message": "No API key provided. Send it via the X-API-Key header or Authorization: Bearer <key>."},
    "invalid_api_key":            {"category": "auth_error", "status": 401, "retryable": False, "message": "The API key provided is not valid."},
    "malformed_api_key":          {"category": "auth_error", "status": 401, "retryable": False, "message": "The API key is malformed. Expected format: 'csd_live_...' or 'csd_test_...'."},
    "internal_key_required":      {"category": "auth_error", "status": 401, "retryable": False, "message": "This endpoint requires an internal/admin key (X-Internal-Key)."},
    # Permission
    "api_key_inactive":           {"category": "permission_error", "status": 403, "retryable": False, "message": "This API key has been deactivated. Create a new key in your dashboard."},
    "account_inactive":           {"category": "permission_error", "status": 403, "retryable": False, "message": "This account is inactive. Contact support@cardshowdata.com."},
    "account_type_not_allowed":   {"category": "permission_error", "status": 403, "retryable": False, "message": "Your account type cannot access this endpoint."},
    "tier_upgrade_required":      {"category": "permission_error", "status": 403, "retryable": False, "message": "Your current plan does not include this feature. Upgrade to unlock."},
    "feature_not_in_tier":        {"category": "permission_error", "status": 403, "retryable": False, "message": "This feature is not available on your plan."},
    "subscription_required":      {"category": "permission_error", "status": 403, "retryable": False, "message": "An active Stripe subscription is required for this action."},
    # Invalid request
    "invalid_request":            {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "The request is malformed."},
    "mutually_exclusive_fields":  {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "Two or more fields that cannot be used together were provided."},
    "missing_required_field":     {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "A required field was not provided."},
    "batch_too_large":            {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "The batch exceeds the maximum allowed size."},
    "invalid_id_format":          {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "The identifier format is not recognized."},
    "invalid_payload":            {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "The request payload is invalid."},
    "invalid_signature":          {"category": "invalid_request_error", "status": 400, "retryable": False, "message": "The request signature is invalid."},
    # Validation
    "validation_failed":          {"category": "validation_error", "status": 422, "retryable": False, "message": "One or more request fields failed validation. Inspect details.field_errors."},
    # Not found
    "product_not_found":          {"category": "not_found_error", "status": 404, "retryable": False, "message": "No product exists for the given identifier."},
    "card_not_found":             {"category": "not_found_error", "status": 404, "retryable": False, "message": "No card exists for the given identifier."},
    "expansion_not_found":        {"category": "not_found_error", "status": 404, "retryable": False, "message": "No expansion exists for the given identifier."},
    "cert_not_found":             {"category": "not_found_error", "status": 404, "retryable": False, "message": "No cert exists for the given grader + cert number."},
    "population_not_linked":      {"category": "not_found_error", "status": 404, "retryable": False, "message": "No population data is linked to this card yet."},
    "subscription_not_found":     {"category": "not_found_error", "status": 404, "retryable": False, "message": "No subscription exists for this account."},
    "webhook_not_found":          {"category": "not_found_error", "status": 404, "retryable": False, "message": "No webhook subscription exists for the given identifier."},
    "resource_not_found":         {"category": "not_found_error", "status": 404, "retryable": False, "message": "The requested resource does not exist."},
    # Conflict
    "duplicate_resource":         {"category": "conflict_error", "status": 409, "retryable": False, "message": "A resource with this identifier already exists."},
    "conflict":                   {"category": "conflict_error", "status": 409, "retryable": False, "message": "The request conflicts with the current state of the resource."},
    # Rate limit (all retryable)
    "rate_limit_exceeded":        {"category": "rate_limit_error", "status": 429, "retryable": True,  "message": "You have exceeded the per-minute request limit for your plan."},
    "daily_limit_exceeded":       {"category": "rate_limit_error", "status": 429, "retryable": True,  "message": "You have reached the daily call limit for your plan."},
    "monthly_limit_exceeded":     {"category": "rate_limit_error", "status": 429, "retryable": True,  "message": "You have reached the monthly call limit for your plan."},
    "overage_cap_reached":        {"category": "rate_limit_error", "status": 429, "retryable": True,  "message": "Your monthly overage spend cap has been reached."},
    "refresh_limit_exceeded":     {"category": "rate_limit_error", "status": 429, "retryable": True,  "message": "You have reached the daily limit for on-demand refresh requests."},
    # Upstream
    "dataset_not_published":      {"category": "upstream_error", "status": 503, "retryable": True,  "message": "The active pricing dataset is not yet published. Try again shortly."},
    "service_unavailable":        {"category": "upstream_error", "status": 503, "retryable": True,  "message": "A required service is temporarily unavailable."},
    "stripe_unavailable":         {"category": "upstream_error", "status": 503, "retryable": True,  "message": "Stripe is not configured or is unavailable."},
    "upstream_failed":            {"category": "upstream_error", "status": 502, "retryable": True,  "message": "An upstream data source failed to respond."},
    "population_refresh_failed":  {"category": "upstream_error", "status": 502, "retryable": True,  "message": "Population refresh failed. Please try again later."},
    "cert_lookup_failed":         {"category": "upstream_error", "status": 502, "retryable": True,  "message": "The cert lookup failed upstream. Please try again later."},
    # Generic
    "internal_error":             {"category": "api_error",       "status": 500, "retryable": True,  "message": "An internal error occurred. Contact support with the request_id if this persists."},
}

# Category-level hints on how the caller should respond.
HANDLING_GUIDANCE: dict[str, str] = {
    "auth_error":            "Fix the caller's credentials. Verify the API key is present, not rotated, and sent in X-API-Key or Authorization: Bearer.",
    "permission_error":      "The call authenticated but is not allowed. Check the account's tier and entitlements; error.details usually lists what's missing.",
    "invalid_request_error": "The request shape is wrong. Inspect error.details for the specific field, limit, or mutually-exclusive combination.",
    "validation_error":      "Pydantic rejected one or more fields. Read error.details.field_errors for per-field code, message, and received value.",
    "not_found_error":       "The identifier doesn't resolve. Some resources (population, lifecycle) are built asynchronously and can 404 until matching finishes.",
    "conflict_error":        "Resource already exists or state conflicts. For duplicates, fetch the existing resource instead of creating a new one.",
    "rate_limit_error":      "Retryable. Honor Retry-After (or retry_after_seconds in details). Prefer bulk endpoints. Upgrade tier for higher limits.",
    "upstream_error":        "Retryable with exponential backoff. If persistent, check status or contact support with the request_id.",
    "api_error":             "Retryable with exponential backoff if the operation is idempotent. Contact support with the request_id if it persists.",
}
