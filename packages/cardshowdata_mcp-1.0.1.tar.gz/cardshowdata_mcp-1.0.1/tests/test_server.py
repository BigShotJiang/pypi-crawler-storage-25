"""Tests for the CardShowData MCP server helpers.

Covers the pure functions that format API error responses for Claude and
explain error codes from the registry snapshot. The MCP itself is invoked
over stdio in production; these tests exercise the helpers and tool
registration without standing up a live MCP session.
"""

from __future__ import annotations

import httpx
import pytest

from cardshowdata_mcp import error_reference, server as server_module
from cardshowdata_mcp.server import _explain_error, _format_api_error, call_tool, list_tools


# ---------------------------------------------------------------------------
# error_reference registry
# ---------------------------------------------------------------------------


class TestErrorReferenceRegistry:
    def test_registry_has_expected_codes(self):
        # Spot-check one code per category — full parity with the API
        # REGISTRY is enforced by the drift checker, not here.
        required = {
            "missing_api_key",
            "tier_upgrade_required",
            "rate_limit_exceeded",
            "validation_failed",
            "product_not_found",
            "dataset_not_published",
            "internal_error",
        }
        assert required <= set(error_reference.ERRORS)

    def test_every_entry_has_full_shape(self):
        for code, spec in error_reference.ERRORS.items():
            assert set(spec) == {"category", "status", "retryable", "message"}, code
            assert 400 <= spec["status"] < 600
            assert spec["category"] in error_reference.HANDLING_GUIDANCE
            assert isinstance(spec["retryable"], bool)
            assert spec["message"]


# ---------------------------------------------------------------------------
# _explain_error
# ---------------------------------------------------------------------------


class TestExplainError:
    def test_known_code_returns_all_fields(self):
        out = _explain_error("rate_limit_exceeded")
        assert "429" in out
        assert "rate_limit_exceeded" in out
        assert "rate_limit_error" in out
        assert "True" in out  # retryable
        assert "docs/errors/rate_limit_exceeded" in out
        assert "Honor Retry-After" in out  # category handling guidance

    def test_unknown_code_points_to_docs(self):
        out = _explain_error("not_a_real_code")
        assert "Unknown error code" in out
        assert "not_a_real_code" in out
        assert "docs/errors" in out

    def test_no_code_lists_every_code(self):
        out = _explain_error(None)
        for code in error_reference.ERRORS:
            assert code in out


# ---------------------------------------------------------------------------
# _format_api_error
# ---------------------------------------------------------------------------


def _make_response(status: int, body: dict | None, *, request_id: str | None = None) -> httpx.Response:
    headers = {"X-Request-Id": request_id} if request_id else {}
    if body is None:
        return httpx.Response(status, text="something went wrong", headers=headers)
    return httpx.Response(status, json=body, headers=headers)


class TestFormatApiError:
    def test_canonical_envelope_is_surfaced(self):
        body = {
            "error": {
                "type": "rate_limit_error",
                "code": "rate_limit_exceeded",
                "message": "Your Starter plan allows 120 requests/minute.",
                "status": 429,
                "request_id": "req_abc",
                "doc_url": "https://cardshowdata.com/docs/errors/rate_limit_exceeded",
                "details": {"tier": "starter", "limit": 120},
            }
        }
        out = _format_api_error(_make_response(429, body))
        assert "429" in out
        assert "rate_limit_exceeded" in out
        assert "Your Starter plan" in out
        assert "req_abc" in out
        assert "docs/errors/rate_limit_exceeded" in out
        assert "starter" in out  # details rendered

    def test_falls_back_when_body_is_not_json(self):
        response = _make_response(502, None, request_id="req_xyz")
        out = _format_api_error(response)
        assert "502" in out
        assert "something went wrong" in out
        assert "req_xyz" in out  # pulled from header

    def test_falls_back_on_unexpected_body_shape(self):
        # e.g. during a mid-deploy when some legacy middleware is still up.
        response = _make_response(500, {"message": "oops"}, request_id="req_1")
        out = _format_api_error(response)
        assert "500" in out
        assert "req_1" in out


# ---------------------------------------------------------------------------
# Tool registration
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_list_tools_registers_public_surface():
    tools = await list_tools()
    names = {t.name for t in tools}
    # Added in this change
    assert "explain_api_error" in names
    assert "get_usage" in names
    assert "refresh_population" in names
    # Previously-existing tools we must not regress
    for expected in ("search_cards", "get_card", "get_pricing", "list_tcgs"):
        assert expected in names


# ---------------------------------------------------------------------------
# Tool dispatch — mocked happy paths
#
# Each test pins one tool's request shape (URL, method, query params) and
# checks that a successful response flows back to the caller. These guard
# against API-shape drift: if /v1/cards/{id} or /v1/pricing/{id} change paths
# or required params, the corresponding test fails immediately.
# ---------------------------------------------------------------------------


import httpx as _httpx


def _mock_client(handler):
    """Build an httpx.Client with a MockTransport, headers shaped like _client()."""
    return _httpx.Client(
        base_url="https://api.cardshowdata.test",
        headers={"X-API-Key": "csd_test_dummy"},
        timeout=5,
        transport=_httpx.MockTransport(handler),
    )


def _patch_client(monkeypatch, handler):
    monkeypatch.setattr(server_module, "_client", lambda: _mock_client(handler))


@pytest.mark.asyncio
async def test_get_card_dispatches_to_v1_cards_path(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["url"] = str(request.url)
        captured["method"] = request.method
        return _httpx.Response(200, json={"id": "pk_bs_004", "tcg": "pk", "variants": []})

    _patch_client(monkeypatch, handler)
    out = await call_tool("get_card", {"card_id": "pk_bs_004", "include": "trends"})
    assert "pk_bs_004" in out[0].text
    assert captured["method"] == "GET"
    assert "/v1/cards/pk_bs_004" in captured["url"]
    assert "include=trends" in captured["url"]


@pytest.mark.asyncio
async def test_search_cards_uses_name_prefix(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["url"] = str(request.url)
        return _httpx.Response(200, json={"data": [], "pagination": {}})

    _patch_client(monkeypatch, handler)
    await call_tool("search_cards", {"query": "Charizard", "tcg": "pk"})
    assert "/v1/cards" in captured["url"]
    # query forwarded with the name: prefix the API expects
    assert "q=name%3ACharizard" in captured["url"] or "q=name:Charizard" in captured["url"]
    assert "tcg=pk" in captured["url"]


@pytest.mark.asyncio
async def test_get_pricing_dispatches_to_v1_pricing(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["url"] = str(request.url)
        return _httpx.Response(200, json={"product_id": "uuid", "as_of_date": "2026-04-24", "variants": []})

    _patch_client(monkeypatch, handler)
    out = await call_tool("get_pricing", {"product_id": "274fd3bc-1b66-45bc-b9bb-db65ed088748"})
    assert "/v1/pricing/274fd3bc" in captured["url"]
    assert "as_of_date" in out[0].text


@pytest.mark.asyncio
async def test_list_tcgs_dispatches_to_catalog_tcgs(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["url"] = str(request.url)
        return _httpx.Response(200, json=[{"tcg_slug": "pokemon", "tcg_code": "pk", "tcg_name": "Pokemon", "product_count": 1, "set_count": 1}])

    _patch_client(monkeypatch, handler)
    out = await call_tool("list_tcgs", {})
    assert "/v1/catalog/tcgs" in captured["url"]
    assert "tcg_code" in out[0].text


@pytest.mark.asyncio
async def test_get_grading_forwards_grader_filter(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["url"] = str(request.url)
        return _httpx.Response(200, json={"csd_product_id": "uuid", "snapshot_date": "2026-04-24", "source": "scrydex", "prices": []})

    _patch_client(monkeypatch, handler)
    await call_tool("get_grading", {"product_id": "uuid", "grader": "psa"})
    assert "/v1/grading/uuid" in captured["url"]
    assert "grader=psa" in captured["url"]


@pytest.mark.asyncio
async def test_refresh_population_uses_post(monkeypatch):
    captured = {}

    def handler(request: _httpx.Request) -> _httpx.Response:
        captured["method"] = request.method
        captured["url"] = str(request.url)
        return _httpx.Response(200, json={"status": "queued"})

    _patch_client(monkeypatch, handler)
    await call_tool("refresh_population", {"card_id": "pk_bs_004"})
    assert captured["method"] == "POST"
    assert "/v1/cards/pk_bs_004/population/refresh" in captured["url"]


@pytest.mark.asyncio
async def test_api_error_envelope_is_surfaced_to_caller(monkeypatch):
    """A 4xx with the canonical envelope should yield a formatted, code-bearing message."""
    body = {
        "error": {
            "type": "permission_error",
            "code": "tier_upgrade_required",
            "message": "Upgrade to Starter to access live pricing.",
            "status": 403,
            "request_id": "req_abc",
            "doc_url": "https://cardshowdata.com/docs/errors/tier_upgrade_required",
            "details": {"required_entitlement": "pricing.live"},
        }
    }

    def handler(request: _httpx.Request) -> _httpx.Response:
        return _httpx.Response(403, json=body)

    _patch_client(monkeypatch, handler)
    out = await call_tool("get_pricing", {"product_id": "uuid"})
    text = out[0].text
    assert "403" in text
    assert "tier_upgrade_required" in text
    assert "Upgrade to Starter" in text
    assert "req_abc" in text


@pytest.mark.asyncio
async def test_unknown_tool_returns_descriptive_message(monkeypatch):
    # _client() shouldn't even be called, but pin it for safety.
    _patch_client(monkeypatch, lambda r: _httpx.Response(500))
    out = await call_tool("not_a_tool", {})
    assert "Unknown tool" in out[0].text
