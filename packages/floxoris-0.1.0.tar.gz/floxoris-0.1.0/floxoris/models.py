from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ModerationResult:
    label: str
    class_id: int
    safe_score: float
    toxic_score: float
    latency_ms: float | None
    model: str
