from __future__ import annotations


class FloxorisError(Exception):
    """Base exception for all SDK errors."""

    def __init__(self, message: str, *, status_code: int | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class AuthError(FloxorisError):
    """Raised when the API rejects the provided credentials."""


class RateLimitError(FloxorisError):
    """Raised when the API rate limit has been exceeded."""


class APIError(FloxorisError):
    """Raised for server-side and unexpected API failures."""
