from __future__ import annotations

from .client import AsyncClient, DEFAULT_BASE_URL, DEFAULT_MODEL
from .exceptions import APIError, AuthError, FloxorisError, RateLimitError
from .models import ModerationResult

__all__ = [
    "APIError",
    "AsyncClient",
    "AuthError",
    "FloxorisError",
    "ModerationResult",
    "RateLimitError",
    "api_key",
    "base_url",
    "default_model",
    "moderate",
]

__version__ = "0.1.0"

api_key: str | None = None
base_url: str = DEFAULT_BASE_URL
default_model: str = DEFAULT_MODEL


async def moderate(text: str, *, model: str | None = None) -> ModerationResult:
    async with AsyncClient(
        api_key=api_key,
        base_url=base_url,
        default_model=default_model,
    ) as client:
        return await client.moderate(text, model=model)
