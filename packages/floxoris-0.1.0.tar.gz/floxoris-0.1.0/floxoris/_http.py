from __future__ import annotations

from typing import Any

import httpx

from .exceptions import APIError, AuthError, FloxorisError, RateLimitError


DEFAULT_TIMEOUT = 30.0


class _AsyncHTTPClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._api_key = api_key
        self._client = httpx.AsyncClient(
            base_url=base_url.rstrip("/"),
            timeout=timeout,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Accept": "application/json",
                "Content-Type": "application/json",
            },
        )

    async def __aenter__(self) -> "_AsyncHTTPClient":
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        await self._client.aclose()

    async def post_json(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        response = await self._request_with_retry("POST", path, json=payload)
        data = self._parse_json(response)
        if not isinstance(data, dict):
            raise APIError("API returned an unexpected response payload.", status_code=response.status_code)
        return data

    async def _request_with_retry(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        attempts = 0
        last_response: httpx.Response | None = None

        while attempts < 2:
            attempts += 1
            try:
                response = await self._client.request(method, path, **kwargs)
            except httpx.HTTPError as exc:
                raise FloxorisError(f"Request failed: {exc}") from exc

            if response.status_code < 500 or attempts == 2:
                self._raise_for_status(response)
                return response

            last_response = response

        if last_response is None:
            raise APIError("Request failed without a response.")

        self._raise_for_status(last_response)
        return last_response

    def _parse_json(self, response: httpx.Response) -> Any:
        try:
            return response.json()
        except ValueError as exc:
            raise APIError("API returned invalid JSON.", status_code=response.status_code) from exc

    def _raise_for_status(self, response: httpx.Response) -> None:
        status_code = response.status_code
        if 200 <= status_code < 300:
            return

        message = self._extract_error_message(response)

        if status_code == 401:
            raise AuthError(message, status_code=status_code)
        if status_code == 429:
            raise RateLimitError(message, status_code=status_code)
        if status_code >= 500:
            raise APIError(message, status_code=status_code)
        raise FloxorisError(message, status_code=status_code)

    def _extract_error_message(self, response: httpx.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            payload = None

        if isinstance(payload, dict):
            for key in ("message", "error", "detail"):
                value = payload.get(key)
                if isinstance(value, str) and value.strip():
                    return value.strip()

        text = response.text.strip()
        if text:
            return text

        return f"API request failed with status code {response.status_code}."
