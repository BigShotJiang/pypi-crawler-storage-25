from __future__ import annotations

from typing import Any

from ._http import _AsyncHTTPClient
from .exceptions import FloxorisError
from .models import ModerationResult


DEFAULT_MODEL = "floxoris/harmony-v0"
DEFAULT_BASE_URL = "https://floxoris.xyz"


class AsyncClient:
    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        default_model: str = DEFAULT_MODEL,
        timeout: float = 30.0,
    ) -> None:
        if api_key is None:
            import floxoris as floxoris_module

            api_key = floxoris_module.api_key

        if base_url is None:
            import floxoris as floxoris_module

            base_url = floxoris_module.base_url

        if not api_key:
            raise FloxorisError("API key is required. Set floxoris.api_key or pass api_key explicitly.")

        self.api_key = api_key
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.default_model = default_model
        self.timeout = timeout
        self._http = _AsyncHTTPClient(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
        )

    async def __aenter__(self) -> "AsyncClient":
        await self._http.__aenter__()
        return self

    async def __aexit__(self, exc_type: object, exc: object, tb: object) -> None:
        await self._http.__aexit__(exc_type, exc, tb)

    async def aclose(self) -> None:
        await self._http.aclose()

    async def moderate(self, text: str, *, model: str | None = None) -> ModerationResult:
        payload = {
            "text": text,
            "model": model or self.default_model,
        }
        data = await self._http.post_json("moderate", payload)
        return self._parse_moderation_result(data, requested_model=payload["model"])

    def _parse_moderation_result(
        self,
        payload: dict[str, Any],
        *,
        requested_model: str,
    ) -> ModerationResult:
        result_payload = payload.get("result")
        if isinstance(result_payload, dict):
            payload = result_payload

        try:
            latency = payload.get("latency_ms")
            if latency is not None:
                latency = float(latency)

            return ModerationResult(
                label=str(payload["label"]),
                class_id=int(payload["class_id"]),
                safe_score=float(payload["safe_score"]),
                toxic_score=float(payload["toxic_score"]),
                latency_ms=latency,
                model=str(payload.get("model", requested_model)),
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise FloxorisError("API returned an invalid moderation response.") from exc
