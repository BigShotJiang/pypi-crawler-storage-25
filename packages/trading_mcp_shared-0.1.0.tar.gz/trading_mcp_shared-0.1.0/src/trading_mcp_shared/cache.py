"""LRU cache wrapper with configurable TTL using cachetools."""

from typing import TypeVar

from cachetools import TTLCache

T = TypeVar("T")

_DEFAULT_MAXSIZE = 256
_DEFAULT_TTL = 300  # seconds


class TTLCacheWrapper:
    """Thin wrapper around cachetools.TTLCache for per-instance TTL config."""

    def __init__(self, maxsize: int = _DEFAULT_MAXSIZE, ttl: float = _DEFAULT_TTL):
        self._cache: TTLCache = TTLCache(maxsize=maxsize, ttl=ttl)

    def get(self, key: str) -> object | None:
        return self._cache.get(key)

    def set(self, key: str, value: object) -> None:
        self._cache[key] = value

    def delete(self, key: str) -> None:
        self._cache.pop(key, None)

    def clear(self) -> None:
        self._cache.clear()

    @property
    def size(self) -> int:
        return len(self._cache)
