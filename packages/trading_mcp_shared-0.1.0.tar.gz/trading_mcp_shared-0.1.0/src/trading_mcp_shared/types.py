"""Shared domain types for Trading MCP servers."""

from datetime import date, datetime

from pydantic import BaseModel, Field


# ── Market Data ──────────────────────────────────────────────────


class Quote(BaseModel):
    symbol: str
    price: float
    change: float
    change_percent: float = Field(alias="changePercent")
    volume: int
    market_cap: float | None = Field(default=None, alias="marketCap")
    high: float | None = None
    low: float | None = None
    open: float | None = None
    previous_close: float | None = Field(default=None, alias="previousClose")
    timestamp: datetime

    model_config = {"populate_by_name": True}


class OHLCVCandle(BaseModel):
    timestamp: datetime
    open: float
    high: float
    low: float
    close: float
    volume: int


class OHLCVResponse(BaseModel):
    symbol: str
    interval: str
    candles: list[OHLCVCandle]


# ── News & Sentiment ────────────────────────────────────────────


class SentimentScore(BaseModel):
    label: str = Field(description="positive | negative | neutral")
    score: float = Field(ge=-1.0, le=1.0)
    model: str = Field(description="Model used for scoring")


class NewsArticle(BaseModel):
    title: str
    url: str
    source: str
    published_at: datetime = Field(alias="publishedAt")
    summary: str | None = None
    symbols: list[str] = Field(default_factory=list)
    sentiment: SentimentScore | None = None

    model_config = {"populate_by_name": True}


class NewsSentimentResponse(BaseModel):
    query: str
    articles: list[NewsArticle]
    overall_sentiment: SentimentScore | None = Field(
        default=None, alias="overallSentiment"
    )

    model_config = {"populate_by_name": True}


# ── SEC Filings ─────────────────────────────────────────────────


class FilingResult(BaseModel):
    company: str
    cik: str
    filing_type: str = Field(alias="filingType")
    filed_date: date = Field(alias="filedDate")
    accession_number: str = Field(alias="accessionNumber")
    url: str
    description: str | None = None

    model_config = {"populate_by_name": True}


# ── Backtest ────────────────────────────────────────────────────


class BacktestTrade(BaseModel):
    timestamp: datetime
    side: str = Field(description="buy | sell")
    symbol: str
    quantity: float
    price: float
    pnl: float | None = None


class BacktestResult(BaseModel):
    strategy_name: str = Field(alias="strategyName")
    start_date: date = Field(alias="startDate")
    end_date: date = Field(alias="endDate")
    initial_capital: float = Field(alias="initialCapital")
    final_value: float = Field(alias="finalValue")
    total_return: float = Field(alias="totalReturn")
    sharpe_ratio: float | None = Field(default=None, alias="sharpeRatio")
    max_drawdown: float | None = Field(default=None, alias="maxDrawdown")
    trades: list[BacktestTrade] = Field(default_factory=list)

    model_config = {"populate_by_name": True}
