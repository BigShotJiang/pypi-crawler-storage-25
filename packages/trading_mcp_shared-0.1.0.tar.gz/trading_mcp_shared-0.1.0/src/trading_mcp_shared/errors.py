"""Typed exception classes for Trading MCP servers."""


class ProviderError(Exception):
    """Raised when an upstream data provider returns an error or is unreachable."""

    def __init__(self, provider: str, message: str, status_code: int | None = None):
        self.provider = provider
        self.status_code = status_code
        super().__init__(f"[{provider}] {message}")


class RateLimitError(ProviderError):
    """Raised when an upstream provider rate-limits us."""

    def __init__(self, provider: str, retry_after: float | None = None):
        self.retry_after = retry_after
        msg = "Rate limited"
        if retry_after is not None:
            msg += f" (retry after {retry_after}s)"
        super().__init__(provider, msg, status_code=429)


class ValidationError(Exception):
    """Raised when input validation fails before reaching a provider."""

    def __init__(self, field: str, message: str):
        self.field = field
        super().__init__(f"Validation error on '{field}': {message}")


class SandboxError(Exception):
    """Raised when the Docker sandbox for backtesting fails."""

    def __init__(self, message: str, exit_code: int | None = None):
        self.exit_code = exit_code
        super().__init__(f"Sandbox error: {message}")
