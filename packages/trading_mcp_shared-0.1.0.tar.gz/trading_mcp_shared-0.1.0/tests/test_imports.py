"""Smoke tests: verify shared package imports and its public surface exists."""

from __future__ import annotations


def test_types_import():
    from trading_mcp_shared import types

    assert hasattr(types, "__name__")


def test_errors_import():
    from trading_mcp_shared import errors

    assert hasattr(errors, "__name__")


def test_cache_import():
    from trading_mcp_shared import cache

    assert hasattr(cache, "__name__")
