"""knowing: content-addressed graph artifact for software systems."""
