"""Entry point for knowing CLI."""
import os
import sys
import subprocess

def main():
    binary = os.path.join(os.path.dirname(__file__), "bin", "knowing")
    if not os.path.exists(binary):
        print("Error: knowing binary not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run([binary] + sys.argv[1:])
    sys.exit(result.returncode)

if __name__ == "__main__":
    main()
