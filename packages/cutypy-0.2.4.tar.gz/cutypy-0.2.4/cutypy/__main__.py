from cutypy.core.main import cli_entry

def main():
  cli_entry()

if __name__ == "__main__":
  main()

