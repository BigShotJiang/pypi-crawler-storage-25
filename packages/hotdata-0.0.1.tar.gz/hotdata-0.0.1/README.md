# hotdata

Official Python client for the [Hotdata](https://app.hotdata.dev) HTTP API: workspaces, connections, datasets, SQL queries, results, secrets, uploads, indexes, jobs, embedding providers, and workspace context.

The package is produced with [OpenAPI Generator](https://openapi-generator.tech) from the Hotdata OpenAPI spec. 

## Requirements

Python 3.9+

## Install

From the repository:

```sh
pip install "git+https://github.com/hotdata-dev/sdk-python.git"
```

From a local checkout (editable):

```sh
pip install -e .
```

## Tests

```sh
pytest
```

## Authentication

The API uses **Bearer** JWTs and an **`X-Workspace-Id`** header on requests that are scoped to a workspace.

```python
import hotdata

configuration = hotdata.Configuration(
    access_token="YOUR_ACCESS_TOKEN",
    api_key={"WorkspaceId": "YOUR_WORKSPACE_ID"},
)
```

`host` defaults to `https://app.hotdata.dev`. Override it if you target another environment.

## Usage

```python
import hotdata
from hotdata.rest import ApiException

configuration = hotdata.Configuration(
    access_token="YOUR_ACCESS_TOKEN",
    api_key={"WorkspaceId": "YOUR_WORKSPACE_ID"},
)

with hotdata.ApiClient(configuration) as api_client:
    workspaces = hotdata.WorkspacesApi(api_client)
    try:
        response = workspaces.list_workspaces()
    except ApiException as e:
        print(f"API error: {e.status} {e.reason}\n{e.body}")
```

Each `Api` class groups endpoints by resource. Construct the client, then call the typed methods you need.

## API reference

Generated Markdown for every operation and model is in [`docs/`](docs/):

- Resource APIs: `docs/*Api.md` (for example [`docs/QueryApi.md`](docs/QueryApi.md))
- Request and response models: `docs/<ModelName>.md`

Use your editor or GitHub file search there instead of duplicating large tables in this file.

## Support

Questions and issues: [github.com/hotdata-dev/sdk-python](https://github.com/hotdata-dev/sdk-python).
