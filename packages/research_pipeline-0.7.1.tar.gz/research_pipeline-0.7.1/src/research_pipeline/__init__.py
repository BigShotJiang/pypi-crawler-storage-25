"""research-pipeline: multi-source academic paper search and analysis."""

__version__ = "0.7.1"
