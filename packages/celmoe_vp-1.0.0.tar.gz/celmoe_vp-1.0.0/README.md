# celmoe-vp

`celmoe-vp` is a domain-agnostic expert-orchestration library.

It provides:

- generic hierarchical expert configuration
- expert routing and fusion mechanisms
- reusable expert batch/result contracts
- multi-loss APIs for parent, child, and global objectives
- typed package metadata for external consumers

Install:

```bash
pip install celmoe-vp
```
