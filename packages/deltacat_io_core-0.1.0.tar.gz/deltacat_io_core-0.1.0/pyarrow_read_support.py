"""Filesystem-aware PyArrow readers cloned from thick DeltaCAT."""

from __future__ import annotations

import bz2
import csv
import gzip
import tempfile
import shutil
from functools import partial
from typing import Any, Callable, Dict, List, Optional, Union

from fsspec import AbstractFileSystem

from deltacat_io_core.delimited_options import content_type_to_reader_kwargs
from deltacat_io_core.deps import (
    require_fastavro,
    require_lance,
    require_pyarrow,
    require_pyarrow_csv,
    require_pyarrow_feather,
    require_pyarrow_json,
    require_pyarrow_orc,
    require_pyarrow_parquet,
)
from deltacat_io_core.filesystem_support import (
    FilesystemType,
    append_protocol_prefix_by_type,
    resolve_path_and_filesystem,
)
from deltacat_io_core.lance_support import (
    normalize_lance_storage_options,
    storage_options_from_filesystem,
)

PARQUET_TYPES = {"parquet", "application/parquet"}
CSV_TYPES = {"csv", "text/csv"}
TSV_TYPES = {"tsv", "text/tsv"}
PSV_TYPES = {"psv", "text/psv"}
UNESCAPED_TSV_TYPES = {"application/x-amzn-unescaped-tsv"}
FEATHER_TYPES = {"feather", "application/feather"}
JSON_TYPES = {"json", "application/json"}
ORC_TYPES = {"orc", "application/orc"}
AVRO_TYPES = {"avro", "application/avro"}
LANCE_TYPES = {"lance", "application/vnd.lance"}
DELIMITED_TEXT_CONTENT_TYPES = CSV_TYPES | TSV_TYPES | PSV_TYPES | UNESCAPED_TSV_TYPES
TABULAR_CONTENT_TYPES = (
    DELIMITED_TEXT_CONTENT_TYPES
    | PARQUET_TYPES
    | FEATHER_TYPES
    | JSON_TYPES
    | ORC_TYPES
    | AVRO_TYPES
    | LANCE_TYPES
)

ENCODING_TO_FILE_INIT: Dict[str, Callable] = {
    "gzip": partial(gzip.open, mode="rb"),
    "bzip2": partial(bz2.open, mode="rb"),
    "identity": lambda file_obj: file_obj,
}


def _stream_uses_gzip_bytes(
    filesystem: Any,
    path: str,
    fs_open_kwargs: Dict[str, Any],
) -> bool:
    with filesystem.open_input_stream(path, **fs_open_kwargs) as stream:
        return stream.read(2) == b"\x1f\x8b"


def filter_kwargs_for_external_readers(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    return {
        k: v
        for k, v in kwargs.items()
        if k
        not in [
            "inner",
            "catalog",
            "ray_options_provider",
            "distributed_dataset_type",
            "table_version_schema",
            "entry_params",
            "io_config",
            "ray_init_options",
            "column_names",
            "include_columns",
            "file_reader_kwargs_provider",
            "file_path_column",
            "max_parallelism",
            "data_root",
        ]
    }


def _add_column_kwargs(
    content_type: str,
    column_names: Optional[List[str]],
    include_columns: Optional[List[str]],
    kwargs: Dict[str, Any],
):
    if content_type in DELIMITED_TEXT_CONTENT_TYPES:
        pacsv = require_pyarrow_csv("pyarrow read support")
        read_options = kwargs.get("read_options")
        if read_options is None:
            read_options = pacsv.ReadOptions()
        if column_names:
            read_options.column_names = column_names
        kwargs["read_options"] = read_options

        convert_options = kwargs.get("convert_options")
        if convert_options is None:
            convert_options = pacsv.ConvertOptions()
        if include_columns:
            convert_options.include_columns = include_columns
        kwargs["convert_options"] = convert_options
    elif content_type in TABULAR_CONTENT_TYPES:
        kwargs["columns"] = include_columns


def read_csv(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    pacsv = require_pyarrow_csv("pyarrow read support")

    def _expected_header_names() -> Optional[List[str]]:
        read_options = read_kwargs.get("read_options")
        column_names = (
            getattr(read_options, "column_names", None) if read_options else None
        )
        if not column_names:
            return None
        return list(column_names)

    def _delimiter() -> str:
        parse_options = read_kwargs.get("parse_options")
        delimiter = getattr(parse_options, "delimiter", None) if parse_options else None
        return delimiter or ","

    def _matches_existing_header(raw_bytes: bytes) -> bool:
        expected_names = _expected_header_names()
        if not expected_names or not raw_bytes:
            return False
        first_line = raw_bytes.decode("utf-8-sig", errors="replace").splitlines()
        if not first_line:
            return False
        parsed = next(csv.reader([first_line[0]], delimiter=_delimiter()), [])
        return parsed == expected_names

    def _effective_read_kwargs(header_matches: bool) -> Dict[str, Any]:
        if not header_matches:
            return read_kwargs
        candidate_kwargs = dict(read_kwargs)
        candidate_kwargs.pop("read_options", None)
        return candidate_kwargs

    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        use_manual_gzip = path.endswith(".gz") and _stream_uses_gzip_bytes(
            filesystem, path, fs_open_kwargs
        )
        with filesystem.open_input_stream(path, **fs_open_kwargs) as f:
            if path.endswith(".gz") and not use_manual_gzip:
                input_file = f
                header_matches = _matches_existing_header(input_file.read(4096))
            else:
                input_file_init = ENCODING_TO_FILE_INIT.get(
                    content_encoding, lambda x: x
                )
                with input_file_init(f) as input_file:
                    header_matches = _matches_existing_header(input_file.read(4096))
        with filesystem.open_input_stream(path, **fs_open_kwargs) as f:
            if path.endswith(".gz") and not use_manual_gzip:
                return pacsv.read_csv(
                    f,
                    **_effective_read_kwargs(header_matches),
                )
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                return pacsv.read_csv(
                    input_file,
                    **_effective_read_kwargs(header_matches),
                )
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            header_matches = _matches_existing_header(input_file.read(4096))
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            return pacsv.read_csv(
                input_file,
                **_effective_read_kwargs(header_matches),
            )


def read_feather(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    paf = require_pyarrow_feather("pyarrow read support")
    pyarrow_kwargs = filter_kwargs_for_external_readers(read_kwargs)
    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        if FilesystemType.from_filesystem(filesystem) == FilesystemType.LOCAL:
            if content_encoding != "identity":
                with filesystem.open(path, "rb", **fs_open_kwargs) as f:
                    input_file_init = ENCODING_TO_FILE_INIT.get(
                        content_encoding, lambda x: x
                    )
                    with input_file_init(f) as input_file:
                        with tempfile.NamedTemporaryFile() as temp_file:
                            shutil.copyfileobj(input_file, temp_file)
                            temp_file.flush()
                            return paf.read_table(temp_file.name, **pyarrow_kwargs)
            return paf.read_table(path, **pyarrow_kwargs)
        with filesystem.open_input_file(path, **fs_open_kwargs) as f:
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                with tempfile.NamedTemporaryFile() as temp_file:
                    shutil.copyfileobj(input_file, temp_file)
                    temp_file.flush()
                    return paf.read_table(temp_file.name, **pyarrow_kwargs)
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            with tempfile.NamedTemporaryFile() as temp_file:
                shutil.copyfileobj(input_file, temp_file)
                temp_file.flush()
                return paf.read_table(temp_file.name, **pyarrow_kwargs)


def read_json(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    pajson = require_pyarrow_json("pyarrow read support")
    pyarrow_kwargs = filter_kwargs_for_external_readers(read_kwargs)
    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        use_manual_gzip = path.endswith(".gz") and _stream_uses_gzip_bytes(
            filesystem, path, fs_open_kwargs
        )
        with filesystem.open_input_stream(path, **fs_open_kwargs) as f:
            if path.endswith(".gz") and not use_manual_gzip:
                return pajson.read_json(f, **pyarrow_kwargs)
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                return pajson.read_json(input_file, **pyarrow_kwargs)
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            return pajson.read_json(input_file, **pyarrow_kwargs)


def read_orc(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    paorc = require_pyarrow_orc("pyarrow read support")
    pyarrow_kwargs = filter_kwargs_for_external_readers(read_kwargs)
    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        with filesystem.open_input_file(path, **fs_open_kwargs) as f:
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                return paorc.read_table(input_file, **pyarrow_kwargs)
    if content_encoding != "identity":
        with filesystem.open(path, "rb", **fs_open_kwargs) as f:
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                with tempfile.NamedTemporaryFile() as temp_file:
                    shutil.copyfileobj(input_file, temp_file)
                    temp_file.flush()
                    return paorc.read_table(temp_file.name, **pyarrow_kwargs)
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        return paorc.read_table(f, **pyarrow_kwargs)


def read_parquet(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    pq = require_pyarrow_parquet("pyarrow read support")
    pyarrow_kwargs = filter_kwargs_for_external_readers(read_kwargs)
    if "filter" in pyarrow_kwargs and "filters" not in pyarrow_kwargs:
        pyarrow_kwargs["filters"] = pyarrow_kwargs.pop("filter")
    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        with filesystem.open_input_file(path, **fs_open_kwargs) as f:
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                return pq.read_table(input_file, **pyarrow_kwargs)
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            return pq.read_table(input_file, **pyarrow_kwargs)


def read_avro(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    fastavro = require_fastavro("pyarrow read support")
    pa = require_pyarrow("pyarrow read support")
    if not filesystem or hasattr(filesystem, "open_input_file"):
        path, filesystem = resolve_path_and_filesystem(path, filesystem)
        with filesystem.open_input_stream(path, **fs_open_kwargs) as f:
            input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
            with input_file_init(f) as input_file:
                return pa.Table.from_pylist(list(fastavro.reader(input_file)))
    with filesystem.open(path, "rb", **fs_open_kwargs) as f:
        input_file_init = ENCODING_TO_FILE_INIT.get(content_encoding, lambda x: x)
        with input_file_init(f) as input_file:
            return pa.Table.from_pylist(list(fastavro.reader(input_file)))


def read_lance(
    path: str,
    *,
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    fs_open_kwargs: Dict[str, Any] = {},
    content_encoding: str = "identity",
    **read_kwargs,
):
    del fs_open_kwargs, content_encoding
    lance = require_lance("pyarrow read support")
    pa_filesystem = filesystem if hasattr(filesystem, "open_input_file") else None
    if pa_filesystem is not None:
        fs_type = FilesystemType.from_filesystem(pa_filesystem)
        if fs_type not in (FilesystemType.LOCAL, FilesystemType.UNKNOWN):
            path = append_protocol_prefix_by_type(path, fs_type)
    storage_options = normalize_lance_storage_options(
        storage_options_from_filesystem(pa_filesystem)
    )
    dataset = (
        lance.dataset(path, storage_options=storage_options)
        if storage_options
        else lance.dataset(path)
    )
    include_columns = read_kwargs.get("columns")
    row_filter = read_kwargs.get("filter")
    return dataset.to_table(columns=include_columns, filter=row_filter)


CONTENT_TYPE_TO_READ_FN: Dict[str, Callable] = {
    **{content_type: read_csv for content_type in DELIMITED_TEXT_CONTENT_TYPES},
    **{content_type: read_parquet for content_type in PARQUET_TYPES},
    **{content_type: read_feather for content_type in FEATHER_TYPES},
    **{content_type: read_json for content_type in JSON_TYPES},
    **{content_type: read_orc for content_type in ORC_TYPES},
    **{content_type: read_avro for content_type in AVRO_TYPES},
    **{content_type: read_lance for content_type in LANCE_TYPES},
}


def file_to_table(
    path: str,
    content_type: str,
    content_encoding: str = "identity",
    filesystem: Optional[Union[AbstractFileSystem, Any]] = None,
    column_names: Optional[List[str]] = None,
    include_columns: Optional[List[str]] = None,
    **kwargs,
):
    pa_read_func = CONTENT_TYPE_TO_READ_FN.get(content_type)
    if not pa_read_func:
        raise NotImplementedError(
            f"PyArrow reader for content type '{content_type}' not implemented. "
            f"Known content types: {sorted(CONTENT_TYPE_TO_READ_FN)}"
        )

    reader_kwargs = content_type_to_reader_kwargs(content_type)
    _add_column_kwargs(content_type, column_names, include_columns, reader_kwargs)
    reader_kwargs.update(kwargs)
    reader_kwargs = {
        key: value for key, value in reader_kwargs.items() if value is not None
    }

    return pa_read_func(
        path,
        filesystem=filesystem,
        content_encoding=content_encoding,
        **reader_kwargs,
    )
