"""Shared helpers for hash/range bucket task execution."""

from __future__ import annotations

from typing import Any

import numpy as np


def execute_bucket_grouping(
    *,
    input: Any,
    load_delta_file_envelope_groups_fn,
    group_hash_bucket_indices_fn,
    current_process_peak_memory_fn,
    hash_bucket_result_factory,
    wall_time_fn,
    log_info_fn,
    peak_memory_log_message: str,
) -> Any:
    """Execute the common bucket-task core shared by hash and range bucketing."""
    (
        delta_file_envelope_groups,
        total_record_count,
        total_size_bytes,
    ) = load_delta_file_envelope_groups_fn()
    hash_bucket_group_to_obj_id_tuple = group_hash_bucket_indices_fn(
        hash_bucket_object_groups=delta_file_envelope_groups,
        num_buckets=input.num_hash_buckets,
        num_groups=input.num_hash_groups,
        object_store=input.object_store,
    )

    peak_memory_usage_bytes = current_process_peak_memory_fn()
    log_info_fn(
        peak_memory_log_message.format(peak_memory_usage_bytes=peak_memory_usage_bytes)
    )
    return hash_bucket_result_factory(
        hash_bucket_group_to_obj_id_tuple,
        np.int64(total_size_bytes),
        np.int64(total_record_count),
        np.double(peak_memory_usage_bytes),
        np.double(0.0),
        np.double(wall_time_fn()),
    )


def execute_bucket_task(
    *,
    input: Any,
    task_fn,
    task_fn_kwargs: dict[str, Any],
    process_utilization_context_factory,
    timed_invocation_fn,
    emit_timer_metrics_fn,
    metrics_name: str,
    hash_bucket_result_factory,
    bytes_per_gibibyte: float,
    log_info_fn,
    log_debug_fn,
    started_message: str,
    finished_message: str,
) -> Any:
    """Execute the common outer wrapper shared by hash/range bucket tasks."""
    with process_utilization_context_factory() as process_util:
        log_info_fn(started_message)

        def log_peak_memory():
            log_debug_fn(
                "Process peak memory utilization so far: %s bytes (%s GB)",
                process_util.max_memory,
                process_util.max_memory / bytes_per_gibibyte,
            )

        if input.memory_logs_enabled:
            process_util.schedule_callback(log_peak_memory, 10)

        bucket_result, duration = timed_invocation_fn(
            func=task_fn,
            **task_fn_kwargs,
        )

        emit_metrics_time = 0.0
        if input.metrics_config:
            _, latency = timed_invocation_fn(
                func=emit_timer_metrics_fn,
                metrics_name=metrics_name,
                value=duration,
                metrics_config=input.metrics_config,
            )
            emit_metrics_time = latency

        log_info_fn(finished_message)
        return hash_bucket_result_factory(
            bucket_result[0],
            bucket_result[1],
            bucket_result[2],
            bucket_result[3],
            np.double(emit_metrics_time),
            bucket_result[5],
        )
