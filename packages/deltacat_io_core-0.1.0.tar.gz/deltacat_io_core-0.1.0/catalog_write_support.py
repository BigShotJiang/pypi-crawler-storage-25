"""Shared catalog write orchestration moved out of thick catalog/main/impl.py."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Iterable, Optional, Sequence


@dataclass(frozen=True)
class PreparedCatalogWriteContext:
    table_exists_flag: bool
    table_definition: Any
    table_version_obj: Any
    stream: Any
    delta_type: Any
    manifest: Optional[Any]
    schema_evolution_mode: Optional[Any]
    default_schema_consistency_type: Optional[Any]


@dataclass(frozen=True)
class PreparedCatalogWriteInput:
    data: Any
    manifest: Optional[Any]
    auto_manifest_items: Optional[Sequence[Any]]


def with_manifest_schema_and_sort_metadata(
    input_manifest: Optional[Any],
    *,
    schema_id: Optional[int],
    sort_scheme_id: Optional[str],
    rebuild_entry_fn: Callable[[Any, Any], Any],
    rebuild_manifest_fn: Callable[[Any, Sequence[Any], Optional[Any]], Any],
) -> Optional[Any]:
    """Apply missing schema/sort metadata to a manifest without changing payloads.

    This keeps manifest-only writes aligned with the resolved table version
    before the manifest is staged as a delta. Existing entry-level schema ids
    are preserved, while missing ones inherit the resolved table schema.
    """
    if input_manifest is None or (schema_id is None and sort_scheme_id is None):
        return input_manifest
    if not input_manifest.entries:
        return input_manifest

    updated_entries = []
    changed = False
    for entry in input_manifest.entries:
        meta = entry.meta
        if meta is None:
            updated_entries.append(entry)
            continue
        current_sort_scheme_id = meta.sort_scheme_id
        current_schema_id = meta.schema_id
        target_schema_id = (
            current_schema_id if current_schema_id is not None else schema_id
        )
        target_sort_scheme_id = sort_scheme_id
        if (
            current_sort_scheme_id == target_sort_scheme_id
            and current_schema_id == target_schema_id
        ):
            updated_entries.append(entry)
            continue
        updated_meta = type(meta).of(
            record_count=meta.record_count,
            content_length=meta.content_length,
            content_type=meta.content_type,
            content_encoding=meta.content_encoding,
            source_content_length=meta.source_content_length,
            credentials=meta.credentials,
            content_type_parameters=meta.content_type_parameters,
            entry_type=meta.entry_type,
            entry_params=meta.entry_params,
            schema_id=target_schema_id,
            sort_scheme_id=target_sort_scheme_id,
            ttl_expires_at=meta.ttl_expires_at,
            ttl_source_path=meta.ttl_source_path,
        )
        if meta.column_stats is not None:
            updated_meta["column_stats"] = meta.column_stats
        updated_entries.append(rebuild_entry_fn(entry, updated_meta))
        changed = True

    if not changed:
        return input_manifest

    manifest_meta = input_manifest.meta
    updated_manifest_meta = None
    if manifest_meta is not None:
        manifest_schema_id = manifest_meta.schema_id
        target_manifest_schema_id = (
            manifest_schema_id if manifest_schema_id is not None else schema_id
        )
        updated_manifest_meta = type(manifest_meta).of(
            record_count=manifest_meta.record_count,
            content_length=manifest_meta.content_length,
            content_type=manifest_meta.content_type,
            content_encoding=manifest_meta.content_encoding,
            source_content_length=manifest_meta.source_content_length,
            credentials=manifest_meta.credentials,
            content_type_parameters=manifest_meta.content_type_parameters,
            entry_type=manifest_meta.entry_type,
            entry_params=manifest_meta.entry_params,
            schema_id=target_manifest_schema_id,
            sort_scheme_id=sort_scheme_id,
            ttl_expires_at=manifest_meta.ttl_expires_at,
            ttl_source_path=manifest_meta.ttl_source_path,
        )

    return rebuild_manifest_fn(input_manifest, updated_entries, updated_manifest_meta)


def resolve_table_version_schema_with_id(table_version_obj: Any) -> Optional[Any]:
    """Return the canonical current schema for a table version, preferring one with an id.

    Some table-version objects expose ``schema`` as a convenience view whose
    ``id`` is unset even though the authoritative schema history is present in
    ``schemas``. For persisted manifest metadata we want the canonical schema
    object that carries the storage schema id whenever possible.
    """
    schema = getattr(table_version_obj, "schema", None) if table_version_obj else None
    if schema is None:
        return None
    if getattr(schema, "id", None) is not None:
        return schema

    all_schemas = list(getattr(table_version_obj, "schemas", None) or [])
    if not all_schemas:
        return schema

    for candidate in all_schemas:
        if getattr(candidate, "id", None) is None:
            continue
        equivalent_to = getattr(candidate, "equivalent_to", None)
        if callable(equivalent_to):
            try:
                if equivalent_to(schema, True):
                    return candidate
            except TypeError:
                if equivalent_to(schema):
                    return candidate
        candidate_arrow = getattr(candidate, "arrow", None)
        schema_arrow = getattr(schema, "arrow", None)
        if candidate_arrow is not None and schema_arrow is not None:
            try:
                if candidate_arrow.equals(schema_arrow, check_metadata=False):
                    return candidate
            except TypeError:
                if candidate_arrow.equals(schema_arrow):
                    return candidate

    candidates_with_ids = [
        candidate
        for candidate in all_schemas
        if getattr(candidate, "id", None) is not None
    ]
    if len(candidates_with_ids) == 1:
        return candidates_with_ids[0]

    return schema


def apply_manifest_entry_defaults(
    items: Sequence[Any],
    *,
    default_entry_type: Optional[Any],
    default_entry_params: Optional[Any],
) -> list[Any]:
    """Apply default entry metadata to path/entry inputs."""
    normalized_entries: list[Any] = []
    for item in items:
        if not isinstance(item, dict):
            if default_entry_type is None and default_entry_params is None:
                normalized_entries.append(item)
                continue
            entry = {"path": item}
        else:
            entry = dict(item)
        if default_entry_type is not None and entry.get("entry_type") is None:
            entry["entry_type"] = default_entry_type
        if default_entry_params is not None and entry.get("entry_params") is None:
            entry["entry_params"] = default_entry_params
        normalized_entries.append(entry)
    return normalized_entries


def prepare_catalog_write_input(
    *,
    data: Any,
    manifest: Optional[Any],
    content_type: Any,
    catalog_root: Optional[str],
    catalog_properties: Any,
    data_root_name: Optional[str],
    default_entry_type: Optional[Any],
    default_entry_params: Optional[Any],
    coerce_write_input_fn: Callable[[Any], tuple[Any, Optional[Sequence[Any]]]],
    build_client_manifest_fn: Callable[..., Any],
) -> PreparedCatalogWriteInput:
    """Prepare the write input before opening the catalog transaction.

    This is the shared pre-transaction input normalization for thick catalog
    writes. It preserves the native behavior of:
    - detecting explicit manifest-entry dict inputs
    - coercing in-memory write inputs into a supported table representation
    - building a manifest for local prewritten paths/dataset roots
    - leaving in-memory table writes on the normal data-bearing path
    """
    if manifest is not None:
        return PreparedCatalogWriteInput(
            data=data,
            manifest=manifest,
            auto_manifest_items=None,
        )

    explicit_manifest_items = None
    if isinstance(data, dict) and data.get("path") is not None:
        explicit_manifest_items = [data]
    elif (
        isinstance(data, Sequence)
        and not isinstance(data, (str, bytes))
        and data
        and all(
            isinstance(item, dict) and item.get("path") is not None for item in data
        )
    ):
        explicit_manifest_items = list(data)

    coerced_table, path_items = (
        (None, None)
        if explicit_manifest_items is not None
        else coerce_write_input_fn(data)
    )
    if explicit_manifest_items is not None or path_items is not None:
        auto_manifest_items = explicit_manifest_items or path_items
        normalized_manifest_items = apply_manifest_entry_defaults(
            auto_manifest_items,
            default_entry_type=default_entry_type,
            default_entry_params=default_entry_params,
        )
        return PreparedCatalogWriteInput(
            data=None,
            manifest=build_client_manifest_fn(
                normalized_manifest_items,
                content_type=content_type,
                catalog_root=catalog_root,
                catalog_properties=catalog_properties,
                data_root_name=data_root_name,
            ),
            auto_manifest_items=normalized_manifest_items,
        )
    if coerced_table is not None:
        return PreparedCatalogWriteInput(
            data=coerced_table,
            manifest=None,
            auto_manifest_items=None,
        )
    return PreparedCatalogWriteInput(
        data=data,
        manifest=None,
        auto_manifest_items=None,
    )


def prepare_catalog_write_context(
    *,
    data: Any,
    table: str,
    namespace: str,
    table_version: Optional[str],
    mode: Any,
    content_type: Any,
    manifest: Optional[Any],
    auto_manifest_items: Optional[Sequence[Any]],
    kwargs: Dict[str, Any],
    schema_content_types: Sequence[str],
    schemaless_content_types: Sequence[str],
    unsorted_scheme_id: Any,
    content_type_validation_error_cls: type[Exception],
    get_table_and_validate_write_mode_fn: Callable[..., Any],
    create_table_for_write_fn: Callable[..., Any],
    alter_table_fn: Callable[..., Any],
    get_latest_active_or_given_table_version_fn: Callable[..., Any],
    handle_write_mode_fn: Callable[..., Any],
    set_entry_params_if_needed_fn: Callable[..., Any],
    validate_table_configuration_fn: Callable[..., Any],
    build_client_manifest_fn: Callable[..., Any],
    read_schema_evolution_mode_fn: Callable[[Any], Any],
    read_default_schema_consistency_type_fn: Callable[[Any], Any],
) -> PreparedCatalogWriteContext:
    """Prepare the shared catalog-write context before executing the write.

    This is the shared outer orchestration for thick catalog writes after the
    transaction is established and after any thin-client manifest autodetection
    has occurred. It preserves the native behavior of:
    - validating write mode against table/table-version existence
    - creating the table when needed
    - applying pending alter_table kwargs
    - resolving the active table version
    - validating schemaless vs schema-table compatibility
    - resolving the target stream and delta type
    - auto-populating entry_params for MERGE/DELETE
    - rebuilding auto-discovered manifests with the resolved table sort metadata
    - surfacing schema-evolution consistency properties for the next stage
    """
    table_exists_flag, table_definition = get_table_and_validate_write_mode_fn(
        table,
        namespace,
        table_version,
        mode,
        **kwargs,
    )

    if not table_exists_flag:
        if manifest is not None:
            kwargs["manifest"] = manifest
        table_definition = create_table_for_write_fn(
            data,
            table,
            namespace,
            table_version,
            content_type,
            table_definition,
            **kwargs,
        )
    else:
        if any(
            key in kwargs
            for key in (
                "lifecycle_state",
                "schema_updates",
                "partition_updates",
                "sort_scheme",
                "table_description",
                "table_version_description",
                "table_properties",
                "table_version_properties",
            )
        ):
            alter_table_fn(
                table,
                namespace=namespace,
                table_version=table_version,
                **kwargs,
            )

    if table_exists_flag and table_definition.table_version:
        table_version_obj = table_definition.table_version
    else:
        table_version_obj = get_latest_active_or_given_table_version_fn(
            namespace=table_definition.table.namespace,
            table_name=table_definition.table.table_name,
            table_version=table_version or table_definition.table_version.table_version,
            **kwargs,
        )

    if (
        getattr(content_type, "value", content_type) not in schema_content_types
        and table_version_obj.schema is not None
    ):
        raise content_type_validation_error_cls(
            f"Content type '{getattr(content_type, 'value', content_type)}' cannot be written to a table with a schema. "
            f"Table '{namespace}.{table}' has a schema, but content type '{getattr(content_type, 'value', content_type)}' "
            f"is schemaless. Schemaless content types ({', '.join(sorted(schemaless_content_types))}) "
            f"can only be written to schemaless tables."
        )

    stream, delta_type = handle_write_mode_fn(
        mode,
        table_definition,
        table_version_obj,
        namespace,
        table,
        table_exists_flag,
        stream=table_definition.stream if table_exists_flag else None,
        **kwargs,
    )
    if not stream:
        raise ValueError(f"No default stream found for table {namespace}.{table}")

    set_entry_params_if_needed_fn(mode, table_version_obj, kwargs)

    if manifest is not None and auto_manifest_items is not None:
        sort_scheme = table_version_obj.sort_scheme
        rebuilt_sort_scheme_id = sort_scheme.id if sort_scheme else unsorted_scheme_id
        rebuilt_sort_column = None
        if sort_scheme and sort_scheme.keys:
            first_key = sort_scheme.keys[0]
            if first_key.key:
                rebuilt_sort_column = first_key.key[0]

        normalized_manifest_items = apply_manifest_entry_defaults(
            auto_manifest_items,
            default_entry_type=kwargs.get("entry_type"),
            default_entry_params=kwargs.get("entry_params"),
        )
        manifest = build_client_manifest_fn(
            normalized_manifest_items,
            content_type=content_type,
            catalog_root=getattr(kwargs.get("inner"), "root", None),
            catalog_properties=kwargs.get("inner"),
            data_root_name=kwargs.get("data_root_name"),
            sort_scheme_id=rebuilt_sort_scheme_id,
            sort_column=rebuilt_sort_column,
        )

    validate_table_configuration_fn(
        stream,
        table_version_obj,
        namespace,
        table,
    )

    return PreparedCatalogWriteContext(
        table_exists_flag=table_exists_flag,
        table_definition=table_definition,
        table_version_obj=table_version_obj,
        stream=stream,
        delta_type=delta_type,
        manifest=manifest,
        schema_evolution_mode=read_schema_evolution_mode_fn(table_version_obj),
        default_schema_consistency_type=read_default_schema_consistency_type_fn(
            table_version_obj
        ),
    )


def execute_manifest_only_catalog_write(
    manifest: Any,
    *,
    mode: Any,
    table_exists_flag: bool,
    delta_type: Any,
    stream: Any,
    content_type: Any,
    table_version_obj: Any,
    updated_table_version_obj: Optional[Any],
    namespace: str,
    table: str,
    filtered_kwargs: Dict[str, Any],
    write_sort_scheme_id: Optional[str],
    read_optimization_level: Any,
    handle_partition_creation_fn: Callable[..., Any],
    stage_commit_and_compact_fn: Callable[..., Any],
) -> Any:
    """Execute the manifest-only catalog write path.

    This is the shared thin-client registration fast path: data files already
    exist, so the catalog write only needs to create/find the partition and
    stage/commit the manifest-backed delta.
    """
    group_partition, group_commit = handle_partition_creation_fn(
        mode,
        table_exists_flag,
        delta_type,
        stream,
        partition_values=None,
        read_optimization_level=read_optimization_level,
        **filtered_kwargs,
    )

    return stage_commit_and_compact_fn(
        None,
        group_partition,
        delta_type,
        content_type,
        group_commit,
        table_version_obj,
        updated_table_version_obj,
        namespace,
        table,
        original_fields=set(),
        manifest=manifest,
        sort_scheme_id=write_sort_scheme_id,
        sort_column=None,
        **filtered_kwargs,
    )


@dataclass(frozen=True)
class PreparedDataCatalogWrite:
    converted_data: Any
    original_fields: set[str]
    resolved_table_version: Any
    filtered_kwargs: Dict[str, Any]
    partition_groups: Any
    write_sort_scheme_id: Optional[str]
    effective_sort: Optional[Any]
    write_sort_column: Optional[str]


def convert_numpy_for_schema_validation(
    data: Any,
    schema: Optional[Any],
    *,
    schema_type: type,
    to_pandas_fn: Callable[..., Any],
    error_cls: type[Exception] = ValueError,
) -> Any:
    """Convert NumPy input to a named-column table for schema validation."""
    if not isinstance(schema, schema_type) or not schema.arrow:
        raise error_cls(
            f"Expected DeltaCAT schema for Numpy schema validation, but found: {schema}"
        )

    import pyarrow as pa

    arrow_schema = schema.arrow
    num_cols = data.shape[1] if data.ndim > 1 else 1
    if len(arrow_schema) >= num_cols:
        subset_fields = [arrow_schema.field(i) for i in range(num_cols)]
        subset_schema = pa.schema(subset_fields)
        return to_pandas_fn(data, schema=subset_schema)

    raise error_cls(
        f"NumPy array has {num_cols} columns but table schema only has {len(arrow_schema)} columns. "
        f"Cannot write NumPy data with more columns than the table schema supports."
    )


def convert_data_if_needed(
    data: Any,
    *,
    daft_dataframe_type: type,
    get_runner_name_fn: Callable[[], str],
) -> Any:
    """Convert unsupported input tables to a supported execution representation."""
    if isinstance(data, daft_dataframe_type):
        runner_name = get_runner_name_fn()
        if runner_name == "ray":
            return data.to_ray_dataset()
        return data.to_arrow()
    return data


def validate_and_coerce_data_against_schema(
    data: Any,
    schema: Optional[Any],
    *,
    schema_evolution_mode: Optional[Any] = None,
    default_schema_consistency_type: Optional[Any] = None,
) -> tuple[Any, bool, Optional[Any]]:
    """Validate/coerce a dataset against schema and surface schema changes."""
    if not schema:
        return data, False, None

    validated_data, updated_schema = schema.validate_and_coerce_dataset(
        data,
        schema_evolution_mode=schema_evolution_mode,
        default_schema_consistency_type=default_schema_consistency_type,
    )
    schema_modified = not updated_schema.equivalent_to(schema, True)
    updated_schema = updated_schema if schema_modified else None
    return validated_data, schema_modified, updated_schema


def validate_reader_compatibility(
    data: Any,
    content_type: Any,
    supported_reader_types: Optional[Sequence[Any]],
    *,
    get_table_schema_fn: Callable[[Any], Any],
    get_dataset_type_fn: Callable[[Any], Any],
    get_base_arrow_type_name_fn: Callable[[Any], str],
    get_compatible_readers_fn: Callable[[str, str, str], Sequence[Any]],
    parquet_content_type: Any,
    pyarrow_parquet_dataset_type: Any,
    pyarrow_dataset_type: Any,
    table_validation_error_cls: type[Exception],
) -> None:
    """Validate that written data remains readable by required reader types."""
    if not supported_reader_types:
        return

    schema = get_table_schema_fn(data)
    writer_dataset_type = get_dataset_type_fn(data)
    writer_type_str = (
        writer_dataset_type.value
        if writer_dataset_type != pyarrow_parquet_dataset_type
        else "pyarrow"
    )
    content_type_str = content_type.value
    incompatible_fields = []

    for field in schema:
        field_name = field.name
        arrow_type_str = str(field.type)
        base_type_name = get_base_arrow_type_name_fn(field.type)
        compatible_readers = get_compatible_readers_fn(
            base_type_name,
            writer_type_str,
            content_type_str,
        )

        for required_reader in supported_reader_types:
            reader_is_compatible = required_reader in compatible_readers
            if (
                not reader_is_compatible
                and content_type == parquet_content_type
                and required_reader == pyarrow_parquet_dataset_type
            ):
                reader_is_compatible = pyarrow_dataset_type in compatible_readers

            if not reader_is_compatible:
                incompatible_fields.append(
                    {
                        "field_name": field_name,
                        "arrow_type": arrow_type_str,
                        "incompatible_reader": required_reader,
                        "writer_type": writer_dataset_type,
                        "content_type": content_type,
                    }
                )

    if incompatible_fields:
        error_details = []
        for incompatible in incompatible_fields:
            writer_type = incompatible["writer_type"]
            if hasattr(writer_type, "value"):
                writer_type = writer_type.value
            content_type = incompatible["content_type"]
            if hasattr(content_type, "value"):
                content_type = content_type.value
            incompatible_reader = incompatible["incompatible_reader"]
            if hasattr(incompatible_reader, "value"):
                incompatible_reader = incompatible_reader.value
            error_details.append(
                f"Field '{incompatible['field_name']}' with type '{incompatible['arrow_type']}' "
                f"written by {writer_type} to {content_type} "
                f"cannot be read by required reader type {incompatible_reader}. "
                f"If you expect this write to succeed and this reader is not required, then it "
                f"can be removed from the table's supported reader types property."
            )
        raise table_validation_error_cls(
            "Reader compatibility validation failed. The following fields would break "
            f"supported reader types:\n" + "\n".join(error_details)
        )


def handle_partition_creation(
    mode: Any,
    table_exists_flag: bool,
    delta_type: Any,
    stream: Any,
    *,
    partition_values: Optional[Any] = None,
    read_optimization_level: Optional[Any] = None,
    stage_partition_fn: Callable[..., Any],
    get_partition_fn: Callable[..., Any],
    replace_mode: Any,
    replace_partition_mode: Any,
    upsert_delta_type: Any,
    delete_delta_type: Any,
    max_read_optimization_level: Any,
    table_validation_error_cls: type[Exception],
    **kwargs,
) -> tuple[Any, bool]:
    """Create or resolve the target partition for a write group."""
    scheme_id = stream.partition_scheme.id if stream.partition_scheme else None

    if mode == replace_mode or not table_exists_flag:
        partition = stage_partition_fn(
            stream=stream,
            partition_values=partition_values,
            **kwargs,
        )
        if delta_type in (upsert_delta_type, delete_delta_type):
            commit_staged_partition = (
                read_optimization_level != max_read_optimization_level
            )
        else:
            commit_staged_partition = True
        return partition, commit_staged_partition

    if mode == replace_partition_mode:
        if not stream.partition_scheme or not partition_values:
            raise table_validation_error_cls(
                "REPLACE_PARTITION is only supported on partitioned tables. "
                "Unpartitioned tables use a fixed internal partition ID that "
                "cannot be replaced individually. Use TableWriteMode.REPLACE "
                "to replace the entire table instead."
            )
        partition = stage_partition_fn(
            stream=stream,
            partition_values=partition_values,
            **kwargs,
        )
        return partition, True

    if delta_type in (upsert_delta_type, delete_delta_type):
        partition = get_partition_fn(
            stream_locator=stream.locator,
            partition_values=partition_values,
            partition_scheme_id=scheme_id,
            **kwargs,
        )
        commit_staged_partition = False
        if not partition:
            partition = stage_partition_fn(
                stream=stream,
                partition_values=partition_values,
                **kwargs,
            )
            commit_staged_partition = (
                read_optimization_level != max_read_optimization_level
            )
        return partition, commit_staged_partition

    partition = get_partition_fn(
        stream_locator=stream.locator,
        partition_values=partition_values,
        partition_scheme_id=scheme_id,
        **kwargs,
    )
    commit_staged_partition = False
    if not partition:
        partition = stage_partition_fn(
            stream=stream,
            partition_values=partition_values,
            **kwargs,
        )
        commit_staged_partition = True
    return partition, commit_staged_partition


def sort_data(
    data: Any,
    sort_scheme: Any,
    *,
    get_sort_fn: Callable[[Any], Optional[Callable[[Any, Any], Any]]],
    table_validation_error_cls: type[Exception],
) -> Any:
    """Sort data by the given sort scheme using the native table sort dispatch."""
    sort_fn = get_sort_fn(data)
    if sort_fn:
        return sort_fn(data, sort_scheme)
    raise table_validation_error_cls(
        f"Cannot sort dataset of type '{type(data).__name__}' by sort scheme "
        f"'{sort_scheme.name or sort_scheme.id}'. Sorting is supported for "
        f"PyArrow Tables, Pandas DataFrames, Polars DataFrames, and Ray "
        f"Datasets (single sort key only). For distributed multi-key sorts, "
        f"use Daft with a Daft-native write path."
    )


def validate_packds_write_invariants(
    table_version_obj: Any,
    delta: Any,
    namespace: str,
    table: str,
    *,
    is_packds_backed_fn: Callable[[Sequence[Any], Any], bool],
    require_packds_uri_fn: Callable[[Any], Any],
) -> None:
    """Reject PackDS writes that do not persist ``packds_uri`` in table properties."""
    props = (
        table_version_obj.properties
        if table_version_obj and hasattr(table_version_obj, "properties")
        else None
    ) or {}
    if is_packds_backed_fn([delta], props):
        require_packds_uri_fn(props, table_ref=f"{namespace}.{table}")


def prepare_data_catalog_write(
    *,
    data: Any,
    stream: Any,
    table_version_obj: Any,
    namespace: str,
    table: str,
    content_type: Any,
    kwargs: Dict[str, Any],
    schema_evolution_mode: Optional[Any],
    default_schema_consistency_type: Optional[Any],
    supported_reader_types_property: Any,
    unsorted_scheme_id: Any,
    convert_numpy_for_schema_validation_fn: Callable[[Any, Any], Any],
    convert_data_if_needed_fn: Callable[[Any], Any],
    get_table_column_names_fn: Callable[[Any], Sequence[str]],
    validate_and_coerce_data_against_schema_fn: Callable[
        ..., tuple[Any, bool, Optional[Any]]
    ],
    validate_reader_compatibility_fn: Callable[[Any, Any, Optional[Any]], None],
    update_table_version_fn: Callable[[Any], Any],
    compute_partition_groups_fn: Callable[..., Any],
    get_merge_key_field_names_fn: Callable[[Any], Sequence[str]],
    build_effective_sort_fn: Callable[[Any, Sequence[str]], Any],
    get_dataset_type_fn: Callable[[Any], Any],
    ray_dataset_type: Any,
) -> PreparedDataCatalogWrite:
    """Prepare the standard data-bearing catalog write inputs.

    This is the shared prelude for thick catalog writes after table/stream mode
    resolution and before the per-partition stage/commit loop. It preserves the
    native behavior of:
    - special NumPy conversion when schema validation needs named columns
    - schema validation/coercion and schema evolution detection
    - optional table-version update when schema evolution modified the schema
    - reader-compatibility validation
    - partition-group computation
    - partition-local effective sort preparation
    """
    if hasattr(data, "ndim") and table_version_obj.schema is not None:
        converted_data = convert_numpy_for_schema_validation_fn(
            data, table_version_obj.schema
        )
    else:
        converted_data = convert_data_if_needed_fn(data)

    original_fields = set(get_table_column_names_fn(converted_data))

    (
        validated_data,
        schema_modified,
        updated_schema,
    ) = validate_and_coerce_data_against_schema_fn(
        converted_data,
        table_version_obj.schema,
        schema_evolution_mode=schema_evolution_mode,
        default_schema_consistency_type=default_schema_consistency_type,
    )

    converted_data = convert_data_if_needed_fn(validated_data)
    validate_reader_compatibility_fn(
        converted_data,
        content_type,
        supported_reader_types_property,
    )

    resolved_table_version = (
        update_table_version_fn(updated_schema)
        if schema_modified
        else table_version_obj
    )

    partition_groups = compute_partition_groups_fn(
        converted_data,
        stream.partition_scheme if stream else None,
        schema=table_version_obj.schema,
    )

    filtered_kwargs = {key: value for key, value in kwargs.items() if key != "schema"}

    (
        write_sort_scheme_id,
        effective_sort,
        write_sort_column,
    ) = prepare_partitioned_write_sort(
        resolved_table_version=resolved_table_version,
        unsorted_scheme_id=unsorted_scheme_id,
        get_merge_key_field_names_fn=get_merge_key_field_names_fn,
        build_effective_sort_fn=build_effective_sort_fn,
    )

    if (
        effective_sort
        and getattr(effective_sort, "keys", None)
        and get_dataset_type_fn(converted_data) == ray_dataset_type
    ):
        sort_keys = list(effective_sort.keys or [])
        if len(sort_keys) > 1 or any(len(key.key or []) > 1 for key in sort_keys):
            raise ValueError(
                "Ray Dataset sorting only supports a single sort key. "
                f"Got {len(sort_keys)} key(s) with fields "
                f"{[key.key for key in sort_keys]}. For multi-key distributed "
                "sorts, use Daft with a Daft-native write path."
            )

    return PreparedDataCatalogWrite(
        converted_data=converted_data,
        original_fields=original_fields,
        resolved_table_version=resolved_table_version,
        filtered_kwargs=filtered_kwargs,
        partition_groups=partition_groups,
        write_sort_scheme_id=write_sort_scheme_id,
        effective_sort=effective_sort,
        write_sort_column=write_sort_column,
    )


def prepare_partitioned_write_sort(
    *,
    resolved_table_version: Any,
    unsorted_scheme_id: Any,
    get_merge_key_field_names_fn: Callable[[Any], Sequence[str]],
    build_effective_sort_fn: Callable[[Any, Sequence[str]], Any],
) -> tuple[str, Optional[Any], Optional[str]]:
    """Prepare partition-local sort metadata for standard data-bearing writes."""
    sort_scheme = resolved_table_version.sort_scheme
    write_sort_scheme_id = sort_scheme.id if sort_scheme else unsorted_scheme_id

    effective_sort = None
    write_sort_column = None
    if sort_scheme and sort_scheme.keys:
        merge_key_names = get_merge_key_field_names_fn(resolved_table_version.schema)
        effective_sort = build_effective_sort_fn(sort_scheme, merge_key_names)
        first_key = effective_sort.keys[0]
        if first_key.key:
            write_sort_column = first_key.key[0]

    return write_sort_scheme_id, effective_sort, write_sort_column


def execute_partition_group_writes(
    *,
    partition_groups: Iterable[tuple[Any, Any]],
    effective_sort: Optional[Any],
    mode: Any,
    table_exists_flag: bool,
    delta_type: Any,
    stream: Any,
    content_type: Any,
    table_version_obj: Any,
    resolved_table_version: Any,
    namespace: str,
    table: str,
    original_fields: set[str],
    filtered_kwargs: Dict[str, Any],
    write_sort_scheme_id: Optional[str],
    write_sort_column: Optional[str],
    read_optimization_level: Any,
    sort_data_fn: Callable[[Any, Any], Any],
    handle_partition_creation_fn: Callable[..., Any],
    stage_commit_and_compact_fn: Callable[..., Any],
) -> list[Any]:
    """Execute the standard partition-group catalog write loop."""
    all_deltas = []
    for partition_values, data_subset in partition_groups:
        if effective_sort and effective_sort.keys:
            data_subset = sort_data_fn(data_subset, effective_sort)

        group_partition, group_commit = handle_partition_creation_fn(
            mode,
            table_exists_flag,
            delta_type,
            stream,
            partition_values=partition_values,
            read_optimization_level=read_optimization_level,
            **filtered_kwargs,
        )

        deltas = stage_commit_and_compact_fn(
            data_subset,
            group_partition,
            delta_type,
            content_type,
            group_commit,
            table_version_obj,
            resolved_table_version
            if resolved_table_version is not table_version_obj
            else None,
            namespace,
            table,
            original_fields=original_fields,
            manifest=None,
            sort_scheme_id=write_sort_scheme_id,
            sort_column=write_sort_column,
            **filtered_kwargs,
        )
        all_deltas.extend(deltas)

    return all_deltas


def stage_commit_and_compact(
    converted_data: Any,
    partition: Any,
    delta_type: Any,
    content_type: Any,
    commit_staged_partition: bool,
    original_table_version_obj: Any,
    updated_table_version_obj: Optional[Any],
    namespace: str,
    table: str,
    original_fields: set[str],
    *,
    manifest: Optional[Any],
    kwargs: Dict[str, Any],
    storage: Any,
    validate_packds_write_invariants_fn: Callable[[Any, Any, str, str], None],
    resolve_compaction_dispatch_mode_fn: Callable[[], Any],
    async_compaction_dispatch_mode: Any,
    trigger_compaction_fn: Callable[..., bool],
    dispatch_compaction_job_fn: Callable[..., None],
    run_compaction_session_fn: Callable[..., None],
    trigger_retention_fn: Callable[..., None],
    trigger_episode_index_build_fn: Callable[..., None],
    manifest_author_factory: Callable[..., Any],
    dc_version: str,
    max_delta_stream_position: Any,
    missing_schema_error_cls: type[Exception] = RuntimeError,
) -> list[Any]:
    """Stage a delta, commit it, and run post-write native follow-up hooks.

    This is the shared finalization core for standard catalog writes after the
    partition has already been selected and any in-memory data sorting/schema
    handling has completed. It preserves the native behavior of:
    - staging from either in-memory data or a prebuilt manifest
    - committing the delta and optionally the staged partition
    - triggering compaction using the already-resolved partition
    - applying best-effort retention and episode-index hooks after the write
    """
    resolved_table_version_obj = (
        updated_table_version_obj
        if updated_table_version_obj
        else original_table_version_obj
    )
    resolved_schema = resolve_table_version_schema_with_id(resolved_table_version_obj)

    if manifest is not None:
        delta = storage.stage_delta_from_manifest(
            manifest=manifest,
            partition=partition,
            delta_type=delta_type,
            content_type=content_type,
            schema=resolved_schema,
            **kwargs,
        )
    else:
        delta = storage.stage_delta(
            data=converted_data,
            partition=partition,
            delta_type=delta_type,
            content_type=content_type,
            author=manifest_author_factory(
                name="deltacat.write_to_table",
                version=dc_version,
            ),
            schema=resolved_schema,
            **kwargs,
        )

    validate_packds_write_invariants_fn(
        resolved_table_version_obj,
        delta,
        namespace,
        table,
    )

    delta = storage.commit_delta(
        delta=delta,
        parent_partition=partition,
        **kwargs,
    )

    if commit_staged_partition:
        storage.commit_partition(
            partition=partition,
            partition_stats_deltas=[delta],
            **kwargs,
        )

    # Check compaction trigger decision using the already-resolved partition
    # so the native caller does not have to re-read stream/partition state.
    should_compact = trigger_compaction_fn(
        resolved_table_version_obj,
        delta,
        partition=partition,
        **kwargs,
    )
    if should_compact:
        dispatch_mode = resolve_compaction_dispatch_mode_fn()
        if dispatch_mode == async_compaction_dispatch_mode:
            dispatch_compaction_job_fn(
                namespace=namespace,
                table=table,
                table_version=resolved_table_version_obj.table_version,
                partition=partition,
                partition_values=delta.partition_locator.partition_values,
                partition_id=partition.partition_id if partition else None,
                inner=kwargs.get("inner"),
                latest_stream_position=delta.stream_position,
                delta_count=None,
                catalog_name=kwargs.get("_catalog_name"),
            )
        else:
            if not original_table_version_obj.schema:
                raise missing_schema_error_cls(
                    "Table version schema is required to run compaction."
                )
            original_table_version_column_names = (
                original_table_version_obj.schema.arrow.names
            )
            run_compaction_session_fn(
                table_version_obj=resolved_table_version_obj,
                partition=partition,
                latest_delta_stream_position=max_delta_stream_position,
                namespace=namespace,
                table=table,
                original_fields=original_fields,
                original_table_version_column_names=original_table_version_column_names,
                **kwargs,
            )

        # No separate post-compaction sort needed. The native compaction path
        # already produces globally sorted output when the table has sort keys.

    # After write (and possible compaction), preserve the native best-effort
    # retention and PackDS episode-index side effects.
    trigger_retention_fn(
        resolved_table_version_obj,
        partition,
        namespace,
        table,
        **kwargs,
    )
    trigger_episode_index_build_fn(
        resolved_table_version_obj,
        namespace,
        table,
        **kwargs,
    )

    return [delta]
