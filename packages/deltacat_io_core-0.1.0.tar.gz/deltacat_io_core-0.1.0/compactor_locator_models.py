"""Shared locator/meta models for the older compactor stack."""

from __future__ import annotations

import hashlib
from typing import Any, List
from uuid import uuid4


def _sha1_hexdigest(payload: bytes) -> str:
    return hashlib.sha1(payload).hexdigest()


class DeltaFileLocator(tuple):
    @classmethod
    def of(
        cls,
        is_src_delta,
        stream_position,
        file_index,
        file_record_count=None,
    ):
        return cls((is_src_delta, stream_position, file_index, file_record_count))

    @property
    def is_source_delta(self):
        return self[0]

    @property
    def stream_position(self):
        return self[1]

    @property
    def file_index(self):
        return self[2]

    @property
    def file_record_count(self):
        return self[3]

    def canonical_string(self) -> str:
        return f"{self[0]}|{self[1]}|{self[2]}"


class PrimaryKeyIndexMeta(dict):
    @classmethod
    def of(
        cls,
        compacted_partition_locator,
        primary_keys: List[str],
        sort_keys: List[Any],
        primary_key_index_algo_version: str,
    ):
        pkim = cls()
        pkim["compactedPartitionLocator"] = compacted_partition_locator
        pkim["primaryKeys"] = primary_keys
        pkim["sortKeys"] = sort_keys
        pkim["primaryKeyIndexAlgorithmVersion"] = primary_key_index_algo_version
        return pkim

    @property
    def compacted_partition_locator(self):
        return self.get("compactedPartitionLocator")

    @property
    def primary_keys(self) -> List[str]:
        return self["primaryKeys"]

    @property
    def sort_keys(self) -> List[Any]:
        return self["sortKeys"]

    @property
    def primary_key_index_algorithm_version(self) -> str:
        return self["primaryKeyIndexAlgorithmVersion"]


class PrimaryKeyIndexLocator(dict):
    @classmethod
    def of(cls, primary_key_index_meta):
        pki_root_path = cls._root_path(
            primary_key_index_meta.compacted_partition_locator,
            primary_key_index_meta.primary_keys,
            primary_key_index_meta.sort_keys,
            primary_key_index_meta.primary_key_index_algorithm_version,
        )
        pkil = cls()
        pkil["primaryKeyIndexMeta"] = primary_key_index_meta
        pkil["primaryKeyIndexRootPath"] = pki_root_path
        return pkil

    @staticmethod
    def _root_path(
        compacted_partition_locator,
        primary_keys: List[str],
        sort_keys: List[Any],
        primary_key_index_algorithm_version: str,
    ) -> str:
        pl_hexdigest = compacted_partition_locator.hexdigest()
        pki_version_str = (
            f"{pl_hexdigest}|{primary_keys}|{sort_keys}|"
            f"{primary_key_index_algorithm_version}"
        )
        return _sha1_hexdigest(pki_version_str.encode("utf-8"))

    @property
    def primary_key_index_meta(self):
        return self.get("primaryKeyIndexMeta")

    @property
    def primary_key_index_root_path(self) -> str:
        return self["primaryKeyIndexRootPath"]

    def get_primary_key_index_s3_url_base(self, s3_bucket: str) -> str:
        return f"s3://{s3_bucket}/{self.primary_key_index_root_path}"

    def canonical_string(self) -> str:
        return self.primary_key_index_root_path


class PrimaryKeyIndexVersionMeta(dict):
    @classmethod
    def of(cls, primary_key_index_meta, hash_bucket_count: int):
        pkivm = cls()
        pkivm["primaryKeyIndexMeta"] = primary_key_index_meta
        pkivm["hashBucketCount"] = hash_bucket_count
        return pkivm

    @property
    def primary_key_index_meta(self):
        return self.get("primaryKeyIndexMeta")

    @property
    def hash_bucket_count(self) -> int:
        return self["hashBucketCount"]


class PrimaryKeyIndexVersionLocator(dict):
    @classmethod
    def of(cls, primary_key_index_version_meta, pki_version_root_path: str):
        pkivl = cls()
        pkivl["primaryKeyIndexVersionMeta"] = primary_key_index_version_meta
        pkivl["primaryKeyIndexVersionRootPath"] = pki_version_root_path
        return pkivl

    @classmethod
    def generate(cls, pki_version_meta):
        pki_version_root_path = cls._generate_version_root_path(
            cls._pki_root_path(pki_version_meta),
            pki_version_meta.hash_bucket_count,
        )
        pkivl = cls()
        pkivl["primaryKeyIndexVersionMeta"] = pki_version_meta
        pkivl["primaryKeyIndexVersionRootPath"] = pki_version_root_path
        return pkivl

    @staticmethod
    def _pki_root_path(pki_version_meta) -> str:
        pki_meta = pki_version_meta.primary_key_index_meta
        pki_locator = PrimaryKeyIndexLocator.of(pki_meta)
        return pki_locator.primary_key_index_root_path

    @staticmethod
    def _generate_version_root_path(pki_root_path: str, hash_bucket_count: int) -> str:
        return f"{pki_root_path}/{hash_bucket_count}/{str(uuid4())}"

    @property
    def primary_key_index_version_meta(self):
        return self.get("primaryKeyIndexVersionMeta")

    @property
    def primary_key_index_root_path(self) -> str:
        return PrimaryKeyIndexVersionLocator._pki_root_path(
            self.primary_key_index_version_meta
        )

    @property
    def primary_key_index_version_root_path(self) -> str:
        return self["primaryKeyIndexVersionRootPath"]

    def get_primary_key_index_version_s3_url_base(self, s3_bucket: str) -> str:
        return f"s3://{s3_bucket}/{self.primary_key_index_version_root_path}"

    def get_pkiv_hb_index_root_path(self, hb_index: int) -> str:
        return f"{self.primary_key_index_version_root_path}/{hb_index}"

    def get_pkiv_hb_index_s3_url_base(
        self,
        s3_bucket: str,
        hash_bucket_index: int,
    ) -> str:
        return f"s3://{s3_bucket}/{self.get_pkiv_hb_index_root_path(hash_bucket_index)}"

    def get_pkiv_hb_index_manifest_s3_url(
        self,
        s3_bucket: str,
        hash_bucket_index: int,
    ) -> str:
        return (
            f"{self.get_pkiv_hb_index_s3_url_base(s3_bucket, hash_bucket_index)}.json"
        )

    def canonical_string(self) -> str:
        return self.primary_key_index_version_root_path
