"""Shared storage write orchestration moved out of thick storage/main/impl.py."""

from __future__ import annotations

import posixpath
from typing import Any, Callable, Dict, Optional

from deltacat_io_core.deps import optional_import


def resolve_named_root(
    catalog_properties: Any,
    root_name: str,
    *,
    registry_factory: Callable[[], Any],
    resolve_path_and_filesystem_fn: Callable[[str, Any], tuple[str, Any]],
) -> tuple[Any, Any, str]:
    """Resolve a named data root to its DataRoot, filesystem, and normalized root path."""
    dr = catalog_properties.data_root_config.roots.get(root_name)
    if dr is None:
        available = sorted(catalog_properties.data_root_config.roots.keys())
        raise ValueError(
            f"Unknown data_root_name '{root_name}'. " f"Available roots: {available}"
        )
    registry = registry_factory()
    effective_data_fs = registry.get_filesystem(dr)
    resolved_root, _ = resolve_path_and_filesystem_fn(dr.root, effective_data_fs)
    return dr, effective_data_fs, resolved_root


def prefix_manifest_entries(
    manifest_entries: Any,
    root_name: str,
    *,
    prefix_path_fn: Callable[[str, str], str],
    manifest_entry_factory: Callable[..., Any],
) -> Any:
    """Prefix manifest entry URLs with a named-root marker like ``{{root}}/``."""
    prefixed_entries = []
    for entry in manifest_entries:
        url = entry.url or entry.uri
        prefixed_url = prefix_path_fn(url, root_name)
        entry_factory = getattr(type(entry), "of", None)
        if callable(entry_factory):
            prefixed_entries.append(
                entry_factory(
                    url=prefixed_url,
                    uri=prefixed_url,
                    meta=entry.meta,
                    mandatory=getattr(entry, "mandatory", True),
                    uuid=getattr(entry, "id", None),
                )
            )
            continue
        prefixed_entries.append(
            manifest_entry_factory(
                url=prefixed_url,
                uri=prefixed_url,
                meta=entry.meta,
                mandatory=getattr(entry, "mandatory", True),
                uuid=getattr(entry, "id", None),
            )
        )
    return prefixed_entries


def write_table_to_storage(
    *,
    partition_id: str,
    table: Any,
    max_records_per_entry: Optional[int],
    author: Optional[Any],
    content_type: Any,
    entry_params: Optional[Any],
    entry_type: Optional[Any],
    table_writer_kwargs: Optional[Dict[str, Any]],
    data_root_name: Optional[str],
    catalog_properties: Any,
    data_file_dir_name: str,
    content_type_to_write_strategy: Dict[Any, Callable],
    default_write_strategy: Callable,
    registry_factory: Callable[[], Any],
    resolve_path_and_filesystem_fn: Callable[[str, Any], tuple[str, Any]],
    restore_data_uri_scheme_fn: Callable[[str, Optional[Any]], str],
    prefix_path_fn: Callable[[str, str], str],
    manifest_entry_factory: Callable[..., Any],
    manifest_factory: Callable[..., Any],
    manifest_uuid_factory: Callable[[], str],
    lance_content_type: Any,
) -> Any:
    """Write a table to storage and return the resulting manifest.

    This is the shared replica of thick native ``_write_table(...)`` orchestration.
    It intentionally owns only the filesystem/data-root/write-strategy flow and
    leaves native storage-model construction at the caller boundary.

    Native behavior preserved here:
    - named-root resolution for multi-root catalogs
    - staging directory creation under ``DATA_FILE_DIR_NAME/partition_id``
    - URI-scheme restoration for writers that cannot use scheme-less
      PyArrow paths directly (for example Lance/object_store)
    - content-type-specific write strategy dispatch
    - ``{{root}}/`` manifest prefixing for non-default roots
    """
    target_data_root = None
    effective_data_root_path = catalog_properties.data_root
    effective_data_fs = catalog_properties.data_filesystem

    if data_root_name and not getattr(catalog_properties, "data_root_config", None):
        raise ValueError(
            "data_root_name was provided, but this catalog is configured with a "
            "single data_root. Configure a DataRootConfig to use named roots."
        )

    if data_root_name and getattr(catalog_properties, "data_root_config", None):
        (
            target_data_root,
            effective_data_fs,
            effective_data_root_path,
        ) = resolve_named_root(
            catalog_properties,
            data_root_name,
            registry_factory=registry_factory,
            resolve_path_and_filesystem_fn=resolve_path_and_filesystem_fn,
        )

    data_dir_path = posixpath.join(
        effective_data_root_path,
        data_file_dir_name,
        partition_id,
    )
    effective_data_fs.create_dir(data_dir_path, recursive=True)

    fs = effective_data_fs
    # PyArrow filesystem operations use scheme-less paths (e.g. ``bucket/key``),
    # but non-PyArrow writers such as Lance need fully-qualified URIs.
    pafs = optional_import("pyarrow.fs")
    needs_full_uri = (
        pafs is None
        or not isinstance(fs, pafs.FileSystem)
        or (content_type == lance_content_type)
    )
    if needs_full_uri:
        write_data_dir = restore_data_uri_scheme_fn(data_dir_path, target_data_root)
        write_data_root = restore_data_uri_scheme_fn(
            effective_data_root_path, target_data_root
        )
    else:
        write_data_dir = data_dir_path
        write_data_root = effective_data_root_path

    write_strategy = content_type_to_write_strategy.get(
        content_type, default_write_strategy
    )
    if target_data_root is not None and content_type == lance_content_type:
        # Preserve the native Lance contract: when writing to a named root,
        # pass the resolved DataRoot through so Lance storage_options can pick
        # up endpoint/profile/region configuration.
        table_writer_kwargs = dict(table_writer_kwargs or {})
        table_writer_kwargs["data_root"] = target_data_root

    manifest_entries = write_strategy(
        table,
        write_data_dir,
        catalog_root=write_data_root,
        filesystem=fs,
        max_records_per_entry=max_records_per_entry,
        content_type=content_type,
        entry_params=entry_params,
        entry_type=entry_type,
        table_writer_kwargs=table_writer_kwargs,
    )

    if target_data_root is not None and data_root_name:
        # Persist ``{{key}}/`` manifest URLs for non-default roots so later
        # reads can resolve the correct filesystem in O(1) without guessing.
        manifest_entries = prefix_manifest_entries(
            manifest_entries,
            data_root_name,
            prefix_path_fn=prefix_path_fn,
            manifest_entry_factory=manifest_entry_factory,
        )

    return manifest_factory(
        entries=manifest_entries,
        author=author,
        uuid=manifest_uuid_factory(),
        entry_type=entry_type,
        entry_params=entry_params,
    )
