"""Shared exceptions for deltacat_io_core."""


class SchemaNullabilityError(ValueError):
    """Raised when nulls appear in non-nullable fields before local file writes."""


class SchemaValidationError(ValueError):
    """Raised when local schema validation/coercion fails before file writes."""
