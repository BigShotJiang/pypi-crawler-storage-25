"""Shared helpers for table-version schema ID assignment."""

from __future__ import annotations

from typing import Any, Callable, Iterable, Optional


def _model_field(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        missing = object()
        value = obj.get(name, missing)
        if value is not missing:
            return value
    return getattr(obj, name, default)


def ensure_table_version_schema_id(
    schema: Optional[Any],
    *,
    existing_schemas: Optional[Iterable[Any]] = None,
    schema_factory: Callable[[Any, int], Any],
) -> Optional[Any]:
    """Return a schema with a table-version schema ID assigned.

    DeltaCAT schemas are dict-backed models whose ``id`` may be exposed as a
    computed property instead of a literal dict key. This helper preserves the
    authoritative existing ID when present and only assigns a new one when the
    caller-provided schema is missing its table-version schema ID.
    """
    if schema is None:
        return None

    schema_id = _model_field(schema, "id")
    if schema_id is not None:
        return schema

    arrow_schema = _model_field(schema, "arrow")
    if arrow_schema is None:
        return schema

    existing_schema_ids = [
        existing_id
        for existing_id in (
            _model_field(existing_schema, "id")
            for existing_schema in (existing_schemas or [])
        )
        if existing_id is not None
    ]
    next_schema_id = (max(existing_schema_ids) + 1) if existing_schema_ids else 0
    return schema_factory(arrow_schema, next_schema_id)
