"""Standalone Lance dataset helpers shared by client IO and native DeltaCAT."""

from __future__ import annotations

import logging
import posixpath
from decimal import Decimal
from dataclasses import dataclass
from typing import Any, Dict, Optional
from uuid import uuid4

import deltacat_io_core.logs as logs
from deltacat_io_core.deps import require_pyarrow
from deltacat_io_core.filesystem_support import FilesystemType

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))

_DELTACAT_SCHEMA_ID_KEY = b"DELTACAT:schema_id"

DEFAULT_MAX_ROWS_PER_FILE = 100_000

_TYPE_ALIGNMENT: Optional[Dict[int, int]] = None


def _require_lance():
    import lance

    return lance


def _require_pafs():
    import pyarrow.fs as pafs

    return pafs


def storage_options_from_filesystem(
    filesystem: Optional[Any],
    *,
    endpoint_url: Optional[str] = None,
    profile: Optional[str] = None,
    region: Optional[str] = None,
    credentials: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """Build Lance storage_options from a resolved filesystem/config."""
    if (
        filesystem is None
        and not endpoint_url
        and not profile
        and not region
        and not credentials
    ):
        return None

    fs_type = (
        FilesystemType.from_filesystem(filesystem) if filesystem is not None else None
    )
    if fs_type == FilesystemType.S3 or endpoint_url or profile or region:
        opts: Dict[str, Any] = {}
        if filesystem is not None:
            fs_region = getattr(filesystem, "region", None)
            if fs_region:
                opts["region"] = fs_region

        if region:
            opts["region"] = region
        if endpoint_url:
            opts["aws_endpoint"] = endpoint_url
            opts["allow_http"] = "true" if "http://" in endpoint_url else "false"

        access_key = None
        secret_key = None
        session_token = None
        if credentials:
            access_key = (
                credentials.get("aws_access_key_id")
                or credentials.get("AccessKeyId")
                or credentials.get("access_key_id")
            )
            secret_key = (
                credentials.get("aws_secret_access_key")
                or credentials.get("SecretAccessKey")
                or credentials.get("secret_access_key")
            )
            session_token = (
                credentials.get("aws_session_token")
                or credentials.get("SessionToken")
                or credentials.get("session_token")
            )
        else:
            try:
                import boto3

                session = (
                    boto3.Session(profile_name=profile) if profile else boto3.Session()
                )
                resolved_credentials = session.get_credentials()
                if resolved_credentials:
                    resolved = resolved_credentials.get_frozen_credentials()
                    access_key = resolved.access_key
                    secret_key = resolved.secret_key
                    session_token = resolved.token
            except Exception:
                logger.debug(
                    "Could not resolve AWS credentials via boto3; Lance will use its "
                    "default credential chain.",
                    exc_info=True,
                )

        if access_key:
            opts["aws_access_key_id"] = access_key
        if secret_key:
            opts["aws_secret_access_key"] = secret_key
        if session_token:
            opts["aws_session_token"] = session_token
        return opts or None

    return None


def normalize_lance_storage_options(
    storage_options: Optional[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Normalize keys for ``lance.dataset(..., storage_options=...)`` consumers."""
    if not storage_options:
        return storage_options
    normalized = dict(storage_options)
    if "aws_access_key_id" in normalized and "access_key_id" not in normalized:
        normalized["access_key_id"] = normalized["aws_access_key_id"]
    if "AccessKeyId" in normalized and "access_key_id" not in normalized:
        normalized["access_key_id"] = normalized["AccessKeyId"]
    if "aws_secret_access_key" in normalized and "secret_access_key" not in normalized:
        normalized["secret_access_key"] = normalized["aws_secret_access_key"]
    if "SecretAccessKey" in normalized and "secret_access_key" not in normalized:
        normalized["secret_access_key"] = normalized["SecretAccessKey"]
    if "aws_session_token" in normalized and "session_token" not in normalized:
        normalized["session_token"] = normalized["aws_session_token"]
    if "SessionToken" in normalized and "session_token" not in normalized:
        normalized["session_token"] = normalized["SessionToken"]
    if "aws_endpoint" in normalized and "endpoint" not in normalized:
        normalized["endpoint"] = normalized["aws_endpoint"]
    if "endpoint_url" in normalized and "endpoint" not in normalized:
        normalized["endpoint"] = normalized["endpoint_url"]
    return normalized


@dataclass(frozen=True)
class LanceEntryPayload:
    path: str
    record_count: int
    content_length: int
    schema_id: Optional[int]
    source_content_length: Optional[int]
    sort_scheme_id: Optional[str]
    column_stats: Optional[Dict[str, Any]]
    entry_type: Optional[Any]
    entry_params: Optional[Any]
    catalog_root: Optional[str]


def _type_alignment_map() -> Dict[int, int]:
    global _TYPE_ALIGNMENT
    if _TYPE_ALIGNMENT is None:
        pa = require_pyarrow("lance support")
        _TYPE_ALIGNMENT = {
            pa.int16().id: 2,
            pa.uint16().id: 2,
            pa.float16().id: 2,
            pa.int32().id: 4,
            pa.uint32().id: 4,
            pa.float32().id: 4,
            pa.date32().id: 4,
            pa.time32("ms").id: 4,
            pa.int64().id: 8,
            pa.uint64().id: 8,
            pa.float64().id: 8,
            pa.date64().id: 8,
            pa.time64("us").id: 8,
            pa.duration("us").id: 8,
            pa.decimal128(1).id: 16,
            pa.decimal256(1).id: 16,
        }
        _TYPE_ALIGNMENT[pa.timestamp("us").id] = 8
    return _TYPE_ALIGNMENT


def _alignment_for_type(arrow_type: Any) -> int:
    return _type_alignment_map().get(arrow_type.id, 1)


def _column_needs_realignment(chunked: Any) -> bool:
    pa = require_pyarrow("lance support")
    required = _alignment_for_type(chunked.type)
    if required <= 1:
        return False
    for chunk in chunked.chunks:
        for buf in chunk.buffers():
            if buf is not None and buf.address % required != 0:
                return True
        if pa.types.is_struct(chunked.type):
            for i in range(chunked.type.num_fields):
                child = pa.chunked_array([chunk.field(i) for chunk in chunked.chunks])
                if _column_needs_realignment(child):
                    return True
        elif pa.types.is_list(chunked.type) or pa.types.is_large_list(chunked.type):
            child = pa.chunked_array([chunk.values for chunk in chunked.chunks])
            if _column_needs_realignment(child):
                return True
    return False


def _realign_column(chunked: Any, column_name: str) -> Any:
    pa = require_pyarrow("lance support")
    try:
        return pa.chunked_array([pa.concat_arrays([chunk]) for chunk in chunked.chunks])
    except Exception:
        values = chunked.to_pylist()
        logger.debug(
            "Realigned Lance column %r (type=%s) via to_pylist round-trip",
            column_name,
            chunked.type,
            exc_info=True,
        )
        return pa.chunked_array([pa.array(values, type=chunked.type)])


def ensure_lance_buffer_alignment(table: Any) -> Any:
    pa = require_pyarrow("lance support")
    misaligned = [
        name
        for name, col in zip(table.column_names, table.columns)
        if _column_needs_realignment(col)
    ]
    if not misaligned:
        return table
    new_columns = []
    for name, col in zip(table.column_names, table.columns):
        if name in misaligned:
            new_columns.append(_realign_column(col, name))
        else:
            new_columns.append(col)
    return pa.table(dict(zip(table.column_names, new_columns)), schema=table.schema)


def _metadata_value_to_serializable(value: Any) -> Any:
    if hasattr(value, "isoformat"):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    return value


def get_lance_dataset_stats(
    lance_path: str,
    *,
    storage_options: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    lance = _require_lance()
    ds = lance.dataset(lance_path, storage_options=storage_options)
    record_count = ds.count_rows()
    content_length = sum(
        df.file_size_bytes for frag in ds.get_fragments() for df in frag.metadata.files
    )
    schema = ds.schema
    schema_id_bytes = (schema.metadata or {}).get(_DELTACAT_SCHEMA_ID_KEY)
    schema_id = int(schema_id_bytes) if schema_id_bytes is not None else None
    return {
        "record_count": record_count,
        "content_length": content_length or 0,
        "schema_id": schema_id,
        "schema": schema,
    }


def compute_sort_column_stats(
    lance_path: str,
    sort_column: str,
    *,
    storage_options: Optional[Dict[str, Any]] = None,
) -> Dict[str, Dict[str, Any]]:
    lance = _require_lance()
    ds = lance.dataset(lance_path, storage_options=storage_options)
    col = ds.to_table(columns=[sort_column])[sort_column].combine_chunks()
    if len(col) == 0:
        return {}
    min_val = col[0].as_py()
    max_val = col[-1].as_py()
    return {
        sort_column: {
            "min": _metadata_value_to_serializable(min_val),
            "max": _metadata_value_to_serializable(max_val),
        }
    }


def write_lance_dataset(
    table: Any,
    lance_path: str,
    *,
    schema_id: Optional[int] = None,
    sort_column: Optional[str] = None,
    max_rows_per_fragment: int = DEFAULT_MAX_ROWS_PER_FILE,
    storage_options: Optional[Dict[str, Any]] = None,
    filesystem: Optional[Any] = None,
) -> Dict[str, Any]:
    lance = _require_lance()
    if schema_id is not None:
        existing_meta = table.schema.metadata or {}
        table = table.replace_schema_metadata(
            {
                **existing_meta,
                _DELTACAT_SCHEMA_ID_KEY: str(schema_id).encode(),
            }
        )

    table = ensure_lance_buffer_alignment(table)
    source_content_length = getattr(table, "nbytes", None)

    try:
        lance.write_dataset(
            table,
            lance_path,
            mode="create",
            max_rows_per_file=max_rows_per_fragment,
            storage_options=storage_options,
        )
    except Exception:
        cleanup_fs = filesystem or _require_pafs().LocalFileSystem()
        try:
            cleanup_fs.delete_dir(lance_path)
        except Exception:
            logger.debug(
                "Failed to clean up partial Lance directory: %s",
                lance_path,
                exc_info=True,
            )
        raise

    stats = get_lance_dataset_stats(lance_path, storage_options=storage_options)
    column_stats = None
    if sort_column:
        try:
            column_stats = compute_sort_column_stats(
                lance_path,
                sort_column,
                storage_options=storage_options,
            )
        except Exception:
            logger.warning(
                "Failed to compute Lance sort-column stats for %s",
                lance_path,
                exc_info=True,
            )

    return {
        "path": lance_path,
        "record_count": stats["record_count"],
        "content_length": stats["content_length"],
        "schema_id": stats["schema_id"],
        "schema": stats["schema"],
        "source_content_length": source_content_length,
        "column_stats": column_stats,
    }


def write_lance_entry_payload(
    table: Any,
    *,
    base_path: str,
    filesystem: Optional[Any] = None,
    catalog_root: Optional[str] = None,
    schema_id: Optional[int] = None,
    sort_scheme_id: Optional[str] = None,
    sort_column: Optional[str] = None,
    max_rows_per_fragment: int = DEFAULT_MAX_ROWS_PER_FILE,
    entry_type: Optional[Any] = None,
    entry_params: Optional[Any] = None,
    data_root=None,
    dataset_name: Optional[str] = None,
    credentials: Optional[Dict[str, Any]] = None,
    endpoint_url: Optional[str] = None,
    profile: Optional[str] = None,
    region: Optional[str] = None,
) -> LanceEntryPayload:
    dataset_name = dataset_name or f"{uuid4()}.lance"
    lance_path = posixpath.join(base_path, dataset_name)
    storage_options = storage_options_from_filesystem(
        filesystem,
        endpoint_url=(
            endpoint_url
            if endpoint_url is not None
            else (
                data_root.storage_config.get("endpoint_url")
                if data_root and data_root.storage_config
                else None
            )
        ),
        profile=(
            profile
            if profile is not None
            else (
                data_root.storage_config.get("profile")
                if data_root and data_root.storage_config
                else None
            )
        ),
        region=(
            region
            if region is not None
            else (
                data_root.storage_config.get("region")
                if data_root and data_root.storage_config
                else None
            )
        ),
        credentials=credentials,
    )

    write_result = write_lance_dataset(
        table,
        lance_path,
        schema_id=schema_id,
        sort_column=sort_column,
        max_rows_per_fragment=max_rows_per_fragment,
        storage_options=storage_options,
        filesystem=filesystem,
    )

    return LanceEntryPayload(
        path=lance_path,
        record_count=int(write_result["record_count"]),
        content_length=int(write_result["content_length"]),
        schema_id=write_result["schema_id"] if schema_id is None else schema_id,
        source_content_length=write_result.get("source_content_length"),
        sort_scheme_id=sort_scheme_id,
        column_stats=write_result.get("column_stats"),
        entry_type=entry_type,
        entry_params=entry_params,
        catalog_root=catalog_root,
    )
