"""Shared envelope and table-storage model layer."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Optional

import numpy as np
import pyarrow as pa

LocalTableReference = Any


class LocalTableStorageStrategy(ABC):
    @property
    @abstractmethod
    def object_store(self) -> Any:
        pass

    @abstractmethod
    def store_table(self, table: Any) -> LocalTableReference:
        pass

    @abstractmethod
    def get_table(self, table_like: LocalTableReference) -> Any:
        pass

    def get_table_reference(self, table_ref: Any) -> LocalTableReference:
        return table_ref


DeltaFileEnvelopeGroups = np.ndarray


class DeltaFileEnvelope(dict):
    @classmethod
    def of(
        cls,
        stream_position: int,
        delta_type: Any,
        table: Any,
        file_index: int = None,
        is_src_delta: np.bool_ = True,
        file_record_count: Optional[int] = None,
        table_storage_strategy: Optional[LocalTableStorageStrategy] = None,
    ):
        if stream_position is None:
            raise ValueError("Missing delta file envelope stream position.")
        if delta_type is None:
            raise ValueError("Missing Delta file envelope delta type.")
        if table is None:
            raise ValueError("Missing Delta file envelope table.")
        delta_file_envelope = cls()
        delta_file_envelope["streamPosition"] = stream_position
        delta_file_envelope["fileIndex"] = file_index
        delta_file_envelope["deltaType"] = delta_type
        if table_storage_strategy is None:
            delta_file_envelope["table"] = table
        else:
            delta_file_envelope["table"] = table_storage_strategy.store_table(table)
        delta_file_envelope["table_storage_strategy"] = table_storage_strategy
        delta_file_envelope["is_src_delta"] = is_src_delta
        delta_file_envelope["file_record_count"] = file_record_count
        return delta_file_envelope

    @property
    def stream_position(self) -> int:
        return self.get("streamPosition", self.get("stream_position"))

    @property
    def file_index(self) -> int:
        return self.get("fileIndex", self.get("file_index"))

    @property
    def delta_type(self):
        return self.get("deltaType", self.get("delta_type"))

    @property
    def table_storage_strategy(self) -> Optional[LocalTableStorageStrategy]:
        return self.get("table_storage_strategy")

    @property
    def table(self):
        val = self.table_storage_strategy
        raw_table = self.get("table")
        if val is not None and raw_table is not None:
            return val.get_table(raw_table)
        return raw_table

    @property
    def is_src_delta(self) -> np.bool_:
        return self.get("is_src_delta")

    @property
    def file_record_count(self) -> int:
        return self.get("file_record_count")

    @property
    def table_size_bytes(self) -> int:
        if isinstance(self.table, pa.Table):
            return self.table.nbytes
        raise ValueError(
            f"Table type: {type(self.table)} not for supported for size method."
        )

    @property
    def table_num_rows(self) -> int:
        return len(self.table)


class DeleteFileEnvelope(DeltaFileEnvelope):
    @classmethod
    def of(
        cls,
        stream_position: int,
        delta_type: Any,
        table: Any,
        delete_columns,
        file_index: int = None,
        is_src_delta: np.bool_ = True,
        file_record_count: Optional[int] = None,
        table_storage_strategy: Optional[LocalTableStorageStrategy] = None,
    ):
        delete_file_envelope = super().of(
            stream_position,
            delta_type,
            table,
            file_index,
            is_src_delta,
            file_record_count,
            table_storage_strategy,
        )
        assert len(delete_columns) > 0, "At least 1 delete column is expected"
        delete_file_envelope["delete_columns"] = delete_columns
        if isinstance(table, pa.Table):
            delete_file_envelope["table_size_bytes"] = table.nbytes
        return cls(**delete_file_envelope)

    @property
    def table_size_bytes(self) -> int:
        val = self.get("table_size_bytes")
        if val is not None:
            return val
        raise ValueError(
            f"Table type: {type(self.table)} not for supported for size method."
        )

    @property
    def delete_columns(self):
        return self["delete_columns"]

    @property
    def table_reference(self) -> Optional[Any]:
        explicit = self.get("table_reference", self.get("tableReference"))
        if explicit is not None:
            return explicit
        strategy = self.table_storage_strategy
        if strategy is not None and hasattr(strategy, "get_table_reference"):
            return strategy.get_table_reference(self.get("table"))
        return None
