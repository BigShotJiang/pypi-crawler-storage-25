"""Shared delete-preparation helpers used by MOR and compaction paths."""

from __future__ import annotations

import itertools
from collections import defaultdict
from typing import Any, Dict, List, Optional, Sequence, Tuple


def aggregate_delete_deltas(
    input_deltas: Sequence[Any],
    *,
    delete_delta_type: Any,
) -> Dict[int, List[Any]]:
    """Group consecutive DELETE deltas with identical delete parameters."""
    start_stream_spos_to_delete_delta_sequence: Dict[int, List[Any]] = defaultdict(list)
    grouped_sequences: List[Tuple[bool, List[Any]]] = [
        (is_delete, list(delete_delta_group))
        for (is_delete, _), delete_delta_group in itertools.groupby(
            input_deltas,
            lambda d: (d.type is delete_delta_type, d.meta.entry_params),
        )
    ]
    for is_delete_delta_sequence, delete_delta_sequence in grouped_sequences:
        if not is_delete_delta_sequence:
            continue
        starting_stream_position = delete_delta_sequence[0].stream_position
        start_stream_spos_to_delete_delta_sequence[
            starting_stream_position
        ] = delete_delta_sequence
    return start_stream_spos_to_delete_delta_sequence


def get_delete_file_envelopes(
    params: Any,
    delete_spos_to_delete_deltas: Dict[int, List[Any]],
    *,
    local_storage_type: Any,
    concat_tables_fn,
    delete_file_envelope_factory,
) -> List[Any]:
    """Create DeleteFileEnvelope objects from grouped DELETE deltas."""
    delete_file_envelopes = []
    for (
        start_stream_position,
        delete_delta_sequence,
    ) in delete_spos_to_delete_deltas.items():
        consecutive_delete_tables = []
        for delete_delta in delete_delta_sequence:
            assert (
                delete_delta.meta.entry_params is not None
            ), "Delete type deltas are required to have delete parameters defined"
            delete_columns: Optional[
                List[str]
            ] = delete_delta.meta.entry_params.equality_field_locators
            assert len(delete_columns) > 0, "At least 1 delete column is required"
            delete_dataset = params.deltacat_storage.download_delta(
                delete_delta,
                file_reader_kwargs_provider=params.read_kwargs_provider,
                columns=delete_columns,
                storage_type=local_storage_type,
                max_parallelism=1,
                **params.deltacat_storage_kwargs,
            )
            consecutive_delete_tables.extend(delete_dataset)
        delete_table = concat_tables_fn(consecutive_delete_tables)
        delete_file_envelopes.append(
            delete_file_envelope_factory.of(
                start_stream_position,
                delta_type=delete_delta.type,
                table=delete_table,
                delete_columns=delete_columns,
            )
        )
    return delete_file_envelopes


def prepare_deletes(
    params: Any,
    input_deltas: List[Any],
    *,
    delete_delta_type: Any,
    aggregate_delete_deltas_fn,
    get_delete_file_envelopes_fn,
    prepare_delete_result_factory,
    equality_delete_strategy_factory,
) -> Any:
    """Prepare delete envelopes and non-delete deltas for compaction/MOR."""
    if not input_deltas:
        return prepare_delete_result_factory(input_deltas, [], None)
    assert all(
        input_deltas[i].stream_position <= input_deltas[i + 1].stream_position
        for i in range(len(input_deltas) - 1)
    ), "Uniform deltas must be in non-decreasing order by stream position"

    start_stream_spos_to_delete_delta_sequence = aggregate_delete_deltas_fn(
        input_deltas
    )
    delete_file_envelopes = get_delete_file_envelopes_fn(
        params, start_stream_spos_to_delete_delta_sequence
    )
    assert len(start_stream_spos_to_delete_delta_sequence) == len(
        delete_file_envelopes
    ), "The number of delete file envelopes should match the number of DELETE-type Delta sequences"
    return prepare_delete_result_factory(
        [delta for delta in input_deltas if delta.type is not delete_delta_type],
        delete_file_envelopes,
        equality_delete_strategy_factory(),
    )
