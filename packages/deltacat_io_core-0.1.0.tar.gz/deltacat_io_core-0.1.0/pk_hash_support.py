"""Shared primary-key hash helpers for compaction and MOR."""

from __future__ import annotations

import hashlib
import logging
import uuid
from functools import lru_cache
from typing import List, Optional

import pyarrow as pa
import pyarrow.compute as pc

from deltacat_io_core import logs
from deltacat_io_core import system_columns as sc

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))

TOTAL_BYTES_IN_SHA1_HASH = 40
PK_DELIMITER = "|"
MAX_INT_BYTES = 2_147_483_646


@lru_cache(maxsize=1)
def _int_max_string_len() -> int:
    uint64_str_bytes = pc.binary_length(
        pc.cast(pa.scalar(2**64 - 1, type=pa.uint64()), pa.string())
    ).as_py()
    int64_str_bytes = pc.binary_length(
        pc.cast(pa.scalar(-(2**63), type=pa.int64()), pa.string())
    ).as_py()
    return max(uint64_str_bytes, int64_str_bytes)


def sliced_string_cast(array: pa.ChunkedArray) -> pa.ChunkedArray:
    """Chunk-preserving cast to string, avoiding oversized intermediate arrays."""
    dtype = array.type
    max_str_len = None
    if pa.types.is_integer(dtype):
        max_str_len = _int_max_string_len()
    elif pa.types.is_floating(dtype):
        max_str_len = 32
    elif pa.types.is_decimal128(dtype):
        max_str_len = dtype.precision + 2
    elif pa.types.is_decimal256(dtype):
        max_str_len = dtype.precision + 2

    if max_str_len is not None:
        max_elems_per_chunk = MAX_INT_BYTES // (2 * max_str_len)
        all_chunks = []
        for chunk in array.chunks:
            if len(chunk) < max_elems_per_chunk:
                all_chunks.append(chunk)
            else:
                curr_pos = 0
                total_len = len(chunk)
                while curr_pos < total_len:
                    sliced = chunk.slice(curr_pos, max_elems_per_chunk)
                    curr_pos += len(sliced)
                    all_chunks.append(sliced)
        array = pa.chunked_array(all_chunks, type=dtype)

    return pc.cast(array, pa.string())


def _append_sha1_hash_to_table(table: pa.Table, hash_column: pa.Array) -> pa.Table:
    hash_column_np = hash_column.to_numpy()
    result = []
    for hash_value in hash_column_np:
        if hash_value is None:
            result.append(None)
            logger.info("A primary key hash is null")
        else:
            result.append(hashlib.sha1(hash_value.encode("utf-8")).hexdigest())
    return sc.append_pk_hash_string_column(table, result)


def _is_sha1_desired(hash_columns: List[pa.Array]) -> bool:
    total_size = 0
    total_len = 0
    for hash_column in hash_columns:
        total_size += hash_column.nbytes
        total_len += len(hash_column)
    logger.info(
        "Found total length of hash column=%s and total_size=%s",
        total_len,
        total_size,
    )
    return total_size > TOTAL_BYTES_IN_SHA1_HASH * total_len


def generate_pk_hash_column(
    tables: List[pa.Table],
    primary_keys: Optional[List[str]] = None,
    requires_hash: bool = False,
) -> List[pa.Table]:
    """Append the system PK-hash string column to each table."""

    def _generate_pk_hash(table: pa.Table) -> pa.Array:
        pk_columns = [sliced_string_cast(table[pk_name]) for pk_name in primary_keys]
        pk_columns.append(PK_DELIMITER)
        return pc.binary_join_element_wise(*pk_columns, null_handling="replace")

    def _generate_uuid(table: pa.Table) -> pa.Array:
        return pa.array([uuid.uuid4().hex for _ in range(len(table))], pa.string())

    hash_column_list = []
    can_sha1 = False
    if primary_keys:
        hash_column_list = [_generate_pk_hash(table) for table in tables]
        can_sha1 = requires_hash or _is_sha1_desired(hash_column_list)
    else:
        hash_column_list = [_generate_uuid(table) for table in tables]

    logger.info(
        "can_generate_sha1=%s for the table and requires_sha1=%s",
        can_sha1,
        requires_hash,
    )

    result = []
    for index, table in enumerate(tables):
        if can_sha1:
            table = _append_sha1_hash_to_table(table, hash_column_list[index])
        else:
            table = table.append_column(
                sc._PK_HASH_STRING_COLUMN_FIELD,
                hash_column_list[index],
            )
        result.append(table)
    return result
