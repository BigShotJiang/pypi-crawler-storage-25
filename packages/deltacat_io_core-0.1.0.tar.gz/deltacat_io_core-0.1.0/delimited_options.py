"""Shared delimited text reader/writer option helpers."""

from __future__ import annotations

import csv
from dataclasses import dataclass
from typing import Any, Dict

from deltacat_io_core.deps import require_pyarrow_csv

UNESCAPED_TSV_TYPES = {"application/x-amzn-unescaped-tsv"}
TSV_TYPES = {"tsv", "text/tsv"}
CSV_TYPES = {"csv", "text/csv"}
PSV_TYPES = {"psv", "text/psv"}


@dataclass(frozen=True)
class DelimitedWriteSpec:
    separator: str
    include_header: bool = False
    quote_mode: str = "needed"
    null_value: str | None = None


def content_type_to_write_spec(content_type: str) -> DelimitedWriteSpec | None:
    if content_type in UNESCAPED_TSV_TYPES:
        return DelimitedWriteSpec(
            separator="\t",
            include_header=False,
            quote_mode="none",
            null_value="",
        )
    if content_type in TSV_TYPES:
        return DelimitedWriteSpec(
            separator="\t",
            include_header=False,
            quote_mode="needed",
        )
    if content_type in CSV_TYPES:
        return DelimitedWriteSpec(
            separator=",",
            include_header=False,
            quote_mode="needed",
        )
    if content_type in PSV_TYPES:
        return DelimitedWriteSpec(
            separator="|",
            include_header=False,
            quote_mode="needed",
        )
    return None


def content_type_to_writer_kwargs(content_type: str) -> Dict[str, Any]:
    pacsv = require_pyarrow_csv("delimited text writer options")
    spec = content_type_to_write_spec(content_type)
    if spec is None:
        return {}
    return {
        "write_options": pacsv.WriteOptions(
            delimiter=spec.separator,
            include_header=spec.include_header,
            quoting_style=spec.quote_mode,
        )
    }


def content_type_to_pandas_writer_kwargs(content_type: str) -> Dict[str, Any]:
    spec = content_type_to_write_spec(content_type)
    if spec is None:
        return {}
    quote_map = {
        "none": csv.QUOTE_NONE,
        "needed": csv.QUOTE_MINIMAL,
    }
    kwargs: Dict[str, Any] = {
        "sep": spec.separator,
        "header": spec.include_header,
        "lineterminator": "\n",
        "quoting": quote_map[spec.quote_mode],
        "index": False,
    }
    if spec.null_value is not None:
        kwargs["na_rep"] = spec.null_value
    return kwargs


def content_type_to_polars_writer_kwargs(content_type: str) -> Dict[str, Any]:
    spec = content_type_to_write_spec(content_type)
    if spec is None:
        return {}
    quote_map = {
        "none": "never",
        "needed": "necessary",
    }
    kwargs: Dict[str, Any] = {
        "separator": spec.separator,
        "include_header": spec.include_header,
        "quote_style": quote_map[spec.quote_mode],
    }
    if spec.null_value is not None:
        kwargs["null_value"] = spec.null_value
    return kwargs


def content_type_to_ray_writer_kwargs(content_type: str) -> Dict[str, Any]:
    spec = content_type_to_write_spec(content_type)
    if spec is None:
        return {}
    kwargs: Dict[str, Any] = {
        "delimiter": spec.separator,
        "include_header": spec.include_header,
    }
    if spec.quote_mode == "none":
        kwargs["quoting_style"] = "none"
    return kwargs


def content_type_to_reader_kwargs(content_type: str) -> Dict[str, Any]:
    pacsv = require_pyarrow_csv("delimited text reader options")
    if content_type in UNESCAPED_TSV_TYPES:
        return {
            "parse_options": pacsv.ParseOptions(delimiter="\t", quote_char=False),
            "convert_options": pacsv.ConvertOptions(
                null_values=[""],
                strings_can_be_null=True,
            ),
        }
    if content_type in TSV_TYPES:
        return {"parse_options": pacsv.ParseOptions(delimiter="\t")}
    if content_type in CSV_TYPES:
        return {"parse_options": pacsv.ParseOptions(delimiter=",")}
    if content_type in PSV_TYPES:
        return {"parse_options": pacsv.ParseOptions(delimiter="|")}
    return {}
