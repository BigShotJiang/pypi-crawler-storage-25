"""Internal shared local execution helpers for the medium-weight client facade."""

from __future__ import annotations

from enum import Enum
import logging
import os
import posixpath
import time
from types import SimpleNamespace
import urllib.parse
from typing import Any, Dict, List, Optional, Sequence, Set, Tuple, Union

import deltacat_io_core.logs as logs
from deltacat_io_core import system_columns as sc
from deltacat_io_core.chunk_dedupe import drop_duplicates as chunk_drop_duplicates
from deltacat_io_core.compactor_task_models import MergeInput
from deltacat_io_core.delete_models import EqualityDeleteStrategy, PrepareDeleteResult
from deltacat_io_core.delete_support import (
    aggregate_delete_deltas as shared_aggregate_delete_deltas,
    get_delete_file_envelopes as shared_get_delete_file_envelopes,
    prepare_deletes as shared_prepare_deletes,
)
from deltacat_io_core.deps import (
    convert_table_output,
    optional_import,
    require_lance,
    require_module,
    require_pyarrow,
    require_pyarrow_csv,
    require_pyarrow_parquet,
)
from deltacat_io_core.errors import SchemaNullabilityError
from deltacat_io_core.delta_annotation_support import (
    DeltaAnnotation as SharedDeltaAnnotation,
    annotated_delta_of as shared_annotated_delta_of,
)
from deltacat_io_core.delta_file_support import (
    get_local_delta_file_envelopes as shared_get_local_delta_file_envelopes,
    read_delta_file_envelopes as shared_read_delta_file_envelopes,
)
from deltacat_io_core.delimited_options import content_type_to_reader_kwargs
from deltacat_io_core.envelope_models import DeleteFileEnvelope, DeltaFileEnvelope
from deltacat_io_core.filesystem_support import (
    get_file_info,
    infer_s3_express_region,
    resolve_path_and_filesystem,
)
from deltacat_io_core.filtering import (
    may_match_column_stats,
    translate_expression_to_pyarrow_filter,
)
from deltacat_io_core.merge_table_support import (
    append_delta_type_column as shared_append_delta_type_column,
    build_incremental_table as shared_build_incremental_table,
    concat_or_coerce_tables as shared_concat_or_coerce_tables,
    drop_delta_type_rows as shared_drop_delta_type_rows,
    flatten_dfe_list as shared_flatten_dfe_list,
    group_sequence_by_delta_type as shared_group_sequence_by_delta_type,
    merge_records_partially as shared_merge_records_partially,
    sort_df_envelopes as shared_sort_df_envelopes,
    merge_tables as shared_merge_tables,
)
from deltacat_io_core.merge_task_support import (
    execute_apply_upserts as shared_execute_apply_upserts,
    execute_compact_tables as shared_execute_compact_tables,
)
from deltacat_io_core.lance_support import (
    compute_sort_column_stats as compute_lance_sort_column_stats,
    get_lance_dataset_stats as get_local_lance_dataset_stats,
    normalize_lance_storage_options,
    storage_options_from_filesystem,
    write_lance_entry_payload,
)
from deltacat_io_core.models import (
    IODataFile,
    ManifestTableRow,
    ScanTask as IOScanTask,
    coerce_scan_tasks,
)
from deltacat_io_core.pk_hash_support import generate_pk_hash_column
from deltacat_io_core.performance_support import timed_invocation
from deltacat_io_core.polars_support import build_polars_lazy_scan
from deltacat_io_core.pyarrow_read_support import file_to_table as pyarrow_file_to_table
from deltacat_io_core.schema_support import (
    align_table_to_schema,
    coerce_table_for_write,
    decode_arrow_schema,
    encode_arrow_schema,
    schema_fields_from_summary,
    schema_has_past_defaults,
)
from deltacat_io_core.sort_support import order_items_by_primary_sort_key
from deltacat_io_core.table_write_replica import write_sliced_pyarrow_table

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))

PARQUET_TYPES = {"parquet", "application/parquet"}
CSV_TYPES = {"csv", "text/csv"}
TSV_TYPES = {"tsv", "text/tsv"}
PSV_TYPES = {"psv", "text/psv"}
UNESCAPED_TSV_TYPES = {"application/x-amzn-unescaped-tsv"}
FEATHER_TYPES = {"feather", "application/feather"}
JSON_TYPES = {"json", "application/json"}
ORC_TYPES = {"orc", "application/orc"}
AVRO_TYPES = {"avro", "application/avro"}
LANCE_TYPES = {"lance", "application/vnd.lance"}
EXT_TO_CONTENT_ENCODING = {
    ".gz": "gzip",
    ".bz2": "bzip2",
    ".zst": "zstd",
    ".sz": "snappy",
    ".zz": "deflate",
    ".zip": "deflate",
}
UNSUPPORTED_REMOTE_SCHEMES = {
    "gs": "GCS",
    "az": "Azure Blob Storage",
}


def _path_scheme(path: str) -> str:
    return urllib.parse.urlparse(str(path)).scheme.lower()


def _raise_for_unsupported_remote_path(path: str, *, operation: str) -> None:
    scheme = _path_scheme(path)
    if scheme not in UNSUPPORTED_REMOTE_SCHEMES:
        return
    raise NotImplementedError(
        f"{operation} does not yet support {scheme}:// paths on the shared "
        "deltacat_io_core path. Use local paths or s3:// paths instead, or "
        "run the operation through a native DeltaCAT path with backend-native "
        f"{UNSUPPORTED_REMOTE_SCHEMES[scheme]} handling."
    )


class _ThinMorDeltaType(str, Enum):
    ADD = "add"
    APPEND = "append"
    UPSERT = "upsert"
    DELETE = "delete"

    @classmethod
    def _missing_(cls, value: Any):
        if value is None:
            return None
        normalized = str(value).strip()
        if "." in normalized:
            normalized = normalized.rsplit(".", 1)[-1]
        normalized = normalized.lower()
        for member in cls:
            if member.value == normalized:
                return member
        return None


class _ThinMorSortKey:
    def __init__(self, key: Sequence[str], sort_order: Optional[str] = None):
        self.key = list(key or [])
        self.sort_order = sort_order or "ascending"

    @property
    def arrow(self):
        order = str(self.sort_order).lower()
        normalized = "descending" if order.startswith("desc") else "ascending"
        return [(column_name, normalized) for column_name in self.key]


class _ThinMorSortScheme:
    def __init__(
        self, keys: Sequence[_ThinMorSortKey], scheme_id: Optional[str] = None
    ):
        self.keys = list(keys or [])
        self.id = scheme_id


class _ThinMorEntryParams:
    def __init__(self, equality_field_locators: Sequence[str]):
        self.equality_field_locators = list(equality_field_locators or [])

    @classmethod
    def from_any(cls, value: Any):
        if value is None:
            return None
        if isinstance(value, cls):
            return value
        if isinstance(value, dict):
            return cls(value.get("equality_field_locators") or [])
        eql = getattr(value, "equality_field_locators", None)
        if eql is not None:
            return cls(eql)
        return None


class _ThinMorMeta:
    def __init__(
        self,
        *,
        record_count: int = 0,
        content_length: int = 0,
        source_content_length: Optional[int] = None,
        content_type: str = "parquet",
        content_encoding: str = "identity",
        entry_params: Optional[Any] = None,
        schema_id: Optional[Any] = None,
        sort_scheme_id: Optional[Any] = None,
        column_stats: Optional[Any] = None,
    ):
        self.record_count = record_count
        self.content_length = content_length
        self.source_content_length = source_content_length
        self.content_type = content_type
        self.content_encoding = content_encoding
        self.entry_params = entry_params
        self.schema_id = schema_id
        self.sort_scheme_id = sort_scheme_id
        self.column_stats = column_stats
        self.content_type_parameters = None


class _ThinMorManifestEntry:
    def __init__(self, *, file_info: IODataFile):
        self.url = file_info.path
        self.uri = file_info.path
        self.id = file_info.entry_id
        self.mandatory = file_info.mandatory
        self.meta = _ThinMorMeta(
            record_count=file_info.record_count,
            content_length=file_info.content_length,
            source_content_length=file_info.source_content_length,
            content_type=str(file_info.content_type or "parquet"),
            content_encoding=str(file_info.content_encoding or "identity"),
            schema_id=file_info.schema_id,
            sort_scheme_id=file_info.sort_scheme_id,
            column_stats=file_info.column_stats,
        )


class _ThinMorManifest:
    def __init__(self, entries: List[_ThinMorManifestEntry]):
        self.entries = entries
        total_records = sum(entry.meta.record_count or 0 for entry in entries)
        total_bytes = sum(entry.meta.content_length or 0 for entry in entries)
        total_source_bytes = sum(
            entry.meta.source_content_length or 0 for entry in entries
        )
        content_type = entries[0].meta.content_type if entries else "parquet"
        content_encoding = entries[0].meta.content_encoding if entries else "identity"
        self.meta = _ThinMorMeta(
            record_count=total_records,
            content_length=total_bytes,
            source_content_length=total_source_bytes,
            content_type=content_type,
            content_encoding=content_encoding,
        )
        self.author = None


class _ThinMorPartitionLocator:
    def __init__(
        self,
        *,
        partition_values: Optional[Any],
        partition_id: Optional[str],
        stream_id: Optional[str],
    ):
        self.partition_values = partition_values
        self.partition_id = partition_id
        self.stream_id = stream_id

    def __eq__(self, other: Any) -> bool:
        return (
            isinstance(other, _ThinMorPartitionLocator)
            and self.partition_values == other.partition_values
            and self.partition_id == other.partition_id
            and self.stream_id == other.stream_id
        )


class _ThinMorDeltaLocator:
    def __init__(
        self, partition_locator: _ThinMorPartitionLocator, stream_position: int
    ):
        self.partition_locator = partition_locator
        self.stream_position = stream_position

    def __eq__(self, other: Any) -> bool:
        return (
            isinstance(other, _ThinMorDeltaLocator)
            and self.partition_locator == other.partition_locator
            and self.stream_position == other.stream_position
        )


class _ThinMorDelta(dict):
    @classmethod
    def from_scan_task(cls, scan_task: IOScanTask):
        delta_type = _ThinMorDeltaType(str(scan_task.delta_type or "append"))
        entry_params = _ThinMorEntryParams.from_any(scan_task.entry_params)
        entries = [
            _ThinMorManifestEntry(file_info=file_info) for file_info in scan_task.files
        ]
        manifest = _ThinMorManifest(entries)
        meta = _ThinMorMeta(
            record_count=manifest.meta.record_count,
            content_length=manifest.meta.content_length,
            source_content_length=manifest.meta.source_content_length,
            content_type=manifest.meta.content_type,
            content_encoding=manifest.meta.content_encoding,
            entry_params=entry_params,
        )
        partition_locator = _ThinMorPartitionLocator(
            partition_values=scan_task.partition_values,
            partition_id=scan_task.partition_id,
            stream_id=scan_task.stream_id,
        )
        locator = _ThinMorDeltaLocator(
            partition_locator=partition_locator,
            stream_position=int(scan_task.stream_position or 0),
        )
        delta = cls()
        delta["type"] = delta_type
        delta["manifest"] = manifest
        delta["meta"] = meta
        delta["locator"] = locator
        delta["stream_position"] = int(scan_task.stream_position or 0)
        delta["previous_stream_position"] = scan_task.previous_stream_position
        delta["scan_task"] = scan_task
        return delta

    @property
    def type(self):
        return self["type"]

    @type.setter
    def type(self, value):
        self["type"] = value

    @property
    def manifest(self):
        return self["manifest"]

    @manifest.setter
    def manifest(self, value):
        self["manifest"] = value

    @property
    def meta(self):
        return self["meta"]

    @meta.setter
    def meta(self, value):
        self["meta"] = value

    @property
    def locator(self):
        return self["locator"]

    @locator.setter
    def locator(self, value):
        self["locator"] = value

    @property
    def partition_locator(self):
        return self.locator.partition_locator

    @property
    def stream_position(self):
        return self["stream_position"]

    @property
    def previous_stream_position(self):
        return self.get("previous_stream_position")

    @property
    def scan_task(self) -> IOScanTask:
        return self["scan_task"]


class _ThinMorAnnotatedDelta(_ThinMorDelta):
    @classmethod
    def of(cls, delta: _ThinMorDelta):
        return shared_annotated_delta_of(
            delta,
            delta_annotated_factory=cls,
            delta_annotation_factory=SharedDeltaAnnotation,
        )

    @property
    def annotations(self):
        return self["annotations"]

    @annotations.setter
    def annotations(self, value):
        self["annotations"] = value


def _compute_arrow_table_column_stats(table: Any) -> Optional[dict[str, Any]]:
    pa = require_pyarrow("column stats computation")
    import pyarrow.compute as pc

    if table.num_rows == 0:
        return None

    stats: dict[str, Any] = {}
    for i in range(table.num_columns):
        field = table.schema.field(i)
        if not (
            pa.types.is_primitive(field.type)
            or pa.types.is_string(field.type)
            or pa.types.is_large_string(field.type)
            or pa.types.is_binary(field.type)
            or pa.types.is_large_binary(field.type)
            or pa.types.is_decimal(field.type)
            or pa.types.is_date(field.type)
            or pa.types.is_timestamp(field.type)
            or pa.types.is_time(field.type)
            or pa.types.is_duration(field.type)
        ):
            continue

        column = table.column(i)
        null_count = column.null_count
        if null_count == len(column):
            stats[field.name] = {"null_count": null_count}
            continue

        try:
            min_val = _metadata_value_to_serializable(pc.min(column).as_py())
            max_val = _metadata_value_to_serializable(pc.max(column).as_py())
            stats[field.name] = {
                "min": min_val,
                "max": max_val,
                "null_count": null_count,
            }
        except Exception:
            logger.debug(
                "Falling back to null_count-only column stats for field %s",
                field.name,
                exc_info=True,
            )
            stats[field.name] = {"null_count": null_count}
    return stats or None


def _metadata_value_to_serializable(value: Any) -> Any:
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def _sort_arrow_table_for_write(table: Any, *, sort_scheme: Any, merge_keys: Any):
    if table is None or getattr(table, "num_rows", 0) <= 1:
        return table
    if not sort_scheme:
        return table

    keys = (
        sort_scheme.get("keys")
        if isinstance(sort_scheme, dict)
        else getattr(sort_scheme, "keys", None)
    )
    if not keys:
        return table

    sort_keys: list[tuple[str, str]] = []
    seen_columns: set[str] = set()
    for key_spec in keys:
        columns = (
            key_spec.get("key")
            if isinstance(key_spec, dict)
            else getattr(key_spec, "key", None)
        ) or []
        order = (
            key_spec.get("sort_order")
            if isinstance(key_spec, dict)
            else getattr(key_spec, "sort_order", None)
        ) or "ascending"
        normalized_order = str(order).lower()
        normalized_order = (
            "descending" if normalized_order.startswith("desc") else "ascending"
        )
        for column_name in columns:
            if column_name not in seen_columns:
                sort_keys.append((column_name, normalized_order))
                seen_columns.add(column_name)

    for merge_key in merge_keys or []:
        if merge_key not in seen_columns:
            sort_keys.append((merge_key, "ascending"))
            seen_columns.add(merge_key)

    if not sort_keys:
        return table
    return table.sort_by(sort_keys)


def _validate_pyarrow_schema_nullability(table: Any) -> None:
    violations = []
    for field in table.schema:
        if not field.nullable and table.column(field.name).null_count > 0:
            violations.append(
                f"  - Column '{field.name}' is NOT NULL but contains "
                f"{table.column(field.name).null_count} null value(s)"
            )
    if violations:
        raise SchemaNullabilityError(
            "Schema/data nullability mismatch will cause corrupt Parquet files.\n"
            "PyArrow silently creates corrupt files when writing nulls to non-nullable columns,\n"
            "resulting in 'Unexpected end of stream' errors on read.\n\n"
            "Violations found:\n"
            + "\n".join(violations)
            + "\n\nTo fix: Either make these fields nullable in the schema, "
            "or ensure the data contains no nulls for these fields."
        )


def coerce_arrow_table_for_write(
    table: Any,
    *,
    schema_serialized: Optional[str],
    schema_info: Optional[Any],
    schema_evolution_mode: Optional[str],
    schema_consistency_type: Optional[str],
):
    return coerce_table_for_write(
        table,
        schema_serialized=schema_serialized,
        schema_info=schema_info,
        schema_evolution_mode=schema_evolution_mode,
        schema_consistency_type=schema_consistency_type,
    )


def manifest_scan_tasks_to_table(scan_tasks: Sequence[Any]):
    pa = require_pyarrow("schemaless manifest table flattening")

    flattened_entries = []
    for task in coerce_scan_tasks(scan_tasks):
        for file_info in task.files:
            flattened_entries.append((file_info, task))

    if not flattened_entries:
        return pa.table({})

    num_entries = len(flattened_entries)
    path_values = [None] * num_entries
    id_values = [None] * num_entries
    mandatory_values = [None] * num_entries
    meta_record_count = [None] * num_entries
    meta_content_length = [None] * num_entries
    meta_source_content_length = [None] * num_entries
    meta_content_type = [None] * num_entries
    meta_content_encoding = [None] * num_entries
    author_name_values = [None] * num_entries
    author_version_values = [None] * num_entries
    stream_position_values = [None] * num_entries
    previous_stream_position_values = [None] * num_entries
    additional_meta_fields: Dict[str, List[Any]] = {}

    excluded_meta_keys = {
        "path",
        "id",
        "mandatory",
        "record_count",
        "content_length",
        "source_content_length",
        "content_type",
        "content_encoding",
        "entry_type",
        "column_stats",
    }

    for idx, (file_data, task_data) in enumerate(flattened_entries):
        path_values[idx] = file_data.path
        id_values[idx] = file_data.entry_id
        mandatory_values[idx] = file_data.mandatory
        meta_record_count[idx] = file_data.record_count
        meta_content_length[idx] = file_data.content_length
        meta_source_content_length[idx] = file_data.source_content_length
        meta_content_type[idx] = file_data.content_type
        meta_content_encoding[idx] = file_data.content_encoding
        author_name_values[idx] = task_data.author_name
        author_version_values[idx] = task_data.author_version
        stream_position_values[idx] = task_data.stream_position
        previous_stream_position_values[idx] = task_data.previous_stream_position

        for meta_key, meta_value in file_data.to_dict().items():
            if meta_key in excluded_meta_keys:
                continue
            if meta_value is None:
                continue
            field_name = f"meta_{meta_key}"
            if field_name not in additional_meta_fields:
                additional_meta_fields[field_name] = [None] * num_entries
            additional_meta_fields[field_name][idx] = meta_value

    arrays_dict = {
        "id": pa.array(id_values),
        "mandatory": pa.array(mandatory_values),
        "meta_content_encoding": pa.array(meta_content_encoding),
        "meta_content_length": pa.array(meta_content_length),
        "meta_content_type": pa.array(meta_content_type),
        "meta_record_count": pa.array(meta_record_count),
        "meta_source_content_length": pa.array(meta_source_content_length),
        "path": pa.array(path_values),
    }

    for field_name, field_values in additional_meta_fields.items():
        arrays_dict[field_name] = pa.array(field_values)

    if any(value is not None for value in author_name_values):
        arrays_dict["author_name"] = pa.array(author_name_values)
    if any(value is not None for value in author_version_values):
        arrays_dict["author_version"] = pa.array(author_version_values)
    if any(value is not None for value in stream_position_values):
        arrays_dict["stream_position"] = pa.array(stream_position_values)
    if any(value is not None for value in previous_stream_position_values):
        arrays_dict["previous_stream_position"] = pa.array(
            previous_stream_position_values
        )

    return pa.table(arrays_dict)


def _manifest_table_input_to_pyarrow(manifest_table: Any):
    pa = require_pyarrow("manifest table materialization")
    if isinstance(manifest_table, pa.Table):
        return manifest_table

    pd = optional_import("pandas")
    if pd is not None and isinstance(manifest_table, pd.DataFrame):
        return pa.Table.from_pandas(manifest_table, preserve_index=False)

    pl = optional_import("polars")
    if pl is not None and isinstance(manifest_table, pl.DataFrame):
        return manifest_table.to_arrow()

    daft_mod = optional_import("daft")
    if daft_mod is not None and isinstance(manifest_table, daft_mod.DataFrame):
        return manifest_table.to_arrow()

    ray_dataset_mod = optional_import("ray.data.dataset")
    if ray_dataset_mod is not None and isinstance(
        manifest_table, getattr(ray_dataset_mod, "Dataset")
    ):
        if pd is None:
            pd = require_module(
                "pandas",
                feature="manifest table materialization",
                extra="pandas",
                package_name="pandas",
            )
        return pa.Table.from_pandas(manifest_table.to_pandas(), preserve_index=False)

    raise TypeError(
        "Unsupported manifest_table input type. Expected a PyArrow table, "
        "Pandas DataFrame, Polars DataFrame, Daft DataFrame, or Ray Dataset."
    )


def build_read_plan_from_manifest_table(
    manifest_table: Any,
    *,
    schema: Optional[Any] = None,
    path_resolver: Optional[Any] = None,
) -> Dict[str, Any]:
    manifest_arrow = _manifest_table_input_to_pyarrow(manifest_table)
    rows = manifest_arrow.to_pylist()
    files: List[IODataFile] = []
    content_types = set()

    for row in rows:
        manifest_row = ManifestTableRow.from_any(row)
        file_info = manifest_row.to_file()
        if path_resolver is not None:
            file_info.path = path_resolver(file_info.path)
        files.append(file_info)
        content_types.add(file_info.content_type)

    if len(content_types) == 1:
        plan_content_type = next(iter(content_types))
    elif len(content_types) > 1:
        plan_content_type = "mixed"
    else:
        plan_content_type = "parquet"

    return {
        "schema": [],
        "schema_serialized": encode_arrow_schema(schema),
        "content_type": plan_content_type,
        "scan_tasks": [{"files": [file_info.to_dict() for file_info in files]}]
        if files
        else [],
        "total_files": len(files),
        "returned_files": len(files),
        "total_records": sum(file_info.record_count for file_info in files),
        "total_bytes": sum(file_info.content_length for file_info in files),
        "requires_mor": False,
        "truncated": False,
    }


def materialize_manifest_table(
    manifest_table: Any,
    *,
    read_as: str = "pyarrow",
    schema: Optional[Any] = None,
    columns: Optional[List[str]] = None,
    file_path_column: Optional[str] = None,
    path_resolver: Optional[Any] = None,
):
    normalized_read_as = str(read_as or "pyarrow").lower()
    execution_read_as = (
        "pyarrow" if normalized_read_as in {"daft", "ray_dataset"} else read_as
    )
    result = execute_read_plan(
        build_read_plan_from_manifest_table(
            manifest_table,
            schema=schema,
            path_resolver=path_resolver,
        ),
        read_as=execution_read_as,
        columns=columns,
        file_path_column=file_path_column,
        prefer_lazy_polars=True,
    )
    if normalized_read_as in {"daft", "ray_dataset"}:
        return convert_table_output(
            result,
            read_as=read_as,
            feature="from_manifest_table(...)",
        )
    return result


def execute_read_plan(
    plan: Any,
    *,
    table: Optional[str] = None,
    namespace: Optional[str] = None,
    table_version: Optional[str] = None,
    catalog: Optional[str] = None,
    read_as: str = "pyarrow",
    row_filter: Optional[Any] = None,
    columns: Optional[List[str]] = None,
    file_path_column: Optional[str] = None,
    prefer_lazy_polars: bool = False,
):
    pa = require_pyarrow("client.catalog.read(...)")
    normalized_read_as = str(read_as or "pyarrow").lower()
    supported_read_as = {
        "pyarrow",
        "pandas",
        "polars",
        "numpy",
        "lance",
        "daft",
        "ray_dataset",
        "pyarrow_parquet",
    }
    if normalized_read_as not in supported_read_as:
        raise ValueError(
            f"Unsupported read_as value {read_as!r}. Expected one of {sorted(supported_read_as)}."
        )

    def _plan_get(key: str, default=None):
        if isinstance(plan, dict):
            return plan.get(key, default)
        return getattr(plan, key, default)

    def _plan_scan_tasks():
        return coerce_scan_tasks(_plan_get("scan_tasks", []) or [])

    def _plan_all_files():
        if hasattr(plan, "all_files"):
            return [IODataFile.from_any(file_info) for file_info in plan.all_files()]
        files = []
        for task in _plan_scan_tasks():
            files.extend(task.files)
        return files

    def _file_attr(file_info, key):
        if isinstance(file_info, IODataFile):
            if key == "id":
                return file_info.entry_id
            if hasattr(file_info, key):
                return getattr(file_info, key)
            return file_info.raw.get(key)
        if isinstance(file_info, dict):
            return file_info.get(key)
        if hasattr(file_info, key):
            return getattr(file_info, key)
        raw = getattr(file_info, "raw", None)
        if isinstance(raw, dict):
            return raw.get(key)
        return None

    def _is_schemaless_plan() -> bool:
        return _plan_get("schema") is None and _plan_get("schema_serialized") is None

    def _matching_data_root(path: str) -> Optional[Dict[str, Any]]:
        data_roots = _plan_get("data_roots") or {}
        matches = []
        for info in data_roots.values():
            root = (
                info.get("root")
                if isinstance(info, dict)
                else getattr(info, "root", None)
            )
            if root and str(path).startswith(str(root)):
                matches.append((len(str(root)), info))
        if not matches:
            return None
        matches.sort(key=lambda item: item[0], reverse=True)
        return matches[0][1]

    def _credentials_for_path(
        path: str,
    ) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]]]:
        creds_map = _plan_get("credentials") or {}
        data_root = _matching_data_root(path)
        endpoint_url = (
            data_root.get("endpoint_url")
            if isinstance(data_root, dict)
            else getattr(data_root, "endpoint_url", None)
        )
        if endpoint_url and endpoint_url in creds_map:
            return creds_map[endpoint_url], data_root
        if str(path).startswith("s3://") and "default" in creds_map:
            return creds_map["default"], data_root
        return None, data_root

    def _filesystem_path(path: str) -> str:
        parsed = urllib.parse.urlparse(path)
        if parsed.scheme == "s3":
            return f"{parsed.netloc}{parsed.path}"
        return path

    def _s3_filesystem_for_path(path: str):
        _raise_for_unsupported_remote_path(
            path,
            operation="client.catalog.read(...)",
        )
        if not str(path).startswith("s3://"):
            return None, path
        creds, data_root = _credentials_for_path(path)
        endpoint_url = (
            data_root.get("endpoint_url")
            if isinstance(data_root, dict)
            else getattr(data_root, "endpoint_url", None)
        )
        region = (
            data_root.get("region")
            if isinstance(data_root, dict)
            else getattr(data_root, "region", None)
        )
        if region is None:
            region = infer_s3_express_region(path)
        if not creds and not endpoint_url and not region:
            return None, path
        fs_kwargs: Dict[str, Any] = {}
        if creds:
            if creds.get("access_key_id"):
                fs_kwargs["access_key"] = creds["access_key_id"]
            if creds.get("secret_access_key"):
                fs_kwargs["secret_key"] = creds["secret_access_key"]
            if creds.get("session_token"):
                fs_kwargs["session_token"] = creds["session_token"]
        if endpoint_url:
            fs_kwargs["endpoint_override"] = endpoint_url
        if region:
            fs_kwargs["region"] = region
        return pa.fs.S3FileSystem(**fs_kwargs), _filesystem_path(path)

    def _lance_storage_options_for_path(path: str) -> Optional[Dict[str, Any]]:
        _raise_for_unsupported_remote_path(
            path,
            operation="client.catalog.read(...)",
        )
        if not str(path).startswith("s3://"):
            return None
        creds, data_root = _credentials_for_path(path)
        endpoint_url = (
            data_root.get("endpoint_url")
            if isinstance(data_root, dict)
            else getattr(data_root, "endpoint_url", None)
        )
        region = (
            data_root.get("region")
            if isinstance(data_root, dict)
            else getattr(data_root, "region", None)
        )
        if region is None:
            region = infer_s3_express_region(path)
        return normalize_lance_storage_options(
            storage_options_from_filesystem(
                None,
                endpoint_url=endpoint_url,
                region=region,
                credentials=creds,
            )
        )

    def _polars_storage_options_for_path(path: str) -> Optional[Dict[str, Any]]:
        _raise_for_unsupported_remote_path(
            path,
            operation="client.catalog.read(...)",
        )
        if not str(path).startswith("s3://"):
            return None
        creds, data_root = _credentials_for_path(path)
        endpoint_url = (
            data_root.get("endpoint_url")
            if isinstance(data_root, dict)
            else getattr(data_root, "endpoint_url", None)
        )
        region = (
            data_root.get("region")
            if isinstance(data_root, dict)
            else getattr(data_root, "region", None)
        )
        if region is None:
            region = infer_s3_express_region(path)
        # Keep custom S3-compatible endpoints on the eager/shared path until we
        # can prove the exact Polars/object_store key contract for endpoint routing.
        if endpoint_url:
            return None
        options: Dict[str, Any] = {}
        if creds:
            if creds.get("access_key_id"):
                options["aws_access_key_id"] = creds["access_key_id"]
            if creds.get("secret_access_key"):
                options["aws_secret_access_key"] = creds["secret_access_key"]
            if creds.get("session_token"):
                options["aws_session_token"] = creds["session_token"]
        if region:
            options["aws_region"] = region
        return options or None

    def _read_parquet_table(
        path: str,
        columns: Optional[List[str]] = None,
        filters: Optional[Any] = None,
    ):
        pq = require_pyarrow_parquet("client.catalog.read(...)")
        filesystem, fs_path = _s3_filesystem_for_path(path)
        if filesystem is not None:
            return pq.read_table(
                fs_path,
                filesystem=filesystem,
                columns=columns,
                filters=filters,
            )
        return pq.read_table(path, columns=columns, filters=filters)

    def _open_parquet_file(path: str):
        pq = require_pyarrow_parquet("client.catalog.read(...)")
        filesystem, fs_path = _s3_filesystem_for_path(path)
        if filesystem is not None:
            return pq.ParquetFile(fs_path, filesystem=filesystem)
        return pq.ParquetFile(path)

    def _open_input_source(path: str):
        filesystem, fs_path = _s3_filesystem_for_path(path)
        if filesystem is not None:
            return filesystem.open_input_file(fs_path)
        return path

    def _open_lance_dataset(path: str):
        lance = require_lance("client.catalog.read(...)")
        storage_options = _lance_storage_options_for_path(path)
        if storage_options:
            return lance.dataset(path, storage_options=storage_options)
        return lance.dataset(path)

    def _parse_type(type_name: Optional[str]):
        if not type_name:
            return None
        try:
            return pa.type_for_alias(type_name)
        except Exception:
            logger.debug(
                "Could not parse Arrow type alias %r", type_name, exc_info=True
            )
            return None

    def _target_schema_has_past_defaults() -> bool:
        return schema_has_past_defaults(
            _plan_get("schema") or [],
            arrow_schema=decode_arrow_schema(_plan_get("schema_serialized")),
        )

    def _schema_fields_from_arrow_schema(
        arrow_schema: Optional[Any],
    ) -> List[Dict[str, Any]]:
        if arrow_schema is None:
            return []
        return [
            {
                "name": field.name,
                "type": field.type,
            }
            for field in arrow_schema
        ]

    def _schema_fields_from_summary(
        schema_summary: Optional[List[Dict[str, Any]]]
    ) -> List[Dict[str, Any]]:
        if not schema_summary:
            return []
        return [
            {
                "name": field["name"],
                "type": _parse_type(field.get("type")),
            }
            for field in schema_summary
            if field.get("name")
        ]

    def _target_schema_fields():
        serialized = _plan_get("schema_serialized")
        decoded = decode_arrow_schema(serialized)
        if decoded is not None:
            return schema_fields_from_summary(
                _plan_get("schema") or [], arrow_schema=decoded
            )
        return schema_fields_from_summary(_plan_get("schema") or [])

    def _reader_column_names() -> Optional[List[str]]:
        explicit_reader_column_names = _plan_get("reader_column_names", "__missing__")
        if explicit_reader_column_names != "__missing__":
            if explicit_reader_column_names is None:
                return None
            return list(explicit_reader_column_names)
        target_fields = _target_schema_fields()
        if not target_fields:
            return None
        return [field["name"] for field in target_fields if field.get("name")]

    def _mor_all_column_names() -> List[str]:
        return _reader_column_names() or [
            field["name"] for field in _target_schema_fields()
        ]

    def _mor_sort_keys_from_payload(
        payload: Optional[Any],
    ) -> Optional[List[_ThinMorSortKey]]:
        if not payload:
            return None
        return [
            _ThinMorSortKey(
                key=entry.get("key")
                if isinstance(entry, dict)
                else getattr(entry, "key", None),
                sort_order=entry.get("sort_order")
                if isinstance(entry, dict)
                else getattr(entry, "sort_order", None),
            )
            for entry in payload
        ]

    def _mor_sort_scheme_from_payload(
        payload: Optional[Any],
    ) -> Optional[_ThinMorSortScheme]:
        if not payload:
            return None
        keys = (
            payload.get("keys")
            if isinstance(payload, dict)
            else getattr(payload, "keys", None)
        )
        scheme_id = (
            payload.get("id")
            if isinstance(payload, dict)
            else getattr(payload, "id", None)
        )
        return _ThinMorSortScheme(
            _mor_sort_keys_from_payload(keys) or [], scheme_id=scheme_id
        )

    class _ThinMorStorage:
        def download_delta(
            self,
            delta_like: _ThinMorDelta,
            file_reader_kwargs_provider=None,
            columns: Optional[List[str]] = None,
            storage_type=None,
            max_parallelism: int = 1,
            all_column_names: Optional[List[str]] = None,
            **kwargs,
        ):
            del file_reader_kwargs_provider, storage_type, max_parallelism, kwargs
            tables = []
            for file_info in delta_like.scan_task.files:
                path = file_info.path
                filesystem, fs_path = _s3_filesystem_for_path(path)
                read_kwargs = {}
                columns_for_file = _read_columns_for_file(file_info)
                if columns_for_file is not None:
                    read_kwargs["include_columns"] = columns_for_file
                if normalized_read_as not in {"ray_dataset", "daft"}:
                    pushdown_filter = _pushdown_filter_for_file(file_info)
                    if pushdown_filter is not None:
                        read_kwargs["filter"] = pushdown_filter
                table_result = pyarrow_file_to_table(
                    fs_path if filesystem is not None else path,
                    str(file_info.content_type or "parquet"),
                    content_encoding=str(file_info.content_encoding or "identity"),
                    filesystem=filesystem,
                    **read_kwargs,
                )
                tables.append(table_result)
            return tables

    def _mor_read_delta_file_envelopes(
        annotated_delta: _ThinMorAnnotatedDelta,
        *,
        all_column_names: Optional[List[str]],
        read_kwargs_provider,
        deltacat_storage,
        deltacat_storage_kwargs,
    ):
        return shared_read_delta_file_envelopes(
            annotated_delta,
            all_column_names=all_column_names,
            read_kwargs_provider=read_kwargs_provider,
            deltacat_storage=deltacat_storage,
            deltacat_storage_kwargs=deltacat_storage_kwargs,
            storage_type_local="local",
            concat_tables_fn=pa.concat_tables,
            delta_file_envelope_factory=DeltaFileEnvelope.of,
        )

    def _mor_build_incremental_table(df_envelopes):
        return shared_build_incremental_table(
            df_envelopes,
            add_delta_type_column_fn=lambda table_result, value: shared_append_delta_type_column(
                table_result,
                value,
                delta_type_column_field=sc._DELTA_TYPE_COLUMN_FIELD,
                delta_type_column_type=sc._DELTA_TYPE_COLUMN_TYPE,
            ),
            concat_or_coerce_tables_fn=shared_concat_or_coerce_tables,
            delete_delta_type=_ThinMorDeltaType.DELETE,
            add_delta_type=_ThinMorDeltaType.ADD,
            append_delta_type=_ThinMorDeltaType.APPEND,
            upsert_delta_type=_ThinMorDeltaType.UPSERT,
            delta_type_to_field_fn=sc.delta_type_to_field,
            partition_stream_position_column_name=sc._PARTITION_STREAM_POSITION_COLUMN_NAME,
        )

    def _mor_merge_records_partially(old_records, new_records, original_fields):
        return shared_merge_records_partially(
            old_records,
            new_records,
            original_fields,
            pk_hash_string_column_name=sc._PK_HASH_STRING_COLUMN_NAME,
            partition_stream_position_column_name=sc._PARTITION_STREAM_POSITION_COLUMN_NAME,
            delta_type_column_name=sc._DELTA_TYPE_COLUMN_NAME,
        )

    def _mor_merge_tables(
        table,
        primary_keys,
        can_drop_duplicates,
        hb_index,
        num_buckets,
        original_fields,
        compacted_table=None,
    ):
        return shared_merge_tables(
            table,
            primary_keys,
            can_drop_duplicates,
            hb_index,
            num_buckets,
            original_fields,
            compacted_table=compacted_table,
            partition_stream_position_column_name=sc._PARTITION_STREAM_POSITION_COLUMN_NAME,
            pk_hash_string_column_name=sc._PK_HASH_STRING_COLUMN_NAME,
            delta_type_delete=_ThinMorDeltaType.DELETE,
            concat_or_coerce_tables_fn=shared_concat_or_coerce_tables,
            drop_delta_type_rows_fn=lambda tbl, delta_type: shared_drop_delta_type_rows(
                tbl,
                delta_type,
                delta_type_column_name=sc._DELTA_TYPE_COLUMN_NAME,
                delta_type_to_field_fn=sc.delta_type_to_field,
            ),
            generate_pk_hash_column_fn=generate_pk_hash_column,
            drop_duplicates_fn=chunk_drop_duplicates,
            validate_bucketing_spec_compliance_fn=lambda *args, **kwargs: None,
            check_bucketing_spec=False,
            incremental_table_log_prefix="Incremental table ",
            merge_records_partially_fn=_mor_merge_records_partially,
            max_int_bytes=2_147_483_647,
            log_info_fn=logger.info,
        )

    def _execute_direct_mor_plan(active_plan: Any):
        mor_plan = _plan_get("mor_plan") or {}
        mor_scan_tasks = coerce_scan_tasks(
            mor_plan.get("scan_tasks") or _plan_scan_tasks()
        )
        if not mor_scan_tasks:
            return convert_table_output(
                _finalize_result_table(_empty_aligned_table()),
                read_as=read_as,
                feature="client.catalog.read(...)",
            )

        all_column_names = _mor_all_column_names()
        primary_keys = list(_plan_get("merge_keys") or [])
        sort_keys = _mor_sort_keys_from_payload(mor_plan.get("sort_keys"))
        output_sort_scheme = _mor_sort_scheme_from_payload(_plan_get("sort_scheme"))
        original_fields = set(all_column_names)

        deltas = [_ThinMorDelta.from_scan_task(task) for task in mor_scan_tasks]
        storage_adapter = _ThinMorStorage()

        delete_strategy = None
        delete_file_envelopes = None
        input_deltas = list(deltas)
        if any(delta.type is _ThinMorDeltaType.DELETE for delta in input_deltas):
            prepared = shared_prepare_deletes(
                SimpleNamespace(
                    deltacat_storage=storage_adapter,
                    deltacat_storage_kwargs={},
                    read_kwargs_provider=None,
                ),
                input_deltas,
                delete_delta_type=_ThinMorDeltaType.DELETE,
                aggregate_delete_deltas_fn=lambda ds: shared_aggregate_delete_deltas(
                    ds,
                    delete_delta_type=_ThinMorDeltaType.DELETE,
                ),
                get_delete_file_envelopes_fn=lambda params, grouped: shared_get_delete_file_envelopes(
                    params,
                    grouped,
                    local_storage_type="local",
                    concat_tables_fn=pa.concat_tables,
                    delete_file_envelope_factory=DeleteFileEnvelope,
                ),
                prepare_delete_result_factory=PrepareDeleteResult,
                equality_delete_strategy_factory=EqualityDeleteStrategy,
            )
            input_deltas = prepared.non_delete_deltas
            delete_file_envelopes = prepared.delete_file_envelopes
            delete_strategy = prepared.delete_strategy

        annotated_deltas = [_ThinMorAnnotatedDelta.of(delta) for delta in input_deltas]
        local_dfe_list, _ = shared_get_local_delta_file_envelopes(
            annotated_deltas,
            all_column_names=all_column_names,
            read_kwargs_provider=None,
            deltacat_storage=storage_adapter,
            deltacat_storage_kwargs={},
            read_delta_file_envelopes_fn=_mor_read_delta_file_envelopes,
            monotonic_time_fn=time.monotonic,
            log_info_fn=logger.info,
        )
        dfe_groups = [local_dfe_list] if local_dfe_list else None

        merge_input = MergeInput.of(
            merge_file_groups_provider=SimpleNamespace(hash_group_index=0),
            write_to_partition=None,
            compacted_file_content_type="parquet",
            primary_keys=primary_keys,
            all_column_names=all_column_names,
            drop_duplicates=True,
            sort_keys=sort_keys,
            merge_task_index=0,
            max_records_per_output_file=None,
            enable_profiler=False,
            metrics_config=None,
            table_writer_kwargs={},
            read_kwargs_provider=None,
            round_completion_info=None,
            object_store=None,
            delete_strategy=delete_strategy,
            delete_file_envelopes=delete_file_envelopes,
            deltacat_storage=storage_adapter,
            deltacat_storage_kwargs={},
            memory_logs_enabled=False,
            disable_copy_by_reference=True,
            hash_bucket_count=int(mor_plan.get("hash_bucket_count") or 1),
            original_fields=original_fields,
            compacted_manifest=None,
            output_sort_scheme=output_sort_scheme,
        )

        result_table, _, _, _ = shared_execute_compact_tables(
            merge_input,
            dfe_groups,
            0,
            compacted_table=None,
            flatten_dfe_list_fn=shared_flatten_dfe_list,
            sort_df_envelopes_fn=shared_sort_df_envelopes,
            group_sequence_by_delta_type_fn=shared_group_sequence_by_delta_type,
            apply_upserts_fn=lambda input, dfe_list, hb_idx, prev_table=None: shared_execute_apply_upserts(
                input,
                dfe_list,
                hb_idx,
                prev_table=prev_table,
                build_incremental_table_fn=_mor_build_incremental_table,
                timed_invocation_fn=timed_invocation,
                merge_tables_fn=_mor_merge_tables,
                partition_stream_position_column_name=sc._PARTITION_STREAM_POSITION_COLUMN_NAME,
                coerce_output_sort_scheme_fn=lambda scheme: scheme,
                log_info_fn=logger.info,
            ),
            timed_invocation_fn=timed_invocation,
            add_delta_type=_ThinMorDeltaType.ADD,
            append_delta_type=_ThinMorDeltaType.APPEND,
            upsert_delta_type=_ThinMorDeltaType.UPSERT,
            delete_delta_type=_ThinMorDeltaType.DELETE,
            log_info_fn=logger.info,
        )
        arrow_table = result_table if result_table is not None else pa.table({})
        if normalized_read_as in {"ray_dataset", "daft"}:
            return convert_table_output(
                arrow_table,
                read_as=read_as,
                feature="client.catalog.read(...)",
            )
        return convert_table_output(
            _finalize_result_table(arrow_table),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )

    def _empty_aligned_table() -> pa.Table:
        return _finalize_table(pa.table({}), "")

    def _collect_filter_fields(expr: Optional[Any]) -> Set[str]:
        if expr is None:
            return set()

        fields: Set[str] = set()
        field_name = getattr(expr, "field", None)
        if field_name:
            fields.add(field_name)

        for attr_name in (
            "left",
            "right",
            "operand",
            "value",
            "lower",
            "upper",
            "pattern",
        ):
            child = getattr(expr, attr_name, None)
            if child is not None:
                fields.update(_collect_filter_fields(child))

        values = getattr(expr, "values", None)
        if values:
            for value in values:
                fields.update(_collect_filter_fields(value))
        return fields

    filter_fields = _collect_filter_fields(row_filter)
    translated_pyarrow_filter = (
        translate_expression_to_pyarrow_filter(row_filter)
        if row_filter is not None
        else None
    )

    def _file_schema_fields(file_info: Any) -> Optional[List[Dict[str, Any]]]:
        schema_id = _file_attr(file_info, "schema_id")
        if schema_id is None:
            return None
        serialized_schemas_by_id = _plan_get("schemas_serialized_by_id") or {}
        serialized_schema = serialized_schemas_by_id.get(schema_id)
        if serialized_schema is None:
            serialized_schema = serialized_schemas_by_id.get(str(schema_id))
        decoded = decode_arrow_schema(serialized_schema)
        if decoded is not None:
            return _schema_fields_from_arrow_schema(decoded)
        schemas_by_id = _plan_get("schemas_by_id") or {}
        schema_summary = schemas_by_id.get(schema_id)
        if schema_summary is None:
            schema_summary = schemas_by_id.get(str(schema_id))
        return _schema_fields_from_summary(schema_summary) or None

    def _read_columns_for_file(file_info: Any) -> Optional[List[str]]:
        requested_columns = list(columns or [])
        required_columns = list(requested_columns)
        for field_name in filter_fields:
            if field_name not in required_columns:
                required_columns.append(field_name)
        if not required_columns:
            return None

        schema_fields = _file_schema_fields(file_info)
        if schema_fields is None:
            return None

        available_names = [field["name"] for field in schema_fields]
        available = set(available_names)
        if columns is None:
            return available_names
        selected = [name for name in required_columns if name in available]
        if selected:
            return selected
        if columns is None:
            return available_names
        return []

    def _pushdown_filter_for_file(file_info: Any):
        if translated_pyarrow_filter is None:
            return None
        if str(_file_attr(file_info, "content_type")) in LANCE_TYPES:
            return None

        schema_fields = _file_schema_fields(file_info)
        if schema_fields is None:
            return translated_pyarrow_filter

        available = {field["name"] for field in schema_fields}
        if filter_fields.issubset(available):
            return translated_pyarrow_filter
        return None

    def _read_file_to_table(file_info: Any) -> pa.Table:
        path = _file_attr(file_info, "path")
        content_type = str(_file_attr(file_info, "content_type"))
        filesystem, resolved_path = _s3_filesystem_for_path(path)
        read_kwargs = {}
        reader_column_names = _reader_column_names()
        if reader_column_names is not None:
            read_kwargs["column_names"] = reader_column_names
        columns_for_file = _read_columns_for_file(file_info)
        if columns_for_file is not None:
            read_kwargs["include_columns"] = columns_for_file
        pushdown_filter = _pushdown_filter_for_file(file_info)
        if pushdown_filter is not None:
            read_kwargs["filter"] = pushdown_filter
        return _finalize_table(
            pyarrow_file_to_table(
                resolved_path,
                content_type,
                content_encoding=str(
                    _file_attr(file_info, "content_encoding") or "identity"
                ),
                filesystem=filesystem,
                **read_kwargs,
            ),
            path,
        )

    def _prune_files_by_row_filter(files: List[Any]) -> List[Any]:
        if row_filter is None:
            return files

        if not any(_file_attr(file_info, "column_stats") for file_info in files):
            return files

        surviving = []
        for file_info in files:
            column_stats = _file_attr(file_info, "column_stats")
            if column_stats and not may_match_column_stats(row_filter, column_stats):
                continue
            surviving.append(file_info)
        return surviving

    def _order_files_by_sort_key(files: List[Any]) -> List[Any]:
        ordered_files, _ = _order_files_by_sort_key_with_flag(files)
        return ordered_files

    def _order_files_by_sort_key_with_flag(files: List[Any]) -> Tuple[List[Any], bool]:
        return order_items_by_primary_sort_key(
            files,
            _plan_get("sort_scheme"),
            get_sort_scheme_id=lambda file_info: _file_attr(
                file_info, "sort_scheme_id"
            ),
            get_column_stats=lambda file_info: _file_attr(file_info, "column_stats"),
            require_matching_scheme_id=True,
        )

    table = table or _plan_get("table")
    namespace = namespace or _plan_get("namespace")
    table_version = table_version or _plan_get("table_version")

    def _try_polars_lazy_scan(files: List[Any]):
        if not prefer_lazy_polars or normalized_read_as != "polars":
            return None
        if _target_schema_has_past_defaults():
            return None
        if any(
            str(_file_attr(file_info, "content_type")) not in PARQUET_TYPES
            for file_info in files
        ):
            return None
        candidate_files = _prune_files_by_row_filter(list(files))
        schema_ids = {
            str(schema_id)
            for schema_id in (
                _file_attr(file_info, "schema_id") for file_info in candidate_files
            )
            if schema_id is not None
        }
        polars_schema = None
        if len(schema_ids) > 1:
            target_fields = _target_schema_fields()
            if not target_fields or any(
                field.get("type") is None for field in target_fields
            ):
                return None
            polars_schema = {field["name"]: field["type"] for field in target_fields}
        return build_polars_lazy_scan(
            candidate_files,
            sort_scheme=_plan_get("sort_scheme"),
            row_filter=row_filter,
            columns=columns,
            file_path_column=file_path_column,
            polars_schema=polars_schema,
            storage_options_resolver=_polars_storage_options_for_path,
        )

    def _concat_or_empty(tables: List[pa.Table]):
        if not tables:
            return _empty_aligned_table()
        try:
            return pa.concat_tables(tables)
        except Exception:
            logger.debug(
                "Default Arrow table concat failed; retrying with permissive promotion.",
                exc_info=True,
            )
            try:
                return pa.concat_tables(tables, promote_options="permissive")
            except TypeError:
                logger.debug(
                    "Permissive Arrow concat signature unavailable; retrying with unify_schemas.",
                    exc_info=True,
                )
                return pa.concat_tables(tables, unify_schemas=True)

    def _with_file_path(table_result: pa.Table, path: str) -> pa.Table:
        if not file_path_column:
            return table_result
        if file_path_column in table_result.column_names:
            return table_result
        return table_result.append_column(
            file_path_column,
            pa.array([path] * table_result.num_rows, type=pa.string()),
        )

    def _project_columns(table_result: pa.Table) -> pa.Table:
        if columns is None:
            return table_result
        keep = [name for name in columns if name in table_result.column_names]
        if (
            file_path_column
            and file_path_column in table_result.column_names
            and file_path_column not in keep
        ):
            keep.append(file_path_column)
        return table_result.select(keep) if keep else table_result.select([])

    def _finalize_table(table_result: pa.Table, path: str) -> pa.Table:
        target_fields = _target_schema_fields()
        if target_fields:
            table_result = align_table_to_schema(
                table_result,
                target_fields,
                missing_default_key="past_default",
            )

        table_result = _with_file_path(table_result, path)
        return table_result

    def _finalize_result_table(table_result: pa.Table) -> pa.Table:
        return _project_columns(_apply_row_filter(table_result))

    def _apply_row_filter(table_result: pa.Table) -> pa.Table:
        if row_filter is None or table_result.num_rows == 0:
            return table_result
        pyarrow_expr = translate_expression_to_pyarrow_filter(row_filter)
        if pyarrow_expr is None:
            return table_result
        try:
            return table_result.filter(pyarrow_expr)
        except Exception:
            logger.warning(
                "Failed to apply requested row filter in shared read path.",
                exc_info=True,
            )
            raise

    def _read_schemaless_manifest_table():
        if normalized_read_as in {"lance", "pyarrow_parquet"}:
            raise ValueError(
                f"read_as={read_as!r} is not supported for schemaless tables. "
                "Schemaless reads return flattened manifest metadata; use "
                "'pyarrow', 'pandas', 'polars', 'numpy', 'daft', or 'ray_dataset'."
            )
        manifest_table = manifest_scan_tasks_to_table(_plan_scan_tasks())
        return convert_table_output(
            _finalize_result_table(manifest_table),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )

    def _raise_lazy_format_content_error(content_types: Set[str]) -> None:
        if normalized_read_as == "pyarrow_parquet":
            raise ValueError(
                "read_as='pyarrow_parquet' requires parquet-only content, "
                f"but the plan contains content types {sorted(content_types)}."
            )
        if normalized_read_as == "lance":
            raise ValueError(
                "read_as='lance' requires lance-only content, "
                f"but the plan contains content types {sorted(content_types)}."
            )

    def _raise_unsupported_content_type_error(content_type: str) -> None:
        raise NotImplementedError(
            f"client.catalog.read(...) does not support content type {content_type!r} "
            f"for read_as={read_as!r} in the shared execution path."
        )

    if not _plan_scan_tasks():
        if any(
            _plan_get(field) is not None
            for field in (
                "snapshot_id",
                "packds_uri",
                "episode_index",
                "shard_manifest",
                "available_recipes",
            )
        ):
            raise ValueError(
                "This plan is metadata-only (include_files=False) and cannot be "
                "executed as a data read. Use the metadata fields directly or "
                "request a plan with file enumeration enabled."
            )

    if _is_schemaless_plan():
        return _read_schemaless_manifest_table()

    if _plan_get("requires_mor", False):
        return _execute_direct_mor_plan(plan)
    if not _plan_scan_tasks():
        if normalized_read_as in {"pyarrow_parquet", "lance"}:
            return []
        return convert_table_output(
            _finalize_result_table(_empty_aligned_table()),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )

    lazy_read_as = normalized_read_as in {"lance", "pyarrow_parquet"}
    candidate_files = _plan_all_files()
    lazy_polars = _try_polars_lazy_scan(candidate_files)
    if lazy_polars is not None:
        return lazy_polars
    if not lazy_read_as:
        candidate_files = _prune_files_by_row_filter(candidate_files)
    all_files = _order_files_by_sort_key(candidate_files)
    if not all_files:
        if normalized_read_as in {"pyarrow_parquet", "lance"}:
            return []
        return convert_table_output(
            _finalize_result_table(_empty_aligned_table()),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )

    content_types = {str(_file_attr(f, "content_type")) for f in all_files}
    if len(content_types) != 1:
        if normalized_read_as in {"pyarrow_parquet", "lance"}:
            _raise_lazy_format_content_error(content_types)
        try:
            return convert_table_output(
                _finalize_result_table(
                    _concat_or_empty(
                        [_read_file_to_table(file_info) for file_info in all_files]
                    )
                ),
                read_as=read_as,
                feature="client.catalog.read(...)",
            )
        except NotImplementedError:
            raise

    content_type = next(iter(content_types))
    if normalized_read_as == "pyarrow_parquet" and content_type not in PARQUET_TYPES:
        _raise_lazy_format_content_error(content_types)
    if normalized_read_as == "lance" and content_type not in LANCE_TYPES:
        _raise_lazy_format_content_error(content_types)
    if content_type in PARQUET_TYPES:
        if normalized_read_as == "pyarrow_parquet":
            parquet_files = [
                _open_parquet_file(_file_attr(file_info, "path"))
                for file_info in all_files
            ]
            return parquet_files[0] if len(parquet_files) == 1 else parquet_files
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in CSV_TYPES | TSV_TYPES | PSV_TYPES | UNESCAPED_TSV_TYPES:
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in FEATHER_TYPES:
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in JSON_TYPES:
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in ORC_TYPES:
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in AVRO_TYPES:
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    if content_type in LANCE_TYPES:
        if str(read_as or "pyarrow").lower() == "lance":
            if file_path_column:
                materialized_tables = []
                for file_info in all_files:
                    path = _file_attr(file_info, "path")
                    dataset = _open_lance_dataset(path)
                    materialized_tables.append(
                        _with_file_path(dataset.to_table(), path)
                    )
                return (
                    materialized_tables[0]
                    if len(materialized_tables) == 1
                    else materialized_tables
                )
            datasets = [
                _open_lance_dataset(_file_attr(file_info, "path"))
                for file_info in all_files
            ]
            return datasets[0] if len(datasets) == 1 else datasets
        return convert_table_output(
            _finalize_result_table(
                _concat_or_empty(
                    [_read_file_to_table(file_info) for file_info in all_files]
                )
            ),
            read_as=read_as,
            feature="client.catalog.read(...)",
        )
    _raise_unsupported_content_type_error(content_type)


def coerce_write_input(
    data,
    *,
    schema_info: Optional[Any] = None,
) -> Tuple[Optional["object"], Optional[List[Union[str, os.PathLike]]]]:
    pa = optional_import("pyarrow")

    arrow_table = None
    if pa is not None and isinstance(data, pa.Table):
        arrow_table = data
    else:
        pd = optional_import("pandas")
        if pd is not None and isinstance(data, pd.DataFrame):
            if pa is None:
                pa = require_pyarrow("client.catalog.write(...) with pandas input")
            arrow_table = pa.Table.from_pandas(data, preserve_index=False)
        if arrow_table is None:
            pl = optional_import("polars")
            if pl is not None and isinstance(data, pl.DataFrame):
                arrow_table = data.to_arrow()
        if arrow_table is None:
            daft_mod = optional_import("daft")
            if daft_mod is not None and isinstance(data, daft_mod.DataFrame):
                arrow_table = data.to_arrow()
        if arrow_table is None:
            np = optional_import("numpy")
            if np is not None and isinstance(data, np.ndarray):
                if schema_info is None:
                    return None, None
                if pa is None:
                    pa = require_pyarrow("client.catalog.write(...) with NumPy input")
                field_names = [
                    field["name"] for field in (schema_info or []) if field.get("name")
                ]
                if data.ndim == 1:
                    column_name = field_names[0] if field_names else "0"
                    arrow_table = pa.table({column_name: data})
                elif data.ndim == 2:
                    column_names = (
                        field_names
                        if field_names and len(field_names) == data.shape[1]
                        else [str(idx) for idx in range(data.shape[1])]
                    )
                    arrow_table = pa.Table.from_pydict(
                        {
                            column_names[idx]: data[:, idx]
                            for idx in range(data.shape[1])
                        }
                    )
                else:
                    raise ValueError(
                        "client.catalog.write(...) NumPy input supports only 1D or 2D arrays."
                    )
        if arrow_table is None and hasattr(data, "to_arrow_refs"):
            if pa is None:
                pa = require_pyarrow("client.catalog.write(...) with Ray Dataset input")
            ray_mod = optional_import("ray")
            if ray_mod is not None:
                arrow_refs = data.to_arrow_refs()
                arrow_tables = ray_mod.get(arrow_refs)
                if len(arrow_tables) == 1:
                    arrow_table = arrow_tables[0]
                elif len(arrow_tables) > 1:
                    try:
                        arrow_table = pa.concat_tables(
                            arrow_tables,
                            promote_options="permissive",
                            unify_schemas=True,
                        )
                    except TypeError:
                        arrow_table = pa.concat_tables(
                            arrow_tables,
                            promote_options="permissive",
                        )

    if arrow_table is not None:
        return arrow_table, None

    if isinstance(data, (str, os.PathLike)):
        return None, [data]
    if (
        isinstance(data, Sequence)
        and data
        and all(isinstance(item, (str, os.PathLike)) for item in data)
    ):
        return None, list(data)
    return None, None


def build_entries_for_local_paths(
    paths: Sequence[Union[str, os.PathLike]],
    *,
    fmt: str,
    sort_column: Optional[str] = None,
) -> List[dict[str, Any]]:
    import pyarrow.fs as pafs

    pacsv = require_pyarrow_csv("client.catalog.write(...)")
    pq = require_pyarrow_parquet("client.catalog.write(...)")
    pa = require_pyarrow("client.catalog.write(...)")

    def _compute_table_column_stats(table: "pa.Table") -> Optional[dict[str, Any]]:
        return _compute_arrow_table_column_stats(table)

    def _compute_parquet_column_stats(
        path: str, filesystem=None
    ) -> Optional[dict[str, Any]]:
        parquet_file = pq.ParquetFile(path, filesystem=filesystem)
        metadata = parquet_file.metadata
        schema = parquet_file.schema_arrow
        stats: dict[str, Any] = {}
        for field_name in schema.names:
            column_idx = schema.get_field_index(field_name)
            min_val = None
            max_val = None
            null_count = 0
            saw_stats = False
            saw_min_max = False
            for i in range(metadata.num_row_groups):
                row_group_stats = metadata.row_group(i).column(column_idx).statistics
                if row_group_stats is None:
                    continue
                saw_stats = True
                null_count += row_group_stats.null_count or 0
                if row_group_stats.has_min_max:
                    rg_min = _metadata_value_to_serializable(row_group_stats.min)
                    rg_max = _metadata_value_to_serializable(row_group_stats.max)
                    try:
                        min_val = (
                            rg_min if min_val is None or rg_min < min_val else min_val
                        )
                        max_val = (
                            rg_max if max_val is None or rg_max > max_val else max_val
                        )
                        saw_min_max = True
                    except TypeError:
                        logger.debug(
                            "Could not compare Parquet row-group stats for field %s; keeping null_count only.",
                            field_name,
                            exc_info=True,
                        )
            if saw_stats:
                column_stats = {"null_count": null_count}
                if saw_min_max:
                    column_stats["min"] = min_val
                    column_stats["max"] = max_val
                stats[field_name] = column_stats
        return stats or None

    def _dir_size_bytes(path: str) -> int:
        total = 0
        for current_root, _dirs, files in os.walk(path):
            for file_name in files:
                total += os.path.getsize(posixpath.join(current_root, file_name))
        return total

    def _resolve_entry_path(path_str: str):
        _raise_for_unsupported_remote_path(
            path_str,
            operation="client.catalog.write(...)",
        )
        resolved_path, filesystem = resolve_path_and_filesystem(path_str)
        file_info = get_file_info(resolved_path, filesystem)
        return resolved_path, filesystem, file_info

    def _require_local_file(path_str: str, message: str):
        resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
        if (
            not isinstance(filesystem, pafs.LocalFileSystem)
            or file_info.type != pafs.FileType.File
        ):
            raise TypeError(message)
        return resolved_path, filesystem, file_info

    def _require_directory(path_str: str, message: str):
        resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
        if file_info.type != pafs.FileType.Directory:
            raise TypeError(message)
        return resolved_path, filesystem, file_info

    def _infer_content_encoding(path: str) -> str:
        _base, ext = posixpath.splitext(path)
        return EXT_TO_CONTENT_ENCODING.get(ext, "identity")

    def _csv_delimiter() -> str:
        if fmt in CSV_TYPES:
            return ","
        if fmt in TSV_TYPES:
            return "\t"
        if fmt in PSV_TYPES:
            return "|"
        raise ValueError(f"No delimiter for format {fmt!r}")

    def _read_delimited_table_with_header(path: str):
        read_kwargs = dict(content_type_to_reader_kwargs(fmt))
        read_kwargs.setdefault("read_options", pacsv.ReadOptions())
        return pacsv.read_csv(path, **read_kwargs)

    resolved_entries: List[dict[str, Any]] = []
    if fmt in PARQUET_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
            if file_info.type != pafs.FileType.File:
                raise TypeError("client.catalog.write(...) expects Parquet file paths.")
            metadata = pq.ParquetFile(resolved_path, filesystem=filesystem).metadata
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": metadata.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_parquet_column_stats(
                        resolved_path, filesystem=filesystem
                    ),
                }
            )
        return resolved_entries
    if fmt in CSV_TYPES | TSV_TYPES | PSV_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, _filesystem, file_info = _require_local_file(
                path_str,
                f"client.catalog.write(...) expects local {fmt.upper()} file paths.",
            )
            table = _read_delimited_table_with_header(resolved_path)
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": table.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_table_column_stats(table),
                }
            )
        return resolved_entries
    if fmt in FEATHER_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
            if file_info.type != pafs.FileType.File:
                raise TypeError("client.catalog.write(...) expects Feather file paths.")
            table = pyarrow_file_to_table(
                resolved_path,
                fmt,
                filesystem=filesystem,
            )
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": table.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_table_column_stats(table),
                }
            )
        return resolved_entries
    if fmt in JSON_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, _filesystem, file_info = _require_local_file(
                path_str,
                "client.catalog.write(...) expects local JSON file paths.",
            )
            table = pyarrow_file_to_table(
                resolved_path,
                fmt,
            )
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": table.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_table_column_stats(table),
                }
            )
        return resolved_entries
    if fmt in ORC_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
            if file_info.type != pafs.FileType.File:
                raise TypeError("client.catalog.write(...) expects ORC file paths.")
            table = pyarrow_file_to_table(
                resolved_path,
                fmt,
                filesystem=filesystem,
            )
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": table.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_table_column_stats(table),
                }
            )
        return resolved_entries
    if fmt in AVRO_TYPES:
        for item in paths:
            path_str = os.fspath(item)
            resolved_path, filesystem, file_info = _resolve_entry_path(path_str)
            if file_info.type != pafs.FileType.File:
                raise TypeError("client.catalog.write(...) expects AVRO file paths.")
            table = pyarrow_file_to_table(
                resolved_path,
                fmt,
                filesystem=filesystem,
            )
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": table.num_rows,
                    "content_length": int(file_info.size or 0),
                    "content_encoding": _infer_content_encoding(path_str),
                    "column_stats": _compute_table_column_stats(table),
                }
            )
        return resolved_entries
    if fmt in LANCE_TYPES:
        require_lance("client.catalog.write(...)")
        for item in paths:
            path_str = os.fspath(item)
            _resolved_path, filesystem, _file_info = _require_directory(
                path_str,
                "client.catalog.write(...) expects Lance dataset directories.",
            )
            storage_options = normalize_lance_storage_options(
                storage_options_from_filesystem(filesystem)
            )
            stats = get_local_lance_dataset_stats(
                path_str,
                storage_options=storage_options,
            )
            column_stats = None
            if sort_column:
                try:
                    column_stats = compute_lance_sort_column_stats(
                        path_str,
                        sort_column,
                        storage_options=storage_options,
                    )
                except Exception:
                    logger.debug(
                        "Failed to compute Lance sort-column stats for %s",
                        path_str,
                        exc_info=True,
                    )
                    column_stats = None
            resolved_entries.append(
                {
                    "path": path_str,
                    "record_count": int(stats["record_count"]),
                    "content_length": int(stats["content_length"]),
                    "content_encoding": "identity",
                }
                | ({"column_stats": column_stats} if column_stats is not None else {})
            )
        return resolved_entries
    raise NotImplementedError(
        f"client.catalog.write(...) does not yet support format {fmt!r}."
    )


def materialize_arrow_write(
    table,
    *,
    fmt: str,
    session: Any,
) -> List[Any]:
    data_dir = getattr(session, "data_dir", "")
    if data_dir:
        _raise_for_unsupported_remote_path(
            data_dir,
            operation="client.catalog.write(...)",
        )
    table = _sort_arrow_table_for_write(
        table,
        sort_scheme=getattr(session, "sort_scheme", None),
        merge_keys=getattr(session, "merge_keys", None),
    )
    _validate_pyarrow_schema_nullability(table)
    target_records_per_file = getattr(session, "target_records_per_file", None)
    if (
        target_records_per_file is None
        or int(target_records_per_file) <= 0
        or getattr(table, "num_rows", 0) <= int(target_records_per_file)
    ):
        table_slices = [("output", table)]
    else:
        per_file = int(target_records_per_file)
        table_slices = [
            (f"output-{idx:05d}", table.slice(offset, per_file))
            for idx, offset in enumerate(range(0, table.num_rows, per_file))
        ]

    def _dir_size_bytes(path: str) -> int:
        total = 0
        for current_root, _dirs, files in os.walk(path):
            for file_name in files:
                total += os.path.getsize(posixpath.join(current_root, file_name))
        return total

    if fmt in (
        PARQUET_TYPES
        | CSV_TYPES
        | TSV_TYPES
        | PSV_TYPES
        | UNESCAPED_TSV_TYPES
        | FEATHER_TYPES
        | JSON_TYPES
        | ORC_TYPES
        | AVRO_TYPES
    ):
        results = write_sliced_pyarrow_table(
            table,
            data_dir=getattr(session, "data_dir", ""),
            content_type=fmt,
            target_records_per_file=target_records_per_file,
        )
        entries = []
        for result in results:
            table_slice = next(
                slice_table
                for base_name, slice_table in table_slices
                if result.relative_path.startswith(base_name)
            )
            entries.append(
                session.entry_for(
                    result.relative_path,
                    records=result.record_count,
                    bytes=result.content_length,
                    content_encoding=result.content_encoding,
                    column_stats=_compute_arrow_table_column_stats(table_slice),
                    source_bytes=result.source_content_length,
                )
            )
        return entries
    if fmt in LANCE_TYPES:
        require_lance("client.catalog.write(...)")
        data_dir = getattr(session, "data_dir", "")
        _resolved_data_dir, filesystem = resolve_path_and_filesystem(data_dir)
        available_roots = getattr(session, "available_roots", None) or {}
        session_root_name = getattr(session, "root", None)
        data_root_info = None
        if isinstance(available_roots, dict):
            if session_root_name and session_root_name in available_roots:
                data_root_info = available_roots[session_root_name]
            elif len(available_roots) == 1:
                data_root_info = next(iter(available_roots.values()))
        endpoint_url = (
            data_root_info.get("endpoint_url")
            if isinstance(data_root_info, dict)
            else getattr(data_root_info, "endpoint_url", None)
        )
        region = (
            data_root_info.get("region")
            if isinstance(data_root_info, dict)
            else getattr(data_root_info, "region", None)
        )
        creds_map = getattr(session, "credentials", None)
        credentials = None
        if isinstance(creds_map, dict):
            if endpoint_url and isinstance(creds_map.get(endpoint_url), dict):
                credentials = creds_map.get(endpoint_url)
            elif isinstance(creds_map.get("default"), dict):
                credentials = creds_map.get("default")
            elif any(
                key in creds_map
                for key in (
                    "access_key_id",
                    "secret_access_key",
                    "session_token",
                    "aws_access_key_id",
                    "aws_secret_access_key",
                    "aws_session_token",
                    "AccessKeyId",
                    "SecretAccessKey",
                    "SessionToken",
                )
            ):
                credentials = creds_map

        sort_scheme = getattr(session, "sort_scheme", None)
        sort_scheme_id = (
            sort_scheme.get("id")
            if isinstance(sort_scheme, dict)
            else getattr(sort_scheme, "id", None)
        )
        sort_keys = (
            sort_scheme.get("keys")
            if isinstance(sort_scheme, dict)
            else getattr(sort_scheme, "keys", None)
        ) or []
        sort_column = None
        if sort_keys:
            first_key = sort_keys[0]
            key_columns = (
                first_key.get("key")
                if isinstance(first_key, dict)
                else getattr(first_key, "key", None)
            ) or []
            if key_columns:
                sort_column = key_columns[0]

        max_rows_per_fragment = None
        if target_records_per_file is not None and int(target_records_per_file) > 0:
            max_rows_per_fragment = int(target_records_per_file)

        payload = write_lance_entry_payload(
            table,
            base_path=data_dir,
            filesystem=filesystem,
            catalog_root=None,
            schema_id=None,
            sort_scheme_id=sort_scheme_id,
            sort_column=sort_column,
            max_rows_per_fragment=max_rows_per_fragment
            if max_rows_per_fragment is not None
            else 100_000,
            dataset_name="output.lance",
            credentials=credentials,
            endpoint_url=endpoint_url,
            region=region,
        )
        return [
            session.entry(
                payload.path,
                records=payload.record_count,
                bytes=payload.content_length,
                content_encoding="identity",
                column_stats=payload.column_stats,
                source_bytes=payload.source_content_length,
            )
        ]
    raise NotImplementedError(
        f"client.catalog.write(...) does not yet support format {fmt!r}."
    )
