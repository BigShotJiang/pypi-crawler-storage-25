"""Shared table conversion dispatch moved out of thick tables.py."""

from __future__ import annotations

from typing import Any, Callable, Dict, Type

from deltacat_io_core.deps import optional_import, require_pyarrow
from deltacat_io_core.table_dispatch import get_table_function


def _numpy_array_to_pandas(table, *, schema=None, **kwargs):
    pd = optional_import("pandas")
    if pd is None:
        raise ImportError("NumPy to pandas conversion requires pandas.")
    if schema is not None:
        if table.ndim == 1:
            column_names = [schema.names[0]] if schema.names else ["0"]
            return pd.DataFrame({column_names[0]: table}, **kwargs)
        if table.ndim == 2:
            column_names = (
                schema.names
                if len(schema.names) == table.shape[1]
                else [f"{i}" for i in range(table.shape[1])]
            )
            return pd.DataFrame(table, columns=column_names, **kwargs)
        raise ValueError(
            f"NumPy arrays with {table.ndim} dimensions are not supported. "
            f"Only 1D and 2D arrays are supported."
        )
    return pd.DataFrame(table, **kwargs)


def _numpy_array_to_pyarrow(table, schema, **kwargs):
    pa = require_pyarrow("NumPy to PyArrow conversion")
    pd_table = _numpy_array_to_pandas(table, schema=schema, **kwargs)
    return pa.Table.from_pandas(pd_table, schema=schema)


def _ray_dataset_to_pyarrow(table, *, schema, **kwargs):
    import ray

    pa = require_pyarrow("Ray Dataset to PyArrow conversion")
    arrow_refs = table.to_arrow_refs(**kwargs)
    arrow_tables = ray.get(arrow_refs)
    if len(arrow_tables) == 1:
        return arrow_tables[0]
    try:
        return pa.concat_tables(
            arrow_tables, promote_options="permissive", unify_schemas=True
        )
    except TypeError:
        return pa.concat_tables(arrow_tables, promote_options="permissive")


def _pyarrow_to_polars(pa_table, **kwargs):
    pl = optional_import("polars")
    pa = require_pyarrow("PyArrow to Polars conversion")
    if pl is None:
        raise ImportError("PyArrow to Polars conversion requires polars.")
    clean_schema = pa.schema(
        [
            pa.field(field.name, field.type, nullable=field.nullable)
            for field in pa_table.schema
        ]
    )
    clean_table = pa.Table.from_arrays(pa_table.columns, schema=clean_schema)
    return pl.from_arrow(clean_table, **kwargs)


def _pyarrow_to_numpy(pa_table, **kwargs):
    if pa_table.num_columns == 1:
        return pa_table.column(0).to_numpy(**kwargs)
    return pa_table.to_pandas().values


def _pandas_to_numpy(pd_df, **kwargs):
    if len(pd_df.columns) == 1:
        return pd_df.iloc[:, 0].to_numpy(**kwargs)
    return pd_df.values


TABLE_CLASS_TO_PYARROW_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_PANDAS_FUNC: Dict[Type[Any], Callable] = {}
DATASET_TYPE_FROM_PYARROW: Dict[str, Callable] = {}
DATASET_TYPE_FROM_PANDAS: Dict[str, Callable] = {}
TABLE_TYPE_TO_EMPTY_TABLE_FUNC: Dict[str, Callable] = {}


def _daft_module():
    import daft

    return daft


def _register_runtime_daft_conversion_type(table_type: Type[Any]) -> None:
    TABLE_CLASS_TO_PYARROW_FUNC.setdefault(
        table_type, lambda table, *, schema, **kwargs: table.to_arrow(**kwargs)
    )
    TABLE_CLASS_TO_PANDAS_FUNC.setdefault(
        table_type, lambda table, *, schema=None, **kwargs: table.to_pandas(**kwargs)
    )


def _ensure_runtime_conversion_support(table: Any) -> None:
    if str(type(table).__module__).startswith("daft"):
        _register_runtime_daft_conversion_type(type(table))


def _initialize_conversion_maps() -> None:
    pa = optional_import("pyarrow")
    if pa is None:
        return
    papq = optional_import("pyarrow.parquet")
    pd = optional_import("pandas")
    pl = optional_import("polars")
    ray_dataset_mod = optional_import("ray.data.dataset")
    ray_mod = optional_import("ray.data")
    lance_mod = optional_import("lance")

    TABLE_CLASS_TO_PYARROW_FUNC[pa.Table] = lambda table, *, schema, **kwargs: table
    TABLE_CLASS_TO_PANDAS_FUNC[
        pa.Table
    ] = lambda table, *, schema=None, **kwargs: table.to_pandas(**kwargs)
    if papq is not None:
        TABLE_CLASS_TO_PYARROW_FUNC[
            papq.ParquetFile
        ] = lambda table, *, schema, **kwargs: table.read(**kwargs)
        TABLE_CLASS_TO_PANDAS_FUNC[
            papq.ParquetFile
        ] = lambda table, *, schema=None, **kwargs: table.read(**kwargs).to_pandas(
            **kwargs
        )
    if pd is not None:
        TABLE_CLASS_TO_PYARROW_FUNC[
            pd.DataFrame
        ] = lambda table, *, schema, **kwargs: pa.Table.from_pandas(
            table, schema=schema, preserve_index=False, **kwargs
        )
        TABLE_CLASS_TO_PANDAS_FUNC[
            pd.DataFrame
        ] = lambda table, *, schema=None, **kwargs: table
    if pl is not None:
        TABLE_CLASS_TO_PYARROW_FUNC[
            pl.DataFrame
        ] = lambda table, *, schema, **kwargs: table.to_arrow(**kwargs)
        TABLE_CLASS_TO_PYARROW_FUNC[
            pl.LazyFrame
        ] = lambda table, *, schema, **kwargs: table.collect().to_arrow(**kwargs)
        TABLE_CLASS_TO_PANDAS_FUNC[
            pl.DataFrame
        ] = lambda table, *, schema=None, **kwargs: table.to_pandas(**kwargs)
        TABLE_CLASS_TO_PANDAS_FUNC[
            pl.LazyFrame
        ] = lambda table, *, schema=None, **kwargs: table.collect().to_pandas(**kwargs)
    np = optional_import("numpy")
    if np is not None:
        TABLE_CLASS_TO_PYARROW_FUNC[
            np.ndarray
        ] = lambda table, *, schema, **kwargs: _numpy_array_to_pyarrow(
            table, schema, **kwargs
        )
        TABLE_CLASS_TO_PANDAS_FUNC[
            np.ndarray
        ] = lambda table, *, schema=None, **kwargs: _numpy_array_to_pandas(
            table, schema=schema, **kwargs
        )
    if ray_dataset_mod is not None:
        dataset_cls = getattr(ray_dataset_mod, "Dataset")
        materialized_cls = getattr(ray_dataset_mod, "MaterializedDataset")
        TABLE_CLASS_TO_PYARROW_FUNC[dataset_cls] = _ray_dataset_to_pyarrow
        TABLE_CLASS_TO_PYARROW_FUNC[materialized_cls] = _ray_dataset_to_pyarrow
        TABLE_CLASS_TO_PANDAS_FUNC[
            dataset_cls
        ] = lambda table, *, schema=None, **kwargs: table.to_pandas(**kwargs)
        TABLE_CLASS_TO_PANDAS_FUNC[
            materialized_cls
        ] = lambda table, *, schema=None, **kwargs: table.to_pandas(**kwargs)
    if lance_mod is not None:
        TABLE_CLASS_TO_PYARROW_FUNC[
            lance_mod.LanceDataset
        ] = lambda table, *, schema, **kwargs: table.to_table(**kwargs)
        TABLE_CLASS_TO_PANDAS_FUNC[
            lance_mod.LanceDataset
        ] = lambda table, *, schema=None, **kwargs: table.to_table(**kwargs).to_pandas(
            **kwargs
        )

    TABLE_TYPE_TO_EMPTY_TABLE_FUNC["pyarrow"] = lambda: pa.Table.from_pydict({})
    if pd is not None:
        TABLE_TYPE_TO_EMPTY_TABLE_FUNC["pandas"] = lambda: pd.DataFrame()
    if pl is not None:
        TABLE_TYPE_TO_EMPTY_TABLE_FUNC["polars"] = lambda: pl.DataFrame()
    if np is not None:
        TABLE_TYPE_TO_EMPTY_TABLE_FUNC["numpy"] = lambda: np.array([])
    if ray_mod is not None:
        TABLE_TYPE_TO_EMPTY_TABLE_FUNC["ray_dataset"] = lambda: ray_mod.from_items([])

    DATASET_TYPE_FROM_PYARROW["pyarrow"] = lambda pa_table, **kwargs: pa_table
    if pd is not None:
        DATASET_TYPE_FROM_PYARROW[
            "pandas"
        ] = lambda pa_table, **kwargs: pa_table.to_pandas(**kwargs)
        DATASET_TYPE_FROM_PANDAS["pandas"] = lambda pd_df, **kwargs: pd_df
        DATASET_TYPE_FROM_PANDAS[
            "pyarrow"
        ] = lambda pd_df, **kwargs: pa.Table.from_pandas(pd_df, **kwargs)
        DATASET_TYPE_FROM_PYARROW[
            "numpy"
        ] = lambda pa_table, **kwargs: _pyarrow_to_numpy(pa_table, **kwargs)
        DATASET_TYPE_FROM_PANDAS["numpy"] = lambda pd_df, **kwargs: _pandas_to_numpy(
            pd_df, **kwargs
        )
    if pl is not None and pd is not None:
        DATASET_TYPE_FROM_PYARROW[
            "polars"
        ] = lambda pa_table, **kwargs: _pyarrow_to_polars(pa_table, **kwargs)
        DATASET_TYPE_FROM_PANDAS["polars"] = lambda pd_df, **kwargs: pl.from_pandas(
            pd_df, **kwargs
        )
    if ray_mod is not None and pd is not None:
        DATASET_TYPE_FROM_PYARROW[
            "ray_dataset"
        ] = lambda pa_table, **kwargs: ray_mod.from_arrow(pa_table)
        DATASET_TYPE_FROM_PANDAS[
            "ray_dataset"
        ] = lambda pd_df, **kwargs: ray_mod.from_pandas(pd_df, **kwargs)
    DATASET_TYPE_FROM_PYARROW["pyarrow_parquet"] = lambda pa_table, **kwargs: pa_table


_initialize_conversion_maps()


def table_to_pyarrow(table: Any, *, schema=None, **kwargs):
    _ensure_runtime_conversion_support(table)
    return get_table_function(table, TABLE_CLASS_TO_PYARROW_FUNC, "pyarrow conversion")(
        table, schema=schema, **kwargs
    )


def table_to_pandas(table: Any, *, schema=None, **kwargs):
    _ensure_runtime_conversion_support(table)
    return get_table_function(table, TABLE_CLASS_TO_PANDAS_FUNC, "pandas conversion")(
        table, schema=schema, **kwargs
    )


def from_pyarrow(pa_table: Any, target_type: str, **kwargs):
    if target_type == "daft":
        return _daft_module().from_arrow(pa_table, **kwargs)
    conversion_func = DATASET_TYPE_FROM_PYARROW.get(target_type)
    if conversion_func is None:
        raise ValueError(
            f"No {target_type} conversion function found for table type: {target_type}.\n"
            f"Known table types: {list(DATASET_TYPE_FROM_PYARROW.keys())}"
        )
    return conversion_func(pa_table, **kwargs)


def from_pandas(pd_df: Any, target_type: str, **kwargs):
    if target_type == "daft":
        return _daft_module().from_pandas(pd_df, **kwargs)
    conversion_func = DATASET_TYPE_FROM_PANDAS.get(target_type)
    if conversion_func is None:
        raise ValueError(
            f"No {target_type} conversion function found for table type: {target_type}.\n"
            f"Known table types: {list(DATASET_TYPE_FROM_PANDAS.keys())}"
        )
    return conversion_func(pd_df, **kwargs)


def empty_table(table_type: str):
    if table_type == "daft":
        return _daft_module().DataFrame()
    empty_table_func = TABLE_TYPE_TO_EMPTY_TABLE_FUNC.get(table_type)
    if empty_table_func is None:
        raise ValueError(
            f"No empty table function found for table type: {table_type}.\n"
            f"Known table types: {list(TABLE_TYPE_TO_EMPTY_TABLE_FUNC.keys())}"
        )
    return empty_table_func()
