"""Filesystem helpers cloned from thick DeltaCAT for io_core write/read paths."""

from __future__ import annotations

import os
import pathlib
import posixpath
import re
import sys
import urllib
from enum import Enum
from typing import Optional, Tuple

from pyarrow.fs import (
    FileInfo,
    FileSystem,
    LocalFileSystem,
    S3FileSystem,
    GcsFileSystem,
    AzureFileSystem,
    HadoopFileSystem,
    _resolve_filesystem_and_path,
)


class FilesystemType(str, Enum):
    LOCAL = "local"
    S3 = "s3"
    GCS = "gcs"
    AZURE = "azure"
    HADOOP = "hadoop"
    UNKNOWN = "unknown"

    @classmethod
    def from_filesystem(cls, filesystem: FileSystem) -> "FilesystemType":
        if isinstance(filesystem, LocalFileSystem):
            return cls.LOCAL
        if isinstance(filesystem, S3FileSystem):
            return cls.S3
        if isinstance(filesystem, GcsFileSystem):
            return cls.GCS
        if isinstance(filesystem, AzureFileSystem):
            return cls.AZURE
        if isinstance(filesystem, HadoopFileSystem):
            return cls.HADOOP
        return cls.UNKNOWN


_FILESYSTEM_SCHEMES = {
    FilesystemType.LOCAL: {"", "file"},
    FilesystemType.S3: {"s3"},
    FilesystemType.GCS: {"gs", "gcs"},
    FilesystemType.AZURE: {"az", "abfs", "abfss", "wasb", "wasbs"},
    FilesystemType.HADOOP: {"hdfs"},
}

_S3_EXPRESS_REGION_PREFIXES = {
    "use": "us-east",
    "usw": "us-west",
    "cac": "ca-central",
    "sae": "sa-east",
    "euw": "eu-west",
    "euc": "eu-central",
    "eun": "eu-north",
    "eus": "eu-south",
    "apse": "ap-southeast",
    "apne": "ap-northeast",
    "aps": "ap-south",
    "mes": "me-south",
    "mec": "me-central",
    "afs": "af-south",
    "ilc": "il-central",
}


def _s3_bucket_from_path(path: str) -> Optional[str]:
    parsed = urllib.parse.urlparse(path, allow_fragments=False)
    if parsed.scheme == "s3":
        return parsed.netloc or None
    if "://" not in path:
        bucket, _, _rest = path.partition("/")
        return bucket or None
    return None


def _is_s3_express_bucket(bucket: Optional[str]) -> bool:
    return bool(bucket and bucket.endswith("--x-s3"))


def infer_s3_express_region(path: str) -> Optional[str]:
    bucket = _s3_bucket_from_path(path)
    if not _is_s3_express_bucket(bucket):
        return None
    parts = (bucket or "").split("--")
    if len(parts) < 3:
        return os.environ.get("AWS_DEFAULT_REGION")
    az_token = parts[-2]
    match = re.fullmatch(r"([a-z]+)(\d+)-az\d+", az_token)
    if not match:
        return os.environ.get("AWS_DEFAULT_REGION")
    prefix, region_num = match.groups()
    region_prefix = _S3_EXPRESS_REGION_PREFIXES.get(prefix)
    if region_prefix is None:
        return os.environ.get("AWS_DEFAULT_REGION")
    return f"{region_prefix}-{region_num}"


def _unwrap_protocol(path: str) -> str:
    if sys.platform == "win32" and path and "://" not in path:
        return pathlib.Path(path).as_posix()

    parsed = urllib.parse.urlparse(path, allow_fragments=False)
    query = f"?{parsed.query}" if parsed.query else ""
    netloc = parsed.netloc
    if parsed.scheme == "s3" and "@" in netloc:
        netloc = netloc.split("@")[-1]

    parsed_path = parsed.path
    if (
        sys.platform == "win32"
        and not netloc
        and len(parsed_path) >= 3
        and parsed_path[0] == "/"
        and parsed_path[1].isalpha()
        and parsed_path[2:4] in (":", ":/")
    ):
        parsed_path = parsed_path[1:]

    return netloc + parsed_path + query


def _normalize_explicit_filesystem_path(path: str, filesystem: FileSystem) -> str:
    scheme = urllib.parse.urlparse(path, allow_fragments=False).scheme.lower()
    filesystem_type = FilesystemType.from_filesystem(filesystem)
    allowed_schemes = _FILESYSTEM_SCHEMES.get(filesystem_type, set())
    if scheme and scheme not in allowed_schemes:
        return path
    if filesystem_type == FilesystemType.LOCAL or scheme:
        return _unwrap_protocol(path)
    return path


def resolve_path_and_filesystem(
    path: str,
    filesystem: Optional[FileSystem] = None,
) -> Tuple[str, FileSystem]:
    candidate_path = (
        _normalize_explicit_filesystem_path(path, filesystem)
        if filesystem is not None
        else path
    )
    try:
        resolved_filesystem, resolved_path = _resolve_filesystem_and_path(
            candidate_path, filesystem
        )
    except OSError as exc:
        if "ACCESS_DENIED" not in str(exc) or "HeadBucket" not in str(exc):
            raise
        region = infer_s3_express_region(candidate_path)
        if region is None:
            raise
        resolved_filesystem = S3FileSystem(region=region)
        resolved_path = _unwrap_protocol(candidate_path)
    if isinstance(resolved_filesystem, S3FileSystem):
        region = infer_s3_express_region(candidate_path)
        if region is not None:
            resolved_filesystem = S3FileSystem(region=region)
    return resolved_path, resolved_filesystem


def get_file_info(
    path: str,
    filesystem: FileSystem,
    ignore_missing_path: bool = False,
) -> FileInfo:
    file_info = filesystem.get_file_info(path)
    if file_info.type.name == "NotFound" and not ignore_missing_path:
        raise FileNotFoundError(path)
    return file_info


def ensure_parent_dir(
    path: str,
    filesystem: Optional[FileSystem] = None,
) -> Tuple[str, FileSystem]:
    resolved_path, resolved_filesystem = resolve_path_and_filesystem(path, filesystem)
    dir_path = posixpath.dirname(resolved_path)
    if dir_path and dir_path != ".":
        if hasattr(resolved_filesystem, "create_dir"):
            resolved_filesystem.create_dir(dir_path, recursive=True)
        elif hasattr(resolved_filesystem, "makedirs"):
            resolved_filesystem.makedirs(dir_path, exist_ok=True)
    return resolved_path, resolved_filesystem


def append_protocol_prefix_by_type(path: str, filesystem_type: FilesystemType) -> str:
    parsed_uri = urllib.parse.urlparse(path)
    if parsed_uri.scheme:
        return path

    if filesystem_type == FilesystemType.LOCAL:
        if sys.platform == "win32":
            posix_path = pathlib.Path(path).as_posix()
            return f"file:///{posix_path.lstrip('/')}"
        return f"file://{path}"
    if filesystem_type == FilesystemType.S3:
        return f"s3://{path}"
    if filesystem_type == FilesystemType.GCS:
        return f"gs://{path}"
    if filesystem_type == FilesystemType.AZURE:
        return f"az://{path}"
    if filesystem_type == FilesystemType.HADOOP:
        return f"hdfs://{path}"
    return path
