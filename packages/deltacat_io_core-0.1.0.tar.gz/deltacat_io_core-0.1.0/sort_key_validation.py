"""Shared sort-key validation helpers for compaction."""

from __future__ import annotations

from itertools import chain

import pyarrow as pa

MAX_SORT_KEYS_BIT_WIDTH = 256


def validate_sort_keys(
    source_partition_locator,
    sort_keys,
    deltacat_storage,
    deltacat_storage_kwargs,
    *,
    identity_transform_name,
) -> int:
    """Validate sort keys and return total fixed-width bit width."""
    if deltacat_storage_kwargs is None:
        deltacat_storage_kwargs = {}
    total_sort_keys_bit_width = 0
    if sort_keys:
        sort_key_names = list(chain.from_iterable([key.key for key in sort_keys]))
        assert all(
            [
                key.transform is None or key.transform.name == identity_transform_name
                for key in sort_keys
            ]
        ), f"Sort key transforms are not supported: {sort_keys}"
        assert len(sort_key_names) == len(
            set(sort_key_names)
        ), f"Sort key names must be unique: {sort_key_names}"
        stream_locator = source_partition_locator.stream_locator
        table_version_schema = deltacat_storage.get_table_version_schema(
            stream_locator.namespace,
            stream_locator.table_name,
            stream_locator.table_version,
            **deltacat_storage_kwargs,
        )
        if isinstance(table_version_schema, pa.Schema):
            for sort_key_name in sort_key_names:
                pa_field = table_version_schema.field(sort_key_name)
                pa_type = pa_field.type
                try:
                    total_sort_keys_bit_width += pa_type.bit_width
                    if total_sort_keys_bit_width > MAX_SORT_KEYS_BIT_WIDTH:
                        raise ValueError(
                            f"Total length of sort keys "
                            f"({total_sort_keys_bit_width}) is greater "
                            f"than the max supported bit width for all "
                            f"sort keys ({MAX_SORT_KEYS_BIT_WIDTH})"
                        )
                except ValueError as e:
                    raise ValueError(
                        f"Unable to get bit width of sort key: {pa_field}. "
                        f"Please ensure that all sort keys are fixed-size "
                        f"PyArrow data types."
                    ) from e
        else:
            total_sort_keys_bit_width = MAX_SORT_KEYS_BIT_WIDTH
    return total_sort_keys_bit_width
