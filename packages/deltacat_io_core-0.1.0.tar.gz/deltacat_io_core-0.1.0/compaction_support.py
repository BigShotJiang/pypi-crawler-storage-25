"""Shared compaction-session helpers moved out of native compaction utils."""

from __future__ import annotations

from collections import Counter
import functools
import inspect
from contextlib import nullcontext
import json
from math import ceil
import posixpath
from typing import Any, Optional, Sequence

import numpy as np


def infer_compaction_output_content_type(
    input_deltas: Sequence[Any],
    *,
    parquet_content_type: Any,
    content_type_factory,
    delimited_text_content_types,
    log_debug_fn,
) -> Any:
    """Infer the compaction output content type from source delta manifests."""
    counts: Counter = Counter()
    for delta in input_deltas:
        manifest = getattr(delta, "manifest", None)
        entries = getattr(manifest, "entries", None)
        if not entries:
            continue
        for entry in entries:
            meta = getattr(entry, "meta", None)
            content_type = getattr(meta, "content_type", None)
            if content_type:
                counts[content_type] += 1

    if not counts:
        log_debug_fn(
            "No content types found in source deltas; "
            "defaulting compaction output to Parquet."
        )
        return parquet_content_type

    dominant_type_str = counts.most_common(1)[0][0]
    if dominant_type_str in delimited_text_content_types:
        log_debug_fn(
            "Source content type %s is delimited text; "
            "promoting compaction output to Parquet.",
            dominant_type_str,
        )
        return parquet_content_type

    return content_type_factory(dominant_type_str)


def get_rci_source_partition_locator(params: Any) -> Any:
    """Return the partition locator whose RCI should drive this compaction."""
    return params.rebase_source_partition_locator or params.source_partition_locator


def is_inplace_compacted(
    rci_source_partition_locator: Any,
    destination_partition_locator: Any,
) -> bool:
    """Whether the compaction output rewrites the same logical partition."""
    return (
        rci_source_partition_locator.partition_values
        == destination_partition_locator.partition_values
        and rci_source_partition_locator.stream_id
        == destination_partition_locator.stream_id
    )


def run_local_merge(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    compacted_partition: Any,
    round_completion_info: Any,
    delete_strategy: Optional[Any],
    delete_file_envelopes: Optional[Any],
    mutable_compaction_audit: Any,
    previous_compacted_delta_manifest: Optional[Any],
    total_input_records_count: Any,
    generate_local_merge_input_fn,
    local_merge_resource_options_provider_fn,
    merge_remote_options_fn,
    ray_get_fn,
) -> tuple[list[Any], Any]:
    """Run the single-bucket local merge path used by compaction."""
    local_merge_input = generate_local_merge_input_fn(
        params,
        uniform_deltas,
        compacted_partition,
        round_completion_info,
        delete_strategy,
        delete_file_envelopes,
    )
    estimated_da_bytes = (
        mutable_compaction_audit.estimated_in_memory_size_bytes_during_discovery
    )
    estimated_num_records = sum(
        entry.meta.record_count
        for delta in uniform_deltas
        for entry in delta.manifest.entries
    )
    local_merge_options = local_merge_resource_options_provider_fn(
        estimated_da_size=estimated_da_bytes,
        estimated_num_rows=estimated_num_records,
        total_memory_buffer_percentage=params.total_memory_buffer_percentage,
        round_completion_info=round_completion_info,
        compacted_delta_manifest=previous_compacted_delta_manifest,
        ray_custom_resources=params.ray_custom_resources,
        primary_keys=params.primary_keys,
        memory_logs_enabled=params.memory_logs_enabled,
        estimate_resources_params=params.estimate_resources_params,
    )
    local_merge_result = ray_get_fn(
        merge_remote_options_fn(**local_merge_options).remote(local_merge_input)
    )
    total_input_records_count += local_merge_result.input_record_count
    return [local_merge_result], total_input_records_count


def discover_deltas(
    source_partition_locator: Any,
    last_stream_position_to_compact: int,
    *,
    rebase_source_partition_locator: Optional[Any] = None,
    rebase_source_partition_high_watermark: Optional[int] = None,
    rcf_high_watermark: Optional[int] = None,
    deltacat_storage=None,
    deltacat_storage_kwargs=None,
    list_deltas_kwargs=None,
    discover_deltas_impl_fn=None,
    log_info_fn=None,
) -> list[Any]:
    """Discover source and optional rebase deltas for a compaction session."""
    previous_compacted_high_watermark = (
        rebase_source_partition_high_watermark or rcf_high_watermark
    )
    delta_source_partition_locator = (
        rebase_source_partition_locator or source_partition_locator
    )

    result = []
    delta_source_incremental_deltas = discover_deltas_impl_fn(
        delta_source_partition_locator,
        previous_compacted_high_watermark,
        last_stream_position_to_compact,
        deltacat_storage,
        deltacat_storage_kwargs,
        list_deltas_kwargs,
    )

    result.extend(delta_source_incremental_deltas)
    log_info_fn(
        f"Length of input deltas from delta source table is {len(delta_source_incremental_deltas)}"
        f" from ({previous_compacted_high_watermark}, {last_stream_position_to_compact}]"
    )
    log_info_fn(f"DEBUG: source_partition_locator = {source_partition_locator}")
    log_info_fn(
        f"DEBUG: source_partition_locator.partition_id = {getattr(source_partition_locator, 'partition_id', 'NO_PARTITION_ID')}"
    )
    log_info_fn(f"DEBUG: total input deltas found = {len(result)}")

    if rebase_source_partition_locator:
        previous_compacted_deltas = discover_deltas_impl_fn(
            source_partition_locator,
            None,
            None,
            deltacat_storage,
            deltacat_storage_kwargs,
            list_deltas_kwargs,
        )
        result.extend(previous_compacted_deltas)
        log_info_fn(
            f"Length of input deltas from previous compacted table is {len(previous_compacted_deltas)}"
            f" from ({None}, {None}]"
        )

    return result


def discover_delta_range(
    source_partition_locator: Any,
    start_position_exclusive: Optional[int],
    end_position_inclusive: Optional[int],
    deltacat_storage,
    deltacat_storage_kwargs: Optional[dict],
    list_deltas_kwargs: Optional[dict],
    log_info_fn,
    log_warning_fn,
) -> list[Any]:
    """Discover deltas in a specific stream-position range."""
    if deltacat_storage_kwargs is None:
        deltacat_storage_kwargs = {}
    kwargs = {**deltacat_storage_kwargs, **(list_deltas_kwargs or {})}

    deltas_list_result = deltacat_storage.list_partition_deltas(
        partition_like=source_partition_locator,
        first_stream_position=start_position_exclusive,
        last_stream_position=end_position_inclusive,
        ascending_order=True,
        include_manifest=True,
        **kwargs,
    )
    deltas = deltas_list_result.all_items()
    if not deltas:
        log_warning_fn(
            f"Couldn't find any deltas to "
            f"compact in delta stream position range "
            f"('{start_position_exclusive}', "
            f"'{end_position_inclusive}']. Source partition: "
            f"{source_partition_locator}"
        )
        return []

    if start_position_exclusive == deltas[0].stream_position:
        first_delta = deltas.pop(0)
        log_info_fn(
            f"Removed exclusive start delta w/ expected stream "
            f"position '{start_position_exclusive}' from deltas to "
            f"compact: {first_delta}"
        )
    log_info_fn(
        f"Count of deltas to compact in delta stream "
        f"position range ('{start_position_exclusive}', "
        f"'{end_position_inclusive}']: {len(deltas)}. Source "
        f"partition: '{source_partition_locator}'"
    )
    return deltas


def create_uniform_input_deltas(
    input_deltas: Sequence[Any],
    hash_bucket_count: int,
    compaction_audit: Any,
    compact_partition_params: Any,
    all_column_names: Sequence[str],
    *,
    deltacat_storage,
    deltacat_storage_kwargs,
    does_require_content_type_params_fn,
    append_content_type_params_fn,
    estimate_manifest_entry_size_bytes_fn,
    delta_annotated_factory,
    pyarrow_download_operation_type,
    log_debug_fn,
    log_info_fn,
) -> list[Any]:
    """Create and rebatch uniform input deltas for compaction/MOR."""
    delta_bytes = 0
    delta_manifest_entries_count = 0
    estimated_da_bytes = 0
    input_da_list = []
    for delta in input_deltas:
        if (
            compact_partition_params.enable_input_split
            or does_require_content_type_params_fn(
                compact_partition_params.resource_estimation_method
            )
        ):
            log_debug_fn(
                f"Delta with locator: {delta.locator} requires content type params..."
            )
            append_content_type_params_fn(
                delta=delta,
                all_column_names=all_column_names,
                deltacat_storage=deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs,
                task_max_parallelism=compact_partition_params.task_max_parallelism,
                max_parquet_meta_size_bytes=compact_partition_params.max_parquet_meta_size_bytes,
                file_reader_kwargs_provider=compact_partition_params.read_kwargs_provider,
            )

        manifest_entries = delta.manifest.entries
        delta_manifest_entries_count += len(manifest_entries)
        for entry in manifest_entries:
            delta_bytes += entry.meta.content_length
            estimated_da_bytes += estimate_manifest_entry_size_bytes_fn(
                entry=entry,
                operation_type=pyarrow_download_operation_type,
                estimate_resources_params=compact_partition_params.estimate_resources_params,
            )

        input_da_list.append(delta_annotated_factory.of(delta))

    log_info_fn(f"Input deltas to compact this round: {len(input_da_list)}")
    log_info_fn(f"Input delta bytes to compact: {delta_bytes}")
    log_info_fn(f"Input delta files to compact: {delta_manifest_entries_count}")

    size_estimation_function = functools.partial(
        estimate_manifest_entry_size_bytes_fn,
        operation_type=pyarrow_download_operation_type,
        estimate_resources_params=compact_partition_params.estimate_resources_params,
    )
    rebatched_da_list = delta_annotated_factory.rebatch(
        input_da_list,
        min_delta_bytes=compact_partition_params.min_delta_bytes_in_batch,
        min_file_counts=compact_partition_params.min_files_in_batch,
        estimation_function=size_estimation_function,
        enable_input_split=compact_partition_params.enable_input_split,
    )

    compaction_audit.set_input_size_bytes(delta_bytes)
    compaction_audit.set_input_file_count(delta_manifest_entries_count)
    compaction_audit.set_estimated_in_memory_size_bytes_during_discovery(
        estimated_da_bytes
    )

    log_info_fn(f"Hash bucket count: {hash_bucket_count}")
    log_info_fn(f"Input uniform delta count: {len(rebatched_da_list)}")
    return rebatched_da_list


def compact_partition(
    params: Any,
    *,
    execute_compaction_fn,
    commit_compaction_result_fn,
    profiler_context_factory=None,
    **kwargs,
) -> None:
    """Run the top-level compaction-session flow behind native decorators."""
    assert (
        params.hash_bucket_count is not None and params.hash_bucket_count >= 1
    ), "hash_bucket_count is a required arg for compactor v2"
    assert type(params.hash_bucket_count) is int, "Hash bucket count must be an integer"
    if params.num_rounds > 1:
        assert (
            not params.drop_duplicates
        ), "num_rounds > 1, drop_duplicates must be False but is True"

    context = (
        profiler_context_factory(params.enable_profiler)
        if profiler_context_factory is not None
        else nullcontext()
    )
    with context:
        execute_compaction_result = execute_compaction_fn(params, **kwargs)
        commit_compaction_result_fn(params, execute_compaction_result)


def process_merge_results(
    params: Any,
    merge_results: Sequence[Any],
    mutable_compaction_audit: Any,
    *,
    upload_audit_data_fn,
    merge_deltas_fn,
    max_delta_stream_position: Any,
) -> tuple[Any, list[Any], dict]:
    """Process merge/materialize results into a merged delta and file-index map."""
    mat_results = []
    for merge_result in merge_results:
        mat_results.extend(merge_result.materialize_results)

    mat_results = sorted(mat_results, key=lambda m: m.task_index)
    hb_id_to_entry_indices_range = {}
    file_index = 0
    previous_task_index = -1

    duplicate_hash_bucket_mat_results = 0
    for mat_result in mat_results:
        assert (
            mat_result.pyarrow_write_result.files >= 1
        ), "At least one file must be materialized"
        if mat_result.task_index == previous_task_index:
            duplicate_hash_bucket_mat_results += 1
        else:
            duplicate_hash_bucket_mat_results = 0
        assert duplicate_hash_bucket_mat_results < params.num_rounds, (
            f"Duplicate record count ({duplicate_hash_bucket_mat_results}) is as large "
            f"as or greater than params.num_rounds, which is {params.num_rounds}"
        )
        hb_id_to_entry_indices_range[str(mat_result.task_index)] = (
            hb_id_to_entry_indices_range.get(str(mat_result.task_index), [file_index])[
                0
            ],
            file_index + mat_result.pyarrow_write_result.files,
        )
        file_index += mat_result.pyarrow_write_result.files
        previous_task_index = mat_result.task_index

    upload_audit_data_fn(
        params,
        mutable_compaction_audit,
    )
    deltas = [m.delta for m in mat_results]
    stream_position = (
        params.last_stream_position_to_compact
        if params.last_stream_position_to_compact != max_delta_stream_position
        else 1
    )
    merged_delta = merge_deltas_fn(
        deltas,
        stream_position=stream_position,
    )
    return merged_delta, mat_results, hb_id_to_entry_indices_range


def group_uniform_deltas(
    params: Any,
    uniform_deltas: Sequence[Any],
) -> list[list[Any]]:
    """Group uniform deltas across compaction rounds."""
    num_deltas = len(uniform_deltas)
    num_rounds = params.num_rounds
    if num_rounds == 1:
        return [list(uniform_deltas)]
    assert (
        num_rounds > 0
    ), f"num_rounds parameter should be greater than zero but is {params.num_rounds}"
    assert (
        num_rounds <= num_deltas
    ), f"{params.num_rounds} rounds should be less than the number of uniform deltas, which is {len(uniform_deltas)}"
    size = ceil(num_deltas / num_rounds)
    grouped = list(
        map(
            lambda x: list(uniform_deltas[x * size : x * size + size]),
            list(range(num_rounds)),
        )
    )
    num_deltas_after_grouping = sum(len(sublist) for sublist in grouped)
    assert (
        num_deltas_after_grouping == num_deltas
    ), f"uniform_deltas_grouped expected to have {num_deltas} deltas, but has {num_deltas_after_grouping}"
    return grouped


def stage_new_partition(
    params: Any,
    *,
    get_stream_fn,
    stage_partition_fn,
) -> Any:
    """Stage the destination partition for a compaction session."""
    compacted_stream_locator = params.destination_partition_locator.stream_locator
    compacted_stream = get_stream_fn(
        compacted_stream_locator.namespace,
        compacted_stream_locator.table_name,
        compacted_stream_locator.table_version,
        **params.deltacat_storage_kwargs,
    )
    return stage_partition_fn(
        compacted_stream,
        params.destination_partition_locator.partition_values,
        **params.deltacat_storage_kwargs,
    )


def update_and_upload_compaction_audit(
    params: Any,
    mutable_compaction_audit: Any,
    *,
    upload_audit_data_fn,
    round_completion_info: Optional[Any] = None,
) -> None:
    """Apply prior-round input adjustments and upload the compaction audit."""
    if round_completion_info:
        mutable_compaction_audit.set_input_file_count(
            (mutable_compaction_audit.input_file_count or 0)
            + round_completion_info.compacted_pyarrow_write_result.files
        )
        mutable_compaction_audit.set_input_size_bytes(
            (mutable_compaction_audit.input_size_bytes or 0.0)
            + round_completion_info.compacted_pyarrow_write_result.file_bytes
        )
        mutable_compaction_audit.set_input_records(
            (mutable_compaction_audit.input_records or 0)
            + round_completion_info.compacted_pyarrow_write_result.records
        )

    upload_audit_data_fn(
        params,
        mutable_compaction_audit,
    )


def json_default_for_audit(obj):
    """JSON encoder default for numpy types in compaction audit data."""
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    raise TypeError(f"Object of type {type(obj).__name__} is not JSON serializable")


def upload_audit_data(
    params: Any,
    audit_info: Any,
    *,
    resolve_path_and_filesystem_fn,
    log_warning_fn,
) -> None:
    """Upload compaction audit JSON using the catalog filesystem when available."""
    audit_url = audit_info.audit_url
    audit_data = json.dumps(
        audit_info.to_serializable(params.catalog.root),
        default=json_default_for_audit,
    )
    if params.catalog and params.catalog.filesystem:
        catalog_filesystem = params.catalog.filesystem
        filesystem = catalog_filesystem
        path = audit_url
        if "://" in audit_url:
            resolved_path, resolved_filesystem = resolve_path_and_filesystem_fn(
                audit_url
            )
            path = resolved_path
            if type(resolved_filesystem) is not type(catalog_filesystem):
                filesystem = resolved_filesystem
    else:
        path, filesystem = resolve_path_and_filesystem_fn(audit_url)

    parent_dir = posixpath.dirname(path)
    if parent_dir and filesystem.get_file_info(parent_dir).type.name != "Directory":
        try:
            filesystem.create_dir(parent_dir, recursive=True)
        except Exception as e:
            log_warning_fn(f"Failed to create directory {parent_dir}: {e}")

    with filesystem.open_output_stream(path) as output_stream:
        output_stream.write(audit_data.encode("utf-8"))


def commit_compaction_result(
    params: Any,
    execute_compaction_result: Any,
    *,
    autonomous_read_context_factory,
    get_previous_partition_fn,
    commit_partition_fn,
    partition_not_found_error_cls: type[Exception],
    log_info_fn,
    log_debug_fn,
    log_error_fn,
) -> None:
    """Commit a completed compaction result, preserving carry-over semantics."""
    compaction_session_type = (
        "INPLACE" if execute_compaction_result.is_inplace_compacted else "NON-INPLACE"
    )
    log_info_fn(
        f"Partition-{params.source_partition_locator} -> "
        f"{compaction_session_type} Compaction session data processing completed"
    )

    if execute_compaction_result.new_compacted_partition:
        previous_partition = None
        if execute_compaction_result.is_inplace_compacted:
            try:
                with autonomous_read_context_factory():
                    previous_partition = get_previous_partition_fn(
                        params.source_partition_locator.stream_locator,
                        params.source_partition_locator.partition_values,
                        **{
                            k: v
                            for k, v in params.deltacat_storage_kwargs.items()
                            if k != "transaction"
                        },
                    )
            except partition_not_found_error_cls:
                log_debug_fn(
                    "No previous partition for carry-over (first compaction for %s)",
                    params.source_partition_locator,
                )
            except Exception as e:
                log_error_fn(
                    "Failed to retrieve previous partition for carry-over: %s",
                    e,
                    exc_info=True,
                )

        log_info_fn(
            f"Committing compacted partition to: {execute_compaction_result.new_compacted_partition.locator} "
            f"using previous partition: {previous_partition.locator if previous_partition else None}"
        )
        execute_compaction_result.new_compacted_partition.compaction_round_completion_info = (
            execute_compaction_result.new_round_completion_info
        )
        execute_compaction_result.new_compacted_partition.previous_stream_position = (
            params.last_stream_position_to_compact
        )
        commit_partition_kwargs = dict(params.deltacat_storage_kwargs)
        if (
            execute_compaction_result.partition_stats_deltas is not None
            and "partition_stats_deltas"
            in inspect.signature(commit_partition_fn).parameters
        ):
            commit_partition_kwargs[
                "partition_stats_deltas"
            ] = execute_compaction_result.partition_stats_deltas
        committed_partition = commit_partition_fn(
            execute_compaction_result.new_compacted_partition,
            previous_partition,
            **commit_partition_kwargs,
        )
        log_info_fn(f"Committed compacted partition: {committed_partition}")
    else:
        log_debug_fn("No new partition was committed during compaction.")

    log_info_fn(f"Completed compaction session for: {params.source_partition_locator}")


def execute_compaction(
    params: Any,
    *,
    fetch_compaction_metadata_fn,
    get_rci_source_partition_locator_fn,
    compaction_audit_factory,
    deltacat_version: str,
    ray_version: str,
    compactor_version_value: str,
    discover_deltas_fn,
    infer_content_type_fn,
    build_uniform_deltas_fn,
    group_uniform_deltas_fn,
    stage_new_partition_fn,
    run_hash_and_merge_fn,
    process_merge_results_fn,
    commit_delta_fn,
    delta_locator_factory,
    pyarrow_write_result_union_fn,
    current_process_peak_memory_fn,
    emit_audit_metrics_and_logs_fn,
    create_round_completion_info_fn,
    execution_compaction_result_factory,
    monotonic_time_fn,
    log_info_fn,
) -> Any:
    """Execute the full compaction-session flow through injected native callbacks."""
    compaction_start_time = monotonic_time_fn()
    (
        previous_compacted_delta_manifest,
        round_completion_info,
    ) = fetch_compaction_metadata_fn(params)
    rci_source_partition_locator = get_rci_source_partition_locator_fn(params)

    base_audit_url = rci_source_partition_locator.path(
        f"{params.compaction_artifact_path}/compaction-audit"
    )
    audit_url = f"{base_audit_url}.json"
    log_info_fn(f"Compaction audit will be written to {audit_url}")
    compaction_audit = (
        compaction_audit_factory(deltacat_version, ray_version, audit_url)
        .set_hash_bucket_count(params.hash_bucket_count)
        .set_compactor_version(compactor_version_value)
    )

    if params.pg_config:
        log_info_fn(
            "pg_config specified. Tasks will be scheduled in a placement group."
        )
        cluster_resources = params.pg_config.resource
        cluster_memory = cluster_resources["memory"]
        compaction_audit.set_total_cluster_memory_bytes(cluster_memory)

    high_watermark = (
        round_completion_info.high_watermark if round_completion_info else None
    )
    audit_url = compaction_audit.audit_url if compaction_audit else None

    delta_discovery_start = monotonic_time_fn()
    input_deltas = discover_deltas_fn(
        params.source_partition_locator,
        params.last_stream_position_to_compact,
        params.rebase_source_partition_locator,
        params.rebase_source_partition_high_watermark,
        high_watermark,
        params.deltacat_storage,
        params.deltacat_storage_kwargs,
        params.list_deltas_kwargs,
    )
    if not input_deltas:
        log_info_fn("No input deltas found to compact.")
        return execution_compaction_result_factory(None, None, None, False)

    if params.compacted_file_content_type is None:
        params.compacted_file_content_type = infer_content_type_fn(input_deltas)
        log_info_fn(
            "Inferred compaction output content type: %s",
            params.compacted_file_content_type.value,
        )

    uniform_deltas, delete_strategy, delete_file_envelopes = build_uniform_deltas_fn(
        params,
        compaction_audit,
        input_deltas,
        delta_discovery_start,
    )
    log_info_fn(f"Number of rounds parameter is set to: {params.num_rounds}")
    uniform_deltas_grouped = group_uniform_deltas_fn(params, uniform_deltas)
    log_info_fn(f"Length of grouped uniform deltas is: {len(uniform_deltas_grouped)}")
    merge_result_list = []
    compacted_partition = stage_new_partition_fn(params)
    for uniform_delta_group in uniform_deltas_grouped:
        merge_result_list.extend(
            run_hash_and_merge_fn(
                params,
                uniform_delta_group,
                round_completion_info,
                delete_strategy,
                delete_file_envelopes,
                compaction_audit,
                previous_compacted_delta_manifest,
                compacted_partition,
            )
        )

    merged_delta, mat_results, hb_id_to_entry_indices_range = process_merge_results_fn(
        params,
        merge_result_list,
        compaction_audit,
    )
    log_info_fn(f" Materialized records: {merged_delta.meta.record_count}")
    compacted_delta = commit_delta_fn(
        merged_delta,
        properties={},
        **params.deltacat_storage_kwargs,
    )
    log_info_fn(f"Committed compacted delta: {compacted_delta}")

    compaction_end_time = monotonic_time_fn()
    compaction_audit.set_compaction_time_in_seconds(
        compaction_end_time - compaction_start_time
    )
    new_compacted_delta_locator = delta_locator_factory.of(
        compacted_partition.locator,
        compacted_delta.stream_position,
    )
    pyarrow_write_result = pyarrow_write_result_union_fn(
        [m.pyarrow_write_result for m in mat_results]
    )
    session_peak_memory = current_process_peak_memory_fn()
    compaction_audit.set_peak_memory_used_bytes_by_compaction_session_process(
        session_peak_memory
    )
    compaction_audit.save_round_completion_stats(mat_results)

    emit_audit_metrics_and_logs_fn(
        audit=compaction_audit,
        mode="cow",
        metrics_config=params.metrics_config,
    )

    return create_round_completion_info_fn(
        params=params,
        mutable_compaction_audit=compaction_audit,
        compacted_partition=compacted_partition,
        compacted_delta=compacted_delta,
        audit_url=audit_url,
        hb_id_to_entry_indices_range=hb_id_to_entry_indices_range,
        rci_source_partition_locator=rci_source_partition_locator,
        new_compacted_delta_locator=new_compacted_delta_locator,
        pyarrow_write_result=pyarrow_write_result,
        prev_round_completion_info=round_completion_info,
    )


def create_round_completion_info(
    *,
    params: Any,
    mutable_compaction_audit: Any,
    compacted_partition: Any,
    compacted_delta: Any = None,
    audit_url: str,
    hb_id_to_entry_indices_range: dict,
    rci_source_partition_locator: Any,
    new_compacted_delta_locator: Any,
    pyarrow_write_result: Any,
    prev_round_completion_info: Optional[Any],
    update_and_upload_compaction_audit_fn,
    is_inplace_compacted_fn,
    round_completion_info_factory,
    execution_compaction_result_factory,
    compactor_version_value: str,
    range_strategy_value: str,
    sha1_hash_strategy_value: str,
    log_info_fn,
) -> Any:
    """Create the round-completion info and wrap it in an execution result."""
    input_inflation = None
    input_average_record_size_bytes = None
    if (
        mutable_compaction_audit.input_size_bytes
        and mutable_compaction_audit.hash_bucket_processed_size_bytes
    ):
        input_inflation = (
            mutable_compaction_audit.hash_bucket_processed_size_bytes
            / mutable_compaction_audit.input_size_bytes
        )

    if (
        mutable_compaction_audit.hash_bucket_processed_size_bytes
        and mutable_compaction_audit.input_records
    ):
        input_average_record_size_bytes = (
            mutable_compaction_audit.hash_bucket_processed_size_bytes
            / mutable_compaction_audit.input_records
        )

    log_info_fn(
        f"The inflation of input deltas={input_inflation}"
        f" and average record size={input_average_record_size_bytes}"
    )

    mutable_compaction_audit.set_observed_input_inflation(input_inflation)
    mutable_compaction_audit.set_observed_input_average_record_size_bytes(
        input_average_record_size_bytes
    )

    update_and_upload_compaction_audit_fn(
        params,
        mutable_compaction_audit,
        prev_round_completion_info,
    )

    log_info_fn(
        f"Checking if partition {rci_source_partition_locator} is inplace compacted against {params.destination_partition_locator}..."
    )
    is_inplace_compacted = is_inplace_compacted_fn(
        rci_source_partition_locator, params.destination_partition_locator
    )

    if is_inplace_compacted:
        log_info_fn(
            "In-place compaction detected. Using compacted partition locator as prev_source_partition_locator. "
            + f"Got compacted partition partition_id of {compacted_partition.locator.partition_id} "
            f"and rci source partition_id of {rci_source_partition_locator.partition_id}."
        )
        prev_source_partition_locator = compacted_partition.locator
        rci_source_partition_locator = compacted_partition.locator
    else:
        prev_source_partition_locator = rci_source_partition_locator

    new_round_completion_info = round_completion_info_factory.of(
        high_watermark=new_compacted_delta_locator.stream_position,
        compacted_delta_locator=new_compacted_delta_locator,
        compacted_pyarrow_write_result=pyarrow_write_result,
        sort_keys_bit_width=params.bit_width_of_sort_keys,
        manifest_entry_copied_by_reference_ratio=mutable_compaction_audit.untouched_file_ratio,
        compaction_audit_url=audit_url,
        hash_bucket_count=params.hash_bucket_count,
        hb_index_to_entry_range=hb_id_to_entry_indices_range,
        compactor_version=compactor_version_value,
        input_inflation=input_inflation,
        input_average_record_size_bytes=input_average_record_size_bytes,
        prev_source_partition_locator=prev_source_partition_locator,
    )

    range_boundaries = params.get("_range_boundaries")
    if range_boundaries:
        new_round_completion_info["rangeBoundaries"] = range_boundaries
        new_round_completion_info["bucketingStrategy"] = range_strategy_value
    else:
        new_round_completion_info["bucketingStrategy"] = sha1_hash_strategy_value

    log_info_fn(
        f"Partition-{params.source_partition_locator.partition_values},"
        f"compacted at: {params.last_stream_position_to_compact},"
    )

    return execution_compaction_result_factory(
        compacted_partition,
        new_round_completion_info,
        [compacted_delta] if compacted_delta is not None else None,
        is_inplace_compacted,
    )


def run_hash_and_merge(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    round_completion_info: Any,
    delete_strategy: Optional[Any],
    delete_file_envelopes: Optional[Any],
    mutable_compaction_audit: Any,
    previous_compacted_delta_manifest: Optional[Any],
    compacted_partition: Any,
    normalize_output_sort_scheme_fn,
    run_range_bucketing_fn,
    hash_bucket_fn,
    aggregate_bucket_results_fn,
    run_local_merge_fn,
    merge_fn,
    merge_task_resource_options_provider_fn,
    merge_resource_options_provider_fn,
    upload_audit_data_fn,
    hash_bucket_step_name: str,
    merge_step_name: str,
    monotonic_time_fn,
    wall_time_fn,
    log_info_fn,
) -> list[Any]:
    """Run the bucketing plus merge phase of compaction."""
    telemetry_time_hb = 0
    total_input_records_count = 0
    total_hb_record_count = 0

    sort_scheme = normalize_output_sort_scheme_fn(params.output_sort_scheme)
    use_range_bucketing = False
    effective_sort_col = None
    if sort_scheme and sort_scheme.keys:
        use_range_bucketing = True
        effective_sort_col = sort_scheme.keys[0].key[0]

    if params.hash_bucket_count == 1:
        log_info_fn("Hash bucket count set to 1. Running local merge")
        merge_start = monotonic_time_fn()
        merge_results, total_input_records_count = run_local_merge_fn(
            params,
            uniform_deltas,
            compacted_partition,
            round_completion_info,
            delete_strategy,
            delete_file_envelopes,
            mutable_compaction_audit,
            previous_compacted_delta_manifest,
            total_input_records_count,
        )
        merge_invoke_end = merge_start
    else:
        hb_start = monotonic_time_fn()
        if use_range_bucketing:
            hb_results, hb_invoke_end, range_boundaries = run_range_bucketing_fn(
                params, uniform_deltas, effective_sort_col, round_completion_info
            )
            params["_range_boundaries"] = range_boundaries
        else:
            hb_results, hb_invoke_end = hash_bucket_fn(params, uniform_deltas)
        hb_end = monotonic_time_fn()
        hb_results_retrieved_at = wall_time_fn()

        telemetry_time_hb = mutable_compaction_audit.save_step_stats(
            hash_bucket_step_name,
            hb_results,
            hb_results_retrieved_at,
            hb_invoke_end - hb_start,
            hb_end - hb_start,
        )

        upload_audit_data_fn(
            params,
            mutable_compaction_audit,
        )

        (
            all_hash_group_idx_to_obj_id,
            all_hash_group_idx_to_size_bytes,
            all_hash_group_idx_to_num_rows,
            total_input_records_count,
            total_hb_record_count,
        ) = aggregate_bucket_results_fn(params, hb_results)

        mutable_compaction_audit.set_hash_bucket_processed_size_bytes(
            sum(r.hb_size_bytes for r in hb_results)
        )

        merge_start = monotonic_time_fn()
        merge_results, merge_invoke_end = merge_fn(
            params,
            merge_task_resource_options_provider_fn,
            merge_resource_options_provider_fn,
            all_hash_group_idx_to_size_bytes,
            all_hash_group_idx_to_num_rows,
            round_completion_info,
            previous_compacted_delta_manifest,
            all_hash_group_idx_to_obj_id,
            compacted_partition,
            delete_strategy,
            delete_file_envelopes,
        )

    log_info_fn(f"Got {len(merge_results)} merge results.")
    merge_results_retrieved_at = wall_time_fn()
    merge_end = monotonic_time_fn()

    total_dd_record_count = sum(ddr.deduped_record_count for ddr in merge_results)
    total_deleted_record_count = sum(ddr.deleted_record_count for ddr in merge_results)
    log_info_fn(
        f"Deduped {total_dd_record_count} records and deleted {total_deleted_record_count} records..."
    )

    total_input_records_int = (
        total_input_records_count.item()
        if hasattr(total_input_records_count, "item")
        else total_input_records_count
    )
    total_dd_record_count_int = (
        total_dd_record_count.item()
        if hasattr(total_dd_record_count, "item")
        else total_dd_record_count
    )
    total_deleted_record_count_int = (
        total_deleted_record_count.item()
        if hasattr(total_deleted_record_count, "item")
        else total_deleted_record_count
    )

    mutable_compaction_audit.set_input_records(total_input_records_int)

    telemetry_time_merge = mutable_compaction_audit.save_step_stats(
        merge_step_name,
        merge_results,
        merge_results_retrieved_at,
        merge_invoke_end - merge_start,
        merge_end - merge_start,
    )

    mutable_compaction_audit.set_records_deduped(total_dd_record_count_int)
    mutable_compaction_audit.set_records_deleted(total_deleted_record_count_int)
    log_info_fn(
        f"Hash bucket records: {total_hb_record_count},"
        f" Deduped records: {total_dd_record_count}, "
        f" Deleted records: {total_deleted_record_count}, "
    )

    telemetry_this_round = telemetry_time_hb + telemetry_time_merge
    previous_telemetry = (
        mutable_compaction_audit.telemetry_time_in_seconds
        if mutable_compaction_audit.telemetry_time_in_seconds
        else 0.0
    )
    mutable_compaction_audit.set_telemetry_time_in_seconds(
        telemetry_this_round + previous_telemetry
    )
    params.object_store.clear()
    if params.num_rounds > 1:
        log_info_fn(f"Cleared object store after {params.num_rounds} rounds.")

    return merge_results


def run_merge(
    *,
    params: Any,
    task_resource_options_provider_fn,
    merge_resource_options_provider_fn,
    all_hash_group_idx_to_size_bytes: dict,
    all_hash_group_idx_to_num_rows: dict,
    round_completion_info: Any,
    previous_compacted_delta_manifest: Any,
    all_hash_group_idx_to_obj_id: dict,
    compacted_partition: Any,
    delete_strategy: Any,
    delete_file_envelopes: Any,
    merge_input_factory,
    remote_merge_file_groups_provider_factory,
    invoke_parallel_fn,
    merge_task,
    ray_get_fn,
    task_max_parallelism: int,
    monotonic_time_fn,
) -> tuple[list[Any], Any]:
    """Run distributed merge tasks for the compaction path."""
    merge_options_provider = functools.partial(
        task_resource_options_provider_fn,
        pg_config=params.pg_config,
        resource_amount_provider=merge_resource_options_provider_fn,
        num_hash_groups=params.hash_group_count,
        hash_group_size_bytes=all_hash_group_idx_to_size_bytes,
        hash_group_num_rows=all_hash_group_idx_to_num_rows,
        total_memory_buffer_percentage=params.total_memory_buffer_percentage,
        round_completion_info=round_completion_info,
        compacted_delta_manifest=previous_compacted_delta_manifest,
        primary_keys=params.primary_keys,
        ray_custom_resources=params.ray_custom_resources,
        memory_logs_enabled=params.memory_logs_enabled,
        estimate_resources_params=params.estimate_resources_params,
    )

    if round_completion_info:
        previous_compacted_delta_manifest = params.deltacat_storage.get_delta_manifest(
            round_completion_info.compacted_delta_locator,
            **params.deltacat_storage_kwargs,
        )

    deltacat_storage_kwargs_copy = {
        k: v for k, v in params.deltacat_storage_kwargs.items() if k != "transaction"
    }

    def merge_input_provider(index, item) -> dict[str, Any]:
        return {
            "input": merge_input_factory.of(
                merge_file_groups_provider=remote_merge_file_groups_provider_factory(
                    hash_group_index=item[0],
                    dfe_groups_refs=item[1],
                    hash_bucket_count=params.hash_bucket_count,
                    num_hash_groups=params.hash_group_count,
                    object_store=params.object_store,
                ),
                write_to_partition=compacted_partition,
                compacted_file_content_type=params.compacted_file_content_type,
                primary_keys=params.primary_keys,
                all_column_names=params.all_column_names,
                sort_keys=params.sort_keys,
                sort_keys_precede_stream_position=params.sort_keys_precede_stream_position,
                merge_task_index=index,
                drop_duplicates=params.drop_duplicates,
                max_records_per_output_file=params.records_per_compacted_file,
                enable_profiler=params.enable_profiler,
                metrics_config=params.metrics_config,
                table_writer_kwargs=params.table_writer_kwargs,
                read_kwargs_provider=params.read_kwargs_provider,
                round_completion_info=round_completion_info,
                object_store=params.object_store,
                deltacat_storage=params.deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs_copy,
                delete_strategy=delete_strategy,
                delete_file_envelopes=delete_file_envelopes,
                memory_logs_enabled=params.memory_logs_enabled,
                disable_copy_by_reference=params.disable_copy_by_reference,
                hash_bucket_count=params.hash_bucket_count,
                original_fields=params.original_fields,
                compacted_manifest=previous_compacted_delta_manifest,
                output_sort_scheme=params.output_sort_scheme,
            )
        }

    merge_tasks_pending = invoke_parallel_fn(
        items=all_hash_group_idx_to_obj_id.items(),
        ray_task=merge_task,
        max_parallelism=task_max_parallelism,
        options_provider=merge_options_provider,
        kwargs_provider=merge_input_provider,
    )
    merge_invoke_end = monotonic_time_fn()
    merge_results = ray_get_fn(merge_tasks_pending)
    return merge_results, merge_invoke_end
