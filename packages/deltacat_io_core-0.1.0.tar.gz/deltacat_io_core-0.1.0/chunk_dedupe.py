"""Shared chunk-preserving dedupe helpers."""

from __future__ import annotations

import logging

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc

from deltacat_io_core import logs
from deltacat_io_core import system_columns as sc
from deltacat_io_core.performance_support import timed_invocation

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def _create_chunked_index_array(array: pa.Array) -> pa.Array:
    chunk_lengths = [
        len(array.chunk(chunk_index)) for chunk_index in range(len(array.chunks))
    ]
    result = np.empty((len(chunk_lengths),), dtype="object")
    for index, cl in enumerate(chunk_lengths):
        result[index] = np.arange(cl, dtype="int32")
    chunk_lengths = ([0] + chunk_lengths)[:-1]
    return pa.chunked_array(result + np.cumsum(chunk_lengths), type=pa.int32())


def drop_duplicates(table: pa.Table, on: str) -> pa.Table:
    if on not in table.column_names:
        return table

    index_array, array_latency = timed_invocation(
        _create_chunked_index_array, table[on]
    )
    logger.info(
        "Created a chunked index array of length %s in %ss",
        len(index_array),
        array_latency,
    )

    table = table.set_column(
        table.shape[1],
        sc._ORDERED_RECORD_IDX_COLUMN_NAME,
        index_array,
    )
    selector = table.group_by([on]).aggregate(
        [(sc._ORDERED_RECORD_IDX_COLUMN_NAME, "max")]
    )
    table = table.filter(
        pc.is_in(
            table[sc._ORDERED_RECORD_IDX_COLUMN_NAME],
            value_set=selector[f"{sc._ORDERED_RECORD_IDX_COLUMN_NAME}_max"],
        )
    )
    return table.drop([sc._ORDERED_RECORD_IDX_COLUMN_NAME])
