"""Shared merge-key helpers moved out of thick catalog/server paths."""

from __future__ import annotations

from typing import Any, Optional, Sequence


def merge_key_field_names(schema: Optional[Any]) -> list[str]:
    """Extract merge-key field names from a generic DeltaCAT schema object."""
    if not schema or not getattr(schema, "merge_keys", None):
        return []

    field_ids_to_fields = getattr(schema, "field_ids_to_fields", {}) or {}
    result: list[str] = []
    for merge_key_id in schema.merge_keys:
        if merge_key_id in field_ids_to_fields:
            result.append(field_ids_to_fields[merge_key_id].arrow.name)
    return result


def default_entry_params_for_merge_keys(
    *,
    mode: Any,
    schema: Optional[Any],
    existing_entry_params: Optional[Any],
    merge_mode: Any,
    delete_mode: Any,
    entry_params_factory,
) -> Optional[Any]:
    """Return default entry params from merge keys when mode requires them."""
    if mode not in (merge_mode, delete_mode):
        return existing_entry_params
    if existing_entry_params is not None:
        return existing_entry_params
    merge_keys = merge_key_field_names(schema)
    if not merge_keys:
        return existing_entry_params
    return entry_params_factory(list(merge_keys))


def apply_default_entry_params_to_entries(
    entries: Sequence[dict[str, Any]],
    *,
    default_entry_params: Optional[Any],
) -> list[dict[str, Any]]:
    """Fill missing entry_params on manifest entry dicts."""
    if default_entry_params is None:
        return list(entries)
    normalized_entries = []
    for entry in entries:
        updated = dict(entry)
        if updated.get("entry_params") is None:
            updated["entry_params"] = default_entry_params
        normalized_entries.append(updated)
    return normalized_entries
