"""Shared constructor/serialization helpers for CompactPartitionParams."""

from __future__ import annotations

import copy
import json
from typing import Any, Dict


def json_handler_for_compact_partition_params(obj):
    """JSON serializer fallback used by CompactPartitionParams.serialize()."""
    try:
        if isinstance(obj, set):
            return list(obj)
        if hasattr(obj, "toJSON"):
            return obj.toJSON()
        return obj.__dict__
    except Exception:
        return obj.__class__.__name__


def serialize_compact_partition_params(params_obj) -> str:
    """Serialize CompactPartitionParams-like objects to JSON."""
    to_serialize: Dict[str, Any] = {}
    for attr, value in params_obj.items():
        try:
            to_serialize[attr] = copy.deepcopy(value)
        except Exception:
            to_serialize[attr] = value.__class__.__name__
    return json.dumps(
        to_serialize,
        default=json_handler_for_compact_partition_params,
    )


def build_compact_partition_params(
    params: Dict[str, Any] | None,
    *,
    params_cls,
    object_store_factory,
    deltacat_storage_default,
    validate_sort_keys_fn,
    max_records_per_compacted_file: int,
    task_max_parallelism: int,
    min_files_in_batch: int | float,
    min_delta_bytes_in_batch: float,
    average_record_size_bytes: float,
    total_memory_buffer_percentage: int,
    default_disable_copy_by_reference: bool,
    default_num_rounds: int,
    parquet_to_pyarrow_inflation: float,
    max_parquet_metadata_size: int,
    pyarrow_inflation_multiplier: float,
    drop_duplicates_default: bool,
    resource_estimation_method_enum,
    memray_available: bool,
):
    """Build a CompactPartitionParams-like object using injected defaults."""
    params = {} if params is None else params
    assert (
        params.get("destination_partition_locator") is not None
    ), "destination_partition_locator is a required arg"
    assert (
        params.get("last_stream_position_to_compact") is not None
    ), "last_stream_position_to_compact is a required arg"
    assert (
        params.get("source_partition_locator") is not None
    ), "source_partition_locator is a required arg"
    assert params.get("catalog") is not None, "catalog is a required arg"
    assert (
        params.get("all_column_names") is not None
    ), "all_column_names is a required arg"

    result = params_cls(params)
    assert (
        result.destination_partition_locator.partition_id
    ), "destination_partition_locator must have a globally unique partition_id"
    assert (
        result.source_partition_locator.partition_id
    ), "source_partition_locator must have a globally unique partition_id"
    if result.rebase_source_partition_locator:
        assert (
            result.rebase_source_partition_locator.partition_id
        ), "rebase_source_partition_locator must have a globally unique partition_id"

    result.records_per_compacted_file = params.get(
        "records_per_compacted_file",
        max_records_per_compacted_file,
    )
    result.compacted_file_content_type = params.get(
        "compacted_file_content_type",
        None,
    )
    result.object_store = params.get("object_store", object_store_factory())
    result.table_writer_kwargs = params.get("table_writer_kwargs", {})

    result.enable_profiler = params.get("enable_profiler", False)
    result.deltacat_storage = params.get("deltacat_storage", deltacat_storage_default)
    result.catalog = params.get("catalog")
    result.deltacat_storage_kwargs = params.get("deltacat_storage_kwargs", {})
    result.list_deltas_kwargs = params.get("list_deltas_kwargs", {})
    result.all_column_names = params.get("all_column_names")
    result.deltacat_storage_kwargs["catalog"] = result.catalog

    result.bit_width_of_sort_keys = validate_sort_keys_fn(
        result.source_partition_locator,
        result.sort_keys,
        result.deltacat_storage,
        result.deltacat_storage_kwargs,
    )
    result.task_max_parallelism = params.get(
        "task_max_parallelism",
        task_max_parallelism,
    )
    result.min_files_in_batch = params.get("min_files_in_batch", min_files_in_batch)
    result.min_delta_bytes_in_batch = params.get(
        "min_delta_bytes_in_batch",
        min_delta_bytes_in_batch,
    )
    result.previous_inflation = params.get(
        "previous_inflation",
        pyarrow_inflation_multiplier,
    )
    result.average_record_size_bytes = params.get(
        "average_record_size_bytes",
        average_record_size_bytes,
    )
    result.total_memory_buffer_percentage = params.get(
        "total_memory_buffer_percentage",
        total_memory_buffer_percentage,
    )
    result.hash_group_count = params.get(
        "hash_group_count",
        result.hash_bucket_count,
    )
    result.disable_copy_by_reference = params.get(
        "disable_copy_by_reference",
        default_disable_copy_by_reference,
    )
    result.drop_duplicates = params.get("drop_duplicates", drop_duplicates_default)
    result.output_sort_scheme = params.get("output_sort_scheme")
    result.ray_custom_resources = params.get("ray_custom_resources")
    result.sort_keys_precede_stream_position = params.get(
        "sort_keys_precede_stream_position",
        False,
    )
    result.memory_logs_enabled = params.get("memory_logs_enabled", False)
    result.metrics_config = params.get("metrics_config")
    result.num_rounds = params.get("num_rounds", default_num_rounds)
    result.parquet_to_pyarrow_inflation = params.get(
        "parquet_to_pyarrow_inflation",
        parquet_to_pyarrow_inflation,
    )
    result.resource_estimation_method = resource_estimation_method_enum[
        params.get(
            "resource_estimation_method",
            resource_estimation_method_enum.DEFAULT.value,
        )
    ]

    result.enable_input_split = params.get("rebase_source_partition_locator") is None
    result.max_parquet_meta_size_bytes = params.get(
        "max_parquet_meta_size_bytes",
        max_parquet_metadata_size,
    )

    if not memray_available:
        result.enable_profiler = False

    if result.primary_keys:
        result.primary_keys = sorted(result.primary_keys)

    result.original_fields = params.get("original_fields")

    assert (
        result.source_partition_locator.partition_values
        == result.destination_partition_locator.partition_values
    ), "Source and destination partitions values must be equal"
    assert (
        result.records_per_compacted_file and result.records_per_compacted_file >= 1
    ), "Max records per output file must be a positive value"

    return result
