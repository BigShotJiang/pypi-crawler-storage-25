"""Shared compaction audit model."""

from __future__ import annotations

import logging
import posixpath
import urllib.parse
from typing import List, Optional, Union

import pyarrow as pa

from deltacat_io_core import logs
from deltacat_io_core.compactor_base_models import (
    MaterializeResult,
    PyArrowWriteResult,
)
from deltacat_io_core.compactor_session_models import DedupeResult
from deltacat_io_core.compactor_task_models import HashBucketResult, MergeResult
from deltacat_io_core.performance_support import timed_invocation
from deltacat_io_core.resource_metrics import (
    ClusterUtilization,
    get_size_of_object_in_bytes,
)


logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def _relative_logical_child_path(root: str, target: str) -> str:
    root_parsed = urllib.parse.urlparse(root)
    target_parsed = urllib.parse.urlparse(target)
    if (root_parsed.scheme, root_parsed.netloc,) != (
        target_parsed.scheme,
        target_parsed.netloc,
    ):
        raise ValueError("Expected target to be a child of root.")

    root_path = root_parsed.path if root_parsed.scheme else root
    target_path = target_parsed.path if target_parsed.scheme else target
    normalized_root = posixpath.normpath(root_path)
    normalized_target = posixpath.normpath(target_path)
    if normalized_root == normalized_target:
        raise ValueError(
            "Target and root are identical, but expected target to be a child of root."
        )
    relative_path = posixpath.relpath(normalized_target, normalized_root)
    if relative_path == "." or relative_path.startswith("../"):
        raise ValueError("Expected target to be a child of root.")
    return relative_path


class CompactionSessionAuditInfo(dict):
    DEDUPE_STEP_NAME = "dedupe"
    MATERIALIZE_STEP_NAME = "materialize"
    HASH_BUCKET_STEP_NAME = "hashBucket"
    MERGE_STEP_NAME = "merge"

    def __init__(
        self,
        deltacat_version: Optional[str] = None,
        ray_version: Optional[str] = None,
        audit_url: Optional[str] = None,
        **kwargs,
    ):
        self.set_deltacat_version(deltacat_version)
        self.set_ray_version(ray_version)
        self.set_audit_url(audit_url)
        if kwargs:
            self.update(kwargs)

    @property
    def audit_url(self) -> str:
        return self.get("auditUrl")

    @property
    def deltacat_version(self) -> str:
        return self.get("deltacatVersion")

    @property
    def ray_version(self) -> str:
        return self.get("rayVersion")

    @property
    def input_records(self) -> int:
        return self.get("inputRecords")

    @property
    def input_file_count(self) -> int:
        return self.get("inputFileCount")

    @property
    def uniform_deltas_created(self) -> int:
        return self.get("uniformDeltasCreated")

    @property
    def records_deduped(self) -> int:
        return self.get("recordsDeduped")

    @property
    def records_deleted(self) -> int:
        return self.get("recordsDeleted")

    @property
    def input_size_bytes(self) -> float:
        return self.get("inputSizeBytes")

    @property
    def hash_bucket_count(self) -> int:
        return self.get("hashBucketCount")

    @property
    def compaction_time_in_seconds(self) -> float:
        return self.get("compactionTimeInSeconds")

    @property
    def total_object_store_memory_used_bytes(self) -> float:
        return self.get("totalObjectStoreMemoryUsedBytes")

    @property
    def peak_memory_used_bytes_per_task(self) -> float:
        return self.get("peakMemoryUsedBytesPerTask")

    @property
    def peak_memory_used_bytes_per_hash_bucket_task(self) -> float:
        return self.get("hashBucketTaskPeakMemoryUsedBytes")

    @property
    def peak_memory_used_bytes_per_dedupe_task(self) -> float:
        return self.get("dedupeTaskPeakMemoryUsedBytes")

    @property
    def peak_memory_used_bytes_per_materialize_task(self) -> float:
        return self.get("materializeTaskPeakMemoryUsedBytes")

    @property
    def peak_memory_used_bytes_per_merge_task(self) -> float:
        return self.get("mergeTaskPeakMemoryUsedBytes")

    @property
    def hash_bucket_post_object_store_memory_used_bytes(self) -> float:
        return self.get("hashBucketPostObjectStoreMemoryUsedBytes")

    @property
    def dedupe_post_object_store_memory_used_bytes(self) -> float:
        return self.get("dedupePostObjectStoreMemoryUsedBytes")

    @property
    def materialize_post_object_store_memory_used_bytes(self) -> float:
        return self.get("materializePostObjectStoreMemoryUsedBytes")

    @property
    def merge_post_object_store_memory_used_bytes(self) -> float:
        return self.get("mergePostObjectStoreMemoryUsedBytes")

    @property
    def materialize_buckets(self) -> int:
        return self.get("materializeBuckets")

    @property
    def hash_bucket_time_in_seconds(self) -> float:
        return self.get("hashBucketTimeInSeconds")

    @property
    def hash_bucket_invoke_time_in_seconds(self) -> float:
        return self.get("hashBucketInvokeTimeInSeconds")

    @property
    def hash_bucket_result_wait_time_in_seconds(self) -> float:
        return self.get("hashBucketResultWaitTimeInSeconds")

    @property
    def dedupe_time_in_seconds(self) -> float:
        return self.get("dedupeTimeInSeconds")

    @property
    def dedupe_invoke_time_in_seconds(self) -> float:
        return self.get("dedupeInvokeTimeInSeconds")

    @property
    def dedupe_result_wait_time_in_seconds(self) -> float:
        return self.get("dedupeResultWaitTimeInSeconds")

    @property
    def materialize_time_in_seconds(self) -> float:
        return self.get("materializeTimeInSeconds")

    @property
    def materialize_invoke_time_in_seconds(self) -> float:
        return self.get("materializeInvokeTimeInSeconds")

    @property
    def materialize_result_wait_time_in_seconds(self) -> float:
        return self.get("materializeResultWaitTimeInSeconds")

    @property
    def merge_result_wait_time_in_seconds(self) -> float:
        return self.get("mergeResultWaitTimeInSeconds")

    @property
    def merge_time_in_seconds(self) -> float:
        return self.get("mergeTimeInSeconds")

    @property
    def merge_invoke_time_in_seconds(self) -> float:
        return self.get("mergeInvokeTimeInSeconds")

    @property
    def delta_discovery_time_in_seconds(self) -> float:
        return self.get("deltaDiscoveryTimeInSeconds")

    @property
    def output_file_count(self) -> int:
        return self.get("outputFileCount")

    @property
    def output_size_bytes(self) -> float:
        return self.get("outputSizeBytes")

    @property
    def output_size_pyarrow_bytes(self) -> float:
        return self.get("outputSizePyarrowBytes")

    @property
    def total_cluster_memory_bytes(self) -> float:
        return self.get("totalClusterMemoryBytes")

    @property
    def total_cluster_object_store_memory_bytes(self) -> float:
        return self.get("totalClusterObjectStoreMemoryBytes")

    @property
    def untouched_file_count(self) -> int:
        return self.get("untouchedFileCount")

    @property
    def untouched_file_ratio(self) -> float:
        return self.get("untouchedFileRatio")

    @property
    def untouched_record_count(self) -> int:
        return self.get("untouchedRecordCount")

    @property
    def untouched_size_bytes(self) -> float:
        return self.get("untouchedSizeBytes")

    @property
    def telemetry_time_in_seconds(self) -> float:
        return self.get("telemetryTimeInSeconds")

    @property
    def hash_bucket_result_size_bytes(self) -> float:
        return self.get("hashBucketResultSize")

    @property
    def dedupe_result_size_bytes(self) -> float:
        return self.get("dedupeResultSize")

    @property
    def materialize_result_size(self) -> float:
        return self.get("materializeResultSize")

    @property
    def merge_result_size(self) -> float:
        return self.get("mergeResultSize")

    @property
    def peak_memory_used_bytes_by_compaction_session_process(self) -> float:
        return self.get("peakMemoryUsedBytesCompactionSessionProcess")

    @property
    def estimated_in_memory_size_bytes_during_discovery(self) -> float:
        return self.get("estimatedInMemorySizeBytesDuringDiscovery")

    @property
    def hash_bucket_processed_size_bytes(self) -> int:
        return self.get("hashBucketProcessedSizeBytes")

    @property
    def pyarrow_version(self) -> str:
        return self.get("pyarrowVersion")

    @property
    def compactor_version(self) -> str:
        return self.get("compactorVersion")

    @property
    def observed_input_inflation(self) -> float:
        return self.get("observedInputInflation")

    @property
    def observed_input_average_record_size_bytes(self) -> float:
        return self.get("observedInputAverageRecordSizeBytes")

    def set_audit_url(self, audit_url: str):
        self["auditUrl"] = audit_url
        return self

    def set_deltacat_version(self, version: str):
        self["deltacatVersion"] = version
        return self

    def set_ray_version(self, version: str):
        self["rayVersion"] = version
        return self

    def set_input_records(self, input_records: int):
        self["inputRecords"] = input_records
        return self

    def set_input_file_count(self, input_file_count: int):
        self["inputFileCount"] = input_file_count
        return self

    def set_uniform_deltas_created(self, uniform_deltas_created: int):
        self["uniformDeltasCreated"] = uniform_deltas_created
        return self

    def set_records_deduped(self, records_deduped: int):
        self["recordsDeduped"] = records_deduped
        return self

    def set_records_deleted(self, records_deleted: int):
        self["recordsDeleted"] = records_deleted
        return self

    def set_input_size_bytes(self, input_size_bytes: float):
        self["inputSizeBytes"] = input_size_bytes
        return self

    def set_hash_bucket_count(self, hash_bucket_count: int):
        self["hashBucketCount"] = hash_bucket_count
        return self

    def set_compaction_time_in_seconds(self, compaction_time_in_seconds: float):
        self["compactionTimeInSeconds"] = compaction_time_in_seconds
        return self

    def set_total_object_store_memory_used_bytes(
        self,
        total_object_store_memory_used_bytes: float,
    ):
        self["totalObjectStoreMemoryUsedBytes"] = total_object_store_memory_used_bytes
        return self

    def set_peak_memory_used_bytes_per_task(self, peak_memory_used_bytes: float):
        self["peakMemoryUsedBytesPerTask"] = peak_memory_used_bytes
        return self

    def set_peak_memory_used_bytes_per_hash_bucket_task(
        self,
        peak_memory_used_bytes_per_hash_bucket_task: float,
    ):
        self[
            "hashBucketTaskPeakMemoryUsedBytes"
        ] = peak_memory_used_bytes_per_hash_bucket_task
        return self

    def set_peak_memory_used_bytes_per_dedupe_task(
        self,
        peak_memory_used_bytes_per_dedupe_task: float,
    ):
        self["dedupeTaskPeakMemoryUsedBytes"] = peak_memory_used_bytes_per_dedupe_task
        return self

    def set_peak_memory_used_bytes_per_materialize_task(
        self,
        peak_memory_used_bytes_per_materialize_task: float,
    ):
        self[
            "materializeTaskPeakMemoryUsedBytes"
        ] = peak_memory_used_bytes_per_materialize_task
        return self

    def set_peak_memory_used_bytes_per_merge_task(self, peak_memory_used_bytes: float):
        self["mergeTaskPeakMemoryUsedBytes"] = peak_memory_used_bytes
        return self

    def set_hash_bucket_post_object_store_memory_used_bytes(
        self,
        object_store_memory_used_bytes_by_hb: float,
    ):
        self[
            "hashBucketPostObjectStoreMemoryUsedBytes"
        ] = object_store_memory_used_bytes_by_hb
        return self

    def set_dedupe_post_object_store_memory_used_bytes(
        self,
        object_store_memory_used_bytes_by_dedupe: float,
    ):
        self[
            "dedupePostObjectStoreMemoryUsedBytes"
        ] = object_store_memory_used_bytes_by_dedupe
        return self

    def set_materialize_post_object_store_memory_used_bytes(
        self,
        object_store_memory_used_bytes_by_dedupe: float,
    ):
        self[
            "materializePostObjectStoreMemoryUsedBytes"
        ] = object_store_memory_used_bytes_by_dedupe
        return self

    def set_merge_post_object_store_memory_used_bytes(
        self,
        object_store_memory_used_bytes: float,
    ):
        self["mergePostObjectStoreMemoryUsedBytes"] = object_store_memory_used_bytes
        return self

    def set_materialize_buckets(self, materialize_buckets: int):
        self["materializeBuckets"] = materialize_buckets
        return self

    def set_hash_bucket_time_in_seconds(self, hash_bucket_time_in_seconds: float):
        self["hashBucketTimeInSeconds"] = hash_bucket_time_in_seconds
        return self

    def set_hash_bucket_invoke_time_in_seconds(self, hash_bucket_invoke_time: float):
        self["hashBucketInvokeTimeInSeconds"] = hash_bucket_invoke_time
        return self

    def set_hash_bucket_result_wait_time_in_seconds(self, wait_time: float):
        self["hashBucketResultWaitTimeInSeconds"] = wait_time
        return self

    def set_dedupe_time_in_seconds(self, dedupe_time_in_seconds: float):
        self["dedupeTimeInSeconds"] = dedupe_time_in_seconds
        return self

    def set_dedupe_invoke_time_in_seconds(self, dedupe_invoke_time: float):
        self["dedupeInvokeTimeInSeconds"] = dedupe_invoke_time
        return self

    def set_dedupe_result_wait_time_in_seconds(self, wait_time: float):
        self["dedupeResultWaitTimeInSeconds"] = wait_time
        return self

    def set_materialize_time_in_seconds(self, materialize_time_in_seconds: float):
        self["materializeTimeInSeconds"] = materialize_time_in_seconds
        return self

    def set_materialize_invoke_time_in_seconds(self, materialize_invoke_time: float):
        self["materializeInvokeTimeInSeconds"] = materialize_invoke_time
        return self

    def set_materialize_result_wait_time_in_seconds(self, wait_time: float):
        self["materializeResultWaitTimeInSeconds"] = wait_time
        return self

    def set_merge_time_in_seconds(self, time_in_seconds: float):
        self["mergeTimeInSeconds"] = time_in_seconds
        return self

    def set_merge_invoke_time_in_seconds(self, invoke_time: float):
        self["mergeInvokeTimeInSeconds"] = invoke_time
        return self

    def set_merge_result_wait_time_in_seconds(self, wait_time: float):
        self["mergeResultWaitTimeInSeconds"] = wait_time
        return self

    def set_delta_discovery_time_in_seconds(
        self, delta_discovery_time_in_seconds: float
    ):
        self["deltaDiscoveryTimeInSeconds"] = delta_discovery_time_in_seconds
        return self

    def set_output_file_count(self, output_file_count: float):
        self["outputFileCount"] = output_file_count
        return self

    def set_output_size_bytes(self, output_size_bytes: float):
        self["outputSizeBytes"] = output_size_bytes
        return self

    def set_output_size_pyarrow_bytes(self, output_size_pyarrow_bytes: float):
        self["outputSizePyarrowBytes"] = output_size_pyarrow_bytes
        return self

    def set_total_cluster_memory_bytes(self, total_cluster_memory_bytes: float):
        self["totalClusterMemoryBytes"] = total_cluster_memory_bytes
        return self

    def set_total_cluster_object_store_memory_bytes(
        self,
        total_cluster_object_store_memory_bytes: float,
    ):
        self[
            "totalClusterObjectStoreMemoryBytes"
        ] = total_cluster_object_store_memory_bytes
        return self

    def set_untouched_file_count(self, untouched_file_count: int):
        self["untouchedFileCount"] = untouched_file_count
        return self

    def set_untouched_file_ratio(self, untouched_file_ratio: float):
        self["untouchedFileRatio"] = untouched_file_ratio
        return self

    def set_untouched_record_count(self, untouched_record_count: int):
        self["untouchedRecordCount"] = untouched_record_count
        return self

    def set_untouched_size_bytes(self, untouched_size_bytes: float):
        self["untouchedSizeBytes"] = untouched_size_bytes
        return self

    def set_telemetry_time_in_seconds(self, telemetry_time_in_seconds: float):
        self["telemetryTimeInSeconds"] = telemetry_time_in_seconds
        return self

    def set_hash_bucket_result_size_bytes(self, hash_bucket_result_size_bytes: float):
        self["hashBucketResultSize"] = hash_bucket_result_size_bytes
        return self

    def set_dedupe_result_size_bytes(self, dedupe_result_size_bytes: float):
        self["dedupeResultSize"] = dedupe_result_size_bytes
        return self

    def set_materialize_result_size_bytes(self, materialize_result_size_bytes: float):
        self["materializeResultSize"] = materialize_result_size_bytes
        return self

    def set_merge_result_size_bytes(self, merge_result_size_bytes: float):
        self["mergeResultSize"] = merge_result_size_bytes
        return self

    def set_peak_memory_used_bytes_by_compaction_session_process(
        self, peak_memory: float
    ):
        self["peakMemoryUsedBytesCompactionSessionProcess"] = peak_memory
        return self

    def set_estimated_in_memory_size_bytes_during_discovery(self, memory: float):
        self["estimatedInMemorySizeBytesDuringDiscovery"] = memory
        return self

    def set_hash_bucket_processed_size_bytes(self, size: int):
        self["hashBucketProcessedSizeBytes"] = size
        return self

    def set_pyarrow_version(self, value: str):
        self["pyarrowVersion"] = value
        return self

    def set_compactor_version(self, value: str):
        self["compactorVersion"] = value
        return self

    def set_observed_input_inflation(self, value: float):
        self["observedInputInflation"] = value
        return self

    def set_observed_input_average_record_size_bytes(self, value: float):
        self["observedInputAverageRecordSizeBytes"] = value
        return self

    def save_step_stats(
        self,
        step_name: str,
        task_results: Union[
            List[HashBucketResult],
            List[DedupeResult],
            List[MaterializeResult],
            List[MergeResult],
        ],
        task_results_retrieved_at: float,
        invoke_time_in_seconds: float,
        task_time_in_seconds: float,
    ) -> float:
        self[f"{step_name}TimeInSeconds"] = task_time_in_seconds
        self[f"{step_name}InvokeTimeInSeconds"] = invoke_time_in_seconds
        self[f"{step_name}ResultSize"] = get_size_of_object_in_bytes(task_results)

        (
            cluster_utilization_after_task,
            cluster_util_after_task_latency,
        ) = timed_invocation(ClusterUtilization.get_current_cluster_utilization)

        self.set_total_cluster_object_store_memory_bytes(
            cluster_utilization_after_task.total_object_store_memory_bytes
        )
        self.set_total_cluster_memory_bytes(
            cluster_utilization_after_task.total_memory_bytes
        )
        self.set_total_object_store_memory_used_bytes(
            cluster_utilization_after_task.used_object_store_memory_bytes
        )
        self[
            f"{step_name}PostObjectStoreMemoryUsedBytes"
        ] = cluster_utilization_after_task.used_object_store_memory_bytes

        telemetry_time = 0
        if task_results:
            last_task_completed_at = max(
                result.task_completed_at for result in task_results
            )
            if hasattr(last_task_completed_at, "item"):
                last_task_completed_at = last_task_completed_at.item()
            self[f"{step_name}ResultWaitTimeInSeconds"] = (
                task_results_retrieved_at - last_task_completed_at
            )

            peak_task_memory = max(
                result.peak_memory_usage_bytes for result in task_results
            )
            telemetry_time = sum(
                result.telemetry_time_in_seconds for result in task_results
            )
            if hasattr(peak_task_memory, "item"):
                peak_task_memory = peak_task_memory.item()
            self[f"{step_name}TaskPeakMemoryUsedBytes"] = peak_task_memory

        return cluster_util_after_task_latency + telemetry_time

    def save_round_completion_stats(self, mat_results: List[MaterializeResult]) -> None:
        pyarrow_write_result = PyArrowWriteResult.union(
            [m.pyarrow_write_result for m in mat_results]
        )

        total_count_of_src_dfl_not_touched = sum(
            m.referenced_pyarrow_write_result.files
            if m.referenced_pyarrow_write_result
            else 0
            for m in mat_results
        )

        logger.info(
            "Got total of %s manifest files not touched.",
            total_count_of_src_dfl_not_touched,
        )
        logger.info(
            "Got total of %s manifest files during compaction.",
            pyarrow_write_result.files,
        )
        manifest_entry_copied_by_reference_ratio = (
            (
                round(
                    total_count_of_src_dfl_not_touched / pyarrow_write_result.files,
                    4,
                )
                * 100
            )
            if pyarrow_write_result.files != 0
            else None
        )
        logger.info(
            "%s percent of manifest files are copied by reference during materialize.",
            manifest_entry_copied_by_reference_ratio,
        )

        untouched_file_record_count = sum(
            m.referenced_pyarrow_write_result.records
            if m.referenced_pyarrow_write_result
            else 0
            for m in mat_results
        )
        untouched_file_size_bytes = sum(
            m.referenced_pyarrow_write_result.file_bytes
            if m.referenced_pyarrow_write_result
            else 0
            for m in mat_results
        )

        self.set_untouched_file_count(total_count_of_src_dfl_not_touched)
        self.set_untouched_file_ratio(manifest_entry_copied_by_reference_ratio)
        self.set_untouched_record_count(untouched_file_record_count)
        self.set_untouched_size_bytes(untouched_file_size_bytes)

        self.set_output_file_count(pyarrow_write_result.files)
        self.set_output_size_bytes(pyarrow_write_result.file_bytes)
        self.set_output_size_pyarrow_bytes(pyarrow_write_result.pyarrow_bytes)

        self.set_peak_memory_used_bytes_per_task(
            max(
                [
                    self.peak_memory_used_bytes_per_hash_bucket_task or 0,
                    self.peak_memory_used_bytes_per_dedupe_task or 0,
                    self.peak_memory_used_bytes_per_materialize_task or 0,
                    self.peak_memory_used_bytes_per_merge_task or 0,
                ]
            )
        )

        self.set_pyarrow_version(pa.__version__)

    def to_serializable(self, catalog_root: str):
        try:
            relative_path = _relative_logical_child_path(
                catalog_root,
                self.audit_url,
            )
            audit_copy = CompactionSessionAuditInfo(**dict(self))
            audit_copy["auditUrl"] = relative_path
            return audit_copy
        except ValueError:
            raise ValueError("Expected target to be a child of root.")
