"""Shared helpers for merge-task execution."""

from __future__ import annotations

from typing import Any

import numpy as np


def execute_merge_core(
    input: Any,
    *,
    can_copy_by_reference_fn,
    has_previous_compacted_table_fn,
    download_compacted_table_fn,
    compact_tables_fn,
    merge_core_result_factory,
    log_warning_fn,
) -> Any:
    """Core merge logic shared by COW merge and MOR merge-for-read."""
    total_input_records, total_deduped_records = 0, 0
    total_dropped_records = 0
    tables = []
    merge_file_groups = input.merge_file_groups_provider.create()
    hb_index_copy_by_ref_ids = []

    for merge_file_group in merge_file_groups:
        compacted_table = None
        has_delete = input.delete_file_envelopes is not None
        if has_delete:
            assert (
                input.delete_strategy is not None
            ), "Merge input missing delete_strategy"
        if can_copy_by_reference_fn(merge_file_group):
            hb_index_copy_by_ref_ids.append(merge_file_group.hb_index)
            continue
        if has_previous_compacted_table_fn(merge_file_group.hb_index):
            compacted_table = download_compacted_table_fn(merge_file_group.hb_index)
        if not merge_file_group.dfe_groups and compacted_table is None:
            log_warning_fn(
                f" [Hash bucket index {merge_file_group.hb_index}]"
                + f" No new deltas and no compacted table found. Skipping compaction for {merge_file_group.hb_index}"
            )
            continue
        table, input_records, deduped_records, dropped_records = compact_tables_fn(
            merge_file_group.dfe_groups,
            merge_file_group.hb_index,
            compacted_table,
        )
        total_input_records += input_records
        total_deduped_records += deduped_records
        total_dropped_records += dropped_records
        tables.append((merge_file_group.hb_index, table))

    return merge_core_result_factory(
        tables=tables,
        copy_by_ref_ids=hb_index_copy_by_ref_ids,
        total_input_records=total_input_records,
        total_deduped_records=total_deduped_records,
        total_dropped_records=total_dropped_records,
    )


def execute_materializing_merge(
    input: Any,
    *,
    timed_merge_core_fn,
    materialize_table_fn,
    copy_manifests_by_reference_fn,
    current_process_peak_memory_fn,
    merge_result_factory,
    wall_time_fn,
    log_info_fn,
) -> Any:
    """Run the COW merge task on top of the shared merge core."""
    core = timed_merge_core_fn(input)

    materialized_results = []
    for hb_index, table in core.tables:
        materialized_results.append(materialize_table_fn(hb_index, table))

    if core.copy_by_ref_ids:
        materialized_results.extend(
            copy_manifests_by_reference_fn(core.copy_by_ref_ids)
        )

    log_info_fn(
        f"[Hash group index: {input.merge_file_groups_provider.hash_group_index}]"
        f" Total number of materialized results produced: {len(materialized_results)} "
    )

    peak_memory_usage_bytes = current_process_peak_memory_fn()
    log_info_fn(f"Peak memory usage in bytes after merge: {peak_memory_usage_bytes}")

    return merge_result_factory(
        materialized_results,
        np.int64(core.total_input_records),
        np.int64(core.total_deduped_records),
        np.int64(core.total_dropped_records),
        np.double(peak_memory_usage_bytes),
        np.double(0.0),
        np.double(wall_time_fn()),
    )


def execute_merge_for_read(
    input: Any,
    *,
    timed_merge_core_fn,
    has_previous_compacted_table_fn,
    download_compacted_table_fn,
    concat_tables_fn,
    empty_table_factory,
    ray_put_fn,
    current_process_peak_memory_fn,
    merge_for_read_result_factory,
    log_info_fn,
    log_warning_fn,
) -> Any:
    """Run the MOR merge task on top of the shared merge core."""
    core = timed_merge_core_fn(input)
    all_tables = [table for _, table in core.tables]

    for hb_index in core.copy_by_ref_ids:
        if has_previous_compacted_table_fn(hb_index):
            ref_table = download_compacted_table_fn(hb_index)
            if ref_table is not None and len(ref_table) > 0:
                all_tables.append(ref_table)

    combined = (
        concat_tables_fn(all_tables, promote_options="permissive")
        if all_tables
        else empty_table_factory()
    )
    num_rows = len(combined)

    table_ref = None
    table_inline = None
    try:
        table_ref = ray_put_fn(combined)
    except Exception as e:
        log_warning_fn(
            "merge_for_read: ray.put failed (%s), returning table "
            "inline (driver will collect via serialization)",
            e,
        )
        table_inline = combined

    peak_memory_usage_bytes = current_process_peak_memory_fn()
    log_info_fn(
        f"Merge-for-read: {num_rows} records from "
        f"{len(core.tables)} merged + {len(core.copy_by_ref_ids)} "
        f"copy-by-ref buckets. Peak memory: {peak_memory_usage_bytes}"
    )

    return merge_for_read_result_factory(
        table=table_inline,
        table_ref=table_ref,
        input_record_count=np.int64(core.total_input_records),
        deduped_record_count=np.int64(core.total_deduped_records),
        deleted_record_count=np.int64(core.total_dropped_records),
        peak_memory_usage_bytes=np.double(peak_memory_usage_bytes),
        num_rows=np.int64(num_rows),
    )


def has_previous_compacted_table(input: Any, hb_idx: int) -> bool:
    """Whether the requested hash bucket has compacted data in the previous round."""
    return (
        input.round_completion_info
        and input.compacted_manifest is not None
        and input.round_completion_info.hb_index_to_entry_range
        and input.round_completion_info.hb_index_to_entry_range.get(str(hb_idx))
        is not None
    )


def can_copy_by_reference(
    *,
    has_delete: bool,
    merge_file_group: Any,
    input: Any,
    log_info_fn,
) -> bool:
    """Whether this merge bucket can be handled via manifest copy-by-reference."""
    copy_by_ref = (
        not has_delete
        and not merge_file_group.dfe_groups
        and input.round_completion_info is not None
        and input.compacted_manifest is not None
    )

    if input.disable_copy_by_reference:
        copy_by_ref = False

    log_info_fn(f"Copy by reference is {copy_by_ref} for {merge_file_group.hb_index}")
    return copy_by_ref


def download_compacted_table(
    *,
    hb_index: int,
    rci: Any,
    primary_keys,
    all_column_names,
    compacted_delta_manifest,
    read_kwargs_provider,
    deltacat_storage,
    deltacat_storage_kwargs,
    delta_factory,
    append_delta_type,
    concat_tables_fn,
    check_bucketing_spec: bool,
    validate_bucketing_spec_compliance_fn,
    existing_variant_log_prefix: str,
    log_debug_fn,
) -> Any:
    """Download the compacted table for a single hash bucket from prior output."""
    tables = []
    hb_index_to_indices = rci.hb_index_to_entry_range

    if str(hb_index) not in hb_index_to_indices:
        return None
    indices = hb_index_to_indices[str(hb_index)]
    assert (
        indices is not None and len(indices) == 2
    ), "indices should not be none and contains exactly two elements"
    for offset in range(indices[1] - indices[0]):
        table = deltacat_storage.download_delta_manifest_entry(
            delta_factory(
                rci.compacted_delta_locator,
                append_delta_type,
                compacted_delta_manifest.meta,
                None,
                compacted_delta_manifest,
            ),
            entry_index=(indices[0] + offset),
            file_reader_kwargs_provider=read_kwargs_provider,
            all_column_names=all_column_names,
            **deltacat_storage_kwargs,
        )
        tables.append(table)

    compacted_table = concat_tables_fn(tables)
    log_debug_fn(
        "Value of BUCKETING_SPEC_COMPLIANCE_PROFILE, check_bucketing_spec:" " %s",
        check_bucketing_spec,
    )

    if primary_keys and check_bucketing_spec:
        validate_bucketing_spec_compliance_fn(
            compacted_table,
            rci.hash_bucket_count,
            hb_index,
            primary_keys,
            rci=rci,
            log_prefix=existing_variant_log_prefix,
        )
    return compacted_table


def copy_all_manifest_files_from_old_hash_buckets(
    *,
    hb_index_copy_by_reference,
    round_completion_info,
    write_to_partition,
    compacted_manifest,
    manifest_factory,
    delta_locator_of_fn,
    delta_factory,
    append_delta_type,
    pyarrow_write_result_factory,
    materialize_result_factory,
    uuid_factory,
    log_info_fn,
) -> list[Any]:
    """Create copy-by-reference materialize results for unchanged hash buckets."""
    manifest_entry_referenced_list = []
    materialize_result_list = []
    hb_index_to_indices = round_completion_info.hb_index_to_entry_range

    if hb_index_to_indices is None:
        log_info_fn("Nothing to copy by reference. Skipping...")
        return []

    for hb_index in hb_index_copy_by_reference:
        if str(hb_index) not in hb_index_to_indices:
            continue

        indices = hb_index_to_indices[str(hb_index)]
        for offset in range(indices[1] - indices[0]):
            entry_index = indices[0] + offset
            assert entry_index < len(
                compacted_manifest.entries
            ), f"entry index: {entry_index} >= {len(compacted_manifest.entries)}"
            manifest_entry = compacted_manifest.entries[entry_index]
            manifest_entry_referenced_list.append(manifest_entry)

        next_manifest = manifest_factory(
            entries=manifest_entry_referenced_list,
            uuid=uuid_factory(),
        )
        delta = delta_factory(
            locator=delta_locator_of_fn(write_to_partition.locator),
            delta_type=append_delta_type,
            meta=next_manifest.meta,
            manifest=next_manifest,
            previous_stream_position=write_to_partition.stream_position,
            properties={},
        )
        referenced_pyarrow_write_result = pyarrow_write_result_factory(
            len(manifest_entry_referenced_list),
            next_manifest.meta.source_content_length,
            next_manifest.meta.content_length,
            next_manifest.meta.record_count,
        )
        materialize_result = materialize_result_factory(
            delta=delta,
            task_index=hb_index,
            pyarrow_write_result=referenced_pyarrow_write_result,
            referenced_pyarrow_write_result=referenced_pyarrow_write_result,
        )
        materialize_result_list.append(materialize_result)
    return materialize_result_list


def copy_manifests_from_hash_bucketing(
    *,
    input: Any,
    hb_index_copy_by_reference_ids,
    copy_all_manifest_files_fn,
    log_info_fn,
) -> list[Any]:
    """Wrapper for copy-by-reference materialize-result production."""
    materialized_results = []
    if input.round_completion_info:
        referenced_materialized_results = copy_all_manifest_files_fn(
            hb_index_copy_by_reference_ids
        )
        log_info_fn(
            f"Copying {len(referenced_materialized_results)} manifest files by reference..."
        )
        materialized_results.extend(referenced_materialized_results)
    return materialized_results


def execute_apply_upserts(
    input: Any,
    dfe_list,
    hb_idx,
    prev_table=None,
    *,
    build_incremental_table_fn,
    timed_invocation_fn,
    merge_tables_fn,
    partition_stream_position_column_name: str,
    coerce_output_sort_scheme_fn,
    log_info_fn,
) -> tuple[Any, int, int, Any]:
    """Run the shared UPSERT path for a single merge bucket."""
    assert all(
        dfe.delta_type in ("add", "append", "upsert")
        or getattr(dfe.delta_type, "value", None) in ("add", "append", "upsert")
        for dfe in dfe_list
    ), "All incoming delta file envelopes must be of the DeltaType.ADD, DeltaType.APPEND, or DeltaType.UPSERT"
    log_info_fn(
        f"[Hash bucket index {hb_idx}] Reading dedupe input for "
        f"{len(dfe_list)} delta file envelope lists..."
    )
    table = build_incremental_table_fn(dfe_list)
    incremental_len = len(table)
    log_info_fn(
        f"[Hash bucket index {hb_idx}] Got the incremental table of length {incremental_len}"
    )

    sort_keys = []
    stream_position_key = None
    if partition_stream_position_column_name in table.column_names:
        stream_position_key = (partition_stream_position_column_name, "ascending")
    if input.sort_keys and input.sort_keys_precede_stream_position:
        sort_keys.extend([pa_key for key in input.sort_keys for pa_key in key.arrow])
    if stream_position_key is not None:
        sort_keys.append(stream_position_key)
    if input.sort_keys and not input.sort_keys_precede_stream_position:
        sort_keys.extend([pa_key for key in input.sort_keys for pa_key in key.arrow])
    if sort_keys:
        table = table.sort_by(sort_keys)
    elif stream_position_key is not None:
        table = table.sort_by([stream_position_key])

    hb_table_record_count = len(table) + (len(prev_table) if prev_table else 0)
    table, merge_time = timed_invocation_fn(
        func=merge_tables_fn,
        table=table,
        primary_keys=input.primary_keys,
        can_drop_duplicates=input.drop_duplicates,
        hb_index=hb_idx,
        num_buckets=input.hash_bucket_count,
        original_fields=input.original_fields,
        compacted_table=prev_table,
    )
    deduped_records = hb_table_record_count - len(table)

    output_sort_scheme = input.output_sort_scheme
    if output_sort_scheme:
        output_sort_scheme = coerce_output_sort_scheme_fn(output_sort_scheme)
        if output_sort_scheme.keys:
            sort_arrow_keys = [
                pa_key for key in output_sort_scheme.keys for pa_key in key.arrow
            ]
            table = table.sort_by(sort_arrow_keys)

    return table, incremental_len, deduped_records, merge_time


def execute_compact_tables(
    input: Any,
    dfe_list,
    hb_idx,
    compacted_table=None,
    *,
    flatten_dfe_list_fn,
    sort_df_envelopes_fn,
    group_sequence_by_delta_type_fn,
    apply_upserts_fn,
    timed_invocation_fn,
    add_delta_type,
    append_delta_type,
    upsert_delta_type,
    delete_delta_type,
    log_info_fn,
) -> tuple[Any, int, int, int]:
    """Run the shared compact-tables orchestration for a merge bucket."""
    df_envelopes = flatten_dfe_list_fn(dfe_list)
    delete_file_envelopes = input.delete_file_envelopes or []
    reordered_all_dfes = sort_df_envelopes_fn(delete_file_envelopes + df_envelopes)
    assert all(
        dfe.delta_type
        in (add_delta_type, append_delta_type, upsert_delta_type, delete_delta_type)
        for dfe in reordered_all_dfes
    ), "All reordered delta file envelopes must be of the ADD, APPEND, UPSERT or DELETE"
    table = compacted_table
    aggregated_incremental_len = 0
    aggregated_deduped_records = 0
    aggregated_dropped_records = 0
    for _, (delta_type, delta_type_sequence) in enumerate(
        group_sequence_by_delta_type_fn(reordered_all_dfes)
    ):
        if delta_type in (add_delta_type, append_delta_type, upsert_delta_type):
            table, incremental_len, deduped_records, merge_time = apply_upserts_fn(
                input=input,
                dfe_list=delta_type_sequence,
                hb_idx=hb_idx,
                prev_table=table,
            )
            log_info_fn(
                f" [Merge task index {input.merge_task_index}] Merged"
                f" record count: {len(table)}, size={table.nbytes} took: {merge_time}s"
            )
            aggregated_incremental_len += incremental_len
            aggregated_deduped_records += deduped_records
        elif delta_type is delete_delta_type:
            table_size_before_delete = len(table) if table else 0
            (table, dropped_rows), delete_time = timed_invocation_fn(
                func=input.delete_strategy.apply_many_deletes,
                table=table,
                delete_file_envelopes=delta_type_sequence,
            )
            log_info_fn(
                f" [Merge task index {input.merge_task_index}]"
                + f" Dropped record count: {dropped_rows} from table"
                + f" of record count {table_size_before_delete} took: {delete_time}s"
            )
            aggregated_dropped_records += dropped_rows
    return (
        table,
        aggregated_incremental_len,
        aggregated_deduped_records,
        aggregated_dropped_records,
    )


def execute_remote_materializing_merge_task(
    input: Any,
    *,
    timed_merge_fn,
    process_utilization_context_factory,
    timed_invocation_fn,
    emit_timer_metrics_fn,
    metrics_name: str,
    merge_result_factory,
    bytes_per_gibibyte: float,
    log_info_fn,
    log_debug_fn,
) -> Any:
    """Execute the outer Ray wrapper for the COW merge task."""
    with process_utilization_context_factory() as process_util:
        log_info_fn(f"Starting merge task {input.merge_task_index}...")

        def log_peak_memory():
            log_debug_fn(
                "Process peak memory utilization so far: %s bytes (%s GB)",
                process_util.max_memory,
                process_util.max_memory / bytes_per_gibibyte,
            )

        if input.memory_logs_enabled:
            process_util.schedule_callback(log_peak_memory, 10)

        merge_result, duration = timed_invocation_fn(func=timed_merge_fn, input=input)

        emit_metrics_time = 0.0
        if input.metrics_config:
            _, latency = timed_invocation_fn(
                func=emit_timer_metrics_fn,
                metrics_name=metrics_name,
                value=duration,
                metrics_config=input.metrics_config,
            )
            emit_metrics_time = latency

        log_info_fn(f"Finished merge task {input.merge_task_index}...")
        return merge_result_factory(
            merge_result[0],
            merge_result[1],
            merge_result[2],
            merge_result[3],
            merge_result[4],
            np.double(emit_metrics_time),
            merge_result[6],
        )


def execute_remote_merge_for_read_task(
    input: Any,
    *,
    timed_merge_for_read_fn,
    process_utilization_context_factory,
    timed_invocation_fn,
    bytes_per_gibibyte: float,
    log_info_fn,
    log_debug_fn,
) -> Any:
    """Execute the outer Ray wrapper for the MOR merge-for-read task."""
    with process_utilization_context_factory() as process_util:
        log_info_fn(f"Starting merge-for-read task {input.merge_task_index}...")

        def log_peak_memory():
            log_debug_fn(
                "Process peak memory utilization so far: %s bytes (%s GB)",
                process_util.max_memory,
                process_util.max_memory / bytes_per_gibibyte,
            )

        if input.memory_logs_enabled:
            process_util.schedule_callback(log_peak_memory, 10)

        result, duration = timed_invocation_fn(
            func=timed_merge_for_read_fn,
            input=input,
        )

        log_info_fn(
            f"Finished merge-for-read task {input.merge_task_index} "
            f"in {duration:.2f}s ({result.num_rows} records)"
        )
        return result
