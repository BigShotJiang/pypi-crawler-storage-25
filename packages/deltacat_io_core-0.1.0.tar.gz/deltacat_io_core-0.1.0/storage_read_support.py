"""Shared storage read/download helpers moved out of thick storage/main/impl.py."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence, Type


def resolve_delta_locator(
    delta_like: Any,
    *,
    delta_type: Type[Any],
    delta_locator_type: Type[Any],
    delta_factory: Callable[[Any], Any],
) -> Any:
    """Normalize a Delta or DeltaLocator input to a DeltaLocator."""
    if isinstance(delta_like, delta_locator_type):
        return delta_like
    if isinstance(delta_like, delta_type):
        return delta_factory(delta_like).locator
    raise ValueError(
        f"Expected delta_like to be a {delta_type.__name__} or "
        f"{delta_locator_type.__name__}, but found {type(delta_like)}."
    )


def resolve_manifest_for_delta_like(
    delta_like: Any,
    *,
    delta_type: Type[Any],
    all_column_names: Optional[Sequence[str]],
    get_delta_manifest_fn: Callable[[Any], Any],
) -> Any:
    """Resolve the authoritative manifest for a Delta/DeltaLocator input.

    If an inline manifest is already present on a Delta object, preserve the
    native fast path and reuse it. Otherwise, fetch the durable manifest from
    storage. Callers that supply ``all_column_names`` are declaring a pure
    manifest-entry download path and therefore must provide the inline manifest.
    """
    if isinstance(delta_like, delta_type) and getattr(delta_like, "manifest", None):
        return delta_like.manifest
    if all_column_names:
        raise ValueError(
            "All column names can only be specified with a delta with an inline manifest."
        )
    return get_delta_manifest_fn(delta_like)


def normalize_requested_columns(
    columns: Optional[List[str]],
    *,
    all_column_names: Optional[Sequence[str]],
    error_cls: Type[Exception],
    file_path_column: Optional[str] = None,
) -> Optional[List[str]]:
    """Validate requested columns against the known table-version schema.

    ``file_path_column`` is excluded from validation because it is appended
    after each file read and therefore is not part of the persisted table
    schema.
    """
    if not columns:
        return columns
    columns_to_validate = (
        [col for col in columns if col != file_path_column]
        if file_path_column
        else list(columns)
    )
    if all_column_names is not None:
        normalized_known = [col_name.lower() for col_name in all_column_names]
        if not all(col in normalized_known for col in columns_to_validate):
            raise error_cls(
                f"One or more columns in {columns_to_validate} are not present in table "
                f"version columns {list(all_column_names)}"
            )
    return [column.lower() for column in columns]


@dataclass(frozen=True)
class PreparedDeltaDownload:
    delta_locator: Any
    manifest: Any
    all_column_names: Optional[List[str]]
    columns: Optional[List[str]]
    table_version_schema: Optional[Any] = None


def resolve_prefixed_entry_filesystem(
    *,
    raw_url: str,
    default_filesystem: Any,
    data_root_config: Any,
    registry_factory: Callable[[], Any],
    prefixed_url_start: str,
) -> Any:
    """Resolve the filesystem override for a single manifest entry.

    For non-prefixed URLs, returns the default filesystem unchanged. For
    ``{{root}}/...`` manifest entries, resolves the named root and returns the
    corresponding filesystem from the supplied registry factory.
    """
    if data_root_config is None or not raw_url.startswith(prefixed_url_start):
        return default_filesystem
    data_root, _ = data_root_config.resolve(raw_url)
    if data_root is None:
        return default_filesystem
    registry = registry_factory()
    return registry.get_filesystem(data_root)


def prepare_delta_download(
    *,
    delta_like: Any,
    all_column_names: Optional[List[str]],
    columns: Optional[List[str]],
    delta_type: Type[Any],
    delta_locator_type: Type[Any],
    delta_factory: Callable[[Any], Any],
    get_delta_manifest_fn: Callable[[Any], Any],
    get_table_version_column_names_fn: Optional[
        Callable[[Any], Optional[List[str]]]
    ] = None,
    get_table_version_schema_fn: Optional[Callable[[Any], Any]] = None,
    file_path_column: Optional[str] = None,
    distributed_dataset_type: Optional[Any] = None,
    daft_dataset_type: Optional[Any] = None,
    error_cls: Type[Exception] = ValueError,
) -> PreparedDeltaDownload:
    """Prepare the shared Delta/manifest/schema state for a download request.

    This is the common prelude for both ``download_delta(...)`` and
    ``download_delta_manifest_entry(...)``. It preserves the native fast path
    for inline manifests, reuses table-version schema metadata when available,
    and centralizes requested-column validation so thick and thin read paths
    do not drift.
    """
    delta_locator = resolve_delta_locator(
        delta_like,
        delta_type=delta_type,
        delta_locator_type=delta_locator_type,
        delta_factory=delta_factory,
    )
    manifest = resolve_manifest_for_delta_like(
        delta_like,
        delta_type=delta_type,
        all_column_names=all_column_names,
        get_delta_manifest_fn=get_delta_manifest_fn,
    )

    resolved_all_column_names = list(all_column_names) if all_column_names else None
    resolved_table_version_schema = None
    if not resolved_all_column_names:
        if get_table_version_schema_fn is not None:
            resolved_table_version_schema = get_table_version_schema_fn(delta_locator)
            arrow_schema = getattr(resolved_table_version_schema, "arrow", None)
            if arrow_schema:
                resolved_all_column_names = [field.name for field in arrow_schema]
        elif get_table_version_column_names_fn is not None:
            resolved_all_column_names = get_table_version_column_names_fn(delta_locator)
    elif (
        distributed_dataset_type is not None
        and daft_dataset_type is not None
        and distributed_dataset_type == daft_dataset_type
    ):
        raise ValueError("All column names canot be specified with Daft.")

    resolved_columns = normalize_requested_columns(
        columns,
        all_column_names=resolved_all_column_names,
        error_cls=error_cls,
        file_path_column=file_path_column,
    )

    return PreparedDeltaDownload(
        delta_locator=delta_locator,
        manifest=manifest,
        all_column_names=resolved_all_column_names,
        columns=resolved_columns,
        table_version_schema=resolved_table_version_schema,
    )


def execute_prepared_delta_download(
    *,
    prepared: PreparedDeltaDownload,
    storage_type: Any,
    storage_type_to_download_func: Dict[Any, Callable[..., Any]],
    table_type: Any,
    max_parallelism: Optional[int],
    file_reader_kwargs_provider: Optional[Any],
    ray_options_provider: Optional[Any],
    distributed_dataset_type: Optional[Any],
    file_path_column: Optional[str],
    kwargs: Dict[str, Any],
) -> Any:
    """Execute a prepared Delta download through the selected storage mode.

    This is the shared post-prepare orchestration for ``download_delta(...)``.
    It preserves the native argument shaping while removing duplicate wrapper
    logic from the thick storage implementation.
    """
    filtered_kwargs = {
        key: value
        for key, value in kwargs.items()
        if key
        not in [
            "manifest",
            "table_type",
            "max_parallelism",
            "column_names",
            "include_columns",
            "file_reader_kwargs_provider",
            "ray_options_provider",
            "distributed_dataset_type",
        ]
    }

    return storage_type_to_download_func[storage_type](
        prepared.manifest,
        table_type,
        max_parallelism,
        prepared.all_column_names,
        prepared.columns,
        file_reader_kwargs_provider,
        ray_options_provider=ray_options_provider,
        distributed_dataset_type=distributed_dataset_type,
        file_path_column=file_path_column,
        **filtered_kwargs,
    )


def execute_prepared_manifest_entry_download(
    *,
    prepared: PreparedDeltaDownload,
    entry_index: int,
    table_type: Any,
    file_reader_kwargs_provider: Optional[Any],
    catalog_properties: Any,
    reconstruct_manifest_entry_url_fn: Callable[..., Any],
    download_manifest_entry_fn: Callable[..., Any],
    resolve_prefixed_entry_filesystem_fn: Callable[..., Any],
    registry_factory: Callable[[], Any],
    prefixed_url_start: str,
    kwargs: Dict[str, Any],
) -> Any:
    """Execute a prepared single-manifest-entry download.

    This is the shared post-prepare orchestration for
    ``download_delta_manifest_entry(...)``. It preserves the thick native
    behavior of reconstructing manifest URLs first, then resolving any
    multi-root filesystem override from the raw persisted manifest URL.
    """
    entry = prepared.manifest.entries[entry_index]
    reconstructed_entry = reconstruct_manifest_entry_url_fn(entry, **kwargs)

    filesystem = catalog_properties.data_filesystem
    data_root_config = getattr(catalog_properties, "data_root_config", None)
    raw_url = getattr(entry, "url", None) or getattr(entry, "uri", None) or ""
    filesystem = resolve_prefixed_entry_filesystem_fn(
        raw_url=raw_url,
        default_filesystem=filesystem,
        data_root_config=data_root_config,
        registry_factory=registry_factory,
        prefixed_url_start=prefixed_url_start,
    )

    return download_manifest_entry_fn(
        reconstructed_entry,
        table_type,
        prepared.all_column_names,
        prepared.columns,
        file_reader_kwargs_provider,
        filesystem=filesystem,
    )
