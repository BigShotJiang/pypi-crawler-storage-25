"""Shared helpers for building manifest entries from existing objects."""

from __future__ import annotations

import logging
import os
import posixpath
from typing import Any, Callable, Optional, Sequence

import deltacat_io_core.logs as logs
from deltacat_io_core.lance_support import (
    compute_sort_column_stats as compute_lance_sort_column_stats,
    storage_options_from_filesystem,
)
from deltacat_io_core.manifest_entry_support import (
    build_existing_lance_manifest_entries,
)
from deltacat_io_core.pyarrow_read_support import file_to_table as pyarrow_file_to_table
from deltacat_io_core.sort_support import order_items_by_primary_sort_key
from deltacat_io_core.table_dispatch import compute_arrow_table_column_stats

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def _encoding_value(value: Any) -> Any:
    return getattr(value, "value", value)


def compute_existing_object_sort_column_stats(
    path: str,
    filesystem: Optional[Any],
    data_root: Optional[Any],
    target_content_type: str,
    target_sort_column: Optional[str],
) -> Optional[dict[str, Any]]:
    """Compute sort-column stats for existing objects used in manifest builds."""
    if not target_sort_column:
        return None

    if target_content_type in {"lance", "application/vnd.lance"}:
        storage_config = (
            getattr(data_root, "storage_config", None)
            if data_root is not None
            else None
        ) or {}
        storage_options = storage_options_from_filesystem(
            filesystem,
            endpoint_url=storage_config.get("endpoint_url"),
            profile=storage_config.get("profile"),
            region=storage_config.get("region"),
        )
        return compute_lance_sort_column_stats(
            path,
            target_sort_column,
            storage_options=storage_options,
        )

    try:
        table = pyarrow_file_to_table(
            path,
            target_content_type,
            filesystem=filesystem,
            include_columns=[target_sort_column],
        )
    except NotImplementedError:
        return None

    stats = compute_arrow_table_column_stats(table)
    if not stats:
        return None
    column_stats = stats.get(target_sort_column)
    if not column_stats:
        return None
    return {target_sort_column: column_stats}


def build_manifest_entries_for_existing_objects(
    items: Sequence[Any],
    *,
    content_type: str,
    catalog_root: Optional[str],
    catalog_properties: Optional[Any],
    data_root_name: Optional[str],
    sort_scheme_id: Optional[str],
    sort_column: Optional[str],
    ext_to_content_encoding: dict[str, Any],
    lance_content_type: str,
    build_entries_for_local_paths_fn: Callable[..., list[dict[str, Any]]],
    compute_sort_column_stats_fn: Callable[..., Optional[dict[str, Any]]],
    resolve_manifest_entry_location_fn: Callable[..., Any],
    get_lance_dataset_stats_fn: Callable[..., Any],
    build_lance_manifest_entries_core_fn: Callable[..., Any],
    build_existing_manifest_entry_fn: Callable[..., Any],
    manifest_entry_of_fn: Callable[..., Any],
    prefix_path_fn: Callable[[str, str], str],
) -> list[Any]:
    """Build manifest entries for local path inputs or explicit entry dicts."""

    normalized_items = (
        [items]
        if isinstance(items, dict)
        or isinstance(items, (str, bytes))
        or hasattr(items, "__fspath__")
        else list(items)
    )

    explicit_entries: list[dict[str, Any]]
    explicit_entry_mode = False
    if normalized_items and all(isinstance(item, dict) for item in normalized_items):
        explicit_entry_mode = True
        explicit_entries = []
        for item in normalized_items:
            if "path" not in item:
                raise TypeError(
                    "dc.build_client_manifest(...) explicit entry dicts must include a 'path'."
                )
            entry = dict(item)
            entry["path"] = os.fspath(entry["path"])
            if "content_encoding" not in entry:
                _base, ext = posixpath.splitext(entry["path"])
                inferred_encoding = ext_to_content_encoding.get(ext)
                entry["content_encoding"] = (
                    _encoding_value(inferred_encoding)
                    if inferred_encoding is not None
                    else "identity"
                )
            if content_type != lance_content_type and any(
                entry.get(field_name) is None
                for field_name in (
                    "record_count",
                    "content_length",
                    "content_encoding",
                    "column_stats",
                )
            ):
                try:
                    inferred_entry = build_entries_for_local_paths_fn(
                        [entry["path"]],
                        fmt=content_type,
                        sort_column=sort_column,
                    )[0]
                except Exception:
                    logger.debug(
                        "Shared entry-metadata inference failed for %s; "
                        "falling back to native manifest construction.",
                        entry["path"],
                        exc_info=True,
                    )
                    inferred_entry = None
                if inferred_entry is not None:
                    for field_name in (
                        "record_count",
                        "content_length",
                        "content_encoding",
                        "column_stats",
                    ):
                        if (
                            entry.get(field_name) is None
                            and inferred_entry.get(field_name) is not None
                        ):
                            entry[field_name] = inferred_entry[field_name]
            explicit_entries.append(entry)
    elif all(
        isinstance(item, (str, bytes)) or hasattr(item, "__fspath__")
        for item in normalized_items
    ):
        explicit_entries = build_entries_for_local_paths_fn(
            normalized_items, fmt=content_type
        )
    else:
        raise TypeError(
            "dc.build_client_manifest(...) expects local path(s) or explicit entry dict(s)."
        )

    manifest_entries = []
    for entry in explicit_entries:
        path = entry["path"]
        entry_data_root_name = entry.get("data_root_name", data_root_name)
        location = resolve_manifest_entry_location_fn(
            path=path,
            entry_data_root_name=entry_data_root_name,
            catalog_root=catalog_root,
            catalog_properties=catalog_properties,
        )
        resolved_path = location.resolved_path
        if content_type == lance_content_type:
            resolved_column_stats = entry.get("column_stats")
            if resolved_column_stats is None:
                resolved_column_stats = compute_sort_column_stats_fn(
                    resolved_path,
                    location.filesystem,
                    location.data_root,
                    content_type,
                    sort_column,
                )
            stats = get_lance_dataset_stats_fn(
                resolved_path,
                filesystem=location.filesystem,
                data_root=location.data_root,
            )
            manifest_entries.extend(
                list(
                    build_existing_lance_manifest_entries(
                        resolved_path=resolved_path,
                        relative_root=location.relative_root,
                        prefixed_root_name=location.prefixed_root_name,
                        filesystem=location.filesystem,
                        schema_id=entry.get("schema_id"),
                        sort_scheme_id=entry.get("sort_scheme_id", sort_scheme_id),
                        resolved_column_stats=resolved_column_stats,
                        entry_type=entry.get("entry_type"),
                        entry_params=entry.get("entry_params"),
                        source_content_length=entry.get("source_content_length"),
                        credentials=entry.get("credentials"),
                        content_type_parameters=entry.get("content_type_parameters"),
                        build_lance_manifest_entries_core_fn=build_lance_manifest_entries_core_fn,
                        manifest_entry_of_fn=manifest_entry_of_fn,
                        prefix_path_fn=prefix_path_fn,
                        precomputed_stats=stats,
                    )
                )
            )
        else:
            resolved_column_stats = entry.get("column_stats")
            if resolved_column_stats is None:
                resolved_column_stats = compute_sort_column_stats_fn(
                    resolved_path,
                    location.filesystem,
                    location.data_root,
                    content_type,
                    sort_column,
                )
            manifest_entries.append(
                build_existing_manifest_entry_fn(
                    resolved_path=resolved_path,
                    final_url=location.final_url,
                    filesystem=location.filesystem,
                    relative_root=location.relative_root,
                    record_count=entry.get("record_count", 0),
                    explicit_content_length=(
                        entry.get("content_length") if explicit_entry_mode else None
                    ),
                    source_content_length=entry.get("source_content_length"),
                    content_type=content_type,
                    content_encoding=entry.get("content_encoding", "identity"),
                    credentials=entry.get("credentials"),
                    content_type_parameters=entry.get("content_type_parameters"),
                    entry_type=entry.get("entry_type"),
                    entry_params=entry.get("entry_params"),
                    schema_id=entry.get("schema_id"),
                    sort_scheme_id=entry.get("sort_scheme_id", sort_scheme_id),
                    resolved_column_stats=resolved_column_stats,
                )
            )

    if sort_column and len(manifest_entries) > 1:
        ordered, ok = order_items_by_primary_sort_key(
            manifest_entries,
            {"keys": [{"key": [sort_column]}]},
            get_sort_scheme_id=lambda _entry: None,
            get_column_stats=lambda entry: (
                entry.meta.column_stats if getattr(entry, "meta", None) else None
            ),
            require_matching_scheme_id=False,
        )
        if ok:
            manifest_entries = ordered

    return manifest_entries


def build_manifest_for_existing_objects(
    items: Sequence[Any],
    *,
    content_type: str,
    catalog_root: Optional[str],
    catalog_properties: Optional[Any],
    data_root_name: Optional[str],
    author_name: str,
    author_version: str,
    sort_scheme_id: Optional[str],
    sort_column: Optional[str],
    ext_to_content_encoding: dict[str, Any],
    lance_content_type: str,
    build_entries_for_local_paths_fn: Callable[..., list[dict[str, Any]]],
    compute_sort_column_stats_fn: Callable[..., Optional[dict[str, Any]]],
    resolve_manifest_entry_location_fn: Callable[..., Any],
    get_lance_dataset_stats_fn: Callable[..., Any],
    build_lance_manifest_entries_core_fn: Callable[..., Any],
    build_existing_manifest_entry_fn: Callable[..., Any],
    manifest_entry_of_fn: Callable[..., Any],
    prefix_path_fn: Callable[[str, str], str],
    manifest_factory: Callable[..., Any],
    manifest_entry_list_factory: Callable[[list[Any]], Any],
    manifest_author_factory: Callable[..., Any],
) -> Any:
    """Build a complete manifest for existing local objects or explicit entries."""
    manifest_entries = build_manifest_entries_for_existing_objects(
        items,
        content_type=content_type,
        catalog_root=catalog_root,
        catalog_properties=catalog_properties,
        data_root_name=data_root_name,
        sort_scheme_id=sort_scheme_id,
        sort_column=sort_column,
        ext_to_content_encoding=ext_to_content_encoding,
        lance_content_type=lance_content_type,
        build_entries_for_local_paths_fn=build_entries_for_local_paths_fn,
        compute_sort_column_stats_fn=compute_sort_column_stats_fn,
        resolve_manifest_entry_location_fn=resolve_manifest_entry_location_fn,
        get_lance_dataset_stats_fn=get_lance_dataset_stats_fn,
        build_lance_manifest_entries_core_fn=build_lance_manifest_entries_core_fn,
        build_existing_manifest_entry_fn=build_existing_manifest_entry_fn,
        manifest_entry_of_fn=manifest_entry_of_fn,
        prefix_path_fn=prefix_path_fn,
    )
    return manifest_factory(
        entries=manifest_entry_list_factory(manifest_entries),
        author=manifest_author_factory(
            name=author_name,
            version=author_version,
        ),
    )
