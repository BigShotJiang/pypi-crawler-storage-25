"""Shared helpers for DeltaAnnotated behavior."""

from __future__ import annotations

from typing import Any, Callable, List, Optional, Union


class DeltaAnnotation(tuple):
    @staticmethod
    def of(file_index: int, delta_type: Any, stream_position: int):
        return DeltaAnnotation((file_index, delta_type, stream_position))

    @property
    def annotation_file_index(self) -> int:
        return self[0]

    @property
    def annotation_delta_type(self):
        return self[1]

    @property
    def annotation_stream_position(self):
        return self[2]


def annotated_delta_of(
    delta: Any,
    *,
    delta_annotated_factory,
    delta_annotation_factory=DeltaAnnotation,
):
    """Create an annotated delta from a Delta-like object."""
    delta_annotated = delta_annotated_factory()
    delta_annotated.update(delta)
    entries = delta.manifest.entries if delta.manifest else []
    annotations = []
    if entries:
        dtype = delta.type
        pos = delta.stream_position
        annotations = [
            delta_annotation_factory.of(i, dtype, pos) for i in range(len(entries))
        ]
    delta_annotated.annotations = annotations
    return delta_annotated


def append_annotated_entry(
    src_da: Any,
    dst_da: Any,
    src_entry: Any,
    src_annotation: Any,
    *,
    manifest_factory,
    manifest_entry_list_factory,
) -> None:
    """Append one annotated entry to a destination annotated delta."""
    if not dst_da:
        dst_da.update(src_da)
        dst_da.manifest = manifest_factory(manifest_entry_list_factory([src_entry]))
        dst_da.annotations = [src_annotation]
    else:
        entries = dst_da.manifest.entries
        src_dl = src_da.locator
        dst_dl = dst_da.locator
        assert src_dl == dst_dl, "Delta locator should be same when grouping entries"
        if src_da.type != dst_da.type:
            dst_da.type = None
        entries.append(src_entry)
        dst_da.annotations.append(src_annotation)


def split_annotated_delta(
    src_da: Any,
    pieces: int,
    *,
    delta_annotated_factory,
    append_annotated_entry_fn,
    log_info_fn,
) -> List[Any]:
    """Split one annotated delta into roughly equal annotated groups."""
    groups = []
    new_da = delta_annotated_factory()
    da_group_entry_count = 0
    src_da_annotations = src_da.annotations
    src_da_entries = src_da.manifest.entries
    assert len(src_da_annotations) == len(src_da_entries), (
        f"Unexpected Error: Length of delta annotations "
        f"({len(src_da_annotations)}) doesn't mach the length of "
        f"delta manifest entries ({len(src_da_entries)})."
    )
    src_da_entries_length = len(src_da_entries)
    equal_length = src_da_entries_length // pieces
    for i in range(len(src_da_entries)):
        append_annotated_entry_fn(
            src_da,
            new_da,
            src_da_entries[i],
            src_da_annotations[i],
        )
        da_group_entry_count += 1
        if da_group_entry_count >= equal_length and i < equal_length * (pieces - 1):
            log_info_fn(
                f"Splitting {da_group_entry_count} manifest files "
                f"to {pieces} pieces of {equal_length} size."
            )
            groups.append(new_da)
            new_da = delta_annotated_factory()
            da_group_entry_count = 0
        if i == len(src_da_entries) - 1:
            groups.append(new_da)
            log_info_fn(
                f"Splitting {da_group_entry_count} manifest files "
                f"to {pieces} pieces of {equal_length} size."
            )
            new_da = delta_annotated_factory()
    if new_da:
        groups.append(new_da)
    return groups


def split_single_annotated_delta(
    delta_annotated: Any,
    *,
    delta_annotated_factory,
    append_annotated_entry_fn,
    manifest_entry_factory,
    partial_parquet_parameters_type,
    partial_parquet_parameters_factory,
    parquet_content_type,
    identity_content_encoding,
    deepcopy_fn,
    log_info_fn,
) -> List[Any]:
    """Split a single annotated delta by Parquet row groups when possible."""
    result = []

    if (
        delta_annotated.meta
        and delta_annotated.manifest
        and delta_annotated.meta.content_type == parquet_content_type
        and delta_annotated.meta.content_encoding == identity_content_encoding
    ):
        for entry_index, entry in enumerate(delta_annotated.manifest.entries):
            input_split_params = None
            if entry.meta and entry.meta.content_type_parameters:
                for type_params in entry.meta.content_type_parameters:
                    if (
                        isinstance(type_params, partial_parquet_parameters_type)
                        and type_params.num_row_groups > 1
                        and type_params.pq_metadata
                    ):
                        input_split_params = type_params
                        break

            if input_split_params:
                log_info_fn(
                    f"Splitting input file with URI: {entry.uri} into "
                    f"different {input_split_params.num_row_groups} entries"
                )
                for rg in input_split_params.row_groups_to_download:
                    new_da = delta_annotated_factory()
                    new_entry_dict = deepcopy_fn(entry)
                    new_entry = manifest_entry_factory(new_entry_dict)
                    row_group_meta = input_split_params.pq_metadata.row_group(rg)
                    new_partial_params = partial_parquet_parameters_factory(
                        row_groups_to_download=[rg],
                        num_row_groups=1,
                        num_rows=row_group_meta.num_rows,
                        in_memory_size_bytes=row_group_meta.total_byte_size,
                        pq_metadata=input_split_params.pq_metadata,
                    )
                    new_entry.meta.content_type_parameters = [new_partial_params]
                    for type_params in entry.meta.content_type_parameters:
                        if not isinstance(type_params, partial_parquet_parameters_type):
                            new_entry.meta.content_type_parameters.append(type_params)
                    append_annotated_entry_fn(
                        delta_annotated,
                        new_da,
                        new_entry,
                        delta_annotated.annotations[entry_index],
                    )
                    result.append(new_da)
            else:
                log_info_fn(
                    f"Split was not performed on delta with locator: {delta_annotated.locator} "
                    "as partial parquet params was not found."
                )
                return [delta_annotated]

    if result:
        return result

    log_info_fn(
        f"Split was not performed on the delta with locator: {delta_annotated.locator}"
    )
    return [delta_annotated]


def rebatch_annotated_deltas(
    annotated_deltas: List[Any],
    *,
    min_delta_bytes: float,
    min_file_counts: Optional[Union[int, float]],
    estimation_function: Optional[Callable[[Any], float]],
    enable_input_split: Optional[bool],
    delta_annotated_factory,
    split_single_fn,
    append_annotated_entry_fn,
    log_info_fn,
    log_debug_fn,
) -> List[Any]:
    """Greedily group annotated deltas into size-limited batches."""
    split_annotated_deltas = []
    groups = []
    new_da = delta_annotated_factory()
    new_da_bytes = 0
    da_group_entry_count = 0

    if enable_input_split:
        for delta_annotated in annotated_deltas:
            split_annotated_deltas.extend(split_single_fn(delta_annotated))

        log_info_fn(
            f"Split the {len(annotated_deltas)} annotated deltas "
            f"into {len(split_annotated_deltas)} groups."
        )
    else:
        log_info_fn("Skipping input split as it is disabled...")
        split_annotated_deltas = annotated_deltas

    for src_da in split_annotated_deltas:
        src_da_annotations = src_da.annotations
        src_da_entries = src_da.manifest.entries
        assert len(src_da_annotations) == len(src_da_entries), (
            f"Unexpected Error: Length of delta annotations "
            f"({len(src_da_annotations)}) doesn't mach the length of "
            f"delta manifest entries ({len(src_da_entries)})."
        )
        for i, src_entry in enumerate(src_da_entries):
            if new_da and src_da.locator != new_da.locator:
                groups.append(new_da)
                log_debug_fn(
                    f"Due to different delta locator, Appending group of {da_group_entry_count} elements "
                    f"and {new_da_bytes} bytes"
                )
                new_da = delta_annotated_factory()
                new_da_bytes = 0
                da_group_entry_count = 0
            append_annotated_entry_fn(
                src_da,
                new_da,
                src_entry,
                src_da_annotations[i],
            )
            estimated_new_da_bytes = estimation_function(src_entry)
            new_da_bytes += estimated_new_da_bytes
            da_group_entry_count += 1
            if (
                new_da_bytes >= min_delta_bytes
                or da_group_entry_count >= min_file_counts
            ):
                if new_da_bytes >= min_delta_bytes:
                    log_debug_fn(
                        f"Appending group of {da_group_entry_count} elements "
                        f"and {new_da_bytes} bytes to meet file size limit"
                    )
                if da_group_entry_count >= min_file_counts:
                    log_debug_fn(
                        f"Appending group of {da_group_entry_count} elements "
                        f"and {da_group_entry_count} files to meet file count limit"
                    )
                groups.append(new_da)
                new_da = delta_annotated_factory()
                new_da_bytes = 0
                da_group_entry_count = 0
    if new_da:
        groups.append(new_da)
    return groups
