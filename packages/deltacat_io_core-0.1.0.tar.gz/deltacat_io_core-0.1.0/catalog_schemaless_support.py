"""Shared schemaless catalog-read helpers moved out of thick catalog/main/impl.py."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Sequence


def build_data_roots_info_from_catalog_props(
    cat_props: Optional[Any],
) -> Optional[Dict[str, Any]]:
    """Build thin-client-style data-root info from generic catalog props."""
    if cat_props is None or getattr(cat_props, "data_root_config", None) is None:
        return None
    result = {}
    for name, data_root in cat_props.data_root_config.roots.items():
        storage_cfg = data_root.storage_config
        info = {
            "root": data_root.root,
            "storage_type": data_root.storage_type,
        }
        if storage_cfg:
            if storage_cfg.endpoint_url:
                info["endpoint_url"] = storage_cfg.endpoint_url
            if storage_cfg.region:
                info["region"] = storage_cfg.region
        result[name] = info
    return result or None


def build_schemaless_execution_plan(
    *,
    qualified_deltas: Sequence[Any],
    table: str,
    namespace: str,
    path_resolver: Optional[Callable[[str], str]] = None,
    data_roots_info: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Build a direct-execution plan for schemaless manifest-table reads."""
    scan_tasks: List[Dict[str, Any]] = []
    total_files = 0
    total_records = 0
    total_bytes = 0
    content_types = set()

    for delta in qualified_deltas:
        manifest = getattr(delta, "manifest", None)
        if manifest is None:
            continue

        manifest_author = getattr(manifest, "author", None)
        author_name = manifest_author.name if manifest_author else None
        author_version = manifest_author.version if manifest_author else None
        files: List[Dict[str, Any]] = []

        for entry in manifest.entries or []:
            raw_path = getattr(entry, "url", None) or getattr(entry, "uri", None) or ""
            if raw_path and path_resolver is not None:
                raw_path = path_resolver(raw_path)
            meta = getattr(entry, "meta", None)
            content_type = (
                meta.content_type
                if meta and meta.content_type is not None
                else "parquet"
            )
            content_type_value = (
                content_type.value
                if hasattr(content_type, "value")
                else str(content_type)
            )
            file_info = {
                "path": raw_path,
                "id": getattr(entry, "id", None),
                "mandatory": getattr(entry, "mandatory", None),
                "record_count": meta.record_count
                if meta and meta.record_count is not None
                else 0,
                "content_length": meta.content_length
                if meta and meta.content_length is not None
                else 0,
                "source_content_length": (
                    meta.source_content_length
                    if meta and meta.source_content_length is not None
                    else None
                ),
                "content_type": content_type_value,
                "content_encoding": (
                    meta.content_encoding
                    if meta and meta.content_encoding is not None
                    else "identity"
                ),
                "schema_id": meta.schema_id if meta else None,
                "sort_scheme_id": meta.sort_scheme_id if meta else None,
                "column_stats": meta.column_stats if meta else None,
            }
            files.append(file_info)
            total_files += 1
            total_records += int(file_info["record_count"] or 0)
            total_bytes += int(file_info["content_length"] or 0)
            content_types.add(content_type_value)

        if files:
            partition_values = None
            if getattr(delta, "partition_locator", None):
                partition_values = delta.partition_locator.partition_values
            scan_tasks.append(
                {
                    "partition_values": partition_values,
                    "partition_scheme_id": None,
                    "delta_type": str(delta.type)
                    if getattr(delta, "type", None)
                    else None,
                    "stream_position": getattr(delta, "stream_position", None),
                    "previous_stream_position": getattr(
                        delta, "previous_stream_position", None
                    ),
                    "author_name": author_name,
                    "author_version": author_version,
                    "files": files,
                }
            )

    if len(content_types) == 1:
        plan_content_type = next(iter(content_types))
    elif len(content_types) > 1:
        plan_content_type = "mixed"
    else:
        plan_content_type = "parquet"

    return {
        "table": table,
        "namespace": namespace,
        "content_type": plan_content_type,
        "scan_tasks": scan_tasks,
        "total_files": total_files,
        "returned_files": total_files,
        "total_records": total_records,
        "total_bytes": total_bytes,
        "requires_mor": False,
        "truncated": False,
        "data_roots": data_roots_info,
    }


def handle_schemaless_table_read(
    qualified_deltas: Sequence[Any],
    read_as: Any,
    *,
    get_manifest_for_delta_fn: Callable[[Any], Any],
    delta_manifest_to_table_fn: Callable[[Any, Any], Any],
    concat_tables_fn: Callable[[list[Any]], Any],
    from_pyarrow_fn: Callable[[Any, Any], Any],
) -> Any:
    """Read schemaless tables by flattening delta manifests to a manifest table."""
    tables = []
    for delta in qualified_deltas:
        manifest = get_manifest_for_delta_fn(delta)
        table = delta_manifest_to_table_fn(manifest, delta)
        tables.append(table)

    final_table = concat_tables_fn(tables)
    return from_pyarrow_fn(final_table, read_as)
