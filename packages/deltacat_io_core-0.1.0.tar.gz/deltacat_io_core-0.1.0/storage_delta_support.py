"""Shared storage delta staging helpers moved out of thick storage/main/impl.py."""

from __future__ import annotations

from typing import Any, Dict, Optional, Type


def _field(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        missing = object()
        value = obj.get(name, missing)
        if value is not missing:
            return value
    return getattr(obj, name, default)


def compute_delta_content_fingerprint(
    manifest: Any,
    delta_type: Any,
) -> str:
    """Compute a deterministic per-delta manifest fingerprint.

    The fingerprint covers the same fields as snapshot-id computation but is
    scoped to one delta. That lets higher-level snapshot code hash
    per-delta fingerprints in O(deltas) instead of iterating every file in
    every manifest in O(files).

    Important invariant: this uses raw persisted manifest entry URLs, including
    ``{{root}}/`` multi-root prefixes when present. It must never hash
    reconstructed or presigned paths.
    """
    import hashlib

    delta_type_value = _field(delta_type, "value", delta_type) or ""
    entry_fingerprints = []
    for entry in _field(manifest, "entries", []) or []:
        url = _field(entry, "url", "") or _field(entry, "uri", "") or ""
        meta = _field(entry, "meta")
        content_length = _field(meta, "content_length", 0) or 0
        record_count = _field(meta, "record_count", 0) or 0
        schema_id = _field(meta, "schema_id", "") or ""
        entry_fingerprints.append(
            f"{delta_type_value}|{url}|{content_length}|{record_count}|{schema_id}"
        )
    entry_fingerprints.sort()
    payload = "|".join(entry_fingerprints)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]


def prepare_stage_delta_writer_kwargs(
    table_writer_kwargs: Optional[Dict[str, Any]],
    *,
    schema: Optional[Any] = None,
    schema_type: Optional[Type[Any]] = None,
    sort_scheme_id: Optional[str] = None,
    sort_column: Optional[str] = None,
) -> Dict[str, Any]:
    """Prepare writer kwargs for staged data writes.

    This is the shared prelude for both thick staged writes and thin manifest
    staging. It preserves the native behavior of:
    - extracting ``schema_id`` from DeltaCAT Schema objects
    - passing Arrow schema through when available
    - attaching ``sort_scheme_id`` to drive manifest metadata
    - attaching ``sort_column`` so post-write manifest ordering can recover
      the native sorted-write contract for parallel/distributed writers
    """
    prepared = dict(table_writer_kwargs or {})
    schema_id = _field(schema, "id")
    arrow_schema = _field(schema, "arrow")
    is_schema_like = schema is not None and (
        (schema_type is not None and isinstance(schema, schema_type))
        or schema_id is not None
        or arrow_schema is not None
    )
    if is_schema_like:
        if schema_id is not None:
            prepared["schema_id"] = schema_id
        if "schema" not in prepared and arrow_schema is not None:
            prepared["schema"] = arrow_schema
    elif schema is not None and "schema" not in prepared:
        prepared["schema"] = schema
    if sort_scheme_id is not None:
        prepared["sort_scheme_id"] = sort_scheme_id
    if sort_column is not None:
        prepared["sort_column"] = sort_column
    return prepared


def validate_stage_delta_target(
    *,
    partition: Any,
    content_type: Any,
    delta_type: Any,
    add_delta_type: Any,
    deprecated_partition_state: Any,
    error_cls: Type[Exception],
) -> Optional[int]:
    """Validate that a partition can accept a staged delta.

    Returns the previous ordered stream position when applicable. For ADD
    deltas, the caller should keep ``previous_stream_position`` unset to
    preserve the native unordered-delta contract.
    """
    if not partition.is_supported_content_type(content_type):
        raise error_cls(
            f"Content type {content_type} is not supported by partition: {partition}"
        )
    if _field(partition, "state") == deprecated_partition_state:
        raise error_cls(
            f"Cannot stage delta to {_field(partition, 'state')} partition: {partition}"
        )
    return (
        _field(partition, "stream_position") if delta_type != add_delta_type else None
    )


def build_staged_delta_properties(
    manifest: Any,
    delta_type: Any,
    properties: Optional[Dict[str, Any]],
) -> Dict[str, Any]:
    """Attach the per-delta content fingerprint to properties.

    This keeps the staging behavior identical whether the manifest came from a
    local data write or from a thin-client prebuilt manifest registration.
    """
    props = dict(properties) if properties else {}
    props["content_fingerprint"] = compute_delta_content_fingerprint(
        manifest, delta_type
    )
    return props


def ensure_manifest_schema_metadata(
    manifest: Any,
    *,
    schema: Optional[Any] = None,
) -> Any:
    """Fill missing manifest/entry schema ids from the resolved write schema.

    Some callers still provide a resolved schema object whose ``id`` is the
    authoritative table-version schema id, but intermediate write layers may
    omit that value when constructing manifest metadata. Persisted delta
    manifests must carry the schema id so later reads can resolve the correct
    schema history after evolution.
    """
    schema_id = _field(schema, "id")
    if manifest is None or schema_id is None:
        return manifest

    manifest_meta = _field(manifest, "meta")
    if manifest_meta is not None and _field(manifest_meta, "schema_id") is None:
        manifest_meta["schema_id"] = schema_id

    for entry in _field(manifest, "entries", []) or []:
        entry_meta = _field(entry, "meta")
        if entry_meta is not None and _field(entry_meta, "schema_id") is None:
            entry_meta["schema_id"] = schema_id

    return manifest
