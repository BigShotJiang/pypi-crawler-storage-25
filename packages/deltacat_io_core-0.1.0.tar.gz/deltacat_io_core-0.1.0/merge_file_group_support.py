"""Shared helpers for merge file group providers."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Sequence


def create_local_merge_file_groups(
    *,
    uniform_deltas: Sequence[Any],
    all_column_names,
    read_kwargs_provider,
    deltacat_storage,
    deltacat_storage_kwargs,
    get_local_delta_file_envelopes_fn,
    merge_file_group_factory,
    local_hash_bucket_index: int,
) -> list[Any]:
    """Build the local merge-file-group list for single-bucket merges."""
    local_dfe_list, _ = get_local_delta_file_envelopes_fn(
        uniform_deltas=uniform_deltas,
        all_column_names=all_column_names,
        read_kwargs_provider=read_kwargs_provider,
        deltacat_storage=deltacat_storage,
        deltacat_storage_kwargs=deltacat_storage_kwargs,
    )
    dfe_groups = [local_dfe_list] if local_dfe_list else None
    return [
        merge_file_group_factory(
            hb_index=local_hash_bucket_index,
            dfe_groups=dfe_groups,
        )
    ]


def create_remote_merge_file_groups(
    *,
    hash_group_index: int,
    dfe_groups_refs: Sequence[Any],
    hash_bucket_count: int,
    num_hash_groups: int,
    object_store,
    hash_group_index_to_hash_bucket_indices_fn,
    merge_file_group_factory,
) -> list[Any]:
    """Build merge-file-group objects from remote object-store DFE groups."""
    delta_file_envelope_groups_list = object_store.get_many(dfe_groups_refs)
    hb_index_to_delta_file_envelopes_list = defaultdict(list)
    for delta_file_envelope_groups in delta_file_envelope_groups_list:
        assert hash_bucket_count == len(delta_file_envelope_groups), (
            f"The hash bucket count must match the dfe size as {hash_bucket_count}"
            f" != {len(delta_file_envelope_groups)}"
        )

        for hb_idx, dfes in enumerate(delta_file_envelope_groups):
            if dfes:
                hb_index_to_delta_file_envelopes_list[hb_idx].append(dfes)

    valid_hb_indices_iterable = hash_group_index_to_hash_bucket_indices_fn(
        hash_group_index,
        hash_bucket_count,
        num_hash_groups,
    )

    total_dfes_found = 0
    dfe_list_groups = []
    for hb_idx in valid_hb_indices_iterable:
        dfe_list = hb_index_to_delta_file_envelopes_list.get(hb_idx)
        if dfe_list:
            total_dfes_found += 1
            dfe_list_groups.append(
                merge_file_group_factory(hb_index=hb_idx, dfe_groups=dfe_list)
            )
        else:
            dfe_list_groups.append(merge_file_group_factory(hb_index=hb_idx))

    assert total_dfes_found == len(hb_index_to_delta_file_envelopes_list), (
        "The total dfe list does not match the input dfes from hash bucket as "
        f"{total_dfes_found} != {len(hb_index_to_delta_file_envelopes_list)}"
    )
    return dfe_list_groups
