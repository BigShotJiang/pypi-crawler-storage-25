"""Shared round-completion reader support."""

from __future__ import annotations

import logging
from typing import Optional

from deltacat_io_core import logs

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def read_round_completion_info(
    source_partition_locator,
    destination_partition_locator,
    deltacat_storage,
    deltacat_storage_kwargs: Optional[dict] = None,
    destination_partition=None,
):
    """Read round-completion info from the destination partition lineage."""
    if not destination_partition_locator:
        return None

    if deltacat_storage_kwargs is None:
        deltacat_storage_kwargs = {}

    try:
        if destination_partition:
            partition = destination_partition
        else:
            current_partition = deltacat_storage.get_partition(
                destination_partition_locator.stream_locator,
                destination_partition_locator.partition_values,
                **deltacat_storage_kwargs,
            )

            if current_partition.compaction_round_completion_info:
                partition = current_partition
            elif current_partition.previous_partition_id is not None:
                logger.info(
                    "Current partition %s does not have round completion info, "
                    "getting previous partition with ID: %s",
                    destination_partition_locator,
                    current_partition.previous_partition_id,
                )
                previous_partition = deltacat_storage.get_partition_by_id(
                    destination_partition_locator.stream_locator,
                    current_partition.previous_partition_id,
                    **deltacat_storage_kwargs,
                )
                if previous_partition is not None:
                    logger.info(
                        "Found previous partition: %s", previous_partition.locator
                    )
                    partition = previous_partition
                else:
                    raise LookupError(
                        f"Previous partition with ID {current_partition.previous_partition_id} not found"
                    )
            else:
                logger.info("No previous partition ID found, using current partition")
                partition = current_partition

        if partition:
            round_completion_info = partition.compaction_round_completion_info
            if round_completion_info:
                if (
                    not source_partition_locator
                    or not round_completion_info.prev_source_partition_locator
                ):
                    raise ValueError(
                        f"Source partition locator ({source_partition_locator}) and "
                        f"prev_source_partition_locator ({round_completion_info.prev_source_partition_locator}) "
                        f"must both be provided."
                    )

                if (
                    round_completion_info.prev_source_partition_locator.canonical_string()
                    != source_partition_locator.canonical_string()
                ):
                    logger.warning(
                        "Previous source partition locator mismatch: expected %s, "
                        "but found %s in round completion info. Ignoring cached round completion info.",
                        source_partition_locator.canonical_string(),
                        round_completion_info.prev_source_partition_locator.canonical_string(),
                    )
                    return None

                logger.info(
                    "Read round completion info from partition metafile: %s",
                    round_completion_info,
                )
                return round_completion_info

    except Exception as e:
        logger.debug(
            "Failed to read round completion info from partition metafile: %s",
            e,
        )

    return None
