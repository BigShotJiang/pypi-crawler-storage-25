"""Shared manifest-entry wrapper logic moved from thick tables.py."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, List, Optional

from deltacat_io_core.manifest_write_replica import build_manifest_entry_payloads
from deltacat_io_core.write_capture import write_table_capture


@dataclass(frozen=True)
class ManifestEntryWrapperPayload:
    path: str
    record_count: int
    source_content_length: Optional[int]
    content_type: str
    content_encoding: Optional[str]
    entry_type: Optional[Any]
    entry_params: Optional[Any]
    schema_id: Optional[Any]
    sort_scheme_id: Optional[Any]
    catalog_root: Optional[str]
    column_stats: Optional[Any]


def wrap_manifest_entry_payloads(
    payloads: Iterable[Any],
    *,
    filesystem: Any,
    manifest_entry_from_path: Callable[..., Any],
    is_retryable_error: Callable[[BaseException], bool],
    on_retryable_error: Callable[[Exception, str], None],
    on_non_retryable_error: Callable[[BaseException, str], None],
) -> List[Any]:
    manifest_entries: List[Any] = []
    for payload in payloads:
        try:
            manifest_entry = manifest_entry_from_path(
                path=payload.path,
                filesystem=filesystem,
                record_count=payload.record_count,
                source_content_length=payload.source_content_length,
                content_type=payload.content_type,
                content_encoding=payload.content_encoding,
                entry_type=payload.entry_type,
                entry_params=payload.entry_params,
                schema_id=payload.schema_id,
                sort_scheme_id=payload.sort_scheme_id,
                catalog_root=payload.catalog_root,
            )
            if payload.column_stats and getattr(manifest_entry, "meta", None):
                manifest_entry.meta.column_stats = payload.column_stats
            manifest_entries.append(manifest_entry)
        except BaseException as exc:
            if is_retryable_error(exc):
                on_retryable_error(exc, payload.path)
            else:
                on_non_retryable_error(exc, payload.path)
    return manifest_entries


def write_table_with_wrapper(
    table: Any,
    *,
    base_path: str,
    filesystem: Any,
    table_writer_fn: Callable,
    table_writer_kwargs: Optional[dict],
    content_type: str,
    validate_table_fn: Callable[[Any], None],
    column_stats_getter: Callable[[Any], Optional[dict]],
    skip_manifest_write: bool,
    use_ray_capture: bool,
    schema_id: Optional[Any],
    sort_scheme_id: Optional[Any],
    sort_column: Optional[str],
    entry_type: Optional[Any],
    entry_params: Optional[Any],
    catalog_root: Optional[str],
    manifest_entry_from_path: Callable[..., Any],
    manifest_entry_list_factory: Callable[[List[Any]], Any],
    is_retryable_error: Callable[[BaseException], bool],
    on_retryable_error: Callable[[Exception, str], None],
    on_non_retryable_error: Callable[[BaseException, str], None],
):
    capture_result = write_table_capture(
        table,
        base_path=base_path,
        filesystem=filesystem,
        table_writer_fn=table_writer_fn,
        table_writer_kwargs=table_writer_kwargs,
        content_type=content_type,
        validate_table_fn=validate_table_fn,
        column_stats_getter=column_stats_getter,
        skip_manifest_write=skip_manifest_write,
        use_ray_capture=use_ray_capture,
    )

    if skip_manifest_write:
        return capture_result.write_paths

    payloads = build_manifest_entry_payloads(
        write_paths=capture_result.write_paths,
        block_metadata=capture_result.block_metadata,
        fallback_blocks=capture_result.blocks,
        fallback_table=table,
        precomputed_stats=capture_result.column_stats,
        content_type=content_type,
        content_encoding=capture_result.content_encoding,
        entry_type=entry_type,
        entry_params=entry_params,
        schema_id=schema_id,
        sort_scheme_id=sort_scheme_id,
        catalog_root=catalog_root,
        sort_column=sort_column,
        column_stats_getter=column_stats_getter,
    )
    manifest_entries = wrap_manifest_entry_payloads(
        payloads,
        filesystem=filesystem,
        manifest_entry_from_path=manifest_entry_from_path,
        is_retryable_error=is_retryable_error,
        on_retryable_error=on_retryable_error,
        on_non_retryable_error=on_non_retryable_error,
    )
    return manifest_entry_list_factory(manifest_entries)
