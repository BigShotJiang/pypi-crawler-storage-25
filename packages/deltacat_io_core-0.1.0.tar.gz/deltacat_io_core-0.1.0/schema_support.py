"""Shared schema serialization and coercion helpers for deltacat_io_core."""

from __future__ import annotations

import base64
import logging
from typing import Any, Dict, List, Optional

import deltacat_io_core.logs as logs
from deltacat_io_core.deps import require_pyarrow
from deltacat_io_core.errors import SchemaValidationError

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))

FIELD_PAST_DEFAULT_KEY_NAME = b"DELTACAT:past_default"
FIELD_FUTURE_DEFAULT_KEY_NAME = b"DELTACAT:future_default"
FIELD_CONSISTENCY_TYPE_KEY_NAME = b"DELTACAT:consistency_type"


def encode_arrow_schema(arrow_schema: Optional[Any]) -> Optional[str]:
    if arrow_schema is None:
        return None
    return base64.b64encode(arrow_schema.serialize().to_pybytes()).decode("ascii")


def decode_arrow_schema(schema_serialized: Optional[str]) -> Optional[Any]:
    if not schema_serialized:
        return None
    pa = require_pyarrow("schema decoding")
    try:
        return pa.ipc.read_schema(pa.BufferReader(base64.b64decode(schema_serialized)))
    except Exception:
        logger.debug("Could not decode serialized Arrow schema.", exc_info=True)
        return None


def _decode_metadata_value(encoded_bytes: bytes) -> Any:
    import msgpack

    try:
        return msgpack.loads(base64.b64decode(encoded_bytes))
    except Exception:
        logger.debug(
            "Falling back to raw msgpack metadata decoding for schema metadata value.",
            exc_info=True,
        )
        return msgpack.loads(encoded_bytes)


def _field_metadata_value(field: Any, key: bytes) -> Any:
    metadata = field.metadata or {}
    value = metadata.get(key)
    if value is None:
        return None
    if key == FIELD_CONSISTENCY_TYPE_KEY_NAME:
        return value.decode()
    return _decode_metadata_value(value)


def schema_fields_from_summary(
    schema_summary: Optional[List[Dict[str, Any]]],
    *,
    arrow_schema: Optional[Any] = None,
) -> List[Dict[str, Any]]:
    summary_by_name = {
        field["name"]: field for field in (schema_summary or []) if field.get("name")
    }
    if arrow_schema is not None:
        return [
            {
                "name": field.name,
                "type": field.type,
                "nullable": field.nullable,
                "past_default": (
                    summary_by_name.get(field.name, {}).get("past_default")
                    if summary_by_name.get(field.name, {}).get("past_default")
                    is not None
                    else _field_metadata_value(field, FIELD_PAST_DEFAULT_KEY_NAME)
                ),
                "future_default": (
                    summary_by_name.get(field.name, {}).get("future_default")
                    if summary_by_name.get(field.name, {}).get("future_default")
                    is not None
                    else _field_metadata_value(field, FIELD_FUTURE_DEFAULT_KEY_NAME)
                ),
                "consistency_type": (
                    summary_by_name.get(field.name, {}).get("consistency_type")
                    if summary_by_name.get(field.name, {}).get("consistency_type")
                    is not None
                    else _field_metadata_value(field, FIELD_CONSISTENCY_TYPE_KEY_NAME)
                ),
            }
            for field in arrow_schema
        ]
    if not schema_summary:
        return []
    result: List[Dict[str, Any]] = []
    for field in schema_summary:
        if not field.get("name"):
            continue
        pa = require_pyarrow("schema field parsing")
        try:
            field_type = (
                pa.type_for_alias(field.get("type")) if field.get("type") else None
            )
        except Exception:
            logger.debug(
                "Could not parse schema field type alias %r",
                field.get("type"),
                exc_info=True,
            )
            field_type = None
        result.append(
            {
                "name": field["name"],
                "type": field_type,
                "nullable": field.get("nullable", True),
                "past_default": field.get("past_default"),
                "future_default": field.get("future_default"),
                "consistency_type": field.get("consistency_type"),
            }
        )
    return result


def schema_has_past_defaults(
    schema_summary: Optional[List[Dict[str, Any]]],
    *,
    arrow_schema: Optional[Any] = None,
) -> bool:
    if any(field.get("past_default") is not None for field in (schema_summary or [])):
        return True
    if arrow_schema is not None:
        for field in arrow_schema:
            if _field_metadata_value(field, FIELD_PAST_DEFAULT_KEY_NAME) is not None:
                return True
    return False


def align_table_to_schema(
    table: Any,
    schema_fields: List[Dict[str, Any]],
    *,
    missing_default_key: str = "past_default",
) -> Any:
    if not schema_fields:
        return table
    pa = require_pyarrow("schema alignment")
    arrays = []
    names = []
    for field in schema_fields:
        name = field["name"]
        typ = field["type"]
        if name in table.column_names:
            column = table[name]
            if typ is not None and column.type != typ:
                try:
                    column = column.cast(typ)
                except Exception:
                    logger.debug(
                        "Could not align column %s from type %s to %s; preserving original type.",
                        name,
                        column.type,
                        typ,
                        exc_info=True,
                    )
            arrays.append(column)
        else:
            default_value = field.get(missing_default_key)
            if default_value is not None and typ is not None:
                arrays.append(pa.array([default_value] * table.num_rows, type=typ))
            else:
                arrays.append(
                    pa.nulls(table.num_rows, type=typ)
                    if typ is not None
                    else pa.nulls(table.num_rows)
                )
        names.append(name)
    return pa.Table.from_arrays(arrays, names=names)


def coerce_table_for_write(
    table: Any,
    *,
    schema_serialized: Optional[str],
    schema_info: Optional[Any],
    schema_evolution_mode: Optional[str],
    schema_consistency_type: Optional[str],
) -> Any:
    pa = require_pyarrow("schema coercion")
    target_schema = decode_arrow_schema(schema_serialized)
    if target_schema is None:
        return table

    field_info_by_name = {
        field["name"]: field for field in (schema_info or []) if field.get("name")
    }
    target_names = [field.name for field in target_schema]
    extra_columns = [name for name in table.column_names if name not in target_names]
    evolution_mode = str(schema_evolution_mode or "").lower()
    allow_schema_evolution = evolution_mode.endswith("auto")
    if extra_columns:
        if not allow_schema_evolution:
            raise ValueError(
                "client.catalog.write(...) received columns not present in the "
                "active table schema. Enable schema evolution or use the native "
                "DeltaCAT write path."
            )

    arrays = []
    names = []
    for field in target_schema:
        name = field.name
        info = field_info_by_name.get(name, {})
        if name in table.column_names:
            column = table[name]
            if column.type != field.type:
                consistency = (
                    info.get("consistency_type") or schema_consistency_type or ""
                ).lower()
                if consistency == "validate":
                    raise SchemaValidationError(
                        f"client.catalog.write(...) field '{name}' requires exact type "
                        f"{field.type}, but received {column.type}."
                    )
                try:
                    column = column.cast(field.type)
                except Exception as exc:
                    raise SchemaValidationError(
                        f"client.catalog.write(...) field '{name}' could not be coerced "
                        f"from {column.type} to {field.type}."
                    ) from exc
            arrays.append(column)
            names.append(name)
        else:
            default_value = info.get("future_default")
            if default_value is not None:
                arrays.append(
                    pa.array([default_value] * table.num_rows, type=field.type)
                )
                names.append(name)
            elif field.nullable:
                arrays.append(pa.nulls(table.num_rows, type=field.type))
                names.append(name)
            else:
                raise SchemaValidationError(
                    f"client.catalog.write(...) missing required non-nullable field "
                    f"'{name}' with no future_default."
                )
    if allow_schema_evolution and extra_columns:
        for extra_column in extra_columns:
            arrays.append(table[extra_column])
            names.append(extra_column)
        return pa.Table.from_arrays(arrays, names=names)
    return pa.Table.from_arrays(arrays, schema=target_schema)
