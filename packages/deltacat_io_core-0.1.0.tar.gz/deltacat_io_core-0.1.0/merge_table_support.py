"""Shared pure table and list helpers for merge-task execution."""

from __future__ import annotations

import itertools
from typing import Any, Sequence

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc


def append_delta_type_column(
    table: pa.Table,
    value: np.bool_,
    *,
    delta_type_column_field,
    delta_type_column_type,
) -> pa.Table:
    """Append the internal delta-type system column to a table."""
    return table.append_column(
        delta_type_column_field,
        pa.array(np.repeat(value, len(table)), delta_type_column_type),
    )


def drop_delta_type_rows(
    table: pa.Table,
    delta_type: Any,
    *,
    delta_type_column_name: str,
    delta_type_to_field_fn,
) -> pa.Table:
    """Drop rows whose internal delta-type field matches the given type."""
    if delta_type_column_name not in table.column_names:
        return table

    delta_type_value = delta_type_to_field_fn(delta_type)
    result = table.filter(pc.not_equal(table[delta_type_column_name], delta_type_value))
    return result.drop([delta_type_column_name])


def concat_or_coerce_tables(all_tables: Sequence[pa.Table]) -> pa.Table:
    """Concatenate tables, falling back to permissive schema unification."""
    try:
        return pa.concat_tables(list(all_tables))
    except pa.ArrowInvalid:
        if all_tables:
            try:
                return pa.concat_tables(
                    list(all_tables),
                    promote_options="permissive",
                    unify_schemas=True,
                )
            except (pa.ArrowInvalid, TypeError, pa.ArrowNotImplementedError):
                raise
        raise RuntimeError("Expected at least one table to merge, but found none.")


def merge_records_partially(
    old_records: pa.Table,
    new_records: pa.Table,
    original_fields,
    *,
    pk_hash_string_column_name: str,
    partition_stream_position_column_name: str,
    delta_type_column_name: str,
) -> pa.Table:
    """Fill missing or schema-coerced fields in new records from old records."""
    sys_cols = {
        pk_hash_string_column_name,
        partition_stream_position_column_name,
        delta_type_column_name,
    }
    old_fields = set(old_records.column_names) - sys_cols
    new_fields = set(new_records.column_names) - sys_cols
    missing_fields = old_fields - new_fields

    auto_added_null_fields = set()
    for field_name in old_fields & new_fields:
        if field_name not in original_fields:
            auto_added_null_fields.add(field_name)

    fields_to_fill = missing_fields | auto_added_null_fields

    result_columns = {}
    for column_name in new_records.column_names:
        result_columns[column_name] = new_records[column_name]
    for field_name in fields_to_fill:
        result_columns[field_name] = old_records[field_name]

    return pa.table(result_columns)


def build_incremental_table(
    df_envelopes,
    *,
    add_delta_type_column_fn,
    concat_or_coerce_tables_fn,
    delete_delta_type,
    add_delta_type,
    append_delta_type,
    upsert_delta_type,
    delta_type_to_field_fn,
    partition_stream_position_column_name: str,
) -> pa.Table:
    """Build the incremental merge table from DFE inputs."""
    hb_tables = []
    is_delete = False
    for df_envelope in df_envelopes:
        assert df_envelope.delta_type in (
            add_delta_type,
            append_delta_type,
            upsert_delta_type,
            delete_delta_type,
        ), "Only ADD, APPEND, UPSERT, and DELETE delta types are supported"
        if df_envelope.delta_type == delete_delta_type:
            is_delete = True

    for df_envelope in df_envelopes:
        table = df_envelope.table
        if is_delete:
            table = add_delta_type_column_fn(
                table,
                np.bool_(delta_type_to_field_fn(df_envelope.delta_type)),
            )

        sp = df_envelope.stream_position or 0
        table = table.append_column(
            partition_stream_position_column_name,
            pa.array([sp] * len(table), type=pa.int64()),
        )
        hb_tables.append(table)

    return concat_or_coerce_tables_fn(hb_tables)


def merge_tables(
    table: pa.Table,
    primary_keys,
    can_drop_duplicates: bool,
    hb_index: int,
    num_buckets: int,
    original_fields,
    compacted_table: pa.Table | None = None,
    *,
    partition_stream_position_column_name: str,
    pk_hash_string_column_name: str,
    delta_type_delete,
    concat_or_coerce_tables_fn,
    drop_delta_type_rows_fn,
    generate_pk_hash_column_fn,
    drop_duplicates_fn,
    validate_bucketing_spec_compliance_fn,
    check_bucketing_spec: bool,
    incremental_table_log_prefix: str,
    merge_records_partially_fn,
    max_int_bytes: int,
    log_info_fn,
) -> pa.Table:
    """Merge incremental and compacted tables, applying dedup and partial upserts."""
    all_tables = []
    incremental_idx = 0

    if compacted_table:
        incremental_idx = 1
        if (
            partition_stream_position_column_name in table.column_names
            and partition_stream_position_column_name
            not in compacted_table.column_names
        ):
            compacted_table = compacted_table.append_column(
                partition_stream_position_column_name,
                pa.array([0] * len(compacted_table), type=pa.int64()),
            )
        all_tables.append(compacted_table)

    all_tables.append(table)

    if primary_keys and check_bucketing_spec:
        validate_bucketing_spec_compliance_fn(
            table=all_tables[incremental_idx],
            num_buckets=num_buckets,
            primary_keys=primary_keys,
            hb_index=hb_index,
            log_prefix=incremental_table_log_prefix,
        )

    if not primary_keys or not can_drop_duplicates:
        log_info_fn(
            f"Not dropping duplicates for primary keys={primary_keys} "
            f"and can_drop_duplicates={can_drop_duplicates}"
        )
        all_tables[incremental_idx] = drop_delta_type_rows_fn(
            all_tables[incremental_idx],
            delta_type_delete,
        )
        result = concat_or_coerce_tables_fn(all_tables)
        if partition_stream_position_column_name in result.column_names:
            result = result.drop([partition_stream_position_column_name])
        return result

    all_tables = generate_pk_hash_column_fn(all_tables, primary_keys=primary_keys)
    result_table_list = []

    incremental_table = drop_duplicates_fn(
        all_tables[incremental_idx],
        on=pk_hash_string_column_name,
    )
    incremental_table = drop_delta_type_rows_fn(incremental_table, delta_type_delete)
    incremental_data = incremental_table

    if compacted_table:
        compacted_table = all_tables[0]
        compacted_pk_hash_str = compacted_table[pk_hash_string_column_name]
        incremental_pk_hash_str = incremental_table[pk_hash_string_column_name]

        log_info_fn(
            f"Size of compacted pk hash={compacted_pk_hash_str.nbytes} "
            f"and incremental pk hash={incremental_pk_hash_str.nbytes}."
        )

        if (
            compacted_table[pk_hash_string_column_name].nbytes >= max_int_bytes
            or incremental_table[pk_hash_string_column_name].nbytes >= max_int_bytes
        ):
            log_info_fn("Casting compacted and incremental pk hash to large_string...")
            compacted_pk_hash_str = pc.cast(compacted_pk_hash_str, pa.large_string())
            incremental_pk_hash_str = pc.cast(
                incremental_pk_hash_str, pa.large_string()
            )

        records_to_update = pc.is_in(compacted_pk_hash_str, incremental_pk_hash_str)
        records_to_keep = pc.invert(records_to_update)
        result_table_list.append(compacted_table.filter(records_to_keep))

        if pc.sum(records_to_update).as_py() > 0:
            old_records_to_update = compacted_table.filter(records_to_update)
            incremental_data = merge_records_partially_fn(
                old_records=old_records_to_update,
                new_records=incremental_table,
                original_fields=original_fields,
            )

    result_table_list.append(incremental_data)

    final_table = concat_or_coerce_tables_fn(result_table_list)
    cols_to_drop = [pk_hash_string_column_name]
    if partition_stream_position_column_name in final_table.column_names:
        cols_to_drop.append(partition_stream_position_column_name)
    return final_table.drop(cols_to_drop)


def validate_bucketing_spec_compliance(
    table: pa.Table,
    num_buckets: int,
    hb_index: int,
    primary_keys,
    *,
    generate_pk_hash_column_fn,
    pk_hash_string_column_np_fn,
    pk_digest_to_hash_bucket_index_fn,
    assert_on_violation: bool,
    rci: Any = None,
    log_prefix=None,
    log_info_fn,
    log_debug_fn,
) -> None:
    """Validate that table rows all belong to the expected hash bucket."""
    if rci is not None:
        message_prefix = (
            f"{log_prefix}{rci.compacted_delta_locator.namespace}."
            f"{rci.compacted_delta_locator.table_name}."
            f"{rci.compacted_delta_locator.table_version}."
            f"{rci.compacted_delta_locator.partition_id}."
            f"{rci.compacted_delta_locator.partition_values}"
        )
    else:
        message_prefix = f"{log_prefix}"

    pki_table = generate_pk_hash_column_fn(
        [table],
        primary_keys=primary_keys,
        requires_hash=True,
    )[0]
    is_not_compliant = False
    for index, hash_value in enumerate(pk_hash_string_column_np_fn(pki_table)):
        hash_bucket = pk_digest_to_hash_bucket_index_fn(hash_value, num_buckets)
        if hash_bucket != hb_index:
            is_not_compliant = True
            log_info_fn(
                f"{message_prefix} has non-compliant bucketing spec at index: {index} "
                f"Expected hash bucket is {hb_index} but found {hash_bucket}."
            )
            if assert_on_violation:
                raise AssertionError(
                    f"Hash bucket drift detected at index: {index}. Expected hash bucket index"
                    f" to be {hb_index} but found {hash_bucket}"
                )
            break

    if not is_not_compliant:
        log_debug_fn(
            f"{message_prefix} has compliant bucketing spec for hb_index: {hb_index}"
        )


def flatten_dfe_list(df_envelopes_list):
    """Flatten a nested list of DFEs into a single list."""
    if not df_envelopes_list:
        return []
    return [d for dfe_list in df_envelopes_list for d in dfe_list]


def sort_df_envelopes(
    df_envelopes,
    key=lambda df: (df.stream_position, df.file_index),
):
    """Sort DFEs in ascending stream-position/file-index order."""
    if not df_envelopes:
        return []
    return sorted(df_envelopes, key=key, reverse=False)


def group_sequence_by_delta_type(df_envelopes):
    """Group an already-ordered DFE sequence by adjacent delta type."""
    iter_df_envelopes = iter(df_envelopes)
    for delta_type, delta_type_sequence in itertools.groupby(
        iter_df_envelopes,
        lambda x: x.delta_type,
    ):
        yield delta_type, list(delta_type_sequence)
