"""Shared distributed manifest download execution moved out of thick tables.py."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from deltacat_io_core.deps import require_pyarrow


def cast_string_view_to_string(table: Any) -> Any:
    """Normalize string_view columns for distributed dataset compatibility."""
    pa = require_pyarrow("string_view normalization")
    if not isinstance(table, pa.Table):
        return table

    has_string_view = any(pa.types.is_string_view(field.type) for field in table.schema)
    if not has_string_view:
        return table

    try:
        pandas_df = table.to_pandas()
        return pa.Table.from_pandas(pandas_df, preserve_index=False)
    except Exception:
        return table


def download_manifest_entries_ray_data_distributed(
    *,
    manifest: Any,
    table_type: Any,
    max_parallelism: Optional[int],
    column_names: Optional[list[str]],
    include_columns: Optional[list[str]],
    file_reader_kwargs_provider: Optional[Any],
    ray_options_provider: Optional[Callable[[int, Any], Dict[str, Any]]],
    file_path_column: Optional[str],
    invoke_parallel_fn: Callable[..., Any],
    download_manifest_entry_ray_fn: Callable[..., Any],
    align_tables_to_unified_schema_fn: Callable[[Any], Any],
    get_table_type_function_fn: Callable[[Any, Dict[Any, Callable], str], Callable],
    table_type_to_dataset_create_func_refs: Dict[Any, Callable],
    ray_dataset_type: Any,
    **kwargs,
):
    """Download manifest entries into a Ray-backed distributed dataset."""
    table_pending_ids = []
    manifest_entries = manifest.entries

    if manifest_entries:
        table_pending_ids = invoke_parallel_fn(
            manifest_entries,
            download_manifest_entry_ray_fn,
            table_type,
            column_names,
            include_columns,
            file_reader_kwargs_provider,
            max_parallelism=max_parallelism,
            options_provider=ray_options_provider,
            file_path_column=file_path_column,
            **kwargs,
        )

    if len(table_pending_ids) > 1 and table_type == ray_dataset_type:
        table_pending_ids = align_tables_to_unified_schema_fn(table_pending_ids)

    create_func = get_table_type_function_fn(
        table_type,
        table_type_to_dataset_create_func_refs,
        "dataset create",
    )
    return create_func(table_pending_ids)


def download_manifest_entries_grouped_distributed(
    *,
    manifest: Any,
    column_names: Optional[list[str]],
    include_columns: Optional[list[str]],
    file_reader_kwargs_provider: Optional[Any],
    ray_options_provider: Optional[Callable[[int, Any], Dict[str, Any]]],
    distributed_dataset_type: Optional[Any],
    file_path_column: Optional[str],
    filter_catalog_kwargs_fn: Callable[[dict], dict],
    group_manifest_urls_by_content_type_fn: Callable[..., Any],
    filter_reader_kwargs_fn: Callable[[dict], dict],
    reader_func_map: Dict[Any, Callable],
    daft_dataset_type: Any,
    **kwargs,
):
    """Download manifest entries into a non-Ray distributed dataset."""
    filtered_kwargs = filter_catalog_kwargs_fn(kwargs)
    urls_by_content_type = group_manifest_urls_by_content_type_fn(
        manifest,
        **filtered_kwargs,
    )

    reader_kwargs = filter_reader_kwargs_fn(kwargs)

    try:
        reader_func = reader_func_map[distributed_dataset_type.value]
    except KeyError:
        raise ValueError(
            f"Unsupported distributed dataset type={distributed_dataset_type}. "
            f"Supported types: {list(reader_func_map.keys())}"
        )

    if len(urls_by_content_type) == 1:
        content_type, content_encoding = next(iter(urls_by_content_type.keys()))
        urls = next(iter(urls_by_content_type.values()))
        return reader_func(
            uris=urls,
            content_type=content_type,
            content_encoding=content_encoding,
            column_names=column_names,
            include_columns=include_columns,
            read_func_kwargs_provider=file_reader_kwargs_provider,
            ray_options_provider=ray_options_provider,
            file_path_column=file_path_column,
            **reader_kwargs,
        )

    if distributed_dataset_type != daft_dataset_type:
        raise ValueError(
            f"Mixed content types are only supported for Daft datasets. "
            f"Got {len(urls_by_content_type)} different content types with dataset type {distributed_dataset_type}"
        )

    dataframes = []
    for (content_type, content_encoding), urls in urls_by_content_type.items():
        df = reader_func(
            uris=urls,
            content_type=content_type,
            content_encoding=content_encoding,
            column_names=column_names,
            include_columns=include_columns,
            read_func_kwargs_provider=file_reader_kwargs_provider,
            ray_options_provider=ray_options_provider,
            file_path_column=file_path_column,
            **reader_kwargs,
        )
        dataframes.append(df)

    if len(dataframes) == 1:
        return dataframes[0]

    result = dataframes[0]
    for df in dataframes[1:]:
        result = result.union_all(df)

    return result
