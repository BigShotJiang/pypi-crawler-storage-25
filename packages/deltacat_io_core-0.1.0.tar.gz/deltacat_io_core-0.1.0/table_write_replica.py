"""Replica of thick DeltaCAT's file-based table write path for io_core."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass
from typing import Any, List, Optional, Tuple
from uuid import uuid4

from deltacat_io_core.filesystem_support import (
    get_file_info,
    resolve_path_and_filesystem,
)
from deltacat_io_core.pyarrow_write_support import (
    table_to_file as pyarrow_table_to_file,
)

PARQUET_TYPES = {"parquet", "application/parquet"}
CSV_TYPES = {"csv", "text/csv"}
TSV_TYPES = {"tsv", "text/tsv"}
PSV_TYPES = {"psv", "text/psv"}
UNESCAPED_TSV_TYPES = {"application/x-amzn-unescaped-tsv"}
FEATHER_TYPES = {"feather", "application/feather"}
JSON_TYPES = {"json", "application/json"}
ORC_TYPES = {"orc", "application/orc"}
AVRO_TYPES = {"avro", "application/avro"}

CONTENT_TYPE_TO_EXT = {
    **{content_type: ".parquet" for content_type in PARQUET_TYPES},
    **{content_type: ".csv" for content_type in CSV_TYPES},
    **{content_type: ".tsv" for content_type in TSV_TYPES | UNESCAPED_TSV_TYPES},
    **{content_type: ".psv" for content_type in PSV_TYPES},
    **{content_type: ".feather" for content_type in FEATHER_TYPES},
    **{content_type: ".json" for content_type in JSON_TYPES},
    **{content_type: ".orc" for content_type in ORC_TYPES},
    **{content_type: ".avro" for content_type in AVRO_TYPES},
}
EXPLICIT_COMPRESSION_CONTENT_TYPES = (
    CSV_TYPES | TSV_TYPES | PSV_TYPES | UNESCAPED_TSV_TYPES | JSON_TYPES
)


@dataclass
class WriteSliceResult:
    relative_path: str
    output_path: str
    record_count: int
    content_length: int
    source_content_length: Optional[int]
    content_encoding: Optional[str]


class DeterministicBlockWritePathProvider:
    """Replica of thick DeltaCAT's UuidBlockWritePathProvider for local io_core writes.

    The only intentional difference is that the caller may supply a deterministic
    ``filename_base`` instead of always using a UUID. Thin client materialization
    relies on stable names like ``output-00000``; the thick path relies on UUIDs.
    """

    def __init__(
        self,
        *,
        base_path: str,
        content_type: Optional[str],
        content_encoding: Optional[str],
    ):
        self.base_path = base_path
        self.content_type = content_type
        self.content_encoding = content_encoding
        self.write_paths: List[str] = []

    def get_write_path(
        self,
        *,
        filename_base: Optional[str] = None,
    ) -> Tuple[str, str]:
        actual_base = filename_base or str(uuid4())

        extension = ""
        if self.content_type:
            content_type_extension = CONTENT_TYPE_TO_EXT.get(self.content_type)
            if content_type_extension:
                extension += content_type_extension
        if self.content_encoding == "gzip":
            extension += ".gz"

        filename = f"{actual_base}{extension}"
        write_path = f"{self.base_path}/{filename}"
        self.write_paths.append(write_path)
        return filename, write_path


def _slice_names(
    table, target_records_per_file: Optional[int]
) -> List[Tuple[str, Any]]:
    if (
        target_records_per_file is None
        or int(target_records_per_file) <= 0
        or getattr(table, "num_rows", 0) <= int(target_records_per_file)
    ):
        return [("output", table)]

    per_file = int(target_records_per_file)
    return [
        (f"output-{idx:05d}", table.slice(offset, per_file))
        for idx, offset in enumerate(range(0, table.num_rows, per_file))
    ]


def write_sliced_pyarrow_table(
    table,
    *,
    data_dir: str,
    content_type: str,
    target_records_per_file: Optional[int],
) -> List[WriteSliceResult]:
    normalized_content_type = str(content_type)
    content_encoding = (
        "gzip"
        if normalized_content_type in EXPLICIT_COMPRESSION_CONTENT_TYPES
        else None
    )
    resolved_base_path, filesystem = resolve_path_and_filesystem(data_dir)

    results: List[WriteSliceResult] = []
    provider = DeterministicBlockWritePathProvider(
        base_path=resolved_base_path,
        content_type=normalized_content_type,
        content_encoding=content_encoding,
    )
    for base_name, table_slice in _slice_names(table, target_records_per_file):
        relative_path, resolved_output_path = provider.get_write_path(
            filename_base=base_name
        )
        pyarrow_table_to_file(
            table_slice,
            resolved_base_path,
            filesystem,
            lambda _base_path, _relative_path=relative_path: _relative_path,
            normalized_content_type,
        )
        file_info = get_file_info(resolved_output_path, filesystem)
        results.append(
            WriteSliceResult(
                relative_path=relative_path,
                output_path=posixpath.join(data_dir, relative_path),
                record_count=table_slice.num_rows,
                content_length=int(file_info.size or 0),
                source_content_length=getattr(table_slice, "nbytes", None),
                content_encoding=content_encoding,
            )
        )

    return results
