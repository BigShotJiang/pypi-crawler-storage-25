"""Optional dependency helpers for the shared client IO layer."""

from __future__ import annotations

import importlib


def optional_import(module_name: str):
    try:
        return importlib.import_module(module_name)
    except ImportError:
        return None


def require_module(
    module_name: str,
    *,
    feature: str,
    extra: str | None = None,
    package_name: str | None = None,
):
    try:
        return importlib.import_module(module_name)
    except ImportError as exc:
        package_name = package_name or module_name
        if extra:
            raise ImportError(
                f"{feature} requires optional dependency `{package_name}`. "
                f"Install `deltacat-io-core[{extra}]` "
                f"(or `deltacat-client[{extra}]` when using the thin client)."
            ) from exc
        raise ImportError(
            f"{feature} requires optional dependency `{package_name}`."
        ) from exc


def require_pyarrow(feature: str):
    return require_module(
        "pyarrow", feature=feature, extra="io", package_name="pyarrow"
    )


def require_pyarrow_csv(feature: str):
    return require_module(
        "pyarrow.csv", feature=feature, extra="io", package_name="pyarrow"
    )


def require_pyarrow_feather(feature: str):
    return require_module(
        "pyarrow.feather", feature=feature, extra="io", package_name="pyarrow"
    )


def require_pyarrow_json(feature: str):
    return require_module(
        "pyarrow.json", feature=feature, extra="io", package_name="pyarrow"
    )


def require_pyarrow_orc(feature: str):
    return require_module(
        "pyarrow.orc", feature=feature, extra="io", package_name="pyarrow"
    )


def require_pyarrow_parquet(feature: str):
    return require_module(
        "pyarrow.parquet", feature=feature, extra="io", package_name="pyarrow"
    )


def require_fastavro(feature: str):
    return require_module(
        "fastavro", feature=feature, extra="io", package_name="fastavro"
    )


def require_pandas(feature: str):
    return require_module(
        "pandas", feature=feature, extra="pandas", package_name="pandas"
    )


def require_polars(feature: str):
    return require_module(
        "polars", feature=feature, extra="polars", package_name="polars"
    )


def require_lance(feature: str):
    return require_module(
        "lance", feature=feature, extra="lance", package_name="pylance"
    )


def convert_table_output(result, *, read_as: str, feature: str):
    normalized = str(read_as or "pyarrow").lower()
    if normalized == "pyarrow":
        return result
    if normalized == "pandas":
        require_pandas(feature)
        return result.to_pandas()
    if normalized == "polars":
        pl = require_polars(feature)
        return pl.from_arrow(result)
    if normalized == "numpy":
        require_pandas(feature)
        return result.to_pandas().to_numpy()
    if normalized == "daft":
        daft = require_module("daft", feature=feature, package_name="daft")
        return daft.from_arrow(result)
    if normalized == "ray_dataset":
        ray_data = require_module(
            "ray.data",
            feature=feature,
            package_name="ray[data]",
        )
        return ray_data.from_arrow(result)
    raise ValueError(
        f"Unsupported read_as value {read_as!r}. Expected 'pyarrow', 'pandas', "
        f"'polars', 'numpy', 'daft', or 'ray_dataset'."
    )
