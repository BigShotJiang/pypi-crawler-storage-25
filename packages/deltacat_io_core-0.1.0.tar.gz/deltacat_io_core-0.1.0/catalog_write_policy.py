"""Shared catalog write policy helpers moved out of thick catalog/main/impl.py."""

from __future__ import annotations

import hashlib as _hashlib
import hmac as _hmac
import logging
from dataclasses import dataclass
from typing import Any, Callable, Optional, Sequence, Tuple

import deltacat_io_core.logs as logs

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


@dataclass(frozen=True)
class PreparedWriteValidation:
    table_exists_flag: bool
    table_definition: Any
    table_version_obj: Optional[Any]
    stream: Optional[Any]


def generate_validation_token(
    *,
    catalog_identity: str,
    table: str,
    namespace: str,
    content_type: Any,
    mode: Any,
    table_version_obj: Any,
    validation_token_key: bytes,
    validation_token_ttl_seconds: int,
    stage_data_dir: Optional[str] = None,
    time_provider: Callable[[], float],
) -> str:
    """Generate an HMAC token encoding the validation state."""
    del validation_token_ttl_seconds

    schema_hash = ""
    if table_version_obj and table_version_obj.schema:
        try:
            arrow = table_version_obj.schema.arrow
            schema_hash = _hashlib.sha256(arrow.to_string().encode()).hexdigest()[:16]
        except Exception:
            schema_hash = ""

    timestamp = str(int(time_provider()))
    stage_data_dir = stage_data_dir or ""
    payload = (
        f"{catalog_identity}|{namespace}|{table}|{content_type.value}|"
        f"{mode.value}|{schema_hash}|{timestamp}|{stage_data_dir}"
    )
    sig = _hmac.new(
        validation_token_key, payload.encode(), _hashlib.sha256
    ).hexdigest()[:32]
    return f"{payload}|{sig}"


def decode_validation_token(
    token: str,
    *,
    validation_token_key: bytes,
    validation_token_ttl_seconds: int,
    time_provider: Callable[[], float],
) -> Optional[dict[str, str]]:
    """Return decoded token fields after signature and TTL validation."""
    try:
        parts = token.rsplit("|", 1)
        if len(parts) != 2:
            return None
        payload, sig = parts

        expected_sig = _hmac.new(
            validation_token_key, payload.encode(), _hashlib.sha256
        ).hexdigest()[:32]
        if not _hmac.compare_digest(sig, expected_sig):
            return None

        fields = payload.split("|")
        if len(fields) < 7:
            return None

        elapsed = time_provider() - int(fields[6])
        if elapsed > validation_token_ttl_seconds:
            return None

        return {
            "catalog_identity": fields[0],
            "namespace": fields[1],
            "table": fields[2],
            "content_type": fields[3],
            "mode": fields[4],
            "schema_hash": fields[5],
            "timestamp": fields[6],
            "stage_data_dir": fields[7] if len(fields) > 7 and fields[7] else "",
        }
    except Exception:
        return None


def get_validation_token_stage_data_dir(
    token: str,
    *,
    validation_token_key: bytes,
    validation_token_ttl_seconds: int,
    time_provider: Callable[[], float],
) -> Optional[str]:
    decoded = decode_validation_token(
        token,
        validation_token_key=validation_token_key,
        validation_token_ttl_seconds=validation_token_ttl_seconds,
        time_provider=time_provider,
    )
    if not decoded:
        return None
    return decoded.get("stage_data_dir") or None


def verify_validation_token(
    token: str,
    *,
    catalog_identity: str,
    table: str,
    namespace: str,
    content_type: Any,
    mode: Any,
    validation_token_key: bytes,
    validation_token_ttl_seconds: int,
    time_provider: Callable[[], float],
) -> bool:
    decoded = decode_validation_token(
        token,
        validation_token_key=validation_token_key,
        validation_token_ttl_seconds=validation_token_ttl_seconds,
        time_provider=time_provider,
    )
    if not decoded:
        return False
    return (
        decoded["catalog_identity"] == catalog_identity
        and decoded["namespace"] == namespace
        and decoded["table"] == table
        and decoded["content_type"] == content_type.value
        and decoded["mode"] == mode.value
    )


def get_table_and_validate_write_mode(
    *,
    table: str,
    namespace: str,
    table_version: Optional[str],
    mode: Any,
    get_table_fn: Callable[..., Any],
    create_mode: Any,
    auto_mode: Any,
    table_already_exists_error_cls: type[Exception],
    table_not_found_error_cls: type[Exception],
    table_version_already_exists_error_cls: type[Exception],
    table_version_not_found_error_cls: type[Exception],
    **kwargs,
) -> Tuple[bool, Any]:
    """Validate write mode against table/table-version existence."""
    existing_table_def = get_table_fn(
        table,
        namespace=namespace,
        table_version=table_version,
        **kwargs,
    )
    table_exists_flag = (
        existing_table_def is not None
        and getattr(existing_table_def, "table_version", None)
        and getattr(existing_table_def, "stream", None)
    )
    logger.info(
        "Table to write to (%s.%s) exists: %s", namespace, table, table_exists_flag
    )

    if mode == create_mode and table_exists_flag and table_version is None:
        raise table_already_exists_error_cls(
            f"Table {namespace}.{table} already exists and mode is CREATE."
        )
    if mode not in (create_mode, auto_mode) and existing_table_def is None:
        mode_value = mode.value if hasattr(mode, "value") else mode
        raise table_not_found_error_cls(
            f"Table {namespace}.{table} does not exist and write mode is {mode_value}. Use CREATE or AUTO mode to create a new table."
        )

    if table_version is not None and table_exists_flag:
        if mode == create_mode:
            raise table_version_already_exists_error_cls(
                f"Table version {namespace}.{table}.{table_version} already exists and mode is CREATE."
            )
        logger.info("Table version (%s.%s.%s) exists.", namespace, table, table_version)
    elif (
        mode not in (create_mode, auto_mode)
        and table_version is not None
        and not table_exists_flag
    ):
        raise table_version_not_found_error_cls(
            f"Table version {namespace}.{table}.{table_version} does not exist and write mode is {mode}. "
            f"Use CREATE or AUTO mode to create a new table version, or omit table_version "
            f"to use the latest version."
        )

    return table_exists_flag, existing_table_def


def validate_content_type_against_supported_content_types(
    *,
    namespace: str,
    table: str,
    content_type: Any,
    supported_content_types: Optional[Sequence[Any]],
    error_cls: type[Exception] = ValueError,
) -> None:
    if supported_content_types and content_type not in supported_content_types:
        raise error_cls(
            f"Content type proposed for write to table {namespace}.{table} ({content_type}) "
            f"conflicts with the proposed list of new supported content types: {supported_content_types}"
        )


def create_table_for_write(
    *,
    data: Any,
    table: str,
    namespace: str,
    table_version: Optional[str],
    content_type: Any,
    existing_table_definition: Optional[Any],
    kwargs: dict[str, Any],
    extra_create_args: Sequence[Any],
    infer_table_schema_fn: Callable[[Any], Any],
    validate_content_type_fn: Callable[..., None],
    create_table_fn: Callable[..., Any],
    manifest_only_missing_table_error_cls: type[Exception],
) -> Any:
    """Create a new table/table-version/stream in preparation for a write."""
    create_kwargs = dict(kwargs)
    if "schema" not in create_kwargs:
        if data is not None:
            create_kwargs["schema"] = infer_table_schema_fn(data)
        elif create_kwargs.get("manifest") is not None:
            raise manifest_only_missing_table_error_cls(
                f"Table '{namespace}.{table}' does not exist and cannot be "
                f"auto-created from a manifest-only write. Create the table "
                f"first (e.g., via stage_write which validates schema and "
                f"write mode) before calling commit_write."
            )

    validate_content_type_fn(
        namespace=namespace,
        table=table,
        content_type=content_type,
        supported_content_types=create_kwargs.get("content_types"),
    )
    return create_table_fn(
        table,
        *extra_create_args,
        namespace=namespace,
        table_version=table_version,
        existing_table_definition=existing_table_definition,
        **create_kwargs,
    )


def prepare_write_validation_context(
    *,
    table: str,
    namespace: str,
    table_version: Optional[str],
    mode: Any,
    content_type: Any,
    kwargs: dict[str, Any],
    schema_content_types: Sequence[str],
    schemaless_content_types: Sequence[str],
    get_table_and_validate_write_mode_fn: Callable[..., tuple[bool, Any]],
    get_latest_active_or_given_table_version_fn: Callable[..., Any],
    validate_write_mode_schema_compat_fn: Callable[..., None],
    validate_table_configuration_fn: Callable[..., None],
    content_type_validation_error_cls: type[Exception],
) -> PreparedWriteValidation:
    """Prepare the shared preflight validation context for ``validate_write()``."""
    table_exists_flag, table_definition = get_table_and_validate_write_mode_fn(
        table,
        namespace,
        table_version,
        mode,
        **kwargs,
    )
    if not table_exists_flag:
        return PreparedWriteValidation(
            table_exists_flag=False,
            table_definition=table_definition,
            table_version_obj=None,
            stream=None,
        )

    if table_definition.table_version:
        table_version_obj = table_definition.table_version
    else:
        table_version_obj = get_latest_active_or_given_table_version_fn(
            namespace=table_definition.table.namespace,
            table_name=table_definition.table.table_name,
            table_version=table_version,
            **kwargs,
        )

    if (
        getattr(content_type, "value", content_type) not in schema_content_types
        and table_version_obj.schema is not None
    ):
        raise content_type_validation_error_cls(
            f"Content type '{getattr(content_type, 'value', content_type)}' cannot be written to a "
            f"table with a schema. Table '{namespace}.{table}' has a schema, "
            f"but content type '{getattr(content_type, 'value', content_type)}' is schemaless. "
            f"Schemaless content types ({', '.join(sorted(schemaless_content_types))}) "
            f"can only be written to schemaless tables."
        )

    validate_write_mode_schema_compat_fn(
        mode,
        table_version_obj.schema if table_version_obj else None,
        namespace,
        table,
        table_version_obj,
    )

    stream = table_definition.stream
    if stream:
        validate_table_configuration_fn(stream, table_version_obj, namespace, table)

    return PreparedWriteValidation(
        table_exists_flag=True,
        table_definition=table_definition,
        table_version_obj=table_version_obj,
        stream=stream,
    )


def validate_write_mode_schema_compat(
    *,
    mode: Any,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any = None,
    add_mode: Any,
    append_mode: Any,
    merge_mode: Any,
    delete_mode: Any,
    schema_validation_error_cls: type[Exception],
    table_validation_error_cls: type[Exception],
) -> None:
    """Validate write-mode compatibility against merge-key configuration."""
    has_merge_keys = table_schema and table_schema.merge_keys
    if has_merge_keys:
        if mode in (add_mode, append_mode):
            raise schema_validation_error_cls(
                f"{mode.value.upper()} mode cannot be used with tables that have "
                f"merge keys. Table {namespace}.{table} has merge keys: "
                f"{table_schema.merge_keys}. Use MERGE mode instead."
            )
    else:
        if mode in (merge_mode, delete_mode):
            tv = table_version_obj.table_version if table_version_obj else "?"
            raise table_validation_error_cls(
                f"{mode.value.upper()} mode requires tables to have at least one "
                f"merge key. Table {namespace}.{table}.{tv} has no merge keys. "
                f"Use APPEND, AUTO, or REPLACE mode instead."
            )


def handle_replace_mode(
    *,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any,
    stage_stream_fn: Callable[..., Any],
    commit_stream_fn: Callable[..., Any],
    upsert_delta_type: Any,
    append_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    stream = stage_stream_fn(
        namespace=namespace,
        table_name=table,
        table_version=table_version_obj.table_version,
        **kwargs,
    )
    stream = commit_stream_fn(stream=stream, **kwargs)
    delta_type = (
        upsert_delta_type
        if table_schema and table_schema.merge_keys
        else append_delta_type
    )
    return stream, delta_type


def handle_replace_partition_mode(
    *,
    table_schema: Any,
    stream: Any,
    upsert_delta_type: Any,
    append_delta_type: Any,
) -> Tuple[Any, Any]:
    delta_type = (
        upsert_delta_type
        if table_schema and table_schema.merge_keys
        else append_delta_type
    )
    return stream, delta_type


def handle_append_mode(
    *,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any,
    stream: Any,
    validate_write_mode_schema_compat_fn: Callable[..., None],
    append_mode: Any,
    get_table_stream_fn: Callable[..., Any],
    append_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    validate_write_mode_schema_compat_fn(
        mode=append_mode,
        table_schema=table_schema,
        namespace=namespace,
        table=table,
        table_version_obj=table_version_obj,
    )
    if stream is None:
        stream = get_table_stream_fn(
            namespace,
            table,
            table_version_obj.table_version,
            **kwargs,
        )
    return stream, append_delta_type


def handle_add_mode(
    *,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any,
    stream: Any,
    validate_write_mode_schema_compat_fn: Callable[..., None],
    add_mode: Any,
    get_table_stream_fn: Callable[..., Any],
    add_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    validate_write_mode_schema_compat_fn(
        mode=add_mode,
        table_schema=table_schema,
        namespace=namespace,
        table=table,
        table_version_obj=table_version_obj,
    )
    if stream is None:
        stream = get_table_stream_fn(
            namespace,
            table,
            table_version_obj.table_version,
            **kwargs,
        )
    return stream, add_delta_type


def handle_merge_delete_mode(
    *,
    mode: Any,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any,
    stream: Any,
    validate_write_mode_schema_compat_fn: Callable[..., None],
    get_table_stream_fn: Callable[..., Any],
    merge_mode: Any,
    upsert_delta_type: Any,
    delete_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    validate_write_mode_schema_compat_fn(
        mode=mode,
        table_schema=table_schema,
        namespace=namespace,
        table=table,
        table_version_obj=table_version_obj,
    )
    if stream is None:
        stream = get_table_stream_fn(
            namespace,
            table,
            table_version_obj.table_version,
            **kwargs,
        )
    delta_type = upsert_delta_type if mode == merge_mode else delete_delta_type
    return stream, delta_type


def handle_auto_create_mode(
    *,
    table_schema: Any,
    namespace: str,
    table: str,
    table_version_obj: Any,
    table_exists_flag: bool,
    stream: Any,
    get_table_stream_fn: Callable[..., Any],
    upsert_delta_type: Any,
    add_delta_type: Any,
    append_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    if stream is None:
        stream = get_table_stream_fn(
            namespace,
            table,
            table_version_obj.table_version,
            **kwargs,
        )
    delta_type = (
        upsert_delta_type
        if table_schema and table_schema.merge_keys
        else add_delta_type
        if table_exists_flag
        else append_delta_type
    )
    return stream, delta_type


def handle_write_mode(
    *,
    mode: Any,
    table_definition: Any,
    table_version_obj: Any,
    namespace: str,
    table: str,
    table_exists_flag: bool,
    stream: Any,
    validate_write_mode_schema_compat_fn: Callable[..., None],
    stage_stream_fn: Callable[..., Any],
    commit_stream_fn: Callable[..., Any],
    get_table_stream_fn: Callable[..., Any],
    replace_mode: Any,
    replace_partition_mode: Any,
    append_mode: Any,
    add_mode: Any,
    merge_mode: Any,
    delete_mode: Any,
    upsert_delta_type: Any,
    append_delta_type: Any,
    add_delta_type: Any,
    delete_delta_type: Any,
    **kwargs,
) -> Tuple[Any, Any]:
    """Resolve the target stream and delta type for a write."""
    table_schema = table_definition.table_version.schema

    if mode == replace_mode:
        return handle_replace_mode(
            table_schema=table_schema,
            namespace=namespace,
            table=table,
            table_version_obj=table_version_obj,
            stage_stream_fn=stage_stream_fn,
            commit_stream_fn=commit_stream_fn,
            upsert_delta_type=upsert_delta_type,
            append_delta_type=append_delta_type,
            **kwargs,
        )

    if mode == replace_partition_mode:
        return handle_replace_partition_mode(
            table_schema=table_schema,
            stream=stream,
            upsert_delta_type=upsert_delta_type,
            append_delta_type=append_delta_type,
        )

    if mode == append_mode:
        return handle_append_mode(
            table_schema=table_schema,
            namespace=namespace,
            table=table,
            table_version_obj=table_version_obj,
            stream=stream,
            validate_write_mode_schema_compat_fn=validate_write_mode_schema_compat_fn,
            append_mode=append_mode,
            get_table_stream_fn=get_table_stream_fn,
            append_delta_type=append_delta_type,
            **kwargs,
        )

    if mode == add_mode:
        return handle_add_mode(
            table_schema=table_schema,
            namespace=namespace,
            table=table,
            table_version_obj=table_version_obj,
            stream=stream,
            validate_write_mode_schema_compat_fn=validate_write_mode_schema_compat_fn,
            add_mode=add_mode,
            get_table_stream_fn=get_table_stream_fn,
            add_delta_type=add_delta_type,
            **kwargs,
        )

    if mode in (merge_mode, delete_mode):
        return handle_merge_delete_mode(
            mode=mode,
            table_schema=table_schema,
            namespace=namespace,
            table=table,
            table_version_obj=table_version_obj,
            stream=stream,
            validate_write_mode_schema_compat_fn=validate_write_mode_schema_compat_fn,
            get_table_stream_fn=get_table_stream_fn,
            merge_mode=merge_mode,
            upsert_delta_type=upsert_delta_type,
            delete_delta_type=delete_delta_type,
            **kwargs,
        )
    return handle_auto_create_mode(
        table_schema=table_schema,
        namespace=namespace,
        table=table,
        table_version_obj=table_version_obj,
        table_exists_flag=table_exists_flag,
        stream=stream,
        get_table_stream_fn=get_table_stream_fn,
        upsert_delta_type=upsert_delta_type,
        add_delta_type=add_delta_type,
        append_delta_type=append_delta_type,
        **kwargs,
    )
