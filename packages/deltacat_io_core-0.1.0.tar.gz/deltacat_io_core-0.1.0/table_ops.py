"""Shared table slicing and concatenation dispatch moved out of thick tables.py."""

from __future__ import annotations

import math
from typing import Any, Callable, Dict, List, Optional, Type, Union

from deltacat_io_core.deps import optional_import, require_pyarrow
from deltacat_io_core.table_dispatch import get_table_function


def slice_arrow_table(
    table: Any,
    max_len: Optional[int],
) -> List[Any]:
    """Iteratively create 0-copy table slices."""
    if max_len is None:
        return [table]
    tables = []
    offset = 0
    records_remaining = len(table)
    while records_remaining > 0:
        records_this_entry = min(max_len, records_remaining)
        tables.append(table.slice(offset, records_this_entry))
        records_remaining -= records_this_entry
        offset += records_this_entry
    return tables


def slice_pandas_dataframe(
    dataframe: Any,
    max_len: Optional[int],
) -> List[Any]:
    if max_len is None:
        return [dataframe]
    dataframes = []
    num_slices = math.ceil(len(dataframe) / max_len)
    for i in range(num_slices):
        dataframes.append(dataframe[i * max_len : (i + 1) * max_len])
    return dataframes


def slice_polars_table(
    table: Any,
    max_len: Optional[int],
) -> List[Any]:
    if max_len is None:
        return [table]
    tables = []
    offset = 0
    records_remaining = len(table)
    while records_remaining > 0:
        records_this_entry = min(max_len, records_remaining)
        tables.append(table.slice(offset, records_this_entry))
        records_remaining -= records_this_entry
        offset += records_this_entry
    return tables


def slice_ndarray(
    np_array: Any,
    max_len: Optional[int],
) -> List[Any]:
    if max_len is None:
        return [np_array]
    return [np_array[i : i + max_len] for i in range(0, len(np_array), max_len)]


def concat_arrow_tables(
    tables: List[Any],
    promote_options: Optional[str] = "permissive",
    **kwargs,
) -> Optional[Union[Any, List[Any]]]:
    pa = require_pyarrow("table concatenation")
    papq = optional_import("pyarrow.parquet")

    if tables is None or not len(tables):
        return None
    if len(tables) == 1:
        return next(iter(tables))

    if papq is not None and all(
        isinstance(table, papq.ParquetFile) for table in tables
    ):
        return list(tables)

    converted_tables = []
    if papq is not None:
        for table in tables:
            if isinstance(table, papq.ParquetFile):
                converted_tables.append(table.read())
            else:
                converted_tables.append(table)
    else:
        converted_tables = list(tables)

    return pa.concat_tables(converted_tables, promote_options=promote_options, **kwargs)


def concat_pandas_dataframes(
    dataframes: List[Any],
    axis: int = 0,
    copy: bool = False,
    ignore_index: bool = True,
    **kwargs,
) -> Optional[Any]:
    pd = optional_import("pandas")
    if pd is None:
        raise ImportError("pandas concatenation requires optional dependency `pandas`.")
    if dataframes is None or not len(dataframes):
        return None
    if len(dataframes) == 1:
        return next(iter(dataframes))
    return pd.concat(dataframes, axis=axis, copy=copy, ignore_index=ignore_index)


def concat_polars_dataframes(dataframes: List[Any]) -> Optional[Any]:
    pl = optional_import("polars")
    if pl is None:
        raise ImportError("polars concatenation requires optional dependency `polars`.")
    if dataframes is None or not len(dataframes):
        return None
    if len(dataframes) == 1:
        return next(iter(dataframes))
    return pl.concat(dataframes)


def concat_ndarrays(arrays: List[Any]) -> Optional[Any]:
    np = optional_import("numpy")
    if np is None:
        raise ImportError("numpy concatenation requires optional dependency `numpy`.")
    if arrays is None or not len(arrays):
        return None
    if len(arrays) == 1:
        return next(iter(arrays))
    return np.concatenate(arrays, axis=0)


TABLE_CLASS_TO_SLICER_FUNC: Dict[Type[Any], Callable] = {}
TABLE_TYPE_TO_CONCAT_FUNC: Dict[str, Callable] = {}


def _initialize_table_ops() -> None:
    pa = optional_import("pyarrow")
    pd = optional_import("pandas")
    pl = optional_import("polars")
    np = optional_import("numpy")

    if pa is not None:
        TABLE_CLASS_TO_SLICER_FUNC[pa.Table] = slice_arrow_table
        papq = optional_import("pyarrow.parquet")
        if papq is not None:
            TABLE_TYPE_TO_CONCAT_FUNC["pyarrow_parquet"] = concat_arrow_tables
        TABLE_TYPE_TO_CONCAT_FUNC["pyarrow"] = concat_arrow_tables
    if pd is not None:
        TABLE_CLASS_TO_SLICER_FUNC[pd.DataFrame] = slice_pandas_dataframe
        TABLE_TYPE_TO_CONCAT_FUNC["pandas"] = concat_pandas_dataframes
    if pl is not None:
        TABLE_CLASS_TO_SLICER_FUNC[pl.DataFrame] = slice_polars_table
        TABLE_TYPE_TO_CONCAT_FUNC["polars"] = concat_polars_dataframes
    if np is not None:
        TABLE_CLASS_TO_SLICER_FUNC[np.ndarray] = slice_ndarray
        TABLE_TYPE_TO_CONCAT_FUNC["numpy"] = concat_ndarrays


_initialize_table_ops()


def get_table_slicer(table: Any) -> Callable:
    return get_table_function(table, TABLE_CLASS_TO_SLICER_FUNC, "slicer")


def concat_tables(tables: List[Any], table_type: str) -> Any:
    concat_func = TABLE_TYPE_TO_CONCAT_FUNC.get(table_type)
    if concat_func is None:
        raise ValueError(
            f"No concatenation function found for table type: {table_type}.\n"
            f"Known table types: {list(TABLE_TYPE_TO_CONCAT_FUNC.keys())}"
        )
    return concat_func(tables)
