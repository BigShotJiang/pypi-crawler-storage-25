"""Shared merge-on-read helpers for moving the native MOR engine into IO core."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Optional, Sequence


def build_mor_params(
    *,
    partition: Any,
    primary_keys: Sequence[str],
    sort_keys: Optional[Any],
    output_sort_scheme: Optional[Any],
    hash_bucket_count: int,
    deltacat_storage: Any,
    deltacat_storage_kwargs: dict,
    catalog: Any = None,
    original_fields: Optional[Any] = None,
    all_column_names: Optional[Sequence[str]] = None,
    table_writer_kwargs: Optional[dict] = None,
    qualified_deltas: Optional[Sequence[Any]] = None,
    compact_partition_params_factory=None,
    compacted_file_content_type: Any = None,
) -> Any:
    """Build the lightweight compaction params object used by MOR."""
    last_stream_position = max(
        (d.stream_position or 0 for d in (qualified_deltas or [])),
        default=0,
    )

    storage_kwargs_copy = {
        key: value
        for key, value in deltacat_storage_kwargs.items()
        if key != "transaction"
    }
    if catalog is not None:
        storage_kwargs_copy["catalog"] = catalog

    return compact_partition_params_factory.of(
        {
            "catalog": catalog,
            "source_partition_locator": partition.locator,
            "destination_partition_locator": partition.locator,
            "primary_keys": list(primary_keys),
            "last_stream_position_to_compact": last_stream_position,
            "deltacat_storage": deltacat_storage,
            "deltacat_storage_kwargs": storage_kwargs_copy,
            "list_deltas_kwargs": storage_kwargs_copy,
            "table_writer_kwargs": table_writer_kwargs or {},
            "hash_bucket_count": hash_bucket_count,
            "compacted_file_content_type": compacted_file_content_type,
            "drop_duplicates": True,
            "sort_keys": sort_keys,
            "output_sort_scheme": output_sort_scheme,
            "original_fields": original_fields,
            "all_column_names": list(all_column_names or []),
        }
    )


def contains_delete_deltas(
    deltas: Sequence[Any],
    *,
    delete_delta_type: Any,
) -> bool:
    """Return whether any delta in the sequence is a DELETE delta."""
    for delta in deltas:
        if delta.type is delete_delta_type:
            return True
    return False


def normalize_output_sort_scheme(
    sort_scheme: Any,
    *,
    sort_scheme_type: type,
) -> Any:
    """Normalize a sort scheme into the native SortScheme type when present."""
    if not sort_scheme:
        return None
    return (
        sort_scheme
        if isinstance(sort_scheme, sort_scheme_type)
        else sort_scheme_type(sort_scheme)
    )


def fetch_compaction_metadata(
    *,
    params: Any,
    read_round_completion_info_fn,
    get_delta_manifest_fn,
    normalize_output_sort_scheme_fn,
    sha1_hash_strategy_value: str,
    range_strategy_value: str,
    log_info_fn,
) -> tuple[Optional[Any], Optional[Any]]:
    """Fetch prior compaction metadata and validate bucketing compatibility."""
    round_completion_info = None
    previous_compacted_delta_manifest = None

    if not params.rebase_source_partition_locator:
        round_completion_info = read_round_completion_info_fn(
            source_partition_locator=params.source_partition_locator,
            destination_partition_locator=params.destination_partition_locator,
            deltacat_storage=params.deltacat_storage,
            deltacat_storage_kwargs=params.deltacat_storage_kwargs,
        )
        if not round_completion_info:
            log_info_fn(
                "Both rebase partition and round completion file not found. Performing an entire backfill on source."
            )
        else:
            compacted_delta_locator = round_completion_info.compacted_delta_locator
            previous_compacted_delta_manifest = get_delta_manifest_fn(
                compacted_delta_locator, **params.deltacat_storage_kwargs
            )
            log_info_fn(
                f"Setting round completion high watermark: {round_completion_info.high_watermark}"
            )

            prev_strategy = round_completion_info.get(
                "bucketingStrategy", sha1_hash_strategy_value
            )
            sort_scheme = normalize_output_sort_scheme_fn(params.output_sort_scheme)
            curr_strategy = sha1_hash_strategy_value
            if sort_scheme and sort_scheme.keys:
                curr_strategy = range_strategy_value

            if prev_strategy != curr_strategy:
                log_info_fn(
                    f"Bucketing strategy changed ({prev_strategy} -> {curr_strategy}). Forcing rebase compaction."
                )
                round_completion_info = None
                previous_compacted_delta_manifest = None
            else:
                assert (
                    params.hash_bucket_count == round_completion_info.hash_bucket_count
                ), (
                    "Partition hash bucket count for compaction has changed. "
                    "Rebase compaction with the desired hash bucket count before "
                    "running another incremental compaction. "
                    f"Hash bucket count in RCI={round_completion_info.hash_bucket_count} "
                    f"!= hash bucket count in params={params.hash_bucket_count}."
                )

        log_info_fn(f"Round completion file: {round_completion_info}")

    return previous_compacted_delta_manifest, round_completion_info


def generate_local_merge_input(
    *,
    params: Any,
    annotated_deltas: Sequence[Any],
    compacted_partition: Any,
    round_completion_info: Optional[Any],
    merge_input_factory,
    local_merge_file_groups_provider_factory,
    delete_strategy: Optional[Any] = None,
    delete_file_envelopes: Optional[Any] = None,
) -> Any:
    """Generate the local merge input used by single-bucket MOR."""
    return merge_input_factory.of(
        merge_file_groups_provider=local_merge_file_groups_provider_factory(
            annotated_deltas,
            all_column_names=params.all_column_names,
            read_kwargs_provider=params.read_kwargs_provider,
            deltacat_storage=params.deltacat_storage,
            deltacat_storage_kwargs=params.deltacat_storage_kwargs,
        ),
        write_to_partition=compacted_partition,
        compacted_file_content_type=params.compacted_file_content_type,
        primary_keys=params.primary_keys,
        all_column_names=params.all_column_names,
        sort_keys=params.sort_keys,
        sort_keys_precede_stream_position=params.sort_keys_precede_stream_position,
        drop_duplicates=params.drop_duplicates,
        max_records_per_output_file=params.records_per_compacted_file,
        enable_profiler=params.enable_profiler,
        metrics_config=params.metrics_config,
        table_writer_kwargs=params.table_writer_kwargs,
        read_kwargs_provider=params.read_kwargs_provider,
        round_completion_info=round_completion_info,
        object_store=params.object_store,
        deltacat_storage=params.deltacat_storage,
        deltacat_storage_kwargs=params.deltacat_storage_kwargs,
        delete_strategy=delete_strategy,
        delete_file_envelopes=delete_file_envelopes,
        disable_copy_by_reference=params.disable_copy_by_reference,
        hash_bucket_count=params.hash_bucket_count,
        original_fields=params.original_fields,
        output_sort_scheme=params.output_sort_scheme,
    )


def aggregate_bucket_results(
    params: Any,
    hb_results: Sequence[Any],
    *,
    log_info_fn,
) -> tuple[dict, dict, dict, Any, Any]:
    """Aggregate bucketing results into per-hash-group maps for merge tasks."""
    all_hash_group_idx_to_obj_id = defaultdict(list)
    all_hash_group_idx_to_size_bytes = defaultdict(int)
    all_hash_group_idx_to_num_rows = defaultdict(int)
    total_input_records_count = 0

    for hb_group in range(params.hash_group_count):
        all_hash_group_idx_to_num_rows[hb_group] = 0
        all_hash_group_idx_to_obj_id[hb_group] = []
        all_hash_group_idx_to_size_bytes[hb_group] = 0

    for hb_result in hb_results:
        total_input_records_count += hb_result.hb_record_count
        for hash_group_index, object_id_size_tuple in enumerate(
            hb_result.hash_bucket_group_to_obj_id_tuple
        ):
            if object_id_size_tuple:
                all_hash_group_idx_to_obj_id[hash_group_index].append(
                    object_id_size_tuple[0]
                )
                all_hash_group_idx_to_size_bytes[hash_group_index] += int(
                    object_id_size_tuple[1]
                )
                all_hash_group_idx_to_num_rows[hash_group_index] += int(
                    object_id_size_tuple[2]
                )

    log_info_fn(
        f"Got {total_input_records_count} bucket records from bucketing step..."
    )

    return (
        all_hash_group_idx_to_obj_id,
        all_hash_group_idx_to_size_bytes,
        all_hash_group_idx_to_num_rows,
        total_input_records_count,
        total_input_records_count,
    )


def run_range_bucketing(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    sort_column: str,
    round_completion_info: Optional[Any] = None,
    compute_range_boundaries_fn=None,
    run_range_bucket_fn=None,
    log_info_fn=None,
) -> tuple[Any, Any, list]:
    """Run range bucketing, reusing prior boundaries when available."""
    boundaries = None
    if round_completion_info:
        boundaries = round_completion_info.get("rangeBoundaries")
        if boundaries:
            log_info_fn(
                f"Reusing {len(boundaries)} range boundaries from previous "
                f"compaction round for column '{sort_column}'."
            )

    if not boundaries:
        log_info_fn(
            f"Computing range boundaries on column '{sort_column}' "
            f"with {params.hash_bucket_count} buckets."
        )
        boundaries = compute_range_boundaries_fn(
            input_deltas=uniform_deltas,
            sort_column=sort_column,
            num_buckets=params.hash_bucket_count,
            deltacat_storage=params.deltacat_storage,
            deltacat_storage_kwargs={
                k: v
                for k, v in params.deltacat_storage_kwargs.items()
                if k != "transaction"
            },
        )

    results, invoke_end = run_range_bucket_fn(
        params,
        uniform_deltas,
        boundaries,
        sort_column,
    )
    return results, invoke_end, boundaries


def hash_bucket(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    invoke_parallel_fn,
    hash_bucket_task,
    options_provider,
    hash_bucket_input_factory,
    monotonic_time_fn,
    ray_get_fn,
    log_info_fn,
) -> tuple[Any, float]:
    """Run the distributed hash bucketing step."""
    deltacat_storage_kwargs_copy = {
        k: v for k, v in params.deltacat_storage_kwargs.items() if k != "transaction"
    }

    def hash_bucket_input_provider(index, item) -> dict:
        return {
            "input": hash_bucket_input_factory.of(
                item,
                primary_keys=params.primary_keys,
                hb_task_index=index,
                num_hash_buckets=params.hash_bucket_count,
                num_hash_groups=params.hash_group_count,
                all_column_names=params.all_column_names,
                enable_profiler=params.enable_profiler,
                metrics_config=params.metrics_config,
                read_kwargs_provider=params.read_kwargs_provider,
                object_store=params.object_store,
                deltacat_storage=params.deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs_copy,
                memory_logs_enabled=params.memory_logs_enabled,
            )
        }

    hb_tasks_pending = invoke_parallel_fn(
        items=uniform_deltas,
        ray_task=hash_bucket_task,
        max_parallelism=params.task_max_parallelism,
        options_provider=options_provider,
        kwargs_provider=hash_bucket_input_provider,
    )
    hb_invoke_end = monotonic_time_fn()

    log_info_fn(f"Getting {len(hb_tasks_pending)} hash bucket results...")
    hb_results = ray_get_fn(hb_tasks_pending)
    log_info_fn(f"Got {len(hb_results)} hash bucket results.")
    return hb_results, hb_invoke_end


def range_bucket(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    boundaries: list,
    sort_column: str,
    invoke_parallel_fn,
    range_bucket_task,
    options_provider,
    hash_bucket_input_factory,
    monotonic_time_fn,
    ray_get_fn,
    log_info_fn,
) -> tuple[Any, float]:
    """Run the distributed range bucketing step."""
    deltacat_storage_kwargs_copy = {
        k: v for k, v in params.deltacat_storage_kwargs.items() if k != "transaction"
    }

    def range_bucket_input_provider(index, item) -> dict:
        return {
            "input": hash_bucket_input_factory.of(
                item,
                primary_keys=params.primary_keys,
                hb_task_index=index,
                num_hash_buckets=params.hash_bucket_count,
                num_hash_groups=params.hash_group_count,
                all_column_names=params.all_column_names,
                enable_profiler=params.enable_profiler,
                metrics_config=params.metrics_config,
                read_kwargs_provider=params.read_kwargs_provider,
                object_store=params.object_store,
                deltacat_storage=params.deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs_copy,
                memory_logs_enabled=params.memory_logs_enabled,
            ),
            "boundaries": boundaries,
            "sort_column": sort_column,
        }

    rb_tasks_pending = invoke_parallel_fn(
        items=uniform_deltas,
        ray_task=range_bucket_task,
        max_parallelism=params.task_max_parallelism,
        options_provider=options_provider,
        kwargs_provider=range_bucket_input_provider,
    )
    rb_invoke_end = monotonic_time_fn()

    log_info_fn(f"Getting {len(rb_tasks_pending)} range bucket results...")
    rb_results = ray_get_fn(rb_tasks_pending)
    log_info_fn(f"Got {len(rb_results)} range bucket results.")
    return rb_results, rb_invoke_end


def run_range_bucket(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    boundaries: list,
    sort_column: str,
    options_provider,
    invoke_parallel_fn,
    range_bucket_task,
    hash_bucket_input_factory,
    monotonic_time_fn,
    ray_get_fn,
    log_info_fn,
) -> tuple[Any, float]:
    """Run the lower-level distributed range bucket task launcher."""
    deltacat_storage_kwargs_copy = {
        k: v for k, v in params.deltacat_storage_kwargs.items() if k != "transaction"
    }

    def range_bucket_input_provider(index, item) -> dict:
        return {
            "input": hash_bucket_input_factory.of(
                item,
                primary_keys=params.primary_keys,
                hb_task_index=index,
                num_hash_buckets=params.hash_bucket_count,
                num_hash_groups=params.hash_group_count,
                all_column_names=params.all_column_names,
                enable_profiler=params.enable_profiler,
                metrics_config=params.metrics_config,
                read_kwargs_provider=params.read_kwargs_provider,
                object_store=params.object_store,
                deltacat_storage=params.deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs_copy,
                memory_logs_enabled=params.memory_logs_enabled,
            ),
            "boundaries": boundaries,
            "sort_column": sort_column,
        }

    rb_tasks_pending = invoke_parallel_fn(
        items=uniform_deltas,
        ray_task=range_bucket_task,
        max_parallelism=params.task_max_parallelism,
        options_provider=options_provider,
        kwargs_provider=range_bucket_input_provider,
    )
    rb_invoke_end = monotonic_time_fn()

    log_info_fn(f"Getting {len(rb_tasks_pending)} range bucket results...")
    rb_results = ray_get_fn(rb_tasks_pending)
    log_info_fn(f"Got {len(rb_results)} range bucket results.")
    return rb_results, rb_invoke_end


def build_uniform_deltas(
    *,
    params: Any,
    mutable_compaction_audit: Any,
    input_deltas: list[Any],
    delta_discovery_start: float,
    contains_delete_deltas_fn,
    prepare_deletes_fn,
    create_uniform_input_deltas_fn,
    upload_audit_data_fn,
    delete_delta_type: Any,
    monotonic_time_fn,
    log_info_fn,
) -> tuple[list[Any], Any, Any]:
    """Build uniform deltas and associated delete metadata."""
    delete_strategy = None
    delete_file_envelopes = None
    delete_file_size_bytes = 0
    if contains_delete_deltas_fn(input_deltas):
        input_deltas, delete_file_envelopes, delete_strategy = prepare_deletes_fn(
            params, input_deltas
        )
        for delete_file_envelope in delete_file_envelopes:
            delete_file_size_bytes += delete_file_envelope.table_size_bytes
        log_info_fn(
            f" Input deltas contain {delete_delta_type}-type deltas. Total delete file size={delete_file_size_bytes}."
            f" Total length of delete file envelopes={len(delete_file_envelopes)}"
        )

    uniform_deltas = create_uniform_input_deltas_fn(
        input_deltas=input_deltas,
        hash_bucket_count=params.hash_bucket_count,
        compaction_audit=mutable_compaction_audit,
        compact_partition_params=params,
        all_column_names=params.all_column_names,
        deltacat_storage=params.deltacat_storage,
        deltacat_storage_kwargs=params.deltacat_storage_kwargs,
    )

    delta_discovery_end = monotonic_time_fn()
    mutable_compaction_audit.set_uniform_deltas_created(len(uniform_deltas))
    mutable_compaction_audit.set_delta_discovery_time_in_seconds(
        delta_discovery_end - delta_discovery_start
    )

    upload_audit_data_fn(
        params,
        mutable_compaction_audit,
    )
    return uniform_deltas, delete_strategy, delete_file_envelopes


def run_local_mor(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    round_completion_info: Optional[Any],
    delete_strategy: Any,
    delete_file_envelopes: Any,
    previous_compacted_delta_manifest: Optional[Any],
    distributed: bool,
    generate_local_merge_input_fn,
    merge_for_read_remote_fn,
    ray_get_fn,
    audit_factory,
    from_arrow_refs_fn,
    empty_table_factory,
) -> tuple[Any, Any]:
    """Run the single-bucket MOR path without bucketing."""
    local_merge_input = generate_local_merge_input_fn(
        params=params,
        uniform_deltas=uniform_deltas,
        compacted_partition=None,
        round_completion_info=round_completion_info,
        delete_strategy=delete_strategy,
        delete_file_envelopes=delete_file_envelopes,
        previous_compacted_delta_manifest=previous_compacted_delta_manifest,
    )

    result = ray_get_fn(merge_for_read_remote_fn(local_merge_input))

    audit = audit_factory()
    audit.set_input_records(int(result.input_record_count))
    audit.set_records_deduped(int(result.deduped_record_count))
    audit.set_records_deleted(int(result.deleted_record_count))

    if distributed and result.table_ref is not None and result.num_rows > 0:
        return from_arrow_refs_fn([result.table_ref]), audit

    table = (
        ray_get_fn(result.table_ref)
        if result.table_ref is not None
        else empty_table_factory()
    )
    return table, audit


def run_merge_for_read(
    *,
    params: Any,
    all_hash_group_idx_to_obj_id: dict,
    round_completion_info: Optional[Any],
    previous_compacted_delta_manifest: Optional[Any],
    delete_strategy: Any,
    delete_file_envelopes: Any,
    distributed: bool,
    get_delta_manifest_fn,
    merge_input_factory,
    remote_merge_file_groups_provider_factory,
    invoke_parallel_fn,
    merge_for_read_task,
    ray_get_fn,
    audit_factory,
    from_arrow_refs_fn,
    concat_tables_fn,
    empty_table_factory,
) -> tuple[Any, Any]:
    """Run distributed merge-for-read tasks and collect the results."""
    if round_completion_info:
        previous_compacted_delta_manifest = get_delta_manifest_fn(
            round_completion_info.compacted_delta_locator,
            **params.deltacat_storage_kwargs,
        )

    deltacat_storage_kwargs_copy = {
        key: value
        for key, value in params.deltacat_storage_kwargs.items()
        if key != "transaction"
    }

    def merge_input_provider(index, item) -> dict:
        return {
            "input": merge_input_factory.of(
                merge_file_groups_provider=remote_merge_file_groups_provider_factory(
                    hash_group_index=item[0],
                    dfe_groups_refs=item[1],
                    hash_bucket_count=params.hash_bucket_count,
                    num_hash_groups=params.hash_group_count,
                    object_store=params.object_store,
                ),
                write_to_partition=None,
                compacted_file_content_type=params.compacted_file_content_type,
                primary_keys=params.primary_keys,
                all_column_names=params.all_column_names,
                sort_keys=params.sort_keys,
                sort_keys_precede_stream_position=params.sort_keys_precede_stream_position,
                merge_task_index=index,
                drop_duplicates=params.drop_duplicates,
                max_records_per_output_file=params.records_per_compacted_file,
                enable_profiler=params.enable_profiler,
                metrics_config=params.metrics_config,
                table_writer_kwargs=params.table_writer_kwargs,
                read_kwargs_provider=params.read_kwargs_provider,
                round_completion_info=round_completion_info,
                object_store=params.object_store,
                deltacat_storage=params.deltacat_storage,
                deltacat_storage_kwargs=deltacat_storage_kwargs_copy,
                delete_strategy=delete_strategy,
                delete_file_envelopes=delete_file_envelopes,
                memory_logs_enabled=params.memory_logs_enabled,
                disable_copy_by_reference=params.disable_copy_by_reference,
                hash_bucket_count=params.hash_bucket_count,
                original_fields=params.original_fields,
                compacted_manifest=previous_compacted_delta_manifest,
                output_sort_scheme=params.output_sort_scheme,
            )
        }

    merge_tasks_pending = invoke_parallel_fn(
        items=all_hash_group_idx_to_obj_id.items(),
        ray_task=merge_for_read_task,
        max_parallelism=params.task_max_parallelism,
        kwargs_provider=merge_input_provider,
    )

    results = ray_get_fn(merge_tasks_pending)
    total_input = sum(r.input_record_count for r in results)
    total_deduped = sum(r.deduped_record_count for r in results)
    total_deleted = sum(r.deleted_record_count for r in results)
    audit = audit_factory()
    audit.set_input_records(int(total_input))
    audit.set_records_deduped(int(total_deduped))
    audit.set_records_deleted(int(total_deleted))

    table_refs = [r.table_ref for r in results if r.table_ref and r.num_rows > 0]
    inline_tables = [r.table for r in results if r.table is not None and r.num_rows > 0]
    del results

    if distributed and table_refs and not inline_tables:
        return from_arrow_refs_fn(table_refs), audit

    all_tables = []
    if table_refs:
        all_tables.extend(ray_get_fn(table_refs))
    all_tables.extend(inline_tables)

    if all_tables:
        return concat_tables_fn(all_tables), audit
    return empty_table_factory(), audit


def run_mor_pipeline(
    *,
    params: Any,
    uniform_deltas: Sequence[Any],
    round_completion_info: Optional[Any],
    delete_strategy: Any,
    delete_file_envelopes: Any,
    previous_compacted_delta_manifest: Optional[Any],
    distributed: bool,
    normalize_output_sort_scheme_fn,
    run_range_bucketing_fn,
    hash_bucket_fn,
    aggregate_bucket_results_fn,
    run_local_mor_fn,
    run_merge_for_read_fn,
) -> tuple[Any, Any]:
    """Run the bucketing plus merge-for-read MOR pipeline."""
    sort_scheme = normalize_output_sort_scheme_fn(params.output_sort_scheme)
    use_range_bucketing = False
    effective_sort_col = None
    if sort_scheme and sort_scheme.keys:
        use_range_bucketing = True
        effective_sort_col = sort_scheme.keys[0].key[0]

    if params.hash_bucket_count == 1:
        return run_local_mor_fn(
            params,
            uniform_deltas,
            round_completion_info,
            delete_strategy,
            delete_file_envelopes,
            previous_compacted_delta_manifest,
            distributed,
        )

    if use_range_bucketing:
        hb_results, _, range_boundaries = run_range_bucketing_fn(
            params,
            uniform_deltas,
            effective_sort_col,
            round_completion_info,
        )
        params["_range_boundaries"] = range_boundaries
    else:
        hb_results, _ = hash_bucket_fn(params, uniform_deltas)

    (
        all_hash_group_idx_to_obj_id,
        _all_hash_group_idx_to_size_bytes,
        _all_hash_group_idx_to_num_rows,
        _total_input_records,
        _total_hb_records,
    ) = aggregate_bucket_results_fn(params, hb_results)

    try:
        return run_merge_for_read_fn(
            params=params,
            all_hash_group_idx_to_obj_id=all_hash_group_idx_to_obj_id,
            round_completion_info=round_completion_info,
            previous_compacted_delta_manifest=previous_compacted_delta_manifest,
            delete_strategy=delete_strategy,
            delete_file_envelopes=delete_file_envelopes,
            distributed=distributed,
        )
    finally:
        params.object_store.clear()


def execute_merge_on_read(
    *,
    qualified_deltas: Sequence[Any],
    partition: Any,
    primary_keys: Sequence[str],
    sort_keys: Optional[Any],
    output_sort_scheme: Optional[Any],
    hash_bucket_count: int,
    deltacat_storage: Any,
    deltacat_storage_kwargs: dict,
    catalog: Any = None,
    original_fields: Optional[Any] = None,
    all_column_names: Optional[Sequence[str]] = None,
    table_writer_kwargs: Optional[dict] = None,
    distributed: bool = False,
    table_identifier: Optional[str] = None,
    build_mor_params_fn=None,
    fetch_compaction_metadata_fn=None,
    contains_delete_deltas_fn=None,
    prepare_deletes_fn=None,
    delta_annotated_factory=None,
    run_mor_pipeline_fn=None,
    emit_audit_metrics_and_logs_fn=None,
    empty_table_factory=None,
    monotonic_time_fn=None,
    log_info_fn=None,
) -> Any:
    """Run the full read-only MOR pipeline through injected native callbacks."""
    if not qualified_deltas:
        if log_info_fn is not None:
            log_info_fn("merge_on_read: no qualified deltas, returning empty table")
        return empty_table_factory()

    params = build_mor_params_fn(
        partition=partition,
        primary_keys=primary_keys,
        sort_keys=sort_keys,
        output_sort_scheme=output_sort_scheme,
        hash_bucket_count=hash_bucket_count,
        deltacat_storage=deltacat_storage,
        deltacat_storage_kwargs=deltacat_storage_kwargs,
        catalog=catalog,
        original_fields=original_fields,
        all_column_names=all_column_names,
        table_writer_kwargs=table_writer_kwargs,
        qualified_deltas=qualified_deltas,
    )

    (
        previous_compacted_delta_manifest,
        round_completion_info,
    ) = fetch_compaction_metadata_fn(params)

    delete_strategy = None
    delete_file_envelopes = None
    input_deltas = list(qualified_deltas)
    if contains_delete_deltas_fn(input_deltas):
        input_deltas, delete_file_envelopes, delete_strategy = prepare_deletes_fn(
            params, input_deltas
        )
    uniform_deltas = [delta_annotated_factory.of(d) for d in input_deltas]

    if not uniform_deltas and not delete_file_envelopes:
        if log_info_fn is not None:
            log_info_fn(
                "merge_on_read: no uniform deltas or delete envelopes after processing %d qualified deltas, returning empty table",
                len(qualified_deltas),
            )
        return empty_table_factory()

    mor_start = monotonic_time_fn()
    result, mor_audit = run_mor_pipeline_fn(
        params=params,
        uniform_deltas=uniform_deltas,
        round_completion_info=round_completion_info,
        delete_strategy=delete_strategy,
        delete_file_envelopes=delete_file_envelopes,
        previous_compacted_delta_manifest=previous_compacted_delta_manifest,
        distributed=distributed,
    )
    mor_audit.set_compaction_time_in_seconds(monotonic_time_fn() - mor_start)
    mor_audit.set_hash_bucket_count(hash_bucket_count)
    emit_audit_metrics_and_logs_fn(
        audit=mor_audit,
        mode="mor",
        table_identifier=table_identifier,
        metrics_config=params.metrics_config,
    )
    return result
