"""Shared merge file group models and providers."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, List, Optional

from deltacat_io_core.merge_file_group_support import (
    create_local_merge_file_groups,
    create_remote_merge_file_groups,
)


class MergeFileGroup(dict):
    @staticmethod
    def of(hb_index: int, dfe_groups: Optional[List[List[Any]]] = None):
        d = MergeFileGroup()
        d["hb_index"] = hb_index
        d["dfe_groups"] = dfe_groups
        return d

    @property
    def dfe_groups(self) -> Optional[List[List[Any]]]:
        return self["dfe_groups"]

    @property
    def hb_index(self) -> int:
        return self["hb_index"]


class MergeFileGroupsProvider(ABC):
    @abstractmethod
    def create(self) -> List[MergeFileGroup]:
        raise NotImplementedError("Method not implemented")

    @property
    @abstractmethod
    def hash_group_index(self):
        raise NotImplementedError("Method not implemented")


class LocalMergeFileGroupsProvider(MergeFileGroupsProvider):
    LOCAL_HASH_BUCKET_INDEX = 0
    LOCAL_HASH_GROUP_INDEX = 0

    def __init__(
        self,
        uniform_deltas,
        all_column_names,
        read_kwargs_provider,
        *,
        deltacat_storage,
        deltacat_storage_kwargs: Optional[dict] = None,
        get_local_delta_file_envelopes_fn,
    ):
        self._deltas = uniform_deltas
        self._all_column_names = all_column_names
        self._read_kwargs_provider = read_kwargs_provider
        self._deltacat_storage = deltacat_storage
        self._deltacat_storage_kwargs = deltacat_storage_kwargs
        self._get_local_delta_file_envelopes_fn = get_local_delta_file_envelopes_fn
        self._loaded_deltas = False

    def _read_deltas_locally(self):
        self._dfe_groups = create_local_merge_file_groups(
            uniform_deltas=self._deltas,
            all_column_names=self._all_column_names,
            read_kwargs_provider=self._read_kwargs_provider,
            deltacat_storage=self._deltacat_storage,
            deltacat_storage_kwargs=self._deltacat_storage_kwargs,
            get_local_delta_file_envelopes_fn=self._get_local_delta_file_envelopes_fn,
            merge_file_group_factory=MergeFileGroup.of,
            local_hash_bucket_index=LocalMergeFileGroupsProvider.LOCAL_HASH_BUCKET_INDEX,
        )
        self._loaded_deltas = True

    def create(self) -> List[MergeFileGroup]:
        if not self._loaded_deltas:
            self._read_deltas_locally()
        return self._dfe_groups

    @property
    def hash_group_index(self):
        return LocalMergeFileGroupsProvider.LOCAL_HASH_GROUP_INDEX


class RemoteMergeFileGroupsProvider(MergeFileGroupsProvider):
    def __init__(
        self,
        hash_group_index: int,
        dfe_groups_refs,
        hash_bucket_count: int,
        num_hash_groups: int,
        object_store,
        *,
        hash_group_index_to_hash_bucket_indices_fn,
    ):
        self.hash_bucket_count = hash_bucket_count
        self.num_hash_groups = num_hash_groups
        self.object_store = object_store
        self._hash_group_index = hash_group_index
        self._dfe_groups_refs = dfe_groups_refs
        self._dfe_groups = []
        self._loaded_from_object_store = False
        self._hash_group_index_to_hash_bucket_indices_fn = (
            hash_group_index_to_hash_bucket_indices_fn
        )

    def _load_deltas_from_object_store(self):
        self._dfe_groups = create_remote_merge_file_groups(
            hash_group_index=self._hash_group_index,
            dfe_groups_refs=self._dfe_groups_refs,
            hash_bucket_count=self.hash_bucket_count,
            num_hash_groups=self.num_hash_groups,
            object_store=self.object_store,
            hash_group_index_to_hash_bucket_indices_fn=self._hash_group_index_to_hash_bucket_indices_fn,
            merge_file_group_factory=MergeFileGroup.of,
        )
        self._loaded_from_object_store = True

    def create(self) -> List[MergeFileGroup]:
        if not self._loaded_from_object_store:
            self._load_deltas_from_object_store()
        return self._dfe_groups

    @property
    def hash_group_index(self):
        return self._hash_group_index
