"""Shared session/result enums and models for compactor execution."""

from __future__ import annotations

from dataclasses import dataclass, fields
from enum import Enum
from typing import Dict, NamedTuple, Optional, Tuple

import numpy as np


@dataclass(frozen=True)
class ExecutionCompactionResult:
    new_compacted_partition: Optional[object]
    new_round_completion_info: Optional[object]
    partition_stats_deltas: Optional[list[object]]
    is_inplace_compacted: bool

    def __iter__(self):
        return (getattr(self, field.name) for field in fields(self))


class CompactorVersion(str, Enum):
    V1 = "V1"
    V2 = "V2"


class BucketingStrategy(str, Enum):
    SHA1_HASH = "SHA1_HASH"
    RANGE = "RANGE"


class DedupeResult(NamedTuple):
    mat_bucket_idx_to_obj_id: Dict[int, Tuple]
    deduped_record_count: np.int64
    peak_memory_usage_bytes: np.double
    telemetry_time_in_seconds: np.double
    task_completed_at: np.double
