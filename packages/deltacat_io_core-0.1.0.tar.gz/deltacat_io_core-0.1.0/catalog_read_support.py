"""Shared catalog read orchestration moved out of thick catalog/main/impl.py."""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, Sequence, Tuple

import deltacat_io_core.logs as logs

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


@dataclass(frozen=True)
class PreparedSchemaTableRead:
    merged_delta: Any
    table_type: Any
    distributed_dataset_type: Optional[Any]


def execute_merge_on_read(
    *,
    qualified_deltas: Sequence[Any],
    partition_filter: Optional[Sequence[Any]],
    table_version_obj: Any,
    namespace: str,
    table: str,
    original_read_as: Any,
    effective_read_as: Any,
    row_filter: Optional[Any],
    columns: Optional[list[str]],
    kwargs: Dict[str, Any],
    execute_read_only_mor_fn: Callable[..., Any],
    get_storage_fn: Callable[..., Any],
    get_partition_lookup_fn: Callable[..., Any],
    get_merge_key_field_names_fn: Callable[[Any], Sequence[str]],
    get_merge_order_sort_keys_fn: Callable[[Any], Any],
    get_compaction_hash_bucket_count_fn: Callable[..., int],
    apply_post_download_filter_fn: Callable[[Any, Any, Any], Any],
    from_pyarrow_fn: Callable[[Any, Any], Any],
    convert_pandas_to_numpy_fn: Callable[[Any], Any],
    is_distributed_dataset_type_fn: Callable[[Any], bool],
    ray_dataset_type: Any,
    daft_dataset_type: Any,
    pyarrow_dataset_type: Any,
    numpy_dataset_type: Any,
    mor_disabled: bool,
    build_mor_params_fn=None,
    fetch_compaction_metadata_fn=None,
    contains_delete_deltas_fn=None,
    prepare_deletes_fn=None,
    delta_annotated_factory=None,
    run_mor_pipeline_fn=None,
    emit_audit_metrics_and_logs_fn=None,
    empty_table_factory=None,
    monotonic_time_fn=None,
    log_info_fn=None,
    error_cls: type[Exception] = RuntimeError,
) -> Any:
    """Execute the standard merge-on-read branch for schema-table reads."""
    import pyarrow as pa

    if mor_disabled:
        raise error_cls(
            f"Merge-on-read is required for {namespace}/{table}/"
            f"{table_version_obj.table_version} ({len(qualified_deltas)} "
            f"uncompacted deltas with merge keys) but is disabled via "
            f"DELTACAT_DISABLE_MOR. Either unset DELTACAT_DISABLE_MOR or "
            f"run compaction (READ_OPTIMIZATION_LEVEL=MAX) to resolve "
            f"deltas before reading."
        )

    logger.info(
        "Merge-on-read: %d deltas with merge keys for %s/%s/%s, routing through unified compaction pipeline",
        len(qualified_deltas),
        namespace,
        table,
        table_version_obj.table_version,
    )

    partition = None
    if partition_filter:
        for candidate in partition_filter:
            if hasattr(candidate, "compaction_round_completion_info"):
                partition = candidate
                break
    if partition is None:
        first_delta = qualified_deltas[0]
        sl = first_delta.partition_locator.stream_locator
        partition = get_partition_lookup_fn(
            sl,
            partition_values=first_delta.partition_locator.partition_values,
            **kwargs,
        )
    else:
        first_delta = qualified_deltas[0]
        sl = first_delta.partition_locator.stream_locator

    if partition is None:
        raise ValueError(
            f"Merge-on-read failed: partition not found for "
            f"{namespace}/{table}/{table_version_obj.table_version} "
            f"(partition_values={first_delta.partition_locator.partition_values}, "
            f"stream_id={sl.stream_id}). "
            f"Cannot look up compaction metadata."
        )

    merge_key_names = get_merge_key_field_names_fn(table_version_obj.schema)
    sort_keys = get_merge_order_sort_keys_fn(table_version_obj)
    hash_bucket_count = get_compaction_hash_bucket_count_fn(
        partition, table_version_obj, **kwargs
    )

    deltacat_storage_kwargs = {k: v for k, v in kwargs.items() if k != "transaction"}
    is_distributed = is_distributed_dataset_type_fn(effective_read_as)
    storage = get_storage_fn(**kwargs)
    mor_result = execute_read_only_mor_fn(
        qualified_deltas=qualified_deltas,
        partition=partition,
        primary_keys=merge_key_names,
        sort_keys=sort_keys,
        output_sort_scheme=table_version_obj.sort_scheme,
        hash_bucket_count=hash_bucket_count,
        deltacat_storage=storage,
        deltacat_storage_kwargs=deltacat_storage_kwargs,
        catalog=kwargs.get("inner"),
        original_fields=(
            set(table_version_obj.schema.arrow.names)
            if table_version_obj.schema and table_version_obj.schema.arrow
            else None
        ),
        all_column_names=(
            list(table_version_obj.schema.arrow.names)
            if table_version_obj.schema and table_version_obj.schema.arrow
            else None
        ),
        table_writer_kwargs=kwargs.get("table_writer_kwargs", {}),
        distributed=is_distributed,
        table_identifier=f"{namespace}/{table}/{table_version_obj.table_version}",
        build_mor_params_fn=build_mor_params_fn,
        fetch_compaction_metadata_fn=fetch_compaction_metadata_fn,
        contains_delete_deltas_fn=contains_delete_deltas_fn,
        prepare_deletes_fn=prepare_deletes_fn,
        delta_annotated_factory=delta_annotated_factory,
        run_mor_pipeline_fn=run_mor_pipeline_fn,
        emit_audit_metrics_and_logs_fn=emit_audit_metrics_and_logs_fn,
        empty_table_factory=empty_table_factory,
        monotonic_time_fn=monotonic_time_fn,
        log_info_fn=log_info_fn,
    )

    if is_distributed and not isinstance(mor_result, pa.Table):
        if effective_read_as == ray_dataset_type:
            return mor_result
        if effective_read_as == daft_dataset_type:
            import daft

            return daft.from_ray_dataset(mor_result)
        return from_pyarrow_fn(mor_result.to_arrow(), effective_read_as)

    arrow_table = (
        mor_result if isinstance(mor_result, pa.Table) else mor_result.to_arrow()
    )
    if row_filter is not None and len(arrow_table) > 0:
        arrow_table = apply_post_download_filter_fn(
            arrow_table, row_filter, pyarrow_dataset_type
        )
    if columns and len(arrow_table) > 0:
        available = [c for c in columns if c in arrow_table.column_names]
        if available:
            arrow_table = arrow_table.select(available)

    if original_read_as == numpy_dataset_type:
        return convert_pandas_to_numpy_fn(arrow_table.to_pandas())
    if effective_read_as == pyarrow_dataset_type:
        return arrow_table
    return from_pyarrow_fn(arrow_table, effective_read_as)


def prepare_schema_table_read(
    *,
    qualified_deltas: Sequence[Any],
    table_version_obj: Any,
    effective_read_as: Any,
    kwargs: Dict[str, Any],
    merge_deltas_fn: Callable[[Sequence[Any]], Any],
    reorder_manifest_entries_fn: Callable[[Any, Any], None],
    is_local_dataset_type_fn: Callable[[Any], bool],
    is_distributed_dataset_type_fn: Callable[[Any], bool],
    default_table_type: Any,
) -> PreparedSchemaTableRead:
    """Prepare the standard non-MOR schema-table read inputs.

    This is the shared prelude for the thick catalog read path after
    schemaless/MOR branching. It preserves the native behavior of:
    - grouping deltas by partition
    - preserving per-delta type ordering for merge-key tables
    - combining manifest entries across partitions
    - sort-aware manifest entry reordering
    - deriving local vs distributed table-type execution parameters
    """
    deltas_by_partition = defaultdict(list)
    for delta in qualified_deltas:
        deltas_by_partition[delta.partition_locator.digest()].append(delta)

    has_merge_keys = table_version_obj.schema and table_version_obj.schema.merge_keys
    merged_deltas = []
    for partition_deltas in deltas_by_partition.values():
        if has_merge_keys:
            sorted_deltas = sorted(
                partition_deltas,
                key=lambda delta: delta.stream_position if delta.stream_position else 0,
            )
            deltas_by_type = defaultdict(list)
            for delta in sorted_deltas:
                deltas_by_type[delta.type].append(delta)
            for type_group in deltas_by_type.values():
                merged_deltas.append(merge_deltas_fn(type_group))
        else:
            merged_deltas.append(merge_deltas_fn(partition_deltas))

    if len(merged_deltas) == 1:
        merged_delta = merged_deltas[0]
    else:
        all_entries = []
        for merged in merged_deltas:
            if merged.manifest and merged.manifest.entries:
                all_entries.extend(merged.manifest.entries)
        merged_delta = merged_deltas[0]
        if merged_delta.manifest:
            merged_delta.manifest["entries"] = all_entries

    if table_version_obj.sort_scheme and table_version_obj.sort_scheme.keys:
        reorder_manifest_entries_fn(merged_delta, table_version_obj.sort_scheme)

    table_type = (
        effective_read_as
        if is_local_dataset_type_fn(effective_read_as)
        else (kwargs.pop("table_type", None) or default_table_type)
    )
    distributed_dataset_type = (
        effective_read_as if is_distributed_dataset_type_fn(effective_read_as) else None
    )

    return PreparedSchemaTableRead(
        merged_delta=merged_delta,
        table_type=table_type,
        distributed_dataset_type=distributed_dataset_type,
    )


def validate_read_table_input(
    namespace: str,
    table: str,
    table_schema: Optional[Any],
    table_type: Optional[Any],
    distributed_dataset_type: Optional[Any],
    *,
    valid_local_types: Sequence[Any],
    valid_distributed_types: Sequence[Any],
    error_cls: type[Exception] = ValueError,
    schemaless_distributed_error_cls: type[Exception] = NotImplementedError,
) -> None:
    """Validate input parameters for the standard schema-table read path."""
    if (
        distributed_dataset_type is not None
        and distributed_dataset_type not in valid_distributed_types
    ):
        raise error_cls(
            f"'{distributed_dataset_type}' is not a valid distributed dataset type. "
            f"Use one of {valid_distributed_types}."
        )
    if table_type is not None and table_type not in valid_local_types:
        raise error_cls(
            f"'{table_type}' is not a valid local table type. "
            f"Use one of {valid_local_types}."
        )
    if table_schema is None and distributed_dataset_type is not None:
        raise schemaless_distributed_error_cls(
            f"Distributed dataset reading is not yet supported for schemaless tables. "
            f"Table {namespace}.{table} has no schema; use a local read type instead."
        )


def get_max_parallelism(
    max_parallelism: Optional[int],
    distributed_dataset_type: Optional[Any],
    *,
    default_local_parallelism: int = 1,
    default_distributed_parallelism: int = 100,
    error_cls: type[Exception] = ValueError,
) -> int:
    """Resolve the effective max_parallelism for a read operation."""
    if distributed_dataset_type:
        max_parallelism = max_parallelism or default_distributed_parallelism
    else:
        max_parallelism = default_local_parallelism
    if max_parallelism < 1:
        raise error_cls(
            f"max_parallelism must be greater than 0, but got {max_parallelism}"
        )
    logger.info("Using max_parallelism=%s for read operation", max_parallelism)
    return max_parallelism


def convert_pandas_to_numpy(dataset: Any, *, error_cls: type[Exception] = ValueError):
    """Convert pandas DataFrame results to numpy ndarray."""
    try:
        import pandas as pd
    except ImportError:
        pd = None
    if pd is None or not isinstance(dataset, pd.DataFrame):
        raise error_cls(f"Expected pandas DataFrame but found {type(dataset)}")
    return dataset.to_numpy()


def create_target_schema(
    arrow_schema: Any,
    *,
    columns: Optional[list[str]] = None,
    file_path_column: Optional[str] = None,
    append_string_field_fn: Optional[Callable[[Any, str], Any]] = None,
) -> Any:
    """Create the target schema for local concatenation/coercion."""
    if columns is not None:
        field_map = {field.name: field for field in arrow_schema}
        selected_fields = []
        for col_name in columns:
            if col_name in field_map:
                selected_fields.append(field_map[col_name])
        import pyarrow as pa

        arrow_schema = pa.schema(selected_fields)
    if file_path_column and file_path_column not in arrow_schema.names:
        if append_string_field_fn is not None:
            arrow_schema = append_string_field_fn(arrow_schema, file_path_column)
        else:
            import pyarrow as pa

            arrow_schema = arrow_schema.append(pa.field(file_path_column, pa.string()))
    return arrow_schema


def coerce_results_to_schema(
    results: Any,
    target_schema: Any,
    *,
    coerce_dataset_to_schema_fn: Callable[[Any, Any], Any],
) -> list[Any]:
    """Coerce local table results to a unified schema before concatenation."""
    coerced_results = []
    for index, table_result in enumerate(results):
        coerced_result = coerce_dataset_to_schema_fn(table_result, target_schema)
        coerced_results.append(coerced_result)
        logger.debug("Coerced table %s to unified schema", index)
    return coerced_results


def handle_local_table_concatenation(
    results: Any,
    table_type: Any,
    table_schema: Any,
    *,
    file_path_column: Optional[str] = None,
    columns: Optional[list[str]] = None,
    create_target_schema_fn: Callable[..., Any],
    coerce_results_to_schema_fn: Callable[[Any, Any], list[Any]],
    concat_tables_fn: Callable[[Any, Any], Any],
) -> Any:
    """Concatenate local table results with schema coercion."""
    logger.debug("Target table schema for concatenation: %s", table_schema)
    target_schema = create_target_schema_fn(
        table_schema.arrow,
        columns=columns,
        file_path_column=file_path_column,
    )
    logger.debug("Created target schema: %s", target_schema.names)
    coerced_results = coerce_results_to_schema_fn(results, target_schema)
    logger.debug(
        "Concatenating %s local tables of type %s with unified schemas",
        len(coerced_results),
        table_type,
    )
    concatenated_result = concat_tables_fn(coerced_results, table_type)
    logger.debug("Concatenation complete, result type: %s", type(concatenated_result))
    return concatenated_result


def execute_prepared_schema_table_read(
    *,
    merged_delta: Any,
    qualified_deltas: Sequence[Any],
    table_version_obj: Any,
    table: str,
    namespace: str,
    read_as: Any,
    original_read_as: Any,
    effective_read_as: Any,
    table_type: Any,
    distributed_dataset_type: Optional[Any],
    max_parallelism: Optional[int],
    columns: Optional[list[str]],
    file_path_column: Optional[str],
    row_filter: Optional[Any],
    default_namespace: str,
    catalog_name: Optional[str],
    catalog_properties: Any,
    kwargs: Dict[str, Any],
    get_max_parallelism_fn: Callable[[Optional[int], Optional[Any]], int],
    validate_read_input_fn: Callable[[str, str, Any, Any, Optional[Any]], None],
    build_local_execution_plan_fn: Callable[..., Any],
    execute_client_plan_fn: Callable[..., Any],
    storage_download_delta_fn: Callable[..., Any],
    apply_post_download_filter_fn: Callable[[Any, Any, Any], Any],
    handle_local_table_concatenation_fn: Callable[..., Any],
    convert_pandas_to_numpy_fn: Callable[[Any], Any],
    local_lazy_table_types: Tuple[Any, ...],
    parquet_content_type: Any,
    polars_dataset_type: Any,
    numpy_dataset_type: Any,
    local_storage_type: Any,
    distributed_storage_type: Any,
) -> Any:
    """Execute the standard non-MOR schema-table read path.

    This is the shared tail of thick catalog reads after:
    - metadata resolution
    - MOR/schemaless branching
    - per-partition delta merging
    - sort-aware manifest entry reordering

    The native caller still owns those higher-level decisions. This helper
    owns the remaining execution orchestration:
    - input validation
    - max-parallelism selection
    - safe delegation to the shared local thin-plan executor
    - fallback to storage.download_delta(...)
    - local table concatenation
    - final numpy conversion
    """
    validate_read_input_fn(
        namespace,
        table,
        table_version_obj.schema,
        table_type,
        distributed_dataset_type,
    )

    resolved_max_parallelism = get_max_parallelism_fn(
        max_parallelism,
        distributed_dataset_type,
    )

    can_delegate_shared_local_read = resolved_max_parallelism == 1
    if read_as == polars_dataset_type:
        supported_content_types = table_version_obj.content_types or []
        can_delegate_shared_local_read = can_delegate_shared_local_read and (
            not supported_content_types
            or all(
                content_type == parquet_content_type
                for content_type in supported_content_types
            )
        )

    if can_delegate_shared_local_read:
        local_plan = build_local_execution_plan_fn(
            resolved_plan={
                "table_version_obj": table_version_obj,
                "qualified_deltas": qualified_deltas,
                "requires_mor": False,
            },
            table=table,
            namespace=namespace,
            default_namespace=default_namespace,
            catalog=catalog_name,
            cat_props=catalog_properties,
        )
        return execute_client_plan_fn(
            local_plan,
            table=table,
            namespace=namespace,
            table_version=table_version_obj.table_version
            if table_version_obj
            else None,
            catalog=catalog_name,
            read_as=read_as,
            row_filter=row_filter,
            columns=columns,
            file_path_column=file_path_column,
        )

    filtered_kwargs = {
        key: value
        for key, value in kwargs.items()
        if key
        not in [
            "delta_like",
            "table_type",
            "storage_type",
            "max_parallelism",
            "columns",
            "distributed_dataset_type",
            "file_path_column",
        ]
    }
    result = storage_download_delta_fn(
        merged_delta,
        table_type=effective_read_as,
        storage_type=(
            distributed_storage_type if distributed_dataset_type else local_storage_type
        ),
        max_parallelism=resolved_max_parallelism,
        columns=columns,
        distributed_dataset_type=distributed_dataset_type,
        file_path_column=file_path_column,
        **filtered_kwargs,
    )

    if not distributed_dataset_type and table_type and isinstance(result, list):
        if table_type in local_lazy_table_types:
            result = result[0] if len(result) == 1 else result
        else:
            result = handle_local_table_concatenation_fn(
                result,
                table_type,
                table_version_obj.schema,
                file_path_column,
                columns,
            )

    if row_filter is not None and result is not None:
        result = apply_post_download_filter_fn(result, row_filter, effective_read_as)

    if original_read_as == numpy_dataset_type:
        return convert_pandas_to_numpy_fn(result)

    return result
