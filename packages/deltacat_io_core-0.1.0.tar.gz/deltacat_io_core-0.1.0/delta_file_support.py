"""Shared delta-file-envelope helpers for compaction and MOR."""

from __future__ import annotations

import numpy as np
from typing import Any, Optional, Sequence


def read_delta_file_envelopes(
    annotated_delta: Any,
    *,
    all_column_names: Optional[Sequence[str]],
    read_kwargs_provider,
    deltacat_storage,
    deltacat_storage_kwargs: Optional[dict],
    storage_type_local,
    concat_tables_fn,
    delta_file_envelope_factory,
) -> tuple[Optional[list[Any]], int, int]:
    """Download a delta locally and wrap it as a single delta-file envelope."""
    storage_kwargs = deltacat_storage_kwargs or {}
    tables = deltacat_storage.download_delta(
        annotated_delta,
        max_parallelism=1,
        file_reader_kwargs_provider=read_kwargs_provider,
        storage_type=storage_type_local,
        all_column_names=list(all_column_names) if all_column_names else None,
        **storage_kwargs,
    )
    annotations = annotated_delta.annotations
    assert len(tables) == len(annotations), (
        f"Unexpected Error: Length of downloaded delta manifest tables "
        f"({len(tables)}) doesn't match the length of delta manifest "
        f"annotations ({len(annotations)})."
    )
    if not tables:
        return None, 0, 0

    delta_stream_position = annotations[0].annotation_stream_position
    delta_type = annotations[0].annotation_delta_type

    for annotation in annotations:
        assert annotation.annotation_stream_position == delta_stream_position, (
            f"Annotation stream position does not match - {annotation.annotation_stream_position} "
            f"!= {delta_stream_position}"
        )
        assert annotation.annotation_delta_type == delta_type, (
            f"Annotation delta type does not match - {annotation.annotation_delta_type} "
            f"!= {delta_type}"
        )

    table = concat_tables_fn(tables)
    delta_file = delta_file_envelope_factory(
        stream_position=delta_stream_position,
        delta_type=delta_type,
        table=table,
    )
    return [delta_file], len(table), int(table.nbytes)


def get_local_delta_file_envelopes(
    uniform_deltas: Sequence[Any],
    *,
    all_column_names: Optional[Sequence[str]],
    read_kwargs_provider,
    deltacat_storage,
    deltacat_storage_kwargs: Optional[dict],
    read_delta_file_envelopes_fn,
    monotonic_time_fn,
    log_info_fn,
) -> tuple[list[Any], int]:
    """Load local delta-file envelopes for a local merge path."""
    local_dfe_list = []
    input_records_count = 0
    log_info_fn(f"Getting {len(uniform_deltas)} DFE Tasks.")
    dfe_start = monotonic_time_fn()
    for annotated_delta in uniform_deltas:
        delta_file_envelopes, total_record_count, _ = read_delta_file_envelopes_fn(
            annotated_delta,
            all_column_names=all_column_names,
            read_kwargs_provider=read_kwargs_provider,
            deltacat_storage=deltacat_storage,
            deltacat_storage_kwargs=deltacat_storage_kwargs,
        )
        if delta_file_envelopes:
            local_dfe_list.extend(delta_file_envelopes)
            input_records_count += total_record_count
    dfe_end = monotonic_time_fn()
    log_info_fn(f"Retrieved {len(local_dfe_list)} DFE Tasks in {dfe_end - dfe_start}s.")
    return local_dfe_list, input_records_count


def group_delta_file_envelopes(
    annotated_delta: Any,
    *,
    bucket_count: int,
    all_column_names: Optional[Sequence[str]],
    read_kwargs_provider,
    deltacat_storage,
    deltacat_storage_kwargs: Optional[dict],
    read_delta_file_envelopes_fn,
    group_table_fn,
    delta_file_envelope_factory,
    monotonic_time_fn,
    log_info_fn,
    grouping_started_message: str,
    grouping_finished_message_template: str,
) -> tuple[Optional[np.ndarray], int, int]:
    """Read a delta locally, regroup it, and wrap grouped tables as DFEs."""
    (
        delta_file_envelopes,
        total_record_count,
        total_size_bytes,
    ) = read_delta_file_envelopes_fn(
        annotated_delta=annotated_delta,
        all_column_names=all_column_names,
        read_kwargs_provider=read_kwargs_provider,
        deltacat_storage=deltacat_storage,
        deltacat_storage_kwargs=deltacat_storage_kwargs,
    )

    if delta_file_envelopes is None:
        return None, 0, 0

    log_info_fn(
        f"Read all delta file envelopes: {len(delta_file_envelopes)} "
        f"and total_size_bytes={total_size_bytes} and records={total_record_count}"
    )

    bucket_to_delta_file_envelopes = np.empty([bucket_count], dtype="object")
    for dfe in delta_file_envelopes:
        log_info_fn(grouping_started_message)
        group_start = monotonic_time_fn()
        bucket_to_table = group_table_fn(dfe.table)
        group_end = monotonic_time_fn()
        log_info_fn(
            grouping_finished_message_template.format(duration=group_end - group_start)
        )
        for bucket_idx, table in enumerate(bucket_to_table):
            if table is not None:
                if bucket_to_delta_file_envelopes[bucket_idx] is None:
                    bucket_to_delta_file_envelopes[bucket_idx] = []
                bucket_to_delta_file_envelopes[bucket_idx].append(
                    delta_file_envelope_factory(
                        stream_position=dfe.stream_position,
                        file_index=dfe.file_index,
                        delta_type=dfe.delta_type,
                        table=table,
                    )
                )
    return bucket_to_delta_file_envelopes, total_record_count, total_size_bytes
