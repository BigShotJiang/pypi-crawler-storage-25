"""Shared block write-path capture helpers moved out of thick tables.py."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional
from uuid import uuid4

import deltacat_io_core.logs as logs
from tenacity import (
    Retrying,
    retry_if_exception_type,
    stop_after_delay,
    wait_random_exponential,
)

from deltacat_io_core.filesystem_support import (
    FilesystemType,
    append_protocol_prefix_by_type,
)
from deltacat_io_core.table_dispatch import get_block_metadata_list

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


try:
    import ray
    from ray.data.datasource import FilenameProvider
except ImportError:  # pragma: no cover - optional for thin installs
    ray = None

    class FilenameProvider:  # type: ignore[override]
        pass


CONTENT_TYPE_TO_EXT = {
    "application/avro": ".avro",
    "text/csv": ".csv",
    "application/feather": ".feather",
    "application/json": ".json",
    "application/vnd.lance": ".lance",
    "application/orc": ".orc",
    "application/parquet": ".parquet",
    "text/psv": ".psv",
    "text/tsv": ".tsv",
    "application/x-amzn-unescaped-tsv": ".tsv",
}

CONTENT_ENCODING_TO_EXT = {
    "gzip": ".gz",
    "bzip2": ".bz2",
    "zstd": ".zst",
    "snappy": ".sz",
    "deflate": ".zz",
}


class CapturedBlockWritePathsBase:
    def __init__(self):
        self._write_paths: List[str] = []
        self._blocks: List[Any] = []
        self._column_stats: List[Optional[Dict]] = []

    def extend(
        self,
        write_paths: List[str],
        blocks: List[Any],
        column_stats: Optional[List[Optional[Dict]]] = None,
    ) -> None:
        try:
            iter(write_paths)
        except TypeError:
            pass
        else:
            self._write_paths.extend(write_paths)
        try:
            iter(blocks)
        except TypeError:
            pass
        else:
            self._blocks.extend(blocks)
        if column_stats is not None:
            self._column_stats.extend(column_stats)

    def write_paths(self) -> List[str]:
        return self._write_paths

    def blocks(self) -> List[Any]:
        return self._blocks

    def column_stats(self) -> List[Optional[Dict]]:
        return self._column_stats


def _create_capture_actor():
    if ray is None:
        raise RuntimeError("Ray is required to create the remote capture actor.")

    @ray.remote
    class _CapturedBlockWritePathsActor:
        def __init__(self):
            self._wrapped = CapturedBlockWritePathsBase()

        def extend(
            self,
            write_paths: List[str],
            blocks: List[Any],
            column_stats: Optional[List[Optional[Dict]]] = None,
        ) -> None:
            self._wrapped.extend(write_paths, blocks, column_stats)

        def write_paths(self) -> List[str]:
            return self._wrapped.write_paths()

        def blocks(self) -> List[Any]:
            return self._wrapped.blocks()

        def column_stats(self) -> List[Optional[Dict]]:
            return self._wrapped.column_stats()

    return _CapturedBlockWritePathsActor.remote()


class CapturedBlockWritePaths:
    def __init__(self, wrapped=None):
        self._wrapped = wrapped or CapturedBlockWritePathsBase()

    def extend(
        self,
        write_paths: List[str],
        blocks: List[Any],
        column_stats: Optional[List[Optional[Dict]]] = None,
    ) -> None:
        return (
            self._wrapped.extend(write_paths, blocks, column_stats)
            if isinstance(self._wrapped, CapturedBlockWritePathsBase)
            else ray.get(self._wrapped.extend.remote(write_paths, blocks, column_stats))
        )

    def write_paths(self) -> List[str]:
        return (
            self._wrapped.write_paths()
            if isinstance(self._wrapped, CapturedBlockWritePathsBase)
            else ray.get(self._wrapped.write_paths.remote())
        )

    def blocks(self) -> List[Any]:
        return (
            self._wrapped.blocks()
            if isinstance(self._wrapped, CapturedBlockWritePathsBase)
            else ray.get(self._wrapped.blocks.remote())
        )

    def column_stats(self) -> List[Optional[Dict]]:
        return (
            self._wrapped.column_stats()
            if isinstance(self._wrapped, CapturedBlockWritePathsBase)
            else ray.get(self._wrapped.column_stats.remote())
        )


def create_capture_object(*, use_ray: bool) -> CapturedBlockWritePaths:
    if use_ray:
        return CapturedBlockWritePaths(_create_capture_actor())
    return CapturedBlockWritePaths(CapturedBlockWritePathsBase())


class UuidBlockWritePathProvider(FilenameProvider):
    """Moved from thick tables.py with injectable column-stats callback."""

    def __init__(
        self,
        capture_object: CapturedBlockWritePaths,
        base_path: Optional[str] = None,
        content_type: Optional[Any] = None,
        content_encoding: Optional[Any] = None,
        column_stats_getter: Optional[Callable[[Any], Optional[Dict]]] = None,
    ):
        self.base_path = base_path
        self.content_type = content_type
        self.content_encoding = content_encoding
        self.write_paths: List[str] = []
        self.blocks: List[Any] = []
        self._column_stats: List[Optional[Dict]] = []
        self.capture_object = capture_object
        self._column_stats_getter = column_stats_getter

    def __del__(self):
        if self.write_paths or self.blocks or self._column_stats:
            self.capture_object.extend(
                self.write_paths,
                self.blocks,
                self._column_stats if self._column_stats else None,
            )

    def get_filename_for_block(
        self,
        block: Any,
        write_uuid: str,
        task_index: int,
        block_index: int,
    ) -> str:
        if self.base_path is None:
            raise ValueError("Base path must be provided to UuidBlockWritePathProvider")
        return self._get_write_path_for_block(
            base_path=self.base_path,
            block=block,
            block_index=block_index,
            write_uuid=write_uuid,
            task_index=task_index,
        )

    def _get_write_path_for_block(
        self,
        base_path: str,
        *,
        block: Optional[Any] = None,
        write_uuid: Optional[str] = None,
        task_index: Optional[int] = None,
        block_index: Optional[int] = None,
        **kwargs,
    ) -> str:
        is_ray_path = (
            write_uuid is not None
            and task_index is not None
            and block_index is not None
        )
        if is_ray_path:
            filename_base = f"{write_uuid}_{task_index:06}_{block_index:06}"
        else:
            filename_base = str(uuid4())

        content_type_key = (
            self.content_type.value
            if hasattr(self.content_type, "value")
            else self.content_type
        )
        content_encoding_key = (
            self.content_encoding.value
            if hasattr(self.content_encoding, "value")
            else self.content_encoding
        )

        extension = ""
        if content_type_key:
            content_type_extension = CONTENT_TYPE_TO_EXT.get(content_type_key)
            if content_type_extension:
                extension += content_type_extension
        if content_encoding_key:
            encoding_extension = CONTENT_ENCODING_TO_EXT.get(content_encoding_key)
            if encoding_extension:
                extension += encoding_extension

        if is_ray_path and content_type_key == "application/parquet":
            template_filename = f"{filename_base}-{{i}}{extension}"
            actual_filename = f"{filename_base}-0{extension}"
        else:
            template_filename = f"{filename_base}{extension}"
            actual_filename = template_filename

        write_path = f"{base_path}/{actual_filename}"
        self.write_paths.append(write_path)
        if block is not None:
            self.blocks.append(block)
            if self._column_stats_getter is not None:
                try:
                    self._column_stats.append(self._column_stats_getter(block))
                except Exception:
                    logger.debug(
                        "Failed to capture per-block column stats for write path %s",
                        write_path,
                        exc_info=True,
                    )
                    self._column_stats.append(None)
            else:
                self._column_stats.append(None)
        else:
            self._column_stats.append(None)
        return template_filename

    def __call__(
        self,
        base_path: str,
        *,
        filesystem: Optional[Any] = None,
        dataset_uuid: Optional[str] = None,
        block: Optional[Any] = None,
        block_index: Optional[int] = None,
        file_format: Optional[str] = None,
    ) -> str:
        return self._get_write_path_for_block(
            base_path,
            filesystem=filesystem,
            dataset_uuid=dataset_uuid,
            block=block,
            block_index=block_index,
            file_format=file_format,
        )


@dataclass
class CapturedWriteResult:
    write_paths: List[str]
    blocks: List[Any]
    column_stats: List[Optional[Dict]]
    block_metadata: List[Any]
    content_encoding: Optional[str]


EXPLICIT_COMPRESSION_CONTENT_TYPES = {
    "application/x-amzn-unescaped-tsv",
    "text/tsv",
    "text/csv",
    "text/psv",
    "application/json",
}


def write_sliced_with_retry(
    table: Any,
    *,
    base_path: str,
    filesystem: Any,
    max_records_per_entry: Optional[int],
    table_slicer_fn: Callable,
    write_one_fn: Callable[[Any], Any],
    retry_exception_type: type,
    retry_stop_after_delay_seconds: int,
    empty_result_factory: Callable[[], Any],
    append_result_fn: Callable[[Any, Any], None],
) -> Any:
    retrying = Retrying(
        wait=wait_random_exponential(multiplier=1, max=60),
        stop=stop_after_delay(retry_stop_after_delay_seconds),
        retry=retry_if_exception_type(retry_exception_type),
    )

    should_write_whole_table = max_records_per_entry is None or not len(table)
    if should_write_whole_table:
        return retrying(write_one_fn, table)

    results = empty_result_factory()
    table_slices = table_slicer_fn(table, max_records_per_entry)
    for table_slice in table_slices:
        slice_result = retrying(write_one_fn, table_slice)
        append_result_fn(results, slice_result)
    return results


def write_table_capture(
    table: Any,
    *,
    base_path: str,
    filesystem: Any,
    table_writer_fn: Callable,
    table_writer_kwargs: Optional[Dict[str, Any]],
    content_type: str,
    validate_table_fn: Callable[[Any], None],
    column_stats_getter: Callable[[Any], Optional[Dict]],
    skip_manifest_write: bool = False,
    use_ray_capture: bool = False,
) -> CapturedWriteResult:
    table_writer_kwargs = dict(table_writer_kwargs or {})

    content_encoding = None
    if content_type in EXPLICIT_COMPRESSION_CONTENT_TYPES and not skip_manifest_write:
        content_encoding = "gzip"

    capture_object = create_capture_object(use_ray=use_ray_capture)
    if skip_manifest_write:
        block_write_path_provider = UuidBlockWritePathProvider(
            capture_object,
            base_path=base_path,
            column_stats_getter=column_stats_getter,
        )
    else:
        block_write_path_provider = UuidBlockWritePathProvider(
            capture_object,
            base_path=base_path,
            content_type=content_type,
            content_encoding=content_encoding,
            column_stats_getter=column_stats_getter,
        )

    schema = table_writer_kwargs.pop("schema", None)

    validate_table_fn(table)
    table_writer_fn(
        table,
        base_path,
        filesystem,
        block_write_path_provider,
        content_type,
        schema=schema,
        **table_writer_kwargs,
    )

    del block_write_path_provider
    write_paths = capture_object.write_paths()
    blocks = capture_object.blocks()
    column_stats = capture_object.column_stats()
    block_metadata = get_block_metadata_list(table, write_paths, blocks)

    if skip_manifest_write:
        filesystem_type = FilesystemType.from_filesystem(filesystem)
        write_paths = [
            append_protocol_prefix_by_type(path, filesystem_type)
            for path in write_paths
        ]

    return CapturedWriteResult(
        write_paths=write_paths,
        blocks=blocks,
        column_stats=column_stats,
        block_metadata=block_metadata,
        content_encoding=content_encoding,
    )
