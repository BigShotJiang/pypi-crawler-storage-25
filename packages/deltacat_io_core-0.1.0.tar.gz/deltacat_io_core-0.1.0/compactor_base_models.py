"""Shared base compactor model layer."""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple, Union


class PyArrowWriteResult(dict):
    @classmethod
    def of(
        cls,
        file_count: int,
        pyarrow_bytes: int,
        file_bytes: int,
        record_count: int,
    ):
        pawr = cls()
        pawr["files"] = file_count
        pawr["paBytes"] = pyarrow_bytes
        pawr["fileBytes"] = file_bytes
        pawr["records"] = record_count
        return pawr

    @classmethod
    def union(cls, results: List["PyArrowWriteResult"]):
        return cls.of(
            sum([result.files for result in results]),
            sum([result.pyarrow_bytes for result in results]),
            sum([result.file_bytes for result in results]),
            sum([result.records for result in results]),
        )

    @property
    def files(self) -> int:
        return self["files"]

    @property
    def pyarrow_bytes(self) -> int:
        return self["paBytes"]

    @property
    def file_bytes(self) -> int:
        return self["fileBytes"]

    @property
    def records(self) -> int:
        return self["records"]


class HighWatermark(dict):
    """Map a partition-locator-like object's canonical string to a watermark."""

    def set(self, partition_locator: Any, delta_stream_position: int):
        self[partition_locator.canonical_string()] = (
            partition_locator,
            delta_stream_position,
        )

    def get(self, partition_locator: Any) -> int:
        if partition_locator.canonical_string() in self:
            return self[partition_locator.canonical_string()][1]
        return 0


class RoundCompletionInfo(dict):
    @classmethod
    def of(
        cls,
        high_watermark: Union[HighWatermark, int],
        compacted_delta_locator: Any,
        compacted_pyarrow_write_result: PyArrowWriteResult,
        sort_keys_bit_width: int,
        rebase_source_partition_locator: Optional[Any] = None,
        manifest_entry_copied_by_reference_ratio: Optional[float] = None,
        compaction_audit_url: Optional[str] = None,
        hash_bucket_count: Optional[int] = None,
        hb_index_to_entry_range: Optional[Dict[int, Tuple[int, int]]] = None,
        compactor_version: Optional[str] = None,
        input_inflation: Optional[float] = None,
        input_average_record_size_bytes: Optional[float] = None,
        prev_source_partition_locator: Optional[Any] = None,
    ):
        rci = cls()
        rci["highWatermark"] = high_watermark
        rci["compactedDeltaLocator"] = compacted_delta_locator
        rci["compactedPyarrowWriteResult"] = compacted_pyarrow_write_result
        rci["sortKeysBitWidth"] = sort_keys_bit_width
        rci["rebaseSourcePartitionLocator"] = rebase_source_partition_locator
        rci[
            "manifestEntryCopiedByReferenceRatio"
        ] = manifest_entry_copied_by_reference_ratio
        rci["compactionAuditUrl"] = compaction_audit_url
        rci["hashBucketCount"] = hash_bucket_count
        rci["hbIndexToEntryRange"] = hb_index_to_entry_range
        rci["compactorVersion"] = compactor_version
        rci["inputInflation"] = input_inflation
        rci["inputAverageRecordSizeBytes"] = input_average_record_size_bytes
        rci["prevSourcePartitionLocator"] = prev_source_partition_locator
        return rci

    @property
    def high_watermark(self) -> Union[HighWatermark, int]:
        val: Dict[str, Any] = self.get("highWatermark")
        if (
            val is not None
            and isinstance(val, dict)
            and not isinstance(val, HighWatermark)
        ):
            self["highWatermark"] = val = HighWatermark(val)
        return val

    @property
    def compacted_delta_locator(self):
        return self.get("compactedDeltaLocator")

    @property
    def compacted_pyarrow_write_result(self) -> PyArrowWriteResult:
        val: Dict[str, Any] = self.get("compactedPyarrowWriteResult")
        if val is not None and not isinstance(val, PyArrowWriteResult):
            self["compactedPyarrowWriteResult"] = val = PyArrowWriteResult(val)
        return val

    @property
    def sort_keys_bit_width(self) -> int:
        return self["sortKeysBitWidth"]

    @property
    def compaction_audit_url(self) -> Optional[str]:
        return self.get("compactionAuditUrl")

    @property
    def rebase_source_partition_locator(self):
        return self.get("rebaseSourcePartitionLocator")

    @property
    def manifest_entry_copied_by_reference_ratio(self) -> Optional[float]:
        return self["manifestEntryCopiedByReferenceRatio"]

    @property
    def hash_bucket_count(self) -> Optional[int]:
        return self["hashBucketCount"]

    @property
    def hb_index_to_entry_range(self) -> Optional[Dict[str, Tuple[int, int]]]:
        return self["hbIndexToEntryRange"]

    @property
    def compactor_version(self) -> Optional[str]:
        return self.get("compactorVersion")

    @property
    def input_inflation(self) -> Optional[float]:
        return self.get("inputInflation")

    @property
    def input_average_record_size_bytes(self) -> Optional[float]:
        return self.get("inputAverageRecordSizeBytes")

    @property
    def prev_source_partition_locator(self):
        return self.get("prevSourcePartitionLocator")


class MaterializeResult(dict):
    @classmethod
    def of(
        cls,
        delta: Any,
        task_index: int,
        pyarrow_write_result: PyArrowWriteResult,
        referenced_pyarrow_write_result: Optional[PyArrowWriteResult] = None,
        peak_memory_usage_bytes: Optional[Any] = None,
        telemetry_time_in_seconds: Optional[Any] = None,
        task_completed_at: Optional[Any] = None,
    ):
        materialize_result = cls()
        materialize_result["delta"] = delta
        materialize_result["taskIndex"] = task_index
        materialize_result["paWriteResult"] = pyarrow_write_result
        materialize_result["referencedPaWriteResult"] = referenced_pyarrow_write_result
        materialize_result["peakMemoryUsageBytes"] = peak_memory_usage_bytes
        materialize_result["telemetryTimeInSeconds"] = telemetry_time_in_seconds
        materialize_result["taskCompletedAt"] = task_completed_at
        return materialize_result

    @property
    def delta(self):
        return self.get("delta")

    @property
    def task_index(self) -> int:
        return self["taskIndex"]

    @property
    def peak_memory_usage_bytes(self):
        return self["peakMemoryUsageBytes"]

    @property
    def telemetry_time_in_seconds(self):
        return self["telemetryTimeInSeconds"]

    @property
    def pyarrow_write_result(self) -> PyArrowWriteResult:
        val: Dict[str, Any] = self.get("paWriteResult")
        if val is not None and not isinstance(val, PyArrowWriteResult):
            self["paWriteResult"] = val = PyArrowWriteResult(val)
        return val

    @property
    def referenced_pyarrow_write_result(self) -> PyArrowWriteResult:
        val: Dict[str, Any] = self.get("referencedPaWriteResult")
        if val is not None and not isinstance(val, PyArrowWriteResult):
            self["referencedPaWriteResult"] = val = PyArrowWriteResult(val)
        return val

    @property
    def task_completed_at(self):
        return self["taskCompletedAt"]
