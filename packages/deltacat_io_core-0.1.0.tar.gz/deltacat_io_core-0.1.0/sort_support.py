"""Shared sort-aware ordering helpers for DeltaCAT read and write paths."""

from __future__ import annotations

from typing import Any, Callable, Iterable, List, Optional, Tuple

from deltacat_io_core.filtering import may_match_column_stats


def primary_sort_column(sort_scheme: Any) -> str | None:
    if not sort_scheme:
        return None
    keys = (
        sort_scheme.get("keys")
        if isinstance(sort_scheme, dict)
        else getattr(sort_scheme, "keys", None)
    ) or []
    if not keys:
        return None
    first_key = keys[0]
    key_columns = (
        first_key.get("key")
        if isinstance(first_key, dict)
        else getattr(first_key, "key", None)
    ) or []
    return key_columns[0] if key_columns else None


def order_items_by_primary_sort_key(
    items: Iterable[Any],
    sort_scheme: Any,
    *,
    get_sort_scheme_id: Callable[[Any], Any],
    get_column_stats: Callable[[Any], Any],
    require_matching_scheme_id: bool,
) -> Tuple[list[Any], bool]:
    items = list(items)
    if not sort_scheme or len(items) <= 1:
        return items, False

    sort_column = primary_sort_column(sort_scheme)
    if not sort_column:
        return items, False

    scheme_id = (
        sort_scheme.get("id")
        if isinstance(sort_scheme, dict)
        else getattr(sort_scheme, "id", None)
    )

    sort_metas = []
    for item in items:
        if require_matching_scheme_id and scheme_id is not None:
            item_scheme_id = get_sort_scheme_id(item)
            if item_scheme_id is None or item_scheme_id != scheme_id:
                return items, False

        column_stats = get_column_stats(item) or {}
        if sort_column not in column_stats:
            return items, False
        col_stat = column_stats[sort_column]
        if "min" not in col_stat or "max" not in col_stat:
            return items, False
        sort_metas.append((col_stat["min"], col_stat["max"], item))

    try:
        sort_metas.sort(key=lambda item: item[0])
    except TypeError:
        return items, False

    for idx in range(1, len(sort_metas)):
        prev_max = sort_metas[idx - 1][1]
        curr_min = sort_metas[idx][0]
        try:
            if curr_min < prev_max:
                return items, False
        except TypeError:
            return items, False

    return [item for _, _, item in sort_metas], True


def extract_data_files_with_sort_metadata(
    deltas: Iterable[Any],
    *,
    row_filter: Any = None,
    supported_delta_types: Optional[Iterable[Any]] = None,
    logger: Any = None,
) -> List[dict[str, Any]]:
    files: List[dict[str, Any]] = []
    supported = set(supported_delta_types or [])

    def _delta_type_matches(delta_type: Any) -> bool:
        if not supported:
            return True
        if delta_type in supported:
            return True
        raw_value = getattr(delta_type, "value", None)
        if raw_value in supported:
            return True
        return False

    for delta in deltas:
        delta_type = getattr(delta, "type", None)
        if not _delta_type_matches(delta_type):
            if logger is not None:
                logger.warning(
                    "Skipping delta with unexpected type '%s' at %s. "
                    "Only supported delta types are included.",
                    delta_type,
                    getattr(delta, "locator", None),
                )
            continue
        manifest = getattr(delta, "manifest", None)
        entries = getattr(manifest, "entries", None) if manifest is not None else None
        if not entries:
            continue
        manifest_meta = getattr(manifest, "meta", None)
        manifest_sort_scheme_id = (
            getattr(manifest_meta, "sort_scheme_id", None)
            if manifest_meta is not None
            else None
        )
        for entry in entries:
            url = getattr(entry, "url", None) or getattr(entry, "uri", None)
            if not url:
                continue
            meta = getattr(entry, "meta", None)
            column_stats = (
                getattr(meta, "column_stats", None) if meta is not None else None
            )
            if (
                row_filter is not None
                and column_stats
                and not may_match_column_stats(row_filter, column_stats)
            ):
                continue
            files.append(
                {
                    "path": url,
                    "record_count": (
                        getattr(meta, "record_count", 0) if meta is not None else 0
                    ),
                    "content_length": (
                        getattr(meta, "content_length", 0) if meta is not None else 0
                    ),
                    "content_type": (
                        getattr(meta, "content_type", None)
                        if meta is not None
                        else None
                    ),
                    "content_encoding": (
                        getattr(meta, "content_encoding", None)
                        if meta is not None
                        else None
                    ),
                    "sort_scheme_id": (
                        getattr(meta, "sort_scheme_id", None)
                        if meta is not None and hasattr(meta, "sort_scheme_id")
                        else manifest_sort_scheme_id
                    ),
                    "column_stats": column_stats,
                }
            )
    return files
