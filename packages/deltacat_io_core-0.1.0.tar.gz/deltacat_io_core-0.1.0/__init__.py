"""Shared local IO execution helpers for DeltaCAT thin and thick read/write paths."""

from __future__ import annotations

import logging

__version__ = "0.1.0"

logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "__version__",
    "build_entries_for_local_paths",
    "coerce_write_input",
    "execute_read_plan",
    "materialize_arrow_write",
]


def __getattr__(name: str):
    if name in {
        "build_entries_for_local_paths",
        "coerce_write_input",
        "execute_read_plan",
        "materialize_arrow_write",
    }:
        from deltacat_io_core.execution import (
            build_entries_for_local_paths,
            coerce_write_input,
            execute_read_plan,
            materialize_arrow_write,
        )

        return {
            "build_entries_for_local_paths": build_entries_for_local_paths,
            "coerce_write_input": coerce_write_input,
            "execute_read_plan": execute_read_plan,
            "materialize_arrow_write": materialize_arrow_write,
        }[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
