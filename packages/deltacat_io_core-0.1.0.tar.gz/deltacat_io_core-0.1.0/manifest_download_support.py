"""Shared manifest-entry download orchestration moved out of thick tables.py."""

from __future__ import annotations

from functools import partial
from typing import Any, Callable, Optional


def download_manifest_entries_local(
    manifest: Any,
    *,
    table_type: Any,
    column_names: Optional[list[str]],
    include_columns: Optional[list[str]],
    file_reader_kwargs_provider: Optional[Any],
    file_path_column: Optional[str],
    prepare_download_arguments_fn: Callable[..., Any],
    filter_catalog_kwargs_fn: Callable[[dict], dict],
    build_data_root_registry_fn: Callable[[dict], tuple[Any, Any]],
    reconstruct_manifest_entry_url_fn: Callable[..., Any],
    resolve_entry_download_args_fn: Callable[[Any, Any, Any, Any], Any],
    download_manifest_entry_fn: Callable[..., Any],
    **kwargs,
):
    """Download all manifest entries into a local dataset.

    This is the shared orchestration layer around the native manifest-entry
    reader. It preserves the existing thick behavior of:
    - deriving one shared download-argument bundle
    - reconstructing entry URLs relative to the catalog/data-root config
    - resolving per-entry filesystems for multi-root catalogs
    - reading entries in manifest order
    """
    download_args = prepare_download_arguments_fn(
        table_type,
        column_names,
        include_columns,
        file_reader_kwargs_provider,
        file_path_column,
        **kwargs,
    )

    catalog_kwargs = filter_catalog_kwargs_fn(kwargs)
    registry, data_root_config = build_data_root_registry_fn(catalog_kwargs)

    result = []
    for entry in manifest.entries:
        manifest_entry = reconstruct_manifest_entry_url_fn(entry, **catalog_kwargs)
        entry_args = resolve_entry_download_args_fn(
            download_args,
            entry,
            registry,
            data_root_config,
        )
        result.append(
            download_manifest_entry_fn(manifest_entry=manifest_entry, **entry_args)
        )

    return result


def download_manifest_entries_parallel(
    manifest: Any,
    *,
    max_parallelism: Optional[int],
    table_type: Any,
    column_names: Optional[list[str]],
    include_columns: Optional[list[str]],
    file_reader_kwargs_provider: Optional[Any],
    file_path_column: Optional[str],
    prepare_download_arguments_fn: Callable[..., Any],
    filter_catalog_kwargs_fn: Callable[[dict], dict],
    build_data_root_registry_fn: Callable[[dict], tuple[Any, Any]],
    reconstruct_manifest_entry_url_fn: Callable[..., Any],
    resolve_entry_download_args_fn: Callable[[Any, Any, Any, Any], Any],
    download_manifest_entry_fn: Callable[..., Any],
    download_manifest_entry_with_args_fn: Callable[[Any], Any],
    pool_factory: Callable[[Optional[int]], Any],
    **kwargs,
):
    """Download all manifest entries into a local dataset using multiprocessing."""
    download_args = prepare_download_arguments_fn(
        table_type,
        column_names,
        include_columns,
        file_reader_kwargs_provider,
        file_path_column,
        **kwargs,
    )

    catalog_kwargs = filter_catalog_kwargs_fn(kwargs)
    registry, data_root_config = build_data_root_registry_fn(catalog_kwargs)

    entries_to_process = []
    entry_args_list = []
    for entry in manifest.entries:
        manifest_entry = reconstruct_manifest_entry_url_fn(entry, **catalog_kwargs)
        entries_to_process.append(manifest_entry)
        entry_args_list.append(
            resolve_entry_download_args_fn(
                download_args,
                entry,
                registry,
                data_root_config,
            )
        )

    if registry is not None:
        download_tuples = list(zip(entries_to_process, entry_args_list))
        with pool_factory(max_parallelism) as pool:
            return pool.map(download_manifest_entry_with_args_fn, download_tuples)

    downloader = partial(download_manifest_entry_fn, **download_args)
    with pool_factory(max_parallelism) as pool:
        return pool.map(downloader, entries_to_process)
