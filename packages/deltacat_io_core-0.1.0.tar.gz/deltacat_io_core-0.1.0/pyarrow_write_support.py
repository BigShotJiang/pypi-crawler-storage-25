"""Filesystem-aware PyArrow table writers cloned from thick DeltaCAT."""

from __future__ import annotations

import posixpath
from typing import Any, Callable, Dict

from pyarrow import csv as pacsv

from deltacat_io_core.deps import (
    require_polars,
    require_pyarrow,
    require_pyarrow_feather,
    require_pyarrow_orc,
    require_pyarrow_parquet,
)
from deltacat_io_core.delimited_options import content_type_to_writer_kwargs
from deltacat_io_core.filesystem_support import (
    ensure_parent_dir,
)

PARQUET_TYPES = {"parquet", "application/parquet"}
CSV_TYPES = {"csv", "text/csv"}
TSV_TYPES = {"tsv", "text/tsv"}
PSV_TYPES = {"psv", "text/psv"}
UNESCAPED_TSV_TYPES = {"application/x-amzn-unescaped-tsv"}
FEATHER_TYPES = {"feather", "application/feather"}
JSON_TYPES = {"json", "application/json"}
ORC_TYPES = {"orc", "application/orc"}
AVRO_TYPES = {"avro", "application/avro"}


def write_feather(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    paf = require_pyarrow_feather("pyarrow write support")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            paf.write_feather(table, f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            paf.write_feather(table, f, **write_kwargs)


def write_csv(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    pa = require_pyarrow("pyarrow write support")
    if write_kwargs.get("write_options") is None:
        write_kwargs["write_options"] = pacsv.WriteOptions(include_header=False)

    should_compress = path.endswith(".gz")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            if should_compress:
                with pa.CompressedOutputStream(f, "gzip") as out:
                    pacsv.write_csv(table, out, **write_kwargs)
            else:
                pacsv.write_csv(table, f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            if should_compress:
                with pa.CompressedOutputStream(f, "gzip") as out:
                    pacsv.write_csv(table, out, **write_kwargs)
            else:
                pacsv.write_csv(table, f, **write_kwargs)


def write_orc(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    paorc = require_pyarrow_orc("pyarrow write support")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            paorc.write_table(table, f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            paorc.write_table(table, f, **write_kwargs)


def write_parquet(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    pq = require_pyarrow_parquet("pyarrow write support")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            pq.write_table(table, f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            pq.write_table(table, f, **write_kwargs)


def write_json(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    pa = require_pyarrow("pyarrow json write support")
    pl = require_polars("pyarrow json write support")
    should_compress = path.endswith(".gz")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            if should_compress:
                with pa.CompressedOutputStream(f, "gzip") as out:
                    pl.from_arrow(table).write_ndjson(out, **write_kwargs)
            else:
                pl.from_arrow(table).write_ndjson(f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            if should_compress:
                with pa.CompressedOutputStream(f, "gzip") as out:
                    pl.from_arrow(table).write_ndjson(out, **write_kwargs)
            else:
                pl.from_arrow(table).write_ndjson(f, **write_kwargs)


def write_avro(
    table,
    path: str,
    *,
    filesystem=None,
    fs_open_kwargs: Dict[str, Any] = {},
    **write_kwargs,
) -> None:
    pl = require_polars("pyarrow avro write support")
    pafs = __import__("pyarrow.fs", fromlist=["FileSystem"])
    if not filesystem or isinstance(filesystem, pafs.FileSystem):
        path, filesystem = ensure_parent_dir(path, filesystem)
        with filesystem.open_output_stream(path, **fs_open_kwargs) as f:
            pl.from_arrow(table).write_avro(f, **write_kwargs)
    else:
        with filesystem.open(path, "wb", **fs_open_kwargs) as f:
            pl.from_arrow(table).write_avro(f, **write_kwargs)


CONTENT_TYPE_TO_PA_WRITE_FUNC: Dict[str, Callable] = {
    **{
        content_type: write_csv
        for content_type in UNESCAPED_TSV_TYPES | TSV_TYPES | CSV_TYPES | PSV_TYPES
    },
    **{content_type: write_parquet for content_type in PARQUET_TYPES},
    **{content_type: write_feather for content_type in FEATHER_TYPES},
    **{content_type: write_json for content_type in JSON_TYPES},
    **{content_type: write_avro for content_type in AVRO_TYPES},
    **{content_type: write_orc for content_type in ORC_TYPES},
}


def table_to_file(
    table,
    base_path: str,
    filesystem,
    block_path_provider,
    content_type: str = "application/parquet",
    schema=None,
    **kwargs,
) -> str:
    del schema
    writer = CONTENT_TYPE_TO_PA_WRITE_FUNC.get(content_type)
    if not writer:
        raise NotImplementedError(
            f"PyArrow writer for content type '{content_type}' not implemented. "
            f"Known content types: {sorted(CONTENT_TYPE_TO_PA_WRITE_FUNC)}"
        )
    filename = block_path_provider(base_path)
    path = posixpath.join(base_path, filename)
    writer_kwargs = content_type_to_writer_kwargs(content_type)
    writer_kwargs.update(kwargs)
    writer(table, path, filesystem=filesystem, **writer_kwargs)
    return path
