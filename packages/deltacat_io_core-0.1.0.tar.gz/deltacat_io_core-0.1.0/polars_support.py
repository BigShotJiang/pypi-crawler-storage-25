"""Shared Polars lazy-scan helpers for DeltaCAT read paths."""

from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

import deltacat_io_core.logs as logs
from deltacat_io_core.deps import require_polars, require_pyarrow
from deltacat_io_core.filtering import translate_expression_to_polars
from deltacat_io_core.sort_support import (
    order_items_by_primary_sort_key,
    primary_sort_column,
)

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def is_parquet_path(path: str) -> bool:
    lower = path.lower()
    return (
        lower.endswith(".parquet")
        or lower.endswith(".pq")
        or lower.endswith(".parquet.gz")
        or "." not in path.rsplit("/", 1)[-1]
    )


def _item_attr(item: Any, key: str):
    return item.get(key) if isinstance(item, dict) else getattr(item, key)


def build_polars_lazy_scan(
    file_records: List[Dict[str, Any]],
    *,
    sort_scheme: Any,
    row_filter: Optional[Any],
    columns: Optional[List[str]],
    file_path_column: Optional[str],
    polars_schema: Optional[Dict[str, Any]] = None,
    storage_options_resolver: Optional[
        Callable[[str], Optional[Dict[str, Any]]]
    ] = None,
):
    pl = require_polars("Polars lazy scan")
    pa = require_pyarrow("Polars lazy scan")

    if not file_records:
        if polars_schema:
            empty_df = pl.from_arrow(
                pa.table(
                    {
                        name: pa.array([], type=field_type)
                        for name, field_type in polars_schema.items()
                    }
                )
            )
            if file_path_column and file_path_column not in empty_df.columns:
                empty_df = empty_df.with_columns(
                    pl.Series(name=file_path_column, values=[], dtype=pl.String)
                )
            if columns:
                keep = list(columns)
                if file_path_column and file_path_column not in keep:
                    keep.append(file_path_column)
                empty_df = empty_df.select(keep)
            return empty_df.lazy()
        return pl.LazyFrame()

    if any(not is_parquet_path(str(_item_attr(rec, "path"))) for rec in file_records):
        return None

    ordered_records, is_sorted = order_items_by_primary_sort_key(
        file_records,
        sort_scheme,
        get_sort_scheme_id=lambda rec: _item_attr(rec, "sort_scheme_id"),
        get_column_stats=lambda rec: _item_attr(rec, "column_stats"),
        require_matching_scheme_id=True,
    )
    file_paths = [str(_item_attr(rec, "path")) for rec in ordered_records]

    storage_options = None
    if storage_options_resolver is not None and any(
        path.startswith("s3://") for path in file_paths
    ):
        per_path_options = [storage_options_resolver(path) for path in file_paths]
        if any(
            path.startswith("s3://") and opts is None
            for path, opts in zip(file_paths, per_path_options)
        ):
            return None
        first_options = per_path_options[0]
        if any(opts != first_options for opts in per_path_options[1:]):
            return None
        storage_options = first_options

    scan_opts: Dict[str, Any] = {
        "low_memory": True,
        "hive_partitioning": False,
        "allow_missing_columns": True,
    }
    if file_path_column:
        scan_opts["include_file_paths"] = file_path_column
    if storage_options is not None:
        scan_opts["storage_options"] = storage_options
    if polars_schema:
        scan_opts["schema"] = {
            field_name: pl.from_arrow(
                pa.table({field_name: pa.array([], type=field_type)})
            ).dtypes[0]
            for field_name, field_type in polars_schema.items()
        }

    lf = pl.scan_parquet(file_paths, **scan_opts)

    if row_filter is not None:
        polars_expr = translate_expression_to_polars(row_filter)
        if polars_expr is not None:
            lf = lf.filter(polars_expr)

    if columns:
        keep = list(columns)
        if file_path_column and file_path_column not in keep:
            keep.append(file_path_column)
        lf = lf.select(keep)

    if is_sorted:
        sort_column = primary_sort_column(sort_scheme)
        if sort_column:
            keys = (
                sort_scheme.get("keys")
                if isinstance(sort_scheme, dict)
                else getattr(sort_scheme, "keys", None)
            ) or []
            first_key = keys[0] if keys else None
            sort_order = (
                first_key.get("sort_order")
                if isinstance(first_key, dict)
                else getattr(first_key, "sort_order", None)
            )
            try:
                lf = lf.set_sorted(
                    sort_column,
                    descending=str(sort_order).lower().startswith("desc"),
                )
            except Exception:
                logger.debug(
                    "Polars could not mark LazyFrame as sorted on column %s",
                    sort_column,
                    exc_info=True,
                )

    return lf
