"""Shared manifest-entry construction helpers moved from thick tables.py."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from deltacat_io_core.sort_support import order_items_by_primary_sort_key


@dataclass(frozen=True)
class ManifestEntryPayload:
    path: str
    record_count: int
    source_content_length: Optional[int]
    content_type: str
    content_encoding: Optional[str]
    entry_type: Optional[Any]
    entry_params: Optional[Any]
    schema_id: Optional[Any]
    sort_scheme_id: Optional[Any]
    catalog_root: Optional[str]
    column_stats: Optional[Dict[str, Any]]


def build_manifest_entry_payloads(
    *,
    write_paths: List[str],
    block_metadata: List[Any],
    fallback_blocks: List[Any],
    fallback_table: Any,
    precomputed_stats: List[Optional[Dict]],
    content_type: str,
    content_encoding: Optional[str],
    entry_type: Optional[Any],
    entry_params: Optional[Any],
    schema_id: Optional[Any],
    sort_scheme_id: Optional[Any],
    catalog_root: Optional[str],
    sort_column: Optional[str],
    column_stats_getter,
) -> List[ManifestEntryPayload]:
    payloads: List[ManifestEntryPayload] = []
    for block_idx, path in enumerate(write_paths):
        col_stats = None
        if precomputed_stats and block_idx < len(precomputed_stats):
            col_stats = precomputed_stats[block_idx]
        if col_stats is None:
            resolved_blocks = fallback_blocks if fallback_blocks else [fallback_table]
            if block_idx < len(resolved_blocks):
                col_stats = column_stats_getter(resolved_blocks[block_idx])

        payloads.append(
            ManifestEntryPayload(
                path=path,
                record_count=block_metadata[block_idx].num_rows,
                source_content_length=block_metadata[block_idx].size_bytes,
                content_type=content_type,
                content_encoding=content_encoding,
                entry_type=entry_type,
                entry_params=entry_params,
                schema_id=schema_id,
                sort_scheme_id=sort_scheme_id,
                catalog_root=catalog_root,
                column_stats=col_stats,
            )
        )

    if sort_column and len(payloads) > 1:
        ordered_payloads, ok = order_items_by_primary_sort_key(
            payloads,
            {"id": sort_scheme_id, "keys": [{"key": [sort_column]}]},
            get_sort_scheme_id=lambda entry: entry.sort_scheme_id,
            get_column_stats=lambda entry: entry.column_stats,
            require_matching_scheme_id=True,
        )
        if ok:
            payloads = ordered_payloads

    return payloads
