"""Shared structured filter parsing and evaluation helpers."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

import deltacat_io_core.logs as logs

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


@dataclass(frozen=True)
class Reference:
    field: str


@dataclass(frozen=True)
class Literal:
    value: Any


@dataclass(frozen=True)
class And:
    left: Any
    right: Any


@dataclass(frozen=True)
class Or:
    left: Any
    right: Any


@dataclass(frozen=True)
class Not:
    operand: Any


@dataclass(frozen=True)
class IsNull:
    operand: Any


@dataclass(frozen=True)
class Equal:
    left: Any
    right: Any


@dataclass(frozen=True)
class NotEqual:
    left: Any
    right: Any


@dataclass(frozen=True)
class GreaterThan:
    left: Any
    right: Any


@dataclass(frozen=True)
class GreaterThanEqual:
    left: Any
    right: Any


@dataclass(frozen=True)
class LessThan:
    left: Any
    right: Any


@dataclass(frozen=True)
class LessThanEqual:
    left: Any
    right: Any


@dataclass(frozen=True)
class In:
    value: Any
    values: list[Any]


@dataclass(frozen=True)
class Between:
    value: Any
    lower: Any
    upper: Any


def parse_structured_filter(
    predicate: Optional[Dict[str, Any]],
):
    """Parse a JSON AST predicate into a DeltaCAT Expression tree."""
    if predicate is None or predicate == {}:
        return None
    return _parse_node(predicate)


def _parse_node(node: Dict[str, Any]):
    if not isinstance(node, dict) or len(node) != 1:
        raise ValueError(
            f"Filter predicate node must be a single-key object, got: {node}"
        )

    op = next(iter(node))
    args = node[op]

    if op == "and":
        if not isinstance(args, list) or len(args) < 2:
            raise ValueError("'and' requires a list of at least 2 predicates.")
        result = _parse_node(args[0])
        for child in args[1:]:
            result = And(result, _parse_node(child))
        return result

    if op == "or":
        if not isinstance(args, list) or len(args) < 2:
            raise ValueError("'or' requires a list of at least 2 predicates.")
        result = _parse_node(args[0])
        for child in args[1:]:
            result = Or(result, _parse_node(child))
        return result

    if op == "not":
        if not isinstance(args, dict):
            raise ValueError("'not' requires a single predicate object.")
        return Not(_parse_node(args))

    if op == "is_null":
        if not isinstance(args, str) or not args:
            raise ValueError("'is_null' requires a non-empty column name.")
        return IsNull(Reference(args))

    if op in ("eq", "neq", "gt", "gte", "lt", "lte"):
        if not isinstance(args, list) or len(args) != 2:
            raise ValueError(f"'{op}' requires [column_name, value].")
        column, value = args
        if not isinstance(column, str) or not column:
            raise ValueError(f"'{op}' requires a non-empty column name.")
        ref = Reference(column)
        literal = Literal(value)
        mapping = {
            "eq": Equal,
            "neq": NotEqual,
            "gt": GreaterThan,
            "gte": GreaterThanEqual,
            "lt": LessThan,
            "lte": LessThanEqual,
        }
        return mapping[op](ref, literal)

    if op == "in":
        if not isinstance(args, list) or len(args) != 2:
            raise ValueError("'in' requires [column_name, [values]].")
        column, values = args
        if not isinstance(column, str) or not column:
            raise ValueError("'in' requires a non-empty column name.")
        if not isinstance(values, list):
            raise ValueError("'in' values must be a list.")
        return In(Reference(column), [Literal(value) for value in values])

    if op == "between":
        if not isinstance(args, list) or len(args) != 3:
            raise ValueError("'between' requires [column_name, lower, upper].")
        column, lower, upper = args
        if not isinstance(column, str) or not column:
            raise ValueError("'between' requires a non-empty column name.")
        return Between(Reference(column), Literal(lower), Literal(upper))

    raise ValueError(f"Unknown filter predicate operator: '{op}'.")


def _expr_name(expr: Any) -> str:
    return type(expr).__name__


def _is_expr(expr: Any, name: str) -> bool:
    return _expr_name(expr) == name


def _literal_value(expr: Any) -> Any:
    value = getattr(expr, "value", expr)
    if hasattr(value, "as_py"):
        return value.as_py()
    return value


def translate_expression_to_pyarrow_filter(expr: Any):
    import pyarrow.compute as pc

    try:
        if _is_expr(expr, "And"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left & right
            return left or right

        if _is_expr(expr, "Or"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left | right
            return None

        if _is_expr(expr, "Not"):
            inner = translate_expression_to_pyarrow_filter(expr.operand)
            if inner is not None:
                return ~inner
            return None

        if _is_expr(expr, "IsNull"):
            operand = getattr(expr, "operand", None)
            if _is_expr(operand, "Reference"):
                return pc.field(operand.field).is_null()
            return None

        if _is_expr(expr, "Reference"):
            return pc.field(expr.field)

        if _is_expr(expr, "Literal"):
            return pc.scalar(_literal_value(expr))

        if _is_expr(expr, "Equal"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left == right

        if _is_expr(expr, "NotEqual"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left != right

        if _is_expr(expr, "GreaterThan"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left > right

        if _is_expr(expr, "GreaterThanEqual"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left >= right

        if _is_expr(expr, "LessThan"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left < right

        if _is_expr(expr, "LessThanEqual"):
            left = translate_expression_to_pyarrow_filter(expr.left)
            right = translate_expression_to_pyarrow_filter(expr.right)
            if left is not None and right is not None:
                return left <= right

        if _is_expr(expr, "In"):
            value = getattr(expr, "value", None)
            if _is_expr(value, "Reference"):
                field = pc.field(value.field)
                values = []
                for item in getattr(expr, "values", []) or []:
                    if _is_expr(item, "Literal"):
                        values.append(_literal_value(item))
                    else:
                        return None
                return field.isin(values)

        if _is_expr(expr, "Between"):
            value = translate_expression_to_pyarrow_filter(expr.value)
            lower = translate_expression_to_pyarrow_filter(expr.lower)
            upper = translate_expression_to_pyarrow_filter(expr.upper)
            if value is not None and lower is not None and upper is not None:
                return (value >= lower) & (value <= upper)
    except Exception:
        logger.debug(
            "Could not translate expression to PyArrow filter; falling back to non-pushdown path.",
            exc_info=True,
        )
        return None

    return None


def translate_expression_to_polars(expr: Any):
    import polars as pl

    try:
        if _is_expr(expr, "And"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left & right
            return left or right

        if _is_expr(expr, "Or"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left | right
            return None

        if _is_expr(expr, "Not"):
            inner = translate_expression_to_polars(expr.operand)
            if inner is not None:
                return ~inner
            return None

        if _is_expr(expr, "IsNull"):
            operand = translate_expression_to_polars(getattr(expr, "operand", None))
            if operand is not None:
                return operand.is_null()
            return None

        if _is_expr(expr, "Reference"):
            return pl.col(expr.field)

        if _is_expr(expr, "Literal"):
            return pl.lit(_literal_value(expr))

        if _is_expr(expr, "Equal"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left == right

        if _is_expr(expr, "NotEqual"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left != right

        if _is_expr(expr, "GreaterThan"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left > right

        if _is_expr(expr, "GreaterThanEqual"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left >= right

        if _is_expr(expr, "LessThan"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left < right

        if _is_expr(expr, "LessThanEqual"):
            left = translate_expression_to_polars(expr.left)
            right = translate_expression_to_polars(expr.right)
            if left is not None and right is not None:
                return left <= right

        if _is_expr(expr, "In"):
            value = translate_expression_to_polars(getattr(expr, "value", None))
            values = getattr(expr, "values", []) or []
            translated = []
            for item in values:
                current = translate_expression_to_polars(item)
                if current is None:
                    return None
                translated.append(current)
            if value is not None:
                return value.is_in(translated)

        if _is_expr(expr, "Between"):
            value = translate_expression_to_polars(expr.value)
            lower = translate_expression_to_polars(expr.lower)
            upper = translate_expression_to_polars(expr.upper)
            if value is not None and lower is not None and upper is not None:
                return value.is_between(lower, upper)
    except Exception:
        logger.debug(
            "Could not translate expression to Daft filter; falling back to non-pushdown path.",
            exc_info=True,
        )
        return None

    return None


def translate_expression_to_daft(expr: Any):
    import daft

    try:
        if _is_expr(expr, "And"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left & right
            return left or right

        if _is_expr(expr, "Or"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left | right
            return None

        if _is_expr(expr, "Not"):
            inner = translate_expression_to_daft(expr.operand)
            if inner is not None:
                return ~inner
            return None

        if _is_expr(expr, "IsNull"):
            operand = getattr(expr, "operand", None)
            if _is_expr(operand, "Reference"):
                return daft.col(operand.field).is_null()
            return None

        if _is_expr(expr, "Reference"):
            return daft.col(expr.field)

        if _is_expr(expr, "Literal"):
            return daft.lit(_literal_value(expr))

        if _is_expr(expr, "Equal"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left == right

        if _is_expr(expr, "NotEqual"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left != right

        if _is_expr(expr, "GreaterThan"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left > right

        if _is_expr(expr, "GreaterThanEqual"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left >= right

        if _is_expr(expr, "LessThan"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left < right

        if _is_expr(expr, "LessThanEqual"):
            left = translate_expression_to_daft(expr.left)
            right = translate_expression_to_daft(expr.right)
            if left is not None and right is not None:
                return left <= right
    except Exception:
        return None

    return None


def apply_post_download_filter(result: Any, filter_expr: Any, read_as: Any):
    import pyarrow as pa

    normalized_read_as = getattr(read_as, "value", read_as)
    normalized_read_as = (
        normalized_read_as.lower()
        if isinstance(normalized_read_as, str)
        else normalized_read_as
    )

    try:
        if isinstance(result, pa.Table):
            if result.num_rows == 0:
                return result
            pyarrow_expr = translate_expression_to_pyarrow_filter(filter_expr)
            if pyarrow_expr is not None:
                return result.filter(pyarrow_expr)

        try:
            import pandas as pd
        except ImportError:
            pd = None
        if pd is not None and isinstance(result, pd.DataFrame):
            if result.empty:
                return result
            arrow_table = pa.Table.from_pandas(result, preserve_index=False)
            pyarrow_expr = translate_expression_to_pyarrow_filter(filter_expr)
            if pyarrow_expr is not None:
                return arrow_table.filter(pyarrow_expr).to_pandas()

        if normalized_read_as == "ray_dataset":
            pyarrow_expr = translate_expression_to_pyarrow_filter(filter_expr)
            if pyarrow_expr is not None:

                def _filter_batch(batch: pa.Table) -> pa.Table:
                    return batch.filter(pyarrow_expr)

                return result.map_batches(_filter_batch, batch_format="pyarrow")

        if normalized_read_as == "daft":
            daft_expr = translate_expression_to_daft(filter_expr)
            if daft_expr is not None:
                return result.where(daft_expr)
    except Exception:
        logger.warning(
            "Failed to apply requested post-download filter.",
            exc_info=True,
        )
        raise

    return result


def may_match_column_stats(expr: Any, column_stats: Dict[str, Any]) -> bool:
    try:
        if _is_expr(expr, "And"):
            return may_match_column_stats(
                expr.left, column_stats
            ) and may_match_column_stats(expr.right, column_stats)
        if _is_expr(expr, "Or"):
            return may_match_column_stats(
                expr.left, column_stats
            ) or may_match_column_stats(expr.right, column_stats)
        if _is_expr(expr, "Not"):
            return True
        if _is_expr(expr, "IsNull"):
            operand = getattr(expr, "operand", None)
            if not _is_expr(operand, "Reference"):
                return True
            stats = column_stats.get(operand.field)
            if not stats:
                return True
            return int(stats.get("null_count", 0) or 0) > 0

        if _is_expr(expr, "Equal"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats:
                return True
            value = _literal_value(lit)
            min_val = stats.get("min")
            max_val = stats.get("max")
            if min_val is not None:
                try:
                    if value < min_val:
                        return False
                except TypeError:
                    logger.debug(
                        "Could not compare predicate value against column-stats min for field %s; keeping file.",
                        ref.field,
                        exc_info=True,
                    )
                    pass
            if max_val is not None:
                try:
                    if value > max_val:
                        return False
                except TypeError:
                    logger.debug(
                        "Could not compare predicate value against column-stats max for field %s; keeping file.",
                        ref.field,
                        exc_info=True,
                    )
                    pass
            return True

        if _is_expr(expr, "NotEqual"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats:
                return True
            value = _literal_value(lit)
            min_val = stats.get("min")
            max_val = stats.get("max")
            try:
                if (
                    min_val is not None
                    and max_val is not None
                    and min_val == max_val == value
                ):
                    return False
            except TypeError:
                logger.debug(
                    "Could not compare NotEqual predicate against exact column-stats bounds for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                pass
            return True

        if _is_expr(expr, "GreaterThan"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats or stats.get("max") is None:
                return True
            try:
                return stats["max"] > _literal_value(lit)
            except TypeError:
                logger.debug(
                    "Could not compare GreaterThan predicate against column-stats max for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                return True

        if _is_expr(expr, "GreaterThanEqual"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats or stats.get("max") is None:
                return True
            try:
                return stats["max"] >= _literal_value(lit)
            except TypeError:
                logger.debug(
                    "Could not compare GreaterThanEqual predicate against column-stats max for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                return True

        if _is_expr(expr, "LessThan"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats or stats.get("min") is None:
                return True
            try:
                return stats["min"] < _literal_value(lit)
            except TypeError:
                logger.debug(
                    "Could not compare LessThan predicate against column-stats min for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                return True

        if _is_expr(expr, "LessThanEqual"):
            ref = getattr(expr, "left", None)
            lit = getattr(expr, "right", None)
            if not (_is_expr(ref, "Reference") and _is_expr(lit, "Literal")):
                return True
            stats = column_stats.get(ref.field)
            if not stats or stats.get("min") is None:
                return True
            try:
                return stats["min"] <= _literal_value(lit)
            except TypeError:
                logger.debug(
                    "Could not compare LessThanEqual predicate against column-stats min for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                return True

        if _is_expr(expr, "In"):
            ref = getattr(expr, "value", None)
            values = getattr(expr, "values", None) or []
            if not _is_expr(ref, "Reference"):
                return True
            stats = column_stats.get(ref.field)
            if not stats:
                return True
            min_val = stats.get("min")
            max_val = stats.get("max")
            if min_val is None or max_val is None:
                return True
            candidates = [
                _literal_value(item) for item in values if _is_expr(item, "Literal")
            ]
            if len(candidates) != len(values):
                return True
            for candidate in candidates:
                try:
                    if min_val <= candidate <= max_val:
                        return True
                except TypeError:
                    logger.debug(
                        "Could not compare IN predicate candidate against column-stats bounds for field %s; keeping file.",
                        ref.field,
                        exc_info=True,
                    )
                    return True
            return False

        if _is_expr(expr, "Between"):
            ref = getattr(expr, "value", None)
            lower = getattr(expr, "lower", None)
            upper = getattr(expr, "upper", None)
            if not (
                _is_expr(ref, "Reference")
                and _is_expr(lower, "Literal")
                and _is_expr(upper, "Literal")
            ):
                return True
            stats = column_stats.get(ref.field)
            if not stats:
                return True
            min_val = stats.get("min")
            max_val = stats.get("max")
            if min_val is None or max_val is None:
                return True
            lower_val = _literal_value(lower)
            upper_val = _literal_value(upper)
            try:
                return not (upper_val < min_val or lower_val > max_val)
            except TypeError:
                logger.debug(
                    "Could not compare BETWEEN predicate against column-stats bounds for field %s; keeping file.",
                    ref.field,
                    exc_info=True,
                )
                return True
    except Exception:
        logger.debug(
            "Could not evaluate column stats for conservative pruning; keeping file.",
            exc_info=True,
        )
        return True

    return True
