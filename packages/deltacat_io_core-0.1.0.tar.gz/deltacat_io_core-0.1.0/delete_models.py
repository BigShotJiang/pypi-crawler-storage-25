"""Shared delete strategy/model layer for compactor-v2."""

from __future__ import annotations

from dataclasses import dataclass, fields
import logging
from typing import Any, Callable, List, Optional, Tuple

import numpy as np
import pyarrow as pa
import pyarrow.compute as pc

from deltacat_io_core import logs


logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


class DeleteStrategy:
    """Abstract interface for applying row-level deletes during compaction."""

    @property
    def name(self) -> str:
        raise NotImplementedError

    def apply_deletes(
        self,
        table: Optional[pa.Table],
        delete_file_envelope: Any,
        *args,
        **kwargs,
    ) -> Tuple[pa.Table, int]:
        raise NotImplementedError

    def apply_many_deletes(
        self,
        table: Optional[pa.Table],
        delete_file_envelopes: List[Any],
        *args,
        **kwargs,
    ) -> Tuple[pa.Table, int]:
        raise NotImplementedError


class EqualityDeleteStrategy(DeleteStrategy):
    """Apply equality deletes based on one or more delete columns."""

    _name = "EqualityDeleteStrategy"

    @property
    def name(self) -> str:
        return self._name

    def _drop_rows(
        self,
        table: pa.Table,
        delete_table: pa.Table,
        delete_column_names: List[str],
        equality_predicate_operation: Optional[Callable] = pa.compute.and_,
    ) -> Tuple[pa.Table, int]:
        if len(delete_column_names) < 1:
            return table, 0

        prev_boolean_mask = pa.array(np.ones(len(table), dtype=bool))
        curr_boolean_mask = pa.array(np.zeros(len(table), dtype=bool))
        for delete_column_name in delete_column_names:
            if delete_column_name not in table.column_names:
                logger.warning(
                    "Column name %s not in table column names. "
                    "Skipping dropping rows for this column.",
                    delete_column_name,
                )
                continue
            curr_boolean_mask = pc.is_in(
                table[delete_column_name],
                value_set=delete_table[delete_column_name],
            )
            curr_boolean_mask = equality_predicate_operation(
                prev_boolean_mask,
                curr_boolean_mask,
            )
            prev_boolean_mask = curr_boolean_mask

        number_of_rows_before_dropping = len(table)
        logger.debug(
            "Number of table rows before dropping: %s.",
            number_of_rows_before_dropping,
        )
        table = table.filter(pc.invert(curr_boolean_mask))
        number_of_rows_after_dropping = len(table)
        logger.debug(
            "Number of table rows after dropping: %s.",
            number_of_rows_after_dropping,
        )
        dropped_rows = number_of_rows_before_dropping - number_of_rows_after_dropping
        return table, dropped_rows

    def apply_deletes(
        self,
        table: Optional[pa.Table],
        delete_file_envelope: Any,
        *args,
        **kwargs,
    ) -> Tuple[pa.Table, int]:
        if not table or not delete_file_envelope.table:
            logger.debug(
                "No table passed or no delete file envelope delete table found. "
                "DeleteFileEnvelope: %s",
                delete_file_envelope,
            )
            return table, 0

        delete_columns = delete_file_envelope.delete_columns
        delete_table = delete_file_envelope.table
        return self._drop_rows(table, delete_table, delete_columns)

    def apply_many_deletes(
        self,
        table: Optional[pa.Table],
        delete_file_envelopes: List[Any],
        *args,
        **kwargs,
    ) -> Tuple[pa.Table, int]:
        if not table:
            logger.debug("No table passed.")
            return table, 0

        total_dropped_rows = 0
        for delete_file_envelope in delete_file_envelopes:
            if delete_file_envelope.table_reference is None:
                continue
            table, number_of_rows_dropped = self.apply_deletes(
                table,
                delete_file_envelope,
            )
            total_dropped_rows += number_of_rows_dropped
        return table, total_dropped_rows


@dataclass
class PrepareDeleteResult:
    non_delete_deltas: List[Any]
    delete_file_envelopes: List[Any]
    delete_strategy: DeleteStrategy

    def __iter__(self):
        return (getattr(self, field.name) for field in fields(self))
