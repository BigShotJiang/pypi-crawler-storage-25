"""Small shared performance helpers."""

from __future__ import annotations

import time
from typing import Any, Callable, Tuple, TypeVar

T = TypeVar("T")


def timed_invocation(func: Callable[[Any], T], *args, **kwargs) -> Tuple[T, float]:
    start = time.perf_counter()
    result = func(*args, **kwargs)
    stop = time.perf_counter()
    return result, stop - start
