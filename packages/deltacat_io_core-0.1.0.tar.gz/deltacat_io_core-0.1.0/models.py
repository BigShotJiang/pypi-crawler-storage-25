"""Canonical shared read-plan and manifest materialization models."""

from __future__ import annotations

import posixpath
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, TypeAlias

from typing_extensions import Self, TypedDict

JsonScalar: TypeAlias = str | int | float | bool | None
JsonValue: TypeAlias = JsonScalar | list[object] | dict[str, object]
JsonObject: TypeAlias = dict[str, JsonValue]
IdentifierValue: TypeAlias = str | int


class MergeOrderSummary(TypedDict):
    sort_order: str
    null_order: str


class SchemaFieldSummary(TypedDict, total=False):
    name: str
    type: str
    nullable: bool
    field_id: int
    is_merge_key: bool
    consistency_type: str
    past_default: JsonValue
    future_default: JsonValue
    doc: str
    is_event_time: bool
    merge_order: MergeOrderSummary


SchemaSummary: TypeAlias = list[SchemaFieldSummary]
MergeKeysSummary: TypeAlias = list[str]


class PartitionKeySummary(TypedDict, total=False):
    key: list[str]
    transform: Optional[str]


class SortKeySummary(TypedDict, total=False):
    key: list[str]
    sort_order: Optional[str]


class PartitionSchemeSummary(TypedDict, total=False):
    id: IdentifierValue
    keys: list[PartitionKeySummary]


class SortSchemeSummary(TypedDict, total=False):
    id: IdentifierValue
    keys: list[SortKeySummary]


class ColumnStatSummary(TypedDict, total=False):
    min: JsonValue
    max: JsonValue
    null_count: int


ColumnStatsSummary: TypeAlias = dict[str, ColumnStatSummary]
EntryParamsSummary: TypeAlias = JsonObject
MetadataSummary: TypeAlias = JsonObject


class DataRootInfoSummary(TypedDict, total=False):
    root: str
    storage_type: str
    endpoint_url: Optional[str]
    region: Optional[str]


DataRootsSummary: TypeAlias = dict[str, DataRootInfoSummary]
CredentialEntry: TypeAlias = JsonObject
CredentialsByEndpoint: TypeAlias = dict[str, CredentialEntry]
CredentialsBySession: TypeAlias = dict[str, CredentialEntry]
PartitionValues: TypeAlias = JsonValue
MORPlanSummary: TypeAlias = MetadataSummary
EpisodeIndexSummary: TypeAlias = MetadataSummary
ShardManifestSummary: TypeAlias = MetadataSummary
RecipeSummary: TypeAlias = MetadataSummary
ReplicationStatusSummary: TypeAlias = MetadataSummary


class WriteEntrySummary(TypedDict, total=False):
    path: str
    record_count: int
    content_length: int
    content_encoding: str
    column_stats: ColumnStatsSummary
    source_content_length: int


PendingWriteEntries: TypeAlias = list[WriteEntrySummary]


def _raw_dict(value: object) -> MetadataSummary:
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "to_dict"):
        data = value.to_dict()
        if isinstance(data, dict):
            return dict(data)
    raw = getattr(value, "raw", None)
    if isinstance(raw, dict):
        return dict(raw)
    return {}


@dataclass
class DataFile:
    path: str = ""
    id: Optional[str] = None
    mandatory: Optional[bool] = None
    record_count: int = 0
    content_length: int = 0
    source_content_length: Optional[int] = None
    content_type: str = "parquet"
    content_encoding: str = "identity"
    schema_id: Optional[IdentifierValue] = None
    sort_scheme_id: Optional[IdentifierValue] = None
    column_stats: Optional[ColumnStatsSummary] = None
    raw: MetadataSummary = field(default_factory=dict)

    @property
    def entry_id(self) -> Optional[str]:
        return self.id

    @entry_id.setter
    def entry_id(self, value: Optional[str]) -> None:
        self.id = value

    @classmethod
    def from_any(cls, value: object) -> "DataFile":
        data = _raw_dict(value)
        content_type = data.get(
            "content_type",
            getattr(value, "content_type", "parquet"),
        )
        content_encoding = data.get(
            "content_encoding",
            getattr(value, "content_encoding", "identity"),
        )
        if hasattr(content_type, "value"):
            content_type = getattr(content_type, "value")
        if hasattr(content_encoding, "value"):
            content_encoding = getattr(content_encoding, "value")
        return cls(
            path=data.get("path", getattr(value, "path", "")),
            id=data.get("id", getattr(value, "id", None)),
            mandatory=data.get("mandatory", getattr(value, "mandatory", None)),
            record_count=int(
                data.get("record_count", getattr(value, "record_count", 0)) or 0
            ),
            content_length=int(
                data.get("content_length", getattr(value, "content_length", 0)) or 0
            ),
            source_content_length=data.get(
                "source_content_length",
                getattr(value, "source_content_length", None),
            ),
            content_type=str(content_type or "parquet"),
            content_encoding=str(content_encoding or "identity"),
            schema_id=data.get("schema_id", getattr(value, "schema_id", None)),
            sort_scheme_id=data.get(
                "sort_scheme_id",
                getattr(value, "sort_scheme_id", None),
            ),
            column_stats=data.get(
                "column_stats",
                getattr(value, "column_stats", None),
            ),
            raw=data,
        )

    @classmethod
    def from_dict(cls, data: MetadataSummary) -> "DataFile":
        return cls.from_any(data)

    def to_dict(self) -> MetadataSummary:
        return (
            dict(self.raw)
            if self.raw
            else {
                "path": self.path,
                "id": self.id,
                "mandatory": self.mandatory,
                "record_count": self.record_count,
                "content_length": self.content_length,
                "source_content_length": self.source_content_length,
                "content_type": self.content_type,
                "content_encoding": self.content_encoding,
                "schema_id": self.schema_id,
                "sort_scheme_id": self.sort_scheme_id,
                "column_stats": self.column_stats,
            }
        )

    @property
    def extension(self) -> str:
        return posixpath.splitext(self.path)[1]

    def is_content_type(self, content_type: str) -> bool:
        return self.content_type == content_type

    @property
    def name(self) -> str:
        return posixpath.basename(self.path)

    def has_extension(self, *extensions: str) -> bool:
        normalized = {ext if ext.startswith(".") else f".{ext}" for ext in extensions}
        return self.extension in normalized


@dataclass
class ScanTask:
    partition_values: Optional[PartitionValues] = None
    partition_scheme_id: Optional[IdentifierValue] = None
    partition_id: Optional[str] = None
    stream_id: Optional[str] = None
    delta_type: Optional[str] = None
    stream_position: Optional[int] = None
    previous_stream_position: Optional[int] = None
    entry_params: Optional[EntryParamsSummary] = None
    author_name: Optional[str] = None
    author_version: Optional[str] = None
    files: List[DataFile] = field(default_factory=list)
    raw: MetadataSummary = field(default_factory=dict)

    @classmethod
    def from_any(cls, value: object) -> "ScanTask":
        data = _raw_dict(value)
        if not data and hasattr(value, "files"):
            data = {
                "partition_values": getattr(value, "partition_values", None),
                "partition_scheme_id": getattr(value, "partition_scheme_id", None),
                "partition_id": getattr(value, "partition_id", None),
                "stream_id": getattr(value, "stream_id", None),
                "delta_type": getattr(value, "delta_type", None),
                "stream_position": getattr(value, "stream_position", None),
                "previous_stream_position": getattr(
                    value, "previous_stream_position", None
                ),
                "entry_params": getattr(value, "entry_params", None),
                "author_name": getattr(value, "author_name", None),
                "author_version": getattr(value, "author_version", None),
                "files": getattr(value, "files", []) or [],
            }
        return cls(
            partition_values=data.get("partition_values"),
            partition_scheme_id=data.get("partition_scheme_id"),
            partition_id=data.get("partition_id"),
            stream_id=data.get("stream_id"),
            delta_type=data.get("delta_type"),
            stream_position=data.get("stream_position"),
            previous_stream_position=data.get("previous_stream_position"),
            entry_params=data.get("entry_params"),
            author_name=data.get("author_name"),
            author_version=data.get("author_version"),
            files=[DataFile.from_any(file_info) for file_info in data.get("files", [])],
            raw=data,
        )

    @classmethod
    def from_dict(cls, data: MetadataSummary) -> "ScanTask":
        return cls.from_any(data)

    def to_dict(self) -> MetadataSummary:
        if self.raw:
            return dict(self.raw)
        return {
            "partition_values": self.partition_values,
            "partition_scheme_id": self.partition_scheme_id,
            "partition_id": self.partition_id,
            "stream_id": self.stream_id,
            "delta_type": self.delta_type,
            "stream_position": self.stream_position,
            "previous_stream_position": self.previous_stream_position,
            "entry_params": self.entry_params,
            "author_name": self.author_name,
            "author_version": self.author_version,
            "files": [file_info.to_dict() for file_info in self.files],
        }

    @property
    def file_count(self) -> int:
        return len(self.files)

    @property
    def total_records(self) -> int:
        return sum(file_info.record_count for file_info in self.files)

    @property
    def total_bytes(self) -> int:
        return sum(file_info.content_length for file_info in self.files)

    @property
    def content_types(self) -> List[str]:
        return sorted({str(file_info.content_type) for file_info in self.files})


@dataclass
class PartitionSummary:
    partition_values: Optional[PartitionValues]
    task_count: int = 0
    file_count: int = 0
    total_records: int = 0
    total_bytes: int = 0
    content_types: List[str] = field(default_factory=list)


@dataclass
class ReadPlan:
    table: str = ""
    namespace: str = ""
    table_version: Optional[str] = None
    schema: Optional[SchemaSummary] = None
    merge_keys: Optional[MergeKeysSummary] = None
    partition_scheme: Optional[PartitionSchemeSummary] = None
    sort_scheme: Optional[SortSchemeSummary] = None
    content_type: str = "parquet"
    scan_tasks: List[ScanTask] = field(default_factory=list)
    total_files: int = 0
    returned_files: int = 0
    total_records: int = 0
    total_bytes: int = 0
    requires_mor: bool = False
    mor_plan: Optional[MORPlanSummary] = None
    mor_instructions: Optional[str] = None
    truncated: bool = False
    next_file_offset: Optional[int] = None
    data_roots: Optional[DataRootsSummary] = None
    credentials: Optional[CredentialsByEndpoint] = None
    snapshot_id: Optional[str] = None
    packds_uri: Optional[str] = None
    episode_index: Optional[EpisodeIndexSummary] = None
    shard_manifest: Optional[ShardManifestSummary] = None
    available_recipes: Optional[List[RecipeSummary]] = None
    raw: MetadataSummary = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: MetadataSummary) -> "ReadPlan":
        return cls(
            table=data.get("table", ""),
            namespace=data.get("namespace", ""),
            table_version=data.get("table_version"),
            schema=data.get("schema"),
            merge_keys=data.get("merge_keys"),
            partition_scheme=data.get("partition_scheme"),
            sort_scheme=data.get("sort_scheme"),
            content_type=data.get("content_type", "parquet"),
            scan_tasks=[
                ScanTask.from_dict(scan_task)
                for scan_task in data.get("scan_tasks", [])
            ],
            total_files=data.get("total_files", 0),
            returned_files=data.get("returned_files", 0),
            total_records=data.get("total_records", 0),
            total_bytes=data.get("total_bytes", 0),
            requires_mor=data.get("requires_mor", False),
            mor_plan=data.get("mor_plan"),
            mor_instructions=data.get("mor_instructions"),
            truncated=data.get("truncated", False),
            next_file_offset=data.get("next_file_offset"),
            data_roots=data.get("data_roots"),
            credentials=data.get("credentials"),
            snapshot_id=data.get("snapshot_id"),
            packds_uri=data.get("packds_uri"),
            episode_index=data.get("episode_index"),
            shard_manifest=data.get("shard_manifest"),
            available_recipes=data.get("available_recipes"),
            raw=data,
        )

    def all_files(self) -> List[DataFile]:
        files: List[DataFile] = []
        for task in self.scan_tasks:
            files.extend(task.files)
        return files

    def file_paths(self) -> List[str]:
        return [file_info.path for file_info in self.all_files()]

    def files_by_content_type(self) -> Dict[str, List[DataFile]]:
        grouped: Dict[str, List[DataFile]] = {}
        for file_info in self.all_files():
            grouped.setdefault(str(file_info.content_type), []).append(file_info)
        return grouped

    def files_for_partition(self, partition_values: PartitionValues) -> List[DataFile]:
        files: List[DataFile] = []
        for task in self.scan_tasks:
            if task.partition_values == partition_values:
                files.extend(task.files)
        return files

    def files_with_extension(self, *extensions: str) -> List[DataFile]:
        return [
            file_info
            for file_info in self.all_files()
            if file_info.has_extension(*extensions)
        ]

    def partition_values(self) -> List[PartitionValues]:
        seen: List[PartitionValues] = []
        for task in self.scan_tasks:
            if task.partition_values not in seen:
                seen.append(task.partition_values)
        return seen

    def partition_summaries(self) -> List[PartitionSummary]:
        grouped: Dict[str, PartitionSummary] = {}
        for task in self.scan_tasks:
            key = repr(task.partition_values)
            summary = grouped.get(key)
            if summary is None:
                summary = PartitionSummary(partition_values=task.partition_values)
                grouped[key] = summary
            summary.task_count += 1
            summary.file_count += task.file_count
            summary.total_records += task.total_records
            summary.total_bytes += task.total_bytes
            summary.content_types = sorted(
                set(summary.content_types).union(task.content_types)
            )
        return list(grouped.values())


@dataclass
class Plan(ReadPlan):
    schema_serialized: Optional[str] = None
    schemas_by_id: Optional[dict[str, SchemaSummary]] = None
    schemas_serialized_by_id: Optional[Dict[str, str]] = None
    sort_schemes_by_id: Optional[dict[str, SortSchemeSummary]] = None
    partition_schemes_by_id: Optional[dict[str, PartitionSchemeSummary]] = None
    preferred_root_used: Optional[bool] = None
    replication_status: Optional[ReplicationStatusSummary] = None
    expires_at: Optional[int] = None
    transaction_id: Optional[str] = None
    transaction_version_seen: Optional[int] = None

    @classmethod
    def from_response(cls, data: MetadataSummary) -> "Plan":
        base = ReadPlan.from_response(data)
        return cls(
            **base.__dict__,
            schema_serialized=data.get("schema_serialized"),
            schemas_by_id=data.get("schemas_by_id"),
            schemas_serialized_by_id=data.get("schemas_serialized_by_id"),
            sort_schemes_by_id=data.get("sort_schemes_by_id"),
            partition_schemes_by_id=data.get("partition_schemes_by_id"),
            preferred_root_used=data.get("preferred_root_used"),
            replication_status=data.get("replication_status"),
            expires_at=data.get("expires_at"),
            transaction_id=data.get("transaction_id"),
            transaction_version_seen=data.get("transaction_version_seen"),
        )


@dataclass
class WriteEntry:
    path: str
    records: int
    bytes: Optional[int] = None
    content_encoding: Optional[str] = None
    column_stats: Optional[ColumnStatsSummary] = None
    source_bytes: Optional[int] = None
    raw: MetadataSummary = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: MetadataSummary) -> Self:
        return cls(
            path=str(data.get("path", "")),
            records=int(data.get("record_count", data.get("records", 0)) or 0),
            bytes=(
                int(data.get("content_length", data.get("bytes")) or 0)
                if data.get("content_length", data.get("bytes")) is not None
                else None
            ),
            content_encoding=(
                str(data["content_encoding"])
                if data.get("content_encoding") is not None
                else None
            ),
            column_stats=data.get("column_stats"),
            source_bytes=(
                int(data.get("source_content_length", data.get("source_bytes")) or 0)
                if data.get("source_content_length", data.get("source_bytes"))
                is not None
                else None
            ),
            raw=data,
        )

    def to_dict(self) -> WriteEntrySummary:
        data: WriteEntrySummary = {
            "path": self.path,
            "record_count": self.records,
        }
        if self.bytes is not None:
            data["content_length"] = self.bytes
        if self.content_encoding is not None:
            data["content_encoding"] = self.content_encoding
        if self.column_stats is not None:
            data["column_stats"] = self.column_stats
        if self.source_bytes is not None:
            data["source_content_length"] = self.source_bytes
        if self.raw:
            data.update(self.raw)
        return data


@dataclass
class WriteSessionInfo:
    session_id: str
    session_version: int
    status: str
    namespace: str
    table: str
    table_version: Optional[str] = None
    mode: str = "auto"
    format: str = "parquet"
    root: Optional[str] = None
    catalog: Optional[str] = None
    transaction_id: Optional[str] = None
    transaction_version: Optional[int] = None
    data_dir: str = ""
    table_exists: bool = False
    schema: Optional[SchemaSummary] = None
    schema_serialized: Optional[str] = None
    merge_keys: Optional[MergeKeysSummary] = None
    partition_scheme: Optional[PartitionSchemeSummary] = None
    sort_scheme: Optional[SortSchemeSummary] = None
    schema_evolution_mode: Optional[str] = None
    schema_consistency_type: Optional[str] = None
    target_records_per_file: Optional[int] = None
    available_roots: Optional[DataRootsSummary] = None
    credentials: Optional[CredentialsByEndpoint] = None
    created_at: int = 0
    expires_at: int = 0
    last_heartbeat_at: int = 0
    files_registered: Optional[int] = None
    total_records: Optional[int] = None
    total_bytes: Optional[int] = None
    attached: Optional[bool] = None
    committed: Optional[bool] = None
    deltas_written: Optional[int] = None
    raw: MetadataSummary = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: MetadataSummary) -> Self:
        return cls(
            session_id=str(data.get("session_id", "")),
            session_version=int(data.get("session_version", 0) or 0),
            status=str(data.get("status", "")),
            namespace=str(data.get("namespace", "")),
            table=str(data.get("table", "")),
            table_version=(
                str(data["table_version"])
                if data.get("table_version") is not None
                else None
            ),
            mode=str(data.get("mode", "auto")),
            format=str(data.get("format", "parquet")),
            root=str(data["root"]) if data.get("root") is not None else None,
            catalog=(str(data["catalog"]) if data.get("catalog") is not None else None),
            transaction_id=(
                str(data["transaction_id"])
                if data.get("transaction_id") is not None
                else None
            ),
            transaction_version=(
                int(data["transaction_version"])
                if data.get("transaction_version") is not None
                else None
            ),
            data_dir=str(data.get("data_dir", "")),
            table_exists=bool(data.get("table_exists", False)),
            schema=data.get("schema"),
            schema_serialized=(
                str(data["schema_serialized"])
                if data.get("schema_serialized") is not None
                else None
            ),
            merge_keys=data.get("merge_keys"),
            partition_scheme=data.get("partition_scheme"),
            sort_scheme=data.get("sort_scheme"),
            schema_evolution_mode=(
                str(data["schema_evolution_mode"])
                if data.get("schema_evolution_mode") is not None
                else None
            ),
            schema_consistency_type=(
                str(data["schema_consistency_type"])
                if data.get("schema_consistency_type") is not None
                else None
            ),
            target_records_per_file=(
                int(data["target_records_per_file"])
                if data.get("target_records_per_file") is not None
                else None
            ),
            available_roots=data.get("available_roots"),
            credentials=data.get("credentials"),
            created_at=int(data.get("created_at", 0) or 0),
            expires_at=int(data.get("expires_at", 0) or 0),
            last_heartbeat_at=int(data.get("last_heartbeat_at", 0) or 0),
            files_registered=(
                int(data["files_registered"])
                if data.get("files_registered") is not None
                else None
            ),
            total_records=(
                int(data["total_records"])
                if data.get("total_records") is not None
                else None
            ),
            total_bytes=(
                int(data["total_bytes"])
                if data.get("total_bytes") is not None
                else None
            ),
            attached=(
                bool(data["attached"]) if data.get("attached") is not None else None
            ),
            committed=(
                bool(data["committed"]) if data.get("committed") is not None else None
            ),
            deltas_written=(
                int(data["deltas_written"])
                if data.get("deltas_written") is not None
                else None
            ),
            raw=data,
        )


@dataclass
class RemoteTransactionInfo:
    transaction_id: str
    transaction_version: int
    status: str
    catalog: Optional[str] = None
    as_of: Optional[int] = None
    commit_message: Optional[str] = None
    created_at: int = 0
    expires_at: int = 0
    last_heartbeat_at: int = 0
    bound_write_sessions: List[str] = field(default_factory=list)
    operation_count: int = 0
    finalized_at: Optional[int] = None
    finalization_state: Optional[str] = None
    refreshed_credentials_by_session: Optional[CredentialsBySession] = None
    raw: MetadataSummary = field(default_factory=dict)

    @classmethod
    def from_response(cls, data: MetadataSummary) -> Self:
        return cls(
            transaction_id=str(data.get("transaction_id", "")),
            transaction_version=int(data.get("transaction_version", 0) or 0),
            status=str(data.get("status", "")),
            catalog=(str(data["catalog"]) if data.get("catalog") is not None else None),
            as_of=int(data["as_of"]) if data.get("as_of") is not None else None,
            commit_message=(
                str(data["commit_message"])
                if data.get("commit_message") is not None
                else None
            ),
            created_at=int(data.get("created_at", 0) or 0),
            expires_at=int(data.get("expires_at", 0) or 0),
            last_heartbeat_at=int(data.get("last_heartbeat_at", 0) or 0),
            bound_write_sessions=[
                str(session_id)
                for session_id in (data.get("bound_write_sessions") or [])
            ],
            operation_count=int(data.get("operation_count", 0) or 0),
            finalized_at=(
                int(data["finalized_at"])
                if data.get("finalized_at") is not None
                else None
            ),
            finalization_state=(
                str(data["finalization_state"])
                if data.get("finalization_state") is not None
                else None
            ),
            refreshed_credentials_by_session=data.get(
                "refreshed_credentials_by_session"
            ),
            raw=data,
        )


@dataclass
class ManifestTableRow:
    path: str
    id: Optional[str] = None
    mandatory: Optional[bool] = None
    record_count: int = 0
    content_length: int = 0
    source_content_length: Optional[int] = None
    content_type: str = "parquet"
    content_encoding: str = "identity"
    schema_id: Optional[IdentifierValue] = None
    sort_scheme_id: Optional[IdentifierValue] = None
    column_stats: Optional[ColumnStatsSummary] = None

    @property
    def entry_id(self) -> Optional[str]:
        return self.id

    @classmethod
    def from_any(cls, value: object) -> "ManifestTableRow":
        data = _raw_dict(value)
        path = data.get("path")
        if not path:
            raise ValueError("Manifest table rows must include a non-empty 'path'.")
        content_type = data.get(
            "meta_content_type", data.get("content_type", "parquet")
        )
        content_type = (
            content_type.value if hasattr(content_type, "value") else str(content_type)
        )
        return cls(
            path=path,
            id=data.get("id"),
            mandatory=data.get("mandatory"),
            record_count=int(
                data.get("meta_record_count", data.get("record_count", 0)) or 0
            ),
            content_length=int(
                data.get("meta_content_length", data.get("content_length", 0)) or 0
            ),
            source_content_length=data.get(
                "meta_source_content_length",
                data.get("source_content_length"),
            ),
            content_type=content_type,
            content_encoding=str(
                data.get(
                    "meta_content_encoding",
                    data.get("content_encoding", "identity"),
                )
                or "identity"
            ),
            schema_id=data.get("meta_schema_id", data.get("schema_id")),
            sort_scheme_id=data.get("meta_sort_scheme_id", data.get("sort_scheme_id")),
            column_stats=data.get("meta_column_stats", data.get("column_stats")),
        )

    def to_file(self) -> DataFile:
        return DataFile(
            path=self.path,
            id=self.id,
            mandatory=self.mandatory,
            record_count=self.record_count,
            content_length=self.content_length,
            source_content_length=self.source_content_length,
            content_type=self.content_type,
            content_encoding=self.content_encoding,
            schema_id=self.schema_id,
            sort_scheme_id=self.sort_scheme_id,
            column_stats=self.column_stats,
        )


def coerce_scan_tasks(values: Iterable[object]) -> List[ScanTask]:
    return [ScanTask.from_any(value) for value in values or []]


# Backward-compatible aliases for the earlier IO-core adapter names.
IODataFile = DataFile
IOScanTask = ScanTask
