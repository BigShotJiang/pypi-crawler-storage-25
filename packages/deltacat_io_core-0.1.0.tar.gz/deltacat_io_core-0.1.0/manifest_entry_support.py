"""Shared helpers for wrapping existing files into manifest entries."""

from __future__ import annotations

from typing import Any, Callable, Optional


def build_existing_manifest_entry(
    *,
    resolved_path: str,
    final_url: str,
    filesystem: Any,
    relative_root: Optional[str],
    record_count: int,
    explicit_content_length: Optional[int],
    source_content_length: Optional[int],
    content_type: str,
    content_encoding: str,
    credentials: Optional[Any],
    content_type_parameters: Optional[Any],
    entry_type: Optional[Any],
    entry_params: Optional[Any],
    schema_id: Optional[Any],
    sort_scheme_id: Optional[Any],
    resolved_column_stats: Optional[Any],
    manifest_entry_from_path_fn: Callable[..., Any],
    manifest_entry_of_fn: Callable[..., Any],
    manifest_meta_factory: Callable[..., Any],
) -> Any:
    """Build a manifest entry for an already-written non-Lance object.

    Preserves the native behavior of:
    - using explicit content length when the caller already knows it
    - otherwise delegating to ``ManifestEntry.from_path(...)``
    - attaching column stats after construction
    - rewriting the final URL when named-root prefixing is required
    """
    if explicit_content_length is not None:
        manifest_entry = manifest_entry_of_fn(
            url=final_url,
            meta=manifest_meta_factory(
                record_count=record_count,
                content_length=explicit_content_length,
                content_type=content_type,
                content_encoding=content_encoding,
                source_content_length=source_content_length,
                credentials=credentials,
                content_type_parameters=content_type_parameters,
                entry_type=entry_type,
                entry_params=entry_params,
                schema_id=schema_id,
                sort_scheme_id=sort_scheme_id,
            ),
        )
    else:
        manifest_entry = manifest_entry_from_path_fn(
            path=resolved_path,
            filesystem=filesystem,
            record_count=record_count,
            source_content_length=source_content_length,
            content_type=content_type,
            content_encoding=content_encoding,
            credentials=credentials,
            content_type_parameters=content_type_parameters,
            catalog_root=relative_root,
            entry_type=entry_type,
            entry_params=entry_params,
            schema_id=schema_id,
            sort_scheme_id=sort_scheme_id,
        )
        if getattr(manifest_entry, "url", None) != final_url:
            manifest_entry = manifest_entry_of_fn(
                url=final_url, meta=manifest_entry.meta
            )

    if (
        resolved_column_stats is not None
        and getattr(manifest_entry, "meta", None) is not None
    ):
        manifest_entry.meta["column_stats"] = resolved_column_stats
    return manifest_entry


def build_lance_manifest_entries(
    *,
    lance_path: str,
    stats: Any,
    schema_id: Optional[Any],
    sort_scheme_id: Optional[Any],
    column_stats: Optional[Any],
    catalog_root: Optional[str],
    entry_type: Optional[Any],
    entry_params: Optional[Any],
    source_content_length: Optional[Any],
    absolute_path_to_relative_fn: Callable[[str, str], str],
    manifest_meta_factory: Callable[..., Any],
    manifest_entry_of_fn: Callable[..., Any],
    manifest_entry_list_factory: Callable[[list[Any]], Any],
    lance_content_type: str,
    identity_content_encoding: str,
) -> Any:
    """Build manifest entries for an existing Lance dataset from precomputed stats."""
    resolved_schema_id = schema_id if schema_id is not None else stats["schema_id"]

    url = lance_path
    if catalog_root:
        url = absolute_path_to_relative_fn(catalog_root, lance_path)

    meta = manifest_meta_factory(
        record_count=stats["record_count"],
        content_length=stats["content_length"],
        content_type=lance_content_type,
        content_encoding=identity_content_encoding,
        source_content_length=source_content_length,
        schema_id=resolved_schema_id,
        sort_scheme_id=sort_scheme_id,
        entry_type=entry_type,
        entry_params=entry_params,
    )
    if column_stats:
        meta["column_stats"] = column_stats

    entry = manifest_entry_of_fn(url=url, meta=meta, mandatory=True)
    return manifest_entry_list_factory([entry])


def build_existing_lance_manifest_entries(
    *,
    resolved_path: str,
    relative_root: Optional[str],
    prefixed_root_name: Optional[str],
    filesystem: Any,
    schema_id: Optional[Any],
    sort_scheme_id: Optional[Any],
    resolved_column_stats: Optional[Any],
    entry_type: Optional[Any],
    entry_params: Optional[Any],
    source_content_length: Optional[Any],
    credentials: Optional[Any],
    content_type_parameters: Optional[Any],
    build_lance_manifest_entries_core_fn: Callable[..., Any],
    manifest_entry_of_fn: Callable[..., Any],
    prefix_path_fn: Callable[[str, str], str],
    precomputed_stats: Optional[Any] = None,
) -> list[Any]:
    """Build manifest entries for an existing Lance dataset directory."""
    lance_entries = list(
        build_lance_manifest_entries_core_fn(
            lance_path=resolved_path,
            stats=precomputed_stats,
            schema_id=schema_id,
            sort_scheme_id=sort_scheme_id,
            column_stats=resolved_column_stats,
            catalog_root=relative_root,
            entry_type=entry_type,
            entry_params=entry_params,
            source_content_length=source_content_length,
        )
    )
    if lance_entries and credentials is not None:
        lance_entries[0].meta["credentials"] = credentials
    if lance_entries and content_type_parameters is not None:
        lance_entries[0].meta["content_type_parameters"] = content_type_parameters
    if prefixed_root_name:
        lance_entries = [
            manifest_entry_of_fn(
                url=prefix_path_fn(manifest_entry.url, prefixed_root_name),
                meta=manifest_entry.meta,
            )
            for manifest_entry in lance_entries
        ]
    return lance_entries
