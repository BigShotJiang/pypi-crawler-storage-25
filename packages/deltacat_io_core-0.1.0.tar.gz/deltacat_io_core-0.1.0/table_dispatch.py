"""Shared table dispatch maps and block metadata helpers moved out of thick tables.py."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from decimal import Decimal
from typing import Any, Callable, Dict, List, Optional, Type

import deltacat_io_core.logs as logs
from deltacat_io_core.deps import optional_import, require_pyarrow
from deltacat_io_core.errors import SchemaNullabilityError

logger = logs.configure_deltacat_logger(logging.getLogger(__name__))


def _register_runtime_daft_table_type(table_type: Type[Any]) -> None:
    TABLE_CLASS_TO_COLUMN_NAMES_FUNC.setdefault(
        table_type, lambda table: table.column_names
    )
    TABLE_CLASS_TO_SCHEMA_FUNC.setdefault(
        table_type, lambda table: table.schema().to_pyarrow_schema()
    )
    TABLE_CLASS_TO_TABLE_TYPE.setdefault(table_type, "daft")


def _maybe_register_runtime_table_type(table: Any) -> bool:
    table_type = type(table)
    if str(table_type.__module__).startswith("daft"):
        _register_runtime_daft_table_type(table_type)
        return True
    return False


def _to_serializable_pd(val: Any) -> Any:
    if hasattr(val, "item"):
        try:
            return val.item()
        except Exception:
            pass
    if hasattr(val, "to_pydatetime"):
        return val.to_pydatetime().isoformat()
    if hasattr(val, "isoformat"):
        return val.isoformat()
    if isinstance(val, Decimal):
        return str(val)
    return val


def _to_serializable_pl(val: Any) -> Any:
    if hasattr(val, "item"):
        try:
            return val.item()
        except Exception:
            pass
    if isinstance(val, (datetime, date, timedelta)):
        return val.isoformat() if hasattr(val, "isoformat") else val.total_seconds()
    if isinstance(val, Decimal):
        return float(val)
    if hasattr(val, "isoformat"):
        return val.isoformat()
    return val


def validate_pyarrow_schema_nullability(table: Any) -> None:
    violations = []
    for field in table.schema:
        if not field.nullable:
            null_count = table.column(field.name).null_count
            if null_count > 0:
                violations.append(
                    f"  - Column '{field.name}' is NOT NULL but contains {null_count} null value(s)"
                )
    if violations:
        raise SchemaNullabilityError(
            "Schema/data nullability mismatch will cause corrupt Parquet files.\n"
            "PyArrow silently creates corrupt files when writing nulls to non-nullable columns,\n"
            "resulting in 'Unexpected end of stream' errors on read.\n\n"
            "Violations found:\n"
            + "\n".join(violations)
            + "\n\nTo fix: Either make these fields nullable in the schema, "
            "or ensure the data contains no nulls for these fields."
        )


def compute_arrow_table_column_stats(table: Any) -> Optional[Dict[str, Any]]:
    pa = require_pyarrow("column stats computation")
    import pyarrow.compute as pc

    if table.num_rows == 0:
        return None

    stats = {}
    for i in range(table.num_columns):
        field = table.schema.field(i)
        if not (
            pa.types.is_primitive(field.type)
            or pa.types.is_string(field.type)
            or pa.types.is_large_string(field.type)
            or pa.types.is_binary(field.type)
            or pa.types.is_large_binary(field.type)
            or pa.types.is_decimal(field.type)
            or pa.types.is_date(field.type)
            or pa.types.is_timestamp(field.type)
            or pa.types.is_time(field.type)
            or pa.types.is_duration(field.type)
        ):
            continue

        col = table.column(i)
        null_count = col.null_count
        if null_count == len(col):
            stats[field.name] = {"null_count": null_count}
            continue

        try:
            min_val = pc.min(col).as_py()
            max_val = pc.max(col).as_py()
            if hasattr(min_val, "isoformat"):
                min_val = min_val.isoformat()
            if hasattr(max_val, "isoformat"):
                max_val = max_val.isoformat()
            if isinstance(min_val, Decimal):
                min_val = str(min_val)
            if isinstance(max_val, Decimal):
                max_val = str(max_val)
        except Exception:
            logger.debug(
                "Falling back to null_count-only Arrow column stats for field %s",
                field.name,
                exc_info=True,
            )
            stats[field.name] = {"null_count": null_count}
            continue

        stats[field.name] = {
            "min": min_val,
            "max": max_val,
            "null_count": null_count,
        }

    return stats if stats else None


def compute_pandas_column_stats(df: Any) -> Optional[Dict[str, Any]]:
    np = optional_import("numpy")
    if len(df) == 0:
        return None

    stats = {}
    for col_name in df.columns:
        dtype = df[col_name].dtype
        if np is not None and dtype == np.dtype("O"):
            sample = (
                df[col_name].dropna().iloc[0] if df[col_name].notna().any() else None
            )
            if sample is not None and not isinstance(sample, (str, bytes)):
                continue

        null_count = int(df[col_name].isna().sum())
        if null_count == len(df):
            stats[col_name] = {"null_count": null_count}
            continue

        try:
            min_val = _to_serializable_pd(df[col_name].min())
            max_val = _to_serializable_pd(df[col_name].max())
        except Exception:
            logger.debug(
                "Falling back to null_count-only pandas column stats for field %s",
                col_name,
                exc_info=True,
            )
            stats[col_name] = {"null_count": null_count}
            continue

        stats[col_name] = {
            "min": min_val,
            "max": max_val,
            "null_count": null_count,
        }

    return stats if stats else None


def compute_polars_column_stats(df: Any) -> Optional[Dict[str, Any]]:
    pl = optional_import("polars")
    if len(df) == 0:
        return None

    stats = {}
    for col_name in df.columns:
        dtype = df[col_name].dtype
        if pl is not None and dtype in (pl.List, pl.Struct, pl.Object):
            continue

        null_count = df[col_name].null_count()
        if null_count == len(df):
            stats[col_name] = {"null_count": null_count}
            continue

        try:
            min_val = _to_serializable_pl(df[col_name].min())
            max_val = _to_serializable_pl(df[col_name].max())
        except Exception:
            logger.debug(
                "Falling back to null_count-only polars column stats for field %s",
                col_name,
                exc_info=True,
            )
            stats[col_name] = {"null_count": null_count}
            continue

        stats[col_name] = {
            "min": min_val,
            "max": max_val,
            "null_count": null_count,
        }

    return stats if stats else None


def table_size_arrow(table: Any) -> int:
    return table.nbytes


def parquet_file_size(table: Any) -> int:
    return table.metadata.serialized_size


def dataframe_size_pandas(table: Any) -> int:
    return int(table.memory_usage(deep=True).sum())


def dataframe_size_polars(table: Any) -> int:
    return table.estimated_size()


def ndarray_size_numpy(table: Any) -> int:
    return int(table.nbytes)


TABLE_CLASS_TO_COLUMN_STATS_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_VALIDATOR_FUNC: Dict[Type[Any], Optional[Callable]] = {}
TABLE_CLASS_TO_SIZE_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_COLUMN_NAMES_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_SCHEMA_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_TABLE_TYPE: Dict[Type[Any], str] = {}
TABLE_CLASS_TO_APPEND_COLUMN_FUNC: Dict[Type[Any], Callable] = {}
TABLE_CLASS_TO_SELECT_COLUMNS_FUNC: Dict[Type[Any], Callable] = {}


def append_column_to_arrow_table(
    table: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    pa = require_pyarrow("append column")
    column_array = pa.array([column_value] * table.num_rows)
    return table.append_column(column_name, column_array)


def append_column_to_parquet_file(
    parquet_file: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    return append_column_to_arrow_table(parquet_file.read(), column_name, column_value)


def append_column_to_pandas_dataframe(
    dataframe: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    dataframe[column_name] = column_value
    return dataframe


def append_column_to_polars_table(
    table: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    pl = optional_import("polars")
    if pl is None:
        raise ImportError("append column requires optional dependency `polars`.")
    return table.with_columns(pl.lit(column_value).alias(column_name))


def append_column_to_ndarray(
    np_array: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    np = optional_import("numpy")
    if np is None:
        raise ImportError("append column requires optional dependency `numpy`.")
    return np.concatenate(
        (np_array, np.full((len(np_array), 1), column_value)),
        axis=1,
    )


def select_arrow_columns(table: Any, column_names: Any) -> Any:
    return table.select(column_names)


def select_pandas_columns(table: Any, column_names: Any) -> Any:
    return table[column_names]


def select_polars_columns(table: Any, column_names: Any) -> Any:
    return table.select(column_names)


def _initialize_dispatch_maps() -> None:
    pa = optional_import("pyarrow")
    pd = optional_import("pandas")
    pl = optional_import("polars")
    lance_mod = optional_import("lance")

    if pa is not None:
        TABLE_CLASS_TO_COLUMN_STATS_FUNC[pa.Table] = compute_arrow_table_column_stats
        TABLE_CLASS_TO_VALIDATOR_FUNC[pa.Table] = validate_pyarrow_schema_nullability
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[pa.Table] = lambda table: table.schema.names
        TABLE_CLASS_TO_SCHEMA_FUNC[pa.Table] = lambda table: table.schema
        TABLE_CLASS_TO_TABLE_TYPE[pa.Table] = "pyarrow"
        TABLE_CLASS_TO_APPEND_COLUMN_FUNC[pa.Table] = append_column_to_arrow_table
        TABLE_CLASS_TO_SELECT_COLUMNS_FUNC[pa.Table] = select_arrow_columns
        try:
            import pyarrow.parquet as papq

            TABLE_CLASS_TO_SIZE_FUNC[pa.Table] = table_size_arrow
            TABLE_CLASS_TO_SIZE_FUNC[papq.ParquetFile] = parquet_file_size
            TABLE_CLASS_TO_COLUMN_NAMES_FUNC[
                papq.ParquetFile
            ] = lambda table: table.schema.names
            TABLE_CLASS_TO_SCHEMA_FUNC[
                papq.ParquetFile
            ] = lambda table: table.schema_arrow
            TABLE_CLASS_TO_TABLE_TYPE[papq.ParquetFile] = "pyarrow_parquet"
            TABLE_CLASS_TO_APPEND_COLUMN_FUNC[
                papq.ParquetFile
            ] = append_column_to_parquet_file
        except Exception:
            logger.debug(
                "PyArrow Parquet support unavailable while initializing shared table dispatch; "
                "falling back to Arrow-table-only registration.",
                exc_info=True,
            )
            TABLE_CLASS_TO_SIZE_FUNC[pa.Table] = table_size_arrow
    if pd is not None:
        TABLE_CLASS_TO_COLUMN_STATS_FUNC[pd.DataFrame] = compute_pandas_column_stats
        TABLE_CLASS_TO_VALIDATOR_FUNC[pd.DataFrame] = None
        TABLE_CLASS_TO_SIZE_FUNC[pd.DataFrame] = dataframe_size_pandas
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[
            pd.DataFrame
        ] = lambda table: table.columns.tolist()
        TABLE_CLASS_TO_SCHEMA_FUNC[pd.DataFrame] = lambda table: pa.Schema.from_pandas(
            table
        )
        TABLE_CLASS_TO_TABLE_TYPE[pd.DataFrame] = "pandas"
        TABLE_CLASS_TO_APPEND_COLUMN_FUNC[
            pd.DataFrame
        ] = append_column_to_pandas_dataframe
        TABLE_CLASS_TO_SELECT_COLUMNS_FUNC[pd.DataFrame] = select_pandas_columns
    if pl is not None:
        TABLE_CLASS_TO_COLUMN_STATS_FUNC[pl.DataFrame] = compute_polars_column_stats
        TABLE_CLASS_TO_VALIDATOR_FUNC[pl.DataFrame] = None
        TABLE_CLASS_TO_SIZE_FUNC[pl.DataFrame] = dataframe_size_polars
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[pl.DataFrame] = lambda table: table.columns
        TABLE_CLASS_TO_SCHEMA_FUNC[pl.DataFrame] = lambda table: table.to_arrow().schema
        TABLE_CLASS_TO_TABLE_TYPE[pl.DataFrame] = "polars"
        TABLE_CLASS_TO_APPEND_COLUMN_FUNC[pl.DataFrame] = append_column_to_polars_table
        TABLE_CLASS_TO_SELECT_COLUMNS_FUNC[pl.DataFrame] = select_polars_columns
    np = optional_import("numpy")
    if np is not None:
        TABLE_CLASS_TO_SIZE_FUNC[np.ndarray] = ndarray_size_numpy
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[np.ndarray] = lambda table: [
            f"{i}" for i in range(table.shape[1])
        ]
        TABLE_CLASS_TO_TABLE_TYPE[np.ndarray] = "numpy"
        TABLE_CLASS_TO_APPEND_COLUMN_FUNC[np.ndarray] = append_column_to_ndarray
        if pa is not None and pd is not None:
            TABLE_CLASS_TO_SCHEMA_FUNC[
                np.ndarray
            ] = lambda table: pa.Schema.from_pandas(pd.DataFrame(table))
    ray_dataset_mod = optional_import("ray.data.dataset")
    if ray_dataset_mod is not None:
        dataset_cls = getattr(ray_dataset_mod, "Dataset")
        materialized_cls = getattr(ray_dataset_mod, "MaterializedDataset")
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[
            dataset_cls
        ] = lambda table: table.schema().names
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[
            materialized_cls
        ] = lambda table: table.schema().names
        TABLE_CLASS_TO_SCHEMA_FUNC[
            dataset_cls
        ] = lambda table: table.schema().base_schema
        TABLE_CLASS_TO_SCHEMA_FUNC[
            materialized_cls
        ] = lambda table: table.schema().base_schema
        TABLE_CLASS_TO_TABLE_TYPE[dataset_cls] = "ray_dataset"
        TABLE_CLASS_TO_TABLE_TYPE[materialized_cls] = "ray_dataset"
    if lance_mod is not None:
        TABLE_CLASS_TO_COLUMN_STATS_FUNC[
            lance_mod.LanceDataset
        ] = lambda table: compute_arrow_table_column_stats(table.to_table())
        TABLE_CLASS_TO_VALIDATOR_FUNC[lance_mod.LanceDataset] = None
        TABLE_CLASS_TO_SIZE_FUNC[
            lance_mod.LanceDataset
        ] = lambda table: table.to_table().nbytes
        TABLE_CLASS_TO_COLUMN_NAMES_FUNC[
            lance_mod.LanceDataset
        ] = lambda table: table.schema.names
        TABLE_CLASS_TO_SCHEMA_FUNC[lance_mod.LanceDataset] = lambda table: table.schema
        TABLE_CLASS_TO_TABLE_TYPE[lance_mod.LanceDataset] = "lance"
        TABLE_CLASS_TO_APPEND_COLUMN_FUNC[
            lance_mod.LanceDataset
        ] = lambda table, column_name, column_value: append_column_to_arrow_table(
            table.to_table(), column_name, column_value
        )
        TABLE_CLASS_TO_SELECT_COLUMNS_FUNC[
            lance_mod.LanceDataset
        ] = lambda table, columns: table.to_table(columns=columns)


_initialize_dispatch_maps()


def validate_table_before_write(table: Any) -> None:
    validator = TABLE_CLASS_TO_VALIDATOR_FUNC.get(type(table))
    if validator is not None:
        validator(table)


def try_compute_column_stats(table: Any) -> Optional[Dict[str, Any]]:
    if table is None:
        return None
    try:
        stats_fn = TABLE_CLASS_TO_COLUMN_STATS_FUNC.get(type(table))
        if stats_fn:
            return stats_fn(table)
    except Exception:
        logger.debug(
            "Failed to compute column stats for table type %s",
            type(table),
            exc_info=True,
        )
    return None


def get_table_function(
    table: Any, function_map: Dict[Type[Any], Callable], operation_name: str
) -> Callable:
    table_func = function_map.get(type(table))
    if table_func is None:
        if _maybe_register_runtime_table_type(table):
            table_func = function_map.get(type(table))
        if table_func is None:
            raise ValueError(
                f"No {operation_name} function found for table type: {type(table)}.\n"
                f"Known table types: {list(function_map.keys())}"
            )
    return table_func


def get_table_column_names(table: Any):
    return get_table_function(table, TABLE_CLASS_TO_COLUMN_NAMES_FUNC, "column names")(
        table
    )


def get_table_schema(table: Any):
    return get_table_function(table, TABLE_CLASS_TO_SCHEMA_FUNC, "schema")(table)


def get_table_type_name(table: Any) -> str:
    table_type = TABLE_CLASS_TO_TABLE_TYPE.get(type(table))
    if table_type is None:
        if _maybe_register_runtime_table_type(table):
            table_type = TABLE_CLASS_TO_TABLE_TYPE.get(type(table))
        if table_type is None:
            raise ValueError(
                f"No dataset type identification function found for table type: {type(table)}.\n"
                f"Known table types: {list(TABLE_CLASS_TO_TABLE_TYPE.keys())}"
            )
    return table_type


def append_column_to_table(
    table: Any,
    column_name: str,
    column_value: Any,
) -> Any:
    return get_table_function(
        table, TABLE_CLASS_TO_APPEND_COLUMN_FUNC, "append column"
    )(table, column_name, column_value)


def select_columns_from_table(
    table: Any,
    column_names: Any,
) -> Any:
    return get_table_function(
        table, TABLE_CLASS_TO_SELECT_COLUMNS_FUNC, "select columns"
    )(table, column_names)


@dataclass(frozen=True)
class BlockMetadataInfo:
    num_rows: int
    size_bytes: Optional[int]


def get_block_metadata(table: Any) -> BlockMetadataInfo:
    table_size = None
    table_size_func = TABLE_CLASS_TO_SIZE_FUNC.get(type(table))
    if table_size_func:
        table_size = table_size_func(table)
    if hasattr(table, "to_block"):
        table = table.to_block()
    return BlockMetadataInfo(
        num_rows=len(table),
        size_bytes=table_size,
    )


def get_block_metadata_list(
    table: Any, write_paths: List[str], blocks: List[Any]
) -> List[BlockMetadataInfo]:
    block_meta_list: List[BlockMetadataInfo] = []
    if not blocks:
        assert len(write_paths) == 1, (
            f"Expected table of type '{type(table)}' to be written to 1 "
            f"file, but found {len(write_paths)} files."
        )
        blocks = [table]
    for block in blocks:
        block_meta_list.append(get_block_metadata(block))
    return block_meta_list
