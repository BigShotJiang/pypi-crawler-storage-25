"""Shared resource metric helpers used by compaction audit models."""

from __future__ import annotations

import logging
import sys
from typing import Any, Dict

import ray

from deltacat_io_core import logs


logger = logs.configure_deltacat_logger(logging.getLogger(__name__))

BYTES_PER_GIBIBYTE = 1024**3


class ClusterUtilization:
    def __init__(
        self,
        cluster_resources: Dict[str, Any],
        available_resources: Dict[str, Any],
    ):
        used_resources = {}
        for key in cluster_resources:
            if (
                isinstance(cluster_resources[key], float)
                or isinstance(cluster_resources[key], int)
            ) and key in available_resources:
                used_resources[key] = cluster_resources[key] - available_resources[key]

        self.total_memory_bytes = cluster_resources.get("memory")
        self.used_memory_bytes = used_resources.get("memory", 0.0)
        self.total_cpu = cluster_resources.get("CPU")
        self.used_cpu = used_resources.get("CPU", 0)
        self.total_object_store_memory_bytes = cluster_resources.get(
            "object_store_memory"
        )
        self.used_object_store_memory_bytes = used_resources.get(
            "object_store_memory",
            0.0,
        )
        self.used_memory_percent = (
            self.used_memory_bytes / self.total_memory_bytes
        ) * 100
        self.used_object_store_memory_percent = (
            self.used_object_store_memory_bytes / self.total_object_store_memory_bytes
        ) * 100
        self.used_cpu_percent = (self.used_cpu / self.total_cpu) * 100
        self.used_resources = used_resources

    @staticmethod
    def get_current_cluster_utilization():
        cluster_resources = ray.cluster_resources()
        available_resources = ray.available_resources()
        return ClusterUtilization(
            cluster_resources=cluster_resources,
            available_resources=available_resources,
        )


def get_size_of_object_in_bytes(obj: object) -> float:
    size = sys.getsizeof(obj)
    if isinstance(obj, dict):
        return (
            size
            + sum(map(get_size_of_object_in_bytes, obj.keys()))
            + sum(map(get_size_of_object_in_bytes, obj.values()))
        )
    if isinstance(obj, (list, tuple, set, frozenset)):
        return size + sum(map(get_size_of_object_in_bytes, obj))
    return size
