"""Shared write-strategy orchestration moved out of thick tables.py."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional


def write_file_entries_strategy(
    table: Any,
    *,
    data_dir_path: str,
    catalog_root: str,
    filesystem: Any,
    max_records_per_entry: Optional[int],
    content_type: Any,
    entry_params: Optional[Any],
    entry_type: Optional[Any],
    table_writer_kwargs: Optional[Dict[str, Any]],
    table_writer_map: Dict[Any, Callable],
    table_slicer_map: Dict[Any, Callable],
    get_table_function: Callable,
    write_sliced_table_fn: Callable,
    catalog_properties_factory: Callable,
    manifest_entries_factory: Callable,
):
    """Standard file-based write strategy shared by thick and thin paths."""
    table_writer_kwargs = dict(table_writer_kwargs or {})
    if "catalog_properties" not in table_writer_kwargs:
        table_writer_kwargs["catalog_properties"] = catalog_properties_factory(
            root=catalog_root,
            filesystem=filesystem,
        )

    table_writer_fn = get_table_function(table, table_writer_map, "writing")
    table_slicer_fn = get_table_function(table, table_slicer_map, "slicing")

    manifest_entries = manifest_entries_factory()
    tables = [t for t in table] if isinstance(table, list) else [table]
    for t in tables:
        manifest_entries.extend(
            write_sliced_table_fn(
                t,
                data_dir_path,
                filesystem,
                max_records_per_entry,
                table_writer_fn,
                table_slicer_fn,
                table_writer_kwargs,
                content_type,
                entry_params,
                entry_type,
            )
        )
    return manifest_entries


def write_lance_entries_strategy(
    table: Any,
    *,
    data_dir_path: str,
    catalog_root: str,
    filesystem: Any,
    max_records_per_entry: Optional[int],
    entry_params: Optional[Any],
    entry_type: Optional[Any],
    table_writer_kwargs: Optional[Dict[str, Any]],
    write_lance_entries_fn: Callable,
):
    """Directory-based Lance write strategy shared by thick and thin paths."""
    return write_lance_entries_fn(
        table,
        data_dir_path,
        catalog_root=catalog_root,
        filesystem=filesystem,
        max_records_per_entry=max_records_per_entry,
        entry_params=entry_params,
        entry_type=entry_type,
        table_writer_kwargs=table_writer_kwargs,
    )
