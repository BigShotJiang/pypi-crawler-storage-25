"""Shared distributed manifest download orchestration moved out of thick tables.py."""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional


def dispatch_distributed_manifest_download(
    *,
    manifest: Any,
    table_type: Any,
    max_parallelism: Optional[int],
    column_names: Optional[list[str]],
    include_columns: Optional[list[str]],
    file_reader_kwargs_provider: Optional[Any],
    ray_options_provider: Optional[Callable[[int, Any], Dict[str, Any]]],
    distributed_dataset_type: Optional[Any],
    ray_dataset_type: Any,
    file_path_column: Optional[str],
    ray_dispatch_fn: Callable[..., Any],
    other_dispatch_fn: Callable[..., Any],
    **kwargs,
):
    """Dispatch to the correct distributed manifest download implementation."""
    params = {
        "manifest": manifest,
        "table_type": table_type,
        "max_parallelism": max_parallelism,
        "column_names": column_names,
        "include_columns": include_columns,
        "file_reader_kwargs_provider": file_reader_kwargs_provider,
        "ray_options_provider": ray_options_provider,
        "file_path_column": file_path_column,
        **kwargs,
    }

    if (
        distributed_dataset_type
        and distributed_dataset_type.value == ray_dataset_type.value
    ):
        return ray_dispatch_fn(**params)
    if distributed_dataset_type is not None:
        params["distributed_dataset_type"] = distributed_dataset_type
        return other_dispatch_fn(**params)
    raise ValueError(
        f"Distributed dataset type {distributed_dataset_type} not supported."
    )
