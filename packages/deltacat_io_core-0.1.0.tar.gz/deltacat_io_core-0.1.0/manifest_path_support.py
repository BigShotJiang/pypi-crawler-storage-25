"""Shared manifest path/storage normalization helpers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional


@dataclass(frozen=True)
class ManifestEntryLocation:
    data_root: Optional[Any]
    filesystem: Optional[Any]
    resolved_path: str
    relative_root: Optional[str]
    prefixed_root_name: Optional[str]
    final_url: str


def resolve_manifest_entry_location(
    *,
    path: str,
    entry_data_root_name: Optional[str],
    catalog_root: Optional[str],
    catalog_properties: Optional[Any],
    resolve_path_and_filesystem_fn: Callable[[str, Optional[Any]], tuple[str, Any]],
    absolute_path_to_relative_fn: Callable[[str, str], str],
    registry_factory: Callable[[], Any],
    prefix_path_fn: Callable[[str, str], str],
) -> ManifestEntryLocation:
    """Resolve manifest entry storage and normalize the stored manifest URL."""

    data_root = None
    filesystem = None
    entry_catalog_root = None
    cfg = getattr(catalog_properties, "data_root_config", None)

    if entry_data_root_name and not cfg:
        raise ValueError(
            "data_root_name was provided, but this catalog is configured with a "
            "single data_root. Configure a DataRootConfig to use named roots."
        )

    if catalog_properties:
        if cfg is not None:
            if entry_data_root_name:
                data_root = cfg.roots.get(entry_data_root_name)
                if data_root is None:
                    available = sorted(cfg.roots.keys())
                    raise ValueError(
                        f"Unknown data_root_name '{entry_data_root_name}'. "
                        f"Available roots: {available}"
                    )
            else:
                data_root = cfg.default_root

            if data_root is not None:
                registry = registry_factory()
                filesystem = registry.get_filesystem(data_root)
                entry_catalog_root = data_root.root
        else:
            filesystem = getattr(catalog_properties, "data_filesystem", None)

    resolved_path, filesystem = resolve_path_and_filesystem_fn(path, filesystem)

    if cfg is not None:
        if entry_data_root_name:
            root_uri = cfg.roots[entry_data_root_name].root
            try:
                normalized_path = absolute_path_to_relative_fn(root_uri, resolved_path)
            except ValueError as exc:
                raise ValueError(
                    f"Manifest entry path '{resolved_path}' does not match the expected "
                    f"data root '{root_uri}'. Ensure the file was written to the "
                    "staging path returned by stage_write."
                ) from exc
            relative_root = root_uri
            prefixed_root_name = (
                entry_data_root_name
                if entry_data_root_name != cfg.default_name
                else None
            )
        else:
            default_dr = cfg.default_root
            if default_dr is None:
                normalized_path = resolved_path
                relative_root = None
                prefixed_root_name = None
            else:
                root_uri = default_dr.root
                try:
                    normalized_path = absolute_path_to_relative_fn(
                        root_uri, resolved_path
                    )
                except ValueError as exc:
                    raise ValueError(
                        f"Manifest entry path '{resolved_path}' does not match the expected "
                        f"data root '{root_uri}'. Ensure the file was written to the "
                        "staging path returned by stage_write."
                    ) from exc
                relative_root = root_uri
                prefixed_root_name = (
                    entry_data_root_name
                    if entry_data_root_name and entry_data_root_name != cfg.default_name
                    else None
                )
        if cfg.default_root is None and not entry_data_root_name:
            normalized_path = resolved_path
            relative_root = None
            prefixed_root_name = None
    elif catalog_root:
        try:
            normalized_path = absolute_path_to_relative_fn(catalog_root, resolved_path)
            relative_root = catalog_root
            prefixed_root_name = None
        except ValueError:
            normalized_path = resolved_path
            relative_root = None
            prefixed_root_name = None
    else:
        normalized_path = resolved_path
        relative_root = None
        prefixed_root_name = None

    if entry_catalog_root is not None:
        relative_root = entry_catalog_root

    final_url = (
        prefix_path_fn(normalized_path, prefixed_root_name)
        if prefixed_root_name
        else normalized_path
    )

    return ManifestEntryLocation(
        data_root=data_root,
        filesystem=filesystem,
        resolved_path=resolved_path,
        relative_root=relative_root,
        prefixed_root_name=prefixed_root_name,
        final_url=final_url,
    )
