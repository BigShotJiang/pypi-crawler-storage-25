"""Shared task/result models for compactor-v2 execution."""

from __future__ import annotations

from typing import Any, Dict, List, NamedTuple, Optional, Set

import numpy as np


class HashBucketInput(Dict):
    @classmethod
    def of(
        cls,
        annotated_delta: Any,
        primary_keys: List[str],
        num_hash_buckets: int,
        num_hash_groups: int,
        all_column_names: List[str],
        hb_task_index: Optional[int] = 0,
        enable_profiler: Optional[bool] = False,
        metrics_config: Optional[Any] = None,
        read_kwargs_provider: Optional[Any] = None,
        object_store: Optional[Any] = None,
        deltacat_storage=None,
        deltacat_storage_kwargs: Optional[Dict[str, Any]] = None,
        memory_logs_enabled: Optional[bool] = None,
    ):
        result = cls()
        result["annotated_delta"] = annotated_delta
        result["primary_keys"] = primary_keys
        result["hb_task_index"] = hb_task_index
        result["num_hash_buckets"] = num_hash_buckets
        result["num_hash_groups"] = num_hash_groups
        result["all_column_names"] = all_column_names
        result["enable_profiler"] = enable_profiler
        result["metrics_config"] = metrics_config
        result["read_kwargs_provider"] = read_kwargs_provider
        result["object_store"] = object_store
        result["deltacat_storage"] = deltacat_storage
        result["deltacat_storage_kwargs"] = deltacat_storage_kwargs or {}
        result["memory_logs_enabled"] = memory_logs_enabled
        return result

    @property
    def annotated_delta(self):
        return self["annotated_delta"]

    @property
    def primary_keys(self) -> List[str]:
        return self["primary_keys"]

    @property
    def hb_task_index(self):
        return self["hb_task_index"]

    @property
    def num_hash_buckets(self) -> int:
        return self["num_hash_buckets"]

    @property
    def num_hash_groups(self) -> int:
        return self["num_hash_groups"]

    @property
    def all_column_names(self) -> List[str]:
        return self["all_column_names"]

    @property
    def enable_profiler(self) -> Optional[bool]:
        return self.get("enable_profiler")

    @property
    def metrics_config(self):
        return self.get("metrics_config")

    @property
    def read_kwargs_provider(self):
        return self.get("read_kwargs_provider")

    @property
    def object_store(self):
        return self.get("object_store")

    @property
    def deltacat_storage(self):
        return self.get("deltacat_storage")

    @property
    def deltacat_storage_kwargs(self) -> Optional[Dict[str, Any]]:
        return self.get("deltacat_storage_kwargs")

    @property
    def memory_logs_enabled(self) -> Optional[bool]:
        return self.get("memory_logs_enabled")


class MergeInput(Dict):
    @classmethod
    def of(
        cls,
        merge_file_groups_provider: Any,
        write_to_partition: Any,
        compacted_file_content_type: Any,
        primary_keys: List[str],
        all_column_names: List[str],
        drop_duplicates: Optional[bool] = True,
        sort_keys: Optional[List[Any]] = None,
        sort_keys_precede_stream_position: Optional[bool] = False,
        merge_task_index: Optional[int] = 0,
        max_records_per_output_file: Optional[int] = None,
        enable_profiler: Optional[bool] = False,
        metrics_config: Optional[Any] = None,
        table_writer_kwargs: Optional[Dict[str, Any]] = None,
        read_kwargs_provider: Optional[Any] = None,
        round_completion_info: Optional[Any] = None,
        object_store: Optional[Any] = None,
        delete_strategy: Optional[Any] = None,
        delete_file_envelopes: Optional[List[Any]] = None,
        deltacat_storage=None,
        deltacat_storage_kwargs: Optional[Dict[str, Any]] = None,
        memory_logs_enabled: Optional[bool] = None,
        disable_copy_by_reference: Optional[bool] = None,
        hash_bucket_count: Optional[int] = None,
        original_fields: Optional[Set[str]] = None,
        compacted_manifest: Optional[Any] = None,
        output_sort_scheme=None,
    ):
        result = cls()
        result["merge_file_groups_provider"] = merge_file_groups_provider
        result["write_to_partition"] = write_to_partition
        result["compacted_file_content_type"] = compacted_file_content_type
        result["primary_keys"] = primary_keys
        result["all_column_names"] = all_column_names
        result["drop_duplicates"] = drop_duplicates
        result["sort_keys"] = sort_keys
        result["sort_keys_precede_stream_position"] = sort_keys_precede_stream_position
        result["merge_task_index"] = merge_task_index
        result["max_records_per_output_file"] = max_records_per_output_file
        result["enable_profiler"] = enable_profiler
        result["metrics_config"] = metrics_config
        result["table_writer_kwargs"] = table_writer_kwargs or {}
        result["read_kwargs_provider"] = read_kwargs_provider
        result["round_completion_info"] = round_completion_info
        result["object_store"] = object_store
        result["delete_file_envelopes"] = delete_file_envelopes
        result["delete_strategy"] = delete_strategy
        result["deltacat_storage"] = deltacat_storage
        result["deltacat_storage_kwargs"] = deltacat_storage_kwargs or {}
        result["memory_logs_enabled"] = memory_logs_enabled
        result["disable_copy_by_reference"] = disable_copy_by_reference
        result["hash_bucket_count"] = hash_bucket_count
        result["original_fields"] = original_fields
        result["compacted_manifest"] = compacted_manifest
        result["output_sort_scheme"] = output_sort_scheme
        return result

    @property
    def merge_file_groups_provider(self):
        return self["merge_file_groups_provider"]

    @property
    def write_to_partition(self):
        return self["write_to_partition"]

    @property
    def compacted_file_content_type(self):
        return self["compacted_file_content_type"]

    @property
    def primary_keys(self) -> List[str]:
        return self["primary_keys"]

    @property
    def all_column_names(self) -> List[str]:
        return self["all_column_names"]

    @property
    def drop_duplicates(self):
        return self["drop_duplicates"]

    @property
    def sort_keys(self):
        return self.get("sort_keys")

    @property
    def sort_keys_precede_stream_position(self) -> bool:
        return self.get("sort_keys_precede_stream_position", False)

    @property
    def merge_task_index(self) -> int:
        return self.get("merge_task_index")

    @property
    def max_records_per_output_file(self):
        return self.get("max_records_per_output_file")

    @property
    def enable_profiler(self) -> bool:
        return self.get("enable_profiler")

    @property
    def metrics_config(self):
        return self.get("metrics_config")

    @property
    def table_writer_kwargs(self):
        return self.get("table_writer_kwargs")

    @property
    def read_kwargs_provider(self):
        return self.get("read_kwargs_provider")

    @property
    def round_completion_info(self):
        return self.get("round_completion_info")

    @property
    def object_store(self):
        return self.get("object_store")

    @property
    def deltacat_storage(self):
        return self["deltacat_storage"]

    @property
    def deltacat_storage_kwargs(self):
        return self.get("deltacat_storage_kwargs")

    @property
    def memory_logs_enabled(self) -> Optional[bool]:
        return self.get("memory_logs_enabled")

    @property
    def delete_file_envelopes(self):
        return self.get("delete_file_envelopes")

    @property
    def delete_strategy(self):
        return self.get("delete_strategy")

    @property
    def disable_copy_by_reference(self):
        return self["disable_copy_by_reference"]

    @property
    def hash_bucket_count(self):
        return self["hash_bucket_count"]

    @property
    def original_fields(self):
        return self.get("original_fields")

    @property
    def compacted_manifest(self):
        return self.get("compacted_manifest")

    @property
    def output_sort_scheme(self):
        return self.get("output_sort_scheme")


class HashBucketResult(NamedTuple):
    hash_bucket_group_to_obj_id_tuple: np.ndarray
    hb_size_bytes: np.int64
    hb_record_count: np.int64
    peak_memory_usage_bytes: np.double
    telemetry_time_in_seconds: np.double
    task_completed_at: np.double


class MergeResult(NamedTuple):
    materialize_results: List[Any]
    input_record_count: np.int64
    deduped_record_count: np.int64
    deleted_record_count: np.int64
    peak_memory_usage_bytes: np.double
    telemetry_time_in_seconds: np.double
    task_completed_at: np.double


class MergeForReadResult(NamedTuple):
    table: Optional[Any]
    table_ref: Optional[Any]
    input_record_count: np.int64
    deduped_record_count: np.int64
    deleted_record_count: np.int64
    peak_memory_usage_bytes: np.double
    num_rows: np.int64
