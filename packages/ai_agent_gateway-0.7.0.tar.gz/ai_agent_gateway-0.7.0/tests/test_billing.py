import asyncio
import sqlite3
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[3]
PKG_DIR = ROOT / "packages" / "agent-gateway"
if str(PKG_DIR) not in sys.path:
  sys.path.insert(0, str(PKG_DIR))

from agent_gateway.multi_user.billing import SqliteUsageLedger, UsageEvent, replay_dlq, write_dlq


def _run(coro):
  return asyncio.run(coro)


def _event(
  *,
  user_id: str = "alice",
  request_id: str = "req-1",
  timestamp: float = 100.0,
  model: str = "claude-sonnet-4-6",
  billing_mode: str = "metered",
  channel: str | None = "web",
  parent_turn_id: str | None = None,
) -> UsageEvent:
  return UsageEvent(
    user_id=user_id,
    session_id="sess-1",
    request_id=request_id,
    parent_turn_id=parent_turn_id,
    timestamp=timestamp,
    model=model,
    input_tokens=100,
    output_tokens=50,
    cache_read_tokens=10,
    cache_creation_tokens=5,
    cost_usd=0.125,
    rate_table_version="2026-04-08",
    billing_mode=billing_mode,  # type: ignore[arg-type]
    channel=channel,
  )


def test_sqlite_usage_ledger_record_inserts_all_fields(tmp_path: Path) -> None:
  db_path = tmp_path / "usage.db"
  ledger = SqliteUsageLedger(db_path)

  _run(ledger.record(_event(parent_turn_id="tool-1")))

  with sqlite3.connect(db_path) as conn:
    row = conn.execute(
      """
      SELECT user_id, session_id, request_id, parent_turn_id, timestamp, model,
             input_tokens, output_tokens, cache_read_tokens, cache_creation_tokens,
             cost_usd, rate_table_version, billing_mode, channel
      FROM usage_events
      """
    ).fetchone()

  assert row == (
    "alice",
    "sess-1",
    "req-1",
    "tool-1",
    100.0,
    "claude-sonnet-4-6",
    100,
    50,
    10,
    5,
    0.125,
    "2026-04-08",
    "metered",
    "web",
  )


def test_sqlite_usage_ledger_get_total_filters_and_sums(tmp_path: Path) -> None:
  ledger = SqliteUsageLedger(tmp_path / "usage.db")
  events = [
    _event(user_id="alice", request_id="req-1", timestamp=100.0, billing_mode="metered", model="claude-sonnet-4-6"),
    UsageEvent(
      user_id="alice",
      session_id="sess-2",
      request_id="req-2",
      parent_turn_id=None,
      timestamp=200.0,
      model="claude-opus-4-6",
      input_tokens=40,
      output_tokens=20,
      cache_read_tokens=4,
      cache_creation_tokens=2,
      cost_usd=0.05,
      rate_table_version="2026-04-08",
      billing_mode="byok",
      channel="cli",
    ),
    UsageEvent(
      user_id="bob",
      session_id="sess-3",
      request_id="req-3",
      parent_turn_id=None,
      timestamp=300.0,
      model="claude-sonnet-4-6",
      input_tokens=999,
      output_tokens=999,
      cache_read_tokens=0,
      cache_creation_tokens=0,
      cost_usd=9.99,
      rate_table_version="2026-04-08",
      billing_mode="metered",
      channel="web",
    ),
  ]
  for event in events:
    _run(ledger.record(event))

  total = _run(ledger.get_total("alice"))
  assert total.input_tokens == 140
  assert total.output_tokens == 70
  assert total.cache_read_tokens == 14
  assert total.cache_creation_tokens == 7
  assert total.cost_usd == pytest.approx(0.175)
  assert total.event_count == 2

  metered = _run(ledger.get_total("alice", billing_mode="metered"))
  assert metered.input_tokens == 100
  assert metered.output_tokens == 50
  assert metered.event_count == 1

  ranged = _run(ledger.get_total("alice", since=150.0, until=250.0))
  assert ranged.input_tokens == 40
  assert ranged.output_tokens == 20
  assert ranged.event_count == 1

  model_filtered = _run(ledger.get_total("alice", model="claude-opus-4-6"))
  assert model_filtered.input_tokens == 40
  assert model_filtered.output_tokens == 20
  assert model_filtered.event_count == 1


def test_sqlite_usage_ledger_get_total_returns_zeros_when_empty(tmp_path: Path) -> None:
  ledger = SqliteUsageLedger(tmp_path / "usage.db")

  total = _run(ledger.get_total("nobody"))

  assert total.user_id == "nobody"
  assert total.input_tokens == 0
  assert total.output_tokens == 0
  assert total.cache_read_tokens == 0
  assert total.cache_creation_tokens == 0
  assert total.cost_usd == 0.0
  assert total.event_count == 0


def test_sqlite_usage_ledger_handles_concurrent_writes(tmp_path: Path) -> None:
  ledger = SqliteUsageLedger(tmp_path / "usage.db")

  def _write(index: int) -> None:
    _run(
      ledger.record(
        UsageEvent(
          user_id="alice",
          session_id=f"sess-{index}",
          request_id=f"req-{index}",
          parent_turn_id=None,
          timestamp=float(index),
          model="claude-sonnet-4-6",
          input_tokens=10,
          output_tokens=5,
          cache_read_tokens=1,
          cache_creation_tokens=0,
          cost_usd=0.01,
          rate_table_version="2026-04-08",
          billing_mode="metered",
          channel="web",
        )
      )
    )

  with ThreadPoolExecutor(max_workers=10) as executor:
    list(executor.map(_write, range(10)))

  total = _run(ledger.get_total("alice"))
  assert total.input_tokens == 100
  assert total.output_tokens == 50
  assert total.event_count == 10


def test_dlq_write_and_replay_round_trip(tmp_path: Path) -> None:
  ledger = SqliteUsageLedger(tmp_path / "usage.db")
  spool_path = tmp_path / "usage_dlq.jsonl"
  event = _event()

  write_dlq(event, spool_path)

  assert spool_path.exists()
  assert spool_path.read_text(encoding="utf-8").count("\n") == 1

  stats = _run(replay_dlq(ledger, spool_path))

  assert stats == {"total": 1, "replayed": 1, "failed": 0, "invalid": 0}
  assert not spool_path.exists()
  total = _run(ledger.get_total("alice"))
  assert total.event_count == 1


def test_dlq_spool_survives_as_file_on_disk(tmp_path: Path) -> None:
  spool_path = tmp_path / "nested" / "usage_dlq.jsonl"

  write_dlq(_event(), spool_path)

  assert spool_path.exists()
  line = spool_path.read_text(encoding="utf-8").strip()
  assert '"request_id": "req-1"' in line


def test_sqlite_usage_ledger_schema_migration_is_idempotent(tmp_path: Path) -> None:
  db_path = tmp_path / "usage.db"

  ledger_one = SqliteUsageLedger(db_path)
  ledger_one.close()

  ledger_two = SqliteUsageLedger(db_path)
  _run(ledger_two.record(_event()))

  with sqlite3.connect(db_path) as conn:
    count = conn.execute("SELECT COUNT(*) FROM usage_events").fetchone()[0]
    journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]

  assert count == 1
  assert str(journal_mode).lower() == "wal"
