import { GUARD_ACTION_TYPES } from "./guard-types";
import type {
  GuardActionEnvelope,
  GuardActionType,
  GuardApprovalRequest,
  GuardArtifactDiff,
  GuardInventoryItem,
  GuardPolicyDecision,
  GuardReceipt,
  GuardRuntimeSnapshot,
  GuardSettingsPayload,
  GuardSettings
} from "./guard-types";
import {
  getDemoDiff,
  getDemoPolicy,
  getDemoReceipts,
  getDemoRequest,
  getDemoRequests,
  isGuardDemoMode
} from "./guard-demo";

const GUARD_TOKEN_PARAM = "guard-token";
const GUARD_DAEMON_PARAM = "guardDaemon";

type RawGuardApprovalRequest = Omit<GuardApprovalRequest, "action_envelope_json"> & {
  action_envelope_json?: unknown;
};

type ApprovalRequestListPayload = {
  items?: RawGuardApprovalRequest[] | null;
};

type RuntimeSnapshotPayload = Omit<GuardRuntimeSnapshot, "items"> & {
  items?: RawGuardApprovalRequest[] | null;
};

async function readJson<T>(input: RequestInfo, init?: RequestInit): Promise<T> {
  const response = await fetch(guardApiInput(input), withGuardAuth(init));
  if (!response.ok) {
    throw new Error(`Request failed with ${response.status}`);
  }
  return (await response.json()) as T;
}

function guardParams(): URLSearchParams {
  const params = new URLSearchParams(window.location.search);
  const fragment = window.location.hash.startsWith("#") ? window.location.hash.slice(1) : window.location.hash;
  for (const [key, value] of new URLSearchParams(fragment)) {
    params.set(key, value);
  }
  return params;
}

function guardParam(name: string): string | null {
  return guardParams().get(name);
}

function readGuardToken(): string | null {
  const guardToken = guardParam(GUARD_TOKEN_PARAM);
  if (guardToken) {
    window.sessionStorage.setItem(GUARD_TOKEN_PARAM, guardToken);
    return guardToken;
  }
  return window.sessionStorage.getItem(GUARD_TOKEN_PARAM);
}

function readGuardDaemonOrigin(): string | null {
  const rawDaemonUrl = guardParam(GUARD_DAEMON_PARAM);
  if (rawDaemonUrl) {
    const daemonOrigin = localGuardDaemonOrigin(rawDaemonUrl);
    if (daemonOrigin) {
      window.sessionStorage.setItem(GUARD_DAEMON_PARAM, daemonOrigin);
      return daemonOrigin;
    }
  }
  const storedDaemonUrl = window.sessionStorage.getItem(GUARD_DAEMON_PARAM);
  return storedDaemonUrl ? localGuardDaemonOrigin(storedDaemonUrl) : null;
}

function localGuardDaemonOrigin(rawUrl: string): string | null {
  try {
    const url = new URL(rawUrl);
    if (url.protocol !== "http:" || !["127.0.0.1", "localhost", "[::1]", "::1"].includes(url.hostname)) {
      return null;
    }
    if (url.username || url.password || (url.pathname && url.pathname !== "/") || url.search || url.hash) {
      return null;
    }
    return url.origin;
  } catch {
    return null;
  }
}

function guardApiInput(input: RequestInfo): RequestInfo {
  const daemonOrigin = readGuardDaemonOrigin();
  if (!daemonOrigin || typeof input !== "string" || !input.startsWith("/")) {
    return input;
  }
  return `${daemonOrigin}${input}`;
}

function withGuardAuth(init?: RequestInit): RequestInit | undefined {
  const guardToken = readGuardToken();
  if (!guardToken) {
    return init;
  }
  const headers = new Headers(init?.headers);
  headers.set("X-Guard-Token", guardToken);
  return {
    ...init,
    headers
  };
}

function guardAuthHeaders(): HeadersInit {
  const guardToken = readGuardToken();
  return guardToken ? { "X-Guard-Token": guardToken } : {};
}

export function guardAwareHref(href: string): string {
  const guardToken = readGuardToken();
  if (!guardToken) {
    return href;
  }

  const url = new URL(href, window.location.origin);
  if (url.origin !== window.location.origin) {
    return href;
  }

  const fragmentPairs = [[GUARD_TOKEN_PARAM, guardToken]];
  const daemonOrigin = readGuardDaemonOrigin();
  if (daemonOrigin) {
    fragmentPairs.push([GUARD_DAEMON_PARAM, daemonOrigin]);
  }
  url.hash = new URLSearchParams(fragmentPairs).toString();
  if (href.startsWith("http://") || href.startsWith("https://")) {
    return url.toString();
  }
  return `${url.pathname}${url.search}${url.hash}`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isGuardActionType(value: unknown): value is GuardActionType {
  return typeof value === "string" && GUARD_ACTION_TYPES.some((actionType) => actionType === value);
}

function isStringOrNull(value: unknown): value is string | null {
  return value === null || typeof value === "string";
}

function isStringArray(value: unknown): value is string[] {
  return Array.isArray(value) && value.every((item): item is string => typeof item === "string");
}

export function parseActionEnvelope(raw: unknown): GuardActionEnvelope | null {
  if (!isRecord(raw)) {
    return null;
  }
  const schemaVersion = raw["schema_version"];
  const actionId = raw["action_id"];
  const harness = raw["harness"];
  const eventName = raw["event_name"];
  const actionType = raw["action_type"];
  const workspace = raw["workspace"];
  const workspaceHash = raw["workspace_hash"];
  const toolName = raw["tool_name"];
  const command = raw["command"];
  const promptExcerpt = raw["prompt_excerpt"];
  const targetPaths = raw["target_paths"];
  const networkHosts = raw["network_hosts"];
  const mcpServer = raw["mcp_server"];
  const mcpTool = raw["mcp_tool"];
  const packageManager = raw["package_manager"];
  const packageName = raw["package_name"];
  const scriptName = raw["script_name"];
  const rawPayloadRedacted = raw["raw_payload_redacted"];
  if (
    typeof schemaVersion !== "number" ||
    typeof actionId !== "string" ||
    typeof harness !== "string" ||
    typeof eventName !== "string" ||
    !isGuardActionType(actionType)
  ) {
    return null;
  }
  if (
    !isStringOrNull(workspace) ||
    !isStringOrNull(workspaceHash) ||
    !isStringOrNull(toolName) ||
    !isStringOrNull(command) ||
    !isStringOrNull(promptExcerpt) ||
    !isStringOrNull(mcpServer) ||
    !isStringOrNull(mcpTool) ||
    !isStringOrNull(packageManager) ||
    !isStringOrNull(packageName) ||
    !isStringOrNull(scriptName)
  ) {
    return null;
  }
  if (!isStringArray(targetPaths) || !isStringArray(networkHosts)) {
    return null;
  }
  if (!isRecord(rawPayloadRedacted)) {
    return null;
  }
  return {
    schema_version: schemaVersion,
    action_id: actionId,
    harness,
    event_name: eventName,
    action_type: actionType,
    workspace,
    workspace_hash: workspaceHash,
    tool_name: toolName,
    command,
    prompt_excerpt: promptExcerpt,
    target_paths: targetPaths,
    network_hosts: networkHosts,
    mcp_server: mcpServer,
    mcp_tool: mcpTool,
    package_manager: packageManager,
    package_name: packageName,
    script_name: scriptName,
    raw_payload_redacted: rawPayloadRedacted
  };
}

export function normalizeApprovalRequest(item: RawGuardApprovalRequest): GuardApprovalRequest {
  return { ...item, action_envelope_json: parseActionEnvelope(item.action_envelope_json) };
}

function normalizeApprovalRequests(items: RawGuardApprovalRequest[] | null | undefined): GuardApprovalRequest[] {
  if (!Array.isArray(items)) {
    return [];
  }
  return items.map(normalizeApprovalRequest);
}

export async function fetchRequests(): Promise<GuardApprovalRequest[]> {
  if (isGuardDemoMode()) {
    return getDemoRequests();
  }
  const payload = await readJson<ApprovalRequestListPayload>("/v1/requests");
  return normalizeApprovalRequests(payload.items);
}

export async function fetchRuntimeSnapshot(): Promise<GuardRuntimeSnapshot> {
  if (isGuardDemoMode()) {
    return buildDemoRuntimeSnapshot();
  }
  const snapshot = await readJson<RuntimeSnapshotPayload>("/v1/runtime");
  return { ...snapshot, items: normalizeApprovalRequests(snapshot.items) };
}

export function buildDemoRuntimeSnapshot(): GuardRuntimeSnapshot {
  const demoRequests = getDemoRequests();
  const demoReceipts = getDemoReceipts();
  const now = new Date().toISOString();
  const cloudState = "paired_waiting";
  const cloudLabel = "Connected";
  const cloudDetail =
    "This machine is connected to Guard Cloud, but the first shared proof has not landed yet. Open Watched Apps while the first sync settles.";
  const dashboardUrl = "https://hol.org/guard";
  const inboxUrl = "https://hol.org/guard/inbox";
  const fleetUrl = "https://hol.org/guard/fleet";
  const connectUrl = "https://hol.org/guard/connect";
  return {
    generated_at: now,
    approval_center_url: "http://127.0.0.1:4455",
    runtime_state: {
      session_id: "demo-runtime",
      daemon_host: "127.0.0.1",
      daemon_port: 4455,
      started_at: now,
      last_heartbeat_at: now,
      approval_center_url: "http://127.0.0.1:4455"
    },
    pending_count: demoRequests.length,
    receipt_count: demoReceipts.length,
    headline_state: demoRequests.length > 0 ? "blocked" : "connected",
    headline_label: demoRequests.length > 0 ? "Blocked" : "Connected",
    headline_detail:
      demoRequests.length > 0
        ? "A blocked action is waiting for review."
        : "This machine is connected to Guard Cloud and waiting for the first shared proof to appear.",
    sync_configured: true,
    cloud_state: cloudState,
    cloud_state_label: cloudLabel,
    cloud_state_detail: cloudDetail,
    cloud_pairing_state: {
      state: cloudState,
      label: cloudLabel,
      detail: cloudDetail,
      sync_configured: true,
      dashboard_url: dashboardUrl,
      inbox_url: inboxUrl,
      fleet_url: fleetUrl,
      connect_url: connectUrl
    },
    dashboard_url: dashboardUrl,
    inbox_url: inboxUrl,
    fleet_url: fleetUrl,
    connect_url: connectUrl,
    items: demoRequests,
    latest_receipts: demoReceipts.slice(0, 10)
  };
}

export async function fetchInventory(): Promise<GuardInventoryItem[]> {
  if (isGuardDemoMode()) {
    return [];
  }
  const payload = await readJson<{ items: GuardInventoryItem[] }>("/v1/inventory");
  return payload.items;
}

export async function fetchSettings(): Promise<GuardSettingsPayload> {
  if (isGuardDemoMode()) {
    return {
      guard_home: "~/.hol-guard",
      config_path: "~/.hol-guard/config.toml",
      settings: {
        mode: "prompt",
        security_level: "balanced",
        default_action: "warn",
        unknown_publisher_action: "review",
        changed_hash_action: "require-reapproval",
        new_network_domain_action: "warn",
        subprocess_action: "warn",
        risk_actions: {
          local_secret_read: "require-reapproval",
          credential_exfiltration: "require-reapproval",
          destructive_shell: "require-reapproval",
          encoded_execution: "require-reapproval",
          network_egress: "warn"
        },
        risk_action_overrides: {},
        harness_risk_actions: {
          codex: {}
        },
        approval_wait_timeout_seconds: 120,
        approval_surface_policy: "auto-open-once",
        telemetry: false,
        sync: true,
        billing: false
      }
    };
  }
  return readJson<GuardSettingsPayload>("/v1/settings");
}

export async function updateSettings(settings: Partial<GuardSettings>): Promise<GuardSettingsPayload> {
  if (isGuardDemoMode()) {
    const current = await fetchSettings();
    return { ...current, settings: { ...current.settings, ...settings } };
  }
  return readJson<GuardSettingsPayload>("/v1/settings", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...guardAuthHeaders()
    },
    body: JSON.stringify({ settings })
  });
}

export async function fetchRequest(requestId: string): Promise<GuardApprovalRequest> {
  if (isGuardDemoMode()) {
    return getDemoRequest(requestId);
  }
  const payload = await readJson<RawGuardApprovalRequest>(`/v1/requests/${requestId}`);
  return normalizeApprovalRequest(payload);
}

export async function fetchReceipts(): Promise<GuardReceipt[]> {
  if (isGuardDemoMode()) {
    return getDemoReceipts();
  }
  const payload = await readJson<{ items: GuardReceipt[] }>("/v1/receipts");
  return payload.items;
}

export async function fetchLatestReceipt(
  artifactId: string,
  harness: string
): Promise<GuardReceipt | null> {
  if (isGuardDemoMode()) {
    return getDemoReceipts().find((entry) => entry.artifact_id === artifactId) ?? null;
  }
  const response = await fetchGuardApi(
    `/v1/receipts/latest?harness=${encodeURIComponent(harness)}&artifact_id=${encodeURIComponent(artifactId)}`
  );
  if (response.status === 404) {
    return null;
  }
  if (!response.ok) {
    throw new Error(`Receipt request failed with ${response.status}`);
  }
  return (await response.json()) as GuardReceipt;
}

export async function fetchPolicy(harness: string): Promise<GuardPolicyDecision[]> {
  if (isGuardDemoMode()) {
    return getDemoPolicy(harness);
  }
  const payload = await readJson<{ items: GuardPolicyDecision[] }>(
    `/v1/policy?harness=${encodeURIComponent(harness)}`
  );
  return payload.items;
}

export async function fetchPolicies(): Promise<GuardPolicyDecision[]> {
  if (isGuardDemoMode()) {
    return getDemoPolicy("codex");
  }
  const payload = await readJson<{ items: GuardPolicyDecision[] }>("/v1/policy");
  return payload.items;
}

export async function clearPolicy(input: {
  harness?: string;
  all?: boolean;
  source?: string;
}): Promise<{ cleared: number; harness: string | null; source: string | null }> {
  if (isGuardDemoMode()) {
    return { cleared: 0, harness: input.harness ?? null, source: input.source ?? null };
  }
  return readJson<{ cleared: number; harness: string | null; source: string | null }>("/v1/policy/clear", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...guardAuthHeaders()
    },
    body: JSON.stringify({
      harness: input.harness,
      all: input.all ?? false,
      source: input.source
    })
  });
}

export async function fetchDiff(
  artifactId: string,
  harness: string
): Promise<GuardArtifactDiff | null> {
  if (isGuardDemoMode()) {
    return getDemoDiff(artifactId, harness);
  }
  const response = await fetchGuardApi(
    `/v1/artifacts/${encodeURIComponent(artifactId)}/diff?harness=${encodeURIComponent(harness)}`
  );
  if (response.status === 404) {
    return null;
  }
  if (!response.ok) {
    throw new Error(`Diff request failed with ${response.status}`);
  }
  return (await response.json()) as GuardArtifactDiff;
}

function fetchGuardApi(input: RequestInfo, init?: RequestInit): Promise<Response> {
  return fetch(guardApiInput(input), withGuardAuth(init));
}

export async function resolveRequest(input: {
  requestId: string;
  action: "allow" | "block";
  scope: string;
  workspace?: string;
  reason: string;
}): Promise<void> {
  if (isGuardDemoMode()) {
    return;
  }
  const actionPath = input.action === "allow" ? "approve" : "block";
  await readJson(`/v1/requests/${encodeURIComponent(input.requestId)}/${actionPath}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...guardAuthHeaders()
    },
    body: JSON.stringify({
      action: input.action,
      scope: input.scope,
      workspace: input.workspace || undefined,
      reason: input.reason || undefined
    })
  });
}
