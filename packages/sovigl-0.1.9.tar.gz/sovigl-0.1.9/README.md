# SOVIGL

Policy enforcement and audit layer for AI agents.

Every action your AI takes - governed before
it executes.
pip install sovigl

## What it does

SOVIGL sits between your AI agent and the
action it wants to take. Before anything
executes - payment, approval, data operation
- SOVIGL evaluates it against your policy
and returns one of three outcomes:

- APPROVED - executes immediately
- PENDING - held for human approval
- BLOCKED - stopped permanently

Every decision is permanently recorded with
a unique ID, plain English explanation, risk
score, and the exact policy version that
triggered it.

## Quick start

```python
import sovigl

sovigl.configure(api_key="your-key", org_id="your-org")

decision = sovigl.evaluate(
    action="payment.create",
    context={
        "amount": 5000,
        "role": "employee",
        "user_id": "user_123",
        "agent_id": "invoice_bot"
    }
)

print(decision.status)               # approved
print(decision.decision_id)          # permanent audit ID
print(decision.reason)               # why it was approved
print(decision.risk_assessment)      # risk score 0.0-1.0
print(decision.explanation_registry) # full explainability
print(decision.policy_version)       # which policy version
print(decision.approved)             # True
```

## Demo - no signup needed

Try it instantly with the demo org:

```python
import sovigl

# No configuration needed for demo
decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 5000}
)

print(decision.status)      # approved
print(decision.decision_id) # permanent ID
print(decision.reason)      # plain English reason
```

Live dashboard:
https://web-production-e334b.up.railway.app/dashboard

## Full response object

`evaluate()` returns a `Decision` object:

| Field | Type | Description |
|-------|------|-------------|
| `status` | string | approved / pending / blocked |
| `decision_id` | string | permanent immutable audit ID |
| `reason` | string | why this decision was made |
| `explanation_registry` | dict | full explainability record |
| `risk_assessment` | dict | risk score 0.0-1.0 + factors |
| `policy_version` | int | which policy version was active |
| `approval_id` | string | human approval reference |
| `summary` | string | plain English summary |
| `approved` | bool | True if status == approved |
| `pending` | bool | True if status == pending |
| `blocked` | bool | True if status == blocked |
| `raw` | dict | complete backend response |

## What makes it different

- **Pre-execution gate** - nothing executes
  without a decision. Not post-execution logging.

- **Policy versioning** - auditors know exactly
  which rule was active at decision time.

- **Business policy engine** - amount thresholds,
  role-based routing, mandate enforcement,
  fraud detection built in.

- **Compliance evidence** - every decision
  automatically satisfies EU AI Act Art.12/13/14,
  MAS FEAT, NIST AI RMF, RBI FREE-AI.

- **Fully hosted** - no self-hosting needed.
  Works in an afternoon.

## Context fields

| Field | Type | Description |
|-------|------|-------------|
| `amount` | number | Transaction amount |
| `role` | string | employee / manager / admin |
| `user_id` | string | Who is performing the action |
| `agent_id` | string | AI agent identifier |
| `description` | string | Optional note |

## Action types

Any string in dot notation:

- `payment.create`
- `expense.submit`
- `transfer.initiate`
- `loan.approve`
- `vendor.onboard`
- `data.export`

## Pending workflow

```python
decision = sovigl.evaluate(
    action="payment.create",
    context={"amount": 25000, "role": "employee"}
)

if decision.pending:
    # Route to human approver
    print(f"Approval required: {decision.approval_id}")
    print(f"Reason: {decision.reason}")
```

## Node.js

```javascript
const sovigl = require("./node/index.js");

const decision = await sovigl.evaluate({
    action: "payment.create",
    context: { amount: 5000, role: "employee" }
});

console.log(decision.status);      // approved
console.log(decision.decision_id); // permanent audit ID
console.log(decision.reason);      // why
```

## Production access

Email sovigl100@gmail.com to get your
org_id and api_key.

Free during beta. No credit card.
No commitment.

## Links

- Dashboard: https://web-production-e334b.up.railway.app/dashboard
- PyPI: https://pypi.org/project/sovigl/
- Backend: https://github.com/riteshkumar10000/sovigl-sdk
