from .client import evaluate, configure


class CheckDecision:
    def __init__(self, data):
        self.raw = data
        self.status = data.get("status", "blocked")
        self.allowed = self.status == "allowed"
        self.decision_id = data.get("decision_id", "")
        self.reason = data.get("reason", "")
        self.explanation = data.get("explanation")


def check(
    amount,
    agent_id=None,
    org_id=None,
    api_key=None,
    user_id="agent_user",
    role="employee",
    type="payment",
    description=None,
    decision_id=None
):
    import uuid

    context = {
        "amount": amount,
        "user_id": user_id,
        "role": role,
        "type": type,
        "agent_id": agent_id or "sdk_agent",
        "decision_id": decision_id or str(uuid.uuid4()),
    }
    if description:
        context["description"] = description

    result = evaluate(
        action=type,
        context=context,
        org_id=org_id,
        api_key=api_key
    )

    # evaluate() returns client.Decision; prefer backend raw payload if present.
    data = result.raw if hasattr(result, "raw") and isinstance(result.raw, dict) else {}
    if not data:
        data = {
            "status": "allowed" if getattr(result, "approved", False) else (
                "pending_approval" if getattr(result, "pending", False) else "blocked"
            ),
            "decision_id": getattr(result, "decision_id", ""),
            "reason": getattr(result, "reason", ""),
            "explanation": getattr(result, "summary", None),
        }

    if "explanation" not in data:
        data["explanation"] = data.get("summary") or data.get("explanation_registry")

    return CheckDecision(data)
