import requests
import uuid

_config = {
    "api_key": "demo_key_123",
    "org_id": "demo_fintech"
}


def configure(api_key: str, org_id: str):
    _config["api_key"] = api_key
    _config["org_id"] = org_id


def map_status(status):
    if status == "allowed":
        return "approved"
    if status == "pending_approval":
        return "pending"
    return status


class Decision:
    def __init__(self, data):
        self.raw = data
        self.status = map_status(data["status"])
        self.reason = data.get("reason")
        self.cdt = data.get("cdt")
        self.decision_id = data.get("decision_id")
        self.approval_id = data.get("approval_id")
        self.fraud = data.get("fraud")
        self.risk_assessment = data.get("risk_assessment")
        self.explanation_registry = data.get("explanation_registry")
        self.policy_version = data.get("policy_version")
        self.summary = data.get("summary")

    @property
    def approved(self):
        return self.status == "approved"

    @property
    def pending(self):
        return self.status == "pending"

    @property
    def blocked(self):
        return self.status == "blocked"


def evaluate(
    action: str,
    context: dict,
    org_id: str = None,
    api_key: str = None,
):
    api_key = api_key or _config["api_key"]
    org_id = org_id or _config["org_id"]

    payload = {
        "org_id": org_id,
        "type": action.split(".")[0],
        "amount": context["amount"],
        "role": context.get("role", "employee"),
        "user_id": context.get("user_id", "sdk_user"),
        "agent_id": context.get("agent_id", "sdk_client"),
        "agent_type": context.get("agent_type", "ai"),
        "decision_id": str(uuid.uuid4()),
    }
    if context.get("description"):
        payload["description"] = context["description"]
    elif context["amount"] > 10000:
        payload["description"] = "SDK transaction"

    headers = {"api-key": api_key, "Content-Type": "application/json"}

    response = requests.post(
        "https://web-production-e334b.up.railway.app/check",
        headers=headers,
        json=payload,
    )
    data = response.json()
    return Decision(data)
