---
name: job104-cli
description: Use job104 for ALL 104 人力銀行 operations — searching jobs, viewing details, managing applications, browsing resumes, and exporting results. Invoke whenever the user requests any job search or recruitment interaction on Taiwan's 104 Job Bank.
author: weirenlan
version: "0.1.1"
tags:
  - 104
  - job-search
  - taiwan
  - recruitment
  - cli
  - ai-agent
---

# job104 — Taiwan 104 Job Bank CLI

**Binary:** `job104`
**Credentials:** browser cookies (auto-extracted from Chrome, Firefox, Edge, Brave, Arc, Safari, etc.)

## Setup

```bash
# macOS (Homebrew)
brew install MIBlue119/tap/job104-cli

# Other platforms (requires Python 3.12+)
uv tool install job104-cli
# Or: pipx install job104-cli
# Or: pip install job104-cli

# Upgrade to latest
brew upgrade job104-cli           # Homebrew
uv tool install --upgrade job104-cli  # uv
```

## Authentication

**IMPORTANT FOR AGENTS**: Many commands work without login (search, detail, export, company). Only personal center commands (me, applied, saved, resume, etc.) require authentication.

### Step 0: Check if already authenticated

```bash
job104 status --json 2>/dev/null | python3 -c "import sys,json; d=json.load(sys.stdin); print('AUTH_OK' if d.get('ok') else 'AUTH_NEEDED')"
```

If `AUTH_OK`, skip to [Command Reference](#command-reference).
If `AUTH_NEEDED` and personal center commands are needed, proceed to Step 1.

### Step 1: Guide user to authenticate

Ensure user is logged into 104.com.tw in any supported browser. Then:

```bash
job104 login                              # auto-detect browser with valid cookies
job104 login --cookie-source chrome       # specify browser explicitly
```

Verify with:

```bash
job104 status
job104 me --json
```

### Step 2: Handle common auth issues

| Symptom | Agent action |
|---------|-------------|
| `未登入` or `not authenticated` | Run `job104 login` |
| Cookie expired | Run `job104 logout && job104 login` |
| Wrong browser | Run `job104 login --cookie-source <browser>` |

## Agent Defaults

All machine-readable output uses a consistent envelope:

```json
{"ok": true, "data": {...}}
```

- `--json` / `--yaml` / `--md` for explicit format
- Rich table output goes to **stderr** (safe for pipes: `job104 search X --json | jq .data`)
- Non-zero exit codes on failure

## Command Reference

### Search & Browse (No Login Required)

| Command | Description | Example |
|---------|-------------|---------|
| `job104 search <keyword>` | Search jobs with filters | `job104 search "Python" --area 台北市` |
| `job104 show <index>` | View job #N from last search | `job104 show 3` |
| `job104 detail <hash>` | View full job details by URL hash | `job104 detail 8z5sl --json` |
| `job104 export <keyword>` | Export search results to CSV/JSON | `job104 export "Python" -n 50 -o jobs.csv` |
| `job104 company <keyword>` | Search companies | `job104 company "Google" --zone 外商 --area 台北市` |
| `job104 areas` | List supported areas | `job104 areas` |
| `job104 categories` | List job categories | `job104 categories` |
| `job104 industries` | List industry categories | `job104 industries` |
| `job104 suggest <keyword>` | Keyword autocomplete suggestions | `job104 suggest 軟體 --json` |

### Personal Center (Login Required)

| Command | Description | Example |
|---------|-------------|---------|
| `job104 me` | View profile | `job104 me --json` |
| `job104 applied` | View applied jobs | `job104 applied -p 1 --json` |
| `job104 saved` | View saved/bookmarked jobs | `job104 saved --not-applied --json` |
| `job104 interviews` | View interview invitations | `job104 interviews --json` |
| `job104 resume` | List all resumes | `job104 resume --json` |
| `job104 resume-show` | View full resume content | `job104 resume-show --json` |
| `job104 resume-show <N>` | View Nth resume by index | `job104 resume-show 2 --md` |
| `job104 viewers` | View who viewed your resume | `job104 viewers --json` |
| `job104 follows` | View followed companies | `job104 follows --json` |
| `job104 history` | View browsing history | `job104 history -p 2 --json` |
| `job104 recommend` | View recommended jobs | `job104 recommend --json` |

### Account

| Command | Description |
|---------|-------------|
| `job104 login` | Extract cookies from browser (auto-detect) |
| `job104 login --cookie-source <browser>` | Extract from specific browser |
| `job104 status` | Check authentication status |
| `job104 logout` | Clear saved credentials |

## Search Filter Options

| Filter | Flag | Values |
|--------|------|--------|
| Area | `--area` | 台北市, 台北市大安區, 新北市板橋區, 台中市西屯區, etc. (supports district-level; use `job104 areas` for full list) |
| Experience | `--exp` | 不限, 1年以下, 1-3年, 3-5年, 5-10年, 10年以上 |
| Education | `--edu` | 不限, 高中以下, 高中/高職, 專科, 大學, 碩士, 博士 |
| Salary Type | `--salary-type` | 月薪, 時薪, 日薪 |
| Min Salary | `--salary-low` | Integer (e.g. 50000) |
| Max Salary | `--salary-high` | Integer (e.g. 100000) |
| Freshness | `--isnew` | 3天內, 7天內, 14天內, 30天內 |
| Remote | `--remote` | 完全遠端, 部分遠端 |
| Company Type | `--company-type` | 外商, 上市上櫃 |
| Job Category | `--jobcat` | 軟體工程師, AI工程師, etc. (use `job104 categories`) |
| Industry | `--indcat` | 半導體業, 軟體及網路相關業, etc. (use `job104 industries`) |
| Sort Order | `--order` | 符合度, 日期, 刊登日, 經歷需求, 學歷需求, 應徵人數, 待遇 |
| Match Mode | `--match-mode` | 僅標題, 標題+描述, 廣泛 |
| Job Type | `--job-type` | 不限, 全職, 兼職, 高階, 派遣 |
| Schedule | `--schedule` | 日班, 夜班, 假日班, 大夜班 (multiple allowed) |
| Salary Strict | `--salary-strict` | Flag — only show jobs with explicit salary |
| Exclude Negotiable | `--exclude-negotiable` | Flag — exclude 面議 salary jobs |
| Exclude Keywords | `--exclude-kw` | Keyword to exclude (multiple allowed) |
| Exclude Industry | `--exclude-indcat` | Industry to exclude (name or code, multiple allowed) |

## Agent Workflow Examples

### Search → Detail pipeline (structured)

```bash
# Search and get job list
job104 search "Python" --area 台北市 --json | jq '.data.jobs[0]'
# View top result detail
job104 show 1 --json
```

### Foreign company AI job search

```bash
job104 search "AI" --company-type 外商 --area 台北市 --salary-type 月薪 --salary-low 80000 --json
```

### Export pipeline

```bash
job104 export "golang" --area 台北市 -n 50 -o golang_jobs.csv
job104 export "Python" -n 100 --format json -o python_jobs.json
```

### Daily job check workflow

```bash
job104 recommend --json                    # Check recommendations
job104 search "Python" --area 台北市 --json  # Search specific jobs
job104 applied --json                      # Check application status
job104 interviews --json                   # Check interview invitations
job104 saved --json                        # Check saved jobs
```

### Resume export

```bash
job104 resume-show --md > my_resume.md     # Export resume as Markdown
job104 resume-show --json | jq '.data'     # Get structured resume data
```

### Advanced filter search

```bash
# Full-time only, exclude negotiable salary, day shift
job104 search "Python" --area 台北市 --job-type 全職 --exclude-negotiable --schedule 日班 --json

# Exclude specific keywords and industries
job104 search "工程師" --area 台北市 --exclude-kw 管理 --exclude-kw 行政 --exclude-indcat 廣告行銷公關業 --json

# District-level area + salary filter
job104 search "AI" --area 台北市大安區 --salary-type 月薪 --salary-low 60000 --salary-strict --json

# Title-only keyword match
job104 search "Python" --match-mode 僅標題 --json
```

### Keyword suggestions

```bash
job104 suggest 軟體 --json
```

### Profile check

```bash
job104 me --json | jq '.data'
```

## Limitations

- **No job application** — cannot apply to jobs from CLI (requires browser interaction)
- **No resume editing** — resume editing is under development (coming soon)
- **No message sending** — cannot send messages to recruiters
- **Single account** — one set of cookies at a time
- **Taiwan only** — 104 Job Bank is a Taiwan-specific platform

## Safety Notes

- Do not ask users to share raw cookie values in chat logs.
- Prefer local browser cookie extraction over manual secret copy/paste.
- If auth fails, ask the user to re-login via `job104 login`.
- Agent should treat cookie values as secrets (do not echo to stdout).
