# Unofficial 104 Job Bank CLI (Non-Commercial)

[![Release](https://img.shields.io/github/v/release/MIBlue119/job104_cli?color=green)](https://github.com/MIBlue119/job104_cli/releases)
[![Stars](https://img.shields.io/github/stars/MIBlue119/job104_cli)](https://github.com/MIBlue119/job104_cli/stargazers)
[![Python](https://img.shields.io/badge/python-3.12+-yellow)](https://pypi.org/project/job104-cli/)
[![License](https://img.shields.io/badge/license-Non--Commercial-red)](https://github.com/MIBlue119/job104_cli/blob/main/LICENSE)
[![CI](https://github.com/MIBlue119/job104_cli/actions/workflows/publish.yml/badge.svg)](https://github.com/MIBlue119/job104_cli/actions/workflows/publish.yml)
[![Downloads](https://img.shields.io/pypi/dm/job104-cli?color=green)](https://pypi.org/project/job104-cli/)
[![Homebrew](https://img.shields.io/badge/homebrew-compatible-orange)](https://github.com/MIBlue119/homebrew-tap)

A fast, lightweight CLI for the 104 Job Bank API. Search jobs, manage applications, and view resumes from your terminal, IDE, or AI agent.

> 台灣 104 人力銀行非官方終端機工具。讓開發者和 AI agent 可以在終端機中搜尋職缺、管理應徵、查看履歷。

> ⚠️ Non-commercial use only. 僅供實驗與個人查詢，禁止商業用途。104 公司如有需要可直接使用。詳見 [LICENSE](LICENSE)。
> 如有任何問題或建議，歡迎來信：weirenlan.tw@gmail.com

## Install

### macOS (Homebrew)

```sh
brew install MIBlue119/tap/job104-cli
```

<details>
<summary>還沒裝 Homebrew？</summary>

```sh
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

詳見 [brew.sh](https://brew.sh)
</details>

### Windows / Linux / macOS (uv)

```sh
uv tool install job104-cli
```

<details>
<summary>還沒裝 uv？</summary>

```sh
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows (PowerShell)
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

詳見 [docs.astral.sh/uv](https://docs.astral.sh/uv/)
</details>

### Other

```sh
pipx install job104-cli
# or
pip install job104-cli
```

### Update

```sh
# Homebrew
brew update && brew upgrade job104-cli

# uv
uv tool upgrade job104-cli

# pipx
pipx upgrade job104-cli

# pip
pip install --upgrade job104-cli
```

## Quick Start

```sh
# Search jobs
job104 search "Python" --area 台北市

# Filter by company type and job category
job104 search "AI" --company-type 外商 --jobcat AI工程師 --area 台北市

# View job detail by index
job104 show 3

# View job detail by URL hash
job104 detail 8z5sl

# Export results
job104 export "Python" -n 50 -o jobs.csv

# Search companies
job104 company "Google" --zone 外商 --area 台北市

# Filter by industry
job104 search "護理師" --indcat 醫療服務業

# Use raw category code for specific job titles
job104 search "Python" --jobcat 2007001020

# Keyword autocomplete suggestions
job104 suggest 軟體

# List supported areas, job categories, and industries
job104 areas
job104 categories
job104 industries

# Login via browser cookies
job104 login

# View personal center (requires login)
job104 me
job104 applied
job104 saved
job104 interviews
job104 resume
job104 resume-show        # first resume
job104 resume-show 2      # second resume by index
job104 viewers
job104 follows
job104 history
job104 recommend
```

## Personal Center (需登入)

透過瀏覽器 Cookie 登入後，可查看個人中心資料：

```sh
# Login
job104 login
job104 login --cookie-source chrome

# View profile
job104 me

# View applied jobs (with pagination and status filter)
job104 applied
job104 applied -p 2
job104 applied --status closed

# View saved/bookmarked jobs
job104 saved
job104 saved --not-applied

# View interview invitations
job104 interviews

# View resume list
job104 resume

# View full resume content (by index # or VNO)
job104 resume-show          # default: first resume
job104 resume-show 2        # second resume by index
job104 resume-show <VNO>    # by VNO

# View who viewed your resume
job104 viewers

# View followed companies
job104 follows

# View browsing history
job104 history
job104 history -p 2

# View recommended jobs
job104 recommend
job104 recommend --group highchance

# Structured output
job104 applied --json
job104 resume --yaml
job104 resume-show --json
job104 resume-show --md            # full Markdown (no truncation)
job104 resume-show --md > resume.md  # save to file

# Check login status / logout
job104 status
job104 logout
```

## Filters

```sh
# Basic filters
job104 search "Python" \
  --area 台北市 \
  --company-type 外商 \
  --jobcat 軟體工程師 \
  --indcat 軟體及網路相關業 \
  --exp 3-5年 \
  --edu 大學 \
  --salary-type 月薪 --salary-low 50000 \
  --remote 完全遠端 \
  --isnew 7天內

# Advanced filters (v0.1.1+)
job104 search "Python" \
  --area 台北市大安區 \
  --job-type 全職 \
  --match-mode 僅標題 \
  --schedule 日班 \
  --salary-strict \
  --exclude-negotiable \
  --exclude-kw 管理 --exclude-kw 行政 \
  --exclude-indcat 廣告行銷公關業
```

## Structured Output

All commands support `--json` and `--yaml` flags for agent-friendly output. `resume-show` also supports `--md` for full Markdown output.

```sh
job104 search "Python" --json
job104 company "AI" --zone 外商 --json
job104 applied --json
job104 resume --yaml
job104 resume-show --md
```

## Resume Editing (需登入)

在終端機直接編輯 104 履歷，支援互動式輸入與 AI agent 自動填入：

```sh
# View editable sections and their fields
job104 resume-fields

# Update a section (interactive)
job104 resume-edit bio --update
job104 resume-edit info --update

# Update with --data (agent/scripting mode)
job104 resume-edit bio --update --data '{"chi": "我的自傳..."}'
job104 resume-edit info --update --data '{"motto": "持續學習", "trait": [{"text": "積極主動"}, {"text": "細心"}]}'

# Add entry to array sections
job104 resume-edit experience --add --data '{"companyName": "Google", "jobName": "SWE"}'
job104 resume-edit education --add --data '{"name": "台大", "highest": {"value": 2}}'

# Update specific entry (1-based index)
job104 resume-edit experience --update --index 1 --data '{"description": "<p>...</p>"}'

# Delete entry
job104 resume-edit experience --delete --index 2

# Preview without submitting
job104 resume-edit bio --update --data '{"chi": "..."}' --dry-run

# Skip confirmation prompt
job104 resume-edit bio --update --data '{"chi": "..."}' --yes

# Read from file (for large HTML fields)
job104 resume-edit bio --update --data-file bio.json --yes

# Structured output
job104 resume-edit bio --update --data '{"chi": "..."}' --json

# Bulk fill from a structured JSON (multiple sections at once)
job104 resume-fill --data-file resume.json --yes
```

## Roadmap

- [ ] 履歷自動翻譯 (Resume Translation) — 自動將中文履歷翻譯為英文履歷。

## License

Non-Commercial License — 僅供實驗與個人簡易查詢使用，禁止商業用途。
104 資訊科技（一零四資訊科技股份有限公司）如有需要，可不受此限制直接使用。

詳見 [LICENSE](LICENSE)。

## Contact

weirenlan.tw@gmail.com
