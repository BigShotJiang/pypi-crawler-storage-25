"""Authentication for 104 Job Bank.

Strategy:
1. Try loading saved credential from ~/.config/104-cli/credential.json
2. Try extracting cookies from local browsers via browser-cookie3
3. Fallback: manual cookie file import
"""

from __future__ import annotations

import json
import logging
import subprocess
import sys
import time
from typing import Any

from .constants import BASE_URL, CONFIG_DIR, CREDENTIAL_FILE, HEADERS, SIGNIN_URL

logger = logging.getLogger(__name__)

# Credential TTL: attempt browser refresh after 7 days
CREDENTIAL_TTL_DAYS = 7
_CREDENTIAL_TTL_SECONDS = CREDENTIAL_TTL_DAYS * 86400


# -- Credential data class ---------------------------------------------------


class Credential:
    """Holds 104 Job Bank session cookies."""

    def __init__(self, cookies: dict[str, str]):
        self.cookies = cookies

    @property
    def is_valid(self) -> bool:
        return bool(self.cookies)

    def to_dict(self) -> dict[str, Any]:
        return {"cookies": self.cookies, "saved_at": time.time()}

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Credential:
        return cls(cookies=data.get("cookies", {}))

    def as_cookie_header(self) -> str:
        return "; ".join(f"{k}={v}" for k, v in self.cookies.items())


# -- Credential persistence --------------------------------------------------


def save_credential(credential: Credential) -> None:
    """Save credential to config file with restricted permissions."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CREDENTIAL_FILE.write_text(
        json.dumps(credential.to_dict(), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    CREDENTIAL_FILE.chmod(0o600)
    logger.info("Credential saved to %s", CREDENTIAL_FILE)


def load_credential() -> Credential | None:
    """Load credential from saved file with TTL-based auto-refresh.

    If saved cookies are older than 7 days, automatically attempt to
    refresh from the browser before falling back to stale cookies.
    """
    if not CREDENTIAL_FILE.exists():
        return None
    try:
        data = json.loads(CREDENTIAL_FILE.read_text(encoding="utf-8"))
        cred = Credential.from_dict(data)
        if not cred.is_valid:
            return None

        # Check TTL -- auto-refresh if stale
        saved_at = data.get("saved_at", 0)
        if saved_at and (time.time() - saved_at) > _CREDENTIAL_TTL_SECONDS:
            logger.info(
                "Credential older than %d days, attempting browser refresh",
                CREDENTIAL_TTL_DAYS,
            )
            fresh = extract_browser_credential()
            if fresh:
                logger.info("Auto-refreshed credential from browser")
                return fresh
            logger.warning(
                "Cookie refresh failed; using existing cookies (age: %d+ days)",
                CREDENTIAL_TTL_DAYS,
            )
        return cred
    except (json.JSONDecodeError, KeyError) as e:
        logger.warning("Failed to load saved credential: %s", e)
    return None


def clear_credential() -> None:
    """Remove saved credential file."""
    if CREDENTIAL_FILE.exists():
        CREDENTIAL_FILE.unlink()
        logger.info("Credential removed: %s", CREDENTIAL_FILE)


# -- Browser cookie extraction -----------------------------------------------


def extract_browser_credential(cookie_source: str | None = None) -> Credential | None:
    """Extract 104 cookies from local browsers via browser-cookie3.

    Runs cookie extraction in a subprocess to avoid import-time side effects
    and macOS Keychain permission issues in the main process.

    Args:
        cookie_source: Optional browser name (e.g., 'chrome', 'firefox', 'arc').
                       If None, tries all supported browsers in order.
    """
    extract_script = """
import json, sys
try:
    import browser_cookie3 as bc3
except ImportError:
    print(json.dumps({"error": "not_installed"}))
    sys.exit(0)

target = sys.argv[1] if len(sys.argv) > 1 else None

browsers = [
    ("Chrome", bc3.chrome),
    ("Firefox", bc3.firefox),
    ("Edge", bc3.edge),
    ("Brave", bc3.brave),
    ("Chromium", bc3.chromium),
    ("Opera", bc3.opera),
    ("Vivaldi", bc3.vivaldi),
]

# Try adding optional browsers (not all browser_cookie3 versions support these)
for name, attr in [("Arc", "arc"), ("Safari", "safari"), ("LibreWolf", "librewolf")]:
    fn = getattr(bc3, attr, None)
    if fn:
        browsers.append((name, fn))

if target:
    target_lower = target.lower()
    browsers = [(n, fn) for n, fn in browsers if n.lower() == target_lower]
    if not browsers:
        print(json.dumps({"error": f"unsupported_browser: {target}"}))
        sys.exit(0)

for name, loader in browsers:
    try:
        cj = loader(domain_name=".104.com.tw")
        cookies = {c.name: c.value for c in cj if "104.com.tw" in (c.domain or "")}
        if cookies:
            print(json.dumps({"browser": name, "cookies": cookies}))
            sys.exit(0)
    except Exception:
        pass

print(json.dumps({"error": "no_cookies"}))
"""

    try:
        cmd = [sys.executable, "-c", extract_script]
        if cookie_source:
            cmd.append(cookie_source)

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)

        if result.returncode != 0:
            logger.debug("Cookie extraction subprocess failed: %s", result.stderr)
            return None

        output = result.stdout.strip()
        if not output:
            return None

        data = json.loads(output)
        if "error" in data:
            if data["error"] == "not_installed":
                logger.debug("browser-cookie3 not installed, skipping")
            else:
                logger.debug("No valid 104 cookies found: %s", data["error"])
            return None

        cookies = data["cookies"]
        browser_name = data["browser"]
        cred = Credential(cookies=cookies)
        logger.info("Found cookies in %s (%d cookies)", browser_name, len(cookies))
        save_credential(cred)
        return cred

    except subprocess.TimeoutExpired:
        logger.warning("Cookie extraction timed out (browser may be running)")
        return None
    except (json.JSONDecodeError, KeyError) as e:
        logger.warning("Cookie extraction parse error: %s", e)
        return None


def load_cookie_file(path: str) -> Credential | None:
    """Load cookies from a JSON file (manual import).

    Expected format: {"cookie_name": "cookie_value", ...}
    or Netscape cookie jar format (one cookie per line).
    """
    try:
        with open(path, encoding="utf-8") as f:
            content = f.read().strip()

        # Try JSON first
        if content.startswith("{"):
            cookies = json.loads(content)
            if not isinstance(cookies, dict):
                logger.warning("Cookie file must contain a JSON object")
                return None
            cred = Credential(cookies={str(k): str(v) for k, v in cookies.items()})
            if cred.is_valid:
                save_credential(cred)
                return cred
            return None

        # Try Netscape cookie jar format (tab-separated)
        cookies: dict[str, str] = {}
        for line in content.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split("\t")
            if len(parts) >= 7 and "104.com.tw" in parts[0]:
                cookies[parts[5]] = parts[6]

        if cookies:
            cred = Credential(cookies=cookies)
            save_credential(cred)
            return cred

        logger.warning("No valid cookies found in file: %s", path)
        return None

    except FileNotFoundError:
        logger.warning("Cookie file not found: %s", path)
        return None
    except (json.JSONDecodeError, ValueError) as e:
        logger.warning("Cookie file parse error: %s", e)
        return None


# -- Credential verification -------------------------------------------------

# Session cookie groups (old-style and new Ory Hydra style).
# At least one cookie from ANY group must be present.
_SESSION_COOKIE_GROUPS = [
    {"JBCLOGIN"},  # Legacy auth
    {"JBCSESS"},  # New Ory Hydra auth
    {"signin_session"},  # Ory Hydra SSO session
]

# Endpoints to probe for authenticated access (tried in order).
# Each tuple: (base_url, path, referer)
_VERIFY_ENDPOINTS = [
    ("https://pda.104.com.tw", "/api/user", f"{BASE_URL}/"),
    (BASE_URL, "/apis/my/profile", f"{BASE_URL}/my/104profile/"),
]


def _has_session_cookie(cookies: dict[str, str]) -> bool:
    """Check that at least one known session cookie exists."""
    names = set(cookies)
    return any(group & names for group in _SESSION_COOKIE_GROUPS)


def verify_credential(credential: Credential) -> tuple[bool, str | None]:
    """Verify that the credential can access an authenticated 104 API.

    Strategy:
    1. Check that at least one session cookie is present.
    2. Probe known API endpoints for an authenticated JSON response.
    3. If probes are inconclusive but session cookies exist, accept them
       optimistically — actual operations will fail gracefully if expired.

    Returns (authenticated: bool, reason: str | None).
    """
    import httpx

    # Step 1: Check session cookies exist
    if not _has_session_cookie(credential.cookies):
        return False, (
            "缺少登入 Session Cookie（JBCLOGIN / JBCSESS / signin_session 均不存在）\n請先在瀏覽器登入 https://www.104.com.tw 再重試"
        )

    # Step 2: Probe API endpoints
    try:
        for base, path, referer in _VERIFY_ENDPOINTS:
            try:
                with httpx.Client(
                    base_url=base,
                    headers=dict(HEADERS),
                    cookies=credential.cookies,
                    follow_redirects=False,
                    timeout=httpx.Timeout(10),
                ) as client:
                    resp = client.get(path, headers={"Referer": referer})

                    # Skip endpoints that redirect or no longer exist
                    if resp.status_code in (301, 302, 404):
                        logger.debug("Verify endpoint %s%s -> %d, skipping", base, path, resp.status_code)
                        continue

                    if resp.status_code == 200:
                        ct = resp.headers.get("content-type", "")
                        if "json" not in ct:
                            continue
                        try:
                            data = resp.json()
                        except Exception:
                            continue
                        payload = data.get("data")
                        if payload and payload != []:
                            return True, None
                        if data.get("status") == "success":
                            return True, None

                    # 401 means endpoint works but session invalid
                    if resp.status_code == 401:
                        logger.debug("Verify endpoint %s%s -> 401 (unauthorized)", base, path)
                        continue

            except (httpx.HTTPError, OSError):
                logger.debug("Verify endpoint %s%s network error, skipping", base, path)
                continue

    except Exception as e:
        logger.debug("Verification error: %s", e)

    # Step 3: All probes were inconclusive (404 / unreachable / 401).
    # Accept cookies optimistically if session cookies exist — 104's
    # verification endpoints are unreliable (change frequently).
    return True, None


# -- Unified get_credential --------------------------------------------------


def get_credential() -> Credential | None:
    """Try all auth methods and return credential.

    1. Saved credential file
    2. Browser cookie extraction
    """
    cred = load_credential()
    if cred:
        logger.info("Loaded credential from %s", CREDENTIAL_FILE)
        return cred

    cred = extract_browser_credential()
    if cred:
        logger.info("Extracted credential from browser")
        return cred

    return None


# -- Browser login flow (open browser + poll) --------------------------------


def browser_login_flow(
    url: str = SIGNIN_URL,
    timeout: int = 120,
    poll_interval: int = 3,
) -> Credential | None:
    """Open 104 sign-in page in browser and poll until session cookies appear.

    Strategy:
    1. webbrowser.open(url) to launch the sign-in page
    2. Poll extract_browser_credential() every poll_interval seconds
    3. Return credential as soon as a valid session cookie is found
    4. Return None after timeout seconds

    Headless / non-tty guard: prints the URL and returns None immediately if
    sys.stdin is not a tty (CI/CD, pipe, agent-driven contexts).

    Handles KeyboardInterrupt gracefully — returns any credential found so far.
    """
    import webbrowser

    if not sys.stdin.isatty():
        logger.info("Non-tty environment: skipping browser login flow")
        return None

    logger.info("Opening browser login: %s", url)
    webbrowser.open(url)

    deadline = time.time() + timeout
    cred: Credential | None = None
    try:
        while time.time() < deadline:
            time.sleep(poll_interval)
            candidate = extract_browser_credential()
            if candidate and _has_session_cookie(candidate.cookies):
                save_credential(candidate)
                logger.info("Browser login succeeded (%d cookies)", len(candidate.cookies))
                return candidate
    except KeyboardInterrupt:
        logger.debug("Browser login flow interrupted by user")

    return cred
