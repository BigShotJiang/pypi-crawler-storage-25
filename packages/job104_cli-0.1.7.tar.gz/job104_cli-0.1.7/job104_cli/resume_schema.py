"""Resume section schemas for 104 PDA API.

Defines field metadata for each resume section, used for:
- Field validation before submission
- Interactive prompts for resume-edit
- Field mapping for resume-fill (agent auto-fill)
- resume-fields command output
"""

from __future__ import annotations

from typing import Any


# -- Field types ---------------------------------------------------------------

FIELD_TYPES = {
    "text": "文字",
    "number": "數字",
    "select": "下拉選單",
    "multiselect": "多選",
    "date": "日期",
    "html": "HTML 文字",
    "bool": "布林",
    "array": "陣列",
    "autocomplete": "自動完成",
}


# -- Section schemas -----------------------------------------------------------
# Each section defines:
#   "fields": dict of field_name -> {type, label, required, options_key?, ac_type?, max_length?}
#   "array": bool — whether this section holds a list of entries
#   "operations": list of supported operations (all use PUT under the hood)
#   "payload_key": for single sections, the key within formData that holds the data
#   "array_key": for array sections, the key within formData that holds the entries array


SECTION_SCHEMAS: dict[str, dict[str, Any]] = {
    "info": {
        "label": "基本資料",
        "array": False,
        "operations": ["PUT"],
        "payload_key": "info",
        "fields": {
            "jobStatus": {"type": "select", "label": "就業狀態", "required": True, "options_key": "optionsJobStatus"},
            "birthYear": {"type": "number", "label": "出生年份", "required": False, "max_length": 4},
            "birthMonth": {"type": "select", "label": "出生月份", "required": False},
            "birthDate": {"type": "select", "label": "出生日", "required": False},
            "military": {"type": "select", "label": "兵役狀態", "required": False, "options_key": "optionsMilitary"},
            "cellphone": {"type": "text", "label": "手機號碼", "required": False, "max_length": 15},
            "city": {"type": "select", "label": "居住地區", "required": False},
            "street": {"type": "text", "label": "地址", "required": False, "max_length": 102},
            "bio": {"type": "text", "label": "個人簡介", "required": False, "max_length": 1000},
            "motto": {"type": "text", "label": "個人格言", "required": False, "max_length": 100},
            "traits": {"type": "array", "label": "個人特色", "required": False, "max_items": 6, "item_max_length": 20},
        },
    },
    "bio": {
        "label": "自傳",
        "array": False,
        "operations": ["PUT"],
        "payload_key": "bio",
        "fields": {
            "chi": {"type": "html", "label": "中文自傳", "required": False, "max_length": 4000},
            "eng": {"type": "html", "label": "英文自傳", "required": False, "max_length": 8000},
        },
    },
    "education": {
        "label": "學歷",
        "array": True,
        "operations": ["PUT"],
        "array_key": "educations",
        "max_entries": 3,
        "fields": {
            "name": {"type": "autocomplete", "label": "學校名稱", "required": True, "ac_type": "school"},
            "departments": {"type": "array", "label": "科系", "required": True},
            "highest": {"type": "select", "label": "學歷等級", "required": True, "options_key": "optionsEducation"},
            "duration": {"type": "date", "label": "就讀期間", "required": True},
            "status": {"type": "select", "label": "畢業狀態", "required": True, "options_key": "optionsEducationStatus"},
            "region": {"type": "select", "label": "地區", "required": True, "options_key": "optionsRegion"},
            "inSchoolStatus": {"type": "select", "label": "在學狀態", "required": False, "options_key": "optionsInSchoolStatus"},
            "sort": {"type": "number", "label": "排序", "required": False},
        },
    },
    "experience": {
        "label": "工作經歷",
        "array": True,
        "operations": ["PUT"],
        "array_key": "experiences",
        "max_entries": 20,
        "fields": {
            "companyName": {"type": "autocomplete", "label": "公司名稱", "required": True, "ac_type": "company"},
            "industry": {"type": "multiselect", "label": "產業", "required": False},
            "companyScale": {"type": "select", "label": "公司規模", "required": False, "options_key": "optionsCompanyScale"},
            "jobName": {"type": "autocomplete", "label": "職稱", "required": True, "ac_type": "jobTitle"},
            "workArea": {"type": "multiselect", "label": "工作地點", "required": False},
            "jobType": {"type": "select", "label": "工作性質", "required": False, "options_key": "optionsJobType"},
            "jobCat": {"type": "multiselect", "label": "職務類別", "required": False},
            "duration": {"type": "date", "label": "工作期間", "required": True},
            "stillWork": {"type": "bool", "label": "仍在職", "required": False},
            "description": {"type": "html", "label": "工作內容", "required": False},
            "skill": {"type": "multiselect", "label": "使用技能", "required": False},
            "management": {"type": "select", "label": "管理人數", "required": False, "options_key": "optionsManagement"},
            "salary": {"type": "select", "label": "薪資", "required": False},
            "companyVisibility": {"type": "bool", "label": "公司可見", "required": False},
            "salaryVisibility": {"type": "bool", "label": "薪資可見", "required": False},
            "sort": {"type": "number", "label": "排序", "required": False},
        },
    },
    "jobCondition": {
        "label": "求職條件",
        "array": False,
        "operations": ["PUT"],
        "payload_key": "jobCondition",
        "fields": {
            "jobTimeType": {"type": "multiselect", "label": "工作型態", "required": False, "options_key": "optionsJobTimeType"},
            "jobTimePeriod": {"type": "multiselect", "label": "上班時段", "required": False, "options_key": "optionsJobTimePeriod"},
            "onBoardDate": {"type": "select", "label": "可上班日", "required": False, "options_key": "optionsJobOnBoardDate"},
            "salary": {"type": "select", "label": "期望薪資", "required": False, "options_key": "optionsJobSalary"},
            "salaryPeriod": {"type": "select", "label": "薪資類型", "required": False, "options_key": "optionsJobSalaryPeriod"},
            "preferArea": {"type": "multiselect", "label": "希望工作地點", "required": False},
            "preferJobTitle": {"type": "text", "label": "希望職稱", "required": False},
            "preferJobType": {"type": "multiselect", "label": "希望職務類別", "required": False},
            "remoteWork": {"type": "select", "label": "遠端工作", "required": False, "options_key": "optionsRemoteWork"},
        },
    },
    "skill": {
        "label": "技能",
        "array": True,
        "operations": ["PUT"],
        "array_key": "skills",
        "fields": {
            "name": {"type": "text", "label": "技能分類名稱", "required": True},
            "desc": {"type": "text", "label": "技能描述", "required": False},
            "tag": {"type": "multiselect", "label": "技能標籤", "required": False, "ac_type": "skill"},
            "sort": {"type": "number", "label": "排序", "required": False},
        },
    },
    "certificate": {
        "label": "證照",
        "array": False,
        "operations": ["PUT"],
        "payload_key": "certificate",
        "fields": {
            "certificates": {"type": "array", "label": "正式證照", "required": False},
            "others": {"type": "text", "label": "其他證照", "required": False},
        },
    },
    "language": {
        "label": "語言能力",
        "array": False,
        "operations": ["PUT"],
        "payload_key": "languages",
        "fields": {
            "foreign": {"type": "array", "label": "外語", "required": False},
            "local": {"type": "array", "label": "方言", "required": False},
        },
    },
    "project": {
        "label": "專案作品",
        "array": True,
        "operations": ["PUT"],
        "array_key": "projects",
        "fields": {
            "name": {"type": "text", "label": "專案名稱", "required": True},
            "duration": {"type": "date", "label": "專案期間", "required": False},
            "isInProgress": {"type": "bool", "label": "進行中", "required": False},
            "introduction": {"type": "html", "label": "專案介紹", "required": False},
            "url": {"type": "text", "label": "連結", "required": False},
            "sort": {"type": "number", "label": "排序", "required": False},
        },
    },
    "portfolio": {
        "label": "作品集",
        "array": True,
        "operations": ["PUT"],
        "array_key": "portfolios",
        "fields": {
            "name": {"type": "text", "label": "作品名稱", "required": True},
            "attach": {"type": "text", "label": "附件", "required": False},
            "attachType": {"type": "select", "label": "附件類型", "required": False, "options_key": "optionsAttachFileType"},
            "sort": {"type": "number", "label": "排序", "required": False},
        },
    },
    "referrer": {
        "label": "推薦人",
        "array": True,
        "operations": ["PUT"],
        "array_key": "referrers",
        "max_entries": 2,
        "fields": {
            "name": {"type": "text", "label": "姓名", "required": True, "max_length": 30},
            "company": {"type": "text", "label": "服務單位", "required": False, "max_length": 35},
            "position": {"type": "text", "label": "職銜", "required": False, "max_length": 20},
            "email": {"type": "text", "label": "信箱", "required": False, "max_length": 50},
            "tel": {"type": "text", "label": "電話", "required": False, "max_length": 50},
        },
    },
    "custom1": {
        "label": "自訂內容 1",
        "array": True,
        "operations": ["PUT"],
        "array_key": "content",
        "max_entries": 6,
        "fields": {
            "sectionName": {"type": "text", "label": "區塊標題", "required": False, "max_length": 120},
            "introduction": {"type": "html", "label": "內容說明", "required": False, "max_length": 2000},
            "duration": {"type": "date", "label": "期間", "required": False},
            "isInProgress": {"type": "bool", "label": "進行中", "required": False},
            "url": {"type": "text", "label": "連結", "required": False, "max_length": 200},
        },
    },
    "custom2": {
        "label": "自訂內容 2",
        "array": True,
        "operations": ["PUT"],
        "array_key": "content",
        "max_entries": 6,
        "fields": {
            "sectionName": {"type": "text", "label": "區塊標題", "required": False, "max_length": 120},
            "introduction": {"type": "html", "label": "內容說明", "required": False, "max_length": 2000},
            "duration": {"type": "date", "label": "期間", "required": False},
            "isInProgress": {"type": "bool", "label": "進行中", "required": False},
            "url": {"type": "text", "label": "連結", "required": False, "max_length": 200},
        },
    },
    "custom3": {
        "label": "自訂內容 3",
        "array": True,
        "operations": ["PUT"],
        "array_key": "content",
        "max_entries": 6,
        "fields": {
            "sectionName": {"type": "text", "label": "區塊標題", "required": False, "max_length": 120},
            "introduction": {"type": "html", "label": "內容說明", "required": False, "max_length": 2000},
            "duration": {"type": "date", "label": "期間", "required": False},
            "isInProgress": {"type": "bool", "label": "進行中", "required": False},
            "url": {"type": "text", "label": "連結", "required": False, "max_length": 200},
        },
    },
}


def get_section_schema(section: str) -> dict[str, Any] | None:
    """Get schema for a resume section."""
    return SECTION_SCHEMAS.get(section)


def list_sections() -> list[dict[str, str]]:
    """List all supported resume sections with labels."""
    return [
        {"name": name, "label": schema["label"], "array": schema["array"], "operations": schema["operations"]}
        for name, schema in SECTION_SCHEMAS.items()
    ]
