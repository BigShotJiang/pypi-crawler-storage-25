"""job104 CLI — 台灣 104 人力銀行終端機工具。"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("job104-cli")
except PackageNotFoundError:
    # Running from source without an editable install
    __version__ = "0.0.0+local"
