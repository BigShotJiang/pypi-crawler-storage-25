"""Search result index cache for short-index navigation.

Stores the last search result set so that users can quickly
access a job by its 1-based index number (e.g., `job104 show 3`).

Cache file: ~/.config/104-cli/index_cache.json
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from .constants import CONFIG_DIR

logger = logging.getLogger(__name__)

INDEX_CACHE_FILE = CONFIG_DIR / "index_cache.json"


def _extract_job_id(job: dict[str, Any]) -> str:
    """Extract the URL hash ID from a job's link field (e.g. '8z5sl')."""
    link = job.get("link", {})
    job_url = link.get("job", "") if isinstance(link, dict) else ""
    if job_url:
        return job_url.rstrip("/").split("/")[-1]
    return ""


def save_index(jobs: list[dict[str, Any]], source: str = "search") -> None:
    """Persist an ordered list of jobs for short-index navigation."""
    if not jobs:
        return

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    entries = []
    for job in jobs:
        job_id = _extract_job_id(job)
        job_no = str(job.get("jobNo", ""))
        # Need at least one identifier
        if not job_id and not job_no:
            continue
        entry = {
            "jobId": job_id,
            "jobNo": job_no,
            "jobName": job.get("jobName", ""),
            "custName": job.get("custName", ""),
            "salaryLow": job.get("salaryLow", 0),
            "salaryHigh": job.get("salaryHigh", 0),
            "jobAddrNoDesc": job.get("jobAddrNoDesc", ""),
            "optionEdu": job.get("optionEdu", []),
            "optionExp": job.get("optionExp", ""),
            "tags": job.get("tags", {}),
        }
        entries.append(entry)

    payload = {
        "source": source,
        "saved_at": time.time(),
        "count": len(entries),
        "items": entries,
    }

    INDEX_CACHE_FILE.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
    INDEX_CACHE_FILE.chmod(0o600)
    logger.debug("Saved index cache with %d entries from %s", len(entries), source)


def get_job_by_index(index: int) -> dict[str, Any] | None:
    """Resolve a 1-based short index to a cached job reference."""
    if index <= 0:
        return None

    if not INDEX_CACHE_FILE.exists():
        return None

    try:
        data = json.loads(INDEX_CACHE_FILE.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    items = data.get("items", [])
    if index > len(items):
        return None

    return items[index - 1]


def get_index_info() -> dict[str, Any]:
    """Get metadata about the current index cache."""
    if not INDEX_CACHE_FILE.exists():
        return {"exists": False, "count": 0}

    try:
        data = json.loads(INDEX_CACHE_FILE.read_text(encoding="utf-8"))
        return {
            "exists": True,
            "source": data.get("source", "unknown"),
            "count": data.get("count", 0),
            "saved_at": data.get("saved_at", 0),
        }
    except (OSError, json.JSONDecodeError):
        return {"exists": False, "count": 0}
