"""Tests for personal center commands: applied, saved, interviews, resume, viewers, follows, history, recommend."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from job104_cli.cli import cli
from job104_cli.client import Job104Client


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def _mock_credential():
    """Create a mock credential object."""
    cred = MagicMock()
    cred.cookies = {"ac": "test_ac", "user": "test_user"}
    return cred


def _mock_http_response(json_data: dict):
    """Create a mock HTTP response."""
    import json

    resp = MagicMock()
    resp.status_code = 200
    resp.text = json.dumps(json_data)
    resp.json.return_value = json_data
    resp.cookies = {}
    return resp


def _patch_auth_and_client(json_data: dict):
    """Context manager to mock auth + client for personal commands."""
    cred = _mock_credential()
    mock_response = _mock_http_response(json_data)

    return (
        patch("job104_cli.commands.personal.require_auth", return_value=cred),
        patch.object(
            Job104Client,
            "_build_client",
            return_value=MagicMock(
                request=MagicMock(return_value=mock_response),
                cookies=MagicMock(),
                get=MagicMock(return_value=mock_response),
            ),
        ),
    )


# -- Help tests --------------------------------------------------------------


class TestPersonalHelp:
    @pytest.mark.parametrize(
        "cmd",
        [
            "applied",
            "saved",
            "interviews",
            "resume",
            "resume-show",
            "viewers",
            "follows",
            "history",
            "recommend",
        ],
    )
    def test_help_exits_cleanly(self, runner: CliRunner, cmd: str) -> None:
        result = runner.invoke(cli, [cmd, "--help"])
        assert result.exit_code == 0, f"Failed for {cmd}: {result.output}"


# -- Auth required tests -----------------------------------------------------


class TestAuthRequired:
    @pytest.mark.parametrize(
        "cmd",
        [
            "applied",
            "saved",
            "interviews",
            "resume",
            "resume-show",
            "viewers",
            "follows",
            "history",
            "recommend",
        ],
    )
    def test_no_auth_shows_error(self, runner: CliRunner, cmd: str) -> None:
        with patch("job104_cli.auth.get_credential", return_value=None):
            result = runner.invoke(cli, [cmd])
            assert result.exit_code == 1


# -- Applied command tests ---------------------------------------------------


class TestAppliedCommand:
    def test_applied_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "jobName": "軟體工程師",
                    "custName": "台積電",
                    "salaryDesc": "面議",
                    "status": "已讀",
                    "applyDate": "2026/03/01",
                }
            ],
            "totalCount": 1,
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["applied", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_applied_with_page(self, runner: CliRunner) -> None:
        data = {"data": [], "totalCount": 0}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["applied", "-p", "2", "--json"])
            assert result.exit_code == 0

    def test_applied_with_status_filter(self, runner: CliRunner) -> None:
        data = {"data": [], "totalCount": 0}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["applied", "--status", "closed", "--json"])
            assert result.exit_code == 0

    def test_applied_empty_result(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["applied"])
            assert result.exit_code == 0


# -- Saved command tests -----------------------------------------------------


class TestSavedCommand:
    def test_saved_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "jobName": "前端工程師",
                    "custName": "Google",
                    "salaryDesc": "80,000 ~ 150,000",
                    "jobAddrNoDesc": "台北市信義區",
                    "saveDate": "2026/03/10",
                }
            ],
            "totalCount": 1,
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["saved", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_saved_not_applied_filter(self, runner: CliRunner) -> None:
        data = {"data": [], "totalCount": 0}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["saved", "--not-applied", "--json"])
            assert result.exit_code == 0

    def test_saved_empty_result(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["saved"])
            assert result.exit_code == 0


# -- Interviews command tests ------------------------------------------------


class TestInterviewsCommand:
    def test_interviews_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "jobName": "後端工程師",
                    "custName": "Meta",
                    "interviewDate": "2026/03/20 14:00",
                    "address": "台北市內湖區",
                    "status": "待回覆",
                }
            ],
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["interviews", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_interviews_empty(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["interviews"])
            assert result.exit_code == 0


# -- Resume command tests ----------------------------------------------------


class TestResumeCommand:
    def test_resume_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": {
                "formData": {
                    "overview": [
                        {
                            "versionNo": "abc123",
                            "vno": "abc123",
                            "title": "第一份履歷表",
                            "resumeType": {"text": "一般履歷", "value": 1},
                            "lastModified": 1772373370,
                            "publicStatus": {"text": "開放中", "value": 2},
                            "isCompleted": True,
                            "resumeHash": "xyz",
                        }
                    ]
                }
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_resume_rich_render(self, runner: CliRunner) -> None:
        data = {
            "data": {
                "formData": {
                    "overview": [
                        {
                            "versionNo": "abc123",
                            "vno": "abc123",
                            "title": "第一份履歷表",
                            "resumeType": {"text": "一般履歷", "value": 1},
                            "lastModified": 1772373370,
                            "publicStatus": {"text": "開放中", "value": 2},
                            "isCompleted": True,
                        }
                    ]
                }
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume"])
            assert result.exit_code == 0

    def test_resume_empty_overview(self, runner: CliRunner) -> None:
        data = {"data": {"formData": {"overview": []}}}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume"])
            assert result.exit_code == 0


# -- Resume-show command tests -----------------------------------------------


class TestResumeShowCommand:
    def test_resume_show_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": {
                "progress": 100,
                "resume": {"name": "第一份履歷表", "vno": "abc123"},
                "info": {"formData": {"info": {"age": 30, "city": "台北市"}}},
                "experience": {
                    "formData": {
                        "experiences": [
                            {
                                "companyName": "Test Corp",
                                "jobName": "工程師",
                                "duration": {"startYear": 2020, "startMonth": 1},
                                "stillWork": True,
                                "description": "寫程式",
                            },
                        ]
                    }
                },
                "education": {
                    "formData": {
                        "educations": [
                            {
                                "name": "台灣大學",
                                "departments": [{"name": "資工系"}],
                                "highest": {"text": "碩士"},
                                "duration": {"startYear": 2015, "endYear": 2017},
                                "status": {"text": "畢業"},
                            },
                        ]
                    }
                },
                "skill": {"formData": {"skills": []}},
                "certificate": {"formData": {"certificate": []}},
                "language": {"formData": {"languages": []}},
                "bio": {"formData": {"bio": ""}},
                "jobCondition": {"formData": {"jobCondition": {}}},
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume-show", "abc123", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_resume_show_rich_render(self, runner: CliRunner) -> None:
        data = {
            "data": {
                "progress": 100,
                "resume": {"name": "第一份履歷表", "vno": "abc123"},
                "info": {
                    "formData": {
                        "info": {
                            "age": 30,
                            "city": "台北市",
                            "cellphone": "0912345678",
                            "jobStatus": "在職中",
                            "motto": "努力學習",
                        }
                    }
                },
                "experience": {
                    "formData": {
                        "experiences": [
                            {
                                "companyName": "Test Corp",
                                "jobName": "工程師",
                                "duration": {"startYear": 2020, "startMonth": 1, "endYear": 2023, "endMonth": 6},
                                "stillWork": False,
                                "description": "寫程式",
                            },
                        ],
                        "seniority": {"total": {"year": 3, "month": 5}},
                    }
                },
                "education": {
                    "formData": {
                        "educations": [
                            {
                                "name": "台灣大學",
                                "departments": [{"name": "資工系"}],
                                "highest": {"text": "碩士"},
                                "duration": {"startYear": 2015, "endYear": 2017},
                                "status": {"text": "畢業"},
                            },
                        ]
                    }
                },
                "skill": {
                    "formData": {
                        "skills": [
                            {"category": "程式語言", "items": [{"name": "Python"}, {"name": "Go"}]},
                        ]
                    }
                },
                "certificate": {
                    "formData": {
                        "certificate": [
                            {"name": "AWS Solutions Architect", "issuer": "Amazon", "date": "2024/01"},
                        ]
                    }
                },
                "language": {
                    "formData": {
                        "languages": [
                            {
                                "language": {"text": "英文"},
                                "listening": {"text": "精通"},
                                "speaking": {"text": "中等"},
                                "reading": {"text": "精通"},
                                "writing": {"text": "中等"},
                            },
                        ]
                    }
                },
                "bio": {"formData": {"bio": "我是一位有經驗的工程師"}},
                "jobCondition": {
                    "formData": {
                        "jobCondition": {
                            "jobTimeType": {"text": "全職"},
                            "salary": {"min": 80000, "max": 150000},
                            "preferArea": [{"name": "台北市"}],
                            "preferJobTitle": [{"name": "AI工程師"}],
                        }
                    }
                },
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume-show", "abc123"])
            assert result.exit_code == 0

    def test_resume_show_real_api_format(self, runner: CliRunner) -> None:
        """Test with actual 104 PDA API response structure."""
        data = {
            "data": {
                "progress": 85,
                "resume": {"name": "我的履歷", "vno": "real123"},
                "ACData": {
                    "info": {
                        "name": "王大明",
                        "email": "test@example.com",
                        "gender": {"text": "男", "value": 1},
                    }
                },
                "info": {
                    "formData": {
                        "info": {
                            "age": 28,
                            "city": {"text": "台北市"},
                            "jobStatus": {"text": "在職中"},
                        }
                    }
                },
                "experience": {
                    "formData": {
                        "experiences": [
                            {
                                "companyName": "科技公司",
                                "jobName": "軟體工程師",
                                "duration": {"startYear": 2021, "startMonth": {"des": "3月", "no": 3}},
                                "stillWork": True,
                                "description": "<p>負責<strong>後端開發</strong></p><ul><li>Python</li></ul>",
                            },
                        ],
                        "seniority": {"text": "7~8年", "value": 7},
                    }
                },
                "education": {
                    "formData": {
                        "educations": [
                            {
                                "name": "台灣大學",
                                "departments": [{"name": "資工系"}],
                                "highest": {"text": "碩士"},
                                "duration": {"startYear": 2015, "endYear": 2017},
                                "status": {"text": "畢業"},
                            },
                        ]
                    }
                },
                "skill": {
                    "formData": {
                        "skills": [
                            {
                                "name": "擅長工具",
                                "desc": "Python, JS",
                                "tag": [
                                    {"text": "Python"},
                                    {"text": "JavaScript"},
                                    {"text": "Docker"},
                                ],
                            },
                        ]
                    }
                },
                "certificate": {
                    "formData": {
                        "certificate": {
                            "certificates": [{"name": "TOEIC 900", "org": "ETS", "date": "2023/06"}],
                            "others": "",
                        }
                    }
                },
                "language": {
                    "formData": {
                        "languages": {
                            "foreign": [
                                {
                                    "type": {"text": "英文"},
                                    "listening": {"text": "精通"},
                                    "speaking": {"text": "中等"},
                                    "reading": {"text": "精通"},
                                    "writing": {"text": "中等"},
                                },
                            ],
                            "local": [
                                {"type": {"text": "台語"}, "level": {"text": "略懂"}},
                            ],
                        }
                    }
                },
                "bio": {
                    "formData": {
                        "bio": {
                            "chi": "<blockquote>我是工程師</blockquote><p>熱愛技術</p>",
                            "eng": "",
                        }
                    }
                },
                "jobCondition": {
                    "formData": {
                        "jobCondition": {
                            "jobTimeType": {"text": "全職"},
                            "salary": {"text": "自訂薪資", "value": 4},
                            "salaryPeriod": {"text": "月薪"},
                            "salaryOfMonth": {
                                "unitOfTenThousand": {"text": "18萬"},
                                "unitOfThousand": {"text": "0千"},
                            },
                            "preferArea": [{"no": 1, "des": "台北市"}, {"no": 2, "des": "新北市"}],
                            "preferJobTitle": "軟體工程師、AI工程師、資料科學家",
                        }
                    }
                },
                "project": {
                    "formData": {
                        "projects": [
                            {
                                "name": "AI平台",
                                "duration": {"startYear": 2022, "startMonth": 1, "endYear": 2023, "endMonth": 6},
                                "isInProgress": False,
                                "introduction": "<p>開發AI推論平台</p>",
                                "url": "https://github.com/example/ai-platform",
                            },
                        ]
                    }
                },
                "portfolio": {
                    "formData": {
                        "portfolios": [
                            {
                                "name": "深度學習論文",
                                "attach": {
                                    "name": "論文PPT.pdf",
                                    "status": 2,
                                    "url": "/profile/portfolio/attachment?vno=real123&fileId=abc",
                                    "fileId": "upload1.pdf",
                                },
                                "attachType": {"text": "檔案", "value": 1},
                                "sort": 1,
                            },
                        ]
                    }
                },
                "custom1": {
                    "formData": {
                        "custom": {
                            "name": "[獲頒專利]聲音輸出之調整方法",
                            "sort": 1,
                            "content": [
                                {
                                    "duration": {"startYear": "2021", "startMonth": {"text": 2, "value": 2}},
                                    "isInProgress": ["1"],
                                    "introduction": "一種聲音輸出之調整方法",
                                    "url": "https://example.com/patent.pdf",
                                }
                            ],
                        }
                    }
                },
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume-show", "real123"])
            assert result.exit_code == 0
            output = result.output
            # ACData personal info
            assert "王大明" in output
            # Seniority text format
            assert "7~8年" in output
            # Languages from foreign+local
            assert "英文" in output
            assert "台語" in output
            # Skills from tag key
            assert "Python" in output
            # preferArea with des key
            assert "台北市" in output
            # preferJobTitle as string
            assert "軟體工程師" in output
            # Bio with HTML stripped
            assert "我是工程師" in output
            # Projects
            assert "AI平台" in output
            # Portfolio with file attachment
            assert "深度學習論文" in output
            assert "論文PPT.pdf" in output
            # Custom sections (patents)
            assert "獲頒專利" in output
            assert "聲音輸出之調整方法" in output

    def test_resume_show_md_output(self, runner: CliRunner) -> None:
        """Test --md outputs full Markdown with untruncated content."""
        long_desc = "這是一段很長的工作描述，" * 20  # >80 chars
        long_bio = "我是一位資深工程師，" * 60  # >500 chars
        long_intro = "這是一段很長的專利說明，" * 20  # >120 chars
        data = {
            "data": {
                "progress": 85,
                "resume": {"name": "我的履歷", "vno": "md123"},
                "ACData": {
                    "info": {
                        "name": "王大明",
                        "email": "test@example.com",
                        "gender": {"text": "男", "value": 1},
                    }
                },
                "info": {
                    "formData": {
                        "info": {
                            "age": 28,
                            "city": {"text": "台北市"},
                            "jobStatus": {"text": "在職中"},
                        }
                    }
                },
                "experience": {
                    "formData": {
                        "experiences": [
                            {
                                "companyName": "科技公司",
                                "jobName": "軟體工程師",
                                "duration": {"startYear": 2021, "startMonth": {"des": "3月", "no": 3}},
                                "stillWork": True,
                                "description": long_desc,
                            },
                        ],
                        "seniority": {"text": "7~8年"},
                    }
                },
                "education": {
                    "formData": {
                        "educations": [
                            {
                                "name": "台灣大學",
                                "departments": [{"name": "資工系"}],
                                "highest": {"text": "碩士"},
                                "duration": {"startYear": 2015, "endYear": 2017},
                                "status": {"text": "畢業"},
                            },
                        ]
                    }
                },
                "skill": {
                    "formData": {
                        "skills": [
                            {
                                "name": "擅長工具",
                                "tag": [
                                    {"text": "Python"},
                                    {"text": "JavaScript"},
                                    {"text": "Docker"},
                                ],
                            },
                        ]
                    }
                },
                "certificate": {
                    "formData": {
                        "certificate": {
                            "certificates": [{"name": "TOEIC 900", "org": "ETS", "date": "2023/06"}],
                            "others": "",
                        }
                    }
                },
                "language": {
                    "formData": {
                        "languages": {
                            "foreign": [
                                {
                                    "type": {"text": "英文"},
                                    "listening": {"text": "精通"},
                                    "speaking": {"text": "中等"},
                                    "reading": {"text": "精通"},
                                    "writing": {"text": "中等"},
                                },
                            ],
                            "local": [
                                {"type": {"text": "台語"}, "level": {"text": "略懂"}},
                            ],
                        }
                    }
                },
                "bio": {"formData": {"bio": {"chi": long_bio, "eng": ""}}},
                "jobCondition": {
                    "formData": {
                        "jobCondition": {
                            "jobTimeType": {"text": "全職"},
                            "salary": {"text": "自訂薪資"},
                            "salaryPeriod": {"text": "月薪"},
                            "preferArea": [{"des": "台北市"}, {"des": "新北市"}],
                            "preferJobTitle": "軟體工程師、AI工程師",
                        }
                    }
                },
                "project": {
                    "formData": {
                        "projects": [
                            {
                                "name": "AI平台",
                                "duration": {"startYear": 2022, "startMonth": 1, "endYear": 2023, "endMonth": 6},
                                "isInProgress": False,
                                "introduction": "<p>開發AI推論平台，支援多種模型部署</p>",
                                "url": "https://github.com/example/ai-platform",
                            },
                        ]
                    }
                },
                "portfolio": {
                    "formData": {
                        "portfolios": [
                            {
                                "name": "深度學習論文",
                                "attach": {
                                    "name": "論文PPT.pdf",
                                    "url": "/profile/portfolio/attachment?vno=md123&fileId=abc",
                                },
                            },
                        ]
                    }
                },
                "custom1": {
                    "formData": {
                        "custom": {
                            "name": "[獲頒專利]聲音輸出之調整方法",
                            "content": [
                                {
                                    "duration": {"startYear": "2021", "startMonth": {"text": 2, "value": 2}},
                                    "isInProgress": ["1"],
                                    "introduction": long_intro,
                                    "url": "https://example.com/patent.pdf",
                                }
                            ],
                        }
                    }
                },
            }
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["resume-show", "md123", "--md"])
            assert result.exit_code == 0
            output = result.output

            # Markdown headings present
            assert "# 我的履歷" in output
            assert "## 個人資訊" in output
            assert "## 工作經歷" in output
            assert "## 學歷" in output
            assert "## 技能" in output
            assert "## 證照" in output
            assert "## 語言能力" in output
            assert "## 求職條件" in output
            assert "## 自傳" in output
            assert "## 專案作品" in output
            assert "## 作品集" in output
            assert "## [獲頒專利]聲音輸出之調整方法" in output

            # Content untruncated (longer than Rich table limits)
            assert long_desc in output  # work description not truncated at 80
            assert long_bio in output  # bio not truncated at 500
            assert long_intro in output  # custom intro not truncated at 120

            # Key content
            assert "王大明" in output
            assert "軟體工程師 @ 科技公司" in output
            assert "Python" in output
            assert "[論文PPT.pdf]" in output
            assert "pda.104.com.tw" in output


# -- Viewers command tests ---------------------------------------------------


class TestViewersCommand:
    def test_viewers_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "browseDate": "03/14",
                    "custNo": "abc123",
                    "custName": "拓明科技",
                    "areaDesc": "新北市新店區",
                    "industryDesc": "軟體業",
                    "jobCount": 5,
                    "tagNames": ["年終獎金", "三節獎金"],
                }
            ],
            "metadata": {},
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["viewers", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_viewers_empty(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["viewers"])
            assert result.exit_code == 0

    def test_viewers_rich_render(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "browseDate": "03/14",
                    "custName": "和碩科技",
                    "areaDesc": "台北市",
                    "industryDesc": "電子業",
                    "jobCount": 10,
                    "tagNames": ["年終獎金", "三節獎金", "零食櫃", "咖啡吧"],
                }
            ],
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["viewers"])
            assert result.exit_code == 0


# -- Follows command tests ---------------------------------------------------


class TestFollowsCommand:
    def test_follows_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "custName": "Google",
                    "custNo": "goo123",
                    "industryDesc": "網際網路",
                    "areaDesc": "台北市",
                    "employeeCountDesc": "5000+",
                    "jobCount": 50,
                    "followedJobCount": 3,
                    "memo": "很想去",
                }
            ],
            "metadata": {},
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["follows", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_follows_empty(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["follows"])
            assert result.exit_code == 0


# -- History command tests ---------------------------------------------------


class TestHistoryCommand:
    def test_history_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "viewDate": "2026/03/14",
                    "jobName": "AI工程師",
                    "jobNo": "12345",
                    "custName": "台積電",
                    "areaDesc": "新竹市",
                    "isSaved": False,
                    "isApplied": True,
                }
            ],
            "metadata": {},
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["history", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_history_empty(self, runner: CliRunner) -> None:
        data = {"data": []}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["history"])
            assert result.exit_code == 0

    def test_history_with_page(self, runner: CliRunner) -> None:
        data = {"data": [], "metadata": {}}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["history", "-p", "2", "--json"])
            assert result.exit_code == 0


# -- Recommend command tests -------------------------------------------------


class TestRecommendCommand:
    def test_recommend_json_output(self, runner: CliRunner) -> None:
        data = {
            "data": [
                {
                    "jobName": "AI應用工程師",
                    "jobNo": "67890",
                    "custName": "Google",
                    "jobAddrNoDesc": "台北市",
                    "applyCnt": "30+",
                    "isSave": False,
                    "isApplied": False,
                }
            ],
            "metadata": {"pagination": {"total": 400, "currentPage": 1, "lastPage": 80}},
        }
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["recommend", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_recommend_with_group(self, runner: CliRunner) -> None:
        data = {"data": [], "metadata": {"pagination": {"total": 0}}}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["recommend", "--group", "highchance", "--json"])
            assert result.exit_code == 0

    def test_recommend_empty(self, runner: CliRunner) -> None:
        data = {"data": [], "metadata": {}}
        auth_patch, client_patch = _patch_auth_and_client(data)
        with auth_patch, client_patch:
            result = runner.invoke(cli, ["recommend"])
            assert result.exit_code == 0


# -- Client method tests -----------------------------------------------------


class TestClientPdaMethods:
    def test_headers_for_pda_applied(self) -> None:
        client = Job104Client()
        headers = client._headers_for_request("https://pda.104.com.tw/applyRecord/ajax/list")
        assert headers["Referer"] == "https://pda.104.com.tw/applyRecord/"

    def test_headers_for_pda_saved(self) -> None:
        client = Job104Client()
        headers = client._headers_for_request("https://pda.104.com.tw/work/jobStore/ajax/list")
        assert headers["Referer"] == "https://pda.104.com.tw/work/jobStore/"

    def test_headers_for_pda_profile(self) -> None:
        client = Job104Client()
        headers = client._headers_for_request("https://pda.104.com.tw/profile/ajax/overview")
        assert headers["Referer"] == "https://pda.104.com.tw/profile/"

    def test_headers_for_pda_api(self) -> None:
        client = Job104Client()
        headers = client._headers_for_request("https://pda.104.com.tw/api/interviews")
        assert headers["Referer"] == "https://pda.104.com.tw/"

    def test_headers_for_pda_viewjob(self) -> None:
        client = Job104Client()
        headers = client._headers_for_request("https://pda.104.com.tw/viewjobRecord/ajax/list")
        assert headers["Referer"] == "https://pda.104.com.tw/work/jobBrowse/"

    def test_headers_for_www_unchanged(self) -> None:
        """Existing www URLs should still work as before."""
        client = Job104Client()
        headers = client._headers_for_request("/jobs/search/api/jobs")
        assert "104.com.tw" in headers["Referer"]
