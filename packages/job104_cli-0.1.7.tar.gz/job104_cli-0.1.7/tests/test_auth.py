"""Tests for authentication module and commands."""

from __future__ import annotations

import json
import time
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from job104_cli.auth import (
    Credential,
    browser_login_flow,
    clear_credential,
    load_cookie_file,
    load_credential,
    save_credential,
)
from job104_cli.cli import cli
from job104_cli.client import Job104Client


# -- Credential data class tests ---------------------------------------------


class TestCredential:
    def test_is_valid_with_cookies(self) -> None:
        cred = Credential(cookies={"AC": "abc123"})
        assert cred.is_valid is True

    def test_is_valid_empty(self) -> None:
        cred = Credential(cookies={})
        assert cred.is_valid is False

    def test_to_dict_and_from_dict(self) -> None:
        cred = Credential(cookies={"AC": "abc", "UID": "123"})
        data = cred.to_dict()
        assert "cookies" in data
        assert "saved_at" in data
        assert data["cookies"] == {"AC": "abc", "UID": "123"}

        restored = Credential.from_dict(data)
        assert restored.cookies == cred.cookies

    def test_from_dict_missing_cookies(self) -> None:
        cred = Credential.from_dict({})
        assert cred.cookies == {}
        assert cred.is_valid is False

    def test_as_cookie_header(self) -> None:
        cred = Credential(cookies={"AC": "abc", "UID": "123"})
        header = cred.as_cookie_header()
        assert "AC=abc" in header
        assert "UID=123" in header


# -- Credential persistence tests --------------------------------------------


class TestCredentialPersistence:
    def test_save_and_load(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        cred = Credential(cookies={"AC": "abc123", "UID": "456"})
        save_credential(cred)

        # Check file permissions
        cred_file = tmp_path / "credential.json"
        assert cred_file.exists()
        assert oct(cred_file.stat().st_mode & 0o777) == "0o600"

        loaded = load_credential()
        assert loaded is not None
        assert loaded.cookies == {"AC": "abc123", "UID": "456"}

    def test_load_nonexistent(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "does_not_exist.json")
        assert load_credential() is None

    def test_load_invalid_json(self, tmp_path, monkeypatch) -> None:
        cred_file = tmp_path / "credential.json"
        cred_file.write_text("not valid json", encoding="utf-8")
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", cred_file)
        assert load_credential() is None

    def test_load_empty_cookies(self, tmp_path, monkeypatch) -> None:
        cred_file = tmp_path / "credential.json"
        cred_file.write_text(json.dumps({"cookies": {}, "saved_at": time.time()}), encoding="utf-8")
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", cred_file)
        assert load_credential() is None

    def test_clear_credential(self, tmp_path, monkeypatch) -> None:
        cred_file = tmp_path / "credential.json"
        cred_file.write_text("{}", encoding="utf-8")
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", cred_file)

        clear_credential()
        assert not cred_file.exists()

    def test_clear_nonexistent_is_noop(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "nope.json")
        clear_credential()  # Should not raise

    def test_ttl_refresh_attempts_browser(self, tmp_path, monkeypatch) -> None:
        """When credential is older than TTL, load_credential attempts browser refresh."""
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        stale_data = {
            "cookies": {"AC": "old_value"},
            "saved_at": time.time() - (8 * 86400),  # 8 days ago
        }
        (tmp_path / "credential.json").write_text(json.dumps(stale_data), encoding="utf-8")

        # Mock browser extraction to return None (no refresh available)
        with patch("job104_cli.auth.extract_browser_credential", return_value=None):
            cred = load_credential()
            # Should fall back to stale credential
            assert cred is not None
            assert cred.cookies == {"AC": "old_value"}


# -- Cookie file import tests ------------------------------------------------


class TestCookieFileImport:
    def test_load_json_cookie_file(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        cookie_file = tmp_path / "cookies.json"
        cookie_file.write_text(json.dumps({"AC": "test", "UID": "42"}), encoding="utf-8")

        cred = load_cookie_file(str(cookie_file))
        assert cred is not None
        assert cred.cookies == {"AC": "test", "UID": "42"}

    def test_load_netscape_cookie_file(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        cookie_file = tmp_path / "cookies.txt"
        cookie_file.write_text(
            "# Netscape HTTP Cookie File\n.104.com.tw\tTRUE\t/\tTRUE\t0\tAC\tabc123\n.104.com.tw\tTRUE\t/\tTRUE\t0\tUID\t456\n",
            encoding="utf-8",
        )

        cred = load_cookie_file(str(cookie_file))
        assert cred is not None
        assert cred.cookies["AC"] == "abc123"
        assert cred.cookies["UID"] == "456"

    def test_load_nonexistent_file(self) -> None:
        assert load_cookie_file("/nonexistent/path.json") is None

    def test_load_invalid_json_file(self, tmp_path) -> None:
        cookie_file = tmp_path / "bad.json"
        cookie_file.write_text("{not valid json}", encoding="utf-8")
        assert load_cookie_file(str(cookie_file)) is None


# -- Browser cookie extraction tests -----------------------------------------


class TestBrowserExtraction:
    def test_extract_returns_none_when_no_cookies(self, monkeypatch) -> None:
        """Subprocess returns no_cookies error."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"error": "no_cookies"})
        mock_result.stderr = ""

        monkeypatch.setattr("job104_cli.auth.subprocess.run", lambda *a, **kw: mock_result)

        from job104_cli.auth import extract_browser_credential

        assert extract_browser_credential() is None

    def test_extract_returns_credential_on_success(self, tmp_path, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"browser": "Chrome", "cookies": {"AC": "val1", "UID": "val2"}})
        mock_result.stderr = ""

        monkeypatch.setattr("job104_cli.auth.subprocess.run", lambda *a, **kw: mock_result)

        from job104_cli.auth import extract_browser_credential

        cred = extract_browser_credential()
        assert cred is not None
        assert cred.cookies == {"AC": "val1", "UID": "val2"}

    def test_extract_handles_subprocess_failure(self, monkeypatch) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "error"

        monkeypatch.setattr("job104_cli.auth.subprocess.run", lambda *a, **kw: mock_result)

        from job104_cli.auth import extract_browser_credential

        assert extract_browser_credential() is None


# -- Verify credential tests -------------------------------------------------


class TestVerifyCredential:
    def test_verify_success_with_api(self) -> None:
        from job104_cli.auth import verify_credential

        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.headers = {"content-type": "application/json"}
        mock_resp.json.return_value = {"data": {"name": "Test User"}}

        mock_client_instance = MagicMock()
        mock_client_instance.get.return_value = mock_resp
        mock_client_instance.__enter__ = MagicMock(return_value=mock_client_instance)
        mock_client_instance.__exit__ = MagicMock(return_value=False)

        with patch("httpx.Client", return_value=mock_client_instance):
            cred = Credential(cookies={"JBCLOGIN": "session123"})
            ok, reason = verify_credential(cred)
            assert ok is True
            assert reason is None

    def test_verify_success_new_style_cookies(self) -> None:
        """New Ory Hydra auth with JBCSESS accepts optimistically."""
        from job104_cli.auth import verify_credential

        # All endpoints return 401 (session check inconclusive)
        mock_resp = MagicMock()
        mock_resp.status_code = 401

        mock_client_instance = MagicMock()
        mock_client_instance.get.return_value = mock_resp
        mock_client_instance.__enter__ = MagicMock(return_value=mock_client_instance)
        mock_client_instance.__exit__ = MagicMock(return_value=False)

        with patch("httpx.Client", return_value=mock_client_instance):
            cred = Credential(cookies={"JBCSESS": "abc", "signin_session": "xyz"})
            ok, reason = verify_credential(cred)
            assert ok is True

    def test_verify_missing_session_cookies(self) -> None:
        from job104_cli.auth import verify_credential

        cred = Credential(cookies={"_ga": "something"})
        ok, reason = verify_credential(cred)
        assert ok is False
        assert "缺少登入 Session Cookie" in reason

    def test_verify_failure_no_session(self) -> None:
        from job104_cli.auth import verify_credential

        cred = Credential(cookies={"AC": "12345", "_csrf": "token"})
        ok, reason = verify_credential(cred)
        assert ok is False
        assert reason is not None


# -- Browser login flow tests ------------------------------------------------


class TestBrowserLoginFlow:
    def test_success_on_second_poll(self, tmp_path, monkeypatch) -> None:
        """Flow returns credential when session cookie found on 2nd poll."""
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        # Simulate tty
        monkeypatch.setattr("sys.stdin.isatty", lambda: True)

        session_cred = Credential(cookies={"JBCSESS": "session_token", "AC": "abc"})
        call_count = {"n": 0}

        def mock_extract(**kwargs):
            call_count["n"] += 1
            if call_count["n"] >= 2:
                return session_cred
            return None

        with (
            patch("webbrowser.open") as mock_open,
            patch("job104_cli.auth.extract_browser_credential", side_effect=mock_extract),
            patch("time.sleep"),  # Don't actually sleep
        ):
            result = browser_login_flow(timeout=30, poll_interval=1)

        assert result is not None
        assert result.cookies["JBCSESS"] == "session_token"
        mock_open.assert_called_once()
        assert call_count["n"] == 2

    def test_timeout_returns_none(self, monkeypatch) -> None:
        """Flow returns None when no session cookie found before timeout."""
        monkeypatch.setattr("sys.stdin.isatty", lambda: True)

        with (
            patch("webbrowser.open"),
            patch("job104_cli.auth.extract_browser_credential", return_value=None),
            patch("time.sleep"),
            patch("time.time", side_effect=[0, 0, 5, 10, 15, 20, 25]),  # Exhaust timeout quickly
        ):
            result = browser_login_flow(timeout=10, poll_interval=1)

        assert result is None

    def test_headless_returns_none_without_opening_browser(self, monkeypatch) -> None:
        """In non-tty environments, flow returns None and never opens browser."""
        monkeypatch.setattr("sys.stdin.isatty", lambda: False)

        with patch("webbrowser.open") as mock_open:
            result = browser_login_flow()

        assert result is None
        mock_open.assert_not_called()

    def test_keyboard_interrupt_handled_gracefully(self, monkeypatch) -> None:
        """KeyboardInterrupt during polling returns None gracefully."""
        monkeypatch.setattr("sys.stdin.isatty", lambda: True)

        def sleep_then_interrupt(_):
            raise KeyboardInterrupt

        with (
            patch("webbrowser.open"),
            patch("job104_cli.auth.extract_browser_credential", return_value=None),
            patch("time.sleep", side_effect=sleep_then_interrupt),
        ):
            result = browser_login_flow(timeout=60, poll_interval=1)

        # Should return None, not raise
        assert result is None


# -- Auth CLI command tests ---------------------------------------------------


class TestAuthCommands:
    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    @pytest.mark.parametrize(
        "args",
        [
            ["login", "--help"],
            ["logout", "--help"],
            ["status", "--help"],
            ["me", "--help"],
        ],
    )
    def test_help_exits_cleanly(self, runner: CliRunner, args: list[str]) -> None:
        result = runner.invoke(cli, args)
        assert result.exit_code == 0, f"Failed for {args}: {result.output}"

    def test_logout_clears_credential(self, runner: CliRunner, tmp_path, monkeypatch) -> None:
        cred_file = tmp_path / "credential.json"
        cred_file.write_text(json.dumps({"cookies": {"AC": "test"}, "saved_at": time.time()}))
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", cred_file)

        result = runner.invoke(cli, ["logout"])
        assert result.exit_code == 0
        assert not cred_file.exists()

    def test_status_not_logged_in(self, runner: CliRunner, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", MagicMock(exists=MagicMock(return_value=False)))
        monkeypatch.setattr("job104_cli.auth.extract_browser_credential", lambda **kw: None)

        result = runner.invoke(cli, ["status"])
        assert result.exit_code == 0

    def test_status_json_not_logged_in(self, runner: CliRunner, monkeypatch) -> None:
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", MagicMock(exists=MagicMock(return_value=False)))
        monkeypatch.setattr("job104_cli.auth.extract_browser_credential", lambda **kw: None)

        result = runner.invoke(cli, ["status", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["authenticated"] is False
        assert data["credential_present"] is False

    def test_login_no_cookies_found(self, runner: CliRunner, monkeypatch) -> None:
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = json.dumps({"error": "no_cookies"})
        mock_result.stderr = ""
        monkeypatch.setattr("job104_cli.auth.subprocess.run", lambda *a, **kw: mock_result)

        result = runner.invoke(cli, ["login"])
        assert result.exit_code == 1

    def test_login_browser_flag_help(self, runner: CliRunner) -> None:
        """--browser flag is documented in login --help."""
        result = runner.invoke(cli, ["login", "--help"])
        assert result.exit_code == 0
        assert "--browser" in result.output

    def test_login_browser_success(self, runner: CliRunner, tmp_path, monkeypatch) -> None:
        """login --browser succeeds when browser_login_flow returns a credential."""
        monkeypatch.setattr("job104_cli.auth.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.auth.CREDENTIAL_FILE", tmp_path / "credential.json")

        session_cred = Credential(cookies={"JBCSESS": "tok123"})

        # browser_login_flow is imported inside the function via `from ..auth import`
        # so we patch the source in job104_cli.auth
        with patch("job104_cli.auth.browser_login_flow", return_value=session_cred):
            result = runner.invoke(cli, ["login", "--browser"])

        assert result.exit_code == 0
        assert "登入成功" in result.output

    def test_login_browser_timeout(self, runner: CliRunner) -> None:
        """login --browser exits with code 1 when browser_login_flow times out."""
        with patch("job104_cli.auth.browser_login_flow", return_value=None):
            result = runner.invoke(cli, ["login", "--browser"])

        assert result.exit_code == 1
        assert "逾時" in result.output or "失敗" in result.output

    def test_me_fallback_no_profile_api(self, runner: CliRunner) -> None:
        """me command handles fallback when profile API returns no data."""
        cred = MagicMock()
        cred.cookies = {"JBCLOGIN": "test"}

        fallback_data = {
            "_source": "applied_fallback",
            "_raw": {
                "data": [{"jobName": "Test Job", "applyDate": "2026/03/15"}],
            },
        }
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = json.dumps(fallback_data)
        mock_resp.json.return_value = fallback_data
        mock_resp.cookies = {}

        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch.object(
                Job104Client,
                "_build_client",
                return_value=MagicMock(
                    request=MagicMock(return_value=mock_resp),
                    cookies=MagicMock(),
                ),
            ),
        ):
            result = runner.invoke(cli, ["me", "--json"])
            assert result.exit_code == 0
            assert '"ok": true' in result.output

    def test_me_fallback_no_data(self, runner: CliRunner) -> None:
        """me command handles the case where no profile data is available."""
        cred = MagicMock()
        cred.cookies = {"JBCLOGIN": "test"}

        no_data = {"_source": "none", "authenticated": True}
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.text = json.dumps(no_data)
        mock_resp.json.return_value = no_data
        mock_resp.cookies = {}

        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch.object(
                Job104Client,
                "_build_client",
                return_value=MagicMock(
                    request=MagicMock(return_value=mock_resp),
                    cookies=MagicMock(),
                ),
            ),
        ):
            result = runner.invoke(cli, ["me"])
            assert result.exit_code == 0
