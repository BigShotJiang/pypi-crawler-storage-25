"""Tests for resume edit commands: resume-edit, resume-fill, resume-fields, resume-autocomplete, resume-options."""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from job104_cli.cli import cli
from job104_cli.client import Job104Client
from job104_cli.resume_schema import SECTION_SCHEMAS, get_section_schema, list_sections


@pytest.fixture
def runner() -> CliRunner:
    return CliRunner()


def _mock_credential():
    """Create a mock credential object."""
    cred = MagicMock()
    cred.cookies = {"ac": "test_ac", "user": "test_user"}
    return cred


def _mock_http_response(json_data: dict):
    """Create a mock HTTP response."""
    resp = MagicMock()
    resp.status_code = 200
    resp.text = json.dumps(json_data)
    resp.json.return_value = json_data
    resp.cookies = {}
    return resp


SAMPLE_OVERVIEW = {
    "data": {
        "formData": {
            "overview": [
                {"versionNo": "abc123", "title": "第一份履歷表"},
                {"versionNo": "def456", "title": "英文履歷"},
            ]
        }
    }
}

SAMPLE_RESUME_DETAIL = {
    "data": {
        "info": {
            "formData": {
                "info": {
                    "name": "王大明",
                    "enName": "Daming Wang",
                    "sex": {"text": "男", "value": "1"},
                }
            }
        },
        "bio": {
            "formData": {
                "bio": {
                    "chi": "我是一個有經驗的工程師...",
                    "eng": "I am an experienced engineer...",
                }
            }
        },
        "experience": {
            "formData": {
                "experiences": [
                    {
                        "sort": 1,
                        "companyName": "Google",
                        "jobName": "Software Engineer",
                        "description": "Built stuff",
                    },
                    {
                        "sort": 2,
                        "companyName": "Meta",
                        "jobName": "Senior Engineer",
                        "description": "More stuff",
                    },
                ]
            }
        },
        "education": {
            "formData": {
                "educations": [
                    {
                        "sort": 1,
                        "name": "台灣大學",
                        "departments": [{"name": "資訊工程"}],
                    }
                ]
            }
        },
    },
}


# -- Help tests ----------------------------------------------------------------


class TestResumeEditHelp:
    @pytest.mark.parametrize(
        "cmd",
        [
            "resume-edit",
            "resume-fill",
            "resume-fields",
            "resume-autocomplete",
            "resume-options",
        ],
    )
    def test_help_exits_cleanly(self, runner: CliRunner, cmd: str) -> None:
        result = runner.invoke(cli, [cmd, "--help"])
        assert result.exit_code == 0, f"Failed for {cmd}: {result.output}"


# -- Auth required tests -------------------------------------------------------


class TestResumeEditAuthRequired:
    def test_resume_edit_requires_auth(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=None):
            result = runner.invoke(cli, ["resume-edit", "bio", "--data", '{"chi": "test"}'])
            assert result.exit_code == 1

    def test_resume_fill_requires_auth(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=None):
            result = runner.invoke(cli, ["resume-fill", "--stdin"], input='{"bio": {}}')
            assert result.exit_code == 1

    def test_resume_autocomplete_requires_auth(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=None):
            result = runner.invoke(cli, ["resume-autocomplete", "school", "台大"])
            assert result.exit_code == 1


# -- resume-fields tests -------------------------------------------------------


class TestResumeFields:
    def test_fields_json_all(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-fields", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert "info" in data["data"]
        assert "bio" in data["data"]
        assert "experience" in data["data"]

    def test_fields_json_includes_new_sections(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-fields", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert "referrer" in data["data"]
        assert "custom1" in data["data"]
        assert "custom2" in data["data"]
        assert "custom3" in data["data"]

    def test_fields_json_single_section(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-fields", "--section", "experience", "--json"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert "experience" in data["data"]
        assert "info" not in data["data"]

    def test_fields_invalid_section(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-fields", "--section", "nonexistent"])
        assert result.exit_code == 1

    def test_fields_rich_output(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-fields"])
        assert result.exit_code == 0


# -- resume_schema tests -------------------------------------------------------


class TestResumeSchema:
    def test_all_sections_have_required_keys(self) -> None:
        for name, schema in SECTION_SCHEMAS.items():
            assert "label" in schema, f"{name} missing label"
            assert "array" in schema, f"{name} missing array"
            assert "operations" in schema, f"{name} missing operations"
            assert "fields" in schema, f"{name} missing fields"

    def test_all_operations_are_put(self) -> None:
        for name, schema in SECTION_SCHEMAS.items():
            assert schema["operations"] == ["PUT"], f"{name} operations should be ['PUT'], got {schema['operations']}"

    def test_get_section_schema_valid(self) -> None:
        schema = get_section_schema("bio")
        assert schema is not None
        assert schema["label"] == "自傳"

    def test_get_section_schema_invalid(self) -> None:
        schema = get_section_schema("nonexistent")
        assert schema is None

    def test_list_sections(self) -> None:
        sections = list_sections()
        assert len(sections) > 0
        assert all("name" in s for s in sections)
        assert all("label" in s for s in sections)
        names = [s["name"] for s in sections]
        assert "info" in names
        assert "bio" in names
        assert "experience" in names
        assert "referrer" in names
        assert "custom1" in names
        assert "custom2" in names
        assert "custom3" in names

    def test_section_field_types_valid(self) -> None:
        valid_types = {"text", "number", "select", "multiselect", "date", "html", "bool", "array", "autocomplete"}
        for name, schema in SECTION_SCHEMAS.items():
            for field_name, field_meta in schema["fields"].items():
                assert field_meta["type"] in valid_types, f"{name}.{field_name} has invalid type: {field_meta['type']}"

    def test_array_sections_have_array_key(self) -> None:
        for name, schema in SECTION_SCHEMAS.items():
            if schema["array"]:
                assert "array_key" in schema, f"{name} is array but missing array_key"

    def test_single_sections_have_payload_key(self) -> None:
        for name, schema in SECTION_SCHEMAS.items():
            if not schema["array"]:
                assert "payload_key" in schema, f"{name} is single but missing payload_key"


# -- resume-edit tests ---------------------------------------------------------


class TestResumeEditCommand:
    def test_invalid_section_rejected(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-edit", "bogus"])
        assert result.exit_code != 0

    def test_invalid_json_data(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=_mock_credential()):
            result = runner.invoke(cli, ["resume-edit", "bio", "--data", "not-json"])
            assert result.exit_code == 1

    def test_array_section_update_requires_index(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=_mock_credential()):
            with patch.object(Job104Client, "_build_client", return_value=MagicMock()):
                result = runner.invoke(cli, ["resume-edit", "experience", "--update", "--data", '{"companyName": "X"}'])
                assert result.exit_code == 1
                assert "index" in result.output.lower() or "編號" in result.output

    def test_array_section_delete_requires_index(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=_mock_credential()):
            with patch.object(Job104Client, "_build_client", return_value=MagicMock()):
                result = runner.invoke(cli, ["resume-edit", "experience", "--delete"])
                assert result.exit_code == 1

    def test_add_on_single_section_rejected(self, runner: CliRunner) -> None:
        """Non-array sections should reject --add."""
        with patch("job104_cli.auth.get_credential", return_value=_mock_credential()):
            result = runner.invoke(cli, ["resume-edit", "info", "--add", "--data", '{"name": "test"}'])
            assert result.exit_code == 1
            assert "add" in result.output.lower() or "非陣列" in result.output

    def test_dry_run_bio_update(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--data",
                    '{"chi": "新的自傳內容"}',
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0
            assert "dry-run" in result.output.lower() or "預覽" in result.output

    def test_bio_update_with_confirm_no(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch("job104_cli.commands._common.click.confirm", return_value=False),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--data",
                    '{"chi": "新的自傳內容"}',
                ],
            )
            assert result.exit_code == 0
            assert "取消" in result.output

    def test_bio_update_with_yes_flag(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}) as mock_update,
            patch("job104_cli.commands._common.backup_resume", return_value=None),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--yes",
                    "--data",
                    '{"chi": "新的自傳內容"}',
                ],
            )
            assert result.exit_code == 0
            mock_update.assert_called_once()
            call_args = mock_update.call_args
            assert call_args[0][0] == "abc123"  # resolved vno
            assert call_args[0][1] == "bio"

    def test_experience_add_with_yes(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        new_exp = json.dumps({"companyName": "Apple", "jobName": "iOS Engineer"})
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}) as mock_update,
            patch("job104_cli.commands._common.backup_resume", return_value=None),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "experience",
                    "--add",
                    "--yes",
                    "--data",
                    new_exp,
                ],
            )
            assert result.exit_code == 0
            mock_update.assert_called_once()
            call_args = mock_update.call_args
            # All operations now use PUT
            assert call_args[1]["method"] == "PUT"

    def test_experience_delete_with_index(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}) as mock_update,
            patch("job104_cli.commands._common.backup_resume", return_value=None),
            patch("job104_cli.commands._common.click.confirm", return_value=True),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "experience",
                    "--delete",
                    "--index",
                    "1",
                ],
            )
            assert result.exit_code == 0
            # Delete uses PUT-replace, not delete_resume_section
            mock_update.assert_called_once()
            call_args = mock_update.call_args
            assert call_args[1]["method"] == "PUT"

    def test_delete_index_out_of_range(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "experience",
                    "--delete",
                    "--index",
                    "99",
                ],
            )
            assert result.exit_code == 1

    def test_explicit_vno(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}),
            patch("job104_cli.commands._common.backup_resume", return_value=None),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--yes",
                    "--vno",
                    "def456",
                    "--data",
                    '{"chi": "test"}',
                ],
            )
            assert result.exit_code == 0

    def test_unsupported_operation(self, runner: CliRunner) -> None:
        """Test that info section rejects --add (not an array section)."""
        schema = get_section_schema("info")
        assert not schema["array"], "info should not be an array section"
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "info",
                    "--add",
                    "--data",
                    '{"name": "test"}',
                ],
            )
            assert result.exit_code == 1

    def test_json_output(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}),
            patch("job104_cli.commands._common.backup_resume", return_value=None),
            patch("job104_cli.commands._common.console"),
            patch("job104_cli.commands.resume_edit.console"),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--yes",
                    "--data",
                    '{"chi": "test"}',
                    "--json",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True

    def test_data_file_option(self, runner: CliRunner, tmp_path) -> None:
        cred = _mock_credential()
        data_file = tmp_path / "bio.json"
        data_file.write_text('{"chi": "from file"}', encoding="utf-8")
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-edit",
                    "bio",
                    "--update",
                    "--data-file",
                    str(data_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0


# -- resume-fill tests ---------------------------------------------------------


class TestResumeFill:
    def test_fill_requires_input(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=_mock_credential()):
            result = runner.invoke(cli, ["resume-fill"])
            assert result.exit_code == 1

    def test_fill_stdin_json_dry_run(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        fill_data = json.dumps({"bio": {"chi": "新自傳內容"}})
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                    "--dry-run",
                ],
                input=fill_data,
            )
            assert result.exit_code == 0

    def test_fill_stdin_json_dry_run_json_mode_no_truncation(self, runner: CliRunner) -> None:
        """In JSON mode, dry-run payload should not be truncated."""
        cred = _mock_credential()
        long_bio = "x" * 1000
        fill_data = json.dumps({"bio": {"chi": long_bio}})
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                    "--dry-run",
                    "--json",
                ],
                input=fill_data,
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True
            # In JSON mode, payload is included and not truncated
            bio_result = next(r for r in data["data"]["results"] if r["section"] == "bio")
            assert "payload" in bio_result
            assert bio_result["payload"]["chi"] == long_bio

    def test_fill_stdin_invalid_json(self, runner: CliRunner) -> None:
        with (
            patch("job104_cli.auth.get_credential", return_value=_mock_credential()),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=_mock_credential()),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                ],
                input="not json",
            )
            assert result.exit_code == 1

    def test_fill_invalid_section_filter(self, runner: CliRunner) -> None:
        fill_data = json.dumps({"bio": {"chi": "test"}})
        with (
            patch("job104_cli.auth.get_credential", return_value=_mock_credential()),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=_mock_credential()),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                    "--sections",
                    "bogus",
                ],
                input=fill_data,
            )
            assert result.exit_code == 1

    def test_fill_json_file_dry_run(self, runner: CliRunner, tmp_path) -> None:
        cred = _mock_credential()
        fill_data = {"bio": {"chi": "from file"}, "info": {"name": "Test"}}
        fill_file = tmp_path / "resume.json"
        fill_file.write_text(json.dumps(fill_data), encoding="utf-8")

        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--from",
                    str(fill_file),
                    "--dry-run",
                ],
            )
            assert result.exit_code == 0

    def test_fill_unsupported_file_type(self, runner: CliRunner, tmp_path) -> None:
        cred = _mock_credential()
        fill_file = tmp_path / "resume.docx"
        fill_file.write_text("dummy", encoding="utf-8")

        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--from",
                    str(fill_file),
                ],
            )
            assert result.exit_code == 1

    def test_fill_with_sections_filter(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        fill_data = json.dumps({"bio": {"chi": "test"}, "info": {"name": "Test"}})
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                    "--sections",
                    "bio",
                    "--dry-run",
                ],
                input=fill_data,
            )
            assert result.exit_code == 0

    def test_fill_with_yes_flag(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        fill_data = json.dumps({"bio": {"chi": "agent filled bio"}})
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_overview", return_value=SAMPLE_OVERVIEW),
            patch.object(Job104Client, "get_resume_detail", return_value=SAMPLE_RESUME_DETAIL),
            patch.object(Job104Client, "update_resume_section", return_value={"ok": True}) as mock_update,
            patch("job104_cli.commands._common.backup_resume", return_value=None),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-fill",
                    "--stdin",
                    "--yes",
                ],
                input=fill_data,
            )
            assert result.exit_code == 0
            mock_update.assert_called_once()


# -- resume-autocomplete tests -------------------------------------------------


class TestResumeAutocomplete:
    def test_invalid_type_rejected(self, runner: CliRunner) -> None:
        result = runner.invoke(cli, ["resume-autocomplete", "bogus", "test"])
        assert result.exit_code != 0

    def test_autocomplete_json_output(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        ac_results = [{"text": "台灣大學", "value": "1001"}]
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "autocomplete", return_value=ac_results),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-autocomplete",
                    "school",
                    "台灣大學",
                    "--json",
                ],
            )
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True

    def test_autocomplete_empty_result(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "autocomplete", return_value=[]),
        ):
            result = runner.invoke(
                cli,
                [
                    "resume-autocomplete",
                    "school",
                    "xxxxxxx",
                ],
            )
            assert result.exit_code == 0


# -- resume-options tests ------------------------------------------------------


class TestResumeOptions:
    MOCK_OPTIONS = {
        "data": {
            "formData": {
                "optionsMilitary": [
                    {"value": 1, "text": "役畢"},
                    {"value": 2, "text": "未役"},
                    {"value": 3, "text": "免役"},
                ],
                "optionsEducation": [
                    {"value": 1, "text": "高中"},
                    {"value": 2, "text": "大學"},
                    {"value": 3, "text": "碩士"},
                ],
            }
        }
    }

    def test_options_list_all_json(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_options", return_value=self.MOCK_OPTIONS),
        ):
            result = runner.invoke(cli, ["resume-options", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True
            assert "optionsMilitary" in data["data"]
            assert "optionsEducation" in data["data"]

    def test_options_specific_key_json(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_options", return_value=self.MOCK_OPTIONS),
        ):
            result = runner.invoke(cli, ["resume-options", "optionsMilitary", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True
            assert "optionsMilitary" in data["data"]
            assert len(data["data"]["optionsMilitary"]) == 3
            assert data["data"]["optionsMilitary"][0]["text"] == "役畢"

    def test_options_unknown_key_returns_empty(self, runner: CliRunner) -> None:
        cred = _mock_credential()
        with (
            patch("job104_cli.auth.get_credential", return_value=cred),
            patch("job104_cli.commands.resume_edit.require_auth", return_value=cred),
            patch.object(Job104Client, "_build_client", return_value=MagicMock()),
            patch.object(Job104Client, "get_resume_options", return_value=self.MOCK_OPTIONS),
        ):
            result = runner.invoke(cli, ["resume-options", "optionsNonExistent", "--json"])
            assert result.exit_code == 0
            data = json.loads(result.output)
            assert data["ok"] is True
            assert data["data"]["optionsNonExistent"] == []

    def test_options_requires_auth(self, runner: CliRunner) -> None:
        with patch("job104_cli.auth.get_credential", return_value=None):
            result = runner.invoke(cli, ["resume-options"])
            assert result.exit_code == 1


# -- Helper function tests -----------------------------------------------------


class TestHelperFunctions:
    def test_resolve_vno_with_explicit_vno(self) -> None:
        from job104_cli.commands._common import resolve_vno

        client = MagicMock()
        assert resolve_vno(client, "my_vno") == "my_vno"
        client.get_resume_overview.assert_not_called()

    def test_resolve_vno_defaults_to_first(self) -> None:
        from job104_cli.commands._common import resolve_vno

        client = MagicMock()
        client.get_resume_overview.return_value = SAMPLE_OVERVIEW
        assert resolve_vno(client, None) == "abc123"

    def test_resolve_vno_no_resumes_exits(self) -> None:
        from job104_cli.commands._common import resolve_vno

        client = MagicMock()
        client.get_resume_overview.return_value = {"data": {"formData": {"overview": []}}}
        with pytest.raises(SystemExit):
            resolve_vno(client, None)

    def test_confirm_write_yes_flag(self) -> None:
        from job104_cli.commands._common import confirm_write

        assert confirm_write("test", yes=True) is True

    def test_backup_resume_creates_file(self, tmp_path) -> None:
        from job104_cli.commands._common import backup_resume

        client = MagicMock()
        client.get_resume_detail.return_value = {"data": {"test": True}}
        with patch("job104_cli.commands._common.BACKUP_DIR", tmp_path):
            path = backup_resume(client, "abc123")
            assert path is not None
            assert path.exists()
            content = json.loads(path.read_text(encoding="utf-8"))
            assert content["data"]["test"] is True

    def test_backup_resume_prunes_old(self, tmp_path) -> None:
        from job104_cli.commands._common import backup_resume

        # Create 12 existing backups
        for i in range(12):
            (tmp_path / f"abc123_2026010{i:02d}T000000.json").write_text("{}")

        client = MagicMock()
        client.get_resume_detail.return_value = {"data": {}}
        with patch("job104_cli.commands._common.BACKUP_DIR", tmp_path):
            backup_resume(client, "abc123")
            # Should keep at most 10 + the new one
            remaining = list(tmp_path.glob("abc123_*.json"))
            assert len(remaining) <= 11

    def test_build_submit_payload_single_update(self) -> None:
        from job104_cli.commands.resume_edit import _build_submit_payload

        schema = get_section_schema("bio")
        current_section = {"bio": {"chi": "old", "eng": "old_eng"}}
        new_data = {"chi": "new"}
        result = _build_submit_payload("bio", schema, current_section, new_data, "update", None)
        assert result["bio"]["chi"] == "new"
        assert result["bio"]["eng"] == "old_eng"  # preserved from current

    def test_build_submit_payload_array_add(self) -> None:
        from job104_cli.commands.resume_edit import _build_submit_payload

        schema = get_section_schema("experience")
        current_section = {
            "experiences": [
                {"sort": 1, "companyName": "A"},
                {"sort": 2, "companyName": "B"},
            ]
        }
        new_data = {"companyName": "C"}
        result = _build_submit_payload("experience", schema, current_section, new_data, "add", None)
        # Returns full section with new entry appended
        assert len(result["experiences"]) == 3
        assert result["experiences"][-1]["sort"] == 3  # max_sort + 1
        assert result["experiences"][-1]["companyName"] == "C"

    def test_build_submit_payload_array_update(self) -> None:
        from job104_cli.commands.resume_edit import _build_submit_payload

        schema = get_section_schema("experience")
        current_section = {
            "experiences": [
                {"sort": 1, "companyName": "A", "jobName": "X"},
            ]
        }
        new_data = {"companyName": "B"}
        result = _build_submit_payload("experience", schema, current_section, new_data, "update", 1)
        # Returns full section with entry updated
        assert result["experiences"][0]["companyName"] == "B"
        assert result["experiences"][0]["jobName"] == "X"  # preserved

    def test_build_submit_payload_preserves_extra_keys(self) -> None:
        from job104_cli.commands.resume_edit import _build_submit_payload

        schema = get_section_schema("experience")
        current_section = {
            "experiences": [{"sort": 1, "companyName": "A"}],
            "seniority": {"value": 3, "text": "3年以上"},
        }
        new_data = {"companyName": "B"}
        result = _build_submit_payload("experience", schema, current_section, new_data, "update", 1)
        # Seniority key should be preserved in the result
        assert "seniority" in result
        assert result["seniority"]["value"] == 3

    def test_get_array_key(self) -> None:
        from job104_cli.commands.resume_edit import _get_array_key

        assert _get_array_key("education", {}) == "educations"
        assert _get_array_key("experience", {}) == "experiences"
        assert _get_array_key("skill", {}) == "skills"
        assert _get_array_key("project", {}) == "projects"
        assert _get_array_key("portfolio", {}) == "portfolios"
        assert _get_array_key("referrer", {}) == "referrers"

    def test_get_main_key(self) -> None:
        from job104_cli.commands.resume_edit import _get_main_key

        assert _get_main_key("info", {}) == "info"
        assert _get_main_key("bio", {}) == "bio"
        assert _get_main_key("jobCondition", {}) == "jobCondition"
        assert _get_main_key("language", {}) == "language"  # was "languages" (bug fix)

    def test_summarize_entry_experience(self) -> None:
        from job104_cli.commands.resume_edit import _summarize_entry

        entry = {"companyName": "Google", "jobName": "SWE"}
        assert "Google" in _summarize_entry("experience", entry)
        assert "SWE" in _summarize_entry("experience", entry)

    def test_summarize_entry_education(self) -> None:
        from job104_cli.commands.resume_edit import _summarize_entry

        entry = {"name": "台灣大學", "departments": [{"name": "資工"}]}
        result = _summarize_entry("education", entry)
        assert "台灣大學" in result
        assert "資工" in result
