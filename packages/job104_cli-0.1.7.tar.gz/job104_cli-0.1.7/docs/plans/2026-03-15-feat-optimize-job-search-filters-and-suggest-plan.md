---
title: "feat: Optimize Job Search Filters, Suggest Command, and Job Model Integration"
type: feat
date: 2026-03-15
---

# Optimize Job Search Filters, Suggest Command, and Job Model Integration

## Overview

Add missing search filters from the 104 API, a keyword `suggest` command, district-level area codes, and integrate the `Job` model into the rendering pipeline. This closes the gap between the 104 API capabilities documented in `docs/draft/jobsearch_analysis_api.md` and the current CLI implementation.

## Problem Statement

The 104 API supports many filters not yet exposed in the CLI:
- Keyword match mode (`kwop`), job type (`ro`), work schedule (`s9`), welfare (`wf`)
- Salary strictness (`scstrict`, `scneg`), exclude keywords/industries/companies
- The `export` command is missing filters that `search` already has (`--salary-type`, `--salary-low`, `--salary-high`, `--isnew`, `--remote`, `--order`)
- No keyword autocomplete command exists despite a public API being available
- The `Job` dataclass exists but is unused in rendering — all commands use raw dicts
- Area filtering is city-level only; no district granularity
- `resolve_area()` silently falls back to "全部" on unrecognized names (data correctness bug)

## Proposed Solution

Four-phase implementation:

1. **Phase 1: New search filter constants + client params + CLI options**
2. **Phase 2: Export command filter parity**
3. **Phase 3: `suggest` command**
4. **Phase 4: Job model integration + district-level areas**

## Technical Approach

### Phase 1: New Search Filters

#### 1a. Add new constants to `constants.py`

```python
# constants.py — new filter mappings

MATCH_MODE_CODES: dict[str, str] = {
    "僅標題": "1",
    "標題+描述": "7",
    "廣泛": "3",
}

JOB_TYPE_CODES: dict[str, str] = {
    "不限": "0",
    "全職": "1",
    "兼職": "2",
    "高階": "3",
    "派遣": "4",
}

SCHEDULE_CODES: dict[str, str] = {
    "日班": "1",
    "夜班": "2",
    "假日班": "4",
    "大夜班": "8",
}
```

> **Design decision — `--schedule` bitmask**: Use `click.option` with `multiple=True` so users can write `--schedule 日班 --schedule 夜班`. OR the bitmask values together: `int("1") | int("2") = 3`. Pass the computed bitmask as `s9`.

> **Design decision — Chinese labels**: All new `click.Choice` values use Chinese labels for consistency with existing filters (`EXP_CODES`, `EDU_CODES`, `SALARY_TYPE_CODES`, etc.).

> **Design decision — `kwop` and `ro` override**: Remove `"kwop": "7"` and `"ro": "0"` from `DEFAULT_SEARCH_PARAMS`. Instead, set them as explicit defaults in `search_jobs()` so CLI overrides work correctly via the params dict spread pattern.

#### 1b. Add parameters to `client.py:search_jobs()`

Add new keyword arguments:

```python
# client.py — search_jobs() new params
def search_jobs(
    self,
    keyword: str,
    ...,
    # Existing params...
    # New params:
    kwop: str | None = None,        # keyword match mode
    ro: str | None = None,          # job type
    s9: str | None = None,          # work schedule bitmask
    scstrict: bool = False,         # strict salary
    scneg: bool = False,            # exclude negotiable
    exclude_kw: str | None = None,  # exclude keywords
    exclude_indcat: str | None = None,  # exclude industry
    wf: str | None = None,          # welfare filter
) -> dict[str, Any]:
```

#### 1c. Add CLI options to `search` command in `commands/search.py`

New options:
- `--match-mode` → `click.Choice(list(MATCH_MODE_CODES.keys()))`
- `--job-type` → `click.Choice(list(JOB_TYPE_CODES.keys()))`
- `--schedule` → `click.Choice(list(SCHEDULE_CODES.keys()))` with `multiple=True`
- `--salary-strict` → `is_flag=True`
- `--exclude-negotiable` → `is_flag=True`
- `--exclude-kw` → `multiple=True` (repeated `--exclude-kw "管理" --exclude-kw "行政"`)
- `--exclude-indcat` → `multiple=True` (accepts names or codes, resolved via `_resolve_cat_code`)

### Phase 2: Export Command Filter Parity

The `export` command (lines 310-395 in `commands/search.py`) is currently missing many filters that `search` supports. Backport **all** filters from `search` to `export`:

**Already in export**: `--area`, `--exp`, `--edu`, `--company-type`, `--jobcat`, `--indcat`

**Missing from export (existing search filters)**:
- `--salary-type`, `--salary-low`, `--salary-high`
- `--isnew`
- `--remote`
- `--order`

**Missing from export (new filters)**:
- `--match-mode`, `--job-type`, `--schedule`
- `--salary-strict`, `--exclude-negotiable`
- `--exclude-kw`, `--exclude-indcat`

> **Implementation note**: Extract a shared decorator or helper to apply common search filter options to both `search` and `export` commands, avoiding option duplication. Consider a `_search_filter_options` decorator that chains all the common `@click.option` decorators.

### Phase 3: `suggest` Command

#### 3a. Add endpoint constant

```python
# constants.py
KEYWORD_SUGGEST_URL = "/jobs/main/ajax/KeywordSuggest/mixSearch"
```

#### 3b. Add client method

```python
# client.py
def suggest_keywords(self, keyword: str, count: int = 5) -> dict[str, Any]:
    """Get keyword and company suggestions for autocomplete."""
    params = {"scope": "com", "count": count, "kw": keyword}
    return self._get_json(KEYWORD_SUGGEST_URL, params=params, action="關鍵字建議")
```

> **Design decision**: Use the full `Job104Client` pipeline (rate limiting, retry, CF warmup). The suggest endpoint is on the same domain and likely needs the same headers. The ~1s CF warmup only happens on the first request in a session.

#### 3c. Add CLI command

```python
# commands/search.py
@click.command()
@click.argument("keyword")
@structured_output_options
def suggest(keyword: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """關鍵字自動完成建議 (例: job104 suggest 軟體)"""
    ...
```

TTY rendering: Rich table with two sections — "公司建議" and "關鍵字建議".

Register in `cli.py` with `cli.add_command(search.suggest)`.

### Phase 4: Job Model Integration + District Areas

#### 4a. Add missing fields to `Job` dataclass

```python
# models.py — new fields
@dataclass
class Job:
    # ... existing fields ...
    apply_cnt: int = 0
    remote_work_type: int = 0
    employee_count: int = 0
```

Update `from_search_result()` to extract these fields from raw API response.
Update `to_dict()` to include them.

#### 4b. Integrate `Job` model into rendering pipeline

In `commands/search.py`:
1. `_render_job_table()`: Convert `list[dict]` → `list[Job]` via `Job.from_search_result()`
2. Use `Job` attributes instead of `dict.get()` calls
3. `save_index()`: Store `Job.to_dict()` output instead of raw dicts
4. `export()`: Use `Job` objects for CSV field extraction

> **Migration note**: The index cache format changes from raw API dicts to `Job.to_dict()` output. This is safe because the cache only persists the most recent search and is not long-lived.

#### 4c. Fix `resolve_area()` silent fallback

Current behavior: unrecognized area names silently return `""` (全部). This is a data correctness bug.

Fix:

```python
# client.py
def resolve_area(name: str) -> str:
    if name.isdigit() and len(name) >= 6:
        return name
    code = AREA_CODES.get(name)
    if code is None and name != "全部":
        import sys
        print(f"[warning] 找不到地區: {name!r}。使用 job104 areas 查看可用地區。", file=sys.stderr)
        return ""
    return code or ""
```

#### 4d. Add district-level area codes

Add major districts for Taipei, New Taipei, Taichung, Kaohsiung to `AREA_CODES` in `constants.py`. Include all administrative districts for these 4 cities (~60 entries).

Example entries:

```python
# 台北市各區
"台北市中正區": "6001001001",
"台北市大同區": "6001001002",
"台北市中山區": "6001001003",
"台北市松山區": "6001001004",
"台北市大安區": "6001001005",
"台北市信義區": "6001001007",
"台北市內湖區": "6001001010",
"台北市南港區": "6001001011",
# ... etc for all 4 cities
```

> **Note**: District codes need verification against the actual 104 API. The codes in the API survey doc (`6001001010` = 內湖區) should be validated with a test request before hardcoding.

## Acceptance Criteria

### Phase 1: New Search Filters
- [ ] `MATCH_MODE_CODES`, `JOB_TYPE_CODES`, `SCHEDULE_CODES` constants added to `constants.py`
- [ ] `kwop` and `ro` removed from `DEFAULT_SEARCH_PARAMS`; defaults set explicitly in `search_jobs()`
- [ ] `search_jobs()` accepts new parameters: `kwop`, `ro`, `s9`, `scstrict`, `scneg`, `exclude_kw`, `exclude_indcat`, `wf`
- [ ] `search` command has new options: `--match-mode`, `--job-type`, `--schedule` (multiple), `--salary-strict`, `--exclude-negotiable`, `--exclude-kw` (multiple), `--exclude-indcat` (multiple)
- [ ] `--schedule` computes bitmask by OR-ing selected shift values
- [ ] All new filter values displayed in search result title
- [ ] Tests for new filter resolution and bitmask computation

### Phase 2: Export Filter Parity
- [ ] `export` command supports ALL filters that `search` supports
- [ ] Shared filter options extracted to avoid duplication (optional but preferred)
- [ ] `export` tests verify new filters are passed through to `search_jobs()`

### Phase 3: `suggest` Command
- [ ] `KEYWORD_SUGGEST_URL` constant added
- [ ] `suggest_keywords()` method added to `Job104Client`
- [ ] `suggest` command registered in `cli.py`
- [ ] TTY output shows suggestions in a rich table
- [ ] `--json`/`--yaml`/`--md` structured output works
- [ ] Empty keyword produces a helpful error message
- [ ] Tests for suggest command

### Phase 4: Job Model + District Areas
- [ ] `apply_cnt`, `remote_work_type`, `employee_count` added to `Job` dataclass
- [ ] `from_search_result()` and `to_dict()` updated
- [ ] `_render_job_table()` uses `Job` objects instead of raw dicts
- [ ] `save_index()` stores `Job.to_dict()` output
- [ ] `export` CSV uses `Job` objects for field extraction
- [ ] `resolve_area()` warns on unrecognized area names (stderr)
- [ ] District-level codes added for Taipei, New Taipei, Taichung, Kaohsiung
- [ ] District codes verified against 104 API
- [ ] `job104 areas --all` shows districts (optional enhancement)

## Risk Analysis

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| `DEFAULT_SEARCH_PARAMS` kwop/ro override bug | High | Search breaks silently | Remove from DEFAULT_SEARCH_PARAMS; explicit defaults in search_jobs() |
| District area codes incorrect | Medium | Wrong search results | Verify codes with live API request before hardcoding |
| `suggest` API needs different headers | Low | Command fails | Test endpoint with existing client pipeline first |
| `--schedule` bitmask composition edge case | Low | Wrong filter results | Unit test all combinations (single, double, triple, all) |
| Job model migration breaks index cache | Low | `show` command fails once | Cache is ephemeral (last search only); user re-searches |
| Export with strict filters = very slow | Medium | Poor UX | Add progress indicator showing estimated remaining pages |

## References

- API survey: `docs/draft/jobsearch_analysis_api.md`
- Previous migration plan: `docs/plans/2026-03-14-refactor-api-migration-and-search-filters-plan.md`
- Current search implementation: `job104_cli/commands/search.py`
- API client: `job104_cli/client.py`
- Constants: `job104_cli/constants.py`
- Job model: `job104_cli/models.py`
