---
title: "fix: Company search displays empty fields and missing links"
type: fix
date: 2026-03-15
---

# fix: Company search displays empty fields and missing links

## Overview

`job104 company "AI" --zone 外商 --area 台北市` 的 Rich 表格輸出中，員工數、資本額顯示為 `-`（空值），且缺少公司頁面連結與公司簡介。

## Problem Statement

### 1. 欄位名稱不匹配（員工數/資本額顯示為空）

程式碼中使用的欄位名稱與 104 API 實際回傳的欄位名稱不一致：

| 表格欄位 | 程式碼使用 | API 實際回傳 |
|---------|-----------|------------|
| 產業 | `industry` | `industryDesc` |
| 員工數 | `empNo` | `employeeCountDesc` |
| 資本額 | `capital` | `capitalDesc` |

因為 key 不存在，`dict.get()` 回傳預設值 `"-"`，導致這三欄永遠顯示 `-`。

**出問題的程式碼** — `job104_cli/commands/search.py:600-607`：

```python
for i, co in enumerate(companies, 1):
    table.add_row(
        str(i),
        co.get("name", "-"),       # ✓ 正確
        co.get("industry", "-"),   # ✗ 應為 "industryDesc"
        str(co.get("empNo", "-")), # ✗ 應為 "employeeCountDesc"
        co.get("capital", "-"),    # ✗ 應為 "capitalDesc"
    )
```

### 2. 缺少公司頁面與介紹

API 已回傳足夠資訊，但未顯示：

- `encodedCustNo` → 可組出公司頁面網址：`https://www.104.com.tw/company/{encodedCustNo}`
- `profile` → 公司簡介文字（太長不適合放表格，但可放在 `--md` 輸出或加一欄短連結）
- `jobCount` → 公司目前職缺數

## Proposed Solution

### Step 1: 修正欄位名稱映射

修改 `job104_cli/commands/search.py:600-607`，使用正確的 API 欄位名稱：

```python
for i, co in enumerate(companies, 1):
    table.add_row(
        str(i),
        co.get("name", "-"),
        co.get("industryDesc", "-"),
        co.get("employeeCountDesc", "-"),
        co.get("capitalDesc", "-"),
    )
```

> 注意：`employeeCountDesc` 回傳值已經是字串（如 `"員工數100人"`），不需要 `str()` 包裝。

### Step 2: 新增公司頁面連結欄

在表格中新增「公司頁面」欄，利用 `encodedCustNo` 組成連結：

```python
table.add_column("職缺", max_width=6)
table.add_column("公司頁面", style="dim", max_width=50)

# 在 add_row 中加入：
str(co.get("jobCount", 0)),
f"https://www.104.com.tw/company/{co['encodedCustNo']}" if co.get("encodedCustNo") else "-",
```

### Step 3: 更新測試

確認 `tests/` 中相關的 company 指令測試（若有）使用正確的 mock 欄位名稱。

## Acceptance Criteria

- [ ] `job104 company "AI" --zone 外商` 的表格正確顯示產業、員工數、資本額
- [ ] 表格新增公司頁面連結欄（如 `https://www.104.com.tw/company/d9tnh1s`）
- [ ] 表格新增職缺數欄
- [ ] `--json` / `--yaml` 輸出不受影響（它們直接輸出 API raw data）
- [ ] 既有測試通過

## References

- API endpoint: `https://www.104.com.tw/company/ajax/list`
- 出問題的檔案: `job104_cli/commands/search.py:593-609`
- API client: `job104_cli/client.py:369-389`
