---
title: "feat: Expand Personal Center - Resume Detail, Viewers, Follows, History, Recommend"
type: feat
date: 2026-03-15
phase: 3b
---

# feat: Expand Personal Center Commands (Phase 3b)

## Overview

Phase 3a 已實作基礎個人中心命令（applied, saved, interviews, resume overview）。此計畫擴展個人中心功能，新增 6 個命令 + 1 個增強，涵蓋 104 會員中心的完整功能。

## Problem Statement

目前 CLI 只涵蓋 104 會員中心的一小部分功能。使用者仍需回瀏覽器才能：
- 查看履歷的完整內容（工作經歷、學歷、技能等）
- 查看誰看過我的履歷
- 查看關注的公司
- 查看瀏覽紀錄
- 查看專屬推薦工作
- 篩選儲存但未應徵的工作

## 104 會員中心完整功能導覽（Browser Verified）

從瀏覽器驗證的側邊欄結構：

```
My104
├── 履歷 (Resume)
│   ├── 我的履歷 (2)          ✅ 已實作 (resume overview)
│   ├── 履歷開放設定            ❌ 不適合 CLI（需要複雜 UI 互動）
│   ├── AI 自我推薦信 New      ❌ 不適合 CLI（104 專屬功能）
│   ├── 履歷範本              ❌ 不適合 CLI
│   ├── 免費1對1健診           ❌ 不適合 CLI
│   └── AI 履歷健檢            ❌ 不適合 CLI
│
├── 工作 (Jobs)
│   ├── 應徵紀錄              ✅ 已實作 (applied)
│   │   ├── 全部 / 已讀取 / 已回覆 / 已關閉    🆕 新增狀態篩選
│   │   └── 應徵成效分析                       ❌ 複雜圖表，不適合 CLI
│   ├── 誰聯絡我              ⚠️ WebSocket，暫不實作
│   ├── 誰看過我              🆕 新增 (viewers)
│   ├── 儲存工作 (13)         ✅ 已實作 (saved)
│   │   └── 儲存未應徵         🆕 新增 --not-applied 篩選
│   ├── 我的關注 (4)          🆕 新增 (follows)
│   ├── 專屬工作              🆕 新增 (recommend)
│   └── 訂閱條件總覽 (2)       ❌ 設定類，不適合 CLI
│
├── 工具 (Tools)              ❌ 全部為外部連結，不適合 CLI
│   ├── 職業適性測驗 / 職業價值觀測驗 / 升學就業地圖 / ...
│
└── 設定 (Settings)           ❌ 設定類功能，未來考慮
```

## Proposed Solution

### 新增命令一覽

| 命令 | 用途 | API 端點 | 優先級 |
|------|------|----------|--------|
| `job104 resume show [VNO]` | 查看履歷完整內容 | `/profile/ajax/resumeByBlock?vno={vno}` | P0 |
| `job104 viewers` | 查看誰看過我的履歷 | `/api/peruse-record/companies` | P0 |
| `job104 follows` | 查看關注的公司 | `/api/follow-company/companies` | P1 |
| `job104 history` | 查看職缺瀏覽紀錄 | `/viewjobRecord/ajax/list` | P1 |
| `job104 recommend` | 查看專屬推薦工作 | `/api/jobs/personal-recommend-jobs` | P1 |

### 增強現有命令

| 命令 | 增強 | 說明 |
|------|------|------|
| `job104 applied --status <s>` | 狀態篩選 | `all`/`read`/`replied`/`closed` |
| `job104 saved --not-applied` | 未應徵篩選 | `status=notApply` |

---

## Technical Approach

### API Endpoints (Browser Verified)

所有端點已通過瀏覽器實際呼叫驗證，以下為確認的回應結構：

#### 1. Resume Detail（履歷完整內容）

```
GET /profile/ajax/resumeByBlock?vno={vno}
```

**已驗證回應結構：**
```json
{
  "data": {
    "progress": 100,
    "resume": {"name": "...", "vno": "750dw3o2y", "publicStatus": {...}, "resumeType": {...}},
    "info": {
      "formData": {
        "info": {
          "jobStatus": "...", "age": "...", "cellphone": "...",
          "city": "...", "bio": "...", "motto": "...", "trait": "...",
          "personalLink1Url": "..."
        }
      }
    },
    "experience": {
      "formData": {
        "experiences": [{
          "companyName": "迪威智能股份有限公司",
          "jobName": "人工智慧演算法主任工程師",
          "industry": "...", "duration": {...}, "description": "...",
          "skill": [...], "management": {...}, "salary": {...}
        }],
        "seniority": {...}
      }
    },
    "education": {
      "formData": {
        "educations": [{
          "name": "...", "departments": [...], "highest": "...",
          "duration": {...}, "status": "..."
        }]
      }
    },
    "jobCondition": {
      "formData": {
        "jobCondition": {
          "salary": {...}, "preferArea": [...], "preferJobTitle": [...],
          "preferJobType": [...], "remoteWork": "..."
        }
      }
    },
    "skill": {"formData": {"skills": [...]}},
    "certificate": {"formData": {"certificate": [...]}},
    "language": {"formData": {"languages": [...]}},
    "project": {"formData": {...}},
    "portfolio": {"formData": {...}},
    "bio": {"formData": {"bio": "..."}},
    "referrer": {"formData": {...}}
  }
}
```

**取得 vno 方式：** 從 `/profile/ajax/overview` 回應的 `overview[].vno` 或從 `/api/user` 的 `resume.vno`。

#### 2. Who Viewed Me（誰看過我）

```
GET /api/peruse-record/companies
```

**已驗證回應結構：**
```json
{
  "data": [{
    "browseDate": "03/14",
    "custNo": "1a2x6bncom",
    "custName": "拓明科技有限公司",
    "custSwitch": "on",
    "areaDesc": "新北市新店區",
    "industryDesc": "電腦系統整合服務業",
    "jobCount": 5,
    "logo": "https://static.104.com.tw/...",
    "jobCatTag": {"no": 2007001004, "desc": "軟體工程師"},
    "profile": "...",
    "tagNames": ["年終獎金", "三節獎金/禮品", ...],
    "zone": "...",
    "mainScore": "...",
    "saved": false,
    "tracked": false
  }],
  "metadata": {"pagination": {...}}
}
```

**頁面有篩選：** 全部 / 關注公司

#### 3. Followed Companies（我的關注）

```
GET /api/follow-company/companies
```

**已驗證回應結構：**
```json
{
  "data": [{
    "custName": "...",
    "custNo": "...",
    "industryDesc": "...",
    "areaDesc": "...",
    "employeeCountDesc": "...",
    "jobCount": 5,
    "logo": "...",
    "memo": "...",
    "saveDate": "...",
    "tagNames": [...],
    "zone": "...",
    "followedJobs": [...],
    "followedJobCount": 3,
    "mainScore": "..."
  }],
  "metadata": {}
}
```

#### 4. Browsing History（瀏覽紀錄）

```
GET /viewjobRecord/ajax/list?page={n}
```

**已驗證回應結構：**
```json
{
  "data": [{
    "viewDate": "...",
    "jobName": "...",
    "jobNo": "...",
    "custName": "...",
    "custNo": "...",
    "industryDesc": "...",
    "areaDesc": "...",
    "workExpDesc": "...",
    "eduDesc": "...",
    "description": "...",
    "tags": {...},
    "isSaved": false,
    "isApplied": false,
    "applyDate": "...",
    "userApplyCount": 0,
    "analysisType": 0
  }],
  "metadata": {}
}
```

**注意：** 網頁 `/work/jobBrowse` 路徑回 404，但 API `/viewjobRecord/ajax/list` 正常運作。

#### 5. Recommended Jobs（專屬工作）

```
GET /api/jobs/personal-recommend-jobs?group={group}&page={n}&pageSize={size}
```

**已驗證回應結構：**
```json
{
  "data": [{
    "jobName": "...",
    "jobNo": "...",
    "custName": "...",
    "custNo": "...",
    "jobAddrNoDesc": "...",
    "description": "...",
    "applyCnt": "...",
    "tags": {...},
    "isSave": false,
    "isApplied": false,
    "optionEdu": "..."
  }],
  "metadata": {
    "pagination": {"count": 5, "total": 400, "currentPage": 1, "lastPage": 80}
  }
}
```

**推薦類型（從 `/work/mate/ajax/list/all` 取得）：**
- `recommend` — AI 推薦（~400 筆）
- `highchance` — 高度適配（~3000 筆）
- `customer` — 使用者自訂條件

#### 6. Applied Status Filter（應徵狀態篩選）

```
GET /applyRecord/ajax/list?page={n}&status={status}
```

**狀態值：** `all` | `off`

**應徵紀錄頁面 tabs（browser verified）：** 全部 / 已讀取 / 已回覆 / 已關閉

#### 7. Saved Not Applied Filter

```
GET /work/jobStore/ajax/list?page={n}&status=notApply
```

---

### Architecture Changes

```
job104_cli/
├── client.py             # 修改: 新增 5 個 API 方法
├── commands/
│   └── personal.py       # 修改: 新增 5 個命令 + 2 個增強
└── cli.py                # 修改: 註冊新命令
tests/
└── test_personal.py      # 修改: 新增測試
```

### Implementation Phases

#### Phase 3b-1: Resume Detail（最重要，使用者明確要求）

- [x] `client.py`: 新增 `get_resume_detail(vno: str)` 方法，呼叫 `/profile/ajax/resumeByBlock?vno={vno}`
- [x] `client.py`: 修改 `get_resume_overview()` 確保回傳 vno
- [x] `commands/personal.py`: 增強 `resume` 命令，新增 `--detail` / `-d` 選項或子命令 `resume show [VNO]`
- [x] 顯示以下區塊的 Rich Panel：
  - 個人資訊（年齡、求職狀態、城市）
  - 工作經歷（公司、職稱、期間、描述）
  - 學歷（學校、科系、學位）
  - 技能
  - 證照
  - 語言能力
  - 求職條件（期望薪資、地區、職類）
  - 自傳
- [x] `tests/test_personal.py`: resume detail 測試

<details>
<summary>commands/personal.py: resume show 命令設計</summary>

```python
@click.command("resume-show")
@click.argument("vno", required=False)
@structured_output_options
def resume_show(vno: str | None, as_json: bool, as_yaml: bool) -> None:
    """查看履歷完整內容（工作經歷、學歷、技能等）"""
    cred = require_auth()

    def _action(c):
        if not vno:
            # Get first resume's vno from overview
            overview = c.get_resume_overview()
            items = overview.get("data", {}).get("formData", {}).get("overview", [])
            if not items:
                return {"error": "no_resume"}
            first_vno = items[0].get("vno", "")
            return c.get_resume_detail(first_vno)
        return c.get_resume_detail(vno)

    def _render(data: dict) -> None:
        if data.get("error") == "no_resume":
            console.print("[yellow]暫無履歷資料[/yellow]")
            return

        d = data.get("data", data)

        # Resume name
        resume_info = d.get("resume", {})
        console.print(Panel(f"[bold]{resume_info.get('name', '履歷')}[/bold]  完成度: {d.get('progress', 0)}%"))

        # Personal info
        info = d.get("info", {}).get("formData", {}).get("info", {})
        if info:
            table = Table(title="個人資訊", show_lines=True)
            table.add_column("欄位", style="bold")
            table.add_column("內容")
            table.add_row("求職狀態", str(info.get("jobStatus", "")))
            table.add_row("年齡", str(info.get("age", "")))
            table.add_row("城市", str(info.get("city", "")))
            table.add_row("手機", str(info.get("cellphone", "")))
            console.print(table)

        # Work experience
        exps = d.get("experience", {}).get("formData", {}).get("experiences", [])
        if exps:
            table = Table(title=f"工作經歷 ({len(exps)})", show_lines=True)
            table.add_column("#", style="dim", width=3)
            table.add_column("公司", style="green", max_width=25)
            table.add_column("職稱", style="bold cyan", max_width=25)
            table.add_column("期間")
            table.add_column("描述", max_width=40)
            for i, exp in enumerate(exps, 1):
                dur = exp.get("duration", {})
                period = f"{dur.get('startYear','')}/{dur.get('startMonth','')}"
                if exp.get("stillWork"):
                    period += " ~ 至今"
                else:
                    period += f" ~ {dur.get('endYear','')}/{dur.get('endMonth','')}"
                table.add_row(str(i), exp.get("companyName",""), exp.get("jobName",""),
                              period, (exp.get("description","") or "")[:80])
            console.print(table)

        # Education
        edus = d.get("education", {}).get("formData", {}).get("educations", [])
        if edus:
            table = Table(title=f"學歷 ({len(edus)})", show_lines=True)
            table.add_column("學校", style="bold")
            table.add_column("科系")
            table.add_column("學位")
            table.add_column("期間")
            for edu in edus:
                dur = edu.get("duration", {})
                depts = edu.get("departments", [])
                dept_name = depts[0].get("name","") if depts else ""
                table.add_row(edu.get("name",""), dept_name,
                              str(edu.get("highest","")),
                              f"{dur.get('startYear','')}-{dur.get('endYear','')}")
            console.print(table)

        # Skills, certificates, languages...
        # (similar Rich table rendering)

    handle_command(action=_action, render=_render,
                   as_json=as_json, as_yaml=as_yaml, credential=cred)
```

</details>

**交付物：**
- `job104 resume` 顯示履歷列表（保留現有行為）
- `job104 resume-show [VNO]` 顯示履歷完整內容
- 省略 VNO 時自動顯示第一份（主要）履歷

#### Phase 3b-2: Viewers + Follows

- [x] `client.py`: 新增 `get_viewers()` 方法
- [x] `client.py`: 新增 `get_followed_companies()` 方法
- [x] `commands/personal.py`: 實作 `viewers` 命令
  - 顯示: 公司名 / 產業 / 地區 / 職缺數 / 瀏覽日期 / 福利標籤
- [x] `commands/personal.py`: 實作 `follows` 命令
  - 顯示: 公司名 / 產業 / 地區 / 員工規模 / 關注職缺數
- [x] `cli.py`: 註冊 `viewers` 和 `follows` 命令
- [x] `tests/test_personal.py`: viewers/follows 測試

<details>
<summary>client.py: 新增 API 方法</summary>

```python
def get_viewers(self) -> dict[str, Any]:
    """Get companies that viewed your resume."""
    return self._pda_get_json("api/peruse-record/companies", action="誰看過我")

def get_followed_companies(self) -> dict[str, Any]:
    """Get followed/tracked companies."""
    return self._pda_get_json("api/follow-company/companies", action="關注公司")
```

</details>

**交付物：**
- `job104 viewers` 查看哪些公司看過我的履歷
- `job104 follows` 查看關注的公司列表

#### Phase 3b-3: History + Recommend + Filter Enhancements

- [x] `client.py`: 新增 `get_browsing_history(page=1)` 方法
- [x] `client.py`: 新增 `get_recommended_jobs(group="recommend", page=1)` 方法
- [x] `commands/personal.py`: 實作 `history` 命令
  - 顯示: 職缺名 / 公司 / 地區 / 瀏覽日期 / 是否已應徵
- [x] `commands/personal.py`: 實作 `recommend` 命令
  - 選項: `--group recommend|highchance` (預設 recommend)
  - 顯示: 職缺名 / 公司 / 地區 / 應徵人數
- [x] `commands/personal.py`: 增強 `applied` 命令，新增 `--status` 選項
- [x] `commands/personal.py`: 增強 `saved` 命令，新增 `--not-applied` 選項
- [x] Index cache 整合: history/recommend 結果也整合 `job104 show N`
- [x] `tests/test_personal.py`: history/recommend/filter 測試

<details>
<summary>client.py: 新增 API 方法</summary>

```python
def get_browsing_history(self, page: int = 1) -> dict[str, Any]:
    """Get job browsing history."""
    return self._pda_get_json(
        "viewjobRecord/ajax/list",
        params={"page": page},
        action="瀏覽紀錄",
    )

def get_recommended_jobs(self, group: str = "recommend", page: int = 1, page_size: int = 20) -> dict[str, Any]:
    """Get personalized recommended jobs.

    Args:
        group: 'recommend' (AI推薦) or 'highchance' (高度適配).
    """
    return self._pda_get_json(
        "api/jobs/personal-recommend-jobs",
        params={"group": group, "page": page, "pageSize": page_size},
        action="專屬工作",
    )
```

</details>

**交付物：**
- `job104 history [-p PAGE]` 查看瀏覽紀錄
- `job104 recommend [--group recommend|highchance] [-p PAGE]` 查看推薦工作
- `job104 applied --status read|replied|closed` 篩選應徵狀態
- `job104 saved --not-applied` 只看儲存未應徵

---

## Scope Decisions

### In Scope (Phase 3b)

- 5 個新命令: resume-show, viewers, follows, history, recommend
- 2 個增強: applied --status, saved --not-applied
- 所有命令支援 `--json`/`--yaml`
- Index cache 整合（history, recommend）
- 分頁支援

### Out of Scope

| 功能 | 原因 |
|------|------|
| 誰聯絡我 (messages) | 使用 WebSocket + JWT token，架構完全不同，需要獨立設計 |
| 寫入操作 (apply/save/unsave) | 需要 CSRF token 處理，風險較高，留待 Phase 4 |
| 履歷開放設定 | 設定類功能，需要複雜的互動流程 |
| 訂閱條件管理 | 設定類功能 |
| 工具區（測驗、薪資情報等） | 全部為外部連結 |
| 應徵成效分析圖表 | 複雜圖表數據，CLI 呈現有限 |

---

## 完整命令總覽（Phase 3 完成後）

```
job104 CLI — Personal Center Commands

# 搜尋（Phase 1，已完成）
job104 search "AI engineer" --area 台北 --exp 3年
job104 show 3
job104 detail <job_id>

# 認證（Phase 2，已完成）
job104 login / logout / status / me

# 個人中心 — 已完成 (Phase 3a)
job104 applied [-p PAGE]                    # 應徵紀錄
job104 saved [-p PAGE]                      # 儲存工作
job104 interviews                           # 面試邀請
job104 resume                               # 履歷列表

# 個人中心 — 新增 (Phase 3b)
job104 resume-show [VNO]                    # 履歷完整內容 🆕
job104 viewers                              # 誰看過我 🆕
job104 follows                              # 我的關注 🆕
job104 history [-p PAGE]                    # 瀏覽紀錄 🆕
job104 recommend [--group TYPE] [-p PAGE]   # 專屬工作 🆕
job104 applied --status read                # 應徵狀態篩選 🆕
job104 saved --not-applied                  # 儲存未應徵篩選 🆕
```

## Acceptance Criteria

### Functional

- [x] `job104 resume-show` 顯示完整履歷（個人資訊 + 經歷 + 學歷 + 技能 + 證照 + 語言 + 求職條件 + 自傳）
- [x] `job104 resume-show` 省略 VNO 時自動取第一份履歷
- [x] `job104 viewers` 顯示瀏覽公司清單含產業、地區、職缺數
- [x] `job104 follows` 顯示關注公司含職缺數
- [x] `job104 history` 顯示瀏覽過的職缺含日期
- [x] `job104 recommend` 顯示推薦職缺，支援 group 篩選
- [x] `job104 applied --status read` 正確篩選
- [x] `job104 saved --not-applied` 正確篩選
- [x] 所有新命令支援 `--json` / `--yaml`
- [x] 所有新命令未登入時顯示明確錯誤

### Non-Functional

- [x] 沿用現有 `_pda_get_json()` 方法和 rate limiting
- [x] 正確的 Referer 標頭
- [x] UI 文字使用繁體中文

## Files to Create/Modify

### Modified Files
- `job104_cli/client.py` — 新增 5 個 API 方法 (`get_resume_detail`, `get_viewers`, `get_followed_companies`, `get_browsing_history`, `get_recommended_jobs`)
- `job104_cli/commands/personal.py` — 新增 5 個命令 + 增強 2 個現有命令
- `job104_cli/cli.py` — 註冊新命令
- `tests/test_personal.py` — 新增測試

## References

### API Discovery (Browser Verified 2026-03-15)
- `/profile/ajax/resumeByBlock?vno={vno}` — 回傳 20 個區塊：progress, resume, info, education, experience, jobCondition, skill, certificate, language, project, portfolio, bio, referrer, custom1-3
- `/api/peruse-record/companies` — 回傳 20 筆/頁，含 browseDate, custName, industryDesc, jobCatTag, tagNames
- `/api/follow-company/companies` — 回傳全部關注公司，含 followedJobs, followedJobCount
- `/viewjobRecord/ajax/list` — 正常 API 端點（非 SSR），回傳 viewDate, jobName, custName, tags
- `/api/jobs/personal-recommend-jobs?group=recommend` — 回傳最多 400 筆推薦，支援分頁
- `/work/mate/ajax/list/all` — 推薦群組總覽：recommend, highchance, customer

### Internal References
- 既有命令模式: `job104_cli/commands/personal.py`
- API 客戶端: `job104_cli/client.py:381-422`
- 使用者 API 研究: `docs/draft/search.md`
- Phase 3a 計畫: `docs/plans/2026-03-15-feat-personal-center-commands-plan.md`
