---
title: "feat: Auto-Open Browser Login on Auth Failure"
type: feat
date: 2026-03-22
---

# feat: Auto-Open Browser Login on Auth Failure

## Overview

當 CLI 遇到 401（未授權）或找不到憑證時，自動開啟瀏覽器到 `https://signin.104.com.tw/`，使用者登入後 CLI 自動偵測新的 cookies 並繼續操作。

這對第三方工具完全可行——我們不需要 104 配合提供 OAuth endpoint，只需用 `webbrowser.open()` + polling `browser-cookie3` 即可。許多主流 CLI（GitHub CLI、Vercel CLI、Google Cloud SDK）都用類似模式。

---

## Problem Statement

目前當 cookies 失效或不存在時，所有需要登入的指令都會直接 crash 並顯示：

```
[red]未登入，請先使用 job104 login 登入[/red]
# 或
httpx.HTTPStatusError: Client error '401 Unauthorized'
```

使用者必須手動執行 `job104 login`，而且如果還沒在瀏覽器登入，`login` 也會失敗。整個 UX 斷裂、不友善。

---

## Proposed Solution

### 三層防線策略

```
層 1: require_auth() — 沒有本地憑證
  → 問使用者要不要開瀏覽器登入
  → 開啟 https://signin.104.com.tw/ + polling cookies
  → 成功後繼續原本指令

層 2: login --browser 新 flag
  → 明確的「開瀏覽器登入」指令，讓使用者可主動觸發
  → 不需要依賴 auth fail 才能觸發

層 3: client._request() 上的 401 hook (Optional)
  → 若已有 cookies 但 API 回傳 401（session 過期）
  → 觸發 browser-login flow 並 retry 一次
```

### 核心機制：Open + Poll

```python
# auth.py — 新增函式
def browser_login_flow(timeout: int = 120) -> Credential | None:
    """開啟 104 登入頁，polling 直到瀏覽器出現 session cookie。

    Strategy:
    1. webbrowser.open("https://signin.104.com.tw/")
    2. 每 3 秒呼叫 extract_browser_credential()
    3. 有 session cookie (JBCSESS / signin_session) 就視為成功
    4. timeout 後放棄
    """
```

---

## Technical Approach

### 可行性分析

| 問題 | 答案 |
|---|---|
| 104 需要配合嗎？ | 不需要。我們只是開他的公開登入頁，再讀自己電腦上的 cookies |
| browser-cookie3 能讀到新登入的 cookies 嗎？ | 可以。login 完成後 cookies 會寫入 browser profile，下次 extraction 就抓得到 |
| macOS Keychain 問題？ | 已有 subprocess isolation 解決（`auth.py:110-171`），沿用即可 |
| 需要 root / 特殊權限嗎？ | 不需要。`webbrowser.open()` 是標準庫，不需要 root |
| CI/CD 或 headless 環境？ | 需要 guard：偵測到 `not sys.stdin.isatty()` 就跳過，改印出 URL 請使用者手動開 |

### Session Cookie 偵測條件

登入成功的判斷：出現以下任一 cookie（來自 `auth.py:256-262`）：

```python
_SESSION_COOKIE_GROUPS = [
    {"JBCLOGIN"},        # 舊版 auth
    {"JBCSESS"},         # Ory Hydra auth（目前主要用這個）
    {"signin_session"},  # Ory Hydra SSO
]
```

### Polling 實作

```python
import time
import webbrowser

def browser_login_flow(
    url: str = "https://signin.104.com.tw/",
    timeout: int = 120,
    poll_interval: int = 3,
) -> Credential | None:
    """Open browser and poll for session cookies."""
    import sys

    # Headless guard
    if not sys.stdin.isatty():
        console.print(f"[yellow]請在瀏覽器開啟並登入: {url}[/yellow]")
        console.print("[dim]登入後執行 job104 login 取得 cookies[/dim]")
        return None

    console.print(f"[cyan]正在開啟登入頁面...[/cyan]")
    webbrowser.open(url)
    console.print(f"[dim]等待登入（最多 {timeout} 秒）...[/dim]")

    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(poll_interval)
        cred = extract_browser_credential()
        if cred and _has_session_cookie(cred.cookies):
            save_credential(cred)
            return cred

    return None  # timeout
```

### require_auth() 整合

```python
# commands/_common.py
def require_auth(allow_browser_login: bool = True) -> object:
    """Get credential, optionally offering browser login if missing."""
    from ..auth import browser_login_flow, get_credential

    cred = get_credential()
    if cred:
        return cred

    # No credential found
    if allow_browser_login and sys.stdin.isatty():
        console.print("[yellow]未登入[/yellow]")
        if click.confirm("要開啟瀏覽器登入嗎？", default=True):
            cred = browser_login_flow()
            if cred:
                console.print("[green]登入成功！[/green]")
                return cred

    console.print("[red]未登入，請先使用 [bold]job104 login[/bold] 登入[/red]")
    raise SystemExit(1)
```

### login --browser 新 flag

```python
# commands/auth.py
@click.command()
@click.option("--browser", is_flag=True, help="開啟瀏覽器登入（自動偵測 cookies）")
@click.option("--cookie-source", ...)
@click.option("--cookie-file", ...)
def login(browser: bool, cookie_source, cookie_file):
    ...
    if browser:
        from ..auth import browser_login_flow
        console.print("[cyan]開啟瀏覽器到 104 登入頁面...[/cyan]")
        cred = browser_login_flow()
        if not cred:
            console.print("[red]等待逾時或登入失敗[/red]")
            raise SystemExit(1)
        console.print(f"[green]登入成功！({len(cred.cookies)} cookies)[/green]")
        return
    ...
```

---

## Acceptance Criteria

### Functional Requirements

- [x] `job104 login --browser` 開啟 `https://signin.104.com.tw/`，使用者登入後自動偵測 cookies 並顯示登入成功
- [x] 任何需要登入的指令（`resume`, `me`, `applied` 等）在無憑證時，tty 環境下提示「要開啟瀏覽器登入嗎？」
- [x] Polling 在偵測到有效 session cookie（JBCSESS / signin_session）後立即停止，不等到 timeout
- [x] Timeout 120 秒後優雅失敗，顯示 `job104 login` 手動指引
- [x] Headless / non-tty 環境（CI/CD）跳過 browser flow，只印出 URL

### Non-Functional Requirements

- [x] 不引入新的 runtime 依賴（`webbrowser` 是標準庫）
- [x] Polling 不會讓 CLI 完全卡住（每次 poll 是 3 秒 sleep，Ctrl+C 可中斷）
- [x] 不影響 `--json` / `--yaml` 輸出模式下的行為（browser prompt 只在 tty 環境顯示）
- [x] `allow_browser_login=False` 可以關掉（給 agent 使用，不需要互動式 prompt）

### Quality Gates

- [x] `test_auth.py` 新增 `test_browser_login_flow_success` 和 `test_browser_login_flow_timeout`
- [x] `test_cli.py` 驗證 `login --browser` 指令存在且可呼叫
- [x] ruff linting passes

---

## Implementation Phases

### Phase 1: Core — `browser_login_flow()` in `auth.py`

**File:** `job104_cli/auth.py`

- [x] 新增 `browser_login_flow(url, timeout, poll_interval)` 函式
- [x] 使用現有的 `extract_browser_credential()` + `_has_session_cookie()` 判斷成功
- [x] Headless guard: `not sys.stdin.isatty()` → 印 URL 後 return None

### Phase 2: `login --browser` flag

**File:** `job104_cli/commands/auth.py`

- [x] 在 `login` command 加 `--browser` flag
- [x] `--browser` 時呼叫 `browser_login_flow()`，顯示 spinner/progress
- [x] 更新 help text

### Phase 3: `require_auth()` 整合

**File:** `job104_cli/commands/_common.py`

- [x] 在 `require_auth()` 加 browser login prompt（tty-only，需使用者確認）
- [x] 加 `allow_browser_login: bool = True` 參數供 agent 關掉

### Phase 4: Tests

**File:** `tests/test_auth.py`

- [x] Mock `webbrowser.open` 和 `extract_browser_credential` 的輪詢行為
- [x] Test success case: poll 第 2 次就找到 cookies
- [x] Test timeout case: poll 全部失敗
- [x] Test headless case: `isatty()` 返回 False，跳過並印 URL

---

## Dependencies & Risks

| Risk | Likelihood | Mitigation |
|---|---|---|
| 104 登入頁 URL 改變 | Low | URL 作為常數放 `constants.py`，易於更新 |
| browser-cookie3 抓到舊 session 誤判為成功 | Medium | 先清掉本地 credential 再開始 polling，或比較 polling 前後的 cookie 值 |
| 使用者登入了另一個帳號 | Low | 不在 scope，save 最新 cookies 即可 |
| macOS Safari 不支援 browser-cookie3 | Low | 已有 fallback 到其他瀏覽器；Safari 支援是 optional in bc3 |
| Ctrl+C 中斷 polling 時 credential 未儲存 | Medium | 在 `SIGINT` handler 或 try/except KeyboardInterrupt 中處理 |

---

## Files to Change

| File | Change |
|---|---|
| `job104_cli/auth.py` | 新增 `browser_login_flow()` 函式 |
| `job104_cli/constants.py` | 新增 `SIGNIN_URL = "https://signin.104.com.tw/"` 常數 |
| `job104_cli/commands/auth.py` | `login` 加 `--browser` flag |
| `job104_cli/commands/_common.py` | `require_auth()` 加 browser login prompt |
| `tests/test_auth.py` | 新增 browser flow tests |

---

## References

### Internal

- `job104_cli/auth.py:110-201` — `extract_browser_credential()` + subprocess isolation
- `job104_cli/auth.py:256-262` — `_SESSION_COOKIE_GROUPS` session cookie 名稱
- `job104_cli/auth.py:270-273` — `_has_session_cookie()` helper
- `job104_cli/commands/_common.py:119-127` — 現有 `require_auth()`
- `job104_cli/constants.py` — 統一 URL 常數管理

### External

- [Python `webbrowser` module](https://docs.python.org/3/library/webbrowser.html) — 標準庫，無需安裝
- GitHub CLI 的 browser login flow — 類似 polling 設計
