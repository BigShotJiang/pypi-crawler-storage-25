---
title: "fix: Personal center commands return no data after login"
type: fix
date: 2026-03-15
---

# fix: Personal center commands return no data after login

## Overview

After `job104 login` succeeds, several personal center commands (`me`, `saved`, `resume`) fail or return empty data. Investigation reveals API endpoint changes on 104.com.tw that require parameter updates and response handling fixes.

## Problem Statement

Live API testing against `pda.104.com.tw` reveals three broken commands:

| Command | Symptom | Root Cause |
|---------|---------|------------|
| `job104 me` | `Job104ApiError: 收到 HTML 而非 JSON` | Both profile endpoints broken: `pda /api/user` returns `{"data":[]}`, `www /apis/my/profile` returns HTML |
| `job104 saved` | `400 Bad Request` | API now requires `status` param (`all` or `off`) |
| `job104 resume` | Shows only `-` for all fields | Overview endpoint returns resume list metadata, not profile content; render expects name/email/skills |

Working commands: `applied` ✅, `interviews` ✅, `login/logout/status` ✅

## Root Cause Analysis

### 1. `get_saved_jobs()` — Missing required `status` parameter

**File:** `job104_cli/client.py:393-399`

The API at `pda.104.com.tw/work/jobStore/ajax/list` now requires a `status` parameter with value `"all"` or `"off"`. Without it, the server returns:
```json
{"error":{"code":400,"message":"status must be present","details":{}}}
```
Then after adding `page`:
```json
{"error":{"code":400,"message":"status 必須是all或off","details":{}}}
```

**Fix:** Add `status="all"` as default parameter.

### 2. `get_profile()` — Both endpoints broken

**File:** `job104_cli/client.py:339-367`

- `pda.104.com.tw/api/user` returns `{"data":[],"metadata":{}}` — empty array
- `www.104.com.tw/apis/my/profile` returns HTML (200, `text/html`)

The PDA call also bypasses `_request()` entirely (no CF warmup, no retry, no rate limiting).

**Fix:** Refactor `get_profile()` to:
1. Route through `_request()` for proper anti-detection
2. Accept empty response gracefully
3. Try extracting basic user info from `applyRecord/ajax/list` (contains `custName` fields showing the user's applied jobs context)
4. Fall back to a minimal profile dict with auth status confirmation

### 3. `resume` command — Render assumes wrong response shape

**File:** `job104_cli/commands/personal.py:160-239`

`get_resume_overview()` returns:
```json
{
  "data": {
    "formData": {
      "overview": [
        {
          "versionNo": "750dw3o2y",
          "title": "第一份履歷表",
          "resumeType": {"text": "一般履歷", "value": 1},
          "lastModified": 1772373370,
          "publicStatus": {"text": "開放中", "value": 2},
          "isCompleted": true,
          "resumeHash": "tb841m"
        }
      ]
    }
  }
}
```

But `_render()` in the `resume` command tries to extract `name`, `email`, `phone`, `education`, `experience`, `skills`, `autobiography` — none of which exist in this response. All fields display as `-` or empty.

**Fix:** Rewrite `_render()` to display resume list as a table showing title, type, status, last modified, and completeness.

## Proposed Solution

### Phase 1: Fix `get_saved_jobs()` (client.py)

```python
# client.py:393-399
def get_saved_jobs(self, page: int = 1, status: str = "all") -> dict[str, Any]:
    """Get saved/bookmarked jobs from pda.104.com.tw."""
    return self._pda_get_json(
        "work/jobStore/ajax/list",
        params={"page": page, "status": status},
        action="收藏職缺",
    )
```

### Phase 2: Fix `get_profile()` (client.py)

Refactor to route through `_request()` and handle empty/HTML gracefully:

```python
def get_profile(self) -> dict[str, Any]:
    """Get authenticated user's profile information."""
    # Try pda /api/user through proper request pipeline
    try:
        data = self._pda_get_json("api/user", action="個人資料")
        payload = data.get("data", data)
        if payload and payload != []:
            if isinstance(payload, list):
                return payload[0] if payload else data
            return payload
    except Job104ApiError:
        pass

    # Fallback: derive basic info from applied jobs
    try:
        resp = self._pda_get_json(
            "applyRecord/ajax/list",
            params={"page": 1},
            action="個人資料(應徵紀錄)",
        )
        return {"_source": "applied_fallback", "_raw": resp}
    except Job104ApiError:
        pass

    # Last resort: return authenticated-but-no-profile-data indicator
    return {"_source": "none", "authenticated": True}
```

### Phase 3: Rewrite `resume` command render (commands/personal.py)

Show resume list as a table instead of trying to render non-existent profile fields:

```python
def _render(data: dict) -> None:
    # Navigate to the overview list
    form_data = data.get("data", data)
    if isinstance(form_data, dict):
        form_data = form_data.get("formData", form_data)
    overview = form_data.get("overview", [])

    if not overview:
        console.print("[yellow]暫無履歷資料[/yellow]")
        return

    table = Table(title="履歷列表", show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("履歷名稱", style="bold cyan")
    table.add_column("類型", style="green")
    table.add_column("狀態", style="yellow")
    table.add_column("完整度")
    table.add_column("最後修改", style="dim")

    for i, r in enumerate(overview, 1):
        # Convert Unix timestamp to readable date
        modified = r.get("lastModified", 0)
        if modified:
            from datetime import datetime
            mod_str = datetime.fromtimestamp(modified).strftime("%Y/%m/%d")
        else:
            mod_str = "-"

        table.add_row(
            str(i),
            r.get("title", "-"),
            r.get("resumeType", {}).get("text", "-") if isinstance(r.get("resumeType"), dict) else str(r.get("resumeType", "-")),
            r.get("publicStatus", {}).get("text", "-") if isinstance(r.get("publicStatus"), dict) else str(r.get("publicStatus", "-")),
            "✓ 完整" if r.get("isCompleted") else "✗ 未完成",
            mod_str,
        )
    console.print(table)
```

### Phase 4: Fix `me` command render (commands/auth.py)

Update `_render()` to handle the fallback profile shapes:

```python
def _render(info: dict) -> None:
    source = info.get("_source", "")

    if source == "none":
        console.print("[green]已登入[/green]（個人資料 API 暫不可用）")
        return

    if source == "applied_fallback":
        # Show what we can from applied records
        raw = info.get("_raw", {})
        records = raw.get("data", [])
        lines = ["[green]已登入[/green]"]
        if records:
            lines.append(f"已應徵 {len(records)} 筆職缺")
        panel = Panel("\n".join(lines), title="帳號狀態", border_style="cyan")
        console.print(panel)
        return

    # Normal profile rendering (original logic)
    name = info.get("name", info.get("userName", "-"))
    # ... (keep existing render logic)
```

### Phase 5: Update tests

**File:** `tests/test_personal.py`

1. Update `get_saved_jobs` mock data to include `status` param
2. Add test for resume overview rendering with actual API response shape
3. Add test for `me` command fallback paths
4. Update `TestClientPdaMethods` with saved jobs `status` param

**File:** `tests/test_auth.py`

1. Add test for profile fallback chain

## Acceptance Criteria

- [ ] `job104 saved` returns saved job list (not 400 error)
- [ ] `job104 saved --json` returns structured JSON envelope
- [ ] `job104 resume` displays resume list table (title, type, status, last modified)
- [ ] `job104 resume --json` returns structured JSON with overview data
- [ ] `job104 me` does not crash; shows login status or profile data
- [ ] `job104 me --json` returns structured JSON
- [ ] `job104 applied` continues to work (no regression)
- [ ] `job104 interviews` continues to work (no regression)
- [ ] All existing tests pass
- [ ] New tests cover the fixed response shapes

## Technical Considerations

- **API stability**: 104.com.tw changes their API without notice. The fixes should be defensive (handle multiple response shapes).
- **No breaking changes**: The `get_saved_jobs()` parameter change is backwards compatible (default `status="all"`).
- **`get_profile()` refactor**: The direct `self.client.request()` call should be replaced with `self._pda_get_json()` to go through the full anti-detection pipeline.

## Files to Modify

1. `job104_cli/client.py` — Fix `get_saved_jobs()`, refactor `get_profile()`
2. `job104_cli/commands/personal.py` — Rewrite `resume` render
3. `job104_cli/commands/auth.py` — Update `me` render for fallback paths
4. `tests/test_personal.py` — Update tests for new response shapes
5. `tests/test_auth.py` — Add profile fallback tests
