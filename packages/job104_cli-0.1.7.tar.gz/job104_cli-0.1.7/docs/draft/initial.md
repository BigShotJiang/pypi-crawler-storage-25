
I want to to make 台灣104人力銀行的 104_cli, 目的是讓大家可以用coding agent工具如claude code來更好的查找相關資料(職缺等等)。

而你可以參考 /Users/weirenlan/Desktop/self_project/labs/104_cli/docs/refs/boss-cli 的架構，我們的使用情境需求也會差不多。

但是104的操作會有不同。