#!/usr/bin/env python3
"""
Sandflare CLI — manage sandboxes and databases from your terminal.
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

PRIMARY_CONFIG_FILE = Path.home() / ".sandflare" / "config.json"
LEGACY_CONFIG_FILE = Path.home() / ".pandaagent" / "config.json"
DEFAULT_BASE = "https://api.sandflare.io"


def load_config() -> dict:
    for path in (PRIMARY_CONFIG_FILE, LEGACY_CONFIG_FILE):
        if path.exists():
            try:
                return json.loads(path.read_text())
            except Exception:
                pass
    return {}


def save_config(cfg: dict):
    PRIMARY_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    PRIMARY_CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


def get_api_key() -> str:
    return (
        os.environ.get("SANDFLARE_API_KEY")
        or os.environ.get("PANDAAGENT_API_KEY")
        or os.environ.get("AGENTBOX_API_KEY")
        or load_config().get("api_key")
        or ""
    )


def get_base_url() -> str:
    return (
        os.environ.get("SANDFLARE_API_URL")
        or load_config().get("base_url")
        or DEFAULT_BASE
    )


def _headers() -> dict:
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "User-Agent": "sandflare-cli/1.0",
    }
    key = get_api_key()
    if key:
        headers["X-API-Key"] = key
    return headers


def api(method: str, path: str, body: dict | None = None):
    url = get_base_url().rstrip("/") + path
    data = json.dumps(body).encode() if body else None
    req = urllib.request.Request(url, data=data, headers=_headers(), method=method)
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read())
            msg = err.get("error") or err.get("message") or str(e)
        except Exception:
            msg = str(e)
        die(f"API error ({e.code}): {msg}")
    except urllib.error.URLError as e:
        die(f"Connection error: {e.reason}\nIs the server reachable at {get_base_url()}?")


def die(msg: str):
    print(f"\033[31m✗\033[0m {msg}", file=sys.stderr)
    sys.exit(1)


def ok(msg: str):
    print(f"\033[32m✓\033[0m {msg}")


def info(msg: str):
    print(f"\033[90m  {msg}\033[0m")


def _col(s: str, w: int, color: str = "") -> str:
    s = str(s or "")
    truncated = s[: w - 1] + "…" if len(s) > w else s.ljust(w)
    return f"\033[{color}m{truncated}\033[0m" if color else truncated


def _status_color(status: str) -> str:
    mapping = {"running": "32", "ready": "32", "starting": "33", "stopped": "31", "error": "31"}
    return mapping.get(status.lower(), "37")


def print_table(headers: list[str], rows: list[list], widths: list[int]):
    header_line = "  ".join(_col(h, w, "1") for h, w in zip(headers, widths))
    print(f"\033[90m{header_line}\033[0m")
    print("\033[90m" + "─" * sum(w + 2 for w in widths) + "\033[0m")
    for row in rows:
        parts = []
        for index, (cell, width) in enumerate(zip(row, widths)):
            cell_str = str(cell or "")
            if headers[index].lower() == "status":
                parts.append(_col(cell_str, width, _status_color(cell_str)))
            else:
                parts.append(_col(cell_str, width))
        print("  ".join(parts))


def sandbox_create(args):
    body = {}
    if args.template:
        body["template"] = args.template
    if args.name:
        body["name"] = args.name
    if args.size:
        body["size"] = args.size
    result = api("POST", "/sandboxes", body)
    ok(f"Sandbox created: \033[1m{result['name']}\033[0m")
    info(f"Agent URL : {result.get('agent_url', 'starting...')}")
    info(f"Template  : {result.get('template', 'base')}")
    if result.get("ip"):
        info(f"IP        : {result['ip']}")


def sandbox_list(_args):
    result = api("GET", "/sandboxes")
    items = result if isinstance(result, list) else result.get("sandboxes", [])
    if not items:
        info("No sandboxes found.")
        return
    print_table(
        ["NAME", "STATUS", "TEMPLATE", "IP", "CREATED"],
        [
            [
                item.get("name"),
                item.get("status"),
                item.get("template", "base"),
                item.get("ip", ""),
                item.get("created_at", "")[:10] if item.get("created_at") else "",
            ]
            for item in items
        ],
        [18, 10, 14, 16, 12],
    )


def _resolve_sandbox_id(name_or_id: str) -> str:
    """Resolve a sandbox name/label to its ID (sb-xxxxxxxx).
    If name_or_id already looks like a sandbox ID, return it as-is.
    Otherwise fetch the list and find by label match."""
    if name_or_id.startswith("sb-"):
        return name_or_id
    sandboxes = api("GET", "/sandboxes") or []
    if isinstance(sandboxes, dict):
        sandboxes = sandboxes.get("sandboxes", [])
    for sb in sandboxes:
        if sb.get("label") == name_or_id or sb.get("name") == name_or_id:
            return sb.get("name") or sb.get("sandbox_id") or name_or_id
    return name_or_id  # best effort


def sandbox_exec(args):
    sandbox_id = _resolve_sandbox_id(args.name)
    result = api("POST", f"/sandboxes/{sandbox_id}/exec", {"cmd": " ".join(args.cmd)})
    stdout = result.get("stdout", "")
    stderr = result.get("stderr", "")
    if stdout:
        print(stdout, end="" if stdout.endswith("\n") else "\n")
    if stderr:
        print(stderr, end="" if stderr.endswith("\n") else "\n", file=sys.stderr)
    exit_code = result.get("exit_code", 0)
    if exit_code != 0:
        sys.exit(exit_code)


def sandbox_delete(args):
    api("DELETE", f"/sandboxes/{args.name}")
    ok(f"Sandbox \033[1m{args.name}\033[0m deleted.")


def sandbox_shell(args):
    result = api("GET", f"/sandboxes/{args.name}")
    ip = result.get("ip")
    if not ip:
        die(f"Sandbox {args.name} has no IP yet (status: {result.get('status')}). Try again shortly.")
    print(f"\033[90mConnecting to {args.name} ({ip})…\033[0m")
    os.execvp("ssh", ["ssh", "-o", "StrictHostKeyChecking=no", f"root@{ip}"])


def sandbox_keep_alive(args):
    sandbox_id = _resolve_sandbox_id(args.name)
    result = api("POST", f"/sandboxes/{sandbox_id}/timeout", {"timeout": args.seconds})
    ok(f"Sandbox \033[1m{sandbox_id}\033[0m kept alive for {args.seconds}s")
    if result and result.get("new_deadline"):
        info(f"New deadline: {result['new_deadline']}")


def sandbox_browser(args):
    sandbox_id = _resolve_sandbox_id(args.name)
    action = args.browser_action

    if action == "screenshot":
        result = api("GET", f"/sandboxes/{sandbox_id}/browser/screenshot")
        png_b64 = result.get("png", "")
        out = args.output or "screenshot.png"
        import base64
        with open(out, "wb") as f:
            f.write(base64.b64decode(png_b64))
        ok(f"Screenshot saved to \033[1m{out}\033[0m")

    elif action == "navigate":
        if not args.url:
            die("--url is required for navigate")
        result = api("POST", f"/sandboxes/{sandbox_id}/browser/navigate", {"url": args.url})
        ok(f"Navigated to {result.get('url', args.url)}")

    elif action == "text":
        result = api("GET", f"/sandboxes/{sandbox_id}/browser/text")
        print(result.get("text", ""))

    elif action == "html":
        result = api("GET", f"/sandboxes/{sandbox_id}/browser/html")
        print(result.get("html", ""))

    elif action == "elements":
        result = api("GET", f"/sandboxes/{sandbox_id}/browser/elements")
        elements = result.get("elements", [])
        if not elements:
            info("No interactive elements found.")
            return
        print_table(
            ["TAG", "TEXT", "X", "Y", "SELECTOR"],
            [[e.get("tag",""), e.get("text","")[:40], e.get("x",""), e.get("y",""), e.get("selector","")[:30]] for e in elements],
            [8, 42, 6, 6, 32],
        )

    elif action == "click":
        if args.x is None or args.y is None:
            die("--x and --y are required for click")
        result = api("POST", f"/sandboxes/{sandbox_id}/browser/click", {"x": args.x, "y": args.y})
        ok(f"Clicked at ({args.x}, {args.y})")

    elif action == "type":
        if not args.text:
            die("--text is required for type")
        result = api("POST", f"/sandboxes/{sandbox_id}/browser/type", {"text": args.text})
        ok(f"Typed {result.get('length', 0)} characters")

    elif action == "key":
        if not args.key:
            die("--key is required for key")
        result = api("POST", f"/sandboxes/{sandbox_id}/browser/key", {"key": args.key})
        ok(f"Pressed key: {args.key}")

    elif action == "url":
        result = api("GET", f"/sandboxes/{sandbox_id}/browser/url")
        print(result.get("url", ""))

    elif action == "start":
        api("POST", f"/sandboxes/{sandbox_id}/browser/start")
        ok("Browser started")

    else:
        die(f"Unknown browser action: {action}. Valid: screenshot, navigate, text, html, elements, click, type, key, url, start")


def keys_list(_args):
    result = api("GET", "/api-keys")
    items = result if isinstance(result, list) else result.get("keys", [])
    if not items:
        info("No API keys found.")
        return
    print_table(
        ["ID", "PREFIX", "LABEL", "CREATED"],
        [
            [
                item.get("id", ""),
                item.get("key_prefix", ""),
                item.get("label", ""),
                item.get("created_at", "")[:10] if item.get("created_at") else "",
            ]
            for item in items
        ],
        [36, 20, 24, 12],
    )


def keys_create(args):
    body = {}
    if args.label:
        body["label"] = args.label
    result = api("POST", "/api-keys", body)
    ok("API key created:")
    print(f"\n  \033[1;33m{result['key']}\033[0m\n")
    print("  \033[90mStore this securely — it won't be shown again.\033[0m")
    print(f"  Key ID: {result.get('id', '')}")


def keys_revoke(args):
    api("DELETE", f"/api-keys/{args.id}")
    ok(f"API key \033[1m{args.id}\033[0m revoked.")


def config_set_key(args):
    cfg = load_config()
    cfg["api_key"] = args.api_key
    save_config(cfg)
    ok(f"API key saved to {PRIMARY_CONFIG_FILE}")


def config_show(_args):
    cfg = load_config()
    key = cfg.get("api_key", "")
    masked = key[:12] + "…" if len(key) > 12 else key
    print(f"  base_url  : {cfg.get('base_url', DEFAULT_BASE)}")
    print(f"  api_key   : {masked or '(not set)'}")
    cfg_path = PRIMARY_CONFIG_FILE if PRIMARY_CONFIG_FILE.exists() else LEGACY_CONFIG_FILE
    print(f"  config    : {cfg_path}")


# ---------------------------------------------------------------------------
# Template commands
# ---------------------------------------------------------------------------

def _multipart_post(path: str, fields: dict, files: dict) -> dict:
    """POST multipart/form-data to the Sandflare API (no external deps)."""
    import time as _time
    boundary = f"sandflare{int(_time.time() * 1e6):x}"
    parts: list[bytes] = []
    for key, value in fields.items():
        parts.append(
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{key}"\r\n'
            f"\r\n{value}\r\n".encode("utf-8")
        )
    for filename, content in files.items():
        header = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="{filename}"; filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode("utf-8")
        parts.append(header + content + b"\r\n")
    parts.append(f"--{boundary}--\r\n".encode("utf-8"))
    body = b"".join(parts)

    url = get_base_url().rstrip("/") + path
    headers = {
        "X-API-Key": get_api_key(),
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "User-Agent": "sandflare-cli/1.0",
    }
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=600) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read())
            msg = err.get("error") or err.get("message") or str(e)
        except Exception:
            msg = str(e)
        die(f"API error ({e.code}): {msg}")


def _parse_dockerignore(dir_path: Path) -> list:
    ignore_file = dir_path / ".dockerignore"
    if not ignore_file.exists():
        return []
    patterns = []
    for line in ignore_file.read_text(encoding="utf-8", errors="replace").splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            patterns.append(line)
    return patterns


def _dockerignore_matches(rel_path: str, patterns: list) -> bool:
    import fnmatch
    parts = rel_path.replace("\\", "/").split("/")
    for pattern in patterns:
        if pattern.startswith("!"):
            continue
        if fnmatch.fnmatch(rel_path, pattern) or fnmatch.fnmatch(parts[0], pattern):
            return True
        if "/" not in pattern and any(fnmatch.fnmatch(p, pattern) for p in parts):
            return True
    return False


def template_build(args):
    dir_path = Path(args.path).resolve()
    dockerfile_path = dir_path / "Dockerfile"
    if not dockerfile_path.exists():
        die(f"No Dockerfile found in {dir_path}")

    dockerfile_text = dockerfile_path.read_text(encoding="utf-8")
    ignore_patterns = _parse_dockerignore(dir_path)

    # Collect context files
    context_files: dict[str, bytes] = {}
    for file_path in sorted(dir_path.rglob("*")):
        if not file_path.is_file():
            continue
        try:
            rel = file_path.relative_to(dir_path)
        except ValueError:
            continue
        rel_str = rel.as_posix()
        if rel_str == "Dockerfile":
            continue
        if _dockerignore_matches(rel_str, ignore_patterns):
            continue
        context_files[rel_str] = file_path.read_bytes()

    info(f"Packing {len(context_files)} context file(s) from {dir_path}")

    fields = {"name": args.name, "dockerfile": dockerfile_text}
    if args.description:
        fields["description"] = args.description

    result = _multipart_post("/templates/build", fields, context_files)
    template_id = result.get("id") or result.get("template_id", "")
    ok(f"Template build started: \033[1m{template_id}\033[0m")
    info(f"Name    : {args.name}")
    info(f"Context : {len(context_files)} file(s)")

    if args.wait:
        import time as _time
        print(f"\033[90m  Waiting for build to complete…\033[0m")
        deadline = _time.time() + 3600  # 60 min max
        while _time.time() < deadline:
            _time.sleep(5)
            status_result = api("GET", f"/templates/{template_id}/build-status")
            status = status_result.get("status", "")
            if status == "ready":
                ok(f"Template \033[1m{template_id}\033[0m is ready!")
                return
            elif status == "failed":
                die(f"Build failed: {status_result.get('error', 'unknown error')}")
        die("Timed out waiting for build to complete (60 min)")


def template_list(_args):
    result = api("GET", "/templates")
    items = result if isinstance(result, list) else result.get("templates", [])
    custom = [t for t in items if t.get("provider") == "custom"]
    if not custom:
        info("No custom templates found.")
        return
    print_table(
        ["ID", "NAME", "STATUS", "CREATED"],
        [
            [
                t.get("id", ""),
                t.get("name", ""),
                t.get("build_status") or t.get("status", ""),
                (t.get("created_at") or "")[:10],
            ]
            for t in custom
        ],
        [20, 24, 10, 12],
    )


def template_delete(args):
    api("DELETE", f"/templates/{args.id}")
    ok(f"Template \033[1m{args.id}\033[0m deleted.")


def main():
    prog_name = Path(sys.argv[0]).stem or "sandflare"
    parser = argparse.ArgumentParser(
        prog=prog_name,
        description="Sandflare CLI — manage sandboxes",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest="resource", metavar="<resource>")

    sandbox_parser = sub.add_parser("sandbox", aliases=["sb"], help="Manage sandboxes")
    sandbox_sub = sandbox_parser.add_subparsers(dest="action", metavar="<action>")

    sandbox_create_parser = sandbox_sub.add_parser("create", help="Create a sandbox")
    sandbox_create_parser.add_argument("--template", "-t", help="Template name (python, node, fullstack…)")
    sandbox_create_parser.add_argument("--name", "-n", help="Custom name")
    sandbox_create_parser.add_argument("--size", "-s", help="Sandbox tier (nano, small, medium, large, xl)", default=None)
    sandbox_create_parser.set_defaults(func=sandbox_create)

    sandbox_list_parser = sandbox_sub.add_parser("list", aliases=["ls"], help="List sandboxes")
    sandbox_list_parser.set_defaults(func=sandbox_list)

    sandbox_exec_parser = sandbox_sub.add_parser("exec", help="Run a command in a sandbox")
    sandbox_exec_parser.add_argument("name", help="Sandbox name")
    sandbox_exec_parser.add_argument("cmd", nargs=argparse.REMAINDER, help="Command to run")
    sandbox_exec_parser.set_defaults(func=sandbox_exec)

    sandbox_delete_parser = sandbox_sub.add_parser("delete", aliases=["rm", "del"], help="Delete a sandbox")
    sandbox_delete_parser.add_argument("name", help="Sandbox name")
    sandbox_delete_parser.set_defaults(func=sandbox_delete)

    sandbox_shell_parser = sandbox_sub.add_parser("shell", aliases=["ssh"], help="Open a shell in a sandbox")
    sandbox_shell_parser.add_argument("name", help="Sandbox name")
    sandbox_shell_parser.set_defaults(func=sandbox_shell)

    sandbox_keepalive_parser = sandbox_sub.add_parser("keep-alive", aliases=["keepalive", "ka"], help="Extend sandbox lifetime")
    sandbox_keepalive_parser.add_argument("name", help="Sandbox name")
    sandbox_keepalive_parser.add_argument("--seconds", "-s", type=int, default=3600, help="Seconds to extend (default 3600)")
    sandbox_keepalive_parser.set_defaults(func=sandbox_keep_alive)

    sandbox_browser_parser = sandbox_sub.add_parser("browser", aliases=["br"], help="Control the browser inside a sandbox")
    sandbox_browser_parser.add_argument("name", help="Sandbox name")
    sandbox_browser_parser.add_argument("browser_action", metavar="action",
        choices=["screenshot", "navigate", "text", "html", "elements", "click", "type", "key", "url", "start"],
        help="screenshot | navigate | text | html | elements | click | type | key | url | start")
    sandbox_browser_parser.add_argument("--url", help="URL for navigate action")
    sandbox_browser_parser.add_argument("--output", "-o", help="Output file for screenshot (default: screenshot.png)")
    sandbox_browser_parser.add_argument("--x", type=float, help="X coordinate for click")
    sandbox_browser_parser.add_argument("--y", type=float, help="Y coordinate for click")
    sandbox_browser_parser.add_argument("--text", help="Text for type action")
    sandbox_browser_parser.add_argument("--key", help="Key name for key action (e.g. Enter, Tab, Control+c)")
    sandbox_browser_parser.set_defaults(func=sandbox_browser)

    keys_parser = sub.add_parser("keys", help="Manage API keys")
    keys_sub = keys_parser.add_subparsers(dest="action", metavar="<action>")

    keys_list_parser = keys_sub.add_parser("list", aliases=["ls"], help="List API keys")
    keys_list_parser.set_defaults(func=keys_list)

    keys_create_parser = keys_sub.add_parser("create", help="Create an API key")
    keys_create_parser.add_argument("--label", "-l", help="Key label/description")
    keys_create_parser.set_defaults(func=keys_create)

    keys_revoke_parser = keys_sub.add_parser("revoke", aliases=["delete", "rm"], help="Revoke an API key")
    keys_revoke_parser.add_argument("id", help="Key ID to revoke")
    keys_revoke_parser.set_defaults(func=keys_revoke)

    config_parser = sub.add_parser("config", help="CLI configuration")
    config_sub = config_parser.add_subparsers(dest="action", metavar="<action>")

    config_key_parser = config_sub.add_parser("set-key", help="Save API key to config")
    config_key_parser.add_argument("api_key", help="Your pa_live_... API key")
    config_key_parser.set_defaults(func=config_set_key)

    config_show_parser = config_sub.add_parser("show", help="Show current config")
    config_show_parser.set_defaults(func=config_show)

    template_parser = sub.add_parser("template", aliases=["tpl"], help="Manage custom templates")
    template_sub = template_parser.add_subparsers(dest="action", metavar="<action>")

    template_build_parser = template_sub.add_parser("build", help="Build a custom template from a directory")
    template_build_parser.add_argument("path", nargs="?", default=".", help="Directory containing the Dockerfile (default: .)")
    template_build_parser.add_argument("--name", "-n", required=True, help="Template name")
    template_build_parser.add_argument("--description", "-d", default="", help="Optional description")
    template_build_parser.add_argument("--wait", "-w", action="store_true", help="Wait until the build finishes")
    template_build_parser.set_defaults(func=template_build)

    template_list_parser = template_sub.add_parser("list", aliases=["ls"], help="List your custom templates")
    template_list_parser.set_defaults(func=template_list)

    template_delete_parser = template_sub.add_parser("delete", aliases=["rm", "del"], help="Delete a custom template")
    template_delete_parser.add_argument("id", help="Template ID (tpl-xxxxxxxx)")
    template_delete_parser.set_defaults(func=template_delete)

    args = parser.parse_args()
    if not hasattr(args, "func"):
        for subparser in [sandbox_parser, keys_parser, config_parser, template_parser]:
            if args.resource in (
                getattr(subparser, "prog", "").split()[-1:] + list(subparser._option_string_actions.get("aliases", []))
            ):
                subparser.print_help()
                sys.exit(0)
        parser.print_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    main()
