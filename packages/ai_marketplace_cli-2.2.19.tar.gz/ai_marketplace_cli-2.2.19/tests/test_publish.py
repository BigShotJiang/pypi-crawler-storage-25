"""Tests for CLI publish helpers."""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tarfile
from collections.abc import Callable
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
from rich.console import Console
from rich.progress import SpinnerColumn, TextColumn

from aimp_cli.core.config import build_command_context
from aimp_cli.clients.docker import DockerAccessStatus, RegistryAuthStatus
from aimp_cli.core.errors import CliError
from aimp_cli.core.errors import network_error
from aimp_cli.domain.models import (
    CapabilitiesConfig,
    InputDefinition,
    ModeContract,
    ModelSecretListResponse,
    ModelSecretMetadata,
    ModeResourcesConfig,
    ModeReadinessPayload,
    ModesConfig,
    OutputDefinition,
    PublishBuildGroup,
    PublishBuildGroupCreateRequest,
    PublishBuildGroupListResponse,
    PublishBuildProfile,
    PublishRequest,
    PublishResponse,
    ResourceConfig,
    SdkContract,
    SdkModeContract,
    StudioPublishPayload,
    VectorCollectionConfig,
    VectorResourceCollectionsConfig,
)
from aimp_cli.domain.project import (
    ProjectConfig,
    default_tuning_workspace_config,
)
from aimp_cli.domain.publish_config import resolve_studio_file_paths
from aimp_cli.domain.protocols import PublishGatewayProtocol, UploadClientProtocol
from aimp_cli.domain.runtime_packages import OFFICIAL_RUNTIME_DEPENDENCY_SPECS
from aimp_cli.utils.docker_build import MODEL_RUNTIME_DOCKERFILE
from aimp_cli.operations.publish.core import (
    _SOURCE_BUNDLE_STABLE_MTIME,
    _derive_build_requirements,
    _build_platform_root_runner_dockerfile,
    _build_runtime_dependency_wheelhouse,
    _load_runtime_dependency_specs,
    _resolve_runtime_dependency_source_dirs,
    _resolve_runtime_dependency_source_mode,
    _resolve_publish_version as _real_resolve_publish_version,
    _runtime_pythonpaths,
    _build_studio_publish_payload,
    _build_contract_python_candidates,
    _confirm_remote_build_cancel,
    _format_runtime_package_index_targets,
    _reject_legacy_runtime_path_sources,
    _managed_progress,
    _managed_status,
    _wait_for_runtime_package_index_visibility,
    _verify_runtime_packages_downloadable,
    build_mode_readiness_payload,
    build_publish_payload,
    create_source_bundle_archive,
    extract_contract_from_python,
    extract_mode_readiness_from_python,
    publish_model_by_slug,
    run_publish,
    wait_for_publish_build_group,
)
from aimp_cli.operations.publish.project_secrets import (
    ManagedProjectSecrets,
    load_managed_project_secrets,
    sync_managed_project_secrets,
)
from aimp_cli.operations.scaffold.init_project import create_project_scaffold


FRAMEWORK_TEMPLATE_MODULES = (
    Path(__file__).resolve().parents[2]
    / "framework"
    / "aimp_framework"
    / "project_template"
    / "test_modules"
)

DOCS_VECTOR_COLLECTION_PAYLOAD = {
    "alias": "docs",
    "name": "Documents",
    "description": "Document embeddings used by vector-backed modes.",
    "dimension": 1536,
    "metric": "cosine",
}

OFFICIAL_SDK_SPEC = OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]
OFFICIAL_SDK_VERSION = OFFICIAL_SDK_SPEC.split("==", 1)[1]


def _write_runtime_pyproject(
    path: Path,
    *,
    framework_spec: str | None = None,
    sdk_spec: str | None = None,
    include_sources: bool = False,
) -> None:
    framework_dep = framework_spec or OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"]
    sdk_dep = sdk_spec or OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]
    content = [
        "[project]",
        'name = "demo-runtime"',
        'version = "0.1.0"',
        "dependencies = [",
        f'    "{framework_dep}",',
        f'    "{sdk_dep}",',
        "]",
    ]
    if include_sources:
        content.extend(
            [
                "",
                "[tool.uv.sources]",
                'ai-marketplace-framework = { path = "../framework" }',
                'ai-marketplace-sdk = { path = "../sdk" }',
            ]
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(content) + "\n", encoding="utf-8")


def _output(name: str, kind: str) -> OutputDefinition:
    """Build one structured output definition for local project config tests."""
    return OutputDefinition(name=name, kind=kind, required=True)


def _docs_vector_collection() -> VectorCollectionConfig:
    return VectorCollectionConfig(**DOCS_VECTOR_COLLECTION_PAYLOAD)


@pytest.fixture(autouse=True)
def _ensure_project_env(request: pytest.FixtureRequest) -> None:
    if "tmp_path" not in request.fixturenames:
        return
    tmp_path = request.getfixturevalue("tmp_path")
    env_path = tmp_path / ".env"
    if not env_path.exists():
        env_path.write_text("", encoding="utf-8")


@dataclass(slots=True)
class FakeUploadResult:
    """Minimal upload result used by publish tests."""

    storage_uri: str
    artifact_id: str = "artifact-1"
    size_bytes: int = 1


class FakeDockerBase:
    """Typed Docker test double implementing the publish protocol."""

    def inspect_daemon_access(self) -> DockerAccessStatus:
        return DockerAccessStatus(ok=True)

    def build_image(
        self,
        *,
        context_dir: Path,
        tag: str,
        dockerfile: str | None,
        on_line: Callable[[str], None],
    ) -> None:
        _ = context_dir, tag, dockerfile, on_line

    def verify_runtime_sdk(self, image_tag: str) -> None:
        _ = image_tag

    def tag_image(self, source: str, target: str) -> None:
        _ = source, target

    def push_image(self, image_ref: str, on_line: Callable[[str], None]) -> None:
        _ = image_ref, on_line

    def get_image_manifest(self, image_ref: str) -> ImageManifest:
        _ = image_ref
        return ImageManifest(
            digest="sha256:test",
            total_size=1,
            raw_manifest={},
            layers=[ImageManifestLayer(digest="sha256:layer", size=1)],
            media_type="application/vnd.oci.image.manifest.v1+json",
        )

    def save_image(self, image_tag: str, output_path: Path) -> None:
        _ = image_tag
        output_path.write_text("archive", encoding="utf-8")

    def get_registry_auth_status(self, registry_host: str) -> RegistryAuthStatus:
        _ = registry_host
        return RegistryAuthStatus(
            state="configured",
            message="Docker registry credentials configured",
        )

    def get_registry_basic_auth_header(self, registry_host: str) -> str | None:
        _ = registry_host
        return None


class FakeGatewayBase:
    """Typed Gateway test double implementing the publish protocol."""

    def __init__(self) -> None:
        self.build_group_request: PublishBuildGroupCreateRequest | None = None
        self.model_secrets: dict[str, str] = {}
        self.build_group = PublishBuildGroup(
            job_id="group-1",
            slug="demo-model",
            version="0.1.0",
            status="succeeded",
            registration_result={
                "id": "asset-1",
                "slug": "demo-model",
                "visibility": "private",
                "readiness": {"is_ready": True, "blocking_reasons": []},
                "url": "http://localhost:3000/studio/models/demo-model",
            },
            requested_profiles=[
                PublishBuildProfile(
                    runtime_profile="cpu",
                    supported_hardware_tiers=["cpu-basic"],
                )
            ],
        )
        self.stream_lines: list[str] | None = None

    def get_model(self, slug: str) -> None:
        _ = slug
        return None

    def get_model_version(self, slug: str, version: str) -> None:
        _ = slug, version
        return None

    def upload_studio_media(
        self,
        *,
        file_path: Path,
        media_type: str,
    ) -> dict[str, Any]:
        _ = file_path, media_type
        return {
            "storage_uri": "s3://studio/media/object",
            "public_url": "https://cdn.example.com/object",
        }

    def set_model_secret(self, *, model_slug: str, name: str, value: str) -> ModelSecretMetadata:
        _ = model_slug
        self.model_secrets[name] = value
        return ModelSecretMetadata(name=name, is_configured=True)

    def list_model_secrets(self, *, model_slug: str) -> ModelSecretListResponse:
        _ = model_slug
        return ModelSecretListResponse(
            model="demo-model",
            secrets=[
                ModelSecretMetadata(name=name, is_configured=True)
                for name in sorted(self.model_secrets)
            ],
        )

    def delete_model_secret(self, *, model_slug: str, name: str) -> None:
        _ = model_slug
        self.model_secrets.pop(name, None)

    def create_publish_build_group(
        self,
        request: PublishBuildGroupCreateRequest,
    ) -> PublishBuildGroup:
        self.build_group_request = request
        return self.build_group

    def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
        assert job_id == self.build_group.job_id
        return self.build_group

    @contextmanager
    def stream_job(self, job_id: str, **kwargs: Any) -> Any:
        job = {
            "job_id": job_id,
            "job_type": "publish_build_group",
            "model_slug": self.build_group.slug,
            "status": self.build_group.status,
            "timeline": self.build_group.timeline or [],
            "logs": self.build_group.logs or [],
            "details": {"version": self.build_group.version},
        }
        snapshot_payload = {
            "job": job,
            "timeline_count": len(job["timeline"]),
            "log_count": len(job["logs"]),
        }
        lines = self.stream_lines or [
            "event: snapshot",
            f"data: {json.dumps(snapshot_payload)}",
            "",
            "event: terminal",
            f"data: {json.dumps(snapshot_payload)}",
            "",
        ]
        yield iter(lines)

    def list_publish_build_groups(
        self,
        *,
        model_slug: str | None = None,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PublishBuildGroupListResponse:
        _ = model_slug, status, page, page_size
        return PublishBuildGroupListResponse(results=[], pagination={"total_items": 0})

    def cancel_publish_build_group(self, job_id: str) -> Any:
        assert job_id == self.build_group.job_id
        return SimpleNamespace(cancel_state="canceled")

    def delete_publish_build_group(self, job_id: str) -> None:
        assert job_id == self.build_group.job_id

    def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
        _ = request
        raise NotImplementedError

    def publish_model_by_slug(self, slug: str) -> PublishResponse:
        _ = slug
        raise NotImplementedError


@pytest.fixture(autouse=True)
def _stub_runtime_dependency_checks(monkeypatch: pytest.MonkeyPatch) -> None:
    """Keep publish tests focused on orchestration, not external package indexes."""
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._load_runtime_dependency_specs",
        lambda project_dir: {
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._verify_runtime_packages_downloadable",
        lambda **kwargs: None,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._reject_legacy_runtime_path_sources",
        lambda project_dir: None,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_publish_version",
        lambda **kwargs: SimpleNamespace(name="Demo Model", version="0.1.0"),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_runtime_dependency_source_mode",
        lambda project_dir: "published-index",
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._derive_build_pyproject",
        lambda **kwargs: '[project]\nname = "demo-model"\nversion = "0.1.0"\n',
    )


def test_load_runtime_dependency_specs_requires_exact_runtime_pins(tmp_path: Path) -> None:
    _write_runtime_pyproject(
        tmp_path / "pyproject.toml",
        framework_spec="ai-marketplace-framework>=0.1.1,<0.2.0",
        sdk_spec="ai-marketplace-sdk==0.2.0",
    )

    with pytest.raises(CliError) as exc_info:
        _load_runtime_dependency_specs(tmp_path)

    assert exc_info.value.code == "runtime_dependencies_must_be_exact"
    assert OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"] in exc_info.value.message
    assert "ai-marketplace-framework>=0.1.1,<0.2.0" in exc_info.value.message
    assert "pyproject.toml" in exc_info.value.message
    assert "Published runtime images are built from explicit manifests." in exc_info.value.message


def test_load_runtime_dependency_specs_reports_outdated_cli_for_newer_project_pin(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setitem(
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS,
        "ai-marketplace-framework",
        "ai-marketplace-framework==0.4.5",
    )
    monkeypatch.setitem(
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS,
        "ai-marketplace-sdk",
        "ai-marketplace-sdk==0.6.1",
    )
    _write_runtime_pyproject(
        tmp_path / "pyproject.toml",
        framework_spec="ai-marketplace-framework==0.4.6",
        sdk_spec="ai-marketplace-sdk==0.6.1",
    )

    with pytest.raises(CliError) as exc_info:
        _load_runtime_dependency_specs(tmp_path)

    assert exc_info.value.code == "runtime_cli_outdated"
    assert "Your ai CLI runtime manifest is outdated." in exc_info.value.message
    assert "Installed CLI expects ai-marketplace-framework==0.4.5" in exc_info.value.message
    assert "this project uses ai-marketplace-framework==0.4.6" in exc_info.value.message
    assert "Upgrade ai-marketplace-cli" in exc_info.value.message


def test_reject_legacy_runtime_path_sources_fails_with_remediation(tmp_path: Path) -> None:
    _write_runtime_pyproject(
        tmp_path / "pyproject.toml",
        include_sources=True,
    )

    with pytest.raises(CliError) as exc_info:
        _reject_legacy_runtime_path_sources(tmp_path)

    assert exc_info.value.code == "runtime_path_sources_unsupported"
    assert "pyproject.toml" in exc_info.value.message
    assert "Remove [tool.uv.sources] from runtime manifests" in exc_info.value.message
    assert "published index packages or bundled local wheels" in exc_info.value.message


def test_resolve_runtime_dependency_source_mode_uses_main_branch_by_default(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("AIMP_RUNTIME_DEPENDENCY_SOURCE_MODE", raising=False)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(args[0], 0, stdout="main\n", stderr=""),
    )

    assert _resolve_runtime_dependency_source_mode(tmp_path) == "published-index"


def test_resolve_runtime_dependency_source_mode_uses_local_wheels_outside_main(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("AIMP_RUNTIME_DEPENDENCY_SOURCE_MODE", raising=False)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            args[0],
            0,
            stdout="feature/contracts\n",
            stderr="",
        ),
    )

    assert _resolve_runtime_dependency_source_mode(tmp_path) == "bundled-local-wheels"


def test_resolve_runtime_dependency_source_mode_honors_override(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("AIMP_RUNTIME_DEPENDENCY_SOURCE_MODE", "bundled-local-wheels")
    assert _resolve_runtime_dependency_source_mode(tmp_path) == "bundled-local-wheels"


def test_derive_build_requirements_includes_build_backend_and_project_dependencies(
    tmp_path: Path,
) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                'version = "0.1.0"',
                "dependencies = [",
                '    "ai-marketplace-framework==0.4.4",',
                f'    "{OFFICIAL_SDK_SPEC}",',
                '    "httpx==0.28.1",',
                "]",
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
        encoding="utf-8",
    )

    requirements_text = _derive_build_requirements(tmp_path)

    assert requirements_text == (
        f"hatchling\nai-marketplace-framework==0.4.4\n{OFFICIAL_SDK_SPEC}\nhttpx==0.28.1\n"
    )


def test_derive_build_requirements_omits_runtime_dependencies_for_local_wheelhouse(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    project_dir = tmp_path / "model"
    framework_dir = tmp_path / "framework"
    sdk_dir = tmp_path / "sdk"
    project_dir.mkdir()
    framework_dir.mkdir()
    sdk_dir.mkdir()
    (project_dir / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                'version = "0.1.0"',
                "dependencies = [",
                '    "ai-marketplace-framework==0.4.4",',
                f'    "{OFFICIAL_SDK_SPEC}",',
                '    "httpx==0.28.1",',
                "]",
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    (framework_dir / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "ai-marketplace-framework"',
                'version = "0.4.4"',
                "dependencies = []",
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    (sdk_dir / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "ai-marketplace-sdk"',
                f'version = "{OFFICIAL_SDK_VERSION}"',
                "dependencies = [",
                '    "ai-marketplace-framework==0.4.4",',
                '    "datasets",',
                '    "pandas",',
                "]",
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_runtime_dependency_source_dirs",
        lambda _project_dir: (framework_dir, sdk_dir),
    )

    requirements_text = _derive_build_requirements(
        project_dir,
        omit_dependency_names=("ai-marketplace-framework", "ai-marketplace-sdk"),
    )

    assert requirements_text == "hatchling\nhttpx==0.28.1\ndatasets\npandas\n"


def test_official_runtime_dependency_specs_require_protocol_v2_sdk_release() -> None:
    assert OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"] == "ai-marketplace-sdk==0.6.5"


def test_build_runtime_dependency_wheelhouse_collects_wheels(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    project_dir = tmp_path / "repo" / "agents" / "demo"
    project_dir.mkdir(parents=True)
    wheel_dir = tmp_path / "wheelhouse"
    calls: list[Path] = []

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        calls.append(Path(kwargs["cwd"]))
        out_dir = Path(cmd[cmd.index("--out-dir") + 1])
        package_name = "sdk" if "sdk" in str(kwargs["cwd"]) else "framework"
        (out_dir / f"{package_name}-0.0.1-py3-none-any.whl").write_bytes(b"wheel")
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_runtime_dependency_source_dirs",
        lambda _project_dir: (tmp_path / "framework", tmp_path / "sdk"),
    )

    injected = _build_runtime_dependency_wheelhouse(
        project_dir=project_dir,
        output_dir=wheel_dir,
    )

    assert set(injected) == {
        ".aimp/runtime-wheelhouse/framework-0.0.1-py3-none-any.whl",
        ".aimp/runtime-wheelhouse/sdk-0.0.1-py3-none-any.whl",
    }
    assert len(calls) == 2


def test_resolve_runtime_dependency_source_dirs_uses_monorepo_checkout(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("AIMP_FRAMEWORK_SOURCE_ROOT", raising=False)
    monkeypatch.delenv("AIMP_SDK_SOURCE_ROOT", raising=False)
    project_dir = tmp_path / "repo" / "agents" / "demo"
    framework_dir = tmp_path / "repo" / "packages" / "python" / "framework"
    sdk_dir = tmp_path / "repo" / "packages" / "python" / "sdk"
    project_dir.mkdir(parents=True)
    framework_dir.mkdir(parents=True)
    sdk_dir.mkdir(parents=True)
    (framework_dir / "pyproject.toml").write_text("[project]\nname='f'\nversion='0.1.0'\n")
    (sdk_dir / "pyproject.toml").write_text("[project]\nname='s'\nversion='0.1.0'\n")

    assert _resolve_runtime_dependency_source_dirs(project_dir) == (framework_dir, sdk_dir)


def test_resolve_runtime_dependency_source_dirs_honors_explicit_overrides(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    framework_dir = tmp_path / "framework-src"
    sdk_dir = tmp_path / "sdk-src"
    framework_dir.mkdir()
    sdk_dir.mkdir()
    (framework_dir / "pyproject.toml").write_text("[project]\nname='f'\nversion='0.1.0'\n")
    (sdk_dir / "pyproject.toml").write_text("[project]\nname='s'\nversion='0.1.0'\n")
    monkeypatch.setenv("AIMP_FRAMEWORK_SOURCE_ROOT", str(framework_dir))
    monkeypatch.setenv("AIMP_SDK_SOURCE_ROOT", str(sdk_dir))

    assert _resolve_runtime_dependency_source_dirs(tmp_path) == (framework_dir, sdk_dir)


def test_resolve_runtime_dependency_source_dirs_fails_without_buildable_source_roots(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("AIMP_FRAMEWORK_SOURCE_ROOT", raising=False)
    monkeypatch.delenv("AIMP_SDK_SOURCE_ROOT", raising=False)

    with pytest.raises(CliError, match="Bundled local runtime wheels require source checkouts"):
        _resolve_runtime_dependency_source_dirs(tmp_path)


def test_verify_runtime_packages_downloadable_uses_uv_pip_dry_run(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    calls: list[dict[str, Any]] = []

    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", raising=False)

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        calls.append({"cmd": cmd, "env": kwargs.get("env")})
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin="/tmp/python-no-pip",
        python_package_index=None,
    )

    assert len(calls) == 1
    assert calls[0]["cmd"][:5] == [
        "/usr/bin/uv",
        "pip",
        "install",
        "--dry-run",
        "--no-deps",
    ]
    assert calls[0]["cmd"][5:] == [
        "--python",
        "/tmp/python-no-pip",
        "--index-url",
        "https://pypi.org/simple/",
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"],
        OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
    ]
    assert "UV_INDEX" not in (calls[0]["env"] or {})


def test_verify_runtime_packages_downloadable_uses_private_index_env(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env") or {}
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setenv(
        "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL",
        "https://pip.pkg.github.com/acme/simple",
    )
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", "octocat")
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "ghp_test_token")
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin=None,
        python_package_index=None,
    )

    assert captured["cmd"][:4] == ["/usr/bin/uv", "pip", "install", "--dry-run"]
    assert "--index-url" in captured["cmd"]
    default_index_arg = captured["cmd"].index("--index-url")
    assert captured["cmd"][default_index_arg + 1] == "https://pypi.org/simple/"
    assert "--extra-index-url" in captured["cmd"]
    index_arg = captured["cmd"].index("--extra-index-url")
    assert (
        captured["cmd"][index_arg + 1]
        == "https://octocat:ghp_test_token@pip.pkg.github.com/acme/simple"
    )
    assert "UV_INDEX" not in captured["env"]


def test_verify_runtime_packages_downloadable_accepts_unauthenticated_extra_index(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, Any] = {}

    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        captured["cmd"] = cmd
        captured["env"] = kwargs.get("env") or {}
        return subprocess.CompletedProcess(cmd, 0, stdout="", stderr="")

    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL", "https://test.pypi.org/simple/")
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", raising=False)
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    _verify_runtime_packages_downloadable(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_bin=None,
        python_package_index=None,
    )

    assert "--index-url" in captured["cmd"]
    default_index_arg = captured["cmd"].index("--index-url")
    assert captured["cmd"][default_index_arg + 1] == "https://pypi.org/simple/"
    assert "--extra-index-url" in captured["cmd"]
    index_arg = captured["cmd"].index("--extra-index-url")
    assert captured["cmd"][index_arg + 1] == "https://test.pypi.org/simple/"
    assert "UV_INDEX" not in captured["env"]


def test_verify_runtime_packages_downloadable_rejects_partial_extra_index_credentials(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv(
        "AIMP_PYTHON_PACKAGE_EXTRA_INDEX_URL",
        "https://pip.pkg.github.com/acme/simple",
    )
    monkeypatch.delenv("AIMP_PYTHON_PACKAGE_INDEX_USERNAME", raising=False)
    monkeypatch.setenv("AIMP_PYTHON_PACKAGE_INDEX_PASSWORD", "ghp_test_token")
    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    with pytest.raises(CliError) as exc_info:
        _verify_runtime_packages_downloadable(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                    "ai-marketplace-framework"
                ],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_bin=None,
            python_package_index=None,
        )

    assert exc_info.value.code == "python_package_index_config_incomplete"


def test_verify_runtime_packages_downloadable_surfaces_registry_failure(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    def _fake_run(cmd: list[str], **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        raise subprocess.CalledProcessError(
            returncode=1,
            cmd=cmd,
            stderr="No solution found when resolving dependencies",
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.shutil.which", lambda name: "/usr/bin/uv")
    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._wait_for_runtime_package_index_visibility",
        lambda **_: None,
    )

    with pytest.raises(CliError) as exc_info:
        _verify_runtime_packages_downloadable(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                    "ai-marketplace-framework"
                ],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_bin=None,
            python_package_index=None,
        )

    assert exc_info.value.code == "runtime_packages_unavailable"
    assert "configured package index" in exc_info.value.message
    assert "https://pypi.org/simple/" in exc_info.value.message
    assert "No solution found when resolving dependencies" in exc_info.value.message


def test_wait_for_runtime_package_index_visibility_skips_when_index_check_is_indeterminate(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: None,
    )
    sleep_calls: list[float] = []
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.time.sleep",
        lambda seconds: sleep_calls.append(seconds),
    )

    _wait_for_runtime_package_index_visibility(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_package_index=None,
    )

    assert sleep_calls == []


def test_wait_for_runtime_package_index_visibility_waits_for_propagation(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    missing_responses = iter(
        [
            {"ai-marketplace-sdk": "0.2.0"},
            {},
        ]
    )
    messages: list[str] = []
    sleep_calls: list[float] = []

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: next(missing_responses),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.console.print",
        lambda message: messages.append(str(message)),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.time.sleep",
        lambda seconds: sleep_calls.append(seconds),
    )

    _wait_for_runtime_package_index_visibility(
        dependency_specs={
            "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                "ai-marketplace-framework"
            ],
            "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
        },
        python_package_index=None,
    )

    assert len(messages) == 1
    assert "ai-marketplace-sdk==0.2.0" in messages[0]
    assert sleep_calls == [10.0]


def test_wait_for_runtime_package_index_visibility_times_out_with_redacted_indexes(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._missing_runtime_packages_from_indexes",
        lambda **_: {"ai-marketplace-sdk": "0.2.0"},
    )
    monkeypatch.setattr("aimp_cli.operations.publish.core.time.sleep", lambda seconds: None)
    monkeypatch.setattr("aimp_cli.operations.publish.core.console.print", lambda message: None)

    with pytest.raises(CliError) as exc_info:
        _wait_for_runtime_package_index_visibility(
            dependency_specs={
                "ai-marketplace-framework": OFFICIAL_RUNTIME_DEPENDENCY_SPECS[
                    "ai-marketplace-framework"
                ],
                "ai-marketplace-sdk": OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"],
            },
            python_package_index={
                "extra_index_url": "https://pip.pkg.github.com/acme/simple",
                "username": "octocat",
                "password": "ghp_secret",
                "authenticated_extra_index_url": (
                    "https://octocat:ghp_secret@pip.pkg.github.com/acme/simple"
                ),
            },
        )

    assert exc_info.value.code == "runtime_packages_unavailable"
    assert "ai-marketplace-sdk==0.2.0" in exc_info.value.message
    assert "https://pypi.org/simple/" in exc_info.value.message
    assert "https://pip.pkg.github.com/acme/simple/" in exc_info.value.message
    assert "ghp_secret" not in exc_info.value.message


def test_format_runtime_package_index_targets_redacts_credentials() -> None:
    formatted = _format_runtime_package_index_targets(
        {
            "extra_index_url": "https://pip.pkg.github.com/acme/simple",
            "authenticated_extra_index_url": (
                "https://octocat:ghp_secret@pip.pkg.github.com/acme/simple"
            ),
        }
    )

    assert formatted == "https://pypi.org/simple/, https://pip.pkg.github.com/acme/simple/"


def test_confirm_remote_build_cancel_non_tty_defaults_to_keep(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Non-interactive sessions should not auto-cancel remote builds."""

    class _StdinStub:
        @staticmethod
        def isatty() -> bool:
            return False

    monkeypatch.setattr("aimp_cli.operations.publish.core.sys.stdin", _StdinStub())

    assert _confirm_remote_build_cancel("job-123") is False


def test_wait_for_publish_build_group_status_message_includes_job_status(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SSE status updates should include the current job status and job ID."""

    class _StatusStub:
        def __init__(self) -> None:
            self.messages: list[str] = []

        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            self.messages.append(message)

    status_stub = _StatusStub()

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return status_stub

    class _GatewayStub:
        def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
            return PublishBuildGroup(
                job_id=job_id,
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "queued",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

    monkeypatch.setattr("aimp_cli.operations.publish.core.console", _ConsoleStub())
    wait_for_publish_build_group(
        gateway=_GatewayStub(),
        job_id="job-123",
        context=build_command_context("publish.wait", debug=False, json_output=False),
    )

    # Status message should include job status and model slug, but NOT 'Ctrl+C to stop watching'
    assert any("queued" in message for message in status_stub.messages)
    assert any("demo-model" in message for message in status_stub.messages)
    assert not any("Ctrl+C" in message for message in status_stub.messages)


def test_wait_for_publish_build_group_prints_only_new_logs(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """SSE watching should print only log entries that were not shown previously."""

    class _StatusStub:
        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            _ = message

    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return _StatusStub()

        @staticmethod
        def print(message: str, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(message)

    class _GatewayStub:
        def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
            return PublishBuildGroup(
                job_id=job_id,
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
                logs=[
                    {"level": "info", "message": "Downloading source bundle"},
                    {"level": "warning", "message": "Pushing image"},
                    {"level": "error", "message": "final failure line"},
                ],
            )

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "running",
                                    "timeline": [],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Downloading source bundle",
                                        }
                                    ],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 1,
                            }
                        )
                    ),
                    "",
                    "event: logs",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "publish_build_group",
                                "offset": 1,
                                "count": 1,
                                "items": [
                                    {
                                        "level": "warning",
                                        "message": "Pushing image",
                                    }
                                ],
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "timeline": [],
                                    "logs": [
                                        {
                                            "level": "info",
                                            "message": "Downloading source bundle",
                                        },
                                        {
                                            "level": "warning",
                                            "message": "Pushing image",
                                        },
                                        {
                                            "level": "error",
                                            "message": "final failure line",
                                        },
                                    ],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 3,
                            }
                        )
                    ),
                    "",
                ]
            )

    monkeypatch.setattr("aimp_cli.operations.publish.core.console", _ConsoleStub())

    wait_for_publish_build_group(
        gateway=_GatewayStub(),
        job_id="job-123",
        context=build_command_context("publish.wait", debug=False, json_output=False),
    )

    assert printed == [
        "[dim]  Downloading source bundle[/dim]",
        "[yellow]⚠ Pushing image[/yellow]",
        "[red]✗ final failure line[/red]",
    ]


def test_wait_for_publish_build_group_renders_stage_and_step_transitions_once(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Build watch should render Stage/Step separately and dedupe unchanged values."""

    class _StatusStub:
        def __enter__(self) -> _StatusStub:
            return self

        def __exit__(self, exc_type, exc, tb) -> None:
            _ = exc_type, exc, tb

        def update(self, message: str) -> None:
            _ = message

    printed: list[str] = []

    class _ConsoleStub:
        @staticmethod
        def status(*args: Any, **kwargs: Any) -> _StatusStub:
            _ = args, kwargs
            return _StatusStub()

        @staticmethod
        def print(message: str, **kwargs: Any) -> None:
            _ = kwargs
            printed.append(message)

    class _GatewayStub:
        def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
            return PublishBuildGroup(
                job_id=job_id,
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                stage="runtime_matrix_build",
                phase="runtime_matrix_build",
                current_step_message="Runtime contract verification failed",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "running",
                                    "stage": "runtime_matrix_build",
                                    "current_step_message": "Building image",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                    "event: status",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "publish_build_group",
                                "status": "running",
                                "stage": "runtime_matrix_build",
                                "current_step_message": "Building image",
                            }
                        )
                    ),
                    "",
                    "event: status",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job_id": job_id,
                                "job_type": "publish_build_group",
                                "status": "running",
                                "stage": "runtime_matrix_build",
                                "current_step_message": (
                                    "Validating declared runtime vector contract from published image"
                                ),
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": "demo-model",
                                    "status": "succeeded",
                                    "stage": "runtime_matrix_build",
                                    "current_step_message": (
                                        "Validating declared runtime vector contract from published image"
                                    ),
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

    monkeypatch.setattr("aimp_cli.operations.publish.core.console", _ConsoleStub())

    wait_for_publish_build_group(
        gateway=_GatewayStub(),
        job_id="job-123",
        context=build_command_context("publish.wait", debug=False, json_output=False),
    )

    assert printed == [
        "[cyan]Stage:[/cyan] Runtime matrix build",
        "[bold]Step:[/bold] Building image",
        "[bold]Step:[/bold] Validating declared runtime vector contract from published image",
    ]


def test_managed_live_display_prevents_nested_status_progress_live_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Managed publish live helpers should degrade nested live usage safely."""
    test_console = Console(record=True, force_terminal=False)
    monkeypatch.setattr("aimp_cli.operations.publish.core.console", test_console)
    monkeypatch.setattr("aimp_cli.operations.publish.core._LIVE_DISPLAY_DEPTH", 0)

    with _managed_status("outer"):
        with _managed_progress(
            SpinnerColumn(spinner_name="line"),
            TextColumn("{task.description}"),
            transient=True,
        ) as progress:
            task_id = progress.add_task("inner", total=1)
            progress.update(task_id, completed=1)

    assert progress.__class__.__name__ == "_NoopProgress"


def _fake_extract_contract(**kwargs: Any) -> SdkContract:
    _ = kwargs
    return SdkContract(
        schema_version=3,
        resources=ResourceConfig(
            vector_db=VectorResourceCollectionsConfig(
                collections=[VectorCollectionConfig(**DOCS_VECTOR_COLLECTION_PAYLOAD)]
            )
        ),
        modes={
            "generate": SdkModeContract(),
            "search": SdkModeContract(),
            "index": SdkModeContract(),
        },
        parameters={},
        playground=None,
    )


def _fake_mode_readiness(**kwargs: Any) -> ModeReadinessPayload:
    _ = kwargs
    return ModeReadinessPayload.model_validate(
        {
            "generate": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "search": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "index": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
        }
    )


def _fake_project_config(project_dir: Path) -> ProjectConfig:
    _ = project_dir
    return ProjectConfig()


def _fake_publish_config(project_dir: Path) -> SimpleNamespace:
    _ = project_dir
    return SimpleNamespace(
        studio=SimpleNamespace(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article_mdx_file="studio/article.mdx",
            cover_file=None,
            cover_url=None,
        ),
        pricing={"developer_margin": 0},
    )


def _write_local_version_metadata(project_dir: Path, *, version: str) -> None:
    (project_dir / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                f'version = "{version}"',
                'description = "demo model"',
                "",
                "[tool.aimp.project]",
                'author = "tester"',
                "",
            ]
        ),
        encoding="utf-8",
    )


def _ensure_publish_pyproject(project_dir: Path, *, version: str = "0.1.0") -> None:
    """Ensure a minimal ``pyproject.toml`` exists for publish flows that stub extraction."""
    if (project_dir / "pyproject.toml").exists():
        return
    _write_local_version_metadata(project_dir, version=version)


_MINIMAL_PUBLISH_RUNTIME_DOCKERFILE = """\
FROM python:3.11-slim
WORKDIR /app
COPY runtime/pyproject.toml ./pyproject.toml
RUN python -m pip install --no-cache-dir -e .
COPY . .
CMD ["python", "-m", "aimp_sdk.model_runner", "--module", "/app/main.py"]
"""

_MINIMAL_PUBLISH_RUNTIME_PYPROJECT = """\
[project]
name = "demo-runtime"
version = "0.1.0"
dependencies = []
"""


def _ensure_publish_contract_layout(project_dir: Path) -> None:
    """Lay down ``artifacts/`` and framework README files required for ``ai push`` validation."""
    artifacts = project_dir / "artifacts"
    artifacts.mkdir(parents=True, exist_ok=True)
    readme_a = artifacts / "README.md"
    if not readme_a.exists():
        readme_a.write_text(
            "# Execution artifacts\n\nModel bundle root for publish.\n",
            encoding="utf-8",
        )
    runtime_readme = project_dir / "runtime" / "README.md"
    if not runtime_readme.exists():
        runtime_readme.parent.mkdir(parents=True, exist_ok=True)
        runtime_readme.write_text(
            "# Runtime image\n\nContainer image definition only.\n",
            encoding="utf-8",
        )
    artifact_py = artifacts / "artifact.py"
    if not artifact_py.exists():
        artifact_py.write_text(
            "from pathlib import Path\n"
            "def main() -> None:\n"
            "    (Path(__file__).parent / 'w.txt').write_text('ok', encoding='utf-8')\n"
            'if __name__ == "__main__":\n'
            "    main()\n",
            encoding="utf-8",
        )


def _ensure_minimal_publish_runtime(project_dir: Path) -> None:
    """Lay down ``runtime/Dockerfile`` and ``runtime/pyproject.toml`` required for ``ai push``."""
    runtime = project_dir / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    (runtime / "Dockerfile").write_text(_MINIMAL_PUBLISH_RUNTIME_DOCKERFILE, encoding="utf-8")
    (runtime / "pyproject.toml").write_text(_MINIMAL_PUBLISH_RUNTIME_PYPROJECT, encoding="utf-8")
    _ensure_publish_contract_layout(project_dir)


def _build_fake_upload_client(_gateway: PublishGatewayProtocol) -> UploadClientProtocol:
    return _FakeUploadClient()


class _FakeUploadClient:
    """Upload client test double."""

    def upload_file(
        self,
        *,
        file_path: Path,
        slug: str,
        version: str,
        artifact_type: ArtifactType,
        content_type: str,
        metadata: dict[str, Any] | None,
        concurrency: int,
        on_progress: Any | None,
    ) -> FakeUploadResult:
        _ = (
            file_path,
            slug,
            version,
            artifact_type,
            content_type,
            metadata,
            concurrency,
            on_progress,
        )
        return FakeUploadResult(storage_uri="s3://models/demo-model.tar")


def test_build_publish_payload_includes_tuning_when_enabled() -> None:
    tuning_config = default_tuning_workspace_config()
    tuning_dump = tuning_config.model_dump(by_alias=True)
    mode_readiness = ModeReadinessPayload.model_validate(
        {
            "generate": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "search": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
            "index": {
                "declared": True,
                "implemented": True,
                "reason": None,
            },
        }
    )
    sdk_contract = SdkContract(
        schema_version=3,
        resources=ResourceConfig(
            vector_db=VectorResourceCollectionsConfig(
                collections=[
                    VectorCollectionConfig(
                        **DOCS_VECTOR_COLLECTION_PAYLOAD,
                    )
                ]
            )
        ),
        modes={
            "generate": SdkModeContract(),
            "search": SdkModeContract(resources=ModeResourcesConfig(vector_aliases=["docs"])),
            "index": SdkModeContract(resources=ModeResourcesConfig(vector_aliases=["docs"])),
        },
        parameters={},
        tuning=tuning_dump,
    )
    payload = build_publish_payload(
        slug="demo-model",
        version="0.1.0",
        publish_build_group_id="group-1",
        selected_hardware_tier="cpu-basic",
        sdk_contract=sdk_contract,
        required_secrets=["ZAI_API_KEY"],
        mode_readiness=mode_readiness,
        publish_config=SimpleNamespace(
            studio=SimpleNamespace(
                name="Demo Model",
                tags=["example"],
                visibility="private",
            ),
            pricing={"developer_margin": 0},
        ),
        studio=StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    assert payload.contract.get("tuning") is not None
    assert payload.required_secrets == ["ZAI_API_KEY"]
    assert payload.contract["tuning"]["artifacts"]["fields"][0]["key"] == "result"
    assert payload.contract["tuning"]["metrics"]["fields"][0]["key"] == "validation_score"
    assert payload.contract["tuning"]["supports_chaining"] is True
    assert payload.mode_readiness["generate"].implemented is True
    assert payload.publish_build_group_id == "group-1"
    assert payload.selected_hardware_tier == "cpu-basic"
    serialized = payload.model_dump(exclude_none=True)
    assert serialized["selected_hardware_tier"] == "cpu-basic"
    assert "enabled" not in serialized["contract"]["modes"]["generate"]
    assert "enabled" not in serialized["contract"]["modes"]["search"]
    assert "enabled" not in serialized["contract"]["modes"]["index"]


def test_build_publish_payload_excludes_disabled_modes_from_serialized_request() -> None:
    """SDK-only modes appear in the publish contract; readiness lists only implemented modes."""
    sdk_contract = SdkContract(
        schema_version=3,
        resources=ResourceConfig(vector_db=False),
        modes={
            "generate": SdkModeContract(
                inputs=[{"name": "text", "kind": "text", "required": True}],
                outputs=[{"name": "result", "kind": "text", "required": True}],
            ),
        },
        parameters={},
    )
    payload = build_publish_payload(
        slug="demo-model",
        version="0.1.0",
        publish_build_group_id="group-1",
        selected_hardware_tier="cpu-basic",
        sdk_contract=sdk_contract,
        required_secrets=[],
        mode_readiness=ModeReadinessPayload.model_validate(
            {
                "generate": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                },
            }
        ),
        publish_config=SimpleNamespace(
            studio=SimpleNamespace(
                name="Demo Model",
                tags=["example"],
                visibility="private",
            ),
            pricing={"developer_margin": 0},
        ),
        studio=StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    serialized = payload.model_dump(exclude_none=True)
    assert list(serialized["contract"]["modes"].keys()) == ["generate"]
    assert list(serialized["mode_readiness"].keys()) == ["generate"]


def test_build_studio_publish_payload_preserves_cover_media_ref(tmp_path: Path) -> None:
    """Local cover uploads must carry media_ref into the publish payload."""

    class FakeGateway(FakeGatewayBase):
        def upload_studio_media(
            self,
            *,
            file_path: Path,
            media_type: str,
        ) -> dict[str, Any]:
            _ = file_path, media_type
            return {
                "media_ref": "signed-cover-ref",
                "storage_uri": "s3://studio/media/cover.png",
                "public_url": "https://cdn.example.com/cover.png",
            }

    article_path, cover_path = (
        tmp_path / "studio" / "article.mdx",
        tmp_path / "studio" / "cover.png",
    )
    article_path.parent.mkdir(parents=True, exist_ok=True)
    article_path.write_text("# Demo\n", encoding="utf-8")
    cover_path.write_bytes(b"png")

    publish_config = SimpleNamespace(
        studio=SimpleNamespace(
            article_mdx_file="studio/article.mdx",
            cover_file="studio/cover.png",
            cover_url=None,
            name="Demo Model",
            tags=["example"],
            visibility="private",
        )
    )

    resolved_article_path, resolved_cover_path = resolve_studio_file_paths(tmp_path, publish_config)
    assert resolved_article_path == article_path
    assert resolved_cover_path == cover_path

    payload = _build_studio_publish_payload(
        project_dir=tmp_path,
        publish_config=publish_config,
        gateway=FakeGateway(),
    )

    assert payload.cover is not None
    assert payload.cover.media_ref == "signed-cover-ref"
    assert payload.cover.public_url == "https://cdn.example.com/cover.png"


def test_build_contract_python_candidates_prefers_explicit_then_venv_then_cli(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Explicit and active project interpreters must take precedence."""
    project_dir = tmp_path / "demo"
    project_dir.mkdir()
    monkeypatch.setenv("VIRTUAL_ENV", "/project/.venv")
    monkeypatch.setattr(sys, "executable", "/tool/python3.13")

    assert _build_contract_python_candidates("/custom/python", project_dir=project_dir) == [
        "/custom/python",
        str(project_dir / ".venv" / "bin" / "python"),
        str(project_dir / ".venv" / "Scripts" / "python.exe"),
        str(project_dir / ".venv" / "Scripts" / "python"),
        "/project/.venv/bin/python",
        "/project/.venv/Scripts/python.exe",
        "/project/.venv/Scripts/python",
        "/tool/python3.13",
    ]


def test_build_contract_python_candidates_prefers_cli_python_without_venv(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """The project-local venv must win even when the shell venv is inactive."""
    project_dir = tmp_path / "pixis"
    project_dir.mkdir()
    monkeypatch.delenv("VIRTUAL_ENV", raising=False)
    monkeypatch.setattr(sys, "executable", "/tool/python3.13")

    assert _build_contract_python_candidates(None, project_dir=project_dir) == [
        str(project_dir / ".venv" / "bin" / "python"),
        str(project_dir / ".venv" / "Scripts" / "python.exe"),
        str(project_dir / ".venv" / "Scripts" / "python"),
        "/tool/python3.13",
    ]


def test_extract_contract_from_python_reports_candidates_on_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Failure output should include interpreter candidates for diagnosis."""
    module_path = tmp_path / "main.py"
    module_path.write_text("from aimp_sdk import Model\n", encoding="utf-8")
    fake_sdk = tmp_path / "site-packages" / "aimp_sdk" / "__init__.py"
    fake_sdk.parent.mkdir(parents=True)
    fake_sdk.write_text('"""fake sdk"""', encoding="utf-8")

    monkeypatch.setitem(sys.modules, "aimp_sdk", SimpleNamespace(__file__=str(fake_sdk)))
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_contract_python_candidates",
        lambda _python_bin, *, project_dir: [
            "/tool/python3.13",
            str(project_dir / ".venv" / "bin" / "python"),
        ],
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            args=args[0],
            returncode=1,
            stdout="",
            stderr="boom",
        ),
    )

    with pytest.raises(
        Exception,
        match=r"python candidates tried: /tool/python3\.13, .*\.venv/bin/python",
    ):
        extract_contract_from_python(project_dir=tmp_path, python_bin=None)


def test_runtime_pythonpaths_prefers_repo_source_roots_over_installed_site_packages(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    fake_sdk = SimpleNamespace(__file__="/tmp/site-packages/aimp_sdk/__init__.py")
    fake_framework = SimpleNamespace(__file__="/tmp/site-packages/aimp_framework/__init__.py")

    monkeypatch.setitem(sys.modules, "aimp_sdk", fake_sdk)
    monkeypatch.setitem(sys.modules, "aimp_framework", fake_framework)

    paths = _runtime_pythonpaths()

    assert any(path.endswith("/packages/python/sdk") for path in paths)
    assert any(path.endswith("/packages/python/framework") for path in paths)
    assert all("site-packages" not in path for path in paths)


def test_extract_contract_from_python_rejects_legacy_vector_resource_shapes(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Legacy vector resource payloads must fail before remote publish starts."""
    module_path = tmp_path / "main.py"
    module_path.write_text("from aimp_sdk import Model\n", encoding="utf-8")
    fake_sdk = tmp_path / "site-packages" / "aimp_sdk" / "__init__.py"
    fake_sdk.parent.mkdir(parents=True)
    fake_sdk.write_text('"""fake sdk"""', encoding="utf-8")

    monkeypatch.setitem(sys.modules, "aimp_sdk", SimpleNamespace(__file__=str(fake_sdk)))
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_contract_python_candidates",
        lambda _python_bin, *, project_dir: ["/tool/python3.13"],
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.subprocess.run",
        lambda *args, **kwargs: subprocess.CompletedProcess(
            args=args[0],
            returncode=0,
            stdout=json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {"vector": True, "tuning": False},
                    "resources": {"vector_db": {"aliases": ["Documents"]}},
                    "modes": {
                        "search": {
                            "inputs": [{"name": "query", "kind": "text", "required": True}],
                            "resources": {"vector_aliases": ["Documents"]},
                        }
                    },
                    "parameters": {},
                }
            ),
            stderr="",
        ),
    )

    with pytest.raises(CliError) as exc_info:
        extract_contract_from_python(project_dir=tmp_path, python_bin=None)

    assert exc_info.value.code == "legacy_python_contract_shape"
    assert "resources.vector_db.collections" in exc_info.value.message
    assert exc_info.value.extra["legacy_shape"] == "resources.vector_db.aliases"


def test_extract_contract_from_python_does_not_inject_legacy_accelerator_backend_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Contract extraction should not receive legacy runtime backend env injection."""
    module_path = tmp_path / "main.py"
    module_path.write_text("from aimp_sdk import Model\n", encoding="utf-8")
    fake_sdk = tmp_path / "site-packages" / "aimp_sdk" / "__init__.py"
    fake_sdk.parent.mkdir(parents=True)
    fake_sdk.write_text('"""fake sdk"""', encoding="utf-8")

    captured_envs: list[dict[str, str]] = []

    monkeypatch.setitem(sys.modules, "aimp_sdk", SimpleNamespace(__file__=str(fake_sdk)))
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_contract_python_candidates",
        lambda _python_bin, *, project_dir: ["/tool/python3.13"],
    )

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        captured_envs.append(dict(kwargs["env"]))
        return subprocess.CompletedProcess(
            args=args[0],
            returncode=0,
            stdout=json.dumps(
                {
                    "schema_version": 4,
                    "capabilities": {},
                    "resources": {},
                    "modes": {},
                    "parameters": {},
                }
            ),
            stderr="",
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)

    extract_contract_from_python(
        project_dir=tmp_path,
        python_bin=None,
        publish_config=SimpleNamespace(),
    )

    assert len(captured_envs) == 1
    assert "MODEL_ACCELERATOR_BACKEND" not in captured_envs[0]


def test_extract_contract_and_mode_readiness_from_unified_init_project(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_scaffold("demo-model")

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        argv = args[0]
        if "aimp_sdk.contract" in argv:
            payload = {
                "schema_version": 4,
                "capabilities": {"vector": False, "tuning": False},
                "resources": {"vector_db": False},
                "modes": {
                    "generate": {
                        "inputs": [{"name": "prompt", "kind": "text", "required": True}],
                        "outputs": [{"name": "text", "kind": "text", "required": True}],
                    }
                },
                "parameters": {},
            }
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout=json.dumps(payload), stderr=""
            )
        if "aimp_sdk.mode_readiness" in argv:
            payload = {
                "generate": {"implemented": True, "reason": None},
                "search": {
                    "implemented": False,
                    "reason": "search() is not implemented by this model",
                },
                "index": {
                    "implemented": False,
                    "reason": "index() is not implemented by this model",
                },
            }
            return subprocess.CompletedProcess(
                args=argv, returncode=0, stdout=json.dumps(payload), stderr=""
            )
        return subprocess.CompletedProcess(
            args=argv, returncode=1, stdout="", stderr="unexpected tool"
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)

    contract = extract_contract_from_python(project_dir=project_dir, python_bin=sys.executable)
    readiness = extract_mode_readiness_from_python(
        project_dir=project_dir,
        python_bin=sys.executable,
    )

    assert sorted(contract.modes.keys()) == ["generate"]
    assert "hardware_tier" not in contract.model_dump()
    assert "runtime_profile" not in contract.model_dump()
    assert "supported_hardware_tiers" not in contract.model_dump()
    assert contract.modes["generate"].inputs[0].name == "prompt"
    assert readiness["generate"].implemented is True
    assert readiness["search"].implemented is False
    assert readiness["index"].implemented is False


def test_extract_contract_from_python_ignores_legacy_hardware_fields(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_scaffold("demo-model")

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        argv = args[0]
        if "aimp_sdk.contract" not in argv:
            return subprocess.CompletedProcess(
                args=argv, returncode=1, stdout="", stderr="unexpected"
            )
        payload = {
            "schema_version": 4,
            "capabilities": {"vector": False, "tuning": False},
            "resources": {"vector_db": False},
            "modes": {},
            "parameters": {},
            "hardware_tier": "cpu-basic",
        }
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout=json.dumps(payload), stderr=""
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)

    contract = extract_contract_from_python(project_dir=project_dir, python_bin=sys.executable)
    payload = contract.model_dump()
    assert payload["schema_version"] == 4
    assert "hardware_tier" not in payload
    assert "runtime_profile" not in payload
    assert "supported_hardware_tiers" not in payload


def test_extract_contract_from_python_preserves_playground_contract(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_scaffold("demo-model")

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        argv = args[0]
        if "aimp_sdk.contract" not in argv:
            return subprocess.CompletedProcess(
                args=argv, returncode=1, stdout="", stderr="unexpected"
            )
        payload = {
            "schema_version": 4,
            "capabilities": {"vector": True, "tuning": False},
            "resources": {
                "vector_db": {
                    "collections": [
                        {
                            **DOCS_VECTOR_COLLECTION_PAYLOAD,
                        }
                    ]
                }
            },
            "modes": {
                "index": {
                    "inputs": [{"name": "images", "kind": "image", "required": True}],
                    "outputs": [{"name": "indexed", "kind": "json", "required": True}],
                    "parameters": {},
                    "description": "Index images",
                }
            },
            "playground": {
                "index": {
                    "response": [
                        {
                            "preset": "table",
                            "field": "indexed",
                            "columns": ["image_id", "filename"],
                        }
                    ]
                }
            },
            "parameters": {},
        }
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout=json.dumps(payload), stderr=""
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)

    contract = extract_contract_from_python(project_dir=project_dir, python_bin=sys.executable)

    assert contract.playground == {
        "index": {
            "response": [
                {
                    "preset": "table",
                    "field": "indexed",
                    "columns": ["image_id", "filename"],
                }
            ]
        }
    }


def test_extract_contract_from_python_preserves_mode_display_metadata(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.chdir(tmp_path)
    project_dir = create_project_scaffold("demo-model")

    def _fake_run(*args: Any, **kwargs: Any) -> subprocess.CompletedProcess[str]:
        _ = kwargs
        argv = args[0]
        if "aimp_sdk.contract" not in argv:
            return subprocess.CompletedProcess(
                args=argv, returncode=1, stdout="", stderr="unexpected"
            )
        payload = {
            "schema_version": 4,
            "capabilities": {"vector": False, "tuning": False},
            "resources": {"vector_db": False},
            "modes": {
                "thinking": {
                    "label": "Thinking",
                    "description": "Streams reasoning and answer responses.",
                    "inputs": [{"name": "message", "kind": "text", "required": True}],
                    "outputs": [{"name": "answer", "kind": "text", "required": True}],
                    "parameters": {},
                }
            },
            "parameters": {},
        }
        return subprocess.CompletedProcess(
            args=argv, returncode=0, stdout=json.dumps(payload), stderr=""
        )

    monkeypatch.setattr("aimp_cli.operations.publish.core.subprocess.run", _fake_run)

    contract = extract_contract_from_python(project_dir=project_dir, python_bin=sys.executable)
    payload = contract.model_dump(exclude_none=True)

    assert payload["modes"]["thinking"]["label"] == "Thinking"
    assert payload["modes"]["thinking"]["description"] == (
        "Streams reasoning and answer responses."
    )


def test_extract_mode_readiness_from_python_detects_missing_public_methods(
    tmp_path: Path,
) -> None:
    contract_path = tmp_path / "contract.toml"
    app_path = tmp_path / "main.py"
    contract_path.write_text(
        "[project]\nname = 'demo'\nversion = '0.1.0'\nauthor = 'test'\ndescription = 'demo'\n",
        encoding="utf-8",
    )
    shutil.copy2(FRAMEWORK_TEMPLATE_MODULES / "functional_mode_generate.py", app_path)

    readiness = extract_mode_readiness_from_python(
        project_dir=tmp_path,
        python_bin=sys.executable,
        mode_names=["generate", "search", "index"],
    )

    assert readiness["generate"].implemented is True
    assert readiness["search"].implemented is False
    assert readiness["index"].implemented is False
    assert readiness["index"].reason == "index() is not implemented by this model"


def test_build_mode_readiness_payload_marks_declared_but_missing_modes() -> None:
    implementation_status = ModeReadinessPayload.model_validate(
        {
            "generate": {"declared": True, "implemented": True, "reason": None},
            "search": {"declared": True, "implemented": True, "reason": None},
            "index": {
                "declared": True,
                "implemented": False,
                "reason": "index() is not implemented by this model",
            },
        }
    )

    payload = build_mode_readiness_payload(
        mode_names=["search", "index"],
        implementation_status=implementation_status,
    )

    assert "generate" not in payload
    assert payload["search"].declared is True
    assert payload["search"].implemented is True
    assert payload["index"].declared is True
    assert payload["index"].implemented is False
    assert payload["index"].reason == "index() is not implemented by this model"


def test_create_source_bundle_archive_respects_dockerignore(tmp_path: Path) -> None:
    """Source bundle must mirror Docker context exclusions for remote builds."""
    build_context = tmp_path

    (build_context / "Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    (build_context / ".dockerignore").write_text(
        "\n".join(
            [
                "ignored.txt",
                "build/",
                "!build/keep.txt",
                "Dockerfile",
            ]
        ),
        encoding="utf-8",
    )
    (build_context / "included.txt").write_text("keep", encoding="utf-8")
    (build_context / "ignored.txt").write_text("drop", encoding="utf-8")
    (build_context / "build").mkdir()
    (build_context / "build" / "keep.txt").write_text("keep", encoding="utf-8")
    (build_context / "build" / "drop.txt").write_text("drop", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert ".dockerignore" in names
    assert "Dockerfile" in names
    assert "included.txt" in names
    assert "build/keep.txt" in names
    assert "ignored.txt" not in names
    assert "build/drop.txt" not in names


def test_create_source_bundle_archive_forces_publish_contract_files_when_dockerignore_excludes_them(
    tmp_path: Path,
) -> None:
    """Source bundles must keep publish-critical project config files."""
    build_context = tmp_path

    (build_context / "Dockerfile").write_text(
        (
            "FROM python:3.13-slim\n"
            "COPY pyproject.toml ./\n"
            "COPY main.py ./main.py\n"
            "RUN pip install --no-cache-dir --no-deps --no-build-isolation .\n"
        ),
        encoding="utf-8",
    )
    (build_context / ".dockerignore").write_text("*\n", encoding="utf-8")
    (build_context / "pyproject.toml").write_text(
        "[project]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8"
    )
    (build_context / ".aimp").mkdir()
    (build_context / ".aimp" / "project.toml").write_text("schema_version = 3\n", encoding="utf-8")
    (build_context / ".aimp" / "publish.toml").write_text("schema_version = 4\n", encoding="utf-8")
    (build_context / "main.py").write_text("print('ok')\n", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert "pyproject.toml" in names
    assert ".aimp/project.toml" in names
    assert ".aimp/publish.toml" in names
    assert "main.py" not in names


def test_create_source_bundle_archive_includes_artifacts_when_dockerignore_excludes_them(
    tmp_path: Path,
) -> None:
    """Execution assets live under artifacts/ but are excluded from Docker context via .dockerignore.

    The publish tarball must still contain artifacts/ so the remote worker can run
    artifacts/artifact.py and package publish.artifact_path.
    """
    build_context = tmp_path
    (build_context / ".dockerignore").write_text(
        "\n".join(
            [
                "artifacts/",
            ]
        ),
        encoding="utf-8",
    )
    art = build_context / "artifacts"
    art.mkdir()
    (art / "README.md").write_text("# Artifacts\n", encoding="utf-8")
    (art / "artifact.py").write_text("print('prep')\n", encoding="utf-8")
    (build_context / "main.py").write_text("x=1\n", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert "artifacts/README.md" in names
    assert "artifacts/artifact.py" in names


def test_create_source_bundle_archive_rejects_symlinks(tmp_path: Path) -> None:
    """Source bundle creation must fail fast when context contains symlinks."""
    build_context = tmp_path
    (build_context / "Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    (build_context / "target.txt").write_text("content\n", encoding="utf-8")
    (build_context / "linked.txt").symlink_to(build_context / "target.txt")

    with pytest.raises(CliError) as exc_info:
        create_source_bundle_archive(build_context=build_context, dockerfile=None)

    assert exc_info.value.code == "publish_source_bundle_symlink_unsupported"
    assert "linked.txt" in str(exc_info.value)


def test_create_source_bundle_archive_excludes_default_python_artifacts(tmp_path: Path) -> None:
    """Source bundle should skip local virtualenv/cached files by default."""
    build_context = tmp_path
    (build_context / "Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    (build_context / ".venv").mkdir()
    (build_context / ".venv" / "pyvenv.cfg").write_text("home=/tmp\n", encoding="utf-8")
    (build_context / "module.pyc").write_text("x", encoding="utf-8")
    (build_context / "pkg").mkdir()
    (build_context / "pkg" / "__pycache__").mkdir()
    (build_context / "pkg" / "__pycache__" / "m.cpython-313.pyc").write_text(
        "x",
        encoding="utf-8",
    )
    (build_context / "main.py").write_text("print('ok')\n", encoding="utf-8")

    bundle_path = create_source_bundle_archive(build_context=build_context, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            names = set(archive.getnames())
    finally:
        bundle_path.unlink(missing_ok=True)

    assert "Dockerfile" in names
    assert "main.py" in names
    assert ".venv/pyvenv.cfg" not in names
    assert "module.pyc" not in names
    assert "pkg/__pycache__/m.cpython-313.pyc" not in names


def test_codex_source_bundle_installs_project_after_copy(tmp_path: Path) -> None:
    """The bundled Dockerfile must install dependencies before copied source."""
    project_dir = tmp_path
    (project_dir / "Dockerfile").write_text(
        (
            "FROM python\n"
            "COPY pyproject.toml ./\n"
            "RUN pip install --no-cache-dir -r /tmp/build-requirements.txt\n"
            "COPY main.py ./main.py\n"
            "COPY model ./model\n"
            "RUN pip install --no-cache-dir --no-deps --no-build-isolation .\n"
            "CMD python main.py\n"
        ),
        encoding="utf-8",
    )
    (project_dir / "pyproject.toml").write_text(
        "[project]\nname='demo'\nversion='0.1.0'\n", encoding="utf-8"
    )

    bundle_path = create_source_bundle_archive(build_context=project_dir, dockerfile=None)
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            dockerfile = archive.extractfile("Dockerfile")
            assert dockerfile is not None
            dockerfile_content = dockerfile.read().decode("utf-8")
    finally:
        bundle_path.unlink(missing_ok=True)

    copy_manifest_index = dockerfile_content.index("COPY pyproject.toml ./")
    dependency_run_index = dockerfile_content.index(
        "RUN pip install --no-cache-dir -r /tmp/build-requirements.txt"
    )
    copy_model_index = dockerfile_content.index("COPY model ./model")
    run_index = dockerfile_content.index(
        "RUN pip install --no-cache-dir --no-deps --no-build-isolation ."
    )
    assert copy_manifest_index < dependency_run_index < copy_model_index < run_index


def test_build_platform_root_runner_dockerfile_uses_platform_model_runner() -> None:
    dockerfile_text = _build_platform_root_runner_dockerfile().decode("utf-8")

    assert dockerfile_text.startswith("# syntax=docker/dockerfile:1.7\n")
    assert "Platform-managed model runner" in dockerfile_text
    assert 'python", "-m", "aimp_sdk.model_runner"' in dockerfile_text
    assert '"/app/main.py"' in dockerfile_text
    assert "runtime-wheelhouse" in dockerfile_text
    assert "--mount=type=cache,target=/root/.cache/pip" in dockerfile_text
    assert "COPY pyproject.toml /app/pyproject.toml" in dockerfile_text
    assert "COPY . /app" in dockerfile_text
    assert "pip install --no-cache-dir --no-deps --no-build-isolation /app" in dockerfile_text
    assert (
        "pip install -r /app/.aimp/platform-root-runtime/build-requirements.txt" in dockerfile_text
    )
    assert "pip install --no-deps /app/.aimp/runtime-wheelhouse/*.whl" in dockerfile_text


def test_build_platform_root_runner_dockerfile_installs_dependencies_before_source_copy() -> None:
    dockerfile_text = _build_platform_root_runner_dockerfile().decode("utf-8")

    copy_manifest_index = dockerfile_text.index("COPY pyproject.toml /app/pyproject.toml")
    copy_build_req_index = dockerfile_text.index(
        "COPY .aimp/platform-root-runtime/build-requirements.txt "
        "/app/.aimp/platform-root-runtime/build-requirements.txt"
    )
    copy_wheelhouse_index = dockerfile_text.index(
        "COPY .aimp/runtime-wheelhouse/ /app/.aimp/runtime-wheelhouse/"
    )
    dependency_run_index = dockerfile_text.index(
        "RUN --mount=type=cache,target=/root/.cache/pip if [ -s /app/.aimp/platform-root-runtime/build-requirements.txt ]"
    )
    copy_full_aimp_index = dockerfile_text.index("COPY .aimp/ /app/.aimp/")
    copy_source_index = dockerfile_text.index("COPY . /app")
    install_project_index = dockerfile_text.index(
        "RUN --mount=type=cache,target=/root/.cache/pip pip install --no-cache-dir --no-deps --no-build-isolation /app"
    )

    assert (
        copy_manifest_index
        < copy_build_req_index
        < copy_wheelhouse_index
        < dependency_run_index
        < copy_full_aimp_index
        < copy_source_index
        < install_project_index
    )
    assert "pip install --no-deps /app/.aimp/runtime-wheelhouse/*.whl" in dockerfile_text
    assert dockerfile_text.index("COPY .aimp/ /app/.aimp/") > dependency_run_index


def test_create_source_bundle_archive_injected_files_use_stable_mtime(tmp_path: Path) -> None:
    """Injected bundle members must not use wall-clock mtimes (Docker cache stability)."""
    build_context = tmp_path
    (build_context / "Dockerfile").write_text("FROM scratch\n", encoding="utf-8")

    injected = {".aimp/platform-root-runtime/Dockerfile": b"# stub\n"}
    path_a = create_source_bundle_archive(
        build_context=build_context,
        dockerfile=None,
        injected_files=injected,
    )
    path_b = create_source_bundle_archive(
        build_context=build_context,
        dockerfile=None,
        injected_files=injected,
    )
    try:
        with (
            tarfile.open(path_a, mode="r:gz") as archive_a,
            tarfile.open(path_b, mode="r:gz") as archive_b,
        ):
            member_a = archive_a.getmember(".aimp/platform-root-runtime/Dockerfile")
            member_b = archive_b.getmember(".aimp/platform-root-runtime/Dockerfile")
    finally:
        path_a.unlink(missing_ok=True)
        path_b.unlink(missing_ok=True)

    assert member_a.mtime == member_b.mtime == _SOURCE_BUNDLE_STABLE_MTIME


def test_create_source_bundle_archive_derived_pyproject_uses_stable_mtime(tmp_path: Path) -> None:
    build_context = tmp_path
    (build_context / "Dockerfile").write_text("FROM scratch\n", encoding="utf-8")
    (build_context / "pyproject.toml").write_text(
        "[project]\nname='x'\nversion='0.1.0'\n", encoding="utf-8"
    )

    derived = "[project]\nname='y'\nversion='0.2.0'\n"
    path_a = create_source_bundle_archive(
        build_context=build_context,
        dockerfile=None,
        derived_pyproject_text=derived,
    )
    path_b = create_source_bundle_archive(
        build_context=build_context,
        dockerfile=None,
        derived_pyproject_text=derived,
    )
    try:
        with (
            tarfile.open(path_a, mode="r:gz") as archive_a,
            tarfile.open(path_b, mode="r:gz") as archive_b,
        ):
            member_a = archive_a.getmember("pyproject.toml")
            member_b = archive_b.getmember("pyproject.toml")
    finally:
        path_a.unlink(missing_ok=True)
        path_b.unlink(missing_ok=True)

    assert member_a.mtime == member_b.mtime == _SOURCE_BUNDLE_STABLE_MTIME


def test_run_publish_does_not_require_local_docker_access(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Remote publish should not fail when local Docker access is unavailable."""

    class FakeDocker(FakeDockerBase):
        def inspect_daemon_access(self) -> DockerAccessStatus:
            return DockerAccessStatus(
                ok=False,
                code="docker_permission_denied",
                message="Docker is installed, but this shell cannot access the Docker daemon.",
                hint="Refresh shell/session permissions, then run `make dev-up`.",
                detail="permission denied while trying to connect to docker.sock",
            )

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath("Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDocker(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result.publish_build_group_id == "group-1"


def test_run_publish_fails_without_runtime_dockerfile(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``ai push`` requires ``runtime/Dockerfile`` and ``runtime/pyproject.toml``."""
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_publish_contract_layout(tmp_path)

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGatewayBase(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "publish_runtime_dockerfile_missing"


def test_run_publish_with_model_runtime_submits_runtime_dockerfile_without_platform_injection(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """``runtime/Dockerfile`` is the publish entrypoint; platform runner is not injected."""
    bundle_members: list[str] = []

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    class InspectingUploadClient(_FakeUploadClient):
        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: ArtifactType,
            content_type: str,
            metadata: dict[str, Any] | None,
            concurrency: int,
            on_progress: Any | None,
        ) -> FakeUploadResult:
            with tarfile.open(file_path, mode="r:gz") as archive:
                bundle_members[:] = sorted(archive.getnames())
            return super().upload_file(
                file_path=file_path,
                slug=slug,
                version=version,
                artifact_type=artifact_type,
                content_type=content_type,
                metadata=metadata,
                concurrency=concurrency,
                on_progress=on_progress,
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "runtime").mkdir()
    (tmp_path / "runtime" / "Dockerfile").write_text(
        "FROM python:3.11-slim\n"
        "WORKDIR /app\n"
        "COPY runtime/pyproject.toml ./pyproject.toml\n"
        "RUN python -m pip install --no-cache-dir -e .\n"
        "COPY . .\n"
        'CMD ["python", "-m", "aimp_sdk.model_runner", "--module", "/app/main.py"]\n',
        encoding="utf-8",
    )
    (tmp_path / "runtime" / "pyproject.toml").write_text(
        '[project]\nname = "demo-runtime"\nversion = "0.1.0"\ndependencies = []\n',
        encoding="utf-8",
    )
    _ensure_publish_contract_layout(tmp_path)

    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=lambda _gw: InspectingUploadClient(),
    )

    assert result.publish_build_group_id == "group-1"
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.dockerfile_path == MODEL_RUNTIME_DOCKERFILE
    assert "runtime/Dockerfile" in bundle_members
    assert ".aimp/platform-root-runtime/Dockerfile" not in bundle_members


def test_run_publish_normalizes_missing_publish_config_before_bundling(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured_project_toml: dict[str, str] = {}

    class FakeGateway(FakeGatewayBase):
        def publish(self, request: PublishRequest | dict[str, Any]) -> PublishResponse:
            assert isinstance(request, PublishRequest)
            return PublishResponse(
                id="asset-1",
                slug="demo-model",
                visibility="private",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/demo-model",
            )

    class InspectingUploadClient(_FakeUploadClient):
        def upload_file(
            self,
            *,
            file_path: Path,
            slug: str,
            version: str,
            artifact_type: ArtifactType,
            content_type: str,
            metadata: dict[str, Any] | None,
            concurrency: int,
            on_progress: Any | None,
        ) -> FakeUploadResult:
            with tarfile.open(file_path, mode="r:gz") as archive:
                project_config = archive.extractfile(".aimp/project.toml")
                assert project_config is not None
                captured_project_toml["content"] = project_config.read().decode("utf-8")
            return super().upload_file(
                file_path=file_path,
                slug=slug,
                version=version,
                artifact_type=artifact_type,
                content_type=content_type,
                metadata=metadata,
                concurrency=concurrency,
                on_progress=on_progress,
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    (tmp_path / ".aimp").mkdir(parents=True, exist_ok=True)
    (tmp_path / ".aimp" / "project.toml").write_text(
        "\n".join(
            [
                "schema_version = 3",
                "",
                "[capabilities]",
                "vector = true",
                "tuning = false",
                "",
                "[resources]",
                "",
                "[resources.vector_db]",
                "",
                "[[resources.vector_db.collections]]",
                'alias = "docs"',
                'name = "Documents"',
                'description = "Document embeddings used by vector-backed modes."',
                "dimension = 1536",
                'metric = "cosine"',
                "",
                "[modes.generate]",
                "enabled = true",
                "",
                "[[modes.generate.inputs]]",
                'name = "text"',
                'kind = "text"',
                "required = true",
                "",
                "[[modes.generate.outputs]]",
                'name = "result"',
                'kind = "text"',
                "required = true",
                "",
                "[modes.search]",
                "enabled = true",
                "",
                "[modes.search.resources]",
                'vector_aliases = ["docs"]',
                "",
                "[[modes.search.inputs]]",
                'name = "text"',
                'kind = "text"',
                "required = true",
                "",
                "[[modes.search.outputs]]",
                'name = "results"',
                'kind = "json"',
                "required = true",
                "",
                "[modes.index]",
                "enabled = true",
                "",
                "[modes.index.resources]",
                'vector_aliases = ["docs"]',
                "",
                "[[modes.index.inputs]]",
                'name = "text"',
                'kind = "text"',
                "required = true",
                "",
                "[[modes.index.outputs]]",
                'name = "indexed"',
                'kind = "json"',
                "required = true",
                "",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / ".aimp" / "publish.toml").write_text("schema_version = 4\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='demo-model'\nversion='0.1.0'\n", encoding="utf-8"
    )
    (tmp_path / "main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=lambda _gateway: InspectingUploadClient(),
    )

    assert result.publish_build_group_id == "group-1"
    normalized = (tmp_path / ".aimp" / "project.toml").read_text(encoding="utf-8")
    assert "[publish]" in normalized
    assert 'artifact_path = "artifacts"' in normalized
    assert 'artifact_format = "tar.zst"' in normalized
    assert "vector = true" in normalized
    assert "dimension = 1536" in normalized
    assert 'metric = "cosine"' in normalized
    assert captured_project_toml["content"] == normalized


def test_run_publish_watches_submitted_build_group_when_running(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should watch the returned group when submit returns a running build."""
    get_job_calls: list[str] = []

    class FakeGateway(FakeGatewayBase):
        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            _ = request
            return PublishBuildGroup(
                job_id="group-active",
                slug=tmp_path.name,
                version="0.1.0",
                status="running",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

        @contextmanager
        def stream_job(self, job_id: str, **kwargs: Any) -> Any:
            yield iter(
                [
                    "event: snapshot",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": tmp_path.name,
                                    "status": "running",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                    "event: terminal",
                    (
                        "data: "
                        + json.dumps(
                            {
                                "job": {
                                    "job_id": job_id,
                                    "job_type": "publish_build_group",
                                    "model_slug": tmp_path.name,
                                    "status": "succeeded",
                                    "timeline": [],
                                    "logs": [],
                                    "details": {"version": "0.1.0"},
                                },
                                "timeline_count": 0,
                                "log_count": 0,
                            }
                        )
                    ),
                    "",
                ]
            )

        def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
            get_job_calls.append(job_id)
            return PublishBuildGroup(
                job_id=job_id,
                slug=tmp_path.name,
                version="0.1.0",
                status="succeeded",
                registration_result={
                    "id": "asset-resumed",
                    "slug": tmp_path.name,
                    "visibility": "private",
                    "readiness": {"is_ready": False, "blocking_reasons": []},
                    "url": f"http://localhost:3000/studio/models/{tmp_path.name}",
                },
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath("Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    # Must have watched the submitted running build
    assert get_job_calls == ["group-active"]
    assert result.id == "asset-resumed"


def test_run_publish_does_not_run_local_build_group_preflight_policy(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should not list/cancel/delete remote groups before submit."""
    created_jobs: list[PublishBuildGroupCreateRequest] = []

    class FakeGateway(FakeGatewayBase):
        def list_publish_build_groups(
            self,
            *,
            model_slug: str | None = None,
            status: str | None = None,
            page: int = 1,
            page_size: int = 20,
        ) -> PublishBuildGroupListResponse:
            _ = model_slug, status, page, page_size
            raise AssertionError("list_publish_build_groups must not be called")

        def cancel_publish_build_group(self, job_id: str) -> Any:
            raise AssertionError("cancel_publish_build_group must not be called")

        def delete_publish_build_group(self, job_id: str) -> None:
            raise AssertionError("delete_publish_build_group must not be called")

        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            created_jobs.append(request)
            return PublishBuildGroup(
                job_id="group-fresh",
                slug=tmp_path.name,
                version="0.1.0",
                status="succeeded",
                registration_result={
                    "id": "asset-fresh",
                    "slug": tmp_path.name,
                    "visibility": "private",
                    "readiness": {"is_ready": False, "blocking_reasons": []},
                    "url": f"http://localhost:3000/studio/models/{tmp_path.name}",
                },
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath("Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert len(created_jobs) == 1
    assert result.id == "asset-fresh"


def test_run_publish_detach_returns_without_waiting_or_registering(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Detached publish should create or reuse the remote build and return immediately."""
    get_job_calls: list[str] = []

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.build_group = PublishBuildGroup(
                job_id="group-detached",
                slug=tmp_path.name,
                version="0.1.0",
                status="running",
                stage="build",
                phase="image_build",
                current_step_message="Installing runtime dependencies",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

        def get_publish_build_group(self, job_id: str) -> PublishBuildGroup:
            get_job_calls.append(job_id)
            return self.build_group

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )

    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath("Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")

    result = run_publish(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        detach=True,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result.detached is True
    assert result.publish_build_group_id == "group-detached"
    assert result.phase == "image_build"
    assert result.current_step_message == "Installing runtime dependencies"
    assert get_job_calls == []


def test_run_publish_autosyncs_vector_collections_into_final_publish_request(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Submit intent must use synced vector collections, not stale local config."""
    config_state = {
        "current": ProjectConfig(
            capabilities=CapabilitiesConfig(vector=True, tuning=False),
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="query", kind="text", required=True)],
                        outputs=[_output("results", "json")],
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                    "index": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("indexed", "json")],
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
        )
    }

    class FakeGateway(FakeGatewayBase):
        pass

    def _extract_contract_with_vector_resources(**kwargs: Any) -> SdkContract:
        _ = kwargs
        return SdkContract(
            schema_version=4,
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[VectorCollectionConfig(**DOCS_VECTOR_COLLECTION_PAYLOAD)]
                )
            ),
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
                "search": SdkModeContract(
                    inputs=[{"name": "query", "kind": "text", "required": True}],
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "index": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
            parameters={},
        )

    def _load_project_config(project_dir: Path) -> ProjectConfig:
        _ = project_dir
        return config_state["current"].model_copy(deep=True)

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python",
        _extract_contract_with_vector_resources,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        _load_project_config,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config",
        _fake_publish_config,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    gateway = FakeGatewayBase()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.contract["resources"] == {
        "vector_db": {"collections": [DOCS_VECTOR_COLLECTION_PAYLOAD]}
    }


def test_run_publish_includes_playground_registration_intent(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    from aimp_cli.domain.models import SdkContract, SdkModeContract

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python",
        lambda **kwargs: SdkContract(
            schema_version=4,
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[VectorCollectionConfig(**DOCS_VECTOR_COLLECTION_PAYLOAD)]
                )
            ),
            modes={
                "index": SdkModeContract(
                    inputs=[{"name": "images", "kind": "image", "required": True}],
                    outputs=[{"name": "indexed", "kind": "json", "required": True}],
                ),
            },
            playground={
                "index": {
                    "response": [
                        {
                            "preset": "table",
                            "field": "indexed",
                            "columns": ["image_id", "filename"],
                        }
                    ]
                }
            },
            parameters={},
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        lambda **kwargs: ModeReadinessPayload.model_validate(
            {
                "index": {
                    "declared": True,
                    "implemented": True,
                    "reason": None,
                }
            }
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        lambda project_dir: ProjectConfig(
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[VectorCollectionConfig(**DOCS_VECTOR_COLLECTION_PAYLOAD)]
                )
            ),
            modes=ModesConfig(
                {
                    "index": ModeContract(
                        inputs=[InputDefinition(name="images", kind="image", required=True)],
                        outputs=[_output("indexed", "json")],
                    )
                }
            ),
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config",
        _fake_publish_config,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    gateway = FakeGatewayBase()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.contract["playground"] == {
        "index": {
            "response": [
                {
                    "preset": "table",
                    "field": "indexed",
                    "columns": ["image_id", "filename"],
                }
            ]
        }
    }


def test_run_publish_rejects_legacy_runtime_path_sources_before_registry_check(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._reject_legacy_runtime_path_sources",
        _reject_legacy_runtime_path_sources,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._verify_runtime_packages_downloadable",
        lambda **kwargs: (_ for _ in ()).throw(
            AssertionError("registry preflight should not run for legacy path-source manifests")
        ),
    )

    (tmp_path / "main.py").write_text("print('ok')\n", encoding="utf-8")
    _write_runtime_pyproject(
        tmp_path / "pyproject.toml",
        include_sources=True,
    )

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGatewayBase(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "runtime_path_sources_unsupported"
    assert "pyproject.toml" in exc_info.value.message


def test_run_publish_forwards_force_intent_to_control_plane_submit(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Force should be forwarded as submit intent, not handled by local orchestration."""

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.captured_force: bool | None = None

        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            self.captured_force = request.force
            return PublishBuildGroup(
                job_id="group-force",
                slug=tmp_path.name,
                version="0.1.0",
                status="succeeded",
                registration_result={
                    "id": "asset-force",
                    "slug": tmp_path.name,
                    "visibility": "private",
                    "readiness": {"is_ready": True, "blocking_reasons": []},
                    "url": f"http://localhost:3000/studio/models/{tmp_path.name}",
                },
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        force=True,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result.id == "asset-force"
    assert gateway.captured_force is True


def test_run_publish_surfaces_canonical_group_terminal_diagnostics(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Terminal publish failure should render canonical group diagnostics from control plane."""

    class FailingGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.build_group = PublishBuildGroup(
                job_id="group-failed",
                slug="demo-model",
                version="0.1.0",
                status="failed",
                phase="failed",
                stage="registration",
                error_code="publish_registration_failed",
                error_message="Article validation failed",
                current_step_message="Final publish registration failed",
                requested_profiles=[
                    PublishBuildProfile(
                        runtime_profile="cpu",
                        supported_hardware_tiers=["cpu-basic"],
                    )
                ],
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FailingGateway(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "publish_registration_failed"
    assert exc_info.value.message == "Final publish registration failed: Article validation failed"
    assert exc_info.value.extra["current_step_message"] == "Final publish registration failed"
    assert exc_info.value.extra["phase"] == "failed"
    assert exc_info.value.extra["stage"] == "registration"


def test_run_publish_surfaces_canonical_studio_upload_failure(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Studio media upload failures should surface canonical publish registration diagnostics."""

    class UploadFailingGateway(FakeGatewayBase):
        def upload_studio_media(
            self,
            *,
            file_path: Path,
            media_type: str,
        ) -> dict[str, Any]:
            _ = file_path, media_type
            raise network_error(
                "Studio media upload failed: timed out",
                code="publish_registration_failed",
                extra={
                    "reason": "studio_media_upload",
                    "stage": "registration",
                    "upload_phase": "single_part_upload",
                    "current_step_message": "Final publish registration failed",
                },
            )

    def _publish_config_with_cover(project_dir: Path) -> SimpleNamespace:
        config = _fake_publish_config(project_dir)
        config.studio.cover_file = "studio/cover.png"
        return config

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _publish_config_with_cover
    )
    studio_dir = tmp_path / "studio"
    studio_dir.mkdir(parents=True, exist_ok=True)
    (studio_dir / "article.mdx").write_text("# Demo\\n", encoding="utf-8")
    (studio_dir / "cover.png").write_bytes(b"png")
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=UploadFailingGateway(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "publish_registration_failed"
    assert exc_info.value.message == "Studio media upload failed: timed out"
    assert exc_info.value.extra["reason"] == "studio_media_upload"
    assert exc_info.value.extra["stage"] == "registration"
    assert exc_info.value.extra["upload_phase"] == "single_part_upload"


def test_run_publish_forwards_publish_build_group_id(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish submit should include one complete registration intent payload."""

    class FakeGateway(FakeGatewayBase):
        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            self.build_group_request = request
            return PublishBuildGroup(
                job_id="group-1",
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                registration_result={
                    "id": "asset-1",
                    "slug": "demo-model",
                    "visibility": "private",
                    "readiness": {"is_ready": True, "blocking_reasons": []},
                    "url": "http://localhost:3000/studio/models/demo-model",
                },
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    app_path = tmp_path / "main.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / ".aimp").mkdir()
    (tmp_path / ".aimp" / "contract.toml").write_text(
        "schema_version = 1\n\n[interface]\ninputs = ['text']\noutputs = ['text']\n",
        encoding="utf-8",
    )
    _ensure_publish_pyproject(tmp_path)
    _ensure_minimal_publish_runtime(tmp_path)

    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result.id == "asset-1"
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.studio.name == "Demo Model"
    assert gateway.build_group_request.registration_intent.mode_readiness["generate"].implemented


def test_load_managed_project_secrets_parses_valid_name_value_pairs(tmp_path: Path) -> None:
    tmp_path.joinpath(".env").write_text(
        "\n".join(
            [
                "# comment",
                "ZAI_API_KEY=live-zai-key",
                'OPENAI_API_KEY=  "quoted value"  ',
                "",
            ]
        ),
        encoding="utf-8",
    )

    loaded = load_managed_project_secrets(tmp_path)

    assert loaded.names == ["ZAI_API_KEY", "OPENAI_API_KEY"]
    assert loaded.values == {
        "ZAI_API_KEY": "live-zai-key",
        "OPENAI_API_KEY": '  "quoted value"  ',
    }


def test_load_managed_project_secrets_rejects_duplicate_names(tmp_path: Path) -> None:
    tmp_path.joinpath(".env").write_text(
        "ZAI_API_KEY=first\nZAI_API_KEY=second\n",
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        load_managed_project_secrets(tmp_path)

    assert exc_info.value.code == "project_secret_file_invalid"
    assert "duplicate secret 'ZAI_API_KEY'" in exc_info.value.message


def test_load_managed_project_secrets_rejects_invalid_secret_names(tmp_path: Path) -> None:
    tmp_path.joinpath(".env").write_text(
        "zai_api_key=value\n",
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        load_managed_project_secrets(tmp_path)

    assert exc_info.value.code == "project_secret_file_invalid"
    assert "must start with an uppercase letter" in exc_info.value.message


def test_load_managed_project_secrets_rejects_missing_equals(tmp_path: Path) -> None:
    tmp_path.joinpath(".env").write_text(
        "ZAI_API_KEY\n",
        encoding="utf-8",
    )

    with pytest.raises(CliError) as exc_info:
        load_managed_project_secrets(tmp_path)

    assert exc_info.value.code == "project_secret_file_invalid"
    assert "expected NAME=VALUE" in exc_info.value.message


def test_load_managed_project_secrets_requires_project_env_file(tmp_path: Path) -> None:
    tmp_path.joinpath(".env").unlink(missing_ok=True)

    with pytest.raises(CliError) as exc_info:
        load_managed_project_secrets(tmp_path)

    assert exc_info.value.code == "project_secret_file_missing"
    assert "Missing required project secret file: .env" in exc_info.value.message


def test_sync_managed_project_secrets_upserts_before_deleting(tmp_path: Path) -> None:
    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.model_secrets = {
                "OPENAI_API_KEY": "old-openai-key",
                "ZAI_API_KEY": "old-zai-key",
            }
            self.operations: list[tuple[str, str]] = []

        def set_model_secret(
            self, *, model_slug: str, name: str, value: str
        ) -> ModelSecretMetadata:
            _ = model_slug
            self.operations.append(("set", name))
            self.model_secrets[name] = value
            return ModelSecretMetadata(name=name, is_configured=True)

        def delete_model_secret(self, *, model_slug: str, name: str) -> None:
            _ = model_slug
            self.operations.append(("delete", name))
            self.model_secrets.pop(name, None)

    gateway = FakeGateway()
    sync_managed_project_secrets(
        gateway=gateway,
        model_slug="demo-model",
        managed_secrets=ManagedProjectSecrets(
            path=tmp_path / ".env",
            values={"ZAI_API_KEY": "new-zai-key"},
        ),
    )

    assert gateway.operations == [("set", "ZAI_API_KEY"), ("delete", "OPENAI_API_KEY")]
    assert gateway.model_secrets == {"ZAI_API_KEY": "new-zai-key"}


def test_run_publish_fails_loudly_when_project_env_is_missing(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        pass

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    tmp_path.joinpath(".env").unlink(missing_ok=True)

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGateway(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "project_secret_file_missing"


def test_run_publish_syncs_managed_project_secrets_from_project_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        pass

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath(".env").write_text(
        "ZAI_API_KEY=live-zai-key\nOPENAI_API_KEY=live-openai-key\n",
        encoding="utf-8",
    )

    gateway = FakeGateway()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.model_secrets == {
        "OPENAI_API_KEY": "live-openai-key",
        "ZAI_API_KEY": "live-zai-key",
    }
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.required_secrets == [
        "ZAI_API_KEY",
        "OPENAI_API_KEY",
    ]


def test_run_publish_deletes_remote_project_secrets_removed_from_project_env(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.model_secrets = {
                "ZAI_API_KEY": "old-zai-key",
                "OPENAI_API_KEY": "old-openai-key",
            }

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath(".env").write_text(
        "ZAI_API_KEY=new-zai-key\n",
        encoding="utf-8",
    )

    gateway = FakeGateway()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.model_secrets == {"ZAI_API_KEY": "new-zai-key"}
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.required_secrets == ["ZAI_API_KEY"]


def test_run_publish_with_empty_project_env_deletes_all_remote_secrets(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.model_secrets = {
                "ZAI_API_KEY": "old-zai-key",
                "OPENAI_API_KEY": "old-openai-key",
            }

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath(".env").write_text("", encoding="utf-8")

    gateway = FakeGateway()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.model_secrets == {}
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.required_secrets == []


def test_run_publish_does_not_delete_remote_secrets_when_upsert_fails(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()
            self.model_secrets = {
                "ZAI_API_KEY": "old-zai-key",
                "OPENAI_API_KEY": "old-openai-key",
                "LEGACY_KEY": "legacy-value",
            }

        def set_model_secret(
            self, *, model_slug: str, name: str, value: str
        ) -> ModelSecretMetadata:
            _ = model_slug, name, value
            raise network_error("Secret set failed", code="secret_set_failed")

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    tmp_path.joinpath(".env").write_text(
        "ZAI_API_KEY=new-zai-key\n",
        encoding="utf-8",
    )

    gateway = FakeGateway()
    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=gateway,
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "secret_set_failed"
    assert gateway.model_secrets == {
        "ZAI_API_KEY": "old-zai-key",
        "OPENAI_API_KEY": "old-openai-key",
        "LEGACY_KEY": "legacy-value",
    }


def test_create_source_bundle_archive_derives_pyproject_version_for_publish(
    tmp_path: Path,
) -> None:
    (tmp_path / "Dockerfile").write_text("FROM python:3.13-slim\n", encoding="utf-8")
    _write_local_version_metadata(tmp_path, version="0.2.0")
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                'version = "0.1.0"',
                "",
            ]
        ),
        encoding="utf-8",
    )

    bundle_path = create_source_bundle_archive(
        build_context=tmp_path,
        dockerfile=None,
        derived_pyproject_text='[project]\nname = "demo-model"\nversion = "0.2.0"\n',
    )
    try:
        with tarfile.open(bundle_path, mode="r:gz") as archive:
            pyproject_text = archive.extractfile("pyproject.toml").read().decode("utf-8")
    finally:
        bundle_path.unlink(missing_ok=True)

    assert 'version = "0.2.0"' in pyproject_text
    assert 'version = "0.1.0"' not in pyproject_text


def test_run_publish_uses_local_contract_version_for_build_and_publish(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        pass

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_publish_version",
        _real_resolve_publish_version,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "pyproject.toml").write_text(
        "\n".join(
            [
                "[project]",
                'name = "demo-model"',
                'version = "0.2.0"',
                "dependencies = [",
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-framework"]}",',
                f'    "{OFFICIAL_RUNTIME_DEPENDENCY_SPECS["ai-marketplace-sdk"]}",',
                "]",
                "",
                "[build-system]",
                'requires = ["hatchling"]',
                'build-backend = "hatchling.build"',
                "",
            ]
        ),
        encoding="utf-8",
    )
    (tmp_path / ".aimp").mkdir(exist_ok=True)
    (tmp_path / ".aimp" / "publish.toml").write_text("schema_version = 4\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    gateway = FakeGateway()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_group_request is not None
    assert gateway.build_group_request.version == "0.2.0"
    assert gateway.build_group_request.registration_intent is not None


def test_run_publish_fails_before_build_when_local_version_exists_remotely(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        def get_model_version(self, slug: str, version: str) -> SimpleNamespace | None:
            _ = slug
            return SimpleNamespace(version=version)

        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            _ = request
            raise AssertionError("create_publish_build_group must not run after version conflict")

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_publish_version",
        _real_resolve_publish_version,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )

    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _write_local_version_metadata(tmp_path, version="0.1.0")

    with pytest.raises(CliError) as exc_info:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGateway(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc_info.value.code == "local_version_conflict"


def test_run_publish_prompts_for_next_version_before_build(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    version_checks: list[str] = []

    class FakeGateway(FakeGatewayBase):
        def get_model_version(self, slug: str, version: str) -> SimpleNamespace | None:
            _ = slug
            version_checks.append(version)
            if version == "0.1.0":
                return SimpleNamespace(version=version)
            return None

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._resolve_publish_version",
        _real_resolve_publish_version,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.can_prompt_for_input",
        lambda: True,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.prompt_text",
        lambda *args, **kwargs: "0.1.1",
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)

    gateway = FakeGateway()
    run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=False),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert version_checks == ["0.1.0", "0.1.1"]
    assert gateway.build_group_request is not None
    assert gateway.build_group_request.version == "0.1.1"
    assert 'version = "0.1.1"' in (tmp_path / "pyproject.toml").read_text(encoding="utf-8")


def test_resolve_publish_version_prompts_when_only_stdin_is_interactive(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeGateway(FakeGatewayBase):
        def get_model_version(self, slug: str, version: str) -> SimpleNamespace | None:
            _ = slug
            if version == "0.2.0":
                return SimpleNamespace(version=version)
            return None

    _write_local_version_metadata(tmp_path, version="0.2.0")
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.can_prompt_for_input",
        lambda: True,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.prompt_text",
        lambda *args, **kwargs: "0.2.1",
    )

    metadata = _real_resolve_publish_version(
        project_dir=tmp_path,
        gateway=FakeGateway(),
        slug="demo-model",
        context=build_command_context("publish", debug=False, json_output=False),
    )

    assert metadata.version == "0.2.1"
    assert 'version = "0.2.1"' in (tmp_path / "pyproject.toml").read_text(encoding="utf-8")


def test_run_publish_returns_visibility_and_readiness(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should surface visibility/readiness from the Gateway response."""

    class FakeGateway(FakeGatewayBase):
        def create_publish_build_group(
            self,
            request: PublishBuildGroupCreateRequest,
        ) -> PublishBuildGroup:
            self.build_group_request = request
            return PublishBuildGroup(
                job_id="group-1",
                slug="demo-model",
                version="0.1.0",
                status="succeeded",
                registration_result={
                    "id": "8ac15d57-4705-4a1f-86c1-ff81eb477c60",
                    "slug": "demo-model",
                    "visibility": "private",
                    "readiness": {
                        "is_ready": False,
                        "blocking_reasons": ["publish_pricing_not_configured"],
                    },
                    "url": "http://localhost:3000/studio/models/demo-model",
                },
            )

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    app_path = tmp_path / "main.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    _ensure_publish_pyproject(tmp_path)
    _ensure_minimal_publish_runtime(tmp_path)
    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_group_request is not None
    assert gateway.build_group_request.registration_intent.pricing == {"developer_margin": 0}
    assert gateway.build_group_request.registration_intent.studio.name == "Demo Model"
    assert gateway.build_group_request.registration_intent.contract.get("tuning") is None
    assert result.id == "8ac15d57-4705-4a1f-86c1-ff81eb477c60"
    assert result.visibility == "private"
    assert result.readiness.is_ready is False
    assert result.url == "http://localhost:3000/studio/models/demo-model"
    assert result.status is None


def test_run_publish_does_not_send_layer_request_to_remote_build(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publish should create remote build jobs without legacy layer payloads."""

    class FakeGateway(FakeGatewayBase):
        def __init__(self) -> None:
            super().__init__()

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python", _fake_extract_contract
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config", _fake_project_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    gateway = FakeGateway()
    _ensure_publish_pyproject(tmp_path)
    tmp_path.joinpath("main.py").write_text("print('ok')\n", encoding="utf-8")
    _ensure_minimal_publish_runtime(tmp_path)
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert gateway.build_group_request is not None
    assert "layer_request" not in gateway.build_group_request.model_dump()
    assert "layers" not in result


def test_run_publish_includes_tuning_when_enabled_in_root_contract(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Submit intent should forward tuning metadata from the root project contract."""

    class FakeGateway(FakeGatewayBase):
        pass

    tuning_config = default_tuning_workspace_config()
    tuning_contract = tuning_config.model_dump(by_alias=True)
    _ = tuning_contract["schema"]

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python",
        lambda **kwargs: _fake_extract_contract().model_copy(update={"tuning": tuning_contract}),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        lambda project_dir: ProjectConfig(
            resources=ResourceConfig(
                vector_db=VectorResourceCollectionsConfig(
                    collections=[
                        VectorCollectionConfig(
                            alias="docs",
                            name="Documents",
                            description="Document embeddings used by vector-backed modes.",
                            dimension=1536,
                            metric="cosine",
                        )
                    ]
                )
            ),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                    "index": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        enabled=True,
                        resources=ModeResourcesConfig(vector_aliases=["docs"]),
                    ),
                },
            ),
            tuning=tuning_config,
        ),
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core._build_studio_publish_payload",
        lambda **kwargs: StudioPublishPayload(
            name="Demo Model",
            tags=["example"],
            visibility="private",
            article={"format": "tiptap-json", "schema_version": 1, "content": {"type": "doc"}},
        ),
    )
    app_path = tmp_path / "main.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    _ensure_publish_pyproject(tmp_path)
    _ensure_minimal_publish_runtime(tmp_path)

    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_tuning_contract_from_python",
        lambda **kwargs: tuning_contract,
    )

    gateway = FakeGateway()
    result = run_publish(
        project_dir=tmp_path,
        gateway=gateway,
        docker=FakeDockerBase(),
        context=build_command_context("publish", debug=False, json_output=True),
        selected_hardware_tier="cpu-basic",
        python_bin=None,
        parallel=3,
        verbose=False,
        upload_client_factory=_build_fake_upload_client,
    )

    assert result.slug == "demo-model"
    assert gateway.build_group_request is not None
    assert (
        gateway.build_group_request.registration_intent.contract["capabilities"]["tuning"] is True
    )
    assert gateway.build_group_request.registration_intent.contract.get("tuning") == tuning_contract


def test_run_publish_rejects_missing_tuning_contract_when_capability_is_enabled(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Publishing must fail if tuning capability is present but the typed contract is lost."""

    sdk_contract = _fake_extract_contract().model_copy(
        update={"capabilities": CapabilitiesConfig(vector=True, tuning=True), "tuning": None}
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_contract_from_python",
        lambda **kwargs: sdk_contract,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.extract_mode_readiness_from_python",
        _fake_mode_readiness,
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_publish_config", _fake_publish_config
    )
    monkeypatch.setattr(
        "aimp_cli.operations.publish.core.load_project_config",
        lambda project_dir: ProjectConfig(),
    )
    app_path = tmp_path / "main.py"
    app_path.write_text("print('ok')\n", encoding="utf-8")
    _ensure_publish_pyproject(tmp_path)
    _ensure_minimal_publish_runtime(tmp_path)

    with pytest.raises(CliError) as exc:
        run_publish(
            project_dir=tmp_path,
            gateway=FakeGatewayBase(),
            docker=FakeDockerBase(),
            context=build_command_context("publish", debug=False, json_output=True),
            selected_hardware_tier="cpu-basic",
            python_bin=None,
            parallel=3,
            verbose=False,
            upload_client_factory=_build_fake_upload_client,
        )

    assert exc.value.code == "publish_tuning_contract_missing"


def test_publish_model_by_slug_returns_publish_response() -> None:
    class FakeGateway(FakeGatewayBase):
        def publish_model_by_slug(self, slug: str) -> PublishResponse:
            assert slug == "vision-pro-tuned"
            return PublishResponse(
                id="derived-1",
                slug=slug,
                visibility="public",
                readiness={"is_ready": True, "blocking_reasons": []},
                url="http://localhost:3000/studio/models/vision-pro-tuned",
            )

    result = publish_model_by_slug(gateway=FakeGateway(), slug="vision-pro-tuned")

    assert result.model_dump(exclude_none=True) == {
        "id": "derived-1",
        "slug": "vision-pro-tuned",
        "visibility": "public",
        "readiness": {"is_ready": True, "blocking_reasons": []},
        "url": "http://localhost:3000/studio/models/vision-pro-tuned",
    }


class TestSyncSdkModesToConfig:
    """Tests for _sync_sdk_modes_to_config function."""

    def test_no_changes_when_modes_match(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            **DOCS_VECTOR_COLLECTION_PAYLOAD,
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.added_modes == []
        assert result.updated_resources
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                **DOCS_VECTOR_COLLECTION_PAYLOAD,
            )
        ]

    def test_adds_new_mode_from_sdk(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            **DOCS_VECTOR_COLLECTION_PAYLOAD,
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
                "search": SdkModeContract(
                    inputs=[{"name": "query", "kind": "text", "required": True}],
                    description="Search for similar images",
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.added_modes == ["search"]
        assert "search" in project_config.modes
        search_mode = project_config.modes["search"]
        assert len(search_mode.inputs) == 1
        assert search_mode.inputs[0].name == "query"
        assert search_mode.inputs[0].kind == "text"
        assert search_mode.outputs == [_output("result", "text")]
        assert search_mode.description == "Search for similar images"
        assert search_mode.resources is not None
        assert search_mode.resources.vector_aliases == ["docs"]
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                **DOCS_VECTOR_COLLECTION_PAYLOAD,
            )
        ]

    def test_syncs_vector_aliases_from_sdk_contract(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            **DOCS_VECTOR_COLLECTION_PAYLOAD,
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(),
                "search": SdkModeContract(
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.updated_resources
        assert "search" in project_config.modes
        assert project_config.resources.vector_db_enabled is True
        assert project_config.resources.vector_aliases == ["docs"]
        assert project_config.resources.vector_collections == [
            VectorCollectionConfig(
                **DOCS_VECTOR_COLLECTION_PAYLOAD,
            )
        ]
        assert project_config.modes["search"].resources is not None
        assert project_config.modes["search"].resources.vector_aliases == ["docs"]

    def test_updates_existing_mode_contract_from_sdk(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "image", "kind": "image", "required": True}],
                    outputs=[{"name": "indexed", "kind": "json", "required": True}],
                    description="Index an image",
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[
                            InputDefinition(name="image", kind="image", required=True),
                            InputDefinition(name="filename", kind="text", required=False),
                        ],
                        outputs=[_output("result", "text")],
                        description="Old description",
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.updated_modes == ["generate"]
        generate_mode = project_config.modes["generate"]
        assert len(generate_mode.inputs) == 1
        assert generate_mode.inputs[0].name == "image"
        assert generate_mode.inputs[0].kind == "image"
        assert generate_mode.outputs == [_output("indexed", "json")]
        assert generate_mode.description == "Index an image"

    def test_sync_accepts_scalar_output_kinds(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "search": SdkModeContract(
                    inputs=[{"name": "image", "kind": "image", "required": True}],
                    outputs=[
                        {"name": "matches", "kind": "json", "required": True},
                        {"name": "count", "kind": "integer", "required": True},
                        {"name": "score_threshold", "kind": "number", "required": True},
                        {"name": "truncated", "kind": "boolean", "required": True},
                    ],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig({}),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.added_modes == ["search"]
        assert [output.kind for output in project_config.modes["search"].outputs] == [
            "json",
            "integer",
            "number",
            "boolean",
        ]

    def test_sync_rejects_unsupported_public_output_kinds(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "index": SdkModeContract(
                    outputs=[{"name": "indexed", "kind": "list", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig({}),
        )

        with pytest.raises(
            ValueError,
            match="SDK mode 'index' declares unsupported local output kind: list",
        ):
            _sync_sdk_modes_to_config(
                sdk_contract=sdk_contract,
                project_config=project_config,
            )


def test_output_defs_from_sdk_rejects_unsupported_public_output_kind() -> None:
    from aimp_cli.commands.contract import _output_defs_from_sdk

    with pytest.raises(
        ValueError,
        match="SDK mode outputs contain unsupported local modality kind: list",
    ):
        _output_defs_from_sdk([{"name": "indexed", "kind": "list", "required": True}])

    def test_sync_rejects_unsupported_public_input_kinds(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "search": SdkModeContract(
                    inputs=[{"name": "count", "kind": "integer", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig({}),
        )

        with pytest.raises(
            ValueError,
            match=r"SDK mode 'search' declares unsupported local input kind: integer",
        ):
            _sync_sdk_modes_to_config(
                sdk_contract=sdk_contract,
                project_config=project_config,
            )

    def test_removes_modes_missing_from_sdk(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            modes={
                "generate": SdkModeContract(
                    inputs=[{"name": "text", "kind": "text", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                    "search": ModeContract(
                        inputs=[InputDefinition(name="image", kind="image", required=True)],
                        outputs=[_output("results", "json")],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert result.removed_modes == ["search"]
        assert set(project_config.modes.names()) == {"generate"}

    def test_syncs_multiple_new_modes(self) -> None:
        from aimp_cli.operations.publish.core import _sync_sdk_modes_to_config
        from aimp_cli.domain.models import InputDefinition, SdkContract, SdkModeContract

        sdk_contract = SdkContract(
            schema_version=4,
            resources={
                "vector_db": {
                    "collections": [
                        {
                            **DOCS_VECTOR_COLLECTION_PAYLOAD,
                        }
                    ]
                }
            },
            modes={
                "generate": SdkModeContract(),
                "search": SdkModeContract(
                    resources=ModeResourcesConfig(vector_aliases=["docs"]),
                ),
                "classify": SdkModeContract(
                    inputs=[{"name": "image", "kind": "image", "required": True}],
                ),
            },
            parameters={},
        )
        project_config = ProjectConfig(
            resources=ResourceConfig(vector_db=False),
            modes=ModesConfig(
                {
                    "generate": ModeContract(
                        inputs=[InputDefinition(name="text", kind="text", required=True)],
                        outputs=[_output("result", "text")],
                    ),
                }
            ),
        )

        result = _sync_sdk_modes_to_config(
            sdk_contract=sdk_contract,
            project_config=project_config,
        )

        assert result.has_changes
        assert sorted(result.added_modes) == ["classify", "search"]
        assert "search" in project_config.modes
        assert "classify" in project_config.modes
        assert len(project_config.modes["classify"].inputs) == 1
        assert project_config.modes["classify"].inputs[0].name == "image"
        assert project_config.modes["classify"].inputs[0].kind == "image"
        assert project_config.resources.vector_db_enabled is True
        assert project_config.resources.vector_aliases == ["docs"]
