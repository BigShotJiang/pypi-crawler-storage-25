from typing import BinaryIO

import mutagen
import mutagen.mp3

from .common import Info


class MP3Exception(Exception):
    pass


def read_info(file_obj: BinaryIO) -> Info:
    try:
        audio = mutagen.mp3.MP3(fileobj=file_obj)
    except mutagen.mp3.HeaderNotFoundError as e:
        raise MP3Exception(f"Not a valid file: {e}")
    except Exception as e:
        raise MP3Exception(f"Failed to read metadata: {e}")

    info = audio.info
    tags = audio.tags or {}

    if not info:
        raise MP3Exception("No audio info found")
    if not isinstance(info, mutagen.mp3.MPEGInfo):
        raise MP3Exception("Audio info is not of type MP3Info")
    if not audio.mime:
        raise MP3Exception("No MIME type found")

    def get_tag(key: str) -> str:
        frame = tags.get(key)
        return str(frame) if frame is not None else ""

    return Info(
        bitrate=info.bitrate,  # ty: ignore[unresolved-attribute]
        channels=info.channels,  # ty: ignore[unresolved-attribute]
        length=info.length,
        sample_rate=info.sample_rate,  # ty: ignore[unresolved-attribute]
        mime=audio.mime,
        title=get_tag("TIT2"),
        artist=get_tag("TPE1"),
        album=get_tag("TALB"),
        genre=get_tag("TCON"),
    )
