from pydantic import BaseModel


class Info(BaseModel):
    bitrate: int
    channels: int
    length: float
    sample_rate: int
    mime: list[str]
    title: str  # noqa
    artist: str  # noqa
    album: str  # noqa
    genre: str  # noqa
