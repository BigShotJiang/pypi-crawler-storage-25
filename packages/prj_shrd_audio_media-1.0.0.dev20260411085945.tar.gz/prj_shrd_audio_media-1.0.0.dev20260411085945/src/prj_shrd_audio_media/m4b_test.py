from .m4b import read_info


def test_read_info():
    with open("test_files/test.m4b", "rb") as f:
        info = read_info(f)

    assert int(info.length) == 310
    assert info.sample_rate == 44100
    assert info.channels == 2
    assert info.bitrate == 127009
    assert len(info.mime) > 0
    assert info.title == "Title"
    assert info.artist == "Artist"
    assert info.album == "Album"
    assert info.genre == "Genre"
