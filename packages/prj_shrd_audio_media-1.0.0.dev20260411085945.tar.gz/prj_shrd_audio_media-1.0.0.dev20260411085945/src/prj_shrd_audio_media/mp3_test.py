from .mp3 import read_info


def test_read_info():
    with open("/workspace/packages/prj-shrd-audio-media/test_files/test.mp3", "rb") as f:
        info = read_info(f)

    assert int(info.length) == 93
    assert info.sample_rate == 22050
    assert info.channels == 1
    assert info.bitrate == 96000
    assert len(info.mime) > 0
    assert info.title == "The Whispering Walls"
    assert info.artist == "Lucas F."
    assert info.album == ""
    assert info.genre == ""
