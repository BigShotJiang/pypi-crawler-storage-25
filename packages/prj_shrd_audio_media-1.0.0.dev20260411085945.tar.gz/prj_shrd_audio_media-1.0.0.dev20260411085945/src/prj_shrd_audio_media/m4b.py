import json
import subprocess
from pathlib import Path
from typing import BinaryIO

import mutagen
import mutagen.mp4
from pydantic import BaseModel

from .common import Info


class M4BChapter(BaseModel):
    start_time: float
    end_time: float
    duration: float
    title: str


class M4BException(Exception):
    pass


def read_info(file_obj: BinaryIO) -> Info:
    try:
        audio = mutagen.mp4.MP4(fileobj=file_obj)
    except Exception as e:
        raise M4BException(f"Failed to read metadata: {e}")

    info = audio.info
    tags = audio.tags

    if not info:
        raise M4BException("No audio info found")
    if not isinstance(info, mutagen.mp4.MP4Info):
        raise M4BException("Audio info is not of type MP4Info")
    if not audio.mime:
        raise M4BException("No MIME type found")
    if not tags:
        raise M4BException("No tags found")

    def get_tag(key: str) -> str:
        frame = tags.get(key)

        if frame is None:
            return ""

        if isinstance(frame, list):
            return str(frame[0]) if frame else ""

        return str(frame)

    return Info(
        bitrate=info.bitrate,
        channels=info.channels,
        length=info.length,
        sample_rate=info.sample_rate,
        mime=audio.mime,
        title=get_tag("\xa9nam"),
        artist=get_tag("\xa9ART"),
        album=get_tag("\xa9alb"),
        genre=get_tag("\xa9gen"),
    )


def _parse_chapters_from_ffprobe_output(output: str) -> list[M4BChapter]:
    data = json.loads(output)

    chapters = []
    for chapter in data.get("chapters", []):
        title = chapter.get("tags", {}).get("title", None)
        if title is None:
            raise M4BException("Chapter missing title")

        start_time = chapter.get("start_time")
        if start_time is None:
            raise M4BException("Chapter missing start_time")

        end_time = chapter.get("end_time")
        if end_time is None:
            raise M4BException("Chapter missing end_time")

        chapters.append(
            M4BChapter(
                start_time=float(start_time),
                end_time=float(end_time),
                duration=float(end_time) - float(start_time),
                title=str(title),
            )
        )

    return chapters


def read_chapters(fp: Path) -> list[M4BChapter]:
    cmd = [
        "ffprobe",
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_chapters",
        fp.as_posix(),
    ]

    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    return _parse_chapters_from_ffprobe_output(result.stdout)


def read_chapters_lazy(url: str) -> list[M4BChapter]:
    """Reads chapters from a remote M4B file using ffprobe without downloading the entire file."""
    cmd = [
        "ffprobe",
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_chapters",
        url,
    ]

    result = subprocess.run(
        cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    return _parse_chapters_from_ffprobe_output(result.stdout)
