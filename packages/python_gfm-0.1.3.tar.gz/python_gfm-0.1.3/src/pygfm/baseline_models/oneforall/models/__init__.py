# OneForAll model definitions
