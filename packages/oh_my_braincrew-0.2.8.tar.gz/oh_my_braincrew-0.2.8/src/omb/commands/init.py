"""omb init — initialize oh-my-braincrew in a project directory."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import click

RELEASE_REPO = "teddynote-lab/oh-my-braincrew-release"
RELEASE_REPO_URL = f"https://github.com/{RELEASE_REPO}.git"
PLUGIN_DIR = Path.home() / ".omb" / "plugin"


def _scaffold_project(project_dir: Path) -> None:
    """Create .omb/ directory structure in the project."""
    omb_dir = project_dir / ".omb"
    dirs = ["plans", "sessions", "verifications", "prs", "reviews", "logs", "documents", "config"]
    for d in dirs:
        (omb_dir / d).mkdir(parents=True, exist_ok=True)

    config_path = omb_dir / "config.json"
    if not config_path.exists():
        config_path.write_text(json.dumps({
            "project": project_dir.name,
            "counters": {"PLAN": 0, "SPEC": 0, "FIX": 0, "TASK": 0, "PR": 0},
        }, indent=2) + "\n")

    click.echo("  Created .omb/ directory structure")


def _ensure_plugin() -> Path:
    """Ensure plugin is installed at ~/.omb/plugin/ from the release repo."""
    plugin = PLUGIN_DIR

    if plugin.is_dir() and (plugin / ".git").is_dir():
        click.echo(f"  Plugin exists at {plugin}, updating...")
        result = subprocess.run(
            ["git", "-C", str(plugin), "pull", "--ff-only"],
            capture_output=True,
            text=True,
        )
        out = result.stdout.strip()
        click.echo(f"  {out if out else 'Already up to date.'}")
    elif plugin.is_dir():
        click.echo(f"  Plugin at {plugin} is not a git repo — re-cloning...")
        import shutil

        shutil.rmtree(plugin)
        _clone_plugin(plugin)
    else:
        click.echo("  Downloading plugin from release repo...")
        _clone_plugin(plugin)

    # Write ~/.omb/home
    home_file = plugin.parent / "home"
    home_file.parent.mkdir(mode=0o700, exist_ok=True)
    home_file.write_text(str(plugin.resolve()))
    home_file.chmod(0o600)

    return plugin


def _clone_plugin(dest: Path) -> None:
    """Clone the public release repo as the plugin directory."""
    result = subprocess.run(
        ["git", "clone", "--depth", "1", RELEASE_REPO_URL, str(dest)],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        click.echo(f"  Plugin installed to {dest}")
    else:
        click.echo(f"  Failed to clone: {result.stderr.strip()}")
        click.echo(f"  Try manually: git clone {RELEASE_REPO_URL} {dest}")


def run_init(path: str) -> None:
    """Initialize omb in the given project directory."""
    project_dir = Path(path).resolve()

    if not project_dir.is_dir():
        raise click.ClickException(f"Directory does not exist: {project_dir}")

    click.echo(f"Initializing omb in {project_dir}...")
    click.echo()

    # Step 1: Scaffold .omb/ project structure
    _scaffold_project(project_dir)

    # Step 2: Install/update plugin from release repo
    plugin_path = _ensure_plugin()

    # Step 3: Print next steps
    click.echo()
    click.echo("Done! Next steps:")
    click.echo()
    click.echo("  1. Start Claude Code with the plugin:")
    click.echo(f"     claude --plugin-dir {plugin_path}")
    click.echo()
    click.echo("  2. Run the setup wizard inside Claude Code:")
    click.echo("     /omb setup")
    click.echo()
    click.echo("  Update anytime with: omb update")
