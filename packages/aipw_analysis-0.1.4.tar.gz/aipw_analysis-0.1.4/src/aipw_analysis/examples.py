from pathlib import Path

from aipw_analysis.plotting import (
    ASYMPTOTIC_QUADRATIC,
    ControlGroupSizePanel,
    ControlGroupSizePoint,
    EventStudySeries,
    SQRT_ASYMPTOTIC,
    XLOGX,
    plot_control_group_size_tradeoffs,
    plot_control_group_size_tradeoffs_grid,
    plot_event_study,
)


def example_event_study_input() -> list[EventStudySeries]:
    """Return example event-study inputs for quick manual testing."""
    event_years = list(range(-3, 11))
    return [
        EventStudySeries(
            event_time=event_years,
            estimates=[150, 80, 20, 0, -40, 30, 60, 40, -20, 10, 50, 35, 25, 0],
            ses=[250, 240, 230, 220, 220, 230, 240, 250, 260, 270, 280, 290, 300, 310],
            label="RCT benchmark",
        ),
        EventStudySeries(
            event_time=event_years,
            estimates=[150, 95, 35, 0, -70, -120, -180, -220, -250, -215, -165, -120, -80, -55],
            ses=[280, 270, 260, 250, 250, 260, 270, 280, 290, 300, 310, 320, 330, 340],
            label="DoubleML, basic controls",
        ),
        EventStudySeries(
            event_time=event_years,
            estimates=[95, 45, -5, -35, -230, -315, -410, -485, -455, -385, -300, -220, -155, -120],
            ses=[290, 280, 270, 260, 260, 270, 280, 290, 300, 310, 320, 330, 340, 350],
            label="DoubleML w/ NAICS",
        ),
        EventStudySeries(
            event_time=event_years,
            estimates=[180, 125, 65, 15, -110, -165, -230, -285, -265, -220, -165, -115, -70, -35],
            ses=[285, 275, 265, 255, 255, 265, 275, 285, 295, 305, 315, 325, 335, 345],
            label="DoubleML w/ program receipt",
        ),
        EventStudySeries(
            event_time=event_years,
            estimates=[100, 40, 0, -50, -1200, -2200, -3200, -3900, -4400, -4700, -4900, -5050, -5100, -5000],
            ses=[320, 320, 320, 320, 350, 380, 410, 430, 450, 470, 490, 500, 510, 520],
            label="Best matched estimator",
        ),
    ]


def example_control_group_size_points_basic() -> list[ControlGroupSizePoint]:
    return [
        ControlGroupSizePoint(control_group_size=1_000, outcome_mse=0.99, runtime_minutes=3.2, pooled_att_estimate=-2900),
        ControlGroupSizePoint(control_group_size=1_500, outcome_mse=0.81, runtime_minutes=7.4, pooled_att_estimate=-1850),
        ControlGroupSizePoint(control_group_size=2_500, outcome_mse=0.71, runtime_minutes=11.9, pooled_att_estimate=-1320),
        ControlGroupSizePoint(control_group_size=4_000, outcome_mse=0.62, runtime_minutes=19.5, pooled_att_estimate=-860),
        ControlGroupSizePoint(control_group_size=6_500, outcome_mse=0.57, runtime_minutes=27.8, pooled_att_estimate=-630),
        ControlGroupSizePoint(control_group_size=10_000, outcome_mse=0.53, runtime_minutes=40.3, pooled_att_estimate=-470),
        ControlGroupSizePoint(control_group_size=16_000, outcome_mse=0.50, runtime_minutes=53.8, pooled_att_estimate=-350),
        ControlGroupSizePoint(control_group_size=25_000, outcome_mse=0.485, runtime_minutes=72.5, pooled_att_estimate=-240),
    ]


def example_control_group_size_points_county() -> list[ControlGroupSizePoint]:
    return [
        ControlGroupSizePoint(control_group_size=1_200, outcome_mse=0.95, runtime_minutes=6.2, pooled_att_estimate=-2600),
        ControlGroupSizePoint(control_group_size=2_000, outcome_mse=0.78, runtime_minutes=13.6, pooled_att_estimate=-1720),
        ControlGroupSizePoint(control_group_size=3_200, outcome_mse=0.68, runtime_minutes=23.5, pooled_att_estimate=-1180),
        ControlGroupSizePoint(control_group_size=5_500, outcome_mse=0.59, runtime_minutes=40.0, pooled_att_estimate=-770),
        ControlGroupSizePoint(control_group_size=9_000, outcome_mse=0.54, runtime_minutes=61.0, pooled_att_estimate=-540),
        ControlGroupSizePoint(control_group_size=15_000, outcome_mse=0.50, runtime_minutes=96.0, pooled_att_estimate=-360),
        ControlGroupSizePoint(control_group_size=25_000, outcome_mse=0.48, runtime_minutes=142.0, pooled_att_estimate=-265),
        ControlGroupSizePoint(control_group_size=42_000, outcome_mse=0.466, runtime_minutes=205.0, pooled_att_estimate=-205),
    ]


def example_control_group_size_points_tract() -> list[ControlGroupSizePoint]:
    return [
        ControlGroupSizePoint(control_group_size=1_500, outcome_mse=0.91, runtime_minutes=10.0, pooled_att_estimate=-2300),
        ControlGroupSizePoint(control_group_size=2_500, outcome_mse=0.73, runtime_minutes=22.0, pooled_att_estimate=-1500),
        ControlGroupSizePoint(control_group_size=4_500, outcome_mse=0.63, runtime_minutes=42.0, pooled_att_estimate=-1040),
        ControlGroupSizePoint(control_group_size=8_000, outcome_mse=0.56, runtime_minutes=74.0, pooled_att_estimate=-660),
        ControlGroupSizePoint(control_group_size=14_000, outcome_mse=0.52, runtime_minutes=128.0, pooled_att_estimate=-460),
        ControlGroupSizePoint(control_group_size=25_000, outcome_mse=0.49, runtime_minutes=215.0, pooled_att_estimate=-330),
        ControlGroupSizePoint(control_group_size=45_000, outcome_mse=0.474, runtime_minutes=365.0, pooled_att_estimate=-240),
        ControlGroupSizePoint(control_group_size=80_000, outcome_mse=0.462, runtime_minutes=565.0, pooled_att_estimate=-185),
    ]


def example_control_group_size_points_naics() -> list[ControlGroupSizePoint]:
    return [
        ControlGroupSizePoint(control_group_size=1_000, outcome_mse=0.86, runtime_minutes=6.5, pooled_att_estimate=-2050),
        ControlGroupSizePoint(control_group_size=1_500, outcome_mse=0.69, runtime_minutes=13.8, pooled_att_estimate=-1260),
        ControlGroupSizePoint(control_group_size=2_500, outcome_mse=0.60, runtime_minutes=21.0, pooled_att_estimate=-860),
        ControlGroupSizePoint(control_group_size=4_000, outcome_mse=0.54, runtime_minutes=32.5, pooled_att_estimate=-540),
        ControlGroupSizePoint(control_group_size=6_500, outcome_mse=0.50, runtime_minutes=45.0, pooled_att_estimate=-370),
        ControlGroupSizePoint(control_group_size=10_000, outcome_mse=0.475, runtime_minutes=62.0, pooled_att_estimate=-270),
        ControlGroupSizePoint(control_group_size=16_000, outcome_mse=0.462, runtime_minutes=81.0, pooled_att_estimate=-205),
        ControlGroupSizePoint(control_group_size=25_000, outcome_mse=0.452, runtime_minutes=106.0, pooled_att_estimate=-160),
    ]


def example_control_group_size_panels() -> list[ControlGroupSizePanel]:
    fit_specs = {
        "outcome_mse": ASYMPTOTIC_QUADRATIC,
        "runtime_minutes": XLOGX,
        "pooled_att_estimate": SQRT_ASYMPTOTIC,
    }
    return [
        ControlGroupSizePanel(
            title="Basic covariates",
            points=example_control_group_size_points_basic(),
            feature_count=42,
            fit_specs=fit_specs,
        ),
        ControlGroupSizePanel(
            title="Basic + county indicators",
            points=example_control_group_size_points_county(),
            feature_count=96,
            fit_specs=fit_specs,
        ),
        ControlGroupSizePanel(
            title="Basic + county + tract characteristics",
            points=example_control_group_size_points_tract(),
            feature_count=178,
            fit_specs=fit_specs,
        ),
    ]


def write_example_plots(base_dir: str | Path = "dist") -> dict[str, Path]:
    base_dir = Path(base_dir)
    event_dir = base_dir / "event_study_plot_examples"
    control_group_dir = base_dir / "control_group_size_plot_examples"

    panels = example_control_group_size_panels()
    control_group_y_axis_limits = {
        "runtime_minutes": (0, 600),
        "outcome_mse": (0.4, 1.05),
        "pooled_att_estimate": (-3200, 100),
    }

    outputs = {
        "event_study": plot_event_study(
            example_event_study_input(),
            output_path=event_dir / "example_event_study.png",
            title="ERA pooled ATT event-study estimates across estimators",
            y_limits=(0.05, 0.05),
        ),
        "event_study_with_ci_and_caption": plot_event_study(
            example_event_study_input(),
            output_path=event_dir / "example_event_study_with_ci_and_caption.png",
            title="ERA pooled ATT event-study estimates across estimators",
            caption="Confidence bands show 95 percent intervals around each event-study series. The randomized benchmark stays near zero, DoubleML specifications remain much closer to that benchmark, and the matched estimator becomes substantially more negative after program start.",
            show_confidence_bands=True,
            y_limits=(0.05, 0.05),
        ),
        "event_study_with_ci": plot_event_study(
            example_event_study_input(),
            output_path=event_dir / "example_event_study_with_ci.png",
            title="ERA pooled ATT event-study estimates across estimators",
            show_confidence_bands=True,
            y_limits=(0.05, 0.05),
        ),
        "control_group_size_basic": plot_control_group_size_tradeoffs(
            example_control_group_size_points_basic(),
            output_path=control_group_dir / "basic_covariates.png",
            title="Basic covariates",
            y_axis_limits=control_group_y_axis_limits,
            fit_specs={
                "runtime_minutes": XLOGX,
                "outcome_mse": ASYMPTOTIC_QUADRATIC,
                "pooled_att_estimate": SQRT_ASYMPTOTIC,
            },
        ),
        "control_group_size_county": plot_control_group_size_tradeoffs(
            example_control_group_size_points_county(),
            output_path=control_group_dir / "basic_plus_county_indicators.png",
            title="Basic covariates + County indicators",
            y_axis_limits=control_group_y_axis_limits,
            fit_specs={
                "runtime_minutes": XLOGX,
                "outcome_mse": ASYMPTOTIC_QUADRATIC,
                "pooled_att_estimate": SQRT_ASYMPTOTIC,
            },
        ),
        "control_group_size_tract": plot_control_group_size_tradeoffs(
            example_control_group_size_points_tract(),
            output_path=control_group_dir / "basic_plus_county_plus_tract_characteristics.png",
            title="Basic covariates + County indicators + Tract characteristics",
            y_axis_limits=control_group_y_axis_limits,
            fit_specs={
                "runtime_minutes": XLOGX,
                "outcome_mse": ASYMPTOTIC_QUADRATIC,
                "pooled_att_estimate": SQRT_ASYMPTOTIC,
            },
        ),
        "control_group_size_grid": plot_control_group_size_tradeoffs_grid(
            panels,
            output_path=control_group_dir / "control_group_size_grid.png",
            title="DoubleML runtime and performance: Low-complexity LightGBM models on ERA data",
            footnote="LightGBM parameters: num_leaves=31, learning_rate=0.05, n_estimators=250, min_data_in_leaf=50, feature_fraction=0.8, bagging_fraction=0.8.",
            y_axis_limits=control_group_y_axis_limits,
        ),
    }
    return outputs


if __name__ == "__main__":
    for path in write_example_plots().values():
        print(path)
