"""Public API for aipw-analysis plotting utilities."""

from aipw_analysis.plotting import (
    ASYMPTOTIC,
    ASYMPTOTIC_QUADRATIC,
    ControlGroupSizePanel,
    ControlGroupSizePoint,
    ComplexityPoint,
    EventStudySeries,
    FitSpec,
    LINEAR,
    POSITIVE_ASYMPTOTIC_QUADRATIC,
    SQRT_ASYMPTOTIC,
    XLOGX,
    plot_control_group_size_tradeoffs,
    plot_control_group_size_tradeoffs_grid,
    plot_complexity_tradeoffs,
    plot_event_study,
    polynomial,
)

__all__ = [
    "ASYMPTOTIC",
    "ASYMPTOTIC_QUADRATIC",
    "ComplexityPoint",
    "ControlGroupSizePanel",
    "ControlGroupSizePoint",
    "EventStudySeries",
    "FitSpec",
    "LINEAR",
    "POSITIVE_ASYMPTOTIC_QUADRATIC",
    "SQRT_ASYMPTOTIC",
    "XLOGX",
    "example_control_group_size_panels",
    "example_control_group_size_points_basic",
    "example_control_group_size_points_county",
    "example_control_group_size_points_tract",
    "plot_control_group_size_tradeoffs",
    "plot_control_group_size_tradeoffs_grid",
    "example_event_study_input",
    "plot_complexity_tradeoffs",
    "plot_event_study",
    "polynomial",
    "write_example_plots",
]


def __getattr__(name: str):
    if name in {
        "example_control_group_size_panels",
        "example_control_group_size_points_basic",
        "example_control_group_size_points_county",
        "example_control_group_size_points_tract",
        "example_event_study_input",
        "write_example_plots",
    }:
        from aipw_analysis import examples

        return getattr(examples, name)
    raise AttributeError(f"module 'aipw_analysis' has no attribute {name!r}")
