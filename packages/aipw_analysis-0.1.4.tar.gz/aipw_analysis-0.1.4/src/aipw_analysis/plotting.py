from dataclasses import dataclass
import importlib.util
from pathlib import Path
import textwrap
from typing import Callable

import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter, MaxNLocator, NullLocator
import numpy as np

import oi_tools


_OI_COLORS_PATH = Path(oi_tools.__file__).resolve().parent / "figures" / "_colors.py"
_OI_COLORS_SPEC = importlib.util.spec_from_file_location("oi_tools_figures_colors", _OI_COLORS_PATH)
_OI_COLORS_MODULE = importlib.util.module_from_spec(_OI_COLORS_SPEC)
_OI_COLORS_SPEC.loader.exec_module(_OI_COLORS_MODULE)
OIColors = _OI_COLORS_MODULE.OIColors


CONTROL_GROUP_DEFAULT_MIN = 1_000
CONTROL_GROUP_DEFAULT_MAX = 1_000_000_000
CONTROL_GROUP_X_TICKS = np.array(
    [
        1_000,
        10_000,
        100_000,
        1_000_000,
        10_000_000,
        100_000_000,
        1_000_000_000,
    ],
    dtype=float,
)


@dataclass
class EventStudySeries:
    event_time: list[int | float]
    estimates: list[float]
    ses: list[float] | None = None
    label: str | None = None


@dataclass
class ComplexityPoint:
    x: float
    outcome_mse: float
    runtime_minutes: float
    treatment_effect: float


@dataclass
class ControlGroupSizePoint:
    control_group_size: float
    outcome_mse: float
    runtime_minutes: float
    pooled_att_estimate: float


@dataclass
class ControlGroupSizePanel:
    title: str
    points: list[ControlGroupSizePoint]
    feature_count: int | None = None
    fit_specs: dict[str, "FitSpec"] | None = None


@dataclass
class FitSpec:
    label: str
    design_matrix: Callable[[np.ndarray], np.ndarray]
    coefficient_transform: Callable[[np.ndarray], np.ndarray] | None = None


LINEAR = FitSpec(
    label="Linear",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), x]),
)

XLOGX = FitSpec(
    label="x log x",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), x * np.log(x)]),
)

SQRT_ASYMPTOTIC = FitSpec(
    label="Asymptotic sqrt",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), 1 / np.sqrt(x)]),
)

ASYMPTOTIC = FitSpec(
    label="Asymptotic",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), 1 / x]),
)

ASYMPTOTIC_QUADRATIC = FitSpec(
    label="Asymptotic quadratic",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), 1 / x, 1 / (x**2)]),
)

POSITIVE_ASYMPTOTIC_QUADRATIC = FitSpec(
    label="Positive asymptotic quadratic",
    design_matrix=lambda x: np.column_stack([np.ones_like(x), 1 / x, 1 / (x**2)]),
    coefficient_transform=lambda beta: np.array([beta[0], abs(beta[1]), abs(beta[2])]),
)


def polynomial(degree: int) -> FitSpec:
    return FitSpec(
        label=f"Polynomial ({degree})",
        design_matrix=lambda x: np.column_stack([x**power for power in range(degree + 1)]),
    )


def _legend_kwargs(position: str) -> dict:
    positions = {
        "upper_left": {"loc": "upper left", "bbox_to_anchor": (0.02, 0.98)},
        "center_left": {"loc": "center left", "bbox_to_anchor": (0.02, 0.5)},
        "lower_left": {"loc": "lower left", "bbox_to_anchor": (0.02, 0.03)},
        "upper_right": {"loc": "upper right", "bbox_to_anchor": (0.98, 0.98)},
        "center_right": {"loc": "center right", "bbox_to_anchor": (0.98, 0.5)},
        "lower_right": {"loc": "lower right", "bbox_to_anchor": (0.98, 0.03)},
    }
    if position not in positions:
        raise ValueError(f"Unknown legend_position: {position}")
    return positions[position]


def _apply_padded_limits(axis, limits: tuple[float, float] | None) -> None:
    if limits is None:
        return
    ymin, ymax = axis.get_ylim()
    yrange = ymax - ymin
    if yrange == 0:
        yrange = max(abs(ymax), 1.0)
    lower_pad, upper_pad = limits
    axis.set_ylim(ymin - lower_pad * yrange, ymax + upper_pad * yrange)


def _validate_metric_keys(
    values: dict[str, object] | None,
    valid_keys: set[str],
    name: str,
) -> None:
    unknown_keys = set(values or {}) - valid_keys
    if unknown_keys:
        raise ValueError(f"Unknown {name} keys: {sorted(unknown_keys)}")


def _control_group_x_limits(
    x_observed: np.ndarray,
    x_limits: tuple[float, float] | None,
) -> tuple[float, float]:
    if np.any(x_observed <= 0):
        raise ValueError("log-scaled control group sample size requires control_group_size > 0")

    observed_max = float(x_observed.max())
    if x_limits is None:
        return CONTROL_GROUP_DEFAULT_MIN, max(CONTROL_GROUP_DEFAULT_MAX, observed_max)

    x_min, x_max = x_limits
    x_min = CONTROL_GROUP_DEFAULT_MIN if x_min <= 0 else x_min
    if x_max <= x_min:
        raise ValueError("x_limits must have an upper bound greater than the positive lower bound")
    return x_min, x_max


def _control_group_fit_grid(x_min: float, x_max: float) -> np.ndarray:
    return np.geomspace(x_min, x_max, 240)


def _format_control_group_sample_size(value: float) -> str:
    if value <= 0:
        return ""
    if value >= 1_000_000_000:
        amount = value / 1_000_000_000
        suffix = "B"
    elif value >= 1_000_000:
        amount = value / 1_000_000
        suffix = "M"
    elif value >= 1_000:
        amount = value / 1_000
        suffix = "k"
    else:
        amount = value
        suffix = ""
    return f"{amount:g}{suffix}"


def _apply_control_group_x_axis(axis, x_limits: tuple[float, float]) -> None:
    axis.set_xscale("log")
    axis.set_xlim(*x_limits)
    ticks = CONTROL_GROUP_X_TICKS[(CONTROL_GROUP_X_TICKS >= x_limits[0]) & (CONTROL_GROUP_X_TICKS <= x_limits[1])]
    axis.xaxis.set_major_locator(FixedLocator(ticks))
    axis.xaxis.set_minor_locator(NullLocator())
    axis.xaxis.set_major_formatter(FuncFormatter(lambda value, _: _format_control_group_sample_size(value)))


def plot_event_study(
    series: list[EventStudySeries],
    *,
    output_path: str | Path = "event_study.png",
    title: str = "ERA pooled ATT event-study estimates across estimators",
    caption: str | None = None,
    show_confidence_bands: bool = False,
    y_limits: tuple[float, float] | None = None,
    legend_position: str = "bottom",
) -> Path:
    """Plot one or more event-study series."""
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.titlesize": 13,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.0,
            "ytick.labelsize": 8.0,
            "legend.fontsize": 9,
        }
    )

    fig, ax = plt.subplots(figsize=(8.2, 5.8), constrained_layout=False)
    fig.patch.set_facecolor("white")
    ax.set_facecolor("white")

    palette = [
        "#000000",
        OIColors.TEAL,
        OIColors.BLUE,
        OIColors.PURPLE,
        OIColors.ORANGE,
    ]
    spine_color = "#B8B8B8"
    tick_color = "#3F3F3F"
    axis_label_color = "#2F2F2F"
    reference_color = "#CFCFCF"
    title_color = "#1A1A1A"
    for i, s in enumerate(series):
        points = sorted(zip(s.event_time, s.estimates))
        x = [event_time for event_time, _ in points]
        y = [estimate for _, estimate in points]
        color = palette[i % len(palette)]
        label = s.label or f"Series {i + 1}"
        is_primary = i == 0
        is_dml = "doubleml" in label.lower()
        is_matched = "match" in label.lower()
        marker = "o" if is_primary else "^" if is_dml else "s" if is_matched else "o"
        linestyle = ":" if is_primary else "-"

        ax.plot(
            x,
            y,
            color=color,
            linewidth=1.6,
            linestyle=linestyle,
            marker=marker,
            markersize=4.2,
            markerfacecolor=color,
            markeredgecolor=color,
            label=label,
            alpha=1.0 if (is_primary or is_dml or is_matched) else 0.75,
            zorder=3,
        )

        if show_confidence_bands and s.ses is not None:
            ses_by_time = dict(zip(s.event_time, s.ses))
            lower = [estimate - 1.96 * ses_by_time[event_time] for event_time, estimate in points]
            upper = [estimate + 1.96 * ses_by_time[event_time] for event_time, estimate in points]
            band_alpha = 0.09 if is_primary else 0.06 if is_dml else 0.08 if is_matched else 0.03
            ax.fill_between(x, lower, upper, color=color, alpha=band_alpha, linewidth=0, zorder=1)

    ax.axhline(0, color="#E6E6E6", linewidth=0.7, linestyle="-", zorder=1)
    ax.axvline(0, color=reference_color, linewidth=1.1, linestyle="--", zorder=1)

    _apply_padded_limits(ax, y_limits)

    title_text = ax.set_title(title, loc="center", color=title_color, pad=18, fontweight="normal")
    title_text.set_multialignment("left")
    ax.set_xlabel("Years relative to program start", color=axis_label_color)
    ax.set_ylabel("Pooled ATT estimate ($K)", color=axis_label_color)

    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color(spine_color)
    ax.spines["bottom"].set_color(spine_color)
    ax.tick_params(axis="both", colors=tick_color, length=3.5, width=0.8, labelsize=8.0)
    ax.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: _format_dollars_in_thousands(value)))
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))

    ax.set_xticks([-2, 0, 5, 10])
    ax.set_xticklabels(["-2", "0", "5", "10"])

    legend_kwargs = (
        {"loc": "upper center", "bbox_to_anchor": (0.5, -0.18)}
        if legend_position == "bottom"
        else _legend_kwargs(legend_position)
    )
    ax.legend(
        **legend_kwargs,
        ncol=min(len(series), 3) if legend_position == "bottom" else 1,
        frameon=True,
        facecolor="white",
        edgecolor="#D9DEE3",
        framealpha=1.0,
        handlelength=2.2,
        borderpad=0.6,
        labelspacing=0.5,
    )

    bottom_margin = 0.31 if caption else 0.24
    fig.subplots_adjust(left=0.11, right=0.97, top=0.79, bottom=bottom_margin)

    if caption:
        fig.text(
            0.16,
            0.03,
            textwrap.fill(caption, width=100),
            ha="left",
            va="bottom",
            fontsize=7.0,
            color=tick_color,
        )

    fig.savefig(output_path, dpi=400, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


def plot_complexity_tradeoffs(
    points: list[ComplexityPoint],
    *,
    output_path: str | Path = "complexity_tradeoffs.png",
    title: str = "Can DoubleML Scale to the Complexity Required for Good Performance? (ERA Observational Data)",
    caption: str | None = None,
    x_label: str = "Complexity",
    x_limits: tuple[float, float] | None = None,
    y_limits: dict[str, tuple[float, float]] | None = None,
    fit_specs: dict[str, FitSpec] | None = None,
    legend_position: str = "center_right",
) -> Path:
    if not points:
        raise ValueError("points must not be empty")

    valid_series = {"outcome_mse", "runtime_minutes", "treatment_effect"}
    fit_specs = fit_specs or {}
    unknown_keys = set(fit_specs) - valid_series
    if unknown_keys:
        raise ValueError(f"Unknown fit_specs keys: {sorted(unknown_keys)}")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.titlesize": 13,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.0,
            "ytick.labelsize": 8.0,
            "legend.fontsize": 9,
        }
    )

    fig, ax_left = plt.subplots(figsize=(8.2, 5.8), constrained_layout=False)
    fig.patch.set_facecolor("white")
    ax_left.set_facecolor("white")
    ax_right = ax_left.twinx()
    ax_far_right = ax_left.twinx()
    ax_far_right.spines["right"].set_position(("outward", 40))

    spine_color = "#B8B8B8"
    tick_color = "#3F3F3F"
    axis_label_color = "#2F2F2F"
    title_color = "#1A1A1A"
    series_styles = {
        "runtime_minutes": {"color": OIColors.ORANGE, "marker": "s", "axis": ax_left, "label": "Runtime (minutes)"},
        "outcome_mse": {"color": OIColors.TEAL, "marker": "o", "axis": ax_right, "label": "MSE of Outcomes Model"},
        "treatment_effect": {"color": OIColors.BLUE, "marker": "^", "axis": ax_far_right, "label": "Pooled ATT estimate"},
    }
    jitter_patterns = {
        "outcome_mse": np.array([0.008, -0.006, 0.004, -0.005, 0.003, -0.002, 0.002, -0.001]),
        "runtime_minutes": np.array([0.6, -0.8, 0.9, -0.7, 0.5, -0.4, 0.3, -0.2]),
        "treatment_effect": np.array([80, -65, 55, -45, 35, -25, 18, -10]),
    }

    for axis in (ax_left, ax_right, ax_far_right):
        axis.spines["top"].set_visible(False)
        axis.spines["left"].set_color(spine_color)
        axis.spines["bottom"].set_color(spine_color)
        axis.spines["right"].set_color(spine_color)
        axis.tick_params(axis="x", colors=tick_color, length=3.5, width=0.8)

    x_observed = np.array([point.x for point in points], dtype=float)
    x_min = float(x_observed.min()) if x_limits is None else x_limits[0]
    x_max = float(x_observed.max()) if x_limits is None else x_limits[1]
    x_grid = np.linspace(x_min, x_max, 200)

    handles = []
    labels = []

    for series_name, attr in [
        ("outcome_mse", "outcome_mse"),
        ("runtime_minutes", "runtime_minutes"),
        ("treatment_effect", "treatment_effect"),
    ]:
        style = series_styles[series_name]
        axis = style["axis"]
        y_observed = np.array([getattr(point, attr) for point in points], dtype=float)
        jitter = jitter_patterns[series_name][: len(y_observed)]
        y_display = y_observed + jitter
        fit_spec = fit_specs.get(series_name, LINEAR)

        requires_positive_x = fit_spec in (XLOGX, SQRT_ASYMPTOTIC, ASYMPTOTIC, ASYMPTOTIC_QUADRATIC, POSITIVE_ASYMPTOTIC_QUADRATIC)
        if requires_positive_x and np.any(x_observed <= 0):
            raise ValueError(f"{series_name} fit requires x > 0 for log(x)")
        observed = axis.plot(
            x_observed,
            y_display,
            linestyle="none",
            marker=style["marker"],
            markersize=4.2,
            color=style["color"],
            markerfacecolor=style["color"],
            markeredgecolor=style["color"],
            label=style["label"],
            zorder=3,
        )[0]

        design_observed = fit_spec.design_matrix(x_observed)
        beta, *_ = np.linalg.lstsq(design_observed, y_observed, rcond=None)
        if fit_spec.coefficient_transform is not None:
            beta = fit_spec.coefficient_transform(beta)
        fit_grid = x_grid[x_grid > 0] if requires_positive_x else x_grid
        fitted = fit_spec.design_matrix(fit_grid) @ beta
        observed_max_x = float(x_observed.max())
        in_sample = fit_grid <= observed_max_x
        extrapolated = fit_grid > observed_max_x
        axis.plot(
            fit_grid[in_sample],
            fitted[in_sample],
            linestyle=":",
            linewidth=1.4,
            color=style["color"],
            alpha=0.9,
            zorder=2,
        )[0]
        if np.any(extrapolated):
            axis.plot(
                fit_grid[extrapolated],
                fitted[extrapolated],
                linestyle=":",
                linewidth=1.2,
                color=style["color"],
                alpha=0.35,
                zorder=2,
            )[0]

        handles.append(observed)
        labels.append(style["label"])

        axis.tick_params(axis="y", colors=style["color"], length=3.0, width=0.8, pad=2, labelsize=7.0)

    ax_left.set_title(title, loc="center", color=title_color, pad=10, fontweight="normal", fontsize=11.5)
    ax_left.set_xlabel(x_label, color=axis_label_color)
    y_label_size = 8
    ax_left.set_ylabel("Runtime (minutes)", color=series_styles["runtime_minutes"]["color"], fontsize=y_label_size, labelpad=4)
    ax_right.set_ylabel("MSE of Outcomes Model", color=series_styles["outcome_mse"]["color"], fontsize=y_label_size, labelpad=6)
    ax_far_right.set_ylabel("Pooled ATT estimate (ERA sample)", color=series_styles["treatment_effect"]["color"], fontsize=y_label_size, labelpad=8)
    ax_left.spines["left"].set_color(series_styles["runtime_minutes"]["color"])
    ax_right.spines["right"].set_color(series_styles["outcome_mse"]["color"])
    ax_far_right.spines["right"].set_color(series_styles["treatment_effect"]["color"])
    ax_left.set_xlim(x_min, x_max)
    ax_left.xaxis.set_major_locator(MaxNLocator(nbins=6))
    ax_left.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax_right.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax_far_right.yaxis.set_major_locator(MaxNLocator(nbins=6))

    if y_limits:
        _apply_padded_limits(ax_left, y_limits.get("outcome_mse"))
        _apply_padded_limits(ax_right, y_limits.get("runtime_minutes"))
        _apply_padded_limits(ax_far_right, y_limits.get("treatment_effect"))

    ax_left.legend(
        handles,
        labels,
        **_legend_kwargs("upper_right"),
        ncol=1,
        frameon=True,
        facecolor="white",
        edgecolor="#D9DEE3",
        framealpha=1.0,
        handlelength=2.2,
        borderpad=0.6,
        labelspacing=0.5,
    )

    bottom_margin = 0.16 if caption else 0.09
    fig.subplots_adjust(left=0.09, right=0.88, top=0.72, bottom=bottom_margin)

    if caption:
        fig.text(
            0.16,
            0.03,
            textwrap.fill(caption, width=100),
            ha="left",
            va="bottom",
            fontsize=7.0,
            color=tick_color,
        )

    fig.savefig(output_path, dpi=400, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


def _expanded_jitter(pattern: np.ndarray, n: int) -> np.ndarray:
    repeats = int(np.ceil(n / len(pattern)))
    return np.tile(pattern, repeats)[:n]


def _control_group_series_styles(ax_runtime, ax_mse, ax_att) -> dict[str, dict]:
    return {
        "runtime_minutes": {"color": OIColors.ORANGE, "marker": "s", "axis": ax_runtime, "label": "Runtime (minutes)"},
        "outcome_mse": {"color": OIColors.TEAL, "marker": "o", "axis": ax_mse, "label": "MSE of Outcomes Model"},
        "pooled_att_estimate": {"color": OIColors.BLUE, "marker": "^", "axis": ax_att, "label": "Pooled ATT estimate (ERA sample)"},
    }


def _create_control_group_axes(fig=None, ax_runtime=None):
    if ax_runtime is None:
        fig, ax_runtime = plt.subplots(figsize=(8.2, 5.8), constrained_layout=False)
    ax_mse = ax_runtime.twinx()
    ax_att = ax_runtime.twinx()
    ax_att.spines["right"].set_position(("outward", 40))
    return fig, ax_runtime, ax_mse, ax_att


def _prepare_control_group_metric(
    points: list[ControlGroupSizePoint],
    metric_name: str,
    fit_spec: FitSpec,
    x_limits: tuple[float, float] | None,
) -> dict[str, np.ndarray]:
    x_observed = np.array([point.control_group_size for point in points], dtype=float)
    y_observed = np.array([getattr(point, metric_name) for point in points], dtype=float)
    x_min, x_max = _control_group_x_limits(x_observed, x_limits)

    requires_positive_x = fit_spec in (XLOGX, SQRT_ASYMPTOTIC, ASYMPTOTIC, ASYMPTOTIC_QUADRATIC, POSITIVE_ASYMPTOTIC_QUADRATIC)
    if requires_positive_x and np.any(x_observed <= 0):
        raise ValueError(f"{metric_name} fit requires control_group_size > 0")
    x_grid = _control_group_fit_grid(x_min, x_max)

    design_observed = fit_spec.design_matrix(x_observed)
    beta, *_ = np.linalg.lstsq(design_observed, y_observed, rcond=None)
    if fit_spec.coefficient_transform is not None:
        beta = fit_spec.coefficient_transform(beta)

    fit_grid = x_grid[x_grid > 0] if requires_positive_x else x_grid
    fitted = fit_spec.design_matrix(fit_grid) @ beta
    observed_max_x = float(x_observed.max())

    return {
        "x_observed": x_observed,
        "y_observed": y_observed,
        "fit_grid": fit_grid,
        "fitted": fitted,
        "observed_max_x": np.array([observed_max_x]),
    }


def _control_group_auto_limits(
    prepared_panels: list[dict[str, dict[str, np.ndarray]]],
    y_limits: dict[str, tuple[float, float]] | None,
    y_axis_limits: dict[str, tuple[float, float]] | None = None,
) -> dict[str, tuple[float, float]]:
    y_limits = y_limits or {}
    y_axis_limits = y_axis_limits or {}
    auto_limits = {}
    for metric_name in ("runtime_minutes", "outcome_mse", "pooled_att_estimate"):
        if metric_name in y_axis_limits:
            auto_limits[metric_name] = y_axis_limits[metric_name]
            continue
        observed = np.concatenate([panel[metric_name]["y_observed"] for panel in prepared_panels])
        fitted = np.concatenate([panel[metric_name]["fitted"] for panel in prepared_panels])
        ymin = min(float(observed.min()), float(fitted.min()))
        ymax = max(float(observed.max()), float(fitted.max()))
        yrange = ymax - ymin
        if yrange == 0:
            yrange = max(abs(ymax), 1.0)
        lower_pad, upper_pad = y_limits.get(metric_name, (0.05, 0.05))
        auto_limits[metric_name] = (ymin - lower_pad * yrange, ymax + upper_pad * yrange)
    return auto_limits


def _padded_data_limits(values: np.ndarray, padding: tuple[float, float]) -> tuple[float, float]:
    ymin = float(np.min(values))
    ymax = float(np.max(values))
    yrange = ymax - ymin
    if yrange == 0:
        yrange = max(abs(ymax), 1.0)
    lower_pad, upper_pad = padding
    return ymin - lower_pad * yrange, ymax + upper_pad * yrange


def _metric_values_for_limits(
    prepared_panels: list[dict[str, dict[str, np.ndarray]]],
    metric_name: str,
    transform: Callable[[np.ndarray], np.ndarray] | None = None,
) -> np.ndarray:
    values = []
    for panel in prepared_panels:
        series = panel[metric_name]
        values.extend([series["y_observed"], series["fitted"]])
    joined = np.concatenate(values)
    return transform(joined) if transform is not None else joined


def _control_group_grid_limits(
    prepared_panels: list[dict[str, dict[str, np.ndarray]]],
    y_limits: dict[str, tuple[float, float]] | None,
    y_axis_limits: dict[str, tuple[float, float]] | None = None,
) -> dict[str, tuple[float, float]]:
    y_limits = y_limits or {}
    y_axis_limits = y_axis_limits or {}
    return {
        "runtime_minutes": y_axis_limits.get(
            "runtime_minutes",
            _padded_data_limits(
                _metric_values_for_limits(prepared_panels, "runtime_minutes"),
                y_limits.get("runtime_minutes", (0.05, 0.05)),
            ),
        ),
        "outcome_mse": y_axis_limits.get(
            "outcome_mse",
            _padded_data_limits(
                _metric_values_for_limits(prepared_panels, "outcome_mse"),
                y_limits.get("outcome_mse", (0.05, 0.05)),
            ),
        ),
        "pooled_att_estimate": y_axis_limits.get(
            "pooled_att_estimate",
            _padded_data_limits(
                _metric_values_for_limits(prepared_panels, "pooled_att_estimate"),
                y_limits.get("pooled_att_estimate", (0.05, 0.05)),
            ),
        ),
    }


def _plot_prepared_control_group_series(
    axis,
    series: dict[str, np.ndarray],
    *,
    color: str,
    marker: str,
    label: str,
    jitter: np.ndarray,
    transform: Callable[[np.ndarray], np.ndarray] | None = None,
):
    y_observed = transform(series["y_observed"]) if transform is not None else series["y_observed"]
    y_fitted = transform(series["fitted"]) if transform is not None else series["fitted"]
    y_display = y_observed + _expanded_jitter(jitter, len(y_observed))

    observed = axis.plot(
        series["x_observed"],
        y_display,
        linestyle="none",
        marker=marker,
        markersize=4.0,
        color=color,
        markerfacecolor=color,
        markeredgecolor=color,
        label=label,
        zorder=3,
    )[0]

    observed_max_x = float(series["observed_max_x"][0])
    in_sample = series["fit_grid"] <= observed_max_x
    extrapolated = series["fit_grid"] > observed_max_x
    axis.plot(
        series["fit_grid"][in_sample],
        y_fitted[in_sample],
        linestyle=":",
        linewidth=1.75,
        color=color,
        alpha=0.9,
        zorder=2,
    )
    if np.any(extrapolated):
        axis.plot(
            series["fit_grid"][extrapolated],
            y_fitted[extrapolated],
            linestyle=":",
            linewidth=1.5,
            color=color,
            alpha=0.35,
            zorder=2,
        )
    return observed


def _style_scaling_axis(axis, *, spine_color: str, tick_color: str) -> None:
    axis.set_facecolor("white")
    axis.spines["top"].set_visible(False)
    axis.spines["left"].set_color(spine_color)
    axis.spines["bottom"].set_color(spine_color)
    axis.spines["right"].set_color(spine_color)
    axis.tick_params(axis="x", colors=tick_color, length=3.0, width=0.8, labelsize=7.0)


def _control_group_panel_title(panel: ControlGroupSizePanel) -> str:
    if panel.feature_count is None:
        return panel.title
    return f"{panel.title}\n(p = {panel.feature_count})"


def _format_dollars_in_thousands(value: float) -> str:
    amount = abs(value) / 1000
    amount_text = f"{amount:.1f}".rstrip("0").rstrip(".")
    sign = "-" if value < 0 else ""
    return f"{sign}${amount_text}k"


def _draw_control_group_panel(
    ax_runtime,
    ax_mse,
    ax_att,
    prepared_panel: dict[str, dict[str, np.ndarray]],
    *,
    title: str,
    x_limits: tuple[float, float] | None,
    shared_limits: dict[str, tuple[float, float]] | None,
) -> tuple[list, list]:
    spine_color = "#B8B8B8"
    tick_color = "#3F3F3F"
    axis_label_color = "#2F2F2F"
    title_color = "#1A1A1A"
    jitter_patterns = {
        "outcome_mse": np.array([0.008, -0.006, 0.004, -0.005, 0.003, -0.002, 0.002, -0.001]),
        "runtime_minutes": np.array([0.6, -0.8, 0.9, -0.7, 0.5, -0.4, 0.3, -0.2]),
        "pooled_att_estimate": np.array([80, -65, 55, -45, 35, -25, 18, -10]),
    }

    for axis in (ax_runtime, ax_mse, ax_att):
        axis.set_facecolor("white")
        axis.spines["top"].set_visible(False)
        axis.spines["left"].set_color(spine_color)
        axis.spines["bottom"].set_color(spine_color)
        axis.spines["right"].set_color(spine_color)
        axis.tick_params(axis="x", colors=tick_color, length=3.5, width=0.8, labelsize=8.0)

    styles = _control_group_series_styles(ax_runtime, ax_mse, ax_att)
    handles = []
    labels = []
    for metric_name in ("runtime_minutes", "outcome_mse", "pooled_att_estimate"):
        style = styles[metric_name]
        axis = style["axis"]
        series = prepared_panel[metric_name]
        jitter = _expanded_jitter(jitter_patterns[metric_name], len(series["y_observed"]))
        y_display = series["y_observed"] + jitter

        observed = axis.plot(
            series["x_observed"],
            y_display,
            linestyle="none",
            marker=style["marker"],
            markersize=4.2,
            color=style["color"],
            markerfacecolor=style["color"],
            markeredgecolor=style["color"],
            label=style["label"],
            zorder=3,
        )[0]

        observed_max_x = float(series["observed_max_x"][0])
        in_sample = series["fit_grid"] <= observed_max_x
        extrapolated = series["fit_grid"] > observed_max_x
        axis.plot(
            series["fit_grid"][in_sample],
            series["fitted"][in_sample],
            linestyle=":",
            linewidth=1.4,
            color=style["color"],
            alpha=0.9,
            zorder=2,
        )
        if np.any(extrapolated):
            axis.plot(
                series["fit_grid"][extrapolated],
                series["fitted"][extrapolated],
                linestyle=":",
                linewidth=1.2,
                color=style["color"],
                alpha=0.35,
                zorder=2,
            )

        if shared_limits is not None:
            axis.set_ylim(*shared_limits[metric_name])

        axis.tick_params(axis="y", colors=style["color"], length=3.0, width=0.8, pad=2, labelsize=7.0)
        handles.append(observed)
        labels.append(style["label"])

    y_label_size = 9
    ax_runtime.set_title(title, loc="center", color=title_color, pad=8, fontweight="normal", fontsize=10.5)
    ax_runtime.set_xlabel("Control group sample size (log scale)", color=axis_label_color)
    ax_runtime.set_ylabel("Runtime (minutes)", color=styles["runtime_minutes"]["color"], fontsize=y_label_size, labelpad=4)
    ax_mse.set_ylabel("MSE of Outcomes Model", color=styles["outcome_mse"]["color"], fontsize=y_label_size, labelpad=6)
    ax_att.set_ylabel("Pooled ATT estimate (ERA sample)", color=styles["pooled_att_estimate"]["color"], fontsize=y_label_size, labelpad=8)
    ax_runtime.spines["left"].set_color(styles["runtime_minutes"]["color"])
    ax_mse.spines["right"].set_color(styles["outcome_mse"]["color"])
    ax_att.spines["right"].set_color(styles["pooled_att_estimate"]["color"])

    x_axis_limits = _control_group_x_limits(prepared_panel["runtime_minutes"]["x_observed"], x_limits)
    for axis in (ax_runtime, ax_mse, ax_att):
        _apply_control_group_x_axis(axis, x_axis_limits)
    ax_runtime.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax_mse.yaxis.set_major_locator(MaxNLocator(nbins=6))
    ax_att.yaxis.set_major_locator(MaxNLocator(nbins=6))

    return handles, labels


def plot_control_group_size_tradeoffs(
    points: list[ControlGroupSizePoint],
    *,
    output_path: str | Path = "control_group_size_tradeoffs.png",
    title: str = "Basic covariates",
    caption: str | None = None,
    x_limits: tuple[float, float] | None = None,
    y_limits: dict[str, tuple[float, float]] | None = None,
    y_axis_limits: dict[str, tuple[float, float]] | None = None,
    fit_specs: dict[str, FitSpec] | None = None,
    legend_position: str = "upper_right",
) -> Path:
    if not points:
        raise ValueError("points must not be empty")

    valid_series = {"outcome_mse", "runtime_minutes", "pooled_att_estimate"}
    fit_specs = fit_specs or {}
    _validate_metric_keys(fit_specs, valid_series, "fit_specs")
    _validate_metric_keys(y_limits, valid_series, "y_limits")
    _validate_metric_keys(y_axis_limits, valid_series, "y_axis_limits")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.titlesize": 13,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.0,
            "ytick.labelsize": 8.0,
            "legend.fontsize": 9,
        }
    )

    fig, ax_runtime, ax_mse, ax_att = _create_control_group_axes()
    fig.patch.set_facecolor("white")
    prepared_panel = {
        metric_name: _prepare_control_group_metric(points, metric_name, fit_specs.get(metric_name, LINEAR), x_limits)
        for metric_name in valid_series
    }
    shared_limits = _control_group_auto_limits([prepared_panel], y_limits, y_axis_limits)
    handles, labels = _draw_control_group_panel(
        ax_runtime,
        ax_mse,
        ax_att,
        prepared_panel,
        title=title,
        x_limits=x_limits,
        shared_limits=shared_limits,
    )

    ax_runtime.legend(
        handles,
        labels,
        **_legend_kwargs(legend_position),
        ncol=1,
        frameon=True,
        facecolor="white",
        edgecolor="#D9DEE3",
        framealpha=1.0,
        handlelength=2.2,
        borderpad=0.6,
        labelspacing=0.5,
    )

    bottom_margin = 0.20 if caption else 0.11
    fig.subplots_adjust(left=0.13, right=0.84, top=0.79, bottom=bottom_margin)

    if caption:
        fig.text(
            0.16,
            0.03,
            textwrap.fill(caption, width=100),
            ha="left",
            va="bottom",
            fontsize=7.0,
            color="#3F3F3F",
        )

    fig.savefig(output_path, dpi=400, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path


def plot_control_group_size_tradeoffs_grid(
    panels: list[ControlGroupSizePanel],
    *,
    output_path: str | Path = "control_group_size_tradeoffs_grid.png",
    title: str = "DoubleML runtime and performance: Low-complexity LightGBM models on ERA data",
    footnote: str | None = None,
    x_limits: tuple[float, float] | None = None,
    y_limits: dict[str, tuple[float, float]] | None = None,
    y_axis_limits: dict[str, tuple[float, float]] | None = None,
    legend_position: str = "bottom",
) -> Path:
    if len(panels) != 3:
        raise ValueError("panels must contain exactly three panels")
    if any(not panel.points for panel in panels):
        raise ValueError("each panel must contain at least one point")

    valid_series = {"outcome_mse", "runtime_minutes", "pooled_att_estimate"}
    _validate_metric_keys(y_limits, valid_series, "y_limits")
    _validate_metric_keys(y_axis_limits, valid_series, "y_axis_limits")
    for panel in panels:
        _validate_metric_keys(panel.fit_specs, valid_series, "fit_specs")

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    plt.rcParams.update(
        {
            "font.family": "DejaVu Sans",
            "axes.titlesize": 13,
            "axes.labelsize": 10,
            "xtick.labelsize": 8.0,
            "ytick.labelsize": 8.0,
            "legend.fontsize": 9,
        }
    )

    all_x = np.concatenate(
        [np.array([point.control_group_size for point in panel.points], dtype=float) for panel in panels]
    )
    grid_x_limits = _control_group_x_limits(all_x, x_limits)

    fig, axes = plt.subplots(2, 3, figsize=(14.0, 7.8), constrained_layout=False)
    fig.patch.set_facecolor("white")

    prepared_panels = []
    for panel in panels:
        fit_specs = panel.fit_specs or {}
        prepared_panels.append(
            {
                metric_name: _prepare_control_group_metric(
                    panel.points,
                    metric_name,
                    fit_specs.get(metric_name, LINEAR),
                    grid_x_limits,
                )
                for metric_name in ("runtime_minutes", "outcome_mse", "pooled_att_estimate")
            }
        )

    shared_limits = _control_group_grid_limits(prepared_panels, y_limits, y_axis_limits)
    spine_color = "#B8B8B8"
    tick_color = "#3F3F3F"
    axis_label_color = "#2F2F2F"
    title_color = "#1A1A1A"
    styles = {
        "runtime_minutes": {"color": OIColors.ORANGE, "marker": "s", "label": "Runtime (minutes)"},
        "outcome_mse": {"color": OIColors.TEAL, "marker": "o", "label": "Outcome-model MSE"},
        "pooled_att_estimate": {"color": OIColors.BLUE, "marker": "^", "label": "Pooled ATT estimate"},
    }
    jitter_patterns = {
        "runtime_minutes": np.array([0.6, -0.8, 0.9, -0.7, 0.5, -0.4, 0.3, -0.2]),
        "outcome_mse": np.array([0.008, -0.006, 0.004, -0.005, 0.003, -0.002, 0.002, -0.001]),
        "pooled_att_estimate": np.array([80, -65, 55, -45, 35, -25, 18, -10]),
    }
    legend_handles = {}

    for column, (panel, prepared) in enumerate(zip(panels, prepared_panels, strict=True)):
        ax_att = axes[0, column]
        ax_mse = ax_att.twinx()
        ax_runtime = axes[1, column]

        _style_scaling_axis(ax_att, spine_color=spine_color, tick_color=tick_color)
        _style_scaling_axis(ax_mse, spine_color=spine_color, tick_color=tick_color)
        _style_scaling_axis(ax_runtime, spine_color=spine_color, tick_color=tick_color)

        ax_att.spines["left"].set_color(styles["pooled_att_estimate"]["color"])
        ax_att.spines["right"].set_visible(False)
        ax_mse.spines["left"].set_visible(False)
        ax_mse.spines["bottom"].set_visible(False)
        ax_mse.spines["right"].set_color(styles["outcome_mse"]["color"])
        ax_mse.patch.set_visible(False)
        ax_runtime.spines["left"].set_color(styles["runtime_minutes"]["color"])
        ax_runtime.spines["right"].set_visible(False)

        att_handle = _plot_prepared_control_group_series(
            ax_att,
            prepared["pooled_att_estimate"],
            color=styles["pooled_att_estimate"]["color"],
            marker=styles["pooled_att_estimate"]["marker"],
            label=styles["pooled_att_estimate"]["label"],
            jitter=jitter_patterns["pooled_att_estimate"],
        )
        mse_handle = _plot_prepared_control_group_series(
            ax_mse,
            prepared["outcome_mse"],
            color=styles["outcome_mse"]["color"],
            marker=styles["outcome_mse"]["marker"],
            label=styles["outcome_mse"]["label"],
            jitter=jitter_patterns["outcome_mse"],
        )
        runtime_handle = _plot_prepared_control_group_series(
            ax_runtime,
            prepared["runtime_minutes"],
            color=styles["runtime_minutes"]["color"],
            marker=styles["runtime_minutes"]["marker"],
            label=styles["runtime_minutes"]["label"],
            jitter=jitter_patterns["runtime_minutes"],
        )

        legend_handles.setdefault("runtime_minutes", runtime_handle)
        legend_handles.setdefault("outcome_mse", mse_handle)
        legend_handles.setdefault("pooled_att_estimate", att_handle)

        ax_att.set_title(
            _control_group_panel_title(panel),
            loc="center",
            color=title_color,
            pad=10,
            fontweight="normal",
            fontsize=10.0,
        )
        _apply_control_group_x_axis(ax_att, grid_x_limits)
        _apply_control_group_x_axis(ax_mse, grid_x_limits)
        _apply_control_group_x_axis(ax_runtime, grid_x_limits)
        ax_att.tick_params(axis="x", labelbottom=False)
        ax_mse.tick_params(axis="x", labelbottom=False)
        ax_att.set_ylim(*shared_limits["pooled_att_estimate"])
        ax_mse.set_ylim(*shared_limits["outcome_mse"])
        ax_runtime.set_ylim(*shared_limits["runtime_minutes"])

        ax_att.yaxis.set_major_locator(MaxNLocator(nbins=5))
        ax_att.yaxis.set_major_formatter(FuncFormatter(lambda value, _: _format_dollars_in_thousands(value)))
        ax_mse.yaxis.set_major_locator(MaxNLocator(nbins=5))
        ax_runtime.yaxis.set_major_locator(MaxNLocator(nbins=5))

        ax_att.tick_params(
            axis="y",
            colors=styles["pooled_att_estimate"]["color"],
            length=3.0,
            width=0.8,
            pad=2,
            labelsize=9.0,
        )
        ax_mse.tick_params(
            axis="y",
            colors=styles["outcome_mse"]["color"],
            length=3.0,
            width=0.8,
            pad=2,
            labelsize=9.0,
        )
        ax_runtime.tick_params(
            axis="y",
            colors=styles["runtime_minutes"]["color"],
            length=3.0,
            width=0.8,
            pad=2,
            labelsize=9.0,
        )
        for axis in (ax_att, ax_mse, ax_runtime):
            axis.tick_params(axis="x", labelsize=9.0)
            for tick_label in axis.get_xticklabels():
                tick_label.set_fontweight("normal")
            for tick_label in axis.get_yticklabels():
                tick_label.set_fontweight("normal")

        if column != 0:
            ax_att.tick_params(axis="y", labelleft=False, left=False)
            ax_runtime.tick_params(axis="y", labelleft=False, left=False)
        if column != len(panels) - 1:
            ax_mse.tick_params(axis="y", labelright=False, right=False)

        ax_att.set_ylabel(
            "Pooled ATT estimate ($k)" if column == 0 else "",
            color=styles["pooled_att_estimate"]["color"],
            fontsize=11,
            fontweight="normal",
            labelpad=4,
        )
        ax_mse.set_ylabel(
            "Outcome-model MSE" if column == len(panels) - 1 else "",
            color=styles["outcome_mse"]["color"],
            fontsize=11,
            fontweight="normal",
            labelpad=6,
        )
        ax_runtime.set_ylabel(
            "Runtime (minutes)" if column == 0 else "",
            color=styles["runtime_minutes"]["color"],
            fontsize=11,
            fontweight="normal",
            labelpad=4,
        )
        ax_runtime.set_xlabel(
            "Control group sample size (log scale)" if column == 1 else "",
            color=axis_label_color,
            fontsize=10,
        )

    fig.suptitle(title, fontsize=11, fontweight="normal", y=0.965)
    ordered_legend_keys = ["runtime_minutes", "outcome_mse", "pooled_att_estimate"]
    legend_args = {
        "handles": [legend_handles[key] for key in ordered_legend_keys],
        "labels": [styles[key]["label"] for key in ordered_legend_keys],
        "ncol": 3,
        "frameon": True,
        "facecolor": "white",
        "edgecolor": "#D9DEE3",
        "framealpha": 1.0,
        "handlelength": 2.2,
        "borderpad": 0.6,
        "labelspacing": 0.5,
    }
    if legend_position == "bottom":
        fig.legend(loc="lower center", bbox_to_anchor=(0.5, 0.08 if footnote else 0.055), **legend_args)
    else:
        fig.legend(**_legend_kwargs(legend_position), **legend_args)

    bottom_margin = 0.23 if footnote else 0.19
    fig.subplots_adjust(left=0.095, right=0.905, top=0.875, bottom=bottom_margin, wspace=0.14, hspace=0.24)

    if footnote:
        fig.text(
            0.075,
            0.018,
            footnote,
            ha="left",
            va="bottom",
            fontsize=7.0,
            color="#3F3F3F",
        )

    fig.savefig(output_path, dpi=400, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return output_path
