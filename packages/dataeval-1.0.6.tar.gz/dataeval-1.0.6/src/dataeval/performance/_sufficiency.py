__all__ = []

import copy
from collections.abc import Callable, Iterable, Sized
from typing import Any, Generic, TypeVar

import numpy as np
from pydantic import field_validator

from dataeval.performance._aggregator import ResultAggregator
from dataeval.performance._output import SufficiencyOutput
from dataeval.performance.schedules import GeometricSchedule, ManualSchedule
from dataeval.protocols import Dataset, EvaluationSchedule, EvaluationStrategy, TrainingStrategy
from dataeval.types import Evaluator, EvaluatorConfig, set_metadata

DEFAULT_SUFFICIENCY_RUNS = 1
DEFAULT_SUFFICIENCY_SUBSTEPS = 5
DEFAULT_SUFFICIENCY_UNIT_INTERVAL = True

T = TypeVar("T")
M = TypeVar("M")
_T = TypeVar("_T")
_M = TypeVar("_M")


def validate_dataset_len(dataset: Dataset[Any]) -> int:
    if not isinstance(dataset, Sized):
        raise TypeError("Must provide a dataset with a length attribute")
    length: int = len(dataset)
    if length <= 0:
        raise ValueError("Dataset length must be greater than 0")
    return length


class Sufficiency(Evaluator, Generic[T, M]):
    """
    Analyze how much training data is needed for target model performance.

    Trains models on progressively larger data subsets, evaluates at each step,
    and fits power law curves to predict performance on larger datasets.

    This class is backend-agnostic and supports any ML framework (PyTorch,
    TensorFlow, JAX, etc.) through configurable strategies.

    Parameters
    ----------
    model : Any
        Model to train (reset for each run). Can be any model type supported
        by your training and evaluation strategies.
    training_strategy : TrainingStrategy or None, default None
        Strategy for training models. If None, uses config.training_strategy.
    evaluation_strategy : EvaluationStrategy or None, default None
        Strategy for evaluating models. If None, uses config.evaluation_strategy.
    reset_strategy : Callable[[Any], Any] or None, default None
        Strategy for resetting model parameters between runs.
        Must be a callable that takes the model and returns a reset model
        (e.g., with re-initialized weights). If None, defaults to
        ``copy.deepcopy`` of the model captured at construction time.
    runs : int or None, default None
        Number of independent training runs. If None, uses config.runs (default 1).
    substeps : int or None, default None
        Number of evaluation steps per run. If None, uses config.substeps (default 5).
    unit_interval : bool or None, default None
        Whether metrics are constrained to [0, 1]. If None, uses config.unit_interval (default True).
    config : Sufficiency.Config or None, default None
        Optional configuration object. Parameters passed directly to __init__ override config values.

    Warning
    -------
    Since each run is trained sequentially, increasing the parameter `runs` can significantly increase runtime.

    Notes
    -----
    Multiple runs average results to reduce variance.

    Parameters passed directly to __init__ override config defaults.

    See Also
    --------
    :class:`.Sufficiency.Config` : Configuration object
    :class:`.SufficiencyOutput` : Results with measures and projections
    :class:`.ModelResetStrategy` : Protocol for reset strategies
    """

    class Config(EvaluatorConfig, Generic[_T, _M]):
        """
        Configuration for sufficiency analysis execution.

        Attributes
        ----------
        training_strategy : TrainingStrategy
            Strategy for training models on dataset subsets. Must implement
            the `train(model, dataset, indices)` method.
        evaluation_strategy : EvaluationStrategy
            Strategy for evaluating trained models. Must implement the
            `evaluate(model, dataset)` method returning metrics.
        reset_strategy : Callable[[Any], Any] or None, default None
            Strategy for resetting model parameters between runs. Required
            when using Sufficiency. Must be a callable that takes the model
            and returns a reset model (e.g., with re-initialized weights).
        runs : int, default 1
            Number of independent training runs to perform. Each run trains
            a fresh model from scratch.
        substeps : int, default 5
            Number of evaluation steps per run. Used for default geometric
            schedule if no custom schedule is provided.
        unit_interval : bool, default True
            Whether metrics are constrained to [0, 1]. Set True for metrics
            like accuracy, precision, recall. Set False for unbounded metrics
            like loss or error.

        Raises
        ------
        ValueError
            If runs or substeps is not at least 1

        Examples
        --------
        Basic configuration:

        >>> training = CustomTrainingStrategy(learning_rate=0.001, epochs=10)
        >>> evaluation = CustomEvaluationStrategy(batch_size=32)
        >>> config = Sufficiency.Config(
        ...     training_strategy=training,
        ...     evaluation_strategy=evaluation,
        ...     runs=3,
        ...     substeps=5,
        ... )

        Configuration for unbounded metrics (e.g., loss):

        >>> config = Sufficiency.Config(
        ...     training_strategy=training,
        ...     evaluation_strategy=evaluation,
        ...     runs=5,
        ...     unit_interval=False,  # For loss metrics
        ... )

        Configuration with custom reset strategy:

        >>> def custom_reset(model):
        ...     # Custom logic to reset model parameters
        ...     return model

        >>> config = Sufficiency.Config(
        ...     training_strategy=training,
        ...     evaluation_strategy=evaluation,
        ...     reset_strategy=custom_reset,
        ... )

        See Also
        --------
        - :class:`.TrainingStrategy`
        - :class:`.EvaluationStrategy`
        - :class:`.ModelResetStrategy`
        """

        training_strategy: TrainingStrategy[_T] | None = None
        evaluation_strategy: EvaluationStrategy[_T] | None = None
        reset_strategy: Callable[[_M], _M] | None = None
        runs: int = DEFAULT_SUFFICIENCY_RUNS
        substeps: int = DEFAULT_SUFFICIENCY_SUBSTEPS
        unit_interval: bool = DEFAULT_SUFFICIENCY_UNIT_INTERVAL

        @field_validator("runs", "substeps")
        @classmethod
        def validate_positive(cls, v: int) -> int:
            if v <= 0:
                raise ValueError("must be positive")
            return v

    runs: int
    substeps: int
    unit_interval: bool
    training_strategy: TrainingStrategy[T]
    evaluation_strategy: EvaluationStrategy[T]
    reset_strategy: Callable[[M], M]
    config: Config[T, M]

    def __init__(
        self,
        model: M,
        training_strategy: TrainingStrategy[T] | None = None,
        evaluation_strategy: EvaluationStrategy[T] | None = None,
        reset_strategy: Callable[[M], M] | None = None,
        runs: int | None = None,
        substeps: int | None = None,
        unit_interval: bool | None = None,
        config: Config[T, M] | None = None,
    ) -> None:
        self.model = model

        # Store reset_strategy before super().__init__ as Pydantic can't serialize callables properly
        # Priority: direct param > config > deepcopy default
        _reset_strategy = reset_strategy
        if _reset_strategy is None and config is not None:
            _reset_strategy = config.reset_strategy
        if _reset_strategy is None:
            # Default: deepcopy the model at init time, return a fresh copy on each reset
            clean_model = copy.deepcopy(model)
            _reset_strategy = lambda _: copy.deepcopy(clean_model)  # noqa: E731

        super().__init__(locals(), exclude={"model", "reset_strategy"})

        self.reset_strategy = _reset_strategy

        # Validate parameters
        if self.runs <= 0:
            raise ValueError(f"runs must be positive, got {self.runs}")
        if self.substeps <= 0:
            raise ValueError(f"substeps must be positive, got {self.substeps}")

    def _create_schedule(self, schedule: EvaluationSchedule | int | Iterable[int] | None) -> EvaluationSchedule:
        """
        Convert schedule parameter into an EvaluationSchedule object.

        Handles auto-wrapping of int and iterable inputs for convenience.

        Parameters
        ----------
        schedule : EvaluationSchedule or int or Iterable[int] or None, default None
            Custom schedule object, specific evaluation points, or None for default geometric schedule

        Returns
        -------
        EvaluationSchedule
            Concrete schedule object
        """
        if schedule is None:
            return GeometricSchedule(substeps=self.substeps)
        if isinstance(schedule, EvaluationSchedule):
            return schedule
        # Wrap int or iterable
        return ManualSchedule(schedule)

    def _execute_run(
        self,
        run_index: int,
        steps: Iterable[int],
        aggregator: ResultAggregator,
        train_dataset: Dataset[T],
        test_dataset: Dataset[T],
        length: int,
    ) -> None:
        """
        Execute a single training run across all evaluation steps.

        This method makes temporal coupling explicit: model must be reset
        before training, and training must occur before evaluation at each step.

        Parameters
        ----------
        run_index : int
            Index of current run (0-based)
        steps : NDArray[uint32]
            Evaluation points (dataset sizes)
        aggregator : ResultAggregator
            Accumulator for storing results
        train_dataset : Dataset
            Training dataset
        test_dataset : Dataset
            Test/validation dataset
        length : int
            Length of the training dataset
        """
        # Step 1: Create randomized indices for this run
        indices = np.random.randint(0, length, size=length)

        # Step 2: Reset model to fresh initialization using the configured strategy
        model = self.reset_strategy(self.model)

        # Step 3: Train and evaluate at each step (temporal coupling explicit)
        for step_index, dataset_size in enumerate(steps):
            # Train on subset
            self.training_strategy.train(model, train_dataset, indices[: int(dataset_size)].tolist())

            # Evaluate on test set
            metrics = self.evaluation_strategy.evaluate(model, test_dataset)

            # Store results
            for metric_name, metric_value in metrics.items():
                aggregator.add_result(run=run_index, step=step_index, metric_name=metric_name, value=metric_value)

    @set_metadata(state=["runs", "substeps"])
    def evaluate(
        self,
        train_dataset: Dataset[T],
        test_dataset: Dataset[T],
        schedule: EvaluationSchedule | int | Iterable[int] | None = None,
    ) -> SufficiencyOutput:
        """
        Train and evaluate model across multiple dataset sizes.

        This function trains a model up to each step calculated from substeps. The model is then evaluated
        at that step and trained from 0 to the next step. This repeats for all substeps. Once a model has been
        trained and evaluated at all substeps, if runs is greater than one, the model weights are reset and
        the process is repeated.

        During each evaluation, the metrics returned as a dictionary by the given evaluation function are stored
        and then averaged over when all runs are complete.

        Parameters
        ----------
        train_dataset : Dataset
            Full training data
        test_dataset : Dataset
            Test/validation data
        schedule : EvaluationSchedule or int or Iterable[int] or None, default None
            Specify this to collect metrics over a specific set of dataset lengths.
            If `None`, evaluates at each step calculated by
            `np.geomspace` over the length of the dataset

        Returns
        -------
        SufficiencyOutput
            Contains steps, measures, averaged_measures, and params

        Examples
        --------
        >>> sufficiency = Sufficiency(
        ...     model=model,
        ...     training_strategy=CustomTrainingStrategy(),
        ...     evaluation_strategy=CustomEvaluationStrategy(),
        ...     reset_strategy=CustomResetStrategy(),
        ... )

        Default runs and substeps:

        >>> output = sufficiency.evaluate(train_dataset, test_dataset)

        Evaluate at specific points:

        >>> output = sufficiency.evaluate(train_dataset, test_dataset, schedule=[100, 500, 1000])

        Evaluate at a custom geometric spacing

        >>> from dataeval.performance.schedules import GeometricSchedule
        >>> output = sufficiency.evaluate(train_dataset, test_dataset, schedule=GeometricSchedule(substeps=20))

        Evaluate at custom linear steps from 0-100 inclusive

        >>> class LinearSchedule:
        ...     def get_steps(self, dataset_length):
        ...         return np.arange(0, 101, 20)
        >>> output = sufficiency.evaluate(train_dataset, test_dataset, schedule=LinearSchedule())
        """
        # Validate datasets
        length = validate_dataset_len(train_dataset)
        validate_dataset_len(test_dataset)

        # Create evaluation schedule
        schedule_obj = self._create_schedule(schedule=schedule)
        steps = schedule_obj.get_steps(length)

        aggregator = ResultAggregator(runs=self.runs, substeps=len(steps))

        # Execute all runs
        for run_index in range(self.runs):
            self._execute_run(
                run_index=run_index,
                steps=steps,
                aggregator=aggregator,
                train_dataset=train_dataset,
                test_dataset=test_dataset,
                length=length,
            )

        # Create output
        results = aggregator.get_results()
        return SufficiencyOutput(steps=steps, measures=results, unit_interval=self.unit_interval)
