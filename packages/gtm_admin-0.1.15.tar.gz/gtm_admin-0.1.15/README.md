# gtm-admin

Workflow monitoring and management for FastAPI apps.

`gtm-admin` adds a self-hosted dashboard and run-tracking API to **any FastAPI application** with zero infrastructure setup. You write pure Python workflow functions — it handles capture, persistence, and visualization.

## Install

```bash
pip install gtm-admin
```

## Usage

```python
import os
from fastapi import FastAPI
from gtm_admin import GTMAdmin

app = FastAPI()

gtm = GTMAdmin(
    app,
    db_url=os.environ["GTM_DB_URL"],    # postgresql://... connection string
    secret=os.environ["GTM_SECRET"],    # random secret for JWT signing
)

@gtm.workflow
async def enrich_leads(inputs: dict):
    """Each decorated function becomes a tracked workflow."""
    results = call_some_api(inputs["leads"])
    return {"enriched": results}
```

This mounts:

- **`/admin`** — React dashboard SPA (run history, status, I/O inspection)
- **`/api/*`** — REST API consumed by the dashboard

## Routes

| Path             | Description                                  |
| ---------------- | -------------------------------------------- |
| `/api/runs`      | List all workflow runs                       |
| `/api/runs/{id}` | Run detail (inputs, outputs, timing, errors) |
| `/api/workflows` | List registered workflows                    |
| `/api/health`    | Health check                                 |
| `/admin/`        | Dashboard SPA                                |

## Deployment (Digital Ocean App Platform)

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install gtm-admin
RUN pip install -r requirements.txt
COPY . .
EXPOSE 8080
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8080"]
```

Set in DO console: `GTM_DB_URL` (Supabase/Neon), `GTM_SECRET`.

## Development mode

In dev mode, `/admin/*` is proxied to a Vite HMR server instead of serving static files:

```python
gtm = GTMAdmin(app, db_url=..., secret=..., dev=os.getenv("GTM_DEV") == "true")
```

## Requirements

- Python 3.11+
- PostgreSQL database (Supabase, Neon, or self-hosted)
- FastAPI app

## License

MIT
