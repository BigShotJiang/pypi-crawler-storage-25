"""Seed the database with demo data (admin user + realistic workflow runs, configs, db tables).

Usage (from api/ directory):
    uv run python seed.py
"""

import asyncio
import json
import math
import os
from datetime import datetime, timedelta, timezone
from uuid import UUID, uuid4

from sqlmodel import SQLModel, select
from sqlmodel.ext.asyncio.session import AsyncSession
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy.orm import sessionmaker

from app.auth import hash_password
from app.config import settings
from app.models import ConfigRecord, DbTable, User, WorkflowRun
from app.models.workflow_run import WorkflowStatus

engine = create_async_engine(settings.async_database_url)
AsyncSessionLocal = sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

NOW = datetime.now(timezone.utc)


def dt(iso: str) -> datetime:
    return datetime.fromisoformat(iso.replace("Z", "+00:00"))


# ── Workflow runs (with full nodes) ──────────────────────────────────────────

DETAILED_RUNS: list[dict] = [
    {
        "name": "User Onboarding Pipeline",
        "status": "success",
        "triggered_by": "scheduler",
        "started_at": dt("2026-04-04T08:12:00Z"),
        "finished_at": dt("2026-04-04T08:13:47Z"),
        "nodes": [
            {"id": "n1", "name": "Fetch User Data", "status": "success",
             "inputs": {"userId": "u-8821", "includeMetadata": True},
             "outputs": {"email": "alice@example.com", "name": "Alice Martin", "plan": "pro"},
             "duration_ms": 320,
             "logs": "[08:12:00.001] INFO  Starting node execution\n[08:12:00.280] DEBUG Response 200 OK — 275ms\n[08:12:00.320] INFO  Node completed in 320ms"},
            {"id": "n2", "name": "Send Welcome Email", "status": "success",
             "inputs": {"to": "alice@example.com", "template": "welcome_pro"},
             "outputs": {"messageId": "msg-4490", "delivered": True},
             "duration_ms": 880,
             "logs": "[08:12:00.322] INFO  Starting node execution\n[08:12:01.199] INFO  Delivery acknowledged by relay\n[08:12:01.200] INFO  Node completed in 880ms"},
            {"id": "n3", "name": "Create CRM Entry", "status": "success",
             "inputs": {"name": "Alice Martin", "email": "alice@example.com", "source": "signup"},
             "outputs": {"crmId": "crm-9912", "created": True},
             "duration_ms": 430,
             "logs": "[08:12:01.202] INFO  Starting node execution\n[08:12:01.628] INFO  CRM entry created (crmId: crm-9912)\n[08:12:01.630] INFO  Node completed in 430ms"},
        ],
    },
    {
        "name": "Daily Report Generation",
        "status": "failed",
        "triggered_by": "scheduler",
        "started_at": dt("2026-04-04T07:00:00Z"),
        "finished_at": dt("2026-04-04T07:01:12Z"),
        "nodes": [
            {"id": "n1", "name": "Aggregate Sales Data", "status": "success",
             "inputs": {"date": "2026-04-03", "region": "EU"},
             "outputs": {"totalRevenue": 48200, "orders": 312},
             "duration_ms": 520},
            {"id": "n2", "name": "Generate PDF Report", "status": "failed",
             "inputs": {"data": {"totalRevenue": 48200, "orders": 312}, "template": "daily_v2"},
             "outputs": {"error": "TemplateRenderError: missing field `growth_rate`"},
             "duration_ms": 92,
             "logs": "[07:00:00.595] WARN  Variable 'growth_rate' not found in data payload\n[07:00:00.610] ERROR TemplateRenderError: missing field `growth_rate`\n[07:00:00.614] INFO  Node failed in 92ms"},
            {"id": "n3", "name": "Email Report to Stakeholders", "status": "pending",
             "inputs": {}, "outputs": {}, "duration_ms": 0},
        ],
    },
    {
        "name": "Subscription Renewal Check",
        "status": "success",
        "triggered_by": "scheduler",
        "started_at": dt("2026-04-03T22:00:00Z"),
        "finished_at": dt("2026-04-03T22:02:30Z"),
        "nodes": [
            {"id": "n1", "name": "Query Expiring Subscriptions", "status": "success",
             "inputs": {"daysUntilExpiry": 7},
             "outputs": {"count": 14, "subscriptionIds": ["s-001", "s-002", "s-003"]},
             "duration_ms": 380},
            {"id": "n2", "name": "Send Renewal Reminders", "status": "success",
             "inputs": {"subscriptionIds": ["s-001", "s-002", "s-003"], "template": "renewal_7d"},
             "outputs": {"sent": 14, "failed": 0},
             "duration_ms": 1920},
            {"id": "n3", "name": "Log to Audit Trail", "status": "success",
             "inputs": {"event": "renewal_reminders_sent", "count": 14},
             "outputs": {"auditId": "audit-8872"},
             "duration_ms": 110},
        ],
    },
    {
        "name": "Churn Prediction Scoring",
        "status": "success",
        "triggered_by": "scheduler",
        "started_at": dt("2026-04-03T18:30:00Z"),
        "finished_at": dt("2026-04-03T18:35:22Z"),
        "nodes": [
            {"id": "n1", "name": "Load User Activity", "status": "success",
             "inputs": {"cohort": "pro_monthly", "lookbackDays": 30},
             "outputs": {"usersLoaded": 822, "avgLoginFrequency": 4.2},
             "duration_ms": 1100},
            {"id": "n2", "name": "Run ML Model", "status": "success",
             "inputs": {"modelVersion": "churn-v3", "threshold": 0.75},
             "outputs": {"highRisk": 38, "mediumRisk": 119, "lowRisk": 665},
             "duration_ms": 2840},
            {"id": "n3", "name": "Write Scores to DB", "status": "success",
             "inputs": {"table": "churn_scores", "upsert": True},
             "outputs": {"rowsWritten": 822},
             "duration_ms": 560},
            {"id": "n4", "name": "Trigger High-Risk Alerts", "status": "success",
             "inputs": {"users": 38, "channel": "slack"},
             "outputs": {"slackMessageId": "slack-2291", "delivered": True},
             "duration_ms": 290},
        ],
    },
    {
        "name": "Product Catalog Sync",
        "status": "success",
        "triggered_by": "webhook",
        "started_at": dt("2026-04-03T10:00:00Z"),
        "finished_at": dt("2026-04-03T10:04:18Z"),
        "nodes": [
            {"id": "n1", "name": "Fetch Products from ERP", "status": "success",
             "inputs": {"since": "2026-04-02T10:00:00Z"},
             "outputs": {"productsUpdated": 47, "productsAdded": 3},
             "duration_ms": 1230},
            {"id": "n2", "name": "Transform to Shopify Format", "status": "success",
             "inputs": {"mapping": "erp_to_shopify_v2"},
             "outputs": {"transformed": 50, "skipped": 0},
             "duration_ms": 310},
            {"id": "n3", "name": "Push to Shopify", "status": "success",
             "inputs": {"shopDomain": "acme.myshopify.com", "batchSize": 25},
             "outputs": {"synced": 50, "errors": 0},
             "duration_ms": 2520},
        ],
    },
]

# Child runs (parent index → run data)
CHILD_RUNS: list[dict] = [
    {
        "parent_idx": 0,   # child of "User Onboarding Pipeline"
        "name": "Lead Enrichment",
        "status": "running",
        "triggered_by": "workflow",
        "started_at": dt("2026-04-04T09:45:00Z"),
        "finished_at": None,
        "nodes": [
            {"id": "n1", "name": "Fetch Lead from CRM", "status": "success",
             "inputs": {"leadId": "lead-5521"},
             "outputs": {"company": "Techcorp GmbH", "contactEmail": "bob@techcorp.de"},
             "duration_ms": 410},
            {"id": "n2", "name": "Enrich with Clearbit", "status": "running",
             "inputs": {"email": "bob@techcorp.de"}, "outputs": {}, "duration_ms": 0},
            {"id": "n3", "name": "Update CRM Record", "status": "pending",
             "inputs": {}, "outputs": {}, "duration_ms": 0},
        ],
    },
    {
        "parent_idx": 3,   # child of "Churn Prediction Scoring"
        "name": "Support Ticket Triage",
        "status": "running",
        "triggered_by": "workflow",
        "started_at": dt("2026-04-04T09:50:00Z"),
        "finished_at": None,
        "nodes": [
            {"id": "n1", "name": "Classify Ticket", "status": "success",
             "inputs": {"ticketId": "ticket-3381", "subject": "Cannot log in to dashboard"},
             "outputs": {"category": "auth", "priority": "high", "confidence": 0.94},
             "duration_ms": 680},
            {"id": "n2", "name": "Assign to Agent", "status": "success",
             "inputs": {"category": "auth", "priority": "high"},
             "outputs": {"agentId": "agent-07", "agentName": "Sam K."},
             "duration_ms": 120},
            {"id": "n3", "name": "Notify Agent via Slack", "status": "running",
             "inputs": {"agentId": "agent-07", "ticketId": "ticket-3381"},
             "outputs": {}, "duration_ms": 0},
            {"id": "n4", "name": "Update Ticket Status", "status": "pending",
             "inputs": {}, "outputs": {}, "duration_ms": 0},
        ],
    },
]

# Grandchild: child of "Lead Enrichment" (child_idx 0)
GRANDCHILD_RUNS: list[dict] = [
    {
        "parent_child_idx": 0,  # child of CHILD_RUNS[0]
        "name": "Invoice Processing",
        "status": "failed",
        "triggered_by": "workflow",
        "started_at": dt("2026-04-03T14:10:00Z"),
        "finished_at": dt("2026-04-03T14:10:45Z"),
        "nodes": [
            {"id": "n1", "name": "Parse Invoice PDF", "status": "failed",
             "inputs": {"fileUrl": "https://storage.example.com/inv-8812.pdf"},
             "outputs": {"error": "PDF parse error: encrypted document"},
             "duration_ms": 445},
            {"id": "n2", "name": "Validate Invoice Data", "status": "pending",
             "inputs": {}, "outputs": {}, "duration_ms": 0},
            {"id": "n3", "name": "Post to Accounting System", "status": "pending",
             "inputs": {}, "outputs": {}, "duration_ms": 0},
        ],
    },
]


# ── Config records ────────────────────────────────────────────────────────────

CONFIG_RECORDS = [
    {"key": "app.name", "value": "GTM Admin", "type": "string", "folder": "System",
     "description": "Application display name"},
    {"key": "max.retries", "value": "3", "type": "number", "folder": "System",
     "description": "Maximum retry attempts for failed workflows"},
    {"key": "maintenance.date", "value": "2026-05-01", "type": "date", "folder": "Infrastructure",
     "description": "Next scheduled maintenance window"},
    {"key": "report.schedule", "value": "2026-04-05T08:00", "type": "datetime", "folder": "Notifications",
     "description": "When to send the next automated report"},
    {"key": "digest.send.time", "value": "08:00", "type": "time", "folder": "Notifications",
     "description": "Daily digest delivery time"},
    {"key": "default.region", "value": "EU", "type": "select",
     "select_options": ["EU", "US", "APAC"], "folder": "Infrastructure",
     "description": "Default region for data processing"},
    {"key": "smtp.config",
     "value": json.dumps({"host": "smtp.example.com", "port": 587, "auth": {"user": "noreply@example.com"}, "tls": True}, indent=2),
     "type": "json", "folder": "Notifications", "description": "SMTP server configuration"},
    {"key": "feature.flags",
     "value": json.dumps({"darkMode": True, "betaWorkflows": False, "analyticsV2": True}, indent=2),
     "type": "json", "folder": "System", "description": "Feature toggle flags"},
]


# ── DB tables ─────────────────────────────────────────────────────────────────

DB_TABLES = [
    {
        "name": "Customers",
        "description": "All registered customers",
        "columns": [
            {"id": "col-1", "name": "id", "type": "number"},
            {"id": "col-2", "name": "name", "type": "text"},
            {"id": "col-3", "name": "email", "type": "text"},
            {"id": "col-4", "name": "plan", "type": "select", "selectOptions": ["free", "pro", "enterprise"]},
            {"id": "col-5", "name": "mrr", "type": "number"},
            {"id": "col-6", "name": "active", "type": "boolean"},
            {"id": "col-7", "name": "joinedAt", "type": "date"},
            {"id": "col-8", "name": "metadata", "type": "json"},
        ],
        "rows": [
            {"id": "row-1", "col-1": 1, "col-2": "Alice Martin", "col-3": "alice@example.com",
             "col-4": "pro", "col-5": 149, "col-6": True, "col-7": "2025-11-12",
             "col-8": json.dumps({"source": "organic", "tags": ["early-adopter"], "loginCount": 42}, indent=2)},
            {"id": "row-2", "col-1": 2, "col-2": "Bob Strauss", "col-3": "bob@techcorp.de",
             "col-4": "enterprise", "col-5": 599, "col-6": True, "col-7": "2025-08-03",
             "col-8": json.dumps({"source": "referral", "seats": 12, "ssoEnabled": True}, indent=2)},
            {"id": "row-3", "col-1": 3, "col-2": "Clara Ng", "col-3": "clara@startup.io",
             "col-4": "free", "col-5": 0, "col-6": False, "col-7": "2026-01-20",
             "col-8": json.dumps({"source": "product-hunt", "tags": ["churned"]}, indent=2)},
            {"id": "row-4", "col-1": 4, "col-2": "David Kim", "col-3": "dkim@agency.co",
             "col-4": "pro", "col-5": 149, "col-6": True, "col-7": "2025-12-01",
             "col-8": json.dumps({"source": "google-ads", "loginCount": 18}, indent=2)},
            {"id": "row-5", "col-1": 5, "col-2": "Ema Rossi", "col-3": "ema@brand.it",
             "col-4": "enterprise", "col-5": 599, "col-6": True, "col-7": "2025-07-15",
             "col-8": json.dumps({"source": "direct", "seats": 5}, indent=2)},
        ],
    },
    {
        "name": "Workflows",
        "description": "Registered workflow definitions",
        "columns": [
            {"id": "col-1", "name": "id", "type": "text"},
            {"id": "col-2", "name": "name", "type": "text"},
            {"id": "col-3", "name": "trigger", "type": "select", "selectOptions": ["scheduler", "webhook", "manual", "workflow"]},
            {"id": "col-4", "name": "enabled", "type": "boolean"},
            {"id": "col-5", "name": "lastRunAt", "type": "date"},
        ],
        "rows": [
            {"id": "row-1", "col-1": "wf-001", "col-2": "User Onboarding Pipeline",
             "col-3": "scheduler", "col-4": True, "col-5": "2026-04-04"},
            {"id": "row-2", "col-1": "wf-002", "col-2": "Daily Report Generation",
             "col-3": "scheduler", "col-4": True, "col-5": "2026-04-04"},
            {"id": "row-3", "col-1": "wf-003", "col-2": "Product Catalog Sync",
             "col-3": "webhook", "col-4": True, "col-5": "2026-04-03"},
        ],
    },
]


# ── Historical runs for chart (lightweight, no nodes) ──────────────────────

def _seeded(seed: int) -> float:
    x = math.sin(seed + 1) * 10000
    return x - math.floor(x)

HOUR_MS = 3_600_000


def _generate_historical_runs() -> list[dict]:
    """Generate ~150 realistic historical runs spread over the last 30 days."""
    runs = []
    base = NOW - timedelta(days=30)
    now_ms = int(NOW.timestamp() * 1000)
    base_ms = int(base.timestamp() * 1000)
    step_ms = HOUR_MS

    t = (base_ms // step_ms) * step_ms
    slot = 0
    while t <= now_ms:
        d = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
        hour = d.hour
        dow = d.weekday()
        is_weekend = dow >= 5
        is_biz = 8 <= hour <= 18
        max_runs = max(1, round((2 if is_weekend else 18 if is_biz else 4)))
        count = int(_seeded(slot) * max_runs)
        for i in range(count):
            has_failed = _seeded(slot * 100 + i + 77) < 0.13
            status = WorkflowStatus.failed if has_failed else WorkflowStatus.success
            started = datetime.fromtimestamp(t / 1000, tz=timezone.utc)
            runs.append({
                "name": f"Historical Run {slot}-{i}",
                "status": status,
                "triggered_by": "scheduler",
                "started_at": started,
                "finished_at": started + timedelta(minutes=2),
                "nodes": [],
            })
        t += step_ms
        slot += 1

    return runs


# ── Seeder ────────────────────────────────────────────────────────────────────

async def seed() -> None:
    async with AsyncSessionLocal() as session:
        # Admin user
        existing_user = await session.get(User, "admin")
        if not existing_user:
            session.add(User(username="admin", hashed_password=hash_password("password")))
            print("✅ Created admin user (admin / password)")

        # Config records
        existing_configs = await session.exec(select(ConfigRecord))
        if not existing_configs.all():
            for cfg in CONFIG_RECORDS:
                session.add(ConfigRecord(**cfg))
            print(f"✅ Seeded {len(CONFIG_RECORDS)} config records")

        # DB tables
        existing_tables = await session.exec(select(DbTable))
        if not existing_tables.all():
            for tbl in DB_TABLES:
                session.add(DbTable(**tbl))
            print(f"✅ Seeded {len(DB_TABLES)} database tables")

        # Workflow runs
        existing_runs = await session.exec(select(WorkflowRun))
        if not existing_runs.all():
            # Historical (chart data)
            historical = _generate_historical_runs()
            for run_data in historical:
                session.add(WorkflowRun(**run_data))
            print(f"✅ Seeded {len(historical)} historical runs")

            # Detailed top-level runs
            parent_ids: list[UUID] = []
            for run_data in DETAILED_RUNS:
                run = WorkflowRun(**run_data)
                session.add(run)
                parent_ids.append(run.id)

            # Child runs
            child_ids: list[UUID] = []
            for child_data in CHILD_RUNS:
                parent_idx = child_data.pop("parent_idx")
                child = WorkflowRun(**child_data, parent_id=parent_ids[parent_idx])
                session.add(child)
                child_ids.append(child.id)

            # Grandchild runs
            for gc_data in GRANDCHILD_RUNS:
                child_idx = gc_data.pop("parent_child_idx")
                grandchild = WorkflowRun(**gc_data, parent_id=child_ids[child_idx])
                session.add(grandchild)

            print(f"✅ Seeded {len(DETAILED_RUNS)} detailed runs + {len(CHILD_RUNS)} children + {len(GRANDCHILD_RUNS)} grandchildren")

        await session.commit()
        print("🌱 Seed complete.")


if __name__ == "__main__":
    asyncio.run(seed())
