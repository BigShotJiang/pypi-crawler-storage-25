from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import and_, func
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.database import get_session
from app.deps import get_current_user
from app.models.user import User
from app.models.workflow_run import WorkflowRun, WorkflowRunCreate, WorkflowRunUpdate
from app.schemas import CamelModel

router = APIRouter(prefix="/workflow-runs", tags=["workflow-runs"])


# ── Response schemas ─────────────────────────────────────────────────────────

class WorkflowNodeRead(CamelModel):
    id: str
    name: str
    status: str
    inputs: dict[str, Any] = {}
    outputs: dict[str, Any] = {}
    duration_ms: int = 0
    logs: str | None = None


class WorkflowRunSummary(CamelModel):
    """Lightweight projection — no nodes. Used by list and stats endpoints."""
    id: str
    name: str
    status: str
    triggered_by: str
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    children: list[WorkflowRunSummary] = []


WorkflowRunSummary.model_rebuild()


class WorkflowRunRead(CamelModel):
    """Full projection — includes nodes. Used by detail endpoint."""
    id: str
    name: str
    status: str
    triggered_by: str
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime
    nodes: list[WorkflowNodeRead] = []
    children: list[WorkflowRunRead] = []


WorkflowRunRead.model_rebuild()


class WorkflowStats(CamelModel):
    counts: dict[str, int]
    active: list[WorkflowRunSummary]
    recent: list[WorkflowRunSummary]


# ── Tree builders ─────────────────────────────────────────────────────────────

def _to_summary(run: WorkflowRun, children_map: dict[UUID, list[WorkflowRun]]) -> WorkflowRunSummary:
    return WorkflowRunSummary(
        id=str(run.id),
        name=run.name,
        status=run.status.value,
        triggered_by=run.triggered_by,
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        children=[_to_summary(c, children_map) for c in children_map.get(run.id, [])],
    )


def build_summary_tree(runs: list[WorkflowRun]) -> list[WorkflowRunSummary]:
    children_map: dict[UUID, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            children_map[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_to_summary(r, children_map) for r in roots]


def build_tree(runs: list[WorkflowRun]) -> list[WorkflowRunRead]:
    children_map: dict[UUID, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            children_map[r.parent_id].append(r)
        else:
            roots.append(r)

    def to_read(run: WorkflowRun) -> WorkflowRunRead:
        return WorkflowRunRead(
            id=str(run.id),
            name=run.name,
            status=run.status.value,
            triggered_by=run.triggered_by,
            started_at=run.started_at,
            finished_at=run.finished_at,
            created_at=run.created_at,
            nodes=[WorkflowNodeRead(**n) for n in (run.nodes or [])],
            children=[to_read(c) for c in children_map.get(run.id, [])],
        )

    return [to_read(r) for r in roots]


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("/stats", response_model=WorkflowStats, response_model_by_alias=True)
async def get_workflow_stats(
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """Aggregated stats for the overview page — no full row scan needed."""
    # Count per status via GROUP BY
    raw = await session.execute(
        select(WorkflowRun.status, func.count(WorkflowRun.id)).group_by(WorkflowRun.status)
    )
    counts: dict[str, int] = {s.value if hasattr(s, 'value') else str(s): c for s, c in raw.all()}
    for s in ("pending", "running", "success", "failed"):
        counts.setdefault(s, 0)

    # Active (running) — typically a small set
    active = list((await session.exec(
        select(WorkflowRun).where(WorkflowRun.status == "running")  # type: ignore[arg-type]
    )).all())

    # 5 most recent non-running
    recent = list((await session.exec(
        select(WorkflowRun)
        .where(WorkflowRun.status != "running")  # type: ignore[arg-type]
        .order_by(WorkflowRun.started_at.desc())
        .limit(5)
    )).all())

    def to_summary(r: WorkflowRun) -> WorkflowRunSummary:
        return WorkflowRunSummary(
            id=str(r.id), name=r.name, status=r.status.value,
            triggered_by=r.triggered_by, started_at=r.started_at,
            finished_at=r.finished_at, created_at=r.created_at,
        )

    return WorkflowStats(
        counts=counts,
        active=[to_summary(r) for r in active],
        recent=[to_summary(r) for r in recent],
    )


@router.get("", response_model=list[WorkflowRunSummary], response_model_by_alias=True)
async def list_workflow_runs(
    fastapi_response: Response,
    offset: int = 0,
    limit: int = 50,
    search: str = "",
    status: str = "",
    date_from: datetime | None = None,
    date_to: datetime | None = None,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """Paginated list of root runs (summaries only — no nodes).
    Children/grandchildren are batch-fetched alongside each page."""
    conds = [WorkflowRun.parent_id == None]  # noqa: E711
    if search:
        conds.append(WorkflowRun.name.ilike(f"%{search}%"))
    if status:
        conds.append(WorkflowRun.status == status)  # type: ignore[arg-type]
    if date_from:
        conds.append(WorkflowRun.started_at >= date_from)
    if date_to:
        conds.append(WorkflowRun.started_at <= date_to)

    where = and_(*conds)

    # Total count (for X-Total-Count header used by infinite scroll)
    total = (await session.execute(
        select(func.count(WorkflowRun.id)).where(where)
    )).scalar_one()
    fastapi_response.headers["X-Total-Count"] = str(total)

    # Paginated root runs — secondary sort on id ensures stable pages
    # when multiple runs share the same started_at timestamp
    roots = list((await session.exec(
        select(WorkflowRun)
        .where(where)
        .order_by(WorkflowRun.started_at.desc(), WorkflowRun.id.desc())
        .offset(offset)
        .limit(limit)
    )).all())

    if not roots:
        return []

    # Batch-fetch children & grandchildren (2 levels deep, 2 extra queries)
    root_ids = [r.id for r in roots]
    children = list((await session.exec(
        select(WorkflowRun).where(WorkflowRun.parent_id.in_(root_ids))
    )).all())

    grandchildren: list[WorkflowRun] = []
    if children:
        child_ids = [c.id for c in children]
        grandchildren = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
        )).all())

    return build_summary_tree(roots + children + grandchildren)


@router.get("/{id}", response_model=WorkflowRunRead, response_model_by_alias=True)
async def get_workflow_run(
    id: UUID,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """Full detail for a single run — includes nodes and nested children."""
    run = await session.get(WorkflowRun, id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")

    # Fetch this run's descendants (typically a tiny subtree)
    children = list((await session.exec(
        select(WorkflowRun).where(WorkflowRun.parent_id == id)
    )).all())

    grandchildren: list[WorkflowRun] = []
    if children:
        child_ids = [c.id for c in children]
        grandchildren = list((await session.exec(
            select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
        )).all())

    trees = build_tree([run] + children + grandchildren)
    return trees[0]


@router.post("", response_model=WorkflowRunRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED)
async def create_workflow_run(
    body: WorkflowRunCreate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    run = WorkflowRun.model_validate(body)
    session.add(run)
    await session.commit()
    await session.refresh(run)
    return WorkflowRunRead(
        id=str(run.id), name=run.name, status=run.status.value,
        triggered_by=run.triggered_by, started_at=run.started_at,
        finished_at=run.finished_at, created_at=run.created_at,
        nodes=[WorkflowNodeRead(**n) for n in (run.nodes or [])],
    )


@router.patch("/{id}", response_model=WorkflowRunRead, response_model_by_alias=True)
async def update_workflow_run(
    id: UUID,
    body: WorkflowRunUpdate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    run = await session.get(WorkflowRun, id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")
    for field, value in body.model_dump(exclude_unset=True).items():
        setattr(run, field, value)
    session.add(run)
    await session.commit()
    await session.refresh(run)
    return WorkflowRunRead(
        id=str(run.id), name=run.name, status=run.status.value,
        triggered_by=run.triggered_by, started_at=run.started_at,
        finished_at=run.finished_at, created_at=run.created_at,
        nodes=[WorkflowNodeRead(**n) for n in (run.nodes or [])],
    )


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_workflow_run(
    id: UUID,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    run = await session.get(WorkflowRun, id)
    if not run:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")
    await session.delete(run)
    await session.commit()
