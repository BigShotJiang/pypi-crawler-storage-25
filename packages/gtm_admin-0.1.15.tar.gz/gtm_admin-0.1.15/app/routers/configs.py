from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.database import get_session
from app.deps import get_current_user
from app.models.config_record import ConfigRecord
from app.models.user import User
from app.schemas import CamelModel

router = APIRouter(prefix="/configs", tags=["configs"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class ConfigRead(CamelModel):
    id: str
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None
    created_at: datetime
    updated_at: datetime


class ConfigCreate(CamelModel):
    key: str
    value: str
    type: str
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


class ConfigUpdate(CamelModel):
    key: str | None = None
    value: str | None = None
    type: str | None = None
    select_options: list[str] | None = None
    description: str | None = None
    folder: str | None = None


def _to_read(r: ConfigRecord) -> ConfigRead:
    return ConfigRead(
        id=str(r.id),
        key=r.key, value=r.value, type=r.type,
        select_options=r.select_options,
        description=r.description, folder=r.folder,
        created_at=r.created_at, updated_at=r.updated_at,
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("", response_model=list[ConfigRead], response_model_by_alias=True)
async def list_configs(
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    result = await session.exec(select(ConfigRecord))
    return [_to_read(r) for r in result.all()]


@router.post("", response_model=ConfigRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED)
async def create_config(
    body: ConfigCreate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    record = ConfigRecord(**body.model_dump(by_alias=False))
    session.add(record)
    await session.commit()
    await session.refresh(record)
    return _to_read(record)


@router.patch("/{id}", response_model=ConfigRead, response_model_by_alias=True)
async def update_config(
    id: UUID,
    body: ConfigUpdate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    record = await session.get(ConfigRecord, id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
    for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
        setattr(record, field, value)
    record.updated_at = datetime.now(timezone.utc)
    session.add(record)
    await session.commit()
    await session.refresh(record)
    return _to_read(record)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_config(
    id: UUID,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    record = await session.get(ConfigRecord, id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
    await session.delete(record)
    await session.commit()
