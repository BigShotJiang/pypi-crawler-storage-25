from datetime import datetime, timezone
from typing import Any
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.database import get_session
from app.deps import get_current_user
from app.models.db_table import DbTable
from app.models.user import User
from app.schemas import CamelModel

router = APIRouter(prefix="/db-tables", tags=["db-tables"])


# ── Schemas ───────────────────────────────────────────────────────────────────

class DbTableRead(CamelModel):
    id: str
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []
    created_at: datetime
    updated_at: datetime


class DbTableCreate(CamelModel):
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = []
    rows: list[dict[str, Any]] = []


class DbTableUpdate(CamelModel):
    name: str | None = None
    description: str | None = None
    columns: list[dict[str, Any]] | None = None
    rows: list[dict[str, Any]] | None = None


def _to_read(t: DbTable) -> DbTableRead:
    return DbTableRead(
        id=str(t.id),
        name=t.name, description=t.description,
        columns=t.columns or [], rows=t.rows or [],
        created_at=t.created_at, updated_at=t.updated_at,
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@router.get("", response_model=list[DbTableRead], response_model_by_alias=True)
async def list_db_tables(
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    result = await session.exec(select(DbTable))
    return [_to_read(t) for t in result.all()]


@router.get("/{id}", response_model=DbTableRead, response_model_by_alias=True)
async def get_db_table(
    id: UUID,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    t = await session.get(DbTable, id)
    if not t:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
    return _to_read(t)


@router.post("", response_model=DbTableRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED)
async def create_db_table(
    body: DbTableCreate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    t = DbTable(**body.model_dump(by_alias=False))
    session.add(t)
    await session.commit()
    await session.refresh(t)
    return _to_read(t)


@router.patch("/{id}", response_model=DbTableRead, response_model_by_alias=True)
async def update_db_table(
    id: UUID,
    body: DbTableUpdate,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    t = await session.get(DbTable, id)
    if not t:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
    for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
        setattr(t, field, value)
    t.updated_at = datetime.now(timezone.utc)
    session.add(t)
    await session.commit()
    await session.refresh(t)
    return _to_read(t)


@router.delete("/{id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_db_table(
    id: UUID,
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    t = await session.get(DbTable, id)
    if not t:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Table not found")
    await session.delete(t)
    await session.commit()
