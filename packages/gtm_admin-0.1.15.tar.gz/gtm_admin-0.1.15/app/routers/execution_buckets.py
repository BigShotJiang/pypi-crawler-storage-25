from fastapi import APIRouter, Depends, Query
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from app.database import get_session
from app.deps import get_current_user
from app.models.user import User
from app.models.workflow_run import WorkflowRun, WorkflowStatus

router = APIRouter(prefix="/execution-buckets", tags=["execution-buckets"])


@router.get("", response_model=list[dict])
async def get_execution_buckets(
    from_ms: int = Query(..., alias="from"),
    to_ms: int = Query(..., alias="to"),
    step_ms: int = Query(..., alias="step"),
    session: AsyncSession = Depends(get_session),
    _: User = Depends(get_current_user),
):
    """Aggregate workflow-run counts into fixed-width time buckets.

    Each bucket: ``{x: <epoch ms>, y: <run count>, hasFailed: <bool>}``
    """
    from datetime import datetime, timezone

    dt_from = datetime.fromtimestamp(from_ms / 1000, tz=timezone.utc)
    dt_to = datetime.fromtimestamp(to_ms / 1000, tz=timezone.utc)

    result = await session.exec(
        select(WorkflowRun).where(
            WorkflowRun.started_at >= dt_from,
            WorkflowRun.started_at <= dt_to,
        )
    )
    runs = result.all()

    # Build bucket map: slot_start_ms → {count, hasFailed}
    buckets: dict[int, dict] = {}
    for run in runs:
        if run.started_at is None:
            continue
        run_ms = int(run.started_at.timestamp() * 1000)
        slot = (run_ms // step_ms) * step_ms
        if slot not in buckets:
            buckets[slot] = {"x": slot, "y": 0, "hasFailed": False}
        buckets[slot]["y"] += 1
        if run.status == WorkflowStatus.failed:
            buckets[slot]["hasFailed"] = True

    # Fill every slot in range (sparse → dense for chart rendering)
    first_slot = (from_ms // step_ms) * step_ms
    last_slot = (to_ms // step_ms) * step_ms
    slot = first_slot
    output = []
    while slot <= last_slot:
        output.append(buckets.get(slot, {"x": slot, "y": 0, "hasFailed": False}))
        slot += step_ms

    return output
