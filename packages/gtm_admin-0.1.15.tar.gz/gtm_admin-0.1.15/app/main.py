import os

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import RedirectResponse, Response

from app.routers import auth, workflow_runs
from app.routers.configs import router as configs_router
from app.routers.db_tables import router as db_tables_router
from app.routers.execution_buckets import router as execution_buckets_router

app = FastAPI(title="GTM Admin API")

app.include_router(auth.router, prefix="/api")
app.include_router(workflow_runs.router, prefix="/api")
app.include_router(configs_router, prefix="/api")
app.include_router(db_tables_router, prefix="/api")
app.include_router(execution_buckets_router, prefix="/api")

VITE_URL = os.getenv("VITE_URL", "http://localhost:5173")


@app.get("/admin")
async def _admin_redirect() -> RedirectResponse:
    return RedirectResponse("/admin/")


@app.api_route("/admin/{path:path}", methods=["GET", "HEAD"])
async def _dev_proxy(path: str, request: Request) -> Response:
    async with httpx.AsyncClient() as client:
        url = f"{VITE_URL}/admin/{path}"
        resp = await client.request(
            method=request.method,
            url=url,
            headers={k: v for k, v in request.headers.items() if k.lower() != "host"},
        )
        return Response(
            content=resp.content,
            status_code=resp.status_code,
            headers=dict(resp.headers),
            media_type=resp.headers.get("content-type"),
        )
