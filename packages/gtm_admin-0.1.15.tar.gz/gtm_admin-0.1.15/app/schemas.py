"""Shared Pydantic base that serialises to camelCase.

SQLModel table models stay in snake_case internally; only the response/request
schemas exposed to the frontend use camelCase via alias_generator.
"""

from pydantic import BaseModel, ConfigDict


def to_camel(s: str) -> str:
    parts = s.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


class CamelModel(BaseModel):
    """Inheriting from this gives every field a camelCase alias automatically.

    - Responses: pass ``response_model_by_alias=True`` on each route
    - Request bodies: accept both snake_case field names and camelCase aliases
    """
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)
