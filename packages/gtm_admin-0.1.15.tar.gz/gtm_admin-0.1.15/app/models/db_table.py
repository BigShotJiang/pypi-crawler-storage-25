from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import JSON, Column, DateTime
from sqlmodel import Field, SQLModel


class DbTable(SQLModel, table=True):
    __tablename__ = "db_tables"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    name: str
    description: str | None = None
    columns: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))
    rows: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), sa_column=Column(DateTime(timezone=True), nullable=False))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), sa_column=Column(DateTime(timezone=True), nullable=False))
