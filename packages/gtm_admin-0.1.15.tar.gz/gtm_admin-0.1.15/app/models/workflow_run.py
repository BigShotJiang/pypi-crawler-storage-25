from datetime import datetime, timezone
from enum import Enum
from typing import Any
from uuid import UUID, uuid4

from sqlalchemy import JSON, Column, DateTime
from sqlmodel import Field, SQLModel


class WorkflowStatus(str, Enum):
    pending = "pending"
    running = "running"
    success = "success"
    failed = "failed"


class WorkflowRunBase(SQLModel):
    name: str
    status: WorkflowStatus = WorkflowStatus.pending
    triggered_by: str = "manual"
    started_at: datetime | None = None
    finished_at: datetime | None = None


class WorkflowRun(WorkflowRunBase, table=True):
    __tablename__ = "workflow_runs"

    id: UUID = Field(default_factory=uuid4, primary_key=True)
    started_at: datetime | None = Field(default=None, sa_column=Column(DateTime(timezone=True), nullable=True))
    finished_at: datetime | None = Field(default=None, sa_column=Column(DateTime(timezone=True), nullable=True))
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), sa_column=Column(DateTime(timezone=True), nullable=False))
    parent_id: UUID | None = Field(default=None, foreign_key="workflow_runs.id", index=True)
    nodes: list[dict[str, Any]] = Field(default=[], sa_column=Column(JSON))


class WorkflowRunCreate(WorkflowRunBase):
    parent_id: UUID | None = None
    nodes: list[dict[str, Any]] = []


class WorkflowRunUpdate(SQLModel):
    name: str | None = None
    status: WorkflowStatus | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
