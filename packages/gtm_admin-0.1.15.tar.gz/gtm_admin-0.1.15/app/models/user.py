from datetime import datetime, timezone

from sqlalchemy import Column, DateTime
from sqlmodel import Field, SQLModel


class UserBase(SQLModel):
    username: str = Field(primary_key=True)


class User(UserBase, table=True):
    __tablename__ = "users"

    hashed_password: str
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc), sa_column=Column(DateTime(timezone=True), nullable=False))


class UserCreate(UserBase):
    password: str


class UserRead(UserBase):
    created_at: datetime
