from __future__ import annotations

import time
import uuid
import functools

from .database import _SessionLocal
from .models import WorkflowRun


def make_workflow_wrapper(fn):
    @functools.wraps(fn)
    async def wrapper(inputs: dict):
        if _SessionLocal is None:
            raise RuntimeError("Database not initialized. GTMAdmin must be instantiated before calling workflows.")

        run_id = uuid.uuid4()
        started = time.monotonic()
        from datetime import datetime, timezone

        async with _SessionLocal() as session:
            run = WorkflowRun(
                id=run_id,
                workflow=fn.__name__,
                status="running",
                inputs=inputs,
                started_at=datetime.now(timezone.utc),
            )
            session.add(run)
            await session.commit()

        outputs = None
        error = None
        try:
            outputs = await fn(inputs)
            status_val = "success"
        except Exception as exc:
            error = str(exc)
            status_val = "error"
            raise
        finally:
            duration_ms = int((time.monotonic() - started) * 1000)
            from datetime import datetime, timezone

            async with _SessionLocal() as session:
                run = await session.get(WorkflowRun, run_id)
                if run is not None:
                    run.status = status_val
                    run.outputs = outputs
                    run.error = error
                    run.finished_at = datetime.now(timezone.utc)
                    run.duration_ms = duration_ms
                    session.add(run)
                    await session.commit()

        return outputs

    return wrapper
