from __future__ import annotations

from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from .auth import create_access_token, hash_password, verify_password
from .database import get_session
from .deps import get_current_user
from .models import User, WorkflowRun


def create_router(secret: str, workflows: dict) -> APIRouter:
    router = APIRouter()

    # ── Auth ─────────────────────────────────────────────────────────────────

    @router.post("/auth/token", tags=["auth"])
    async def login(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        user = await session.get(User, form.username)
        if not user or not verify_password(form.password, user.hashed_password):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        return {"access_token": create_access_token(user.username), "token_type": "bearer"}

    @router.post("/auth/register", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def register(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        if await session.get(User, form.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        user = User(username=form.username, hashed_password=hash_password(form.password))
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return {"username": user.username}

    # ── Health ────────────────────────────────────────────────────────────────

    @router.get("/health", tags=["system"])
    async def health():
        return {"status": "ok"}

    # ── Workflows ─────────────────────────────────────────────────────────────

    @router.get("/workflows", tags=["workflows"])
    async def list_workflows(_: User = Depends(get_current_user)):
        return [{"name": name, "doc": fn.__doc__} for name, fn in workflows.items()]

    # ── Runs ──────────────────────────────────────────────────────────────────

    @router.get("/runs", tags=["runs"])
    async def list_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        result = await session.exec(select(WorkflowRun).order_by(WorkflowRun.started_at.desc()))
        return result.all()

    @router.get("/runs/{run_id}", tags=["runs"])
    async def get_run(
        run_id: UUID,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, run_id)
        if not run:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Run not found")
        return run

    return router
