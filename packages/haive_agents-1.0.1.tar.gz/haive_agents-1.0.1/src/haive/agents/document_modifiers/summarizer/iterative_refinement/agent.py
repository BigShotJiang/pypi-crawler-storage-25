# Initial summary

from haive.core.engine.agent.agent import Agent, register_agent
from langchain_core.runnables import RunnableConfig
from langgraph.graph import START
from langgraph.types import Command

from haive.agents.document_modifiers.summarizer.iterative_refinement.config import (
    IterativeSummarizerConfig,
)
from haive.agents.document_modifiers.summarizer.iterative_refinement.state import (
    IterativeSummarizerState,
)

# from haive.core.engine.agent.agent import AgentConfig


@register_agent(IterativeSummarizerConfig)
class IterativeSummarizer(Agent[IterativeSummarizerConfig]):
    """An agent that summarizes a document iteratively."""

    def __init__(self, config: IterativeSummarizerConfig = IterativeSummarizerConfig()):
        """Init  .

        Args:
            config: [TODO: Add description]
        """
        super().__init__(config)

    # We define functions for each node, including a node that generates
    # the initial summary:
    async def generate_initial_summary(
        self, state: IterativeSummarizerState, config: RunnableConfig
    ):
        """Generate Initial Summary.

        Args:
            state: [TODO: Add description]
            config: [TODO: Add description]
        """
        summary = await self.engines["initial_summary"].ainvoke(
            state.contents[0], config
        )
        return Command(update={"summary": summary, "index": 1})

    # And a node that refines the summary based on the next document
    async def refine_summary(
        self, state: IterativeSummarizerState, config: RunnableConfig
    ):
        """Refine Summary.

        Args:
            state: [TODO: Add description]
            config: [TODO: Add description]
        """
        content = state.contents[state.index]
        summary = await self.engines["refine_summary"].ainvoke(
            {"existing_answer": state.summary, "context": content}, config
        )

        return Command(update={"summary": summary, "index": state.index + 1})

    def setup_workflow(self) -> None:
        """Setup Workflow.

        Returns:
            [TODO: Add return description]
        """
        self.graph.add_node("generate_initial_summary", self.generate_initial_summary)
        self.graph.add_node("refine_summary", self.refine_summary)

        self.graph.add_edge(START, "generate_initial_summary")
        self.graph.add_conditional_edges(
            "generate_initial_summary", self.state_schema.should_refine
        )
        self.graph.add_conditional_edges(
            "refine_summary", self.state_schema.should_refine
        )
