# ticrobe.datastore

Database gateway package. See the [project README](../../README.md) for full documentation.

## Quick start

```python
from ticrobe.datastore import DataStore

db = DataStore("db.ini")
await db.connect()
await db.create_table({"table_name": "item", "columns": {"id": "SERIAL PRIMARY KEY", "name": "TEXT NOT NULL"}})
item = await db.create({"name": "example"}, returning=("id", "name"))
await db.disconnect()
```
