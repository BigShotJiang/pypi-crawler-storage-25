from __future__ import annotations

import configparser
from dataclasses import dataclass
from pathlib import Path


SUPPORTED_BACKENDS = ("pgsql",)


@dataclass(slots=True)
class StoreConfig:
    backend: str = "pgsql"
    host: str = "localhost"
    port: int = 5432
    database: str = "tX.local"
    schema: str = "public"
    user: str = "postgres"
    password: str = "postgres"
    connect_timeout: int = 10

    @classmethod
    def from_ini(cls, ini_path: str | Path, section: str = "database") -> "StoreConfig":
        path = Path(ini_path)
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")

        parser = configparser.ConfigParser()
        parser.read(path)

        if section not in parser:
            raise KeyError(
                f"Section [{section}] not found in {path}. "
                f"Available sections: {list(parser.sections())}"
            )

        raw = parser[section]
        backend = raw.get("backend", "pgsql").strip().lower()

        if backend not in SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unsupported backend '{backend}'. "
                f"Supported backends: {SUPPORTED_BACKENDS}"
            )

        return cls(
            backend=backend,
            host=raw.get("host", "localhost").strip(),
            port=int(raw.get("port", "5432").strip()),
            database=raw.get("name", "tX.local").strip(),
            schema=raw.get("schema", "public").strip(),
            user=raw.get("user", "postgres").strip(),
            password=raw.get("password", "postgres").strip(),
            connect_timeout=int(raw.get("connect_timeout", "10").strip()),
        )

    def to_pgsql_config(self) -> object:
        from ticrobe.pgsql import DatabaseConfig

        return DatabaseConfig(
            host=self.host,
            port=self.port,
            database=self.database,
            schema=self.schema,
            user=self.user,
            password=self.password,
            connect_timeout=self.connect_timeout,
        )
