from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from .config import StoreConfig


class DataStore:
    """Async database gateway backed by a dynamically loaded INI config.

    Supported backends: pgsql (via ticrobe.pgsql).

    Usage::

        db = DataStore("db.ini")
        await db.connect()
        await db.create_table({...})
        row = await db.create({...}, returning=("id",))
        await db.update(row["id"], {...})
        await db.delete(row["id"])
        await db.disconnect()
    """

    def __init__(self, ini_path: str | Path, *, section: str = "database") -> None:
        self._ini_path = Path(ini_path)
        self._section = section
        self.config: StoreConfig | None = None
        self._backend: Any = None
        self.table_name: str | None = None

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Load config from the INI file and open a connection to the backend."""
        self.config = StoreConfig.from_ini(self._ini_path, section=self._section)
        self._backend = self._init_backend(self.config)
        await self._backend.connect(self.config.to_pgsql_config())

    async def disconnect(self) -> None:
        """Close the active backend connection."""
        if self._backend is not None:
            await self._backend.disconnect()
        self._backend = None

    # ------------------------------------------------------------------
    # Schema operations
    # ------------------------------------------------------------------

    async def create_table(
        self,
        table_config: Mapping[str, Any],
        *,
        if_not_exists: bool = True,
    ) -> None:
        """Create a table from a config dict.

        Args:
            table_config: Dict with ``table_name`` (str) and ``columns``
                (mapping of column_name → SQL type definition).
            if_not_exists: Emit ``IF NOT EXISTS`` guard (default ``True``).

        Example::

            await db.create_table({
                "table_name": "item",
                "columns": {
                    "id": "SERIAL PRIMARY KEY",
                    "name": "VARCHAR(255) NOT NULL",
                },
            })
        """
        backend = self._require_backend()
        await backend.create_table(table_config, if_not_exists=if_not_exists)
        self.table_name = str(table_config["table_name"])

    async def drop_table(self, table_name: str, *, if_exists: bool = True) -> None:
        """Drop a table by name."""
        backend = self._require_backend()
        await backend.drop_table(table_name, if_exists=if_exists)

    # ------------------------------------------------------------------
    # CRUD operations
    # ------------------------------------------------------------------

    async def create(
        self,
        table_row: Mapping[str, Any],
        *,
        table_name: str | None = None,
        returning: Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        """Insert a new row and return it.  Alias for :meth:`insert`.

        Args:
            table_row: Column-value mapping for the new row.
            table_name: Override the active table name.
            returning: Column names to return from the inserted row.

        Returns:
            Dict of returned columns if *returning* is specified, else ``None``.
        """
        return await self.insert(
            table_row,
            table_name=table_name,
            returning=returning,
        )

    async def insert(
        self,
        table_row: Mapping[str, Any],
        *,
        table_name: str | None = None,
        returning: Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        """Insert a row into the active table.

        Args:
            table_row: Column-value mapping for the new row.
            table_name: Override the active table name.
            returning: Column names to return after the insert.

        Returns:
            Dict of returned columns if *returning* is specified, else ``None``.
        """
        backend = self._require_backend()
        resolved = self._resolve_table_name(table_name)
        return await backend.insert(table_row, table_name=resolved, returning=returning)

    async def update(
        self,
        row_id: Any,
        new_table_row: Mapping[str, Any],
        *,
        table_name: str | None = None,
        id_column: str = "id",
        returning: Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        """Update a row identified by *row_id*.

        Args:
            row_id: Value of the identifier column for the row to update.
            new_table_row: Column-value mapping of fields to update.
            table_name: Override the active table name.
            id_column: Name of the identifier column (default ``"id"``).
            returning: Column names to return after the update.

        Returns:
            Dict of returned columns if *returning* is specified, else ``None``.
        """
        backend = self._require_backend()
        resolved = self._resolve_table_name(table_name)
        return await backend.update(
            row_id,
            new_table_row,
            table_name=resolved,
            id_column=id_column,
            returning=returning,
        )

    async def delete(
        self,
        row_id: Any,
        *,
        table_name: str | None = None,
        id_column: str = "id",
        returning: Iterable[str] | None = None,
    ) -> dict[str, Any] | None:
        """Delete a row identified by *row_id*.

        Args:
            row_id: Value of the identifier column for the row to delete.
            table_name: Override the active table name.
            id_column: Name of the identifier column (default ``"id"``).
            returning: Column names to return after the delete.

        Returns:
            Dict of returned columns if *returning* is specified, else ``None``.
        """
        backend = self._require_backend()
        resolved = self._resolve_table_name(table_name)
        return await backend.delete(
            row_id,
            table_name=resolved,
            id_column=id_column,
            returning=returning,
        )

    # ------------------------------------------------------------------
    # Raw query access
    # ------------------------------------------------------------------

    async def fetch_one(
        self,
        query: str,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """Execute a query and return the first row as a dict, or ``None``."""
        backend = self._require_backend()
        return await backend.fetch_one(query, params)

    async def fetch_all(
        self,
        query: str,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        """Execute a query and return all rows as a list of dicts."""
        backend = self._require_backend()
        return await backend.fetch_all(query, params)

    async def execute(
        self,
        query: str,
        params: Sequence[Any] | Mapping[str, Any] | None = None,
        *,
        commit: bool = True,
    ) -> None:
        """Execute a raw SQL statement."""
        backend = self._require_backend()
        await backend.execute(query, params, commit=commit)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _init_backend(self, config: StoreConfig) -> Any:
        if config.backend == "pgsql":
            from ticrobe.pgsql import PostgresDB
            return PostgresDB()
        raise ValueError(f"Unsupported backend: '{config.backend}'")

    def _require_backend(self) -> Any:
        if self._backend is None:
            raise RuntimeError(
                "DataStore is not connected. Call await db.connect() first."
            )
        return self._backend

    def _resolve_table_name(self, table_name: str | None) -> str:
        resolved = table_name or self.table_name
        if not resolved:
            raise ValueError(
                "table_name is required until a table is created via create_table()."
            )
        return resolved
