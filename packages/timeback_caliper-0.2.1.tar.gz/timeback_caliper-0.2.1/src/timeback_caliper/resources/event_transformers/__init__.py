from .base import EventPayloadTransformer
from .lwai import LwaiEventTransformer, transform_for_lwai


def resolve_event_transformer(platform: str | None) -> EventPayloadTransformer | None:
    """Resolve the event transformer to use for a platform."""
    if platform == "LEARNWITH_AI":
        return LwaiEventTransformer()
    return None


__all__ = [
    "EventPayloadTransformer",
    "LwaiEventTransformer",
    "resolve_event_transformer",
    "transform_for_lwai",
]
