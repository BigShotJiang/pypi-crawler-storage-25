"""
Caliper Constants

Caliper-specific constants for the Caliper Analytics client.
"""

# IMS Global Caliper Analytics specification version
CALIPER_DATA_VERSION = "http://purl.imsglobal.org/ctx/caliper/v1p2"

# Score type for individual question results (LWAI GradeEvent)
QUESTION_RESULT_SCORE_TYPE = "QUESTION_RESULT"

__all__ = ["CALIPER_DATA_VERSION", "QUESTION_RESULT_SCORE_TYPE"]
