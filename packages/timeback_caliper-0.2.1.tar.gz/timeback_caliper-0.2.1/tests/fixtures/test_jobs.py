"""Fixture-driven tests for Caliper jobs resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_caliper.lib.testing import create_recording_transport
from timeback_caliper.resources.jobs import JobsResource

FIXTURES_DIR = fixtures_dir("caliper", "jobs")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": JobsResource(transport), "calls": transport.calls}


test_caliper_jobs_fixtures = make_resource_fixture_test(
    name="caliper > jobs",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
    method_configs={
        "waitForCompletion": {
            "options_arg_index": 1,
            "option_args": {
                "timeoutMs": {
                    "target": "timeout",
                    "converter": "milliseconds_to_seconds",
                },
                "pollIntervalMs": {
                    "target": "poll_interval",
                    "converter": "milliseconds_to_seconds",
                },
            },
        }
    },
)
