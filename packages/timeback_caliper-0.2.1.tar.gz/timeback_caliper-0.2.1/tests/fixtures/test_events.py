"""Fixture-driven tests for Caliper events resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_caliper.lib.testing import create_recording_transport
from timeback_caliper.resources.events import EventsResource

FIXTURES_DIR = fixtures_dir("caliper", "events")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": EventsResource(transport), "calls": transport.calls}


test_caliper_events_fixtures = make_resource_fixture_test(
    name="caliper > events",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
