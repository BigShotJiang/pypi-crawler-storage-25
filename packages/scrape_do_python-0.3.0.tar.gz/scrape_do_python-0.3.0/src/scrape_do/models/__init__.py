"""Public API for the data models and Scrape.do API contracts

Aggregates domain models into a unified namespace to expose all necessary type
hints, browser actions, and configuration contracts required to interact with
the API.
"""

from __future__ import annotations

from .browser_actions import (
    ClickAction,
    WaitAction,
    WaitSelectorAction,
    ScrollXAction,
    ScrollYAction,
    ScrollToAction,
    FillAction,
    ExecuteAction,
    ScreenShotAction,
    WaitForRequestCompletionAction,
    BrowserAction
    )
from .enums import (
    RegionCodeType,
    WaitUntilType,
    DeviceType,
    OutputType,
    HttpMethod,
    PayloadType
    )
from .request import (
    PreparedScrapeDoRequest
)
from .parameters import (
    RequestParameters,
    RequestParametersDict
)
from .response import (
    ScrapeDoNetworkRequest,
    ScrapeDoWebSocketFrame,
    ScrapeDoWebSocketEvent,
    ScrapeDoWebsocketRequest,
    ScrapeDoActionResult,
    ScrapeDoScreenshot,
    ScrapeDoFrame,
    ScrapeDoResponse
    )
from .validators import (
    check_geo_code,
    check_geo_exclusion,
    check_header_mutual_exclusion,
    check_headers_vs_set_cookies,
    check_play_with_browser_vs_particular_screenshot,
    check_postal_code,
    check_regional_requires_super,
    check_render_dependencies,
    check_retry_timeout_vs_render,
    check_return_json_dependencies,
    check_screenshot_blocks_resources,
    check_screenshot_mutual_exclusion,
    )


__all__ = [
    "ClickAction",
    "WaitAction",
    "WaitSelectorAction",
    "ScrollXAction",
    "ScrollYAction",
    "ScrollToAction",
    "FillAction",
    "ExecuteAction",
    "ScreenShotAction",
    "WaitForRequestCompletionAction",
    "BrowserAction",
    "RegionCodeType",
    "WaitUntilType",
    "DeviceType",
    "OutputType",
    "HttpMethod",
    "PayloadType",
    "RequestParametersDict",
    "RequestParameters",
    "PreparedScrapeDoRequest",
    "ScrapeDoNetworkRequest",
    "ScrapeDoWebSocketFrame",
    "ScrapeDoWebSocketEvent",
    "ScrapeDoWebsocketRequest",
    "ScrapeDoActionResult",
    "ScrapeDoScreenshot",
    "ScrapeDoFrame",
    "ScrapeDoResponse",
    "check_geo_code",
    "check_geo_exclusion",
    "check_header_mutual_exclusion",
    "check_headers_vs_set_cookies",
    "check_play_with_browser_vs_particular_screenshot",
    "check_postal_code",
    "check_regional_requires_super",
    "check_render_dependencies",
    "check_retry_timeout_vs_render",
    "check_return_json_dependencies",
    "check_screenshot_blocks_resources",
    "check_screenshot_mutual_exclusion",
    ]
