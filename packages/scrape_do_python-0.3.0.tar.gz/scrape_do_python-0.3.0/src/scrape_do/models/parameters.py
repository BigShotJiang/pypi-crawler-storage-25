"""Core validation engine and configuration contracts.

Validates request data before the network layer to ensure that invalid
configurations are caught locally without wasting network requests by using
Pydantic V2 models to enforce Scrape.do's parameter dependencies and
interactions
"""

from __future__ import annotations
import json
import urllib.parse
import warnings
from typing import (
    Optional,
    List,
    Type,
    Any,
    Dict,
    TypedDict
    )
from typing_extensions import Self
from pydantic import (
    BaseModel,
    Field,
    HttpUrl,
    model_validator,
    field_validator,
    ValidationInfo,
    ConfigDict
    )
from .browser_actions import BrowserAction
from .enums import (
    OutputType,
    DeviceType,
    WaitUntilType,
    RegionCodeType
    )
from .validators import (
    _truthy_field_names,
    check_geo_code,
    check_geo_exclusion,
    check_header_mutual_exclusion,
    check_headers_vs_set_cookies,
    check_play_with_browser_vs_particular_screenshot,
    check_postal_code,
    check_regional_requires_super,
    check_render_dependencies,
    check_retry_timeout_vs_render,
    check_return_json_dependencies,
    check_screenshot_blocks_resources,
    check_screenshot_mutual_exclusion,
    )


# ----------------------------------
# RequestParameters Kwargs TypedDict
# ----------------------------------

class RequestParametersDict(TypedDict, total=False):
    """
    Provides strict IDE autocomplete and static type checking for `**kwargs`
    dictionaries meant for the
    [RequestParameters][scrape_do.models.RequestParameters] model.
    """
    super: Optional[bool]
    """
    Activates Residential/Mobile IP proxies.
    """
    render: Optional[bool]
    """
    Executes the request using a headless browser.
    """
    device: Optional[DeviceType]
    """
    Specify the device type (desktop, mobile, tablet)
    """
    session_id: Optional[int]
    """
    Use the same IP address continuously with a session
    """
    geo_code: Optional[str]
    """
    ISO 3166-1 alpha-2 country code for IP targeting.
    """
    regional_geo_code: Optional[RegionCodeType]
    """
    Targets a broader geographical region. Requires super=True.
    """
    postal_code: Optional[str]
    """
    Targets a specific zip code. Requires super=True and a supported geo_code.
    """
    wait_until: Optional[WaitUntilType]
    """
    Control when the browser considers the page loaded
    """
    custom_wait: Optional[int]
    """
    Set the browser wait time on the target web page after content loaded
    """
    wait_selector: Optional[str]
    """
    CSS selector to wait for in the target web page.
    """
    width: Optional[int]
    """
    Custom viewport width.
    """
    height: Optional[int]
    """
    Custom viewport height.
    """
    return_json: Optional[bool]
    """
    Returns response body as base64-encoded JSON instead of raw HTML.
    """
    block_resources: Optional[bool]
    """
    Block CSS, images, and fonts on your target web page
    """
    screenshot: Optional[bool]
    """
    Captures the visible viewport.
    """
    full_screenshot: Optional[bool]
    """
    Captures the entire scrollable page.
    """
    particular_screenshot: Optional[str]
    """
    Captures a specific DOM element by selector.
    """
    play_with_browser: Optional[List[BrowserAction]]
    """
    A sequence of automated interactions to perform.
    """
    show_frames: Optional[bool]
    """
    Returns all iframe content from the target webpage. Requires render=true
    and returnJSON=true
    """
    show_websocket_requests: Optional[bool]
    """
    Captures WebSocket network traffic. Requires render=true and
    returnJSON=true.
    """
    custom_headers: Optional[bool]
    """
    Replaces Scrape.do's default headers with your provided headers.
    """
    extra_headers: Optional[bool]
    """
    Appends your provided headers to Scrape.do's default headers.
    """
    forward_headers: Optional[bool]
    """
    Forwards all headers exactly as sent by your client.
    """
    set_cookies: Optional[str]
    """
    Injects specific cookies into the request.
    """
    disable_redirection: Optional[bool]
    """
    Prevents the proxy from following 3xx HTTP redirects.
    """
    timeout: Optional[int]
    """
    Total API connection timeout in milliseconds.
    """
    retry_timeout: Optional[int]
    """
    Internal proxy retry duration in milliseconds. Cannot be used with
    render=True.
    """
    disable_retry: Optional[bool]
    """
    Fails immediately on target error without rotating IPs.
    """
    output: Optional[OutputType]
    """
    Output format parser.
    """
    transparent_response: Optional[bool]
    """
    Return pure response from target web page without Scrape.do processing
    """
    pure_cookies: Optional[bool]
    """
    Returns the original Set-Cookie headers from the target website
    """


# --------------------
# Request Parameters
# --------------------

class RequestParameters(BaseModel):
    """The strict data contract for the request parameters accepted by
    Scrape.do's API.

    This model enforces all parameter dependencies, mutually exclusive rules,
    and geographical targeting constraints locally before a network request
    is generated.

    Attributes:
        url (HttpUrl): The absolute destination URL you wish to scrape.
        super (Optional[bool]): Activates Residential/Mobile IP proxies.
        render (Optional[bool]): Executes the request using a headless browser.
        device (Optional[DeviceType]): Specify the device type (desktop,
            mobile, tablet)
        session_id (Optional[int]): Use the same IP address continuously with
            a session
        geo_code (Optional[str]): ISO 3166-1 alpha-2 country code for IP
            targeting.
        regional_geo_code (Optional[RegionCodeType]): Targets a broader
            geographical region. Requires super=True.
        postal_code (Optional[str]): Targets a specific zip code. Requires
            super=True and a supported geo_code.
        wait_until (Optional[WaitUntilType]): Control when the browser
            considers the page loaded
        custom_wait (Optional[int]): Set the browser wait time on the target
            web page after content loaded
        wait_selector (Optional[str]): CSS selector to wait for in the target
            web page.
        width (Optional[int]): Custom viewport width.
        height (Optional[int]): Custom viewport height.
        return_json (Optional[bool]): Returns response body as base64-encoded
            JSON instead of raw HTML.
        block_resources (Optional[bool]): Block CSS, images, and fonts on your
            target web page
        screenshot (Optional[bool]): Captures the visible viewport.
        full_screenshot (Optional[bool]): Captures the entire scrollable page.
        particular_screenshot (Optional[str]): Captures a specific DOM element
            by selector.
        play_with_browser (Optional[List[BrowserAction]]): A sequence of
            automated interactions to perform.
        show_frames (Optional[bool]): Returns all iframe content from the
            target webpage. Requires render=true and returnJSON=true
        show_websocket_requests (Optional[bool]): Captures WebSocket network
            traffic. Requires render=true and returnJSON=true.
        custom_headers (Optional[bool]): Replaces Scrape.do's default headers
            with your provided headers.
        extra_headers (Optional[bool]): Appends your provided headers to
            Scrape.do's default headers.
        forward_headers (Optional[bool]): Forwards all headers exactly as sent
            by your client.
        set_cookies (Optional[str]): Injects specific cookies into the request.
        disable_redirection (Optional[bool]): Prevents the proxy from
            following 3xx HTTP redirects.
        timeout (Optional[int]): Total API connection timeout in milliseconds.
        retry_timeout (Optional[int]): Internal proxy retry duration in
            milliseconds. Cannot be used with render=True.
        disable_retry (Optional[bool]): Fails immediately on target error
            without rotating IPs.
        output (Optional[OutputType]): Output format parser.
        transparent_response (Optional[bool]): Return pure response from
            target web page without Scrape.do processing
        pure_cookies (Optional[bool]): Returns the original Set-Cookie headers
            from the target website
    """
    model_config = ConfigDict(
        populate_by_name=True
        )

    # --- Required Parameters ---

    url: HttpUrl = Field(
        ...,
        alias="url"
        )

    # --- Core Routing Parameters ---

    super: Optional[bool] = Field(
        default=None,
        alias="super"
        )

    render: Optional[bool] = Field(
        None,
        alias="render"
        )

    device: Optional[DeviceType] = Field(
        None,
        alias="device"
        )

    session_id: Optional[int] = Field(
        None,
        alias="sessionId",
        ge=0,
        le=1000000
        )

    # --- Location Parameters ---

    geo_code: Optional[str] = Field(
        None,
        alias="geoCode",
        min_length=2,
        max_length=2,
        validate_default=True
        )

    regional_geo_code: Optional[RegionCodeType] = Field(
        None,
        alias="regionalGeoCode"
        )

    postal_code: Optional[str] = Field(
        None,
        alias="postalcode",
        validate_default=True
    )

    # --- Browser Parameters ---

    wait_until: Optional[WaitUntilType] = Field(
        None,
        alias="waitUntil"
        )

    custom_wait: Optional[int] = Field(
        None,
        alias="customWait",
        ge=0,
        le=35000
        )

    wait_selector: Optional[str] = Field(
        None,
        alias="waitSelector"
        )

    width: Optional[int] = Field(
        None,
        alias="width"
        )

    height: Optional[int] = Field(
        None,
        alias="height"
        )

    return_json: Optional[bool] = Field(
        None,
        alias="returnJSON"
        )

    block_resources: Optional[bool] = Field(
        None,
        alias="blockResources"
        )

    screenshot: Optional[bool] = Field(
        None,
        alias="screenShot"
        )

    full_screenshot: Optional[bool] = Field(
        None,
        alias="fullScreenShot"
        )

    particular_screenshot: Optional[str] = Field(
        None,
        alias="particularScreenShot"
        )

    play_with_browser: Optional[List[BrowserAction]] = Field(
        None,
        alias="playWithBrowser"
        )

    # --- Browser Response Configuration Parameters ---

    show_frames: Optional[bool] = Field(
        None,
        alias="showFrames"
        )

    show_websocket_requests: Optional[bool] = Field(
        None,
        alias="showWebsocketRequests"
    )

    # --- Header + Cookie Control Parameters ---

    custom_headers: Optional[bool] = Field(
        None,
        alias="customHeaders"
        )

    extra_headers: Optional[bool] = Field(
        None,
        alias="extraHeaders"
        )

    forward_headers: Optional[bool] = Field(
        None,
        alias="forwardHeaders"
        )

    set_cookies: Optional[str] = Field(
        None,
        alias="setCookies"
        )

    # --- Network Parameters ---

    disable_redirection: Optional[bool] = Field(
        None,
        alias="disableRedirection"
        )

    timeout: Optional[int] = Field(
        None,
        alias="timeout",
        le=120000,
        ge=5000
        )

    retry_timeout: Optional[int] = Field(
        None,
        alias="retryTimeout",
        le=55000,
        ge=5000
        )

    disable_retry: Optional[bool] = Field(
        None,
        alias="disableRetry"
        )

    # --- General Response Configuration Parameters ---

    output: Optional[OutputType] = Field(
        None,
        alias="output"
        )

    transparent_response: Optional[bool] = Field(
        None,
        alias="transparentResponse"
        )

    pure_cookies: Optional[bool] = Field(
        None,
        alias="pureCookies"
        )

    @model_validator(mode="after")
    def validate_compatibility(self) -> Self:
        """Cross-validates parameter dependencies to prevent invalid API
        requests locally.

        info: Headless Browser Dependencies (`render=True`)
            - `wait_until`
            - `wait_selector`
            - `custom_wait`
            - `width`
            - `height`
            - `return_json`
            - `block_resources`
            - `screenshot`
            - `full_screenshot`
            - `particular_screenshot`
            - `play_with_browser`
            - `show_frames`
            - `show_websocket_requests`

        info: ReturnJSON Dependencies (`render=True` + `return_json=True`)
            - `screenshot`
            - `full_screenshot`
            - `particular_screenshot`
            - `show_frames`
            - `show_websocket_requests`

        info: Super Proxy Dependencies (`super=True`)
            - `regional_geo_code`

        info: Screenshot Parameters
             - Only one of the screenshot parameters can be set at a time.

             - In addition to `render=True` and `return_json=True`, all
                screenshot parameters require `blockResources` to be set to
                False.

        info: Header Parameters
            - Only one of the header parameters can be set at a time.

            - None of the header parameters can be set to True when using the
               `setCookies` parameter

        info: Mutually Exclusive Parameters
            - The `playWithBrowser` and `particular_screenshot` parameters
                cannot be used simultaneously

            - The `retryTimeout` and `render` parameters cannot be used
                simultaneously

            - The `regional_geo_code` and `geo_code` parameters cannot be used
                simultaneously

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If mutually exclusive parameters are combined or if
                dependent parameters are provided without their required
                prerequisites.
        """

        # --- Headless Browser Dependencies ---

        check_render_dependencies(
            self.render,
            {
                "wait_until": self.wait_until,
                "custom_wait": self.custom_wait,
                "wait_selector": self.wait_selector,
                "width": self.width,
                "height": self.height,
                "return_json": self.return_json,
                "block_resources": self.block_resources,
                "screenshot": self.screenshot,
                "full_screenshot": self.full_screenshot,
                "particular_screenshot": self.particular_screenshot,
                "play_with_browser": self.play_with_browser,
                "show_frames": self.show_frames,
                "show_websocket_requests": self.show_websocket_requests,
                },
            )

        check_return_json_dependencies(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            self.show_frames,
            self.show_websocket_requests,
            self.return_json,
            )

        check_screenshot_blocks_resources(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            self.block_resources,
            )

        # --- Enforce Mutually Exclusive Parameters ---

        check_retry_timeout_vs_render(self.render, self.retry_timeout)

        check_screenshot_mutual_exclusion(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            )

        check_play_with_browser_vs_particular_screenshot(
            self.play_with_browser,
            self.particular_screenshot,
            )

        check_header_mutual_exclusion(
            self.custom_headers,
            self.extra_headers,
            self.forward_headers,
            )

        used_header_fields = _truthy_field_names({
            "custom_headers": self.custom_headers,
            "extra_headers": self.extra_headers,
            "forward_headers": self.forward_headers,
            })
        check_headers_vs_set_cookies(used_header_fields, self.set_cookies)

        check_geo_exclusion(self.geo_code, self.regional_geo_code)

        check_regional_requires_super(
            bool(self.super),
            self.regional_geo_code,
            )

        return self

    @field_validator("geo_code")
    @classmethod
    def validate_geo_code(
        cls: Type[Self],
        v: Optional[str],
        info: ValidationInfo
    ) -> Optional[str]:
        """Validates the country code against the allowed proxy pools.

        Delegates to
        [`check_geo_code`][scrape_do.models.validators.check_geo_code].

        Args:
            v (Optional[str]): The `geo_code` provided during initialization
            info (ValidationInfo): The data already validated for the model so
                far

        Returns:
            The validated (lowercased) `geo_code` parameter

        Raises:
            ValueError: If the country code is not supported by the selected
                proxy tier.
        """
        return check_geo_code(v, super_set=info.data.get("super", False))

    @field_validator("postal_code")
    @classmethod
    def validate_postal_code(
        cls: Type[Self],
        v: Optional[str],
        info: ValidationInfo
    ) -> Optional[str]:
        """Validates postal codes based on specific regional formats.

        Delegates to
        [`check_postal_code`][scrape_do.models.validators.check_postal_code].

        Args:
            v (Optional[str]): The `postal_code` provided during initialization
            info (ValidationInfo): The data already validated for the model so
                far

        Returns:
            The validated `postal_code` parameter

        Raises:
            ValueError: If dependencies are missing or the format does not
                match the regional regex.
        """
        return check_postal_code(
            v,
            super_set=info.data.get("super", False),
            geo_code=info.data.get("geo_code"),
            )

    def to_api_params(self) -> Dict[str, Any]:
        """Serializes the model into a dictionary formatted for httpx
        query parameters.

        This method automatically drops unassigned fields, maps snake_case
        variables to their camelCase API equivalents, and stringifies nested
        JSON objects as required by Scrape.do.

        Returns:
            A sanitized dictionary ready to be passed to httpx.
        """

        params = self.model_dump(
            by_alias=True,
            exclude_none=True,
            mode="json"
            )

        for key, value in params.items():

            # Serialize playWithBrowserActions
            if key == "playWithBrowser" and self.play_with_browser:
                actions = []
                for action in self.play_with_browser:
                    a_dict = action.model_dump(
                        by_alias=True,
                        exclude_none=True,
                        mode="json"
                        )

                    # Scrape.do's backend expects string booleans
                    for k, v in a_dict.items():
                        if isinstance(v, bool):
                            a_dict[k] = "true" if v else "false"

                    actions.append(a_dict)

                params[key] = json.dumps(actions)

            if isinstance(value, bool):
                params[key] = "true" if value else "false"

        return params

    @classmethod
    def from_url(cls: type[Self], api_url: str) -> RequestParameters:
        """Instantiates a `RequestParameters` instance by parsing a raw
        Scrape.do API URL string.

        tip: Accepted URLs
            This method accepts both raw and encoded URLs by using
            the `urllib.parse.parse_qs` and `urllib.parse.unquote_plus`
            functions to normalize encoded URLs.

        warning: Browser Actions (`playWithBrowser`)
            When providing a URL containing the `playWithBrowser` parameter,
            make sure to use the `json.dumps` function to stringify the list
            of dictionaries containing the entries. Both the raw and ecoded
            URLs can be passed to this method afterwards.

        warning: API Token
            This method ignores the `&token=` parameter containing the
            Scrape.do API key, since its insertion is meant to be handled by
            the `ScrapeDoClient` using either an initialization parameter, or
            the `SCRAPE_DO_API_KEY` environment variable.

        Args:
            api_url (str): The full Scrape.do endpoint
                (`https://api.scrape.do/?url=...&render=true...`)

        Raises:
            ValueError: If the value found in the `&playWithBrowser=` parameter
                is not a parsable JSON string.

        Returns:
            The `RequestParameters` instance mapping the URL parameters
                (`&render=true&...`) to validated attributes
        """

        parsed = urllib.parse.urlparse(api_url)
        query_params = urllib.parse.parse_qs(parsed.query)
        # Type parsed params as Dict[str, Any] and let Pydantic raise a
        # ValidationError if it can't coerce a specific value
        flat_params: Dict[str, Any] = {
            k: v[0] for k, v in query_params.items()
            }

        # Reconstruct the nested JSON actions if they exist
        if "playWithBrowser" in flat_params:
            try:
                # Manually convert '+' to ' ' specifically for this JSON string
                decoded = urllib.parse.unquote_plus(
                    flat_params["playWithBrowser"]
                    )

                flat_params["playWithBrowser"] = json.loads(decoded)

            except json.JSONDecodeError as e:
                raise ValueError(
                    f"Failed to decode `playWithBrowser` parameter from URL | "
                    f"Parameter Value : {flat_params['playWithBrowser']}"
                    ) from e

        # Strip Token
        flat_params.pop("token", None)

        return cls(**flat_params)

    def validate_proxy_params(self) -> Self:
        """
        Cross-validates specific `Proxy Mode` parameter dependencies to
        prevent invalid proxy configurations from being set.

        tip: Intended Usage
            Since `Scrape.do's Proxy Mode` has a few configuration quirks,
            this method can be called on an already validated
            `RequestParameters` instance to ensure that the current parameter
            configuration is also valid when using it.

        info: Proxy Mode Additional Validation
            - `Proxy Mode` can be used with `customHeaders=false`, but unlike
              when using the API, it automatically sets this parameter to
              `true` if no value is provided. Therefore, setting either
              `forwardHeaders=true`, or `extra_headers=true` without
              explicitly setting `customHeaders=false` would result in a
              configuration error where more than one header parameter is
              provided.

            - Additionally, the `customHeaders` parameter must be explicitly
              set to `false` when `setCookies=true`.  Not doing so would
              result in a configuration error where `customHeaders` and
              `setCookies` are used simultaneously.

            - Apart from these, all other parameter validations are
              already ensured by the `validate_compatibility` model validator

        warning: `render=True`
            When using `Proxy Mode` with browser-automation tools, Scrape.do
            does not recommend setting `render=true`, so in this case, this
            method emits a `UserWarning`.

        Raises:
            ValueError: If any of the `Proxy Mode` additional constraints are
                violated

        Returns:
            The validated instance from which the method was called
        """

        # Warn render=true
        if self.render:
            warnings.warn(
                ("If you are using your own browser automation via Proxy Mode,"
                 " Scrape.do does not recommend using Headless Browser "
                 "features (it would be more accurate to set render=false)."
                 ),
                UserWarning
                )

        # customHeaders is explicitly set to False
        if self.custom_headers is not None and not self.custom_headers:
            return self

        # From now on, customHeaders is either not set, or set to True
        # So if either `if` statement evaluates to `True`, `customHeaders`
        # must be `None`, or else validate_compatibility would have raised
        if self.set_cookies:
            raise ValueError(
                ("The `setCookies` parameters can't be used "
                 "simultaneously with any of the header parameters. The"
                 " `customHeaders` parameters defaults to `True` in  "
                 "`Proxy Mode`, so `customHeaders=false` must be explicitly "
                 "set"
                 )
                )

        if self.extra_headers or self.forward_headers:
            raise ValueError((
                "Proxy Mode uses `customHeaders=true` by default."
                " Please set `customHeaders=false` explicitly to use other "
                "header parameters"
                ))

        return self

    def to_proxy_url(self) -> str:
        """
        Generates a `Scrape.do` Proxy connection string template.

        abstract: Proxy Mode
            Since `Scrape.do's Proxy Mode` accepts API parameters as the proxy
            `password`, this method serializes the current configuration into
            a valid connection string template that can later be formatted with
            a valid API token.

        tip: Intended Usage
            - The `Proxy Clients` use this method to generate the proxy
              connection URL

            - It can also be used to construct `Proxy Mode` URLs for
              browser automation libraries like `Playwright` or `Selenium`
              while still benefiting from the strict validation provided by
              the `RequestParameters` model.

        tip: Formatting The Result
            To turn the resulting template into a valid `Proxy Mode` URL, it
            needs to be formatted with a `Scrape.do` API, for example
            ```py
            url = RequestParameters().to_proxy_url().format(api_token="TOKEN")
            ```

        warning: Proxy Mode Validation
            This method calls `validate_proxy_params` to ensure
            that a misconfigured `Proxy Mode` URL is not generated


        Raises:
            ValueError: If any of the `Proxy Mode` additional constraints are
                violated

        Returns:
            A string template formatted as:
                `http://{api_token}:<params>@proxy.scrape.do:8080`
        """

        # Validate parameters
        self.validate_proxy_params()

        # Serialize params reusing the API URL logic
        api_params = self.to_api_params()

        # Strip `url` from parameters
        api_params.pop("url", None)

        # Double-encode the param string. httpx transparently URL-decodes
        # the proxy password before placing it in the Basic auth header,
        # so values with URL-reserved characters (e.g. the JSON-string
        # `playWithBrowser` value) would arrive at Scrape.do unencoded
        # and get re-parsed as a fragmented query string. The outer
        # `quote(..., safe="=&")` preserves the key=value&key=value
        # framing while escaping `%` (and any other special chars urlencode
        # produced) so httpx's single decode round-trips back to the
        # canonical single-encoded form Scrape.do expects.
        param_string = urllib.parse.quote(
            urllib.parse.urlencode(api_params),
            safe="=&",
            )

        return f"http://{{api_token}}:{param_string}@proxy.scrape.do:8080"
