"""Reusable validation helpers for Scrape.do parameter contracts

This module exposes the cross-field and field-level rules enforced by
[`RequestParameters`][scrape_do.models.RequestParameters] as pure
functions so they can be reused by other parameter models without inheriting
from `RequestParameters` itself

abstract: Design Notes
    - Every helper is a free function

    - Callers pass in exactly the values each rule needs

    - Helpers either return the validated value on success or
      `raise ValueError` with a message on rule violation
"""

from __future__ import annotations

from typing import (
    Any,
    Dict,
    List,
    Optional,
    Sequence
    )

from ..constants import (
    _DATACENTER_SUPPORTED_COUNTRIES,
    _SUPER_SUPPORTED_COUNTRIES,
    _ZIPCODE_FORMATS,
    )

from .browser_actions import BrowserAction
from .enums import RegionCodeType


# --------------------------------------------------------------------
# Private Helpers
# --------------------------------------------------------------------


def _truthy_field_names(fields: Dict[str, Any]) -> List[str]:
    """Returns the names of every entry in `fields` whose value is
    neither `None` nor `False` (truthy)

    info: Usage
        Used to treat both `None` and `False` as `not set` when checking
        mutually-exclusive boolean/string parameters

    Args:
        fields (Dict[str, Any]): Dictionary of field names and their values

    Returns:
        List of existing keys in `fields` where the `value` is not `None` or
            `False`
    """
    return [name for name, value in fields.items() if value]


def _non_none_field_names(fields: Dict[str, Any]) -> List[str]:
    """Returns the names of every entry in `fields` whose value is not
    `None`

    info: Usage
        Used for render-dependency checks where `False` and `0` count as
        `field is set`, since the user provided an explicit value

    Args:
        fields (Dict[str, Any]): Dictionary of field names and their values

    Returns:
        List of existing keys in `fields` that have non-none values
    """
    return [name for name, value in fields.items() if value is not None]


def check_geo_code(
    value: Optional[str],
    *,
    super_set: bool,
) -> Optional[str]:
    """Normalizes and validates an ISO 3166-1 alpha-2 country code against
    the different sets of countries allowed by `Scrape.do` when `super=True`
    and when `super=False`

    Lowercases the input and checks it against
    [`_SUPER_SUPPORTED_COUNTRIES`][scrape_do.constants] or
    [`_DATACENTER_SUPPORTED_COUNTRIES`][scrape_do.constants] depending
    on the value of `super_set`

    Args:
        value (Optional[str]): Raw `geo_code` (any case). `None`
            short-circuits the check and is returned unchanged

        super_set (bool): Whether `super=True` was provided alongside
            this `geo_code`

    Returns:
        The lowercased `geo_code` on success, or `None` if `value`
            was `None`

    Raises:
        ValueError: If the country code is not supported by the
            selected proxy tier. The message distinguishes between
            `not supported at all` and `supported only on super`
    """
    if value is None:
        return value

    value = value.lower()
    if super_set:
        if value not in _SUPER_SUPPORTED_COUNTRIES:
            raise ValueError(
                f"'{value}' is not a supported country code"
                )
    else:
        if value not in _DATACENTER_SUPPORTED_COUNTRIES:
            if value in _SUPER_SUPPORTED_COUNTRIES:
                raise ValueError(
                    f"'{value}' is not a supported country code when"
                    f" 'super=false'"
                    )
            else:
                raise ValueError(
                    f"'{value}' is not a supported country code"
                    )
    return value


def check_postal_code(
    value: Optional[str],
    *,
    super_set: bool,
    geo_code: Optional[str],
) -> Optional[str]:
    """Validates a postal code against the list of countries supported by
    `Scrape.do` for this parameter. In addition, it uses regex to check if the
    provided value matches the valid postal code format of that country

    info: Validation Logic
        - Postal-code targeting requires both `super=True` AND a previously
          validated `geo_code` that belongs to
          [`_ZIPCODE_FORMATS`][scrape_do.constants]

        - The value is stripped of surrounding whitespace before format
          matching

    Args:
        value (Optional[str]): Raw `postal_code`. `None`
            short-circuits the check and is returned unchanged

        super_set (bool): Whether `super=True` was provided alongside
            this `postal_code`

        geo_code (Optional[str]): The (already-validated) ISO
            3166-1 alpha-2 country code accompanying this request

    Returns:
        The stripped `postal_code` on success, or `None` if `value`
            was `None`

    Raises:
        ValueError: If `super=False`, if `geo_code` is missing, if the
            country has no zip-code format defined, or if the format
            regex does not match
    """
    if value is None:
        return value

    value = value.strip()

    if not super_set or not geo_code:
        raise ValueError(
            "The 'postalcode' parameter can only be used when both "
            "'super=true' and a valid 'geoCode' are provided."
            )

    if geo_code not in _ZIPCODE_FORMATS:
        raise ValueError(
            f"Zip code targeting is not supported for country"
            f" '{geo_code}'. "
            f" Supported countries are:"
            f" {', '.join(_ZIPCODE_FORMATS.keys())}."
            )

    regex = _ZIPCODE_FORMATS[geo_code]
    if not regex.match(value):
        raise ValueError(
            f"Invalid zip code format for {geo_code}. "
            f"Provided '{value}' does not match the required pattern."
            )

    return value


def check_geo_exclusion(
    geo_code: Optional[str],
    regional_geo_code: Optional[RegionCodeType],
) -> None:
    """Enforces mutual exclusivity between `geo_code` and
    `regional_geo_code`

    info: Logic Behind Validation
        `Scrape.do's gateway` rejects requests that specify both a country
        code and a regional code at the same time

    Args:
        geo_code (Optional[str]): The ISO 3166-1 alpha-2 country code
            on this request, or `None`

        regional_geo_code (Optional[RegionCodeType]): The
            [`RegionCodeType`][scrape_do.models.RegionCodeType] value on
            this request, or `None`

    Raises:
        ValueError: If both arguments are non-`None`
    """
    if geo_code is not None and regional_geo_code is not None:
        raise ValueError(
            "'geoCode' and 'regionalGeoCode' parameters cannot be used"
            " simultaneously"
            )


def check_regional_requires_super(
    super_set: bool,
    regional_geo_code: Optional[Any],
) -> None:
    """Enforces the `regional_geo_code` and `super=True` dependency

    info: Logic Behind Validation
        `Scrape.do` only routes regional codes through the premium proxy
        pool, so `super` must be explicitly enabled when a regional code
        is supplied

    Args:
        super_set (bool): Whether `super=True` was provided

        regional_geo_code (Optional[Any]): The
            [`RegionCodeType`][scrape_do.models.RegionCodeType] value on
            this request, or `None`

    Raises:
        ValueError: If `regional_geo_code` is set while `super=False`
    """
    if not super_set and regional_geo_code is not None:
        raise ValueError(
            "'super=true' must be set to use the 'regionalGeoCode'"
            " parameter"
            )


def check_screenshot_mutual_exclusion(
    screenshot: Optional[bool],
    full_screenshot: Optional[bool],
    particular_screenshot: Optional[str],
) -> None:
    """Enforces that at most one of the three screenshot parameters is
    set per request

    info: Logic Behind Validation
        `Scrape.do` doesn't allow setting more than one screenshot parameter
        per request

    tip: Multiple Screenshots
        To get multiple screenshot per requests, you can use the
        `play_with_browser` parameter to provide a list containing
        [`ScreenShotAction`][scrape_do.models.browser_actions.ScreenShotAction]
        objects

    Args:
        screenshot (Optional[bool]): `True` to capture the visible
            viewport

        full_screenshot (Optional[bool]): `True` to capture the entire
            scrollable page

        particular_screenshot (Optional[str]): CSS selector targeting
            a specific element to screenshot

    Raises:
        ValueError: If more than one of the three is truthy
    """
    used = _truthy_field_names({
        "screenshot": screenshot,
        "full_screenshot": full_screenshot,
        "particular_screenshot": particular_screenshot,
        })

    if len(used) > 1:
        raise ValueError(
            f"Only one screenshot parameter can be used at a time."
            f" Screenshot Parameters used:"
            f" {', '.join(used)}"
            )


def check_screenshot_blocks_resources(
    screenshot: Optional[bool],
    full_screenshot: Optional[bool],
    particular_screenshot: Optional[str],
    block_resources: Optional[bool],
) -> None:
    """Enforces that screenshots run with `block_resources=False`

    info: Logic Beghind Validation
        - Any active screenshot parameter requires that resource blocking be
          disabled so that images, CSS, and fonts are actually loaded before
          capture

        - Combining a screenshot with `block_resources=True` might
          yield an empty/partially-rendered image, so `Scrape.do` automatically
          sets it to `False` regardless of the value sent for the parameter

    Args:
        screenshot (Optional[bool]): Visible-viewport screenshot flag

        full_screenshot (Optional[bool]): Full-page screenshot flag

        particular_screenshot (Optional[str]): Element-selector
            screenshot

        block_resources (Optional[bool]): `True` to block CSS / images
            / fonts

    Raises:
        ValueError: If any screenshot parameter is truthy while
            `block_resources` is also `True`
    """
    used = _truthy_field_names({
        "screenshot": screenshot,
        "full_screenshot": full_screenshot,
        "particular_screenshot": particular_screenshot,
        })

    if used and block_resources:
        raise ValueError(
            f"Screenshot parameters automatically operate with "
            f"'blockResources=false' to ensure contents are loaded "
            f"correctly. Screenshot Parameters used:"
            f" {', '.join(used)}"
            )


def check_return_json_dependencies(
    screenshot: Optional[bool],
    full_screenshot: Optional[bool],
    particular_screenshot: Optional[str],
    show_frames: Optional[bool],
    show_websocket_requests: Optional[bool],
    return_json: Optional[bool],
) -> None:
    """Enforces the `return_json=True` dependency for response-only
    artifacts

    info: Logic Behind Validation
        `Screenshots`, `iframe content`, and `websocket traces` are delivered
        inside the structured JSON envelope, so they require both `render=True`
        AND `return_json=True`

    warning: Render Dependencies
        - The render-side requirement is enforced separately by
          [`check_render_dependencies`][scrape_do.models.validators.check_render_dependencies]

        - This helper only enforces the JSON-envelope side

    Args:
        screenshot (Optional[bool]): Visible-viewport screenshot flag

        full_screenshot (Optional[bool]): Full-page screenshot flag

        particular_screenshot (Optional[str]): Element-selector
            screenshot

        show_frames (Optional[bool]): Include all iframe content in
            the response

        show_websocket_requests (Optional[bool]): Capture websocket
            traffic in the response

        return_json (Optional[bool]): Whether `return_json=True` was
            set

    Raises:
        ValueError: If any JSON-envelope-dependent field is truthy
            while `return_json` is not set
    """
    used = _truthy_field_names({
        "screenshot": screenshot,
        "full_screenshot": full_screenshot,
        "particular_screenshot": particular_screenshot,
        "show_frames": show_frames,
        "show_websocket_requests": show_websocket_requests,
        })

    if used and not return_json:
        raise ValueError((
            f"The following parameters require both 'render=true' AND"
            f" 'returnJSON=true' to be set: "
            f" {', '.join(used)}."
            ))


def check_play_with_browser_vs_particular_screenshot(
    play_with_browser: Optional[Sequence[BrowserAction]],
    particular_screenshot: Optional[str],
) -> None:
    """Enforces mutual exclusivity between `play_with_browser` and
    `particular_screenshot`

    info: Logic Behind Validation
        Element-selector screenshots are taken after navigation but cannot
        coexist with a scripted browser-action sequence in the same
        request

    tip: Use Particular Screenshot With `playWithBrowser`
        To get a `particular_screenshot` while using the `playWithBrowser`
        parameter, you can use use a
        [`ScreenShotAction`][scrape_do.models.browser_actions.ScreenShotAction]
        object with the `particular_screenshot` field set to the `CSS selector`
        you want to capture

    Args:
        play_with_browser (Optional[Sequence[BrowserAction]]): Sequence of
            [`BrowserAction`][scrape_do.models.BrowserAction]
            entries or `None`

        particular_screenshot (Optional[str]): CSS selector targeting
            a specific element to screenshot, or `None`

    Raises:
        ValueError: If both arguments are non-`None`
    """
    if (
        particular_screenshot is not None
        and play_with_browser is not None
    ):
        raise ValueError(
            "The 'particular_screenshot' parameter cannot be used"
            " concurrently with the 'playWithBrowser' parameter"
            )


def check_render_dependencies(
    render: Optional[bool],
    dependent_fields: Dict[str, Any],
) -> None:
    """Enforces the `render=True` dependency for headless-browser
    parameters

    info: Logic Behind Validation
        The `wait_until`, `custom_wait`, `wait_selector`, `width`,
        `height`, `return_json`, `block_resources`, `screenshot`,
        `full_screenshot`, `particular_screenshot`, `play_with_browser`,
        `show_frames`, `show_websocket_requests` require the headless-browser
        pipeline to be active

    tip: Usage
        The caller must pass the actual field values keyed by name so that the
        error message can name the offending fields verbatim

    Args:
        render (Optional[bool]): Whether `render=True` was set

        dependent_fields (Dict[str, Any]): Map of render-dependent
            field names &rarr; their current values. Any field whose
            value is non-`None` is considered `in use`

    Raises:
        ValueError: If any of the dependent fields is non-`None`
            while `render` is not truthy. The message lists every
            offending field name
    """
    used = _non_none_field_names(dependent_fields)

    if used and not render:
        raise ValueError(
            f"The following parameters require 'render=true' to be set: "
            f"{', '.join(used)}."
            )


def check_retry_timeout_vs_render(
    render: Optional[bool],
    retry_timeout: Optional[int],
) -> None:
    """Enforces mutual exclusivity between `retry_timeout` and
    `render=True`

    info: Logic Behind Validation
        According to the `Scrape.do` official documentation, the
        `retry_timeout` parameter does not work when set simultaneously with
        `render=true`

    Args:
        render (Optional[bool]): Whether `render=True` was set

        retry_timeout (Optional[int]): Internal proxy retry duration
            in milliseconds, or `None`

    Raises:
        ValueError: If `render=True` and `retry_timeout` is not
            `None`
    """
    if render and retry_timeout is not None:
        raise ValueError(
            "The 'retry_timeout' parameter cannot be used concurrently"
            " with 'render=true'"
            )


def check_header_mutual_exclusion(
    custom_headers: Optional[bool],
    extra_headers: Optional[bool],
    forward_headers: Optional[bool],
) -> None:
    """Enforces that at most one of the three header-control
    parameters is set

    info: Logic Behind Validation
        - `custom_headers`, `extra_headers`, and `forward_headers` are
          mutually exclusive header-handling modes

        - `Scrape.do's` gateway will reject combinations

    Args:
        custom_headers (Optional[bool]): Replace Scrape.do's default
            headers with the user-provided ones

        extra_headers (Optional[bool]): Append the user-provided
            headers to Scrape.do's defaults

        forward_headers (Optional[bool]): Forward all headers exactly
            as sent by the client

    Raises:
        ValueError: If more than one of the three is truthy
    """
    used = _truthy_field_names({
        "custom_headers": custom_headers,
        "extra_headers": extra_headers,
        "forward_headers": forward_headers,
        })

    if len(used) > 1:
        raise ValueError(
            f"Only one header parameter can be used at a time."
            f" Header Parameters used: {', '.join(used)}"
            )


def check_headers_vs_set_cookies(
    used_header_fields: List[str],
    set_cookies: Optional[str],
) -> None:
    """Enforces incompatibility between any header-control mode and
    `set_cookies`

    info: Logic Behind Validation
        Scrape.do does not accept `setCookies` alongside any of the
        `customHeaders / extraHeaders / forwardHeaders` flags

    Args:
        used_header_fields (List[str]): Names of header-control fields
            that are currently truthy. Pass `[]` if none are set

        set_cookies (Optional[str]): The `set_cookies` parameter value

    Raises:
        ValueError: If `used_header_fields` is non-empty AND
            `set_cookies` is non-`None`
    """
    if used_header_fields and set_cookies:
        raise ValueError(
            f"Header parameters cannot be used concurrently with"
            f" the set_cookies parameter. Header Parameters used:"
            f" {', '.join(used_header_fields)}"
            )
