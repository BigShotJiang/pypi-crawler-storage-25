"""Public model surface for `Scrape.do's Amazon Plugin`

Re-exports every `*Parameters` model defined under
[`scrape_do.plugins.amazon.models`][scrape_do.plugins.amazon.models]
"""

from __future__ import annotations

from .parameters import (
    AmazonOfferListingParameters,
    AmazonPdpParameters,
    AmazonRawHtmlParameters,
    AmazonSearchParameters,
    )

__all__ = [
    "AmazonOfferListingParameters",
    "AmazonPdpParameters",
    "AmazonRawHtmlParameters",
    "AmazonSearchParameters",
    ]
