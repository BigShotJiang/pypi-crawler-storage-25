"""Parameter Models For `Scrape.do's Amazon Plugin` Endpoints

Defines the `pydantic` models containing the parameters accepted
by the various endpoints of the `Scrape.do Amazon Scraper API`.

info: Model Definitions
    Model structure comes from the [`Official Documentation Page`](https://
    scrape.do/documentation/amazon-scraper-api/)


## Common Parameters

tip: `asin`
    10-character Amazon Standard Identification Number

tip: `geocode`
    Country code selecting the target Amazon marketplace.
    See the [`Amazon Scraper API`](https://scrape.do/documentation/amazon-
    scraper-api/) reference for all allowed countries


tip: `zipcode`
    Postal code in the per-country format required by the target marketplace.
    See the [`Amazon Scraper API`](https://scrape.do/documentation/amazon-
    scraper-api/) reference for the full per-country table

tip: `language`
    - Optional ISO 639-1 code (uppercase, e.g. `EN`, `DE`, `FR`).
    - Each marketplace has a per-country language whitelist
    - The server returns `400 language_not_supported` if the combination is
      invalid

tip: `super`
    When `true`, routes through `Scrape.do's` premium residential / mobile
    proxy pool. **Costs 10 credits**

tip: `include_html`
    When `true`, the response payload includes the raw scraped HTML alongside
    the parsed structured JSON

"""

from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


class AmazonPdpParameters(BaseModel):
    """Input parameters for the `/plugin/amazon/pdp` endpoint
    (`Product Detail Page`)

    Attributes:
        asin (str): 10-character Amazon ASIN
        geocode (str): ISO 3166-1 alpha-2 country code
        zipcode (str): Postal code formatted per the country's requirements
        language (Optional[str]): ISO 639-1 language code (e.g. `EN`,
            `DE`). Constrained per-marketplace by `Scrape.do`
        super (Optional[bool]): Route through premium residential / mobile
            proxies (10 credit cost)
        include_html (Optional[bool]): Include raw HTML alongside parsed
            JSON
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    asin: str = Field(
        ...,
        alias="asin"
        )
    geocode: str = Field(
        ...,
        alias="geocode"
        )
    zipcode: str = Field(
        ...,
        alias="zipcode"
        )
    language: Optional[str] = Field(
        default=None,
        alias="language"
        )
    super: Optional[bool] = Field(
        default=None,
        alias="super"
        )
    include_html: Optional[bool] = Field(
        default=None,
        alias="include_html"
        )


class AmazonSearchParameters(BaseModel):
    """Input parameters for the `/plugin/amazon/search` endpoint
    (`Search Results`).

    Attributes:
        keyword (str): Search query (URL-encode spaces / special chars)
        geocode (str): ISO 3166-1 alpha-2 country code
        zipcode (str): Postal code formatted per the country's requirements.
        page (Optional[int]): 1-indexed page number (server-side
            default `1`)
        language (Optional[str]): ISO 639-1 language code.
        super (Optional[bool]): Route through premium proxies (10 credit
            cost)
        include_html (Optional[bool]): Include raw HTML alongside parsed
            JSON
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    keyword: str = Field(
        ...,
        alias="keyword"
        )
    geocode: str = Field(
        ...,
        alias="geocode"
        )
    zipcode: str = Field(
        ...,
        alias="zipcode"
        )
    page: Optional[int] = Field(
        default=None,
        alias="page",
        ge=1
        )
    language: Optional[str] = Field(
        default=None,
        alias="language"
        )
    super: Optional[bool] = Field(
        default=None,
        alias="super"
        )
    include_html: Optional[bool] = Field(
        default=None,
        alias="include_html"
        )


class AmazonOfferListingParameters(BaseModel):
    """Input parameters for the `/plugin/amazon/offer-listing` endpoint
    (`All-Seller Offer Listing`)

    Attributes:
        asin (str): 10-character Amazon ASIN
        geocode (str): ISO 3166-1 alpha-2 country code
        zipcode (str): Postal code formatted per the country's requirements
        language (Optional[str]): ISO 639-1 language code
        super (Optional[bool]): Route through premium proxies (10 credit
            cost)
        include_html (Optional[bool]): Include raw HTML alongside parsed
            JSON
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    asin: str = Field(
        ...,
        alias="asin"
        )
    geocode: str = Field(
        ...,
        alias="geocode"
        )
    zipcode: str = Field(
        ...,
        alias="zipcode"
        )
    language: Optional[str] = Field(
        default=None,
        alias="language"
        )
    super: Optional[bool] = Field(
        default=None,
        alias="super"
        )
    include_html: Optional[bool] = Field(
        default=None,
        alias="include_html"
        )


class AmazonRawHtmlParameters(BaseModel):
    """Input parameters for the sync-only `/plugin/amazon/` endpoint
    (`Raw HTML with Geo-Targeting`)

    warning: Sync-Only Endpoint
        - `/plugin/amazon/` has no async-API counterpart and is reachable
          only through the synchronous `Amazon Scraper API` gateway

    Attributes:
        url (str): The Amazon URL to fetch (URL-encoded)
        geocode (str): ISO 3166-1 alpha-2 country code
        zipcode (str): Postal code formatted per the country's requirements
        output (str): Output format. `"html"` is the only documented
            value. Defaults to `"html"`
        super (Optional[bool]): Route through premium proxies (10 credit
            cost)
        language (Optional[str]): ISO 639-1 language code
        timeout (Optional[int]): Request timeout in milliseconds
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    url: str = Field(
        ...,
        alias="url"
        )
    geocode: str = Field(
        ...,
        alias="geocode"
        )
    zipcode: str = Field(
        ...,
        alias="zipcode"
        )
    output: str = Field(
        default="html",
        alias="output"
        )
    super: Optional[bool] = Field(
        default=None,
        alias="super"
        )
    language: Optional[str] = Field(
        default=None,
        alias="language"
        )
    timeout: Optional[int] = Field(
        default=None,
        alias="timeout",
        ge=0
        )
