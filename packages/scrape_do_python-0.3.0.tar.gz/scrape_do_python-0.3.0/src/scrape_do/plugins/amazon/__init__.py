"""`Scrape.do Amazon Plugin` Sub-Package.

abstract: `models/`
    Defines the [`amazon`](https://scrape.do/documentation/amazon-scraper-api/)
    gateway contract models.

warning: Partially Implemented
    - `0.3` ships **ONLY** the `Typed Parameter Models`

    - The plugin-specific `Clients`, `Responses`, and `Exceptions` are still
      **NOT** implemented
"""

from __future__ import annotations

from .models import (
    AmazonOfferListingParameters,
    AmazonPdpParameters,
    AmazonRawHtmlParameters,
    AmazonSearchParameters,
    )

__all__ = [
    "AmazonOfferListingParameters",
    "AmazonPdpParameters",
    "AmazonRawHtmlParameters",
    "AmazonSearchParameters",
    ]
