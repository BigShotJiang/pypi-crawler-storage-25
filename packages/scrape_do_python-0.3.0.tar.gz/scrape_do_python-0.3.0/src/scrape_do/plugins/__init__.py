"""`Scrape.do Plugins` Top-Level Sub-Package

Contains sub-packages providing tools to facilitate programmatic interaction
with the `Scrape.do Plugins` and their endpoints

abstract: Additional Information
    - Each sub-package will represent one major `Scrape.do Plugin` gateway and
      will provide `specialised clients` to interact with all of its endpoints

    - Each sub-package also defines strictly-typed `pydantic` models for the
      type of `request` expected by each one of the plugin's endpoints along
      with `local validation` to prevent misconfigured requests

    - The `response` returned by each one of the endpoints will be mapped into
      a strictly-typed `pydantic` model to provide structured access and
      specialised error recognition

info: Available Plugins
    - [`Scrape.do Amazon Scraper API Plugin`][scrape_do.plugins.amazon]
    - [`Scrape.do Google Scraper API Plugin`][scrape_do.plugins.google]

tip: Official Documentation Pages
    - [`amazon`](https://scrape.do/documentation/amazon-scraper-api/)
    - [`google`](https://scrape.do/documentation/google-scraper-api/)

tip: Async Adaptation
    - A subset of these plugins' endpoints can also be used asynchronously via
      the `Scrape.do Async API`

    - For more information about which endpoints can be used and how the models
      defined here are reused when creating `Async API Jobs`, please refer to
      the [`Async API Sub-Package Documentation`]
    [scrape_do.async_api.models.plugins]

warning: Partially Implemented
    - `0.3` ships **ONLY** the `Typed Parameter Models`

    - The plugin-specific `Clients`, `Responses`, and `Exceptions` are still
      **NOT** implemented
"""

from __future__ import annotations

from .amazon import (
    AmazonOfferListingParameters,
    AmazonPdpParameters,
    AmazonRawHtmlParameters,
    AmazonSearchParameters,
    )
from .google import (
    GOOGLE_COUNTRY_CODES,
    GOOGLE_DOMAINS,
    GOOGLE_LANGUAGE_CODES,
    GOOGLE_LANGUAGE_RESTRICT_VALUES,
    GoogleDeviceType,
    GoogleFlightsParameters,
    GoogleFlightsSortByType,
    GoogleFlightsStopsType,
    GoogleFlightsTravelClassType,
    GoogleFlightsTripType,
    GoogleHotelsDetailParameters,
    GoogleHotelsParameters,
    GoogleHotelsRatingType,
    GoogleHotelsSortByType,
    GoogleMapsPlaceParameters,
    GoogleMapsReviewsParameters,
    GoogleMapsSearchParameters,
    GoogleNFPRType,
    GoogleNewsParameters,
    GoogleNewsSortOrderType,
    GoogleReviewsSortByType,
    GoogleSafeSearchType,
    GoogleSearchAiModeParameters,
    GoogleSearchAiOverviewParameters,
    GoogleSearchParameters,
    GoogleShoppingParameters,
    GoogleShoppingSortByType,
    GoogleTimePeriodType,
    GoogleTrendingParameters,
    GoogleTrendsDataType,
    GoogleTrendsGPropType,
    GoogleTrendsParameters,
    )

__all__ = [
    # Google localization constants
    "GOOGLE_COUNTRY_CODES",
    "GOOGLE_DOMAINS",
    "GOOGLE_LANGUAGE_CODES",
    "GOOGLE_LANGUAGE_RESTRICT_VALUES",
    # Amazon
    "AmazonOfferListingParameters",
    "AmazonPdpParameters",
    "AmazonRawHtmlParameters",
    "AmazonSearchParameters",
    # Google
    "GoogleDeviceType",
    "GoogleFlightsParameters",
    "GoogleFlightsSortByType",
    "GoogleFlightsStopsType",
    "GoogleFlightsTravelClassType",
    "GoogleFlightsTripType",
    "GoogleHotelsDetailParameters",
    "GoogleHotelsParameters",
    "GoogleHotelsRatingType",
    "GoogleHotelsSortByType",
    "GoogleMapsPlaceParameters",
    "GoogleMapsReviewsParameters",
    "GoogleMapsSearchParameters",
    "GoogleNFPRType",
    "GoogleNewsParameters",
    "GoogleNewsSortOrderType",
    "GoogleReviewsSortByType",
    "GoogleSafeSearchType",
    "GoogleSearchAiModeParameters",
    "GoogleSearchAiOverviewParameters",
    "GoogleSearchParameters",
    "GoogleShoppingParameters",
    "GoogleShoppingSortByType",
    "GoogleTimePeriodType",
    "GoogleTrendingParameters",
    "GoogleTrendsDataType",
    "GoogleTrendsGPropType",
    "GoogleTrendsParameters",
    ]
