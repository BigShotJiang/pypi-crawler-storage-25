"""`Scrape.do Google Plugin` Sub-Package.

abstract: `models/`
    Defines the [`/plugin/google/...`](https://scrape.do/documentation/google-
    scraper-api/) gateway contracts and the literal type aliases and public
    localization constants used by those parameters

warning: Partially Implemented
    - `0.3` ships **ONLY** the `Typed Parameter Models`

    - The plugin-specific `Clients`, `Responses`, and `Exceptions` are still
      **NOT** implemented
"""

from __future__ import annotations

from .models import (
    GOOGLE_COUNTRY_CODES,
    GOOGLE_DOMAINS,
    GOOGLE_LANGUAGE_CODES,
    GOOGLE_LANGUAGE_RESTRICT_VALUES,
    GoogleDeviceType,
    GoogleFlightsParameters,
    GoogleFlightsSortByType,
    GoogleFlightsStopsType,
    GoogleFlightsTravelClassType,
    GoogleFlightsTripType,
    GoogleHotelsDetailParameters,
    GoogleHotelsParameters,
    GoogleHotelsRatingType,
    GoogleHotelsSortByType,
    GoogleMapsPlaceParameters,
    GoogleMapsReviewsParameters,
    GoogleMapsSearchParameters,
    GoogleNFPRType,
    GoogleNewsParameters,
    GoogleNewsSortOrderType,
    GoogleReviewsSortByType,
    GoogleSafeSearchType,
    GoogleSearchAiModeParameters,
    GoogleSearchAiOverviewParameters,
    GoogleSearchParameters,
    GoogleShoppingParameters,
    GoogleShoppingSortByType,
    GoogleTimePeriodType,
    GoogleTrendingParameters,
    GoogleTrendsDataType,
    GoogleTrendsGPropType,
    GoogleTrendsParameters,
    )

__all__ = [
    "GOOGLE_COUNTRY_CODES",
    "GOOGLE_DOMAINS",
    "GOOGLE_LANGUAGE_CODES",
    "GOOGLE_LANGUAGE_RESTRICT_VALUES",
    "GoogleDeviceType",
    "GoogleFlightsParameters",
    "GoogleFlightsSortByType",
    "GoogleFlightsStopsType",
    "GoogleFlightsTravelClassType",
    "GoogleFlightsTripType",
    "GoogleHotelsDetailParameters",
    "GoogleHotelsParameters",
    "GoogleHotelsRatingType",
    "GoogleHotelsSortByType",
    "GoogleMapsPlaceParameters",
    "GoogleMapsReviewsParameters",
    "GoogleMapsSearchParameters",
    "GoogleNFPRType",
    "GoogleNewsParameters",
    "GoogleNewsSortOrderType",
    "GoogleReviewsSortByType",
    "GoogleSafeSearchType",
    "GoogleSearchAiModeParameters",
    "GoogleSearchAiOverviewParameters",
    "GoogleSearchParameters",
    "GoogleShoppingParameters",
    "GoogleShoppingSortByType",
    "GoogleTimePeriodType",
    "GoogleTrendingParameters",
    "GoogleTrendsDataType",
    "GoogleTrendsGPropType",
    "GoogleTrendsParameters",
    ]
