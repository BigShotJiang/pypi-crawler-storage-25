"""Parameter Models for `Scrape.do's Google Plugin` Endpoints

Defines the `pydantic` models containing the parameters accepted
by the various endpoints of the `Scrape.do Google Scraper API`

info: Model Definitions
    Model structure comes from the [`Official Documentation Page`](https://
    scrape.do/documentation/google-scraper-api/)

## Sections

abstract: Search Results
    - [`GoogleSearchParameters`]
    [scrape_do.plugins.google.GoogleSearchParameters]
    - [`GoogleSearchAiModeParameters`]
    [scrape_do.plugins.google.GoogleSearchAiModeParameters]
    - [`GoogleSearchAiOverviewParameters`]
    [scrape_do.plugins.google.GoogleSearchAiOverviewParameters]

abstract: Maps
    - [`GoogleMapsSearchParameters`]
    [scrape_do.plugins.google.GoogleMapsSearchParameters]
    - [`GoogleMapsPlaceParameters`]
    [scrape_do.plugins.google.GoogleMapsPlaceParameters]
    - [`GoogleMapsReviewsParameters`]
    [scrape_do.plugins.google.GoogleMapsReviewsParameters]

abstract: Verticals
    - [`GoogleShoppingParameters`]
    [scrape_do.plugins.google.GoogleShoppingParameters]
    - [`GoogleFlightsParameters`]
    [scrape_do.plugins.google.GoogleFlightsParameters]
    - [`GoogleHotelsParameters`]
    [scrape_do.plugins.google.GoogleHotelsParameters]
    - [`GoogleHotelsDetailParameters`]
    [scrape_do.plugins.google.GoogleHotelsDetailParameters]

abstract: Others
    - [`GoogleNewsParameters`][scrape_do.plugins.google.GoogleNewsParameters]
    - [`GoogleTrendsParameters`]
    [scrape_do.plugins.google.GoogleTrendsParameters]
    - [`GoogleTrendingParameters`]
    [scrape_do.plugins.google.GoogleTrendingParameters]

## Additional Information

info: Localization
    All Google plugins accept `hl` (language) and `gl` (country) for
    localization

warning: `super=True`
    All google plugins use `premium residential proxies` by default


tip: Parameter Types
    - Some of the models' parameters are `Literal Mappings`

    - See the [`Enums`][scrape_do.plugins.google.models.enums] module for a
      more detailed explanation of what they represent
"""

from __future__ import annotations

from datetime import date
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator
from typing_extensions import Self

from .enums import (
    GoogleDeviceType,
    GoogleFlightsSortByType,
    GoogleFlightsStopsType,
    GoogleFlightsTravelClassType,
    GoogleFlightsTripType,
    GoogleHotelsRatingType,
    GoogleHotelsSortByType,
    GoogleNFPRType,
    GoogleNewsSortOrderType,
    GoogleReviewsSortByType,
    GoogleSafeSearchType,
    GoogleShoppingSortByType,
    GoogleTimePeriodType,
    GoogleTrendsDataType,
    GoogleTrendsGPropType,
    )


# --------------------------------------------------------------------
# Search
# --------------------------------------------------------------------


class GoogleSearchParameters(BaseModel):
    """Input parameters accepted by the `google/search` endpoint

    **Localization**

    info: `hl` / `gl`
        - `hl` (language) and `gl` (country) are `CONTEXT` hints

        - Results are ranked from that locale's perspective but may still
          include `cross-locale` results

    info: `cr` / `lr`
        - `cr` and `lr` are `STRICT` filters

        - They restrict to a `country of origin` / `language` and accept
          tokens like `countryUS` and `lang_en` respectively

        - See the [`Localization Reference`](https://
          scrape.do/documentation/google-scraper-api/localization/)
          for the full allowlists

        - You can also import the public
        [`GOOGLE_LANGUAGE_RESTRICT_VALUES`][scrape_do.plugins.google.models.localization]
        frozenset for opt-in client-side validation of `lr`

    info: `location` / `uule`
        - `location` is a human-readable string (e.g. `"New York,New York,
          United States"`)

        - The server `auto-encodes` it to a `UULE` token and echoes both back
          in `search_parameters`

        - `uule` is a pre-encoded location token

        - When both `location` and `uule` are set, `uule` wins

    Attributes:
        q (str): Search query.
        gl (Optional[str]): Country-perspective code (default `us`)
        hl (Optional[str]): Interface-language code (default `en`)
        google_domain (Optional[str]): Google domain override
            (default `google.com`)
        device (Optional[GoogleDeviceType]): Device class to emulate
        start (Optional[int]): Non-negative result offset for
            pagination
        include_html (Optional[bool]): Include raw HTML alongside
            parsed JSON
        cr (Optional[str]): Strict country-of-origin filter in
            `country<UPPER_ISO>` form (combine with `.` for multiple)
        lr (Optional[str]): Strict language-of-origin filter in
            `lang_<iso>` form
        uule (Optional[str]): Pre-encoded UULE location token
        location (Optional[str]): Human-readable location string.
            (auto-encoded to UULE server-side)
        safe (Optional[GoogleSafeSearchType]): SafeSearch toggle
        time_period (Optional[GoogleTimePeriodType]): Filter results
            to a rolling time window
        filter (Optional[str]): Server-side de-duplication / similar
            content filter (opaque on the gateway)
        nfpr (Optional[GoogleNFPRType]): Spell-correction toggle.
        num (Optional[int]): Page size `1`-`100`
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    google_domain: Optional[str] = Field(
        default=None,
        alias="google_domain"
        )
    device: Optional[GoogleDeviceType] = Field(
        default=None,
        alias="device"
        )
    start: Optional[int] = Field(
        default=None,
        alias="start",
        ge=0
        )
    include_html: Optional[bool] = Field(
        default=None,
        alias="include_html"
        )
    cr: Optional[str] = Field(
        default=None,
        alias="cr"
        )
    lr: Optional[str] = Field(
        default=None,
        alias="lr"
        )
    uule: Optional[str] = Field(
        default=None,
        alias="uule"
        )
    location: Optional[str] = Field(
        default=None,
        alias="location"
        )
    safe: Optional[GoogleSafeSearchType] = Field(
        default=None,
        alias="safe"
        )
    time_period: Optional[GoogleTimePeriodType] = Field(
        default=None,
        alias="time_period"
        )
    filter: Optional[str] = Field(
        default=None,
        alias="filter"
        )
    nfpr: Optional[GoogleNFPRType] = Field(
        default=None,
        alias="nfpr"
        )
    num: Optional[int] = Field(
        default=None,
        alias="num",
        ge=1,
        le=100
        )


class GoogleSearchAiModeParameters(BaseModel):
    """Input parameters accepted by the `google/search/ai-mode` endpoint

    info: Mirror of `google/search`
        - The sync gateway documents AI Mode as sharing the
          [`GoogleSearchParameters`][scrape_do.plugins.google.GoogleSearchParameters]
          surface

        - Every field below is documented on [`/plugin/google/search`](https://
          scrape.do/documentation/google-scraper-api/search/) and accepted on
          AI Mode for the same purpose

        - The two endpoints differ only in the `response payload`

        - `AI Mode` returns an AI-generated overview with citations rather
          than the standard `SERP` envelope

    Attributes:
        q (str): Search query.
        gl (Optional[str]): Country-perspective code (default `us`)
        hl (Optional[str]): Interface-language code (default `en`)
        google_domain (Optional[str]): Google domain override
            (default `google.com`)
        device (Optional[GoogleDeviceType]): Device class to emulate
        start (Optional[int]): Non-negative result offset for
            pagination
        include_html (Optional[bool]): Include raw HTML alongside
            parsed JSON
        cr (Optional[str]): Strict country-of-origin filter in
            `country<UPPER_ISO>` form
        lr (Optional[str]): Strict language-of-origin filter in
            `lang_<iso>` form
        uule (Optional[str]): Pre-encoded UULE location token
        location (Optional[str]): Human-readable location string
            (auto-encoded to UULE server-side)
        safe (Optional[GoogleSafeSearchType]): SafeSearch toggle
        time_period (Optional[GoogleTimePeriodType]): Filter results
            to a rolling time window
        filter (Optional[str]): Server-side de-duplication / similar
            content filter (opaque on the gateway)
        nfpr (Optional[GoogleNFPRType]): Spell-correction toggle
        num (Optional[int]): Page size `1`-`100`
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    google_domain: Optional[str] = Field(
        default=None,
        alias="google_domain"
        )
    device: Optional[GoogleDeviceType] = Field(
        default=None,
        alias="device"
        )
    start: Optional[int] = Field(
        default=None,
        alias="start",
        ge=0
        )
    include_html: Optional[bool] = Field(
        default=None,
        alias="include_html"
        )
    cr: Optional[str] = Field(
        default=None,
        alias="cr"
        )
    lr: Optional[str] = Field(
        default=None,
        alias="lr"
        )
    uule: Optional[str] = Field(
        default=None,
        alias="uule"
        )
    location: Optional[str] = Field(
        default=None,
        alias="location"
        )
    safe: Optional[GoogleSafeSearchType] = Field(
        default=None,
        alias="safe"
        )
    time_period: Optional[GoogleTimePeriodType] = Field(
        default=None,
        alias="time_period"
        )
    filter: Optional[str] = Field(
        default=None,
        alias="filter"
        )
    nfpr: Optional[GoogleNFPRType] = Field(
        default=None,
        alias="nfpr"
        )
    num: Optional[int] = Field(
        default=None,
        alias="num",
        ge=1,
        le=100
        )


# --------------------------------------------------------------------
# Maps
# --------------------------------------------------------------------


class GoogleMapsSearchParameters(BaseModel):
    """Input parameters accepted by the `google/maps/search` endpoint

    Attributes:
        q (str): Search query
        ll (Optional[str]): Lat / lng / zoom pin in
            `@<lat>,<lng>,<zoom>z` form
        start (Optional[int]): Page offset (multiples of 20)
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
        google_domain (Optional[str]): Google domain override
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    ll: Optional[str] = Field(
        default=None,
        alias="ll"
        )
    start: Optional[int] = Field(
        default=None,
        alias="start",
        ge=0
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    google_domain: Optional[str] = Field(
        default=None,
        alias="google_domain"
        )


class GoogleMapsPlaceParameters(BaseModel):
    """Input parameters accepted by the `google/maps/place` endpoint

    warning: Place ID + Data CID
        - Exactly one of `place_id` or `data_cid` **MUST** be set

        - Setting both or neither raises `ValueError`

    Attributes:
        place_id (Optional[str]): Google Place ID in `ChIJ...` form
        data_cid (Optional[str]): Numeric CID
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
        google_domain (Optional[str]): Google domain override
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    place_id: Optional[str] = Field(
        default=None,
        alias="place_id"
        )
    data_cid: Optional[str] = Field(
        default=None,
        alias="data_cid"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    google_domain: Optional[str] = Field(
        default=None,
        alias="google_domain"
        )

    @model_validator(mode="after")
    def _require_exactly_one_id(self) -> Self:
        """Enforces that exactly one of `place_id` / `data_cid` is set

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If both or neither identifier is provided
        """
        if self.place_id is None and self.data_cid is None:
            raise ValueError(
                "google/maps/place requires exactly one of"
                " 'place_id' or 'data_cid'"
                )
        if self.place_id is not None and self.data_cid is not None:
            raise ValueError(
                "google/maps/place accepts only one of 'place_id'"
                " or 'data_cid', not both"
                )
        return self


class GoogleMapsReviewsParameters(BaseModel):
    """Input parameters accepted by the `google/maps/reviews` endpoint

    warning: Data ID + Place ID
        Exactly one of `data_id` or `place_id` **MUST** be set

    warning: Topic ID + Query
        `topic_id` and `query` are `mutually exclusive`

    Attributes:
        data_id (Optional[str]): Place ID in `0xHEX:0xHEX` form
        place_id (Optional[str]): Place ID in `ChIJ...` form
        num (Optional[int]): Reviews per page (`1`-`20`, default `10`
            server-side)
        sort_by (Optional[GoogleReviewsSortByType]): Sort order for
            the returned reviews
        topic_id (Optional[str]): Filter reviews by topic ID
        query (Optional[str]): Filter reviews by free-text keyword
        next_page_token (Optional[str]): Cursor returned from a
            previous response's `pagination.next_page_token`
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    data_id: Optional[str] = Field(
        default=None,
        alias="data_id"
        )
    place_id: Optional[str] = Field(
        default=None,
        alias="place_id"
        )
    num: Optional[int] = Field(
        default=None,
        alias="num",
        ge=1,
        le=20
        )
    sort_by: Optional[GoogleReviewsSortByType] = Field(
        default=None,
        alias="sort_by"
        )
    topic_id: Optional[str] = Field(
        default=None,
        alias="topic_id"
        )
    query: Optional[str] = Field(
        default=None,
        alias="query"
        )
    next_page_token: Optional[str] = Field(
        default=None,
        alias="next_page_token"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )

    @model_validator(mode="after")
    def _validate_id_and_filters(self) -> Self:
        """Enforces the exactly-one-id and topic_id/query exclusion
        rules

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If neither / both identifier(s) are provided,
                or if both `topic_id` and `query` are set
        """
        if self.data_id is None and self.place_id is None:
            raise ValueError(
                "google/maps/reviews requires exactly one of"
                " 'data_id' or 'place_id'"
                )
        if self.data_id is not None and self.place_id is not None:
            raise ValueError(
                "google/maps/reviews accepts only one of 'data_id'"
                " or 'place_id', not both"
                )
        if self.topic_id is not None and self.query is not None:
            raise ValueError(
                "google/maps/reviews 'topic_id' and 'query' are"
                " mutually exclusive"
                )
        return self


# --------------------------------------------------------------------
# Verticals
# --------------------------------------------------------------------


class GoogleShoppingParameters(BaseModel):
    """Input Parameters accepted by the `google/shopping` endpoint

    Attributes:
        q (str): Search query
        min_price (Optional[int]): Minimum price filter
        max_price (Optional[int]): Maximum price filter
        sort_by (Optional[GoogleShoppingSortByType]): Sort order
        free_shipping (Optional[bool]): Filter to free-shipping
            listings
        on_sale (Optional[bool]): Filter to on-sale listings
        shoprs (Optional[str]): Opaque filter token from a previous
            response
        device (Optional[GoogleDeviceType]): Device class to emulate
        start (Optional[int]): Pagination offset
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
        google_domain (Optional[str]): Google domain override
        location (Optional[str]): Location string for localization
        uule (Optional[str]): Encoded UULE location parameter
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    min_price: Optional[int] = Field(
        default=None,
        alias="min_price",
        ge=0
        )
    max_price: Optional[int] = Field(
        default=None,
        alias="max_price",
        ge=0
        )
    sort_by: Optional[GoogleShoppingSortByType] = Field(
        default=None,
        alias="sort_by"
        )
    free_shipping: Optional[bool] = Field(
        default=None,
        alias="free_shipping"
        )
    on_sale: Optional[bool] = Field(
        default=None,
        alias="on_sale"
        )
    shoprs: Optional[str] = Field(
        default=None,
        alias="shoprs"
        )
    device: Optional[GoogleDeviceType] = Field(
        default=None,
        alias="device"
        )
    start: Optional[int] = Field(
        default=None,
        alias="start",
        ge=0
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    google_domain: Optional[str] = Field(
        default=None,
        alias="google_domain"
        )
    location: Optional[str] = Field(
        default=None,
        alias="location"
        )
    uule: Optional[str] = Field(
        default=None,
        alias="uule"
        )


class GoogleFlightsParameters(BaseModel):
    """Input parameters accepted by the `google/flights` endpoint

    warning: Include / Exclude Airlines
        - `include_airlines` and `exclude_airlines` are `mutually exclusive`

        - Setting both raises `ValueError`

    warning: Unsupported Parameters
        The following parameters are **NOT** supported by `Scrape.do's` plugin
        engine and trigger a `400` response if sent, so they're intentionally
        absent from the model

        - `type=3` (Multi-City)
        - `max_price`
        - `max_duration`
        - `bags`

        The plugin engine enforces these limits regardless of whether the
        request is routed through the synchronous gateway or the `Async API`

    Attributes:
        departure_id (str): IATA code for departure airport(s)
            Comma-separated for multi-airport
        arrival_id (str): IATA code for arrival airport(s).
            Comma-separated for multi-airport
        outbound_date (str): YYYY-MM-DD outbound date
        return_date (Optional[str]): YYYY-MM-DD return date for round
            trips
        type (Optional[GoogleFlightsTripType]): Trip type. Auto-inferred
            when omitted
        adults (Optional[int]): Number of adult passengers (`1`-`9`)
        children (Optional[int]): Number of child passengers (`0`-`9`)
        infants_in_seat (Optional[int]): Infants requiring a seat
            (`0`-`4`)
        infants_on_lap (Optional[int]): Infants on lap (`0`-`4`)
        travel_class (Optional[GoogleFlightsTravelClassType]): Cabin
            class
        stops (Optional[GoogleFlightsStopsType]): Stop filter
        sort_by (Optional[GoogleFlightsSortByType]): Sort order
        include_airlines (Optional[str]): Comma-separated IATA codes
            of airlines to include
        exclude_airlines (Optional[str]): Comma-separated IATA codes
            of airlines to exclude
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
        currency (Optional[str]): ISO-4217 currency code
            (e.g. `USD`, `EUR`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    departure_id: str = Field(
        ...,
        alias="departure_id"
        )
    arrival_id: str = Field(
        ...,
        alias="arrival_id"
        )
    outbound_date: str = Field(
        ...,
        alias="outbound_date"
        )
    return_date: Optional[str] = Field(
        default=None,
        alias="return_date"
        )
    type: Optional[GoogleFlightsTripType] = Field(
        default=None,
        alias="type"
        )
    adults: Optional[int] = Field(
        default=None,
        alias="adults",
        ge=1,
        le=9
        )
    children: Optional[int] = Field(
        default=None,
        alias="children",
        ge=0,
        le=9
        )
    infants_in_seat: Optional[int] = Field(
        default=None,
        alias="infants_in_seat",
        ge=0,
        le=4
        )
    infants_on_lap: Optional[int] = Field(
        default=None,
        alias="infants_on_lap",
        ge=0,
        le=4
        )
    travel_class: Optional[GoogleFlightsTravelClassType] = Field(
        default=None,
        alias="travel_class"
        )
    stops: Optional[GoogleFlightsStopsType] = Field(
        default=None,
        alias="stops"
        )
    sort_by: Optional[GoogleFlightsSortByType] = Field(
        default=None,
        alias="sort_by"
        )
    include_airlines: Optional[str] = Field(
        default=None,
        alias="include_airlines"
        )
    exclude_airlines: Optional[str] = Field(
        default=None,
        alias="exclude_airlines"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    currency: Optional[str] = Field(
        default=None,
        alias="currency"
        )

    @model_validator(mode="after")
    def _validate_airline_exclusion(self) -> Self:
        """Enforces mutual exclusion between `include_airlines` and
        `exclude_airlines`

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If both filters are set
        """
        if (
            self.include_airlines is not None
            and self.exclude_airlines is not None
        ):
            raise ValueError(
                "google/flights 'include_airlines' and"
                " 'exclude_airlines' are mutually exclusive"
                )
        return self


class GoogleHotelsParameters(BaseModel):
    """Input parameters accepted by the `google/hotels` endpoint

    warning: Unsupported Parameters
        - Occupancy Parameters (`adults`, `children`, `children ages`)
          are **NOT** supported by `Scrape.do's` plugin engine

        - Results always reflect `2 adults / 0 children`

        - These fields are intentionally absent from the model

        - The plugin engine enforces this regardless of whether the request is
          routed through the synchronous gateway or the `Async API`

    warning: Date Order
        - `check_out_date` **MUST** be strictly after `check_in_date`

        - Same-day or reversed ranges raise a `ValueError` at model
          construction time

    warning: Price Range
        - When both `min_price` and `max_price` are set, `max_price`
          **MUST** be `>= min_price`

        - Reversed ranges raise a `ValueError` at construction

    Attributes:
        q (str): Hotel search query (use the simple
            `"<City> hotels"` form)
        check_in_date (date): ISO-8601 check-in date (accepts a
            `datetime.date` or `"YYYY-MM-DD"` string)
        check_out_date (date): ISO-8601 check-out date (must be after
            `check_in_date`)
        sort_by (Optional[GoogleHotelsSortByType]): Sort order
        min_price (Optional[int]): Minimum nightly price (in requested
            currency)
        max_price (Optional[int]): Maximum nightly price (>= `min_price`
            when both set)
        rating (Optional[GoogleHotelsRatingType]): Rating threshold
        hotel_class (Optional[str]): Comma-separated star ratings
            (`2`-`5`)
        brands (Optional[str]): Comma-separated brand codes
        amenities (Optional[str]): Comma-separated amenity codes
        property_types (Optional[str]): Comma-separated
            property-type codes
        free_cancellation (Optional[bool]): Filter to
            free-cancellation listings
        eco_certified (Optional[bool]): Filter to eco-certified
            listings
        special_offers (Optional[bool]): Filter to listings with
            special offers
        next_page_token (Optional[str]): Pagination cursor from a
            previous response
        limit (Optional[int]): Maximum properties to return per
            request (`1`-`20`, default `20` server-side)
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
        currency (Optional[str]): ISO-4217 currency code
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    check_in_date: date = Field(
        ...,
        alias="check_in_date"
        )
    check_out_date: date = Field(
        ...,
        alias="check_out_date"
        )
    sort_by: Optional[GoogleHotelsSortByType] = Field(
        default=None,
        alias="sort_by"
        )
    min_price: Optional[int] = Field(
        default=None,
        alias="min_price",
        ge=0
        )
    max_price: Optional[int] = Field(
        default=None,
        alias="max_price",
        ge=0
        )
    rating: Optional[GoogleHotelsRatingType] = Field(
        default=None,
        alias="rating"
        )
    hotel_class: Optional[str] = Field(
        default=None,
        alias="hotel_class"
        )
    brands: Optional[str] = Field(
        default=None,
        alias="brands"
        )
    amenities: Optional[str] = Field(
        default=None,
        alias="amenities"
        )
    property_types: Optional[str] = Field(
        default=None,
        alias="property_types"
        )
    free_cancellation: Optional[bool] = Field(
        default=None,
        alias="free_cancellation"
        )
    eco_certified: Optional[bool] = Field(
        default=None,
        alias="eco_certified"
        )
    special_offers: Optional[bool] = Field(
        default=None,
        alias="special_offers"
        )
    next_page_token: Optional[str] = Field(
        default=None,
        alias="next_page_token"
        )
    limit: Optional[int] = Field(
        default=None,
        alias="limit",
        ge=1,
        le=20
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    currency: Optional[str] = Field(
        default=None,
        alias="currency"
        )

    @model_validator(mode="after")
    def _validate_date_and_price_ranges(self) -> Self:
        """Enforces `check_out_date > check_in_date` and
        `max_price >= min_price`

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If the check-out date is not strictly after the
                check-in date, or if the price range is reversed
        """
        if self.check_out_date <= self.check_in_date:
            raise ValueError(
                "google/hotels 'check_out_date' must be strictly after"
                " 'check_in_date'"
                )
        if (
            self.min_price is not None
            and self.max_price is not None
            and self.max_price < self.min_price
        ):
            raise ValueError(
                "google/hotels 'max_price' must be greater than or equal"
                " to 'min_price'"
                )
        return self


# --------------------------------------------------------------------
# Other
# --------------------------------------------------------------------


class GoogleNewsParameters(BaseModel):
    """Input parameters accepted by the `google/news` endpoint

    warning: Driver
        Exactly **ONE** of the following parameters **MUST** be provided

        They are considered the `driver` of the request and setting zero or
        more than one raises `ValueError`

        - `q`
        - `topic_token`
        - `section_token`
        - `story_token`
        - `publication_token`

    warning: `so`
        - The `so` parameter is only valid when provided along with the `q` or
          `kgmid` drivers

        - Pairing it with any other `driver` raises `ValueError`

    tip: Driver Semantics
        - `q` = Keyword Search
        - `topic_token` = Topic Stream
        - `section_token` = Section Within A Topic
        - `story_token` = Full-Coverage Story Page
        - `publication_token` = Publisher Feed
        - `kgmid` = Knowledge Graph Entity (e.g. `/m/02_286` = New York City)

    Attributes:
        q (Optional[str]): Keyword search driver
        topic_token (Optional[str]): Topic-stream driver
        section_token (Optional[str]): Section-within-topic driver
        story_token (Optional[str]): Full-coverage story-page driver
        publication_token (Optional[str]): Publisher-feed driver
        kgmid (Optional[str]): Knowledge Graph entity driver
        so (Optional[GoogleNewsSortOrderType]): Sort order
        hl (Optional[str]): Language code
        gl (Optional[str]): Country code
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: Optional[str] = Field(
        default=None,
        alias="q"
        )
    topic_token: Optional[str] = Field(
        default=None,
        alias="topic_token"
        )
    section_token: Optional[str] = Field(
        default=None,
        alias="section_token"
        )
    story_token: Optional[str] = Field(
        default=None,
        alias="story_token"
        )
    publication_token: Optional[str] = Field(
        default=None,
        alias="publication_token"
        )
    kgmid: Optional[str] = Field(
        default=None,
        alias="kgmid"
        )
    so: Optional[GoogleNewsSortOrderType] = Field(
        default=None,
        alias="so"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )

    @model_validator(mode="after")
    def _require_exactly_one_driver(self) -> Self:
        """Enforces tht exactly one of the six driver fields is set, and
        that `so` is only paired with the `q` or `kgmid` drivers

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If zero or more than one driver is provided, or if the
                `so` parameter is paired with any other driver other than `q`
                or `kgmid`
        """
        drivers = {
            "q": self.q,
            "topic_token": self.topic_token,
            "section_token": self.section_token,
            "story_token": self.story_token,
            "publication_token": self.publication_token,
            "kgmid": self.kgmid,
            }
        used = [name for name, value in drivers.items() if value is not None]
        if len(used) == 0:
            raise ValueError(
                "google/news requires exactly one of"
                " 'q', 'topic_token', 'section_token', 'story_token',"
                " 'publication_token', or 'kgmid'"
                )
        if len(used) > 1:
            raise ValueError(
                f"google/news drivers are mutually exclusive."
                f" Multiple set: {', '.join(used)}"
                )
        if self.so is not None and used and used[0] not in {"q", "kgmid"}:
            raise ValueError(
                f"google/news 'so' is only valid with the 'q' or 'kgmid'"
                f" driver (search mode); got driver '{used[0]}'"
                )
        return self


class GoogleTrendsParameters(BaseModel):
    """Input Parameters accepted by the `google/trends` endpoint

    Attributes:
        q (str): Search keyword
        geo (Optional[str]): Location code
            (e.g. `US`, `GB`, `US-CA`)
        hl (Optional[str]): Language code (default `en`)
        date (Optional[str]): Time-range string (default
            `today 12-m`)
        data_type (Optional[GoogleTrendsDataType]): Trends widget to
            fetch
        cat (Optional[str]): Category ID
        gprop (Optional[GoogleTrendsGPropType]): Google property
            scope
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    q: str = Field(
        ...,
        alias="q"
        )
    geo: Optional[str] = Field(
        default=None,
        alias="geo"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    date: Optional[str] = Field(
        default=None,
        alias="date"
        )
    data_type: Optional[GoogleTrendsDataType] = Field(
        default=None,
        alias="data_type"
        )
    cat: Optional[str] = Field(
        default=None,
        alias="cat"
        )
    gprop: Optional[GoogleTrendsGPropType] = Field(
        default=None,
        alias="gprop"
        )


class GoogleTrendingParameters(BaseModel):
    """One request for the `google/trending` endpoint

    info: Real-Time Feed
        - Returns the current real-time trending searches from `Google
          Trends`

        - The `gateway docs` list no required input beyond the
          `X-Token` authentication header

    warning: Sync-Only Endpoint
        - `google/trending` can't be used through the
          `Async API`

    warning: `extra="allow"`
        The `pydantic` model permits arbitrary additional keys
        to cover undocumented fields the gateway may accept

    Example:
        ```python
        from scrape_do.plugins.google import GoogleTrendingParameters

        param = GoogleTrendingParameters()
        ```
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow"
        )


class GoogleSearchAiOverviewParameters(BaseModel):
    """One request for the `google/search/ai-overview` endpoint.

    abstract: Session-Based Follow-Up
        - `AI Overview` is a follow-up retrieval that requires a valid
          `session_key` returned by a prior `google/search`
          or `google/search/ai-mode` request

        - The `session_key` has a `90`-second TTL on the server side

        - An expired or invalid key returns `404 session not found`

    warning: Sync-Only Endpoint
        `google/search/ai-overview` can't be used through the
        `Async API`

    Attributes:
        session_key (str): Session token captured from the originating
            `google/search` (or `/ai-mode`) response
        hl (Optional[str]): Interface-language code
        gl (Optional[str]): Country-perspective code
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    session_key: str = Field(
        ...,
        alias="session_key"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )


class GoogleHotelsDetailParameters(BaseModel):
    """One request for the `google/hotels/detail` endpoint

    abstract: Two-Step Hotel Workflow
        - `detail_token` is acquired from a prior
          [`GoogleHotelsParameters`][scrape_do.plugins.google.GoogleHotelsParameters]
          listing response (`properties[].detail_token`) and must be
          passed unchanged

        - The same `check_in_date`, `check_out_date`, and `currency`
          values used on the listing call should be reused here so
          vendor pricing matches the original results

    warning: Sync-Only Endpoint
        `google/hotels/detail` can't be used through the
        `Async API`

    warning: Date Order
        - `check_out_date` **MUST** be strictly after `check_in_date`

        - Same-day or reversed ranges raise a `ValueError` at model
          construction time

    Attributes:
        detail_token (str): Opaque token returned by the listing
            response
        check_in_date (date): ISO-8601 check-in date (accepts a
            `datetime.date` or `"YYYY-MM-DD"` string)
        check_out_date (date): ISO-8601 check-out date (must be after
            `check_in_date`)
        currency (Optional[str]): ISO-4217 currency code (default
            `USD`)
        gl (Optional[str]): Country-perspective code (default `us`)
        hl (Optional[str]): Interface-language code (default `en`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    detail_token: str = Field(
        ...,
        alias="detail_token"
        )
    check_in_date: date = Field(
        ...,
        alias="check_in_date"
        )
    check_out_date: date = Field(
        ...,
        alias="check_out_date"
        )
    currency: Optional[str] = Field(
        default=None,
        alias="currency"
        )
    gl: Optional[str] = Field(
        default=None,
        alias="gl"
        )
    hl: Optional[str] = Field(
        default=None,
        alias="hl"
        )

    @model_validator(mode="after")
    def _validate_date_order(self) -> Self:
        """Enforces `check_out_date > check_in_date`

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If the check-out date is not strictly after the
                check-in date
        """
        if self.check_out_date <= self.check_in_date:
            raise ValueError(
                "google/hotels/detail 'check_out_date' must be strictly"
                " after 'check_in_date'"
                )
        return self
