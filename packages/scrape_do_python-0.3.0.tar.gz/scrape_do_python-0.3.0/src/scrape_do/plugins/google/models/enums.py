"""Type Aliases for `Scrape.do's Google Plugin` Literal Parameters

Every fixed-value field on a `Google Plugin` parameter model resolves to a
named `TypeAlias` declared here

abstract: Device / Sort
    - [`GoogleDeviceType`]
    [scrape_do.plugins.google.models.GoogleDeviceType]
    - [`GoogleReviewsSortByType`]
    [scrape_do.plugins.google.models.GoogleReviewsSortByType]
    - [`GoogleShoppingSortByType`]
    [scrape_do.plugins.google.models.GoogleShoppingSortByType]

abstract: Search Filters
    - [`GoogleSafeSearchType`]
    [scrape_do.plugins.google.models.GoogleSafeSearchType]
    - [`GoogleTimePeriodType`]
    [scrape_do.plugins.google.models.GoogleTimePeriodType]
    - [`GoogleNFPRType`]
    [scrape_do.plugins.google.models.GoogleNFPRType]

abstract: Flights
    - [`GoogleFlightsTripType`]
    [scrape_do.plugins.google.models.GoogleFlightsTripType]
    - [`GoogleFlightsTravelClassType`]
    [scrape_do.plugins.google.models.GoogleFlightsTravelClassType]
    - [`GoogleFlightsStopsType`]
    [scrape_do.plugins.google.models.GoogleFlightsStopsType]
    - [`GoogleFlightsSortByType`]
    [scrape_do.plugins.google.models.GoogleFlightsSortByType]

abstract: Hotels
    - [`GoogleHotelsSortByType`]
    [scrape_do.plugins.google.models.GoogleHotelsSortByType]
    - [`GoogleHotelsRatingType`]
    [scrape_do.plugins.google.models.GoogleHotelsRatingType]

abstract: News / Trends
    - [`GoogleNewsSortOrderType`]
    [scrape_do.plugins.google.models.GoogleNewsSortOrderType]
    - [`GoogleTrendsDataType`]
    [scrape_do.plugins.google.models.GoogleTrendsDataType]
    - [`GoogleTrendsGPropType`]
    [scrape_do.plugins.google.models.GoogleTrendsGPropType]
"""

from __future__ import annotations

from typing import Literal

from typing_extensions import TypeAlias


GoogleDeviceType: TypeAlias = Literal["desktop", "mobile"]
"""
Device class to emulate when fetching the `SERP` / `Shopping` page
"""

GoogleReviewsSortByType: TypeAlias = Literal[
  "newestFirst",
  "ratingHigh",
  "ratingLow"
  ]
"""
Sort order returned by `google/maps/reviews`
"""

GoogleShoppingSortByType: TypeAlias = Literal[0, 1, 2]
"""
Sort order for `google/shopping`

info: Mapping
    - `0` = Relevance
    - `1` = Acsending Price
    - `2` = Descending Price
"""

GoogleFlightsTripType: TypeAlias = Literal[1, 2]
"""
Trip type for `google/flights`

info: Mapping
    - `1` = Round Trip
    - `2` = One Way
"""

GoogleFlightsTravelClassType: TypeAlias = Literal[1, 2, 3, 4]
"""
Cabin class for `google/flights`

info: Mapping
    - `1` = Economy
    - `2` = Premium Economy
    - `3` = Business
    - `4` = Fist Class
"""

GoogleFlightsStopsType: TypeAlias = Literal[0, 1, 2, 3]
"""
Stop filter for `google/flights`

info: Mapping
    - `0` = Any
    - `1` = No Stops
    - `2` = 1 Stop Or Less
    - `3` = 2 Stops Or Less
"""

GoogleFlightsSortByType: TypeAlias = Literal[1, 2, 3, 4, 5, 6]
"""
Sort order for `google/flights`

info: Mapping
    - `1` = Top
    - `2` = Price
    - `3` = Departure
    - `4` = Arrival
    - `5` = Duration
    - `6` = Emissions
"""

GoogleHotelsSortByType: TypeAlias = Literal[3, 8, 13]
"""
Sort order for `google/hotels`

info: Mapping
    - `3` = Price
    - `8` = Rating
    - `13` = Most Reviewed
"""

GoogleHotelsRatingType: TypeAlias = Literal[7, 8, 9]
"""
Rating threshold for `google/hotels`

info: Mapping
    - `7` = `3.5+`
    - `8` = `4.0+`
    - `9` = `4.5+`
"""

GoogleNewsSortOrderType: TypeAlias = Literal["0", "1"]
"""
Sort order for `google/news` when `q` is the `driver`

info: Mapping
    - `"0"` = Relevance
    - `"1"` = Date
"""

GoogleTrendsDataType: TypeAlias = Literal[
    "TIMESERIES",
    "GEO_MAP_0",
    "RELATED_QUERIES",
    "RELATED_TOPICS"
    ]
"""
Trends widget to fetch for `google/trends`
"""

GoogleTrendsGPropType: TypeAlias = Literal[
    "web",
    "images",
    "news",
    "youtube",
    "froogle"
    ]
"""
Google property scope for `google/trends`
"""

GoogleSafeSearchType: TypeAlias = Literal["active", "off"]
"""
SafeSearch filter for `google/search`

info: Mapping
    - `"active"` = SafeSearch on (filters explicit content)
    - `"off"` = SafeSearch off
"""

GoogleTimePeriodType: TypeAlias = Literal[
    "last_hour",
    "last_day",
    "last_week",
    "last_month",
    "last_year"
    ]
"""
Time-range filter for `google/search`

tip: Usages
    - Filters organic results to a `rolling window` ending at the current
      moment

    - Combine with `start` for paginated time-filtered results
"""

GoogleNFPRType: TypeAlias = Literal[0, 1]
"""
Spell-correction toggle for `google/search`

info: Mapping
    - `0` = Spell correction enabled (default Google behaviour)
    - `1` = Spell correction disabled (returns "no fix for spelling")
"""
