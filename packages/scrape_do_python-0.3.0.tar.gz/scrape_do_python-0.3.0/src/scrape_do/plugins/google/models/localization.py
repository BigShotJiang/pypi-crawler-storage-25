"""Public localization constants for the `Scrape.do Google Plugin`

Attributes:
    GOOGLE_LANGUAGE_CODES (FrozenSet[str]): ISO 639-1 language codes accepted
        by the `hl` parameter across Google Plugins (`150+` entries)
    GOOGLE_COUNTRY_CODES (FrozenSet[str]): ISO 3166-1 alpha-2 country codes
        accepted by the `gl` parameter across Google Plugins (`240+` entries)
    GOOGLE_DOMAINS (FrozenSet[str]): Regional `google_domain` values accepted
        across Google plugins (`84` entries)
    GOOGLE_LANGUAGE_RESTRICT_VALUES (FrozenSet[str]): Strict
        `language-restrict` tokens accepted by the `lr` parameter on
        `google/search`. Format = `lang_<lowercase-iso-639-1>`.
        The Chinese variants use `lang_zh-CN` / `lang_zh-TW` (capital country
        segment)

warning: Validation Policy
    - These are **PUBLIC** frozensets meant for opt-in client-side validation

    - The endpoint parameter models keep `hl / gl / google_domain / lr` as
      plain `str` and **DO NOT** validate against these sets at construction
      time

    - `Scrape.do` may add new codes server-side faster than this SDK can ship
      them

    - Use them in your own pre-flight checks if you want strong feedback for
      typos

example: Validation Policy Example
    ```python
    from scrape_do.plugins.google.models.localization import (
        GOOGLE_LANGUAGE_CODES
        )
    assert "en" in GOOGLE_LANGUAGE_CODES
    ```

note: Source
    Reconstructed from the official [`Localization Reference`](https://scrape.
    do/documentation/google-scraper-api/localization/)
"""

from __future__ import annotations

from typing import FrozenSet


GOOGLE_LANGUAGE_CODES: FrozenSet[str] = frozenset({
    "af", "ak", "am", "ar", "az", "be", "bem", "bg", "bh", "bn", "br", "bs",
    "bt", "ca", "chr", "ckb", "co", "crs", "cs", "cy", "da", "de", "ee", "el",
    "en", "eo", "es", "et", "eu", "fa", "fi", "fo", "fr", "fy", "ga", "gaa",
    "gd", "gl", "gn", "gu", "ha", "haw", "he", "hi", "hr", "ht", "hu", "hy",
    "ia", "id", "ig", "is", "it", "iw", "ja", "jw", "ka", "kg", "kk", "kl",
    "km", "kn", "ko", "kri", "ku", "ky", "la", "lg", "ln", "lo", "loz", "lt",
    "lua", "lv", "mfe", "mg", "mi", "mk", "ml", "mn", "mo", "mr", "ms", "mt",
    "mv", "my", "ne", "nl", "nn", "no", "nso", "ny", "nyn", "oc", "om", "or",
    "pa", "pcm", "pl", "ps", "pt", "pt-br", "pt-pt", "qu", "rm", "rn", "ro",
    "ru", "rw", "sd", "sh", "si", "sk", "sl", "sn", "so", "sq", "sr", "sr-me",
    "st", "su", "sv", "sw", "ta", "te", "tg", "th", "ti", "tk", "tl", "tn",
    "to", "tr", "tt", "tum", "tw", "ug", "uk", "ur", "uz", "vi", "vu", "wo",
    "ws", "xh", "yi", "yo", "zh-cn", "zh-tw", "zu"
    })

GOOGLE_COUNTRY_CODES: FrozenSet[str] = frozenset({
    # Americas
    "ar", "as", "bo", "br", "ca", "cl", "co", "cr", "cu", "dm", "do",
    "ec", "fk", "gd", "gf", "gp", "gt", "gy", "hn", "ht", "jm", "mq",
    "mx", "ni", "pa", "pe", "pr", "py", "sr", "sv", "tt", "um", "us",
    "uy", "ve", "vg", "vi",
    # Europe
    "ad", "al", "at", "ba", "be", "bg", "by", "ch", "cz", "de", "dk",
    "ee", "es", "fi", "fo", "fr", "gb", "ge", "gg", "gi", "gl", "gr",
    "hr", "hu", "ie", "im", "is", "it", "je", "li", "lt", "lu", "lv",
    "mc", "md", "me", "mk", "mt", "nl", "no", "pl", "pt", "ro", "rs",
    "ru", "sj", "sk", "si", "sm", "se", "ua", "uk", "va",
    # Asia / Pacific
    "af", "as", "au", "az", "bd", "bn", "cc", "ck", "cn", "cx", "fj",
    "fm", "gu", "hk", "id", "in", "jp", "kg", "kh", "ki", "kp", "kr",
    "kz", "la", "lk", "mh", "mm", "mo", "mp", "my", "nf", "np", "nr",
    "nu", "nz", "pf", "pg", "ph", "pk", "pn", "pw", "sb", "sg", "th",
    "tk", "to", "tv", "tw", "uz", "vn", "vu", "ws",
    # Middle East & Africa
    "ae", "bh", "cd", "cf", "cg", "ci", "cm", "dj", "dz", "eg", "er",
    "et", "ga", "gh", "gm", "gn", "gq", "gw", "il", "iq", "ir", "jo",
    "ke", "km", "kn", "kw", "lb", "lr", "ls", "ly", "ma", "mg", "ml",
    "mr", "mu", "mw", "mz", "na", "ne", "ng", "om", "ps", "qa", "re",
    "rw", "sa", "sc", "sd", "sh", "sl", "sn", "so", "st", "sy", "sz",
    "td", "tg", "tn", "tr", "tz", "ug", "ye", "yt", "za", "zm", "zw",
    })


GOOGLE_DOMAINS: FrozenSet[str] = frozenset({
    # Americas
    "google.com", "google.ca", "google.com.br", "google.com.mx",
    "google.com.ar", "google.cl", "google.com.co", "google.com.pe",
    # Europe
    "google.co.uk", "google.de", "google.fr", "google.es", "google.it",
    "google.nl", "google.be", "google.at", "google.ch", "google.se",
    "google.no", "google.dk", "google.fi", "google.pl", "google.pt",
    "google.com.tr", "google.ie", "google.com.ua", "google.ro",
    "google.gr", "google.hu", "google.cz", "google.sk", "google.bg",
    "google.hr", "google.rs", "google.si", "google.lt", "google.lv",
    "google.ee", "google.ru",
    # Asia / Pacific
    "google.co.jp", "google.co.kr", "google.com.au", "google.co.nz",
    "google.co.in", "google.co.id", "google.co.th", "google.com.sg",
    "google.com.my", "google.com.ph", "google.com.vn", "google.com.tw",
    "google.com.hk", "google.com.pk", "google.com.bd", "google.com.np",
    "google.lk", "google.com.mm", "google.com.kh", "google.la",
    # Middle East & Africa
    "google.co.za", "google.com.eg", "google.com.sa", "google.ae",
    "google.co.il", "google.com.ng", "google.co.ke", "google.com.gh",
    "google.com.et", "google.co.tz", "google.co.ug", "google.com.ly",
    "google.dz", "google.co.ma", "google.tn", "google.com.qa",
    "google.com.kw", "google.com.bh", "google.com.om", "google.jo",
    "google.com.lb", "google.iq",
    # Central Asia & Caucasus
    "google.az", "google.kz", "google.ge",
    })

GOOGLE_LANGUAGE_RESTRICT_VALUES: FrozenSet[str] = frozenset({
    "lang_ar", "lang_bg", "lang_ca", "lang_cs", "lang_da", "lang_de",
    "lang_el", "lang_en", "lang_es", "lang_et", "lang_fi", "lang_fr",
    "lang_hr", "lang_hu", "lang_id", "lang_is", "lang_it", "lang_iw",
    "lang_ja", "lang_ko", "lang_lt", "lang_lv", "lang_nl", "lang_no",
    "lang_pl", "lang_pt", "lang_ro", "lang_ru", "lang_sk", "lang_sl",
    "lang_sr", "lang_sv", "lang_tr", "lang_zh-CN", "lang_zh-TW",
    })
