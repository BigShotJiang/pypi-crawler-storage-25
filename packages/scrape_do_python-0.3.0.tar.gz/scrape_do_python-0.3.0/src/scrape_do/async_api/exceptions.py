"""Exception hierarchy and structured error envelope for the
`Scrape.do Async API` surface

Defines the typed exceptions raised by the `ScrapeDoAsyncAPIClient`,
`AsyncScrapeDoAsyncAPIClient`, and polling helpers. In addition, defines
[`AsyncScrapeDoErrorMessage`]
[scrape_do.async_api.exceptions.AsyncScrapeDoErrorMessage], a
`pydantic` model wrapping the `{Error, Code}` JSON body returned by
`q.scrape.do` on non-2xx responses
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Optional

import httpx
from pydantic import BaseModel, ConfigDict, Field, ValidationError

from ..exceptions import ScrapeDoError

if TYPE_CHECKING:
    from .models.response import JobDetails, TaskDetails


class AsyncScrapeDoErrorMessage(BaseModel):
    """Structured representation of a `Scrape.do Async API` error body

    warning: Tolerant Parsing
        - Server-side additions are silently ignored (`extra="ignore"`)

        - Missing fields fall back to their defaults

    warning: Different From The Sync Envelope
        - The synchronous gateway's
        [`ScrapeDoJSONErrorMessage`][scrape_do.exceptions.ScrapeDoJSONErrorMessage]
        uses a richer schema (`StatusCode`, `Message`, `PossibleCauses`,
        `ErrorType`, etc.)

        - `Error` carries the human-readable description, `Code` carries the
          HTTP status code

        - Both models follow the same `try_from_response` parsing contract so
          callers can route either envelope to typed exceptions without
          special-casing

    Attributes:
        error (Optional[str]): human-readable description of what went wrong
        code (Optional[int]): HTTP status code echoed in the body
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    error: Optional[str] = Field(
        default=None,
        alias="Error"
        )
    code: Optional[int] = Field(
        default=None,
        alias="Code"
        )

    @classmethod
    def try_from_response(
        cls,
        raw_resp: httpx.Response,
    ) -> Optional[AsyncScrapeDoErrorMessage]:
        """Parse a `Scrape.do Async API` error envelope, or return `None`

        abstract: Return Value
            - If `raw_resp` has a parsable JSON body containing at least one
              `Error` and `Code` **AND** the `pydantic` validation of this
              model succeeds, this method returns a validated
              `AsyncScrapeDoErrorMessage` instance

            - Otherwise, it returns `None`

            - This method never raises

        Args:
            raw_resp: The raw `httpx.Response` object received from
                `q.scrape.do`

        Returns:
            An `AsyncScrapeDoErrorMessage` instance when the body parses
                as a JSON dict containing at least one of `Error` /
                `Code` and `pydantic` validation succeeds. `None`
                otherwise. Never raises
        """
        try:
            data = raw_resp.json()
        except ValueError:
            return None

        if not isinstance(data, dict):
            return None

        if "Error" not in data and "Code" not in data:
            return None

        try:
            return cls.model_validate(data)
        except ValidationError:
            return None

    def __str__(self) -> str:
        """Human-readable rendering for inclusion in exception messages

        Returns:
            A multi-line string with both fields labeled
        """
        error = f"Error : {self.error or 'Unknown'}"
        code = f"Code : {self.code if self.code is not None else 'Unknown'}"
        return f"Async API Error\n{error}\n{code}"


class AsyncAPIError(ScrapeDoError):
    """Base exception for every error raised by the `Scrape.do Async API`
    surface

    info: Routing
        - Catching this class guarantees every Async-API-originated failure is
          handled

        - It inherits from [`ScrapeDoError`]
        [scrape_do.exceptions.ScrapeDoError], so a `except ScrapeDoError`
        block still catches it
    """


class AsyncAPIResponseError(AsyncAPIError):
    """Base for non-`2xx` HTTP responses returned by `q.scrape.do`

    abstract: Error Parsing
        - Parses the response body via
          [`AsyncScrapeDoErrorMessage.try_from_response`]
        [scrape_do.async_api.exceptions.AsyncScrapeDoErrorMessage.try_from_response]
          to populate `self.message`

        - Falls back to an `Unknown API Error` rendering when the body isn't a
          recognizable Async API envelope

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """

    def __init__(self, raw_response: httpx.Response):
        self.raw_response = raw_response
        self.raw_status_code = raw_response.status_code
        e_info = AsyncScrapeDoErrorMessage.try_from_response(raw_response)

        self.error_info: Optional[AsyncScrapeDoErrorMessage] = e_info
        if self.error_info is not None:
            self.message = str(self.error_info)
        else:
            self.message = (
                f"Unknown Async API Error\n"
                f"Status: {raw_response.status_code}\n"
                f"Body: {raw_response.text}"
                )

        super().__init__(self.message)


class AsyncAPIUnparsableResponseError(AsyncAPIError):
    """Raised when the SDK can't parse a successful response sent by
    `q.scrape.do`

    This can either happen because the response sent by `q.scrape.do` is not
    parsable JSON, or because one of the endpoints returned an unexpected JSON
    schema and caused one of the custom `pydantic` response models to raise a
    `ValidationError`

    tip: Additional Exception Information
        This exception is always chained to either a [`JSONDecodeError`]
        [json.JSONDecodeError] or a
        [`ValidationError`][pydantic_core._pydantic_core.ValidationError]
        exception to provide additional information on what caused the error

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
    """

    def __init__(
        self,
        message: str,
        raw_response: httpx.Response
    ) -> None:
        self.raw_response = raw_response

        super().__init__(message)


class AsyncAPIBadRequestError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns `HTTP 400`

    Indicates the job request was rejected at schema validation

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class AsyncAPIAuthError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns `HTTP 401`

    Indicates the `X-Token` header is missing or invalid

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class AsyncAPINotFoundError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns `HTTP 404`

    Indicates the requested `JobID` / `TaskID` does not exist or has
    already expired

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class AsyncAPINotAcceptableError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns `HTTP 406`

    Indicates the request is structurally valid but cannot be served in
    the current state (e.g. canceling a job that already completed)

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class AsyncAPIRateLimitError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns `HTTP 429`

    Indicates the account has exhausted its Async-API concurrency
    allowance (roughly `30%` of the main plan concurrency)

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class AsyncAPIServerError(AsyncAPIResponseError):
    """Raised when `q.scrape.do` returns a `5xx` status code

    Indicates a gateway or proxy pool failure on `Scrape.do's` side

    Attributes:
        raw_response (httpx.Response): The raw `httpx.Response` object
            received from `q.scrape.do`
        raw_status_code (int): The HTTP status code (shortcut for
            `raw_response.status_code`)
        error_info (Optional[AsyncScrapeDoErrorMessage]): Parsed envelope
            or `None` when the body wasn't a recognizable Async API
            error
    """


class JobLifecycleError(AsyncAPIError):
    """Base for terminal-state errors surfaced by polling helpers

    Raised by `wait_for_job` and `submit_and_wait` when the job reaches
    a terminal status the caller didn't expect

    Attributes:
        job (JobDetails): The `JobDetails` snapshot at the terminal
            status that triggered this error
    """

    def __init__(self, job: JobDetails, message: str):
        self.job = job
        super().__init__(message)


class JobFailedError(JobLifecycleError):
    """Raised when a polled job reaches terminal status `error`

    Attributes:
        job (JobDetails): The `JobDetails` snapshot at the terminal
            status that triggered this error

    info: Per-Task Errors
        After the polling helper raises, callers can still inspect each
        task's `error_message` via the corresponding
        [`TaskDetails`][scrape_do.async_api.models.response.TaskDetails]
    """

    def __init__(self, job: JobDetails):
        super().__init__(
            job,
            f"Async API job {job.job_id} terminated with status `error`",
            )


class JobCanceledError(JobLifecycleError):
    """Raised when a polled job reaches terminal status `canceled`

    Attributes:
        job (JobDetails): The `JobDetails` snapshot at the terminal
            status that triggered this error
    """

    def __init__(self, job: JobDetails):
        super().__init__(
            job,
            f"Async API job {job.job_id} was canceled",
            )


class TaskLifecycleError(AsyncAPIError):
    """Base for terminal-state errors surfaced by `TaskDetails`

    Raised by [`TaskDetails.raise_for_status`]
    [scrape_do.async_api.models.response.TaskDetails.raise_for_status]
    when the task has reached a terminal failure status the caller
    didn't expect

    Includes the `task.error_message` in the exception's error message if it
    exists.

    Attributes:
        task (TaskDetails): The `TaskDetails` snapshot at the terminal
            status that triggered this error
    """

    def __init__(self, task: TaskDetails, message: str):
        self.task = task

        if task.error_message is not None:
            message += f"| Error Message: {task.error_message}"

        super().__init__(message)


class TaskFailedError(TaskLifecycleError):
    """Raised when a `TaskDetails` snapshot has terminal status `error`

    Attributes:
        task (TaskDetails): The `TaskDetails` snapshot at the terminal
            status that triggered this error
    """

    def __init__(self, task: TaskDetails):
        super().__init__(
            task,
            f"Async API task {task.task_id} terminated with status"
            f" `error`",
            )


class TaskCanceledError(TaskLifecycleError):
    """Raised when a `TaskDetails` snapshot has terminal status
    `canceled`

    Attributes:
        task (TaskDetails): The `TaskDetails` snapshot at the terminal
            status that triggered this error
    """

    def __init__(self, task: TaskDetails):
        super().__init__(
            task,
            f"Async API task {task.task_id} was canceled",
            )


class JobTimeoutError(AsyncAPIError):
    """Raised when the `PollingStrategy.__call__`, or a user-defined
    `PollingFunction` has chosen to stop polling for a job before it reached
    a terminal status

    Attributes:
        job_id (str): The `JobID` that was being polled
        last_status (str): The last non-terminal status observed before
            timing out
        elapsed (float): Total seconds spent polling before timeout
        attempts (int): Number of `get_job` calls made before timeout
    """

    def __init__(
        self,
        job_id: str,
        last_status: str,
        elapsed: float,
        attempts: int,
    ):
        self.job_id = job_id
        self.last_status = last_status
        self.elapsed = elapsed
        self.attempts = attempts
        super().__init__(
            f"Polling for Async API job {job_id} timed out after"
            f" {attempts} attempt(s) / {elapsed:.2f}s"
            f" (last status: {last_status!r})"
            )
