"""`Scrape.do Async API` Top-Level Sub-Package

Houses the public surface for the
[`Scrape.do Async API`](https://scrape.do/documentation/async-api/) on
`q.scrape.do`

abstract: Modules
    - [`client`][scrape_do.async_api.client] = Synchronous
      [`ScrapeDoAsyncAPIClient`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient] backed by
      [`httpx.Client`][]

    - [`async_client`][scrape_do.async_api.async_client] =
      Asynchronous [`AsyncScrapeDoAsyncAPIClient`]
    [scrape_do.async_api.async_client.AsyncScrapeDoAsyncAPIClient]
      backed by [`httpx.AsyncClient`][]

    - [`polling`][scrape_do.async_api.polling] = Configurable
      [`PollingStrategy`][scrape_do.async_api.polling.PollingStrategy]
      and [`PollingFunction`]
    [scrape_do.async_api.polling.PollingFunction] type alias for
      bespoke backoff schedules

    - [`exceptions`][scrape_do.async_api.exceptions] = Typed exception
      hierarchy and the [`AsyncScrapeDoErrorMessage`]
    [scrape_do.async_api.exceptions.AsyncScrapeDoErrorMessage] error-body
      envelope

    - [`models`][scrape_do.async_api.models] = Request / response
      `pydantic` models plus the [`AsyncPlugin`]
    [scrape_do.async_api.models.plugins.AsyncPlugin] discriminated
      union

"""

from .models import (
    RENDER_PARAMETER_FIELDS,
    AmazonOfferListingAsyncPlugin,
    AmazonPdpAsyncPlugin,
    AmazonSearchAsyncPlugin,
    AsyncPlugin,
    CancelJobResponse,
    GoogleFlightsAsyncPlugin,
    GoogleHotelsAsyncPlugin,
    GoogleMapsPlaceAsyncPlugin,
    GoogleMapsReviewsAsyncPlugin,
    GoogleMapsSearchAsyncPlugin,
    GoogleNewsAsyncPlugin,
    GoogleSearchAiModeAsyncPlugin,
    GoogleSearchAsyncPlugin,
    GoogleShoppingAsyncPlugin,
    GoogleTrendsAsyncPlugin,
    JobCreationRequest,
    JobCreationRequestDict,
    JobCreationResponse,
    JobDetails,
    JobListQueryParameters,
    JobListQueryParametersDict,
    JobListQuerySortType,
    JobResult,
    JobsListResponse,
    JobStatus,
    LowesStoreAsyncPlugin,
    LowesStoreParameters,
    RenderParameters,
    TaskDetails,
    TERMINAL_STATUSES,
    UndetailedTaskResponse,
    UserInformation,
    WalmartStoreAsyncPlugin,
    WalmartStoreParameters,
    WebhookPayload,
)
from .exceptions import (
    AsyncAPIAuthError,
    AsyncAPIBadRequestError,
    AsyncAPIError,
    AsyncAPINotAcceptableError,
    AsyncAPINotFoundError,
    AsyncAPIRateLimitError,
    AsyncAPIResponseError,
    AsyncAPIServerError,
    AsyncAPIUnparsableResponseError,
    AsyncScrapeDoErrorMessage,
    JobCanceledError,
    JobFailedError,
    JobLifecycleError,
    JobTimeoutError,
    TaskCanceledError,
    TaskFailedError,
    TaskLifecycleError,
)
from .client import (
    AsyncAPIEventHooks,
    ScrapeDoAsyncAPIClient
    )
from .async_client import (
    AsyncAPIAsyncEventHooks,
    AsyncScrapeDoAsyncAPIClient,
    )

from .polling import PollingStrategy, PollingFunction


__all__ = [
  # Async API
  "AsyncAPIAsyncEventHooks",
  "AsyncAPIAuthError",
  "AsyncAPIBadRequestError",
  "AsyncAPIError",
  "AsyncAPIEventHooks",
  "AsyncAPINotAcceptableError",
  "AsyncAPINotFoundError",
  "AsyncAPIRateLimitError",
  "AsyncAPIResponseError",
  "AsyncAPIServerError",
  "AsyncAPIUnparsableResponseError",
  "AsyncPlugin",
  "AsyncScrapeDoAsyncAPIClient",
  "AsyncScrapeDoErrorMessage",
  "CancelJobResponse",
  "JobCanceledError",
  "JobCreationRequest",
  "JobCreationRequestDict",
  "JobCreationResponse",
  "JobDetails",
  "JobFailedError",
  "JobLifecycleError",
  "JobListQueryParameters",
  "JobListQueryParametersDict",
  "JobListQuerySortType",
  "JobResult",
  "JobStatus",
  "JobTimeoutError",
  "JobsListResponse",
  "PollingFunction",
  "PollingStrategy",
  "RENDER_PARAMETER_FIELDS",
  "ScrapeDoAsyncAPIClient",
  "RenderParameters",
  "TERMINAL_STATUSES",
  "TaskCanceledError",
  "TaskDetails",
  "TaskFailedError",
  "TaskLifecycleError",
  "UndetailedTaskResponse",
  "UserInformation",
  "WebhookPayload",
  # Plugin Models
  "AmazonOfferListingAsyncPlugin",
  "AmazonPdpAsyncPlugin",
  "AmazonSearchAsyncPlugin",
  "GoogleFlightsAsyncPlugin",
  "GoogleHotelsAsyncPlugin",
  "GoogleMapsPlaceAsyncPlugin",
  "GoogleMapsReviewsAsyncPlugin",
  "GoogleMapsSearchAsyncPlugin",
  "GoogleNewsAsyncPlugin",
  "GoogleSearchAiModeAsyncPlugin",
  "GoogleSearchAsyncPlugin",
  "GoogleShoppingAsyncPlugin",
  "GoogleTrendsAsyncPlugin",
  "LowesStoreAsyncPlugin",
  "LowesStoreParameters",
  "WalmartStoreAsyncPlugin",
  "WalmartStoreParameters",
  ]
