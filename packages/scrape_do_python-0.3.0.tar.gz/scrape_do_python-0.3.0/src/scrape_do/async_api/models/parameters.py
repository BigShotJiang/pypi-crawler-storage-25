"""Outbound request shapes for the `Scrape.do Async API`

Defines the `pydantic` models the `ScrapeDoAsyncAPIClient` uses to
construct the JSON bodies and query strings for `q.scrape.do`

info: Validation Parity
    Every cross-field rule enforced on
    [`RequestParameters`][scrape_do.models.parameters.RequestParameters]
    is mirrored here via the shared helpers in
    [`scrape_do.models.validators`][scrape_do.models.validators]
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Type,
    TypedDict,
    Union,
    FrozenSet
    )

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    HttpUrl,
    field_serializer,
    field_validator,
    model_validator,
    ValidationInfo
)
from typing_extensions import Self

from ...models.browser_actions import BrowserAction
from ...models.enums import (
    DeviceType,
    HttpMethod,
    OutputType,
    RegionCodeType,
    WaitUntilType,
)
from ...models.validators import (
    check_geo_code,
    check_geo_exclusion,
    check_play_with_browser_vs_particular_screenshot,
    check_regional_requires_super,
    check_return_json_dependencies,
    check_screenshot_blocks_resources,
    check_screenshot_mutual_exclusion,
)

from ..models.plugins import AsyncPlugin
from .enums import JobListQuerySortType, JobStatus


# --------------------------------------------------------------------
# Kwargs TypedDict (kwargs-based construction on the client side)
# --------------------------------------------------------------------


class JobCreationRequestDict(TypedDict, total=False):
    """Strict IDE autocomplete + static type-checking for `**kwargs`
    dictionaries that build a [`JobCreationRequest`]
    [scrape_do.async_api.models.parameters.JobCreationRequest] model

    tip: Usage
        - Consumed by the client's smart-routing kwargs path

        - Callers can use either an explicit `JobCreationRequest` instance or
          unpacked kwargs

    warning: Flat `Render` Fields
        - Every field on the nested [`RenderParameters`]
        [scrape_do.async_api.models.parameters.RenderParameters]
        sub-model is exposed at the top level here

        - When the client receives any of those keys it auto-builds a
        `RenderParameters` instance and assigns it to
        [`JobCreationRequest.render`][scrape_do.async_api.models.parameters.JobCreationRequest]
    """

    # --- Top-Level Fields ---
    targets: Optional[List[Union[str, HttpUrl]]]
    """URLs to scrape (mutually exclusive with `plugin`)"""

    method: Optional[HttpMethod]
    """HTTP method for each task (default `GET`)"""

    body: Optional[str]
    """HTTP request body for `POST` / `PUT` / `PATCH`"""

    headers: Optional[Dict[str, str]]
    """Custom HTTP headers"""

    geo_code: Optional[str]
    """ISO 3166-1 alpha-2 country code"""

    regional_geo_code: Optional[RegionCodeType]
    """Regional code (requires `super=True`)"""

    super: Optional[bool]
    """Use residential / mobile proxies"""

    forward_headers: Optional[bool]
    """Forward only the provided headers without merging Scrape.do defaults"""

    session_id: Optional[int]
    """Sticky session ID (`0`-`1000000`)"""

    device: Optional[DeviceType]
    """Device class to emulate (`desktop`, `mobile`, `tablet`)"""

    set_cookies: Optional[str]
    """Cookies to attach to each task (cannot be combined with `headers`)"""

    timeout: Optional[int]
    """Total request timeout in milliseconds (`5000`-`120000`)"""

    retry_timeout: Optional[int]
    """
    Per-curl retry timeout in milliseconds (`5000`-`55000`).
    (mutually exclusive with any render-related field)
    """

    disable_retry: Optional[bool]
    """Disable Scrape.do's internal retry on non-2xx target responses"""

    transparent_response: Optional[bool]
    """
    Forward the target's actual status code instead of wrapping non-2xx in a
    `502`
    """
    disable_redirection: Optional[bool]
    """Disable following redirects"""

    output: Optional[OutputType]
    """Output format (`raw` or `markdown`) (default `raw`)"""

    webhook_url: Optional[Union[str, HttpUrl]]
    """Webhook URL to deliver results to"""

    webhook_headers: Optional[Dict[str, str]]
    """Additional headers to send with the webhook delivery"""

    plugin: Optional[AsyncPlugin]
    """Plugin job spec (mutually exclusive with `targets`)"""

    # --- Render Fields (flat — auto-collected into RenderParameters) ---
    block_resources: Optional[bool]
    """
    Render: Block loading of resources (cannot combine with
    `play_with_browser` or screenshots)
    """

    wait_until: Optional[WaitUntilType]
    """Render: Event to wait for during page load"""

    custom_wait: Optional[int]
    """Render: Custom wait time in milliseconds (`0`-`35000`)"""

    wait_selector: Optional[str]
    """Render: CSS selector to wait for"""

    play_with_browser: Optional[List[BrowserAction]]
    """Render: Sequence of browser actions to run after the page loads"""

    return_json: Optional[bool]
    """
    Render: Return the response as a JSON envelope rather than raw target body
    """

    show_websocket_requests: Optional[bool]
    """Render: Include captured WebSocket requests (requires `return_json`)"""

    show_frames: Optional[bool]
    """Render: Include iframe metadata (requires `return_json`)"""

    screenshot: Optional[bool]
    """Render: Capture a screenshot of the visible viewport"""

    full_screenshot: Optional[bool]
    """Render: Capture a screenshot of the entire scrollable page"""

    particular_screenshot: Optional[str]
    """Render: CSS selector targeting a specific element to screenshot"""

    # --- Pre-Built Override ---
    render: Optional[RenderParameters]
    """
    Pre-built `RenderParameters` model. When set, any flat `RenderParameters`
    field is ignored
    """


RENDER_PARAMETER_FIELDS: FrozenSet[str] = frozenset({
    "block_resources",
    "wait_until",
    "custom_wait",
    "wait_selector",
    "play_with_browser",
    "return_json",
    "show_websocket_requests",
    "show_frames",
    "screenshot",
    "full_screenshot",
    "particular_screenshot",
    })
"""
Set of field names in [`JobCreationRequestDict`]
[scrape_do.async_api.models.parameters.JobCreationRequestDict] that
belong to the nested [`RenderParameters`]
[scrape_do.async_api.models.parameters.RenderParameters] sub-model

tip: Usage
    Consumed by the client's smart-routing kwargs path to separate
    render-specific fields from the rest of the
    `JobCreationRequest` body
"""


# --------------------------------------------------------------------
# Render Sub-Model
# --------------------------------------------------------------------


class RenderParameters(BaseModel):
    """Nested `Render` object on a `Scrape.do Async API` job creation
    payload

    info: Source
        Field list and bounds come from the official TypeScript
        definition for `POST /api/v1/jobs`

    Attributes:
        block_resources (Optional[bool]): Block loading of resources
            (cannot combine with `play_with_browser` or screenshots)
        wait_until (Optional[WaitUntilType]): Event to wait for during
            page load (`domcontentloaded`, `networkidle0`,
            `networkidle2`, `load`)
        custom_wait (Optional[int]): Custom wait time in milliseconds
            (`0`-`35000`)
        wait_selector (Optional[str]): CSS selector to wait for
        play_with_browser (Optional[List[BrowserAction]]): Sequence of
            browser actions to run after the page loads
        return_json (Optional[bool]): Return the response as a JSON
            envelope rather than the raw target body
        show_websocket_requests (Optional[bool]): Include captured
            WebSocket requests in the response (requires `return_json`)
        show_frames (Optional[bool]): Include iframe metadata in the
            response (requires `return_json`)
        screenshot (Optional[bool]): Capture a screenshot of the
            visible viewport
        full_screenshot (Optional[bool]): Capture a screenshot of the
            entire scrollable page
        particular_screenshot (Optional[str]): CSS selector targeting
            a specific element to screenshot
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    block_resources: Optional[bool] = Field(
        default=None,
        alias="BlockResources"
        )
    wait_until: Optional[WaitUntilType] = Field(
        default=None,
        alias="WaitUntil"
        )
    custom_wait: Optional[int] = Field(
        default=None,
        alias="CustomWait",
        ge=0,
        le=35000
        )
    wait_selector: Optional[str] = Field(
        default=None,
        alias="WaitSelector"
        )
    play_with_browser: Optional[List[BrowserAction]] = Field(
        default=None,
        alias="PlayWithBrowser"
        )
    return_json: Optional[bool] = Field(
        default=None,
        alias="ReturnJSON"
        )
    show_websocket_requests: Optional[bool] = Field(
        default=None,
        alias="ShowWebsocketRequests"
        )
    show_frames: Optional[bool] = Field(
        default=None,
        alias="ShowFrames"
        )
    screenshot: Optional[bool] = Field(
        default=None,
        alias="Screenshot"
        )
    full_screenshot: Optional[bool] = Field(
        default=None,
        alias="FullScreenshot"
        )
    particular_screenshot: Optional[str] = Field(
        default=None,
        alias="ParticularScreenshot"
        )

    @model_validator(mode="after")
    def _validate_render_compatibility(self) -> Self:
        """Cross-validates the `screenshot / return-json / play-with-browser`
        dependencies inside the `Render` object

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If any of the documented mutual-exclusion or
                dependency rules is violated
        """
        check_screenshot_mutual_exclusion(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            )
        check_screenshot_blocks_resources(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            self.block_resources,
            )
        check_return_json_dependencies(
            self.screenshot,
            self.full_screenshot,
            self.particular_screenshot,
            self.show_frames,
            self.show_websocket_requests,
            self.return_json,
            )
        check_play_with_browser_vs_particular_screenshot(
            self.play_with_browser,
            self.particular_screenshot,
            )
        return self


# --------------------------------------------------------------------
# Job Creation Body
# --------------------------------------------------------------------


class JobCreationRequest(BaseModel):
    """Body for `POST /api/v1/jobs`

    abstract: Driver
        - Exactly **ONE** of `targets` or `plugin` must be set

        - Setting both or neither raises `ValueError` at construction time

    warning: Set Cookies vs Headers
        - `set_cookies` cannot be combined with `headers` per the official
          TypeScript definition

        - Setting both raises `ValueError`

    warning: Plugin Geocode
        - When `plugin.params` includes any entry with a `geocode` field
          set, the top-level `geo_code` **MUST** be `None`

        - The per-task geocode wins server-side and a top-level value would
          conflict

    Attributes:
        targets (Optional[List[HttpUrl]]): URLs to scrape (mutually
            exclusive with `plugin`)
        method (Optional[HttpMethod]): HTTP method for each task
            (default `GET`)
        body (Optional[str]): HTTP request body for `POST` / `PUT` /
            `PATCH`
        headers (Optional[Dict[str, str]]): Custom HTTP headers
        geo_code (Optional[str]): ISO 3166-1 alpha-2 country code
        regional_geo_code (Optional[RegionCodeType]): Regional code
            (requires `super=True`)
        super (Optional[bool]): Use residential / mobile proxies
        forward_headers (Optional[bool]): Forward only the provided
            headers without merging Scrape.do defaults
        session_id (Optional[int]): Sticky session ID (`0`-`1000000`).
            Serialized to a string on outbound JSON to match the
            documented wire shape
        device (Optional[DeviceType]): Device class to emulate
            (`desktop`, `mobile`, `tablet`)
        set_cookies (Optional[str]): Cookies to attach to each task
            (cannot be combined with `headers`)
        timeout (Optional[int]): Total request timeout in
            milliseconds (`5000`-`120000`)
        retry_timeout (Optional[int]): Per-curl retry timeout in
            milliseconds (`5000`-`55000`; mutually exclusive with
            `render`)
        disable_retry (Optional[bool]): Disable Scrape.do's internal
            retry on non-2xx target responses
        transparent_response (Optional[bool]): Forward the target's
            actual status code instead of wrapping non-2xx in a `502`
        disable_redirection (Optional[bool]): Disable following
            redirects
        output (Optional[OutputType]): Output format (`raw` or
            `markdown`; default `raw`)
        render (Optional[RenderParameters]): Browser rendering options
        webhook_url (Optional[HttpUrl]): Webhook URL to deliver results
            to
        webhook_headers (Optional[Dict[str, str]]): Additional headers
            to send with the webhook delivery
        plugin (Optional[AsyncPlugin]): Plugin job spec (mutually
            exclusive with `targets`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    targets: Optional[List[HttpUrl]] = Field(
        default=None,
        alias="Targets"
        )
    method: Optional[HttpMethod] = Field(
        default=None,
        alias="Method"
        )
    body: Optional[str] = Field(
        default=None,
        alias="Body"
        )
    headers: Optional[Dict[str, str]] = Field(
        default=None,
        alias="Headers"
        )
    geo_code: Optional[str] = Field(
        default=None,
        alias="GeoCode"
        )
    regional_geo_code: Optional[RegionCodeType] = Field(
        default=None,
        alias="RegionalGeoCode"
        )
    super: Optional[bool] = Field(
        default=None,
        alias="Super"
        )
    forward_headers: Optional[bool] = Field(
        default=None,
        alias="ForwardHeaders"
        )
    session_id: Optional[int] = Field(
        default=None,
        alias="SessionID",
        ge=0,
        le=1000000
        )
    device: Optional[DeviceType] = Field(
        default=None,
        alias="Device"
        )
    set_cookies: Optional[str] = Field(
        default=None,
        alias="SetCookies"
        )
    timeout: Optional[int] = Field(
        default=None,
        alias="Timeout",
        ge=5000,
        le=120000
        )
    retry_timeout: Optional[int] = Field(
        default=None,
        alias="RetryTimeout",
        ge=5000,
        le=55000
        )
    disable_retry: Optional[bool] = Field(
        default=None,
        alias="DisableRetry"
        )
    transparent_response: Optional[bool] = Field(
        default=None,
        alias="TransparentResponse"
        )
    disable_redirection: Optional[bool] = Field(
        default=None,
        alias="DisableRedirection"
        )
    output: Optional[OutputType] = Field(
        default=None,
        alias="Output"
        )
    render: Optional[RenderParameters] = Field(
        default=None,
        alias="Render"
        )
    webhook_url: Optional[HttpUrl] = Field(
        default=None,
        alias="WebhookURL"
        )
    webhook_headers: Optional[Dict[str, str]] = Field(
        default=None,
        alias="WebhookHeaders"
        )
    plugin: Optional[AsyncPlugin] = Field(
        default=None,
        alias="Plugin"
        )

    @field_validator("geo_code")
    @classmethod
    def _validate_geo_code(
        cls: Type[Self],
        v: Optional[str],
        info: ValidationInfo
    ) -> Optional[str]:
        """Delegates to
        [`check_geo_code`][scrape_do.models.validators.check_geo_code]

        Args:
            v (Optional[str]): The value provided to the `geo_code` argument
            info (ValidationInfo): The data already validated for the model so
                far

        Returns:
            The validated (lowercased) `geo_code`

        Raises:
            ValueError: If the country code is not supported by the
                selected proxy tier
        """
        return check_geo_code(v, super_set=info.data.get("super", False))

    @field_serializer("session_id", when_used="json")
    def _serialize_session_id(
        self,
        value: Optional[int]
    ) -> Optional[str]:
        """Coerces `session_id` to a string on outbound JSON

        abstract: String Coercion
            - The Async API's TypeScript definition documents `SessionID` as a
              `string`

            - The server still expects an integer between `0-1000000` in
              string form, so the Python type stays `int` and this serializer
              coerces it into a string

        Args:
            value (Optional[int]): The value provided to `session_id` during
                initialization

        Returns:
            The coerced `session_id` string, or `None` if `session_id` was
                `None`
        """
        return None if value is None else str(value)

    @model_validator(mode="after")
    def _validate_compatibility(self) -> Self:
        """Cross-validates parameter dependencies before any network
        round trip

        info: Driver
            Exactly one of `targets` / `plugin` must be set

        info: Headers vs Set Cookies
            `set_cookies` cannot be combined with `headers`

        info: Render vs Retry Timeout
            `retry_timeout` and `render` are mutually exclusive (same
            rule as on `RequestParameters`)

        info: Geo Exclusion
            `geo_code` and `regional_geo_code` are mutually exclusive

        info: Regional Requires Super
            `regional_geo_code` requires `super=True`

        info: Plugin Geocode
            When `plugin.params` includes any entry with a `geocode`
            field set, the top-level `geo_code` must be `None`

        Returns:
            The validated instance from which the method was called

        Raises:
            ValueError: If any of the documented rules is violated
        """
        # --- Driver ---
        if self.targets is None and self.plugin is None:
            raise ValueError(
                "JobCreationRequest requires exactly one of 'targets' or"
                " 'plugin'"
                )
        if self.targets is not None and self.plugin is not None:
            raise ValueError(
                "JobCreationRequest accepts only one of 'targets' or"
                " 'plugin', not both"
                )

        # --- Headers vs Set Cookies ---
        if self.headers and self.set_cookies:
            raise ValueError(
                "JobCreationRequest 'set_cookies' cannot be combined with"
                " 'headers' (per the Async API specification)"
                )

        # --- Render vs Retry Timeout ---
        if self.render is not None and self.retry_timeout is not None:
            raise ValueError(
                "JobCreationRequest 'retry_timeout' cannot be used"
                " concurrently with 'render'"
                )

        # --- Geo Exclusion ---
        check_geo_exclusion(self.geo_code, self.regional_geo_code)

        # --- Regional Requires Super ---
        check_regional_requires_super(
            bool(self.super),
            self.regional_geo_code,
            )

        # --- Plugin Geocode vs Top-level Geo Code ---
        if self.plugin is not None and self.geo_code is not None:
            params = getattr(self.plugin, "params", None) or []
            has_geocode = any(
                getattr(entry, "geocode", None) is not None
                for entry in params
                )
            if has_geocode:
                raise ValueError(
                    "JobCreationRequest 'geo_code' must be None when"
                    " 'plugin.params' includes per-task 'geocode' entries"
                    " (the per-task geocode wins server-side)"
                    )

        return self


# --------------------------------------------------------------------
# Job-List Query Parameters
# --------------------------------------------------------------------

class JobListQueryParametersDict(TypedDict, total=False):
    """Strict IDE autocomplete + static type-checking for `**kwargs`
    dictionaries that build a [`JobListQueryParameters`]
    [scrape_do.async_api.models.parameters.JobListQueryParameters] model

    tip: Usage
        - Consumed by the client's smart-routing kwargs path on
          [`list_jobs`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.list_jobs]

        - Callers can use either an explicit `JobListQueryParameters`
          instance or unpacked kwargs
    """

    page_size: Optional[int]
    """Number of jobs per page (`1`-`100`, default `10`)"""

    page: Optional[int]
    """Page number (`>= 1`, default `1`)"""

    status: Optional[JobStatus]
    """Filter results to one `JobStatus`"""

    start_from: Optional[datetime]
    """
    Return jobs with `start_time >= start_from`. Serialized as `RFC3339`
    with uppercase `T` and `Z` (UTC)
    """

    start_to: Optional[datetime]
    """
    Return jobs with `start_time <= start_to`. Same `RFC3339` formatting
    """

    sort: Optional[JobListQuerySortType]
    """Sort order (`start_time_asc` or `start_time_desc`)"""


class JobListQueryParameters(BaseModel):
    """Query parameters for `GET /api/v1/jobs`

    warning: Query Parameter Casing
        Unlike the JSON body fields (which use `PascalCase`), the
        server requires list-jobs query parameters to be lower-snake-case

    Attributes:
        page_size (Optional[int]): Number of jobs per page (`1`-`100`)
        page (Optional[int]): Page number (`>= 1`)
        status (Optional[JobStatus]): Filter results to one
            `JobStatus`
        start_from (Optional[datetime]): Return jobs with `start_time >=
            start_from`. Serialized as `RFC3339` with uppercase `T` and `Z`
            (UTC)
        start_to (Optional[datetime]): Return jobs with `start_time
            <= start_to`. Same RFC3339 formatting
        sort (Optional[JobListQuerySortType]): Sort order (`start_time_asc` or
            `start_time_desc`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    page_size: Optional[int] = Field(
        default=10,
        alias="page_size",
        ge=1,
        le=100
        )
    page: Optional[int] = Field(
        default=1,
        alias="page",
        ge=1
        )
    status: Optional[JobStatus] = Field(
        default=None,
        alias="status"
        )
    start_from: Optional[datetime] = Field(
        default=None,
        alias="start_from"
        )
    start_to: Optional[datetime] = Field(
        default=None,
        alias="start_to"
        )
    sort: Optional[JobListQuerySortType] = Field(
        default="start_time_desc",
        alias="sort"
        )

    @staticmethod
    def _format_datetime(value: datetime) -> str:
        """Renders a datetime as `RFC3339 UTC` with uppercase `T` / `Z`

        warning: Timezone
            - `datetime` objects that don't contain timezone information are
              treated as UTC

            - `datetime` object that contain timezone information are converted
              to `UTC`

        Args:
            value (datetime): The datetime to format. Naive values are
                treated as UTC. Aware values are converted to UTC

        Returns:
            The formatted timestamp string
        """
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        else:
            value = value.astimezone(timezone.utc)
        return value.strftime("%Y-%m-%dT%H:%M:%SZ")

    def to_query_dict(self) -> Dict[str, Any]:
        """Serializes the model into a flat dict suitable for the
        `httpx.request` `params` argument

        abstract: Serialization Rules
            - `None` values are dropped
            - `datetime` values are formatted as `RFC3339` UTC strings

        Returns:
            A flat `Dict[str, Any]` ready to pass as `params=...`
        """
        out: Dict[str, Any] = {}
        if self.page_size is not None:
            out["page_size"] = self.page_size
        if self.page is not None:
            out["page"] = self.page
        if self.status is not None:
            out["status"] = self.status
        if self.start_from is not None:
            out["start_from"] = self._format_datetime(self.start_from)
        if self.start_to is not None:
            out["start_to"] = self._format_datetime(self.start_to)
        if self.sort is not None:
            out["sort"] = self.sort
        return out
