"""`Scrape.do Async API` Data Models

Hosts every `pydantic` model used to describe the
[`Scrape.do Async API`](https://scrape.do/documentation/async-api/) request
and response shapes

abstract: Modules
    - [`enums`][scrape_do.async_api.models.enums] = Async-API specific
      literal type aliases

    - [`parameters`][scrape_do.async_api.models.parameters] = Outbound request
      shapes

    - [`response`][scrape_do.async_api.models.response] = Inbound response
      shapes

    - [`plugins`][scrape_do.async_api.models.plugins] = Async plugin adapter
      models and the `AsyncPlugin` discriminated union
"""

from __future__ import annotations

from .enums import JobListQuerySortType, JobStatus, TERMINAL_STATUSES
from .parameters import (
    RENDER_PARAMETER_FIELDS,
    JobCreationRequest,
    JobCreationRequestDict,
    JobListQueryParameters,
    JobListQueryParametersDict,
    RenderParameters,
    )
from .plugins import (
    LowesStoreAsyncPlugin,
    LowesStoreParameters,
    WalmartStoreAsyncPlugin,
    WalmartStoreParameters,
    AmazonOfferListingAsyncPlugin,
    AmazonPdpAsyncPlugin,
    AmazonSearchAsyncPlugin,
    GoogleFlightsAsyncPlugin,
    GoogleHotelsAsyncPlugin,
    GoogleMapsPlaceAsyncPlugin,
    GoogleMapsReviewsAsyncPlugin,
    GoogleMapsSearchAsyncPlugin,
    GoogleNewsAsyncPlugin,
    GoogleSearchAiModeAsyncPlugin,
    GoogleSearchAsyncPlugin,
    GoogleShoppingAsyncPlugin,
    GoogleTrendsAsyncPlugin,
    AsyncPlugin
  )
from .response import (
    CancelJobResponse,
    JobCreationResponse,
    JobDetails,
    JobResult,
    JobsListResponse,
    TaskDetails,
    UndetailedTaskResponse,
    UserInformation,
    WebhookPayload,
    )

__all__ = [
    # Enums
    "JobListQuerySortType",
    "JobStatus",
    "TERMINAL_STATUSES",
    # Outbound request shapes
    "JobCreationRequest",
    "JobCreationRequestDict",
    "JobListQueryParameters",
    "JobListQueryParametersDict",
    "RENDER_PARAMETER_FIELDS",
    "RenderParameters",
    # Inbound response shapes
    "CancelJobResponse",
    "JobCreationResponse",
    "JobDetails",
    "JobResult",
    "JobsListResponse",
    "TaskDetails",
    "UndetailedTaskResponse",
    "UserInformation",
    "WebhookPayload",
    # Plugins
    "AmazonOfferListingAsyncPlugin",
    "AmazonPdpAsyncPlugin",
    "AmazonSearchAsyncPlugin",
    "GoogleFlightsAsyncPlugin",
    "GoogleHotelsAsyncPlugin",
    "GoogleMapsPlaceAsyncPlugin",
    "GoogleMapsReviewsAsyncPlugin",
    "GoogleMapsSearchAsyncPlugin",
    "GoogleNewsAsyncPlugin",
    "GoogleSearchAiModeAsyncPlugin",
    "GoogleSearchAsyncPlugin",
    "GoogleShoppingAsyncPlugin",
    "GoogleTrendsAsyncPlugin",
    "LowesStoreAsyncPlugin",
    "LowesStoreParameters",
    "WalmartStoreAsyncPlugin",
    "WalmartStoreParameters",
    "AsyncPlugin"
    ]
