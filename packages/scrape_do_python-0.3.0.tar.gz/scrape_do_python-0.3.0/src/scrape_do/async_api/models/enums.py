"""Type aliases for `Scrape.do Async API` Literal Parameters

Defines literal types specific to the Async API surface

info: Shared Literals
    `HttpMethod`, `DeviceType`, `WaitUntilType`, `OutputType` are
    re-used from [`scrape_do.models.enums`][scrape_do.models.enums] since
    the Async API runs the same engine as the synchronous gateway

abstract: Job Lifecycle
    - [`JobStatus`][scrape_do.async_api.models.enums.JobStatus]
    - [`TERMINAL_STATUSES`][scrape_do.async_api.models.enums.TERMINAL_STATUSES]

abstract: Job Listing
    - [`JobListQuerySortType`]
    [scrape_do.async_api.models.enums.JobListQuerySortType]
"""

from __future__ import annotations

from typing import FrozenSet, Literal

from typing_extensions import TypeAlias


JobStatus: TypeAlias = Literal[
    "queuing",
    "queued",
    "pending",
    "rotating",
    "success",
    "error",
    "canceled",
    ]
"""
Lifecycle state of an `Async API` job / task

info: Mapping
    - `queuing` = Job is being prepared
    - `queued` = Job is in queue waiting to be processed
    - `pending` = Job is currently being processed
    - `rotating` = Job is retrying with different proxies
    - `success` = Job completed successfully (`TERMINAL`)
    - `error` = Job failed (`TERMINAL`)
    - `canceled` = Job was canceled by the user (`TERMINAL`)
"""


TERMINAL_STATUSES: FrozenSet[JobStatus] = frozenset(
    {"success", "error", "canceled"}
    )
"""
Set of [`JobStatus`][scrape_do.async_api.models.enums.JobStatus] values
the server treats as `terminal`

tip: Usage
    Used by the polling helpers to decide when to stop polling and
    fetch task details
"""

JobListQuerySortType: TypeAlias = Literal["start_time_desc", "start_time_asc"]
"""
Defines the values accepted by the `sort` argument of the
`JobListQueryParameters` model

info: Mapping
    - `start_time_desc` = Most recently started jobs appear at the top
    - `start_time_asc` = Jobs that started first (oldest jobs) appear at the
      top
"""
