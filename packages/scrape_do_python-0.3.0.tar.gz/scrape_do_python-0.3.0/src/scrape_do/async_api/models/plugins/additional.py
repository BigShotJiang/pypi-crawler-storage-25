"""`Scrape.do Async-API Additional Plugin Adapters`

abstract: Current Async-Only Plugins
    - [`walmart/store`]
    [scrape_do.async_api.models.plugins.WalmartStoreAsyncPlugin]

    - [`lowes/store`]
    [scrape_do.async_api.models.plugins.LowesStoreAsyncPlugin]

info: Usage
    These adapters participate in the
    [`AsyncPlugin`]
    [scrape_do.async_api.models.plugins.AsyncPlugin]
    discriminated union consumed by `JobCreationRequest.plugin`

warning: No Sync Gateway
    - Walmart and Lowes do NOT have dedicated synchronous gateway endpoints,
      which is why they're not listed in the [`Sync Plugins Sub-Package`]
    [scrape_do.plugins]

    - The parameter models live alongside their adapters here

warning: Sparse Documentation
    - [`Scrape.do's Async API Plugins`](https://scrape.do/documentation/
    async-api/plugins/) page enumerates the `walmart/store` and `lowes/store`
    plugin keys, but does NOT formally specify their full schema

    - These plugins return raw HTML rather than structured JSON

    - The models require `geocode` and accept arbitrary additional `key /
      value` pairs via `extra="allow"` so that callers can construct entries
      that match whatever shape `Scrape.do` is currently expecting
      without the SDK blocking on a stale schema

"""

from __future__ import annotations

from typing import List, Literal

from pydantic import BaseModel, ConfigDict, Field


class WalmartStoreParameters(BaseModel):
    """Parameters accepted by the `walmart/store` plugin

    warning: Schema-Free
        - Only `geocode` is documented as required

        - Construct an instance with whatever additional keys the
          documentation currently lists (extras pass through unchanged
          thanks to `extra="allow"`)

        - The plugin returns `raw HTML` rather than structured JSON

    Attributes:
        geocode (str): ISO 3166-1 alpha-2 country code selecting the
            target Walmart marketplace

    Example:
        ```python
        from scrape_do.async_api.models.plugins import WalmartStoreParameters

        param = WalmartStoreParameters(geocode="us", some_extra="value")
        ```
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow"
        )

    geocode: str = Field(
        ...,
        alias="geocode"
        )


class LowesStoreParameters(BaseModel):
    """Parameters accepted by the `lowes/store` plugin

    warning: Schema-Free
        - Only `geocode` is documented as required

        - Construct an instance with whatever additional keys the
          documentation currently lists (extras pass through unchanged
          thanks to `extra="allow"`)

        - The plugin returns `raw HTML` rather than structured JSON

    Attributes:
        geocode (str): ISO 3166-1 alpha-2 country code selecting the
            target Lowes marketplace

    Example:
        ```python
        from scrape_do.async_api.models.plugins import LowesStoreParameters

        param = LowesStoreParameters(geocode="us", some_extra="value")
        ```
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="allow"
        )

    geocode: str = Field(
        ...,
        alias="geocode"
        )


class WalmartStoreAsyncPlugin(BaseModel):
    """Async adapter for the `walmart/store` plugin

    Attributes:
        key (Literal["walmart/store"]): Plugin discriminator
        params (List[WalmartStoreParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["walmart/store"] = Field(
        default="walmart/store",
        alias="Key"
        )
    params: List[WalmartStoreParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class LowesStoreAsyncPlugin(BaseModel):
    """Async adapter for the `lowes/store` plugin

    Attributes:
        key (Literal["lowes/store"]): Plugin discriminator
        params (List[LowesStoreParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["lowes/store"] = Field(
        default="lowes/store",
        alias="Key"
        )
    params: List[LowesStoreParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )
