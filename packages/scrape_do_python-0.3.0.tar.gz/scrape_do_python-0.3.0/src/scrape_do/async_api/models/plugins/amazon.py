"""
`*AsyncPlugin` Adapters for `Scrape.do's Amazon Plugins`

Each adapter pairs a plugin's `Key` discriminator literal with the list
of [`Amazon Sync *Parameters`][scrape_do.plugins.amazon] entries the Async API
expects

info: Usage
    These adapters participate in the
    [`AsyncPlugin`]
    [scrape_do.async_api.models.plugins.AsyncPlugin]
    discriminated union consumed by `JobCreationRequest.plugin`

tip: Official Documentation
    - [`Async API Plugins`](https://scrape.do/documentation/async-api/plugins/#
    amazon-plugins)
    - [`Amazon Scraper API`](https://scrape.do/documentation/amazon-scraper-
    api/)
"""

from __future__ import annotations

from typing import List, Literal

from pydantic import BaseModel, ConfigDict, Field

from ....plugins.amazon import (
    AmazonOfferListingParameters,
    AmazonPdpParameters,
    AmazonSearchParameters,
    )


class AmazonPdpAsyncPlugin(BaseModel):
    """Async adapter for the `amazon/pdp` plugin

    Attributes:
        key (Literal["amazon/pdp"]): Plugin discriminator
        params (List[AmazonPdpParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["amazon/pdp"] = Field(
        default="amazon/pdp",
        alias="Key"
        )
    params: List[AmazonPdpParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class AmazonSearchAsyncPlugin(BaseModel):
    """Async adapter for the `amazon/search` plugin

    Attributes:
        key (Literal["amazon/search"]): Plugin discriminator
        params (List[AmazonSearchParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["amazon/search"] = Field(
        default="amazon/search",
        alias="Key"
        )
    params: List[AmazonSearchParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class AmazonOfferListingAsyncPlugin(BaseModel):
    """Async adapter for the `amazon/offer-listing` plugin

    Attributes:
        key (Literal["amazon/offer-listing"]): Plugin discriminator
        params (List[AmazonOfferListingParameters]): Per-job task
            entries (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["amazon/offer-listing"] = Field(
        default="amazon/offer-listing",
        alias="Key"
        )
    params: List[AmazonOfferListingParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )
