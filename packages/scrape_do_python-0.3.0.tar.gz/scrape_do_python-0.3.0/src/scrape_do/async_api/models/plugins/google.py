"""
`Scrape.do Async-API Google Plugin Adapters`

Each adapter pairs a plugin's `Key` discriminator literal with the list
of [`Sync *Parameters`][scrape_do.plugins.google] entries the Async API expects

info: Usage
    These adapters participate in the
    [`AsyncPlugin`]
    [scrape_do.async_api.models.plugins.AsyncPlugin]
    discriminated union consumed by `JobCreationRequest.plugin`

tip: Country Targeting
    - The top-level `geo_code` of the [`JobCreationRequest`]
    [scrape_do.async_api.models.parameters.JobCreationRequest] cannot be used
    with plugin-specifc location parameters and has no effect on
    `Google Plugins`

    - Use the per-param `gl` instead

tip: `super`
    - All `Google Plugins` use premium proxies internally by default

    - The top-level `Super` flag on [`JobCreationRequest`]
    [scrape_do.async_api.models.parameters.JobCreationRequest] has no effect
    on them

info: Async-Surface Parity
    Adapters without an `Async-Surface Caveat` warning accept every
    documented sync parameter unchanged. Only the ones whose async
    surface differs from their sync counterpart carry an explicit
    warning on the class docstring

tip: Official Documentation
    - [`Async API Plugins`](https://scrape.do/documentation/async-api/plugins/#
    google-plugins)
    - [`Google Scraper API`](https://scrape.do/documentation/google-scraper-
    api/)
"""

from __future__ import annotations

from typing import List, Literal

from pydantic import BaseModel, ConfigDict, Field

from ....plugins.google import (
    GoogleFlightsParameters,
    GoogleHotelsParameters,
    GoogleMapsPlaceParameters,
    GoogleMapsReviewsParameters,
    GoogleMapsSearchParameters,
    GoogleNewsParameters,
    GoogleSearchAiModeParameters,
    GoogleSearchParameters,
    GoogleShoppingParameters,
    GoogleTrendsParameters,
    )


class GoogleSearchAsyncPlugin(BaseModel):
    """Async adapter for the `google/search` plugin

    warning: Async-Surface Caveat
        - `num` set on a wrapped
          [`GoogleSearchParameters`]
        [scrape_do.plugins.google.GoogleSearchParameters]
          entry is silently dropped by the Async-API `SERP` plugin

        - Pagination size stays at the server default of `10`
          regardless of the value sent

        - The field is honored on the synchronous gateway, so it
          remains on the `Parameters` model

    Attributes:
        key (Literal["google/search"]): Plugin discriminator
        params (List[GoogleSearchParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/search"] = Field(
        default="google/search",
        alias="Key"
        )
    params: List[GoogleSearchParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleSearchAiModeAsyncPlugin(BaseModel):
    """Async adapter for the `google/search/ai-mode` plugin

    warning: Async-Surface Caveat
        - The Async-API AI Mode plugin honors only `q`, `hl`, `gl`,
          `device`, and `google_domain`

        - Every other field on a wrapped
          [`GoogleSearchAiModeParameters`]
        [scrape_do.plugins.google.GoogleSearchAiModeParameters]
          is silently dropped on the async surface

        - Dropped Parameters are `start`, `include_html`, `cr`, `lr`, `uule`,
          `location`, `safe`, `time_period`, `filter`, `nfpr`, `num`

        - The synchronous gateway docs claim those fields are accepted
          equivalently to `google/search`, so the `Parameters` model
          keeps them

    Attributes:
        key (Literal["google/search/ai-mode"]): Plugin discriminator
        params (List[GoogleSearchAiModeParameters]): Per-job task
            entries (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/search/ai-mode"] = Field(
        default="google/search/ai-mode",
        alias="Key"
        )
    params: List[GoogleSearchAiModeParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleMapsSearchAsyncPlugin(BaseModel):
    """Async adapter for the `google/maps/search` plugin

    Attributes:
        key (Literal["google/maps/search"]): Plugin discriminator
        params (List[GoogleMapsSearchParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/maps/search"] = Field(
        default="google/maps/search",
        alias="Key"
        )
    params: List[GoogleMapsSearchParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleMapsPlaceAsyncPlugin(BaseModel):
    """Async adapter for the `google/maps/place` plugin

    Attributes:
        key (Literal["google/maps/place"]): Plugin discriminator
        params (List[GoogleMapsPlaceParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/maps/place"] = Field(
        default="google/maps/place",
        alias="Key"
        )
    params: List[GoogleMapsPlaceParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleMapsReviewsAsyncPlugin(BaseModel):
    """Async adapter for the `google/maps/reviews` plugin

    Attributes:
        key (Literal["google/maps/reviews"]): Plugin discriminator
        params (List[GoogleMapsReviewsParameters]): Per-job task
            entries (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/maps/reviews"] = Field(
        default="google/maps/reviews",
        alias="Key"
        )
    params: List[GoogleMapsReviewsParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleShoppingAsyncPlugin(BaseModel):
    """Async adapter for the `google/shopping` plugin

    Attributes:
        key (Literal["google/shopping"]): Plugin discriminator
        params (List[GoogleShoppingParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/shopping"] = Field(
        default="google/shopping",
        alias="Key"
        )
    params: List[GoogleShoppingParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleFlightsAsyncPlugin(BaseModel):
    """Async adapter for the `google/flights` plugin

    Attributes:
        key (Literal["google/flights"]): Plugin discriminator
        params (List[GoogleFlightsParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/flights"] = Field(
        default="google/flights",
        alias="Key"
        )
    params: List[GoogleFlightsParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleHotelsAsyncPlugin(BaseModel):
    """Async adapter for the `google/hotels` plugin

    Attributes:
        key (Literal["google/hotels"]): Plugin discriminator
        params (List[GoogleHotelsParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/hotels"] = Field(
        default="google/hotels",
        alias="Key"
        )
    params: List[GoogleHotelsParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleNewsAsyncPlugin(BaseModel):
    """Async adapter for the `google/news` plugin

    Attributes:
        key (Literal["google/news"]): Plugin discriminator
        params (List[GoogleNewsParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/news"] = Field(
        default="google/news",
        alias="Key"
        )
    params: List[GoogleNewsParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )


class GoogleTrendsAsyncPlugin(BaseModel):
    """Async adapter for the `google/trends` plugin

    Attributes:
        key (Literal["google/trends"]): Plugin discriminator
        params (List[GoogleTrendsParameters]): Per-job task entries
            (`1`-`1000`)
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    key: Literal["google/trends"] = Field(
        default="google/trends",
        alias="Key"
        )
    params: List[GoogleTrendsParameters] = Field(
        ...,
        alias="Params",
        min_length=1,
        max_length=1000
        )
