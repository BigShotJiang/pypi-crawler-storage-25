"""Inbound response shapes for the `Scrape.do Async API`

Defines the `pydantic` models the `ScrapeDoAsyncAPIClient` parses from
`q.scrape.do` JSON responses

warning: Plugin Content
    - `TaskDetails.content` is an opaque string for now

    - Per-plugin structured response models ship with the plugin clients
      themselves in `0.4` / `0.5`
"""

from __future__ import annotations

import base64
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field
from typing_extensions import TypeAlias

from ..exceptions import (
    JobCanceledError,
    JobFailedError,
    TaskCanceledError,
    TaskFailedError,
)
from .enums import TERMINAL_STATUSES, JobStatus


# --------------------------------------------------------------------
# Job Creation Response
# --------------------------------------------------------------------


class JobCreationResponse(BaseModel):
    """Response body returned by `POST /api/v1/jobs`

    Attributes:
        job_id (str): Server-assigned UUID for the newly created job
        task_ids (List[str]): UUIDs for each task spawned from this
            job (one per `Targets[]` entry or one per
            `Plugin.Params[]` entry)
        message (Optional[str]): Human-readable acknowledgment message
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    job_id: str = Field(
        ...,
        alias="JobID"
        )
    task_ids: List[str] = Field(
        default_factory=list,
        alias="TaskIDs"
        )
    message: Optional[str] = Field(
        default=None,
        alias="Message"
        )


# --------------------------------------------------------------------
# Task Summary (used by JobDetails.tasks)
# --------------------------------------------------------------------


class UndetailedTaskResponse(BaseModel):
    """Per-task summary nested inside
    [`JobDetails.tasks`][scrape_do.async_api.models.response.JobDetails]

    Attributes:
        task_id (str): UUID of the task
        url (str): The target URL for this task
        status (JobStatus): Current lifecycle status of the task
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    task_id: str = Field(
        ...,
        alias="TaskID"
        )
    url: str = Field(
        ...,
        alias="URL"
        )
    status: JobStatus = Field(
        ...,
        alias="Status"
        )


# --------------------------------------------------------------------
# Job Details
# --------------------------------------------------------------------


class JobDetails(BaseModel):
    """Response body returned by `GET /api/v1/jobs/{jobID}` and
    `DELETE /api/v1/jobs/{jobID}`

    Attributes:
        job_id (str): UUID of the job
        task_ids (List[str]): UUIDs of every task in this job
        status (JobStatus): Current lifecycle status
        start_time (Optional[datetime]): When the job started
            executing (RFC3339)
        end_time (Optional[datetime]): When the job reached a terminal
            status (RFC3339)
        acquired_concurrency (int): Number of concurrent requests
            currently in use by this job (per `Scrape.do's` Async API
            response schema)
        limit_concurrency (int): Maximum number of concurrent requests
            allowed for this job. `0` indicates no per-job ceiling
            beyond the account-wide async pool
        canceled (bool): `True` if the job was explicitly canceled
        tasks (List[UndetailedTaskResponse]): Per-task summary entries
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    job_id: str = Field(
        ...,
        alias="JobID"
        )
    task_ids: List[str] = Field(
        default_factory=list,
        alias="TaskIDs"
        )
    status: JobStatus = Field(
        ...,
        alias="Status"
        )
    start_time: Optional[datetime] = Field(
        default=None,
        alias="StartTime"
        )
    end_time: Optional[datetime] = Field(
        default=None,
        alias="EndTime"
        )
    acquired_concurrency: int = Field(
        default=0,
        alias="AcquiredConcurrency"
        )
    limit_concurrency: int = Field(
        default=0,
        alias="LimitConcurrency"
        )
    canceled: bool = Field(
        default=False,
        alias="Canceled"
        )
    tasks: List[UndetailedTaskResponse] = Field(
        default_factory=list,
        alias="Tasks"
        )

    @property
    def is_terminal(self) -> bool:
        """Whether the job has reached any terminal status

        info: Terminal Statuses
            - `success`
            - `error`
            - `canceled`

        Returns:
            `True` if `status` is one of the documented terminal
                statuses, `False` otherwise
        """
        return self.status in TERMINAL_STATUSES

    @property
    def is_success(self) -> bool:
        """Whether the job completed successfully

        Returns:
            `True` if `status == "success"`, `False` otherwise
        """
        return self.status == "success"

    @property
    def is_terminal_failure(self) -> bool:
        """Whether the job has reached a terminal failure state

        info: Status Routing
            - `error` / `canceled` &rarr; `True`
            - `success` &rarr; `False`
            - `Non-Terminal Statuses` &rarr; `False`

        Returns:
            `True` if `status` is `error` or `canceled`, `False`
                otherwise
        """
        return self.status in ("error", "canceled")

    @property
    def duration(self) -> Optional[timedelta]:
        """Wall-clock duration the job spent running

        warning: Availability
            - Both `start_time` and `end_time` are populated only once
              the job reaches a terminal status

            - Before then, this property returns `None`

        Returns:
            `end_time - start_time` when both are set, `None`
                otherwise
        """
        if self.start_time is None or self.end_time is None:
            return None
        return self.end_time - self.start_time

    def raise_for_status(self) -> None:
        """Raises the appropriate terminal-state exception for the
        current `status`

        asbstract: Exception Mapping
            - `status == "error"` &rarr; raises `JobFailedError`
            - `status == "canceled"` &rarr; raises `JobCanceledError`
            - `Success / Non-Terminal` &rarr; no-op

        tip: Intended Usage
            - Polling helpers [`wait_for_job`]
            [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.wait_for_job]
              and [`submit_and_wait`]
            [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.submit_and_wait]
              already call this internally

            - Use it directly when working with [`get_job`]
            [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.get_job]
            outputs

        Raises:
            JobFailedError: When `status == "error"`
            JobCanceledError: When `status == "canceled"`
        """
        if self.status == "error":
            raise JobFailedError(self)
        if self.status == "canceled":
            raise JobCanceledError(self)


CancelJobResponse: TypeAlias = JobDetails
"""
Alias for [`JobDetails`][scrape_do.async_api.models.response.JobDetails]

`DELETE /api/v1/jobs/{jobID}` returns the same shape as the corresponding
`GET` with `Canceled=true`
"""


# --------------------------------------------------------------------
# Task Details
# --------------------------------------------------------------------


class TaskDetails(BaseModel):
    """Response body returned by `GET /api/v1/jobs/{jobID}/{taskID}`

    Attributes:
        task_id (str): UUID of the task
        job_id (str): UUID of the parent job
        url (str): The target URL the task was fetching
        status (JobStatus): Terminal status (`success`, `error`, or
            `canceled` when delivered via webhook)
        start_time (Optional[datetime]): When the task started
        end_time (Optional[datetime]): When the task reached its
            terminal status
        update_time (Optional[datetime]): Last update timestamp
        expires_at (Optional[datetime]): When the task's content
            expires server-side and becomes unretrievable
        base64_encoded_content (bool): Whether `content` is
            base64-encoded
        status_code (int): HTTP status code returned by the target
        response_headers (Dict[str, str]): Headers returned by the
            target
        scrape_do_metadata (Dict[str, str]): Scrape.do's telemetry
            block. Exposed under the literal `Scrape.do` key on the
            wire
        content (Optional[str]): Response body. Base64-decoded via
            `decoded_content()` when `base64_encoded_content=True`
        error_message (Optional[str]): Task-level error message on
            failure
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    task_id: str = Field(
        ...,
        alias="TaskID"
        )
    job_id: str = Field(
        ...,
        alias="JobID"
        )
    url: str = Field(
        ...,
        alias="URL"
        )
    status: JobStatus = Field(
        ...,
        alias="Status"
        )
    start_time: Optional[datetime] = Field(
        default=None,
        alias="StartTime"
        )
    end_time: Optional[datetime] = Field(
        default=None,
        alias="EndTime"
        )
    update_time: Optional[datetime] = Field(
        default=None,
        alias="UpdateTime"
        )
    expires_at: Optional[datetime] = Field(
        default=None,
        alias="ExpiresAt"
        )
    base64_encoded_content: bool = Field(
        default=False,
        alias="Base64EncodedContent"
        )
    status_code: int = Field(
        default=0,
        alias="StatusCode"
        )
    response_headers: Dict[str, str] = Field(
        default_factory=dict,
        alias="ResponseHeaders"
        )
    scrape_do_metadata: Dict[str, str] = Field(
        default_factory=dict,
        alias="Scrape.do"
        )
    content: Optional[str] = Field(
        default=None,
        alias="Content"
        )
    error_message: Optional[str] = Field(
        default=None,
        alias="ErrorMessage"
        )

    @property
    def is_terminal(self) -> bool:
        """Whether the task has reached any terminal status

        info: Terminal Statuses
            - `success`
            - `error`
            - `canceled`

        Returns:
            `True` if `status` is one of the documented terminal
                statuses, `False` otherwise
        """
        return self.status in TERMINAL_STATUSES

    @property
    def is_success(self) -> bool:
        """Whether the task completed successfully

        warning: Lifecycle Status vs Target Response
            - This checks the task's `lifecycle status`, not the
              target's `HTTP Status Code`

            - A task with `status == "success"` and `status_code ==
              404` means `Scrape.do` successfully fetched the target,
              which itself returned `404`

        Returns:
            `True` if `status == "success"`, `False` otherwise
        """
        return self.status == "success"

    @property
    def is_terminal_failure(self) -> bool:
        """Whether the task has reached a terminal failure state

        info: Status Routing
            - `error` / `canceled` &rarr; `True`
            - `success` &rarr; `False`
            - `Non-Terminal Statuses` &rarr; `False`

        Returns:
            `True` if `status` is `error` or `canceled`, `False`
                otherwise
        """
        return self.status in ("error", "canceled")

    @property
    def is_expired(self) -> Optional[bool]:
        """Whether the task's content has expired server-side

        warning: Definition
            - Returns `True` only when `expires_at` is populated and
              strictly before `datetime.now(timezone.utc)`

            - Returns `False` only when `expires_at` is populated and
              strictly after `datetime.now(timezone.utc)`

            - Returns `None` when `expires_at` is not set

        Returns:
            `True` if `expires_at` is set and in the past, `False`
                if `expires_at` is set and in the future, `None` if
                `expires_at` is not set
        """
        if self.expires_at is None:
            return None
        now = datetime.now(timezone.utc)
        expires = self.expires_at
        if expires.tzinfo is None:
            expires = expires.replace(tzinfo=timezone.utc)
        return expires < now

    @property
    def duration(self) -> Optional[timedelta]:
        """Wall-clock duration the task spent running

        warning: Availability
            - Both `start_time` and `end_time` are populated only once
              the task reaches a terminal status

            - Before then, this property returns `None`

        Returns:
            `end_time - start_time` when both are set, `None`
                otherwise
        """
        if self.start_time is None or self.end_time is None:
            return None
        return self.end_time - self.start_time

    def decoded_content(self) -> Optional[bytes]:
        """Returns `content` as bytes, decoding base64 when applicable

        info: Behavior
            - When `base64_encoded_content=True`, decodes `content`
              via [`base64.b64decode`][base64.b64decode]
            - When `base64_encoded_content=False`, returns
              `content.encode("utf-8")` so callers always get bytes
            - Returns `None` when `content is None`

        Returns:
            The decoded bytes, or `None` if there is no `content`

        Raises:
            ValueError: If `base64_encoded_content=True` but `content`
                is not valid base64
        """
        if self.content is None:
            return None
        if self.base64_encoded_content:
            return base64.b64decode(self.content)
        return self.content.encode("utf-8")

    def raise_for_status(self) -> None:
        """Raises the appropriate terminal-state exception for the
        current `status`

        abstract: Exception Mapping
            - `status == "error"` &rarr; raises `TaskFailedError`
            - `status == "canceled"` &rarr; raises `TaskCanceledError`
            - `Success / Non-Terminal` &rarr; no-op

        tip: Mirrors `JobDetails.raise_for_status`
            Equivalent to [`JobDetails.raise_for_status`]
            [scrape_do.async_api.models.response.JobDetails.raise_for_status]
            on the parent job, but for the task's own lifecycle status

        Raises:
            TaskFailedError: When `status == "error"`. The task's
                `error_message` (when set) gives a more specific reason
            TaskCanceledError: When `status == "canceled"`
        """
        if self.status == "error":
            raise TaskFailedError(self)
        if self.status == "canceled":
            raise TaskCanceledError(self)


WebhookPayload: TypeAlias = TaskDetails
"""
Alias for [`TaskDetails`][scrape_do.async_api.models.response.TaskDetails]

The `Scrape.do Async API` posts a `TaskDetails`-shaped JSON body to
the configured webhook URL when each task reaches a terminal status
"""


# --------------------------------------------------------------------
# User information
# --------------------------------------------------------------------


class UserInformation(BaseModel):
    """Response body returned by `GET /api/v1/me`

    warning: `AvaliableCredits`
        - The credit-balance field is spelled `AvaliableCredits`
          in `Scrape.do's` official documentation and is the live server
          spelling

        - Verified against `/api/v1/me` and locked here as the alias

    Attributes:
        total_concurrency (int): Total concurrency limit on the
            account
        free_concurrency (int): Currently available concurrency slots
        active_jobs (int): Number of jobs currently running
        available_credits (int): Remaining account credits. Mapped
            from the `AvaliableCredits` server field
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    total_concurrency: int = Field(
        default=0,
        alias="TotalConcurrency"
        )
    free_concurrency: int = Field(
        default=0,
        alias="FreeConcurrency"
        )
    active_jobs: int = Field(
        default=0,
        alias="ActiveJobs"
        )
    available_credits: int = Field(
        default=0,
        alias="AvaliableCredits"
        )


# --------------------------------------------------------------------
# Job Listing
# --------------------------------------------------------------------


class JobsListResponse(BaseModel):
    """Response body returned by `GET /api/v1/jobs`

    warning: Per-Job Entries
        - Each entry in `jobs` is parsed as a [`JobDetails`]
        [scrape_do.async_api.models.response.JobDetails] model

        - Unlike `GET /api/v1/jobs/{jobID}`, the listing payload omits the
          `AcquiredConcurrency`, `LimitConcurrency`, `Canceled`, and
          `Tasks` attributes, so those fall back to their model defaults
          (`0`, `0`, `False`, and `[]`, respectively)

        - The actual values can always be fetched via [`get_job`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.get_job]

    Attributes:
        jobs (List[JobDetails]): Per-job entries on this page
        total_count (int): Total jobs matching the query (across all
            pages)
        page_size (int): Page size used to compute the response
        page_number (int): 1-indexed page number of the current
            response
        total_pages (int): Total pages available for the query
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    jobs: List[JobDetails] = Field(
        default_factory=list,
        alias="Jobs"
        )
    total_count: int = Field(
        default=0,
        alias="TotalCount"
        )
    page_size: int = Field(
        default=0,
        alias="PageSize"
        )
    page_number: int = Field(
        default=0,
        alias="PageNumber"
        )
    total_pages: int = Field(
        default=0,
        alias="TotalPages"
        )

# --------------------------------------------------------------------
# Response Bundles
# --------------------------------------------------------------------


class JobResult(BaseModel):
    """Bundle of terminal `JobDetails` + the fetched per-task details

    Returned by [`ScrapeDoAsyncAPIClient.submit_and_wait`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.submit_and_wait]
    after a job reaches a terminal status and every task's details have
    been fetched

    Attributes:
        job (JobDetails): The terminal `JobDetails` snapshot
        tasks (List[TaskDetails]): The fully-fetched `TaskDetails` for
            each `task_id` in `job.task_ids`, in input order
    """

    model_config = ConfigDict(
        populate_by_name=True,
        extra="ignore"
        )

    job: JobDetails
    tasks: List[TaskDetails] = Field(
        default_factory=list
        )
