"""Synchronous client for the `Scrape.do Async API`

Defines the [`ScrapeDoAsyncAPIClient`]
[scrape_do.async_api.client.ScrapeDoAsyncAPIClient], a synchronous
wrapper over [`httpx.Client`][] configured against `q.scrape.do`

abstract: Endpoint Mapping
    - `POST /api/v1/jobs` &rarr; [`create_job`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.create_job]

    - `GET /api/v1/jobs/{jobID}` &rarr; [`get_job`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.get_job]

    - `GET /api/v1/jobs/{jobID}/{taskID}` &rarr; [`get_task`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.get_task]

    - `GET /api/v1/jobs` &rarr; [`list_jobs`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.list_jobs]

    - `DELETE /api/v1/jobs/{jobID}` &rarr; [`cancel_job`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.cancel_job]

    - `GET /api/v1/me` &rarr; [`get_user_info`]
    [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.get_user_info]
"""

from __future__ import annotations

import logging
import os
import ssl
import time
from types import TracebackType
from typing import (
    Any,
    Callable,
    Dict,
    FrozenSet,
    List,
    Literal,
    Optional,
    Type,
    TypedDict,
    TypeVar,
    Union
)

import httpx
from httpx import BaseTransport, Client, Limits, RequestError
from httpx._client import USE_CLIENT_DEFAULT, UseClientDefault
from httpx._config import DEFAULT_LIMITS
from httpx._types import (
    CertTypes,
    QueryParamTypes,
    RequestExtensions,
    TimeoutTypes,
)
from pydantic import BaseModel, ValidationError
from typing_extensions import Self, Unpack

from ..client import default_backoff_strategy
from ..exceptions import APIConnectionError
from ..models.enums import HttpMethod
from .exceptions import (
    AsyncAPIAuthError,
    AsyncAPIBadRequestError,
    AsyncAPINotAcceptableError,
    AsyncAPINotFoundError,
    AsyncAPIRateLimitError,
    AsyncAPIResponseError,
    AsyncAPIServerError,
    AsyncAPIUnparsableResponseError
)
from .models.enums import TERMINAL_STATUSES
from .models.parameters import (
    RENDER_PARAMETER_FIELDS,
    JobCreationRequest,
    JobCreationRequestDict,
    JobListQueryParameters,
    JobListQueryParametersDict,
    RenderParameters,
)
from .models.response import (
    CancelJobResponse,
    JobCreationResponse,
    JobDetails,
    JobResult,
    JobsListResponse,
    TaskDetails,
    UserInformation,
)
from .polling import PollingFunction, PollingStrategy


logger = logging.getLogger("scrape_do.async_api")

# ----------------------------------------------------------------
# Client Helpers
# ----------------------------------------------------------------

_RETRYABLE_STATUSES: FrozenSet[int] = frozenset({429, 502, 503, 504})
"""HTTP status codes the client retries with exponential backoff"""


_ResponseModelT = TypeVar("_ResponseModelT", bound=BaseModel)
"""
TypeVar bound to [`BaseModel`][pydantic.BaseModel] used by
[`_parse_response`][scrape_do.async_api.client._parse_response] to
propagate the concrete `pydantic` response model that it returns to the
callers
"""


_STATUS_TO_EXCEPTION: Dict[int, Type[AsyncAPIResponseError]] = {
    400: AsyncAPIBadRequestError,
    401: AsyncAPIAuthError,
    404: AsyncAPINotFoundError,
    406: AsyncAPINotAcceptableError,
    429: AsyncAPIRateLimitError,
}
"""Mapping of HTTP status codes to typed Async-API exceptions"""


def _raise_for_status(resp: httpx.Response) -> None:
    """Raises the relevant [`Async-API Exception`]
    [scrape_do.async_api.exceptions] based on the status code of a non-2xx
    [`httpx.Response`][] object

    info: Shared Helper
        Both the [`ScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient] and
        the [`AsyncScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.async_client.AsyncScrapeDoAsyncAPIClient] clients
        use this function

    abstract: Exception Mapping
        - `400` &rarr; [`AsyncAPIBadRequestError`]
        [scrape_do.async_api.exceptions.AsyncAPIBadRequestError]
        - `401` &rarr; [`AsyncAPIAuthError`]
        [scrape_do.async_api.exceptions.AsyncAPIAuthError]
        - `404` &rarr; [`AsyncAPINotFoundError`]
        [scrape_do.async_api.exceptions.AsyncAPINotFoundError]
        - `406` &rarr; [`AsyncAPINotAcceptableError`]
        [scrape_do.async_api.exceptions.AsyncAPINotAcceptableError]
        - `429` &rarr; [`AsyncAPIRateLimitError`]
        [scrape_do.async_api.exceptions.AsyncAPIRateLimitError]
        - `5xx` &rarr; [`AsyncAPIServerError`]
        [scrape_do.async_api.exceptions.AsyncAPIServerError]
        - `Unmapped` &rarr; [`AsyncAPIResponseError`]
        [scrape_do.async_api.exceptions.AsyncAPIResponseError]

    Args:
        resp (httpx.Response): The raw response received from
            `q.scrape.do`

    Raises:
        AsyncAPIResponseError: One of the typed subclasses
            corresponding to the response's status code
    """
    if resp.status_code < 400:
        return

    cls = _STATUS_TO_EXCEPTION.get(resp.status_code)

    if cls is not None:
        raise cls(resp)

    if 500 <= resp.status_code < 600:
        raise AsyncAPIServerError(resp)

    raise AsyncAPIResponseError(resp)


def _parse_response(
    resp: httpx.Response,
    model_cls: Type[_ResponseModelT]
) -> _ResponseModelT:
    """Parses the raw JSON body returned by a request to `q.scrape.do` into
    one of the endpoint-specific [`Async-API Pydantic Response Models`]
    [scrape_do.async_api.models.response] by parsing it with
    `httpx.Response.json` and feeding the result to
    `model_cls.model_validate`

    info: Shared Helper
        Both the [`ScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient] and
        the [`AsyncScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.async_client.AsyncScrapeDoAsyncAPIClient] clients
        use this function

    abstract: `AsyncAPIUnparsableResponseError`
        This method raises the [`AsyncAPIUnparsableResponseError`]
        [scrape_do.async_api.exceptions.AsyncAPIUnparsableResponseError]
        exception whenever a [`JSONDecodeError`]
        [json.JSONDecodeError] or a [`ValidationError`]
        [pydantic_core._pydantic_core.ValidationError] occurs when parsing
        the raw [`httpx.Response`][] into a custom `pydantic` response
        model

    question: Why Wrap These Errors
        - `q.scrape.do` ordinarily returns JSON bodies that match
          the documented schema for each endpoint

        - Server-side incidents can leak raw HTML or a malformed
          payload through to the client. In that case, `resp.json()`
          would raise `JSONDecodeError`

        - An unexpected change to the JSON schema returned by one of the
          endpoints would cause `model_cls.model_validate` to raise
          `ValidationError`

        - Either failure is surfaced as an
          `AsyncAPIUnparsableResponseError` so callers see a single,
          consistent exception type for the cases in which the gateway
          returned something that the SDK couldn't parse

    Args:
        resp (httpx.Response): The 2xx response to parse
        model_cls (Type[_ResponseModelT]): The pydantic model class to
            validate against

    Returns:
        The validated `model_cls` instance

    Raises:
        AsyncAPIUnparsableResponseError: If `resp.json()` fails or the body
            doesn't match `model_cls`
    """
    try:
        data = resp.json()

    except ValueError as e:
        raise AsyncAPIUnparsableResponseError(
            (f"Failed to parse the successful httpx.Response body into "
             f" JSON for the {model_cls.__name__} pydantic model"
             ),
            resp
            ) from e

    try:
        return model_cls.model_validate(data)

    except ValidationError as e:
        raise AsyncAPIUnparsableResponseError(
            (f"Failed to build the {model_cls.__name__} pydantic model"
             f" from the successful httpx.Response JSON body"
             ),
            resp
            ) from e


def _build_job_creation_request(
    **kwargs: Unpack[JobCreationRequestDict]
) -> JobCreationRequest:
    """Builds a [`JobCreationRequest`]
    [scrape_do.async_api.models.parameters.JobCreationRequest] from
    the [`JobCreationRequestDict`]
    [scrape_do.async_api.models.parameters.JobCreationRequestDict]
    `TypedDict` kwargs dictionary

    info: Shared Helper
        Both the [`ScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient] and
        the [`AsyncScrapeDoAsyncAPIClient`]
        [scrape_do.async_api.async_client.AsyncScrapeDoAsyncAPIClient] clients
        use this function

    info: Render Field Auto-Collection
        Every key in [`RENDER_PARAMETER_FIELDS`]
        [scrape_do.async_api.models.parameters.RENDER_PARAMETER_FIELDS]
        found in `kwargs` is collected into a [`RenderParameters`]
        [scrape_do.async_api.models.parameters.RenderParameters]
        instance and assigned to `JobCreationRequest.render`

    warning: Mixed Render Configuration
        - Providing a pre-built `RenderParameters` instance via
          `kwargs["render"]` **AND** any key in [`RENDER_PARAMETER_FIELDS`]
        [scrape_do.async_api.models.parameters.RENDER_PARAMETER_FIELDS] at
          the same time raises a `ValueError`

        - The two configuration styles are mutually exclusive

    Args:
        **kwargs (Unpack[JobCreationRequestDict]): Any subset of the
            `JobCreationRequestDict` keys

    Returns:
        The validated `JobCreationRequest` model

    Raises:
        ValueError: If both a pre-built `render` and any flat render
            field are provided in the same call
    """
    # Turn TypedDict into a mutable dict to edit parameters later
    mutable: Dict[str, Any] = dict(kwargs)

    used_flat = [
        f for f in RENDER_PARAMETER_FIELDS if f in mutable
        ]

    if mutable.get("render") is not None and used_flat:
        raise ValueError(
            "Cannot combine a pre-built 'render' RenderParameters"
            " with flat render fields"
            f" ({', '.join(used_flat)}). Pick one configuration"
            " style."
            )

    if used_flat:
        render_kwargs = {f: mutable.pop(f) for f in used_flat}
        mutable["render"] = RenderParameters(**render_kwargs)

    return JobCreationRequest(**mutable)


class AsyncAPIEventHooks(TypedDict, total=False):
    """Configuration dictionary for SDK-native Async-API lifecycle hooks

    abstract: Differences From The `Sync Client's Hooks`
        Modeled after [`SyncClientEventHooks`]
        [scrape_do.client.SyncClientEventHooks], but adapted to the
          `Async-API` request lifecycle

    warning: `poll`
        - The `poll` event hooks are the only ones that receive a custom
          response model
          ([`JobDetails`][scrape_do.async_api.models.response.JobDetails])
          instead of a raw `httpx` object

        - This is because all other hooks are executed for all endpoint methods
          and have distinct `request` / `response` structures while `poll`
          hooks are only executed for `/api/v1/jobs/{jobID}` requests
    """

    request: List[Callable[[httpx.Request], None]]
    """
    Fires immediately before each `HTTP` call leaves the client.
    Receives the prepared `httpx.Request`. Useful for logging the raw
    `Async-API` call about to be sent
    """

    response: List[Callable[[httpx.Response], None]]
    """
    Fires immediately after each `HTTP` call returns, before the
    status-code error routing in [`_raise_for_status`]
    [scrape_do.async_api.client._raise_for_status] runs. Receives
    the raw `httpx.Response`. Useful for logging every `Async-API`
    response (including ones that are about to be raised on)
    """

    retry: List[
        Callable[
            [
                int,
                httpx.Request,
                Optional[httpx.Response],
                Optional[Exception],
                ],
            None,
            ]
        ]
    """
    Fires inside the execution loop ONLY when an `Async-API` gateway
    error (`429` / `502` / `503` / `504`) or an `httpx.RequestError`
    occurs and the SDK decides to retry. Receives the current attempt
    number, the prepared `httpx.Request` that was retried, and either
    the failed `httpx.Response` (when the gateway returned a retryable
    status) or the underlying `Exception` that caused the retry. Useful
    for tracking gateway instability
    """

    poll: List[Callable[[int, "JobDetails"], None]]
    """
    Fires on each `non-terminal` polling iteration of `wait_for_job` or
    `submit_and_wait`. Receives the zero-indexed attempt counter and
    the latest [`JobDetails`]
    [scrape_do.async_api.models.response.JobDetails] snapshot returned
    by `get_job`. Useful for surfacing polling progress
    """


class ScrapeDoAsyncAPIClient:
    """Synchronous client for the `Scrape.do Async API` on `q.scrape.do`

    Aims to facilitate interactions with the `Scrape.do Async API` by managing
    an `httpx.Client` instance to provide strict type-checking for request
    parameters, endpoint-specific methods, automatic polling, and custom error
    parsing while keeping the network configurations as flexible as possible

    abstract: Features
        - Pre-flight payload validation via the [`JobCreationRequest`]
        [scrape_do.async_api.models.parameters.JobCreationRequest] and
        [`JobListQueryParameters`][scrape_do.async_api.models.parameters.JobListQueryParameters]
        models

        - Status code error routing to specific exceptions
          (`400` / `401` / `404` / `406` / `429` / `5xx`)

        - Customisable retry intervals on transient gateway errors

        - Polling helpers ([`wait_for_job`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.wait_for_job]
          and [`submit_and_wait`]
        [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.submit_and_wait])
          with either a built-in
          [`PollingStrategy`][scrape_do.async_api.polling.PollingStrategy]
          or a user-supplied `PollingFunction`

    info: Concurrency Limit and Server Errors
        This client intercepts and manages `Scrape.do's Async API` specific
        gateway errors (`429` / `502` / `503` / `504`),
        automatically applying a customisable retry strategy before the error
        can reach the application

    tip: SDK Event Hooks (`event_hooks`)
        This client implements SDK-specific event hooks mimicking the
        structure of `httpx` native event hooks. See
        [`AsyncAPIEventHooks`][scrape_do.async_api.client.AsyncAPIEventHooks]
        for available lifecycle hooks and their required signatures

    tip: Additional `httpx.Client` Configuration
        The following `httpx.Client` parameters can be provided as keyword
        arguments and will be passed directly to the underlying object

        - `verify`
        - `cert`
        - `http1`
        - `http2`
        - `timeout`
        - `limits`
        - `transport`
        - `default_encoding`

        Additionally, the following `httpx.Client.request` parameters can be
        provided as keyword arguments during request execution

        - `timeout` (`r_timeout`)
        - `extensions`

        For more information on their behaviour and default values, please
        consult the official
        [`httpx`](https://www.python-httpx.org/api/#client) documentation

    warning: Unsupported HTTPX Client Arguments
        The underlying `httpx.Client` object is strictly managed by the
        instance to prevent invalid configurations from being sent to the
        `Scrape.do Async API`. For this reason, arguments not listed in the
        previous section are intentionally blocked and shouldn't be changed

    Args:
        api_token (Optional[str]): The Scrape.do API key. If omitted,
            falls back to the `SCRAPE_DO_API_KEY` environment variable
        max_retries (int): Maximum retry attempts on transient gateway
            errors (`429` / `502` / `503` / `504`)
        retry_backoff (Optional[Union[float, Callable[[int], float]]]): The
            strategy used to calculate the delay between retries. Can be a
            static `float` (seconds) or a callable that accepts the current
            attempt number (0-indexed) and returns a float. Defaults to a
            jittered exponential backoff when set to `None`
        event_hooks (Optional[AsyncAPIEventHooks]): A dictionary of
            SDK-native hooks to execute during different points of the
            Async-API request lifecycle
        verify (Union[ssl.SSLContext, str, bool]): Configures SSL certificate
            verification. Defaults to True (secure)
        cert (Optional[CertTypes]): Client-side certificates for mutual TLS
            authentication
        http1 (bool): Enable HTTP/1.1
        http2 (bool): Enable HTTP/2 multiplexing
        timeout (TimeoutTypes): Default timeout in seconds applied to
            every network phase
        limits (Limits): Connection pool limits
        transport (Optional[BaseTransport]): Custom transport engine
        default_encoding (Union[str, Callable[[bytes], str]]): The fallback
            text encoding used if a target website omits a charset header
    """

    BASE_URL = "https://q.scrape.do"
    """Base URL for the Scrape.do Async API"""

    API_PATH = "/api/v1"
    """API path prefix appended after `BASE_URL`"""

    def __init__(
        self,
        api_token: Optional[str] = None,
        max_retries: int = 3,
        retry_backoff: Optional[Union[float, Callable[[int], float]]] = None,
        event_hooks: Optional[AsyncAPIEventHooks] = None,
        *,
        verify: Union[ssl.SSLContext, str, bool] = True,
        cert: Optional[CertTypes] = None,
        http1: bool = True,
        http2: bool = False,
        timeout: TimeoutTypes = 60.0,
        limits: Limits = DEFAULT_LIMITS,
        transport: Optional[BaseTransport] = None,
        default_encoding: Union[str, Callable[[bytes], str]] = "utf-8",
    ) -> None:
        self.api_token = api_token or os.getenv("SCRAPE_DO_API_KEY")
        if not self.api_token:
            raise ValueError(
                "Scrape.do API token must be provided explicitly or set via"
                " the 'SCRAPE_DO_API_KEY' environment variable."
                )

        self.max_retries = max_retries

        if retry_backoff is not None:
            self.retry_backoff = retry_backoff
        else:
            self.retry_backoff = default_backoff_strategy

        self.event_hooks: AsyncAPIEventHooks = event_hooks or {}

        self._http_client = Client(
            base_url=f"{self.BASE_URL}{self.API_PATH}",
            headers={
                "X-Token": self.api_token,
                "Content-Type": "application/json",
                },
            verify=verify,
            cert=cert,
            trust_env=False,
            http1=http1,
            http2=http2,
            timeout=timeout,
            limits=limits,
            transport=transport,
            default_encoding=default_encoding,
            )

    # ----------------------------------------------------------------
    # Context Manager
    # ----------------------------------------------------------------

    def close(self) -> None:
        """Closes the underlying HTTPX connection pool.

        It is recommended to use the client as a context manager to ensure
        resources are released automatically.
        """
        self._http_client.close()

    def __enter__(self) -> Self:
        """Initializes the HTTPX connection pool and returns the context
        manager object

        Returns:
            The `ScrapeDoAsyncAPIClient` instance with an opened HTTPX
                connection pool
        """
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        exc_val: Optional[BaseException],
        exc_tb: Optional[TracebackType],
    ) -> Literal[False]:
        """Calls the `close` method to close the underlying HTTPX
        connection pool without swallowing any exceptions

        Args:
            exc_type (Optional[Type[BaseException]]): The type of the
                exception
            exc_val (Optional[BaseException]): The instance of the
                exception
            exc_tb (Optional[TracebackType]): The traceback information

        Returns:
            `False`, since no exceptions are swallowed
        """
        self.close()
        return False

    # ----------------------------------------------------------------
    # Internal Helpers
    # ----------------------------------------------------------------

    def _sleep(self, attempt: int) -> None:
        """Sleeps for the duration dictated by `self.retry_backoff`

        Args:
            attempt (int): The current zero-index attempt number
        """
        if callable(self.retry_backoff):
            time.sleep(self.retry_backoff(attempt))
        else:
            time.sleep(float(self.retry_backoff))

    def _request(
        self,
        method: HttpMethod,
        path: str,
        *,
        json_body: Optional[Any] = None,
        params: Optional[QueryParamTypes] = None,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
    ) -> httpx.Response:
        """Sends an HTTP request to a `Scrape.do Async API` endpoint with
        retry on transient gateway errors

        info: Usage
            This method is used internally by all of the client's
            endpoint-specific methods

        abstract: Execution
            - Applies the customisable `retry_backoff` strategy on
              retryable statuses

            - Fires the configured [`AsyncAPIEventHooks`]
            [scrape_do.async_api.client.AsyncAPIEventHooks]
              (`request` / `response` / `retry`)

            - Uses the [`_raise_for_status`]
            [scrape_do.async_api.client._raise_for_status] function to raise
            exceptions on network and API response errors, ensuring that the
            returned `httpx.Response` is successful

        Args:
            method (HttpMethod): HTTP method
            path (str): Endpoint path relative to `API_PATH`
            json_body (Optional[Any]): Optional JSON body for `POST`
            params (Optional[QueryParamsType]): Optional query
                parameters for `httpx` client's `request` method
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions for this specific request

        Returns:
            The successful `httpx.Response`

        Raises:
            AsyncAPIResponseError: Any typed Async-API error routed by
                status code
            APIConnectionError: If the underlying network transport
                fails for `max_retries + 1` consecutive attempts
        """
        last_exc: Optional[Exception] = None

        httpx_kwargs: Dict[str, Any] = {
            "method": method,
            "url": path,
            "json": json_body,
            "params": params,
            }
        if not isinstance(r_timeout, UseClientDefault):
            httpx_kwargs["timeout"] = r_timeout
        if extensions is not None:
            httpx_kwargs["extensions"] = extensions

        for attempt in range(self.max_retries + 1):
            built = self._http_client.build_request(**httpx_kwargs)

            # Fire request event hooks
            for req_hook in self.event_hooks.get("request", []):
                req_hook(built)

            try:
                resp = self._http_client.send(built)
            except RequestError as e:
                last_exc = e
                if attempt == self.max_retries:
                    raise APIConnectionError(
                        f"Network transport failed: {e}"
                        ) from e

                # If attempt < max_retries, fire retry hooks and sleep
                # according to retry_backoff before sending another request
                for retry_hook in self.event_hooks.get("retry", []):
                    retry_hook(attempt, built, None, e)

                self._sleep(attempt)
                continue

            # Not a network-error at this point

            # Fire response event hooks before any status-code routing
            for resp_hook in self.event_hooks.get("response", []):
                resp_hook(resp)

            if (
                resp.status_code in _RETRYABLE_STATUSES
                and attempt < self.max_retries
            ):
                # Fire retry hook with the failed request + response
                for retry_hook in self.event_hooks.get("retry", []):
                    retry_hook(attempt, built, resp, None)

                self._sleep(attempt)
                continue

            # If status code is not retryable or attempts are exhausted ->
            # Return the response if it's a successful 2xx
            # Otherwise, raise the relevant typed exception

            _raise_for_status(resp)
            return resp

        # Unreachable for any non-negative max_retries
        raise RuntimeError(  # pragma: no cover
            "Async API execution loop exhausted without returning a response"
            ) from last_exc

    # ----------------------------------------------------------------
    # Endpoints
    # ----------------------------------------------------------------

    def create_job(
        self,
        request: Optional[JobCreationRequest] = None,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
        **job_kwargs: Unpack[JobCreationRequestDict],
    ) -> JobCreationResponse:
        """Creates a new Async API job

        info: Parameter Configuration
            This method provides smart routing based on the arguments provided.
            You can configure the request in two ways

            - `job_kwargs` &rarr; Build a [`JobCreationRequest`]
            [scrape_do.async_api.models.parameters.JobCreationRequest]
            implicitly by passing the keyword-arguments accepted by the
            [`JobCreationRequestDict`]
            [scrape_do.async_api.models.parameters.JobCreationRequestDict]
            TypedDict

            - `Pre-Built Parameters`&rarr; Pass a validated
              [`JobCreationRequest`]
            [scrape_do.async_api.models.parameters.JobCreationRequest]
              instance directly to the `request` argument

        info: `job_kwargs` Additional Configuration
            Since [`JobCreationRequest`]
            [scrape_do.async_api.models.parameters.JobCreationRequest] accepts
            a [`Nested Pydantic Model`]
            [scrape_do.async_api.models.parameters.RenderParameters] for its
            `render` attribute, `job_kwargs` offers two ways to configure it

            - `Implicit Construction` &rarr; Pass
              [`every field accepted by the nested model`]
            [scrape_do.async_api.models.parameters.RENDER_PARAMETER_FIELDS]
            as a flat keyword-argument

            - `Explicit Construction` &rarr; Pass a validated
            [`RenderParameters`][scrape_do.async_api.models.parameters.RenderParameters]
            instance to the `render` keyword-argument

        warning: Parameter Restrictions
            To prevent silent overwrites and routing ambiguity, the client
            enforces that only one of the parameter configurations can be
            used at a time.

            - When using the `Pre-Built Parameters` configuration, passing any
              `job_kwargs` keyword-argument will raise a `ValueError`

            - When using the `job_kwargs` configuration, passing a
            [`JobCreationRequest`]
            [scrape_do.async_api.models.parameters.JobCreationRequest] to the
            `request` argument will raise a `ValueError`

            - When using the `job_kwargs` configuration, providing a pre-built
            `RenderParameters` instance via `job_kwargs["render"]` **AND** any
            other `job_kwargs` keyword-argument in [`RENDER_PARAMETER_FIELDS`]
            [scrape_do.async_api.models.parameters.RENDER_PARAMETER_FIELDS] at
            the same time raises a `ValueError`

        Args:
            request (Optional[JobCreationRequest]): Pre-built job
                creation body. Mutually exclusive with `**job_kwargs`
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions
            **job_kwargs (Unpack[JobCreationRequestDict]): Flat
                kwargs-based configuration

        Returns:
            The parsed `JobCreationResponse` containing the assigned
                `job_id` and per-task `task_ids`

        Raises:
            ValueError: If both `request` and `**job_kwargs` are
                provided, or if the flat render fields conflict with a
                pre-built `render` in `job_kwargs`
            AsyncAPIBadRequestError: On `HTTP 400`
            AsyncAPIAuthError: On `HTTP 401`
            AsyncAPIRateLimitError: On `HTTP 429` once retries are
                exhausted
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausted
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        if request is not None and job_kwargs:
            raise ValueError(
                "Provide either a 'request' JobCreationRequest instance"
                " or **job_kwargs, not both"
                )
        if request is None:
            request = _build_job_creation_request(**job_kwargs)

        payload = request.model_dump(
            mode="json",
            by_alias=True,
            exclude_none=True,
            )
        resp = self._request(
            "POST",
            "/jobs",
            json_body=payload,
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, JobCreationResponse)

    def get_job(
        self,
        job_id: str,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
    ) -> JobDetails:
        """Fetches the current state of an Async API job

        Args:
            job_id (str): UUID of the job to fetch
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions

        Returns:
            The parsed `JobDetails` model

        Raises:
            AsyncAPINotFoundError: If the job doesn't exist or has
                expired
            AsyncAPIAuthError: On `HTTP 401`
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausteds
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        resp = self._request(
            "GET",
            f"/jobs/{job_id}",
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, JobDetails)

    def list_jobs(
        self,
        query: Optional[JobListQueryParameters] = None,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
        **query_kwargs: Unpack[JobListQueryParametersDict],
    ) -> JobsListResponse:
        """Lists Async API jobs filtered / sorted by `query`

        info: Parameter Configuration
            This method provides smart routing based on the arguments provided.
            You can configure the request in two ways

            - `query_kwargs` &rarr; Build a [`JobListQueryParameters`]
            [scrape_do.async_api.models.parameters.JobListQueryParameters]
            implicitly by passing the keyword-arguments accepted by the
            [`JobListQueryParametersDict`]
            [scrape_do.async_api.models.parameters.JobCreationRequestDict]
            TypedDict

            - `Pre-Built Parameters` &rarr; Pass a validated
              [`JobListQueryParameters`]
            [scrape_do.async_api.models.parameters.JobListQueryParameters]
              instance directly to the `query` argument

        warning: Parameter Restrictions
            To prevent silent overwrites and routing ambiguity, the client
            enforces that only one of the parameter configurations can be
            used at a time.

            - When using the `Pre-Built Parameters` configuration, passing any
              `query_kwargs` keyword-argument will raise a `ValueError`

            - When using the `query_kwargs` configuration, passing a
            [`JobListQueryParameters`]
            [scrape_do.async_api.models.parameters.JobListQueryParameters] to
            the `query` argument will raise a `ValueError`

        Args:
            query (Optional[JobListQueryParameters]): Pre-built
                filter / sort / pagination shape. Mutually exclusive
                with `**query_kwargs`
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions
            **query_kwargs (Unpack[JobListQueryParametersDict]): Flat
                kwargs-based configuration

        Returns:
            The parsed `JobsListResponse` model

        Raises:
            ValueError: If both `query` and `**query_kwargs` are
                provided
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausted
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        if query is not None and query_kwargs:
            raise ValueError(
                "Provide either a 'query' JobListQueryParameters instance"
                " or **query_kwargs, not both"
                )
        if query is None and query_kwargs:
            query = JobListQueryParameters(**query_kwargs)

        params = query.to_query_dict() if query is not None else None
        resp = self._request(
            "GET",
            "/jobs",
            params=params,
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, JobsListResponse)

    def get_task(
        self,
        job_id: str,
        task_id: str,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
    ) -> TaskDetails:
        """Fetches the full details of a single task within a job

        Args:
            job_id (str): UUID of the parent job
            task_id (str): UUID of the task to fetch
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions

        Returns:
            The parsed `TaskDetails` model

        Raises:
            AsyncAPINotFoundError: If the job / task doesn't exist or
                has expired
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausted
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        resp = self._request(
            "GET",
            f"/jobs/{job_id}/{task_id}",
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, TaskDetails)

    def cancel_job(
        self,
        job_id: str,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
    ) -> CancelJobResponse:
        """Cancels an in-flight Async API job

        Args:
            job_id (str): UUID of the job to cancel
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions

        Returns:
            The parsed `CancelJobResponse` (same shape as `JobDetails`,
                with `Canceled=True`)

        Raises:
            AsyncAPINotFoundError: If the job doesn't exist or has
                expired
            AsyncAPINotAcceptableError: If the job is already in a
                terminal state and can no longer be canceled
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausted
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        resp = self._request(
            "DELETE",
            f"/jobs/{job_id}",
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, CancelJobResponse)

    def get_user_info(
        self,
        *,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
    ) -> UserInformation:
        """Fetches the current user / account information

        Args:
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions

        Returns:
            The parsed `UserInformation` model

        Raises:
            AsyncAPIAuthError: On `HTTP 401`
            AsyncAPIServerError: On `HTTP 5xx` once retries are
                exhausted
            AsyncAPIUnparsableResponseError: If the SDK can't parse a
                successful response to `q.scrape.do`
        """
        resp = self._request(
            "GET",
            "/me",
            r_timeout=r_timeout,
            extensions=extensions,
            )
        return _parse_response(resp, UserInformation)

    # ----------------------------------------------------------------
    # Polling Helpers
    # ----------------------------------------------------------------

    def wait_for_job(
        self,
        job_id: str,
        *,
        strategy: Optional[Union[PollingStrategy, PollingFunction]] = None,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None
    ) -> JobDetails:
        """Polls a job until it reaches a terminal status

        info: Strategy Argument
            - `None (default)` &rarr; Uses [`PollingStrategy()`]
            [scrape_do.async_api.polling.PollingStrategy] with its
              documented defaults

            - `Custom PollingStrategy Instance` &rarr; Uses
            [`PollingStrategy()`][scrape_do.async_api.polling.PollingStrategy]
            with the instance's custom configurations

            - [`PollingFunction`]
            [scrape_do.async_api.polling.PollingFunction] &rarr; Uses the
            provided callable to calculate sleep times between attempts and
            decide whether or not to stop polling before the job reaches a
            terminal status

        tip: Additional `strategy` Information
            - For more information on how the default polling strategy works
              and how to customise it, see the [`PollingStrategy`]
            [scrape_do.async_api.polling.PollingStrategy] docstring

            - For more information on how to define a custom polling function,
            see the [`PollingFunction`]
            [scrape_do.async_api.polling.PollingFunction] docstring

        Args:
            job_id (str): UUID of the job to poll
            strategy (Optional[Union[PollingStrategy, PollingFunction]]): How
                to poll for the job
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override applied to every `get_job`
                call
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions applied to every `get_job` call

        Returns:
            The terminal `JobDetails` snapshot

        Raises:
            JobTimeoutError: If `strategy` raises
        """
        if strategy is None:
            strategy = PollingStrategy()

        start = time.monotonic()
        attempt = 0

        while True:
            job = self.get_job(
                job_id,
                r_timeout=r_timeout,
                extensions=extensions
                )
            if job.status in TERMINAL_STATUSES:
                return job

            # Fire poll event hooks on every non-terminal snapshot
            for poll_hook in self.event_hooks.get("poll", []):
                poll_hook(attempt, job)

            elapsed = time.monotonic() - start
            sleep_for = strategy(attempt, elapsed, job)

            time.sleep(sleep_for)
            attempt += 1

    def submit_and_wait(
        self,
        request: Optional[JobCreationRequest] = None,
        *,
        strategy: Optional[Union[PollingStrategy, PollingFunction]] = None,
        r_timeout: Union[TimeoutTypes, UseClientDefault] = USE_CLIENT_DEFAULT,
        extensions: Optional[RequestExtensions] = None,
        **job_kwargs: Unpack[JobCreationRequestDict]
    ) -> JobResult:
        """Submits a job, polls until terminal, and fetches every task

        warning: Parameter Configuration
            - This method reuses the same smart-routing as the client's
              job-creation method

            - For more information, see the [`create_job`]
            [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.create_job]
            method's docstring

        warning: Polling Configuration
            - This method passes the `strategy` argument unchanged to the
              client's polling helper

            - For more information, see the [`wait_for_job`]
            [scrape_do.async_api.client.ScrapeDoAsyncAPIClient.wait_for_job]
            method's docstring

        Args:
            request (Optional[JobCreationRequest]): Pre-built job
                creation body. Mutually exclusive with `**job_kwargs`
            strategy (Optional[Union[PollingStrategy, PollingFunction]]): How
                to poll for the job
            r_timeout (Union[TimeoutTypes, UseClientDefault]): A
                request-specific timeout override applied to every
                underlying HTTP call (create / poll / fetch)
            extensions (Optional[RequestExtensions]): Advanced HTTPX
                extensions applied to every underlying HTTP call
            **job_kwargs (Unpack[JobCreationRequestDict]): Flat
                kwargs-based configuration

        Returns:
            A `JobResult` bundling the terminal `JobDetails` with the
                fetched `List[TaskDetails]` (one per task, in input
                order)

        Raises:
            ValueError: If both `request` and `**job_kwargs` are
                provided, or if mixed render configurations are detected
            JobFailedError: If the job reaches terminal status `error`
            JobCanceledError: If the job reaches terminal status
                `canceled`
            JobTimeoutError: If `strategy` raises
        """
        creation = self.create_job(
            request=request,
            r_timeout=r_timeout,
            extensions=extensions,
            **job_kwargs,
            )
        job = self.wait_for_job(creation.job_id, strategy=strategy)

        tasks = [
            self.get_task(
                job.job_id,
                tid,
                r_timeout=r_timeout,
                extensions=extensions,
                )
            for tid in job.task_ids
            ]
        result = JobResult(job=job, tasks=tasks)

        job.raise_for_status()

        return result


__all__ = [
    "AsyncAPIEventHooks",
    "ScrapeDoAsyncAPIClient"
    ]
