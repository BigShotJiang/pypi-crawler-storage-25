from dataclasses_json import DataClassJsonMixin
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Fault(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: List[str]
    name: str


@dataclass
class Horizon(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: List[str]
    name: str


@dataclass
class Explicit(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: str
    name: str
    faults: Optional[List[Fault]] = None
    horizons: Optional[List[Horizon]] = None
