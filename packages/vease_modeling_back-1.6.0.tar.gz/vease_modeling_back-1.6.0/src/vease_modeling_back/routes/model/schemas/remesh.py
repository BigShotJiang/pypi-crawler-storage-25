from dataclasses_json import DataClassJsonMixin
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Block(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: str
    metric: float


@dataclass
class Corner(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: str
    metric: float


@dataclass
class Line(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: str
    metric: float


@dataclass
class Surface(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    id: str
    metric: float


@dataclass
class Remesh(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    default: float
    """Default mesh size"""

    id: str
    name: str
    blocks: Optional[List[Block]] = None
    corners: Optional[List[Corner]] = None
    gradation: Optional[float] = None
    lines: Optional[List[Line]] = None
    surfaces: Optional[List[Surface]] = None
