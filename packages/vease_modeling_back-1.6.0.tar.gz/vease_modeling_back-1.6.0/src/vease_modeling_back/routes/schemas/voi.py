from dataclasses_json import DataClassJsonMixin
from dataclasses import dataclass
from typing import Optional


@dataclass
class Voi(DataClassJsonMixin):
    def __post_init__(self) -> None:
        print(self, flush=True)

    name: str
    """Name of the VOI"""

    aoi_id: Optional[str] = None
    """ID of the corresponding AOI"""

    id: Optional[str] = None
    """Optional ID for updating existing VOI"""

    z_max: Optional[float] = None
    """Maximum Z coordinate"""

    z_min: Optional[float] = None
    """Minimum Z coordinate"""
