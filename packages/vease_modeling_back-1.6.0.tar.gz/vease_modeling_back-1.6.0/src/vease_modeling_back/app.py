# Standard library imports

# Third party imports
import flask
from opengeodeweb_back.app import create_app, run_server, register_ogw_back_blueprints

# Local application imports
import vease_modeling_back.routes.blueprint_create as blueprint_create
import vease_modeling_back.routes.model.blueprint_model as blueprint_model

url_prefix = "/vease_modeling_back"


def create_vease_modeling_back_app() -> flask.Flask:
    app = create_app(__name__)
    register_ogw_back_blueprints(app)
    app.register_blueprint(
        blueprint_create.routes,
        url_prefix=url_prefix,
        name="create",
    )
    app.register_blueprint(
        blueprint_model.routes,
        url_prefix=f"{url_prefix}/model",
        name="models",
    )
    return app


def run_vease_modeling_back() -> flask.Flask:
    app = create_vease_modeling_back_app()
    run_server(app)
    return app


if __name__ == "__main__":
    run_vease_modeling_back()
