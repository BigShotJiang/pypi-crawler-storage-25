"""CodeGreen CLI module"""
