"""Energy profiler interfaces for CodeGreen and perf RAPL."""
import json
import re
import subprocess
import tempfile
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List

@dataclass
class ProfileResult:
    energy_joules: float
    time_seconds: float
    output: str
    checkpoints: List[Dict[str, Any]]
    raw_data: Dict[str, Any]

class ProfilerInterface(ABC):
    @abstractmethod
    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        pass

    @abstractmethod
    def is_available(self) -> bool:
        pass

class CodeGreenProfiler(ProfilerInterface):
    """Uses codegreen measure CLI for energy measurement."""
    def __init__(self):
        self.source_path: Path | None = None
        self.language: str | None = None

    def set_source(self, source: Path, language: str = None):
        """Set source file and language for measurement."""
        self.source_path = source
        self.language = language

    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        # Use stored source/language if available (unified approach)
        if self.source_path and self.language:
            source = str(self.source_path)
            lang = self.language
            # Extract args from the original command (skip interpreter/binary)
            if cmd[0] == "python3":
                args = cmd[2:] if len(cmd) > 2 else []
            elif cmd[0] == "java":
                args = cmd[3:] if len(cmd) > 3 else []  # java -cp dir class args
            else:
                args = cmd[1:] if len(cmd) > 1 else []  # binary args
        else:
            # Fallback: detect from command
            lang, source, args = self._detect_from_cmd(cmd)

        import os
        full_cmd = ["codegreen", "measure", lang, source, "--json", "--timeout", str(timeout)] + args
        env = {**os.environ, "PYTHONUNBUFFERED": "1"}

        start = time.perf_counter()
        result = subprocess.run(full_cmd, capture_output=True, text=True, timeout=timeout + 30, env=env)
        elapsed = time.perf_counter() - start

        energy, checkpoints, raw, program_output = self._parse_output(result.stdout)
        if energy <= 0.0 and checkpoints:
            energy = 0.0
        return ProfileResult(energy_joules=energy, time_seconds=elapsed, output=program_output, checkpoints=checkpoints, raw_data=raw)

    def _detect_from_cmd(self, cmd: List[str]) -> tuple:
        """Fallback: detect language, source, args from command."""
        if cmd[0] == "python3":
            return "python", cmd[1] if len(cmd) > 1 else cmd[0], cmd[2:] if len(cmd) > 2 else []
        elif cmd[0] == "java":
            # java -cp dir class args -> need source from set_source
            return "java", str(self.source_path) if self.source_path else "", cmd[3:] if len(cmd) > 3 else []
        else:
            # Compiled binary
            source = str(self.source_path) if self.source_path else cmd[0]
            lang = "cpp" if (".gpp" in source or "cpp" in source) else "c"
            return lang, source, cmd[1:] if len(cmd) > 1 else []

    def _parse_output(self, stdout: str) -> tuple:
        energy, checkpoints, raw, program_output = 0.0, [], {}, ""
        try:
            raw = json.loads(stdout)
        except (json.JSONDecodeError, ValueError):
            return energy, checkpoints, raw, stdout

        # Extract energy from summary (primary) or checkpoints (fallback)
        summary = raw.get("summary", {})
        if summary.get("total_energy_j", 0) > 0:
            energy = summary["total_energy_j"]

        checkpoints = raw.get("checkpoints", [])
        if energy <= 0 and len(checkpoints) >= 2:
            first_j = checkpoints[0].get("joules", 0)
            last_j = checkpoints[-1].get("joules", 0)
            energy = last_j - first_j
            if energy < 0:
                energy = 0.0

        return energy, checkpoints, raw, program_output

    def is_available(self) -> bool:
        try:
            with open("/sys/class/powercap/intel-rapl:0/energy_uj") as f:
                f.read()
            return True
        except (FileNotFoundError, PermissionError, OSError):
            return False

class PerfProfiler(ProfilerInterface):
    def __init__(self):
        self.perf_output_file: Path | None = None
        self._events = self._detect_events()
        self.repeat_count: int = 1

    def __del__(self):
        self._cleanup()

    def _detect_events(self) -> str:
        try:
            result = subprocess.run(["perf", "list", "power"], capture_output=True, text=True, timeout=5)
            events = []
            if "energy-pkg" in result.stdout:
                events.append("power/energy-pkg/")
            if "energy-ram" in result.stdout:
                events.append("power/energy-ram/")
            return ",".join(events) if events else "power/energy-pkg/"
        except Exception:
            return "power/energy-pkg/"

    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            self.perf_output_file = Path(f.name)
        if self.repeat_count > 1:
            shell_cmd = " ".join(f"'{c}'" for c in cmd)
            loop_cmd = f"for i in $(seq 1 {self.repeat_count}); do {shell_cmd}; done"
            full_cmd = ["perf", "stat", "-e", self._events, "-o",
                        str(self.perf_output_file), "--", "bash", "-c", loop_cmd]
        else:
            full_cmd = ["perf", "stat", "-e", self._events, "-o",
                        str(self.perf_output_file), "--"] + cmd
        start = time.perf_counter()
        result = subprocess.run(full_cmd, capture_output=True, text=True, timeout=timeout)
        elapsed = time.perf_counter() - start
        energy = self._parse_perf_output()
        if self.repeat_count > 1:
            energy /= self.repeat_count
            elapsed /= self.repeat_count
        return ProfileResult(
            energy_joules=energy,
            time_seconds=elapsed,
            output=result.stdout,
            checkpoints=[],
            raw_data={"perf_output": self.perf_output_file.read_text() if self.perf_output_file.exists() else "",
                       "repeat_count": self.repeat_count}
        )

    def _parse_perf_output(self) -> float:
        if not self.perf_output_file or not self.perf_output_file.exists():
            return 0.0
        content = self.perf_output_file.read_text()
        total = 0.0
        pkg_match = re.search(r'([\d.,]+)\s+Joules\s+power/energy-pkg/', content)
        if pkg_match:
            total += float(pkg_match.group(1).replace(',', ''))
        ram_match = re.search(r'([\d.,]+)\s+Joules\s+power/energy-ram/', content)
        if ram_match:
            total += float(ram_match.group(1).replace(',', ''))
        return total

    def _cleanup(self):
        if self.perf_output_file and self.perf_output_file.exists():
            try:
                self.perf_output_file.unlink()
            except OSError:
                pass
            self.perf_output_file = None

    def is_available(self) -> bool:
        try:
            result = subprocess.run(["perf", "list", "power"], capture_output=True, text=True, timeout=5)
            return "energy-pkg" in result.stdout
        except (subprocess.TimeoutExpired, FileNotFoundError):
            return False

class NativeProfiler(ProfilerInterface):
    """Runs without energy profiling - for baseline timing."""
    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        start = time.perf_counter()
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        elapsed = time.perf_counter() - start
        return ProfileResult(
            energy_joules=0.0,
            time_seconds=elapsed,
            output=result.stdout,
            checkpoints=[],
            raw_data={}
        )

    def is_available(self) -> bool:
        return True

class CodeCarbonProfiler(ProfilerInterface):
    """Wraps CodeCarbon for energy measurement (requires: pip install codecarbon)."""
    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        try:
            from codecarbon import EmissionsTracker
        except ImportError:
            return ProfileResult(0.0, 0.0, "", [], {"error": "codecarbon not installed"})
        tracker = EmissionsTracker(log_level="error", save_to_file=False)
        tracker.start()
        start = time.perf_counter()
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        elapsed = time.perf_counter() - start
        emissions = tracker.stop()
        energy = tracker._total_energy.kWh * 3_600_000  # kWh -> J
        return ProfileResult(energy, elapsed, result.stdout, [],
                             {"emissions_kg_co2": emissions, "energy_kwh": tracker._total_energy.kWh})

    def is_available(self) -> bool:
        try:
            import codecarbon
            return True
        except ImportError:
            return False


class JoularJXProfiler(ProfilerInterface):
    """Wraps JoularJX for Java energy measurement (requires JoularJX agent jar)."""
    def __init__(self, agent_path: str = ""):
        self.agent_path = agent_path or self._find_agent()

    def _find_agent(self) -> str:
        for p in [Path("joularjx-agent.jar"), Path.home() / ".joularjx" / "joularjx-agent.jar"]:
            if p.exists():
                return str(p)
        return ""

    def run(self, cmd: List[str], timeout: int = 300) -> ProfileResult:
        if not self.agent_path:
            return ProfileResult(0.0, 0.0, "", [], {"error": "JoularJX agent not found"})
        jx_cmd = cmd.copy()
        if cmd[0] == "java":
            jx_cmd.insert(1, f"-javaagent:{self.agent_path}")
        start = time.perf_counter()
        result = subprocess.run(jx_cmd, capture_output=True, text=True, timeout=timeout)
        elapsed = time.perf_counter() - start
        energy = self._parse_joularjx_output()
        return ProfileResult(energy, elapsed, result.stdout, [], {"agent": self.agent_path})

    def _parse_joularjx_output(self) -> float:
        csv_path = Path("joularJX-all-methods-energy.csv")
        if not csv_path.exists():
            return 0.0
        total = 0.0
        for line in csv_path.read_text().splitlines()[1:]:
            parts = line.split(",")
            if len(parts) >= 2:
                try:
                    total += float(parts[-1])
                except ValueError:
                    pass
        return total

    def is_available(self) -> bool:
        return bool(self.agent_path) and Path(self.agent_path).exists()


def get_profiler(name: str) -> ProfilerInterface:
    profilers = {
        "codegreen": CodeGreenProfiler,
        "perf": PerfProfiler,
        "native": NativeProfiler,
        "codecarbon": CodeCarbonProfiler,
        "joularjx": JoularJXProfiler,
    }
    if name not in profilers:
        raise ValueError(f"Unknown profiler: {name}. Available: {list(profilers.keys())}")
    return profilers[name]()
