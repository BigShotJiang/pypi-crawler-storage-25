# Viewer audit — 2026-05-09

각 페이지의 API 응답 + 코드 점검 결과. 사용자 실 데이터 (7,494 files / 406 folders / 1,548-op b13 plan applied).

## 페이지별 상태

### Dashboard (`/`) — ✅ 정상

API: `/api/stats` + `/api/duplicates` + `/api/permissions`
- `total_files_count: 7494`, `last_scan_at`, `last_classify_at` 정확
- Freshness chips, 검토 요청 / 공유받음 알림 카드 모두 정상 작동
- Storage Used / Indexed Items / Wasted Space 메트릭 정확

### Explorer (`/explorer`) — ✅ 정상

이번 세션에서 집중 개선됨:
- 가상 폴더 `⚠️ 검토 요청` (1 직계, 자손 2)
- 가상 폴더 `👥 공유받음` (1 직계, 자손 55)
- 폴더 색상 (`folderColorRgb`) 반영
- 자손 카운트 (직계 + 자손 + files + folders 분리)
- 외부 deep-link `↗`, orphan/external 배지

### Plan Review (`/plan`) — ✅ 잘 되어있음

API: `/api/plan` + `/api/last-applied`
- 1,548 ops 표시, op-type 필터, 검색, subset 승인 메커니즘
- `last-applied` 패널이 마지막 apply 메타데이터 보여줌
- viewer_operation_id로 op별 체크박스 → 승인 → CLI plan apply가 subset만 적용
- **관찰**: latest plan이 이미 적용됐을 때(`approved_plan_present: false` 이고 `last_applied`가 이 plan과 매칭) 명확한 "이미 적용됨" 배너가 더 있으면 좋을 것

### Permissions (`/permissions`) — ⚠️ 의미 broken

API: `/api/permissions` 응답:
```json
{ "public": 0, "domain": 0, "specific_users": 0, "not_shared": 7494, "details": {...} }
```

**문제**: 7,494 파일이 모두 `not_shared`. 실제로는:
- 55개는 외부 공유 (jhjung 등 9명) — `ownedByMe=False`
- 일부 사용자 본인 파일도 외부에 공유돼 있을 가능성

**원인 추정**: `summarize_permissions`가 `f.shared` 필드를 보지만, 이 필드는 사용자 본인이 공유한 경우에만 True. 외부에서 공유받은 파일은 shared=False로 들어옴. 또한 permissions 배열 enrichment는 full scan에서만 실행되고 incremental에서는 누락.

**권장 fix**:
- "Shared with me" 분류 추가 — `ownedByMe=False AND parents non-empty` 매칭
- "Shared by me" 분류 명확화
- Permissions enrichment를 incremental scan에서도 변경분에 한해 실행

### Duplicates (`/duplicates`) — ⚠️ 빈 파일 그룹 노이즈

API 결과:
- 105 그룹 표시, 그 중 1 그룹은 빈 파일 35개 (md5 `d41d8cd9...` = empty 콘텐츠)
- 진짜 중복: 104 그룹, 약 19.2 MB 절약 가능
- Top 절약 후보: pptx 파일 중복 (`성능 평가 결과서.pptx`, `모델 정의서.pptx` 등)

**문제**: 빈 파일끼리 같은 md5라서 한 그룹으로 묶임. `__init__.py`, `requirements.txt` 같은 정상 파일도 빈 상태일 수 있음 — "duplicates" 의미가 깨짐.

**권장 fix**: `api_duplicates`에 `if size == 0: continue` 추가, 또는 빈 파일 그룹은 별도 카테고리로 표시.

### Settings (`/settings`) — ⏳ 별도 audit 필요

`loadSettings` 함수만 봤고 실 응답은 미점검. 사용자가 직접 확인 권장.

### Search (⌘K / `/api/files`) — ✅ 동작, ⚠️ 개선점 있음

`q=README` → 65 매치 정상. 단, 결과에 path 정보 없어서 같은 이름 파일 구분 어려움.

**권장 fix**: `_file_summary`에 `path` 필드 추가, frontend가 이름 옆에 회색으로 표시.

## 종합 우선순위

| # | 항목 | 사이즈 | 효과 |
|---|---|---|---|
| 1 | Duplicates 빈 파일 필터 | XS (1줄) | 105 → 104 노이즈 즉시 제거 |
| 2 | Search 결과 path 표시 | XS | 동명 파일 구분 |
| 3 | Permissions "Shared with me" 분리 | S | 외부 공유 가시성 |
| 4 | Plan Review "이미 적용됨" 배너 명확화 | S | 사용자 혼란 방지 |
| 5 | Settings 페이지 직접 사용 점검 | (사용자 작업) | - |

이 중 #1, #2는 다음 작업(#5 duplicates 일괄 정리) 진행 전에 같이 처리하면 좋음.
