A same-day b8 follow-up driven by 4 issues found in viewer dogfood: viewer/Drive mismatch on root, broken folder counts, missing folder colors, and a planner correctness fix on the time archive.

**Fixed**

- **Time archive uses `created_time`, not `modified_time`.** Our own apply ops bump `modifiedTime` on Drive, so using it for `YYYY/MM` collapsed every previously-archived file into the apply month. The planner now prefers `created_time` (falls back to `modified_time` for legacy files lacking a created timestamp). Migration + second-brain system prompts updated so the LLM picks the bucket from `created` and explicitly avoids `modified`. Existing wrong-bucket files will be re-routed on the next classify cycle.
- **Folder counts are recursive descendants, not just direct children.** Big subtrees were showing tiny numbers — 부트캠프 was "353" but actually contains 871. The viewer now walks each subtree once (iterative DFS, memoized) and exposes total, direct, files, folders. Hovering the count chip shows the breakdown.

**Added**

- **`⚠️ 검토 요청` virtual folder for orphans.** J6's reparent (b6) lifts files whose direct parent is in trash to the snapshot root, but listing them at the real root confused users comparing the viewer with the Drive UI ("but I don't have these files at root!"). They're now bundled under a synthetic top-level folder (dashed amber border + alert-triangle icon). Each file inside carries a `상위 폴더 삭제 - 검토 요망` badge explaining why it's there. The dashboard surfaces the total via a header alert.
- **Folder colors matter again.** Drive's `folderColorRgb` is now read on scan (snapshot stores it; viewer tints the icon) AND written on `CREATE_FOLDER` ops by the runner. The planner assigns every newly-created folder a stable color from Drive's official 24-color palette via `hash(name) % palette` — same name produces the same color across runs. AI roots get fixed brand colors: `🪄 AI 정리` → indigo, `보관함` → grey, `미분류` → orange.

**API additions for the viewer frontend**

- `directChildCount`, `descendantFiles`, `descendantFolders`, `folderColor`, `isOrphan`, `isVirtualReview` on each tree node.
- `orphan_count` on `/api/stats`.

**Migration note**

The b8→b9 upgrade keeps your existing snapshot working. To get folder colors into the viewer and re-route any wrong-bucket files (from the old `modified_time` archive), run:

```bash
gdrive-organizer scan --incremental
gdrive-organizer classify --preset migration
gdrive-organizer plan apply --dry-run     # destination 분포로 변경 폭 확인
gdrive-organizer plan apply -y
```

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
