A long-pending feature ships, plus a quick viewer audit pass and CI hygiene.

**Added — Bulk duplicate cleanup**

- `gdrive-organizer cleanup-duplicates` CLI command + `POST /api/duplicates/cleanup` viewer endpoint + checkboxes/button on the Duplicates page. Generates a TRASH-only plan that keeps the newest file in each md5 group (deterministic tiebreak: modified_time → version → id) and queues the rest for the trash.
- Safety rails enforced everywhere: skip files where `size == 0` (the empty-content md5 was producing a noisy 35-file "duplicate group"), skip files without md5 (Workspace docs etc), skip files we don't own (Drive denies the write), skip orphan-subtree files. Drive's trash keeps deleted files for 30 days, so a misclick is recoverable.
- The CLI saves a normal plan you review with `plan apply --dry-run`. The viewer button writes straight to `approved-plan.json` after a two-step confirmation (count + trash ack), then the user runs `plan apply -y` from the terminal — keeping the CLI as the single mutation entry point.

**Fixed**

- **Empty files no longer pollute the duplicates list.** `__init__.py`, `requirements.txt`, `archive.xlsx` etc. all sharing the empty-content md5 was forming a meaningless 35-file group. `/api/duplicates` now filters out `size == 0` files.
- **Search results show the parent folder** alongside the filename. Distinguishing `README.md` #1 vs #65 used to require clicking each one.

**Infrastructure**

- **CI workflows force Node 24** via `FORCE_JAVASCRIPT_ACTIONS_TO_NODE24=true`. Validated by the existing test matrix against pinned action versions (checkout@v4, setup-python@v5, setup-uv@v6, upload/download-artifact@v4). Prepares for the 2026-06-02 Node 20 default-removal without bumping every action major version.

**Migration**

```bash
gdrive-organizer scan --incremental
gdrive-organizer cleanup-duplicates    # generates a plan
gdrive-organizer plan apply --dry-run  # review
gdrive-organizer plan apply -y         # commit
```

Or via the viewer's Duplicates page → check groups → 선택 그룹 정리 → run `plan apply -y`.

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
