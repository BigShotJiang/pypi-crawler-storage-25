b11 dogfood revealed a class of items that looked like orphans but weren't — folders shared by other users (e.g. `자료실` shared by jhjung@dschloe.com). Drive denies our writes through them just like through trashed parents, but they need a different conceptual treatment: informational, not actionable. b12 cleanly splits the two everywhere.

**Fixed**

- **External folders no longer slip past the planner.** b11's orphan filter only caught true orphans (parents=[]). An external folder like `자료실` (parents=[root_id], ownedByMe=False) passed through; the LLM proposed shortcuts under `자료실/Book`; Drive 403'd on every one. The planner now folds external folders into the same unwriteable-subtree exclusion as orphans, with transitive descendant coverage. **Effect: 5 of 6 b11-cycle apply failures → 0 expected.**

- **External files skip all ops in the planner**, not just MOVE — same Drive 403 reason, applied consistently across MOVE / SHORTCUT / DESCRIPTION.

**Added**

- **Two virtual folders in the viewer instead of one:**
  - `⚠️ 검토 요청` — true orphans (parents=[] AND owned by me). Actionable: untrash the parent in Drive UI, then re-classify.
  - `👥 공유받음` — external (ownedByMe=False). Informational: someone else owns these; we have at most read access.

  Each gets its own dashed-border tint (amber / sky) and its own dashboard alert card with the right language. Files inside carry color-matched badges (`상위 폴더 삭제 - 검토 요망` vs `공유받음`).

- **`isExternal` flag** on each tree node + **`external_count`** on `/api/stats`, alongside the existing `isOrphan` / `orphan_count`.

**Migration**

No new state. After upgrading, the next viewer page-load will show the new split automatically. The next classify will produce a smaller plan because shortcuts under `자료실` (and any other external folder) won't be proposed anymore.

```bash
gdrive-organizer scan --incremental
gdrive-organizer classify --preset migration
gdrive-organizer plan apply --dry-run
```

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
