# Scan Performance Investigation

**Status**: open hypothesis — instrumentation added, root-cause fix not yet applied.

## Observed (2026-05-01 dogfood)

- 1,500 files / 310 folders / 1.5 GB drive
- `gdrive-organizer scan` (full): **19 minutes wall**, ~1% CPU
- Drive API quota: 12,000 reads/min — observed throughput ~88 files/sec
  (~5,300/min), well under quota

## What is *not* the cause

- **Permissions N+1**: `crawler.py` deliberately omits the `permissions` field
  from `files.list` because that field caps `pageSize` at 100. Permissions are
  fetched per-file only for files where `ownedByMe` AND `shared` are both true
  (`enrich_permissions_for_shared`). On the audited drive, 0 files met this
  criterion after `공유/` and `호스팅 이미지/` were excluded — so this loop
  ran zero iterations and cannot explain the 19-minute wall.

## Likely causes (ranked)

1. **Field cardinality**: `_FILE_FIELDS` requests ~25 fields including
   `imageMediaMetadata`, `videoMediaMetadata`, `sharingUser`,
   `lastModifyingUser`. Each adds server-side lookups before the response is
   serialized. A field-slimming variant for the bulk scan path could shave
   significant latency.
2. **Cold-cache server latency**: Drive often serves first request slowly
   (cold cache for the user's tree) and warms up across pagination.
3. **Transient retry**: `with_retry` retries 429/500/503 with exponential
   backoff up to 64s. Without per-page logs we couldn't tell if the scan hit
   any retries during dogfood.

## What we added (this PR)

`crawler.py:scan_all_files` now logs per-page latency to
`logs/gdrive-organizer.log`:

```
scan page 1: 1000 files, 12.34s (1000 total so far)
scan page 2: 500 files, 6.78s (1500 total so far)
scan complete: 1500 files in 2 pages, 19.12s total
```

Next time a slow scan happens, the log will show whether it's the first page,
all pages, or specific retries.

## What we shipped (b8)

`scan --minimal-fields` requests only the fields the planner + tree builder
strictly need (`_MINIMAL_FILE_FIELDS` in `crawler.py`). Trade-off: skips
the permissions and revisions enrichment phases, since both rely on fields
the slim set deliberately omits.

Use this to test the field-cardinality hypothesis on the same drive:

```bash
time uv run gdrive-organizer scan                    # baseline
time uv run gdrive-organizer scan --minimal-fields   # slim
```

Record the wall-clock delta here when measured.

## Possible follow-ups (not in this PR)

- Investigate parallel pagination via `pageToken` chains (currently sequential).
- Profile `_execute_list` over a real scan once we have logs to diagnose.

---

# Classify performance

## Measurements (1500-file Drive, migration preset)

| Run | Wall time | Snippet | LLM batch | Notes |
|-----|-----------|---------|-----------|-------|
| Pre-dogfood (b3) | **21 min 02 s** | ~6 min serial | ~15 min serial | baseline |
| Post-snippet-gate (b5) | **14 min 17 s** | 0 s (skipped) | ~14 min serial | `preset.requires_content` (#4) |
| Post-LLM-parallel | **1 min 35 s** | 0 s | ~1 min 35 s parallel | gather + client's `Semaphore(10)` |

That's a **13× total speedup** (21 min → 1 min 35 s) and **9× on the LLM
phase alone**. Each subsequent improvement isolates a real bottleneck:

1. The snippet gate was easy and exact — migration is metadata-only, so
   downloading content for 590 Workspace docs was pure waste.
2. The LLM phase was harder because it required us to trust that out-of-
   order responses didn't break downstream consumers (validator, conflict
   detection, `_response_to_operations`). All of these key off `file_id`
   and don't care about batch order, so `asyncio.gather` is safe.

The client's internal `Semaphore(MAX_CONCURRENT=10)` does the throttling —
launching 26 batches at once just queues 16 of them at the semaphore.
