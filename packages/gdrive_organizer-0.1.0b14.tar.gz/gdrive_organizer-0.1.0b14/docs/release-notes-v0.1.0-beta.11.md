A polish pass on b10's planner. Two rough edges from the b10 dogfood — wasteful description regeneration and a transitive orphan miss — both closed. End-to-end re-classify on the user's Drive shrinks from b10's 1,343 ops to **356 ops**.

**Fixed**

- **Description rewrite waste.** The LLM regenerated descriptions for every file on every cycle even when the existing one was already a good Korean summary, so DESCRIPTION ops stayed at ~1,200 each cycle. The preset input now carries `existing_description` and the JSON contract tells the LLM to return null for `new_description` when the existing one is already a reasonable search summary. Real effect: DESCRIPTION 1,241 → 1 on the user's Drive.

- **Transitive orphan subtree exclusion.** b10's orphan filter only caught direct orphans (parents=[]). A child folder of an orphan — like `자료실/Book` whose parents list is `[자료실_id]` — passed through, and the apply 403'd because Drive denies writes to anything reachable through a trashed ancestor. The planner now BFS's down from each orphan-folder root and excludes the entire subtree from `_get_existing_folders` / `_get_existing_folder_index`.

- **Plan Summary table** now shows the Renames / Rename + Moves rows that PlanStats already tracked but the CLI was silently dropping.

**Added**

- **Drive deep-link on orphan files in the viewer.** `⚠️ 검토 요청` folder rows now render a small `↗` icon next to the orphan badge that opens the file's `webViewLink` in a new tab. The badge tooltip points the user to the manual fix path: untrash the parent in Drive UI (or move the file out), then the next `classify` will pick it up.

**Migration**

No new state; just upgrade and re-classify on your existing snapshot. Effect is most visible if you've previously run apply with an earlier release — the smaller plan reflects how much of the prior work the planner now correctly identifies as "already done."

```bash
gdrive-organizer scan --incremental
gdrive-organizer classify --preset migration
gdrive-organizer plan apply --dry-run
gdrive-organizer plan apply -y
```

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
