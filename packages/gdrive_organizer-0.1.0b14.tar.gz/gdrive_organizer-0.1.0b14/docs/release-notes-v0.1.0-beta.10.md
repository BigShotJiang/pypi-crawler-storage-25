Three planner correctness fixes that compounded into a much tighter cycle: re-classify on the user's 1,500+ file Drive went from b9's 3,944-op plan to 1,343 ops with zero predicted failures.

**Fixed**

- **Orphan files and orphan-folder targets are now skipped** (P1). Files whose direct parent is in trash (the J6 reparent surfaces them at root) hit Drive 403 on every write — the API treats trashed-parent paths as read-only. The b9 dogfood produced exactly 6 such failures: 1 MOVE on `LG U+ Why Not SW Camp 6기 블로그` and 5 SHORTCUT ops targeting the orphan `자료실` folder. The planner now excludes orphans from `_get_existing_folders` / `_get_existing_folder_index` so the LLM never proposes them as shortcut targets, and skips ALL ops (MOVE / SHORTCUT / DESCRIPTION) for orphan source files. The skipped count is logged so the user knows what needs manual attention via the viewer's `⚠️ 검토 요청` folder.

- **No-op detection on MOVE / DESCRIPTION / SHORTCUT** (P4). Re-classify on an already-organized Drive previously regenerated every op — burning API quota and duplicating shortcuts on every cycle. The planner now skips:
  - MOVE when the file is already at the target parent,
  - UPDATE_DESCRIPTION when the new text equals the current (whitespace-normalized),
  - CREATE_SHORTCUT when the same `(target, parent)` shortcut is already in the snapshot.

  Real-world impact on the user's Drive: MOVE 1242→1, SHORTCUT 1457→286. DESCRIPTION still high because the LLM regenerates the text on each call (a separate prompt-side problem).

- **Plan Summary table now shows Folder colors** count, not just Moves/Shortcuts/Descriptions/Trashed.

**Added**

- **`UPDATE_FOLDER_COLOR` op + automatic backfill** (P3). AI folders from earlier releases (pre-b9) shipped without `folderColorRgb`, so 28 of the user's `🪄 AI 정리/...` folders showed as default grey in Drive. The planner now backfills them from the same hash-based palette that new folders get, strictly scoped to the AI_ROOT subtree. Drive's `#8f8f8f` "no color set" sentinel is treated as missing — otherwise none of the b8-era folders qualified. Runner Phase 4 applies the op; rollback restores the prior color when one was recorded.

- **`shortcut_target_id` on `DriveFile`** so the planner can deduplicate shortcuts.

**Migration**

After upgrading, run a one-time full scan so the snapshot is rewritten with `shortcut_target_id` populated and folder colors are read from Drive:

```bash
gdrive-organizer scan          # full, ~19 min on a 5K-file Drive
gdrive-organizer classify --preset migration
gdrive-organizer plan apply --dry-run
gdrive-organizer plan apply -y
```

Without the full scan, shortcut no-op detection won't have data to work with and SHORTCUT counts will look the same as b9.

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
