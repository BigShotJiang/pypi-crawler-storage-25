Two long-standing user asks: a simpler folder layout, and AI-powered filename rewriting.

**Changed**

- **AI archive layer simplified.** `🪄 AI 정리/보관함/YYYY/MM/foo.pdf` → `🪄 AI 정리/YYYY/MM/foo.pdf`. The 보관함 middle layer was redundant — the wand-emoji prefix already signals "AI-managed", so two prefixes were one too many. `ARCHIVE_ROOT` now equals `AI_ROOT`. Existing files migrate naturally on the next classify cycle: the planner sees them at the old path and emits MOVE ops to the new flatter path. Empty `보관함/` shells linger as a one-time artifact you can clean up manually.

**Added**

- **AI proposes new filenames** via a new `new_name` field in the JSON contract. The LLM rewrites obviously uninformative names like:
  - `Untitled document.gdoc`
  - `Screenshot 2025-04-08 at 10.32 AM.png`
  - `document (3).pdf`
  - `노트북-2024-03-12-final-FINAL.pdf`

  Keeps the file extension. Returns null when the current name already helps a future search — same opt-out pattern as `new_description`. Planner emits a single `RENAME_AND_MOVE` op when both rename + move apply, or `RENAME` when the file is already at destination. No-op detection: identical proposed name (post-strip) silently skipped, so the LLM saying "this name is fine" doesn't produce a noisy op.

**Migration**

Re-classify on your existing snapshot. Expect a one-time bump in MOVE ops while files migrate from `🪄 AI 정리/보관함/...` to `🪄 AI 정리/...`. Some RENAME / RENAME_AND_MOVE ops will appear for files with bad names — review the dry-run before applying.

```bash
gdrive-organizer scan --incremental
gdrive-organizer classify --preset migration
gdrive-organizer plan apply --dry-run    # review the rename + flatten
gdrive-organizer plan apply -y
```

**Upgrade**

```bash
brew upgrade gdrive-organizer
pipx upgrade gdrive-organizer
```

See [CHANGELOG.md](CHANGELOG.md) for the full diff.
