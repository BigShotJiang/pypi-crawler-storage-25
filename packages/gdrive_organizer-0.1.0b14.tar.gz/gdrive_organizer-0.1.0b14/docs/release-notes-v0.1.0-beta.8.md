A UX-and-debugging-friction release. Three changes that each remove a "how do I figure out what just happened" moment, plus one performance investigation aid.

**Added**

- **Apply failures now show the API error.** `plan apply` prints a Rich table of the first ~10 failed ops (file id + truncated error) right after the `Failed: N` line. Same digest for `plan rollback`. Previously the user only saw a count and had to grep the rollback log — which itself recorded only `status: "failed"` with no error string. The Stage-5 dogfood failure on file id `1bevOvqk-Hi5KEHo03BVzoZGUYb2iplULCm7aB-I-za4` ("LG U+ Why Not SW Camp 6기 블로그") motivated this — root cause was unidentifiable then, and would have been instantly visible now.
- **Rollback log records the failure reason.** Every failed op in `logs/rollback-*.json` now carries an `"error"` field with the API exception message. Old logs without the field still load.
- **Dry-run shows where moves land, not just how many.** `plan apply --dry-run` now prints a "MOVE / RENAME+MOVE destinations" table (top 15 destination folders by op count, with `... N more folders` overflow) and a separate "SHORTCUT destinations" table. Suppressed under `--verbose`. Catches bad LLM bucketing before apply.
- **`scan --minimal-fields` flag** for measuring the `_FILE_FIELDS`-bloat hypothesis in `docs/SCAN-PERFORMANCE.md`. Requests only the planner-essential fields; documented trade-off is that permissions and revisions enrichment are skipped (those rely on fields the slim set omits).

**Build**

- **`viewer-build/package-lock.json` is now committed** so `npm ci` produces the same `static/vendor/tailwind.css` on every machine. The rebuilt artifact ships in this release.

**Upgrade**

```bash
brew upgrade gdrive-organizer        # macOS / Linux
pipx upgrade gdrive-organizer        # platform-agnostic
```

See [CHANGELOG.md](CHANGELOG.md) for the full list of changes.
