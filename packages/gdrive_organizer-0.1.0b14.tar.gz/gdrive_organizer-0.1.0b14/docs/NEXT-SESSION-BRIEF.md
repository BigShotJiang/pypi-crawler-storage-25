# Next-session brief — gdrive-organizer follow-ups

This document is a **self-contained handoff** for the next Claude Code session. It assumes zero prior context, so paths, line numbers, and verification criteria are spelled out. Read it top-to-bottom once, pick a task by priority, and execute.

> Paste-ready bootstrap prompt for a fresh session: just say
>
> > Read `docs/NEXT-SESSION-BRIEF.md` and pick up the highest-priority unfinished item. Treat the file as your spec — do not re-derive priorities from anything else.

---

## 0. Repo state at handoff

- **Repo**: `/Users/chan/Developer/module-server/google-drive-manager` (single git worktree, branch `main`)
- **Released**: `v0.1.0-beta.7` (PyPI + GitHub Release + Homebrew tap)
- **Last commits**:
  - `8d11b8a chore(release): v0.1.0-beta.7`
  - `5a4630b feat: post-apply auto-rescan + viewer mtime-based snapshot reload (#J3)`
  - `455a410 style(planner): apply ruff format`
  - `03da39a chore(release): v0.1.0-beta.6`
  - `be78703 fix(scanner): re-parent orphans whose folder was trashed to root (#J6)`
  - `eb838a9 fix(executor): refuse plan apply when destination parent is in trash (#J5)`
- **Test suite**: 288 passing (`uv run pytest tests/ --ignore=tests/e2e`), takes ~37s. Playwright e2e in `tests/e2e/` is intentionally skipped from this default — only run if you change viewer templates/JS.
- **Lint**: `uv run ruff check src/` and `uv run ruff format --check src/` must both pass — CI enforces them on `src/` only, but please don't introduce new violations in `tests/` either.
- **Resolved P0/P1**: J1–J6 + J3 + #N. `audit text` (the prompt that opened this work) considered these "done" if all are fixed; they are.
- **The user's Drive**: stage-5 organize done — 3887/3888 ops applied; 1 known failure on file id `1bevOvqk-Hi5KEHo03BVzoZGUYb2iplULCm7aB-I-za4` (name "LG U+ Why Not SW Camp 6기 블로그"), root cause never identified. See item **A** below.

## 1. How to work in this repo

- Run things with `uv run gdrive-organizer …` from the repo root — that's the b7 source build.
- The user's data dir is `~/.local/share/gdrive-organizer/` (snapshots, plans, logs). Don't blow it away.
- The user's auth lives at `~/.config/gdrive-organizer/token.json`; refresh tokens expire every 7 days (testing-mode OAuth — see P4-3 for the long-term fix).
- For long-running CLI commands, prefer Bash with `run_in_background: true`. **macOS has no `/proc`** — wait loops must use `pgrep -f "..." >/dev/null` directly, not `/proc/PID` checks. Use `PYTHONUNBUFFERED=1` when piping rich output through `tee`, otherwise it block-buffers.
- **Two version locations** when releasing: `pyproject.toml` and `src/gdrive_organizer/__init__.py`. Keep them in sync — beta.5 left them desynced, beta.6 fixed it.
- **Release flow** (also in `docs/RELEASING.md`):
  1. Bump version in both files
  2. Update `CHANGELOG.md` + add `docs/release-notes-v<VERSION>.md`
  3. Commit `chore(release): v<VERSION>`
  4. `git push origin main`
  5. `git tag v<VERSION> && git push origin v<VERSION>` — CI publishes
  6. Watch `gh run watch <run-id> --exit-status`. If `ruff format --check src/` fails (it has before — beta.6 first attempt), fix the format, advance the tag (`git tag -d` + `git tag` + `git push --force origin <tag>`), re-watch.

## 2. Tasks, ranked by user value × cost

The user explicitly listed all of these and asked for them to be finished completely. Do them in this order; bundle into a single release when done (see §3).

### A. Apply-result error visibility (highest leverage, smallest blast radius)

**Why**: After the dogfood today, `Success: 3887, Failed: 1` was printed but no error detail. The user had to grep `~/.local/share/gdrive-organizer/logs/rollback-*.json` to find which file failed and got no error message at all (the rollback log only stores `status`, not the API error). When the next failure happens it will be the same dance. Not a tool defect, but a UX defect that hides every future tool defect.

**Where**:
- `src/gdrive_organizer/executor/runner.py::PlanRunner.execute` populates `errors: list[dict]` (each entry `{"file_id": ..., "error": ...}`). The list is returned in `ExecutionResult.errors` but currently only the count surfaces.
- `src/gdrive_organizer/cli.py::plan_apply` prints `Failed: N` (line ~711 region — re-grep, line numbers may shift).

**What**:
1. In `cli.py::plan_apply`, after `console.print(f"[red]Failed: {result.failure_count}[/red]")`, print the first ~10 errors as a Rich `Table` with columns `file_id`, `error` (truncated to ~120 chars). If more than 10, append `… N more — see rollback log: <path>`.
2. In `runner.py::_save_rollback_log`, persist the error message into the rollback log entry. Currently the entry has `status: "failed"` but no error string. Add `"error": <str>` when status is failed. This costs nothing in the success path and makes the rollback log self-explanatory.
3. Surface ops that the runner itself rejected (placeholder unresolved, shortcut chain, etc.) the same way — they go into `errors[]` already.

**Verify**:
- New test in `tests/test_failure_transparency.py` (file already exists): construct a runner whose mock `execute_batch` callback raises; call `runner.execute(plan)`; assert the rollback log JSON contains the error string for failed ops.
- Manual: synthesize a plan op with an unresolved placeholder, run `plan apply --dry-run` (no API calls) to confirm the table renders. Or use the existing `tests/test_e2e_workflow.py` integration path.

**Avoid**: don't change `ExecutionResult` fields (downstream callers depend on them). Just add to the log + presentation layers.

**Estimate**: 30–40 min including test.

---

### B. P2-1 — Commit `viewer-build/package-lock.json` for reproducible builds

**Why**: Without the lockfile, every CI run resolves transitive npm deps fresh and the produced `static/vendor/tailwind.css` can drift. CI is currently green because the deps are stable, but it's a latent flake.

**Where**:
- `viewer-build/.gitignore` (or root `.gitignore`) currently ignores `package-lock.json`. Find with `grep -rn "package-lock.json" --include=".gitignore" .`.
- `viewer-build/package-lock.json` exists locally but is untracked.

**What**:
1. Remove the `package-lock.json` line from the appropriate `.gitignore`.
2. `git add viewer-build/package-lock.json` and commit as `build(viewer): commit package-lock.json for reproducible CSS builds`.
3. Verify the file is sane: `cd viewer-build && npm ci && npm run build` should regenerate the same `static/vendor/tailwind.css` (run `git diff` on the output to confirm no spurious diff). If it does diff, regenerate and commit the new artifact.

**Verify**: `npm ci` (uses lockfile) should succeed in a fresh clone. CI does not currently call `npm` — this is purely for the human contributor flow + future CI work.

**Estimate**: 5–10 min.

---

### C. P2-2 — `plan apply --dry-run` shows category distribution per phase

**Why**: Today's b6 dogfood produced a 3775-op plan. The phase summary (`MOVE: 1222`) was useful but didn't reveal *which destination folders* the moves target — the user couldn't tell at a glance whether classify made reasonable bucketing decisions before pulling the trigger on apply.

**Where**:
- `src/gdrive_organizer/executor/runner.py::_dry_run_display` builds the existing summary table.

**What**:
1. After the existing phase summary table, add a second table: for `MOVE` and `RENAME_AND_MOVE` ops, group by destination folder (`op.new_path.rsplit("/", 1)[0]`); show top ~15 buckets with op count, then `… N more folders` for the long tail.
2. Same for `CREATE_SHORTCUT` ops grouped by `op.shortcut_parent_id` resolved against snapshot folder names — if you can't resolve, group by `op.new_path.rsplit("/", 1)[0]`.
3. Don't run when `verbose=True` — verbose already lists every op.

**Verify**: new test in `tests/test_execution_invariants.py` builds a small plan with two destination folders, captures Rich console output via `Console(record=True)`, asserts the second table appears and the counts add up.

**Estimate**: 30–45 min.

---

### D. P2-3 — `scan --minimal-fields` flag for performance investigation

**Why**: `docs/SCAN-PERFORMANCE.md` records a 19-min scan on 1500 files and hypothesizes that the bloated `_FILE_FIELDS` constant is the culprit. The hypothesis has never been measured. This task ships the flag so the next slow scan can answer the question.

**Where**:
- `src/gdrive_organizer/scanner/crawler.py` — `_FILE_FIELDS` constant.
- `src/gdrive_organizer/scanner/service.py::run_full_scan`.
- `src/gdrive_organizer/cli.py::scan`.

**What**:
1. Add a `_MINIMAL_FILE_FIELDS = "id,name,mimeType,parents,modifiedTime,createdTime,size,owners(emailAddress),ownedByMe,md5Checksum,trashed"` — only the fields the planner + tree builder actually read.
2. `scan_all_files(service, query, page_size, *, minimal_fields=False)` — selects field set.
3. `run_full_scan(..., *, minimal_fields=False)` — plumbs the flag through.
4. `scan --minimal-fields/--no-minimal-fields` CLI flag (default off).
5. **Critical**: when `minimal_fields=True`, skip `enrich_permissions_for_shared` and `enrich_revisions` — they need fields you didn't fetch. Make this the documented trade-off in the help text.
6. Document the result in `docs/SCAN-PERFORMANCE.md` after the user runs both scans on the same Drive.

**Verify**:
- New test: `tests/test_crawler.py::test_minimal_fields_uses_slim_field_set` — mock `service.files().list` and assert the `fields` kwarg matches `_MINIMAL_FILE_FIELDS`.
- Manual benchmark left to the user (capture wall-clock with `time uv run gdrive-organizer scan --minimal-fields` and update SCAN-PERFORMANCE.md).

**Estimate**: 1–1.5 hr including docs.

---

### E. P4-1 — Verify the `second-brain` preset on real data

**Why**: The migration preset is heavily verified (5 stages of dogfood). The `second-brain` preset (content-based tagging via shortcuts) ships in the same release but has *never* been run end-to-end. If a user picks it, who knows what happens.

**Where**: `src/gdrive_organizer/ai/prompts.py` — preset definition. `--preset second-brain` is the CLI handle.

**What** (this is a **verification + write-up** task, not a build task):
1. Run `gdrive-organizer classify --preset second-brain` against the user's current snapshot. Cost: ~$1 LLM, ~5 min wall.
2. Inspect the plan: are shortcuts created with reasonable category folder names? Do descriptions match the file content the LLM saw? Are there obviously-wrong classifications?
3. Either run apply on a small approved subset (3–5 files via the viewer) OR document why the plan looks unfit.
4. Write findings to `docs/PRESET-SECOND-BRAIN-EVALUATION.md` with: sample size, qualitative observations, list of issues, recommendation (ship as-is / refine prompt / mark experimental).
5. If any issues are clear bugs (wrong path resolution, hallucinated file ids), open them as new J-bugs and add to the next-session brief — don't fix in this task.

**Verify**: this is itself the verification. The deliverable is the markdown doc.

**Estimate**: 30–60 min including write-up.

---

### F. P4-2 — Duplicates bulk-cleanup feature (largest scope)

**Why**: The viewer surfaces 105 duplicate groups / 19 MB of redundancy on the user's Drive but offers no action. Manual cleanup of 105 groups is a non-starter.

**Scope decision before starting**: this is genuinely 2–3 hours and touches the planner, runner, viewer, and tests. Confirm with the user that they want it shipped before starting; if not, defer.

**Where**:
- New op type: extend `OperationType` enum in `src/gdrive_organizer/models.py` with `TRASH_DUPLICATE` (or reuse `TRASH` with a `reason` carrying `"duplicate-of:<other-id>"`).
- Planner: new function `generate_duplicates_plan(snapshot)` in `src/gdrive_organizer/ai/planner.py` — for each md5 group with >1 file, keep the newest by `modified_time`, mark the rest TRASH.
- Viewer: enable a "Trash duplicates" button on the duplicates page; POSTs to a new `/api/duplicates/approve` endpoint that writes an approved plan exactly like the existing `/api/plan/approve` flow (same session-token + confirmation barrier).
- Tests: planner unit test + viewer integration test, both following the patterns in `tests/test_planner.py` and `tests/test_viewer_safety.py`.

**Critical safety constraints**:
- **Never trash without an md5 match** — md5 collisions are negligible but if md5 is missing on either file, skip the pair.
- **Never trash a file that is the only copy in its folder** — duplicates are about same-content, not same-name.
- **Always preserve the newest by `modified_time`**, ties broken by `version` field, then by id (deterministic).
- **Surface in dry-run** with file names + sizes + which file is being kept, before any apply.

**Estimate**: 2–3 hours. Probably worth its own b8 release.

---

### G. P4-3 — Submit OAuth app to Google for verification

**Why**: Testing-mode OAuth caps users at 100 and refresh tokens expire every 7 days. To ship gdrive-organizer to anyone outside the user's Google Cloud project, the app needs Google's OAuth verification (privacy policy, terms of service, scopes review, security questionnaire).

**Where**: this is a Google Cloud Console workflow, not a code task. The repo already has minimal scopes (`drive.readonly` + `drive.file`), which simplifies review.

**What** (mostly user-facing process):
1. Audit `src/gdrive_organizer/auth/oauth.py` `SCOPES` — verify they're the *minimum* needed. The current set should be reviewed; document the why for each scope.
2. Draft `docs/PRIVACY.md` and `docs/TERMS.md` (or link to a hosted version).
3. Update `docs/05-BOOTSTRAP.md` with verification status.
4. Set up the Google Cloud Console verification request (manual web flow — the next session can write a checklist but cannot click the buttons).
5. Track the request status; if Google asks for clarifications, the agent can draft responses for the user to send.

**Estimate**: code/doc work ~1 hr. Google review takes weeks of calendar time. The agent finishes the *prep* work; the *submit + wait* is the user.

---

## 3. Release flow when the bundle is done

Aim for **v0.1.0-beta.8** as the next release, bundling A + B + C + (D if it lands cleanly). Defer E to its own release because its deliverable is documentation, and defer F + G to b9+ because of scope.

Per-release checklist (mirrors §1):

```bash
# Pre-flight
uv run ruff check src/
uv run ruff format --check src/
uv run pytest tests/ --ignore=tests/e2e

# Bump (both files!)
$EDITOR pyproject.toml                              # version = "0.1.0-beta.8"
$EDITOR src/gdrive_organizer/__init__.py            # __version__ = "0.1.0-beta.8"

# CHANGELOG + release notes
$EDITOR CHANGELOG.md
$EDITOR docs/release-notes-v0.1.0-beta.8.md

# Commit + push + tag
git add -A
git commit -m "chore(release): v0.1.0-beta.8"
git push origin main
git tag v0.1.0-beta.8
git push origin v0.1.0-beta.8

# Watch
gh run list --workflow=release.yml --limit 1
gh run watch <run-id> --exit-status
```

If the verify step fails on `ruff format --check src/`, fix in a follow-up commit, **then move the tag** (`git tag -d <tag> && git tag <tag> && git push --force origin <tag>`). Do **not** force-push `main` for this — only the tag.

## 4. Things to **not** do

- Don't add new files to the user's `~/.local/share/gdrive-organizer/` data dir for testing — use `tmp_path` fixtures.
- Don't run `gdrive-organizer plan apply` against the user's real Drive without explicit per-call permission. The `--dry-run` path is fine.
- Don't bypass the J5 trashed-parent guard or the snapshot freshness check in production code paths — they cost nothing and protect the user.
- Don't skip pre-commit hooks (`--no-verify`). If a hook fails, fix the underlying issue.
- Don't change `_FILE_FIELDS` itself in scope of D — add `_MINIMAL_FILE_FIELDS` alongside. The default-large fields are intentional for richer downstream features.
- Don't silently swallow errors from the new auto-rescan path (b7 added) — the warning is fine, an exception traceback is also fine, but a silent skip is not.

## 5. Open questions to ask the user before starting any task

- **A**: "OK to add an `error` field to rollback log entries — old logs without it still load?" (yes, add `.get("error")` defensively in `_build_reverse_operations`)
- **F**: "Want duplicates bulk cleanup as b8 or defer to b9?" — scope decision.
- **G**: "Privacy policy / TOS — should I draft against a template, or do you have hosted versions?" — material for verification.

Everything else is safe to proceed without re-confirming.
