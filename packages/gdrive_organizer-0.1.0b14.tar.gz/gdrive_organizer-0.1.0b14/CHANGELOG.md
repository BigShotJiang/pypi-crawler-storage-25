# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0-beta.14] - 2026-05-09

Polish + a long-pending feature: bulk duplicate cleanup. Plus three
small viewer UX fixes from a fresh audit.

### Added

- **`cleanup-duplicates` CLI** + viewer endpoint
  (`POST /api/duplicates/cleanup`) + Duplicates page checkboxes and
  `선택 그룹 정리` button. Generates a TRASH-only plan that keeps the
  newest file in each md5 group and trashes the rest. Same safety
  rails throughout: external files / orphans / empty content / files
  without md5 are all excluded. Drive's 30-day trash holds the files
  in case of a misclick. The CLI saves a normal plan; the viewer
  saves directly as `approved-plan.json` with a TRASH confirmation
  gate identical to `/api/plan/approve`.

### Fixed

- **Empty files no longer pollute the duplicates list.** All
  zero-byte files share the empty-content md5; treating them as a
  "35-file duplicate group" was noise the user had to mentally filter
  out. `/api/duplicates` now skips files where `size == 0`.
- **Search results show the parent folder** alongside the filename so
  duplicate names (`README.md` × 65) are distinguishable.

### Infrastructure

- **CI workflows force Node 24 runtime** via
  `FORCE_JAVASCRIPT_ACTIONS_TO_NODE24=true` env var, validated against
  the existing pinned action versions. Prepares for the 2026-06-02
  Node 20 default-removal without bumping every action major version
  and risking a breaking change.

## [0.1.0-beta.13] - 2026-05-08

Two long-standing user requests: simpler folder layout and AI-powered
filename rewriting.

### Changed

- **AI archive layer simplified.** `🪄 AI 정리/보관함/YYYY/MM/foo.pdf`
  → `🪄 AI 정리/YYYY/MM/foo.pdf`. The `보관함` middle layer was
  redundant since the wand-emoji prefix already signals "AI-managed".
  `ARCHIVE_ROOT` now equals `AI_ROOT`. Existing files migrate
  automatically on the next classify cycle: the planner sees them at
  the old path and emits MOVE ops to the new path. Empty `보관함/`
  shells stay around as a one-time visual artifact the user can clean
  up manually if they want.

### Added

- **AI proposes new filenames** (`new_name` in the JSON contract). The
  LLM may rename uninformative names like `Untitled document.gdoc`,
  `Screenshot 2025-04-08 at 10.32 AM.png`, or `document (3).pdf` to
  something searchable. Keeps the file extension; returns null when
  the current name is already informative. Planner combines this with
  the time-archive move into a single RENAME_AND_MOVE op when both
  apply, or RENAME-only when the file is already at the destination.
  No-op detection: identical proposed name (post-strip) vs current
  is silently skipped.

## [0.1.0-beta.12] - 2026-05-08

The b11 dogfood revealed a class of files that looked like orphans but
weren't — folders shared by other users (e.g. `자료실` shared by
jhjung@dschloe.com). Drive denies our writes through them just like
through trashed parents, but they need a different conceptual treatment:
informational, not actionable. b12 splits the two.

### Fixed

- **External (ownedByMe=False) folders no longer slip through the
  planner.** b11's orphan filter only caught true orphans (parents=[]).
  An external folder like `자료실` whose parents list is non-empty
  passed through, the LLM proposed shortcuts under `자료실/Book`, and
  Drive 403'd on every one. The planner now folds external folders
  into the same unwriteable-subtree exclusion (`_unwriteable_subtree_ids`),
  so descendants of external folders are excluded transitively too.
  Effect on the user's Drive: 5 b11-cycle apply failures → 0 expected.
- **External files skip ALL ops in `_response_to_operations`,** not
  just MOVE. Same Drive 403 reason, applied consistently.

### Added

- **Two virtual folders in the viewer instead of one:**
  - `⚠️ 검토 요청` — true orphans (parents=[] AND owned by me).
    Actionable: untrash the parent in Drive UI.
  - `👥 공유받음` — external (ownedByMe=False). Informational:
    other users own these and we have at most read access.

  Each gets its own dashed-border tint (amber for review, sky for
  external) and its own dashboard alert card with appropriate
  language. Files inside carry color-matched badges
  (`상위 폴더 삭제 - 검토 요망` vs `공유받음`).
- **`isExternal` flag** on each tree node + **`external_count`** on
  the stats endpoint, alongside the existing `isOrphan` /
  `orphan_count`.

## [0.1.0-beta.11] - 2026-05-07

A polish pass on top of b10's planner overhaul. The 1,343-op b10 plan
on the user's Drive shrinks to **356 ops** with these prompt + planner
tweaks; one apply later, the next cycle's plan should be even smaller.

### Fixed

- **Description rewrite waste** — the LLM regenerated descriptions for
  every file on every cycle even when the existing one was already a
  good Korean summary, so DESCRIPTION ops stayed at ~1,200/cycle. The
  preset input now carries the file's `existing_description` and the
  JSON contract instructs the LLM to return null for `new_description`
  when the existing one is already a reasonable search summary. Real
  effect: DESCRIPTION 1,241 → 1 on the user's Drive.
- **Transitive orphan subtree exclusion** — b10's orphan filter only
  caught direct orphans (parents=[]). A child folder of an orphan
  (e.g. `자료실/Book` with `parents=[자료실_id]`) sailed through and
  the apply 403'd because Drive denies writes to anything reachable
  through a trashed ancestor. The planner now BFS's down from each
  orphan-folder root and excludes the entire subtree from
  `_get_existing_folders` / `_get_existing_folder_index`.
- **Plan Summary table** now shows Renames and Rename + Moves rows
  (were silently absent — only Moves got a row even though Renames
  / Rename+Moves are tracked in PlanStats).

### Added

- **Drive deep-link on orphan files in the viewer** — `⚠️ 검토 요청`
  folder rows now render a small `↗` icon next to the orphan badge
  that opens `webViewLink` in a new tab. Tooltip on the badge points
  the user to the manual fix path: untrash the parent in Drive UI,
  then the next classify can absorb the file.

## [0.1.0-beta.10] - 2026-05-07

Three planner correctness fixes that emerged from successive b9 dogfood
cycles. End-to-end re-classify on the user's 1500+ file Drive shrinks
from b9's 3,944-op plan to 1,343 ops with **zero predicted apply
failures** — a tighter, faster, safer cycle.

### Fixed

- **Planner skips orphan files and orphan-folder targets** (P1). Files
  whose direct parent is in trash (J6 reparent) hit Drive 403 on every
  write because the API treats trashed-parent paths as read-only.
  Six predictable apply failures during the b9 dogfood (1 MOVE on the
  `LG U+ Why Not SW Camp 6기 블로그` file plus 5 SHORTCUT ops targeting
  the orphan `자료실` folder) traced back to this. The planner now
  excludes orphan folders from `_get_existing_folders` /
  `_get_existing_folder_index` so the LLM never sees them as shortcut
  targets, and skips MOVE / SHORTCUT / DESCRIPTION ops for orphan
  source files (logging the count so the user knows which files need
  manual attention via the viewer's `⚠️ 검토 요청` folder).
- **No-op detection on MOVE / DESCRIPTION / SHORTCUT** (P4). Re-running
  classify on an already-organized Drive previously regenerated every
  op as a redundant rewrite — apply burned API quota and shortcuts
  duplicated themselves on every cycle. The planner now skips:
  - MOVE when `target_parent_id == file.parents[0]`,
  - UPDATE_DESCRIPTION when the new text equals the current (after
    whitespace trim),
  - CREATE_SHORTCUT when a shortcut with the same `(target, parent)`
    already exists in the snapshot.
  Effect on the user's Drive: MOVE 1242→1, SHORTCUT 1457→286,
  DESCRIPTION still high because the LLM regenerates the text each
  cycle. Requires `shortcut_target_id` to be present in the snapshot,
  so a one-time full scan is needed after upgrading to populate it.
- **Plan Summary table now lists Folder colors** count, not just
  Moves/Shortcuts/Descriptions/Trashed.

### Added

- **`UPDATE_FOLDER_COLOR` op type + automatic backfill** (P3). AI-managed
  folders created in earlier releases (pre-b9) shipped without
  `folderColorRgb`, so 28 of the user's `🪄 AI 정리/...` folders showed
  as default grey in Drive. The planner now backfills them from the
  same hash-based palette new folders get, scoped strictly to the
  AI_ROOT subtree so user folders are never repainted. Drive returns
  `#8f8f8f` for "no color set" — the backfill treats this sentinel as
  missing, otherwise none of the b8-era folders ever qualified for
  recolor. Runner Phase 4 handles the new op alongside descriptions;
  rollback restores the prior color when one was recorded.
- **`shortcut_target_id` field on `DriveFile`** so the planner and
  viewer can reason about which shortcuts already point to which files.

## [0.1.0-beta.9] - 2026-05-04

A same-day follow-up release driven by 4 issues found in dogfood after b8.
All four are user-visible defects in the viewer's representation of the
user's Drive plus a planner correctness fix for the time archive.

### Fixed

- **Time archive uses `created_time`, not `modified_time`.** Our own
  apply ops bump `modifiedTime` on Drive, so using it for `YYYY/MM`
  bucketing collapsed every previously-archived file into the apply
  month. `_resolve_time_path` now prefers `created_time` (with
  `modified_time` as fallback for legacy files that lack a created
  timestamp). Migration + second-brain system prompts updated to send
  the LLM the `created` field and tell it explicitly not to use
  `modified`. Existing wrong-bucket files will be re-routed naturally
  on the next classify cycle.
- **Folder counts are recursive descendants, not just direct children.**
  The viewer's tree was showing direct child count for each folder, so
  big subtrees looked tiny ("부트캠프: 353" but actually contains 871).
  `_count_descendants` walks the subtree iteratively and the response
  now exposes `childCount` (total), `directChildCount`,
  `descendantFiles`, and `descendantFolders`. Tooltip on the count chip
  shows the breakdown.

### Added

- **Orphan files surface in a virtual "⚠️ 검토 요청" folder.** J6's
  reparent (b6) lifts files whose direct parent is in trash to the
  snapshot root, but the viewer scattered them through the real root,
  confusing users comparing the viewer with the Drive UI. Now the
  viewer collects them under a synthetic top-level folder with a
  dashed amber border and an `alert-triangle` icon. Each file inside
  carries a `상위 폴더 삭제 - 검토 요망` badge with a tooltip explaining
  why it's there. Dashboard surfaces the total via an alert card so
  the user can spot it immediately.
- **Folder color matters again.** Drive's `folderColorRgb` is now both
  read on scan (snapshot stores it; viewer tints the folder icon) and
  written on `CREATE_FOLDER` ops by the runner. The planner assigns
  every newly-created folder a stable color from Drive's official
  24-color palette via a hash of the folder name (same name → same
  color across runs). AI roots get fixed brand colors:
  `🪄 AI 정리` → indigo, `보관함` → grey, `미분류` → orange.
- **`directChildCount`, `descendantFiles`, `descendantFolders`,
  `folderColor`, `isOrphan`, `isVirtualReview`** fields on tree nodes
  for richer frontend rendering. `orphan_count` field on the stats
  endpoint.

## [0.1.0-beta.8] - 2026-05-04

A UX-and-debugging-friction release. Three changes that each remove a
"how do I figure out what just happened" moment, plus one performance
investigation aid.

### Added

- **Apply failures now show the API error.** `plan apply` prints a Rich
  table of the first ~10 failed ops (file id + truncated error) right
  after the `Failed: N` line. The same digest fires for `plan rollback`.
  Previously the user only saw a count and had to grep the rollback log,
  which itself recorded only `status: "failed"` with no error string.
- **Rollback log records the failure reason.** Every failed op in
  `logs/rollback-*.json` now carries an `"error"` field with the API
  exception message. Old logs without the field still load — the rollback
  builder treats it as optional.
- **Dry-run shows where moves land, not just how many.** After the phase
  summary, `plan apply --dry-run` now prints a "MOVE / RENAME+MOVE
  destinations" table (top 15 destination folders by op count, with
  `... N more folders` overflow), and a separate "SHORTCUT destinations"
  table. Suppressed under `--verbose` since that already lists every op.
  Catches bad LLM bucketing before apply.
- **`scan --minimal-fields` flag** for measuring the
  `_FILE_FIELDS`-bloat hypothesis in `docs/SCAN-PERFORMANCE.md`. Requests
  only the fields the planner + tree builder strictly need; documented
  trade-off is that permissions and revisions enrichment are skipped
  (those rely on fields the slim set deliberately omits).

### Build

- **`viewer-build/package-lock.json` is now committed** so `npm ci`
  produces the same `static/vendor/tailwind.css` on every machine. The
  rebuilt artifact ships in this release as well.

## [0.1.0-beta.7] - 2026-05-04

A workflow-friction fix landed during the same-day b6 dogfood. Both
defects always required manual intervention after every apply, so the
release goes out separately for visibility.

### Fixed

- **Viewer dashboard auto-reloads on snapshot advance** (#J3). The viewer cached the snapshot at startup and never re-read the file, so a CLI scan had no effect on the running server until the user killed and re-started it. `SnapshotCache` now tracks the latest-snapshot file's mtime (resolving the symlink) and invalidates itself the next time the file advances. The first request after a scan transparently reloads. Tests cover both `/api/stats` and `/api/tree`.

### Added

- **`plan apply --rescan/--no-rescan`** (default on). After a successful apply, the runner now invokes the existing `incremental_scan` path so the snapshot reflects the just-applied state. Without this, the next plan and the viewer's tree both lied about what was actually in Drive — observed in real dogfood. Auto-rescan failures degrade to a yellow note instead of aborting the apply summary.

## [0.1.0-beta.6] - 2026-05-03

A second dogfood pass against the same 1500-file Drive surfaced two new
data-integrity defects (#J5, #J6) and four planner / classify
improvements (#J1, #J2, #J4, #N) plus a 13× speedup on classify. This
release ships all of them.

### Fixed

- **Apply refuses to write into a trashed parent folder** (#J5). After a `plan rollback` trashes folders that were freshly created by the previous apply, those folder Drive IDs still live in the snapshot. The next classify happily resolved a destination path to one of those trashed IDs, and Phase 2 quietly moved files into an invisible parent — they no longer appeared in the Drive UI even though the API call succeeded. The runner now batch-fetches `trashed` for every real (non-placeholder, non-`root`) destination parent the plan references and aborts with a clear "re-scan and re-classify" message if any are trashed.
- **Scanner re-parents orphans whose folder is in trash** (#J6). Drive's `q=trashed=false` returns a file whose own `trashed=false` even when its direct parent has been moved to trash; `build_tree` then silently demoted such a file to a root node, but it was still a member of an invisible parent so the user could not see it and the next plan never flagged it as needing organization. The scanner now detects files whose parents fell outside the scan result, confirms the parent is trashed via a `files.get`, and clears `parents=[]` so the file surfaces at My Drive root and gets classified normally. Live external parents (e.g. shared-from-others folders) are left alone.
- **Planner skips shared-from-others files** (`ownedByMe=False`) (#J1). Drive rejects move/update on these files (canEdit/canMove=False), so including them produced guaranteed apply failures — 7 of 15 failures in the Stage-1 dogfood were `ownedByMe=False` PDFs in shared course folders. Files where `owned_by_me` is unknown (`None`) are still permitted.
- **Planner skips `mimeType=shortcut` files as classification candidates** (#J2). Using a shortcut as a source produced a shortcut-of-shortcut chain that Drive rejects (4 of 4 remaining failures in Stage-2 dogfood were exactly this — shortcuts created by an earlier apply, then handed back to the next plan as candidates).
- **Conflict resolution renames instead of dropping** (#J4). When two ops would land at the same destination, the planner used to drop the later op, leaving duplicate-named files stranded at root forever — they would be dropped from every subsequent plan as well. Stage-5 dogfood found 6 such files that survived 4 stages. Renaming with a `(2)`, `(3)`, ... suffix preserves the data so every file gets organized, just with disambiguated names.

### Changed

- **Classify is dramatically faster — 13× wall-clock speedup** (~14 min → ~1 min 35 s on a 1500-file Drive). LLM batches now run in parallel via `asyncio.gather`; `client.chat()` already enforced concurrency through its `Semaphore(MAX_CONCURRENT=10)`, so spawning all batches at once and letting the client throttle them brings wall time down by roughly the semaphore size. Order is preserved (gather returns results in input order) and first-failure abort semantics match the old sequential path.
- **AI-managed folders are prefixed with `🪄 AI 정리`** (#N). The previous default rooted everything under `보관함`, which the user already used for unrelated personal archives. The wand emoji prefix lets the user tell at a glance which folders the tool created vs. their own existing tree.

## [0.1.0-beta.5] - 2026-05-02

Real-world dogfooding on a 1500-file Drive surfaced 18 defects — three of
which were data-integrity bugs that the existing test suite missed. This
release ships the fixes.

### Fixed

- **Rollback no longer trashes the original file** when undoing a `create_shortcut` op. The shortcut entry's `fileId` was the *target* file's ID, not the shortcut's; the rollback log now records the shortcut's own Drive ID and trashes that. (#24)
- **Rollback restores root files correctly** when `before.parent_id` is `null` — previously the reverse `move` op silently failed to specify a parent and left the file orphaned in the apply target. Now resolves to Drive's `"root"` alias. (#25)
- **Rollback unsets descriptions** that were newly added by the apply (empty string), instead of skipping the reversal. (#22)
- **`success_count` is per-op, not per-file_id** — a file that received both a `move` and an `update_description` op was undercounting by 1 because the results dict overwrote on `file_id` collision. (#20)
- **`auth login` recovers from expired refresh tokens** automatically — was leaking a `RefreshError` traceback and forcing manual `auth logout` first. (#1)
- **Stale-snapshot guard reports honestly** — was printing "Failed: N" when nothing was even attempted. Added `ExecutionResult.skipped_count` to distinguish "not attempted" from "tried and failed". (#18, #23)
- **`plan rollback` accepts `-y/--yes`** for non-interactive use, matching `plan apply`. (#21)

### Changed

- **Classify is dramatically faster for the migration preset** — measured 21 min → 14 min on a 1500-file Drive (-32%). The `_extract_snippets` step is now gated behind a `requires_content` flag on the preset (migration is metadata-only), and when it does run it's genuinely async + parallel via `asyncio.to_thread` + `Semaphore` instead of fake-async sync calls + `time.sleep`. Progress bars added to both extract and LLM batch phases. (#4, #5, #6)
- **`plan apply --dry-run` defaults to a phase summary** instead of one line per op (was 3,262 lines on a real plan). Pass `--verbose` for the legacy line-by-line output. (#15, #16)
- **`plan show` samples per phase** so the preview isn't dominated by `create_folder` ops. New `--phase` filter and `--per-phase N` knob; columns auto-fit so paths no longer truncate mid-name. (#9–#11)
- **Viewer Plan page**: `create_folder` ops show a single "NEW" card (was identical BEFORE/AFTER); the bulk-select button is now labeled "Select All (Skip Trash)" with an explicit tooltip. (#12, #14)
- **Viewer CSS pipeline** moved from the Tailwind JIT browser runtime (which printed a "do not use in production" warning on every page load and weighed 407 KB) to a proper PostCSS production build (47 KB, no warning). New `viewer-build/` workspace with the compiled output committed under `static/vendor/tailwind.css`. End users still need no Node installed. (#13)
- **`config exclude` documentation** in `README.md` and `CLAUDE.md` now matches the actual flag-style command (`--show`, `--add-folder`, `--remove-folder`, ...) instead of subcommand-style. (#2)
- **Validator's "Conflict removed" log line** now identifies the planner as the source and explains *why* (which destination already had a different op landing there). (#7)
- **File logging is actually wired up** — `setup_logger` was previously never called, so `~/.local/share/gdrive-organizer/logs/gdrive-organizer.log` stayed empty even on errors. (#8)

### Added

- **Per-page scan timing logs** for diagnosing slow scans. The 19-minute scan observed during dogfood had no breakdown; the next slow run will. (#3)
- **`docs/SCAN-PERFORMANCE.md`** — investigation notes for the 19-minute scan and a measurement of the post-fix classify run with a follow-up suggestion (parallelize `_classify_with_preset` via the existing `classify_batch_parallel` path).
- **5 dogfood regression tests** in `tests/test_rollback.py::TestDogfoodRegression` reproducing each of #20, #22, #24, #25.

## [0.1.0-beta.4] - 2026-04-17

### Added

- **`auth setup` command**: GCP OAuth 설정을 처음부터 안내하는 인터랙티브 가이드. 프로젝트 생성 → Drive API 활성화 → OAuth 동의 화면 → Client ID 생성 → credentials 자동 감지 → OAuth 로그인까지 5단계로 진행. credentials.json이 이미 있으면 GCP 단계를 건너뛰고, 인증 완료 상태면 즉시 종료.
- **Docker deployment**: `docker compose up` 으로 viewer를 컨테이너로 실행 가능. Dockerfile + compose.yml 추가.
- **Viewer icon**: Drive Manager 전용 아이콘 적용 (sidebar, favicon).

### Changed

- Viewer sidebar 로고 아이콘 viewBox 조정.

## [0.1.0-beta.3] - 2026-04-16

### Added

- **Homebrew tap**: `brew tap papa-channy/tap && brew install gdrive-organizer` now works on macOS/Linux. Formula pins all transitive resources from the PyPI sdist.
- **CI: tag-driven release workflow** (`.github/workflows/release.yml`) — pushing a `v*` tag runs lint + tests, verifies the tag matches `pyproject.toml` version, builds sdist + wheel, publishes to PyPI via **trusted publishing** (OIDC; no stored tokens), and uploads the artifacts to a matching GitHub release with pre-release flag auto-inferred from the tag suffix.
- **README**: Homebrew install as the first option for macOS/Linux users; `pipx` / `pip` kept as platform-agnostic fallbacks.
- **docs/RELEASING.md**: rewritten for the new two-command release flow, with a one-time PyPI trusted-publisher setup guide and a manual break-glass fallback retained for reference.

### Changed

- No package code changes from v0.1.0-beta.2. This release exists solely to validate the auto-publish pipeline end-to-end and ship the Homebrew path.

## [0.1.0-beta.2] - 2026-04-15

### Added

- **Plan Review**: name/path search box that combines with the operation-type filter
- **Plan Review**: bulk-action shortcuts — "Select Safe Only" (excludes TRASH) and "Deselect all TRASH (N)" (only shown when trash ops exist)
- **Plan Review**: approved-subset banner with "Clear approval" button; matching `DELETE /api/plan/approve` endpoint (session-gated, rate-limited)
- **Plan Review**: last-applied panel with success/failed op counts, expandable per-op status list, and copy-pasteable `plan rollback` command
- **Plan Review**: character-level diff highlighting — common prefix/suffix dimmed, removed middle strike-through (BEFORE), added middle bold-green (AFTER)
- **Dashboard**: freshness chips — "Last scan: 2h ago" / "Last classify: 15m ago" with CLI-command hint when missing
- **Viewer**: vendored Lucide and Tailwind CSS assets (`static/vendor/`) so the local viewer runs fully offline
- **Viewer**: consistent empty/error states via `renderEmptyState` helper across tree, plan, permissions, duplicates, search, and settings
- **Test infra**: Playwright E2E skeleton (`tests/e2e/`) with live uvicorn fixture; 19 browser tests covering all new interactions
- **Docs**: viewer screenshots (`docs/assets/viewer-*.png`) plus `scripts/capture_screenshots.py` for reproducible regeneration with synthetic data

### Fixed

- **Plan Review**: same `file_id` with multiple operations can now be approved independently (approval API switched to `approved_operation_ids`)
- **Plan Review**: selection state survives filter changes (previously any filter change re-checked all items)
- **Settings**: expired or corrupt tokens correctly surface as "Expired" or "Not Connected" instead of "Connected"
- **Dashboard**: `last_scan_at` is now derived from `snapshot.scanned_at`; the dashboard's "Updated Xh ago" subtitle no longer falsely reports "No scan yet" when a snapshot exists

### Changed

- `typer[all]>=0.12` → `typer>=0.12` — removes the "no extra named 'all'" warning on `pip install` with recent typer versions
- Plan apply now prefers `approved-plan.json` as the CLI default; `--latest-plan` bypasses the approved subset when needed

## [0.1.0-beta.1] - 2026-04-12

### Added

- **Core workflow**: scan -> classify -> plan -> apply -> rollback
- **Flat-crawl scanner**: single `files.list` call with in-memory tree reconstruction
- **AI classification**: xAI Grok integration with configurable presets (migration, second-brain, custom)
- **Plan/Apply separation**: AI generates reviewable JSON plans, never mutates Drive directly
- **Dry-run support**: `plan apply --dry-run` previews changes without execution
- **Rollback**: undo applied plans with correct operation ordering and untrash semantics
- **Readonly OAuth mode**: `oauth_readonly` config for inspection without write credentials
- **Incremental sync**: Changes API integration for fast re-scans after initial crawl
- **Local web viewer**: FastAPI dashboard with tree explorer, plan review, duplicate detection, permission audit
- **Batch executor**: Google Batch API wrapper with token-bucket rate limiter (3 writes/sec default)
- **Atomic snapshot writes**: prevents corruption from interrupted writes
- **Advisory snapshot locking**: reduces concurrent write races
- **Session-gated viewer mutations**: confirmation and session token checks for web-initiated changes
- **LLM response validation**: validates AI output structure before mutation planning
- **System keychain API key storage**: via `keyring` library
- **Restricted directory permissions**: `0700` on POSIX for config and data directories
- **File content reading**: `cat` command with auto-export for Google Workspace files
- **Scan exclusion rules**: configurable file/folder exclusions
- **Snapshot freshness checks**: warns when applying plans against stale snapshots
- **CLI**: typer-based with rich output formatting
- **justfile**: task runner with 32 recipes for common operations

### Security

- OAuth scope mismatch detection prevents readonly config from reusing write tokens
- Localhost-only viewer binding by default
- Credentials and tokens excluded from version control via `.gitignore`
