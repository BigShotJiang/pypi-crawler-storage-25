"""Plan execution runner with 4-phase execution and rollback support."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field
from rich.progress import BarColumn, Progress, TextColumn, TimeRemainingColumn

from gdrive_organizer.executor.batch import (
    create_folder,
    create_shortcut,
    execute_batch,
    update_description,
    update_folder_color,
)
from gdrive_organizer.executor.rate_limiter import TokenBucket
from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("executor.runner")


def _op_key(file_id: str, op_type: OperationType | str) -> str:
    """Compose a unique results-dict / batch request_id per operation.

    Why: a single file can be the subject of multiple ops in one plan
    (e.g. move + update_description), so file_id alone collides.
    """
    value = op_type.value if hasattr(op_type, "value") else op_type
    return f"{file_id}:{value}"


def _collect_real_destination_parents(plan: ExecutionPlan) -> set[str]:
    """Drive IDs the plan would write into as a destination/source parent.

    Skips placeholder IDs (`__new_folder_*`) — those refer to folders that
    Phase 1 will create, so they don't yet exist and can't be checked.
    """
    parents: set[str] = set()
    for op in plan.operations:
        if op.operation == OperationType.CREATE_FOLDER:
            parent = op.new_parent_id
        elif op.operation == OperationType.CREATE_SHORTCUT:
            parent = op.shortcut_parent_id or op.new_parent_id
        elif op.operation in (
            OperationType.MOVE,
            OperationType.RENAME_AND_MOVE,
        ):
            parent = op.new_parent_id
        else:
            continue
        if parent and not parent.startswith("__new_folder_") and parent != "root":
            parents.add(parent)
    return parents


def _fetch_trashed_parents(service: Resource, parent_ids: set[str]) -> dict[str, str]:
    """Return {parent_id: name} for every input ID currently in the trash.

    Issues one files.get per ID (ID list is typically small — a plan touches
    only a handful of distinct destination folders). Unknown / inaccessible
    IDs are ignored: this is a defensive guard, not a discovery tool.
    """
    from googleapiclient.errors import HttpError

    trashed: dict[str, str] = {}
    for pid in parent_ids:
        try:
            meta = (
                service.files()
                .get(fileId=pid, fields="id,name,trashed", supportsAllDrives=True)
                .execute()
            )
        except HttpError as e:
            logger.warning(
                "Could not check trashed status for parent %s (HTTP %s): %s",
                pid,
                e.resp.status if e.resp else "?",
                e,
            )
            continue
        if meta.get("trashed"):
            trashed[pid] = meta.get("name", "")
    return trashed


class ExecutionResult(BaseModel):
    success_count: int = 0
    failure_count: int = 0
    # Ops that were never attempted (e.g. blocked by stale-snapshot guard, or
    # rollback log items without enough info to safely reverse). Distinct
    # from `failure_count`, which means "tried and the API rejected it".
    skipped_count: int = 0
    errors: list[dict] = Field(default_factory=list)
    rollback_log_path: Path | None = None


class PlanRunner:
    """Executes a plan against the Drive API with 4-phase execution."""

    def __init__(self, service: Resource, config: Config):
        self.service = service
        self.config = config

    def execute(
        self,
        plan: ExecutionPlan,
        dry_run: bool = False,
        skip_freshness_check: bool = False,
        verbose: bool = False,
    ) -> ExecutionResult:
        """Execute the plan in 4 phases.

        Before any mutations, checks snapshot freshness to reduce the risk of
        operating on stale state. Set skip_freshness_check=True to bypass.
        In dry-run mode, set verbose=True to print every op (the default
        prints a phase/op-type summary table — for big plans op-by-op output
        can be thousands of lines).
        """
        from rich.console import Console

        console = Console()

        # Stale snapshot guard: refuse to apply if snapshot is too old
        if not dry_run and not skip_freshness_check:
            from gdrive_organizer.store.snapshot import check_snapshot_freshness, load_snapshot

            try:
                snapshot = load_snapshot(config=self.config)
                is_fresh, msg = check_snapshot_freshness(
                    snapshot,
                    max_age_minutes=self.config.snapshot_max_age_minutes,
                )
                if not is_fresh:
                    console.print(f"[bold red]Stale snapshot:[/bold red] {msg}")
                    console.print(
                        "[yellow]Run 'gdrive-organizer scan --incremental' to refresh, "
                        "or set GDRIVE_SNAPSHOT_MAX_AGE_MINUTES to a higher value.[/yellow]"
                    )
                    # No ops were attempted — they were skipped by the guard,
                    # not failed by the Drive API. Surface this honestly.
                    return ExecutionResult(
                        skipped_count=len(plan.operations),
                        errors=[{"file_id": "_stale_snapshot", "error": msg}],
                    )
            except FileNotFoundError:
                pass  # No snapshot = nothing to check

        # Trashed-parent guard: refuse to write into folders that are now in
        # trash. Triggers when the snapshot still records a folder ID that a
        # rollback (or manual trash) flipped to trashed=true after the scan.
        # Without this, Phase 2 would happily move files into an invisible
        # parent and the user loses sight of them in the Drive UI (#J5).
        if not dry_run:
            parent_ids = _collect_real_destination_parents(plan)
            if parent_ids:
                trashed = _fetch_trashed_parents(self.service, parent_ids)
                if trashed:
                    pretty = ", ".join(f"{pid} ({name})" for pid, name in trashed.items())
                    msg = (
                        f"Plan references trashed parent folder(s): {pretty}. "
                        "Likely cause: a previous rollback trashed these folders "
                        "after the snapshot was taken. Re-scan and re-classify."
                    )
                    console.print(f"[bold red]Trashed parent:[/bold red] {msg}")
                    return ExecutionResult(
                        skipped_count=len(plan.operations),
                        errors=[{"file_id": "_trashed_parent", "error": msg}],
                    )

        if dry_run:
            self._dry_run_display(plan, console, verbose=verbose)
            return ExecutionResult(success_count=len(plan.operations))

        results: dict[str, dict] = {}
        errors: list[dict] = []
        before_states: dict[str, dict] = {}

        # Record before-states. folder_color_rgb captures the previous color
        # for UPDATE_FOLDER_COLOR ops so rollback can restore it; None means
        # backfill (no prior color), which rollback intentionally skips since
        # Drive API has no clean "remove color" path.
        for op in plan.operations:
            before_states[op.file_id] = {
                "name": op.current_name,
                "path": op.current_path,
                "parent_id": op.current_parent_id,
                "description": op.current_description,
                "folder_color_rgb": op.current_folder_color_rgb,
            }

        # Categorize operations by phase
        folder_ops = [o for o in plan.operations if o.operation == OperationType.CREATE_FOLDER]
        move_ops = [
            o
            for o in plan.operations
            if o.operation
            in (
                OperationType.MOVE,
                OperationType.RENAME,
                OperationType.RENAME_AND_MOVE,
                OperationType.TRASH,
                OperationType.UNTRASH,
            )
        ]
        shortcut_ops = [o for o in plan.operations if o.operation == OperationType.CREATE_SHORTCUT]
        desc_ops = [o for o in plan.operations if o.operation == OperationType.UPDATE_DESCRIPTION]
        color_ops = [o for o in plan.operations if o.operation == OperationType.UPDATE_FOLDER_COLOR]

        # --- Phase 1: Create folders (topologically sorted) ---
        id_mapping: dict[str, str] = {}
        if folder_ops:
            # Sort by path depth so parents are created before children
            folder_ops.sort(key=lambda op: op.new_path.count("/") if op.new_path else 0)
            console.print(f"[bold]Phase 1:[/bold] Creating {len(folder_ops)} folders...")
            for op in folder_ops:
                parent = op.new_parent_id
                if parent and parent in id_mapping:
                    parent = id_mapping[parent]
                try:
                    result = create_folder(
                        self.service,
                        op.current_name,
                        parent,
                        color_rgb=op.folder_color_rgb,
                    )
                    id_mapping[op.file_id] = result["id"]
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "success",
                        "response": result,
                    }
                except Exception as e:
                    logger.error("Failed to create folder %s: %s", op.current_name, e)
                    err_str = str(e)
                    errors.append({"file_id": op.file_id, "error": err_str})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err_str,
                    }

        # Resolve placeholders in subsequent phases and validate resolution
        unresolved = []
        for op in move_ops + shortcut_ops:
            if op.new_parent_id and op.new_parent_id.startswith("__new_folder_"):
                if op.new_parent_id in id_mapping:
                    op.new_parent_id = id_mapping[op.new_parent_id]
                else:
                    unresolved.append((op.file_id, "new_parent_id", op.new_parent_id))
            if op.shortcut_parent_id and op.shortcut_parent_id.startswith("__new_folder_"):
                if op.shortcut_parent_id in id_mapping:
                    op.shortcut_parent_id = id_mapping[op.shortcut_parent_id]
                else:
                    unresolved.append((op.file_id, "shortcut_parent_id", op.shortcut_parent_id))

        if unresolved:
            err_by_fid: dict[str, str] = {}
            for file_id, field, placeholder in unresolved:
                msg = f"Unresolved placeholder {placeholder} in {field} for {file_id}"
                logger.error(msg)
                errors.append({"file_id": file_id, "error": msg})
                err_by_fid.setdefault(file_id, msg)
            bad_ids = {file_id for file_id, _, _ in unresolved}
            # Record the failure against every affected op so the rollback log
            # surfaces the error string, not just status=unknown.
            for op in move_ops + shortcut_ops:
                if op.file_id in bad_ids:
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err_by_fid[op.file_id],
                    }
            move_ops = [o for o in move_ops if o.file_id not in bad_ids]
            shortcut_ops = [o for o in shortcut_ops if o.file_id not in bad_ids]

        # --- Phase 2: Move/Rename/Trash ---
        if move_ops:
            console.print(f"[bold]Phase 2:[/bold] Processing {len(move_ops)} file operations...")
            self._execute_batch_phase(move_ops, results, errors, console)

        # --- Phase 3: Create shortcuts (with semantic validation) ---
        if shortcut_ops:
            console.print(f"[bold]Phase 3:[/bold] Creating {len(shortcut_ops)} shortcuts...")
            for op in shortcut_ops:
                parent = op.shortcut_parent_id or op.new_parent_id
                target = op.shortcut_target_id
                # Validate: both parent and target must be real IDs
                if not parent or not target:
                    err = f"Shortcut missing parent ({parent}) or target ({target})"
                    errors.append({"file_id": op.file_id, "error": err})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err,
                    }
                    continue
                # Reject shortcuts where target looks like another shortcut synthetic ID
                if target.startswith("shortcut__"):
                    err = f"Shortcut-to-shortcut chain rejected: target={target}"
                    errors.append({"file_id": op.file_id, "error": err})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err,
                    }
                    continue
                # Reject if parent is still a placeholder (folder creation failed)
                if parent.startswith("__new_folder_"):
                    err = f"Shortcut parent is unresolved placeholder: {parent}"
                    errors.append({"file_id": op.file_id, "error": err})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err,
                    }
                    continue
                try:
                    result = create_shortcut(self.service, op.current_name, target, parent)
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "success",
                        "response": result,
                        "drive_id": result.get("id"),
                    }
                except Exception as e:
                    err_str = str(e)
                    errors.append({"file_id": op.file_id, "error": err_str})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err_str,
                    }

        # --- Phase 4: Update descriptions + folder colors (metadata mutations) ---
        if desc_ops:
            console.print(f"[bold]Phase 4:[/bold] Updating {len(desc_ops)} descriptions...")
            for op in desc_ops:
                # `is not None` so rollback can pass "" to clear a description.
                if op.new_description is None:
                    continue
                try:
                    result = update_description(self.service, op.file_id, op.new_description)
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "success",
                        "response": result,
                    }
                except Exception as e:
                    err_str = str(e)
                    errors.append({"file_id": op.file_id, "error": err_str})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err_str,
                    }

        if color_ops:
            console.print(f"[bold]Phase 4:[/bold] Updating {len(color_ops)} folder colors...")
            for op in color_ops:
                if not op.folder_color_rgb:
                    continue
                try:
                    result = update_folder_color(self.service, op.file_id, op.folder_color_rgb)
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "success",
                        "response": result,
                    }
                except Exception as e:
                    err_str = str(e)
                    errors.append({"file_id": op.file_id, "error": err_str})
                    results[_op_key(op.file_id, op.operation)] = {
                        "status": "failed",
                        "error": err_str,
                    }

        success_count = sum(1 for r in results.values() if r.get("status") == "success")
        rollback_path = self._save_rollback_log(plan, results, before_states, id_mapping)

        return ExecutionResult(
            success_count=success_count,
            failure_count=len(errors),
            errors=errors,
            rollback_log_path=rollback_path,
        )

    def _execute_batch_phase(
        self,
        operations: list[PlanOperation],
        results: dict,
        errors: list,
        console,
    ):
        """Execute operations in batches with rate limiting."""
        limiter = TokenBucket(
            rate=self.config.write_rate_limit,
            capacity=float(self.config.batch_size),
        )
        batch_size = self.config.batch_size

        def batch_callback(request_id, response, exception):
            # request_id has the form "file_id:op_type"; recover the file_id
            # for the user-facing errors list.
            file_id = request_id.split(":", 1)[0]
            if exception:
                errors.append({"file_id": file_id, "error": str(exception)})
                results[request_id] = {"status": "failed", "error": str(exception)}
            else:
                results[request_id] = {"status": "success", "response": response}

        with Progress(
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task("Executing...", total=len(operations))
            for i in range(0, len(operations), batch_size):
                batch = operations[i : i + batch_size]
                limiter.acquire(len(batch))
                try:
                    execute_batch(self.service, batch, batch_callback)
                except Exception as e:
                    err_str = str(e)
                    for op in batch:
                        # Dedup by op_key (the actual results dict key) so we
                        # don't double-report ops the callback already handled.
                        key = _op_key(op.file_id, op.operation)
                        if key not in results:
                            errors.append({"file_id": op.file_id, "error": err_str})
                            results[key] = {"status": "failed", "error": err_str}
                progress.update(task, advance=len(batch))

    def _dry_run_display(self, plan: ExecutionPlan, console, verbose: bool = False):
        """Display plan phases in dry-run mode.

        Default: a compact summary table grouped by phase + op type.
        verbose=True: also print every op line-by-line (legacy behavior —
        useful for grep, but can be tens of thousands of lines on real plans).
        """
        from collections import Counter

        from rich.table import Table

        phase_map = {
            OperationType.CREATE_FOLDER: ("Phase 1", "FOLDER"),
            OperationType.MOVE: ("Phase 2", "MOVE"),
            OperationType.RENAME: ("Phase 2", "RENAME"),
            OperationType.RENAME_AND_MOVE: ("Phase 2", "RENAME+MOVE"),
            OperationType.TRASH: ("Phase 2", "TRASH"),
            OperationType.UNTRASH: ("Phase 2", "UNTRASH"),
            OperationType.CREATE_SHORTCUT: ("Phase 3", "SHORTCUT"),
            OperationType.UPDATE_DESCRIPTION: ("Phase 4", "DESCRIPTION"),
            OperationType.UPDATE_FOLDER_COLOR: ("Phase 4", "COLOR"),
        }

        if verbose:
            for op in plan.operations:
                phase, label = phase_map.get(op.operation, ("Phase ?", op.operation.value))
                console.print(
                    f"  [dim][DRY RUN][/dim] [{phase} - {label}] {op.current_name}",
                    end="",
                )
                if op.new_path:
                    console.print(f" -> {op.new_path}", end="")
                if op.new_description:
                    console.print(f" [dim]({op.new_description[:40]}...)[/dim]", end="")
                console.print()

        # Always show summary
        counter: Counter[tuple[str, str]] = Counter()
        for op in plan.operations:
            counter[phase_map.get(op.operation, ("Phase ?", op.operation.value))] += 1

        table = Table(title=f"Dry-run summary — {len(plan.operations)} operations")
        table.add_column("Phase", style="cyan")
        table.add_column("Operation", style="magenta")
        table.add_column("Count", justify="right", style="green")
        for (phase, label), count in sorted(counter.items()):
            table.add_row(phase, label, str(count))
        console.print(table)
        if not verbose:
            self._dry_run_destination_buckets(plan, console)
        if not verbose and plan.operations:
            console.print("[dim]Pass --verbose to see every op line-by-line.[/dim]")

    def _dry_run_destination_buckets(
        self,
        plan: ExecutionPlan,
        console,
        top_n: int = 15,
    ) -> None:
        """Show top destination folders for MOVE / RENAME_AND_MOVE / SHORTCUT.

        The phase summary tells the user *what* the plan will do (1222 moves);
        this table tells them *where* those moves land. Without it the
        bucketing decisions made by classify are invisible until apply.
        """
        from collections import Counter

        from rich.table import Table

        move_types = {OperationType.MOVE, OperationType.RENAME_AND_MOVE}
        move_buckets: Counter[str] = Counter()
        shortcut_buckets: Counter[str] = Counter()

        for op in plan.operations:
            if op.operation in move_types and op.new_path:
                folder = op.new_path.rsplit("/", 1)[0] or "/"
                move_buckets[folder] += 1
            elif op.operation == OperationType.CREATE_SHORTCUT:
                # shortcut_parent_id resolves to a Drive ID, not a name. Without
                # a snapshot lookup the path is the human-readable signal.
                if op.new_path:
                    folder = op.new_path.rsplit("/", 1)[0] or "/"
                    shortcut_buckets[folder] += 1

        for label, buckets in (
            ("MOVE / RENAME+MOVE destinations", move_buckets),
            ("SHORTCUT destinations", shortcut_buckets),
        ):
            if not buckets:
                continue
            table = Table(title=label)
            table.add_column("Destination folder", style="cyan", overflow="fold")
            table.add_column("Ops", justify="right", style="green")
            for folder, count in buckets.most_common(top_n):
                table.add_row(folder, str(count))
            console.print(table)
            remaining = len(buckets) - top_n
            if remaining > 0:
                console.print(f"[dim]... {remaining} more folders[/dim]")

    def rollback(self, rollback_log_path: Path) -> ExecutionResult:
        """Rollback operations using a saved rollback log."""
        data = json.loads(rollback_log_path.read_text())
        # Count successful entries in the log; whatever doesn't make it into
        # reverse_ops was skipped (e.g. legacy shortcut without realDriveId).
        successful_log_entries = sum(
            1 for e in data.get("operations", []) if e.get("status") == "success"
        )
        reverse_ops = self._build_reverse_operations(data)
        skipped = max(0, successful_log_entries - len(reverse_ops))

        if not reverse_ops:
            return ExecutionResult(skipped_count=skipped)
        reverse_plan = ExecutionPlan(
            created_at=datetime.now(UTC),
            operations=reverse_ops,
        )
        result = self.execute(reverse_plan)
        # Carry forward the skip count from the build phase
        result.skipped_count += skipped
        return result

    def _save_rollback_log(self, plan, results, before_states, id_mapping) -> Path:
        """Save a rollback log for recovery.

        id_mapping contains placeholder→real-id from Phase 1, needed so rollback
        can TRASH the created folders by their real Drive IDs.
        """
        log = {
            "executedAt": datetime.now(UTC).isoformat(),
            "planRef": str(plan.created_at),
            "id_mapping": id_mapping,  # placeholder → real Drive ID
            "operations": [],
        }
        for op in plan.operations:
            op_result = results.get(_op_key(op.file_id, op.operation), {})
            entry = {
                "fileId": op.file_id,
                "type": op.operation.value,
                "before": before_states.get(op.file_id, {}),
                "after": {
                    "name": op.new_name or op.current_name,
                    "path": op.new_path or op.current_path,
                    "parent_id": op.new_parent_id or op.current_parent_id,
                    "description": op.new_description,
                },
                "status": op_result.get("status", "unknown"),
            }
            # Persist the failure reason so the rollback log is self-explanatory
            # (was: status:"failed" with no message — user had to grep API logs).
            if entry["status"] == "failed" and op_result.get("error"):
                entry["error"] = op_result["error"]
            # For created folders, record the real Drive ID in the log entry
            if op.operation == OperationType.CREATE_FOLDER and op.file_id in id_mapping:
                entry["realDriveId"] = id_mapping[op.file_id]
            # For created shortcuts, record the new shortcut's own Drive ID
            # (op.file_id is the *target* file's ID, not the shortcut's; storing
            # the latter is what lets rollback trash the shortcut, not the target)
            elif op.operation == OperationType.CREATE_SHORTCUT and op_result.get("drive_id"):
                entry["realDriveId"] = op_result["drive_id"]
            log["operations"].append(entry)

        logs_dir = self.config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%S")
        log_path = logs_dir / f"rollback-{timestamp}.json"
        log_path.write_text(json.dumps(log, indent=2))
        return log_path

    def _build_reverse_operations(self, rollback_data: dict) -> list[PlanOperation]:
        """Create reverse operations from a rollback log.

        Operations are reversed in reverse execution order so that dependencies
        (shortcuts before folders, moves before folder deletions) are respected.
        """
        reverse_ops = []
        id_mapping = rollback_data.get("id_mapping", {})

        for entry in reversed(rollback_data.get("operations", [])):
            if entry.get("status") != "success":
                continue
            before = entry.get("before", {})
            after = entry.get("after", {})
            op_type = entry.get("type", "rename")

            if op_type == "trash":
                # Correctly restore from trash via UNTRASH (sets trashed=false)
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType.UNTRASH,
                        reason="rollback: restore from trash",
                    )
                )
            elif op_type == "create_folder":
                # Trash the created folder using its real Drive ID
                real_id = entry.get("realDriveId") or id_mapping.get(entry["fileId"])
                if real_id:
                    reverse_ops.append(
                        PlanOperation(
                            file_id=real_id,
                            current_name=after.get("name", ""),
                            current_path=after.get("path", ""),
                            operation=OperationType.TRASH,
                            reason="rollback: remove created folder",
                        )
                    )
                else:
                    logger.warning(
                        "Cannot rollback folder %s: no real Drive ID in log",
                        entry["fileId"],
                    )
            elif op_type == "create_shortcut":
                # Trash the *shortcut* itself, identified by realDriveId — NOT
                # entry["fileId"], which is the target file's ID. Without
                # realDriveId we can't safely rollback (legacy logs).
                shortcut_drive_id = entry.get("realDriveId")
                if not shortcut_drive_id:
                    logger.warning(
                        "Cannot rollback shortcut for %s: log lacks shortcut Drive ID",
                        entry["fileId"],
                    )
                    continue
                reverse_ops.append(
                    PlanOperation(
                        file_id=shortcut_drive_id,
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType.TRASH,
                        reason="rollback: remove shortcut",
                    )
                )
            elif op_type == "update_folder_color":
                # Restore the prior color if we recorded one. For backfill
                # (prior was None) we skip — Drive API has no clean way to
                # un-set a folder color.
                previous_color = before.get("folder_color_rgb")
                if not previous_color:
                    logger.info(
                        "Skipping rollback for color backfill on %s (no prior color recorded)",
                        entry["fileId"],
                    )
                    continue
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=before.get("name", "") or after.get("name", ""),
                        current_path=before.get("path", "") or after.get("path", ""),
                        operation=OperationType.UPDATE_FOLDER_COLOR,
                        folder_color_rgb=previous_color,
                        reason="rollback: restore color",
                    )
                )
            elif op_type == "update_description":
                # Reverse semantics: if a description was newly added (prior is
                # None / missing), unset it via empty string. Otherwise restore
                # the prior value verbatim.
                previous_description = before.get("description")
                new_value = previous_description if previous_description is not None else ""
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=before.get("name", "") or after.get("name", ""),
                        current_path=before.get("path", "") or after.get("path", ""),
                        operation=OperationType.UPDATE_DESCRIPTION,
                        new_description=new_value,
                        current_description=after.get("description"),
                        reason="rollback: restore description",
                    )
                )
            elif op_type in ("move", "rename", "rename_and_move"):
                # null parent_id in `before` means the file lived at My Drive
                # root before the move. Drive API accepts the literal "root"
                # alias, so we use that to send the file back home.
                if op_type in ("move", "rename_and_move"):
                    target_parent = before.get("parent_id") or "root"
                else:
                    target_parent = None
                reverse_ops.append(
                    PlanOperation(
                        file_id=entry["fileId"],
                        current_name=after.get("name", ""),
                        current_path=after.get("path", ""),
                        operation=OperationType(op_type),
                        new_name=before.get("name"),
                        new_parent_id=target_parent,
                        current_parent_id=after.get("parent_id"),
                        new_path=before.get("path"),
                        reason="rollback",
                    )
                )
        return reverse_ops
