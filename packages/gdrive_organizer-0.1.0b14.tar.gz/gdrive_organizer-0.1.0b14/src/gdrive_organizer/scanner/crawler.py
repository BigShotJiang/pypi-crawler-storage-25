"""Flat crawl scanner for Google Drive API v3."""

from __future__ import annotations

from typing import TYPE_CHECKING

from googleapiclient.errors import HttpError
from rich.progress import Progress, SpinnerColumn, TextColumn

from gdrive_organizer.utils.logger import get_logger
from gdrive_organizer.utils.retry import with_retry

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

logger = get_logger("scanner.crawler")

# Shared file field list — used by both files.list and changes.list.
# Note: permissions field is excluded because it forces pageSize to max 100.
# Permissions are fetched separately via the permissions command.
_FILE_FIELDS = (
    "id,name,mimeType,parents,owners(displayName,emailAddress),"
    "shared,createdTime,modifiedTime,size,webViewLink,driveId,shortcutDetails,"
    "md5Checksum,sha256Checksum,ownedByMe,description,starred,"
    "lastModifyingUser(displayName,emailAddress),"
    "originalFilename,quotaBytesUsed,fileExtension,fullFileExtension,viewedByMeTime,"
    "imageMediaMetadata(width,height,rotation,cameraMake,cameraModel),"
    "videoMediaMetadata(width,height,durationMillis),"
    "sharingUser(displayName,emailAddress),version,folderColorRgb"
)

# Slim field set — only what the planner + tree builder strictly require.
# Trades richer metadata (descriptions, image/video EXIF, sharing user, etc.)
# and the permissions/revisions enrichment phases for a faster scan. Useful
# for measuring whether _FILE_FIELDS bloat is the cause of slow scans
# (docs/SCAN-PERFORMANCE.md hypothesis).
_MINIMAL_FILE_FIELDS = (
    "id,name,mimeType,parents,modifiedTime,createdTime,size,"
    "owners(emailAddress),ownedByMe,md5Checksum,trashed"
)

FIELDS = f"files({_FILE_FIELDS}),nextPageToken"
CHANGE_FIELDS = f"changes(fileId,file({_FILE_FIELDS}),removed),newStartPageToken,nextPageToken"


def scan_all_files(
    service: Resource,
    query: str = "trashed=false",
    page_size: int = 1000,
    *,
    minimal_fields: bool = False,
) -> list[dict]:
    """Flat crawl all files using files.list with pagination.

    minimal_fields=True swaps the rich field set for _MINIMAL_FILE_FIELDS —
    a measurement aid for the slow-scan hypothesis in SCAN-PERFORMANCE.md.
    """
    import time as _time

    all_files: list[dict] = []
    fields = f"files({_MINIMAL_FILE_FIELDS}),nextPageToken" if minimal_fields else FIELDS

    @with_retry(max_retries=5)
    def _execute_list(request):
        return request.execute()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=True,
    ) as progress:
        task = progress.add_task("Scanning Drive...", total=None)

        request = service.files().list(
            q=query,
            pageSize=page_size,
            fields=fields,
            includeItemsFromAllDrives=True,
            supportsAllDrives=True,
        )

        page_num = 0
        scan_start = _time.perf_counter()
        while request is not None:
            page_start = _time.perf_counter()
            response = _execute_list(request)
            page_elapsed = _time.perf_counter() - page_start
            files = response.get("files", [])
            all_files.extend(files)
            page_num += 1
            # Log per-page latency so a slow scan can be diagnosed from logs/
            # (a 19-minute scan on 1500 files in our dogfood had no breakdown).
            logger.info(
                "scan page %d: %d files, %.2fs (%d total so far)",
                page_num,
                len(files),
                page_elapsed,
                len(all_files),
            )
            progress.update(task, description=f"Scanning Drive... ({len(all_files)} files)")
            request = service.files().list_next(request, response)
        logger.info(
            "scan complete: %d files in %d pages, %.2fs total",
            len(all_files),
            page_num,
            _time.perf_counter() - scan_start,
        )

    return all_files


def fetch_drive_info(service: Resource) -> dict:
    """Fetch Drive account info (user, storage quota)."""

    @with_retry(max_retries=3)
    def _execute():
        return service.about().get(fields="user(displayName,emailAddress),storageQuota").execute()

    about = _execute()
    user = about.get("user", {})
    quota = about.get("storageQuota", {})
    return {
        "user_name": user.get("displayName", ""),
        "user_email": user.get("emailAddress", ""),
        "storage_limit": int(quota.get("limit", 0)),
        "storage_used": int(quota.get("usage", 0)),
        "storage_in_drive": int(quota.get("usageInDrive", 0)),
        "storage_in_trash": int(quota.get("usageInDriveTrash", 0)),
    }


def enrich_permissions_for_shared(
    service: Resource,
    files: list[dict],
    delay: float = 0.05,
) -> int:
    """Enrich permissions for files that I own AND are shared (in-place).

    Only fetches permissions for files where ownedByMe=True AND shared=True.
    This is fast because shared-by-me files are usually a small subset.
    Returns the number of files enriched.
    """
    import time

    enriched = 0
    for f in files:
        if not (f.get("ownedByMe") and f.get("shared")):
            continue
        if f.get("mimeType") == "application/vnd.google-apps.folder":
            # Folders can also be shared — include them
            pass

        @with_retry(max_retries=3)
        def _get_perms(fid=f["id"]):
            return (
                service.permissions()
                .list(
                    fileId=fid,
                    fields=(
                        "permissions(id,type,role,emailAddress,"
                        "displayName,domain,allowFileDiscovery)"
                    ),
                    supportsAllDrives=True,
                )
                .execute()
            )

        try:
            result = _get_perms()
            f["permissions"] = result.get("permissions", [])
            enriched += 1
            if delay > 0:
                time.sleep(delay)
        except HttpError as e:
            logger.warning(
                "Permission fetch failed for %s (HTTP %s): %s",
                f["id"],
                e.resp.status if e.resp else "?",
                e,
            )
            f["permissions"] = []
        except Exception as e:
            # Unexpected non-API error — log at ERROR and re-raise
            logger.error("Unexpected error fetching permissions for %s: %s", f["id"], e)
            raise

    return enriched


def enrich_revisions(
    service: Resource,
    files: list[dict],
    max_files: int = 200,
    delay: float = 0.05,
) -> None:
    """Enrich files with revision count (in-place). Only for non-folder files."""
    import time

    count = 0
    for f in files:
        if f.get("mimeType") == "application/vnd.google-apps.folder":
            continue
        if count >= max_files:
            break

        @with_retry(max_retries=3)
        def _get_revisions(fid=f["id"]):
            return service.revisions().list(fileId=fid, fields="revisions(id)").execute()

        try:
            revs = _get_revisions()
            f["revisionCount"] = len(revs.get("revisions", []))
            count += 1
            if delay > 0:
                time.sleep(delay)
        except HttpError as e:
            logger.warning(
                "Revision fetch failed for %s (HTTP %s): %s",
                f["id"],
                e.resp.status if e.resp else "?",
                e,
            )
            f["revisionCount"] = 0
        except Exception as e:
            logger.error("Unexpected error fetching revisions for %s: %s", f["id"], e)
            raise

    # Files not enriched get 0
    for f in files:
        if "revisionCount" not in f:
            f["revisionCount"] = 0


def reparent_orphans_with_trashed_parent(
    service: Resource,
    files: list[dict],
) -> int:
    """Find files whose parent is missing from the scan result, and re-parent
    them to the user's root if that parent is currently in the trash.

    Why: Drive's `q=trashed=false` returns a file whose own `trashed=false`
    even if its direct parent was later moved to trash. Such a file ends up
    with `parents=[<trashed_id>]`, which `build_tree` quietly demotes to a
    root node — but the file is still a member of an invisible folder, so
    the user can't see it in Drive UI either. Without this guard those
    files never surface as needing organization (#J6).

    Returns the number of files re-parented. Mutates the input list
    in-place (sets `parents=[]` for re-parented files so they appear at
    My Drive root and the next plan classifies them).
    """
    file_ids = {f["id"] for f in files}
    # Collect orphan-parent IDs and the children attached to each
    children_per_parent: dict[str, list[dict]] = {}
    for f in files:
        parents = f.get("parents") or []
        if not parents:
            continue
        pid = parents[0]
        if pid in file_ids:
            continue
        children_per_parent.setdefault(pid, []).append(f)

    if not children_per_parent:
        return 0

    reparented = 0
    for pid, children in children_per_parent.items():
        try:

            @with_retry(max_retries=3)
            def _get_meta(fid=pid):
                return (
                    service.files()
                    .get(fileId=fid, fields="id,name,trashed", supportsAllDrives=True)
                    .execute()
                )

            meta = _get_meta()
        except HttpError as e:
            # Inaccessible parents (shared-from-others, deleted) are out of
            # scope: this guard only acts on confirmed-trashed parents.
            logger.debug(
                "Could not check orphan parent %s (HTTP %s): %s",
                pid,
                e.resp.status if e.resp else "?",
                e,
            )
            continue
        if not meta.get("trashed"):
            continue
        logger.warning(
            "Re-parenting %d file(s) from trashed folder %s (%s) to root.",
            len(children),
            pid,
            meta.get("name", ""),
        )
        for child in children:
            child["parents"] = []
            reparented += 1
    return reparented


def get_start_page_token(service: Resource) -> str:
    """Get the starting page token for the Changes API."""

    @with_retry(max_retries=5)
    def _execute():
        return service.changes().getStartPageToken(supportsAllDrives=True).execute()

    response = _execute()
    return response["startPageToken"]
