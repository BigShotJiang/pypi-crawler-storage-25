"""Tests for plan generation."""

from datetime import UTC, datetime

from gdrive_organizer.ai.planner import (
    _resolve_time_path,
    _response_to_operations,
    detect_conflicts,
)
from gdrive_organizer.models import (
    DriveFile,
    LLMResponseItem,
    OperationType,
    PlanOperation,
)


def _make_file(fid: str, name: str, path: str = "", modified: str | None = None) -> DriveFile:
    return DriveFile(
        id=fid,
        name=name,
        mime_type="text/plain",
        path=path or f"root/{name}",
        parents=["root_folder"],
        modified_time=modified or datetime(2026, 4, 8, tzinfo=UTC),
        description="기존 설명",
        owned_by_me=True,  # default — orphan/external tests opt-out explicitly
    )


def test_resolve_time_path():
    f = _make_file("1", "test.txt", modified=datetime(2026, 4, 8, tzinfo=UTC))
    assert _resolve_time_path(f) == "🪄 AI 정리/2026/04"


def test_resolve_time_path_no_date():
    f = DriveFile(id="1", name="test.txt", mime_type="text/plain")
    assert _resolve_time_path(f) == "🪄 AI 정리/미분류"


def test_resolve_time_path_prefers_created_over_modified():
    """The archive bucket must reflect when the user originally created the
    file in Drive, not the most-recent-modify. Otherwise our own move/edit
    ops bump modified_time and re-tag every previously-archived file to the
    apply timestamp, collapsing the timeline into one folder."""
    f = DriveFile(
        id="1",
        name="t.txt",
        mime_type="text/plain",
        created_time=datetime(2024, 1, 15, tzinfo=UTC),
        modified_time=datetime(2026, 5, 4, tzinfo=UTC),
    )
    assert _resolve_time_path(f) == "🪄 AI 정리/2024/01"


def test_resolve_time_path_falls_back_to_modified_when_no_created():
    """Some legacy/imported files have no created_time. Fall back to
    modified_time so they don't all dump into 미분류/."""
    f = DriveFile(
        id="1",
        name="t.txt",
        mime_type="text/plain",
        created_time=None,
        modified_time=datetime(2026, 5, 4, tzinfo=UTC),
    )
    assert _resolve_time_path(f) == "🪄 AI 정리/2026/05"


def test_archive_root_prefix_signals_ai_origin():
    """The AI-managed root must be visually distinct so the user can tell
    AI-created folders apart from their own (per #N from dogfood)."""
    from gdrive_organizer.ai.prompts import AI_ROOT, ARCHIVE_ROOT

    assert AI_ROOT.startswith("🪄")  # wand emoji = AI/auto
    assert "AI" in AI_ROOT
    # b13: ARCHIVE_ROOT collapsed onto AI_ROOT — no extra 보관함 layer
    # because the prefix already signals AI-managed.
    assert ARCHIVE_ROOT == AI_ROOT


# --- Folder color palette helper (#3) ---


class TestFolderColor:
    """Stable palette so the user's mental map of the tree doesn't shift
    between classify runs, and brand colors for the AI roots."""

    def test_fixed_overrides_for_ai_roots(self):
        from gdrive_organizer.ai.prompts import AI_ROOT, folder_color_for

        assert folder_color_for(AI_ROOT) == "#9a9cff"
        assert folder_color_for("보관함") == "#c2c2c2"
        assert folder_color_for("미분류") == "#ffad46"

    def test_same_name_returns_same_color(self):
        from gdrive_organizer.ai.prompts import folder_color_for

        c1 = folder_color_for("Sec_Brain")
        c2 = folder_color_for("Sec_Brain")
        assert c1 == c2

    def test_different_names_can_differ(self):
        from gdrive_organizer.ai.prompts import folder_color_for

        # Among a handful of distinct names, at least one collision-free pair.
        names = ["AI", "Code", "Docs", "Photos", "Videos", "Books", "Papers", "Sec_Brain"]
        colors = {n: folder_color_for(n) for n in names}
        assert len(set(colors.values())) > 1, "palette must yield variation"

    def test_color_always_in_palette(self):
        from gdrive_organizer.ai.prompts import (
            DRIVE_FOLDER_PALETTE,
            _FIXED_FOLDER_COLORS,
            folder_color_for,
        )

        valid = set(DRIVE_FOLDER_PALETTE) | set(_FIXED_FOLDER_COLORS.values())
        for n in ["x", "2024", "프로젝트", "이상한 이름!@#"]:
            assert folder_color_for(n) in valid

    def test_planner_assigns_color_to_create_folder_ops(self):
        """CREATE_FOLDER ops emitted by the planner must carry a color so
        the runner can write it. Without this, every new folder defaults
        to grey in Drive."""
        from gdrive_organizer.ai.planner import _response_to_operations
        from gdrive_organizer.ai.prompts import folder_color_for

        files = {"f1": _make_file("f1", "doc.txt")}
        items = [LLMResponseItem(file_id="f1", move_to="🪄 AI 정리/2024/03")]
        ops = _response_to_operations(items, files, set())
        folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
        assert folder_ops, "expected at least one CREATE_FOLDER op"
        for op in folder_ops:
            assert op.folder_color_rgb == folder_color_for(op.current_name), (
                f"folder {op.current_name!r} got color {op.folder_color_rgb}"
            )


# --- Color backfill (P3) ---


class TestColorBackfill:
    """Pre-b9 AI folders had no folderColorRgb. The backfill emits
    UPDATE_FOLDER_COLOR ops only for AI_ROOT subtree folders missing a
    color, leaving the user's own folders alone."""

    def _snap(self, folders: list[tuple[str, str | None]]) -> "Snapshot":
        from gdrive_organizer.models import Snapshot, SnapshotStats

        files = []
        for path, color in folders:
            name = path.rsplit("/", 1)[-1]
            files.append(
                DriveFile(
                    id=f"id_{name}_{path}".replace("/", "_"),
                    name=name,
                    mime_type="application/vnd.google-apps.folder",
                    path=path,
                    folder_color_rgb=color,
                )
            )
        return Snapshot(
            scanned_at=datetime(2026, 5, 4, tzinfo=UTC),
            files=files,
            stats=SnapshotStats(total_folders=len(files)),
        )

    def test_backfills_only_uncolored_ai_subtree(self):
        from gdrive_organizer.ai.planner import _add_color_backfill_operations
        from gdrive_organizer.ai.prompts import folder_color_for

        snap = self._snap([
            ("🪄 AI 정리", None),               # AI root, no color → backfill
            ("🪄 AI 정리/2024", None),          # AI subtree → backfill
            ("🪄 AI 정리/2024/03", None),       # AI subtree → backfill
            ("🪄 AI 정리/2025", "#42d692"),     # already colored → skip
            ("부트캠프", None),                # user folder → skip
            ("Sec_Brain", "#fbe983"),          # user folder colored → skip
        ])
        ops = _add_color_backfill_operations(snap, [])
        names = {op.current_name for op in ops}
        # AI_ROOT subtree, no color, not user folders.
        assert names == {"🪄 AI 정리", "2024", "03"}, (
            f"backfill scope wrong: {names}"
        )
        for op in ops:
            assert op.operation == OperationType.UPDATE_FOLDER_COLOR
            assert op.folder_color_rgb == folder_color_for(op.current_name)
            # backfill: prior color was None (not set). We still preserve
            # whatever was there for rollback fidelity.
            assert op.current_folder_color_rgb is None

    def test_backfills_drive_default_grey(self):
        """Drive returns #8f8f8f for folders the user never explicitly
        colored. The backfill must treat this as "no color set" and apply
        a hash-palette color, otherwise b8-era AI folders (which all show
        as #8f8f8f) never get colored."""
        from gdrive_organizer.ai.planner import _add_color_backfill_operations

        snap = self._snap([
            ("🪄 AI 정리", "#8f8f8f"),         # default → backfill
            ("🪄 AI 정리/2024", "#8F8F8F"),    # case-insensitive
            ("🪄 AI 정리/2025", "#42d692"),    # user-set → skip
        ])
        ops = _add_color_backfill_operations(snap, [])
        names = {op.current_name for op in ops}
        assert names == {"🪄 AI 정리", "2024"}
        # Prior color preserved on the op so rollback can restore the
        # exact pre-apply state (even if that's the default grey).
        for op in ops:
            assert (op.current_folder_color_rgb or "").lower() == "#8f8f8f"

    def test_backfill_skips_folders_being_created_in_same_plan(self):
        """If a CREATE_FOLDER op is already going to set the color, don't
        also emit a UPDATE_FOLDER_COLOR for the same path — that would
        race or double-write."""
        from gdrive_organizer.ai.planner import _add_color_backfill_operations
        from gdrive_organizer.models import PlanOperation

        snap = self._snap([
            ("🪄 AI 정리", None),
            ("🪄 AI 정리/2024", None),
        ])
        pending = [
            PlanOperation(
                file_id="__new_folder_0__",
                current_name="2024",
                current_path="",
                operation=OperationType.CREATE_FOLDER,
                new_path="🪄 AI 정리/2024",
            )
        ]
        ops = _add_color_backfill_operations(snap, pending)
        names = [op.current_name for op in ops]
        assert "🪄 AI 정리" in names  # still backfilled
        assert "2024" not in names  # excluded — being CREATEd


def test_response_to_operations_move():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    ops = _response_to_operations(items, files, set())
    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert len(move_ops) == 1
    assert move_ops[0].new_path == "보관함/2026/04/report.txt"


def test_response_to_operations_shortcut():
    files = {"1": _make_file("1", "report.txt")}
    items = [
        LLMResponseItem(
            file_id="1",
            move_to="보관함/2026/04",
            shortcuts=["태그/AI"],
        )
    ]
    ops = _response_to_operations(items, files, set())
    shortcut_ops = [op for op in ops if op.operation == OperationType.CREATE_SHORTCUT]
    assert len(shortcut_ops) == 1
    assert shortcut_ops[0].shortcut_target_id == "1"


def test_response_to_operations_description():
    files = {"1": _make_file("1", "report.txt")}
    items = [
        LLMResponseItem(
            file_id="1",
            move_to="보관함/2026/04",
            new_description="AI 관련 리서치 문서",
        )
    ]
    ops = _response_to_operations(items, files, set())
    desc_ops = [op for op in ops if op.operation == OperationType.UPDATE_DESCRIPTION]
    assert len(desc_ops) == 1
    assert desc_ops[0].new_description == "AI 관련 리서치 문서"
    assert desc_ops[0].current_description == "기존 설명"


def test_response_to_operations_creates_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04", shortcuts=["태그/AI"])]
    ops = _response_to_operations(items, files, set())
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    assert len(folder_ops) >= 2  # 보관함/2026/04 and 태그/AI


def test_response_skips_existing_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    # Mark 보관함/2026/04 as already existing
    ops = _response_to_operations(items, files, {"보관함/2026/04"})
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    # Should NOT create 보관함/2026/04 since it exists
    created_paths = {op.new_path for op in folder_ops}
    assert "보관함/2026/04" not in created_paths


def test_existing_folder_move_uses_real_folder_id():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]

    ops = _response_to_operations(items, files, {"보관함/2026/04": "folder_2026_04"})

    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert move_ops[0].new_parent_id == "folder_2026_04"


def test_partial_existing_parent_chain_uses_real_parent_and_placeholder_child():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]

    ops = _response_to_operations(items, files, {"보관함": "archive_root"})

    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    folder_by_path = {op.new_path: op for op in folder_ops}
    assert folder_by_path["보관함/2026"].new_parent_id == "archive_root"
    assert folder_by_path["보관함/2026/04"].new_parent_id == folder_by_path["보관함/2026"].file_id

    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert move_ops[0].new_parent_id == folder_by_path["보관함/2026/04"].file_id


def test_existing_folder_shortcut_uses_real_folder_id():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04", shortcuts=["태그/AI"])]

    ops = _response_to_operations(items, files, {"태그/AI": "tag_ai"})

    shortcut_ops = [op for op in ops if op.operation == OperationType.CREATE_SHORTCUT]
    assert shortcut_ops[0].shortcut_parent_id == "tag_ai"


def test_detect_conflicts():
    ops = [
        PlanOperation(
            file_id="1",
            current_name="a.txt",
            current_path="root/a.txt",
            operation=OperationType.MOVE,
            new_name="report.txt",
            new_path="보관함/report.txt",
        ),
        PlanOperation(
            file_id="2",
            current_name="b.txt",
            current_path="root/b.txt",
            operation=OperationType.MOVE,
            new_name="report.txt",
            new_path="보관함/report.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 1


def test_detect_no_conflicts():
    ops = [
        PlanOperation(
            file_id="1",
            current_name="a.txt",
            current_path="root/a.txt",
            operation=OperationType.MOVE,
            new_path="보관함/2026/04/a.txt",
        ),
        PlanOperation(
            file_id="2",
            current_name="b.txt",
            current_path="root/b.txt",
            operation=OperationType.MOVE,
            new_path="보관함/2026/04/b.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 0


# --- Preset content-gating (#4) ---


def test_migration_preset_does_not_require_content():
    """Migration is metadata-only — must not trigger snippet extraction."""
    from gdrive_organizer.ai.prompts import BUILTIN_PRESETS

    assert BUILTIN_PRESETS["migration"].requires_content is False


def test_second_brain_preset_requires_content():
    """Second-brain analyzes text content — must trigger snippet extraction."""
    from gdrive_organizer.ai.prompts import BUILTIN_PRESETS

    assert BUILTIN_PRESETS["second-brain"].requires_content is True


def test_custom_preset_defaults_to_requiring_content(tmp_path):
    """Custom preset defaults to True (conservative — user might reference content)."""
    from gdrive_organizer.ai.prompts import load_preset

    prompt_file = tmp_path / "custom.txt"
    prompt_file.write_text("Classify these files based on their content.")

    preset = load_preset("custom", prompt_file=prompt_file)
    assert preset.requires_content is True


def test_generate_plan_skips_extract_snippets_for_migration(monkeypatch):
    """Real-world bug: migration preset triggered ~21min snippet download.
    Verify the gate now skips _extract_snippets entirely."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 1, tzinfo=UTC),
        files=[
            DriveFile(
                id="f1",
                name="report.md",
                mime_type="text/markdown",
                path="report.md",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
            ),
        ],
    )

    from gdrive_organizer.ai.validator import ValidationResult

    extract_mock = AsyncMock(return_value={})
    classify_mock = AsyncMock(return_value=[])

    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_extract_snippets", extract_mock),
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    extract_mock.assert_not_called()
    classify_mock.assert_called_once()


# --- _extract_snippets parallelism (#5) ---


def test_extract_snippets_runs_in_parallel():
    """The serial version blocked the event loop; the parallel version must
    finish in <(N * per_call_latency) wall time. We verify by inserting a
    100ms sleep per call and asserting that 8 files complete in <300ms (vs
    800ms serial)."""
    import asyncio
    import time as time_mod
    from unittest.mock import MagicMock, patch

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="application/vnd.google-apps.document",  # exportable
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(8)
    ]

    def slow_extract(_svc, file_id, _mime, head=300, tail=150):
        time_mod.sleep(0.1)  # simulate Drive export latency
        return f"snippet-{file_id}"

    service = MagicMock()
    with patch.object(planner, "extract_text_snippet", side_effect=slow_extract):
        start = time_mod.perf_counter()
        result = asyncio.run(planner._extract_snippets(service, files, concurrency=8))
        elapsed = time_mod.perf_counter() - start

    assert len(result) == 8
    # 8 parallel × 100ms ≈ ~100-200ms; serial would be ~800ms.
    # Generous threshold accounts for thread spawn overhead in CI.
    assert elapsed < 0.5, f"Expected parallel execution (~0.1s), got {elapsed:.2f}s"


def test_extract_snippets_returns_empty_when_no_service():
    import asyncio

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id="f1",
            name="doc.md",
            mime_type="text/markdown",
            path="doc.md",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        ),
    ]
    result = asyncio.run(planner._extract_snippets(None, files))
    assert result == {}


# --- LLM batch parallelism (#J) ---


def test_classify_with_preset_runs_batches_in_parallel():
    """Sequential batches were the dominant cost (~14min on 1500 files);
    gather + the client's internal Semaphore should bring wall time down
    to roughly N/concurrency * per_batch_latency."""
    import asyncio
    import time as time_mod
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="text/plain",
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(8 * 50)  # 8 batches at BATCH_SIZE=50
    ]

    async def slow_chat(_system, _user, temperature=0.1):
        await asyncio.sleep(0.1)  # simulate LLM latency
        return "[]"  # empty response — parse_preset_output_raw handles it

    client = MagicMock()
    client.chat = slow_chat

    with patch("gdrive_organizer.ai.planner.parse_preset_output_raw", return_value=[]):
        start = time_mod.perf_counter()
        result = asyncio.run(
            planner._classify_with_preset(
                client,
                files,
                preset_prompt="prompt",
                snippets={},
                junk_ids=set(),
                existing_folders=[],
            )
        )
        elapsed = time_mod.perf_counter() - start

    assert result == []
    # 8 batches × 100ms serial = 800ms; in parallel ≈ 100-200ms.
    # Generous threshold for CI scheduling jitter.
    assert elapsed < 0.4, f"Expected parallel execution, got {elapsed:.2f}s"


def test_classify_with_preset_propagates_first_failure():
    """gather should raise the first exception (and cancel the rest),
    matching the old sequential abort-on-first behavior."""
    import asyncio
    from unittest.mock import MagicMock

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.classifier import LLMError

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="text/plain",
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(100)  # 2 batches
    ]

    call_count = {"n": 0}

    async def flaky_chat(_system, _user, temperature=0.1):
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise LLMError("simulated rate limit exhaustion")
        await asyncio.sleep(10)  # would be slow; should be cancelled
        return "[]"

    client = MagicMock()
    client.chat = flaky_chat

    import pytest

    with pytest.raises(LLMError, match="simulated rate limit"):
        asyncio.run(
            planner._classify_with_preset(
                client,
                files,
                preset_prompt="prompt",
                snippets={},
                junk_ids=set(),
                existing_folders=[],
            )
        )


# --- ownedByMe filter (#J1 from Stage-1 dogfood) ---


def test_generate_plan_excludes_unowned_files():
    """Files where ownedByMe=False (shared from someone else) cannot be moved
    or have their description updated by us. The planner must drop them so
    apply doesn't generate guaranteed-fail ops."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.validator import ValidationResult
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 2, tzinfo=UTC),
        files=[
            DriveFile(
                id="mine",
                name="my doc",
                mime_type="text/plain",
                path="my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
            DriveFile(
                id="shared",
                name="someones-pdf.pdf",
                mime_type="application/pdf",
                path="someones-pdf.pdf",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=False,  # shared from someone else
            ),
            DriveFile(
                id="unknown",
                name="legacy.txt",
                mime_type="text/plain",
                path="legacy.txt",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=None,  # scanner couldn't determine — keep
            ),
        ],
    )

    classify_mock = AsyncMock(return_value=[])
    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    # The classifier should have received only the owned + unknown files,
    # never the explicitly-unowned one.
    files_passed = classify_mock.call_args.args[1]
    file_ids = {f.id for f in files_passed}
    assert "mine" in file_ids
    assert "unknown" in file_ids  # None is treated as "maybe owned" → keep
    assert "shared" not in file_ids  # explicit False → drop


# --- shortcut filter (#J2 from Stage-2 dogfood) ---


def test_generate_plan_excludes_shortcut_files():
    """Shortcut files (mimeType=application/vnd.google-apps.shortcut) must
    not feed back into the planner — using them as a source produces a
    shortcut-of-shortcut chain that Drive rejects.

    Real-world trigger: after Stage 1 created shortcuts in 부트캠프/, the
    next snapshot included those shortcuts; the next plan tried to
    create_shortcut on them again. 4 of 4 Stage-2 failures.
    """
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.validator import ValidationResult
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 2, tzinfo=UTC),
        files=[
            DriveFile(
                id="real",
                name="my doc",
                mime_type="text/plain",
                path="my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
            DriveFile(
                id="shortcut1",
                name="my doc (shortcut)",
                mime_type="application/vnd.google-apps.shortcut",
                path="부트캠프/my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
        ],
    )

    classify_mock = AsyncMock(return_value=[])
    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    files_passed = classify_mock.call_args.args[1]
    file_ids = {f.id for f in files_passed}
    assert "real" in file_ids
    assert "shortcut1" not in file_ids


# --- conflict suffix resolution (#J4 from Stage-5 dogfood) ---


def test_resolve_conflicts_appends_suffix_instead_of_dropping():
    """When two ops land at the same destination, the later one should be
    renamed with a ' (2)' suffix — not dropped. Dropping leaves duplicate
    files orphaned at root forever (Stage-5 dogfood: 6 files survived 4
    stages by being silently dropped from every subsequent classify)."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id="a",
            current_name="report",
            current_path="report",
            operation=OperationType.MOVE,
            new_path="보관함/2025/12/report",
        ),
        PlanOperation(
            file_id="b",  # different file, same target name
            current_name="report",
            current_path="report",
            operation=OperationType.MOVE,
            new_path="보관함/2025/12/report",
        ),
    ]
    renames = resolve_conflicts(ops)
    assert renames == 1
    assert ops[0].new_path == "보관함/2025/12/report"  # first wins
    assert ops[1].new_path == "보관함/2025/12/report (2)"  # second renamed
    assert ops[1].new_name == "report (2)"


def test_resolve_conflicts_handles_extension():
    """Suffix must go before the file extension, not after."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id="a",
            current_name="data.csv",
            current_path="data.csv",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/data.csv",
        ),
        PlanOperation(
            file_id="b",
            current_name="data.csv",
            current_path="data.csv",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/data.csv",
        ),
    ]
    resolve_conflicts(ops)
    assert ops[1].new_path == "보관함/2025/06/data (2).csv"


def test_resolve_conflicts_chains_more_than_two():
    """3 colliding ops should become name, name (2), name (3)."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id=str(i),
            current_name="x",
            current_path="x",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/x",
        )
        for i in range(3)
    ]
    resolve_conflicts(ops)
    assert ops[0].new_path == "보관함/2025/06/x"
    assert ops[1].new_path == "보관함/2025/06/x (2)"
    assert ops[2].new_path == "보관함/2025/06/x (3)"


# --- No-op detection (P4) ---


class TestNoOpDetection:
    """Re-classify on an already-organized Drive must not regenerate every op
    that previously ran. Otherwise apply burns API quota AND duplicate
    shortcuts pile up in the same folders."""

    def test_move_skipped_when_already_at_destination(self):
        """File whose parent already matches the LLM's move_to target →
        no MOVE op should be emitted."""
        # Existing folder "보관함/2026/04" with id "real_folder_id"
        f = DriveFile(
            id="1",
            name="report.txt",
            mime_type="text/plain",
            path="보관함/2026/04/report.txt",
            parents=["real_folder_id"],
        )
        items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
        existing = {"보관함/2026/04": "real_folder_id"}
        ops = _response_to_operations(items, {"1": f}, existing)
        assert not [o for o in ops if o.operation == OperationType.MOVE], (
            "expected no MOVE — file is already at destination"
        )

    def test_move_emitted_when_parent_differs(self):
        """File at a different parent → MOVE op IS emitted."""
        f = DriveFile(
            id="1",
            name="report.txt",
            mime_type="text/plain",
            path="other/report.txt",
            parents=["other_folder_id"],
            owned_by_me=True,
        )
        items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
        existing = {"보관함/2026/04": "real_folder_id"}
        ops = _response_to_operations(items, {"1": f}, existing)
        moves = [o for o in ops if o.operation == OperationType.MOVE]
        assert len(moves) == 1
        assert moves[0].new_parent_id == "real_folder_id"

    def test_description_skipped_when_unchanged(self):
        f = DriveFile(
            id="1",
            name="report.txt",
            mime_type="text/plain",
            parents=["real_parent"],
            owned_by_me=True,
            description="AI 리서치 문서",
        )
        items = [LLMResponseItem(file_id="1", new_description="AI 리서치 문서")]
        ops = _response_to_operations(items, {"1": f}, set())
        assert not [o for o in ops if o.operation == OperationType.UPDATE_DESCRIPTION]

    def test_description_skipped_when_only_whitespace_diff(self):
        """Pure whitespace differences should not trigger a rewrite."""
        f = DriveFile(
            id="1",
            name="report.txt",
            mime_type="text/plain",
            parents=["real_parent"],
            owned_by_me=True,
            description="  AI 리서치 문서  ",
        )
        items = [LLMResponseItem(file_id="1", new_description="AI 리서치 문서")]
        ops = _response_to_operations(items, {"1": f}, set())
        assert not [o for o in ops if o.operation == OperationType.UPDATE_DESCRIPTION]

    def test_description_emitted_when_text_differs(self):
        f = DriveFile(
            id="1",
            name="report.txt",
            mime_type="text/plain",
            parents=["real_parent"],
            owned_by_me=True,
            description="기존 설명",
        )
        items = [LLMResponseItem(file_id="1", new_description="새 설명 키워드 포함")]
        ops = _response_to_operations(items, {"1": f}, set())
        desc_ops = [o for o in ops if o.operation == OperationType.UPDATE_DESCRIPTION]
        assert len(desc_ops) == 1

    def test_shortcut_skipped_when_already_exists(self):
        """A shortcut with the same target+parent is already in the
        snapshot → no CREATE_SHORTCUT, otherwise we'd duplicate it."""
        target = DriveFile(
            id="t1",
            name="research.txt",
            mime_type="text/plain",
        )
        existing_shortcut = DriveFile(
            id="s1",
            name="research.txt",
            mime_type="application/vnd.google-apps.shortcut",
            shortcut_target_id="t1",
            parents=["topic_folder_id"],
        )
        files = {"t1": target, "s1": existing_shortcut}
        items = [LLMResponseItem(file_id="t1", shortcuts=["태그/AI"])]
        existing_folders = {"태그/AI": "topic_folder_id"}
        ops = _response_to_operations(items, files, existing_folders)
        sc_ops = [o for o in ops if o.operation == OperationType.CREATE_SHORTCUT]
        assert not sc_ops, "expected no CREATE_SHORTCUT — already exists in this folder"

    def test_llm_new_name_emits_rename_and_move(self):
        """When LLM proposes new_name AND the file isn't yet at destination,
        emit a single RENAME_AND_MOVE op (not separate RENAME + MOVE)."""
        f = _make_file("1", "Untitled document.gdoc", path="other/Untitled document.gdoc")
        f.parents = ["other_parent"]
        items = [
            LLMResponseItem(
                file_id="1",
                move_to="🪄 AI 정리/2025/03",
                new_name="디자인-리뷰-노트.gdoc",
            )
        ]
        existing = {"🪄 AI 정리/2025/03": "real_dest"}
        ops = _response_to_operations(items, {"1": f}, existing)
        ram = [o for o in ops if o.operation == OperationType.RENAME_AND_MOVE]
        assert len(ram) == 1
        assert ram[0].new_name == "디자인-리뷰-노트.gdoc"
        assert ram[0].new_parent_id == "real_dest"
        assert ram[0].new_path == "🪄 AI 정리/2025/03/디자인-리뷰-노트.gdoc"

    def test_llm_new_name_emits_rename_only_when_already_at_destination(self):
        """File already at destination + new_name proposed → RENAME only."""
        f = DriveFile(
            id="1",
            name="Untitled document.gdoc",
            mime_type="application/vnd.google-apps.document",
            path="🪄 AI 정리/2025/03/Untitled document.gdoc",
            parents=["dest_id"],
            owned_by_me=True,
        )
        items = [
            LLMResponseItem(
                file_id="1",
                move_to="🪄 AI 정리/2025/03",
                new_name="디자인-리뷰-노트.gdoc",
            )
        ]
        existing = {"🪄 AI 정리/2025/03": "dest_id"}
        ops = _response_to_operations(items, {"1": f}, existing)
        renames = [o for o in ops if o.operation == OperationType.RENAME]
        assert len(renames) == 1
        assert renames[0].new_name == "디자인-리뷰-노트.gdoc"
        assert "🪄 AI 정리/2025/03/디자인-리뷰-노트.gdoc" == renames[0].new_path
        # Must NOT also emit a redundant MOVE.
        assert not [o for o in ops if o.operation == OperationType.MOVE]

    def test_llm_new_name_skipped_when_identical_to_current(self):
        """LLM returning the current name verbatim must not produce a RENAME."""
        f = _make_file("1", "report.pdf")
        items = [LLMResponseItem(file_id="1", move_to="🪄 AI 정리/2025/03", new_name="report.pdf")]
        ops = _response_to_operations(items, {"1": f}, set())
        rename_kinds = (OperationType.RENAME, OperationType.RENAME_AND_MOVE)
        assert not [o for o in ops if o.operation in rename_kinds]

    def test_orphan_file_skips_all_ops(self):
        """True orphan: parents=[] AND I own it → still excluded (cannot
        write through trashed-ancestor path)."""
        orphan = DriveFile(
            id="orphan1",
            name="LG U+ Why Not SW Camp 6기 블로그",
            mime_type="text/plain",
            parents=[],
            owned_by_me=True,
        )
        items = [
            LLMResponseItem(
                file_id="orphan1",
                move_to="🪄 AI 정리/보관함/2025/05",
                shortcuts=["태그/AI"],
                new_description="블로그 회고",
            )
        ]
        ops = _response_to_operations(items, {"orphan1": orphan}, set())
        assert not [
            o for o in ops if o.operation in (OperationType.MOVE, OperationType.CREATE_SHORTCUT, OperationType.UPDATE_DESCRIPTION)
        ], "expected no ops on orphan file"

    def test_external_file_skips_all_ops(self):
        """External: somebody else owns it. Drive denies our writes
        regardless of where it sits in the tree, so the planner must
        skip ALL ops just like for true orphans. This previously slipped
        through and produced 5 of 6 b10-cycle apply failures (jhjung's
        자료실 subtree)."""
        ext = DriveFile(
            id="ext1",
            name="fluent_python.pdf",
            mime_type="application/pdf",
            parents=["jhjung_folder_id"],
            owned_by_me=False,  # owned by jhjung@dschloe.com
        )
        items = [
            LLMResponseItem(
                file_id="ext1",
                move_to="🪄 AI 정리/보관함/2025/05",
                shortcuts=["Sec_Brain/이론 학습"],
                new_description="파이썬 심화",
            )
        ]
        ops = _response_to_operations(items, {"ext1": ext}, set())
        assert not [
            o for o in ops if o.operation in (OperationType.MOVE, OperationType.CREATE_SHORTCUT, OperationType.UPDATE_DESCRIPTION)
        ], "expected no ops on external file"

    def test_external_folder_excluded_from_existing_index(self):
        """An external folder (someone shared it with us) appears in the
        snapshot but Drive denies addChildren — the LLM must not see it
        as a shortcut destination. Same treatment as orphan folders."""
        from gdrive_organizer.ai.planner import _get_existing_folder_index
        from gdrive_organizer.models import Snapshot, SnapshotStats

        snap = Snapshot(
            scanned_at=datetime(2026, 5, 8, tzinfo=UTC),
            files=[
                DriveFile(
                    id="mine",
                    name="Sec_Brain",
                    mime_type="application/vnd.google-apps.folder",
                    path="Sec_Brain",
                    parents=["root_id"],
                    owned_by_me=True,
                ),
                DriveFile(
                    id="theirs",
                    name="자료실",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실",
                    parents=["root_id"],  # has parent — NOT a J6 orphan
                    owned_by_me=False,    # but external — Drive 403s our writes
                ),
                DriveFile(
                    id="theirs_child",
                    name="Book",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실/Book",
                    parents=["theirs"],
                    owned_by_me=False,
                ),
            ],
            stats=SnapshotStats(total_folders=3),
        )
        idx = _get_existing_folder_index(snap)
        assert "Sec_Brain" in idx
        assert "자료실" not in idx, "external folder must be excluded"
        assert "자료실/Book" not in idx, "external descendant too"

    def test_orphan_subtree_descendants_excluded(self):
        """Children of an orphan folder are also unreachable via Drive's
        write API (403 on writes that touch trashed-ancestor paths).
        Folder `Book` has `parents=[자료실_id]` — non-empty — but its
        ancestor 자료실 is orphan, so Book must also be excluded from
        existing_folders / existing_folder_index."""
        from gdrive_organizer.ai.planner import _get_existing_folder_index
        from gdrive_organizer.models import Snapshot, SnapshotStats

        # All folders are user-owned; only the orphan-status (parents=[])
        # should drive exclusion here, not external ownership.
        snap = Snapshot(
            scanned_at=datetime(2026, 5, 7, tzinfo=UTC),
            files=[
                DriveFile(
                    id="alive",
                    name="alive_folder",
                    mime_type="application/vnd.google-apps.folder",
                    path="alive_folder",
                    parents=["root_id"],
                    owned_by_me=True,
                ),
                DriveFile(
                    id="orphan_root",
                    name="자료실",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실",
                    parents=[],  # J6-reparented orphan root
                    owned_by_me=True,
                ),
                DriveFile(
                    id="orphan_child",
                    name="Book",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실/Book",
                    parents=["orphan_root"],  # parent IS in scan, but it's orphan
                    owned_by_me=True,
                ),
                DriveFile(
                    id="orphan_grandchild",
                    name="vol2",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실/Book/vol2",
                    parents=["orphan_child"],
                    owned_by_me=True,
                ),
            ],
            stats=SnapshotStats(total_folders=4),
        )
        idx = _get_existing_folder_index(snap)
        assert "alive_folder" in idx
        assert "자료실" not in idx
        assert "자료실/Book" not in idx, "child of orphan must also be excluded"
        assert "자료실/Book/vol2" not in idx, "grandchild too"

    def test_orphan_folder_excluded_from_existing_index(self):
        """Orphan folders must not appear in `existing_folders` — otherwise
        the LLM proposes shortcut paths that resolve to orphan folder IDs,
        and apply 403s. Verified via the public extractor functions."""
        from gdrive_organizer.ai.planner import (
            _get_existing_folder_index,
            _get_existing_folders,
        )
        from gdrive_organizer.models import Snapshot, SnapshotStats

        snap = Snapshot(
            scanned_at=datetime(2026, 5, 6, tzinfo=UTC),
            files=[
                DriveFile(
                    id="alive",
                    name="alive_folder",
                    mime_type="application/vnd.google-apps.folder",
                    path="alive_folder",
                    parents=["root_id"],
                    owned_by_me=True,
                ),
                DriveFile(
                    id="orphan",
                    name="자료실",
                    mime_type="application/vnd.google-apps.folder",
                    path="자료실",
                    parents=[],  # orphan
                    owned_by_me=True,
                ),
            ],
            stats=SnapshotStats(total_folders=2),
        )
        paths = _get_existing_folders(snap)
        assert "alive_folder" in paths
        assert "자료실" not in paths

        idx = _get_existing_folder_index(snap)
        assert "alive_folder" in idx
        assert "자료실" not in idx

    def test_shortcut_emitted_when_target_in_different_folder(self):
        """Existing shortcut in a different folder → still create the new one."""
        target = DriveFile(
            id="t1",
            name="r.txt",
            mime_type="text/plain",
            parents=["real_parent"],
            owned_by_me=True,
        )
        existing_shortcut = DriveFile(
            id="s1",
            name="r.txt",
            mime_type="application/vnd.google-apps.shortcut",
            shortcut_target_id="t1",
            parents=["different_folder"],
            owned_by_me=True,
        )
        files = {"t1": target, "s1": existing_shortcut}
        items = [LLMResponseItem(file_id="t1", shortcuts=["태그/AI"])]
        existing_folders = {"태그/AI": "topic_folder_id"}
        ops = _response_to_operations(items, files, existing_folders)
        sc_ops = [o for o in ops if o.operation == OperationType.CREATE_SHORTCUT]
        assert len(sc_ops) == 1


# --- Duplicates cleanup (#5) ---


class TestDuplicatesPlan:
    """generate_duplicates_plan keeps the newest in each md5 group and
    trashes the rest. Same safety rails as classify (owned, non-empty,
    has md5, has parent)."""

    @staticmethod
    def _build_config(tmp_path):
        from gdrive_organizer.config import Config
        return Config(data_dir=tmp_path, config_dir=tmp_path / "config")

    def _snap(self, files: list[DriveFile]) -> "Snapshot":
        from gdrive_organizer.models import Snapshot, SnapshotStats
        return Snapshot(
            scanned_at=datetime(2026, 5, 9, tzinfo=UTC),
            files=files,
            stats=SnapshotStats(total_files=len(files)),
        )

    def _file(self, fid, md5, modified, size=1024, owned=True, parent="real_parent"):
        return DriveFile(
            id=fid,
            name=f"f-{fid}.pdf",
            mime_type="application/pdf",
            md5_checksum=md5,
            size=size,
            modified_time=modified,
            owned_by_me=owned,
            parents=[parent] if parent else [],
        )

    def test_keeps_newest_trashes_others(self, tmp_path):
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", "abc", datetime(2024, 1, 1, tzinfo=UTC), size=5_000_000),
            self._file("b", "abc", datetime(2025, 1, 1, tzinfo=UTC), size=5_000_000),  # newest
            self._file("c", "abc", datetime(2023, 1, 1, tzinfo=UTC), size=5_000_000),
        ])
        plan = generate_duplicates_plan(snap, config)
        ops = plan.operations
        assert len(ops) == 2  # 'b' kept, 'a' and 'c' trashed
        trashed_ids = {op.file_id for op in ops}
        assert trashed_ids == {"a", "c"}
        for op in ops:
            assert op.operation == OperationType.TRASH

    def test_skips_empty_files(self, tmp_path):
        """Empty (size=0) files share the empty-content md5 — not real
        duplicates worth trashing. Skip the whole group."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", "empty_md5", datetime(2024, 1, 1, tzinfo=UTC), size=0),
            self._file("b", "empty_md5", datetime(2025, 1, 1, tzinfo=UTC), size=0),
        ])
        plan = generate_duplicates_plan(snap, config)
        assert plan.operations == []

    def test_skips_external_files(self, tmp_path):
        """Don't trash files we don't own — Drive denies the write
        AND it's the wrong thing to do conceptually."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", "abc", datetime(2024, 1, 1, tzinfo=UTC), owned=False),
            self._file("b", "abc", datetime(2025, 1, 1, tzinfo=UTC), owned=False),
        ])
        plan = generate_duplicates_plan(snap, config)
        assert plan.operations == []

    def test_skips_orphans(self, tmp_path):
        """Orphan files (parent in trash) — Drive denies our writes."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", "abc", datetime(2024, 1, 1, tzinfo=UTC), parent=None),
            self._file("b", "abc", datetime(2025, 1, 1, tzinfo=UTC), parent=None),
        ])
        plan = generate_duplicates_plan(snap, config)
        assert plan.operations == []

    def test_skips_files_without_md5(self, tmp_path):
        """Workspace docs and some other types lack md5; can't dedupe."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", None, datetime(2024, 1, 1, tzinfo=UTC)),
            self._file("b", None, datetime(2025, 1, 1, tzinfo=UTC)),
        ])
        plan = generate_duplicates_plan(snap, config)
        assert plan.operations == []

    def test_singleton_groups_skipped(self, tmp_path):
        """Files with unique md5 (count=1 in their group) are not duplicates."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        snap = self._snap([
            self._file("a", "unique1", datetime(2024, 1, 1, tzinfo=UTC)),
            self._file("b", "unique2", datetime(2025, 1, 1, tzinfo=UTC)),
        ])
        plan = generate_duplicates_plan(snap, config)
        assert plan.operations == []

    def test_keeper_is_deterministic_when_times_match(self, tmp_path):
        """Same modified_time → fall back to id (deterministic across runs)."""
        from gdrive_organizer.ai.planner import generate_duplicates_plan

        config = self._build_config(tmp_path)
        same_time = datetime(2025, 1, 1, tzinfo=UTC)
        snap = self._snap([
            self._file("aaa", "abc", same_time),
            self._file("zzz", "abc", same_time),  # higher id → kept
        ])
        plan = generate_duplicates_plan(snap, config)
        assert len(plan.operations) == 1
        assert plan.operations[0].file_id == "aaa"  # lower id → trashed
