"""Tests for failure transparency — scanner error handling, LLM client error paths."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gdrive_organizer.ai.classifier import GrokClient, LLMError

# --- B1: Scanner error narrowing ---


class TestScannerErrorHandling:
    def test_http_error_caught_gracefully(self):
        """HttpError from permissions fetch should be caught, not re-raised."""
        from googleapiclient.errors import HttpError

        from gdrive_organizer.scanner.crawler import enrich_permissions_for_shared

        service = MagicMock()
        http_err = HttpError(MagicMock(status=403), b"forbidden")
        service.permissions.return_value.list.return_value.execute.side_effect = http_err

        files = [{"id": "f1", "ownedByMe": True, "shared": True}]
        # Should NOT raise — HttpError is caught gracefully
        count = enrich_permissions_for_shared(service, files, delay=0)
        assert count == 0
        assert files[0]["permissions"] == []

    def test_unexpected_error_propagates(self):
        """Non-HttpError (e.g. programming bug) should propagate, not be swallowed."""
        from gdrive_organizer.scanner.crawler import enrich_permissions_for_shared

        service = MagicMock()
        service.permissions.return_value.list.return_value.execute.side_effect = RuntimeError(
            "unexpected bug"
        )

        files = [{"id": "f1", "ownedByMe": True, "shared": True}]
        with pytest.raises(RuntimeError, match="unexpected bug"):
            enrich_permissions_for_shared(service, files, delay=0)

    def test_revision_http_error_caught(self):
        """HttpError from revision fetch should be caught gracefully."""
        from googleapiclient.errors import HttpError

        from gdrive_organizer.scanner.crawler import enrich_revisions

        service = MagicMock()
        http_err = HttpError(MagicMock(status=404), b"not found")
        service.revisions.return_value.list.return_value.execute.side_effect = http_err

        files = [{"id": "f1", "mimeType": "text/plain"}]
        # Should NOT raise
        enrich_revisions(service, files, max_files=1, delay=0)
        assert files[0]["revisionCount"] == 0

    def test_revision_unexpected_error_propagates(self):
        """Non-HttpError in revision fetch should propagate."""
        from gdrive_organizer.scanner.crawler import enrich_revisions

        service = MagicMock()
        service.revisions.return_value.list.return_value.execute.side_effect = TypeError("bug")

        files = [{"id": "f1", "mimeType": "text/plain"}]
        with pytest.raises(TypeError, match="bug"):
            enrich_revisions(service, files, max_files=1, delay=0)


# --- B2: LLM client error transparency ---


class TestLLMClientErrors:
    def test_non_rate_limit_error_raises_llm_error(self):
        """Non-rate-limit exceptions must raise LLMError, not return ''."""
        with patch.object(GrokClient, "__init__", lambda self, *a, **kw: None):
            client = GrokClient.__new__(GrokClient)
            client.model = "test"
            client.client = MagicMock()
            client._semaphore = asyncio.Semaphore(1)

            # Mock create to raise a generic error
            mock_create = AsyncMock(side_effect=ConnectionError("network down"))
            client.client.chat.completions.create = mock_create

            with pytest.raises(LLMError, match="LLM API call failed"):
                asyncio.run(client.chat("system", "user"))

    def test_rate_limit_is_retried_then_raised(self):
        """RateLimitError should be retried, then raised (not swallowed)."""
        from openai import RateLimitError

        with patch.object(GrokClient, "__init__", lambda self, *a, **kw: None):
            client = GrokClient.__new__(GrokClient)
            client.model = "test"
            client.client = MagicMock()
            client._semaphore = asyncio.Semaphore(1)

            mock_resp = MagicMock()
            mock_resp.status_code = 429
            mock_resp.headers = {}
            rate_err = RateLimitError(
                message="rate limited",
                response=mock_resp,
                body=None,
            )
            client.client.chat.completions.create = AsyncMock(side_effect=rate_err)

            with pytest.raises(RateLimitError):
                asyncio.run(client._call_with_retry("sys", "usr", 0.1, max_retries=2))

    def test_llm_error_is_importable(self):
        """LLMError should be importable for caller-side handling."""
        from gdrive_organizer.ai.classifier import LLMError

        assert issubclass(LLMError, Exception)
        err = LLMError("test")
        assert str(err) == "test"


# --- Apply-failure transparency: rollback log + CLI digest ---


class TestApplyFailureVisibility:
    """Failed ops must record their error string in the rollback log
    AND the CLI must surface the first ~10 errors as a Rich table.
    Pre-task-A behaviour was status:"failed" with no error message,
    forcing the user to grep API logs.
    """

    @staticmethod
    def _build_runner(tmp_path):
        from gdrive_organizer.config import Config
        from gdrive_organizer.executor.runner import PlanRunner

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        # Mock files().get() so the trashed-parent guard sees a non-trashed
        # destination — the freshness guard is bypassed via skip_freshness_check.
        service = MagicMock()
        service.files().get().execute.return_value = {
            "id": "x",
            "name": "x",
            "trashed": False,
        }
        return PlanRunner(service, config), config

    def test_rollback_log_records_error_for_failed_batch_op(self, tmp_path):
        """When the batch callback reports an exception, the rollback log
        entry for that op must include the error string."""
        import json

        from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation

        runner, _config = self._build_runner(tmp_path)
        op = PlanOperation(
            file_id="file-A",
            current_name="a.txt",
            current_path="/old/a.txt",
            operation=OperationType.MOVE,
            new_parent_id="dest",
            current_parent_id="src",
        )
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=[op])

        with patch("gdrive_organizer.executor.runner.execute_batch") as mock_batch:

            def fake_batch(_service, batch_ops, callback):
                for o in batch_ops:
                    callback(
                        f"{o.file_id}:{o.operation.value}",
                        None,
                        RuntimeError("simulated drive 403"),
                    )

            mock_batch.side_effect = fake_batch
            result = runner.execute(plan, skip_freshness_check=True)

        assert result.failure_count == 1
        assert result.errors and "simulated drive 403" in result.errors[0]["error"]
        assert result.rollback_log_path is not None

        log = json.loads(result.rollback_log_path.read_text())
        entry = log["operations"][0]
        assert entry["status"] == "failed"
        assert "simulated drive 403" in entry["error"]

    def test_rollback_log_records_error_for_failed_folder_creation(self, tmp_path):
        """create_folder failures (Phase 1) must also persist their error."""
        import json

        from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation

        runner, _config = self._build_runner(tmp_path)
        op = PlanOperation(
            file_id="__new_folder_1",
            current_name="NewBucket",
            current_path="/NewBucket",
            operation=OperationType.CREATE_FOLDER,
            new_parent_id="root",
        )
        plan = ExecutionPlan(created_at="2026-04-11T00:00:00Z", operations=[op])

        with patch(
            "gdrive_organizer.executor.runner.create_folder",
            side_effect=RuntimeError("quota exceeded"),
        ):
            result = runner.execute(plan, skip_freshness_check=True)

        assert result.failure_count == 1
        log = json.loads(result.rollback_log_path.read_text())
        entry = log["operations"][0]
        assert entry["status"] == "failed"
        assert "quota exceeded" in entry["error"]

    def test_cli_failure_digest_renders_table_and_truncates(self, tmp_path):
        """_print_failure_digest writes a Rich table with first N rows + tail."""
        from rich.console import Console

        from gdrive_organizer import cli
        from gdrive_organizer.executor.runner import ExecutionResult

        result = ExecutionResult(
            success_count=0,
            failure_count=15,
            errors=[
                {"file_id": f"id-{i}", "error": f"err-{i}: " + ("x" * 200)}
                for i in range(15)
            ],
            rollback_log_path=tmp_path / "rollback-fake.json",
        )

        recorder = Console(record=True, width=200)
        original = cli.console
        cli.console = recorder
        try:
            cli._print_failure_digest(result, max_rows=10)
        finally:
            cli.console = original
        out = recorder.export_text()

        # First failures table appears with file IDs and at least one error
        assert "First failures" in out
        assert "id-0" in out
        assert "id-9" in out
        # Truncation marker for long error strings
        assert "..." in out
        # Tail count + rollback log hint
        assert "5 more" in out
        assert "rollback-fake.json" in out
