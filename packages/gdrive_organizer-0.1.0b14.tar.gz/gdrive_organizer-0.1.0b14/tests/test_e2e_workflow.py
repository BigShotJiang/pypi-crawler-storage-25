"""End-to-end workflow integration test.

Exercises: scan → classify (stubbed) → plan → apply --dry-run → rollback log
with fakes/stubs at the Drive API and LLM boundary.
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from gdrive_organizer.models import (
    ExecutionPlan,
    OperationType,
    PlanOperation,
)


class TestE2EWorkflow:
    """Full scan → classify → plan → dry-run → rollback proof."""

    def test_scan_classify_plan_dryrun_rollback(
        self,
        config,
        mock_drive_service,
        sample_raw_files,
    ):
        """Exercise the complete value path with stubs."""
        # ── Step 1: Scan ──
        with patch(
            "gdrive_organizer.scanner.crawler.scan_all_files",
            return_value=sample_raw_files,
        ):
            from gdrive_organizer.scanner.service import run_full_scan

            result = run_full_scan(
                mock_drive_service,
                config,
                apply_filters=False,
            )

        assert result.total_items == len(sample_raw_files)
        assert result.filepath.exists()

        # ── Step 2: Load the snapshot we just saved ──
        from gdrive_organizer.store.snapshot import load_snapshot

        snapshot = load_snapshot(config=config)
        assert len(snapshot.files) == len(sample_raw_files)
        assert snapshot.change_token == "token_123"

        # ── Step 3: Build a plan manually (simulating classify output) ──
        # In real flow, this comes from LLM → validator → _response_to_operations.
        # Here we construct PlanOperations directly to prove the pipeline works.
        plan = ExecutionPlan(
            created_at="2026-04-11T12:00:00Z",
            snapshot_ref=str(snapshot.scanned_at),
            preset_id="migration",
            operations=[
                PlanOperation(
                    file_id="__new_folder_0__",
                    current_name="보관함",
                    current_path="",
                    operation=OperationType.CREATE_FOLDER,
                    new_path="보관함",
                ),
                PlanOperation(
                    file_id="file1",
                    current_name="report.docx",
                    current_path="/Documents/report.docx",
                    operation=OperationType.MOVE,
                    new_parent_id="__new_folder_0__",
                    current_parent_id="folder1",
                    new_path="보관함/report.docx",
                    reason="시계열 정리",
                ),
                PlanOperation(
                    file_id="file3",
                    current_name="notes.txt",
                    current_path="/Documents/notes.txt",
                    operation=OperationType.TRASH,
                    reason="중복 파일",
                ),
            ],
        )

        # Save the plan
        plans_dir = config.data_dir / "plans"
        plans_dir.mkdir(parents=True, exist_ok=True)
        plan_path = plans_dir / "plan-2026-04-11T12-00-00.json"
        plan_path.write_text(plan.model_dump_json(indent=2))

        # ── Step 4: Dry-run apply ──
        from gdrive_organizer.executor.runner import PlanRunner

        runner = PlanRunner(mock_drive_service, config)
        dry_result = runner.execute(plan, dry_run=True)

        assert dry_result.success_count == 3  # all ops "previewed"
        assert dry_result.failure_count == 0

        # ── Step 5: Real apply with mock Drive ──
        def mock_create_folder(svc, name, parent=None, color_rgb=None):
            return {"id": f"real_{name}", "name": name}

        def mock_create_shortcut(svc, name, target, parent):
            return {"id": f"shortcut_{name}", "name": name}

        with (
            patch("gdrive_organizer.executor.runner.create_folder", side_effect=mock_create_folder),
            patch("gdrive_organizer.executor.runner.execute_batch") as mock_batch,
        ):
            # Simulate batch callback calling success for each op
            def fake_batch(svc, ops, callback):
                for op in ops:
                    callback(f"{op.file_id}:{op.operation.value}", {"id": op.file_id}, None)

            mock_batch.side_effect = fake_batch
            apply_result = runner.execute(plan, skip_freshness_check=True)

        assert apply_result.success_count >= 2  # folder + batch ops
        assert apply_result.rollback_log_path is not None
        assert apply_result.rollback_log_path.exists()

        # ── Step 6: Verify rollback log structure ──
        rollback_log = json.loads(apply_result.rollback_log_path.read_text())
        assert "id_mapping" in rollback_log
        assert "operations" in rollback_log
        assert rollback_log["id_mapping"].get("__new_folder_0__") == "real_보관함"

        # Verify the log has entries for our operations
        log_types = {e["type"] for e in rollback_log["operations"]}
        assert "create_folder" in log_types
        assert "move" in log_types or "trash" in log_types

        # ── Step 7: Build reverse operations and verify correctness ──
        reverse_ops = runner._build_reverse_operations(rollback_log)
        reverse_types = {op.operation for op in reverse_ops}

        # TRASH should become UNTRASH
        untrash_ops = [op for op in reverse_ops if op.operation == OperationType.UNTRASH]
        assert len(untrash_ops) >= 1

        # CREATE_FOLDER should become TRASH with real Drive ID
        folder_trash_ops = [
            op
            for op in reverse_ops
            if op.operation == OperationType.TRASH and "보관함" in (op.current_name or "")
        ]
        # Should use real ID, not placeholder
        for op in folder_trash_ops:
            assert not op.file_id.startswith("__new_folder_")


class TestE2EValidatorIntegration:
    """Prove the LLM validator is in the classify pipeline."""

    def test_validator_rejects_bad_items_in_pipeline(self, config):
        """Validator should quarantine invalid items during plan generation."""
        from gdrive_organizer.ai.validator import validate_llm_responses

        snapshot_ids = {"file1", "file2", "file3"}
        folder_paths = {"보관함/2026/04"}

        raw_items = [
            {"file_id": "file1", "move_to": "보관함/2026/04", "shortcuts": []},
            {"file_id": "NONEXISTENT", "move_to": "보관함/2026/04", "shortcuts": []},
            {"file_id": "file2", "move_to": "ignore previous/hack", "shortcuts": []},
        ]

        result = validate_llm_responses(raw_items, snapshot_ids, folder_paths)
        assert len(result.accepted) == 1  # only file1
        assert result.reject_count == 2


class TestChangeTokenRecovery:
    """Prove 410 Gone handling in incremental scan."""

    def test_410_raises_change_token_expired(self):
        from googleapiclient.errors import HttpError

        from gdrive_organizer.store.changelog import ChangeTokenExpiredError, poll_changes

        service = MagicMock()
        http_err = HttpError(MagicMock(status=410), b"Gone")
        service.changes.return_value.list.return_value.execute.side_effect = http_err

        with pytest.raises(ChangeTokenExpiredError, match="410 Gone"):
            poll_changes(service, "expired_token")

    def test_non_410_propagates(self):
        from googleapiclient.errors import HttpError

        from gdrive_organizer.store.changelog import poll_changes

        service = MagicMock()
        http_err = HttpError(MagicMock(status=500), b"Internal")
        service.changes.return_value.list.return_value.execute.side_effect = http_err

        with pytest.raises(HttpError):
            poll_changes(service, "some_token")


class TestSnapshotLocking:
    """Prove snapshot write lock exists and works."""

    def test_lock_file_created_during_save(self, config, sample_raw_files):
        """Save should create a lock file in the snapshots directory."""
        from gdrive_organizer.store.snapshot import save_snapshot

        path = save_snapshot(sample_raw_files, "tok", config)
        lock_path = config.data_dir / "snapshots" / "snapshot.lock"
        assert lock_path.exists()

    def test_save_succeeds_under_normal_conditions(self, config, sample_raw_files):
        """Basic save should work without locking issues."""
        from gdrive_organizer.store.snapshot import save_snapshot

        path = save_snapshot(sample_raw_files, "tok1", config)
        assert path.exists()
        # Second save should also work (lock released)
        path2 = save_snapshot(sample_raw_files, "tok2", config)
        assert path2.exists()
