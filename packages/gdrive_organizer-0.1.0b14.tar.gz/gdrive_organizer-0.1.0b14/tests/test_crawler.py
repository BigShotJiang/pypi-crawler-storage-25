"""Tests for the flat crawler."""

from unittest.mock import MagicMock

from gdrive_organizer.scanner.crawler import (
    get_start_page_token,
    reparent_orphans_with_trashed_parent,
    scan_all_files,
)


def _mock_service(pages: list[dict]):
    """Create a mock Drive service that returns paginated results."""
    service = MagicMock()
    files_resource = MagicMock()
    service.files.return_value = files_resource

    # Chain list → execute calls for each page
    responses = []
    for i, page in enumerate(pages):
        resp = {"files": page}
        if i < len(pages) - 1:
            resp["nextPageToken"] = f"token_{i + 1}"
        responses.append(resp)

    list_mock = MagicMock()
    list_mock.execute.return_value = responses[0]
    files_resource.list.return_value = list_mock

    # list_next: return None when there are no more pages
    call_count = {"n": 0}

    def list_next_fn(prev_request, prev_response):
        call_count["n"] += 1
        if call_count["n"] >= len(responses):
            return None
        next_mock = MagicMock()
        next_mock.execute.return_value = responses[call_count["n"]]
        return next_mock

    files_resource.list_next.side_effect = list_next_fn
    return service


def test_scan_single_page():
    files = [{"id": "1", "name": "a.txt"}, {"id": "2", "name": "b.txt"}]
    service = _mock_service([files])
    result = scan_all_files(service)
    assert len(result) == 2
    assert result[0]["name"] == "a.txt"


def test_scan_multiple_pages():
    page1 = [{"id": "1", "name": "a.txt"}]
    page2 = [{"id": "2", "name": "b.txt"}, {"id": "3", "name": "c.txt"}]
    service = _mock_service([page1, page2])
    result = scan_all_files(service)
    assert len(result) == 3


def test_scan_empty():
    service = _mock_service([[]])
    result = scan_all_files(service)
    assert result == []


def test_get_start_page_token():
    service = MagicMock()
    service.changes.return_value.getStartPageToken.return_value.execute.return_value = {
        "startPageToken": "12345"
    }
    token = get_start_page_token(service)
    assert token == "12345"


def test_minimal_fields_uses_slim_field_set():
    """--minimal-fields must request _MINIMAL_FILE_FIELDS so the API returns
    only the planner-essential subset. Verifies the wiring from CLI flag to
    files.list `fields` kwarg, which is the whole point of the flag."""
    from gdrive_organizer.scanner.crawler import _MINIMAL_FILE_FIELDS

    service = _mock_service([[]])
    scan_all_files(service, minimal_fields=True)

    files_resource = service.files.return_value
    list_kwargs = files_resource.list.call_args.kwargs
    expected = f"files({_MINIMAL_FILE_FIELDS}),nextPageToken"
    assert list_kwargs["fields"] == expected


def test_default_uses_full_field_set():
    """Sanity check: the default code path is unchanged — the rich field set
    still ships when --minimal-fields is off."""
    from gdrive_organizer.scanner.crawler import FIELDS

    service = _mock_service([[]])
    scan_all_files(service)
    list_kwargs = service.files.return_value.list.call_args.kwargs
    assert list_kwargs["fields"] == FIELDS


def _service_returning_parent_meta(meta_per_id: dict[str, dict]):
    """Build a mock service whose files().get(fileId=X) returns meta_per_id[X]."""
    service = MagicMock()

    def fake_get(fileId, fields, supportsAllDrives):  # noqa: ARG001, N803
        request = MagicMock()
        request.execute.return_value = meta_per_id[fileId]
        return request

    service.files().get.side_effect = fake_get
    return service


class TestReparentOrphansWithTrashedParent:
    """#J6 regression: a file whose direct parent is in trash must be
    surfaced at root so the next plan organizes it. Without this, Drive
    returns the file (own trashed=false) but it stays invisibly attached
    to its trashed parent — the user can't see it and the planner doesn't
    flag it as orphaned."""

    def test_orphan_with_trashed_parent_reparented_to_root(self):
        files = [
            {"id": "f1", "name": "doc.txt", "parents": ["trashed_folder"]},
            {"id": "f2", "name": "note.txt", "parents": ["trashed_folder"]},
        ]
        service = _service_returning_parent_meta(
            {
                "trashed_folder": {
                    "id": "trashed_folder",
                    "name": "보관함",
                    "trashed": True,
                }
            }
        )

        n = reparent_orphans_with_trashed_parent(service, files)
        assert n == 2
        assert files[0]["parents"] == []
        assert files[1]["parents"] == []

    def test_orphan_with_live_external_parent_left_alone(self):
        """If the orphan parent is NOT trashed (e.g. a shared-from-others
        folder we don't have visibility into), the guard must not touch
        the file — re-parenting an unowned-but-live file would change the
        user's perception of where it lives."""
        files = [
            {"id": "f1", "name": "doc.txt", "parents": ["external_folder"]},
        ]
        service = _service_returning_parent_meta(
            {
                "external_folder": {
                    "id": "external_folder",
                    "name": "Someone else's folder",
                    "trashed": False,
                }
            }
        )

        n = reparent_orphans_with_trashed_parent(service, files)
        assert n == 0
        assert files[0]["parents"] == ["external_folder"]

    def test_files_with_intra_set_parent_not_touched(self):
        """A file whose parent IS in the file set is not orphan — no API
        call is made and no re-parenting happens."""
        files = [
            {"id": "parent1", "name": "folder", "parents": []},
            {"id": "f1", "name": "doc.txt", "parents": ["parent1"]},
        ]
        service = MagicMock()

        n = reparent_orphans_with_trashed_parent(service, files)
        assert n == 0
        # Critical: the API was never queried for parent1
        service.files().get.assert_not_called()
        assert files[1]["parents"] == ["parent1"]

    def test_root_files_with_no_parent_ignored(self):
        files = [{"id": "f1", "name": "root_doc.txt", "parents": []}]
        service = MagicMock()
        n = reparent_orphans_with_trashed_parent(service, files)
        assert n == 0
        service.files().get.assert_not_called()
