# VibeCheck

**Catch AI deployment risks before you commit.**

VibeCheck is a CLI tool that runs a multi-stage LLM pipeline over your idea, PRD, and code — then tells you what can go wrong before it ships. It installs as a pre-commit hook so the check happens automatically on every commit.

Built for vibe coders who move fast and want a safety layer that doesn't require slowing down.

---

## What it does

You're building an AI-powered app. You have an idea doc, maybe a PRD, and some code. VibeCheck reads all three and surfaces:

- **System risks** — what can go wrong, with severity and specific remediations
- **Congruence gaps** — where your idea, spec, and implementation have drifted apart
- **Missing safeguards** — controls your system type typically needs but doesn't have
- **Risk score** — 0–10, with a verdict: proceed / review / block

Two evaluation layers run independently — risk identification and intent/design/build congruence — and are reported separately. Neither collapses into the other.

Every finding references specific details from your input. No generic advice.

---

## Quick start

```bash
# Clone and install
git clone https://github.com/your-username/vibecheck
cd vibecheck
python -m venv .venv && source .venv/bin/activate
pip install -e .

# Set your API key
cp .env.example .env
# Edit .env: OPENAI_API_KEY=your_key_here

# Run on an idea
vibecheck eval --idea "An AI agent that reviews pull requests and deploys to production without human approval"

```

---

## Example output

```
 LLM: openai / gpt-4o-mini
Inputs: idea, PRD, code

───────────────────────── VibeCheck — Pre-Deploy Scan ──────────────────────────
  Risk Score: HIGH  (7.5/10)
  Verdict: Review before shipping
  The system involves user-generated content that may contain sensitive 
information, and the reliance on external APIs introduces significant data 
exposure risks. Additionally, the potential for inaccurate outputs could 
undermine user trust.

⚠  System Risks
  🔴 HIGH — Data & Privacy Risk (conditional)
     Conditional risk: If user input (recipe text or URL) is sent to external 
APIs for parsing and calorie lookup without prior redaction, sensitive data may 
be exposed.
     ⤷ Assumes that user input may contain sensitive information that is not 
filtered before being sent to external APIs.
  🟡 MEDIUM — Output & Decision Risk
     The non-deterministic nature of LLM parsing may lead to inaccurate 
ingredient lists or calorie estimates, impacting user trust and decision-making.
  🟡 MEDIUM — Safeguards & Control Gaps
     Lack of a persistence mechanism for storing parsed recipe data may result 
in data loss or inconsistency for users.

🧠  Missing Safeguards
  · User-selected scope for data sent to external APIs to prevent exposure of 
sensitive information.
  · Redaction or masking of user input before sending to external APIs.
  · Traceability from user input to output to ensure accountability and 
transparency.

🔧  Quick Fixes
  → Implement a user input redaction mechanism to filter out sensitive 
information before API calls.
  → Add a persistence layer to store parsed recipe data reliably.
  → Incorporate user feedback mechanisms to improve the accuracy of parsing and 
estimation.

  · The analysis is limited by the absence of detailed implementation specifics,
particularly regarding data handling and storage.

─────────────────────────────────────────────
⛔  Commit blocked by VibeCheck
─────────────────────────────────────────────

VibeCheck flagged HIGH risk in your staged changes.
Review the findings above before shipping.

Your options:
  1. Address the flagged risks and commit again
  2. Bypass this check:  git commit --no-verify
  3. Re-run manually:    vibecheck eval --idea <path> --prd <path> --code <file>

To disable VibeCheck for this project, remove .git/hooks/pre-commit
─────────────────────────────────────────────

```

---

## Pre-commit hook

Install VibeCheck as a pre-commit hook in any project:

```bash
cd your-project
vibecheck init

```

This creates `.vibecheck.json` (points to your idea and PRD docs) and installs `.git/hooks/pre-commit`.

On every commit, VibeCheck bundles all staged code files and runs them through the pipeline alongside your idea and PRD. **HIGH verdict blocks the commit. MEDIUM/LOW warns and proceeds.**

```bash
# Re-run init after hook template updates — preserves existing config
vibecheck init --update

# Bypass if needed
git commit --no-verify

```

`.vibecheck.json` contains repo-relative paths and is safe to commit. Add it to `.gitignore` if you prefer not to track it.

---

## Evaluate from files

```bash
# Idea only
vibecheck eval --idea idea.md

# Idea + PRD
vibecheck eval --idea idea.md --prd prd.md

# Full stack
vibecheck eval --idea idea.md --prd prd.md --code app.py

# Raw JSON output
vibecheck eval --idea idea.md --json

# Show intermediate pipeline artifacts
vibecheck eval --idea idea.md --code app.py --show-intermediate

```

Any combination of inputs is valid. Stages only run for inputs provided.

---

## LLM providers

```bash
# Default: OpenAI (gpt-4o-mini)
OPENAI_API_KEY=your_key vibecheck eval --idea idea.md

# Local via Ollama
LLM_PROVIDER=ollama vibecheck eval --idea idea.md

```

Routing is configured in `app/llm_router.py`. Local (qwen2.5:3b), remote Ollama (qwen2.5:14b), and OpenAI are supported.

---

## Benchmarks

VibeCheck ships with a structured benchmark suite to validate pipeline behavior after prompt changes.

```bash
# Run baseline suite (5 cases)
vibecheck benchmark run

# Run congruence pack (5 cases)
vibecheck benchmark run --file benchmarks/congruence_v1/

# Run a specific case
vibecheck benchmark run --file benchmarks/baseline_structured/medical_notes_with_prd_and_code.json

# Run extended suite (high-stakes cases)
vibecheck benchmark run --file benchmarks/extended_structured/autonomous_pr_merge_and_deploy_idea_only.json

```

Current pass rate: **10/10** on baseline and congruence packs.

Benchmark cases are JSON files with structured assertions — score bands, required risk categories, substring checks, congruence list bounds. See `benchmarks/README.md` for the full format spec.

---

## Project structure

```
vibecheck/
├── app/
│   ├── cli.py              # Typer CLI — eval, benchmark, init
│   ├── pipeline.py         # 7-stage LLM pipeline
│   ├── llm_router.py       # Provider routing (OpenAI / Ollama)
│   ├── benchmark_runner.py # Structured benchmark evaluation
│   ├── models.py           # Pydantic schemas for all pipeline stages
│   └── pre_commit_hook_body.sh
├── prompts/                # Plain-text prompt templates — edit directly
│   ├── idea_extractor.txt
│   ├── prd_extractor.txt
│   ├── code_extractor.txt
│   ├── context_fusion.txt
│   ├── risk_evaluator.txt
│   ├── congruence_evaluator.txt
│   └── output_refiner.txt
├── benchmarks/
│   ├── baseline_structured/
│   ├── congruence_v1/
│   ├── extended_structured/
│   └── archive/
├── skills.md               # Architecture contract — pipeline roles and boundaries
└── pyproject.toml

```

---

## Pipeline stages


| Stage                | Input             | Output               |
| -------------------- | ----------------- | -------------------- |
| Idea Extractor       | Raw idea text     | `IdeaSchema`         |
| PRD Extractor        | PRD text          | `PRDSchema`          |
| Code Extractor       | Source code       | `CodeSchema`         |
| Context Fusion       | Available schemas | `UnifiedContext`     |
| Risk Evaluator       | `UnifiedContext`  | `RiskAnalysis`       |
| Congruence Evaluator | `UnifiedContext`  | `CongruenceAnalysis` |
| Output Refiner       | `FinalAnalysis`   | Rendered CLI output  |


---

## Risk categories


| Category                     | What it covers                                               |
| ---------------------------- | ------------------------------------------------------------ |
| Data & Privacy Risk          | PII exposure, third-party data sharing, retention, logging   |
| Output & Decision Risk       | Harmful or incorrect AI outputs affecting users              |
| Autonomy & Control Risk      | Automated actions, irreversible decisions, human-out-of-loop |
| Safeguards & Control Gaps    | Missing rate limits, output filters, audit logging           |
| Alignment & Consistency Risk | Gaps between system behavior and stated purpose              |
| Abuse & Misuse Risk          | Prompt injection, adversarial inputs, social engineering     |


---

## Design principles

- Every finding references specific input details — no generic advice
- Conditional risks (based on unconfirmed assumptions) are explicitly labeled
- Risk layer and congruence layer are strictly separate — neither substitutes for the other
- Prompt templates are plain `.txt` files — iterate on behavior without touching Python
- Any combination of idea / PRD / code is valid input

