"""VibeCheck application package — CLI, pipeline, and LLM routing."""
