"""
VibeCheck CLI — governance reasoning engine.
Command: vibecheck eval --idea "..." [--prd "..."] [--code "..."]
"""

import json
from pathlib import Path
from typing import Any, Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from . import benchmark_runner
from .llm_router import (
    RouterConfigurationError,
    get_resolved_routing_debug,
    get_route_startup_summary,
)
from .models import FinalAnalysis
from .pipeline import run_pipeline
from .utils import JSONParseError, read_input

app = typer.Typer(
    name="vibecheck",
    help="VibeCheck — pre-deployment governance reasoning engine.",
    add_completion=False,
    no_args_is_help=True,
)


@app.callback()
def _root() -> None:
    """VibeCheck — AI deployment governance review."""


benchmark_app = typer.Typer(help="Run JSON benchmark cases.")
app.add_typer(benchmark_app, name="benchmark")


console = Console()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SEV_COLOR = {"high": "red", "medium": "yellow", "low": "green"}
_SEV_ICON = {"high": "🔴", "medium": "🟡", "low": "🟢"}


def _score_label(score: float) -> str:
    return "HIGH" if score >= 7.0 else ("MEDIUM" if score >= 4.0 else "LOW")


def _score_color(score: float) -> str:
    return "red" if score >= 7.0 else ("yellow" if score >= 4.0 else "green")


def _print_json_panel(title: str, json_str: str, border: str = "blue") -> None:
    console.print(Panel(json_str, title=f"[bold]{title}[/bold]", border_style=border))


def _print_parse_error(exc: JSONParseError) -> None:
    console.print("\n[bold red]JSON Parse Error[/bold red]")
    console.print(
        "[dim]The model returned output that could not be parsed as JSON "
        "even after repair attempts.[/dim]\n"
    )
    console.print(
        Panel(
            exc.raw[:2000] + ("[dim]…truncated[/dim]" if len(exc.raw) > 2000 else ""),
            title="[bold red]Raw LLM Response[/bold red]",
            border_style="red",
        )
    )
    console.print(
        Panel(
            exc.candidate[:2000] + ("[dim]…truncated[/dim]" if len(exc.candidate) > 2000 else ""),
            title="[bold yellow]Extracted + Repaired Candidate[/bold yellow]",
            border_style="yellow",
        )
    )
    console.print(f"[bold red]Parse error:[/bold red] {exc.error}")


# ---------------------------------------------------------------------------
# Main renderer
# ---------------------------------------------------------------------------

_ARTIFACT_PHRASES = (
    "no prd provided",
    "no code provided",
    "prd not provided",
    "code not provided",
    "not provided",
    "not assessed",
    "not verified",
    "idea-only",
    "idea only",
)


def _is_artifact_note(text: str) -> bool:
    """Return True if the note is just a missing-artifact scope disclaimer."""
    lower = text.lower()
    return any(phrase in lower for phrase in _ARTIFACT_PHRASES)


# Congruence must be diagnostic (gaps/drift), not prescriptive — matches evaluator prompt.
_ADVICE_PHRASES_CONG = (
    "focus on",
    "define ",
    "defining ",
    "clarify ",
    "ensure ",
    "should ",
    "need to ",
    "must ",
    "recommend",
    "consider ",
    "document ",
    "it is important",
    "best practice",
    "clear design and implementation",
    "implementation and testing",
)


def _is_congruence_advice_line(text: str) -> bool:
    lower = text.lower().strip()
    return any(p in lower for p in _ADVICE_PHRASES_CONG)


_CONGRUENCE_FINDING_CAP = 2


def _print_final_analysis(analysis: FinalAnalysis) -> None:
    risk = analysis.risk_analysis
    cong = analysis.congruence_analysis
    score = risk.risk_score
    label = _score_label(score)
    color = _score_color(score)

    # ── Header ──
    console.print()
    console.print(Rule("[bold]VibeCheck — Pre-Deploy Scan[/bold]"))
    console.print(f"  [bold {color}]Risk Score: {label}[/bold {color}]  ({score:.1f}/10)")
    console.print(f"  [bold]Verdict:[/bold] {analysis.verdict}")
    if risk.risk_score_rationale:
        console.print(f"  [dim]{risk.risk_score_rationale}[/dim]")
    console.print()

    # ── System Risks ──
    if risk.system_risks:
        console.print("[bold yellow]⚠  System Risks[/bold yellow]")
        order = {"high": 0, "medium": 1, "low": 2}
        for r in sorted(risk.system_risks, key=lambda x: order[x.severity.value]):
            sev_color = _SEV_COLOR[r.severity.value]
            icon = _SEV_ICON[r.severity.value]
            cond_marker = " [dim italic](conditional)[/dim italic]" if r.conditional else ""
            console.print(
                f"  {icon} [bold {sev_color}]{r.severity.value.upper()}[/bold {sev_color}] "
                f"[dim]— {r.category.value}[/dim]{cond_marker}"
            )
            desc = r.description
            if r.conditional and "conditional" not in desc.lower():
                desc = f"Conditional — {desc}"
            console.print(f"     {desc}")
            if r.conditional and r.condition_note:
                console.print(f"     [dim italic]⤷ {r.condition_note}[/dim italic]")
        console.print()

    # ── Alignment & Congruence ──
    # Artifact scope notes (e.g. "No PRD provided") are secondary — shown dimly
    # only when substantive gap findings are also present.
    cong_items = [
        x
        for x in (
            cong.intent_design_gaps
            + cong.design_build_gaps
            + cong.intent_build_gaps
            + cong.drift_risks
        )
        if not _is_congruence_advice_line(x)
    ][: _CONGRUENCE_FINDING_CAP]
    scope_notes = [n for n in cong.congruence_notes if _is_artifact_note(n)]
    other_notes = [
        n
        for n in cong.congruence_notes
        if not _is_artifact_note(n) and not _is_congruence_advice_line(n)
    ]

    if cong_items:
        console.print("[bold cyan]🔍  Alignment & Congruence[/bold cyan]")
        for item in cong_items:
            console.print(f"  · {item}")
        for note in other_notes[:1]:
            console.print(f"  [dim]· {note}[/dim]")
        if scope_notes:
            console.print(f"  [dim]· {scope_notes[0]}[/dim]")
        console.print()
    elif other_notes:
        console.print("[bold cyan]🔍  Alignment & Congruence[/bold cyan]")
        for note in other_notes[:1]:
            console.print(f"  [dim]· {note}[/dim]")
        console.print()

    # ── Missing Safeguards ──
    if risk.missing_safeguards:
        console.print("[bold red]🧠  Missing Safeguards[/bold red]")
        for item in risk.missing_safeguards:
            console.print(f"  · {item}")
        console.print()

    # ── Quick Fixes ──
    if risk.quick_fixes:
        console.print("[bold green]🔧  Quick Fixes[/bold green]")
        for item in risk.quick_fixes:
            console.print(f"  → {item}")
        console.print()

    # ── Analysis notes (dim — secondary context, not primary findings) ──
    substantive_notes = [n for n in risk.analysis_notes if not _is_artifact_note(n)]
    if substantive_notes:
        for note in substantive_notes:
            console.print(f"[dim]  · {note}[/dim]")
        console.print()


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@app.command("eval")
def cmd_eval(
    idea: Optional[str] = typer.Option(
        None, "--idea",
        help="Idea / concept text, or path to a .txt file.",
    ),
    prd: Optional[str] = typer.Option(
        None, "--prd",
        help="Product Requirements Document text, or path to a .txt file.",
    ),
    code: Optional[str] = typer.Option(
        None, "--code",
        help="Source code text, or path to a source file.",
    ),
    model: Optional[str] = typer.Option(
        None, "--model",
        help="Model override for this run (applies to all stages; routing still selects endpoint).",
    ),
    show_intermediate: bool = typer.Option(
        False, "--show-intermediate", "-i",
        help="Print extracted schemas, unified context, and raw evaluation outputs before the final report.",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v",
        help="Print full LLM routing debug (resolved config, tag probes, task→route table).",
    ),
) -> None:
    """
    Run VibeCheck on any combination of idea, PRD, and code.

    At least one of --idea, --prd, or --code must be provided.
    Inputs may be raw text or paths to files.

    Examples:

      vibecheck eval --idea "App that summarizes emails using OpenAI"

      vibecheck eval --idea idea.txt --prd prd.txt --show-intermediate

      vibecheck eval --idea "..." --prd prd.txt --code main.py

      vibecheck eval --idea "..." --model <your-ollama-tag>

      vibecheck eval --idea "..." --verbose
    """
    if not any([idea, prd, code]):
        console.print(
            "[red]Error:[/red] At least one of [bold]--idea[/bold], "
            "[bold]--prd[/bold], or [bold]--code[/bold] must be provided."
        )
        raise typer.Exit(1)

    idea_text = read_input(idea) if idea else None
    prd_text = read_input(prd) if prd else None
    code_text = read_input(code) if code else None

    # Validate routing; verbose prints full debug (non-verbose: one dim summary line).
    try:
        rs = get_route_startup_summary(model_override=model, validate=True)
        loc, rem = rs["local"], rs["remote"]
        if verbose:
            dbg = get_resolved_routing_debug(model_override=model)
            console.print(Rule("[bold dim]Resolved LLM config (pre-validation)[/bold dim]"))
            console.print(f"[dim]{dbg['env_precedence_note']}[/dim]")
            console.print(f"[dim]Project root: {dbg['project_root']}[/dim]")
            console.print(f"[dim]dotenv file: {dbg['dotenv_file']}[/dim]")
            console.print("[dim]Process env (routing-related):[/dim]")
            for k, v in dbg["raw_process_env"].items():
                console.print(f"[dim]  {k}={v!r}[/dim]")
            console.print(
                "[bold]Local[/bold]  "
                f"provider={dbg['resolved_local_endpoint']['provider']!r}  "
                f"base_url={dbg['resolved_local_endpoint']['base_url']!r}  "
                f"model={dbg['resolved_local_endpoint']['model']!r}"
            )
            console.print(
                "[bold]Remote[/bold] "
                f"provider={dbg['resolved_remote_endpoint']['provider']!r}  "
                f"base_url={dbg['resolved_remote_endpoint']['base_url']!r}  "
                f"model={dbg['resolved_remote_endpoint']['model']!r}"
            )
            console.print("[bold]Ollama tag validation (GET)[/bold]")
            for slot in ("local", "remote"):
                p = dbg["ollama_tag_probes"][slot]
                console.print(
                    f"  [{slot}] {p['tags_validation_url']!r}  "
                    f"[dim](native root {p['ollama_native_root']!r} ← OpenAI base "
                    f"{p['resolved_base_url']!r}; model {p['resolved_model']!r})[/dim]"
                )

            console.print(Rule("[bold dim]LLM routing[/bold dim]"))
            console.print(
                "[bold]Local endpoint[/bold]  "
                f"[dim]provider=[/dim]{loc['provider']}  "
                f"[dim]base_url=[/dim]{loc['base_url']}  "
                f"[dim]default_model=[/dim]{loc['model']}"
            )
            console.print(
                "[bold]Remote endpoint[/bold] "
                f"[dim]provider=[/dim]{rem['provider']}  "
                f"[dim]base_url=[/dim]{rem['base_url']}  "
                f"[dim]default_model=[/dim]{rem['model']}"
            )
            if rs.get("force_all_remote"):
                console.print(
                    "[yellow]Note:[/yellow] [bold]VIBECHECK_FORCE_REMOTE_ALL[/bold] is set — "
                    "every task uses the [bold]remote[/bold] endpoint."
                )
            console.print("[bold]Task → route[/bold] [dim](endpoint / provider / base_url / model)[/dim]")
            for t in rs["tasks"]:
                d, e = t["default_endpoint"], t["effective_endpoint"]
                reroute = f"  [dim](default was {d})[/dim]" if d != e else ""
                console.print(
                    f"  · [cyan]{t['task_type']}[/cyan] → [bold]{e}[/bold]  "
                    f"| {t['provider']} | {t['base_url']} | [green]{t['model']}[/green]{reroute}"
                )
            if model:
                console.print(f"[dim]CLI --model override active for all stages: {model}[/dim]")
        else:
            if loc["provider"] == rem["provider"] and loc["model"] == rem["model"]:
                console.print(f"[dim]LLM: {loc['provider']} / {loc['model']}[/dim]")
            else:
                console.print(
                    f"[dim]LLM: local {loc['provider']} / {loc['model']} · "
                    f"remote {rem['provider']} / {rem['model']}[/dim]"
                )
    except RouterConfigurationError as exc:
        console.print("[bold red]LLM routing configuration error[/bold red]\n")
        console.print(str(exc))
        console.print(
            "\n[dim]Fix model names in .env (see `ollama list` on each machine), "
            "or set VIBECHECK_SKIP_OLLAMA_VALIDATION=1 only for offline/CI.[/dim]"
        )
        raise typer.Exit(1)
    except EnvironmentError as exc:
        console.print(f"[red]Configuration error:[/red] {exc}")
        raise typer.Exit(1)

    inputs_summary = ", ".join(
        label
        for label, val in [("idea", idea_text), ("PRD", prd_text), ("code", code_text)]
        if val
    )
    console.print(f"[dim]Inputs: {inputs_summary}[/dim]")

    try:
        with console.status("[bold green]Running pipeline…[/bold green]"):
            result = run_pipeline(
                idea_text=idea_text,
                prd_text=prd_text,
                code_text=code_text,
                model=model,
            )
    except JSONParseError as exc:
        _print_parse_error(exc)
        raise typer.Exit(1)
    except RouterConfigurationError as exc:
        console.print("[bold red]LLM routing configuration error[/bold red]\n")
        console.print(str(exc))
        raise typer.Exit(1)
    except EnvironmentError as exc:
        console.print(f"[red]Configuration error:[/red] {exc}")
        raise typer.Exit(1)
    except Exception as exc:
        console.print(f"[red]Pipeline error:[/red] {exc}")
        raise typer.Exit(1)

    if show_intermediate:
        step = 1
        if result.idea_schema:
            console.print(Rule(f"[bold dim]Step {step} — Extracted Idea Schema[/bold dim]"))
            _print_json_panel("Idea Schema", result.idea_schema.model_dump_json(indent=2), border="blue")
            step += 1

        if result.prd_schema:
            console.print(Rule(f"[bold dim]Step {step} — Extracted PRD Schema[/bold dim]"))
            _print_json_panel("PRD Schema", result.prd_schema.model_dump_json(indent=2), border="blue")
            step += 1

        if result.code_schema:
            console.print(Rule(f"[bold dim]Step {step} — Extracted Code Schema[/bold dim]"))
            _print_json_panel("Code Schema", result.code_schema.model_dump_json(indent=2), border="blue")
            step += 1

        if result.unified_context:
            console.print(Rule(f"[bold dim]Step {step} — Unified Context[/bold dim]"))
            _print_json_panel("Unified Context", result.unified_context.model_dump_json(indent=2), border="magenta")
            step += 1

        if result.risk_analysis:
            console.print(Rule(f"[bold dim]Step {step} — Raw Risk Analysis[/bold dim]"))
            _print_json_panel("Risk Analysis", result.risk_analysis.model_dump_json(indent=2), border="yellow")
            step += 1

        if result.congruence_analysis:
            console.print(Rule(f"[bold dim]Step {step} — Raw Congruence Analysis[/bold dim]"))
            _print_json_panel("Congruence Analysis", result.congruence_analysis.model_dump_json(indent=2), border="cyan")

    if result.final_analysis:
        _print_final_analysis(result.final_analysis)
    else:
        console.print("[red]Pipeline completed but produced no final analysis.[/red]")
        raise typer.Exit(1)


def _load_pre_commit_hook_template() -> str:
    path = Path(__file__).resolve().parent / "pre_commit_hook_body.sh"
    if path.is_file():
        return path.read_text(encoding="utf-8")
    raise RuntimeError(f"Missing packaged hook template: {path}")


@app.command("init")
def cmd_init(
    update: bool = typer.Option(
        False,
        "--update",
        "-u",
        help="If .vibecheck.json exists, pre-fill prompts from it (otherwise same as normal init).",
    ),
) -> None:
    """
    Interactive setup: write .vibecheck.json at cwd and install .git/hooks/pre-commit.

    Paths in the config are relative to the target repo root (typically cwd).
    Type `-` at a prompt to omit idea or prd from the JSON.
    """
    cwd = Path.cwd().resolve()
    config_path = cwd / ".vibecheck.json"

    idea_default = "Docs/Idea.md"
    prd_default = "Docs/PRD.md"
    cp_default = ""

    if update and config_path.is_file():
        try:
            existing = json.loads(config_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            existing = None
        if isinstance(existing, dict):
            if "idea" in existing:
                iv = existing["idea"]
                if iv is None or (isinstance(iv, str) and not iv.strip()):
                    idea_default = "-"
                else:
                    idea_default = str(iv).strip()
            if "prd" in existing:
                pv = existing["prd"]
                if pv is None or (isinstance(pv, str) and not pv.strip()):
                    prd_default = "-"
                else:
                    prd_default = str(pv).strip()
            if "code_patterns" in existing:
                cp = existing["code_patterns"]
                if cp is None:
                    cp_default = ""
                elif isinstance(cp, list):
                    cp_default = ", ".join(str(x).strip() for x in cp if str(x).strip())
                else:
                    cp_default = str(cp).strip()

    idea_raw = typer.prompt(
        "Idea file path (relative to repo root; `-` to omit)",
        default=idea_default,
    ).strip()
    if idea_raw == "-":
        idea_val: Optional[str] = None
    else:
        idea_val = idea_raw or "Docs/Idea.md"

    prd_raw = typer.prompt(
        "PRD file path (relative to repo root; `-` to omit)",
        default=prd_default,
    ).strip()
    if prd_raw == "-":
        prd_val: Optional[str] = None
    else:
        prd_val = prd_raw or "Docs/PRD.md"

    cp_raw = typer.prompt(
        "code_patterns: comma-separated globs (blank = omit; hook filters staged "
        ".ts/.tsx/.js/.jsx/.py only)",
        default=cp_default,
    ).strip()
    code_patterns: Optional[list[str]] = (
        [x.strip() for x in cp_raw.split(",") if x.strip()] if cp_raw else None
    )

    cfg: dict[str, Any] = {}
    if idea_val:
        cfg["idea"] = idea_val
    if prd_val:
        cfg["prd"] = prd_val
    if code_patterns:
        cfg["code_patterns"] = code_patterns

    config_path.write_text(json.dumps(cfg, indent=2) + "\n", encoding="utf-8")
    console.print(f"[green]Wrote[/green] {config_path}")

    git_dir = cwd / ".git"
    hook_path = git_dir / "hooks" / "pre-commit"
    if git_dir.is_dir():
        hook_path.parent.mkdir(parents=True, exist_ok=True)
        hook_body = _load_pre_commit_hook_template()
        hook_path.write_text(hook_body, encoding="utf-8")
        hook_path.chmod(0o755)
        console.print(f"[green]Installed[/green] executable git hook {hook_path}")
        print("Tip: .vibecheck.json contains repo-relative paths and is safe to commit. Add it to .gitignore if you prefer not to track it.")
    else:
        console.print(
            "[yellow]No .git directory here — skipped pre-commit hook "
            "(run `vibecheck init` from the repo root).[/yellow]"
        )

    console.print(
        "\n[dim]Config fields: idea, prd (optional), code_patterns (optional). "
        "Hook reads .vibecheck.json, scans staged code files, runs `vibecheck eval`. "
        "Exit 1 blocks commit on tool failure or HIGH verdict "
        '("Review before shipping").[/dim]'
    )


@benchmark_app.command("run")
def benchmark_run(
    file: Optional[Path] = typer.Option(
        None,
        "--file",
        "-f",
        path_type=Path,
        help="Single benchmark JSON file (omit for default five-case suite).",
    ),
    all_json: bool = typer.Option(
        False,
        "--all",
        help="Run every benchmarks/*.json at repo root (excludes subfolders).",
    ),
    model: Optional[str] = typer.Option(
        None,
        "--model",
        help="Model override for pipeline stages (same as eval).",
    ),
) -> None:
    """Run benchmarks; compare risk score and concept checks to expected."""
    try:
        results = benchmark_runner.run_benchmark_suite(
            benchmark_file=file,
            all_json=all_json,
            model=model,
            on_case=lambda cid, _: console.print(f"[dim]Case[/dim] [cyan]{cid}[/cyan]"),
        )
    except FileNotFoundError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1)

    benchmark_runner.print_benchmark_report(results, console)
    if any(r.error or not r.passed for r in results):
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
