"""
DEPRECATED — not used by the current VibeCheck pipeline.

This module was written as a boundary layer to a planned SIE/mac-orchestrator
integration: it attempts to invoke a sibling `mac-orchestrator` repo and return
its structured `engine_output`. It is retained for reference only.

Do not import this module. Do not build on it. It is not maintained.
Current pipeline: app/pipeline.py → app/llm_router.py → app/cli.py
"""

from __future__ import annotations

import contextlib
import io
import sys
from pathlib import Path
from typing import Any

from .models import PipelineResult


def _vibecheck_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _mac_orchestrator_root() -> Path:
    return _vibecheck_root().parent / "mac-orchestrator"


def fetch_engine_output_from_sie(combined_source_text: str) -> dict[str, Any] | None:
    """
    Import mac-orchestrator on demand, run ``run_contract_pipeline``, return
    ``engine_output`` dict only. Returns ``None`` if the repo is missing,
    import fails, or the run raises.

    Does not modify mac-orchestrator; suppresses its stdout during the call so
    the VibeCheck CLI stays readable.
    """
    root = _mac_orchestrator_root()
    if not root.is_dir():
        return None

    path_str = str(root.resolve())
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

    try:
        from pipeline_contract import run_contract_pipeline  # type: ignore[import-untyped]
    except ImportError:
        return None

    buf = io.StringIO()
    payload: Any = None
    try:
        with contextlib.redirect_stdout(buf):
            payload = run_contract_pipeline(combined_source_text)
    except Exception:
        return None

    if not isinstance(payload, dict):
        return None
    eo = payload.get("engine_output")
    return eo if isinstance(eo, dict) else None


def combined_text_for_sie(
    idea_text: str | None,
    prd_text: str | None,
    code_text: str | None,
) -> str:
    """Single document string for SIE chunking (idea / PRD / code sections)."""
    parts: list[str] = []
    if idea_text and idea_text.strip():
        parts.append("=== IDEA ===\n" + idea_text.strip())
    if prd_text and prd_text.strip():
        parts.append("=== PRD ===\n" + prd_text.strip())
    if code_text and code_text.strip():
        parts.append("=== CODE ===\n" + code_text.strip())
    return "\n\n".join(parts)


def resolve_engine_output(result: PipelineResult) -> dict[str, Any]:
    """
    Prefer ``result.engine_output`` from SIE when present and dict-shaped;
    always ensure ``risk_score`` and ``relationship_map`` exist for the consumer.

    If SIE output is missing or malformed, fall back to VibeCheck's own
    ``risk_analysis.risk_score`` and an empty ``relationship_map``.
    """
    fallback_rs = result.risk_analysis.risk_score if result.risk_analysis else 0
    fallback: dict[str, Any] = {
        "risk_score": fallback_rs,
        "relationship_map": {},
    }

    raw = result.engine_output
    if not isinstance(raw, dict):
        return dict(fallback)

    out = dict(raw)
    rs = out.get("risk_score")
    if rs is None or (isinstance(rs, str) and not str(rs).strip()):
        out["risk_score"] = fallback_rs

    rm = out.get("relationship_map")
    if rm is None or not isinstance(rm, dict):
        out["relationship_map"] = {}

    return out
