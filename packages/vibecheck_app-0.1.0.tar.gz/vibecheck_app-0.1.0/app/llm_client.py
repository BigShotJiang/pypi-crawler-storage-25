"""
VibeCheck LLM client — provider-agnostic interface.

Supports:
  - Ollama  (default) via its OpenAI-compatible /v1 endpoint
  - OpenAI  via the standard API

Provider is selected by LLM_PROVIDER. All other settings are env-driven.
Nothing in the pipeline imports model names or URLs directly.

Environment variables
---------------------
LLM_PROVIDER    "ollama" | "openai"          (default: ollama)
LLM_MODEL       Optional shared default model tag (no hardcoded default; set explicitly)
LLM_BASE_URL    Full base URL incl. /v1      (default: http://localhost:11434/v1)

Legacy aliases (still supported, lower priority than the LLM_* vars above):
  OLLAMA_BASE_URL   Host without /v1, e.g. http://localhost:11434
  OLLAMA_MODEL      Model tag

OpenAI (used only when LLM_PROVIDER=openai):
  OPENAI_API_KEY    Required
  OPENAI_MODEL      (default: gpt-4o-mini)

Future model routing
--------------------
When per-stage model routing is needed, introduce:
  LLM_SUMMARIZER_MODEL   lighter model for preprocessing / summarization
  LLM_REASONING_MODEL    heavier model for risk + congruence evaluation
These are not read yet — stubs are marked below.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlparse, urlunparse

from dotenv import load_dotenv
from openai import OpenAI

# Load project .env first (stable regardless of cwd), then optional cwd .env.
_PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(_PROJECT_ROOT / ".env")
load_dotenv()

SYSTEM_PROMPT = (
    "You are a precise AI risk analyst. "
    "Always respond with valid JSON when asked. "
    "Never add explanation, commentary, or markdown outside the JSON block."
)

# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_DEFAULT_PROVIDER = "ollama"
# No default Ollama tag — configure LLM_MODEL / OLLAMA_MODEL or use app.llm_router routes.
_DEFAULT_MODEL = ""
_DEFAULT_BASE_URL = "http://localhost:11434/v1"


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _LLMConfig:
    provider: str
    model: str
    base_url: str
    api_key: str


def _resolve_ollama_base_url() -> str:
    """
    Resolve the Ollama base URL, preferring the unified LLM_BASE_URL var.

    LLM_BASE_URL   — full URL including /v1  (preferred)
    OLLAMA_BASE_URL — host only, /v1 appended here  (legacy fallback)
    default         — http://localhost:11434/v1
    """
    if os.environ.get("LLM_BASE_URL"):
        return os.environ["LLM_BASE_URL"].rstrip("/")
    if os.environ.get("OLLAMA_BASE_URL"):
        return os.environ["OLLAMA_BASE_URL"].rstrip("/") + "/v1"
    return _DEFAULT_BASE_URL


def _resolve_model(model_override: str | None) -> str:
    """
    Resolve the active model, in priority order:
      1. explicit override from caller (e.g. --model CLI flag)
      2. LLM_MODEL env var
      3. OLLAMA_MODEL env var (legacy)
      4. hardcoded default

    # ROUTING STUB: to route by stage, callers can pass a stage-specific
    # model_override derived from LLM_SUMMARIZER_MODEL or LLM_REASONING_MODEL.
    # Example pipeline usage (not active yet):
    #   summarizer_model = os.environ.get("LLM_SUMMARIZER_MODEL")
    #   reasoning_model  = os.environ.get("LLM_REASONING_MODEL")
    """
    resolved = (
        model_override
        or os.environ.get("LLM_MODEL")
        or os.environ.get("OLLAMA_MODEL")
        or _DEFAULT_MODEL
    )
    return (resolved or "").strip()


def _build_config(model_override: str | None = None) -> _LLMConfig:
    """
    Build the active LLM config from environment variables.

    model_override lets a caller (e.g. the CLI --model flag) substitute a
    specific model for this call only, without touching the environment.
    """
    provider = os.environ.get("LLM_PROVIDER", _DEFAULT_PROVIDER).strip().lower()

    if provider == "ollama":
        ollama_model = _resolve_model(model_override)
        if not ollama_model:
            raise EnvironmentError(
                "No Ollama model configured for llm_client.call(). "
                "Set LLM_MODEL or OLLAMA_MODEL, or use the pipeline with "
                "LLM_LOCAL_MODEL / LLM_REMOTE_MODEL (see .env.example)."
            )
        return _LLMConfig(
            provider="ollama",
            model=ollama_model,
            base_url=_resolve_ollama_base_url(),
            # Ollama's OpenAI-compat endpoint does not validate the key,
            # but the SDK requires a non-empty string.
            api_key=os.environ.get("LLM_API_KEY", "ollama"),
        )

    if provider == "openai":
        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        if not api_key:
            raise EnvironmentError(
                "LLM_PROVIDER=openai but OPENAI_API_KEY is not set in your .env file."
            )
        model = model_override or os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
        return _LLMConfig(
            provider="openai",
            model=model,
            base_url="https://api.openai.com/v1",
            api_key=api_key,
        )

    raise EnvironmentError(
        f"Unknown LLM_PROVIDER: '{provider}'. "
        "Set LLM_PROVIDER to 'ollama' or 'openai' in your .env file."
    )


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def call(
    prompt: str,
    temperature: float = 0.1,
    model_override: str | None = None,
) -> str:
    """
    Send a prompt to the configured LLM and return the raw text response.

    The OpenAI SDK is used for both providers — for Ollama it is pointed at
    the local /v1 endpoint, which is OpenAI-API-compatible.

    Args:
        prompt:         The user prompt text.
        temperature:    Sampling temperature (0.0 = deterministic).
        model_override: Override the env-configured model for this call only.

    Returns:
        Raw text from the model (caller is responsible for JSON parsing).
    """
    config = _build_config(model_override=model_override)
    client = OpenAI(api_key=config.api_key, base_url=config.base_url)

    response = client.chat.completions.create(
        model=config.model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
    )
    return response.choices[0].message.content or ""


def _normalize_call_transport(base_url: str, api_key: str) -> tuple[str, str]:
    """
    For calls to ``api.openai.com``, ensure ``/v1`` suffix and a real API key.

    Router should already pass these after OpenAI overrides; this covers residual
    ``ollama`` placeholder keys when the host is the official OpenAI API.
    """
    raw = (base_url or "").strip().rstrip("/")
    if not raw:
        return raw, api_key
    p = urlparse(raw)
    host = (p.hostname or "").lower()
    if host != "api.openai.com":
        return raw, api_key
    path = (p.path or "").rstrip("/")
    if not path.lower().endswith("/v1"):
        scheme = p.scheme or "https"
        raw = urlunparse((scheme, p.netloc, "/v1", "", "", "")).rstrip("/")
    env_key = os.environ.get("OPENAI_API_KEY", "").strip()
    key = (api_key or "").strip()
    if (not key or key == "ollama") and env_key:
        key = env_key
    return raw, key


def call_with_config(
    prompt: str,
    model: str,
    base_url: str,
    api_key: str,
    temperature: float = 0.0,
) -> str:
    """
    Send a prompt using fully explicit config — no env resolution.

    Used by llm_router when it has already resolved the endpoint (model,
    base_url, api_key) from its route table. Keeps transport logic in one
    place without coupling the router to env-var resolution.

    For ``https://api.openai.com``, ensures a ``/v1`` base path and uses
    ``OPENAI_API_KEY`` if the caller still passed the Ollama placeholder key.

    Args:
        prompt:      Fully formatted prompt to send.
        model:       Exact model name to request.
        base_url:    Full API base URL including /v1.
        api_key:     API key (use "ollama" for local Ollama).
        temperature: Sampling temperature.

    Returns:
        Raw text from the model.
    """
    base, key = _normalize_call_transport(base_url, api_key)
    client = OpenAI(api_key=key, base_url=base)
    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
        temperature=temperature,
    )
    return response.choices[0].message.content or ""


def active_config(model_override: str | None = None) -> dict:
    """Return the active config as a plain dict for startup logging or --show-config."""
    cfg = _build_config(model_override=model_override)
    return {
        "provider": cfg.provider,
        "model": cfg.model,
        "base_url": cfg.base_url,
    }
