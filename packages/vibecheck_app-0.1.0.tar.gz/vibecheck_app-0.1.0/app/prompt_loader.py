from pathlib import Path

PROMPTS_DIR = Path(__file__).resolve().parent.parent / "prompts"


def load_prompt(name: str) -> str:
    """Load a prompt template by name (without the .txt extension)."""
    path = PROMPTS_DIR / f"{name}.txt"
    if not path.exists():
        raise FileNotFoundError(
            f"Prompt template '{name}' not found at {path}. "
            f"Available templates: {', '.join(list_prompts())}"
        )
    return path.read_text(encoding="utf-8")


def format_prompt(name: str, **kwargs: str) -> str:
    """Load a prompt template and substitute variables using {key} placeholders."""
    template = load_prompt(name)
    return template.format(**kwargs)


def list_prompts() -> list[str]:
    """Return the names of all available prompt templates (without .txt)."""
    return sorted(p.stem for p in PROMPTS_DIR.glob("*.txt"))
