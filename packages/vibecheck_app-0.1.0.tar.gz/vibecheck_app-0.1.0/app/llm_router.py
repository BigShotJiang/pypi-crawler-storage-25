"""
VibeCheck LLM router — endpoint-aware model dispatch.

Routes each pipeline stage to a named endpoint (local Mac vs remote PC) and
resolves provider, base_url, and model per call. OpenAI-compatible transport
only (Ollama /v1 or OpenAI); provider selects validation behavior.

Configuration
-------------
  Editable defaults: DEFAULT_* constants below and .env.example.
  Per-task default models are listed in _DEFAULT_MODEL_BY_TASK (local light
  stages vs remote heavy stages). Env vars override endpoint defaults.

Validation
----------
  For Ollama endpoints, model tags are checked against /api/tags at startup
  (CLI) and on first router.run(). Invalid or unreachable configuration
  raises RouterConfigurationError with available model names — no silent
  fallback to remote.

  For OpenAI (LLM_PROVIDER=openai or LLM_*_PROVIDER=openai), Ollama tag
  validation is skipped; OPENAI_API_KEY must be set instead.

  VIBECHECK_SKIP_OLLAMA_VALIDATION=1  — skip Ollama tag checks (offline / CI)
  VIBECHECK_FORCE_REMOTE_ALL=1      — every task uses the remote endpoint

Per-task route override
-----------------------
  VIBECHECK_ROUTE_<task_type>=local|remote

Caller override
---------------
  options["model_override"] (e.g. CLI --model) applies to that call; validation
  ensures the override exists on every Ollama host that will be used.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any
from urllib.parse import urlparse, urlunparse

from .llm_client import call_with_config

log = logging.getLogger(__name__)


class RouterConfigurationError(EnvironmentError):
    """Raised when routing config is invalid, unreachable, or model tag missing."""


# ---------------------------------------------------------------------------
# Editable defaults (override with env — see .env.example)
# ---------------------------------------------------------------------------

# Ollama OpenAI-compatible /v1 bases (local Mac vs remote). Only used when the
# resolved provider for that endpoint is Ollama (e.g. LLM_PROVIDER=ollama or
# LLM_*_PROVIDER=ollama). When the provider is OpenAI, _apply_openai_endpoint_overrides
# replaces base_url with the OpenAI API base — these defaults are not used.
OLLAMA_DEFAULT_LOCAL_BASE_URL = "http://localhost:11434/v1"
OLLAMA_DEFAULT_REMOTE_BASE_URL = "http://100.65.55.64:11434/v1"

# Default Ollama tags for this hybrid setup (align with `ollama list` on each host).
DEFAULT_LOCAL_MODEL = "qwen2.5:3b-instruct"
DEFAULT_REMOTE_MODEL = "qwen2.5:14b"

# Explicit per-task default model (same as endpoint defaults today; kept for clarity / startup table).
_DEFAULT_MODEL_BY_TASK: dict[str, str] = {
    "idea_extractor": DEFAULT_LOCAL_MODEL,
    "prd_extractor": DEFAULT_LOCAL_MODEL,
    "code_extractor": DEFAULT_LOCAL_MODEL,
    "output_refiner": DEFAULT_LOCAL_MODEL,
    "context_fusion": DEFAULT_REMOTE_MODEL,
    "risk_evaluator": DEFAULT_REMOTE_MODEL,
    "congruence_evaluator": DEFAULT_REMOTE_MODEL,
}

# ---------------------------------------------------------------------------
# Route table: task -> preferred endpoint name
# ---------------------------------------------------------------------------

_ROUTE_TABLE: dict[str, str] = {
    "idea_extractor": "local",
    "prd_extractor": "local",
    "code_extractor": "local",
    "context_fusion": "remote",
    "risk_evaluator": "remote",
    "congruence_evaluator": "remote",
    "output_refiner": "local",
}

# ---------------------------------------------------------------------------
# Validation cache (per resolved model_override key)
# ---------------------------------------------------------------------------

_validated_key: str | None = None


def reset_route_cache() -> None:
    """Clear cached validation state (e.g. after changing env)."""
    global _validated_key
    _validated_key = None


def _strip(s: str | None) -> str:
    return (s or "").strip()


def _default_provider() -> str:
    return _strip(os.environ.get("LLM_PROVIDER")) or "openai"


def _legacy_model() -> str:
    return _strip(os.environ.get("LLM_MODEL")) or _strip(os.environ.get("OLLAMA_MODEL"))


def _ollama_native_root_from_openai_base(openai_compatible_base_url: str) -> str:
    """
    OpenAI-compat base is typically http://host:11434/v1.
    Ollama native /api/tags is http://host:11434/api/tags — strip only a trailing
    /v1 path (urlparse-safe; avoids slicing bugs on unusual URLs).
    """
    raw = openai_compatible_base_url.strip().rstrip("/")
    p = urlparse(raw)
    if not p.scheme or not p.netloc:
        return raw
    path = (p.path or "").rstrip("/")
    if len(path) >= 3 and path.lower().endswith("/v1"):
        path = path[:-3].rstrip("/")
    return urlunparse((p.scheme, p.netloc, "", "", "", "")).rstrip("/")


def _ollama_tags_probe_url(openai_compatible_base_url: str) -> str:
    return _ollama_native_root_from_openai_base(openai_compatible_base_url).rstrip("/") + "/api/tags"


def _fetch_ollama_model_names(
    tags_url: str, timeout: float = 12.0
) -> tuple[list[str] | None, str | None]:
    """
    GET Ollama /api/tags. Returns (names, None) on success, (None, detail) on failure.
    """
    text = ""
    try:
        req = urllib.request.Request(
            tags_url,
            headers={"User-Agent": "VibeCheck/1.0 (Ollama tag validation)"},
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
        text = body.decode("utf-8", errors="replace")
        data = json.loads(text)
        models = data.get("models")
        if not isinstance(models, list):
            return None, (
                f"Unexpected JSON from {tags_url!r}: key 'models' is not a list "
                f"(got {type(models).__name__!r})."
            )
        names = [
            str(m.get("name", ""))
            for m in models
            if isinstance(m, dict) and m.get("name")
        ]
        return names, None
    except urllib.error.HTTPError as exc:
        return None, f"HTTP {exc.code} {exc.reason!r} from GET {tags_url!r}"
    except urllib.error.URLError as exc:
        hint = ""
        if os.environ.get("HTTP_PROXY") or os.environ.get("HTTPS_PROXY"):
            hint = " Hint: HTTP_PROXY/HTTPS_PROXY may affect urllib; curl might not use the same path. Set NO_PROXY for your Ollama hosts if needed."
        return None, f"Network error GET {tags_url!r}: {exc.reason!r}.{hint}"
    except TimeoutError:
        return None, f"Timeout ({timeout}s) GET {tags_url!r}"
    except OSError as exc:
        return None, f"OS error GET {tags_url!r}: {exc!r}"
    except json.JSONDecodeError as exc:
        prefix = text[:240].replace("\n", " ") + ("…" if len(text) > 240 else "")
        return None, (
            f"Invalid JSON from {tags_url!r} (host responded but body is not Ollama /api/tags): "
            f"{exc}; body prefix={prefix!r}"
        )
    except (TypeError, ValueError) as exc:
        return None, f"Failed to parse Ollama tags from {tags_url!r}: {exc!r}"


def _model_available_on_ollama(model: str, tag_names: list[str]) -> bool:
    if not model or not tag_names:
        return False
    if model in tag_names:
        return True
    return any(t == model or t.startswith(model + ":") for t in tag_names)


def _skip_ollama_validation() -> bool:
    return _strip(os.environ.get("VIBECHECK_SKIP_OLLAMA_VALIDATION")).lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


def _effective_endpoint_name(task_type: str) -> str:
    if _strip(os.environ.get("VIBECHECK_FORCE_REMOTE_ALL")).lower() in (
        "1",
        "true",
        "yes",
        "on",
    ):
        return "remote"
    return _strip(os.environ.get(f"VIBECHECK_ROUTE_{task_type}")) or _ROUTE_TABLE.get(
        task_type, "local"
    )


def _is_ollama_provider(provider: str) -> bool:
    p = (provider or "").lower()
    return p in ("", "ollama")


def _is_openai_provider(provider: str) -> bool:
    return (provider or "").strip().lower() == "openai"


# Official OpenAI API base (override with OPENAI_BASE_URL for proxies / Azure-style paths later).
_DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1"


def _apply_openai_endpoint_overrides(ep: dict[str, str]) -> None:
    """
    When the resolved provider is OpenAI, use the real OpenAI API base and key.
    Does not run when provider is ollama — local/remote Ollama URLs are unchanged.
    """
    if not _is_openai_provider(ep["provider"]):
        return
    base = _strip(os.environ.get("OPENAI_BASE_URL")) or _DEFAULT_OPENAI_BASE_URL
    base = base.rstrip("/")
    p = urlparse(base)
    if (p.hostname or "").lower() == "api.openai.com":
        path = (p.path or "").rstrip("/")
        if not path.lower().endswith("/v1"):
            base = urlunparse(
                (p.scheme or "https", p.netloc, "/v1", "", "", "")
            ).rstrip("/")
    ep["base_url"] = base
    ep["api_key"] = _strip(os.environ.get("OPENAI_API_KEY"))
    openai_model = _strip(os.environ.get("OPENAI_MODEL"))
    if openai_model:
        ep["model"] = openai_model
        return
    m = ep.get("model") or ""
    if ":" in m or not m:
        ep["model"] = "gpt-4o-mini"


def _resolve_endpoint(name: str) -> dict[str, str]:
    """
    Resolve provider, base_url, model, api_key for local or remote.
    """
    api_key = _strip(os.environ.get("LLM_API_KEY")) or "ollama"
    legacy = _legacy_model()

    if name == "remote":
        base = _strip(os.environ.get("LLM_REMOTE_BASE_URL")) or OLLAMA_DEFAULT_REMOTE_BASE_URL
        model = (
            _strip(os.environ.get("LLM_REMOTE_MODEL"))
            or legacy
            or DEFAULT_REMOTE_MODEL
        )
        provider = _strip(os.environ.get("LLM_REMOTE_PROVIDER")) or _default_provider()
        ep: dict[str, str] = {
            "name": "remote",
            "provider": provider,
            "base_url": base.rstrip("/"),
            "model": model,
            "api_key": api_key,
        }
    else:
        base = _strip(os.environ.get("LLM_LOCAL_BASE_URL"))
        if not base:
            base = _strip(os.environ.get("LLM_BASE_URL"))
        if not base:
            base = OLLAMA_DEFAULT_LOCAL_BASE_URL
        model = (
            _strip(os.environ.get("LLM_LOCAL_MODEL"))
            or legacy
            or DEFAULT_LOCAL_MODEL
        )
        provider = _strip(os.environ.get("LLM_LOCAL_PROVIDER")) or _default_provider()
        ep = {
            "name": "local",
            "provider": provider,
            "base_url": base.rstrip("/"),
            "model": model,
            "api_key": api_key,
        }
    _apply_openai_endpoint_overrides(ep)
    return ep


def _collect_route_targets(model_override: str | None = None) -> list[dict[str, str]]:
    """One row per pipeline task with resolved endpoint + model."""
    rows: list[dict[str, str]] = []
    for task in sorted(_ROUTE_TABLE.keys()):
        eff = _effective_endpoint_name(task)
        ep = _resolve_endpoint(eff)
        task_default = _DEFAULT_MODEL_BY_TASK.get(task, ep["model"])
        model = (model_override or ep["model"] or task_default).strip()
        rows.append(
            {
                "task_type": task,
                "endpoint": eff,
                "provider": ep["provider"],
                "base_url": ep["base_url"],
                "model": model,
            }
        )
    return rows


def validate_routing_configuration(model_override: str | None = None) -> None:
    """
    Verify routing configuration.

    Ollama: endpoints reachable and configured model tags exist (unless
    VIBECHECK_SKIP_OLLAMA_VALIDATION=1).
    OpenAI: requires OPENAI_API_KEY; no /api/tags checks (nothing to validate).
    """
    # Unique (slot, base_url, provider, model); slot = local|remote for diagnostics
    seen: set[tuple[str, str, str, str]] = set()
    targets: list[dict[str, str]] = []

    for row in _collect_route_targets(model_override):
        slot = row["endpoint"]
        key = (slot, row["base_url"], row["provider"].lower(), row["model"])
        if key in seen:
            continue
        seen.add(key)
        tags_url = _ollama_tags_probe_url(row["base_url"])
        if _is_openai_provider(row["provider"]):
            tags_url = "(skipped — OpenAI provider)"
        targets.append(
            {
                "slot": slot,
                "base_url": row["base_url"],
                "provider": row["provider"],
                "model": row["model"],
                "tags_url": tags_url,
            }
        )

    errors: list[str] = []
    if any(_is_openai_provider(t["provider"]) for t in targets) and not _strip(
        os.environ.get("OPENAI_API_KEY")
    ):
        errors.append(
            "• [OpenAI — missing API key]\n"
            "  Set OPENAI_API_KEY when LLM_PROVIDER=openai or LLM_LOCAL_PROVIDER / "
            "LLM_REMOTE_PROVIDER is openai.\n"
            "  Ollama tag validation is not used for OpenAI."
        )

    if _skip_ollama_validation():
        if errors:
            msg = "LLM routing configuration is invalid:\n" + "\n".join(errors)
            raise RouterConfigurationError(msg)
        return

    for t in targets:
        provider = t["provider"]
        if _is_openai_provider(provider):
            continue
        if not _is_ollama_provider(provider):
            continue
        model = t["model"]
        slot = t["slot"]
        slot_title = "Local" if slot == "local" else "Remote"
        tags_url = t["tags_url"]
        base_url = t["base_url"]

        if not model:
            errors.append(
                f"• [{slot_title} — no model configured]\n"
                f"  OpenAI-compat base_url: {base_url!r}\n"
                f"  Set LLM_{slot_title.upper()}_MODEL or LLM_MODEL (see .env)."
            )
            continue

        tags, fetch_err = _fetch_ollama_model_names(tags_url)
        if tags is None:
            errors.append(
                f"• [{slot_title} — cannot validate tags (network, HTTP, or unexpected response)]\n"
                f"  GET {tags_url!r}\n"
                f"  (derived from OpenAI-compat base {base_url!r}; native root "
                f"{_ollama_native_root_from_openai_base(base_url)!r})\n"
                f"  Detail: {fetch_err}"
            )
            continue

        if not _model_available_on_ollama(model, tags):
            avail = ", ".join(sorted(tags)) if tags else "(none reported)"
            errors.append(
                f"• [{slot_title} — invalid model tag for this host]\n"
                f"  Requested model: {model!r}\n"
                f"  GET {tags_url!r}\n"
                f"  Available models on that host: {avail}"
            )

    if errors:
        msg = "LLM routing configuration is invalid:\n" + "\n".join(errors)
        raise RouterConfigurationError(msg)


def get_resolved_routing_debug(model_override: str | None = None) -> dict[str, Any]:
    """
    Pre-validation snapshot: raw env keys, resolved endpoints, exact tag probe URLs.
    """
    le = _resolve_endpoint("local")
    re = _resolve_endpoint("remote")
    env_keys = (
        "LLM_LOCAL_BASE_URL",
        "LLM_LOCAL_MODEL",
        "LLM_LOCAL_PROVIDER",
        "LLM_REMOTE_BASE_URL",
        "LLM_REMOTE_MODEL",
        "LLM_REMOTE_PROVIDER",
        "LLM_BASE_URL",
        "LLM_MODEL",
        "OLLAMA_MODEL",
        "LLM_PROVIDER",
        "OPENAI_BASE_URL",
        "OPENAI_MODEL",
    )
    root = Path(__file__).resolve().parents[1]
    probes: dict[str, Any] = {}
    for name, ep in (("local", le), ("remote", re)):
        eff_model = (model_override or "").strip() or ep["model"]
        if _is_openai_provider(ep["provider"]):
            probes[name] = {
                "resolved_provider": ep["provider"],
                "resolved_base_url": ep["base_url"],
                "resolved_model": eff_model,
                "ollama_native_root": "(n/a — OpenAI)",
                "tags_validation_url": "(skipped — OpenAI provider)",
            }
        else:
            probes[name] = {
                "resolved_provider": ep["provider"],
                "resolved_base_url": ep["base_url"],
                "resolved_model": eff_model,
                "ollama_native_root": _ollama_native_root_from_openai_base(ep["base_url"]),
                "tags_validation_url": _ollama_tags_probe_url(ep["base_url"]),
            }
    return {
        "project_root": str(root),
        "dotenv_file": str(root / ".env"),
        "env_precedence_note": (
            "Shell/exported variables win over values in .env (python-dotenv default: override=False)."
        ),
        "raw_process_env": {k: os.environ.get(k) for k in env_keys},
        "resolved_local_endpoint": dict(le),
        "resolved_remote_endpoint": dict(re),
        "ollama_tag_probes": probes,
        "cli_model_override": model_override,
    }


def _ensure_validated(model_override: str | None) -> None:
    global _validated_key
    key = (model_override or "__default__").strip() or "__default__"
    if _validated_key == key:
        return
    validate_routing_configuration(model_override)
    _validated_key = key


def get_route_startup_summary(
    model_override: str | None = None,
    *,
    validate: bool = True,
) -> dict[str, Any]:
    """
    Structured routing info for CLI startup / debug.

    When validate=True, raises RouterConfigurationError if Ollama tags don't match
    or OpenAI is selected but OPENAI_API_KEY is missing.
    """
    if validate:
        validate_routing_configuration(model_override)

    local = _resolve_endpoint("local")
    remote = _resolve_endpoint("remote")
    force_all_remote = _strip(os.environ.get("VIBECHECK_FORCE_REMOTE_ALL")).lower() in (
        "1",
        "true",
        "yes",
        "on",
    )

    tasks = []
    for row in _collect_route_targets(model_override):
        default_ep = _ROUTE_TABLE.get(row["task_type"], "local")
        tasks.append(
            {
                "task_type": row["task_type"],
                "default_endpoint": default_ep,
                "effective_endpoint": row["endpoint"],
                "provider": row["provider"],
                "base_url": row["base_url"],
                "model": row["model"],
            }
        )

    return {
        "local": {
            "provider": local["provider"],
            "base_url": local["base_url"],
            "model": local["model"],
        },
        "remote": {
            "provider": remote["provider"],
            "base_url": remote["base_url"],
            "model": remote["model"],
        },
        "force_all_remote": force_all_remote,
        "tasks": tasks,
    }


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def run(
    task_type: str,
    input_text: str,
    options: dict | None = None,
) -> str:
    opts = options or {}
    temperature: float = opts.get("temperature", 0.1)
    model_override: str | None = opts.get("model_override")

    _ensure_validated(model_override)

    endpoint_name = _effective_endpoint_name(task_type)
    ep = _resolve_endpoint(endpoint_name)
    task_default = _DEFAULT_MODEL_BY_TASK.get(task_type, ep["model"])
    model = (model_override or ep["model"] or task_default or "").strip()
    if not model:
        raise RouterConfigurationError(
            f"No model resolved for task={task_type!r} endpoint={endpoint_name!r}. "
            "Set LLM_LOCAL_MODEL / LLM_REMOTE_MODEL or defaults in llm_router.py."
        )

    log.debug(
        "[router] task=%s  endpoint=%s  provider=%s  base_url=%s  model=%s",
        task_type,
        ep["name"],
        ep["provider"],
        ep["base_url"],
        model,
    )

    return call_with_config(
        prompt=input_text,
        model=model,
        base_url=ep["base_url"],
        api_key=ep["api_key"],
        temperature=temperature,
    )
