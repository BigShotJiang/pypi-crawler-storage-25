"""
DEPRECATED — not used by the current VibeCheck pipeline.

This module was written as a consumer contract for a planned SIE/mac-orchestrator
integration that was removed before production. It is retained for reference only.

Do not import this module. Do not build on it. It is not maintained.
Current pipeline: app/pipeline.py → app/llm_router.py → app/cli.py
"""

from __future__ import annotations

from collections.abc import Mapping as MappingABC
from typing import Any, Mapping, TypedDict


class EngineOutputContract(TypedDict, total=False):
    """
    Documented subset of SIE ``engine_output`` for typing and IDE hints.

    The runtime value may include additional keys; :func:`evaluate_vibecheck`
    only reads the fields it needs.
    """

    risk_score: float | int | str
    extracted_notes: list[Any]
    score_breakdown: list[Any]
    relationship_map: Mapping[str, Any]


def _coerce_risk_score(value: Any) -> float:
    """Best-effort numeric score for comparisons; invalid/missing → 0.0."""
    if value is None:
        return 0.0
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _normalize_relationship_map(raw: Any) -> dict[str, Any]:
    """Missing, None, or non-mapping → empty dict (adapter and full SIE)."""
    if raw is None:
        return {}
    if isinstance(raw, MappingABC) and not isinstance(raw, (str, bytes, bytearray)):
        return dict(raw)
    return {}


def _iter_propagation_items(relationship_map: Mapping[str, Any]) -> list[Mapping[str, Any]]:
    """Only iterate real list/tuple propagation rows; ignore wrong types."""
    raw = relationship_map.get("risk_propagation")
    if raw is None:
        return []
    if isinstance(raw, (list, tuple)):
        return [
            x
            for x in raw
            if isinstance(x, MappingABC) and not isinstance(x, (str, bytes, bytearray))
        ]
    return []


def evaluate_vibecheck(engine_output: Mapping[str, Any]) -> dict[str, Any]:
    """
    Map engine ``engine_output`` to VibeCheck consumer summary.

    Ignores unknown top-level fields. Does not mutate ``engine_output``.
    """
    risk_score = _coerce_risk_score(engine_output.get("risk_score", 0))
    relationship_map = _normalize_relationship_map(engine_output.get("relationship_map"))

    if risk_score >= 6:
        alignment_status = "misaligned"
        recommended_next_step = "governance_review_required"
    elif risk_score >= 3:
        alignment_status = "partially_aligned"
        recommended_next_step = "targeted_review"
    else:
        alignment_status = "aligned"
        recommended_next_step = "proceed"

    flags: list[str] = []
    if relationship_map.get("contradictions"):
        flags.append("internal_policy_tension")
    if relationship_map.get("dependencies"):
        flags.append("dependency_chain_present")
    if relationship_map.get("risk_propagation"):
        flags.append("risk_propagation_detected")

    system_risks: list[dict[str, Any]] = []
    for item in _iter_propagation_items(relationship_map):
        system_risks.append(
            {
                "risk_type": item.get("risk_type"),
                "affected_area": item.get("impacts"),
                "effect": item.get("effect"),
            }
        )

    return {
        "alignment_status": alignment_status,
        "governance_flags": flags,
        "system_risks": system_risks,
        "recommended_next_step": recommended_next_step,
    }
