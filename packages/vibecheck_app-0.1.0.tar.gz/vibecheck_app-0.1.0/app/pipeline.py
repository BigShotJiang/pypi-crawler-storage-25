"""
VibeCheck pipeline — dual-layer governance reasoning engine.

Stages:
  1. extract_idea(...)         → IdeaSchema
  2. extract_prd(...)          → PRDSchema   (scaffolded — pass-through in Phase A)
  3. extract_code(...)         → CodeSchema  (scaffolded — pass-through in Phase A)
  4. fuse_context(...)         → UnifiedContext
  5. evaluate_risks(...)       → RiskAnalysis
  6. evaluate_congruence(...)  → CongruenceAnalysis
  7. assemble_final_analysis(...)  → FinalAnalysis

All LLM calls go through app/llm_router.run() — model selection lives there.
Provider config and transport live in app/llm_client.py; routing in app/llm_router.py
with explicit local/remote URLs, per-task models, and Ollama tag validation (no silent fallback).
Prompt templates live in prompts/ (repo root) and are loaded via app/prompt_loader.py.
"""

import json

from .llm_router import run as router_run
from .models import (
    CodeSchema,
    CongruenceAnalysis,
    FinalAnalysis,
    IdeaSchema,
    PRDSchema,
    PipelineResult,
    RiskAnalysis,
    UnifiedContext,
)
from .prompt_loader import format_prompt
from .sie_bridge import combined_text_for_sie, fetch_engine_output_from_sie
from .utils import JSONParseError, extract_json, truncate_text


# ---------------------------------------------------------------------------
# LLM JSON coercion (list fields sometimes returned as string or null)
# ---------------------------------------------------------------------------

_RISK_STR_LIST_FIELDS = ("missing_safeguards", "quick_fixes", "analysis_notes")
_CONGRUENCE_STR_LIST_FIELDS = (
    "intent_design_gaps",
    "design_build_gaps",
    "intent_build_gaps",
    "drift_risks",
    "congruence_notes",
)


def _normalize_str_list_field(value: object) -> list[str]:
    """None → []; str → [str]; list → list of str; anything else → []."""
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        return [str(item) for item in value]
    return []


def _normalize_system_risks_field(value: object) -> list:
    """None → []; single object → [object]; list unchanged; str → []."""
    if value is None:
        return []
    if isinstance(value, dict):
        return [value]
    if isinstance(value, list):
        return value
    return []


def _normalize_risk_analysis_dict(data: dict) -> dict:
    out = dict(data)
    for key in _RISK_STR_LIST_FIELDS:
        out[key] = _normalize_str_list_field(out.get(key))
    out["system_risks"] = _normalize_system_risks_field(out.get("system_risks"))
    return out


def _normalize_congruence_analysis_dict(data: dict) -> dict:
    out = dict(data)
    for key in _CONGRUENCE_STR_LIST_FIELDS:
        out[key] = _normalize_str_list_field(out.get(key))
    return out


_UNIFIED_CONTEXT_TEXT_FIELDS = ("intent", "design", "implementation")


def _normalize_unified_context_scalar(value: object) -> str | None:
    """None unchanged; str unchanged; dict/list → JSON text; other → str(value)."""
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return json.dumps(value, indent=2, ensure_ascii=False)
    if isinstance(value, list):
        return json.dumps(value, indent=2, ensure_ascii=False)
    return str(value)


def _normalize_unified_context_dict(data: dict) -> dict:
    out = dict(data)
    for key in _UNIFIED_CONTEXT_TEXT_FIELDS:
        if key not in out:
            continue
        out[key] = _normalize_unified_context_scalar(out.get(key))
    return out


# ---------------------------------------------------------------------------
# Stage 1 — Idea extractor
# ---------------------------------------------------------------------------

def extract_idea(idea_text: str, model_override: str | None = None) -> IdeaSchema:
    prompt = format_prompt("idea_extractor", idea_text=truncate_text(idea_text))
    try:
        raw = router_run("idea_extractor", prompt, options={"temperature": 0.1, "model_override": model_override})
        return IdeaSchema(**extract_json(raw))
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[idea_extractor] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 2 — PRD extractor (scaffolded)
# ---------------------------------------------------------------------------

def extract_prd(prd_text: str, model_override: str | None = None) -> PRDSchema:
    """Extract structured data from a PRD. Returns empty schema if text is blank."""
    if not prd_text or not prd_text.strip():
        return PRDSchema()
    prompt = format_prompt("prd_extractor", prd_text=truncate_text(prd_text))
    try:
        raw = router_run("prd_extractor", prompt, options={"temperature": 0.1, "model_override": model_override})
        return PRDSchema(**extract_json(raw))
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[prd_extractor] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 3 — Code extractor (scaffolded)
# ---------------------------------------------------------------------------

def extract_code(code_text: str, model_override: str | None = None) -> CodeSchema:
    """Extract structured data from code. Returns empty schema if text is blank."""
    if not code_text or not code_text.strip():
        return CodeSchema()
    prompt = format_prompt("code_extractor", code_text=truncate_text(code_text))
    try:
        raw = router_run("code_extractor", prompt, options={"temperature": 0.1, "model_override": model_override})
        return CodeSchema(**extract_json(raw))
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[code_extractor] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 4 — Context fusion
# ---------------------------------------------------------------------------

def fuse_context(
    idea: IdeaSchema | None = None,
    prd: PRDSchema | None = None,
    code: CodeSchema | None = None,
) -> UnifiedContext:
    """
    Fuse available extractor outputs into a UnifiedContext.

    Idea-only mode: built programmatically (no LLM call needed).
    Multi-input mode: delegates to the context_fusion prompt.
    """
    has_prd = prd is not None and bool(
        prd.features or prd.user_interactions or prd.data_handling
    )
    has_code = code is not None and bool(
        code.components or code.api_calls or code.data_access_patterns
    )

    if not has_prd and not has_code:
        # Idea-only: build programmatically
        uncertainty = []
        if not has_prd:
            uncertainty.append("No PRD provided — design intent not verified")
        if not has_code:
            uncertainty.append("No code provided — implementation risks not assessed")
        return UnifiedContext(
            has_idea=idea is not None,
            has_prd=False,
            has_code=False,
            intent=_normalize_unified_context_scalar(idea.core_intent if idea else None),
            design=None,
            implementation=None,
            combined_data_flows=idea.data_flows if idea else [],
            combined_ai_components=idea.ai_components if idea else [],
            combined_integrations=idea.external_integrations if idea else [],
            uncertainty_flags=uncertainty,
        )

    # Multi-input: use LLM to fuse
    idea_json = idea.model_dump_json(indent=2) if idea else "null"
    prd_json = prd.model_dump_json(indent=2) if prd else "null"
    code_json = code.model_dump_json(indent=2) if code else "null"
    prompt = format_prompt(
        "context_fusion",
        idea_json=idea_json,
        prd_json=prd_json,
        code_json=code_json,
    )
    try:
        raw = router_run("context_fusion", prompt, options={"temperature": 0.0})
        data = _normalize_unified_context_dict(extract_json(raw))
        return UnifiedContext(
            has_idea=idea is not None,
            has_prd=has_prd,
            has_code=has_code,
            **data,
        )
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[context_fusion] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 5 — Risk evaluation
# ---------------------------------------------------------------------------

def evaluate_risks(
    context: UnifiedContext, model_override: str | None = None
) -> RiskAnalysis:
    prompt = format_prompt(
        "risk_evaluator",
        unified_context_json=context.model_dump_json(indent=2),
    )
    try:
        raw = router_run("risk_evaluator", prompt, options={"temperature": 0.0, "model_override": model_override})
        payload = _normalize_risk_analysis_dict(extract_json(raw))
        return RiskAnalysis(**payload)
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[risk_evaluator] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 6 — Congruence evaluation
# ---------------------------------------------------------------------------

def evaluate_congruence(
    context: UnifiedContext, model_override: str | None = None
) -> CongruenceAnalysis:
    prompt = format_prompt(
        "congruence_evaluator",
        unified_context_json=context.model_dump_json(indent=2),
    )
    try:
        raw = router_run("congruence_evaluator", prompt, options={"temperature": 0.0, "model_override": model_override})
        payload = _normalize_congruence_analysis_dict(extract_json(raw))
        return CongruenceAnalysis(**payload)
    except JSONParseError:
        raise
    except Exception as exc:
        raise RuntimeError(f"[congruence_evaluator] failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Stage 7 — Assemble final analysis
# ---------------------------------------------------------------------------

def assemble_final_analysis(
    risk: RiskAnalysis,
    congruence: CongruenceAnalysis,
) -> FinalAnalysis:
    score = risk.risk_score
    if score >= 7.0:
        label = "HIGH"
        verdict = "Review before shipping"
    elif score >= 4.0:
        label = "MEDIUM"
        verdict = "Address flagged items before shipping"
    else:
        label = "LOW"
        verdict = "Proceed with standard review"

    total_gaps = (
        len(congruence.intent_design_gaps)
        + len(congruence.design_build_gaps)
        + len(congruence.intent_build_gaps)
        + len(congruence.drift_risks)
    )
    gap_note = f"{total_gaps} congruence gap(s) identified" if total_gaps else "No congruence gaps identified"

    verdict_upgraded = False
    if total_gaps >= 2 and verdict == "Proceed with standard review":
        verdict = "Address flagged items before shipping"
        label = "MEDIUM"
        verdict_upgraded = True
    if total_gaps >= 3 and verdict == "Address flagged items before shipping":
        verdict = "Review before shipping"
        label = "HIGH"
        verdict_upgraded = True

    summary = f"Risk score {score:.1f}/10 ({label}). {gap_note}."
    if verdict_upgraded:
        summary += f" Verdict upgraded due to {total_gaps} congruence gap(s)."

    return FinalAnalysis(
        risk_analysis=risk,
        congruence_analysis=congruence,
        overall_summary=summary,
        verdict=verdict,
    )


# ---------------------------------------------------------------------------
# Top-level entry points
# ---------------------------------------------------------------------------

def run_pipeline(
    idea_text: str | None = None,
    prd_text: str | None = None,
    code_text: str | None = None,
    model: str | None = None,
    risk_model: str | None = None,
    on_stage: object = None,
) -> PipelineResult:
    """
    Run the full VibeCheck pipeline with any combination of inputs.

    At least one of idea_text, prd_text, or code_text must be provided.
    model:      extraction/fusion model override
    risk_model: evaluation model override (defaults to model)
    on_stage:   optional callback(stage_name: str) called before each stage
    """
    eval_model = risk_model or model

    def _stage(name: str) -> None:
        if on_stage:
            on_stage(name)

    result = PipelineResult()

    # --- Extraction ---
    if idea_text:
        _stage("extract_idea")
        result.idea_schema = extract_idea(idea_text, model_override=model)

    if prd_text:
        _stage("extract_prd")
        result.prd_schema = extract_prd(prd_text, model_override=model)

    if code_text:
        _stage("extract_code")
        result.code_schema = extract_code(code_text, model_override=model)

    # --- Fusion ---
    _stage("fuse_context")
    result.unified_context = fuse_context(
        idea=result.idea_schema,
        prd=result.prd_schema,
        code=result.code_schema,
    )

    # --- Dual evaluation ---
    _stage("evaluate_risks")
    result.risk_analysis = evaluate_risks(result.unified_context, model_override=eval_model)

    _stage("evaluate_congruence")
    result.congruence_analysis = evaluate_congruence(result.unified_context, model_override=eval_model)

    # --- Assembly ---
    _stage("assemble_final_analysis")
    result.final_analysis = assemble_final_analysis(
        result.risk_analysis, result.congruence_analysis
    )

    # --- SIE (mac-orchestrator): structured engine_output (no interpretation here) ---
    _stage("sie_engine")
    sie_text = combined_text_for_sie(idea_text, prd_text, code_text)
    if sie_text.strip():
        result.engine_output = fetch_engine_output_from_sie(sie_text)
    else:
        result.engine_output = None

    return result


def run_idea_eval(
    idea_text: str,
    model_override: str | None = None,
) -> tuple[IdeaSchema, UnifiedContext, RiskAnalysis]:
    """
    Backwards-compatible entry point for idea-only evaluation.

    Returns (idea_schema, unified_context, risk_analysis) matching the
    previous (idea_schema, fused_context, risk_analysis) tuple shape.
    """
    result = run_pipeline(idea_text=idea_text, model=model_override)
    return result.idea_schema, result.unified_context, result.risk_analysis
