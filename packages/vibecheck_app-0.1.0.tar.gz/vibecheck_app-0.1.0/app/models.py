from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class RiskCategory(str, Enum):
    DATA_PRIVACY = "Data & Privacy Risk"
    OUTPUT_DECISION = "Output & Decision Risk"
    AUTONOMY_CONTROL = "Autonomy & Control Risk"
    SAFEGUARDS_GAPS = "Safeguards & Control Gaps"
    ALIGNMENT_CONSISTENCY = "Alignment & Consistency Risk"
    ABUSE_MISUSE = "Abuse & Misuse Risk"


class Severity(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Risk(BaseModel):
    category: RiskCategory
    description: str
    severity: Severity
    conditional: bool = False
    condition_note: Optional[str] = None


# ---------------------------------------------------------------------------
# Extractor schemas
# ---------------------------------------------------------------------------

class IdeaSchema(BaseModel):
    core_intent: str
    target_users: list[str] = Field(default_factory=list)
    ai_components: list[str] = Field(default_factory=list)
    data_flows: list[str] = Field(default_factory=list)
    deployment_context: Optional[str] = None
    external_integrations: list[str] = Field(default_factory=list)
    key_assumptions: list[str] = Field(default_factory=list)


class PRDSchema(BaseModel):
    features: list[str] = Field(default_factory=list)
    user_interactions: list[str] = Field(default_factory=list)
    data_handling: list[str] = Field(default_factory=list)
    integrations: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    out_of_scope: list[str] = Field(default_factory=list)


class CodeSchema(BaseModel):
    components: list[str] = Field(default_factory=list)
    api_calls: list[str] = Field(default_factory=list)
    data_access_patterns: list[str] = Field(default_factory=list)
    error_handling: list[str] = Field(default_factory=list)
    security_controls: list[str] = Field(default_factory=list)
    notable_patterns: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Context fusion
# ---------------------------------------------------------------------------

class UnifiedContext(BaseModel):
    """Fused view of all available inputs, used by both evaluation engines."""
    has_idea: bool = False
    has_prd: bool = False
    has_code: bool = False
    intent: Optional[str] = None          # derived from idea
    design: Optional[str] = None          # derived from PRD
    implementation: Optional[str] = None  # derived from code
    combined_data_flows: list[str] = Field(default_factory=list)
    combined_ai_components: list[str] = Field(default_factory=list)
    combined_integrations: list[str] = Field(default_factory=list)
    uncertainty_flags: list[str] = Field(default_factory=list)


# Backwards-compat alias — remove after benchmark runner is updated
FusedContext = UnifiedContext


# ---------------------------------------------------------------------------
# Evaluation outputs
# ---------------------------------------------------------------------------

class RiskAnalysis(BaseModel):
    """What can go wrong? — risk identification layer."""
    system_risks: list[Risk] = Field(default_factory=list)
    missing_safeguards: list[str] = Field(default_factory=list)
    quick_fixes: list[str] = Field(default_factory=list)
    risk_score: float = Field(ge=0.0, le=10.0)
    risk_score_rationale: str = ""
    analysis_notes: list[str] = Field(default_factory=list)


class CongruenceAnalysis(BaseModel):
    """Does the system behave as intended? — intent/design/build alignment layer."""
    intent_design_gaps: list[str] = Field(default_factory=list)   # idea vs PRD
    design_build_gaps: list[str] = Field(default_factory=list)    # PRD vs code
    intent_build_gaps: list[str] = Field(default_factory=list)    # idea vs code
    drift_risks: list[str] = Field(default_factory=list)          # compounding misalignment
    congruence_notes: list[str] = Field(default_factory=list)     # e.g. "idea-only mode"


class FinalAnalysis(BaseModel):
    """Assembled output from both evaluation engines."""
    risk_analysis: RiskAnalysis
    congruence_analysis: CongruenceAnalysis
    overall_summary: str = ""
    verdict: str = ""


# ---------------------------------------------------------------------------
# Pipeline result envelope
# ---------------------------------------------------------------------------

class PipelineResult(BaseModel):
    idea_schema: Optional[IdeaSchema] = None
    prd_schema: Optional[PRDSchema] = None
    code_schema: Optional[CodeSchema] = None
    unified_context: Optional[UnifiedContext] = None
    risk_analysis: Optional[RiskAnalysis] = None
    congruence_analysis: Optional[CongruenceAnalysis] = None
    final_analysis: Optional[FinalAnalysis] = None
    # mac-orchestrator (SIE) payload when ``fetch_engine_output_from_sie`` succeeds
    engine_output: Optional[dict] = None
