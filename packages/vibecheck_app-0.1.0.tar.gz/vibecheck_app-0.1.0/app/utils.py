from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


# ---------------------------------------------------------------------------
# Input helpers
# ---------------------------------------------------------------------------

def read_input(value: str) -> str:
    """Read from a file path if it exists, otherwise treat the value as raw text."""
    path = Path(value)
    if path.exists() and path.is_file():
        return path.read_text(encoding="utf-8")
    return value


def truncate_text(text: str, max_chars: int = 12_000) -> str:
    """Truncate long inputs so they fit within model context limits."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + f"\n\n[...truncated at {max_chars} characters]"


# ---------------------------------------------------------------------------
# JSON extraction and repair
# ---------------------------------------------------------------------------

class JSONParseError(ValueError):
    """
    Raised when JSON extraction and all repair attempts fail.

    Carries the full diagnostic state so the CLI (or any caller) can display
    exactly what the model returned and where parsing broke.
    """
    def __init__(self, message: str, *, raw: str, candidate: str, error: str) -> None:
        super().__init__(message)
        self.raw = raw          # original LLM response text
        self.candidate = candidate  # extracted + repaired text that was parsed
        self.error = error      # json.JSONDecodeError description


def _find_largest_json_block(text: str) -> str | None:
    """
    Walk the text and return the largest balanced JSON object or array found.

    Unlike simple find/rfind, this correctly handles nested structures and
    avoids being fooled by braces or brackets inside string values.
    """
    best: str | None = None
    best_len = 0

    for opener, closer in [('{', '}'), ('[', ']')]:
        search_from = 0
        while True:
            pos = text.find(opener, search_from)
            if pos == -1:
                break

            depth = 0
            in_string = False
            escape_next = False
            end = -1

            for i in range(pos, len(text)):
                ch = text[i]
                if escape_next:
                    escape_next = False
                    continue
                if ch == '\\' and in_string:
                    escape_next = True
                    continue
                if ch == '"':
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == opener:
                    depth += 1
                elif ch == closer:
                    depth -= 1
                    if depth == 0:
                        end = i
                        break

            if end != -1:
                block = text[pos : end + 1]
                if len(block) > best_len:
                    best = block
                    best_len = len(block)

            search_from = pos + 1

    return best


def _repair_json(text: str) -> str:
    """
    Apply lightweight, non-destructive repairs for common local-model JSON issues.

    Repairs applied (in order):
      1. Single-line // comments          → removed
      2. Python literals True/False/None  → JSON true/false/null
      3. Trailing commas before } or ]    → removed

    Intentional non-repairs:
      - Does NOT invent missing fields
      - Does NOT fix truncated or structurally broken JSON
      - Does NOT reorder or rename keys
    """
    # 1. Single-line // comments (not inside strings — good enough for typical output)
    text = re.sub(r'//[^\n"]*(?=\n|$)', '', text)

    # 2. Python literals → JSON literals (word-boundary match avoids touching strings)
    text = re.sub(r'\bTrue\b', 'true', text)
    text = re.sub(r'\bFalse\b', 'false', text)
    text = re.sub(r'\bNone\b', 'null', text)

    # 3. Trailing commas before } or ] (with optional whitespace between)
    text = re.sub(r',\s*([}\]])', r'\1', text)

    return text


def extract_json(text: str) -> Any:
    """
    Extract and return a parsed JSON value from an LLM response.

    Strategy (each step only runs if the previous one fails):
      1. Strip markdown code fences
      2. Direct parse — fast path for clean responses
      3. Find the largest balanced JSON block in the text
      4. Parse the extracted block as-is
      5. Repair the block (_repair_json) then parse again

    Raises:
        JSONParseError: if all attempts fail, carrying the raw response,
                        the repaired candidate, and the exact parse error.
    """
    raw = text

    # Step 1 — strip markdown fences
    fence = re.search(r"```(?:json)?\s*\n?([\s\S]*?)\n?```", text)
    if fence:
        text = fence.group(1)
    text = text.strip()

    # Step 2 — direct parse (model output is already clean JSON)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    # Step 3 — find the largest balanced block
    candidate = _find_largest_json_block(text)
    if candidate is None:
        candidate = text

    # Step 4 — parse extracted block
    try:
        return json.loads(candidate)
    except json.JSONDecodeError:
        pass

    # Step 5 — repair then parse
    repaired = _repair_json(candidate)
    try:
        return json.loads(repaired)
    except json.JSONDecodeError as exc:
        raise JSONParseError(
            "JSON extraction and repair both failed",
            raw=raw,
            candidate=repaired,
            error=f"{exc.msg} (line {exc.lineno}, col {exc.colno}, pos {exc.pos})",
        ) from exc
