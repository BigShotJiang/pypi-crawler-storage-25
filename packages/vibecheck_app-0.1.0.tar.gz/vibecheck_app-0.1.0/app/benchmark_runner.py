import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from rich.console import Console
from rich.rule import Rule
from rich.table import Table

from .models import FinalAnalysis, PipelineResult, Risk, RiskCategory
from .pipeline import run_pipeline

BENCHMARKS_DIR = Path(__file__).resolve().parent.parent / "benchmarks"

# Default suite: baseline v1 — five tracked cases (repeatable refinement loop).
DEFAULT_SUITE_FILENAMES: tuple[str, ...] = (
    "email_summarizer_idea_only.json",
    "customer_auto_reply_idea_only.json",
    "medical_notes_summarizer_idea_only.json",
    "email_summarizer_with_prd.json",
    "medical_notes_with_prd_and_code.json",
)

# Short names / aliases → RiskCategory (structured domain checks).
_CATEGORY_ALIASES: dict[str, RiskCategory] = {
    "privacy": RiskCategory.DATA_PRIVACY,
    "data_privacy": RiskCategory.DATA_PRIVACY,
    "output": RiskCategory.OUTPUT_DECISION,
    "output_decision": RiskCategory.OUTPUT_DECISION,
    "autonomy": RiskCategory.AUTONOMY_CONTROL,
    "autonomy_control": RiskCategory.AUTONOMY_CONTROL,
    "safeguards": RiskCategory.SAFEGUARDS_GAPS,
    "safeguards_gaps": RiskCategory.SAFEGUARDS_GAPS,
    "alignment": RiskCategory.ALIGNMENT_CONSISTENCY,
    "alignment_consistency": RiskCategory.ALIGNMENT_CONSISTENCY,
    "abuse": RiskCategory.ABUSE_MISUSE,
    "abuse_misuse": RiskCategory.ABUSE_MISUSE,
}


def _category_from_token(token: str) -> Optional[RiskCategory]:
    key = token.lower().strip().replace(" ", "_").replace("-", "_")
    return _CATEGORY_ALIASES.get(key)


# Zones for legacy substring-over-JSON checks.
_STRUCTURED_ZONES = frozenset({"final", "risk_analysis", "congruence", "system_risks"})


# ---------------------------------------------------------------------------
# Data classes for benchmark cases and results
# ---------------------------------------------------------------------------


@dataclass
class BenchmarkCase:
    id: str
    name: str
    description: str
    inputs: dict
    expected: dict
    notes: str = ""

    @classmethod
    def from_dict(cls, data: dict) -> "BenchmarkCase":
        bid = data["id"]
        return cls(
            id=bid,
            name=data.get("name") or bid,
            description=data.get("description", ""),
            notes=data.get("notes", ""),
            inputs=data.get("inputs", {}),
            expected=data.get("expected", {}),
        )


@dataclass
class CheckResult:
    label: str
    passed: bool
    detail: str = ""
    non_blocking: bool = False


@dataclass
class BenchmarkResult:
    case_id: str
    case_name: str
    description: str
    passed: bool
    risk_score: Optional[float]
    checks: list[CheckResult] = field(default_factory=list)
    error: Optional[str] = None
    notes: str = ""


# ---------------------------------------------------------------------------
# File helpers
# ---------------------------------------------------------------------------


def list_benchmark_files() -> list[Path]:
    """All `*.json` directly under benchmarks/ (excludes subfolders)."""
    return sorted(BENCHMARKS_DIR.glob("*.json"))


def load_benchmark_file(path: Path) -> list[BenchmarkCase]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    items = raw if isinstance(raw, list) else [raw]
    return [BenchmarkCase.from_dict(item) for item in items]


def resolve_benchmark_paths(
    benchmark_file: Optional[Path],
    *,
    all_json: bool,
) -> list[Path]:
    if benchmark_file is not None:
        return [benchmark_file]
    if all_json:
        return list_benchmark_files()
    paths = [BENCHMARKS_DIR / name for name in DEFAULT_SUITE_FILENAMES]
    missing = [p for p in paths if not p.exists()]
    if missing:
        names = ", ".join(p.name for p in missing)
        raise FileNotFoundError(
            f"Default benchmark suite is missing file(s): {names} "
            f"(expected under {BENCHMARKS_DIR})"
        )
    return paths


# ---------------------------------------------------------------------------
# Evaluation logic
# ---------------------------------------------------------------------------


def _risk_score_band(score: float) -> str:
    if score >= 7.0:
        return "high"
    if score >= 4.0:
        return "medium"
    return "low"


def _structured_zone_blob(final: FinalAnalysis, zone: str) -> str:
    z = zone.lower().replace("-", "_")
    if z not in _STRUCTURED_ZONES:
        z = "final"
    if z == "final":
        blob = final.model_dump()
    elif z == "risk_analysis":
        blob = final.risk_analysis.model_dump()
    elif z == "congruence":
        blob = final.congruence_analysis.model_dump()
    else:
        blob = [r.model_dump() for r in final.risk_analysis.system_risks]
    return json.dumps(blob, default=str).lower()


def _idea_schema_blob(result: PipelineResult) -> str:
    if not result.idea_schema:
        return ""
    return json.dumps(result.idea_schema.model_dump(), default=str).lower()


def _unified_context_blob(result: PipelineResult) -> str:
    if not result.unified_context:
        return ""
    return json.dumps(result.unified_context.model_dump(), default=str).lower()


def _system_risk_combined_fields(risk: Risk, fields: list[str]) -> str:
    parts: list[str] = []
    for f in fields:
        v = getattr(risk, f, None)
        if v:
            parts.append(str(v))
    return " ".join(parts).lower()


def _system_risks_match_substrings(
    risks: list[Risk],
    fields: list[str],
    tokens: list[str],
) -> tuple[bool, str]:
    """
    True if any token appears as a substring in any risk's selected fields
    (description / condition_note, etc.). Tokens are compared case-insensitively.
    """
    if not tokens:
        return False, ""
    for r in risks:
        hay = _system_risk_combined_fields(r, fields)
        for t in tokens:
            if t in hay:
                return True, t
    return False, ""


def _normalize_match_tokens(srm: dict) -> list[str]:
    """Union of match_any (preferred name) and legacy any_substring; de-duplicated."""
    raw: list[str] = []
    for key in ("match_any", "any_substring"):
        chunk = srm.get(key)
        if isinstance(chunk, list):
            raw.extend(str(x) for x in chunk if x is not None)
        elif chunk is not None and chunk != "":
            raw.append(str(chunk))
    seen: set[str] = set()
    out: list[str] = []
    for x in raw:
        t = x.lower().strip()
        if not t or t in seen:
            continue
        seen.add(t)
        out.append(t)
    return out


def _risk_score_expected_bounds(expected: dict) -> Optional[tuple[float, float, str]]:
    if expected.get("risk_score_min") is not None or expected.get("risk_score_max") is not None:
        lo = float(expected["risk_score_min"]) if expected.get("risk_score_min") is not None else 0.0
        hi = float(expected["risk_score_max"]) if expected.get("risk_score_max") is not None else 10.0
        return lo, hi, f"[{lo:.1f}, {hi:.1f}]"
    if expected.get("risk_score") is not None:
        mid = float(expected["risk_score"])
        tol = float(expected.get("risk_score_tolerance", 1.0))
        lo, hi = mid - tol, mid + tol
        return lo, hi, f"target {mid:.1f} ± {tol:.1f} → [{lo:.1f}, {hi:.1f}]"
    return None


def structured_validation_checks(
    spec: dict,
    final: FinalAnalysis,
    pipeline_result: PipelineResult,
    case: BenchmarkCase,
) -> list[CheckResult]:
    """
    Primary checks on FinalAnalysis + pipeline artifacts (Pydantic JSON paths).
    See README / expected["structured"] schema.
    """
    out: list[CheckResult] = []
    if not spec:
        return out

    rs = final.risk_analysis.risk_score
    risks = final.risk_analysis.system_risks

    score_keys = ("risk_score", "risk_score_tolerance", "risk_score_min", "risk_score_max")
    if any(spec.get(k) is not None for k in score_keys):
        bounds = _risk_score_expected_bounds(spec)
    else:
        bounds = None
    if bounds is not None:
        lo, hi, label = bounds
        ok = lo <= rs <= hi
        out.append(
            CheckResult(
                label=f"structured risk_score ({label})",
                passed=ok,
                detail=f"actual {rs:.2f}",
            )
        )

    band = spec.get("risk_score_band")
    if band is not None:
        want = str(band).lower()
        got = _risk_score_band(rs)
        ok = got == want
        out.append(
            CheckResult(
                label=f"structured risk_score_band == {want!r}",
                passed=ok,
                detail=f"actual band {got!r} (score {rs:.2f})",
            )
        )

    between = spec.get("risk_score_between")
    if between is not None and isinstance(between, (list, tuple)) and len(between) == 2:
        lo, hi = float(between[0]), float(between[1])
        ok = lo <= rs <= hi
        out.append(
            CheckResult(
                label=f"structured risk_score_between [{lo:.1f}, {hi:.1f}]",
                passed=ok,
                detail=f"actual {rs:.2f}",
            )
        )

    key = "any_system_risk_conditional"
    if key in spec:
        want = bool(spec[key])
        got = any(r.conditional for r in risks)
        ok = got is want
        out.append(
            CheckResult(
                label=f"structured {key} == {want}",
                passed=ok,
                detail=f"actual {got}",
            )
        )

    mcr = spec.get("min_conditional_risks")
    if mcr is not None:
        n = sum(1 for r in risks if r.conditional)
        ok = n >= int(mcr)
        out.append(
            CheckResult(
                label=f"structured min_conditional_risks >= {mcr}",
                passed=ok,
                detail=f"actual {n}",
            )
        )

    msr = spec.get("min_system_risks")
    if msr is not None:
        ok = len(risks) >= int(msr)
        out.append(
            CheckResult(
                label=f"structured min_system_risks >= {msr}",
                passed=ok,
                detail=f"actual {len(risks)}",
            )
        )

    cats_any = spec.get("risk_categories_any")
    if cats_any:
        want = {_category_from_token(t) for t in cats_any}
        want.discard(None)
        have = {r.category for r in risks}
        ok = bool(have & want) if want else True
        out.append(
            CheckResult(
                label=f"structured risk_categories_any {list(cats_any)!r}",
                passed=ok,
                detail=f"present {sorted(c.value for c in have)}",
            )
        )

    cats_all = spec.get("risk_categories_all")
    if cats_all:
        want = {_category_from_token(t) for t in cats_all}
        want.discard(None)
        have = {r.category for r in risks}
        ok = want <= have if want else True
        out.append(
            CheckResult(
                label=f"structured risk_categories_all {list(cats_all)!r}",
                passed=ok,
                detail=f"present {sorted(c.value for c in have)}",
            )
        )

    idea_any = spec.get("idea_schema_substrings_any") or spec.get("capability_idea_hints_any")
    if idea_any:
        blob = _idea_schema_blob(pipeline_result)
        subs = [str(s).lower() for s in idea_any if s]
        matched = [s for s in subs if s in blob]
        ok = bool(matched)
        out.append(
            CheckResult(
                label="structured idea_schema_substrings_any",
                passed=ok,
                detail=f"matched {matched!r}" if matched else f"need any of {subs!r}",
            )
        )

    uc_any = spec.get("unified_context_substrings_any")
    if uc_any:
        blob = _unified_context_blob(pipeline_result)
        subs = [str(s).lower() for s in uc_any if s]
        matched = [s for s in subs if s in blob]
        ok = bool(matched)
        out.append(
            CheckResult(
                label="structured unified_context_substrings_any",
                passed=ok,
                detail=f"matched {matched!r}" if matched else f"need any of {subs!r}",
            )
        )

    code_in = case.inputs.get("code")
    code_any = spec.get("code_input_substrings_any")
    if code_any and code_in:
        low = str(code_in).lower()
        subs = [str(s).lower() for s in code_any if s]
        matched = [s for s in subs if s in low]
        ok = bool(matched)
        out.append(
            CheckResult(
                label="structured code_input_substrings_any",
                passed=ok,
                detail=f"matched {matched!r}" if matched else f"need any of {subs!r}",
            )
        )

    srm = spec.get("system_risks_match") or spec.get("system_risks_field_match_any")
    if isinstance(srm, dict):
        fields = srm.get("in_fields", ["description", "condition_note"])
        if not isinstance(fields, list):
            fields = ["description", "condition_note"]
        subs = _normalize_match_tokens(srm)
        if subs:
            matched_risk, which = _system_risks_match_substrings(risks, fields, subs)
            out.append(
                CheckResult(
                    label=f"structured system_risks_match fields={fields!r}",
                    passed=matched_risk,
                    detail=f"hit {which!r} in system_risk text" if matched_risk else f"need any of {subs!r}",
                )
            )

    cmin = spec.get("congruence_lists_min")
    if isinstance(cmin, dict):
        cong = final.congruence_analysis
        for attr, need in cmin.items():
            lst = getattr(cong, attr, None) or []
            n = len(lst)
            ok = n >= int(need)
            out.append(
                CheckResult(
                    label=f"structured congruence_lists_min {attr}>={need}",
                    passed=ok,
                    detail=f"actual {n}",
                )
            )

    c_nonempty = spec.get("congruence_nonempty_total")
    if isinstance(c_nonempty, dict):
        keys = c_nonempty.get("lists", [])
        need = int(c_nonempty.get("min_total", 1))
        cong = final.congruence_analysis
        total = sum(len(getattr(cong, k, None) or []) for k in keys if isinstance(k, str))
        ok = total >= need
        out.append(
            CheckResult(
                label=f"structured congruence_nonempty_total >= {need}",
                passed=ok,
                detail=f"count {total} in {keys!r}",
            )
        )

    cmax = spec.get("congruence_lists_max")
    if isinstance(cmax, dict):
        cong = final.congruence_analysis
        for attr, cap in cmax.items():
            lst = getattr(cong, attr, None) or []
            n = len(lst)
            limit = int(cap)
            ok = n <= limit
            out.append(
                CheckResult(
                    label=f"structured congruence_lists_max {attr}<={limit}",
                    passed=ok,
                    detail=f"actual {n}",
                )
            )

    for i, item in enumerate(spec.get("concepts", [])):
        if not isinstance(item, dict):
            continue
        sub = str(item.get("substring", "")).lower()
        if not sub:
            continue
        within = str(item.get("within", "final")).lower()
        hay = _structured_zone_blob(final, within)
        ok = sub in hay
        out.append(
            CheckResult(
                label=f'structured legacy concept {i + 1}: "{item.get("substring")}" in {within!r}',
                passed=ok,
                detail="found" if ok else "missing",
            )
        )

    return out


def _analysis_to_text(final: FinalAnalysis) -> str:
    risk = final.risk_analysis
    cong = final.congruence_analysis
    parts: list[str] = []
    for r in risk.system_risks:
        parts.append(r.description)
        parts.append(r.category.value)
        if r.condition_note:
            parts.append(r.condition_note)
    parts.extend(risk.missing_safeguards)
    parts.extend(risk.quick_fixes)
    parts.extend(risk.analysis_notes)
    parts.append(risk.risk_score_rationale)
    parts.extend(cong.intent_design_gaps)
    parts.extend(cong.design_build_gaps)
    parts.extend(cong.intent_build_gaps)
    parts.extend(cong.drift_risks)
    parts.extend(cong.congruence_notes)
    parts.append(final.overall_summary)
    parts.append(final.verdict)
    return " ".join(parts).lower()


def _must_include_any_group(
    group: list,
    index: int,
    final: FinalAnalysis,
    analysis_text: str,
) -> CheckResult:
    alts = [str(x).strip() for x in group if x is not None and str(x).strip()]
    if not alts:
        return CheckResult(
            label=f"text must_include_any #{index + 1}",
            passed=True,
            detail="(empty group — skipped)",
        )
    matched: Optional[str] = None
    for a in alts:
        if _must_include_resolved(a, final, analysis_text):
            matched = a
            break
    preview = ", ".join(alts[:4]) + ("…" if len(alts) > 4 else "")
    return CheckResult(
        label=f'text must_include_any #{index + 1} (one of: {preview})',
        passed=matched is not None,
        detail=f"matched {matched!r}" if matched else "no alternative matched",
    )


def _must_include_resolved(concept: str, final: FinalAnalysis, analysis_text: str) -> bool:
    c = concept.lower().strip()
    if c in analysis_text:
        return True
    if c == "conditional":
        return any(r.conditional for r in final.risk_analysis.system_risks)
    return False


def _legacy_score_bounds_only(expected: dict) -> Optional[tuple[float, float, str]]:
    """Top-level risk_score fields when not duplicated in structured."""
    st = expected.get("structured")
    score_keys = ("risk_score", "risk_score_tolerance", "risk_score_min", "risk_score_max", "risk_score_between")
    if isinstance(st, dict) and any(st.get(k) is not None for k in score_keys):
        return None
    return _risk_score_expected_bounds(expected)


def _apply_known_non_blocking(checks: list[CheckResult], tokens: object) -> None:
    """Mark failed checks whose label matches expected.known_non_blocking substrings."""
    if not isinstance(tokens, list) or not checks:
        return
    needles = [str(t).lower().strip() for t in tokens if t is not None and str(t).strip()]
    if not needles:
        return
    for c in checks:
        if c.passed:
            continue
        lab = c.label.lower()
        if any(n in lab for n in needles):
            c.non_blocking = True


def evaluate_case(
    case: BenchmarkCase,
    model: Optional[str] = None,
    risk_model: Optional[str] = None,
    on_stage=None,
) -> BenchmarkResult:
    checks: list[CheckResult] = []

    note_parts = [case.notes.strip(), case.expected.get("notes", "").strip()]
    merged_notes = " ".join(p for p in note_parts if p)

    try:
        pipeline_result = run_pipeline(
            idea_text=case.inputs.get("idea"),
            prd_text=case.inputs.get("prd"),
            code_text=case.inputs.get("code"),
            model=model,
            risk_model=risk_model,
            on_stage=on_stage,
        )
    except Exception as exc:
        return BenchmarkResult(
            case_id=case.id,
            case_name=case.name,
            description=case.description,
            passed=False,
            risk_score=None,
            error=str(exc),
            notes=merged_notes,
        )

    final = pipeline_result.final_analysis
    if not final:
        return BenchmarkResult(
            case_id=case.id,
            case_name=case.name,
            description=case.description,
            passed=False,
            risk_score=None,
            error="Pipeline returned no final analysis.",
            notes=merged_notes,
        )

    risk_score = final.risk_analysis.risk_score

    # --- Primary: structured validation (FinalAnalysis + pipeline artifacts) ---
    structured_spec = case.expected.get("structured")
    if isinstance(structured_spec, dict):
        checks.extend(structured_validation_checks(structured_spec, final, pipeline_result, case))

    # --- Primary: top-level score if not already in structured ---
    bounds = _legacy_score_bounds_only(case.expected)
    if bounds is not None:
        lo, hi, label = bounds
        ok = lo <= risk_score <= hi
        checks.append(
            CheckResult(
                label=f"risk_score ({label}) [expected root]",
                passed=ok,
                detail=f"actual {risk_score:.2f}",
            )
        )

    # --- Secondary: optional text checks ---
    analysis_text = _analysis_to_text(final)
    run_text = bool(case.expected.get("text_checks", False))
    if run_text:
        for concept in case.expected.get("must_include", []):
            found = _must_include_resolved(concept, final, analysis_text)
            checks.append(
                CheckResult(
                    label=f'text must_include "{concept}"',
                    passed=found,
                    detail="found" if found else "missing",
                )
            )
        for gi, group in enumerate(case.expected.get("must_include_any", [])):
            if isinstance(group, (list, tuple)):
                checks.append(_must_include_any_group(list(group), gi, final, analysis_text))

    # --- Anti-hallucination: substring bans on full rendered analysis (default on) ---
    anti = case.expected.get("must_not_include") or []
    if anti:
        for concept in anti:
            found = concept.lower() in analysis_text
            checks.append(
                CheckResult(
                    label=f'text anti_hallucination must_not_include "{concept}"',
                    passed=not found,
                    detail="absent (good)" if not found else "found (bad)",
                )
            )

    _apply_known_non_blocking(checks, case.expected.get("known_non_blocking"))

    overall_passed = all(c.passed or c.non_blocking for c in checks) if checks else True

    return BenchmarkResult(
        case_id=case.id,
        case_name=case.name,
        description=case.description,
        passed=overall_passed,
        risk_score=risk_score,
        checks=checks,
        notes=merged_notes,
    )


def run_benchmark_suite(
    benchmark_file: Optional[Path] = None,
    *,
    all_json: bool = False,
    model: Optional[str] = None,
    risk_model: Optional[str] = None,
    on_case: Optional[callable] = None,
    on_stage: Optional[callable] = None,
) -> list[BenchmarkResult]:
    paths = resolve_benchmark_paths(benchmark_file, all_json=all_json)
    results: list[BenchmarkResult] = []
    for path in paths:
        for case in load_benchmark_file(path):
            if on_case:
                on_case(case.id, case.description)
            result = evaluate_case(
                case,
                model=model,
                risk_model=risk_model,
                on_stage=on_stage,
            )
            results.append(result)

    return results


def print_benchmark_report(results: list[BenchmarkResult], console: Console) -> None:
    console.print()
    console.print(Rule("[bold]VibeCheck — benchmark suite[/bold]"))

    passed_n = sum(1 for r in results if r.passed and not r.error)
    total = len(results)
    for r in results:
        console.print()
        if r.error:
            console.print(f"[bold red]✗[/bold red] [cyan]{r.case_id}[/cyan] — {r.case_name}")
            console.print(f"  [red]error:[/red] {r.error}")
            if r.notes:
                console.print(f"  [dim]{r.notes}[/dim]")
            continue

        status = "[bold green]✓ PASS[/bold green]" if r.passed else "[bold red]✗ FAIL[/bold red]"
        console.print(f"{status} [cyan]{r.case_id}[/cyan] — {r.case_name}")
        if r.description:
            console.print(f"  [dim]{r.description}[/dim]")
        if r.risk_score is not None:
            console.print(f"  [bold]risk_score[/bold] actual [yellow]{r.risk_score:.2f}[/yellow]")
        if r.notes:
            console.print(f"  [dim]notes:[/dim] {r.notes}")

        tbl = Table(show_header=True, header_style="bold")
        tbl.add_column("check")
        tbl.add_column("ok", justify="center")
        tbl.add_column("detail")
        for c in r.checks:
            if c.passed:
                ok_txt = "[green]yes[/green]"
            elif c.non_blocking:
                ok_txt = "[yellow]nb[/yellow]"
            else:
                ok_txt = "[red]no[/red]"
            detail = c.detail
            if c.non_blocking and not c.passed:
                detail = f"{detail} (known non-blocking)"
            tbl.add_row(c.label, ok_txt, detail)
        console.print(tbl)

    console.print()
    fail_n = total - passed_n
    if fail_n:
        console.print(f"[bold]Summary:[/bold] [green]{passed_n}/{total} passed[/green]  [red]({fail_n} failed)[/red]")
    else:
        console.print(f"[bold]Summary:[/bold] [green]{passed_n}/{total} passed[/green]")
    console.print()
