"""
Console entry for the `vibecheck` command.

Loads before `app` so we can put the project root on sys.path. This fixes
editable installs where the `app` meta-path hook is missing or the console
script runs before sitecustomize applies.
"""
from __future__ import annotations

import sys
from pathlib import Path


def main() -> int | None:
    # Project root = parent of this package (…/VibeCheck/vibecheck_launcher → …/VibeCheck)
    root = str(Path(__file__).resolve().parent.parent)
    if root not in sys.path:
        sys.path.insert(0, root)
    from app.cli import app

    return app()
