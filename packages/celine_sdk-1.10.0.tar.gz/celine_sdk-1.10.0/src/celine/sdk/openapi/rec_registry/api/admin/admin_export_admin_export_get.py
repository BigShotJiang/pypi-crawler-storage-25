from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    community: list[str] | None | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_community: list[str] | None | Unset
    if isinstance(community, Unset):
        json_community = UNSET
    elif isinstance(community, list):
        json_community = community

    else:
        json_community = community
    params["community"] = json_community

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/admin/export",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | str | None:
    if response.status_code == 200:
        response_200 = response.text
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    community: list[str] | None | Unset = UNSET,
) -> Response[HTTPValidationError | str]:
    """Admin Export

     Export one or more communities to YAML format.

    Pass `community` once per key to export specific communities.
    Omit `community` entirely to export all communities.
    Returns a multidocument YAML string (documents separated by `---`).

    Args:
        community (list[str] | None | Unset): Community key(s) to export; omit to export all

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        community=community,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    community: list[str] | None | Unset = UNSET,
) -> HTTPValidationError | str | None:
    """Admin Export

     Export one or more communities to YAML format.

    Pass `community` once per key to export specific communities.
    Omit `community` entirely to export all communities.
    Returns a multidocument YAML string (documents separated by `---`).

    Args:
        community (list[str] | None | Unset): Community key(s) to export; omit to export all

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return sync_detailed(
        client=client,
        community=community,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    community: list[str] | None | Unset = UNSET,
) -> Response[HTTPValidationError | str]:
    """Admin Export

     Export one or more communities to YAML format.

    Pass `community` once per key to export specific communities.
    Omit `community` entirely to export all communities.
    Returns a multidocument YAML string (documents separated by `---`).

    Args:
        community (list[str] | None | Unset): Community key(s) to export; omit to export all

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        community=community,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    community: list[str] | None | Unset = UNSET,
) -> HTTPValidationError | str | None:
    """Admin Export

     Export one or more communities to YAML format.

    Pass `community` once per key to export specific communities.
    Omit `community` entirely to export all communities.
    Returns a multidocument YAML string (documents separated by `---`).

    Args:
        community (list[str] | None | Unset): Community key(s) to export; omit to export all

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return (
        await asyncio_detailed(
            client=client,
            community=community,
        )
    ).parsed
