"""Tests for `harnesdk` package."""

import harnesdk


def test_import():
    """Verify the package can be imported."""
    assert harnesdk
