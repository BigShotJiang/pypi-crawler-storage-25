# Installation

## Stable release

To install harnesdk, run this command in your terminal:

```sh
uv add harnesdk
```

Or if you prefer to use `pip`:

```sh
pip install harnesdk
```

## From source

The source files for harnesdk can be downloaded from the [Github repo](https://github.com/alaeddine-13/harnesdk).

You can either clone the public repository:

```sh
git clone https://github.com/alaeddine-13/harnesdk
```

Or download the [tarball](https://github.com/alaeddine-13/harnesdk/tarball/main):

```sh
curl -OJL https://github.com/alaeddine-13/harnesdk/tarball/main
```

Once you have a copy of the source, you can install it with:

```sh
cd harnesdk
uv sync
```
