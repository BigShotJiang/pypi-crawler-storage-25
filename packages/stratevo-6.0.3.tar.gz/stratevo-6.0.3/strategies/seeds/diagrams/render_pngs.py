"""Render strategy flowcharts as PNG using matplotlib with hand-drawn style."""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch
import os

# Use xkcd style for hand-drawn look
plt.xkcd(scale=1.5, length=100, randomness=2)

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))

strategies = [
    {
        "file": "bollinger_flow",
        "title": "Bollinger Squeeze Reversal Strategy",
        "steps": [
            ("filter", "BB Width < 20d Low\n(Squeeze Detected)"),
            ("check", "Price touches\nlower band?"),
            ("check", "Volume > 1.5x avg?"),
            ("buy", "BUY\n(Mean Reversion Play)"),
            ("exit", "EXIT @ middle band\nor stop loss hit"),
        ],
        "notes": [
            "Key: Low volatility squeeze → touches lower band + volume = reversal",
            "Source: John Bollinger | Best in range-bound markets"
        ]
    },
    {
        "file": "macd_flow",
        "title": "MACD Volume Momentum Strategy",
        "steps": [
            ("filter", "Price > MA(50)\n(Uptrend Confirmed)"),
            ("check", "MACD golden cross?\n(MACD > Signal)"),
            ("check", "Volume > 2x average?"),
            ("buy", "BUY\n(Momentum Entry)"),
            ("check", "MACD death cross\nor volume fades?"),
            ("exit", "SELL\n(Momentum Lost)"),
        ],
        "notes": [
            "Key: Triple confirmation — Trend + MACD cross + Volume surge",
            "Source: Gerald Appel (1979) | Best in trending markets"
        ]
    },
    {
        "file": "value_quality_flow",
        "title": "Value-Quality-Momentum (Fama-French)",
        "steps": [
            ("filter", "Screen: Low PE + High ROE\n+ Positive 6M Return"),
            ("confirm", "Composite Score\n= Value + Quality + Momentum"),
            ("buy", "Rank all stocks\nBuy Top 5 scorers"),
            ("filter", "Hold 20 days\nRebalance monthly"),
            ("exit", "EXIT: Score drops\nor stop loss (8%)"),
        ],
        "notes": [
            "Key: Three-factor model — cheap + profitable + trending = proven alpha",
            "Source: Fama & French (1993) | Nobel Prize research"
        ]
    },
    {
        "file": "capitulation_flow",
        "title": "Capitulation Recovery Strategy",
        "steps": [
            ("exit", "Price drops > 15%\nin 5 days (Panic!)"),
            ("check", "Volume > 3x average?\n(Capitulation Volume)"),
            ("check", "RSI(14) < 25?"),
            ("buy", "BUY\n(Catch the bounce)"),
            ("exit", "EXIT: +10% profit\nor 10-day timeout"),
        ],
        "notes": [
            "Key: Blood in the streets — panic selling creates oversold bounces",
            "Risk: Catching falling knives! Strict stop loss | 65-70% win rate"
        ]
    },
    {
        "file": "dual_ma_adx_flow",
        "title": "Dual MA + ADX Trend Strategy",
        "steps": [
            ("filter", "ADX > 25\n(Strong Trend)"),
            ("check", "MA(10) crosses\nabove MA(30)?"),
            ("check", "+DI > -DI?\n(Bullish direction)"),
            ("buy", "BUY\n(Trend Ride)"),
            ("exit", "EXIT: MA death cross\nor ADX < 20"),
        ],
        "notes": [
            "Key: ADX confirms trend strength, dual MA gives direction",
            "Source: Welles Wilder (1978) | Strongly trending markets"
        ]
    },
    {
        "file": "smart_money_flow",
        "title": "Smart Money Accumulation Strategy",
        "steps": [
            ("filter", "Price in tight range\n(< 5% for 10+ days)"),
            ("check", "OBV rising while\nprice flat? (Divergence)"),
            ("check", "Price breaks above\nconsolidation range?"),
            ("buy", "BUY\n(Follow Smart Money)"),
            ("exit", "EXIT: OBV diverges\ndown or SL 6%"),
        ],
        "notes": [
            "Key: Smart money accumulates quietly — OBV reveals hidden buying",
            "Source: Joe Granville (OBV) | Richard Wyckoff (accumulation)"
        ]
    },
    {
        "file": "rubber_band_flow",
        "title": "Rubber Band ATR Dip Strategy",
        "steps": [
            ("filter", "Price > MA(50)\n(Uptrend Active)"),
            ("check", "Price drops > 2x ATR\nfrom recent high?"),
            ("confirm", "Like a rubber band\nstretched too far...\nit SNAPS back!"),
            ("buy", "BUY\n(Dip in uptrend)"),
            ("exit", "EXIT: Returns to\nMA or 5-day hold"),
        ],
        "notes": [
            "Key: In uptrends, extreme ATR dips snap back to mean",
            "Source: QuantifiedStrategies.com | ~72% win rate"
        ]
    },
    {
        "file": "mfi_stochastic_flow",
        "title": "MFI Stochastic Reversal Strategy",
        "steps": [
            ("filter", "Price > MA(100)\n(Long-term uptrend)"),
            ("check", "MFI(14) < 20?\n(Money outflow)"),
            ("check", "Stochastic %K < 20?\n(Double oversold!)"),
            ("confirm", "Double Confirmation!\nMFI + Stoch both low"),
            ("buy", "BUY\n(Oversold Reversal)"),
            ("exit", "EXIT: MFI > 80 or\nStoch > 80 (overbought)"),
        ],
        "notes": [
            "Key: Dual-oscillator confirmation reduces false signals",
            "MFI = price+volume weighted RSI | Stochastic = price in range"
        ]
    },
]

COLORS = {
    "filter": ("#b2f2bb", "#2f9e44"),
    "check":  ("#ffec99", "#e8590c"),
    "buy":    ("#a5d8ff", "#1971c2"),
    "exit":   ("#ffc9c9", "#e8590c"),
    "confirm":("#d0bfff", "#862e9c"),
}

def draw_strategy(s):
    n_steps = len(s["steps"])
    fig_h = 2 + n_steps * 1.5 + 1.0
    fig, ax = plt.subplots(1, 1, figsize=(7, fig_h))
    ax.set_xlim(0, 10)
    ax.set_ylim(0, fig_h)
    ax.set_aspect('equal')
    ax.axis('off')
    
    # Title
    ax.text(5, fig_h - 0.5, s["title"], fontsize=16, ha='center', va='center', fontweight='bold')
    
    box_w = 5.0
    box_h = 0.9
    x_center = 5.0
    
    for i, (stype, text) in enumerate(s["steps"]):
        y = fig_h - 1.5 - i * 1.4
        fc, ec = COLORS[stype]
        
        # Draw box
        box = FancyBboxPatch(
            (x_center - box_w/2, y - box_h/2), box_w, box_h,
            boxstyle="round,pad=0.1",
            facecolor=fc, edgecolor=ec, linewidth=2
        )
        ax.add_patch(box)
        ax.text(x_center, y, text, fontsize=10, ha='center', va='center', fontweight='bold')
        
        # Draw arrow to next
        if i < n_steps - 1:
            arrow_y_start = y - box_h/2
            arrow_y_end = y - 1.4 + box_h/2
            # "Yes!" label for checks
            if stype == "check":
                ax.text(x_center + 0.3, (arrow_y_start + arrow_y_end)/2, "Yes!",
                        fontsize=9, color='#2f9e44', fontweight='bold', va='center')
                ax.annotate('', xy=(x_center, arrow_y_end), xytext=(x_center, arrow_y_start),
                           arrowprops=dict(arrowstyle='->', color='#2f9e44', lw=2))
            else:
                ax.annotate('', xy=(x_center, arrow_y_end), xytext=(x_center, arrow_y_start),
                           arrowprops=dict(arrowstyle='->', color='#1e1e1e', lw=2))
        
        # "No → Wait" branch for checks
        if stype == "check":
            wait_x = x_center + box_w/2 + 1.2
            ax.text(wait_x, y, "Wait...", fontsize=8, ha='center', va='center', color='#868e96',
                   bbox=dict(boxstyle='round,pad=0.3', facecolor='#fff4e6', edgecolor='#868e96', linewidth=1))
            ax.annotate('', xy=(wait_x - 0.6, y), xytext=(x_center + box_w/2, y),
                       arrowprops=dict(arrowstyle='->', color='#868e96', lw=1, linestyle='dashed'))
            ax.text(x_center + box_w/2 + 0.3, y + 0.25, "No", fontsize=8, color='#868e96')
    
    # Notes at bottom
    note_y = fig_h - 1.5 - n_steps * 1.4 + 0.3
    for j, note in enumerate(s["notes"]):
        ax.text(5, note_y - j * 0.35, note, fontsize=7, ha='center', va='center', color='#868e96', style='italic')
    
    out_path = os.path.join(OUTPUT_DIR, f"{s['file']}.png")
    plt.savefig(out_path, dpi=150, bbox_inches='tight', facecolor='white', edgecolor='none')
    plt.close()
    print(f"Saved: {out_path}")

for strat in strategies:
    draw_strategy(strat)

print(f"\nDone! {len(strategies)} PNGs generated.")
