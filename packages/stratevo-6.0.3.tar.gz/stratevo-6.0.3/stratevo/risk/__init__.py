"""stratevo.risk - Risk management and position sizing."""

from stratevo.risk.risk_metrics import RiskMetrics
from stratevo.risk.stop_loss import StopLossManager
from stratevo.risk.position_sizing import KellyCriterion
from stratevo.risk.var_calculator import VaRCalculator

__all__ = [
    "KellyCriterion",
    "VaRCalculator",
    "StopLossManager",
    "RiskMetrics",
]

try:
    from stratevo.risk.advanced_metrics import AdvancedRiskMetrics
    __all__.append("AdvancedRiskMetrics")
except ImportError:
    pass

try:
    from stratevo.risk.position_sizer import PositionSizer
    __all__.append("PositionSizer")
except ImportError:
    pass

try:
    from stratevo.risk.portfolio_risk import PortfolioRiskManager
    __all__.append("PortfolioRiskManager")
except ImportError:
    pass

try:
    from stratevo.risk.stress_test import StressTester, Portfolio
    __all__.extend(["StressTester", "Portfolio"])
except ImportError:
    pass

try:
    from stratevo.risk.risk_budget import RiskBudgeter
    __all__.append("RiskBudgeter")
except ImportError:
    pass
