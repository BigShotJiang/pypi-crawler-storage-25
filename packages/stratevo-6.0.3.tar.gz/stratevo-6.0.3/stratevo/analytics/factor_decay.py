"""
Factor decay detection via rolling IC (Information Coefficient) monitoring.

IC is the Spearman rank correlation between factor values at time t and
forward returns at time t+1. A rolling IC trend that drops below a threshold
signals the factor is losing predictive power.
"""

from __future__ import annotations

import csv
import os
from dataclasses import dataclass, field


def _rank(values: list[float]) -> list[float]:
    """Return rank array (1-based average ranks for ties)."""
    n = len(values)
    indexed = sorted(range(n), key=lambda i: values[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and values[indexed[j + 1]] == values[indexed[i]]:
            j += 1
        avg_rank = (i + j) / 2.0 + 1.0
        for k in range(i, j + 1):
            ranks[indexed[k]] = avg_rank
        i = j + 1
    return ranks


def spearman_ic(factor_vals: list[float], forward_returns: list[float]) -> float:
    """Compute Spearman rank correlation (IC) between factor and forward returns."""
    n = len(factor_vals)
    if n < 3:
        return float("nan")
    rf = _rank(factor_vals)
    rr = _rank(forward_returns)
    mean_f = sum(rf) / n
    mean_r = sum(rr) / n
    num = sum((rf[i] - mean_f) * (rr[i] - mean_r) for i in range(n))
    den_f = sum((x - mean_f) ** 2 for x in rf) ** 0.5
    den_r = sum((x - mean_r) ** 2 for x in rr) ** 0.5
    if den_f < 1e-12 or den_r < 1e-12:
        return float("nan")
    return num / (den_f * den_r)


@dataclass
class FactorDecayResult:
    """Rolling IC stats and decay verdict for a single factor."""

    factor_name: str
    ic_series: list[float]
    ic_mean: float
    ic_std: float
    ic_latest: float
    decaying: bool
    decay_reason: str = ""
    window: int = 60
    windows_computed: int = 0


def compute_rolling_ic(
    closes: list[float],
    factor_vals: list[float],
    window: int = 60,
    horizon: int = 1,
) -> list[float]:
    """
    Compute rolling IC series.

    For each rolling window of `window` bars, compute the Spearman correlation
    between factor_vals[t-window:t] and the 1-period forward return computed
    from closes[t-window:t+horizon].

    Returns a list of IC values (one per completed window).
    """
    n = len(closes)
    if len(factor_vals) != n:
        raise ValueError("closes and factor_vals must have the same length")

    ic_series: list[float] = []
    for end in range(window, n - horizon + 1):
        start = end - window
        fv = factor_vals[start:end]
        fwd_rets = [
            (closes[i + horizon] - closes[i]) / closes[i]
            if closes[i] != 0 else 0.0
            for i in range(start, end)
        ]
        ic = spearman_ic(fv, fwd_rets)
        ic_series.append(ic)
    return ic_series


def detect_decay(
    ic_series: list[float],
    factor_name: str,
    window: int,
    ic_threshold: float = 0.02,
    drop_threshold: float = 0.5,
) -> FactorDecayResult:
    """
    Detect if a factor's IC is decaying.

    Decay is flagged when:
      - The latest IC magnitude is below `ic_threshold`, OR
      - The latest IC is less than `drop_threshold` * mean IC (significant drop).

    Args:
        ic_series: Rolling IC values from compute_rolling_ic.
        factor_name: Human-readable factor name.
        window: Rolling window size used (informational).
        ic_threshold: Minimum meaningful IC magnitude.
        drop_threshold: Fraction of mean IC below which decay is flagged.
    """
    valid = [v for v in ic_series if v == v]  # filter NaN
    if not valid:
        return FactorDecayResult(
            factor_name=factor_name,
            ic_series=ic_series,
            ic_mean=float("nan"),
            ic_std=float("nan"),
            ic_latest=float("nan"),
            decaying=False,
            decay_reason="insufficient data",
            window=window,
            windows_computed=0,
        )

    ic_mean = sum(valid) / len(valid)
    ic_var = sum((v - ic_mean) ** 2 for v in valid) / max(len(valid) - 1, 1)
    ic_std = ic_var ** 0.5
    ic_latest = valid[-1]

    decaying = False
    reason = ""
    if abs(ic_latest) < ic_threshold:
        decaying = True
        reason = f"latest IC {ic_latest:.4f} below threshold {ic_threshold}"
    elif ic_mean != 0 and abs(ic_latest) < drop_threshold * abs(ic_mean):
        decaying = True
        reason = (
            f"latest IC {ic_latest:.4f} dropped to "
            f"{abs(ic_latest) / max(abs(ic_mean), 1e-9):.0%} of mean {ic_mean:.4f}"
        )

    return FactorDecayResult(
        factor_name=factor_name,
        ic_series=valid,
        ic_mean=ic_mean,
        ic_std=ic_std,
        ic_latest=ic_latest,
        decaying=decaying,
        decay_reason=reason,
        window=window,
        windows_computed=len(valid),
    )


@dataclass
class BuiltinFactors:
    """Simple built-in factors computed from OHLCV data."""

    @staticmethod
    def momentum(closes: list[float], lookback: int = 20) -> list[float]:
        """Price momentum: close[t] / close[t-lookback] - 1."""
        vals = [float("nan")] * len(closes)
        for i in range(lookback, len(closes)):
            if closes[i - lookback] != 0:
                vals[i] = closes[i] / closes[i - lookback] - 1.0
        return vals

    @staticmethod
    def volatility(closes: list[float], lookback: int = 20) -> list[float]:
        """Rolling volatility of log returns."""
        import math

        log_rets = [0.0] + [
            math.log(closes[i] / closes[i - 1]) if closes[i - 1] > 0 else 0.0
            for i in range(1, len(closes))
        ]
        vals = [float("nan")] * len(closes)
        for i in range(lookback, len(closes)):
            w = log_rets[i - lookback : i]
            mean = sum(w) / len(w)
            var = sum((r - mean) ** 2 for r in w) / max(len(w) - 1, 1)
            vals[i] = var ** 0.5
        return vals

    @staticmethod
    def mean_reversion(closes: list[float], lookback: int = 20) -> list[float]:
        """Distance from rolling mean (z-score)."""
        vals = [float("nan")] * len(closes)
        for i in range(lookback, len(closes)):
            w = closes[i - lookback : i]
            mean = sum(w) / len(w)
            std = (sum((c - mean) ** 2 for c in w) / max(len(w) - 1, 1)) ** 0.5
            if std > 0:
                vals[i] = (closes[i] - mean) / std
        return vals


def analyze_data_dir(
    data_dir: str,
    window: int = 60,
    ic_threshold: float = 0.02,
    drop_threshold: float = 0.5,
) -> list[FactorDecayResult]:
    """
    Load all CSV files in data_dir and run factor decay analysis.

    Returns one FactorDecayResult per (symbol, factor) combination.
    """
    results: list[FactorDecayResult] = []

    csv_files = [f for f in os.listdir(data_dir) if f.endswith(".csv")]
    if not csv_files:
        return results

    for fname in sorted(csv_files):
        symbol = fname.replace(".csv", "")
        path = os.path.join(data_dir, fname)

        closes: list[float] = []
        try:
            with open(path, newline="") as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    c = row.get("close") or row.get("Close")
                    if c is not None:
                        try:
                            closes.append(float(c))
                        except ValueError:
                            pass
        except OSError:
            continue

        if len(closes) < window + 10:
            continue

        factors = {
            f"{symbol}:momentum": BuiltinFactors.momentum(closes),
            f"{symbol}:volatility": BuiltinFactors.volatility(closes),
            f"{symbol}:mean_reversion": BuiltinFactors.mean_reversion(closes),
        }

        for factor_name, factor_vals in factors.items():
            # Filter out leading NaNs
            first_valid = next(
                (i for i, v in enumerate(factor_vals) if v == v), None
            )
            if first_valid is None or len(closes) - first_valid < window + 10:
                continue
            trimmed_closes = closes[first_valid:]
            trimmed_factor = factor_vals[first_valid:]

            ic_series = compute_rolling_ic(trimmed_closes, trimmed_factor, window=window)
            result = detect_decay(
                ic_series,
                factor_name=factor_name,
                window=window,
                ic_threshold=ic_threshold,
                drop_threshold=drop_threshold,
            )
            results.append(result)

    return results


def format_decay_output(results: list[FactorDecayResult]) -> str:
    """Format factor decay results for terminal output."""
    if not results:
        return "\n  No factors analyzed ΓÇö check data directory.\n"

    lines: list[str] = []
    lines.append("")
    lines.append("  ≡ƒôë Factor Decay Report")
    lines.append("  " + "ΓöÇ" * 68)
    lines.append(
        f"  {'Factor':<38} {'IC Mean':>8} {'IC Std':>8} {'IC Now':>8}  Status"
    )
    lines.append("  " + "ΓöÇ" * 68)

    decaying = [r for r in results if r.decaying]
    stable = [r for r in results if not r.decaying]

    def _fmt_ic(v: float) -> str:
        if v != v:
            return "   N/A"
        return f"{v:>8.4f}"

    for r in stable + decaying:
        icon = "ΓÜá∩╕Å  DECAY" if r.decaying else "Γ£à stable"
        lines.append(
            f"  {r.factor_name:<38} {_fmt_ic(r.ic_mean)} {_fmt_ic(r.ic_std)} "
            f"{_fmt_ic(r.ic_latest)}  {icon}"
        )
        if r.decaying and r.decay_reason:
            lines.append(f"     ΓööΓöÇ {r.decay_reason}")

    lines.append("  " + "ΓöÇ" * 68)
    lines.append(
        f"  {len(stable)} stable, {len(decaying)} decaying "
        f"(window={results[0].window if results else 0} bars)"
    )
    lines.append("")
    return "\n".join(lines)
