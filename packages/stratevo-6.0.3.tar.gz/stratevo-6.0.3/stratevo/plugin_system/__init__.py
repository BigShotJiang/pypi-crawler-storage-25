"""stratevo.plugin_system - Plugin loading and adapters."""
