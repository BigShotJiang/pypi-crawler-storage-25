"""stratevo.data.demo - Demo data directory."""

import os as _os

DEMO_DATA_DIR = _os.path.join(_os.path.dirname(__file__))

__all__ = ["DEMO_DATA_DIR"]
