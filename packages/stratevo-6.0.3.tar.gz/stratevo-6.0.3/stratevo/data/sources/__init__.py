"""stratevo.data.sources - Data input sources."""

from stratevo.data.sources.base import DataSource, DataSink
from stratevo.data.sources.csv_source import CSVSource
from stratevo.data.sources.json_source import JSONSource

__all__ = ["DataSource", "DataSink", "CSVSource", "JSONSource"]

try:
    from stratevo.data.sources.api_source import APISource
    __all__.append("APISource")
except ImportError:
    pass

try:
    from stratevo.data.sources.exchange_source import ExchangeSource
    __all__.append("ExchangeSource")
except ImportError:
    pass
