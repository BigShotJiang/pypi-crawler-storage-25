"""stratevo.data.sinks - Data output sinks."""

from stratevo.data.sinks.csv_sink import CSVSink
from stratevo.data.sinks.json_sink import JSONSink

__all__ = ["CSVSink", "JSONSink"]

try:
    from stratevo.data.sinks.parquet_sink import ParquetSink
    __all__.append("ParquetSink")
except ImportError:
    pass

try:
    from stratevo.data.sinks.sqlite_sink import SQLiteSink
    __all__.append("SQLiteSink")
except ImportError:
    pass
