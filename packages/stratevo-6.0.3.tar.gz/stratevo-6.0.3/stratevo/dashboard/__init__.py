"""stratevo.dashboard - Interactive dashboards."""
