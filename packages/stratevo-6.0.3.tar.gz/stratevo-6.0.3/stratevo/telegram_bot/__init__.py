"""stratevo.telegram_bot - Telegram bot integration."""
