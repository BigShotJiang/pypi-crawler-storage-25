"""
Evolution engine data models and constants.

Extracted from auto_evolve.py -- shared dataclasses and parameter definitions.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from typing import Dict, List, Optional, Tuple


_WEIGHT_KEYS: List[str] = [
    "w_momentum",
    "w_mean_reversion",
    "w_volume",
    "w_trend",
    "w_pattern",
    "w_macd",
    "w_bollinger",
    "w_kdj",
    "w_obv",
    "w_support",
    "w_volume_profile",
    # Technical extended
    "w_atr",
    "w_adx",
    "w_roc",
    "w_williams_r",
    "w_cci",
    "w_mfi",
    "w_vwap",
    "w_donchian",
    "w_ichimoku",
    "w_elder_ray",
    # Rolling statistics
    "w_beta",
    "w_r_squared",
    "w_residual",
    "w_quantile_upper",
    "w_quantile_lower",
    "w_aroon",
    "w_price_volume_corr",
    # Fundamental factors (original)
    "w_pe",
    "w_pb",
    "w_roe",
    "w_revenue_growth",
    # Fundamental growth
    "w_revenue_yoy",
    "w_revenue_qoq",
    "w_profit_yoy",
    "w_profit_qoq",
    # Fundamental valuation
    "w_ps",
    "w_peg",
    # Fundamental quality
    "w_gross_margin",
    "w_debt_ratio",
    "w_cashflow",
]


@dataclass
class StrategyDNA:
    """All tunable parameters for a trading strategy."""

    # --- Selection thresholds ---
    min_score: int = 6
    rsi_buy_threshold: float = 35.0
    rsi_sell_threshold: float = 75.0
    r2_min: float = 0.5
    slope_min: float = 0.5  # daily %
    volume_ratio_min: float = 1.2

    # --- Execution ---
    hold_days: int = 3
    stop_loss_pct: float = 2.0
    take_profit_pct: float = 20.0
    max_positions: int = 2

    # --- Golden dip specific ---
    dip_threshold_pct: float = 10.0  # pullback from high
    r2_trend_min: float = 0.6  # min R² for bull stock confirmation

    # --- v5: Advanced Position & Risk Management (all evolvable) ---
    # Position sizing: score^power determines allocation weight
    # 0 = equal weight, 2 = quadratic (high-score stocks get more capital)
    position_sizing_power: float = 0.0

    # Trailing stop: activated after price rises trailing_activation_pct,
    # then trails at trailing_stop_pct below the peak since entry
    trailing_stop_enabled: float = 0.0  # >0.5 = on (evolved as continuous)
    trailing_activation_pct: float = 5.0  # % gain to activate trailing
    trailing_stop_pct: float = 3.0  # % below peak to trigger exit

    # Scale-in: split entry into N tranches over consecutive days
    scale_in_tranches: int = 1  # 1=all-in, 2=50/50, 3=33/33/33

    # Adaptive stop loss: per-day stop loss rate.
    # Effective SL = stop_loss_per_day * hold_days (capped at stop_loss_pct).
    # 0 = use fixed stop_loss_pct (backwards compatible).
    stop_loss_per_day: float = 0.0

    # Market regime: reduce exposure when market breadth is weak
    # 0 = disabled, 1.0 = very aggressive reduction
    market_regime_sensitivity: float = 0.0

    # Market regime gate: minimum breadth to trade at all.
    # When market breadth (% of stocks above 20-day MA) is below this
    # threshold, go 100% cash — no trades.  Range [0.0, 0.8].
    # 0 = always trade (backwards compatible), 0.5 = only trade in bull.
    min_breadth_to_trade: float = 0.0

    # Sector concentration: max fraction of portfolio in one sector
    # 1.0 = no limit, 0.3 = max 30% per sector
    sector_max_pct: float = 1.0

    # Profit target scaling: multiply take_profit by (score/10)
    # 0 = fixed target, 1.0 = fully scaled by signal strength
    profit_target_scaling: float = 0.0

    # Time-decay exit: after hold_days, tighten stop loss progressively
    # 0 = off, 1.0 = aggressive tightening
    time_decay_exit: float = 0.0

    # Multi-timeframe confirmation: require weekly uptrend (5MA > 20MA).
    # > 0.5 = enabled (evolved as continuous toggle)
    weekly_trend_confirm: float = 0.0

    # Kelly criterion: dynamically scale position size based on recent
    # win rate and payoff ratio.  0 = disabled, 1.0 = full half-Kelly.
    kelly_fraction: float = 0.0

    # Factor momentum: dynamically boost weights of recently-profitable factors.
    # 0 = disabled (static weights from DNA), 1.0 = aggressive adaptation.
    # Uses a lookback of recent trades to score each factor's contribution.
    factor_momentum: float = 0.0

    # Capital utilization: fraction of total capital to deploy across positions.
    # 1.0 = deploy 100% of capital across max_positions (default; full Kelly).
    # 0.5 = deploy 50%, hold 50% cash as reserve.
    # This decouples position count from capital exposure — you can have
    # 2 positions each using 50% of capital (100% utilization) or
    # 5 positions each using 10% (50% utilization with 50% cash).
    capital_utilization: float = 1.0

    # Dynamic hold: allow strategy to exit early when conditions deteriorate.
    # Called "trend exit": if the stock's 5-day MA crosses below 10-day MA
    # while holding, exit immediately (don't wait for hold_days or stops).
    # >0.5 = enabled.
    trend_exit_enabled: float = 0.0

    # --- Regime-specific parameter overrides (v6) ---
    # When market breadth indicates a bear regime, these override base params.
    # Each is a multiplier (1.0 = no change, 0.5 = halve the value).
    # Evolved just like other params — GA discovers optimal adaptation.
    bear_min_score_add: float = 0.0      # add to min_score in bear markets (0-3)
    bear_stop_loss_mult: float = 1.0     # tighten stops in bear (0.3-1.0)
    bear_hold_days_mult: float = 1.0     # shorten hold in bear (0.3-1.0)
    bear_take_profit_mult: float = 1.0   # lower targets in bear (0.3-1.0)

    # --- Scoring weights (12 dimensions, auto-normalized to sum=1) ---
    # Original 5
    w_momentum: float = 0.1       # RSI + slope
    w_mean_reversion: float = 0.1 # RSI oversold
    w_volume: float = 0.1         # volume ratio
    w_trend: float = 0.1          # R² + MA alignment
    w_pattern: float = 0.1        # candle patterns
    # New 6
    w_macd: float = 0.1           # MACD golden/death cross
    w_bollinger: float = 0.1      # Bollinger Band position
    w_kdj: float = 0.1            # KDJ golden cross
    w_obv: float = 0.1            # OBV trend (price-volume)
    w_support: float = 0.05       # support/resistance proximity
    w_volume_profile: float = 0.05  # volume profile shape
    # Fundamental factors (default 0 = disabled until evolved)
    w_pe: float = 0.0             # PE valuation score
    w_pb: float = 0.0             # PB value score
    w_roe: float = 0.0            # Return on equity
    w_revenue_growth: float = 0.0 # Revenue growth rate

    # === Technical Extended ===
    w_atr: float = 0.0              # Average True Range (volatility)
    w_adx: float = 0.0              # Average Directional Index (trend strength)
    w_roc: float = 0.0              # Rate of Change
    w_williams_r: float = 0.0       # Williams %R
    w_cci: float = 0.0              # Commodity Channel Index
    w_mfi: float = 0.0              # Money Flow Index
    w_vwap: float = 0.0             # Volume Weighted Avg Price distance
    w_donchian: float = 0.0         # Donchian Channel breakout
    w_ichimoku: float = 0.0         # Ichimoku cloud position
    w_elder_ray: float = 0.0        # Elder Ray (bull/bear power)

    # === Rolling Statistics ===
    w_beta: float = 0.0             # Price regression slope
    w_r_squared: float = 0.0        # Trend linearity
    w_residual: float = 0.0         # Regression residual (mean reversion)
    w_quantile_upper: float = 0.0   # 80% quantile distance
    w_quantile_lower: float = 0.0   # 20% quantile distance
    w_aroon: float = 0.0            # Days since high/low
    w_price_volume_corr: float = 0.0 # Price-volume correlation

    # === Fundamental Growth ===
    w_revenue_yoy: float = 0.0      # Revenue YoY growth
    w_revenue_qoq: float = 0.0      # Revenue QoQ growth
    w_profit_yoy: float = 0.0       # Net profit YoY growth
    w_profit_qoq: float = 0.0       # Net profit QoQ growth

    # === Fundamental Valuation ===
    w_ps: float = 0.0               # Price-to-Sales
    w_peg: float = 0.0              # PEG ratio

    # === Fundamental Quality ===
    w_gross_margin: float = 0.0     # Gross margin
    w_debt_ratio: float = 0.0       # Debt-to-asset ratio
    w_cashflow: float = 0.0         # Operating cashflow quality

    # === Dynamic factor weights (from factor discovery) ===
    custom_weights: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        # Flatten custom_weights into top-level for serialization
        cw = d.pop("custom_weights", {})
        d.update(cw)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "StrategyDNA":
        valid = {f.name for f in fields(cls)}
        known = {k: v for k, v in d.items() if k in valid and k != "custom_weights"}
        # Any keys not in standard fields go into custom_weights
        extra = {k: v for k, v in d.items() if k not in valid}
        # Merge explicit custom_weights from dict if present
        if "custom_weights" in d and isinstance(d["custom_weights"], dict):
            extra.update(d["custom_weights"])
        known["custom_weights"] = extra
        return cls(**known)


# Valid ranges for each parameter — (min, max, is_int)
_PARAM_RANGES: Dict[str, Tuple[float, float, bool]] = {
    "min_score": (4, 8, True),  # min=4 prevents overfitting via loose threshold
    "rsi_buy_threshold": (10.0, 50.0, False),
    "rsi_sell_threshold": (55.0, 95.0, False),
    "r2_min": (0.1, 0.95, False),
    "slope_min": (0.1, 3.0, False),
    "volume_ratio_min": (0.5, 5.0, False),
    "hold_days": (2, 60, True),  # A-share T+1: minimum 2 days; up to 60 for swing/position trading
    "stop_loss_pct": (0.5, 25.0, False),  # up to 25% for longer hold periods
    "take_profit_pct": (3.0, 200.0, False),  # up to 200% for swing trades catching multi-baggers
    "max_positions": (1, 10, True),
    "dip_threshold_pct": (3.0, 30.0, False),
    "r2_trend_min": (0.2, 0.95, False),
    # v5: Advanced Position & Risk Management
    "position_sizing_power": (0.0, 3.0, False),
    "trailing_stop_enabled": (0.0, 1.0, False),
    "trailing_activation_pct": (2.0, 30.0, False),
    "trailing_stop_pct": (1.0, 15.0, False),
    "scale_in_tranches": (1, 3, True),
    "stop_loss_per_day": (0.0, 3.0, False),
    "market_regime_sensitivity": (0.0, 1.0, False),
    "min_breadth_to_trade": (0.0, 0.8, False),
    "sector_max_pct": (0.2, 1.0, False),
    "profit_target_scaling": (0.0, 1.0, False),
    "time_decay_exit": (0.0, 1.0, False),
    "weekly_trend_confirm": (0.0, 1.0, False),
    "kelly_fraction": (0.0, 1.0, False),
    "factor_momentum": (0.0, 1.0, False),
    "capital_utilization": (0.3, 1.0, False),  # min 30% deployed, max 100%
    "trend_exit_enabled": (0.0, 1.0, False),   # >0.5 = exit on trend break
    # v6: Regime-specific overrides
    "bear_min_score_add": (0.0, 3.0, False),
    "bear_stop_loss_mult": (0.3, 1.0, False),
    "bear_hold_days_mult": (0.3, 1.0, False),
    "bear_take_profit_mult": (0.3, 1.0, False),
    # Original weights
    "w_momentum": (0.0, 1.0, False),
    "w_mean_reversion": (0.0, 1.0, False),
    "w_volume": (0.0, 1.0, False),
    "w_trend": (0.0, 1.0, False),
    "w_pattern": (0.0, 1.0, False),
    # New weights
    "w_macd": (0.0, 1.0, False),
    "w_bollinger": (0.0, 1.0, False),
    "w_kdj": (0.0, 1.0, False),
    "w_obv": (0.0, 1.0, False),
    "w_support": (0.0, 1.0, False),
    "w_volume_profile": (0.0, 1.0, False),
    # Fundamental factor weights
    "w_pe": (0.0, 1.0, False),
    "w_pb": (0.0, 1.0, False),
    "w_roe": (0.0, 1.0, False),
    "w_revenue_growth": (0.0, 1.0, False),
    # Technical extended
    "w_atr": (0.0, 1.0, False),
    "w_adx": (0.0, 1.0, False),
    "w_roc": (0.0, 1.0, False),
    "w_williams_r": (0.0, 1.0, False),
    "w_cci": (0.0, 1.0, False),
    "w_mfi": (0.0, 1.0, False),
    "w_vwap": (0.0, 1.0, False),
    "w_donchian": (0.0, 1.0, False),
    "w_ichimoku": (0.0, 1.0, False),
    "w_elder_ray": (0.0, 1.0, False),
    # Rolling statistics
    "w_beta": (0.0, 1.0, False),
    "w_r_squared": (0.0, 1.0, False),
    "w_residual": (0.0, 1.0, False),
    "w_quantile_upper": (0.0, 1.0, False),
    "w_quantile_lower": (0.0, 1.0, False),
    "w_aroon": (0.0, 1.0, False),
    "w_price_volume_corr": (0.0, 1.0, False),
    # Fundamental growth
    "w_revenue_yoy": (0.0, 1.0, False),
    "w_revenue_qoq": (0.0, 1.0, False),
    "w_profit_yoy": (0.0, 1.0, False),
    "w_profit_qoq": (0.0, 1.0, False),
    # Fundamental valuation
    "w_ps": (0.0, 1.0, False),
    "w_peg": (0.0, 1.0, False),
    # Fundamental quality
    "w_gross_margin": (0.0, 1.0, False),
    "w_debt_ratio": (0.0, 1.0, False),
    "w_cashflow": (0.0, 1.0, False),
}


def get_all_weight_keys(dna: StrategyDNA) -> List[str]:
    """Return builtin weight keys + dynamic custom weight keys."""
    return _WEIGHT_KEYS + list(dna.custom_weights.keys())


@dataclass
class EvolutionResult:
    """Result of one strategy evaluation."""

    dna: StrategyDNA
    annual_return: float
    max_drawdown: float
    win_rate: float
    sharpe: float
    calmar: float
    total_trades: int
    profit_factor: float
    fitness: float = 0.0
    walk_forward_windows: Optional[List[dict]] = None

    def to_dict(self) -> dict:
        d = {k: v for k, v in self.__dict__.items() if k != "dna"}
        d["dna"] = self.dna.to_dict()
        # Exclude None walk_forward_windows to keep backward compat
        if d.get("walk_forward_windows") is None:
            d.pop("walk_forward_windows", None)
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "EvolutionResult":
        dna = StrategyDNA.from_dict(d.pop("dna"))
        # Tolerate unknown keys from newer/older formats
        valid_keys = {
            "annual_return", "max_drawdown", "win_rate", "sharpe",
            "calmar", "total_trades", "profit_factor", "fitness",
            "walk_forward_windows",
        }
        filtered = {k: v for k, v in d.items() if k in valid_keys}
        return cls(dna=dna, **filtered)

