"""
Combinatorial Purged Cross-Validation (CPCV) for strategy evaluation.

Based on López de Prado (2018) "Advances in Financial Machine Learning".
Generates multiple train/test path combinations, calculates Probability
of Backtest Overfitting (PBO), and Deflated Sharpe Ratio (DSR).

This module provides an alternative to standard Walk-Forward validation
that is more robust against overfitting by testing across many possible
historical paths instead of a single walk-forward sequence.
"""

from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple


@dataclass
class CPCVConfig:
    """Configuration for CPCV validation."""
    n_groups: int = 6           # Number of groups to split data into
    n_test_groups: int = 2      # Number of groups used for testing per split
    embargo_pct: float = 0.01   # Embargo % between train/test to prevent leakage
    purge_pct: float = 0.01     # Purge % to remove from train near test boundary
    min_trades_per_path: int = 5


@dataclass
class CPCVPathResult:
    """Result of evaluating one train/test split."""
    train_groups: Tuple[int, ...]
    test_groups: Tuple[int, ...]
    train_return: float
    test_return: float
    test_sharpe: float
    test_trades: int
    test_max_drawdown: float


@dataclass
class CPCVResult:
    """Aggregated CPCV result with PBO and DSR."""
    pbo: float                  # Probability of Backtest Overfitting [0, 1]
    dsr: float                  # Deflated Sharpe Ratio
    mean_oos_return: float      # Mean out-of-sample annual return
    mean_oos_sharpe: float      # Mean out-of-sample Sharpe
    n_paths: int                # Number of paths evaluated
    n_profitable_paths: int     # Number of paths with positive OOS return
    path_results: List[CPCVPathResult] = field(default_factory=list)
    fitness_adjustment: float = 1.0  # Multiplier to apply to WF fitness

    @property
    def is_likely_overfit(self) -> bool:
        """Strategy is likely overfit if PBO > 0.5."""
        return self.pbo > 0.5


class CPCVValidator:
    """Combinatorial Purged Cross-Validation validator.

    Given N groups, generates C(N, K) train/test combinations where K groups
    are held out for testing. Each combination produces an independent
    out-of-sample evaluation of the strategy.

    The Probability of Backtest Overfitting (PBO) measures how often the
    best in-sample configuration would have been the worst out-of-sample.
    """

    def __init__(self, config: Optional[CPCVConfig] = None):
        self.config = config or CPCVConfig()

    def _split_data_into_groups(
        self, total_bars: int
    ) -> List[Tuple[int, int]]:
        """Split data into N equal groups, returning (start, end) tuples."""
        n = self.config.n_groups
        group_size = total_bars // n
        groups = []
        for i in range(n):
            start = i * group_size
            end = (i + 1) * group_size if i < n - 1 else total_bars
            groups.append((start, end))
        return groups

    def _generate_combinations(self) -> List[Tuple[Tuple[int, ...], Tuple[int, ...]]]:
        """Generate all C(N, K) train/test splits.

        Returns list of (train_group_indices, test_group_indices).
        """
        n = self.config.n_groups
        k = self.config.n_test_groups
        all_indices = list(range(n))

        combinations = []
        for test_groups in itertools.combinations(all_indices, k):
            train_groups = tuple(i for i in all_indices if i not in test_groups)
            combinations.append((train_groups, test_groups))

        return combinations

    def _apply_purge_embargo(
        self,
        groups: List[Tuple[int, int]],
        train_indices: Tuple[int, ...],
        test_indices: Tuple[int, ...],
        total_bars: int,
    ) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
        """Apply purging and embargo to train/test ranges.

        Purge: remove training observations that overlap with test labels.
        Embargo: add gap after test set before allowing training observations.
        """
        embargo_bars = max(1, int(total_bars * self.config.embargo_pct))
        purge_bars = max(1, int(total_bars * self.config.purge_pct))

        test_ranges = [groups[i] for i in test_indices]
        # Find min/max of test ranges for purging
        test_min = min(r[0] for r in test_ranges)
        test_max = max(r[1] for r in test_ranges)

        train_ranges = []
        for i in train_indices:
            start, end = groups[i]
            # Purge: remove bars too close to test boundary
            if end > test_min - purge_bars and start < test_min:
                end = max(start, test_min - purge_bars)
            if start < test_max + embargo_bars and end > test_max:
                start = min(end, test_max + embargo_bars)

            if end - start > 10:  # only keep meaningful segments
                train_ranges.append((start, end))

        return train_ranges, test_ranges

    def validate(
        self,
        total_bars: int,
        run_backtest_fn: Callable[[int, int], Tuple[float, float, float, float, float, int, float, float, int, List[float], int, float]],
    ) -> CPCVResult:
        """Run CPCV validation across all combinatorial splits.

        Args:
            total_bars: Total number of data bars
            run_backtest_fn: Function(start, end) -> backtest metrics tuple

        Returns:
            CPCVResult with PBO, DSR, and per-path results
        """
        groups = self._split_data_into_groups(total_bars)
        combinations = self._generate_combinations()

        path_results: List[CPCVPathResult] = []

        for train_indices, test_indices in combinations:
            train_ranges, test_ranges = self._apply_purge_embargo(
                groups, train_indices, test_indices, total_bars
            )

            # Run backtest on train ranges (combined)
            train_metrics = self._aggregate_backtest(train_ranges, run_backtest_fn)
            # Run backtest on test ranges (combined)
            test_metrics = self._aggregate_backtest(test_ranges, run_backtest_fn)

            if test_metrics is None:
                continue

            annual_return, max_dd, win_rate, sharpe, calmar, trades, pf, sortino, mcl, mr, mcp, at = test_metrics
            train_return = train_metrics[0] if train_metrics else 0.0

            path_results.append(CPCVPathResult(
                train_groups=train_indices,
                test_groups=test_indices,
                train_return=train_return,
                test_return=annual_return,
                test_sharpe=sharpe,
                test_trades=trades,
                test_max_drawdown=max_dd,
            ))

        if not path_results:
            return CPCVResult(
                pbo=1.0, dsr=0.0,
                mean_oos_return=0.0, mean_oos_sharpe=0.0,
                n_paths=0, n_profitable_paths=0,
                fitness_adjustment=0.1,
            )

        # Calculate PBO: proportion of paths where best IS → worst OOS
        # Simplified: PBO ≈ fraction of paths with negative OOS return
        n_paths = len(path_results)
        n_profitable = sum(1 for p in path_results if p.test_return > 0)
        n_negative = n_paths - n_profitable

        # PBO approximation: logit of the fraction of losing paths
        loss_ratio = n_negative / n_paths
        pbo = loss_ratio  # Simple but effective approximation

        # Mean OOS metrics
        mean_return = sum(p.test_return for p in path_results) / n_paths
        sharpes = [p.test_sharpe for p in path_results if not math.isnan(p.test_sharpe)]
        mean_sharpe = sum(sharpes) / len(sharpes) if sharpes else 0.0

        # Deflated Sharpe Ratio (simplified)
        # DSR adjusts Sharpe for multiple testing: DSR = Sharpe - adjustment
        # Higher N_paths → larger adjustment → need higher Sharpe to be significant
        if mean_sharpe > 0 and n_paths > 1:
            # Euler-Mascheroni approximation for max of N standard normals
            euler_m = 0.5772
            e_max = (1 - euler_m) * math.sqrt(2 * math.log(n_paths)) + euler_m * math.sqrt(2 * math.log(n_paths))
            variance_sharpe = sum((s - mean_sharpe) ** 2 for s in sharpes) / max(len(sharpes) - 1, 1) if len(sharpes) > 1 else 1.0
            se_sharpe = math.sqrt(variance_sharpe / max(len(sharpes), 1))
            dsr = (mean_sharpe - e_max * se_sharpe) if se_sharpe > 0 else mean_sharpe
        else:
            dsr = mean_sharpe

        # Fitness adjustment based on PBO
        # PBO < 0.3: excellent, no penalty
        # PBO 0.3-0.5: mild penalty
        # PBO > 0.5: likely overfit, heavy penalty
        if pbo < 0.3:
            fitness_adj = 1.0
        elif pbo < 0.5:
            fitness_adj = 1.0 - (pbo - 0.3) * 1.5  # 1.0 → 0.7
        else:
            fitness_adj = max(0.1, 0.7 - (pbo - 0.5) * 1.2)  # 0.7 → 0.1

        return CPCVResult(
            pbo=pbo,
            dsr=dsr,
            mean_oos_return=mean_return,
            mean_oos_sharpe=mean_sharpe,
            n_paths=n_paths,
            n_profitable_paths=n_profitable,
            path_results=path_results,
            fitness_adjustment=fitness_adj,
        )

    def _aggregate_backtest(
        self,
        ranges: List[Tuple[int, int]],
        run_backtest_fn: Callable,
    ) -> Optional[Tuple]:
        """Run backtest across multiple ranges and aggregate."""
        if not ranges:
            return None

        # Use the combined range (may have gaps — acceptable for CPCV)
        all_start = min(r[0] for r in ranges)
        all_end = max(r[1] for r in ranges)

        try:
            return run_backtest_fn(all_start, all_end)
        except Exception:
            return None
