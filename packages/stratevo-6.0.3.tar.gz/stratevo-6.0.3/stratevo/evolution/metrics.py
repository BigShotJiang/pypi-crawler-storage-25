"""Shared backtest metrics — Sharpe, Sortino, slippage.

Extracted from auto_evolve.py and crypto_backtest.py to avoid
duplicating the same logic in two places. Both A-share and crypto
backtests call these functions.
"""

import math
import os
from typing import List, Tuple

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_MIN_SHARPE_TRADES = 5          # Minimum trades for meaningful Sharpe
_SHARPE_CLAMP = (-10.0, 10.0)  # Clamp range — values beyond are noise
_DEFAULT_RF_RATE = 0.04         # 4% annual risk-free rate


def compute_trade_sharpe_sortino(
    trade_returns_pct: List[float],
    total_bars: int,
    bars_per_year: float = 250.0,
) -> Tuple[float, float]:
    """Compute annualized Sharpe and Sortino from per-trade returns.

    Args:
        trade_returns_pct: List of trade returns in percentage (e.g. [5.2, -1.3, ...])
        total_bars: Number of bars in the evaluation window
        bars_per_year: 250 for daily A-share, 8760 for hourly crypto

    Returns:
        (sharpe, sortino) tuple, both clamped to [-10, 10]
    """
    if len(trade_returns_pct) < _MIN_SHARPE_TRADES:
        return 0.0, 0.0

    trade_returns = [t / 100.0 for t in trade_returns_pct]
    n = len(trade_returns)
    mean_r = sum(trade_returns) / n
    var_r = sum((r - mean_r) ** 2 for r in trade_returns) / n
    std_r = math.sqrt(var_r) if var_r > 0 else 0.001

    # Estimate trades per year
    if total_bars > 0 and n > 0:
        trades_per_year = n * (bars_per_year / total_bars)
    else:
        trades_per_year = 50.0  # fallback

    # Risk-free rate per trade
    annual_rf = float(os.environ.get("STRATEVO_RISK_FREE_RATE", str(_DEFAULT_RF_RATE)))
    rf_per_trade = annual_rf / max(trades_per_year, 1.0)

    # Sharpe
    sharpe = ((mean_r - rf_per_trade) / std_r) * math.sqrt(max(trades_per_year, 1))
    sharpe = max(_SHARPE_CLAMP[0], min(_SHARPE_CLAMP[1], sharpe))

    # Sortino
    sortino = 0.0
    downside_returns = [r for r in trade_returns if r < 0]
    if downside_returns:
        downside_var = sum(r ** 2 for r in downside_returns) / n
        downside_std = math.sqrt(downside_var) if downside_var > 0 else 0.001
        sortino = ((mean_r - rf_per_trade) / downside_std) * math.sqrt(max(trades_per_year, 1))
        sortino = max(_SHARPE_CLAMP[0], min(_SHARPE_CLAMP[1], sortino))
    else:
        sortino = min(sharpe * 1.5, _SHARPE_CLAMP[1])  # no down trades = great

    return sharpe, sortino


# ---------------------------------------------------------------------------
# Slippage model
# ---------------------------------------------------------------------------

# Liquidity tiers for crypto — realistic slippage based on market depth
# Values represent one-way slippage (applied to both entry and exit).
# Sources: Binance/OKX order book depth analysis, ~$100K order size.
CRYPTO_SLIPPAGE_TIERS = {
    # Tier 1: Top liquidity (BTC, ETH) — deep books, sub-1bps spread
    "BTCUSDT": 0.0001,  # 1 bp (was 5bps — too pessimistic)
    "ETHUSDT": 0.0001,  # 1 bp
    # Tier 2: Large-cap alts — decent liquidity
    "SOLUSDT": 0.0003,  # 3 bps (was 10bps)
    "BNBUSDT": 0.0002,  # 2 bps
    "XRPUSDT": 0.0003,  # 3 bps
    "ADAUSDT": 0.0004,  # 4 bps
    "DOGEUSDT": 0.0004, # 4 bps
    "AVAXUSDT": 0.0004, # 4 bps
    "DOTUSDT": 0.0004,  # 4 bps
    "LINKUSDT": 0.0003, # 3 bps
    "MATICUSDT": 0.0004, # 4 bps
    # Tier 3: Mid-cap — can have significant slippage
    "UNIUSDT": 0.0005,  # 5 bps
    "AAVEUSDT": 0.0005, # 5 bps
    "ATOMUSDT": 0.0005, # 5 bps
    "NEARUSDT": 0.0005, # 5 bps
    "FILUSDT": 0.0005,  # 5 bps
    "APTUSDT": 0.0005,  # 5 bps
    "ARBUSDT": 0.0005,  # 5 bps
}

# Default for unknown symbols
CRYPTO_SLIPPAGE_DEFAULT = 0.0005  # 5 bps — conservative for unknown pairs


def get_crypto_slippage(symbol: str) -> float:
    """Get realistic slippage for a crypto pair.

    Args:
        symbol: Trading pair symbol (e.g. "BTCUSDT", "ETHUSDT")

    Returns:
        Slippage as a decimal fraction (e.g. 0.0005 for 5 bps)
    """
    return CRYPTO_SLIPPAGE_TIERS.get(symbol.upper(), CRYPTO_SLIPPAGE_DEFAULT)
