"""
Stock scoring and fitness computation for the evolution engine.

Extracted from auto_evolve.py -- scoring logic, fitness function, and industry exclusion.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional

from stratevo.evolution.models import StrategyDNA, _WEIGHT_KEYS
from stratevo.evolution.indicators_builtin import (
    compute_candle_patterns,
    compute_support_resistance,
    compute_volume_profile,
)


# Import fundamental scoring functions
from stratevo.evolution.fundamentals import (
    compute_pe_score as _compute_pe_score,
    compute_pb_score as _compute_pb_score,
    compute_roe_score as _compute_roe_score,
    compute_growth_score as _compute_growth_score,
    compute_revenue_yoy_score as _compute_revenue_yoy_score,
    compute_revenue_qoq_score as _compute_revenue_qoq_score,
    compute_profit_yoy_score as _compute_profit_yoy_score,
    compute_profit_qoq_score as _compute_profit_qoq_score,
    compute_ps_score as _compute_ps_score,
    compute_peg_score as _compute_peg_score,
    compute_gross_margin_score as _compute_gross_margin_score,
    compute_debt_ratio_score as _compute_debt_ratio_score,
    compute_cashflow_score as _compute_cashflow_score,
)

# Import market state filter (hard rule, not part of evolution)


def score_stock(
    idx: int,
    indicators: Dict[str, Any],
    dna: StrategyDNA,
) -> float:
    """Score a stock at a given index using multi-dimensional DNA weights.

    Args:
        idx: Day index to score
        indicators: Dict with pre-computed indicator arrays
        dna: Strategy parameters

    Returns score in [0, 10] range.
    """
    rsi = indicators["rsi"]
    r2 = indicators["r2"]
    slope = indicators["slope"]
    volume_ratio = indicators["volume_ratio"]
    closes = indicators["close"]

    if idx >= len(rsi) or idx >= len(r2) or idx >= len(slope) or idx >= len(volume_ratio):
        return 0.0

    # Track which core indicators are available (NaN-safe)
    _core_nan = {
        "rsi": math.isnan(rsi[idx]),
        "r2": math.isnan(r2[idx]),
        "slope": math.isnan(slope[idx]),
        "volume_ratio": math.isnan(volume_ratio[idx]),
    }
    # If ALL core indicators are NaN, no data to score → return 0
    if all(_core_nan.values()):
        return 0.0

    # 1. Momentum: higher slope = better (skip if slope is NaN)
    if not _core_nan["slope"]:
        momentum_raw = min(slope[idx] / max(dna.slope_min, 0.01), 2.0) / 2.0
    else:
        momentum_raw = 0.5  # neutral fallback

    # 2. Mean reversion: RSI near buy threshold is good
    if not _core_nan["rsi"]:
        rsi_val = rsi[idx]
        if rsi_val <= dna.rsi_buy_threshold:
            mr_raw = 1.0
        elif rsi_val >= dna.rsi_sell_threshold:
            mr_raw = 0.0
        else:
            rng = dna.rsi_sell_threshold - dna.rsi_buy_threshold
            mr_raw = 1.0 - (rsi_val - dna.rsi_buy_threshold) / rng if rng > 0 else 0.5
    else:
        mr_raw = 0.5  # neutral fallback

    # 3. Volume: higher ratio = better
    if not _core_nan["volume_ratio"]:
        vol_raw = min(volume_ratio[idx] / max(dna.volume_ratio_min, 0.01), 2.0) / 2.0
    else:
        vol_raw = 0.5  # neutral fallback

    # 4. Trend: R² + positive slope + MA alignment
    ma_align = indicators.get("ma_alignment", [0.0] * (idx + 1))
    ma_val = ma_align[idx] if idx < len(ma_align) and not math.isnan(ma_align[idx]) else 0.0
    if not _core_nan["r2"] and not _core_nan["slope"]:
        base_trend = r2[idx] if slope[idx] > 0 else r2[idx] * 0.3
        trend_raw = base_trend * (1.0 + 0.3 * ma_val)  # MA alignment boosts trend
        trend_raw = max(0.0, min(1.0, trend_raw))
    else:
        trend_raw = 0.5  # neutral fallback

    # 5. Pattern: golden dip + candle patterns
    lookback = min(20, idx)
    if lookback > 0:
        recent_high = max(closes[idx - lookback: idx])
        pullback = (recent_high - closes[idx]) / recent_high * 100 if recent_high > 0 else 0
        if dna.dip_threshold_pct > 0 and pullback >= dna.dip_threshold_pct * 0.5 and r2[idx] >= dna.r2_trend_min:
            dip_score = min(pullback / dna.dip_threshold_pct, 1.0)
        else:
            dip_score = 0.0
    else:
        dip_score = 0.0
    candle = compute_candle_patterns(
        indicators["open"], indicators["high"], indicators["low"], closes, idx
    )
    pattern_raw = max(0.0, min(1.0, dip_score * 0.5 + (candle + 1) / 2 * 0.5))

    # 6. MACD
    macd_hist = indicators.get("macd_hist", [float("nan")] * (idx + 1))
    macd_line = indicators.get("macd_line", [float("nan")] * (idx + 1))  # noqa: F841
    macd_signal = indicators.get("macd_signal", [float("nan")] * (idx + 1))  # noqa: F841
    if idx < len(macd_hist) and not math.isnan(macd_hist[idx]) and idx >= 1 and not math.isnan(macd_hist[idx - 1]):
        # Golden cross: histogram turns positive
        if macd_hist[idx] > 0 and macd_hist[idx - 1] <= 0:
            macd_raw = 1.0
        elif macd_hist[idx] > 0:
            macd_raw = 0.7
        elif macd_hist[idx] > macd_hist[idx - 1]:  # improving
            macd_raw = 0.4
        else:
            macd_raw = 0.1
    else:
        macd_raw = 0.5

    # 7. Bollinger Bands
    bb_upper = indicators.get("bb_upper", [float("nan")] * (idx + 1))
    bb_lower = indicators.get("bb_lower", [float("nan")] * (idx + 1))
    bb_middle = indicators.get("bb_middle", [float("nan")] * (idx + 1))  # noqa: F841
    if idx < len(bb_upper) and not math.isnan(bb_upper[idx]) and not math.isnan(bb_lower[idx]):
        bb_range = bb_upper[idx] - bb_lower[idx]
        if bb_range > 0:
            bb_pos = (closes[idx] - bb_lower[idx]) / bb_range
            # Near lower band is bullish (oversold), near upper is bearish
            bb_raw = max(0.0, min(1.0, 1.0 - bb_pos))
        else:
            bb_raw = 0.5
    else:
        bb_raw = 0.5

    # 8. KDJ
    k_val_list = indicators.get("kdj_k", [float("nan")] * (idx + 1))
    d_val_list = indicators.get("kdj_d", [float("nan")] * (idx + 1))
    j_val_list = indicators.get("kdj_j", [float("nan")] * (idx + 1))  # noqa: F841
    if (idx < len(k_val_list) and idx >= 1
            and not math.isnan(k_val_list[idx]) and not math.isnan(k_val_list[idx - 1])):
        k_val = k_val_list[idx]
        d_val = d_val_list[idx]
        # KDJ golden cross: K crosses above D
        if k_val > d_val and k_val_list[idx - 1] <= d_val_list[idx - 1]:
            kdj_raw = 1.0
        elif k_val > d_val:
            kdj_raw = 0.6
        elif k_val < 20:  # oversold zone
            kdj_raw = 0.7
        else:
            kdj_raw = 0.2
    else:
        kdj_raw = 0.5

    # 9. OBV trend
    obv = indicators.get("obv_trend", [float("nan")] * (idx + 1))
    if idx < len(obv) and not math.isnan(obv[idx]):
        # Positive OBV trend = accumulation
        obv_val = obv[idx]
        if obv_val > 0.5:
            obv_raw = 1.0
        elif obv_val > 0:
            obv_raw = 0.5 + obv_val
        elif obv_val > -0.5:
            obv_raw = 0.5 + obv_val
        else:
            obv_raw = 0.0
        obv_raw = max(0.0, min(1.0, obv_raw))
    else:
        obv_raw = 0.5

    # 10. Support/Resistance
    support_raw = compute_support_resistance(
        closes, indicators["high"], indicators["low"], idx
    )

    # 11. Volume Profile
    vprofile_val = compute_volume_profile(indicators["volume"], idx)
    # Map from [-1, 1] to [0, 1]: surge is bullish when price also rising
    if vprofile_val > 0 and slope[idx] > 0:
        vprofile_raw = 0.5 + vprofile_val * 0.5  # volume surge + uptrend = bullish
    elif vprofile_val < 0 and slope[idx] > 0:
        vprofile_raw = 0.3  # low volume pullback in uptrend can be okay
    else:
        vprofile_raw = 0.5 + vprofile_val * 0.25

    vprofile_raw = max(0.0, min(1.0, vprofile_raw))

    # ──── Extended Technical Indicators (12-21) ────

    # Stub indicator names — these always return 0.5 (neutral) and should
    # NOT receive evolved weight.  Their weight is forced to 0.0 to prevent
    # the evolution engine from wasting dimensions on meaningless parameters.
    _STUB_INDICATORS = {"w_adx", "w_vwap", "w_ichimoku", "w_elder_ray"}

    # Helper to safely read a pre-computed indicator at idx
    def _safe_read(key: str, default: float = 0.5) -> float:
        arr = indicators.get(key, None)
        if arr is None or idx >= len(arr):
            return default
        val = arr[idx]
        if isinstance(val, float) and math.isnan(val):
            return default
        return val

    # 12. ATR — lower volatility = safer, score inversely
    # Market-aware: crypto has structurally higher volatility than equities,
    # so thresholds must be adjusted to avoid penalising normal crypto moves.
    atr_val = _safe_read("atr_pct", 0.5)
    _is_crypto = indicators.get("_market") == "crypto"
    if atr_val != 0.5:
        if _is_crypto:
            # Crypto hourly ATR: <3% calm, 3-5% normal, 5-10% volatile, >10% extreme
            if atr_val < 3.0:
                atr_raw = 1.0
            elif atr_val < 5.0:
                atr_raw = 0.8
            elif atr_val < 10.0:
                atr_raw = 0.6
            elif atr_val < 15.0:
                atr_raw = 0.4
            else:
                atr_raw = 0.2
        else:
            # Equities daily ATR
            if atr_val < 1.0:
                atr_raw = 1.0
            elif atr_val < 2.0:
                atr_raw = 0.8
            elif atr_val < 3.0:
                atr_raw = 0.6
            elif atr_val < 5.0:
                atr_raw = 0.4
            else:
                atr_raw = 0.2
    else:
        atr_raw = 0.5

    # 13. ADX — stub (not computed, default neutral)
    adx_raw = 0.5

    # 14. ROC — positive momentum = good
    roc_val = _safe_read("roc", 0.5)
    if roc_val != 0.5:
        if roc_val > 10:
            roc_raw = 1.0
        elif roc_val > 5:
            roc_raw = 0.8
        elif roc_val > 0:
            roc_raw = 0.6
        elif roc_val > -5:
            roc_raw = 0.3
        else:
            roc_raw = 0.1
    else:
        roc_raw = 0.5

    # 15. Williams %R — oversold (<-80) = bullish, overbought (>-20) = bearish
    wr_val = _safe_read("williams_r", 0.5)
    if wr_val != 0.5:
        # %R ranges from -100 to 0
        if wr_val < -80:
            williams_raw = 1.0  # oversold = bullish
        elif wr_val < -50:
            williams_raw = 0.6
        elif wr_val < -20:
            williams_raw = 0.3
        else:
            williams_raw = 0.1  # overbought = bearish
    else:
        williams_raw = 0.5

    # 16. CCI — score based on position
    cci_val = _safe_read("cci", 0.5)
    if cci_val != 0.5:
        if cci_val < -200:
            cci_raw = 1.0   # deeply oversold
        elif cci_val < -100:
            cci_raw = 0.8
        elif cci_val < 0:
            cci_raw = 0.5
        elif cci_val < 100:
            cci_raw = 0.4
        elif cci_val < 200:
            cci_raw = 0.2
        else:
            cci_raw = 0.1
    else:
        cci_raw = 0.5

    # 17. MFI — similar to RSI but volume-weighted
    mfi_val = _safe_read("mfi", 0.5)
    if mfi_val != 0.5:
        if mfi_val < 20:
            mfi_raw = 1.0   # oversold
        elif mfi_val < 40:
            mfi_raw = 0.7
        elif mfi_val < 60:
            mfi_raw = 0.5
        elif mfi_val < 80:
            mfi_raw = 0.3
        else:
            mfi_raw = 0.1   # overbought
    else:
        mfi_raw = 0.5

    # 18. VWAP — stub (needs intraday data), neutral
    vwap_raw = 0.5

    # 19. Donchian — position within channel
    donchian_val = _safe_read("donchian_pos", 0.5)
    if donchian_val != 0.5:
        # Near bottom of channel = bullish (buy low)
        donchian_raw = max(0.0, min(1.0, 1.0 - donchian_val))
    else:
        donchian_raw = 0.5

    # 20. Ichimoku — stub (complex, skip for now), neutral
    ichimoku_raw = 0.5

    # 21. Elder Ray — stub, neutral
    elder_ray_raw = 0.5

    # ──── Rolling Statistics (22-28) ────

    # 22. Beta (slope magnitude as trend strength)
    beta_raw = max(0.0, min(1.0, abs(slope[idx]) / 3.0))

    # 23. R² (trend linearity, already available)
    r2_raw = r2[idx]

    # 24. Residual (mean reversion: if price below regression line = buy signal)
    # Use regression slope to estimate expected vs actual
    residual_raw = 0.5  # default neutral
    if lookback >= 20 and closes[idx] > 0:
        seg = closes[idx - 19:idx + 1]
        if len(seg) == 20:
            mean_y = sum(seg) / 20
            mean_x = 9.5
            ss_xy = sum((j - mean_x) * (seg[j] - mean_y) for j in range(20))
            ss_xx = sum((j - mean_x) ** 2 for j in range(20))
            if ss_xx > 0:
                s = ss_xy / ss_xx
                intercept = mean_y - s * mean_x
                expected = s * 19 + intercept
                residual = (closes[idx] - expected) / closes[idx] * 100
                # Below expected = undervalued (bullish)
                if residual < -3:
                    residual_raw = 1.0
                elif residual < -1:
                    residual_raw = 0.7
                elif residual < 1:
                    residual_raw = 0.5
                elif residual < 3:
                    residual_raw = 0.3
                else:
                    residual_raw = 0.1

    # 25-26. Quantile distance
    quantile_upper_raw = 0.5
    quantile_lower_raw = 0.5
    if lookback >= 20:
        seg = sorted(closes[idx - 19:idx + 1])
        if len(seg) == 20:
            q80 = seg[int(20 * 0.8)]
            q20 = seg[int(20 * 0.2)]
            price = closes[idx]
            if q80 > 0:
                # Distance above 80th quantile: higher = overbought
                quantile_upper_raw = max(0.0, min(1.0, 1.0 - (price - q20) / (q80 - q20))) if q80 != q20 else 0.5
            if q20 > 0:
                quantile_lower_raw = max(0.0, min(1.0, (price - q20) / (q80 - q20))) if q80 != q20 else 0.5

    # 27. Aroon oscillator
    aroon_val = _safe_read("aroon", 0.5)
    if aroon_val != 0.5:
        # aroon range [-1, 1]: positive = recent high-dominant, negative = recent low-dominant
        aroon_raw = max(0.0, min(1.0, (aroon_val + 1.0) / 2.0))
    else:
        aroon_raw = 0.5

    # 28. Price-volume correlation
    pv_corr_val = _safe_read("pv_corr", 0.5)
    if pv_corr_val != 0.5:
        # Positive correlation + uptrend = healthy; negative = divergence
        if slope[idx] > 0:
            pv_corr_raw = max(0.0, min(1.0, (pv_corr_val + 1.0) / 2.0))
        else:
            pv_corr_raw = max(0.0, min(1.0, (1.0 - pv_corr_val) / 2.0))
    else:
        pv_corr_raw = 0.5

    # ──── Fundamental Scores (29-42) ────

    fund = indicators.get("fundamentals", {})

    # Original 4 fundamental factors
    pe_val = fund.get("pe", 0)
    pe_raw = _compute_pe_score(pe_val) if pe_val > 0 else 0.5

    pb_val = fund.get("pb", 0)
    pb_raw = _compute_pb_score(pb_val) if pb_val > 0 else 0.5

    roe_val = fund.get("roe", 0)
    roe_raw = _compute_roe_score(roe_val) if roe_val > 0 else 0.5

    rev_growth = fund.get("revenue_growth", 0)
    growth_raw = _compute_growth_score(rev_growth) if rev_growth != 0 else 0.5

    # New fundamental growth factors
    revenue_yoy_val = fund.get("revenue_yoy", 0)
    revenue_yoy_raw = _compute_revenue_yoy_score(revenue_yoy_val) if revenue_yoy_val != 0 else 0.5

    revenue_qoq_val = fund.get("revenue_qoq", 0)
    revenue_qoq_raw = _compute_revenue_qoq_score(revenue_qoq_val) if revenue_qoq_val != 0 else 0.5

    profit_yoy_val = fund.get("profit_yoy", 0)
    profit_yoy_raw = _compute_profit_yoy_score(profit_yoy_val) if profit_yoy_val != 0 else 0.5

    profit_qoq_val = fund.get("profit_qoq", 0)
    profit_qoq_raw = _compute_profit_qoq_score(profit_qoq_val) if profit_qoq_val != 0 else 0.5

    # Valuation factors
    ps_val = fund.get("ps", 0)
    ps_raw = _compute_ps_score(ps_val) if ps_val > 0 else 0.5

    peg_pe = fund.get("pe", 0)
    peg_growth = fund.get("revenue_growth", 0)
    peg_raw = _compute_peg_score(peg_pe, peg_growth) if peg_pe > 0 and peg_growth > 0 else 0.5

    # Quality factors
    gm_val = fund.get("gross_margin", 0)
    gross_margin_raw = _compute_gross_margin_score(gm_val) if gm_val > 0 else 0.5

    dr_val = fund.get("debt_ratio", 0)
    debt_ratio_raw = _compute_debt_ratio_score(dr_val) if dr_val > 0 else 0.5

    cf_val = fund.get("ocf_to_profit", 0)
    cashflow_raw = _compute_cashflow_score(cf_val) if cf_val != 0 else 0.5

    # ──── Weighted sum with all dimensions ────
    # Force stub indicator weights to 0 so they don't affect the score
    _effective_w_adx = 0.0        # stub — always returns 0.5
    _effective_w_vwap = 0.0       # stub — always returns 0.5
    _effective_w_ichimoku = 0.0   # stub — always returns 0.5
    _effective_w_elder_ray = 0.0  # stub — always returns 0.5

    # ── Crypto: force fundamental weights to 0 (no PE/PB/ROE for crypto) ──
    _FUNDAMENTAL_KEYS = {
        "w_pe", "w_pb", "w_roe", "w_revenue_growth",
        "w_revenue_yoy", "w_revenue_qoq", "w_profit_yoy", "w_profit_qoq",
        "w_ps", "w_peg", "w_gross_margin", "w_debt_ratio", "w_cashflow",
    }
    _effective_stubs = set(_STUB_INDICATORS)
    if _is_crypto:
        _effective_stubs |= _FUNDAMENTAL_KEYS

    def _ew(key: str) -> float:
        """Effective weight: 0 for stub/disabled indicators."""
        return 0.0 if key in _effective_stubs else getattr(dna, key)

    raw = (
        _ew("w_momentum") * momentum_raw
        + _ew("w_mean_reversion") * mr_raw
        + _ew("w_volume") * vol_raw
        + _ew("w_trend") * trend_raw
        + _ew("w_pattern") * pattern_raw
        + _ew("w_macd") * macd_raw
        + _ew("w_bollinger") * bb_raw
        + _ew("w_kdj") * kdj_raw
        + _ew("w_obv") * obv_raw
        + _ew("w_support") * support_raw
        + _ew("w_volume_profile") * vprofile_raw
        # Technical extended
        + _ew("w_atr") * atr_raw
        + _ew("w_adx") * adx_raw
        + _ew("w_roc") * roc_raw
        + _ew("w_williams_r") * williams_raw
        + _ew("w_cci") * cci_raw
        + _ew("w_mfi") * mfi_raw
        + _ew("w_vwap") * vwap_raw
        + _ew("w_donchian") * donchian_raw
        + _ew("w_ichimoku") * ichimoku_raw
        + _ew("w_elder_ray") * elder_ray_raw
        # Rolling statistics
        + _ew("w_beta") * beta_raw
        + _ew("w_r_squared") * r2_raw
        + _ew("w_residual") * residual_raw
        + _ew("w_quantile_upper") * quantile_upper_raw
        + _ew("w_quantile_lower") * quantile_lower_raw
        + _ew("w_aroon") * aroon_raw
        + _ew("w_price_volume_corr") * pv_corr_raw
        # Fundamental (original)
        + _ew("w_pe") * pe_raw
        + _ew("w_pb") * pb_raw
        + _ew("w_roe") * roe_raw
        + _ew("w_revenue_growth") * growth_raw
        # Fundamental growth
        + _ew("w_revenue_yoy") * revenue_yoy_raw
        + _ew("w_revenue_qoq") * revenue_qoq_raw
        + _ew("w_profit_yoy") * profit_yoy_raw
        + _ew("w_profit_qoq") * profit_qoq_raw
        # Fundamental valuation
        + _ew("w_ps") * ps_raw
        + _ew("w_peg") * peg_raw
        # Fundamental quality
        + _ew("w_gross_margin") * gross_margin_raw
        + _ew("w_debt_ratio") * debt_ratio_raw
        + _ew("w_cashflow") * cashflow_raw
    )

    total_weight = sum(
        getattr(dna, k) for k in _WEIGHT_KEYS if k not in _effective_stubs
    )

    # ──── Dynamic factors (from custom_weights via factor discovery) ────
    if hasattr(dna, 'custom_weights') and dna.custom_weights:
        factor_fns = indicators.get("_factor_fns", {})
        closes_raw = indicators.get("close", [])
        highs_raw = indicators.get("high", [])
        lows_raw = indicators.get("low", [])
        vols_raw = indicators.get("volume", [])

        # Truncate data to idx+1 to prevent factors from accessing future data.
        # This is the primary defense against look-ahead bias in custom factors.
        closes_trunc = closes_raw[:idx + 1]
        highs_trunc = highs_raw[:idx + 1]
        lows_trunc = lows_raw[:idx + 1]
        vols_trunc = vols_raw[:idx + 1]

        for fname, w in dna.custom_weights.items():
            if w < 0.0001:
                continue
            if fname not in factor_fns:
                # Factor in DNA but not in registry: use neutral score (0.5)
                # and ADD weight to total_weight to prevent score inflation
                raw += w * 0.5
                total_weight += w
                continue
            try:
                factor_raw = factor_fns[fname](closes_trunc, highs_trunc, lows_trunc, vols_trunc, idx)
                factor_raw = max(0.0, min(1.0, float(factor_raw)))
            except Exception:
                factor_raw = 0.5  # neutral on error
            raw += w * factor_raw
            total_weight += w

    if total_weight > 0:
        raw /= total_weight

    return max(0.0, min(raw * 10.0, 10.0))


def compute_fitness(
    annual_return: float,
    max_drawdown: float,
    win_rate: float,
    sharpe: float,
    total_trades: int = 200,
    sortino: Optional[float] = None,
    max_consec_losses: int = 0,
    monthly_returns: Optional[List[float]] = None,
    positions_used: int = 1,
    max_positions: int = 1,
    avg_turnover: float = 0.0,
    factor_weights: Optional[Dict[str, float]] = None,
) -> float:
    """Compute composite fitness score.

    fitness = annual_return * sqrt(win_rate) / max(max_drawdown, 5.0) * sharpe_bonus * trade_penalty
              * sortino_bonus * consec_loss_penalty * consistency_bonus * diversification_bonus
              * turnover_penalty * factor_diversity_bonus

    Rewards: high return, high win rate, low drawdown, good Sharpe, enough trades,
             Sortino > Sharpe, consistent monthly returns, diversified holdings,
             diversified factor usage.
    Penalizes: fewer than 30 trades, long consecutive loss streaks, very high turnover,
               over-reliance on few factors.
    """
    # Guard against NaN/Inf inputs (can occur from degenerate backtests)
    if not math.isfinite(annual_return):
        return 0.0
    if not math.isfinite(max_drawdown):
        max_drawdown = 100.0
    if not math.isfinite(win_rate):
        win_rate = 0.0
    if not math.isfinite(sharpe):
        sharpe = 0.0

    # Cap extreme annual returns to prevent garbage fitness from short-window artifacts
    _ANNUAL_CAP = 1000.0
    annual_return = min(annual_return, _ANNUAL_CAP)

    # v5: Softer drawdown penalty — use sqrt to let GA explore longer hold periods.
    # When trades are few, dd=0% means insufficient data not robustness;
    # use a higher floor proportional to statistical confidence.
    _dd_floor = 8.0
    if total_trades < 20:
        _dd_floor = max(8.0, 40.0 - total_trades * 1.6)
    dd_denom = math.sqrt(max(max_drawdown, _dd_floor))
    win_factor = math.sqrt(max(win_rate, 0.0))
    sharpe_bonus = 1.0 + min(max(sharpe, 0.0), 3.0) * 0.2
    
    # Penalize very low trade count — allow swing strategies with fewer trades
    if total_trades < 3:
        trade_penalty = 0.05  # almost worthless — too few to judge
    elif total_trades < 20:
        # Continuous ramp: 3 trades -> 0.05, 20 trades -> 1.0
        trade_penalty = 0.05 + 0.95 * (total_trades - 3) / 17.0
    else:
        trade_penalty = 1.0  # no penalty, 20+ trades is statistically meaningful

    # v5: High return bonus — reward strategies that capture big moves (bull market).
    # Encourages GA to hold longer in trending markets instead of quick exit.
    # Cap the bonus to prevent extreme returns from dominating.
    return_bonus = 1.0
    if annual_return > 50:
        return_bonus = 1.0 + min((annual_return - 50) * 0.005, 2.0)  # cap at 3.0x
    elif annual_return > 30:
        return_bonus = 1.0 + (annual_return - 30) * 0.003  # +0.3% per 1% above 30%

    base_fitness = annual_return * win_factor / dd_denom * sharpe_bonus * trade_penalty * return_bonus

    # Sortino-like bonus: if sortino > sharpe, extra 10%
    sortino_bonus = 1.0
    if sortino is not None and sortino > sharpe:
        sortino_bonus = 1.1

    # Max consecutive losses penalty
    consec_loss_penalty = 1.0
    if max_consec_losses > 15:
        consec_loss_penalty = 0.4
    elif max_consec_losses > 10:
        consec_loss_penalty = 0.7

    # Consistency bonus: coefficient of variation of monthly returns
    consistency_bonus = 1.0
    if monthly_returns is not None and len(monthly_returns) >= 3:
        mean_mr = sum(monthly_returns) / len(monthly_returns)
        if mean_mr != 0:
            var_mr = sum((r - mean_mr) ** 2 for r in monthly_returns) / len(monthly_returns)
            std_mr = math.sqrt(var_mr)
            cv = abs(std_mr / mean_mr)
            if cv < 1.0:
                consistency_bonus = 1.2  # consistent returns

    # Diversification bonus: reward strategies that actually hold multiple
    # positions simultaneously (not just max_positions parameter, but real usage)
    diversification_bonus = 1.0
    if positions_used >= 2:
        if max_positions >= 5 and positions_used >= 3:
            diversification_bonus = 1.25  # 25% bonus for wide diversification
        elif max_positions >= 3 and positions_used >= 2:
            diversification_bonus = 1.15  # 15% bonus for moderate diversification

    # Turnover penalty: penalize strategies that churn their portfolio
    # v5 P0-4: Strengthened — high turnover eats real profits via fees/slippage
    # Estimate real turnover cost: ~0.3% round trip (commission + stamp + slippage)
    # avg_turnover=1.0 means 100% portfolio change per rebalance
    turnover_penalty = 1.0
    if avg_turnover > 0.8:
        # Heavy churn: each rebalance costs ~0.3% x turnover_ratio
        # For hold_days=3, that's ~25 rebalances/year, 0.8*0.3%*25 = 6% annual drag
        turnover_penalty = 0.70  # severe penalty
    elif avg_turnover > 0.6:
        turnover_penalty = 0.80
    elif avg_turnover > 0.4:
        turnover_penalty = 0.90

    # === v5 P0-3: Factor diversity bonus (anti-concentration) ===
    # Penalize strategies that rely on very few factors.
    # Uses Herfindahl–Hirschman Index (HHI) of factor weights.
    # More diversified factor usage → more robust to individual factor decay.
    factor_diversity_bonus = 1.0
    if factor_weights is not None:
        active_weights = [w for w in factor_weights.values() if w >= 0.001]
        if len(active_weights) >= 3:
            total_w = sum(active_weights)
            if total_w > 0:
                # Normalize weights to sum to 1
                normed = [w / total_w for w in active_weights]
                # HHI: sum of squared shares (1/N for equal, 1.0 for single factor)
                hhi = sum(s ** 2 for s in normed)
                # Ideal HHI for N factors: 1/N
                ideal_hhi = 1.0 / len(normed)
                # Ratio: how close to ideal (1.0 = perfect diversification)
                diversity_ratio = ideal_hhi / max(hhi, ideal_hhi)
                # Bonus: up to 15% for well-diversified, penalty for concentrated
                if diversity_ratio > 0.5:
                    factor_diversity_bonus = 1.0 + 0.15 * diversity_ratio
                else:
                    factor_diversity_bonus = 0.85 + 0.3 * diversity_ratio

    result = (base_fitness * sortino_bonus * consec_loss_penalty
              * consistency_bonus * diversification_bonus * turnover_penalty
              * factor_diversity_bonus)

    # Overflow protection: cap to prevent inf from extreme inputs
    if not math.isfinite(result):
        return 0.0
    return max(-1e8, min(1e8, result))


# ────────────────── Excluded industry codes ──────────────────
# These sectors are excluded from the stock pool because they either:
#   - Have structurally low volatility that drags evolution fitness (highways, banks)
#   - Are in long-term structural decline / policy headwinds (real estate, coal)
#   - Have cyclical overcapacity issues making momentum signals unreliable (steel)
# Codes cover major A-share constituents in each sector.
_EXCLUDED_INDUSTRY_CODES = {
    # ── 房地产开发 (Real estate developers) ──
    # Structural decline: policy tightening ("房住不炒"), debt crises, shrinking demand
    "sh_600048",  # 保利发展
    "sz_000002",  # 万科A
    "sh_600606",  # 绿地控股
    "sz_001979",  # 招商蛇口
    "sh_600340",  # 华夏幸福
    "sz_000069",  # 华侨城A
    "sh_600383",  # 金地集团
    "sz_002146",  # 荣盛发展
    "sh_601155",  # 新城控股
    "sz_000031",  # 大悦城
    "sh_600325",  # 华发股份
    "sz_000656",  # 金科股份
    "sh_600208",  # 新湖中宝
    "sz_000961",  # 中南建设
    "sh_600823",  # 世茂股份（世茂集团A股平台）
    "sz_002244",  # 滨江集团
    "sh_600895",  # 张江高科
    "sh_600007",  # 中国国贸
    "sz_000402",  # 金融街
    "sz_000718",  # 苏宁环球
    "sh_600376",  # 首开股份
    "sh_601588",  # 北辰实业
    "sz_002285",  # 世联行
    "sh_600466",  # 蓝光发展
    "sz_000014",  # 沙河股份
    "sz_000006",  # 深振业A

    # ── 煤炭开采 (Coal mining) ──
    # Carbon transition headwinds, policy caps, cyclical overcapacity
    "sh_601088",  # 中国神华
    "sh_600188",  # 兖矿能源
    "sh_601898",  # 中煤能源
    "sz_000983",  # 西山煤电（山西焦煤）
    "sh_600395",  # 盘江股份
    "sh_601666",  # 平煤股份
    "sh_600985",  # 淮北矿业
    "sh_601001",  # 大同煤业（晋控煤业）
    "sh_600546",  # 山煤国际
    "sz_000937",  # 冀中能源
    "sz_000968",  # 蓝焰控股
    "sh_600121",  # 郑州煤电
    "sh_600348",  # 阳泉煤业（华阳股份）
    "sz_002128",  # 露天煤业
    "sh_600508",  # 上海能源
    "sh_601699",  # 潞安环能
    "sz_000552",  # 靖远煤电
    "sh_600397",  # 安源煤业
    "sh_600971",  # 恒源煤电

    # ── 钢铁 (Steel) ──
    # Chronic overcapacity, thin margins, policy-driven production cuts
    "sh_600019",  # 宝钢股份
    "sz_000898",  # 鞍钢股份
    "sh_600010",  # 包钢股份
    "sh_600022",  # 山东钢铁
    "sz_000709",  # 河钢股份
    "sh_600569",  # 安阳钢铁
    "sz_000932",  # 华菱钢铁
    "sz_000959",  # 首钢股份
    "sh_600782",  # 新钢股份
    "sh_601003",  # 柳钢股份
    "sz_000825",  # 太钢不锈
    "sh_600808",  # 马钢股份
    "sh_600507",  # 方大特钢
    "sz_000708",  # 中信特钢
    "sh_600282",  # 南钢股份
    "sh_600005",  # 武钢股份（已退市/合并，保留以防数据残留）
    "sh_600126",  # 杭钢股份
    "sz_000761",  # 本钢板材
    "sh_601005",  # 重庆钢铁
    "sz_002756",  # 永兴材料

    # ── 高速公路/交通基础设施 (Highways / Transport infrastructure) ──
    # Ultra-low volatility, bond-like returns, drags evolution fitness
    "sh_600012",  # 皖通高速
    "sh_600020",  # 中原高速
    "sh_600033",  # 福建高速
    "sh_600035",  # 楚天高速
    "sh_600350",  # 山东高速
    "sh_600377",  # 宁沪高速
    "sz_000429",  # 粤高速A
    "sz_000548",  # 湖南投资
    "sz_000828",  # 东莞控股
    "sz_000900",  # 现代投资
    "sh_601107",  # 四川成渝
    "sh_600269",  # 赣粤高速
    "sz_002357",  # 富临运业
    "sh_600368",  # 五洲交通
    "sz_000916",  # 华北高速（已更名招商公路子公司）
    "sh_001965",  # 招商公路
}

