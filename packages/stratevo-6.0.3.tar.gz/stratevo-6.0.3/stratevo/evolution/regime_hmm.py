"""
Hidden Markov Model (HMM) Regime Detector
==========================================
Detects market regimes (bull/bear/sideways) using a Gaussian HMM.

Uses hmmlearn.GaussianHMM if available, otherwise falls back to
a pure-numpy implementation (simplified Baum-Welch / EM with
forward-backward inference and K-means initialization).
"""

from __future__ import annotations

import warnings
from typing import Optional

import numpy as np

# ---------------------------------------------------------------------------
# Try importing hmmlearn; flag availability
# ---------------------------------------------------------------------------
try:
    from hmmlearn.hmm import GaussianHMM as _HMMLearnGaussianHMM

    _HAS_HMMLEARN = True
except ImportError:
    _HAS_HMMLEARN = False

# Default regime names ordered by convention (assigned post-fit by mean return)
_DEFAULT_REGIME_NAMES = ("bull", "bear", "sideways")


# ===================================================================
# Pure-numpy fallback: mini GaussianHMM implementation
# ===================================================================

class _NumpyGaussianHMM:
    """Minimal Gaussian HMM trained with Baum-Welch (EM).

    Supports diagonal covariance only (each feature independent given state).
    Initialisation uses K-means clustering on the observation features.
    """

    def __init__(self, n_components: int = 3, n_iter: int = 100,
                 tol: float = 1e-4, random_state: int = 42):
        self.n_components = n_components
        self.n_iter = n_iter
        self.tol = tol
        self.rng = np.random.RandomState(random_state)

        # Model parameters (set after fit)
        self.startprob_: Optional[np.ndarray] = None
        self.transmat_: Optional[np.ndarray] = None
        self.means_: Optional[np.ndarray] = None
        self.covars_: Optional[np.ndarray] = None  # shape (K, D) diagonal

    # ----- K-means initialisation -----

    def _kmeans_init(self, X: np.ndarray) -> np.ndarray:
        """Simple K-means to seed means/covars. Returns cluster labels."""
        N, D = X.shape
        K = self.n_components

        # Pick K random distinct rows as initial centres
        idx = self.rng.choice(N, size=min(K, N), replace=False)
        centres = X[idx].copy()

        labels = np.zeros(N, dtype=int)
        for _ in range(30):
            # Assign
            dists = np.array([np.sum((X - centres[k]) ** 2, axis=1) for k in range(K)])  # (K, N)
            labels = np.argmin(dists, axis=0)
            # Update
            new_centres = np.zeros_like(centres)
            for k in range(K):
                members = X[labels == k]
                if len(members) > 0:
                    new_centres[k] = members.mean(axis=0)
                else:
                    new_centres[k] = centres[k]
            if np.allclose(new_centres, centres, atol=1e-8):
                break
            centres = new_centres

        # Store initial params
        self.means_ = centres.copy()
        self.covars_ = np.zeros((K, D), dtype=np.float64)
        for k in range(K):
            members = X[labels == k]
            if len(members) > 1:
                self.covars_[k] = np.var(members, axis=0) + 1e-6
            else:
                self.covars_[k] = np.var(X, axis=0) + 1e-6

        # Uniform start / transition priors
        self.startprob_ = np.full(K, 1.0 / K)
        self.transmat_ = np.full((K, K), 1.0 / K)

        return labels

    # ----- Gaussian log-likelihood helpers -----

    def _log_gauss(self, X: np.ndarray) -> np.ndarray:
        """Compute log N(x | mu_k, diag(sigma_k)) for each state k.

        Returns array of shape (N, K).
        """
        N, D = X.shape
        K = self.n_components
        log_prob = np.zeros((N, K), dtype=np.float64)
        for k in range(K):
            diff = X - self.means_[k]  # (N, D)
            var = self.covars_[k]  # (D,)
            log_prob[:, k] = -0.5 * (
                D * np.log(2 * np.pi)
                + np.sum(np.log(var))
                + np.sum(diff ** 2 / var, axis=1)
            )
        return log_prob

    # ----- Forward-backward -----

    def _forward(self, log_obs: np.ndarray):
        """Scaled forward pass. Returns log_alpha (N, K) and log-likelihood."""
        N, K = log_obs.shape
        log_alpha = np.full((N, K), -np.inf, dtype=np.float64)

        # t = 0
        log_alpha[0] = np.log(self.startprob_ + 1e-300) + log_obs[0]

        log_transmat = np.log(self.transmat_ + 1e-300)  # (K, K)

        for t in range(1, N):
            for j in range(K):
                log_alpha[t, j] = _logsumexp(log_alpha[t - 1] + log_transmat[:, j]) + log_obs[t, j]

        log_ll = _logsumexp(log_alpha[-1])
        return log_alpha, log_ll

    def _backward(self, log_obs: np.ndarray):
        """Scaled backward pass. Returns log_beta (N, K)."""
        N, K = log_obs.shape
        log_beta = np.full((N, K), -np.inf, dtype=np.float64)
        log_beta[-1] = 0.0  # log(1)

        log_transmat = np.log(self.transmat_ + 1e-300)

        for t in range(N - 2, -1, -1):
            for i in range(K):
                log_beta[t, i] = _logsumexp(
                    log_transmat[i, :] + log_obs[t + 1] + log_beta[t + 1]
                )
        return log_beta

    # ----- EM (Baum-Welch) -----

    def fit(self, X: np.ndarray) -> "_NumpyGaussianHMM":
        """Fit the HMM to observation matrix X (N, D)."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        N, D = X.shape
        K = self.n_components

        self._kmeans_init(X)

        prev_ll = -np.inf

        for iteration in range(self.n_iter):
            log_obs = self._log_gauss(X)  # (N, K)
            log_alpha, log_ll = self._forward(log_obs)
            log_beta = self._backward(log_obs)

            # Convergence check
            if abs(log_ll - prev_ll) < self.tol:
                break
            prev_ll = log_ll

            # Posterior: gamma(t, k) = P(state_t = k | X)
            log_gamma = log_alpha + log_beta
            log_gamma -= _logsumexp_2d(log_gamma)  # normalise per row
            gamma = np.exp(log_gamma)

            # Xi: P(state_t=i, state_{t+1}=j | X)
            log_transmat = np.log(self.transmat_ + 1e-300)
            xi = np.zeros((K, K), dtype=np.float64)
            for t in range(N - 1):
                for i in range(K):
                    for j in range(K):
                        xi[i, j] += np.exp(
                            log_alpha[t, i]
                            + log_transmat[i, j]
                            + log_obs[t + 1, j]
                            + log_beta[t + 1, j]
                            - log_ll
                        )

            # M-step: update parameters
            # Start prob
            self.startprob_ = gamma[0] / gamma[0].sum()

            # Transition matrix
            row_sums = xi.sum(axis=1, keepdims=True)
            row_sums[row_sums == 0] = 1.0
            self.transmat_ = xi / row_sums

            # Means and covariances
            for k in range(K):
                w = gamma[:, k]  # (N,)
                w_sum = w.sum()
                if w_sum < 1e-10:
                    continue
                self.means_[k] = (w[:, None] * X).sum(axis=0) / w_sum
                diff = X - self.means_[k]
                self.covars_[k] = (w[:, None] * diff ** 2).sum(axis=0) / w_sum + 1e-6

        return self

    # ----- Predict & score -----

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Viterbi-like: return most-probable state sequence (argmax gamma)."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        log_obs = self._log_gauss(X)
        log_alpha, _ = self._forward(log_obs)
        log_beta = self._backward(log_obs)
        log_gamma = log_alpha + log_beta
        log_gamma -= _logsumexp_2d(log_gamma)
        return np.argmax(log_gamma, axis=1)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return posterior probabilities gamma (N, K)."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        log_obs = self._log_gauss(X)
        log_alpha, _ = self._forward(log_obs)
        log_beta = self._backward(log_obs)
        log_gamma = log_alpha + log_beta
        log_gamma -= _logsumexp_2d(log_gamma)
        return np.exp(log_gamma)

    def score(self, X: np.ndarray) -> float:
        """Return total log-likelihood of observation sequence."""
        if X.ndim == 1:
            X = X.reshape(-1, 1)
        log_obs = self._log_gauss(X)
        _, log_ll = self._forward(log_obs)
        return float(log_ll)


# ===================================================================
# Numerically stable helpers
# ===================================================================

def _logsumexp(x: np.ndarray) -> float:
    """Log-sum-exp over a 1-D array."""
    c = np.max(x)
    if np.isinf(c):
        return float(c)
    return float(c + np.log(np.sum(np.exp(x - c))))


def _logsumexp_2d(x: np.ndarray) -> np.ndarray:
    """Row-wise log-sum-exp for a 2-D array; returns column vector."""
    c = np.max(x, axis=1, keepdims=True)
    return c + np.log(np.sum(np.exp(x - c), axis=1, keepdims=True))


# ===================================================================
# Public API: HMMRegimeDetector
# ===================================================================

class HMMRegimeDetector:
    """Detect market regimes using a Gaussian Hidden Markov Model.

    Features per time-step:
        1. daily log-return
        2. rolling volatility (std of returns)
        3. volume change (pct change of volume)

    After fitting, states are labelled by mean return:
        highest  → "bull"
        lowest   → "bear"
        middle   → "sideways"
    """

    def __init__(
        self,
        n_regimes: int = 3,
        regime_names: tuple[str, ...] | list[str] | None = None,
        vol_window: int = 20,
        n_iter: int = 100,
        random_state: int = 42,
    ):
        self.n_regimes = n_regimes
        self.regime_names = list(regime_names) if regime_names else list(_DEFAULT_REGIME_NAMES[:n_regimes])
        self.vol_window = vol_window
        self.n_iter = n_iter
        self.random_state = random_state

        self._model = None  # fitted HMM model
        self._label_map: dict[int, str] = {}  # state_id → regime name
        self._fitted = False
        self._using_hmmlearn = _HAS_HMMLEARN

    # ----------------------------------------------------------------
    # Feature engineering
    # ----------------------------------------------------------------

    @staticmethod
    def _build_features(
        prices: list[float] | np.ndarray,
        volumes: list[float] | np.ndarray | None,
        vol_window: int = 20,
    ) -> np.ndarray:
        """Build (N-1, D) feature matrix from prices and optional volumes."""
        prices = np.asarray(prices, dtype=np.float64)
        n = len(prices)
        if n < 3:
            raise ValueError("Need at least 3 price points")

        # 1. Log returns
        log_ret = np.diff(np.log(prices))  # length n-1

        # 2. Rolling volatility (std of returns over a window)
        roll_vol = np.zeros(n - 1, dtype=np.float64)
        for i in range(n - 1):
            start = max(0, i - vol_window + 1)
            roll_vol[i] = np.std(log_ret[start:i + 1]) if i > 0 else abs(log_ret[0])

        # 3. Volume change
        if volumes is not None:
            volumes = np.asarray(volumes, dtype=np.float64)
            # volumes may have length n or n-1+1; we need vol_chg of length n-1
            # If volumes has length n, take pct change → n-1 (aligned with returns)
            if len(volumes) >= n:
                volumes = volumes[:n]  # truncate to match prices
            vol_safe = np.where(volumes == 0, 1.0, volumes)
            vol_chg = np.diff(vol_safe) / vol_safe[:-1]  # length n-1
            # If volumes was shorter than n, pad with zeros
            if len(vol_chg) < n - 1:
                vol_chg = np.concatenate([vol_chg, np.zeros(n - 1 - len(vol_chg))])
        else:
            vol_chg = np.zeros(n - 1, dtype=np.float64)

        features = np.column_stack([log_ret, roll_vol, vol_chg])
        return features

    # ----------------------------------------------------------------
    # Regime labelling
    # ----------------------------------------------------------------

    def _assign_labels(self, features: np.ndarray, states: np.ndarray) -> None:
        """Assign regime name to each state id based on mean return."""
        K = self.n_regimes
        mean_returns = np.zeros(K, dtype=np.float64)
        for k in range(K):
            mask = states == k
            if mask.any():
                mean_returns[k] = features[mask, 0].mean()  # col 0 = log return
            else:
                mean_returns[k] = 0.0

        # Sort states by mean return: lowest → bear, middle → sideways, highest → bull
        sorted_states = np.argsort(mean_returns)  # ascending order

        if K >= 3:
            # bear=lowest, sideways=middle, bull=highest
            names_sorted = list(self.regime_names)  # user-supplied or default
            # We need to map: sorted_states[0] → "bear", sorted_states[-1] → "bull", rest → "sideways"
            self._label_map = {}
            self._label_map[int(sorted_states[0])] = names_sorted[1]   # bear (index 1 in default)
            self._label_map[int(sorted_states[-1])] = names_sorted[0]  # bull (index 0 in default)
            for idx in sorted_states[1:-1]:
                self._label_map[int(idx)] = names_sorted[2]  # sideways
        elif K == 2:
            self._label_map = {
                int(sorted_states[0]): self.regime_names[1],   # bear
                int(sorted_states[1]): self.regime_names[0],   # bull
            }
        else:
            self._label_map = {0: self.regime_names[0]}

    # ----------------------------------------------------------------
    # Public methods
    # ----------------------------------------------------------------

    def fit(
        self,
        prices: list[float] | np.ndarray,
        volumes: list[float] | np.ndarray | None = None,
    ) -> "HMMRegimeDetector":
        """Fit the HMM on historical price/volume data.

        Returns self for chaining.
        """
        features = self._build_features(prices, volumes, self.vol_window)

        if _HAS_HMMLEARN:
            self._using_hmmlearn = True
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                model = _HMMLearnGaussianHMM(
                    n_components=self.n_regimes,
                    covariance_type="diag",
                    n_iter=self.n_iter,
                    random_state=self.random_state,
                )
                model.fit(features)
            self._model = model
            states = model.predict(features)
        else:
            self._using_hmmlearn = False
            model = _NumpyGaussianHMM(
                n_components=self.n_regimes,
                n_iter=self.n_iter,
                random_state=self.random_state,
            )
            model.fit(features)
            self._model = model
            states = model.predict(features)

        self._assign_labels(features, states)
        self._fitted = True
        return self

    def predict(
        self,
        prices: list[float] | np.ndarray,
        volumes: list[float] | np.ndarray | None = None,
    ) -> list[str]:
        """Predict regime label for each day (returns n-1 labels for n prices).

        If not yet fitted, calls fit() first on the same data.
        """
        if not self._fitted:
            self.fit(prices, volumes)

        features = self._build_features(prices, volumes, self.vol_window)
        states = self._model.predict(features)
        return [self._label_map.get(int(s), "unknown") for s in states]

    def current_regime(
        self,
        prices: list[float] | np.ndarray,
        volumes: list[float] | np.ndarray | None = None,
    ) -> tuple[str, float]:
        """Return (regime_name, confidence) for the most recent time step.

        Confidence is the posterior probability of the assigned state.
        """
        if not self._fitted:
            self.fit(prices, volumes)

        features = self._build_features(prices, volumes, self.vol_window)

        if _HAS_HMMLEARN:
            proba = self._model.predict_proba(features)
        else:
            proba = self._model.predict_proba(features)

        last_proba = proba[-1]  # (K,)
        state_id = int(np.argmax(last_proba))
        confidence = float(last_proba[state_id])
        regime = self._label_map.get(state_id, "unknown")
        return regime, confidence

    def regime_probabilities(
        self,
        prices: list[float] | np.ndarray,
        volumes: list[float] | np.ndarray | None = None,
    ) -> dict[str, float]:
        """Return probability of each named regime for the most recent step."""
        if not self._fitted:
            self.fit(prices, volumes)

        features = self._build_features(prices, volumes, self.vol_window)

        if _HAS_HMMLEARN:
            proba = self._model.predict_proba(features)
        else:
            proba = self._model.predict_proba(features)

        last_proba = proba[-1]
        result: dict[str, float] = {}
        for state_id, name in self._label_map.items():
            if name in result:
                result[name] += float(last_proba[state_id])
            else:
                result[name] = float(last_proba[state_id])
        return result

    @property
    def transition_matrix(self) -> np.ndarray | None:
        """Return the fitted transition probability matrix (K×K)."""
        if self._model is None:
            return None
        return np.array(self._model.transmat_)

    @property
    def is_fitted(self) -> bool:
        return self._fitted

    @property
    def backend(self) -> str:
        """Return 'hmmlearn' or 'numpy' depending on which backend is active."""
        if self._using_hmmlearn:
            return "hmmlearn"
        return "numpy"
