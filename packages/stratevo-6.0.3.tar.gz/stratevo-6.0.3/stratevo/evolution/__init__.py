"""stratevo.evolution - Strategy evolution engine."""
