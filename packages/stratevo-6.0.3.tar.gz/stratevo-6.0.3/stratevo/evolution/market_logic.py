"""
Market Logic Layer — Guided factor evolution inspired by AlphaLogics.

Instead of blind random mutation across all 284+ factors, Market Logic
defines high-level trading hypotheses that bias mutation toward
semantically relevant factors.

Each MarketLogic maps to:
  - A set of preferred builtin weight keys (w_momentum, w_roc, etc.)
  - A set of preferred dynamic factor names (from factors/ directory)
  - A mutation bias: factors aligned with the logic get higher mutation
    probability; a configurable exploration_ratio (default 30%) ensures
    random mutations still happen for serendipitous discovery.

Architecture:
  MarketLogic       — defines one trading hypothesis + its preferred factors
  LogicGuidedMutator — wraps AutoEvolver.mutate() with logic-based biasing
  LogicEvolver       — manages logic switching over generations
"""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set

from stratevo.evolution.auto_evolve import StrategyDNA, _WEIGHT_KEYS, _PARAM_RANGES


# ============================================================
# Logic Definitions
# ============================================================

class LogicType(str, Enum):
    """Predefined market logic types."""
    MOMENTUM_FOLLOWING = "momentum_following"
    MEAN_REVERSION = "mean_reversion"
    VOLATILITY_BREAKOUT = "volatility_breakout"
    MONEY_FLOW = "money_flow"
    BOTTOM_FISHING = "bottom_fishing"
    TREND_FOLLOWING = "trend_following"
    VALUE_INVESTING = "value_investing"
    MARKET_SENTIMENT = "market_sentiment"


@dataclass
class MarketLogic:
    """A high-level trading hypothesis that guides factor search.

    Attributes:
        name: Human-readable name (e.g. "Momentum Following")
        logic_type: Enum key for programmatic access
        description: One-line Chinese + English description
        preferred_builtin_weights: Builtin weight keys this logic favors
        preferred_factor_names: Dynamic factor names this logic favors
        preferred_factor_categories: Factor categories this logic favors
            (used to auto-discover new factors matching the logic)
    """
    name: str
    logic_type: LogicType
    description: str
    preferred_builtin_weights: List[str] = field(default_factory=list)
    preferred_factor_names: List[str] = field(default_factory=list)
    preferred_factor_categories: List[str] = field(default_factory=list)

    def get_all_preferred_factor_names(
        self, available_factors: Optional[Dict[str, str]] = None,
    ) -> Set[str]:
        """Return the full set of preferred factor names.

        Combines explicit preferred_factor_names with any factors whose
        category matches preferred_factor_categories.

        Args:
            available_factors: Dict of factor_name -> category from the
                factor registry.  If None, only explicit names are returned.
        """
        names: Set[str] = set(self.preferred_factor_names)
        if available_factors:
            for fname, cat in available_factors.items():
                if cat in self.preferred_factor_categories:
                    names.add(fname)
        return names

    def __repr__(self) -> str:
        return f"MarketLogic({self.logic_type.value!r})"


class CompositeLogic:
    """Combine multiple MarketLogic instances for hybrid strategies.

    Example: Momentum Following + Money Flow = "只买放量动量股"
    """

    def __init__(self, logics: List[MarketLogic]):
        if not logics:
            raise ValueError("CompositeLogic requires at least one logic")
        self.logics = logics
        self.name = " + ".join(l.name for l in logics)

    @property
    def preferred_builtin_weights(self) -> Set[str]:
        result: Set[str] = set()
        for logic in self.logics:
            result.update(logic.preferred_builtin_weights)
        return result

    def get_all_preferred_factor_names(
        self, available_factors: Optional[Dict[str, str]] = None,
    ) -> Set[str]:
        result: Set[str] = set()
        for logic in self.logics:
            result.update(logic.get_all_preferred_factor_names(available_factors))
        return result

    def __repr__(self) -> str:
        types = [l.logic_type.value for l in self.logics]
        return f"CompositeLogic({types})"


# ============================================================
# Predefined Logics (8 种)
# ============================================================

PREDEFINED_LOGICS: Dict[LogicType, MarketLogic] = {
    LogicType.MOMENTUM_FOLLOWING: MarketLogic(
        name="动量追踪 (Momentum Following)",
        logic_type=LogicType.MOMENTUM_FOLLOWING,
        description="偏好 ROC、趋势强度、MA 对齐、价格动量等因子",
        preferred_builtin_weights=[
            "w_momentum", "w_roc", "w_adx", "w_aroon",
            "w_trend", "w_macd",
        ],
        preferred_factor_names=[
            "momentum_10d", "momentum_3d", "acceleration", "trend_acceleration",
            "trend_strength_slope", "trend_consistency", "higher_highs",
            "higher_lows", "price_efficiency", "price_percentile",
            "pullback_depth", "recovery_speed", "gap_momentum",
            "momentum_divergence", "momentum_quality",
            "trend_momentum_confirmation", "quality_momentum",
            "quality_momentum_rank",
            "alpha_rank_return_20d", "alpha_rank_return_5d",
            "cumulative_return_rank", "outperformance_20d", "outperformance_5d",
            "recent_vs_old_return",
        ],
        preferred_factor_categories=[
            "momentum", "relative_performance",
        ],
    ),

    LogicType.MEAN_REVERSION: MarketLogic(
        name="均值回归 (Mean Reversion)",
        logic_type=LogicType.MEAN_REVERSION,
        description="偏好 RSI 超卖、布林带下轨、Z-score、回归残差等因子",
        preferred_builtin_weights=[
            "w_mean_reversion", "w_bollinger", "w_williams_r", "w_cci",
            "w_residual", "w_quantile_lower", "w_quantile_upper",
        ],
        preferred_factor_names=[
            "zscore_20d", "zscore_60d", "distance_to_mean_pct",
            "mean_cross_up", "mean_cross_down", "mean_reversion_speed",
            "consecutive_pattern", "oversold_bounce_setup",
            "price_oscillator", "reversion_pressure", "rubber_band",
            "rsi_divergence", "midpoint_reversion",
            "alpha_return_reversal",
            "stochastic_fast", "stochastic_slow",
        ],
        preferred_factor_categories=[
            "mean_reversion",
        ],
    ),

    LogicType.VOLATILITY_BREAKOUT: MarketLogic(
        name="波动率突破 (Volatility Breakout)",
        logic_type=LogicType.VOLATILITY_BREAKOUT,
        description="偏好 ATR 突破、波动率比率、布林挤压、突破确认等因子",
        preferred_builtin_weights=[
            "w_atr", "w_bollinger", "w_donchian", "w_beta",
        ],
        preferred_factor_names=[
            "bollinger_squeeze", "breakout_confirmation", "breakout_probability",
            "atr_channel_position", "range_expansion", "range_contraction",
            "narrow_range_7", "wide_range_bar", "keltner_position",
            "chaikin_volatility", "vol_ratio_10_30", "vol_skew",
            "volatility_regime", "realized_vol_10d", "realized_vol_30d",
            "intraday_range", "max_drawdown_5d",
            "resistance_breakout", "trend_breakout_new_high",
            "new_high_20d", "new_high_60d",
            "price_channel_upper", "price_channel_lower",
        ],
        preferred_factor_categories=[
            "volatility",
        ],
    ),

    LogicType.MONEY_FLOW: MarketLogic(
        name="资金流向 (Money Flow)",
        logic_type=LogicType.MONEY_FLOW,
        description="偏好 OBV、资金流入、大单比例、成交量异动等因子",
        preferred_builtin_weights=[
            "w_obv", "w_mfi", "w_volume", "w_volume_profile",
            "w_price_volume_corr",
        ],
        preferred_factor_names=[
            "obv_divergence", "smart_money_flow", "smart_money_index",
            "smart_money_divergence", "volume_breakout", "volume_climax",
            "volume_trend", "volume_at_high", "up_volume_ratio",
            "volume_dry_up", "volume_reversal",
            "consecutive_volume_increase", "volume_acceleration",
            "unusual_volume_spike", "relative_volume_rank",
            "up_down_volume_ratio_20d", "volume_price_divergence",
            "volume_price_confirmation", "liquidity_shock",
            "institutional_accumulation", "institutional_buying_proxy",
            "accumulation_day", "distribution_day",
            "accumulation_distribution_ratio",
            "trade_intensity", "turnover_anomaly",
        ],
        preferred_factor_categories=[
            "volume", "flow", "microstructure",
        ],
    ),

    LogicType.BOTTOM_FISHING: MarketLogic(
        name="底部捕捉 (Bottom Fishing)",
        logic_type=LogicType.BOTTOM_FISHING,
        description="偏好 KDJ 金叉、底背离、放量反转、底部形态等因子",
        preferred_builtin_weights=[
            "w_kdj", "w_mean_reversion", "w_pattern", "w_support",
            "w_williams_r", "w_cci",
        ],
        preferred_factor_names=[
            "bottom_consecutive_decline_exhaustion", "bottom_long_lower_shadow",
            "bottom_reversal_candle", "bottom_support_bounce",
            "bottom_volume_decline_stabilize",
            "hammer", "morning_star", "engulfing_bullish",
            "doji", "two_day_reversal", "island_reversal",
            "support_bounce", "spring_pattern",
            "capitulation_signal", "capitulation_recovery",
            "selling_climax", "stopping_volume", "shakeout",
            "post_crash_recovery", "oversold_bounce_setup",
            "consecutive_down_days",
            "distance_from_52w_low",
            "previous_low_test",
            "follow_through_day",
        ],
        preferred_factor_categories=[
            "bottom_confirmation", "wyckoff_vsa",
        ],
    ),

    LogicType.TREND_FOLLOWING: MarketLogic(
        name="趋势跟随 (Trend Following)",
        logic_type=LogicType.TREND_FOLLOWING,
        description="偏好 MA 对齐、趋势通道、ADX 强度、回调买入等因子",
        preferred_builtin_weights=[
            "w_trend", "w_adx", "w_ichimoku", "w_donchian",
            "w_r_squared", "w_beta", "w_aroon",
        ],
        preferred_factor_names=[
            "trend_adx_strength", "trend_breakout_new_high",
            "trend_channel_position", "trend_consistency",
            "trend_ema_golden_cross", "trend_higher_highs_lows",
            "trend_ma_fan_bullish", "trend_momentum_confirmation",
            "trend_price_above_all_ma", "trend_pullback_in_uptrend",
            "trend_quality", "trend_strength_slope",
            "ma_fan_out", "ma_squeeze", "ma5_10_cross", "ma10_20_cross",
            "ma5_bounce", "ma10_bounce", "ma20_bounce",
            "ma5_distance", "ma20_distance",
            "price_above_all_ma",
            "pullback_healthy_retracement", "pullback_ma20_bounce",
            "pullback_uptrend_dip", "pullback_volume_dry_up",
            "quality_trend_persistence", "quality_price_vs_200d_ma",
            "hurst_exponent",
        ],
        preferred_factor_categories=[
            "trend_following", "moving_average", "pullback_strategy",
        ],
    ),

    LogicType.VALUE_INVESTING: MarketLogic(
        name="价值投资 (Value Investing)",
        logic_type=LogicType.VALUE_INVESTING,
        description="偏好 PE/PB/ROE/PEG 等基本面因子 + 价值动量融合",
        preferred_builtin_weights=[
            "w_pe", "w_pb", "w_roe", "w_revenue_growth",
            "w_revenue_yoy", "w_revenue_qoq", "w_profit_yoy", "w_profit_qoq",
            "w_ps", "w_peg", "w_gross_margin", "w_debt_ratio", "w_cashflow",
        ],
        preferred_factor_names=[
            "value_momentum", "value_quality",
            "davis_margin_expansion", "davis_revenue_acceleration",
            "davis_sector_outperformer", "davis_small_cap_elasticity",
            "davis_supply_exhaustion", "davis_tech_moat",
            "davis_new_demand_catalyst", "davis_volume_price_sync",
            "quality_earnings_momentum_proxy",
            "earnings_run_proxy", "earnings_surprise_proxy",
            "insider_proxy",
        ],
        preferred_factor_categories=[
            "davis_double_play", "fundamental_proxy",
        ],
    ),

    LogicType.MARKET_SENTIMENT: MarketLogic(
        name="市场情绪 (Market Sentiment)",
        logic_type=LogicType.MARKET_SENTIMENT,
        description="偏好情绪因子、市场宽度、恐慌贪婪指标等",
        preferred_builtin_weights=[
            "w_pattern", "w_volume_profile", "w_support",
        ],
        preferred_factor_names=[
            "sentiment_momentum", "sentiment_news_score",
            "fear_greed_proxy", "capitulation_recovery",
            "dispersion_signal", "earnings_drift_proxy",
            "breadth_advance_decline", "breadth_correlation_regime",
            "breadth_market_momentum", "breadth_new_highs_lows",
            "breadth_sector_rotation", "breadth_thrust",
            "sector_momentum_rank", "relative_strength_vs_market",
            "drl_q_learning_signal", "drl_value_estimate",
            "risk_reward_setup",
        ],
        preferred_factor_categories=[
            "sentiment", "market_breadth", "rotation", "drl",
        ],
    ),
}


def get_logic(logic_type: LogicType) -> MarketLogic:
    """Get a predefined market logic by type."""
    return PREDEFINED_LOGICS[logic_type]


def get_logic_by_name(name: str) -> MarketLogic:
    """Get a predefined market logic by name string.

    Accepts logic_type values (e.g. "momentum_following") or
    partial Chinese names (e.g. "动量").
    """
    # Try exact enum match first
    try:
        return PREDEFINED_LOGICS[LogicType(name)]
    except (ValueError, KeyError):
        pass

    # Fuzzy match on name
    name_lower = name.lower()
    for lt, logic in PREDEFINED_LOGICS.items():
        if name_lower in logic.name.lower() or name_lower in lt.value:
            return logic

    available = [lt.value for lt in LogicType]
    raise ValueError(
        f"Unknown logic: {name!r}. Available: {available}"
    )


def combine_logics(*names: str) -> CompositeLogic:
    """Create a composite logic from multiple logic names.

    Example: combine_logics("momentum_following", "money_flow")
    """
    logics = [get_logic_by_name(n) for n in names]
    return CompositeLogic(logics)


# ============================================================
# Logic-Guided Mutator
# ============================================================

class LogicGuidedMutator:
    """Mutator that biases mutations toward logic-preferred factors.

    The core idea: instead of uniform random mutation across all factors,
    we split mutations into two pools:

    1. **Guided pool** (1 - exploration_ratio): Only mutate factors that
       align with the current market logic.  This focuses evolution on
       the most promising search space.

    2. **Exploration pool** (exploration_ratio, default 30%): Standard
       random mutation across ALL factors, preserving serendipitous
       discovery.

    Within the guided pool, preferred factors get a higher mutation
    probability (bias_strength, default 3.0x) compared to non-preferred
    factors.
    """

    def __init__(
        self,
        logic: MarketLogic | CompositeLogic,
        mutation_rate: float = 0.3,
        exploration_ratio: float = 0.3,
        bias_strength: float = 3.0,
        seed: Optional[int] = None,
        available_factors: Optional[Dict[str, str]] = None,
    ):
        """
        Args:
            logic: The market logic (or composite) guiding mutations.
            mutation_rate: Base probability of mutating each parameter.
            exploration_ratio: Fraction of mutations that are purely random
                (0.0 = fully guided, 1.0 = fully random, default 0.3).
            bias_strength: Multiplier for preferred factor mutation probability
                within the guided pool (default 3.0x).
            seed: Random seed for reproducibility.
            available_factors: Dict of factor_name -> category from factor
                registry (for category-based discovery).
        """
        if not 0.0 <= exploration_ratio <= 1.0:
            raise ValueError(f"exploration_ratio must be in [0, 1], got {exploration_ratio}")
        if bias_strength < 1.0:
            raise ValueError(f"bias_strength must be >= 1.0, got {bias_strength}")

        self.logic = logic
        self.mutation_rate = mutation_rate
        self.exploration_ratio = exploration_ratio
        self.bias_strength = bias_strength
        self.rng = random.Random(seed)
        self.available_factors = available_factors or {}

        # Pre-compute preferred sets
        if isinstance(logic, CompositeLogic):
            self._preferred_builtins = logic.preferred_builtin_weights
            self._preferred_factors = logic.get_all_preferred_factor_names(
                self.available_factors
            )
        else:
            self._preferred_builtins = set(logic.preferred_builtin_weights)
            self._preferred_factors = logic.get_all_preferred_factor_names(
                self.available_factors
            )

    def mutate(self, dna: StrategyDNA) -> StrategyDNA:
        """Create a logic-guided mutated copy of a StrategyDNA.

        Follows the same structure as AutoEvolver.mutate() but with
        biased mutation probabilities.
        """
        d = dna.to_dict()

        # Extract custom weight keys
        custom_keys = list(dna.custom_weights.keys())
        custom_vals = {k: d.pop(k, 0.0) for k in custom_keys}

        # Mutate builtin parameters
        for param, (lo, hi, is_int) in _PARAM_RANGES.items():
            rate = self._get_mutation_rate(param)
            if self.rng.random() < rate:
                val = d[param]
                pct = self.rng.uniform(0.10, 0.30)
                direction = self.rng.choice([-1, 1])
                delta = val * pct * direction
                if abs(delta) < 0.01:
                    delta = 0.01 * direction
                new_val = val + delta
                new_val = max(lo, min(hi, new_val))
                if is_int:
                    new_val = int(round(new_val))
                d[param] = new_val

        # Mutate custom weights with logic-aware rates
        for k in custom_keys:
            rate = self._get_custom_factor_rate(k)
            if self.rng.random() < rate:
                val = custom_vals[k]
                pct = self.rng.uniform(0.10, 0.30)
                direction = self.rng.choice([-1, 1])
                delta = val * pct * direction
                if abs(delta) < 0.01:
                    delta = 0.01 * direction
                custom_vals[k] = max(0.0, min(1.0, val + delta))

        # Normalize ALL weights together
        w_sum = sum(d[k] for k in _WEIGHT_KEYS) + sum(custom_vals.values())
        if w_sum > 0:
            for k in _WEIGHT_KEYS:
                d[k] = round(d[k] / w_sum, 4)
            for k in custom_keys:
                custom_vals[k] = round(custom_vals[k] / w_sum, 4)

        d.update(custom_vals)
        return StrategyDNA.from_dict(d)

    def _get_mutation_rate(self, param: str) -> float:
        """Compute effective mutation rate for a builtin parameter.

        For weight parameters (w_*), apply logic bias.
        For non-weight parameters, use standard rate.
        """
        if not param.startswith("w_"):
            return self.mutation_rate

        # Is this an exploration mutation or a guided mutation?
        if self.rng.random() < self.exploration_ratio:
            # Exploration: standard rate for all
            return self.mutation_rate

        # Guided: preferred weights get higher rate
        if param in self._preferred_builtins:
            return min(self.mutation_rate * self.bias_strength, 1.0)
        else:
            # Non-preferred weights get lower rate in guided mode
            return self.mutation_rate * 0.3

    def _get_custom_factor_rate(self, factor_name: str) -> float:
        """Compute effective mutation rate for a custom factor weight."""
        if self.rng.random() < self.exploration_ratio:
            return self.mutation_rate

        if factor_name in self._preferred_factors:
            return min(self.mutation_rate * self.bias_strength, 1.0)
        else:
            return self.mutation_rate * 0.3

    def get_mutation_distribution(
        self, dna: StrategyDNA,
    ) -> Dict[str, float]:
        """Return the effective mutation probability for each parameter.

        Useful for debugging and testing that logic biasing works.
        Returns dict of param_name -> effective_rate.
        """
        result: Dict[str, float] = {}

        for param in _PARAM_RANGES:
            if not param.startswith("w_"):
                result[param] = self.mutation_rate
            elif param in self._preferred_builtins:
                # Expected rate: (1-exploration) * biased + exploration * base
                guided_rate = min(self.mutation_rate * self.bias_strength, 1.0)
                result[param] = (
                    (1 - self.exploration_ratio) * guided_rate
                    + self.exploration_ratio * self.mutation_rate
                )
            else:
                lowered = self.mutation_rate * 0.3
                result[param] = (
                    (1 - self.exploration_ratio) * lowered
                    + self.exploration_ratio * self.mutation_rate
                )

        for k in dna.custom_weights:
            if k in self._preferred_factors:
                guided_rate = min(self.mutation_rate * self.bias_strength, 1.0)
                result[k] = (
                    (1 - self.exploration_ratio) * guided_rate
                    + self.exploration_ratio * self.mutation_rate
                )
            else:
                lowered = self.mutation_rate * 0.3
                result[k] = (
                    (1 - self.exploration_ratio) * lowered
                    + self.exploration_ratio * self.mutation_rate
                )

        return result


# ============================================================
# Logic Performance Tracking
# ============================================================

@dataclass
class LogicPerformance:
    """Track a market logic's historical performance."""
    logic_type: LogicType
    generations_used: int = 0
    best_fitness: float = 0.0
    latest_fitness: float = 0.0
    fitness_history: List[float] = field(default_factory=list)
    improvement_streak: int = 0  # consecutive gens with improvement
    stagnation_streak: int = 0   # consecutive gens without improvement
    total_time_secs: float = 0.0

    def record(self, fitness: float, elapsed: float = 0.0) -> None:
        """Record one generation's result."""
        self.generations_used += 1
        self.total_time_secs += elapsed

        if fitness > self.best_fitness:
            self.best_fitness = fitness
            self.improvement_streak += 1
            self.stagnation_streak = 0
        else:
            self.improvement_streak = 0
            self.stagnation_streak += 1

        self.latest_fitness = fitness
        self.fitness_history.append(fitness)

    def avg_fitness(self, last_n: int = 10) -> float:
        """Average fitness over last N generations."""
        if not self.fitness_history:
            return 0.0
        window = self.fitness_history[-last_n:]
        return sum(window) / len(window)

    def to_dict(self) -> dict:
        return {
            "logic_type": self.logic_type.value,
            "generations_used": self.generations_used,
            "best_fitness": self.best_fitness,
            "latest_fitness": self.latest_fitness,
            "avg_fitness_10": self.avg_fitness(10),
            "stagnation_streak": self.stagnation_streak,
        }


# ============================================================
# Logic Evolver — Auto-switching Between Logics
# ============================================================

class LogicEvolver:
    """Manages logic switching over generations.

    Every ``eval_interval`` generations, evaluates the current logic's
    effectiveness.  If stagnation exceeds ``max_stagnation``, switches
    to the next logic (round-robin or best-performing).

    Usage:
        evolver = LogicEvolver(initial_logic="momentum_following")
        for gen in range(100):
            mutator = evolver.get_mutator(mutation_rate=0.3)
            # ... run generation with mutator ...
            evolver.record_generation(best_fitness)
    """

    def __init__(
        self,
        initial_logic: str = "momentum_following",
        eval_interval: int = 10,
        max_stagnation: int = 10,
        exploration_ratio: float = 0.3,
        bias_strength: float = 3.0,
        seed: Optional[int] = None,
        available_factors: Optional[Dict[str, str]] = None,
    ):
        """
        Args:
            initial_logic: Name of the starting logic.
            eval_interval: Evaluate logic every N generations.
            max_stagnation: Switch logic after M consecutive gens
                without improvement.
            exploration_ratio: Fraction of random mutations (passed to mutator).
            bias_strength: Mutation bias for preferred factors.
            seed: Random seed.
            available_factors: Dict of factor_name -> category.
        """
        self.eval_interval = eval_interval
        self.max_stagnation = max_stagnation
        self.exploration_ratio = exploration_ratio
        self.bias_strength = bias_strength
        self.rng = random.Random(seed)
        self.available_factors = available_factors or {}

        # Initialize current logic
        self.current_logic = get_logic_by_name(initial_logic)

        # Performance tracking for ALL logics
        self.performance: Dict[LogicType, LogicPerformance] = {
            lt: LogicPerformance(logic_type=lt) for lt in LogicType
        }

        # Logic rotation order (start from initial, then best-performing)
        self._logic_order = list(LogicType)
        # Put initial logic first
        ct = self.current_logic.logic_type
        if ct in self._logic_order:
            self._logic_order.remove(ct)
            self._logic_order.insert(0, ct)

        self._current_idx = 0
        self._gen_count = 0
        self._best_global_fitness = 0.0

    @property
    def current_logic_type(self) -> LogicType:
        return self.current_logic.logic_type

    def get_mutator(
        self,
        mutation_rate: float = 0.3,
        seed: Optional[int] = None,
    ) -> LogicGuidedMutator:
        """Create a LogicGuidedMutator for the current logic."""
        return LogicGuidedMutator(
            logic=self.current_logic,
            mutation_rate=mutation_rate,
            exploration_ratio=self.exploration_ratio,
            bias_strength=self.bias_strength,
            seed=seed,
            available_factors=self.available_factors,
        )

    def record_generation(
        self, best_fitness: float, elapsed: float = 0.0,
    ) -> Optional[LogicType]:
        """Record a generation's result and potentially switch logic.

        Args:
            best_fitness: Best fitness of this generation.
            elapsed: Time taken for this generation.

        Returns:
            The new LogicType if a switch occurred, None otherwise.
        """
        self._gen_count += 1
        perf = self.performance[self.current_logic.logic_type]
        perf.record(best_fitness, elapsed)

        if best_fitness > self._best_global_fitness:
            self._best_global_fitness = best_fitness

        # Check if we should switch
        if perf.stagnation_streak >= self.max_stagnation:
            return self._switch_logic()

        return None

    def _switch_logic(self) -> LogicType:
        """Switch to the next logic.

        Strategy: try the least-used logic first.  If all have been used,
        pick the one with the best historical avg fitness.
        """
        current_type = self.current_logic.logic_type

        # Find least-used logic (give untried logics priority)
        candidates = [
            (lt, self.performance[lt])
            for lt in LogicType
            if lt != current_type
        ]

        # Sort: untried first, then by best avg fitness descending
        candidates.sort(
            key=lambda x: (
                x[1].generations_used > 0,  # False (untried) sorts first
                -x[1].avg_fitness(10),
            )
        )

        new_type = candidates[0][0]
        self.current_logic = PREDEFINED_LOGICS[new_type]

        return new_type

    def get_performance_summary(self) -> List[Dict]:
        """Return performance summary for all logics."""
        return sorted(
            [p.to_dict() for p in self.performance.values()],
            key=lambda x: x["best_fitness"],
            reverse=True,
        )

    def should_evaluate(self) -> bool:
        """Check if it's time to evaluate the current logic."""
        return self._gen_count % self.eval_interval == 0

    def get_best_logic(self) -> LogicType:
        """Return the logic type with the highest best_fitness."""
        best = max(
            self.performance.values(),
            key=lambda p: p.best_fitness,
        )
        return best.logic_type
