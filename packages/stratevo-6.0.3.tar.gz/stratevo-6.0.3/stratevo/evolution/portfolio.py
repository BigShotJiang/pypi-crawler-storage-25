"""
portfolio.py — Elite DNA Portfolio / Ensemble System

Combines top-N evolved DNA strategies into a diversified portfolio
instead of relying on a single best DNA.

Three combination methods:
1. Majority voting: buy only when >50% of DNA agree on a stock
2. Weighted voting: weight each DNA by WF validation fitness
3. Capital allocation: split capital proportionally to fitness

Plus diversity bonus: dissimilar DNA get higher allocation weight.
"""
from __future__ import annotations

import math
import json
import os
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple

from stratevo.evolution.models import StrategyDNA, EvolutionResult


# ─── DNA Similarity / Diversity ──────────────────────────────────────

def _dna_weight_vector(dna: StrategyDNA) -> List[float]:
    """Extract a flat numeric vector from DNA for similarity comparison."""
    from dataclasses import fields as dc_fields
    vec = []
    for f in dc_fields(dna):
        val = getattr(dna, f.name)
        if isinstance(val, (int, float)) and f.name != 'custom_weights':
            vec.append(float(val))
    # Add custom weights sorted by key
    if hasattr(dna, 'custom_weights') and dna.custom_weights:
        for k in sorted(dna.custom_weights.keys()):
            vec.append(float(dna.custom_weights[k]))
    return vec


def cosine_similarity(a: List[float], b: List[float]) -> float:
    """Cosine similarity between two vectors. Returns 0 if either is zero."""
    if len(a) != len(b):
        # Pad shorter with zeros
        max_len = max(len(a), len(b))
        a = a + [0.0] * (max_len - len(a))
        b = b + [0.0] * (max_len - len(b))

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))

    if norm_a < 1e-12 or norm_b < 1e-12:
        return 0.0
    return dot / (norm_a * norm_b)


def pairwise_diversity(dnas: List[StrategyDNA]) -> float:
    """Average pairwise cosine distance (1 - similarity) across DNA.
    Higher = more diverse portfolio. Range [0, 1]."""
    if len(dnas) < 2:
        return 0.0

    vectors = [_dna_weight_vector(d) for d in dnas]
    total_dist = 0.0
    n_pairs = 0
    for i in range(len(vectors)):
        for j in range(i + 1, len(vectors)):
            sim = cosine_similarity(vectors[i], vectors[j])
            total_dist += (1.0 - sim)
            n_pairs += 1

    return total_dist / n_pairs if n_pairs > 0 else 0.0


def diversity_weights(dnas: List[StrategyDNA]) -> List[float]:
    """Compute diversity-based weights: DNA that are more dissimilar
    to others get higher weight. Returns normalized weights summing to 1."""
    if not dnas:
        return []
    if len(dnas) == 1:
        return [1.0]

    vectors = [_dna_weight_vector(d) for d in dnas]
    # For each DNA, compute average distance to all others
    avg_distances = []
    for i in range(len(vectors)):
        dists = []
        for j in range(len(vectors)):
            if i != j:
                sim = cosine_similarity(vectors[i], vectors[j])
                dists.append(1.0 - sim)
        avg_distances.append(sum(dists) / len(dists) if dists else 0.0)

    total = sum(avg_distances)
    if total < 1e-12:
        # All identical — equal weight
        return [1.0 / len(dnas)] * len(dnas)

    return [d / total for d in avg_distances]


# ─── Portfolio Allocation ─────────────────────────────────────────────

@dataclass
class PortfolioAllocation:
    """Allocation of capital across DNA strategies."""
    weights: Dict[int, float] = field(default_factory=dict)  # dna_index -> weight
    method: str = "equal"

    def to_dict(self) -> dict:
        return {"weights": self.weights, "method": self.method}

    @classmethod
    def from_dict(cls, d: dict) -> "PortfolioAllocation":
        return cls(weights=d.get("weights", {}), method=d.get("method", "equal"))


def compute_allocation(
    results: List[EvolutionResult],
    method: str = "fitness_weighted",
    diversity_blend: float = 0.3,
) -> PortfolioAllocation:
    """Compute capital allocation across elite DNA.

    Methods:
    - "equal": equal weight to all
    - "fitness_weighted": proportional to fitness (clamped to positive)
    - "diversity_weighted": proportional to diversity (dissimilarity)
    - "blended": fitness*(1-blend) + diversity*blend

    Args:
        results: list of EvolutionResult (top elite)
        method: allocation method
        diversity_blend: how much to weight diversity vs fitness (0-1)

    Returns:
        PortfolioAllocation with normalized weights
    """
    n = len(results)
    if n == 0:
        return PortfolioAllocation(weights={}, method=method)
    if n == 1:
        return PortfolioAllocation(weights={0: 1.0}, method=method)

    if method == "equal":
        w = {i: 1.0 / n for i in range(n)}
        return PortfolioAllocation(weights=w, method=method)

    if method == "fitness_weighted":
        # Clamp fitness to positive, with minimum floor
        fitnesses = [max(r.fitness, 0.01) for r in results]
        total = sum(fitnesses)
        w = {i: f / total for i, f in enumerate(fitnesses)}
        return PortfolioAllocation(weights=w, method=method)

    if method == "diversity_weighted":
        dnas = [r.dna for r in results]
        dw = diversity_weights(dnas)
        w = {i: dw[i] for i in range(n)}
        return PortfolioAllocation(weights=w, method=method)

    if method == "blended":
        # Blend fitness and diversity weights
        fitnesses = [max(r.fitness, 0.01) for r in results]
        f_total = sum(fitnesses)
        f_weights = [f / f_total for f in fitnesses]

        dnas = [r.dna for r in results]
        d_weights = diversity_weights(dnas)

        blend = max(0.0, min(1.0, diversity_blend))
        combined = [
            f_weights[i] * (1 - blend) + d_weights[i] * blend
            for i in range(n)
        ]
        c_total = sum(combined)
        w = {i: c / c_total for i, c in enumerate(combined)}
        return PortfolioAllocation(weights=w, method=method)

    raise ValueError(f"Unknown allocation method: {method}")


# ─── Portfolio Backtest ────────────────────────────────────────────────

@dataclass
class PortfolioResult:
    """Result of backtesting a portfolio of DNA strategies."""
    allocation: PortfolioAllocation
    combined_annual_return: float
    combined_max_drawdown: float
    combined_sharpe: float
    combined_trades: int
    individual_results: List[EvolutionResult]
    diversity_score: float
    combined_fitness: float = 0.0

    def to_dict(self) -> dict:
        return {
            "allocation": self.allocation.to_dict(),
            "combined_annual_return": self.combined_annual_return,
            "combined_max_drawdown": self.combined_max_drawdown,
            "combined_sharpe": self.combined_sharpe,
            "combined_trades": self.combined_trades,
            "diversity_score": self.diversity_score,
            "combined_fitness": self.combined_fitness,
            "individual_results": [r.to_dict() for r in self.individual_results],
        }


def evaluate_portfolio(
    results: List[EvolutionResult],
    method: str = "blended",
    diversity_blend: float = 0.3,
) -> PortfolioResult:
    """Evaluate a portfolio of DNA strategies.

    Combines individual EvolutionResults using weighted allocation.
    Computes combined metrics as weighted averages (capital allocation model).

    Args:
        results: list of EvolutionResult (from evolution elite)
        method: allocation method
        diversity_blend: diversity weighting

    Returns:
        PortfolioResult with combined metrics
    """
    if not results:
        return PortfolioResult(
            allocation=PortfolioAllocation(),
            combined_annual_return=0.0,
            combined_max_drawdown=0.0,
            combined_sharpe=0.0,
            combined_trades=0,
            individual_results=[],
            diversity_score=0.0,
        )

    alloc = compute_allocation(results, method=method, diversity_blend=diversity_blend)

    # Weighted combination of returns (capital allocation model)
    combined_ar = sum(
        alloc.weights.get(i, 0) * r.annual_return
        for i, r in enumerate(results)
    )

    # Max drawdown: weighted average (underestimates correlated DD but
    # reasonable approximation without position-level replay)
    combined_dd = sum(
        alloc.weights.get(i, 0) * r.max_drawdown
        for i, r in enumerate(results)
    )

    # Sharpe: weighted average
    combined_sharpe = sum(
        alloc.weights.get(i, 0) * r.sharpe
        for i, r in enumerate(results)
    )

    # Trades: sum (each DNA trades independently)
    combined_trades = sum(r.total_trades for r in results)

    # Diversity score
    dnas = [r.dna for r in results]
    div_score = pairwise_diversity(dnas)

    # Combined fitness: weighted return / (1 + drawdown) * (1 + diversity_bonus)
    dd_penalty = 1.0 + abs(combined_dd) / 100.0
    div_bonus = 1.0 + div_score * 0.2  # up to 20% bonus for full diversity
    combined_fitness = (combined_ar / dd_penalty) * div_bonus if dd_penalty > 0 else 0.0

    return PortfolioResult(
        allocation=alloc,
        combined_annual_return=combined_ar,
        combined_max_drawdown=combined_dd,
        combined_sharpe=combined_sharpe,
        combined_trades=combined_trades,
        individual_results=results,
        diversity_score=div_score,
        combined_fitness=combined_fitness,
    )


# ─── Serialization ────────────────────────────────────────────────────

def save_portfolio(portfolio: PortfolioResult, path: str) -> None:
    """Save portfolio to JSON file (atomic write)."""
    import tempfile
    d = portfolio.to_dict()
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(d, f, indent=2, ensure_ascii=False)
    os.replace(tmp_path, path)


def load_portfolio(path: str) -> Optional[PortfolioResult]:
    """Load portfolio from JSON. Returns None if file doesn't exist."""
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        d = json.load(f)

    alloc = PortfolioAllocation.from_dict(d["allocation"])
    individual = [EvolutionResult.from_dict(r) for r in d.get("individual_results", [])]

    return PortfolioResult(
        allocation=alloc,
        combined_annual_return=d["combined_annual_return"],
        combined_max_drawdown=d["combined_max_drawdown"],
        combined_sharpe=d["combined_sharpe"],
        combined_trades=d["combined_trades"],
        individual_results=individual,
        diversity_score=d["diversity_score"],
        combined_fitness=d.get("combined_fitness", 0.0),
    )


# ─── Build Portfolio from Evolution Results ───────────────────────────

def build_portfolio_from_gen(
    gen_file: str,
    top_n: int = 5,
    method: str = "blended",
    diversity_blend: float = 0.3,
) -> Optional[PortfolioResult]:
    """Build a portfolio from a saved generation file.

    Args:
        gen_file: path to gen_XXXX.json
        top_n: how many top DNA to include
        method: allocation method
        diversity_blend: diversity weight blend

    Returns:
        PortfolioResult or None if file invalid
    """
    if not os.path.exists(gen_file):
        return None

    with open(gen_file, encoding="utf-8") as f:
        data = json.load(f)

    results_raw = data.get("results", [])
    if not results_raw:
        return None

    results = [EvolutionResult.from_dict(r) for r in results_raw[:top_n]]
    return evaluate_portfolio(results, method=method, diversity_blend=diversity_blend)
