"""
Automatic Strategy Evolution Engine
====================================
Runs 24/7. Each generation:
1. Take current best strategy parameters
2. Mutate parameters randomly (genetic algorithm)
3. Backtest all mutations on local CSV data
4. Keep top performers
5. Repeat

Uses local CSV data only — no API calls needed.
Separate from the YAML-DSL evolution engine (engine.py).
This is pure numerical parameter optimization via genetic algorithms.

v2: 12-signal scoring system with MACD, Bollinger, KDJ, OBV, MA alignment,
    candle patterns, volume profile, support/resistance.

v3: Walk-Forward validation (70/30 split), deterministic stock sampling
    per generation, enhanced fitness with Sortino, consecutive loss penalty,
    and consistency bonus.
"""

from __future__ import annotations

print("Evolution Engine v4 -- Walk-Forward + Smart Evolution + 57-dim Factors")

import json
import math
import os
import random
import tempfile
import time
from dataclasses import fields

from stratevo.invariants import (
    assert_no_lookahead,
    assert_fitness_sane,
    assert_annual_return_reasonable,
    assert_factor_output_range,
    InvariantViolation,
)
from typing import Any, Dict, List, Optional, Set, Tuple

# ── Extracted modules (refactored from monolithic auto_evolve.py) ──
from stratevo.evolution.models import (
    StrategyDNA,
    EvolutionResult,
    _WEIGHT_KEYS,
    _PARAM_RANGES,
)
from stratevo.evolution.indicators_builtin import (
    compute_rsi,
    compute_linear_regression,
    compute_volume_ratio,
    compute_macd,
    compute_bollinger_bands,
    compute_kdj,
    compute_obv_trend,
    compute_ma_alignment,
    compute_candle_patterns,  # noqa: F401 — re-exported for tests
    compute_volume_profile,  # noqa: F401 — re-exported for tests
    compute_support_resistance,  # noqa: F401 — re-exported for tests
    compute_atr,
    compute_roc,
    compute_williams_r,
    compute_cci,
    compute_mfi,
    compute_donchian_position,
    compute_aroon,
    compute_price_volume_corr,
)
from stratevo.evolution.scoring import (
    score_stock,
    compute_fitness,
    _EXCLUDED_INDUSTRY_CODES,
)

# Re-export MarketStateFilter for backward compatibility
from stratevo.evolution.market_filter import MarketStateFilter  # noqa: F401



def filter_stock_pool(
    data: Dict[str, Dict[str, list]],
    min_daily_amount: float = 20_000_000.0,
    min_price: float = 5.0,
    max_stocks: int = 500,
    forced_codes: Optional[Set[str]] = None,
    market: str = "cn",
) -> Dict[str, Dict[str, list]]:
    """Filter stock pool by quality metrics.

    Criteria:
    - Exclude ST / *ST stocks (delisting risk)
    - Exclude bank stocks (low volatility, drag on evolution)
    - Exclude stocks with price < min_price
    - Average daily turnover > min_daily_amount
    - Stocks with recent limit-up get priority bonus
    - Returns at most max_stocks best-quality stocks

    Args:
        data: Raw stock data dict (code -> {date, open, high, low, close, volume})
        min_daily_amount: Minimum average daily turnover in CNY
        min_price: Minimum stock price
        max_stocks: Maximum number of stocks to keep

    Returns:
        Filtered data dict
    """
    # Bank stock codes (major A-share banks — low volatility, not useful for evolution)
    _BANK_CODES = {
        "sh_601398",  # 工商银行
        "sh_601288",  # 农业银行
        "sh_601988",  # 中国银行
        "sh_601939",  # 建设银行
        "sh_601328",  # 交通银行
        "sh_600036",  # 招商银行
        "sh_601166",  # 兴业银行
        "sh_600016",  # 民生银行
        "sh_600000",  # 浦发银行
        "sh_601818",  # 光大银行
        "sh_600015",  # 华夏银行
        "sh_601998",  # 中信银行
        "sh_600919",  # 江苏银行
        "sh_601009",  # 南京银行
        "sh_601169",  # 北京银行
        "sz_000001",  # 平安银行
        "sz_002142",  # 宁波银行
        "sh_601838",  # 成都银行
        "sh_600926",  # 杭州银行
        "sh_601077",  # 渝农商行
        "sh_600908",  # 无锡银行
        "sz_002839",  # 张家港行
        "sz_002936",  # 郑州银行
        "sz_002948",  # 青岛银行
        "sh_601528",  # 瑞丰银行
        "sh_601860",  # 紫金银行
        "sz_002807",  # 江阴银行
        "sz_002966",  # 苏州银行
    }

    scored_codes: List[Tuple[str, float]] = []

    for code, sd in data.items():
        closes = sd["close"]
        volumes = sd["volume"]

        if not closes:
            continue

        # --- Exclusion filters ---

        # Skip bank stocks
        if code in _BANK_CODES:
            continue

        # Skip excluded industries (real estate, coal, steel, highways)
        if code in _EXCLUDED_INDUSTRY_CODES:
            continue

        # Skip ST stocks — they have "ST" in the data or erratic price patterns
        # ST stocks typically have 5% daily limit instead of 10%
        # Heuristic: if max daily change in last 60 days never exceeds 5.5%, likely ST
        recent_n = min(60, len(closes))
        if recent_n > 5:
            max_daily_change = 0.0
            for i in range(len(closes) - recent_n + 1, len(closes)):
                if closes[i - 1] > 0:
                    change = abs(closes[i] - closes[i - 1]) / closes[i - 1]
                    max_daily_change = max(max_daily_change, change)
            # ST stocks have 5% limit; normal stocks have 10%+
            # If max change in 60 days is under 5.5%, very likely ST
            if max_daily_change < 0.055 and max_daily_change > 0:
                continue

        # Last close must be > min_price
        last_close = closes[-1]
        if last_close < min_price:
            continue

        # --- Quality scoring ---

        # Average daily turnover (volume * close as proxy for amount)
        avg_amount = sum(
            closes[-recent_n + i] * volumes[-recent_n + i]
            for i in range(recent_n)
        ) / recent_n

        if avg_amount < min_daily_amount:
            continue

        # Bonus: check for limit-up in last 60 days (shows market attention)
        # Only applies to A-share markets with daily limits
        limit_up_bonus = 0.0
        if market == "cn":  # Only for A-share markets
            for i in range(max(1, len(closes) - 60), len(closes)):
                if closes[i - 1] > 0:
                    daily_ret = (closes[i] - closes[i - 1]) / closes[i - 1]
                    # Approximate limit-up: >=9.5% for main board, >=19% for ChiNext/STAR
                    if daily_ret >= 0.095:
                        limit_up_bonus += 1.0

        # Quality score: turnover + limit-up bonus (or just turnover for US/crypto)
        quality = avg_amount / 1e8 + limit_up_bonus * 0.5
        scored_codes.append((code, quality))

    # Sort by quality, keep top max_stocks
    scored_codes.sort(key=lambda x: x[1], reverse=True)
    keep_codes = {code for code, _ in scored_codes[:max_stocks]}

    # Force-include specified codes regardless of quality score
    if forced_codes:
        for code in forced_codes:
            if code in data:
                keep_codes.add(code)

    return {code: sd for code, sd in data.items() if code in keep_codes}


class AutoEvolver:
    """Automatic strategy parameter evolution engine.

    Pure genetic-algorithm approach: mutate numerical parameters,
    backtest on local CSV data, keep the fittest.
    """

    def __init__(
        self,
        data_dir: str,
        population_size: int = 30,
        elite_count: int = 5,
        mutation_rate: float = 0.3,
        results_dir: str = "evolution_results",
        seed: Optional[int] = None,
        market: str = "cn",
        walk_forward: bool = True,
        wf_config: Optional[Any] = None,
        pareto: bool = False,
        pareto_complexity: bool = False,
        logic_guided: bool = False,
        logic: Optional[str] = None,
        logic_eval_interval: int = 10,
        logic_max_stagnation: int = 10,
        logic_exploration_ratio: float = 0.3,
        logic_bias_strength: float = 3.0,
        max_stocks: int = 500,
    ):
        self.data_dir = data_dir
        self.population_size = population_size
        self.elite_count = elite_count
        self.mutation_rate = mutation_rate
        self.results_dir = results_dir
        self.market = market
        self.max_stocks = max_stocks
        self.rng = random.Random(seed)
        os.makedirs(results_dir, exist_ok=True)

        # Walk-forward validation (default ON)
        self.walk_forward = walk_forward
        self._wf_validator = None
        if walk_forward:
            from stratevo.evolution.walk_forward import WalkForwardValidator, WalkForwardConfig
            if wf_config is None and market == "crypto":
                # Crypto: hourly bars → 8760 bars/year (365 × 24)
                wf_config = WalkForwardConfig(
                    n_windows=5,          # 5 windows for sufficient OOS coverage
                    test_window_pct=0.10, # ~10% per window
                    embargo_periods=48,   # 2 days embargo for hourly data
                    bars_per_year=365.0 * 24.0,  # 8760 hourly bars/year
                )
            elif wf_config is None and market == "us":
                # US: daily bars → 250 bars/year, more data available (~1250 bars for 5 years)
                # Use 4 windows x 15% test size (each ~9 months OOS)
                wf_config = WalkForwardConfig(
                    n_windows=4,
                    test_window_pct=0.15,  # ~187 bars per window (~9 months)
                    embargo_periods=5,     # 1-week gap between train & test
                    min_train_pct=0.30,
                    bars_per_year=250.0,
                )
            elif wf_config is None and market != "crypto":
                # A-share: daily bars → 250 bars/year
                # Use 3 wider windows (each ~20% = ~250 bars ≈ 1 year) so that
                # longer hold strategies (up to 60 days) have enough rebalancing
                # cycles per window to produce statistically meaningful results.
                wf_config = WalkForwardConfig(
                    n_windows=3,
                    test_window_pct=0.20,  # ~250 bars per window
                    embargo_periods=5,     # 1-week gap between train & test
                    min_train_pct=0.30,
                    bars_per_year=250.0,
                    min_trades_per_window=3,  # lower threshold for swing trades
                )
            self._wf_validator = WalkForwardValidator(wf_config)

        # Multi-objective Pareto mode (NSGA-III)
        self.pareto = pareto
        self.pareto_complexity = pareto_complexity

        # Market Logic Layer — guided factor evolution
        self.logic_guided = logic_guided
        self._logic_evolver = None
        self._logic_initial = logic or "momentum_following"
        self._logic_eval_interval = logic_eval_interval
        self._logic_max_stagnation = logic_max_stagnation
        self._logic_exploration_ratio = logic_exploration_ratio
        self._logic_bias_strength = logic_bias_strength

        # Initialize crypto backtest engine if needed
        self._crypto_engine = None
        if market == "crypto":
            from stratevo.evolution.crypto_backtest import CryptoBacktestEngine
            self._crypto_engine = CryptoBacktestEngine()

    def load_data(
        self, quality_filter: bool = True, max_stocks: int = 500
    ) -> Dict[str, Dict[str, list]]:
        """Load stock CSV data into memory.

        Returns dict: code -> {date, open, high, low, close, volume}
        Only loads stocks with enough data (>= 60 trading days).

        Uses UnifiedDataLoader for CSV loading with built-in data validation
        and cleaning (NaN removal, negative price removal, date sorting).

        When quality_filter=True, applies:
        - Average daily turnover > 20M CNY (or volume*close proxy)
        - Last close > 5 CNY
        - Stocks with recent limit-up (涨停) get priority
        - Max ``max_stocks`` best-quality stocks retained
        """
        from stratevo.evolution.data_loader import UnifiedDataLoader, validate_data

        loader = UnifiedDataLoader()
        if self.market == "crypto":
            load_market = "crypto"
        elif self.market == "us":
            load_market = "us"
        else:
            load_market = "cn"
        data = loader.load_csv_dir(self.data_dir, market=load_market, min_days=60, clean=True)

        # Run data quality validation and print summary
        if data:
            report = validate_data(data)
            print(f"  [data quality] {report.valid_stocks}/{report.total_stocks} stocks valid, "
                  f"avg {report.avg_trading_days:.0f} trading days")
            if report.stocks_with_gaps > 0:
                print(f"  [data quality] {report.stocks_with_gaps} stocks have date gaps")
            if report.stocks_with_bad_data > 0:
                print(f"  [data quality] {report.stocks_with_bad_data} stocks have data issues")
            for w in report.warnings[:5]:
                print(f"  [data quality] [{w.level}] {w.stock}: {w.message}")
            if len(report.warnings) > 5:
                print(f"  [data quality] ... and {len(report.warnings) - 5} more warnings")

        if quality_filter and self.market != "crypto" and len(data) > max_stocks:
            data = filter_stock_pool(data, max_stocks=max_stocks, market=self.market)

        # Save loaded stock codes for reproducibility checkpoint
        self._loaded_codes = list(data.keys())

        return data

    def mutate(self, dna: StrategyDNA, eta_m_override: Optional[float] = None) -> StrategyDNA:
        """Create a mutated copy using Polynomial Mutation (PM).

        PM is the standard mutation operator for real-coded GAs (Deb & Goyal, 1996).
        It creates a probability distribution around the current value that
        respects parameter bounds, producing small changes more often than large ones.

        The distribution index ``eta_m`` controls shape:
        - High eta_m (e.g. 20): mostly small perturbations (exploitation)
        - Low eta_m (e.g. 5): wider perturbations (exploration)

        When ``eta_m_override`` is provided (e.g. during stagnation), it
        replaces the default eta_m to widen the search radius.
        """
        d = dna.to_dict()
        # Adaptive eta_m: use override when stagnation demands wider exploration
        eta_m = eta_m_override if eta_m_override is not None else 20.0

        # Extract custom weight keys
        custom_keys = list(dna.custom_weights.keys())
        custom_vals = {k: d.pop(k, 0.0) for k in custom_keys}

        for param, (lo, hi, is_int) in _PARAM_RANGES.items():
            if self.rng.random() < self.mutation_rate:
                val = d[param]
                if hi - lo < 1e-12:
                    continue
                # Polynomial mutation (Deb & Goyal 1996)
                u = self.rng.random()
                if u < 0.5:
                    delta_q = (2.0 * u) ** (1.0 / (eta_m + 1.0)) - 1.0
                else:
                    delta_q = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (eta_m + 1.0))
                new_val = val + delta_q * (hi - lo)
                new_val = max(lo, min(hi, new_val))
                if is_int:
                    new_val = int(round(new_val))
                d[param] = new_val

        # Mutate custom weights with PM (bounds [0, 1])
        for k in custom_keys:
            if self.rng.random() < self.mutation_rate:
                val = custom_vals[k]
                u = self.rng.random()
                if u < 0.5:
                    delta_q = (2.0 * u) ** (1.0 / (eta_m + 1.0)) - 1.0
                else:
                    delta_q = 1.0 - (2.0 * (1.0 - u)) ** (1.0 / (eta_m + 1.0))
                custom_vals[k] = max(0.0, min(1.0, val + delta_q))

        # Normalize ALL weights together (builtin + custom) to sum ≈ 1.0
        w_sum = sum(d[k] for k in _WEIGHT_KEYS) + sum(custom_vals.values())
        if w_sum > 0:
            for k in _WEIGHT_KEYS:
                d[k] = round(d[k] / w_sum, 4)
            for k in custom_keys:
                custom_vals[k] = round(custom_vals[k] / w_sum, 4)

        # Put custom weights back into the dict for from_dict
        d.update(custom_vals)
        return StrategyDNA.from_dict(d)

    def crossover(self, dna1: StrategyDNA, dna2: StrategyDNA, bias: float = 0.5) -> StrategyDNA:
        """Combine two strategies using Simulated Binary Crossover (SBX).

        SBX (Deb & Agrawal, 1995) creates offspring by sampling from a
        distribution that mimics single-point crossover on binary strings
        but works on real-coded parameters.  It preserves the mean of
        the two parents while controlling spread via ``eta_c``.

        Args:
            dna1: First parent DNA.
            dna2: Second parent DNA.
            bias: Probability of choosing dna1's gene for integer/discrete
                  params (SBX only applies to continuous params).
        """
        d1 = dna1.to_dict()
        d2 = dna2.to_dict()
        eta_c = 15.0  # distribution index for SBX

        # Get union of custom weight keys from both parents
        custom_keys_1 = set(dna1.custom_weights.keys())
        custom_keys_2 = set(dna2.custom_weights.keys())
        all_custom_keys = custom_keys_1 | custom_keys_2

        # Remove custom keys from d1/d2
        cw1 = {k: d1.pop(k, 0.0) for k in all_custom_keys}
        cw2 = {k: d2.pop(k, 0.0) for k in all_custom_keys}

        child = {}
        for key in d1:
            if key in _PARAM_RANGES:
                lo, hi, is_int = _PARAM_RANGES[key]
                if is_int:
                    # Discrete params: uniform selection (SBX not suitable)
                    child[key] = d1[key] if self.rng.random() < bias else d2.get(key, d1[key])
                else:
                    # Continuous params: SBX
                    p1, p2 = float(d1[key]), float(d2.get(key, d1[key]))
                    if abs(p1 - p2) < 1e-14:
                        child[key] = p1
                    else:
                        u = self.rng.random()
                        if u <= 0.5:
                            beta_q = (2.0 * u) ** (1.0 / (eta_c + 1.0))
                        else:
                            beta_q = (1.0 / (2.0 * (1.0 - u))) ** (1.0 / (eta_c + 1.0))
                        # Produce one child (randomly pick which side)
                        if self.rng.random() < 0.5:
                            child_val = 0.5 * ((1 + beta_q) * p1 + (1 - beta_q) * p2)
                        else:
                            child_val = 0.5 * ((1 - beta_q) * p1 + (1 + beta_q) * p2)
                        child[key] = max(lo, min(hi, child_val))
            else:
                child[key] = d1[key] if self.rng.random() < bias else d2.get(key, d1[key])

        # SBX for custom weights (bounds [0, 1])
        child_custom = {}
        for k in all_custom_keys:
            p1, p2 = cw1[k], cw2[k]
            if abs(p1 - p2) < 1e-14:
                child_custom[k] = p1
            else:
                u = self.rng.random()
                if u <= 0.5:
                    beta_q = (2.0 * u) ** (1.0 / (eta_c + 1.0))
                else:
                    beta_q = (1.0 / (2.0 * (1.0 - u))) ** (1.0 / (eta_c + 1.0))
                if self.rng.random() < 0.5:
                    child_val = 0.5 * ((1 + beta_q) * p1 + (1 - beta_q) * p2)
                else:
                    child_val = 0.5 * ((1 - beta_q) * p1 + (1 + beta_q) * p2)
                child_custom[k] = max(0.0, min(1.0, child_val))

        # Normalize ALL weights together (builtin + custom)
        w_sum = sum(child[k] for k in _WEIGHT_KEYS) + sum(child_custom.values())
        if w_sum > 0:
            for k in _WEIGHT_KEYS:
                child[k] = round(child[k] / w_sum, 4)
            for k in all_custom_keys:
                child_custom[k] = round(child_custom[k] / w_sum, 4)

        # Put custom weights back into child dict for from_dict
        child.update(child_custom)
        return StrategyDNA.from_dict(child)

    def evaluate(
        self,
        dna: StrategyDNA,
        data: Dict[str, Dict[str, list]],
        sample_size: int = 200,
        gen_seed: int = 0,
    ) -> EvolutionResult:
        """Backtest a strategy on loaded data with walk-forward validation.

        For speed, evaluates on a deterministic sample of ``sample_size`` stocks
        (seeded by ``gen_seed`` so same generation always picks same stocks).

        Walk-forward: splits each stock's data into train (first 70%) and
        validation (last 30%).  Final fitness weights validation 60%, train 40%.

        Simplified but correct backtesting:
        - Every hold_days: score all stocks → pick top max_positions
        - T+1 open price entry
        - Check stop-loss / take-profit during holding period
        - Exit at end of hold period
        - Compute annual return, drawdown, win rate, Sharpe, Calmar

        Args:
            dna: Strategy parameters
            data: Stock data dict from load_data()
            sample_size: Max stocks to evaluate (for speed)
            gen_seed: Deterministic seed for stock sampling (generation number)

        Returns:
            EvolutionResult with all metrics
        """
        if not data:
            return EvolutionResult(
                dna=dna,
                annual_return=0.0,
                max_drawdown=0.0,
                win_rate=0.0,
                sharpe=0.0,
                calmar=0.0,
                total_trades=0,
                profit_factor=0.0,
                fitness=0.0,
            )

        # Load dynamic factor registry (cached on self)
        # Reset trade log to prevent cross-DNA contamination
        self._trade_log = []
        if not hasattr(self, '_factor_registry'):
            try:
                from stratevo.evolution.factor_discovery import FactorRegistry, create_seed_factors
                create_seed_factors("factors")
                self._factor_registry = FactorRegistry("factors")
                self._factor_registry.load_all(market=self.market)
                factor_names = self._factor_registry.list_factors()
                if factor_names:
                    print(f"  [factors] loaded {len(factor_names)} dynamic factors")
            except Exception as e:
                print(f"  [factors] skipped: {e}")
                self._factor_registry = None

        # Pre-compute active factor count for logging (once per evaluate call)
        _active_factor_count = None
        _total_factor_count = None
        if self._factor_registry and self._factor_registry.factors:
            _total_factor_count = len(self._factor_registry.list_factors())
            if hasattr(dna, 'custom_weights') and dna.custom_weights:
                _active_factor_count = sum(
                    1 for fname, w in dna.custom_weights.items()
                    if w >= 0.001 and fname in self._factor_registry.factors
                )
                if _active_factor_count < _total_factor_count:
                    if not hasattr(self, '_factor_speedup_shown'):
                        print(f"  [factors] speedup: {_active_factor_count}/{_total_factor_count} factors active (skipping {_total_factor_count - _active_factor_count} near-zero)")
                        self._factor_speedup_shown = True

        # Deterministic sampling: use gen_seed so same generation always
        # picks the same stocks, eliminating sampling noise.
        codes = list(data.keys())
        if len(codes) > sample_size:
            sample_rng = random.Random(gen_seed)
            codes = sample_rng.sample(codes, sample_size)

        # Pre-compute indicators per stock (all 12 dimensions)
        indicators: Dict[str, Dict[str, Any]] = {}
        for code in codes:
            sd = data[code]
            closes = sd["close"]
            vols = sd["volume"]
            opens = sd["open"]
            highs_list = sd["high"]
            lows_list = sd["low"]
            
            # Ensure all lists have same length
            min_len = min(len(closes), len(vols), len(opens), len(highs_list), len(lows_list))
            closes = closes[:min_len]
            vols = vols[:min_len]
            opens = opens[:min_len]
            highs_list = highs_list[:min_len]
            lows_list = lows_list[:min_len]

            rsi = compute_rsi(closes)
            r2, slope = compute_linear_regression(closes)
            vol_ratio = compute_volume_ratio(vols)

            # New v2 indicators
            macd_line, macd_signal, macd_hist = compute_macd(closes)
            bb_upper, bb_middle, bb_lower, bb_width = compute_bollinger_bands(closes)
            kdj_k, kdj_d, kdj_j = compute_kdj(highs_list, lows_list, closes)
            obv = compute_obv_trend(closes, vols)
            ma_align = compute_ma_alignment(closes)

            # Extended technical indicators (v3)
            atr_pct = compute_atr(highs_list, lows_list, closes)
            roc = compute_roc(closes)
            williams_r = compute_williams_r(highs_list, lows_list, closes)
            cci = compute_cci(closes, highs_list, lows_list)
            mfi = compute_mfi(highs_list, lows_list, closes, vols)
            donchian_pos = compute_donchian_position(highs_list, lows_list, closes)
            aroon = compute_aroon(closes)
            pv_corr = compute_price_volume_corr(closes, vols)

            indicators[code] = {
                "rsi": rsi,
                "r2": r2,
                "slope": slope,
                "volume_ratio": vol_ratio,
                "close": closes,
                "open": opens,
                "high": highs_list,
                "low": lows_list,
                "volume": vols,
                # v2 indicators
                "macd_line": macd_line,
                "macd_signal": macd_signal,
                "macd_hist": macd_hist,
                "bb_upper": bb_upper,
                "bb_middle": bb_middle,
                "bb_lower": bb_lower,
                "kdj_k": kdj_k,
                "kdj_d": kdj_d,
                "kdj_j": kdj_j,
                "obv_trend": obv,
                "ma_alignment": ma_align,
                # v3 extended indicators
                "atr_pct": atr_pct,
                "roc": roc,
                "williams_r": williams_r,
                "cci": cci,
                "mfi": mfi,
                "donchian_pos": donchian_pos,
                "aroon": aroon,
                "pv_corr": pv_corr,
                # Market context for scoring adjustments
                "_market": self.market,
            }

            # Store dynamic factor compute functions for on-the-fly scoring
            # Optimization: only include factors with non-trivial weights in DNA
            # If DNA has 196 custom weights but only 30 are >= 0.001, we skip 166
            if self._factor_registry and self._factor_registry.factors:
                if hasattr(dna, 'custom_weights') and dna.custom_weights:
                    # Pre-filter: only compute factors that the DNA actually uses
                    active_factors = {}
                    for fname, w in dna.custom_weights.items():
                        if w >= 0.001 and fname in self._factor_registry.factors:
                            active_factors[fname] = self._factor_registry.factors[fname].compute_fn
                    indicators[code]["_factor_fns"] = active_factors
                else:
                    # No custom weights in DNA, store all (fallback)
                    indicators[code]["_factor_fns"] = {
                        fname: self._factor_registry.factors[fname].compute_fn
                        for fname in self._factor_registry.list_factors()
                    }

        # Load fundamental data (once per session, cached)
        # WARNING: Fundamental data from AKShare/BaoStock is point-in-time
        # (current PE/PB/ROE), NOT historical values.  Using it in backtests
        # introduces severe look-ahead bias.  Auto-disabled when walk_forward
        # is active; set STRATEVO_SKIP_FUNDAMENTALS=0 to force-enable (NOT
        # recommended for backtesting).
        if not hasattr(self, '_fund_data_cache'):
            self._fund_data_cache = {}
            skip_env = os.environ.get("STRATEVO_SKIP_FUNDAMENTALS")
            # Default: skip fundamentals in walk-forward mode (look-ahead bias)
            if skip_env == "0":
                # User explicitly forced fundamentals on
                force_on = True
            elif skip_env or self.walk_forward:
                force_on = False
            else:
                force_on = True  # legacy non-WF mode, allow for backward compat

            if force_on:
                try:
                    from stratevo.evolution.fundamentals import fetch_fundamentals_baostock
                    self._fund_data_cache = fetch_fundamentals_baostock(codes)
                    if self.walk_forward:
                        import logging
                        logging.getLogger(__name__).warning(
                            "Fundamental data loaded in walk-forward mode. "
                            "This uses current PE/PB/ROE (look-ahead bias). "
                            "Set STRATEVO_SKIP_FUNDAMENTALS=1 to disable."
                        )
                except Exception as e:
                    print(f"  [fundamentals] skipped: {e}")
            else:
                if self.walk_forward:
                    print("  [fundamentals] auto-disabled in walk-forward mode (look-ahead bias prevention)")
                else:
                    print("  [fundamentals] skipped (STRATEVO_SKIP_FUNDAMENTALS=1)")
        fund_data = self._fund_data_cache

        # Add fundamentals to indicators dict for each stock
        for code in codes:
            indicators[code]["fundamentals"] = fund_data.get(code, {})

        # Find common date range — use the first stock to determine day count
        first_code = codes[0]
        total_days = len(data[first_code]["close"])

        # ── Walk-Forward Split ──
        # Train on first 70%, validate on last 30%
        warmup = 30  # indicator warmup days
        train_end = warmup + int((total_days - warmup) * 0.7)
        val_start = train_end
        val_end = total_days

        hold_days = max(2, dna.hold_days)  # A-share T+1: buy T+1, earliest sell T+2

        # ── Choose backtest engine ──
        if self.market == "crypto" and self._crypto_engine is not None:
            # Use crypto backtest engine — no T+1, supports shorts/leverage
            def _run_backtest_dispatch(day_start: int, day_end: int):
                return self._crypto_engine.run_backtest(
                    dna, data, indicators, codes, day_start, day_end
                )
        else:
            _run_backtest_dispatch = None  # use inline A-share backtest below

        def _run_backtest(day_start: int, day_end: int) -> Tuple[
            float, float, float, float, float, int, float, float, int, List[float], int, float
        ]:
            """Run backtest on a date range. Returns (annual_return, max_drawdown,
            win_rate, sharpe, calmar, total_trades, profit_factor, sortino,
            max_consec_losses, monthly_returns, max_concurrent_positions, avg_turnover)."""
            initial_capital = 1_000_000.0
            bt_capital = initial_capital
            bt_portfolio_values = [bt_capital]

            bt_trades: List[float] = []
            bt_gross_profit = 0.0
            bt_gross_loss = 0.0

            # Track monthly returns for consistency bonus
            bt_monthly_returns: List[float] = []
            month_start_capital = bt_capital
            last_month_day = day_start
            approx_month_days = 21  # ~21 trading days per month

            # Track max concurrent positions for diversification scoring
            bt_max_concurrent = 0

            # Track turnover: how much the portfolio changes each rebalancing
            bt_turnover_ratios: List[float] = []
            bt_prev_picks: set = set()

            # Market state filter (hard rule, always applied, not evolved)
            bt_market_filter = MarketStateFilter()

            day = day_start

            while day < day_end - hold_days - 1:
                # === Effective params (reset each cycle, may be overridden by bear regime) ===
                effective_stop_loss = dna.stop_loss_pct
                effective_take_profit = dna.take_profit_pct
                effective_hold_days = hold_days

                # Monthly return tracking
                if day - last_month_day >= approx_month_days:
                    if month_start_capital > 0:
                        mr = (bt_capital - month_start_capital) / month_start_capital * 100
                        bt_monthly_returns.append(mr)
                    month_start_capital = bt_capital
                    last_month_day = day

                # Score all stocks at this day
                scored: List[Tuple[str, float]] = []

                # === Factor momentum: adaptive min_score ===
                # When recent trades are losing, raise the bar (be more selective).
                # When winning, keep the bar where it is (don't get greedy).
                factor_mom = getattr(dna, 'factor_momentum', 0.0)
                adaptive_min_score = dna.min_score
                if factor_mom > 0.01 and len(bt_trades) >= 5:
                    recent = bt_trades[-10:]
                    recent_wr = sum(1 for t in recent if t > 0) / len(recent)
                    # If winning < 40%, raise min_score by up to 2 points
                    if recent_wr < 0.4:
                        penalty = factor_mom * 2.0 * (0.4 - recent_wr) / 0.4
                        adaptive_min_score = min(dna.min_score + penalty, 9.0)
                    # If winning > 60%, slightly lower min_score (more aggressive)
                    elif recent_wr > 0.6:
                        bonus = factor_mom * 0.5 * (recent_wr - 0.6) / 0.4
                        adaptive_min_score = max(dna.min_score - bonus, 3.0)

                for code in codes:
                    sd = data[code]
                    if day >= len(sd["close"]):
                        continue
                    ind = indicators[code]
                    s = score_stock(day, ind, dna)
                    # Invariant: factor output should be in valid range
                    try:
                        assert_factor_output_range(s / 10.0)  # score is [0,10], normalize to [0,1]
                    except InvariantViolation:
                        s = max(0.0, min(10.0, s))  # clamp instead of crash
                    if s >= adaptive_min_score:
                        scored.append((code, s))

                # Apply market state filter (hard rule, not evolved)
                if bt_market_filter is not None and scored:
                    mkt_state = bt_market_filter.compute_market_state(
                        data, indicators, codes, day,
                    )
                    adjusted_scored = []
                    for code, s in scored:
                        ind = indicators[code]
                        sd = data[code]
                        has_bottom = MarketStateFilter.check_bottom_signals(
                            ind,
                            sd["close"], sd["high"], sd["low"], sd["volume"],
                            day,
                        )
                        adj_s = bt_market_filter.adjust_score(s, mkt_state, has_bottom)
                        if adj_s >= adaptive_min_score:
                            adjusted_scored.append((code, adj_s))
                    scored = adjusted_scored

                # ── Hard Filter: Reject Chronic Underperformers ──
                # This is a permanent safety rule, NOT subject to evolution.
                # Prevents buying stocks in structural decline (dying industries).
                if scored:
                    filtered_scored = []
                    for code, s in scored:
                        closes_arr = data[code]["close"]
                        if day >= 60:
                            peak_60d = max(closes_arr[day - 59:day + 1])
                            current = closes_arr[day]
                            if peak_60d > 0:
                                drawdown_from_peak = (peak_60d - current) / peak_60d
                                # Hard reject: >30% below 60-day high
                                if drawdown_from_peak > 0.30:
                                    continue
                                # Soft penalty: 15-30% below 60-day high, reduce score by 30%
                                if drawdown_from_peak > 0.15:
                                    s = s * 0.70
                                    if s < adaptive_min_score:
                                        continue
                        filtered_scored.append((code, s))
                    scored = filtered_scored

                # === v5 P0-2: Cross-sectional score neutralization ===
                # Z-score normalize scores across all candidates at this time step.
                # This prevents score inflation from market-wide effects and ensures
                # we're picking genuinely top stocks, not just "everything is hot today".
                if len(scored) >= 5:
                    scores_only = [s for _, s in scored]
                    mean_s = sum(scores_only) / len(scores_only)
                    var_s = sum((s - mean_s) ** 2 for s in scores_only) / len(scores_only)
                    std_s = var_s ** 0.5
                    if std_s > 0.01:
                        # Re-scale: z-score → [0, 10] range, centered at 5
                        scored = [
                            (code, max(0.0, min(10.0, 5.0 + 2.5 * (s - mean_s) / std_s)))
                            for code, s in scored
                        ]
                        # Re-filter by min_score after neutralization
                        scored = [(code, s) for code, s in scored if s >= adaptive_min_score]

                # Pick top max_positions
                scored.sort(key=lambda x: x[1], reverse=True)

                # === v5: Market regime adaptation ===
                # Reduce position count when market breadth is weak
                regime_sensitivity = getattr(dna, 'market_regime_sensitivity', 0.0)
                effective_max_positions = dna.max_positions
                if regime_sensitivity > 0.01:
                    # Simple breadth: % of sampled stocks above their 20-day MA
                    above_ma_count = 0
                    total_counted = 0
                    for c in codes:
                        sd_c = data[c]
                        if day >= 20 and day < len(sd_c["close"]):
                            ma20 = sum(sd_c["close"][day-19:day+1]) / 20
                            if sd_c["close"][day] > ma20:
                                above_ma_count += 1
                            total_counted += 1
                    if total_counted > 0:
                        breadth = above_ma_count / total_counted  # 0-1

                        # === P0: Market regime gate ===
                        # When breadth < min_breadth_to_trade, go 100% cash.
                        # This is the #1 improvement: avoid trading in bear markets entirely.
                        min_breadth = getattr(dna, 'min_breadth_to_trade', 0.0)
                        if min_breadth > 0.01 and breadth < min_breadth:
                            # Skip this entire cycle — sit in cash
                            bt_portfolio_values.append(max(bt_capital, 0.01))
                            day += hold_days
                            continue

                        # If breadth < 0.5 (bear), reduce positions
                        if breadth < 0.5:
                            reduction = regime_sensitivity * (0.5 - breadth) * 2  # 0-1
                            effective_max_positions = max(1, int(dna.max_positions * (1 - reduction)))

                        # === v6: Regime-specific parameter overrides ===
                        # When in bear market (breadth < 0.4), adapt key params
                        if breadth < 0.4:
                            bear_intensity = (0.4 - breadth) / 0.4  # 0-1, stronger in deeper bear
                            # Raise min_score: be more selective in bear markets
                            bear_add = getattr(dna, 'bear_min_score_add', 0.0)
                            if bear_add > 0.01:
                                adaptive_min_score = min(
                                    adaptive_min_score + bear_add * bear_intensity, 9.0
                                )
                            # Tighten stop loss in bear
                            bear_sl = getattr(dna, 'bear_stop_loss_mult', 1.0)
                            if bear_sl < 0.99:
                                effective_stop_loss = dna.stop_loss_pct * (
                                    1.0 - (1.0 - bear_sl) * bear_intensity
                                )
                            # Shorten hold period in bear
                            bear_hd = getattr(dna, 'bear_hold_days_mult', 1.0)
                            if bear_hd < 0.99:
                                effective_hold_days = max(2, int(dna.hold_days * (
                                    1.0 - (1.0 - bear_hd) * bear_intensity
                                )))
                            # Lower take profit targets in bear
                            bear_tp = getattr(dna, 'bear_take_profit_mult', 1.0)
                            if bear_tp < 0.99:
                                effective_take_profit = dna.take_profit_pct * (
                                    1.0 - (1.0 - bear_tp) * bear_intensity
                                )

                picks = scored[: effective_max_positions]

                # === Multi-timeframe confirmation (weekly trend filter) ===
                # Only buy stocks whose weekly trend (5-day MA of closes > 20-day MA)
                # is also bullish.  This prevents buying daily dip signals against
                # a larger downtrend.  Controlled by evolved parameter.
                weekly_confirm = getattr(dna, 'weekly_trend_confirm', 0.0)
                if weekly_confirm > 0.5 and day >= 20:
                    confirmed_picks = []
                    for code, score in picks:
                        sd = data[code]
                        if day < len(sd["close"]):
                            # 5-day MA (weekly proxy)
                            ma5 = sum(sd["close"][day-4:day+1]) / 5
                            # 20-day MA (monthly proxy)
                            ma20 = sum(sd["close"][day-19:day+1]) / 20
                            if ma5 >= ma20:  # weekly uptrend
                                confirmed_picks.append((code, score))
                    # Keep at least 1 pick if any passed daily scoring
                    if confirmed_picks:
                        picks = confirmed_picks

                # === v5 P0-1: Correlation-aware portfolio construction ===
                # If multiple picks, remove highly correlated stocks (keep best scorer)
                if len(picks) > 1:
                    decorrelated_picks = [picks[0]]  # always keep highest scorer
                    for code_i, score_i in picks[1:]:
                        is_correlated = False
                        sd_i = data[code_i]
                        # Use last 20 days of returns for correlation
                        if day >= 21 and day < len(sd_i["close"]):
                            returns_i = [
                                (sd_i["close"][d] - sd_i["close"][d-1]) / sd_i["close"][d-1]
                                for d in range(max(day-19, 1), day+1)
                                if sd_i["close"][d-1] > 0
                            ]
                            for code_j, _ in decorrelated_picks:
                                sd_j = data[code_j]
                                if day >= 21 and day < len(sd_j["close"]):
                                    returns_j = [
                                        (sd_j["close"][d] - sd_j["close"][d-1]) / sd_j["close"][d-1]
                                        for d in range(max(day-19, 1), day+1)
                                        if sd_j["close"][d-1] > 0
                                    ]
                                    # Pearson correlation
                                    n = min(len(returns_i), len(returns_j))
                                    if n >= 10:
                                        ri = returns_i[:n]
                                        rj = returns_j[:n]
                                        mean_i = sum(ri) / n
                                        mean_j = sum(rj) / n
                                        cov = sum((ri[k]-mean_i)*(rj[k]-mean_j) for k in range(n)) / n
                                        std_i = (sum((r-mean_i)**2 for r in ri) / n) ** 0.5
                                        std_j = (sum((r-mean_j)**2 for r in rj) / n) ** 0.5
                                        if std_i > 0 and std_j > 0:
                                            corr = cov / (std_i * std_j)
                                            if corr > 0.85:  # too correlated
                                                is_correlated = True
                                                break
                        if not is_correlated:
                            decorrelated_picks.append((code_i, score_i))
                    picks = decorrelated_picks

                # Track turnover: how many positions changed from previous period
                current_pick_codes = {code for code, _ in picks}
                if bt_prev_picks:  # Skip first period (no previous positions)
                    # Count codes that are new or removed
                    changes = len(bt_prev_picks.symmetric_difference(current_pick_codes))
                    max_pos = max(dna.max_positions, 1)
                    period_turnover = changes / max_pos
                    bt_turnover_ratios.append(period_turnover)
                bt_prev_picks = current_pick_codes

                if picks:
                    # === v5: Signal-strength position sizing ===
                    # position_sizing_power=0 → equal weight (backward compatible)
                    # position_sizing_power>0 → higher scores get more capital
                    sizing_power = getattr(dna, 'position_sizing_power', 0.0)
                    if sizing_power > 0.01 and len(picks) > 1:
                        # Compute raw weights: score^power
                        raw_weights = [(code, score ** sizing_power) for code, score in picks]
                        total_weight = sum(w for _, w in raw_weights)
                        if total_weight > 0:
                            per_pos_map = {code: bt_capital * (w / total_weight) for code, w in raw_weights}
                        else:
                            per_pos_map = {code: bt_capital / len(picks) for code, _ in picks}
                    else:
                        per_pos_map = {code: bt_capital / len(picks) for code, _ in picks}

                    # === Capital utilization: control how much capital is deployed ===
                    # capital_utilization=1.0 → use 100% of capital across positions
                    # capital_utilization=0.5 → only deploy 50%, hold 50% cash
                    cap_util = getattr(dna, 'capital_utilization', 1.0)
                    if cap_util < 0.99:
                        per_pos_map = {code: v * cap_util for code, v in per_pos_map.items()}

                    # === Kelly criterion position sizing ===
                    # After enough trade history, apply fractional Kelly to scale
                    # total exposure up/down based on recent win rate & payoff ratio.
                    kelly_fraction = getattr(dna, 'kelly_fraction', 0.0)
                    if kelly_fraction > 0.01 and len(bt_trades) >= 10:
                        recent = bt_trades[-30:]  # last 30 trades
                        wins = [t for t in recent if t > 0]
                        losses = [t for t in recent if t <= 0]
                        if wins and losses:
                            win_rate = len(wins) / len(recent)
                            avg_win = sum(wins) / len(wins)
                            avg_loss = abs(sum(losses) / len(losses))
                            if avg_loss > 0:
                                payoff = avg_win / avg_loss
                                # Kelly: f = W - (1-W)/R, capped by kelly_fraction
                                kelly_f = win_rate - (1.0 - win_rate) / payoff
                                # Half-Kelly for safety, then scale by evolved fraction
                                kelly_scale = max(0.1, min(1.0, kelly_f * 0.5 * kelly_fraction))
                                per_pos_map = {code: v * kelly_scale for code, v in per_pos_map.items()}

                    # Cap position size to prevent unrealistic compounding
                    max_position = initial_capital * 2.0  # Never risk more than 2x initial per position
                    per_pos_map = {code: min(v, max_position) for code, v in per_pos_map.items()}

                    positions_this_period = 0

                    for code, _score in picks:
                        sd = data[code]
                        entry_day = day + 1  # T+1

                        # Invariant: entry must be strictly after scoring day
                        assert_no_lookahead(decision_time=day, data_time=entry_day - 1)

                        if entry_day >= len(sd["open"]):
                            continue

                        entry_price = sd["open"][entry_day]
                        if entry_price <= 0:
                            continue

                        # === SUSPENSION CHECK ===
                        # Skip if entry day has zero volume (stock is suspended)
                        if entry_day < len(sd["volume"]) and sd["volume"][entry_day] <= 0:
                            continue

                        # === A-SHARE LIMIT RULES ===
                        if entry_day >= 1:
                            prev_close = sd["close"][entry_day - 1]
                            if prev_close > 0:
                                code_str = code.replace("_", ".")
                                if code_str.startswith("sh.688") or code_str.startswith("sz.3"):
                                    limit_pct = 0.20
                                else:
                                    limit_pct = 0.10
                                if entry_price >= prev_close * (1 + limit_pct - 0.005):
                                    continue

                        # === DYNAMIC SLIPPAGE based on volume ===
                        # Compute avg daily volume over recent 20 days
                        vols = sd["volume"]
                        vol_lookback = min(20, entry_day)
                        if vol_lookback > 0:
                            avg_vol = sum(vols[entry_day - vol_lookback:entry_day]) / vol_lookback
                        else:
                            avg_vol = vols[entry_day] if entry_day < len(vols) else 0
                        # Volume-based slippage tiers (market-specific)
                        if self.market == "us":
                            # US markets are more liquid, tighter spreads
                            if avg_vol < 1_000_000:
                                slippage_pct = 0.001   # 0.10% for low volume
                            elif avg_vol < 10_000_000:
                                slippage_pct = 0.0003  # 0.03% for medium volume
                            else:
                                slippage_pct = 0.0001  # 0.01% for high volume
                        elif self.market == "crypto":
                            # Crypto markets can have wider spreads
                            if avg_vol < 100_000:
                                slippage_pct = 0.002   # 0.20% for low volume
                            elif avg_vol < 1_000_000:
                                slippage_pct = 0.001   # 0.10% for medium volume
                            else:
                                slippage_pct = 0.0005  # 0.05% for high volume
                        else:
                            # A-share markets (original thresholds)
                            if avg_vol < 5_000_000:
                                slippage_pct = 0.0015  # 0.15% for low volume
                            elif avg_vol < 50_000_000:
                                slippage_pct = 0.0005  # 0.05% for medium volume
                            else:
                                slippage_pct = 0.0002  # 0.02% for high volume

                        # Apply slippage to entry: buy at slightly higher price
                        entry_price = entry_price * (1 + slippage_pct)

                        shares = per_pos_map.get(code, bt_capital / max(len(picks), 1)) / entry_price
                        exit_price = entry_price
                        positions_this_period += 1

                        # === v5: Pre-compute exit parameters ===
                        trailing_on = getattr(dna, 'trailing_stop_enabled', 0.0) > 0.5
                        trailing_act_pct = getattr(dna, 'trailing_activation_pct', 5.0)
                        trailing_sl_pct = getattr(dna, 'trailing_stop_pct', 3.0)
                        profit_scaling = getattr(dna, 'profit_target_scaling', 0.0)
                        time_decay = getattr(dna, 'time_decay_exit', 0.0)

                        # Effective take-profit: optionally scale by signal strength
                        effective_tp_pct = effective_take_profit
                        if profit_scaling > 0.01:
                            # score is [0,10], scale TP: higher score → higher target
                            score_ratio = min(_score / 10.0, 1.0)
                            # Blend: (1-scaling)*base + scaling*(base * score_ratio * 2)
                            # At score=10: TP stays at base; at score=5: TP = base * (1-scaling) + scaling*base
                            effective_tp_pct = effective_take_profit * (1.0 - profit_scaling + profit_scaling * score_ratio * 2.0)
                            effective_tp_pct = max(effective_tp_pct, effective_stop_loss * 1.5)  # TP must exceed SL

                        peak_price = entry_price  # for trailing stop
                        trailing_activated = False

                        for d in range(entry_day, min(entry_day + effective_hold_days, len(sd["close"]))):
                            low = sd["low"][d]
                            high = sd["high"][d]

                            if d >= 1:
                                pc = sd["close"][d - 1]
                                if pc > 0:
                                    code_str = code.replace("_", ".")
                                    if code_str.startswith("sh.688") or code_str.startswith("sz.3"):
                                        lim = 0.20
                                    else:
                                        lim = 0.10
                                    limit_down_price = pc * (1 - lim + 0.005)
                                    if sd["close"][d] <= limit_down_price:
                                        continue

                            # Update peak price for trailing stop
                            if high > peak_price:
                                peak_price = high

                            # === v5: Time-decay exit — tighten stop loss over time ===
                            days_held = d - entry_day
                            sl_pct = effective_stop_loss
                            # === Adaptive stop loss: scale by hold_days ===
                            sl_per_day = getattr(dna, 'stop_loss_per_day', 0.0)
                            if sl_per_day > 0.01:
                                # Effective SL = per_day * hold_days, capped at fixed SL
                                sl_pct = min(sl_per_day * effective_hold_days, effective_stop_loss)
                            if time_decay > 0.01 and days_held > effective_hold_days * 0.5:
                                # After half the hold period, progressively tighten SL
                                decay_factor = (days_held - effective_hold_days * 0.5) / max(effective_hold_days * 0.5, 1)
                                sl_tightening = sl_pct * time_decay * min(decay_factor, 1.0)
                                sl_pct = max(sl_pct - sl_tightening, 0.5)  # never tighter than 0.5%

                            # Fixed stop loss
                            sl_price = entry_price * (1 - sl_pct / 100)
                            if low <= sl_price:
                                # Gap-down: if bar opens below stop, fill at
                                # the worse price (open), not the stop level.
                                bar_open = sd["open"][d] if d < len(sd["open"]) else sl_price
                                exit_price = min(sl_price, bar_open)
                                break

                            # === v5: Trailing stop ===
                            if trailing_on:
                                gain_pct = (peak_price - entry_price) / entry_price * 100
                                if gain_pct >= trailing_act_pct:
                                    trailing_activated = True
                                if trailing_activated:
                                    trail_price = peak_price * (1 - trailing_sl_pct / 100)
                                    if low <= trail_price:
                                        # Gap-down: fill at worse of trail
                                        # price or bar open.
                                        bar_open = sd["open"][d] if d < len(sd["open"]) else trail_price
                                        exit_price = min(trail_price, bar_open)
                                        break

                            # Take profit (with optional scaling)
                            tp_price = entry_price * (1 + effective_tp_pct / 100)
                            if high >= tp_price:
                                exit_price = tp_price
                                break

                            # === Trend exit: bail out if short-term trend breaks ===
                            # When enabled, exit if 5-day MA crosses below 10-day MA
                            # (i.e., short-term uptrend has ended). This allows longer
                            # hold_days while still cutting losses dynamically.
                            trend_exit = getattr(dna, 'trend_exit_enabled', 0.0)
                            if trend_exit > 0.5 and d >= 10 and days_held >= 3:
                                # Only check after holding at least 3 days
                                if d < len(sd["close"]):
                                    ma5 = sum(sd["close"][max(0,d-4):d+1]) / min(5, d+1)
                                    ma10 = sum(sd["close"][max(0,d-9):d+1]) / min(10, d+1)
                                    if ma5 < ma10:
                                        # Signal fires at close[d]; execute at
                                        # next-bar open to avoid look-ahead.
                                        next_d = d + 1
                                        if next_d < len(sd["open"]):
                                            exit_price = sd["open"][next_d]
                                        else:
                                            exit_price = sd["close"][d]
                                        break

                            # Default: hold through this bar.  When the
                            # holding period expires (loop ends without
                            # break), sell at the next bar's open.  Use
                            # close[d] only as a last-resort fallback when
                            # d is the final available bar.
                            next_d = d + 1
                            if next_d < len(sd["open"]):
                                exit_price = sd["open"][next_d]
                            else:
                                exit_price = sd["close"][d]

                        # Apply slippage to exit: sell at slightly lower price
                        exit_price = exit_price * (1 - slippage_pct)

                        # A-share fees (2023-08-28 regulation):
                        # Commission: 0.025% (0.00025) both sides, min 5 CNY/trade
                        # Stamp tax: 0.05% (0.0005) sell side only
                        buy_commission_total = max(entry_price * shares * 0.00025, 5.0)
                        sell_commission_total = max(exit_price * shares * 0.00025, 5.0)
                        # Convert back to per-share cost for return calculation
                        buy_cost = buy_commission_total / shares if shares > 0 else 0
                        sell_cost = (sell_commission_total + exit_price * shares * 0.0005) / shares if shares > 0 else 0
                        trade_return = (exit_price - entry_price - buy_cost - sell_cost) / entry_price * 100
                        bt_trades.append(trade_return)

                        pnl = shares * entry_price * trade_return / 100
                        if pnl > 0:
                            bt_gross_profit += pnl
                        else:
                            bt_gross_loss += abs(pnl)

                        bt_capital += pnl

                        # Record trade details for verification
                        if not hasattr(self, '_trade_log'):
                            self._trade_log = []
                        _dates = sd["date"]
                        self._trade_log.append({
                            "code": code,
                            "score_date": _dates[day] if day < len(_dates) else "",
                            "entry_date": _dates[entry_day] if entry_day < len(_dates) else "",
                            "exit_date": _dates[min(d + 1, len(_dates) - 1)] if d < len(_dates) else "",
                            "score_day": day,
                            "entry_day": entry_day,
                            "entry_price": round(entry_price, 4),
                            "exit_price": round(exit_price, 4),
                            "shares": round(shares, 4),
                            "allocated": round(per_pos_map.get(code, 0), 2),
                            "trade_return_pct": round(trade_return, 4),
                            "pnl": round(pnl, 2),
                            "capital_after": round(bt_capital, 2),
                            "buy_cost": round(buy_cost * shares, 4),
                            "sell_cost": round(sell_cost * shares, 4),
                            "slippage_pct": slippage_pct,
                        })

                    # Update max concurrent positions
                    if positions_this_period > bt_max_concurrent:
                        bt_max_concurrent = positions_this_period

                bt_portfolio_values.append(max(bt_capital, 0.01))
                day += effective_hold_days

                # ── Bankruptcy check ──
                # If capital drops below 1% of initial, stop trading.
                # Continuing with near-zero or negative capital produces
                # meaningless results (negative shares = inverted strategy).
                if bt_capital < initial_capital * 0.01:
                    break

            # Final partial month
            if month_start_capital > 0 and bt_capital != month_start_capital:
                mr = (bt_capital - month_start_capital) / month_start_capital * 100
                bt_monthly_returns.append(mr)

            # ── Compute metrics ──
            bt_total_trades = len(bt_trades)
            bt_win_rate = 0.0
            if bt_total_trades > 0:
                wins = sum(1 for t in bt_trades if t > 0)
                bt_win_rate = wins / bt_total_trades * 100

            # Max consecutive losses
            bt_max_consec_losses = 0
            current_streak = 0
            for t in bt_trades:
                if t <= 0:
                    current_streak += 1
                    bt_max_consec_losses = max(bt_max_consec_losses, current_streak)
                else:
                    current_streak = 0

            # Annual return
            bt_annual_return = 0.0
            if len(bt_portfolio_values) > 1 and bt_portfolio_values[0] > 0:
                total_return = bt_portfolio_values[-1] / bt_portfolio_values[0] - 1
                trading_days_used = day_end - day_start
                years = trading_days_used / 250 if trading_days_used > 0 else 1
                if total_return > -1:
                    bt_annual_return = ((1 + total_return) ** (1 / max(years, 0.01)) - 1) * 100
                else:
                    bt_annual_return = -100.0
                # Cap annual return to prevent short-window inflation
                bt_annual_return = assert_annual_return_reasonable(bt_annual_return)

            # Max drawdown — use per-trade capital snapshots for accuracy.
            # bt_portfolio_values only samples once per cycle (every hold_days),
            # which misses intra-cycle drawdowns.  The trade log captures
            # capital_after every individual trade, giving a true peak-to-trough.
            bt_max_drawdown = 0.0
            if hasattr(self, '_trade_log') and self._trade_log:
                # Collect capital snapshots from trade log for this backtest run
                # (trade log may contain trades from other individuals too — we
                # just use bt_portfolio_values as the primary source, augmented.)
                pass
            # Primary: use bt_portfolio_values (cycle-level snapshots)
            peak = bt_portfolio_values[0]
            for v in bt_portfolio_values:
                if v > peak:
                    peak = v
                dd = (peak - v) / peak * 100 if peak > 0 else 0
                bt_max_drawdown = max(bt_max_drawdown, dd)

            # Sharpe/Sortino — shared implementation with crypto (metrics.py)
            from stratevo.evolution.metrics import compute_trade_sharpe_sortino
            _bars_per_year_bt = 250.0  # A-share daily bars
            bt_sharpe, bt_sortino = compute_trade_sharpe_sortino(
                bt_trades, day_end - day_start, bars_per_year=_bars_per_year_bt
            )

            bt_calmar = bt_annual_return / max(bt_max_drawdown, 1.0)
            bt_profit_factor = bt_gross_profit / bt_gross_loss if bt_gross_loss > 0 else (10.0 if bt_gross_profit > 0 else 0.0)

            # Compute average turnover
            bt_avg_turnover = 0.0
            if bt_turnover_ratios:
                bt_avg_turnover = sum(bt_turnover_ratios) / len(bt_turnover_ratios)

            return (bt_annual_return, bt_max_drawdown, bt_win_rate, bt_sharpe,
                    bt_calmar, bt_total_trades, bt_profit_factor, bt_sortino,
                    bt_max_consec_losses, bt_monthly_returns, bt_max_concurrent,
                    bt_avg_turnover)

        # ── Run backtests on train and validation periods ──
        # Choose the backtest dispatch callable
        if _run_backtest_dispatch is not None:
            _bt_fn = _run_backtest_dispatch
        else:
            _bt_fn = _run_backtest

        if self.walk_forward and self._wf_validator is not None:
            # ── Multi-window walk-forward validation ──
            wf_result = self._wf_validator.validate(
                _bt_fn, total_bars=total_days, warmup=warmup,
            )
            fitness = wf_result.final_fitness

            # ── CPCV overlay (additional overfit detection) ──
            # Only run on elite candidates (fitness > 5) to avoid crushing
            # every individual with 6 extra backtest paths.
            # C(4,2)=6 paths is lighter than C(6,2)=15.
            if fitness > 5 and 500 <= total_days <= 5000:
                try:
                    from stratevo.evolution.cpcv import CPCVValidator, CPCVConfig
                    cpcv = CPCVValidator(CPCVConfig(
                        n_groups=4,
                        n_test_groups=2,
                        embargo_pct=0.01,
                        purge_pct=0.01,
                    ))
                    cpcv_result = cpcv.validate(total_days, _bt_fn)
                    fitness *= cpcv_result.fitness_adjustment
                except Exception:
                    pass  # CPCV failure should not block evaluation

            if wf_result.window_results:
                n_windows = len(wf_result.window_results)

                # ── CAGR aggregation (industry standard, per empyrical/quantstats) ──
                # Chain all OOS windows into a single compounded return, then
                # annualise over the total OOS period.  This avoids the bias
                # from averaging per-window annualised returns where one short
                # window with extreme performance can dominate the average.
                compounded_oos = 1.0
                total_oos_days = 0

                # Market-aware: window ranges are in bar units, not calendar days
                # A-shares: daily bars → 250 bars/year
                # Crypto: hourly bars → 8760 bars/year (365 × 24)
                if self.market == "crypto":
                    _bars_per_year = 365.0 * 24.0  # 8760 hourly bars
                elif self.market == "us":
                    _bars_per_year = 250.0  # daily bars, US trading days
                else:
                    _bars_per_year = 250.0  # daily bars, A-share trading days

                # Filter to valid windows (enough trades) — must match
                # walk_forward.py which only uses valid windows for CAGR.
                _min_trades = 5
                if self._wf_validator and self._wf_validator.config:
                    _min_trades = self._wf_validator.config.min_trades_per_window
                _valid_wf_windows = [
                    w for w in wf_result.window_results
                    if w.oos_trades >= _min_trades
                ]
                _all_wf_windows = wf_result.window_results

                for w in _valid_wf_windows:
                    window_days = w.test_range[1] - w.test_range[0]
                    total_oos_days += window_days
                    years_w = window_days / _bars_per_year if window_days > 0 else 1.0
                    # Use capped return (same cap as _compute_window_fitness)
                    ar_frac = w.oos_annual_return_capped / 100.0
                    if ar_frac > -1.0:
                        window_total_return = (1.0 + ar_frac) ** years_w - 1.0
                    else:
                        window_total_return = -1.0
                    compounded_oos *= (1.0 + window_total_return)

                total_oos_years = total_oos_days / _bars_per_year if total_oos_days > 0 else 1.0
                if compounded_oos > 0:
                    annual_return = (compounded_oos ** (1.0 / total_oos_years) - 1.0) * 100.0
                else:
                    annual_return = -100.0
                annual_return = assert_annual_return_reasonable(annual_return)

                max_drawdown = max(
                    w.oos_max_drawdown for w in _all_wf_windows
                )
                sharpe = sum(
                    w.oos_sharpe for w in _all_wf_windows
                ) / n_windows
                win_rate = sum(
                    w.oos_win_rate for w in _all_wf_windows
                ) / n_windows
                total_trades = sum(
                    w.oos_trades for w in _all_wf_windows
                )
                calmar = annual_return / max(max_drawdown, 1.0)
                # Aggregate profit_factor across windows (weighted average by trades)
                _total_wf_trades = sum(w.oos_trades for w in _all_wf_windows)
                if _total_wf_trades > 0:
                    profit_factor = sum(
                        w.oos_profit_factor * w.oos_trades for w in _all_wf_windows
                    ) / _total_wf_trades
                else:
                    profit_factor = 0.0
                sortino = 0.0

                # Serialize window details for audit trail
                wf_window_dicts = [
                    {
                        "window": w.window_index,
                        "train_range": list(w.train_range),
                        "test_range": list(w.test_range),
                        "is_fitness": round(w.is_fitness, 4),
                        "oos_fitness": round(w.oos_fitness, 4),
                        "oos_annual_return": round(w.oos_annual_return, 4),
                        "oos_annual_return_capped": round(w.oos_annual_return_capped, 4),
                        "oos_max_drawdown": round(w.oos_max_drawdown, 4),
                        "oos_sharpe": round(w.oos_sharpe, 4),
                        "oos_trades": w.oos_trades,
                        "oos_win_rate": round(w.oos_win_rate, 4),
                        "oos_profit_factor": round(w.oos_profit_factor, 4),
                    }
                    for w in wf_result.window_results
                ]
            else:
                annual_return = 0.0
                max_drawdown = 0.0
                sharpe = 0.0
                win_rate = 0.0
                total_trades = 0
                calmar = 0.0
                profit_factor = 0.0
                sortino = 0.0
                wf_window_dicts = []
        else:
            # ── LEGACY: Single 70/30 split (backward compatible) ──
            (train_ret, train_dd, train_wr, train_sharpe, train_calmar,
             train_trades, train_pf, train_sortino,
             train_consec_losses, train_monthly, train_max_concurrent,
             train_avg_turnover) = _bt_fn(warmup, train_end)

            (val_ret, val_dd, val_wr, val_sharpe, val_calmar,
             val_trades, val_pf, val_sortino,
             val_consec_losses, val_monthly, val_max_concurrent,
             val_avg_turnover) = _bt_fn(val_start, val_end)

            # Combine metrics (report validation-period numbers as primary)
            total_trades = train_trades + val_trades
            annual_return = val_ret
            max_drawdown = max(train_dd, val_dd)
            win_rate = val_wr
            sharpe = val_sharpe
            calmar = val_calmar
            profit_factor = val_pf
            sortino = val_sortino  # noqa: F841
            max_consec_losses = max(train_consec_losses, val_consec_losses)  # noqa: F841
            monthly_returns = (train_monthly or []) + (val_monthly or [])  # noqa: F841
            max_concurrent = max(train_max_concurrent, val_max_concurrent)  # noqa: F841

            # Build factor_weights for fitness bonus
            _fw = dna.to_dict()
            _factor_weights = {k: v for k, v in _fw.items() if k.startswith('w_') or k in (dna.custom_weights or {})}

            train_fitness = compute_fitness(
                train_ret, train_dd, train_wr, train_sharpe, train_trades,
                sortino=train_sortino,
                max_consec_losses=train_consec_losses,
                monthly_returns=train_monthly,
                positions_used=train_max_concurrent,
                max_positions=dna.max_positions,
                avg_turnover=train_avg_turnover,
                factor_weights=_factor_weights,
            )
            val_fitness = compute_fitness(
                val_ret, val_dd, val_wr, val_sharpe, val_trades,
                sortino=val_sortino,
                max_consec_losses=val_consec_losses,
                monthly_returns=val_monthly,
                positions_used=val_max_concurrent,
                max_positions=dna.max_positions,
                avg_turnover=val_avg_turnover,
                factor_weights=_factor_weights,
            )

            fitness = 0.4 * train_fitness + 0.6 * val_fitness

            if train_fitness > 0 and val_fitness < 0.3 * train_fitness:
                fitness *= 0.3

            # ── OOS return gate (mirrors walk-forward fix) ──
            # If validation return is negative, the strategy fails out-of-sample.
            # Train fitness must not rescue it.  (López de Prado 2018)
            if val_ret < 0:
                fitness = min(fitness, 0.0)
            # If validation fitness is negative, cap combined at val_fitness
            if val_fitness < 0:
                fitness = min(fitness, val_fitness)

        # Invariant: fitness sanity check — log warning if suspiciously high
        assert_fitness_sane(fitness)

        # Include walk-forward window details when available
        wf_windows = None
        if self.walk_forward and self._wf_validator is not None:
            wf_windows = wf_window_dicts if wf_window_dicts else None

        return EvolutionResult(
            dna=dna,
            annual_return=round(annual_return, 4),
            max_drawdown=round(max_drawdown, 4),
            win_rate=round(win_rate, 4),
            sharpe=round(sharpe, 4),
            calmar=round(calmar, 4),
            total_trades=total_trades,
            profit_factor=round(profit_factor, 4),
            fitness=round(fitness, 4),
            walk_forward_windows=wf_windows,
        )

    def _random_dna(self) -> StrategyDNA:
        """Generate a completely random StrategyDNA."""
        d = {}
        for param, (lo, hi, is_int) in _PARAM_RANGES.items():
            val = self.rng.uniform(lo, hi)
            if is_int:
                val = int(round(val))
            d[param] = val
        # Normalize weights
        w_sum = sum(d[k] for k in _WEIGHT_KEYS)
        if w_sum > 0:
            for k in _WEIGHT_KEYS:
                d[k] = round(d[k] / w_sum, 4)
        dna = StrategyDNA.from_dict(d)
        # Also randomize custom weights if factor registry exists
        if hasattr(self, '_factor_registry') and self._factor_registry and self._factor_registry.factors:
            cw = {}
            for name in self._factor_registry.list_factors():
                cw[name] = self.rng.uniform(0, 0.1)  # small random values
            dna.custom_weights = cw
        return dna

    def _strategy_distance(self, dna1: StrategyDNA, dna2: StrategyDNA) -> float:
        """Measure how different two strategies are (0=identical, 1=very different)."""
        d1 = dna1.to_dict()
        d2 = dna2.to_dict()
        diffs = []
        for param, (lo, hi, _) in _PARAM_RANGES.items():
            range_size = hi - lo
            if range_size > 0:
                diff = abs(d1.get(param, 0) - d2.get(param, 0)) / range_size
                diffs.append(diff)
        return sum(diffs) / len(diffs) if diffs else 0.0

    def _tournament_select(
        self, results: List[EvolutionResult]
    ) -> List[EvolutionResult]:
        """Select elite parents using tournament selection with elitism.

        - Always keeps the #1 best (elitism).
        - For remaining slots, picks 3 random candidates and takes the best.
        - Preserves diversity by giving weaker-but-different strategies a chance.
        """
        if len(results) <= self.elite_count:
            return list(results)

        # Elitism: always keep #1
        selected = [results[0]]

        # Tournament selection for remaining slots
        for _ in range(self.elite_count - 1):
            tournament = self.rng.sample(results, min(3, len(results)))
            winner = max(tournament, key=lambda r: r.fitness)
            if winner not in selected:
                selected.append(winner)
            else:
                # If winner already selected, take the next best from tournament
                found = False
                for t in sorted(tournament, key=lambda r: r.fitness, reverse=True):
                    if t not in selected:
                        selected.append(t)
                        found = True
                        break
                if not found:
                    # Fallback: pick next unselected result by rank
                    for r in results:
                        if r not in selected:
                            selected.append(r)
                            break

        return sorted(selected[:self.elite_count],
                      key=lambda r: r.fitness, reverse=True)

    def run_generation(
        self,
        parents: List[StrategyDNA],
        data: Dict[str, Dict[str, list]],
        gen: int = 0,
    ) -> List[EvolutionResult]:
        """Run one generation of evolution.

        1. Generate mutations + crossovers from parents
        2. Evaluate all candidates (with deterministic sampling via gen seed)
        3. Apply diversity bonus (niche preservation)
        4. Select elite via tournament selection
        5. Return top ``elite_count`` results
        """
        candidates: List[StrategyDNA] = list(parents)

        # Choose mutator: logic-guided or standard
        if self.logic_guided and self._logic_evolver is not None:
            _logic_mutator = self._logic_evolver.get_mutator(
                mutation_rate=self.mutation_rate,
                seed=gen,
            )
            _mutate_fn = _logic_mutator.mutate
        else:
            # Adaptive eta_m: lower during stagnation for wider exploration
            _stag = getattr(self, '_stagnation_counter', 0)
            if _stag >= 20:
                _eta_m = 3.0   # very wide perturbations
            elif _stag >= 10:
                _eta_m = 5.0   # wide perturbations
            elif _stag >= 5:
                _eta_m = 10.0  # moderate perturbations
            else:
                _eta_m = 20.0  # default: mostly small perturbations
            _mutate_fn = lambda dna: self.mutate(dna, eta_m_override=_eta_m)

        # === Random immigrants: always inject a fraction of fully random DNA ===
        # This maintains population diversity and prevents premature convergence.
        # 10% of population slots (at least 1) are random immigrants.
        n_immigrants = max(1, self.population_size // 10)
        for _ in range(n_immigrants):
            if len(candidates) < self.population_size:
                candidates.append(self._random_dna())

        while len(candidates) < self.population_size:
            parent = self.rng.choice(parents)
            if self.rng.random() < 0.7:
                # Mutation
                child = _mutate_fn(parent)
            else:
                # Crossover with fitness-weighted bias toward better parent
                other = self.rng.choice(parents)
                child = self.crossover(parent, other, bias=0.6)
                child = _mutate_fn(child)  # mutate after crossover
            candidates.append(child)

        results = [self.evaluate(dna, data, gen_seed=gen) for dna in candidates]
        results.sort(key=lambda r: r.fitness, reverse=True)

        # Diversity bonus: strategies different from the champion get a small boost
        if len(results) > 1:
            champion_dna = results[0].dna
            for r in results[1:]:
                dist = self._strategy_distance(r.dna, champion_dna)
                # Up to 25% bonus for being very different (was 10%)
                diversity_bonus = 1.0 + dist * 0.25
                # For negative fitness, use additive bonus instead of
                # multiplicative (multiplying a negative by >1 makes it worse)
                if r.fitness >= 0:
                    r.fitness *= diversity_bonus
                else:
                    # Additive: shift toward zero by a fraction of |fitness|
                    r.fitness += abs(r.fitness) * (diversity_bonus - 1.0)
            # Re-sort after applying diversity bonus
            results.sort(key=lambda r: r.fitness, reverse=True)

        # Tournament selection with elitism (replaces simple top-N)
        return self._tournament_select(results)

    def evolve(self, generations: int = 100, save_interval: int = 10) -> List[EvolutionResult]:
        """Main evolution loop.

        - Loads data once
        - Optionally resumes from saved results
        - If ``self.pareto`` is True, delegates to NSGA-III via ParetoEvolver
        - Otherwise runs ``generations`` generations of single-objective GA
        - Saves best results every ``save_interval`` gens
        - Prints progress each generation

        Returns:
            Final top results
        """
        # ── Multi-objective Pareto mode ──
        if self.pareto:
            return self._evolve_pareto(generations=generations, save_interval=save_interval)

        print("=" * 60)
        print(" StratEvo Auto Evolution Engine")
        print("=" * 60)

        t0 = time.time()
        print("Loading market data...", flush=True)
        data = self.load_data(max_stocks=self.max_stocks)
        elapsed = time.time() - t0
        print(f"Loaded {len(data)} stocks in {elapsed:.1f}s")

        if not data:
            print("ERROR: No data loaded. Check data_dir path.")
            return []

        # Try to resume from saved results
        parents = self._load_parents()
        start_gen = self._load_start_gen()
        if parents:
            print(f"Resuming from generation {start_gen} with {len(parents)} elite strategies")
        else:
            parents = [StrategyDNA()]  # default seed
            start_gen = 0
            print("Starting fresh with default strategy DNA")

        # Load factor registry and initialize custom_weights for all parents
        if not hasattr(self, '_factor_registry'):
            try:
                from stratevo.evolution.factor_discovery import FactorRegistry, create_seed_factors
                create_seed_factors("factors")
                self._factor_registry = FactorRegistry("factors")
                self._factor_registry.load_all(market=self.market)
                factor_names = self._factor_registry.list_factors()
                if factor_names:
                    print(f"  [factors] loaded {len(factor_names)} dynamic factors")
            except Exception as e:
                print(f"  [factors] skipped: {e}")
                self._factor_registry = None

        # Ensure all parents have custom_weights populated with discovered factor names
        if self._factor_registry and self._factor_registry.factors:
            discovered = self._factor_registry.list_factors()
            updated_parents = []
            for p in parents:
                cw = dict(p.custom_weights)  # copy
                for fname in discovered:
                    if fname not in cw:
                        cw[fname] = 0.0
                updated_parents.append(StrategyDNA(
                    **{f.name: getattr(p, f.name) for f in fields(p) if f.name != 'custom_weights'},
                    custom_weights=cw,
                ))
            parents = updated_parents

        # Initialize Market Logic Layer if enabled
        if self.logic_guided:
            from stratevo.evolution.market_logic import LogicEvolver
            # Build available_factors dict (name -> category) from factor registry
            _avail_factors: Dict[str, str] = {}
            if self._factor_registry and self._factor_registry.factors:
                for fname in self._factor_registry.list_factors():
                    meta = self._factor_registry.factors.get(fname)
                    _avail_factors[fname] = meta.category if meta else "custom"
            self._logic_evolver = LogicEvolver(
                initial_logic=self._logic_initial,
                eval_interval=self._logic_eval_interval,
                max_stagnation=self._logic_max_stagnation,
                exploration_ratio=self._logic_exploration_ratio,
                bias_strength=self._logic_bias_strength,
                seed=self.rng.randint(0, 2**31),
                available_factors=_avail_factors,
            )
            print(f"  [market logic] enabled — initial logic: "
                  f"{self._logic_evolver.current_logic.name}")

        # ── Adaptive population size ──
        # Scale population based on search space dimensionality.
        # Rule of thumb: pop_size ≥ 2 × sqrt(n_params) (Deb 2001)
        # NOTE: Disabled auto-expansion — with 500+ params and walk-forward
        # (4 windows), expanding to 46+ makes each generation too slow.
        # User-specified population is respected. Factor pruning (skipping
        # near-zero weights) already reduces effective dimensionality.
        n_builtin_params = len(_PARAM_RANGES)
        n_custom_factors = len(parents[0].custom_weights) if parents else 0
        n_total_params = n_builtin_params + n_custom_factors
        # Log but don't force:
        suggested_pop = max(20, int(2 * math.sqrt(n_total_params)))
        if self.population_size < suggested_pop:
            print(f"  [adaptive pop] {n_total_params} params, suggested pop "
                  f"{suggested_pop} (using {self.population_size} as specified)")

        print(f"Population: {self.population_size} | Elite: {self.elite_count} | "
              f"Mutation rate: {self.mutation_rate}")
        print("-" * 60)

        best_results: List[EvolutionResult] = []

        # Smart evolution: stagnation detection + adaptive mutation rate
        stagnation_counter = 0
        best_ever_fitness = 0.0
        base_mutation_rate = self.mutation_rate
        boost_gens = 0
        # Expose stagnation counter in instance for adaptive eta_m in run_generation
        self._stagnation_counter = 0

        for gen in range(start_gen, start_gen + generations):
            gen_t0 = time.time()

            # Adaptive mutation rate
            if gen < start_gen + 30:
                self.mutation_rate = min(base_mutation_rate * 1.5, 0.8)
            elif boost_gens > 0:
                self.mutation_rate = min(base_mutation_rate * 2.0, 0.9)
                boost_gens -= 1
            elif stagnation_counter > 10:
                # Stagnation: elevate mutation rate proportionally
                stag_factor = min(1.0 + stagnation_counter * 0.05, 2.5)
                self.mutation_rate = min(base_mutation_rate * stag_factor, 0.9)
            else:
                self.mutation_rate = base_mutation_rate

            results = self.run_generation(parents, data, gen=gen)
            gen_time = time.time() - gen_t0

            best = results[0]
            best_results = results

            # Stagnation detection
            if best.fitness > best_ever_fitness:
                best_ever_fitness = best.fitness
                stagnation_counter = 0
            else:
                stagnation_counter += 1
            # Sync to instance for adaptive eta_m in run_generation/mutate
            self._stagnation_counter = stagnation_counter

            print(
                f"Gen {gen:4d} | "
                f"fitness={best.fitness:8.2f} | "
                f"return={best.annual_return:7.2f}% | "
                f"dd={best.max_drawdown:5.2f}% | "
                f"wr={best.win_rate:5.1f}% | "
                f"sharpe={best.sharpe:5.2f} | "
                f"trades={best.total_trades:4d} | "
                f"{gen_time:.1f}s"
            )

            # Market Logic Layer: record generation and auto-switch on stagnation
            if self.logic_guided and self._logic_evolver is not None:
                new_logic = self._logic_evolver.record_generation(
                    best.fitness, elapsed=gen_time,
                )
                if new_logic is not None:
                    from stratevo.evolution.market_logic import PREDEFINED_LOGICS
                    new_name = PREDEFINED_LOGICS[new_logic].name
                    print(f"  [market logic] switching to: {new_name}")

            # Update parents for next generation
            parents = [r.dna for r in results]

            # Stagnation injection: escalating intensity (trigger every 8 gens)
            if stagnation_counter >= 8 and stagnation_counter % 8 == 0:
                # Escalation level: 1st=mild, 2nd=moderate, 3rd+=aggressive
                escalation = stagnation_counter // 8  # 1, 2, 3, ...
                if escalation == 1:
                    # Mild: replace bottom 4 with random DNA
                    n_inject = min(4, len(parents) - 1)
                    for i in range(n_inject):
                        parents[-(i+1)] = self._random_dna()
                    print(f"  [stagnation L1] {stagnation_counter} gens stuck -- injecting {n_inject} random DNA")
                elif escalation == 2:
                    # Moderate: replace bottom half with random DNA
                    n_inject = len(parents) // 2
                    for i in range(n_inject):
                        parents[-(i+1)] = self._random_dna()
                    print(f"  [stagnation L2] {stagnation_counter} gens stuck -- injecting {n_inject} random DNA (half pop)")
                else:
                    # Aggressive: keep only top 2, replace everything else
                    n_inject = len(parents) - 2
                    for i in range(n_inject):
                        parents[-(i+1)] = self._random_dna()
                    print(f"  [stagnation L3] {stagnation_counter} gens stuck -- near-total reset ({n_inject}/{len(parents)} replaced)")
                boost_gens = 5 + escalation * 3  # longer boost at higher levels

            # Periodic save
            if (gen + 1) % save_interval == 0 or gen == start_gen + generations - 1:
                self.save_results(gen, results)

        total_time = time.time() - t0
        self.mutation_rate = base_mutation_rate  # restore original rate
        print("-" * 60)
        print(f"Evolution complete! {generations} generations in {total_time:.1f}s")
        if best_results:
            print(f"Best fitness: {best_results[0].fitness:.4f}")

        # Market Logic Layer summary
        if self.logic_guided and self._logic_evolver is not None:
            print("\n  [market logic] Performance Summary:")
            for entry in self._logic_evolver.get_performance_summary():
                if entry["generations_used"] > 0:
                    print(f"    {entry['logic_type']:25s} | "
                          f"gens={entry['generations_used']:3d} | "
                          f"best_fit={entry['best_fitness']:8.2f} | "
                          f"avg_fit={entry['avg_fitness_10']:8.2f}")
            best_logic = self._logic_evolver.get_best_logic()
            from stratevo.evolution.market_logic import PREDEFINED_LOGICS
            print(f"  [market logic] Best logic: {PREDEFINED_LOGICS[best_logic].name}")

        print("=" * 60)

        return best_results

    def _evolve_pareto(
        self, generations: int = 100, save_interval: int = 10
    ) -> List[EvolutionResult]:
        """Delegate evolution to NSGA-III multi-objective Pareto optimizer.

        Returns a list of EvolutionResult for compatibility with the
        single-objective API. Each entry on the Pareto front is converted
        to an EvolutionResult with fitness=0 (since fitness is ambiguous
        in multi-objective context).
        """
        from stratevo.evolution.pareto import ParetoEvolver, display_pareto_front

        pareto_evolver = ParetoEvolver(
            evolver=self,
            include_complexity=self.pareto_complexity,
            population_size=self.population_size,
            results_dir=self.results_dir,
        )

        pareto_entries = pareto_evolver.evolve(
            generations=generations,
            save_interval=save_interval,
            verbose=True,
        )

        # Display the Pareto front
        print(display_pareto_front(pareto_entries))

        # Convert back to EvolutionResult for compatibility
        results = []
        for entry in pareto_entries:
            dna = StrategyDNA.from_dict(entry.dna)
            results.append(
                EvolutionResult(
                    dna=dna,
                    annual_return=entry.objectives.get("annual_return", 0.0),
                    max_drawdown=entry.objectives.get("max_drawdown", 0.0),
                    win_rate=0.0,
                    sharpe=0.0,
                    calmar=0.0,
                    total_trades=0,
                    profit_factor=0.0,
                    fitness=0.0,  # multi-objective — no single fitness
                )
            )
        return results

    def save_results(self, gen: int, best: List[EvolutionResult]) -> None:
        """Save best strategies to JSON for resumption."""
        result_file = os.path.join(self.results_dir, "latest.json")
        payload = {
            "generation": gen,
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "market": self.market,
            "data_dir": self.data_dir,
            "stock_codes": sorted(self._loaded_codes) if hasattr(self, '_loaded_codes') else [],
            "num_stocks": len(self._loaded_codes) if hasattr(self, '_loaded_codes') else 0,
            "results": [r.to_dict() for r in best],
        }
        def _atomic_json_write(path, payload):
            """Write JSON atomically: temp file + os.replace to avoid corruption."""
            dir_name = os.path.dirname(path) or '.'
            fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix='.tmp')
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as f:
                    json.dump(payload, f, indent=2, ensure_ascii=False)
                os.replace(tmp_path, path)
            except Exception:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise

        _atomic_json_write(result_file, payload)

        # Also save a versioned copy
        versioned = os.path.join(self.results_dir, f"gen_{gen:04d}.json")
        _atomic_json_write(versioned, payload)

        # ═══════════════════════════════════════════════════════════
        # best_ever.json — GLOBAL all-time best, NEVER overwritten
        # unless a new record is set. Survives cycle restarts.
        # ═══════════════════════════════════════════════════════════
        current_best_fitness = best[0].fitness if best else 0.0
        best_ever_file = os.path.join(self.results_dir, "best_ever.json")
        prev_ever_fitness = 0.0
        if os.path.exists(best_ever_file):
            try:
                with open(best_ever_file, "r", encoding="utf-8") as f:
                    prev_ever = json.load(f)
                prev_ever_fitness = prev_ever.get("fitness", 0.0)
            except Exception:
                prev_ever_fitness = 0.0

        if current_best_fitness > prev_ever_fitness:
            best_ever_payload = {
                "fitness": current_best_fitness,
                "generation": gen,
                "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
                "annual_return": best[0].annual_return,
                "max_drawdown": best[0].max_drawdown,
                "win_rate": best[0].win_rate,
                "sharpe": best[0].sharpe,
                "calmar": best[0].calmar,
                "total_trades": best[0].total_trades,
                "profit_factor": best[0].profit_factor,
                "dna": best[0].dna.to_dict(),
            }
            _atomic_json_write(best_ever_file, best_ever_payload)
            print(f"  [best_ever] NEW ALL-TIME RECORD! fitness={current_best_fitness:.2f} "
                  f"(prev={prev_ever_fitness:.2f}) gen={gen} "
                  f"annual={best[0].annual_return:.1f}% sharpe={best[0].sharpe:.2f}")

            # Save trade log for the best-ever DNA (for article verification)
            trade_log = getattr(self, '_trade_log', [])
            if trade_log:
                best_ever_trades_file = os.path.join(self.results_dir, "best_ever_trades.json")
                _atomic_json_write(best_ever_trades_file, {
                    "generation": gen,
                    "fitness": current_best_fitness,
                    "num_trades": len(trade_log),
                    "market": self.market,
                    "trades": trade_log,
                })

            # Save equity curve (capital_after from each trade, for backtest chart)
            if trade_log:
                equity = [{"trade_idx": i, "capital": t.get("capital_after", 0),
                           "date": t.get("exit_date", ""),
                           "code": t.get("code", "")}
                          for i, t in enumerate(trade_log)]
                best_ever_equity_file = os.path.join(self.results_dir, "best_ever_equity.json")
                _atomic_json_write(best_ever_equity_file, {
                    "generation": gen,
                    "fitness": current_best_fitness,
                    "initial_capital": 1000000,
                    "equity_curve": equity,
                })

            # Also save a timestamped copy so we never lose any record-breaking DNA
            hall_dir = os.path.join(self.results_dir, "hall_of_fame")
            os.makedirs(hall_dir, exist_ok=True)
            hof_name = f"record_gen{gen}_fit{int(current_best_fitness)}_" \
                       f"{time.strftime('%Y%m%d_%H%M%S')}.json"
            hof_path = os.path.join(hall_dir, hof_name)
            _atomic_json_write(hof_path, best_ever_payload)

        # Auto-backup best DNA (per-cycle best, kept for reference)
        best_dir = os.path.join(self.results_dir, "best_dna")
        os.makedirs(best_dir, exist_ok=True)
        best_fitness_file = os.path.join(best_dir, "_best_fitness.txt")
        prev_best = 0.0
        if os.path.exists(best_fitness_file):
            try:
                prev_best = float(open(best_fitness_file).read().strip())
            except Exception:
                pass
        if current_best_fitness > prev_best:
            annual = int(best[0].annual_return)
            sharpe_val = round(best[0].sharpe, 1)
            backup_name = f"best_gen{gen}_annual{annual}_sharpe{sharpe_val}.json"
            backup_path = os.path.join(best_dir, backup_name)
            with open(backup_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
            with open(best_fitness_file, "w") as f:
                f.write(str(current_best_fitness))
            print(f"  [backup] New cycle best! fitness={current_best_fitness:.1f} -> {backup_name}")

        # Save trade log for the best strategy (for verification)
        trade_log = getattr(self, '_trade_log', [])
        if trade_log:
            trade_log_file = os.path.join(self.results_dir, "trade_log_latest.json")
            with open(trade_log_file, "w", encoding="utf-8") as f:
                json.dump({
                    "generation": gen,
                    "num_trades": len(trade_log),
                    "market": self.market,
                    "trades": trade_log,
                }, f, indent=2, ensure_ascii=False)
            self._trade_log = []  # Reset for next evaluation

    def load_best(self) -> Optional[StrategyDNA]:
        """Load the best known strategy from saved results."""
        result_file = os.path.join(self.results_dir, "latest.json")
        if not os.path.exists(result_file):
            return None
        with open(result_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        results = data.get("results", [])
        if not results:
            return None
        return StrategyDNA.from_dict(results[0]["dna"])

    def _load_parents(self) -> List[StrategyDNA]:
        """Load elite parents from previous run for resumption."""
        result_file = os.path.join(self.results_dir, "latest.json")
        if not os.path.exists(result_file):
            return []
        try:
            with open(result_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return [StrategyDNA.from_dict(r["dna"]) for r in data.get("results", [])]
        except Exception:
            return []

    def _load_start_gen(self) -> int:
        """Get last completed generation for resumption."""
        result_file = os.path.join(self.results_dir, "latest.json")
        if not os.path.exists(result_file):
            return 0
        try:
            with open(result_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("generation", 0) + 1
        except Exception:
            return 0
