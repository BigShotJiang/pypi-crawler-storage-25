"""
Auto-download market data for the evolution engine.
=====================================================
Downloads default symbol sets when no local CSV data is available.

Supports:
- US stocks via yfinance
- Crypto via ccxt
- CN A-shares via akshare

Downloaded data is saved as CSV files in the expected data directory format
so subsequent runs reuse local data without re-downloading.
"""

from __future__ import annotations

import csv
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional

# ── Default symbol universes ──

DEFAULT_US_SYMBOLS = [
    # Top 50 SP500 stocks by market cap
    "AAPL", "MSFT", "GOOGL", "AMZN", "NVDA", "META", "TSLA", "BRK-B", "JPM", "V",
    "UNH", "JNJ", "WMT", "MA", "PG", "HD", "XOM", "CVX", "LLY", "ABBV",
    "MRK", "KO", "PEP", "COST", "AVGO", "TMO", "MCD", "CSCO", "ACN", "ABT",
    "DHR", "TXN", "NEE", "PM", "UPS", "MS", "RTX", "HON", "LOW", "AMGN",
    "IBM", "GE", "CAT", "BA", "SBUX", "INTC", "AMD", "QCOM", "ISRG", "MDLZ"
]

DEFAULT_CRYPTO_SYMBOLS = [
    "BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "ADA/USDT",
    "XRP/USDT", "DOGE/USDT", "DOT/USDT", "AVAX/USDT", "MATIC/USDT",
]

# CN defaults: top 50 of HS300 by weight (representative large caps)
DEFAULT_CN_SYMBOLS = [
    "600519", "601318", "600036", "000858", "601012",
    "600276", "000333", "002594", "601166", "600900",
    "000001", "600030", "601888", "300750", "002415",
    "601398", "600809", "000568", "601288", "002304",
    "600887", "601939", "000725", "601899", "600016",
    "601668", "600585", "002714", "601988", "000002",
    "002475", "600048", "601328", "300059", "600000",
    "601601", "000651", "002024", "601857", "600690",
    "603259", "000661", "601225", "002352", "600438",
    "601138", "300015", "002230", "600031", "601766",
]


def _data_dir_has_csvs(data_dir: str) -> bool:
    """Check if a data directory exists and contains at least one CSV."""
    if not os.path.isdir(data_dir):
        return False
    for f in os.listdir(data_dir):
        if f.lower().endswith(".csv"):
            return True
    return False


def _save_ohlcv_csv(filepath: str, rows: List[dict]) -> None:
    """Save OHLCV rows to a CSV file.

    Args:
        filepath: Output CSV path.
        rows: List of dicts with keys: date, open, high, low, close, volume.
    """
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["date", "open", "high", "low", "close", "volume"])
        for r in rows:
            writer.writerow([r["date"], r["open"], r["high"], r["low"], r["close"], r["volume"]])


def download_us_data(
    symbols: List[str],
    data_dir: str,
    days: int = 365,
) -> int:
    """Download US stock data via yfinance and save as CSVs.

    Args:
        symbols: Ticker symbols to download.
        data_dir: Output directory for CSV files.
        days: Number of days of history to download.

    Returns:
        Number of symbols successfully downloaded.
    """
    try:
        import yfinance as yf
    except ImportError:
        print("  ❌ yfinance not installed. Run: pip install yfinance")
        return 0

    os.makedirs(data_dir, exist_ok=True)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    start_str = start_date.strftime("%Y-%m-%d")
    end_str = end_date.strftime("%Y-%m-%d")

    print(f"\n  Downloading US stock data ({len(symbols)} symbols)")
    print(f"  Period: {start_str} to {end_str}")
    print(f"  Output: {data_dir}")
    print("  " + "=" * 60)

    success = 0
    for i, symbol in enumerate(symbols, 1):
        print(f"  [{i}/{len(symbols)}] {symbol} ...", end=" ", flush=True)
        try:
            ticker = yf.Ticker(symbol)
            df = ticker.history(start=start_str, end=end_str)
            if df is None or df.empty:
                print("SKIP — no data")
                continue

            rows = []
            for idx, row in df.iterrows():
                date_str = str(idx.date()) if hasattr(idx, "date") else str(idx)[:10]
                rows.append({
                    "date": date_str,
                    "open": round(float(row["Open"]), 4),
                    "high": round(float(row["High"]), 4),
                    "low": round(float(row["Low"]), 4),
                    "close": round(float(row["Close"]), 4),
                    "volume": int(row["Volume"]),
                })

            if rows:
                filepath = os.path.join(data_dir, f"{symbol}.csv")
                _save_ohlcv_csv(filepath, rows)
                print(f"OK — {len(rows)} days")
                success += 1
            else:
                print("SKIP — empty after parsing")
        except Exception as e:
            print(f"FAIL — {e}")
        time.sleep(0.3)  # rate limit

    print("  " + "=" * 60)
    print(f"  Downloaded {success}/{len(symbols)} US stocks\n")
    return success


def download_crypto_data(
    symbols: List[str],
    data_dir: str,
    days: int = 365,
    timeframe: str = "1d",
) -> int:
    """Download crypto OHLCV data via ccxt and save as CSVs.

    Args:
        symbols: Trading pairs like ["BTC/USDT", "ETH/USDT"].
        data_dir: Output directory for CSV files.
        days: Number of days of history to download.
        timeframe: Candle timeframe (default "1d").

    Returns:
        Number of symbols successfully downloaded.
    """
    try:
        import ccxt
    except ImportError:
        print("  ❌ ccxt not installed. Run: pip install ccxt")
        return 0

    os.makedirs(data_dir, exist_ok=True)

    # Try exchanges in order of reliability
    exchange = None
    for name, config in [
        ("okx", {"enableRateLimit": True}),
        ("bybit", {"enableRateLimit": True}),
        ("binance", {"enableRateLimit": True, "options": {"defaultType": "spot"}}),
    ]:
        try:
            print(f"  Trying {name}...", end=" ", flush=True)
            ex_cls = getattr(ccxt, name)
            ex = ex_cls(config)
            ex.load_markets()
            exchange = ex
            print(f"OK — connected to {name}")
            break
        except Exception as e:
            print(f"FAIL — {e}")

    if exchange is None:
        print("  ❌ Could not connect to any exchange.")
        return 0

    now = datetime.now(tz=timezone.utc)
    since = now - timedelta(days=days)
    since_ms = int(since.timestamp() * 1000)
    until_ms = int(now.timestamp() * 1000)

    print(f"\n  📥 Downloading crypto data ({len(symbols)} pairs, {timeframe})")
    print(f"  Period: {since.strftime('%Y-%m-%d')} to {now.strftime('%Y-%m-%d')}")
    print(f"  Output: {data_dir}")
    print("  " + "=" * 60)

    success = 0
    for i, symbol in enumerate(symbols, 1):
        filename = symbol.replace("/", "") + ".csv"
        filepath = os.path.join(data_dir, filename)
        print(f"  [{i}/{len(symbols)}] {symbol} ...", end=" ", flush=True)

        all_candles = []
        current_since = since_ms
        retries = 0

        while current_since < until_ms:
            try:
                candles = exchange.fetch_ohlcv(
                    symbol, timeframe=timeframe, since=current_since, limit=500
                )
                retries = 0
            except Exception as e:
                retries += 1
                if retries > 3:
                    print(f"FAIL — {e}")
                    break
                time.sleep(3 * retries)
                continue

            if not candles:
                break
            for c in candles:
                if c[0] <= until_ms:
                    all_candles.append(c)
            last_ts = candles[-1][0]
            if last_ts <= current_since:
                break
            current_since = last_ts + 1
            time.sleep(exchange.rateLimit / 1000.0)

        if all_candles:
            rows = []
            for c in all_candles:
                dt = datetime.fromtimestamp(c[0] / 1000, tz=timezone.utc)
                rows.append({
                    "date": dt.strftime("%Y-%m-%d %H:%M:%S") if timeframe != "1d" else dt.strftime("%Y-%m-%d"),
                    "open": c[1],
                    "high": c[2],
                    "low": c[3],
                    "close": c[4],
                    "volume": c[5],
                })
            _save_ohlcv_csv(filepath, rows)
            print(f"OK — {len(rows)} candles -> {filename}")
            success += 1
        else:
            print("SKIP — no data")

        if i < len(symbols):
            time.sleep(1.5)

    print("  " + "=" * 60)
    print(f"  ✅ Downloaded {success}/{len(symbols)} crypto pairs\n")
    return success


def download_cn_data(
    symbols: Optional[List[str]],
    data_dir: str,
    days: int = 365,
) -> int:
    """Download A-share data via akshare and save as CSVs.

    Args:
        symbols: Stock codes (e.g. ["600519", "000858"]).
                 If None, uses default top-50 HS300 components.
        data_dir: Output directory for CSV files.
        days: Number of days of history to download.

    Returns:
        Number of symbols successfully downloaded.
    """
    try:
        import akshare as ak
    except ImportError:
        print("  ❌ akshare not installed. Run: pip install akshare")
        return 0

    if symbols is None:
        symbols = DEFAULT_CN_SYMBOLS

    os.makedirs(data_dir, exist_ok=True)
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    start_str = start_date.strftime("%Y%m%d")
    end_str = end_date.strftime("%Y%m%d")

    print(f"\n  📥 Downloading A-share data ({len(symbols)} symbols)")
    print(f"  Period: {start_str} to {end_str}")
    print(f"  Output: {data_dir}")
    print("  " + "=" * 60)

    success = 0
    for i, symbol in enumerate(symbols, 1):
        print(f"  [{i}/{len(symbols)}] {symbol} ...", end=" ", flush=True)
        try:
            df = ak.stock_zh_a_hist(
                symbol=symbol,
                period="daily",
                start_date=start_str,
                end_date=end_str,
                adjust="qfq",
            )
            if df is None or df.empty:
                print("SKIP — no data")
                continue

            rows = []
            for _, row in df.iterrows():
                try:
                    rows.append({
                        "date": str(row.get("日期", "")),
                        "open": float(row.get("开盘", 0)),
                        "high": float(row.get("最高", 0)),
                        "low": float(row.get("最低", 0)),
                        "close": float(row.get("收盘", 0)),
                        "volume": float(row.get("成交量", 0)),
                    })
                except (ValueError, TypeError):
                    continue

            if rows:
                filepath = os.path.join(data_dir, f"{symbol}.csv")
                _save_ohlcv_csv(filepath, rows)
                print(f"OK — {len(rows)} days")
                success += 1
            else:
                print("SKIP — empty after parsing")
        except Exception as e:
            print(f"FAIL — {e}")
        time.sleep(0.5)  # rate limit

    print("  " + "=" * 60)
    print(f"  ✅ Downloaded {success}/{len(symbols)} A-share stocks\n")
    return success


def auto_download_for_market(
    market: str,
    data_dir: str,
    symbols: Optional[List[str]] = None,
    force: bool = False,
    days: int = 365,
) -> bool:
    """Auto-download data for a given market if needed.

    Args:
        market: Market type ("us", "crypto", "cn").
        data_dir: Target data directory.
        symbols: Override symbols list (None = use defaults).
        force: Force re-download even if data exists.
        days: Number of days of history.

    Returns:
        True if data directory has CSVs after this call.
    """
    if not force and _data_dir_has_csvs(data_dir):
        return True

    if force:
        print(f"  Force re-download for market '{market}'")
    else:
        print(f"  No local data found in {data_dir}")
        print(f"  Auto-downloading data for market '{market}'...")

    if market == "us":
        syms = symbols or DEFAULT_US_SYMBOLS
        download_us_data(syms, data_dir, days=days)
    elif market == "crypto":
        syms = symbols or DEFAULT_CRYPTO_SYMBOLS
        download_crypto_data(syms, data_dir, days=days)
    elif market == "cn":
        syms = symbols or DEFAULT_CN_SYMBOLS
        download_cn_data(syms, data_dir, days=days)
    else:
        print(f"  Unknown market: {market}")
        return False

    return _data_dir_has_csvs(data_dir)
