"""
regime.py — Market Regime Detection & Adaptive Evolution

Detects market regime from price data and adapts GA operators:
- Mutation strategies per regime
- Regime-aware fitness weighting
- Crossover that preserves regime-specific strengths
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Dict, List, Optional, Tuple


class MarketRegime(Enum):
    """Market regime classifications."""
    TRENDING_UP = "trending_up"
    TRENDING_DOWN = "trending_down"
    MEAN_REVERTING = "mean_reverting"
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"
    UNKNOWN = "unknown"


@dataclass
class RegimeInfo:
    """Detected regime with supporting metrics."""
    regime: MarketRegime
    confidence: float  # 0-1
    adx: float = 0.0
    atr_pct: float = 0.0
    trend_slope: float = 0.0
    volatility_ratio: float = 0.0  # current vol / historical vol


# ─── Technical Indicators (self-contained, no external deps) ──────

def _ema(data: List[float], period: int) -> List[float]:
    """Exponential moving average."""
    if not data or period <= 0:
        return []
    result = [float('nan')] * len(data)
    alpha = 2.0 / (period + 1)
    # Initialize with SMA
    init_end = min(period, len(data))
    valid = [x for x in data[:init_end] if math.isfinite(x)]
    if not valid:
        return result
    start_idx = init_end - 1
    result[start_idx] = sum(valid) / len(valid)
    for i in range(start_idx + 1, len(data)):
        if math.isfinite(data[i]) and math.isfinite(result[i - 1]):
            result[i] = alpha * data[i] + (1 - alpha) * result[i - 1]
    return result


def _sma(data: List[float], period: int) -> List[float]:
    """Simple moving average."""
    if not data or period <= 0:
        return []
    result = [float('nan')] * len(data)
    for i in range(period - 1, len(data)):
        window = data[i - period + 1:i + 1]
        valid = [x for x in window if math.isfinite(x)]
        if valid:
            result[i] = sum(valid) / len(valid)
    return result


def _true_range(high: List[float], low: List[float], close: List[float]) -> List[float]:
    """True range series."""
    n = len(close)
    tr = [float('nan')] * n
    if n > 0 and math.isfinite(high[0]) and math.isfinite(low[0]):
        tr[0] = high[0] - low[0]
    for i in range(1, n):
        if all(math.isfinite(x) for x in [high[i], low[i], close[i - 1]]):
            tr[i] = max(
                high[i] - low[i],
                abs(high[i] - close[i - 1]),
                abs(low[i] - close[i - 1])
            )
    return tr


def _atr(high: List[float], low: List[float], close: List[float],
         period: int = 14) -> List[float]:
    """Average True Range."""
    tr = _true_range(high, low, close)
    return _ema(tr, period)


def _adx(high: List[float], low: List[float], close: List[float],
         period: int = 14) -> Tuple[List[float], List[float], List[float]]:
    """ADX, +DI, -DI. Returns (adx, plus_di, minus_di)."""
    n = len(close)
    if n < period + 1:
        nans = [float('nan')] * n
        return nans[:], nans[:], nans[:]

    # Directional movement
    plus_dm = [0.0] * n
    minus_dm = [0.0] * n
    tr = _true_range(high, low, close)

    for i in range(1, n):
        if not all(math.isfinite(x) for x in [high[i], high[i-1], low[i], low[i-1]]):
            continue
        up = high[i] - high[i - 1]
        down = low[i - 1] - low[i]
        if up > down and up > 0:
            plus_dm[i] = up
        if down > up and down > 0:
            minus_dm[i] = down

    # Smooth with EMA
    smooth_tr = _ema(tr, period)
    smooth_plus = _ema(plus_dm, period)
    smooth_minus = _ema(minus_dm, period)

    plus_di = [float('nan')] * n
    minus_di = [float('nan')] * n
    dx = [float('nan')] * n

    for i in range(n):
        if (math.isfinite(smooth_tr[i]) and smooth_tr[i] > 0 and
                math.isfinite(smooth_plus[i]) and math.isfinite(smooth_minus[i])):
            plus_di[i] = 100 * smooth_plus[i] / smooth_tr[i]
            minus_di[i] = 100 * smooth_minus[i] / smooth_tr[i]
            di_sum = plus_di[i] + minus_di[i]
            if di_sum > 0:
                dx[i] = 100 * abs(plus_di[i] - minus_di[i]) / di_sum

    adx_line = _ema(dx, period)
    return adx_line, plus_di, minus_di


# ─── Regime Detection ──────────────────────────────────────────


class RegimeDetector:
    """Detects market regime from OHLC data."""

    def __init__(
        self,
        adx_period: int = 14,
        atr_period: int = 14,
        ma_period: int = 50,
        vol_lookback: int = 100,
        adx_trend_threshold: float = 25.0,
        vol_high_threshold: float = 1.5,
        vol_low_threshold: float = 0.5,
    ):
        self.adx_period = adx_period
        self.atr_period = atr_period
        self.ma_period = ma_period
        self.vol_lookback = vol_lookback
        self.adx_trend_threshold = adx_trend_threshold
        self.vol_high_threshold = vol_high_threshold
        self.vol_low_threshold = vol_low_threshold

    def detect(
        self,
        close: List[float],
        high: Optional[List[float]] = None,
        low: Optional[List[float]] = None,
    ) -> RegimeInfo:
        """Detect regime from price data.

        If high/low not provided, estimates from close.
        Only uses past data (look-ahead free).
        """
        if not close or len(close) < 2:
            return RegimeInfo(regime=MarketRegime.UNKNOWN, confidence=0.0)

        # Filter NaN
        valid_close = [c for c in close if math.isfinite(c)]
        if len(valid_close) < 2:
            return RegimeInfo(regime=MarketRegime.UNKNOWN, confidence=0.0)

        n = len(close)

        # Estimate high/low from close if not provided
        if high is None:
            high = [c * 1.005 if math.isfinite(c) else float('nan') for c in close]
        if low is None:
            low = [c * 0.995 if math.isfinite(c) else float('nan') for c in close]

        # Compute indicators
        adx_line, plus_di, minus_di = _adx(high, low, close, self.adx_period)
        atr_line = _atr(high, low, close, self.atr_period)
        ma_line = _sma(close, self.ma_period)

        # Get latest valid values
        last_adx = self._last_valid(adx_line)
        last_plus_di = self._last_valid(plus_di)
        last_minus_di = self._last_valid(minus_di)
        last_atr = self._last_valid(atr_line)
        last_price = self._last_valid(close)
        last_ma = self._last_valid(ma_line)

        # ATR as % of price
        atr_pct = (last_atr / last_price * 100) if (last_price and last_price > 0 and last_atr) else 0.0

        # Volatility ratio: current ATR / historical average ATR
        vol_ratio = self._volatility_ratio(atr_line, self.vol_lookback)

        # MA slope (trend direction)
        trend_slope = self._ma_slope(ma_line, lookback=10)

        # ── Classification logic ──
        regime = MarketRegime.UNKNOWN
        confidence = 0.0

        if last_adx is None:
            return RegimeInfo(regime=MarketRegime.UNKNOWN, confidence=0.0,
                              atr_pct=atr_pct, volatility_ratio=vol_ratio,
                              trend_slope=trend_slope)

        # Check volatility regimes first (they override trend detection)
        if vol_ratio > self.vol_high_threshold:
            regime = MarketRegime.HIGH_VOLATILITY
            confidence = min(1.0, (vol_ratio - 1.0) / (self.vol_high_threshold - 1.0))
        elif vol_ratio < self.vol_low_threshold and vol_ratio > 0:
            regime = MarketRegime.LOW_VOLATILITY
            confidence = min(1.0, (1.0 - vol_ratio) / (1.0 - self.vol_low_threshold))
        elif last_adx >= self.adx_trend_threshold:
            # Strong trend
            if last_plus_di is not None and last_minus_di is not None:
                if last_plus_di > last_minus_di:
                    regime = MarketRegime.TRENDING_UP
                else:
                    regime = MarketRegime.TRENDING_DOWN
                confidence = min(1.0, last_adx / 50.0)
            else:
                regime = MarketRegime.TRENDING_UP if trend_slope > 0 else MarketRegime.TRENDING_DOWN
                confidence = min(1.0, last_adx / 50.0) * 0.7  # lower confidence without DI
        else:
            # Low ADX = ranging/mean-reverting
            regime = MarketRegime.MEAN_REVERTING
            confidence = min(1.0, (self.adx_trend_threshold - last_adx) / self.adx_trend_threshold)

        return RegimeInfo(
            regime=regime,
            confidence=confidence,
            adx=last_adx,
            atr_pct=atr_pct,
            trend_slope=trend_slope,
            volatility_ratio=vol_ratio,
        )

    def detect_windows(
        self,
        close: List[float],
        window_ranges: List[Tuple[int, int]],
        high: Optional[List[float]] = None,
        low: Optional[List[float]] = None,
    ) -> List[RegimeInfo]:
        """Detect regime for each walk-forward window.

        Args:
            close: full price series
            window_ranges: list of (start_idx, end_idx) tuples
            high/low: optional OHLC data

        Returns:
            List of RegimeInfo, one per window
        """
        results = []
        for start, end in window_ranges:
            end = min(end, len(close))
            start = max(0, start)
            if start >= end:
                results.append(RegimeInfo(regime=MarketRegime.UNKNOWN, confidence=0.0))
                continue

            c_slice = close[start:end]
            h_slice = high[start:end] if high else None
            l_slice = low[start:end] if low else None
            results.append(self.detect(c_slice, h_slice, l_slice))
        return results

    @staticmethod
    def _last_valid(series: List[float]) -> Optional[float]:
        for v in reversed(series):
            if math.isfinite(v):
                return v
        return None

    @staticmethod
    def _volatility_ratio(atr_line: List[float], lookback: int) -> float:
        """Current ATR / historical average ATR."""
        valid = [v for v in atr_line if math.isfinite(v)]
        if len(valid) < 2:
            return 1.0
        current = valid[-1]
        hist = valid[:-1][-lookback:] if lookback else valid[:-1]
        if not hist:
            return 1.0
        avg_hist = sum(hist) / len(hist)
        if avg_hist < 1e-12:
            return 1.0
        return current / avg_hist

    @staticmethod
    def _ma_slope(ma_line: List[float], lookback: int = 10) -> float:
        """Slope of MA line (positive = uptrend)."""
        valid = [(i, v) for i, v in enumerate(ma_line) if math.isfinite(v)]
        if len(valid) < 2:
            return 0.0
        recent = valid[-lookback:]
        if len(recent) < 2:
            return 0.0
        first_val = recent[0][1]
        last_val = recent[-1][1]
        n_bars = recent[-1][0] - recent[0][0]
        if n_bars == 0 or first_val == 0:
            return 0.0
        return (last_val - first_val) / first_val * 100  # % change


# ─── Regime-Adaptive Mutation Biases ──────────────────────────


# Which DNA fields to boost per regime
REGIME_MUTATION_BIAS: Dict[MarketRegime, Dict[str, float]] = {
    MarketRegime.TRENDING_UP: {
        # Favor momentum/trend-following params
        "w_momentum_5d": 1.5,
        "w_momentum_20d": 1.5,
        "w_macd": 1.5,
        "w_ema_crossover": 1.5,
        "trailing_stop_enabled": 1.3,
        "trailing_activation_pct": 1.2,
        # Reduce mean-reversion focus
        "w_rsi_oversold": 0.5,
        "w_bollinger_lower": 0.5,
    },
    MarketRegime.TRENDING_DOWN: {
        # Short/defensive params
        "stop_loss_pct": 1.5,  # tighter stops
        "w_rsi_overbought": 1.5,
        "w_volume_spike": 1.3,
        "hold_days": 0.7,  # shorter holds
    },
    MarketRegime.MEAN_REVERTING: {
        # Mean-reversion params
        "w_rsi_oversold": 1.5,
        "w_bollinger_lower": 1.5,
        "w_mean_reversion_5d": 1.5,
        "dip_threshold_pct": 1.3,
        # Reduce trend-following
        "w_momentum_5d": 0.5,
        "w_macd": 0.5,
    },
    MarketRegime.HIGH_VOLATILITY: {
        # Risk management focus
        "stop_loss_pct": 1.5,
        "max_positions": 0.7,  # fewer positions
        "take_profit_pct": 1.3,  # wider take-profit
        "w_atr": 1.5,
        "w_volatility": 1.3,
    },
    MarketRegime.LOW_VOLATILITY: {
        # Aggressive entry params
        "min_score": 0.7,  # lower threshold to enter
        "max_positions": 1.3,  # more positions
        "w_volume_ratio": 1.3,
        "hold_days": 1.3,  # longer holds
    },
}


def get_mutation_bias(regime: MarketRegime) -> Dict[str, float]:
    """Get mutation bias multipliers for a regime.

    Returns dict of DNA field name -> multiplier.
    Multiplier > 1 = boost mutation toward higher values.
    Multiplier < 1 = bias toward lower values.
    """
    return REGIME_MUTATION_BIAS.get(regime, {})


# ─── Regime-Weighted Fitness ──────────────────────────────────


def regime_weighted_fitness(
    window_fitnesses: List[float],
    window_regimes: List[RegimeInfo],
    current_regime: MarketRegime,
    recent_weight: float = 2.0,
) -> float:
    """Weight walk-forward window fitnesses by regime match.

    Windows matching current market regime get ``recent_weight`` multiplier.
    Other windows get 1.0.

    Args:
        window_fitnesses: fitness from each WF window
        window_regimes: detected regime for each window
        current_regime: what regime the market is in now
        recent_weight: multiplier for matching-regime windows

    Returns:
        Weighted average fitness
    """
    if not window_fitnesses:
        return 0.0

    n = len(window_fitnesses)
    if len(window_regimes) != n:
        # Fallback to equal weighting
        return sum(window_fitnesses) / n

    weights = []
    for i in range(n):
        if window_regimes[i].regime == current_regime:
            w = recent_weight * window_regimes[i].confidence
        else:
            w = 1.0
        weights.append(max(w, 0.1))  # floor

    total_w = sum(weights)
    if total_w < 1e-12:
        return sum(window_fitnesses) / n

    return sum(f * w for f, w in zip(window_fitnesses, weights)) / total_w
