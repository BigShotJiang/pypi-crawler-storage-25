"""
Built-in technical indicator functions for the evolution engine.

Extracted from auto_evolve.py -- pure compute functions with no side effects.
"""

from __future__ import annotations

import math
from typing import List, Tuple


def compute_rsi(closes: List[float], period: int = 14) -> List[float]:
    """Compute RSI indicator. Returns list same length as input (NaN-padded)."""
    rsi = [float("nan")] * len(closes)
    if len(closes) < period + 1:
        return rsi
    gains = []
    losses = []
    for i in range(1, len(closes)):
        delta = closes[i] - closes[i - 1]
        gains.append(max(delta, 0.0))
        losses.append(max(-delta, 0.0))

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    for i in range(period, len(closes)):
        if i > period:
            avg_gain = (avg_gain * (period - 1) + gains[i - 1]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i - 1]) / period

        if avg_loss == 0:
            rsi[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            rsi[i] = 100.0 - 100.0 / (1.0 + rs)

    return rsi


def compute_linear_regression(
    values: List[float], window: int = 20
) -> Tuple[List[float], List[float]]:
    """Compute rolling R² and slope over a window.

    Returns (r2_list, slope_list), same length as input, NaN-padded.
    Slope is expressed as daily % return.
    """
    n = len(values)
    r2_out = [float("nan")] * n
    slope_out = [float("nan")] * n

    if n < window:
        return r2_out, slope_out

    for i in range(window - 1, n):
        segment = values[i - window + 1 : i + 1]
        mean_y = sum(segment) / window
        mean_x = (window - 1) / 2.0

        ss_xy = 0.0
        ss_xx = 0.0
        ss_yy = 0.0
        for j, y in enumerate(segment):
            dx = j - mean_x
            dy = y - mean_y
            ss_xy += dx * dy
            ss_xx += dx * dx
            ss_yy += dy * dy

        if ss_xx == 0 or ss_yy == 0:
            r2_out[i] = 0.0
            slope_out[i] = 0.0
            continue

        slope = ss_xy / ss_xx
        r2 = (ss_xy * ss_xy) / (ss_xx * ss_yy)
        # daily % slope relative to mean price
        slope_pct = (slope / mean_y) * 100.0 if mean_y != 0 else 0.0

        r2_out[i] = max(0.0, min(1.0, r2))
        slope_out[i] = slope_pct

    return r2_out, slope_out


def compute_volume_ratio(volumes: List[float], period: int = 20) -> List[float]:
    """Compute rolling volume ratio (current / average of past N days)."""
    n = len(volumes)
    ratios = [float("nan")] * n
    if n < period + 1:
        return ratios
    for i in range(period, n):
        avg = sum(volumes[i - period : i]) / period
        ratios[i] = volumes[i] / avg if avg > 0 else 0.0
    return ratios


# ────────────────── New Signal Functions (v2) ──────────────────


def _ema(values: List[float], period: int) -> List[float]:
    """Exponential moving average. Returns list same length, NaN-padded."""
    out = [float("nan")] * len(values)
    if len(values) < period:
        return out
    # Seed with SMA
    sma = sum(values[:period]) / period
    out[period - 1] = sma
    k = 2.0 / (period + 1)
    for i in range(period, len(values)):
        out[i] = values[i] * k + out[i - 1] * (1 - k)
    return out


def compute_macd(
    closes: List[float], fast: int = 12, slow: int = 26, signal: int = 9
) -> Tuple[List[float], List[float], List[float]]:
    """MACD line, signal line, histogram. Returns 3 lists same length, NaN-padded."""
    n = len(closes)
    nan_list = [float("nan")] * n
    if n < slow + signal:
        return nan_list[:], nan_list[:], nan_list[:]

    fast_ema = _ema(closes, fast)
    slow_ema = _ema(closes, slow)

    macd_line = [float("nan")] * n
    for i in range(slow - 1, n):
        if not (math.isnan(fast_ema[i]) or math.isnan(slow_ema[i])):
            macd_line[i] = fast_ema[i] - slow_ema[i]

    # Signal line = EMA of MACD line
    # Collect valid MACD values for EMA seed
    valid_macd = [(i, macd_line[i]) for i in range(n) if not math.isnan(macd_line[i])]
    signal_line = [float("nan")] * n
    hist = [float("nan")] * n

    if len(valid_macd) >= signal:
        sma = sum(v for _, v in valid_macd[:signal]) / signal
        start_idx = valid_macd[signal - 1][0]
        signal_line[start_idx] = sma
        k = 2.0 / (signal + 1)
        vi = signal  # noqa: F841
        for i in range(start_idx + 1, n):
            if not math.isnan(macd_line[i]):
                signal_line[i] = macd_line[i] * k + signal_line[i - 1] * (1 - k)
            elif not math.isnan(signal_line[i - 1]):
                signal_line[i] = signal_line[i - 1]

        for i in range(n):
            if not (math.isnan(macd_line[i]) or math.isnan(signal_line[i])):
                hist[i] = macd_line[i] - signal_line[i]

    return macd_line, signal_line, hist


def compute_bollinger_bands(
    closes: List[float], window: int = 20, num_std: int = 2
) -> Tuple[List[float], List[float], List[float], List[float]]:
    """Upper, middle, lower bands, and bandwidth percentage. NaN-padded."""
    n = len(closes)
    upper = [float("nan")] * n
    middle = [float("nan")] * n
    lower = [float("nan")] * n
    bw_pct = [float("nan")] * n

    if n < window:
        return upper, middle, lower, bw_pct

    for i in range(window - 1, n):
        seg = closes[i - window + 1: i + 1]
        mean = sum(seg) / window
        var = sum((x - mean) ** 2 for x in seg) / window
        std = math.sqrt(var)
        middle[i] = mean
        upper[i] = mean + num_std * std
        lower[i] = mean - num_std * std
        bw_pct[i] = (num_std * 2 * std / mean * 100) if mean > 0 else 0.0

    return upper, middle, lower, bw_pct


def compute_kdj(
    highs: List[float], lows: List[float], closes: List[float], n: int = 9
) -> Tuple[List[float], List[float], List[float]]:
    """KDJ indicator. Returns K, D, J lists. NaN-padded."""
    length = len(closes)
    k_out = [float("nan")] * length
    d_out = [float("nan")] * length
    j_out = [float("nan")] * length

    if length < n:
        return k_out, d_out, j_out

    k_val = 50.0
    d_val = 50.0

    for i in range(n - 1, length):
        highest = max(highs[i - n + 1: i + 1])
        lowest = min(lows[i - n + 1: i + 1])
        denom = highest - lowest
        rsv = ((closes[i] - lowest) / denom * 100) if denom > 0 else 50.0
        k_val = 2.0 / 3.0 * k_val + 1.0 / 3.0 * rsv
        d_val = 2.0 / 3.0 * d_val + 1.0 / 3.0 * k_val
        j_val = 3.0 * k_val - 2.0 * d_val
        k_out[i] = k_val
        d_out[i] = d_val
        j_out[i] = j_val

    return k_out, d_out, j_out


def compute_obv_trend(
    closes: List[float], volumes: List[float], window: int = 10
) -> List[float]:
    """OBV trend direction. Returns list of slopes (positive = accumulation). NaN-padded."""
    n = min(len(closes), len(volumes))
    trend = [float("nan")] * len(closes)
    if n < window + 1:
        return trend

    # Build OBV series
    obv = [0.0] * n
    for i in range(1, n):
        if closes[i] > closes[i - 1]:
            obv[i] = obv[i - 1] + volumes[i]
        elif closes[i] < closes[i - 1]:
            obv[i] = obv[i - 1] - volumes[i]
        else:
            obv[i] = obv[i - 1]

    # Slope of OBV over window (linear regression slope, normalized)
    for i in range(window, n):
        seg = obv[i - window + 1: i + 1]
        mean_y = sum(seg) / window
        mean_x = (window - 1) / 2.0
        ss_xy = 0.0
        ss_xx = 0.0
        for j, y in enumerate(seg):
            dx = j - mean_x
            ss_xy += dx * (y - mean_y)
            ss_xx += dx * dx
        slope = ss_xy / ss_xx if ss_xx > 0 else 0.0
        # Normalize by avg volume to get comparable values
        avg_vol = sum(volumes[i - window + 1: i + 1]) / window
        trend[i] = slope / avg_vol if avg_vol > 0 else 0.0

    return trend


def compute_ma_alignment(closes: List[float]) -> List[float]:
    """MA5/10/20/60 alignment state. 1=bullish, -1=bearish, 0=mixed. NaN-padded."""
    n = len(closes)
    result = [float("nan")] * n
    if n < 60:
        return result

    # Pre-compute running sums for efficiency
    ma5 = [float("nan")] * n
    ma10 = [float("nan")] * n
    ma20 = [float("nan")] * n
    ma60 = [float("nan")] * n

    cumsum = [0.0] * (n + 1)
    for i in range(n):
        cumsum[i + 1] = cumsum[i] + closes[i]

    for period, arr in [(5, ma5), (10, ma10), (20, ma20), (60, ma60)]:
        for i in range(period - 1, n):
            arr[i] = (cumsum[i + 1] - cumsum[i - period + 1]) / period

    for i in range(59, n):
        m5, m10, m20, m60_v = ma5[i], ma10[i], ma20[i], ma60[i]
        if m5 > m10 > m20 > m60_v:
            result[i] = 1.0   # bullish alignment
        elif m5 < m10 < m20 < m60_v:
            result[i] = -1.0  # bearish alignment
        else:
            result[i] = 0.0

    return result


def compute_candle_patterns(
    opens: List[float],
    highs: List[float],
    lows: List[float],
    closes: List[float],
    idx: int,
) -> float:
    """Candle pattern detection at idx. Returns score in [-1, +1].

    Detects: hammer, inverted hammer, doji, engulfing, three soldiers/crows.
    Positive = bullish, negative = bearish.
    """
    if idx < 2 or idx >= len(closes):
        return 0.0

    o, h, lo, c = opens[idx], highs[idx], lows[idx], closes[idx]
    body = abs(c - o)
    full_range = h - lo
    if full_range <= 0:
        return 0.0

    body_ratio = body / full_range
    upper_shadow = h - max(o, c)
    lower_shadow = min(o, c) - lo

    score = 0.0

    # Hammer (bullish): small body at top, long lower shadow
    if lower_shadow > body * 2 and upper_shadow < body * 0.5 and c > o:
        score += 0.3

    # Inverted hammer (potential reversal)
    if upper_shadow > body * 2 and lower_shadow < body * 0.5 and c > o:
        score += 0.15

    # Doji at bottom (indecision after decline)
    if body_ratio < 0.1 and idx >= 3:
        # Check if we were declining
        recent_decline = closes[idx - 3] > closes[idx - 1] * 1.02
        if recent_decline:
            score += 0.2

    # Bullish engulfing
    prev_o, prev_c = opens[idx - 1], closes[idx - 1]
    if prev_c < prev_o and c > o:  # prev bearish, current bullish
        if c > prev_o and o < prev_c:  # current body engulfs prev
            score += 0.35

    # Bearish engulfing
    if prev_c > prev_o and c < o:  # prev bullish, current bearish
        if c < prev_o and o > prev_c:
            score -= 0.35

    # Three white soldiers
    if idx >= 3:
        all_bullish = all(closes[idx - j] > opens[idx - j] for j in range(3))
        ascending = closes[idx] > closes[idx - 1] > closes[idx - 2]
        if all_bullish and ascending:
            score += 0.3

    # Three black crows
    if idx >= 3:
        all_bearish = all(closes[idx - j] < opens[idx - j] for j in range(3))
        descending = closes[idx] < closes[idx - 1] < closes[idx - 2]
        if all_bearish and descending:
            score -= 0.3

    return max(-1.0, min(1.0, score))


def compute_volume_profile(
    volumes: List[float], idx: int, window: int = 20
) -> float:
    """Volume profile at idx. Returns: 1=surge, -1=shrink, 0=normal."""
    if idx < window or idx >= len(volumes):
        return 0.0

    avg_vol = sum(volumes[idx - window: idx]) / window
    if avg_vol <= 0:
        return 0.0

    ratio = volumes[idx] / avg_vol
    if ratio > 2.0:
        return 1.0   # volume surge
    elif ratio < 0.5:
        return -1.0  # volume shrink
    elif ratio > 1.3:
        return 0.5
    elif ratio < 0.7:
        return -0.5
    return 0.0


def compute_support_resistance(
    closes: List[float],
    highs: List[float],
    lows: List[float],
    idx: int,
    window: int = 20,
) -> float:
    """Distance from support level as a percentage (0-1 score).

    Closer to support = higher score (more upside potential).
    """
    if idx < window or idx >= len(closes):
        return 0.5

    lookback_lows = lows[idx - window: idx]
    lookback_highs = highs[idx - window: idx]

    support = min(lookback_lows)
    resistance = max(lookback_highs)

    price = closes[idx]
    price_range = resistance - support
    if price_range <= 0:
        return 0.5

    # Position in range: 0 = at support (bullish), 1 = at resistance (bearish)
    position = (price - support) / price_range
    # Invert: closer to support = higher score
    return max(0.0, min(1.0, 1.0 - position))


# ────────────────── Scoring ──────────────────

# ────────────────── Extended Technical Indicators ──────────────────


def compute_atr(
    highs: List[float], lows: List[float], closes: List[float], period: int = 14
) -> List[float]:
    """Average True Range. Returns ATR as % of close. NaN-padded."""
    n = len(closes)
    atr = [float("nan")] * n
    if n < period + 1:
        return atr
    trs: List[float] = [0.0]
    for i in range(1, n):
        tr = max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i - 1]),
            abs(lows[i] - closes[i - 1]),
        )
        trs.append(tr)
    # Seed ATR with SMA
    avg_tr = sum(trs[1:period + 1]) / period
    atr[period] = avg_tr / closes[period] * 100 if closes[period] > 0 else 0.0
    for i in range(period + 1, n):
        avg_tr = (avg_tr * (period - 1) + trs[i]) / period
        atr[i] = avg_tr / closes[i] * 100 if closes[i] > 0 else 0.0
    return atr


def compute_roc(closes: List[float], period: int = 10) -> List[float]:
    """Rate of Change: (close - close[n]) / close[n] * 100. NaN-padded."""
    n = len(closes)
    roc = [float("nan")] * n
    for i in range(period, n):
        if closes[i - period] > 0:
            roc[i] = (closes[i] - closes[i - period]) / closes[i - period] * 100
    return roc


def compute_williams_r(
    highs: List[float], lows: List[float], closes: List[float], period: int = 14
) -> List[float]:
    """Williams %R. Returns values in [-100, 0]. NaN-padded."""
    n = len(closes)
    wr = [float("nan")] * n
    if n < period:
        return wr
    for i in range(period - 1, n):
        hh = max(highs[i - period + 1:i + 1])
        ll = min(lows[i - period + 1:i + 1])
        if hh - ll > 0:
            wr[i] = (hh - closes[i]) / (hh - ll) * -100
        else:
            wr[i] = -50.0
    return wr


def compute_cci(closes: List[float], highs: List[float], lows: List[float], period: int = 20) -> List[float]:
    """Commodity Channel Index. NaN-padded."""
    n = len(closes)
    cci = [float("nan")] * n
    if n < period:
        return cci
    for i in range(period - 1, n):
        tp_list = [(highs[j] + lows[j] + closes[j]) / 3 for j in range(i - period + 1, i + 1)]
        tp_mean = sum(tp_list) / period
        md = sum(abs(tp - tp_mean) for tp in tp_list) / period
        if md > 0:
            cci[i] = (tp_list[-1] - tp_mean) / (0.015 * md)
        else:
            cci[i] = 0.0
    return cci


def compute_mfi(
    highs: List[float], lows: List[float], closes: List[float],
    volumes: List[float], period: int = 14,
) -> List[float]:
    """Money Flow Index (volume-weighted RSI). Returns [0, 100]. NaN-padded."""
    n = min(len(closes), len(volumes))
    mfi = [float("nan")] * len(closes)
    if n < period + 1:
        return mfi
    tp = [(highs[i] + lows[i] + closes[i]) / 3 for i in range(n)]
    for i in range(period, n):
        pos_flow = 0.0
        neg_flow = 0.0
        for j in range(i - period + 1, i + 1):
            mf = tp[j] * volumes[j]
            if tp[j] > tp[j - 1]:
                pos_flow += mf
            elif tp[j] < tp[j - 1]:
                neg_flow += mf
        if neg_flow > 0:
            mr = pos_flow / neg_flow
            mfi[i] = 100 - 100 / (1 + mr)
        else:
            mfi[i] = 100.0
    return mfi


def compute_donchian_position(
    highs: List[float], lows: List[float], closes: List[float], period: int = 20
) -> List[float]:
    """Price position within Donchian channel [0=at low, 1=at high]. NaN-padded."""
    n = len(closes)
    pos = [float("nan")] * n
    if n < period:
        return pos
    for i in range(period - 1, n):
        hh = max(highs[i - period + 1:i + 1])
        ll = min(lows[i - period + 1:i + 1])
        rng = hh - ll
        if rng > 0:
            pos[i] = (closes[i] - ll) / rng
        else:
            pos[i] = 0.5
    return pos


def compute_aroon(closes: List[float], period: int = 25) -> List[float]:
    """Aroon oscillator: (days_since_high - days_since_low) / period. Returns [-1, 1]. NaN-padded."""
    n = len(closes)
    aroon = [float("nan")] * n
    if n < period:
        return aroon
    for i in range(period - 1, n):
        seg = closes[i - period + 1:i + 1]
        hi_idx = seg.index(max(seg))
        lo_idx = seg.index(min(seg))
        aroon_up = hi_idx / (period - 1) if period > 1 else 0.5
        aroon_down = lo_idx / (period - 1) if period > 1 else 0.5
        aroon[i] = aroon_up - aroon_down  # [-1, 1]
    return aroon


def compute_price_volume_corr(
    closes: List[float], volumes: List[float], window: int = 20
) -> List[float]:
    """Rolling Pearson correlation between price and volume. Returns [-1, 1]. NaN-padded."""
    n = min(len(closes), len(volumes))
    corr = [float("nan")] * len(closes)
    if n < window:
        return corr
    for i in range(window - 1, n):
        p = closes[i - window + 1:i + 1]
        v = volumes[i - window + 1:i + 1]
        mp = sum(p) / window
        mv = sum(v) / window
        cov = sum((p[j] - mp) * (v[j] - mv) for j in range(window)) / window
        sp = math.sqrt(sum((p[j] - mp) ** 2 for j in range(window)) / window)
        sv = math.sqrt(sum((v[j] - mv) ** 2 for j in range(window)) / window)
        if sp > 0 and sv > 0:
            corr[i] = max(-1.0, min(1.0, cov / (sp * sv)))
        else:
            corr[i] = 0.0
    return corr


