"""
Multi-Objective Pareto Evolution (NSGA-III)
============================================
Extends stratevo's evolution engine with multi-objective optimization,
letting users explore the Pareto front of strategies trading off:

  1. Annualized return (maximize)
  2. Maximum drawdown (minimize)
  3. Turnover rate (minimize)
  4. Strategy complexity / factor count (minimize, optional)

Uses pymoo's NSGA-III implementation (Deb & Jain, IEEE TEVC 2014).

Usage:
  stratevo evolve --pareto                  # enable multi-objective mode
  stratevo pareto-front                     # view current Pareto front

References:
  - pymoo.org
  - K. Deb and H. Jain, "An Evolutionary Many-Objective Optimization
    Algorithm Using Reference-Point-Based Nondominated Sorting Approach,"
    IEEE TEVC, vol. 18, no. 4, 2014.
"""

from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

import numpy as np

from stratevo.evolution.auto_evolve import (
    AutoEvolver,
    EvolutionResult,
    StrategyDNA,
    _PARAM_RANGES,
    _WEIGHT_KEYS,
)


# ────────────────── Objective Definitions ──────────────────


@dataclass
class ParetoObjective:
    """Single objective in the multi-objective optimization."""

    name: str
    direction: str  # "maximize" or "minimize"
    description: str = ""


# Default objectives (pymoo minimizes, so we negate maximize objectives)
DEFAULT_OBJECTIVES: List[ParetoObjective] = [
    ParetoObjective("annual_return", "maximize", "Annualized return (%)"),
    ParetoObjective("max_drawdown", "minimize", "Maximum drawdown (%)"),
    ParetoObjective("turnover", "minimize", "Average portfolio turnover ratio"),
]

OPTIONAL_OBJECTIVES: List[ParetoObjective] = [
    ParetoObjective(
        "complexity",
        "minimize",
        "Strategy complexity (number of active factors, penalizes overfitting)",
    ),
]


# ────────────────── Pareto Front Entry ──────────────────


@dataclass
class ParetoFrontEntry:
    """A single strategy on the Pareto front."""

    dna: Dict[str, Any]
    objectives: Dict[str, float]
    metrics: Dict[str, float]
    generation: int = 0
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "dna": self.dna,
            "objectives": self.objectives,
            "metrics": self.metrics,
            "generation": self.generation,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "ParetoFrontEntry":
        return cls(**d)


# ────────────────── Pareto Front Storage ──────────────────


class ParetoFrontStore:
    """Persist and load the Pareto front to/from JSON and CSV."""

    def __init__(self, results_dir: str = "evolution_results"):
        self.results_dir = results_dir
        self.pareto_dir = os.path.join(results_dir, "pareto")
        os.makedirs(self.pareto_dir, exist_ok=True)

    def save(
        self,
        entries: List[ParetoFrontEntry],
        generation: int = 0,
    ) -> Tuple[str, str]:
        """Save Pareto front to JSON and CSV. Returns (json_path, csv_path)."""
        ts = time.strftime("%Y-%m-%dT%H:%M:%S")

        # JSON
        json_path = os.path.join(self.pareto_dir, "pareto_front.json")
        payload = {
            "generation": generation,
            "timestamp": ts,
            "num_strategies": len(entries),
            "entries": [e.to_dict() for e in entries],
        }
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)

        # Versioned JSON
        versioned_json = os.path.join(
            self.pareto_dir, f"pareto_gen_{generation:04d}.json"
        )
        with open(versioned_json, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)

        # CSV
        csv_path = os.path.join(self.pareto_dir, "pareto_front.csv")
        if entries:
            obj_keys = sorted(entries[0].objectives.keys())
            metric_keys = sorted(entries[0].metrics.keys())
            fieldnames = (
                ["generation", "timestamp"] + obj_keys + metric_keys
            )

            with open(csv_path, "w", newline="", encoding="utf-8") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                for e in entries:
                    row: Dict[str, Any] = {
                        "generation": e.generation,
                        "timestamp": e.timestamp or ts,
                    }
                    row.update(e.objectives)
                    row.update(e.metrics)
                    writer.writerow(row)

        return json_path, csv_path

    def load(self) -> List[ParetoFrontEntry]:
        """Load the latest Pareto front from JSON."""
        json_path = os.path.join(self.pareto_dir, "pareto_front.json")
        if not os.path.exists(json_path):
            return []
        try:
            with open(json_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return [ParetoFrontEntry.from_dict(e) for e in data.get("entries", [])]
        except Exception:
            return []


# ────────────────── Multi-Objective Evaluation ──────────────────


def compute_multi_objectives(
    result: EvolutionResult,
    avg_turnover: float = 0.0,
    active_factor_count: int = 0,
    include_complexity: bool = False,
) -> Dict[str, float]:
    """Extract objective values from an EvolutionResult.

    Returns a dict of objective-name -> value.
    pymoo minimizes, so we negate annual_return (which we want to maximize).
    """
    objectives = {
        "annual_return": result.annual_return,    # to maximize
        "max_drawdown": result.max_drawdown,      # to minimize (already positive %)
        "turnover": avg_turnover,                  # to minimize
    }
    if include_complexity:
        objectives["complexity"] = float(active_factor_count)
    return objectives


def count_active_factors(dna: StrategyDNA, threshold: float = 0.001) -> int:
    """Count the number of active factors (weight > threshold) in DNA."""
    count = 0
    for key in _WEIGHT_KEYS:
        w = getattr(dna, key, 0.0)
        if w >= threshold:
            count += 1
    if hasattr(dna, "custom_weights") and dna.custom_weights:
        count += sum(1 for w in dna.custom_weights.values() if w >= threshold)
    return count


# ────────────────── pymoo Problem Definition ──────────────────

try:
    # pymoo's Cython extensions may fail to load on some platforms (Windows
    # DLL issues, missing compiler). Force pure-Python mode first to be safe.
    from pymoo.functions import FunctionLoader as _FL
    _FL.get_instance().is_compiled = False

    from pymoo.core.problem import ElementwiseProblem
    from pymoo.algorithms.moo.nsga3 import NSGA3
    from pymoo.optimize import minimize as pymoo_minimize
    from pymoo.util.ref_dirs import get_reference_directions
    from pymoo.operators.crossover.sbx import SBX
    from pymoo.operators.mutation.pm import PM
    from pymoo.operators.sampling.rnd import FloatRandomSampling
    from pymoo.termination import get_termination
    from pymoo.core.callback import Callback

    PYMOO_AVAILABLE = True
except ImportError:
    PYMOO_AVAILABLE = False
    _PYMOO_INSTALL_MSG = (
        "pymoo is required for multi-objective Pareto evolution (NSGA-III) "
        "but is not installed. Install it with:\n"
        "  pip install stratevo[pareto]\n"
        "or for all optional dependencies:\n"
        "  pip install stratevo[full]"
    )


def _dna_to_vector(dna: StrategyDNA) -> np.ndarray:
    """Flatten StrategyDNA into a numpy vector for pymoo."""
    values = []
    for param in sorted(_PARAM_RANGES.keys()):
        values.append(float(getattr(dna, param, _PARAM_RANGES[param][0])))
    return np.array(values, dtype=np.float64)


def _vector_to_dna(x: np.ndarray) -> StrategyDNA:
    """Convert numpy vector back to StrategyDNA."""
    d = {}
    for i, param in enumerate(sorted(_PARAM_RANGES.keys())):
        lo, hi, is_int = _PARAM_RANGES[param]
        val = float(x[i])
        val = max(lo, min(hi, val))
        if is_int:
            val = int(round(val))
        d[param] = val
    # Normalize weights to sum ≈ 1.0
    w_sum = sum(d.get(k, 0.0) for k in _WEIGHT_KEYS)
    if w_sum > 0:
        for k in _WEIGHT_KEYS:
            d[k] = round(d.get(k, 0.0) / w_sum, 4)
    return StrategyDNA.from_dict(d)


def _get_bounds() -> Tuple[np.ndarray, np.ndarray]:
    """Get lower and upper bounds for all parameters."""
    lower = []
    upper = []
    for param in sorted(_PARAM_RANGES.keys()):
        lo, hi, _ = _PARAM_RANGES[param]
        lower.append(lo)
        upper.append(hi)
    return np.array(lower), np.array(upper)


if PYMOO_AVAILABLE:

    class _StrategyProblem(ElementwiseProblem):
        """pymoo problem wrapper for strategy evolution."""

        def __init__(
            self,
            evolver: AutoEvolver,
            data: Dict[str, Dict[str, list]],
            include_complexity: bool = False,
            gen_seed: int = 0,
            **kwargs,
        ):
            self.evolver = evolver
            self.data = data
            self.include_complexity = include_complexity
            self.gen_seed = gen_seed

            n_obj = 4 if include_complexity else 3
            xl, xu = _get_bounds()
            n_var = len(xl)

            super().__init__(
                n_var=n_var,
                n_obj=n_obj,
                xl=xl,
                xu=xu,
                **kwargs,
            )

        def _evaluate(self, x, out, *args, **kwargs):
            dna = _vector_to_dna(x)
            result = self.evolver.evaluate(
                dna, self.data, gen_seed=self.gen_seed
            )
            active_count = count_active_factors(dna)

            # pymoo MINIMIZES all objectives by default.
            # Negate annual_return (we want to maximize it).
            # max_drawdown and turnover are already "lower is better".
            f = [
                -result.annual_return,   # negate: maximize return
                result.max_drawdown,     # minimize drawdown
                0.0,                     # placeholder for turnover
            ]

            if self.include_complexity:
                f.append(float(active_count))

            out["F"] = np.array(f)

    class _ParetoCallback(Callback):
        """Callback to print progress during NSGA-III optimization."""

        def __init__(self, verbose: bool = True):
            super().__init__()
            self.verbose = verbose

        def notify(self, algorithm):
            if not self.verbose:
                return
            gen = algorithm.n_gen
            F = algorithm.pop.get("F")
            if F is not None and len(F) > 0:
                best_return = -F[:, 0].min()  # un-negate
                best_dd = F[:, 1].min()
                n_pareto = len(algorithm.opt) if algorithm.opt is not None else 0
                print(
                    f"  NSGA-III Gen {gen:4d} | "
                    f"best_return={best_return:7.2f}% | "
                    f"best_dd={best_dd:5.2f}% | "
                    f"pareto_size={n_pareto}"
                )


# ────────────────── Pareto Evolver (Adapter) ──────────────────


class ParetoEvolver:
    """Multi-objective evolution adapter that wraps AutoEvolver.

    Replaces single-fitness selection with NSGA-III Pareto optimization.
    The existing AutoEvolver handles data loading, indicator computation,
    and backtest evaluation. ParetoEvolver provides the multi-objective
    selection layer on top.
    """

    def __init__(
        self,
        evolver: AutoEvolver,
        include_complexity: bool = False,
        population_size: int = 30,
        results_dir: str = "evolution_results",
    ):
        if not PYMOO_AVAILABLE:
            raise ImportError(_PYMOO_INSTALL_MSG)

        self.evolver = evolver
        self.include_complexity = include_complexity
        self.population_size = population_size
        self.store = ParetoFrontStore(results_dir)
        self.results_dir = results_dir
        self._objectives = list(DEFAULT_OBJECTIVES)
        if include_complexity:
            self._objectives.extend(OPTIONAL_OBJECTIVES)

    @property
    def objective_names(self) -> List[str]:
        return [o.name for o in self._objectives]

    def evolve(
        self,
        generations: int = 100,
        save_interval: int = 10,
        verbose: bool = True,
    ) -> List[ParetoFrontEntry]:
        """Run NSGA-III multi-objective evolution.

        Returns the final Pareto front as a list of ParetoFrontEntry.
        """
        print("=" * 60)
        print(" StratEvo Multi-Objective Pareto Evolution (NSGA-III)")
        print("=" * 60)

        t0 = time.time()
        print("Loading market data...", flush=True)
        data = self.evolver.load_data()
        elapsed = time.time() - t0
        print(f"Loaded {len(data)} stocks in {elapsed:.1f}s")

        if not data:
            print("ERROR: No data loaded. Check data_dir path.")
            return []

        n_obj = len(self._objectives)
        print(f"Objectives ({n_obj}):")
        for obj in self._objectives:
            print(f"  - {obj.name} ({obj.direction}): {obj.description}")

        # Set up NSGA-III
        ref_dirs = get_reference_directions("das-dennis", n_obj, n_partitions=12)

        algorithm = NSGA3(
            ref_dirs=ref_dirs,
            pop_size=self.population_size,
            sampling=FloatRandomSampling(),
            crossover=SBX(prob=0.9, eta=15),
            mutation=PM(eta=20),
        )

        problem = _StrategyProblem(
            evolver=self.evolver,
            data=data,
            include_complexity=self.include_complexity,
        )

        termination = get_termination("n_gen", generations)
        callback = _ParetoCallback(verbose=verbose)

        print(f"\nPopulation: {self.population_size} | Generations: {generations}")
        print("-" * 60)

        result = pymoo_minimize(
            problem,
            algorithm,
            termination,
            callback=callback,
            verbose=False,
        )

        # Extract Pareto front
        pareto_entries = self._extract_pareto_front(result, generation=generations)

        # Save
        json_path, csv_path = self.store.save(pareto_entries, generation=generations)

        total_time = time.time() - t0
        print("-" * 60)
        print(f"Evolution complete! {generations} generations in {total_time:.1f}s")
        print(f"Pareto front size: {len(pareto_entries)} strategies")
        print(f"Saved to: {json_path}")
        print(f"CSV:      {csv_path}")
        print("=" * 60)

        return pareto_entries

    def _extract_pareto_front(
        self, result, generation: int = 0
    ) -> List[ParetoFrontEntry]:
        """Convert pymoo result to ParetoFrontEntry list."""
        entries = []
        ts = time.strftime("%Y-%m-%dT%H:%M:%S")

        if result.opt is None or len(result.opt) == 0:
            return entries

        F = result.opt.get("F")  # objective values
        X = result.opt.get("X")  # decision variables

        if F is None or X is None:
            return entries

        for i in range(len(F)):
            dna = _vector_to_dna(X[i])
            objectives = {
                "annual_return": float(-F[i][0]),  # un-negate
                "max_drawdown": float(F[i][1]),
                "turnover": float(F[i][2]),
            }
            if self.include_complexity and F.shape[1] > 3:
                objectives["complexity"] = float(F[i][3])

            active = count_active_factors(dna)
            metrics = {
                "active_factors": active,
                "total_factors": len(_WEIGHT_KEYS)
                + len(getattr(dna, "custom_weights", {})),
            }

            entries.append(
                ParetoFrontEntry(
                    dna=dna.to_dict(),
                    objectives=objectives,
                    metrics=metrics,
                    generation=generation,
                    timestamp=ts,
                )
            )

        # Sort by annual_return descending (best return first)
        entries.sort(key=lambda e: e.objectives.get("annual_return", 0), reverse=True)
        return entries


# ────────────────── Pareto Dominance Utilities ──────────────────


def dominates(a: Dict[str, float], b: Dict[str, float], directions: Dict[str, str]) -> bool:
    """Return True if solution `a` Pareto-dominates solution `b`.

    For each objective:
      - "maximize": a[key] >= b[key] (and at least one strictly better)
      - "minimize": a[key] <= b[key] (and at least one strictly better)
    """
    at_least_one_better = False
    for key, direction in directions.items():
        av = a.get(key, 0.0)
        bv = b.get(key, 0.0)
        if direction == "maximize":
            if av < bv:
                return False
            if av > bv:
                at_least_one_better = True
        else:  # minimize
            if av > bv:
                return False
            if av < bv:
                at_least_one_better = True
    return at_least_one_better


def compute_pareto_front(
    solutions: List[Dict[str, float]],
    directions: Dict[str, str],
) -> List[int]:
    """Return indices of non-dominated solutions (Pareto front).

    Args:
        solutions: List of objective dicts.
        directions: Dict mapping objective name -> "maximize" or "minimize".

    Returns:
        List of indices into `solutions` that are on the Pareto front.
    """
    n = len(solutions)
    is_dominated = [False] * n

    for i in range(n):
        if is_dominated[i]:
            continue
        for j in range(n):
            if i == j or is_dominated[j]:
                continue
            if dominates(solutions[j], solutions[i], directions):
                is_dominated[i] = True
                break

    return [i for i in range(n) if not is_dominated[i]]


def crowding_distance(
    solutions: List[Dict[str, float]],
    front_indices: List[int],
    objectives: List[str],
) -> List[float]:
    """Compute crowding distance for solutions on the Pareto front.

    Returns distance values for each index in front_indices.
    Larger distance = more isolated = more diversity-preserving.
    """
    n = len(front_indices)
    if n <= 2:
        return [float("inf")] * n

    distances = [0.0] * n

    for obj in objectives:
        # Sort front by this objective
        vals = [(solutions[front_indices[i]].get(obj, 0.0), i) for i in range(n)]
        vals.sort(key=lambda x: x[0])

        # Boundary points get infinite distance
        distances[vals[0][1]] = float("inf")
        distances[vals[-1][1]] = float("inf")

        obj_range = vals[-1][0] - vals[0][0]
        if obj_range == 0:
            continue

        for k in range(1, n - 1):
            distances[vals[k][1]] += (vals[k + 1][0] - vals[k - 1][0]) / obj_range

    return distances


# ────────────────── CLI Helper: Display Pareto Front ──────────────────


def display_pareto_front(
    entries: List[ParetoFrontEntry],
    top_n: int = 20,
) -> str:
    """Format Pareto front for CLI display."""
    if not entries:
        return "  No Pareto front found. Run: stratevo evolve --pareto\n"

    lines = []
    lines.append("=" * 70)
    lines.append(" Pareto Front — Multi-Objective Strategy Optimization")
    lines.append("=" * 70)
    lines.append(
        f"  {'#':<4} {'Return%':>10} {'MaxDD%':>10} {'Turnover':>10} "
        f"{'Factors':>8} {'Gen':>5}"
    )
    lines.append("  " + "─" * 60)

    for i, e in enumerate(entries[:top_n], 1):
        ret = e.objectives.get("annual_return", 0)
        dd = e.objectives.get("max_drawdown", 0)
        to = e.objectives.get("turnover", 0)
        comp = e.objectives.get("complexity", e.metrics.get("active_factors", 0))
        gen = e.generation
        lines.append(
            f"  {i:<4} {ret:>+9.2f}% {dd:>9.2f}% {to:>10.4f} {int(comp):>8} {gen:>5}"
        )

    if len(entries) > top_n:
        lines.append(f"\n  ... and {len(entries) - top_n} more strategies on the front")

    lines.append("=" * 70)
    return "\n".join(lines)
