"""
Factor Discovery Engine — LLM-guided factor creation for the evolution engine.

Architecture:
  1. Each "factor" is a small Python function: (closes, highs, lows, volumes, idx) -> float [0, 1]
  2. Factors are stored as .py files in factors/ directory
  3. The evolution engine loads all factors dynamically
  4. LLM proposes new factors based on performance feedback
  5. New factors get added to the weight vector and evolved

This module handles:
  - Dynamic factor loading
  - Factor validation (must be safe, deterministic, fast)
  - Factor performance tracking
  - LLM-based factor proposal (via prompt templates)
"""

from __future__ import annotations

import math
import importlib.util
from pathlib import Path
from typing import Dict, List, Callable, Optional
from dataclasses import dataclass

import numpy as np


# ============================================================
# Factor Registry
# ============================================================

@dataclass
class FactorMeta:
    """Metadata for a registered factor."""
    name: str
    description: str
    source_file: str
    compute_fn: Callable  # (closes, highs, lows, volumes, idx) -> float [0,1]
    category: str = "custom"  # technical, fundamental, sentiment, custom
    version: int = 1
    avg_score: float = 0.0  # tracking
    times_selected: int = 0  # how often evolution gave it non-zero weight


class FactorRegistry:
    """Dynamic factor registry — loads factors from directory."""

    def __init__(self, factors_dir: str = "factors"):
        self.factors_dir = Path(factors_dir)
        self.factors: Dict[str, FactorMeta] = {}
        self._builtin_loaded = False

    def load_all(self, market: str | None = None) -> int:
        """Load factor files from factors/ directory.
        
        Each .py file should define:
          - FACTOR_NAME: str
          - FACTOR_DESC: str  
          - FACTOR_CATEGORY: str (optional, default 'custom')
          - compute(closes, highs, lows, volumes, idx) -> float
        
        Args:
            market: If set, controls which subdirectories to load.
                    'crypto' → root factors + factors/crypto/
                    'cn'/'us' → root factors only (skip crypto/)
                    None → load everything (backward compatible)
        
        Returns number of factors loaded.
        """
        if not self.factors_dir.exists():
            self.factors_dir.mkdir(parents=True, exist_ok=True)
            return 0

        count = 0
        # Load factors from root directory and market-specific subdirectories
        for fp in sorted(self.factors_dir.rglob("*.py")):
            if fp.name.startswith("_"):
                continue

            # Market-aware filtering: skip irrelevant subdirectory factors
            if market is not None:
                rel = fp.relative_to(self.factors_dir)
                parts = rel.parts
                if len(parts) > 1:
                    # Factor is in a subdirectory — check if it matches market
                    subdir = parts[0].lower()
                    if subdir == "__pycache__":
                        continue
                    if market == "crypto" and subdir != "crypto":
                        continue
                    if market in ("cn", "us") and subdir == "crypto":
                        continue

            try:
                factor = self._load_factor_file(fp)
                if factor:
                    self.factors[factor.name] = factor
                    count += 1
            except Exception as e:
                self._load_failures = getattr(self, '_load_failures', 0) + 1

        return count

    def _load_factor_file(self, path: Path) -> Optional[FactorMeta]:
        """Load a single factor from a .py file."""
        spec = importlib.util.spec_from_file_location(path.stem, path)
        if not spec or not spec.loader:
            return None

        module = importlib.util.module_from_spec(spec)
        
        # Provide safe builtins
        _allowed_imports = {'math': math}
        _original_import = __builtins__.__import__ if hasattr(__builtins__, '__import__') else __import__
        def _safe_import(name, *args, **kwargs):
            if name in _allowed_imports:
                return _allowed_imports[name]
            # Allow os, sys, and stratevo.* for DRL factor integration
            if name in ('os', 'sys') or name.startswith('stratevo'):
                return _original_import(name, *args, **kwargs)
            raise ImportError(f"Import of '{name}' is not allowed in factor files")

        module.__builtins__ = {
            '__import__': _safe_import,
            'math': math,
            'abs': abs, 'min': min, 'max': max, 'sum': sum,
            'len': len, 'range': range, 'enumerate': enumerate,
            'float': float, 'int': int, 'bool': bool,
            'zip': zip, 'map': map, 'filter': filter,
            'sorted': sorted, 'reversed': reversed,
            'round': round, 'pow': pow,
            'True': True, 'False': False, 'None': None,
            'isinstance': isinstance, 'type': type,
            'list': list, 'tuple': tuple, 'dict': dict,
            'ValueError': ValueError, 'TypeError': TypeError,
            'ZeroDivisionError': ZeroDivisionError,
            'IndexError': IndexError, 'ImportError': ImportError,
            'hasattr': hasattr, 'getattr': getattr, 'setattr': setattr,
            'str': str, 'bytes': bytes, 'set': set, 'frozenset': frozenset,
            'property': property, 'staticmethod': staticmethod,
            'classmethod': classmethod, 'super': super, 'object': object,
            'Exception': Exception, 'AttributeError': AttributeError,
            'KeyError': KeyError, 'RuntimeError': RuntimeError,
            # NOTE: __import__ intentionally excluded — factor files must not
            # import arbitrary modules.  Only math builtins are available.
            'print': print,
        }

        spec.loader.exec_module(module)

        name = getattr(module, 'FACTOR_NAME', path.stem)
        desc = getattr(module, 'FACTOR_DESC', 'No description')
        category = getattr(module, 'FACTOR_CATEGORY', 'custom')
        compute_fn = getattr(module, 'compute', None)

        if compute_fn is None:
            return None

        # Validate: must return float in [0, 1] for a simple test
        try:
            test_closes = [10.0 + i * 0.1 for i in range(100)]
            test_highs = [c + 0.5 for c in test_closes]
            test_lows = [c - 0.5 for c in test_closes]
            test_vols = [1000000.0] * 100
            result = compute_fn(test_closes, test_highs, test_lows, test_vols, 99)
            if not isinstance(result, (int, float)):
                print(f"  [factor] {name}: compute() returned {type(result)}, expected float")
                return None
            if math.isnan(result) or math.isinf(result):
                print(f"  [factor] {name}: compute() returned {result}")
                return None
        except Exception as e:
            self._load_failures = getattr(self, '_load_failures', 0) + 1
            return None

        return FactorMeta(
            name=name,
            description=desc,
            source_file=str(path),
            compute_fn=compute_fn,
            category=category,
        )

    def compute_all(self, closes: list, highs: list, lows: list, 
                    volumes: list, idx: int) -> Dict[str, float]:
        """Compute all registered factors for a given stock at a given day.
        
        Returns dict of factor_name -> score [0, 1].
        """
        results = {}
        for name, factor in self.factors.items():
            try:
                val = factor.compute_fn(closes, highs, lows, volumes, idx)
                # Clamp to [0, 1]
                val = max(0.0, min(1.0, float(val)))
                results[name] = val
            except Exception:
                results[name] = 0.5  # neutral on error
        return results

    def list_factors(self) -> List[str]:
        """Return list of factor names."""
        return list(self.factors.keys())


# ============================================================
# LLM Factor Proposal Templates
# ============================================================

FACTOR_PROPOSAL_PROMPT = """You are a quantitative finance researcher. Your task is to invent a NEW trading factor (alpha signal) for A-share (Chinese stock market) trading.

## Current factors already in use:
{existing_factors}

## Recent evolution results:
- Best annual return: {best_return}%
- Best Sharpe: {best_sharpe}
- Current strategy style: {strategy_style}

## Performance feedback:
{performance_feedback}

## Your task:
Create ONE new factor that could improve the strategy. The factor should:
1. Be DIFFERENT from existing factors (don't just re-implement RSI or MACD)
2. Use only price, volume, high, low data (no external API calls)
3. Return a value between 0.0 (bearish) and 1.0 (bullish)
4. Be computationally fast (no loops over full history per call)
5. Have a clear financial intuition

## Output format:
Write a complete Python file with this structure:

```python
FACTOR_NAME = "your_factor_name"  # lowercase, no spaces
FACTOR_DESC = "One-line description of what this factor measures"
FACTOR_CATEGORY = "technical"  # or "momentum", "mean_reversion", "volatility", "microstructure"

def compute(closes, highs, lows, volumes, idx):
    \"\"\"
    Compute factor value at index idx.
    
    Args:
        closes: list of closing prices (full history)
        highs: list of high prices
        lows: list of low prices  
        volumes: list of volumes
        idx: current day index to compute for
        
    Returns:
        float in [0.0, 1.0] where 1.0 = most bullish
    \"\"\"
    # Your implementation here
    return 0.5
```

## Ideas to consider:
- Volume-weighted price acceleration
- Intraday range contraction/expansion patterns
- Price symmetry around moving averages
- Consecutive up/down day patterns with volume confirmation
- Gap analysis (open vs previous close)
- Relative volume at price extremes
- Volatility regime shifts
- Price-volume divergence patterns
- Order flow imbalance proxies
- Mean reversion speed indicators

Be creative! The evolution engine will determine the optimal weight for your factor.
"""

FACTOR_FILE_TEMPLATE = '''"""
Auto-generated factor: {name}
Description: {description}
Category: {category}
Generated: {timestamp}
"""

FACTOR_NAME = "{name}"
FACTOR_DESC = "{description}"
FACTOR_CATEGORY = "{category}"


def compute(closes, highs, lows, volumes, idx):
    """{description}"""
{code}
'''


# ============================================================
# Seed Factors — Good starting factors that demonstrate the pattern
# ============================================================

SEED_FACTORS = {
    "gap_momentum": {
        "desc": "Gap-up/gap-down momentum — measures if stock opened above/below previous close",
        "category": "momentum",
        "code": """
    if idx < 1:
        return 0.5
    
    # Gap = (today's open - yesterday's close) / yesterday's close
    prev_close = closes[idx - 1]
    if prev_close <= 0:
        return 0.5
    
    # We don't have opens directly, approximate from close/high/low
    # Use (high + low) / 2 as rough open proxy
    today_mid = (highs[idx] + lows[idx]) / 2.0
    gap_pct = (today_mid - prev_close) / prev_close
    
    # Normalize: -3% to +3% maps to 0.0 to 1.0
    score = (gap_pct + 0.03) / 0.06
    return max(0.0, min(1.0, score))
""",
    },
    "volume_acceleration": {
        "desc": "Volume acceleration — is volume growing faster than recently?",
        "category": "microstructure",
        "code": """
    if idx < 10:
        return 0.5
    
    # Recent 5-day average volume
    vol_5 = sum(volumes[idx-4:idx+1]) / 5.0
    # Previous 5-day average (days -10 to -5)
    vol_prev5 = sum(volumes[idx-9:idx-4]) / 5.0
    
    if vol_prev5 <= 0:
        return 0.5
    
    accel = vol_5 / vol_prev5 - 1.0
    # -50% to +100% maps to 0 to 1
    score = (accel + 0.5) / 1.5
    return max(0.0, min(1.0, score))
""",
    },
    "range_contraction": {
        "desc": "Range contraction — narrowing daily range often precedes breakout",
        "category": "volatility",
        "code": """
    if idx < 20:
        return 0.5
    
    # Average True Range ratio: recent 5 day vs 20 day
    def true_range(i):
        if i < 1:
            return highs[i] - lows[i]
        return max(
            highs[i] - lows[i],
            abs(highs[i] - closes[i-1]),
            abs(lows[i] - closes[i-1])
        )
    
    atr_5 = sum(true_range(idx - j) for j in range(5)) / 5.0
    atr_20 = sum(true_range(idx - j) for j in range(20)) / 20.0
    
    if atr_20 <= 0:
        return 0.5
    
    ratio = atr_5 / atr_20
    # Contraction (ratio < 1) is bullish (breakout coming)
    # ratio 0.3 -> score 1.0, ratio 1.5 -> score 0.0
    score = 1.0 - (ratio - 0.3) / 1.2
    return max(0.0, min(1.0, score))
""",
    },
    "smart_money_divergence": {
        "desc": "Smart money divergence — price falling but big-volume bars are buying",
        "category": "microstructure",
        "code": """
    if idx < 20:
        return 0.5
    
    # Look at last 20 days
    # Find "big volume" days (above average)
    lookback = min(20, idx)
    avg_vol = sum(volumes[idx - lookback + 1:idx + 1]) / lookback
    
    if avg_vol <= 0:
        return 0.5
    
    # On big-volume days, what's the average price change?
    big_vol_changes = []
    normal_changes = []
    for i in range(idx - lookback + 1, idx + 1):
        if i < 1:
            continue
        change = (closes[i] - closes[i-1]) / closes[i-1] if closes[i-1] > 0 else 0
        if volumes[i] > avg_vol * 1.5:
            big_vol_changes.append(change)
        else:
            normal_changes.append(change)
    
    if not big_vol_changes or not normal_changes:
        return 0.5
    
    # Divergence: big-volume-day returns vs normal-day returns
    big_avg = sum(big_vol_changes) / len(big_vol_changes)
    normal_avg = sum(normal_changes) / len(normal_changes)
    
    # If big volume days are positive but normal days negative = smart money buying
    divergence = big_avg - normal_avg
    # -2% to +2% maps to 0 to 1
    score = (divergence + 0.02) / 0.04
    return max(0.0, min(1.0, score))
""",
    },
    "price_efficiency": {
        "desc": "Price efficiency ratio — straight-line distance vs actual path, measures trend clarity",
        "category": "momentum",
        "code": """
    if idx < 10:
        return 0.5
    
    lookback = min(10, idx)
    
    # Net price change (straight line)
    net_change = abs(closes[idx] - closes[idx - lookback])
    
    # Total path length (sum of absolute daily changes)
    total_path = 0.0
    for i in range(idx - lookback + 1, idx + 1):
        total_path += abs(closes[i] - closes[i - 1])
    
    if total_path <= 0:
        return 0.5
    
    # Efficiency = net / total, ranges from 0 (choppy) to 1 (straight line)
    efficiency = net_change / total_path
    
    # Direction bonus: upward trend is bullish
    if closes[idx] > closes[idx - lookback]:
        score = 0.5 + efficiency * 0.5  # 0.5 to 1.0
    else:
        score = 0.5 - efficiency * 0.5  # 0.0 to 0.5
    
    return max(0.0, min(1.0, score))
""",
    },
    "consecutive_pattern": {
        "desc": "Consecutive up/down days with volume pattern — 3+ down days with declining volume = bullish reversal setup",
        "category": "mean_reversion",
        "code": """
    if idx < 5:
        return 0.5
    
    # Count consecutive down days
    down_days = 0
    vol_declining = True
    for i in range(idx, max(idx - 10, 0), -1):
        if i < 1:
            break
        if closes[i] < closes[i-1]:
            down_days += 1
            if i > 1 and volumes[i] > volumes[i-1]:
                vol_declining = False
        else:
            break
    
    # Count consecutive up days
    up_days = 0
    for i in range(idx, max(idx - 10, 0), -1):
        if i < 1:
            break
        if closes[i] > closes[i-1]:
            up_days += 1
        else:
            break
    
    # 3+ down days with declining volume = reversal setup (bullish)
    if down_days >= 3 and vol_declining:
        score = min(0.7 + down_days * 0.05, 1.0)
    elif down_days >= 3:
        score = 0.6
    elif up_days >= 3:
        score = 0.3  # extended up, less bullish
    else:
        score = 0.5
    
    return max(0.0, min(1.0, score))
""",
    },
}


def create_seed_factors(factors_dir: str = "factors"):
    """Create seed factor files if they don't exist."""
    path = Path(factors_dir)
    path.mkdir(parents=True, exist_ok=True)
    
    created = 0
    for name, info in SEED_FACTORS.items():
        fp = path / f"{name}.py"
        if not fp.exists():
            content = FACTOR_FILE_TEMPLATE.format(
                name=name,
                description=info["desc"],
                category=info["category"],
                timestamp="seed",
                code=info["code"],
            )
            fp.write_text(content, encoding="utf-8")
            created += 1
    
    return created


# ============================================================
# LLM Factor Discovery — Dataclasses
# ============================================================

@dataclass
class DiscoveredFactor:
    """A factor discovered/proposed by the LLM."""
    name: str
    formula: str  # Python expression using numpy + standard math on OHLCV arrays
    description: str
    rationale: str
    category: str  # momentum, volume, volatility, mean_reversion, microstructure, etc.

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "formula": self.formula,
            "description": self.description,
            "rationale": self.rationale,
            "category": self.category,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "DiscoveredFactor":
        return cls(
            name=d["name"],
            formula=d["formula"],
            description=d["description"],
            rationale=d.get("rationale", ""),
            category=d.get("category", "custom"),
        )


@dataclass
class FactorValidation:
    """Result of validating a discovered factor."""
    passed: bool
    factor_name: str
    nan_count: int = 0
    inf_count: int = 0
    total_values: int = 0
    min_value: float = 0.0
    max_value: float = 0.0
    mean_value: float = 0.0
    max_correlation: float = 0.0          # max abs correlation with existing factors
    most_correlated_with: str = ""        # name of the most correlated existing factor
    error: str = ""                       # error message if formula failed to evaluate
    details: str = ""                     # human-readable summary

    def to_dict(self) -> dict:
        return {
            "passed": self.passed,
            "factor_name": self.factor_name,
            "nan_count": self.nan_count,
            "inf_count": self.inf_count,
            "total_values": self.total_values,
            "min_value": self.min_value,
            "max_value": self.max_value,
            "mean_value": self.mean_value,
            "max_correlation": self.max_correlation,
            "most_correlated_with": self.most_correlated_with,
            "error": self.error,
            "details": self.details,
        }


# ============================================================
# Sandboxed formula evaluation
# ============================================================

# Allowed names for sandboxed eval of factor formulas
_SANDBOX_BUILTINS = {"__builtins__": {}}


def _get_sandbox_globals() -> dict:
    """Return a restricted namespace for evaluating factor formulas.

    Only numpy and standard math functions are allowed — no I/O, no imports.
    """
    import numpy as _np

    return {
        "__builtins__": {},
        # numpy
        "np": _np,
        "numpy": _np,
        "nan": _np.nan,
        "inf": _np.inf,
        # standard math
        "abs": abs,
        "min": min,
        "max": max,
        "sum": sum,
        "len": len,
        "range": range,
        "round": round,
        "pow": pow,
        "math": math,
        "True": True,
        "False": False,
        "None": None,
        "float": float,
        "int": int,
    }


def evaluate_formula(
    formula: str,
    close: np.ndarray,
    high: np.ndarray,
    low: np.ndarray,
    volume: np.ndarray,
    open_: np.ndarray | None = None,
) -> np.ndarray:
    """Evaluate a factor formula string in a sandboxed environment.

    The formula can reference: close, high, low, volume, open, np, math.
    Returns an ndarray of the same length as the input arrays.
    """
    import numpy as _np

    sandbox = _get_sandbox_globals()
    sandbox.update({
        "close": _np.asarray(close, dtype=float),
        "high": _np.asarray(high, dtype=float),
        "low": _np.asarray(low, dtype=float),
        "volume": _np.asarray(volume, dtype=float),
        "open": _np.asarray(open_, dtype=float) if open_ is not None else (_np.asarray(high, dtype=float) + _np.asarray(low, dtype=float)) / 2,
    })

    result = eval(formula, sandbox)  # noqa: S307 — sandboxed
    return _np.asarray(result, dtype=float)


# ============================================================
# LLM Factor Discovery Prompt
# ============================================================

LLM_DISCOVERY_SYSTEM_PROMPT = """You are a senior quantitative researcher at a top hedge fund. \
Your task is to propose novel trading factors (alpha signals) that are likely to be \
predictive of future returns and uncorrelated with existing factors.

## Data Format
You have access to OHLCV (Open/High/Low/Close/Volume) daily data as numpy arrays:
- `close`: numpy array of closing prices
- `high`: numpy array of daily high prices
- `low`: numpy array of daily low prices
- `volume`: numpy array of daily trading volume
- `open`: numpy array of opening prices (or (high+low)/2 proxy)
- `np`: numpy module available for computations

## Rules for Factor Formulas
1. Each formula must be a single Python expression or multi-line expression \
   that evaluates to a numpy array of the same length as the input arrays.
2. Only use: np (numpy), math, close, high, low, volume, open.
3. No imports, no I/O, no function definitions — expression only.
4. Handle edge cases: use np.where, np.nan_to_num, np.clip to avoid NaN/inf.
5. Return values should be roughly normalized (no extreme magnitudes).

## Output Format
Return a JSON array of factor objects. Each object has:
- "name": lowercase_snake_case factor name
- "formula": Python expression using the variables above
- "description": one-line description of what it measures
- "rationale": why this factor might be predictive (1-2 sentences)
- "category": one of "momentum", "volume", "volatility", "mean_reversion", "microstructure", "trend", "pattern"

Example:
```json
[
  {
    "name": "volume_price_divergence_5d",
    "formula": "np.nan_to_num((np.convolve(volume, np.ones(5)/5, mode='same') / np.convolve(volume, np.ones(20)/20, mode='same')) - (close / np.convolve(close, np.ones(20)/20, mode='same')), nan=0.0)",
    "description": "Divergence between short-term volume trend and price trend relative to 20-day MA",
    "rationale": "When volume accelerates but price lags, smart money may be accumulating. Based on Granville's OBV theory extended to relative volume.",
    "category": "microstructure"
  }
]
```
"""


def _build_discovery_user_prompt(
    market: str,
    count: int,
    existing_factors: List[str],
    existing_categories: Optional[Dict[str, int]] = None,
) -> str:
    """Build the user prompt for LLM factor discovery."""
    cat_summary = ""
    if existing_categories:
        cat_lines = [f"  - {cat}: {n} factors" for cat, n in sorted(existing_categories.items())]
        cat_summary = "Existing factor categories:\n" + "\n".join(cat_lines) + "\n"

    existing_list = ", ".join(existing_factors[:50]) if existing_factors else "(none)"
    if len(existing_factors) > 50:
        existing_list += f" ... and {len(existing_factors) - 50} more"

    return f"""## Market
Target market: {market}

## Existing Factors ({len(existing_factors)} total)
{cat_summary}
Sample factor names: {existing_list}

## Request
Propose exactly {count} NEW factors that:
1. Are novel — not correlated with the existing factors listed above
2. Have clear financial/academic justification
3. Use only the OHLCV data available
4. Include academic references where applicable (e.g., "Inspired by Amihud (2002) illiquidity measure")

Return ONLY the JSON array, no other text.
"""


# ============================================================
# LLM Factor Discoverer
# ============================================================

class LLMFactorDiscoverer:
    """Discovers new trading factors using an LLM (OpenAI-compatible API).

    Inspired by Microsoft's RD-Agent pattern of using LLMs to propose
    hypotheses (factor formulas) that are then validated empirically.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        model: str = "gpt-4o-mini",
    ):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.model = model

    async def _call_llm(self, system_prompt: str, user_prompt: str) -> str:
        """Make an async API call to the LLM using aiohttp."""
        import aiohttp
        import json

        url = f"{self.base_url}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.8,
            "max_tokens": 4096,
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise RuntimeError(f"LLM API error {resp.status}: {text}")
                data = await resp.json()
                return data["choices"][0]["message"]["content"]

    def _parse_llm_response(self, response: str) -> List[DiscoveredFactor]:
        """Parse LLM response text into DiscoveredFactor list."""
        import json

        # Strip markdown code fences if present
        text = response.strip()
        if text.startswith("```"):
            # Remove opening fence (```json or ```)
            first_newline = text.index("\n")
            text = text[first_newline + 1:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        # Find the JSON array in the response
        start = text.find("[")
        end = text.rfind("]")
        if start == -1 or end == -1:
            raise ValueError(f"No JSON array found in LLM response: {text[:200]}")

        raw = json.loads(text[start:end + 1])
        factors = []
        for item in raw:
            factors.append(DiscoveredFactor(
                name=item.get("name", "unnamed_factor"),
                formula=item.get("formula", "np.zeros(len(close))"),
                description=item.get("description", ""),
                rationale=item.get("rationale", ""),
                category=item.get("category", "custom"),
            ))
        return factors

    async def discover_factors(
        self,
        market: str,
        count: int,
        existing_factors: List[str],
        existing_categories: Optional[Dict[str, int]] = None,
    ) -> List[DiscoveredFactor]:
        """Discover new factors via LLM.

        Args:
            market: Target market (crypto, cn, us).
            count: Number of factors to propose.
            existing_factors: Names of existing factors to avoid duplication.
            existing_categories: Optional dict of category -> count.

        Returns:
            List of DiscoveredFactor objects.
        """
        user_prompt = _build_discovery_user_prompt(
            market=market,
            count=count,
            existing_factors=existing_factors,
            existing_categories=existing_categories,
        )
        response = await self._call_llm(LLM_DISCOVERY_SYSTEM_PROMPT, user_prompt)
        return self._parse_llm_response(response)

    def validate_factor(
        self,
        factor: DiscoveredFactor,
        data: dict,
        existing_factor_values: Optional[Dict[str, np.ndarray]] = None,
        correlation_threshold: float = 0.7,
    ) -> FactorValidation:
        """Validate a discovered factor against sample data.

        Args:
            factor: The factor to validate.
            data: Dict with keys 'close', 'high', 'low', 'volume' (and optionally 'open'),
                  each a list or numpy array.
            existing_factor_values: Optional dict of factor_name -> values array
                  for correlation checking.
            correlation_threshold: Maximum absolute correlation allowed.

        Returns:
            FactorValidation result.
        """
        import numpy as _np

        try:
            values = evaluate_formula(
                factor.formula,
                close=data["close"],
                high=data["high"],
                low=data["low"],
                volume=data["volume"],
                open_=data.get("open"),
            )
        except Exception as e:
            return FactorValidation(
                passed=False,
                factor_name=factor.name,
                error=f"Formula evaluation failed: {e}",
                details=f"Could not evaluate formula: {factor.formula[:200]}",
            )

        total = len(values)
        nan_count = int(_np.isnan(values).sum())
        inf_count = int(_np.isinf(values).sum())

        # Replace NaN/inf for stats
        clean = _np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)

        min_val = float(_np.min(clean)) if total > 0 else 0.0
        max_val = float(_np.max(clean)) if total > 0 else 0.0
        mean_val = float(_np.mean(clean)) if total > 0 else 0.0

        # --- Check NaN/inf ---
        bad_ratio = (nan_count + inf_count) / max(total, 1)
        issues = []
        if bad_ratio > 0.1:
            issues.append(f"Too many NaN/inf values: {nan_count} NaN, {inf_count} inf out of {total}")

        # --- Check constant output ---
        if total > 10 and _np.std(clean) < 1e-10:
            issues.append("Factor produces constant output (no variance)")

        # --- Correlation check ---
        max_corr = 0.0
        most_correlated = ""
        if existing_factor_values:
            for other_name, other_vals in existing_factor_values.items():
                other_arr = _np.asarray(other_vals, dtype=float)
                if len(other_arr) != total:
                    continue
                other_clean = _np.nan_to_num(other_arr, nan=0.0, posinf=0.0, neginf=0.0)
                # Pearson correlation
                if _np.std(clean) > 1e-10 and _np.std(other_clean) > 1e-10:
                    corr = abs(float(_np.corrcoef(clean, other_clean)[0, 1]))
                    if corr > max_corr:
                        max_corr = corr
                        most_correlated = other_name

            if max_corr > correlation_threshold:
                issues.append(
                    f"High correlation ({max_corr:.3f}) with existing factor '{most_correlated}'"
                )

        passed = len(issues) == 0
        details = "; ".join(issues) if issues else "All checks passed"

        return FactorValidation(
            passed=passed,
            factor_name=factor.name,
            nan_count=nan_count,
            inf_count=inf_count,
            total_values=total,
            min_value=min_val,
            max_value=max_val,
            mean_value=mean_val,
            max_correlation=max_corr,
            most_correlated_with=most_correlated,
            details=details,
        )

    def generate_factor_code(self, factor: DiscoveredFactor) -> str:
        """Generate a standalone Python function for a discovered factor.

        Returns a string containing a complete Python function definition.
        """
        safe_name = factor.name.replace("-", "_").replace(" ", "_").lower()
        return f'''import numpy as np
import math


def compute_{safe_name}(close, high, low, volume, open_=None):
    """
    {factor.description}

    Category: {factor.category}
    Rationale: {factor.rationale}

    Args:
        close: numpy array of closing prices
        high: numpy array of high prices
        low: numpy array of low prices
        volume: numpy array of volume
        open_: numpy array of opening prices (optional)

    Returns:
        numpy array of factor values
    """
    close = np.asarray(close, dtype=float)
    high = np.asarray(high, dtype=float)
    low = np.asarray(low, dtype=float)
    volume = np.asarray(volume, dtype=float)
    if open_ is None:
        open_ = (high + low) / 2.0
    else:
        open_ = np.asarray(open_, dtype=float)
    open = open_  # alias for formula compatibility

    result = {factor.formula}
    return np.nan_to_num(np.asarray(result, dtype=float), nan=0.0, posinf=0.0, neginf=0.0)
'''

    def build_prompt(
        self,
        market: str,
        count: int,
        existing_factors: List[str],
        existing_categories: Optional[Dict[str, int]] = None,
    ) -> tuple:
        """Build the (system_prompt, user_prompt) tuple without calling the API.

        Useful for testing and inspection.
        """
        user_prompt = _build_discovery_user_prompt(
            market=market,
            count=count,
            existing_factors=existing_factors,
            existing_categories=existing_categories,
        )
        return LLM_DISCOVERY_SYSTEM_PROMPT, user_prompt


# ============================================================
# CLI entry point for discover-factors
# ============================================================

def build_discover_factors_parser(parent_subparsers=None):
    """Build argparse parser for ``stratevo discover-factors``."""
    import argparse

    if parent_subparsers is not None:
        parser = parent_subparsers.add_parser(
            "discover-factors",
            help="Discover new trading factors using LLM",
            description="LLM-powered factor discovery inspired by Microsoft's RD-Agent",
        )
    else:
        parser = argparse.ArgumentParser(
            prog="stratevo discover-factors",
            description="LLM-powered factor discovery inspired by Microsoft's RD-Agent",
        )

    parser.add_argument("--count", "-n", type=int, default=5,
                        help="Number of factors to discover (default: 5)")
    parser.add_argument("--market", "-m", default="crypto",
                        choices=["crypto", "cn", "us"],
                        help="Target market (default: crypto)")
    parser.add_argument("--api-key", default=None,
                        help="OpenAI API key (or set OPENAI_API_KEY env var)")
    parser.add_argument("--base-url", default="https://api.openai.com/v1",
                        help="API base URL (default: https://api.openai.com/v1)")
    parser.add_argument("--model", default="gpt-4o-mini",
                        help="LLM model name (default: gpt-4o-mini)")
    parser.add_argument("--validate", action="store_true",
                        help="Auto-validate discovered factors against sample data")
    parser.add_argument("--output", "-o", default=None,
                        help="Save results to JSON file")
    return parser


async def _run_discover_factors(args) -> dict:
    """Async implementation of the discover-factors command."""
    import json
    import os

    api_key = args.api_key or os.environ.get("OPENAI_API_KEY", "")
    if not api_key:
        print("  ERROR: No API key. Set --api-key or OPENAI_API_KEY env var.")
        return {"error": "missing api key"}

    discoverer = LLMFactorDiscoverer(
        api_key=api_key,
        base_url=args.base_url,
        model=args.model,
    )

    # Gather existing factor names
    registry = FactorRegistry()
    try:
        registry.load_all()
    except Exception:
        pass
    existing = registry.list_factors()

    # Categorize existing factors
    categories: Dict[str, int] = {}
    for f in registry.factors.values():
        categories[f.category] = categories.get(f.category, 0) + 1

    print(f"  🔬 Discovering {args.count} new factors for {args.market} market...")
    print(f"  📊 {len(existing)} existing factors | Model: {args.model}")
    print()

    factors = await discoverer.discover_factors(
        market=args.market,
        count=args.count,
        existing_factors=existing,
        existing_categories=categories,
    )

    results = []
    for i, factor in enumerate(factors, 1):
        print(f"  [{i}] {factor.name} ({factor.category})")
        print(f"      {factor.description}")
        print(f"      Rationale: {factor.rationale}")

        validation = None
        if args.validate:
            import numpy as _np
            # Generate sample OHLCV data for validation
            n = 252
            _np.random.seed(42)
            base = 100 + _np.cumsum(_np.random.randn(n) * 0.5)
            sample_data = {
                "close": base,
                "high": base + _np.abs(_np.random.randn(n)) * 0.5,
                "low": base - _np.abs(_np.random.randn(n)) * 0.5,
                "volume": (_np.random.rand(n) * 1000000 + 500000),
            }
            validation = discoverer.validate_factor(factor, sample_data)
            status = "✅ PASS" if validation.passed else "❌ FAIL"
            print(f"      Validation: {status} — {validation.details}")

        results.append({
            "factor": factor.to_dict(),
            "validation": validation.to_dict() if validation else None,
        })
        print()

    # Print generated code
    print("  Generated factor code:")
    for factor in factors:
        code = discoverer.generate_factor_code(factor)
        print(f"  --- {factor.name} ---")
        for line in code.split("\n"):
            print(f"  {line}")
        print()

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        print(f"  💾 Results saved to {args.output}")

    return {"factors": results, "count": len(results)}


def cmd_discover_factors(args):
    """Sync wrapper for the discover-factors CLI command."""
    import asyncio
    return asyncio.run(_run_discover_factors(args))


if __name__ == "__main__":
    # Test: create seeds and load
    n = create_seed_factors()
    print(f"Created {n} seed factors")
    
    registry = FactorRegistry()
    loaded = registry.load_all()
    print(f"Loaded {loaded} factors: {registry.list_factors()}")
    
    # Test compute
    closes = [10.0 + i * 0.05 + (i % 7) * 0.2 for i in range(100)]
    highs = [c + 0.5 for c in closes]
    lows = [c - 0.3 for c in closes]
    vols = [1000000 + (i % 5) * 200000 for i in range(100)]
    
    results = registry.compute_all(closes, highs, lows, vols, 99)
    print("\nFactor scores at idx=99:")
    for name, score in sorted(results.items()):
        print(f"  {name}: {score:.3f}")
