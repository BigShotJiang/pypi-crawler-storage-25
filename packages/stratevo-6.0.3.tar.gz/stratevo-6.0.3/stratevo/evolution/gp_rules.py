"""
Genetic Programming (GP) for Trading Rule Evolution
====================================================
Evolves the trading rules themselves, not just parameters.

Instead of: fixed scoring function + evolved weights
We get: evolved expression trees that compute buy/sell signals

Example evolved rules:
  IF (RSI < 30 AND MA5_crosses_MA20) THEN buy_score = 8
  IF (volume_ratio > 2 AND bollinger_lower_touch) THEN buy_score = 9
  IF (MACD_histogram > 0 AND price > MA60) THEN buy_score = 7

Architecture:
  - Node types: Indicator, Operator, Constant, Comparator
  - Tree structure: binary expression trees
  - Operations: AND, OR, NOT, IF-THEN, >, <, +, -, *, max, min
  - Terminals: RSI, MACD, volume_ratio, MA5, MA20, etc.
  - Output: score [0, 10] for each stock at each time step

Evolution operators:
  - Crossover: swap subtrees between two parent rules
  - Mutation: replace random subtree with new random subtree  
  - Point mutation: change a single node (operator or constant)
  - Reproduction: copy elite rules unchanged
"""

from __future__ import annotations

import copy
import math
import random
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple, Union


# ============================================================
# Node Types for Expression Trees
# ============================================================

class NodeType(Enum):
    INDICATOR = "indicator"    # Terminal: reads an indicator value
    CONSTANT = "constant"      # Terminal: a fixed number
    OPERATOR = "operator"      # Internal: math operation (+, -, *, /)
    COMPARATOR = "comparator"  # Internal: comparison (>, <, ==)
    LOGIC = "logic"            # Internal: boolean logic (AND, OR, NOT)
    CONDITIONAL = "conditional"  # IF-THEN-ELSE


# Available indicators (terminals) — mapped to indicators dict keys
INDICATOR_NAMES = [
    "rsi", "r2", "slope", "volume_ratio",
    "macd_line", "macd_signal", "macd_hist",
    "bb_upper", "bb_middle", "bb_lower",
    "kdj_k", "kdj_d", "kdj_j",
    "obv_trend", "ma_alignment",
    "atr_pct", "roc", "williams_r", "cci", "mfi",
    "donchian_pos", "aroon", "pv_corr",
]

# Available operators
OPERATORS = {
    "add": lambda a, b: a + b,
    "sub": lambda a, b: a - b,
    "mul": lambda a, b: a * b,
    "safe_div": lambda a, b: a / b if abs(b) > 0.001 else 0.0,
    "max": lambda a, b: max(a, b),
    "min": lambda a, b: min(a, b),
    "abs": lambda a, b: abs(a),  # unary, ignores b
    "neg": lambda a, b: -a,      # unary
    "sqrt_abs": lambda a, b: math.sqrt(abs(a)),
    "clip01": lambda a, b: max(0.0, min(1.0, a)),
}

COMPARATORS = {
    "gt": lambda a, b: 1.0 if a > b else 0.0,
    "lt": lambda a, b: 1.0 if a < b else 0.0,
    "gte": lambda a, b: 1.0 if a >= b else 0.0,
    "lte": lambda a, b: 1.0 if a <= b else 0.0,
}

LOGIC_OPS = {
    "and": lambda a, b: 1.0 if (a > 0.5 and b > 0.5) else 0.0,
    "or": lambda a, b: 1.0 if (a > 0.5 or b > 0.5) else 0.0,
    "not": lambda a, b: 1.0 if a <= 0.5 else 0.0,  # unary
}


# ============================================================
# Expression Tree Nodes
# ============================================================

@dataclass
class GPNode:
    """A node in the expression tree."""
    node_type: NodeType
    value: str = ""         # indicator name, operator name, or ""
    constant: float = 0.0   # for CONSTANT nodes
    left: Optional['GPNode'] = None
    right: Optional['GPNode'] = None

    def depth(self) -> int:
        """Calculate tree depth."""
        if self.left is None and self.right is None:
            return 0
        left_d = self.left.depth() if self.left else 0
        right_d = self.right.depth() if self.right else 0
        return 1 + max(left_d, right_d)

    def size(self) -> int:
        """Count total nodes."""
        count = 1
        if self.left:
            count += self.left.size()
        if self.right:
            count += self.right.size()
        return count

    def evaluate(self, indicators: Dict[str, Any], idx: int) -> float:
        """Evaluate this node given indicator values at a specific day index.

        Returns a float value. For comparisons/logic, returns 0.0 or 1.0.
        """
        try:
            if self.node_type == NodeType.CONSTANT:
                return self.constant

            if self.node_type == NodeType.INDICATOR:
                arr = indicators.get(self.value)
                if arr is None:
                    return 0.0
                if isinstance(arr, (list, tuple)) and idx < len(arr):
                    val = arr[idx]
                    if isinstance(val, float) and math.isnan(val):
                        return 0.0
                    return float(val)
                elif isinstance(arr, (int, float)):
                    return float(arr)
                return 0.0

            # Evaluate children
            left_val = self.left.evaluate(indicators, idx) if self.left else 0.0
            right_val = self.right.evaluate(indicators, idx) if self.right else 0.0

            if self.node_type == NodeType.OPERATOR:
                fn = OPERATORS.get(self.value)
                if fn:
                    result = fn(left_val, right_val)
                    # Clamp to prevent explosion
                    return max(-1e6, min(1e6, result))
                return 0.0

            if self.node_type == NodeType.COMPARATOR:
                fn = COMPARATORS.get(self.value)
                return fn(left_val, right_val) if fn else 0.0

            if self.node_type == NodeType.LOGIC:
                fn = LOGIC_OPS.get(self.value)
                return fn(left_val, right_val) if fn else 0.0

            if self.node_type == NodeType.CONDITIONAL:
                # IF left > 0.5 THEN right ELSE 0
                condition = left_val
                return right_val if condition > 0.5 else 0.0

            return 0.0

        except (OverflowError, ValueError, ZeroDivisionError):
            return 0.0

    def to_string(self, depth: int = 0) -> str:
        """Human-readable representation."""
        indent = "  " * depth
        if self.node_type == NodeType.CONSTANT:
            return f"{indent}{self.constant:.2f}"
        if self.node_type == NodeType.INDICATOR:
            return f"{indent}{self.value}"
        label = self.value or self.node_type.value
        parts = [f"{indent}({label}"]
        if self.left:
            parts.append(self.left.to_string(depth + 1))
        if self.right:
            parts.append(self.right.to_string(depth + 1))
        parts.append(f"{indent})")
        return "\n".join(parts)


# ============================================================
# Trading Rule (complete GP individual)
# ============================================================

@dataclass
class TradingRule:
    """A complete trading rule evolved by GP.

    The rule tree evaluates to a buying score [0, 10].
    """
    tree: GPNode
    generation: int = 0
    fitness: float = 0.0
    lineage: List[str] = field(default_factory=list)

    def score_stock(self, indicators: Dict[str, Any], idx: int) -> float:
        """Score a stock at time idx using this rule's expression tree.

        Returns score in [0, 10].
        """
        raw = self.tree.evaluate(indicators, idx)
        # Map raw output to [0, 10] using sigmoid
        # This ensures any tree output maps smoothly to a valid score
        try:
            score = 10.0 / (1.0 + math.exp(-raw))
        except OverflowError:
            score = 10.0 if raw > 0 else 0.0
        return score

    def complexity(self) -> int:
        """Tree complexity (number of nodes). Used for parsimony pressure."""
        return self.tree.size()


# ============================================================
# Random Tree Generation
# ============================================================

def random_terminal() -> GPNode:
    """Generate a random terminal node (indicator or constant)."""
    if random.random() < 0.7:
        # Indicator
        name = random.choice(INDICATOR_NAMES)
        return GPNode(NodeType.INDICATOR, value=name)
    else:
        # Constant
        c = random.uniform(-2.0, 2.0)
        return GPNode(NodeType.CONSTANT, constant=round(c, 3))


def random_tree(max_depth: int = 4, current_depth: int = 0) -> GPNode:
    """Generate a random expression tree using ramped half-and-half."""
    # Force terminal at max depth
    if current_depth >= max_depth:
        return random_terminal()

    # At shallow depths, prefer internal nodes (grow)
    if current_depth < 2:
        terminal_prob = 0.2
    else:
        terminal_prob = 0.3 + 0.1 * current_depth

    if random.random() < terminal_prob:
        return random_terminal()

    # Random internal node
    node_type_choice = random.random()
    if node_type_choice < 0.35:
        # Comparator (most useful for trading rules)
        op = random.choice(list(COMPARATORS.keys()))
        node = GPNode(NodeType.COMPARATOR, value=op)
    elif node_type_choice < 0.55:
        # Logic
        op = random.choice(list(LOGIC_OPS.keys()))
        node = GPNode(NodeType.LOGIC, value=op)
    elif node_type_choice < 0.85:
        # Math operator
        op = random.choice(list(OPERATORS.keys()))
        node = GPNode(NodeType.OPERATOR, value=op)
    else:
        # Conditional
        node = GPNode(NodeType.CONDITIONAL, value="if")

    node.left = random_tree(max_depth, current_depth + 1)
    node.right = random_tree(max_depth, current_depth + 1)
    return node


# ============================================================
# GP Operators
# ============================================================

def _all_nodes(tree: GPNode) -> List[GPNode]:
    """Collect all nodes in a tree."""
    nodes = [tree]
    if tree.left:
        nodes.extend(_all_nodes(tree.left))
    if tree.right:
        nodes.extend(_all_nodes(tree.right))
    return nodes


def _random_subtree_ref(tree: GPNode) -> Tuple[Optional[GPNode], str]:
    """Return a random node and the path to reach it (for replacement)."""
    nodes = _all_nodes(tree)
    return random.choice(nodes), ""


def gp_crossover(parent1: TradingRule, parent2: TradingRule) -> TradingRule:
    """Swap a random subtree between two parents."""
    child_tree = copy.deepcopy(parent1.tree)
    donor_tree = copy.deepcopy(parent2.tree)

    # Get all non-root nodes from child
    child_nodes = _all_nodes(child_tree)
    donor_nodes = _all_nodes(donor_tree)

    if len(child_nodes) < 2 or len(donor_nodes) < 2:
        return TradingRule(tree=child_tree, lineage=["crossover"])

    # Pick random internal node in child to replace
    child_parent = random.choice(child_nodes[:-1]) if len(child_nodes) > 1 else child_nodes[0]
    donor_subtree = random.choice(donor_nodes)

    # Replace child's subtree
    if random.random() < 0.5 and child_parent.left is not None:
        child_parent.left = copy.deepcopy(donor_subtree)
    elif child_parent.right is not None:
        child_parent.right = copy.deepcopy(donor_subtree)
    else:
        child_parent.left = copy.deepcopy(donor_subtree)

    # Limit depth
    if child_tree.depth() > 8:
        child_tree = random_tree(max_depth=5)

    return TradingRule(tree=child_tree, lineage=["crossover"])


def gp_mutate(rule: TradingRule, mutation_rate: float = 0.3) -> TradingRule:
    """Mutate a trading rule by replacing random subtrees."""
    tree = copy.deepcopy(rule.tree)
    nodes = _all_nodes(tree)

    for node in nodes:
        if random.random() < mutation_rate:
            if node.node_type == NodeType.CONSTANT:
                # Adjust constant
                node.constant += random.gauss(0, 0.5)
                node.constant = round(max(-5.0, min(5.0, node.constant)), 3)
            elif node.node_type == NodeType.INDICATOR:
                # Swap indicator
                node.value = random.choice(INDICATOR_NAMES)
            elif node.node_type == NodeType.OPERATOR:
                node.value = random.choice(list(OPERATORS.keys()))
            elif node.node_type == NodeType.COMPARATOR:
                node.value = random.choice(list(COMPARATORS.keys()))
            elif node.node_type == NodeType.LOGIC:
                node.value = random.choice(list(LOGIC_OPS.keys()))

    # Subtree mutation: occasionally replace a whole subtree
    if random.random() < 0.15:
        target = random.choice(nodes)
        new_subtree = random_tree(max_depth=3)
        target.node_type = new_subtree.node_type
        target.value = new_subtree.value
        target.constant = new_subtree.constant
        target.left = new_subtree.left
        target.right = new_subtree.right

    return TradingRule(tree=tree, lineage=["mutation"])


def gp_tournament_select(
    population: List[TradingRule],
    tournament_size: int = 3,
) -> TradingRule:
    """Tournament selection — pick best from random subset."""
    competitors = random.sample(population, min(tournament_size, len(population)))
    return max(competitors, key=lambda r: r.fitness)


# ============================================================
# GP Evolution Engine
# ============================================================

class GPEvolver:
    """Genetic Programming engine for evolving trading rules.

    Can be used standalone or integrated into AutoEvolver as an
    alternative/complementary scoring mechanism.
    """

    def __init__(
        self,
        population_size: int = 50,
        max_depth: int = 6,
        tournament_size: int = 3,
        crossover_rate: float = 0.7,
        mutation_rate: float = 0.2,
        reproduction_rate: float = 0.1,
        parsimony_coefficient: float = 0.001,
    ):
        self.population_size = population_size
        self.max_depth = max_depth
        self.tournament_size = tournament_size
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.reproduction_rate = reproduction_rate
        self.parsimony_coefficient = parsimony_coefficient

    def initialize_population(self) -> List[TradingRule]:
        """Create initial random population with ramped half-and-half."""
        population = []
        for i in range(self.population_size):
            depth = 2 + (i % (self.max_depth - 1))  # ramped
            tree = random_tree(max_depth=depth)
            population.append(TradingRule(tree=tree, generation=0))
        return population

    def evolve_generation(
        self,
        population: List[TradingRule],
        generation: int,
    ) -> List[TradingRule]:
        """Create next generation via selection, crossover, mutation."""
        new_pop: List[TradingRule] = []

        # Elitism: keep top 2
        sorted_pop = sorted(population, key=lambda r: r.fitness, reverse=True)
        for elite in sorted_pop[:2]:
            e = TradingRule(
                tree=copy.deepcopy(elite.tree),
                generation=generation,
                lineage=["elite"],
            )
            new_pop.append(e)

        while len(new_pop) < self.population_size:
            r = random.random()
            if r < self.crossover_rate:
                p1 = gp_tournament_select(population, self.tournament_size)
                p2 = gp_tournament_select(population, self.tournament_size)
                child = gp_crossover(p1, p2)
            elif r < self.crossover_rate + self.mutation_rate:
                p = gp_tournament_select(population, self.tournament_size)
                child = gp_mutate(p, mutation_rate=0.3)
            else:
                p = gp_tournament_select(population, self.tournament_size)
                child = TradingRule(
                    tree=copy.deepcopy(p.tree),
                    lineage=["reproduction"],
                )
            child.generation = generation
            new_pop.append(child)

        return new_pop[:self.population_size]

    def apply_parsimony(self, rule: TradingRule) -> float:
        """Apply parsimony pressure: penalize overly complex trees."""
        return rule.fitness - self.parsimony_coefficient * rule.complexity()
