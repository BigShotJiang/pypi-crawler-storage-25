"""
Evolution Dashboard — static HTML generator for visualizing genetic algorithm evolution.

Reads gen_*.json files from a results directory and produces a self-contained,
interactive HTML page with Chart.js charts.

Usage (programmatic):
    from stratevo.web.evolution_dashboard import generate_dashboard
    generate_dashboard("evolution_results/", "dashboard.html")

CLI:
    stratevo dashboard --results-dir evolution_results --output dashboard.html
    stratevo dashboard --results-dir evolution_results --serve --port 8080
"""

from __future__ import annotations

import glob
import json
import os
import html as html_module
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# ─── Config ───────────────────────────────────────────────────────────────

@dataclass
class DashboardConfig:
    """Configuration for the evolution dashboard."""
    title: str = "🦀 StratEvo Evolution Dashboard"
    auto_refresh: bool = False
    refresh_interval: int = 30  # seconds


# ─── Data Loading ─────────────────────────────────────────────────────────

def load_generation_files(results_dir: str) -> list[dict[str, Any]]:
    """Load and sort all gen_*.json files from a directory.

    Skips corrupt/unreadable files silently.
    Returns list sorted by generation number.
    """
    if not os.path.isdir(results_dir):
        return []

    pattern = os.path.join(results_dir, "gen_*.json")
    files = sorted(glob.glob(pattern))
    generations: list[dict[str, Any]] = []

    for filepath in files:
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict) and "generation" in data:
                generations.append(data)
        except (json.JSONDecodeError, OSError, KeyError):
            continue

    generations.sort(key=lambda g: g.get("generation", 0))
    return generations


# ─── Data Extraction ──────────────────────────────────────────────────────

def extract_chart_data(generations: list[dict[str, Any]]) -> dict[str, list]:
    """Extract time-series data for charts from generation files.

    Returns dict with keys: generations, timestamps, fitness, annual_return,
    sharpe, max_drawdown, win_rate, calmar, total_trades
    """
    result: dict[str, list] = {
        "generations": [],
        "timestamps": [],
        "fitness": [],
        "annual_return": [],
        "sharpe": [],
        "max_drawdown": [],
        "win_rate": [],
        "calmar": [],
        "total_trades": [],
    }

    for gen in generations:
        gen_num = gen.get("generation", 0)
        timestamp = gen.get("timestamp", "")
        results = gen.get("results", [])

        if not results:
            continue

        # Use the best result (first one, which is typically the best/elite)
        best = results[0]

        result["generations"].append(gen_num)
        result["timestamps"].append(timestamp)
        result["fitness"].append(best.get("fitness", 0))
        result["annual_return"].append(best.get("annual_return", 0))
        result["sharpe"].append(best.get("sharpe", 0))
        result["max_drawdown"].append(best.get("max_drawdown", 0))
        result["win_rate"].append(best.get("win_rate", 0))
        result["calmar"].append(best.get("calmar", 0))
        result["total_trades"].append(best.get("total_trades", 0))

    return result


def extract_best_strategy(generations: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Find the best strategy across all generations by fitness.

    Returns a dict with metrics + dna + generation number, or None if no data.
    """
    if not generations:
        return None

    best_fitness = float("-inf")
    best_result: dict[str, Any] | None = None
    best_gen = 0

    for gen in generations:
        gen_num = gen.get("generation", 0)
        for result in gen.get("results", []):
            fitness = result.get("fitness", float("-inf"))
            if fitness > best_fitness:
                best_fitness = fitness
                best_result = result
                best_gen = gen_num

    if best_result is None:
        return None

    return {
        "generation": best_gen,
        "fitness": best_result.get("fitness", 0),
        "annual_return": best_result.get("annual_return", 0),
        "max_drawdown": best_result.get("max_drawdown", 0),
        "win_rate": best_result.get("win_rate", 0),
        "sharpe": best_result.get("sharpe", 0),
        "calmar": best_result.get("calmar", 0),
        "total_trades": best_result.get("total_trades", 0),
        "profit_factor": best_result.get("profit_factor", 0),
        "dna": best_result.get("dna", {}),
        "walk_forward_windows": best_result.get("walk_forward_windows", []),
    }


def extract_walk_forward_windows(best: dict[str, Any] | None) -> list[dict[str, Any]]:
    """Extract walk-forward window details from the best strategy.

    Returns list of window dicts, or empty list.
    """
    if best is None:
        return []
    return best.get("walk_forward_windows", [])


# ─── HTML Generation ─────────────────────────────────────────────────────

def _esc(value: Any) -> str:
    """HTML-escape a value."""
    return html_module.escape(str(value))


def _json_dumps(obj: Any) -> str:
    """JSON-serialize for embedding in JS."""
    return json.dumps(obj, ensure_ascii=False)


def generate_html(
    generations: list[dict[str, Any]],
    auto_refresh: bool = False,
    config: DashboardConfig | None = None,
) -> str:
    """Generate self-contained HTML dashboard from generation data.

    Parameters
    ----------
    generations : list of gen dicts (from load_generation_files)
    auto_refresh : enable auto-refresh meta tag
    config : optional DashboardConfig

    Returns
    -------
    str : complete HTML page
    """
    if config is None:
        config = DashboardConfig(auto_refresh=auto_refresh)

    if not generations:
        return _generate_empty_html(config)

    chart_data = extract_chart_data(generations)
    best = extract_best_strategy(generations)
    wf_windows = extract_walk_forward_windows(best)

    # Detect market
    market = generations[0].get("market", "unknown")
    total_gens = len(generations)

    return _render_full_html(config, chart_data, best, wf_windows, market, total_gens)


def _generate_empty_html(config: DashboardConfig) -> str:
    """Render an HTML page when there's no data."""
    refresh_meta = ""
    if config.auto_refresh:
        refresh_meta = f'<meta http-equiv="refresh" content="{config.refresh_interval}">'

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {refresh_meta}
    <title>{_esc(config.title)}</title>
    <style>{_get_css()}</style>
</head>
<body>
    <div class="container">
        <h1>{_esc(config.title)}</h1>
        <div class="card">
            <p class="no-data">No data available. No generation files found.</p>
        </div>
    </div>
</body>
</html>"""


def _render_full_html(
    config: DashboardConfig,
    chart_data: dict[str, list],
    best: dict[str, Any] | None,
    wf_windows: list[dict[str, Any]],
    market: str,
    total_gens: int,
) -> str:
    """Render the full dashboard HTML with charts and tables."""
    refresh_meta = ""
    refresh_js = ""
    if config.auto_refresh:
        refresh_meta = f'<meta http-equiv="refresh" content="{config.refresh_interval}">'
        refresh_js = f"setInterval(() => location.reload(), {config.refresh_interval * 1000});"

    best_table_html = _render_best_table(best) if best else "<p>No best strategy found.</p>"
    wf_table_html = _render_wf_table(wf_windows) if wf_windows else "<p>No walk-forward windows.</p>"
    dna_table_html = _render_dna_table(best) if best and best.get("dna") else ""

    market_label = {
        "cn": "🇨🇳 A-Share",
        "us": "🇺🇸 US Stock",
        "crypto": "₿ Crypto",
    }.get(market, market.upper())

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    {refresh_meta}
    <title>{_esc(config.title)}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
    <style>{_get_css()}</style>
</head>
<body>
    <div class="container">
        <h1>{_esc(config.title)}</h1>
        <div class="meta-bar">
            <span class="badge">{market_label}</span>
            <span class="badge">{total_gens} generations</span>
            <span class="badge">Best fitness: {best['fitness']:.2f}</span>
        </div>

        <!-- Fitness Progression Chart -->
        <div class="card">
            <h2>📈 Fitness Progression</h2>
            <canvas id="fitnessChart"></canvas>
        </div>

        <!-- Metrics Progression Chart -->
        <div class="card">
            <h2>📊 Metrics Progression</h2>
            <canvas id="metricsChart"></canvas>
        </div>

        <!-- Best Strategy Summary -->
        <div class="card">
            <h2>🏆 Best Strategy (Gen {best['generation'] if best else '?'})</h2>
            {best_table_html}
        </div>

        <!-- Walk-Forward Windows -->
        <div class="card">
            <h2>🔄 Walk-Forward Window Breakdown</h2>
            {wf_table_html}
        </div>

        <!-- DNA Summary -->
        {f'<div class="card"><h2>🧬 DNA Parameters</h2>{dna_table_html}</div>' if dna_table_html else ''}
    </div>

    <script>
    // ── Chart Data ──
    const chartData = {_json_dumps(chart_data)};

    // ── Fitness Chart ──
    new Chart(document.getElementById('fitnessChart'), {{
        type: 'line',
        data: {{
            labels: chartData.generations,
            datasets: [{{
                label: 'Fitness',
                data: chartData.fitness,
                borderColor: '#e74c3c',
                backgroundColor: 'rgba(231, 76, 60, 0.1)',
                fill: true,
                tension: 0.3,
                pointRadius: 3,
            }}]
        }},
        options: {{
            responsive: true,
            plugins: {{
                title: {{ display: false }},
                legend: {{ position: 'top' }},
            }},
            scales: {{
                x: {{ title: {{ display: true, text: 'Generation' }} }},
                y: {{ title: {{ display: true, text: 'Fitness' }} }},
            }}
        }}
    }});

    // ── Metrics Chart ──
    new Chart(document.getElementById('metricsChart'), {{
        type: 'line',
        data: {{
            labels: chartData.generations,
            datasets: [
                {{
                    label: 'Annual Return (%)',
                    data: chartData.annual_return,
                    borderColor: '#2ecc71',
                    tension: 0.3,
                    pointRadius: 2,
                    yAxisID: 'y',
                }},
                {{
                    label: 'Sharpe Ratio',
                    data: chartData.sharpe,
                    borderColor: '#3498db',
                    tension: 0.3,
                    pointRadius: 2,
                    yAxisID: 'y1',
                }},
                {{
                    label: 'Max Drawdown (%)',
                    data: chartData.max_drawdown,
                    borderColor: '#e67e22',
                    borderDash: [5, 5],
                    tension: 0.3,
                    pointRadius: 2,
                    yAxisID: 'y',
                }},
            ]
        }},
        options: {{
            responsive: true,
            interaction: {{ mode: 'index', intersect: false }},
            plugins: {{ legend: {{ position: 'top' }} }},
            scales: {{
                x: {{ title: {{ display: true, text: 'Generation' }} }},
                y: {{ type: 'linear', position: 'left', title: {{ display: true, text: 'Return / Drawdown (%)' }} }},
                y1: {{ type: 'linear', position: 'right', title: {{ display: true, text: 'Sharpe Ratio' }}, grid: {{ drawOnChartArea: false }} }},
            }}
        }}
    }});

    {refresh_js}
    </script>
</body>
</html>"""


def _render_best_table(best: dict[str, Any]) -> str:
    """Render the best strategy metrics as an HTML table."""
    rows = [
        ("Fitness", f"{best.get('fitness', 0):.2f}"),
        ("Annual Return", f"{best.get('annual_return', 0):.2f}%"),
        ("Max Drawdown", f"{best.get('max_drawdown', 0):.2f}%"),
        ("Win Rate", f"{best.get('win_rate', 0):.1f}%"),
        ("Sharpe Ratio", f"{best.get('sharpe', 0):.2f}"),
        ("Calmar Ratio", f"{best.get('calmar', 0):.2f}"),
        ("Total Trades", str(best.get('total_trades', 0))),
        ("Profit Factor", f"{best.get('profit_factor', 0):.2f}"),
    ]
    html_rows = "\n".join(
        f"        <tr><td>{_esc(label)}</td><td>{_esc(value)}</td></tr>"
        for label, value in rows
    )
    return f"""    <table class="metrics-table">
        <thead><tr><th>Metric</th><th>Value</th></tr></thead>
        <tbody>
{html_rows}
        </tbody>
    </table>"""


def _render_wf_table(windows: list[dict[str, Any]]) -> str:
    """Render walk-forward windows as an HTML table."""
    if not windows:
        return "<p>No walk-forward windows.</p>"

    header_keys = [
        ("window", "Window"),
        ("oos_annual_return", "OOS Return (%)"),
        ("oos_max_drawdown", "OOS Max DD (%)"),
        ("oos_sharpe", "OOS Sharpe"),
        ("oos_trades", "OOS Trades"),
        ("oos_win_rate", "OOS Win Rate (%)"),
        ("oos_fitness", "OOS Fitness"),
    ]

    # Filter to keys that exist in the data
    sample = windows[0]
    cols = [(k, label) for k, label in header_keys if k in sample]

    header_html = "".join(f"<th>{_esc(label)}</th>" for _, label in cols)
    row_html_parts = []
    for w in windows:
        cells = "".join(
            f"<td>{_format_val(w.get(k, ''))}</td>" for k, _ in cols
        )
        row_html_parts.append(f"        <tr>{cells}</tr>")

    rows_html = "\n".join(row_html_parts)
    return f"""    <table class="metrics-table">
        <thead><tr>{header_html}</tr></thead>
        <tbody>
{rows_html}
        </tbody>
    </table>"""


def _render_dna_table(best: dict[str, Any]) -> str:
    """Render DNA parameters (top 20 non-zero weights) as an HTML table."""
    dna = best.get("dna", {})
    if not dna:
        return ""

    # Sort: non-zero weights first (by abs value desc), then config params
    items = sorted(dna.items(), key=lambda kv: (-abs(kv[1]) if isinstance(kv[1], (int, float)) else 0, kv[0]))
    # Limit to top 30 for readability
    items = items[:30]

    rows = "\n".join(
        f"        <tr><td><code>{_esc(k)}</code></td><td>{_format_val(v)}</td></tr>"
        for k, v in items
    )
    return f"""    <table class="metrics-table dna-table">
        <thead><tr><th>Parameter</th><th>Value</th></tr></thead>
        <tbody>
{rows}
        </tbody>
    </table>"""


def _format_val(v: Any) -> str:
    """Format a numeric value for display."""
    if isinstance(v, float):
        return f"{v:.4f}" if abs(v) < 1 else f"{v:.2f}"
    return _esc(str(v))


def _get_css() -> str:
    """Return inline CSS for the dashboard."""
    return """
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #0d1117;
            color: #c9d1d9;
            line-height: 1.6;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            font-size: 1.8em;
            margin-bottom: 10px;
            color: #f0f6fc;
        }
        h2 {
            font-size: 1.2em;
            margin-bottom: 12px;
            color: #f0f6fc;
        }
        .meta-bar {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .badge {
            background: #21262d;
            border: 1px solid #30363d;
            border-radius: 20px;
            padding: 4px 14px;
            font-size: 0.85em;
            color: #8b949e;
        }
        .card {
            background: #161b22;
            border: 1px solid #30363d;
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
        .no-data {
            text-align: center;
            color: #8b949e;
            padding: 40px;
            font-size: 1.1em;
        }
        .metrics-table {
            width: 100%;
            border-collapse: collapse;
        }
        .metrics-table th, .metrics-table td {
            text-align: left;
            padding: 8px 12px;
            border-bottom: 1px solid #21262d;
        }
        .metrics-table th {
            color: #8b949e;
            font-weight: 600;
            font-size: 0.85em;
            text-transform: uppercase;
        }
        .metrics-table td {
            font-variant-numeric: tabular-nums;
        }
        .dna-table td:first-child {
            font-family: 'SF Mono', 'Fira Code', monospace;
            font-size: 0.85em;
        }
        canvas { max-height: 350px; }
    """


# ─── Public API ──────────────────────────────────────────────────────────

def generate_dashboard(
    results_dir: str,
    output_path: str,
    config: DashboardConfig | None = None,
) -> str:
    """Generate dashboard HTML and write to file.

    Parameters
    ----------
    results_dir : path to directory with gen_*.json files
    output_path : path to write the HTML file
    config : optional DashboardConfig

    Returns
    -------
    str : the generated HTML content
    """
    generations = load_generation_files(results_dir)
    html = generate_html(generations, config=config)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    Path(output_path).write_text(html, encoding="utf-8")

    return html


# ─── Live Server ─────────────────────────────────────────────────────────

def serve_dashboard(results_dir: str, port: int = 8080, host: str = "0.0.0.0") -> None:
    """Start a simple HTTP server that auto-regenerates the dashboard.

    Uses stdlib http.server — no Flask/bottle dependency.
    """
    import http.server
    import threading
    import time

    config = DashboardConfig(auto_refresh=True, refresh_interval=15)

    # Generate initial HTML
    html_content = generate_html(load_generation_files(results_dir), config=config)

    class DashboardHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            nonlocal html_content
            if self.path == "/" or self.path == "/index.html":
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(html_content.encode("utf-8"))
            else:
                self.send_response(404)
                self.end_headers()

        def log_message(self, format, *args):
            pass  # Suppress request logs

    def regenerate_loop():
        nonlocal html_content
        while True:
            time.sleep(config.refresh_interval)
            try:
                html_content = generate_html(
                    load_generation_files(results_dir), config=config
                )
            except Exception:
                pass

    regen_thread = threading.Thread(target=regenerate_loop, daemon=True)
    regen_thread.start()

    server = http.server.HTTPServer((host, port), DashboardHandler)
    print(f"  🦀 Evolution Dashboard serving at http://{host}:{port}/")
    print(f"  📁 Watching: {os.path.abspath(results_dir)}")
    print(f"  🔄 Auto-refresh: every {config.refresh_interval}s")
    print("  Press Ctrl+C to stop.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n  Dashboard server stopped.")
        server.shutdown()


# ─── CLI Entry ───────────────────────────────────────────────────────────

def build_dashboard_parser(parent_subparsers=None):
    """Build argparse parser for 'stratevo dashboard' subcommand."""
    import argparse

    if parent_subparsers is not None:
        parser = parent_subparsers.add_parser(
            "dashboard",
            help="Evolution dashboard — visualize genetic algorithm progress",
        )
    else:
        parser = argparse.ArgumentParser(prog="stratevo dashboard")

    parser.add_argument(
        "--results-dir", default="evolution_results",
        help="Directory with gen_*.json files (default: evolution_results)",
    )
    parser.add_argument(
        "--output", "-o", default="dashboard.html",
        help="Output HTML file (default: dashboard.html)",
    )
    parser.add_argument(
        "--serve", action="store_true", default=False,
        help="Start live server mode instead of generating static file",
    )
    parser.add_argument(
        "--port", type=int, default=8080,
        help="Port for live server (default: 8080)",
    )
    parser.add_argument(
        "--host", default="0.0.0.0",
        help="Host for live server (default: 0.0.0.0)",
    )
    parser.add_argument(
        "--title", default=None,
        help="Custom dashboard title",
    )
    return parser


def cmd_dashboard(args) -> None:
    """Execute 'stratevo dashboard' command."""
    config = DashboardConfig()
    if args.title:
        config.title = args.title

    if args.serve:
        serve_dashboard(args.results_dir, port=args.port, host=args.host)
    else:
        config.auto_refresh = False
        html = generate_dashboard(args.results_dir, args.output, config=config)
        gens = load_generation_files(args.results_dir)
        print(f"  🦀 Evolution Dashboard generated: {args.output}")
        print(f"  📊 {len(gens)} generations loaded")
        if gens:
            best = extract_best_strategy(gens)
            if best:
                print(f"  🏆 Best fitness: {best['fitness']:.2f} (gen {best['generation']})")
