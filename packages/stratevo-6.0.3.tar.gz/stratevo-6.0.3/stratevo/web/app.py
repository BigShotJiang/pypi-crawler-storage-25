"""
StratEvo Web UI — Gradio-based dashboard for the evolution engine.

Launch: python -m stratevo.web.app
        or: stratevo web

Provides:
- Evolution status monitoring
- Strategy DNA viewer
- Quick backtesting
- Market quotes
"""

from __future__ import annotations

import json
from pathlib import Path

import gradio as gr


def _load_evolution_status(results_dir: str = "evolution_results") -> dict:
    """Load latest evolution results."""
    latest = Path(results_dir) / "latest.json"
    if not latest.exists():
        return {"status": "No evolution results found", "generation": 0}
    try:
        with open(latest, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data
    except Exception as e:
        return {"status": f"Error: {e}", "generation": 0}


def _load_best_ever(results_dir: str = "evolution_results") -> dict:
    """Load best-ever strategy."""
    best = Path(results_dir) / "best_ever.json"
    if not best.exists():
        return {}
    try:
        with open(best, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_evolution_summary() -> str:
    """Get formatted evolution status."""
    # Check multiple results dirs
    dirs = ["evolution_results", "evolution_results_ashares", "evolution_results_crypto"]
    sections = []

    for d in dirs:
        if not Path(d).exists():
            continue
        status = _load_evolution_status(d)
        best = _load_best_ever(d)

        gen = status.get("generation", "?")
        fitness = best.get("fitness", "N/A")
        annual_return = best.get("annual_return", "N/A")
        sharpe = best.get("sharpe", "N/A")
        max_dd = best.get("max_drawdown", "N/A")
        trades = best.get("total_trades", "N/A")

        section = f"""### 📁 {d}
| Metric | Value |
|--------|-------|
| Generation | {gen} |
| Best Fitness | {fitness} |
| Annual Return | {annual_return}% |
| Sharpe Ratio | {sharpe} |
| Max Drawdown | {max_dd}% |
| Total Trades | {trades} |
"""
        sections.append(section)

    if not sections:
        return "⚠️ No evolution results found. Start the engine with:\n```\nstratevo evolve --generations 100\n```"

    return "\n---\n".join(sections)


def get_strategy_dna() -> str:
    """Get best strategy DNA as formatted JSON."""
    best = _load_best_ever()
    if not best:
        best = _load_best_ever("evolution_results_ashares")
    if not best:
        best = _load_best_ever("evolution_results_crypto")
    if not best:
        return "No strategy DNA available yet."

    dna = best.get("dna", best)
    return json.dumps(dna, indent=2, ensure_ascii=False)


def get_quote(ticker: str) -> str:
    """Get stock/crypto quote."""
    if not ticker.strip():
        return "Please enter a ticker symbol."
    try:
        import yfinance as yf
        t = yf.Ticker(ticker.strip().upper())
        info = t.info
        price = info.get("currentPrice") or info.get("regularMarketPrice", "N/A")
        change = info.get("regularMarketChangePercent", 0)
        name = info.get("shortName", ticker)
        mkt_cap = info.get("marketCap", "N/A")
        if isinstance(mkt_cap, (int, float)):
            if mkt_cap >= 1e12:
                mkt_cap = f"${mkt_cap/1e12:.1f}T"
            elif mkt_cap >= 1e9:
                mkt_cap = f"${mkt_cap/1e9:.1f}B"
            elif mkt_cap >= 1e6:
                mkt_cap = f"${mkt_cap/1e6:.1f}M"

        return f"""### {name} ({ticker.upper()})

| Metric | Value |
|--------|-------|
| Price | ${price} |
| Change | {change:.2f}% |
| Market Cap | {mkt_cap} |
| 52w High | ${info.get('fiftyTwoWeekHigh', 'N/A')} |
| 52w Low | ${info.get('fiftyTwoWeekLow', 'N/A')} |
| PE Ratio | {info.get('trailingPE', 'N/A')} |
"""
    except Exception as e:
        return f"Error: {e}"


def run_quick_backtest(ticker: str, days: int) -> str:
    """Run a quick backtest on a ticker."""
    if not ticker.strip():
        return "Please enter a ticker."
    try:
        import yfinance as yf
        t = yf.Ticker(ticker.strip().upper())
        hist = t.history(period=f"{days}d")
        if hist.empty:
            return f"No data for {ticker}"

        # Simple momentum backtest
        returns = hist["Close"].pct_change().dropna()
        total_return = (1 + returns).prod() - 1
        sharpe = (returns.mean() / returns.std() * (252**0.5)) if returns.std() > 0 else 0
        max_dd = (hist["Close"] / hist["Close"].cummax() - 1).min()

        return f"""### Quick Backtest: {ticker.upper()} ({days} days)

| Metric | Value |
|--------|-------|
| Total Return | {total_return*100:.2f}% |
| Sharpe Ratio | {sharpe:.2f} |
| Max Drawdown | {max_dd*100:.2f}% |
| Days | {len(returns)} |
| Avg Daily Return | {returns.mean()*100:.3f}% |
| Volatility (ann.) | {returns.std()*100*(252**0.5):.2f}% |
"""
    except Exception as e:
        return f"Error: {e}"


def create_app() -> gr.Blocks:
    """Create the Gradio app."""
    with gr.Blocks(
        title="StratEvo — Vibe Evolving",
    ) as app:
        gr.Markdown("""
# 🦀 StratEvo — Vibe Evolving
**Genetic algorithms discover trading strategies you never would.**
        """)

        with gr.Tab("📊 Evolution Status"):
            gr.Markdown("Real-time view of evolution engine progress.")
            status_output = gr.Markdown()
            refresh_btn = gr.Button("🔄 Refresh", variant="primary")
            refresh_btn.click(get_evolution_summary, outputs=status_output)
            app.load(get_evolution_summary, outputs=status_output)

        with gr.Tab("🧬 Strategy DNA"):
            gr.Markdown("View the best-evolved strategy's DNA weights.")
            dna_output = gr.Code(language="json", label="Best Strategy DNA")
            dna_btn = gr.Button("🔄 Load DNA", variant="primary")
            dna_btn.click(get_strategy_dna, outputs=dna_output)

        with gr.Tab("💹 Market Quote"):
            with gr.Row():
                ticker_input = gr.Textbox(label="Ticker", placeholder="AAPL, BTC-USD, MSFT...", scale=3)
                quote_btn = gr.Button("Get Quote", variant="primary", scale=1)
            quote_output = gr.Markdown()
            quote_btn.click(get_quote, inputs=ticker_input, outputs=quote_output)

        with gr.Tab("📈 Quick Backtest"):
            with gr.Row():
                bt_ticker = gr.Textbox(label="Ticker", placeholder="AAPL", scale=2)
                bt_days = gr.Slider(30, 365, value=90, step=30, label="Days", scale=2)
                bt_btn = gr.Button("Run Backtest", variant="primary", scale=1)
            bt_output = gr.Markdown()
            bt_btn.click(run_quick_backtest, inputs=[bt_ticker, bt_days], outputs=bt_output)

        gr.Markdown("---\n*StratEvo v5.6.0 | [GitHub](https://github.com/NeuZhou/stratevo)*")

    return app


def main():
    """Launch the web UI."""
    app = create_app()
    print("🦀 StratEvo Web UI starting...")
    print("   Open http://localhost:7860 in your browser")
    app.launch(server_name="127.0.0.1", server_port=7860, share=False)


if __name__ == "__main__":
    main()
