"""stratevo.defi - DeFi monitoring and analytics."""
