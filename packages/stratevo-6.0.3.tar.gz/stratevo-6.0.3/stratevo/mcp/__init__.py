"""stratevo.mcp - Model Context Protocol server."""
