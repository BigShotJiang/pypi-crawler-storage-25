"""stratevo.strategies - Trading strategies."""

from stratevo.strategies.momentum_jt import MomentumJTStrategy
from stratevo.strategies.combiner import StrategyCombiner

__all__ = [
    "MomentumJTStrategy",
    "StrategyCombiner",
]

try:
    from stratevo.strategies.mean_reversion import MeanReversionStrategy
    __all__.append("MeanReversionStrategy")
except ImportError:
    pass

try:
    from stratevo.strategies.trend_following import TrendFollowingStrategy
    __all__.append("TrendFollowingStrategy")
except ImportError:
    pass

try:
    from stratevo.strategies.pairs_trading import PairsTradingStrategy
    __all__.append("PairsTradingStrategy")
except ImportError:
    pass

try:
    from stratevo.strategies.ensemble import StrategyEnsemble
    __all__.append("StrategyEnsemble")
except ImportError:
    pass

try:
    from stratevo.strategies.value_momentum import ValueMomentumStrategy
    __all__.append("ValueMomentumStrategy")
except ImportError:
    pass
