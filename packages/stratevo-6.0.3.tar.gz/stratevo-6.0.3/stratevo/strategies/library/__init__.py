"""
stratevo.strategies.library — Built-in strategy registry.
"""

from stratevo.strategies.library.grid_trading import GridTradingStrategy
from stratevo.strategies.library.funding_rate import FundingRateArbitrage
from stratevo.strategies.library.dca import DCAStrategy
from stratevo.strategies.library.pairs_trading import PairsTradingStrategy
from stratevo.strategies.library.sector_rotation import SectorRotationStrategy
from stratevo.strategies.library.dividend_harvest import DividendHarvestStrategy
from stratevo.strategies.library.trend_following import TrendFollowingStrategy
from stratevo.strategies.library.breakout import BreakoutStrategy
from stratevo.strategies.library.mean_reversion_bb import MeanReversionBBStrategy
from stratevo.strategies.library.multi_factor import MultiFactorStrategy
from stratevo.strategies.library.bollinger import BollingerStrategy
from stratevo.strategies.library.momentum import MomentumStrategy
from stratevo.strategies.library.momentum_rotation import MomentumRotationStrategy
from stratevo.strategies.library.ichimoku import IchimokuStrategy
from stratevo.strategies.library.macd_crossover import MACDCrossoverStrategy
from stratevo.strategies.library.rsi_divergence import RSIDivergenceStrategy
from stratevo.strategies.library.vwap import VWAPStrategy
from stratevo.strategies.library.btc_cycle import BTCCycleIndicator


STRATEGY_REGISTRY: dict[str, type] = {
    "grid-trading": GridTradingStrategy,
    "funding-rate": FundingRateArbitrage,
    "dca": DCAStrategy,
    "pairs-trading": PairsTradingStrategy,
    "sector-rotation": SectorRotationStrategy,
    "dividend-harvest": DividendHarvestStrategy,
    "trend-following": TrendFollowingStrategy,
    "breakout": BreakoutStrategy,
    "mean-reversion-bb": MeanReversionBBStrategy,
    "multi-factor": MultiFactorStrategy,
    "bollinger": BollingerStrategy,
    "momentum": MomentumStrategy,
    "momentum-rotation": MomentumRotationStrategy,
    "ichimoku": IchimokuStrategy,
    "macd-crossover": MACDCrossoverStrategy,
    "rsi-divergence": RSIDivergenceStrategy,
    "vwap": VWAPStrategy,
    "btc-cycle": BTCCycleIndicator,
}


def get_strategy(name: str) -> type:
    """Lookup a strategy class by short name."""
    if name not in STRATEGY_REGISTRY:
        raise KeyError(f"Unknown strategy: {name}. Available: {list(STRATEGY_REGISTRY.keys())}")
    return STRATEGY_REGISTRY[name]


def list_strategies() -> list:
    """Return list of StrategyMeta for all registered strategies."""
    metas = []
    for slug, cls in sorted(STRATEGY_REGISTRY.items()):
        if hasattr(cls, 'meta'):
            metas.append(cls.meta())
        else:
            metas.append(slug)
    return metas


__all__ = [
    "STRATEGY_REGISTRY",
    "get_strategy",
    "list_strategies",
    "GridTradingStrategy",
    "FundingRateArbitrage",
    "DCAStrategy",
    "PairsTradingStrategy",
    "SectorRotationStrategy",
    "DividendHarvestStrategy",
    "TrendFollowingStrategy",
    "BreakoutStrategy",
    "MeanReversionBBStrategy",
    "MultiFactorStrategy",
    "BollingerStrategy",
    "MomentumStrategy",
    "MomentumRotationStrategy",
    "IchimokuStrategy",
    "MACDCrossoverStrategy",
    "RSIDivergenceStrategy",
    "VWAPStrategy",
    "BTCCycleIndicator",
]
