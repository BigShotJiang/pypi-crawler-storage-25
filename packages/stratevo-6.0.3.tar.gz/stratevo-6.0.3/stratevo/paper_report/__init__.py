"""stratevo.paper_report - Paper trading reports."""
