"""stratevo.sandbox - Strategy sandbox."""
