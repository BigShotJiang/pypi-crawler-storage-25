"""stratevo.plugins - Plugin system."""
