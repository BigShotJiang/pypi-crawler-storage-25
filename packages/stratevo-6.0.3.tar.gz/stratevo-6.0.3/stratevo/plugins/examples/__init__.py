"""stratevo.plugins.examples - Example plugins."""
