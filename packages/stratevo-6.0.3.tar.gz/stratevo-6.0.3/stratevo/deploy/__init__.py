"""stratevo.deploy - Deployment configuration."""

from stratevo.deploy.config import DeploymentConfig

__all__ = ["DeploymentConfig"]
