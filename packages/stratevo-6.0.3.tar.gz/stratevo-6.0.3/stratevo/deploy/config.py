"""
Deployment Configuration
========================
Manages deployment settings for StratEvo in containerized environments.
Reads configuration from environment variables with sensible defaults.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass
class DeploymentConfig:
    """Configuration for deploying StratEvo.

    Can be populated from environment variables via `from_env()`,
    or constructed directly with keyword arguments.
    """

    host: str = "0.0.0.0"
    port: int = 8080
    workers: int = 1
    log_level: str = "info"
    data_dir: str = "/app/data"
    cors_origin: str = "*"
    auth_enabled: bool = False
    api_key: str = ""
    max_requests: int = 100
    rate_limit_window: int = 60

    @classmethod
    def from_env(cls) -> "DeploymentConfig":
        """Create config from environment variables.

        Recognized env vars:
            STRATEVO_HOST, STRATEVO_PORT, STRATEVO_WORKERS,
            STRATEVO_LOG_LEVEL, STRATEVO_DATA_DIR, STRATEVO_CORS_ORIGIN,
            STRATEVO_AUTH_ENABLED, STRATEVO_API_KEY,
            STRATEVO_MAX_REQUESTS, STRATEVO_RATE_LIMIT_WINDOW
        """
        return cls(
            host=os.environ.get("STRATEVO_HOST", "0.0.0.0"),
            port=int(os.environ.get("STRATEVO_PORT", "8080")),
            workers=int(os.environ.get("STRATEVO_WORKERS", "1")),
            log_level=os.environ.get("STRATEVO_LOG_LEVEL", "info"),
            data_dir=os.environ.get("STRATEVO_DATA_DIR", "/app/data"),
            cors_origin=os.environ.get("STRATEVO_CORS_ORIGIN", "*"),
            auth_enabled=os.environ.get("STRATEVO_AUTH_ENABLED", "").lower() in ("1", "true", "yes"),
            api_key=os.environ.get("STRATEVO_API_KEY", ""),
            max_requests=int(os.environ.get("STRATEVO_MAX_REQUESTS", "100")),
            rate_limit_window=int(os.environ.get("STRATEVO_RATE_LIMIT_WINDOW", "60")),
        )

    def validate(self) -> bool:
        """Validate the configuration.

        Returns:
            True if configuration is valid, False otherwise.
        """
        if not (1 <= self.port <= 65535):
            return False
        if self.workers < 1:
            return False
        if self.log_level not in ("debug", "info", "warning", "error", "critical"):
            return False
        return True

    def to_env_string(self) -> str:
        """Generate .env file content from this configuration.

        Returns:
            String suitable for writing to a .env file.
        """
        lines = [
            f"STRATEVO_HOST={self.host}",
            f"STRATEVO_PORT={self.port}",
            f"STRATEVO_WORKERS={self.workers}",
            f"STRATEVO_LOG_LEVEL={self.log_level}",
            f"STRATEVO_DATA_DIR={self.data_dir}",
            f"STRATEVO_CORS_ORIGIN={self.cors_origin}",
            f"STRATEVO_AUTH_ENABLED={'true' if self.auth_enabled else 'false'}",
            f"STRATEVO_API_KEY={self.api_key}",
            f"STRATEVO_MAX_REQUESTS={self.max_requests}",
            f"STRATEVO_RATE_LIMIT_WINDOW={self.rate_limit_window}",
        ]
        return "\n".join(lines) + "\n"
