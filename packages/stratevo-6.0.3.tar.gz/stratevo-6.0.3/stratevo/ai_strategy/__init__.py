"""stratevo.ai_strategy - AI-powered strategy generation."""
