"""stratevo.derivatives - Options pricing and Greeks."""
