"""stratevo.paper - Paper trading engine."""
