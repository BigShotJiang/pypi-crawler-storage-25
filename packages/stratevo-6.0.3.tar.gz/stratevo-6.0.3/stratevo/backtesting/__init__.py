"""stratevo.backtesting - Backtesting engines and walk-forward analysis."""

from stratevo.backtesting.walk_forward import WalkForwardAnalyzer
from stratevo.backtesting.core_engine import BacktestEngine, BacktestResult

__all__ = [
    "WalkForwardAnalyzer",
    "BacktestEngine",
    "BacktestResult",
]

try:
    from stratevo.backtesting.event_engine import EventDrivenBacktester
    __all__.append("EventDrivenBacktester")
except ImportError:
    pass

try:
    from stratevo.backtesting.monte_carlo import MonteCarloSimulator
    __all__.append("MonteCarloSimulator")
except ImportError:
    pass

try:
    from stratevo.backtesting.realistic import RealisticBacktester
    __all__.append("RealisticBacktester")
except ImportError:
    pass
