"""stratevo.cli - Command-line interface."""
