"""
StratEvo CLI - Comprehensive argparse-based CLI
=====================================================
All commands work end-to-end with real data via yfinance.
"""

import argparse
import asyncio
import os
import sys
from datetime import datetime

# Ensure project root on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


from stratevo.cli.utils import _fetch_data, _calc_vol
from stratevo.cli.commands.backtest import (cmd_backtest, cmd_compare, cmd_scan_cn_backtest, cmd_check_backtest, cmd_regime)
from stratevo.cli.commands.market import (cmd_screen, cmd_analyze, cmd_price, cmd_scan_cn, cmd_trend_scan, cmd_trend_check, cmd_scan, cmd_market_check, cmd_chart, cmd_gainers, cmd_losers)
from stratevo.cli.commands.portfolio import (cmd_portfolio_track, cmd_paper_trade, cmd_paper_report, cmd_watch, cmd_watchlist, cmd_position_size, _handle_portfolio_tracker)
from stratevo.cli.commands.risk import (cmd_risk, cmd_risk_report)
from stratevo.cli.commands.crypto import (cmd_crypto, cmd_defi, cmd_defi_tvl, cmd_yields, cmd_stablecoins, cmd_btc_metrics, cmd_funding_rates, cmd_fear_greed, cmd_ccxt_quote, cmd_download_crypto, cmd_cn_realtime, cmd_cn_fundamentals, cmd_cn_fund_flow)
from stratevo.cli.commands.sentiment import (cmd_sentiment, cmd_news, cmd_trending, cmd_reddit_buzz)
from stratevo.cli.commands.strategy import (cmd_strategy, cmd_predict, cmd_evolve, cmd_compare_markets, cmd_pareto_front, cmd_alert)
from stratevo.cli.commands.report import (cmd_report, cmd_tearsheet, cmd_export)
from stratevo.cli.commands.misc import (cmd_interactive, cmd_options_price)



from stratevo.cli.utils import _get_version


def build_parser() -> argparse.ArgumentParser:
    """Build the full CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="stratevo",
        description=f"StratEvo v{_get_version()} — AI-Powered Financial Intelligence Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  stratevo backtest --strategy momentum --tickers AAPL,MSFT --start 2023-01-01 --benchmark SPY
  stratevo backtest --strategy momentum --ticker AAPL
  stratevo screen --criteria "rsi<30,pe<15,market_cap>1B" --universe sp500
  stratevo analyze --ticker AAPL --indicators rsi,macd,bollinger
  stratevo risk --portfolio portfolio.json
  stratevo portfolio track --file portfolio.json
  stratevo price --ticker AAPL,MSFT,GOOGL
  stratevo options price --type call --S 150 --K 155 --T 0.5 --r 0.05 --sigma 0.25
  stratevo paper-trade --strategy trend --tickers AAPL,MSFT --capital 100000
  stratevo report --input backtest_result.json --format html --output report.html
  stratevo report --data results.json
  stratevo interactive
""",
    )
    parser.add_argument("--version", action="version", version=f"stratevo {_get_version()}")
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # backtest
    p = sub.add_parser("backtest", help="Run strategy backtest")
    p.add_argument("--strategy", "-s", default="momentum", help="Strategy name")
    p.add_argument("--tickers", "-t", default=None, help="Comma-separated tickers")
    p.add_argument("--ticker", default=None, help="Single ticker (alias for --tickers)")
    p.add_argument("--start", default=None, help="Start date (YYYY-MM-DD)")
    p.add_argument("--end", default=None, help="End date (YYYY-MM-DD)")
    p.add_argument("--benchmark", "-b", default=None, help="Benchmark ticker")
    p.add_argument("--capital", "-c", type=float, default=None)
    p.add_argument("--output", "-o", help="Save results to JSON")

    # screen
    p = sub.add_parser("screen", help="Screen stocks by criteria")
    p.add_argument("--criteria", default=None, help='Filter criteria, e.g. "rsi<30,pe<15"')
    p.add_argument("--universe", default="sp500", help="Stock universe")
    p.add_argument("--min-volume", type=float, default=None, help="Minimum volume")
    p.add_argument("--max-volume", type=float, default=None, help="Maximum volume")
    p.add_argument("--min-price", type=float, default=None, help="Minimum price")
    p.add_argument("--max-price", type=float, default=None, help="Maximum price")
    p.add_argument("--change-above", type=float, default=None, help="Daily change %% above")
    p.add_argument("--change-below", type=float, default=None, help="Daily change %% below")
    p.add_argument("--rsi-above", type=float, default=None, help="RSI above")
    p.add_argument("--rsi-below", type=float, default=None, help="RSI below")
    p.add_argument("--min-mcap", type=float, default=None, help="Minimum market cap")
    p.add_argument("--max-mcap", type=float, default=None, help="Maximum market cap")
    p.add_argument("--limit", "-l", type=int, default=20, help="Number of results")

    # analyze
    p = sub.add_parser("analyze", help="Technical analysis")
    p.add_argument("ticker", nargs="?", default=None, help="Ticker symbol (positional)")
    p.add_argument("--ticker", "-t", dest="ticker_flag", default=None, help="Ticker symbol (flag)")
    p.add_argument("--indicators", "-i", default="rsi,macd,bollinger", help="Comma-separated indicators")

    # portfolio
    p_port = sub.add_parser("portfolio", help="Portfolio commands")
    port_sub = p_port.add_subparsers(dest="portfolio_cmd")
    p_track = port_sub.add_parser("track", help="Track portfolio from file")
    p_track.add_argument("--file", "-f", required=True, help="Portfolio JSON file")

    p_padd = port_sub.add_parser("add", help="Add a holding")
    p_padd.add_argument("symbol", help="Ticker symbol (e.g. BTC, AAPL)")
    p_padd.add_argument("quantity", type=float, help="Quantity to add")
    p_padd.add_argument("--price", type=float, default=0.0, help="Buy price per unit")
    p_padd.add_argument("--portfolio", default="main", help="Portfolio name")

    p_prm = port_sub.add_parser("remove", help="Remove a holding")
    p_prm.add_argument("symbol", help="Ticker symbol")
    p_prm.add_argument("quantity", type=float, help="Quantity to remove")
    p_prm.add_argument("--portfolio", default="main", help="Portfolio name")

    p_pshow = port_sub.add_parser("show", help="Show portfolio with P&L")
    p_pshow.add_argument("--portfolio", default="main", help="Portfolio name")

    p_phist = port_sub.add_parser("history", help="Portfolio value history")
    p_phist.add_argument("--portfolio", default="main", help="Portfolio name")

    p_palert = port_sub.add_parser("alert", help="Set price alert")
    p_palert.add_argument("symbol", help="Ticker symbol")
    p_palert.add_argument("--above", type=float, default=None, help="Alert when price above")
    p_palert.add_argument("--below", type=float, default=None, help="Alert when price below")
    p_palert.add_argument("--portfolio", default="main", help="Portfolio name")

    p_pexp = port_sub.add_parser("export", help="Export portfolio to CSV")
    p_pexp.add_argument("--format", default="csv", choices=["csv"], help="Export format")
    p_pexp.add_argument("--what", default="holdings", choices=["holdings", "history"])
    p_pexp.add_argument("--output", "-o", default=None, help="Output file")
    p_pexp.add_argument("--portfolio", default="main", help="Portfolio name")

    # price
    p = sub.add_parser("price", help="Get current prices")
    p.add_argument("--ticker", "-t", required=True, help="Comma-separated tickers")

    # options
    p_opts = sub.add_parser("options", help="Options commands")
    opts_sub = p_opts.add_subparsers(dest="options_cmd")
    p_oprice = opts_sub.add_parser("price", help="Price an option (Black-Scholes)")
    p_oprice.add_argument("--type", choices=["call", "put"], required=True)
    p_oprice.add_argument("--S", type=float, required=True, help="Spot price")
    p_oprice.add_argument("--K", type=float, required=True, help="Strike price")
    p_oprice.add_argument("--T", type=float, required=True, help="Time to expiry (years)")
    p_oprice.add_argument("--r", type=float, required=True, help="Risk-free rate")
    p_oprice.add_argument("--sigma", type=float, required=True, help="Volatility")

    # paper-trade (legacy)
    p = sub.add_parser("paper-trade", help="Paper trading simulation (legacy)")
    p.add_argument("--strategy", "-s", default="trend", help="Strategy name")
    p.add_argument("--tickers", "-t", required=True, help="Comma-separated tickers")
    p.add_argument("--capital", "-c", type=float, default=100000)

    # paper (new paper trading engine)
    p_paper = sub.add_parser("paper", help="Paper trading simulator")
    paper_sub = p_paper.add_subparsers(dest="paper_cmd")

    p_ps = paper_sub.add_parser("start", help="Start paper trading session")
    p_ps.add_argument("--balance", type=float, default=100000, help="Initial balance")
    p_ps.add_argument("--exchange", default="yahoo", help="Exchange adapter")

    p_pb = paper_sub.add_parser("buy", help="Buy shares")
    p_pb.add_argument("symbol", help="Ticker symbol")
    p_pb.add_argument("quantity", type=float, help="Number of shares")
    p_pb.add_argument("--type", default="market", choices=["market", "limit"])
    p_pb.add_argument("--limit-price", type=float, default=None)

    p_pse = paper_sub.add_parser("sell", help="Sell shares")
    p_pse.add_argument("symbol", help="Ticker symbol")
    p_pse.add_argument("quantity", type=float, help="Number of shares")
    p_pse.add_argument("--type", default="market", choices=["market", "limit"])
    p_pse.add_argument("--limit-price", type=float, default=None)

    paper_sub.add_parser("portfolio", help="Show portfolio")
    paper_sub.add_parser("pnl", help="Show P&L")
    paper_sub.add_parser("history", help="Show trade history")
    paper_sub.add_parser("dashboard", help="Show dashboard")

    p_prs = paper_sub.add_parser("run-strategy", help="Run a strategy")
    p_prs.add_argument("strategy", help="Strategy name (golden-cross, momentum)")
    p_prs.add_argument("--symbols", required=True, help="Comma-separated symbols")
    p_prs.add_argument("--ticks", type=int, default=10, help="Number of ticks to run")

    p_pj = paper_sub.add_parser("journal", help="Show trade journal")
    p_pj.add_argument("--export", choices=["csv", "json"], default=None)
    p_pj.add_argument("--date", default=None, help="Date for summary (YYYY-MM-DD)")

    paper_sub.add_parser("reset", help="Reset paper trading session")

    # report
    p = sub.add_parser("report", help="Generate report from results")
    p.add_argument("--input", "-i", default=None, help="Input JSON file")
    p.add_argument("--data", "-d", default=None, help="Input JSON file (alias for --input)")
    p.add_argument("--format", "-f", default="html", choices=["html", "json"])
    p.add_argument("--output", "-o", help="Output file path")

    # tearsheet
    p = sub.add_parser("tearsheet", help="Generate QuantStats-style tearsheet")
    p.add_argument("--returns", "-r", required=True, help="CSV file with daily returns (or JSON)")
    p.add_argument("--benchmark", "-b", default=None, help="Benchmark ticker (e.g. SPY) or CSV file")
    p.add_argument("--output", "-o", help="Output HTML file path")

    # compare (existing file-based)
    p = sub.add_parser("compare", help="Compare multiple strategies")
    p.add_argument("--strategies", "-s", nargs="+", required=True,
                   help="Strategy names (comma-sep) or JSON files with returns")
    p.add_argument("--data", "-d", "--tickers", default=None, help="Ticker symbol for backtest comparison")
    p.add_argument("--period", "-p", default="1y", help="Data period (e.g. 1y, 2y)")
    p.add_argument("--output", "-o", help="Output HTML file path")

    # export
    p_export = sub.add_parser("export", help="Export OHLCV + technical indicators to file")
    p_export.add_argument("--ticker", "-t", required=True, help="Ticker symbol")
    p_export.add_argument("--period", "-p", default="1y", help="Data period (e.g. 1y, 2y, 5y)")
    p_export.add_argument("--format", "-f", default="csv", choices=["csv", "json"], help="Output format")
    p_export.add_argument("--output", "-o", default=None, help="Output file path")
    p_export.add_argument("--indicators", "-i", default="sma20,sma50,rsi,macd", help="Indicators to include")

    # risk
    p = sub.add_parser("risk", help="Portfolio risk analysis")
    p.add_argument("--portfolio", "-p", required=True, help="Portfolio JSON file")
    p.add_argument("--output", "-o", help="Save risk report to JSON")

    # risk-report
    p = sub.add_parser("risk-report", help="Comprehensive risk report from return series or portfolio")
    p.add_argument("--returns", "-r", default=None, help="CSV/JSON file with daily returns")
    p.add_argument("--portfolio", "-p", default=None, help="Portfolio JSON file")
    p.add_argument("--ticker", "-t", default=None, help="Ticker symbol for quick analysis")
    p.add_argument("--period", default="1y", help="Data period (for --ticker)")
    p.add_argument("--output", "-o", help="Save report to JSON")

    # position-size
    p = sub.add_parser("position-size", help="Calculate position size for a trade")
    p.add_argument("--capital", "-c", type=float, required=True, help="Total capital")
    p.add_argument("--risk", "-r", type=float, default=2.0, help="Risk per trade (%%)")
    p.add_argument("--entry", type=float, default=None, help="Entry price")
    p.add_argument("--stop", type=float, default=None, help="Stop-loss price or %% distance")
    p.add_argument("--atr", type=float, default=None, help="ATR value for volatility sizing")
    p.add_argument("--method", "-m", default="fixed-fraction",
                   choices=["fixed-fraction", "kelly", "volatility", "equal-weight"],
                   help="Position sizing method")
    p.add_argument("--win-rate", type=float, default=None, help="Win rate for Kelly (0-1)")
    p.add_argument("--win-loss-ratio", type=float, default=None, help="Avg win / avg loss for Kelly")
    p.add_argument("--n-positions", type=int, default=None, help="Number of positions for equal-weight")

    # serve
    p = sub.add_parser("serve", help="Start REST API server")
    p.add_argument("--host", default="0.0.0.0", help="Bind host")
    p.add_argument("--port", "-p", type=int, default=8080, help="Port number")
    p.add_argument("--auth", action="store_true", help="Enable API key auth")
    p.add_argument("--rate-limit", type=int, default=100, help="Max requests per minute")

    # defi-tvl
    p_dtvl = sub.add_parser("defi-tvl", help="Top DeFi protocols by TVL (via DeFi Llama)")
    p_dtvl.add_argument("--limit", "-l", type=int, default=20, help="Number of protocols")

    # yields
    p_yields = sub.add_parser("yields", help="Best DeFi yield farming opportunities (via DeFi Llama)")
    p_yields.add_argument("--chain", default=None, help="Filter by chain (e.g. Ethereum, BSC)")
    p_yields.add_argument("--min-tvl", type=float, default=100_000, help="Minimum pool TVL in USD")
    p_yields.add_argument("--limit", "-l", type=int, default=20, help="Number of results")

    # stablecoins
    p_stbl = sub.add_parser("stablecoins", help="Stablecoin market overview (via DeFi Llama)")
    p_stbl.add_argument("--limit", "-l", type=int, default=20, help="Number of stablecoins")

    # btc-metrics
    sub.add_parser("btc-metrics", help="Show BTC on-chain metrics dashboard")

    # funding-rates
    p_fr = sub.add_parser("funding-rates", help="Multi-exchange funding rate comparison")
    p_fr.add_argument("--symbols", default="BTCUSDT,ETHUSDT,SOLUSDT", help="Comma-separated symbols")
    p_fr.add_argument("--min-spread", type=float, default=5.0, help="Min annualized spread %% for arbitrage")

    # fear-greed
    p_fng = sub.add_parser("fear-greed", help="Current Fear & Greed Index")
    p_fng.add_argument("--history", type=int, default=1, help="Number of historical data points")

    # ── crypto (RSI trading bot) ────────────────────────────────
    p_crypto = sub.add_parser("crypto", help="Crypto RSI trading bot commands")
    crypto_sub = p_crypto.add_subparsers(dest="crypto_cmd")
    p_csig = crypto_sub.add_parser("signals", help="Show BTC/ETH/SOL RSI signals")
    p_csig.add_argument("--symbols", default="BTC/USDT,ETH/USDT,SOL/USDT", help="Comma-separated symbols")
    p_cport = crypto_sub.add_parser("portfolio", help="Show crypto sandbox portfolio")

    # ── defi (DeFi monitor) ──────────────────────────────────────
    p_defi = sub.add_parser("defi", help="DeFi yield monitoring commands")
    defi_sub = p_defi.add_subparsers(dest="defi_cmd")
    p_dscan = defi_sub.add_parser("scan", help="Scan DeFi yield opportunities")
    p_dscan.add_argument("--chain", default="Arbitrum", help="Chain to scan")
    p_dscan.add_argument("--min-tvl", type=float, default=1_000_000, help="Minimum TVL in USD")
    p_dscan.add_argument("--min-apy", type=float, default=5.0, help="Minimum APY %%")
    p_dscan.add_argument("--limit", "-l", type=int, default=20, help="Number of results")
    p_drec = defi_sub.add_parser("recommend", help="Generate DeFi allocation recommendation")
    p_drec.add_argument("--budget", type=float, default=2000, help="Budget in USD")

    # watch (shortcut for watchlist with enhanced UX)
    p_w = sub.add_parser("watch", help="Quick watchlist commands")
    p_w.add_argument("watch_action", nargs="?", default="show",
                      choices=["show", "add", "remove", "create", "list"],
                      help="Action to perform")
    p_w.add_argument("watch_args", nargs="*", help="Tickers or watchlist name")
    p_w.add_argument("--name", "-n", default="default", help="Watchlist name")

    # gainers / losers
    p_gain = sub.add_parser("gainers", help="Top daily gainers")
    p_gain.add_argument("--limit", "-l", type=int, default=10, help="Number of results")
    p_gain.add_argument("--universe", default="sp500", help="Stock universe")

    p_lose = sub.add_parser("losers", help="Top daily losers")
    p_lose.add_argument("--limit", "-l", type=int, default=10, help="Number of results")
    p_lose.add_argument("--universe", default="sp500", help="Stock universe")

    # interactive
    sub.add_parser("interactive", help="Launch interactive mode")

    # cache
    p = sub.add_parser("cache", help="Cache management")
    p.add_argument("--stats", action="store_true")
    p.add_argument("--clear", action="store_true")

    # exchanges
    p_ex = sub.add_parser("exchanges", help="Exchange adapter commands")
    p_ex.add_argument("exchanges_cmd", nargs="?", default="list", choices=["list", "compare"])
    p_ex.add_argument("exchange_names", nargs="*", help="Exchanges to compare")

    # quote (multi-exchange, supports multiple symbols)
    p_q = sub.add_parser("quote", help="Get quote from any exchange")
    p_q.add_argument("symbol", nargs="+", help="Symbol(s) (e.g. AAPL TSLA MSFT)")
    p_q.add_argument("--exchange", "-e", default="yahoo", help="Exchange name")

    # history (multi-exchange)
    p_h = sub.add_parser("history", help="Get OHLCV history from any exchange")
    p_h.add_argument("symbol", help="Symbol")
    p_h.add_argument("--exchange", "-e", default="yahoo", help="Exchange name")
    p_h.add_argument("--timeframe", "-t", default="1d", help="Timeframe (1m,5m,1h,1d,...)")
    p_h.add_argument("--limit", "-l", type=int, default=20, help="Number of candles")

    # demo
    sub.add_parser("demo", help="Showcase all features with pre-baked data (no API key needed)")

    # web
    p_web = sub.add_parser("web", help="Launch Gradio web dashboard")
    p_web.add_argument("--port", type=int, default=7860, help="Port (default: 7860)")
    p_web.add_argument("--host", default="127.0.0.1", help="Host (default: 127.0.0.1)")
    p_web.add_argument("--share", action="store_true", help="Create public Gradio link")

    # info
    p_info = sub.add_parser("info", help="Show system info or ticker info")
    p_info.add_argument("ticker", nargs="?", default=None, help="Optional ticker symbol for detailed info")

    # doctor
    p_doctor = sub.add_parser("doctor", help="Diagnose environment: deps, API keys, connectivity")
    p_doctor.add_argument("--verbose", "-v", action="store_true", help="Show all checks, not just failures")
    p_doctor.add_argument("--skip-network", action="store_true", help="Skip network connectivity checks")

    # plugin
    p_plugin = sub.add_parser("plugin", help="Plugin management")
    plugin_sub = p_plugin.add_subparsers(dest="plugin_cmd")
    plugin_sub.add_parser("list", help="List installed/loaded plugins")
    p_pi = plugin_sub.add_parser("install", help="Install a plugin")
    p_pi.add_argument("source", help="Path to plugin .py file")
    p_pc = plugin_sub.add_parser("create", help="Create a new plugin from template")
    p_pc.add_argument("--type", dest="plugin_type", default="strategy", choices=["strategy", "indicator", "exchange"], help="Plugin type")
    p_pc.add_argument("--name", required=True, help="Plugin name")
    p_pinfo = plugin_sub.add_parser("info", help="Show plugin details")
    p_pinfo.add_argument("name", help="Plugin name")

    # plugins (new strategy plugin ecosystem)
    p_plugins = sub.add_parser("plugins", help="Strategy plugin ecosystem")
    plugins_sub = p_plugins.add_subparsers(dest="plugins_cmd")
    plugins_sub.add_parser("list", help="List all strategy plugins (built-in + installed)")
    p_plinfo = plugins_sub.add_parser("info", help="Show strategy plugin details")
    p_plinfo.add_argument("name", help="Plugin name")

    # init-strategy
    p_init_strat = sub.add_parser("init-strategy", help="Generate strategy plugin scaffolding")
    p_init_strat.add_argument("name", help="Strategy name (e.g. my_awesome_strategy)")
    p_init_strat.add_argument("--output", "-o", default=".", help="Output directory")

    # predict
    p_pred = sub.add_parser("predict", help="ML prediction engine")
    pred_sub = p_pred.add_subparsers(dest="predict_cmd")
    p_pred_run = pred_sub.add_parser("run", help="Run prediction on a symbol")
    p_pred_run.add_argument("--symbol", "-s", default=None, help="Ticker symbol")
    p_pred_run.add_argument("--ticker", dest="ticker_alias", default=None, help="Ticker symbol (alias for --symbol)")
    p_pred_run.add_argument("--model", "-m", default="gradient-boost",
                            choices=["linear", "decision-tree", "random-forest", "gradient-boost"],
                            help="Model to use")
    p_pred_run.add_argument("--features", "-f", default="rsi,macd,volatility",
                            help="Comma-separated features")
    p_pred_bt = pred_sub.add_parser("backtest", help="Walk-forward backtest")
    p_pred_bt.add_argument("--symbol", "-s", required=True, help="Ticker symbol")
    p_pred_bt.add_argument("--model", "-m", default="random-forest",
                           choices=["linear", "decision-tree", "random-forest", "gradient-boost"],
                           help="Model to use")
    p_pred_bt.add_argument("--train-size", type=int, default=252, help="Training window size")
    p_pred_bt.add_argument("--test-size", type=int, default=21, help="Test window size")
    p_pred_bt.add_argument("--walk-forward", action="store_true", default=True,
                           help="Use walk-forward validation")

    # MCP server
    p_mcp = sub.add_parser("mcp", help="MCP (Model Context Protocol) server for AI agents")
    mcp_sub = p_mcp.add_subparsers(dest="mcp_cmd")
    mcp_sub.add_parser("serve", help="Start MCP server (stdio JSON-RPC)")
    p_mcp_cfg = mcp_sub.add_parser("config", help="Generate MCP client config")
    p_mcp_cfg.add_argument("--client", "-c", default="claude", help="Client: claude, cursor, openclaw, vscode, generic")

    # watchlist
    p_wl = sub.add_parser("watchlist", help="Manage watchlists")
    wl_sub = p_wl.add_subparsers(dest="watchlist_cmd")
    p_wlc = wl_sub.add_parser("create", help="Create a watchlist")
    p_wlc.add_argument("name", help="Watchlist name")
    p_wlc.add_argument("symbols", nargs="*", help="Initial symbols")
    p_wlq = wl_sub.add_parser("quotes", help="Get quotes for a watchlist")
    p_wlq.add_argument("name", help="Watchlist name")
    p_wla = wl_sub.add_parser("add", help="Add symbol to watchlist")
    p_wla.add_argument("name", help="Watchlist name")
    p_wla.add_argument("symbol", help="Symbol to add")
    p_wlr = wl_sub.add_parser("remove", help="Remove symbol from watchlist")
    p_wlr.add_argument("name", help="Watchlist name")
    p_wlr.add_argument("symbol", help="Symbol to remove")
    p_wle = wl_sub.add_parser("export", help="Export watchlist")
    p_wle.add_argument("name", help="Watchlist name")
    p_wle.add_argument("--format", default="csv", choices=["csv", "json"])
    wl_sub.add_parser("list", help="List all watchlists")

    # sentiment (enhanced with social buzz)
    p_sent = sub.add_parser("sentiment", help="Sentiment analysis for a symbol")
    p_sent.add_argument("symbol", help="Ticker symbol (e.g. AAPL, BTCUSDT)")
    p_sent.add_argument("--reddit", action="store_true", help="Include Reddit sentiment")
    p_sent.add_argument("--buzz", action="store_true", help="Show full social buzz score")

    # reddit-buzz
    p_rb = sub.add_parser("reddit-buzz", help="Top buzzing tickers in a subreddit")
    p_rb.add_argument("subreddit", help="Subreddit name (e.g. wallstreetbets, CryptoCurrency)")
    p_rb.add_argument("--limit", "-l", type=int, default=50, help="Number of posts to scan")

    # news
    p_news = sub.add_parser("news", help="Get financial news for a symbol")
    p_news.add_argument("symbol", help="Ticker symbol")
    p_news.add_argument("--limit", "-l", type=int, default=10, help="Number of articles")
    p_news.add_argument("--search", "-s", default=None, help="Search query instead of symbol")

    # trending
    sub.add_parser("trending", help="Show trending financial topics and WSB tickers")

    # market-check (market environment filter)
    p_mc = sub.add_parser("market-check", help="Show current broad market environment assessment")
    p_mc.add_argument("--index", default="000001.SS", help="Market index ticker (default: 000001.SS 上证指数)")
    p_mc.add_argument("--period", default="3mo", help="Data period (default: 3mo)")

    # scan-cn (A-share scanner)
    p_scan_cn = sub.add_parser("scan-cn", help="Scan A-share (China) stocks for buy signals")
    p_scan_cn.add_argument("--top", type=int, default=30, help="Number of top stocks to scan (default: 30)")
    p_scan_cn.add_argument("--sector", default=None,
                           help="Filter by sector: bank, tech, consumer, energy, pharma, manufacturing, ai, optical, storage, chip, ev, solar, military, liquor, real_estate, telecom")
    p_scan_cn.add_argument("--min-score", type=int, default=0, help="Only show stocks with score >= N")
    p_scan_cn.add_argument("--sort", default="score",
                           choices=["score", "rsi", "price", "change"],
                           help="Sort results by field (default: score)")
    p_scan_cn.add_argument("--strategy", default="v1", choices=["v1"],
                           help="Scoring strategy")
    p_scan_cn.add_argument("--ml-version", default="v2", choices=["v1", "v2"],
                           help="ML feature version: v1 (20 features), v2 (40+ features, ensemble, default)")

    # scan-cn-backtest (A-share selection strategy backtest)
    p_scan_cn_bt = sub.add_parser("scan-cn-backtest",
                                  help="Backtest A-share selection strategy")
    p_scan_cn_bt.add_argument("--hold", type=int, default=5,
                              help="Hold period in trading days (1/3/5/10/20, default: 5)")
    p_scan_cn_bt.add_argument("--min-score", type=int, default=6,
                              help="Min score for stock selection (default: 6)")
    p_scan_cn_bt.add_argument("--period", default="6mo",
                              choices=["3mo", "6mo", "1y", "2y"],
                              help="Data period for yfinance (3mo, 6mo, 1y, 2y)")
    p_scan_cn_bt.add_argument("--lookback", type=int, default=30,
                              help="Number of recent trading days to evaluate (max depends on period)")
    p_scan_cn_bt.add_argument("--sector", default=None,
                              help="Limit backtest to a specific sector")
    p_scan_cn_bt.add_argument("--top", type=int, default=None,
                              help="Limit to top-N stocks")
    p_scan_cn_bt.add_argument("--strategy", default="v1", choices=["v1", "v2", "v3", "ml"],
                              help="Scoring strategy")
    p_scan_cn_bt.add_argument("--ml-version", default="v2", choices=["v1", "v2"],
                              help="ML feature version: v1 (20 features), v2 (40+ features, ensemble, default)")
    p_scan_cn_bt.add_argument("--stop-loss", type=float, default=None,
                              help="Stop-loss percentage (e.g. 3 = sell if price drops 3%%)")
    p_scan_cn_bt.add_argument("--take-profit", type=float, default=None,
                              help="Take-profit percentage (e.g. 8 = sell if price rises 8%%)")
    p_scan_cn_bt.add_argument("--trailing-stop", action="store_true", default=False,
                              help="Enable trailing stop (move stop to breakeven at 5%% profit)")

    # trend-scan (Trend Discovery — parallel long-term strategy)
    p_trend_scan = sub.add_parser("trend-scan",
                                  help="Scan A-share stocks for emerging long-term trend candidates")
    p_trend_scan.add_argument("--top", type=int, default=30, help="Number of top stocks to scan (default: 30)")
    p_trend_scan.add_argument("--sector", default=None,
                              help="Filter by sector (same values as scan-cn)")
    p_trend_scan.add_argument("--min-score", type=int, default=0, help="Only show stocks with score >= N")

    # trend-check (single-stock trend analysis)
    p_trend_check = sub.add_parser("trend-check",
                                   help="Check if a specific stock has long-term trend potential")
    p_trend_check.add_argument("code", help="Stock code (e.g. 688498)")
    p_trend_check.add_argument("--period", default="1y", help="Data period (e.g. 6mo, 1y, 2y)")

    # scan
    p_scan = sub.add_parser("scan", help="Real-time market scanner")
    p_scan.add_argument("--rule", required=True, help='Rule expression, e.g. "rsi<30 AND volume>2x"')
    p_scan.add_argument("--symbols", default="AAPL,MSFT,GOOGL,AMZN,TSLA", help="Comma-separated symbols")
    p_scan.add_argument("--exchange", "-e", default="yahoo", help="Exchange name")
    p_scan.add_argument("--interval", type=int, default=60, help="Scan interval in seconds")
    p_scan.add_argument("--once", action="store_true", help="Run only once")

    # strategy library
    p_strat = sub.add_parser("strategy", help="Built-in strategy library & YAML DSL")
    strat_sub = p_strat.add_subparsers(dest="strategy_cmd")
    strat_sub.add_parser("list", help="List all built-in strategies (classic + YAML)")
    p_si = strat_sub.add_parser("info", help="Show strategy details")
    p_si.add_argument("name", help="Strategy slug (e.g. grid-trading)")
    p_sb = strat_sub.add_parser("backtest", help="Backtest a built-in strategy")
    p_sb.add_argument("name", help="Strategy slug (e.g. trend-following)")
    p_sb.add_argument("--symbol", "-s", default="AAPL", help="Ticker symbol")
    p_sb.add_argument("--start", default="2024-01-01", help="Start date")
    p_sb.add_argument("--end", default=None, help="End date")
    p_sb.add_argument("--capital", type=float, default=10000, help="Initial capital")

    # YAML DSL strategy commands
    strat_sub.add_parser("create", help="Interactive YAML strategy builder")
    p_sv = strat_sub.add_parser("validate", help="Validate a YAML strategy file")
    p_sv.add_argument("file", help="Path to YAML strategy file")
    p_sbt = strat_sub.add_parser("dsl-backtest", help="Backtest a YAML strategy file")
    p_sbt.add_argument("file", help="Path to YAML strategy file")
    p_sbt.add_argument("--symbol", "-s", default="AAPL", help="Ticker symbol")
    p_sbt.add_argument("--period", "-p", default="2y", help="Data period (e.g. 1y, 2y)")
    p_sopt = strat_sub.add_parser("optimize", help="Optimize YAML strategy parameters")
    p_sopt.add_argument("file", help="Path to YAML strategy file")
    p_sopt.add_argument("--param", action="append", help="param:min:max:step (e.g. rsi_period:10:30:5)")
    p_sopt.add_argument("--symbol", "-s", default="AAPL", help="Ticker symbol")
    p_sopt.add_argument("--period", "-p", default="2y", help="Data period")

    # ── Alert commands ──────────────────────────────────────────
    p_alert = sub.add_parser("alert", help="Smart alert system")
    alert_sub = p_alert.add_subparsers(dest="alert_cmd")

    p_aa = alert_sub.add_parser("add", help="Add an alert rule")
    p_aa.add_argument("--symbol", "-s", required=True, help="Ticker symbol")
    p_aa.add_argument("--price-above", type=float, help="Alert when price above")
    p_aa.add_argument("--price-below", type=float, help="Alert when price below")
    p_aa.add_argument("--rsi-above", type=float, help="Alert when RSI above")
    p_aa.add_argument("--rsi-below", type=float, help="Alert when RSI below")
    p_aa.add_argument("--volume-spike", type=float, help="Alert on volume spike (multiplier)")
    p_aa.add_argument("--macd-cross", action="store_true", help="Alert on MACD crossover")
    p_aa.add_argument("--bb-breakout", action="store_true", help="Alert on Bollinger Band breakout")
    p_aa.add_argument("--drawdown", type=float, help="Alert on drawdown (e.g. 0.10 for 10%%)")
    p_aa.add_argument("--channel", default="console", help="Notification channel (console|webhook|file)")
    p_aa.add_argument("--cooldown", type=int, default=3600, help="Cooldown in seconds")

    alert_sub.add_parser("list", help="List active alert rules")

    p_ah = alert_sub.add_parser("history", help="Show alert history")
    p_ah.add_argument("--hours", type=int, default=24, help="Hours to look back")
    p_ah.add_argument("--export", choices=["json", "csv"], help="Export format")

    p_ar = alert_sub.add_parser("remove", help="Remove an alert rule")
    p_ar.add_argument("rule_id", type=int, help="Rule ID to remove")

    p_as = alert_sub.add_parser("start", help="Start alert engine")
    p_as.add_argument("--symbols", "-s", required=True, help="Comma-separated symbols")
    p_as.add_argument("--interval", type=int, default=60, help="Check interval in seconds")

    # ── Chart commands (viz) ───────────────────────────────────
    p_chart = sub.add_parser("chart", help="Terminal charts for symbols")
    p_chart.add_argument("symbol", help="Ticker symbol (e.g. AAPL, BTCUSDT)")
    p_chart.add_argument("--type", "-t", default="line", choices=["candle", "line", "bar", "histogram"],
                         help="Chart type")
    p_chart.add_argument("--period", "-p", default="6mo", help="Data period (e.g. 30d, 6mo, 1y)")
    p_chart.add_argument("--width", type=int, default=80, help="Chart width")
    p_chart.add_argument("--height", type=int, default=20, help="Chart height")

    # ── ccxt-quote (crypto via ccxt) ─────────────────────────────
    p_cq = sub.add_parser("ccxt-quote", help="Get crypto quote via ccxt (100+ exchanges)")
    p_cq.add_argument("symbol", help="Trading pair (e.g. BTC/USDT)")
    p_cq.add_argument("--exchange", "-e", default="binance", help="Exchange name (default: binance)")

    # ── cn-realtime (A-share real-time via AKShare) ──────────────
    p_cnrt = sub.add_parser("cn-realtime", help="Get real-time A-share quotes via AKShare")
    p_cnrt.add_argument("code_positional", nargs="?", default=None, help="Stock code (e.g. 600519)")
    p_cnrt.add_argument("--code", "-c", default=None, help="Stock code (e.g. 600438). Omit for all.")

    # ── cn-fundamentals (A-share fundamentals via AKShare) ───────
    p_cnf = sub.add_parser("cn-fundamentals", help="Get A-share fundamental data via AKShare")
    p_cnf.add_argument("--code", "-c", required=True, help="Stock code (e.g. 600438)")

    # ── cn-fund-flow (A-share capital flow via AKShare) ──────────
    p_cnff = sub.add_parser("cn-fund-flow", help="Get A-share capital flow data via AKShare")
    p_cnff.add_argument("--code", "-c", required=True, help="Stock code (e.g. 600438)")

    # ── A2A (Agent-to-Agent) protocol ─────────────────────────────
    p_a2a = sub.add_parser("a2a", help="A2A (Agent-to-Agent) protocol server")
    a2a_sub = p_a2a.add_subparsers(dest="a2a_cmd")
    p_a2a_serve = a2a_sub.add_parser("serve", help="Start A2A server")
    p_a2a_serve.add_argument("--host", default="localhost", help="Bind host")
    p_a2a_serve.add_argument("--port", type=int, default=8081, help="Bind port")
    p_a2a_serve.add_argument("--auth-token", default=None, help="Bearer auth token")
    a2a_sub.add_parser("card", help="Print the A2A agent card")

    # ── AI Strategy Generation ─────────────────────────────────
    p_gen = sub.add_parser("generate-strategy", help="AI-generate a trading strategy from natural language")
    p_gen.add_argument("description", nargs="?", default=None, help="Strategy description in plain English/中文")
    p_gen.add_argument("--interactive", action="store_true", help="Interactive multi-turn builder")
    p_gen.add_argument("--market", default="us_stock", choices=["us_stock", "crypto", "cn_stock"], help="Target market")
    p_gen.add_argument("--risk", default="medium", choices=["low", "medium", "high"], help="Risk profile")
    p_gen.add_argument("--provider", default=None, help="LLM provider (openai, anthropic, deepseek, ollama, ...)")
    p_gen.add_argument("--output", "-o", default=None, help="Save generated code to file")

    p_opt = sub.add_parser("optimize-strategy", help="AI-optimize an existing strategy")
    p_opt.add_argument("strategy_file", help="Path to strategy .py file")
    p_opt.add_argument("--data", "-d", default="AAPL", help="Ticker for backtesting")
    p_opt.add_argument("--period", "-p", default="1y", help="Data period (e.g. 1y, 2y)")
    p_opt.add_argument("--provider", default=None, help="LLM provider")

    sub.add_parser("copilot", help="Interactive AI financial assistant chat")

    # paper-report (automated daily paper trading report)
    p_pr = sub.add_parser("paper-report", help="Paper trading daily report & portfolio init")
    p_pr.add_argument("--init", action="store_true", help="Initialize US and CN paper portfolios")
    p_pr.add_argument("--date", default=None, help="Report date (YYYY-MM-DD), defaults to today")
    p_pr.add_argument("--skip-fetch", action="store_true", help="Skip fetching live market data")
    p_pr.add_argument("--data-dir", default=None, help="Override data directory")

    # regime (enhanced regime detection)
    p_regime = sub.add_parser("regime", help="Detect current market regime (bull/bear/sideways) using HMM")
    p_regime.add_argument("--symbol", "-s", required=True, help="Ticker symbol (e.g. AAPL, MSFT)")
    p_regime.add_argument("--period", "-p", default="1y", help="Data period (e.g. 6mo, 1y, 2y)")
    p_regime.add_argument("--lookback", type=int, default=20, help="Rolling window for regime features")
    p_regime.add_argument("--history", action="store_true", default=False, help="Show regime history over time")

    # check-backtest (economic plausibility checker)
    p_chkbt = sub.add_parser("check-backtest", help="Check backtest results for plausibility")

    # download-crypto
    p_dlc = sub.add_parser("download-crypto", help="Download historical crypto OHLCV data via ccxt")

    # pareto-front
    p_pf = sub.add_parser("pareto-front", help="Display the current Pareto front from multi-objective evolution")
    p_pf.add_argument("--results-dir", default="evolution_results", help="Directory with evolution results")
    p_pf.add_argument("--top", type=int, default=20, help="Number of strategies to display")
    p_pf.add_argument("--format", choices=["table", "json", "csv"], default="table", help="Output format")
    p_dlc.add_argument("--coins", default="BTC,ETH,SOL", help="Comma-separated coin names (default: BTC,ETH,SOL)")
    p_dlc.add_argument("--days", type=int, default=730, help="Number of days of history to download (default: 730)")

    # factor-decay
    p_fd = sub.add_parser("factor-decay", help="Detect factor decay via rolling IC monitoring")
    p_fd.add_argument("--data-dir", default=None, help="Path to CSV data directory (default: data/crypto_lite)")
    p_fd.add_argument("--window", type=int, default=60, help="Rolling IC window in bars (default: 60)")
    p_fd.add_argument("--ic-threshold", type=float, default=0.02, help="Minimum meaningful IC (default: 0.02)")
    p_fd.add_argument("--drop-threshold", type=float, default=0.5, help="Decay flag: latest IC < N * mean IC (default: 0.5)")

    # dashboard (evolution dashboard)
    from stratevo.web.evolution_dashboard import build_dashboard_parser
    build_dashboard_parser(sub)

    # discover-factors (LLM factor discovery)
    from stratevo.evolution.factor_discovery import build_discover_factors_parser
    build_discover_factors_parser(sub)

    # evolve
    p_evo = sub.add_parser("evolve", help="Run strategy evolution engine (genetic algorithm)")
    p_evo.add_argument("--market", default="crypto", choices=["crypto", "a-share", "cn", "us"],
                        help="Market type: crypto, a-share/cn, us (default: crypto)")
    p_evo.add_argument("--quick", action="store_true", default=False,
                        help="Quick mode: small dataset, fast iterations — see results in ~2 minutes")
    p_evo.add_argument("--demo", action="store_true", default=False,
                        help="Demo mode: use built-in sample data, zero setup — experience evolution in 30 seconds")
    p_evo.add_argument("--generations", type=int, default=None, help="Number of generations (default: 100, quick: 10)")
    p_evo.add_argument("--population", type=int, default=None, help="Population size (default: 30, quick: 15)")
    p_evo.add_argument("--data-dir", default=None, help="Path to CSV data directory")
    p_evo.add_argument("--results-dir", default="evolution_results", help="Directory for results (default: evolution_results)")
    p_evo.add_argument("--mutation-rate", type=float, default=None, help="Mutation rate 0.0-1.0 (default: 0.3, quick: 0.5)")
    p_evo.add_argument("--elite", type=int, default=None, help="Number of elite strategies to keep (default: 5, quick: 3)")
    p_evo.add_argument("--seed", type=int, default=None, help="Random seed for reproducibility")
    p_evo.add_argument("--save-interval", type=int, default=None, help="Save every N generations (default: 10, quick: 1)")
    p_evo.add_argument("--max-stocks", type=int, default=None, help="Max stocks to evaluate (default: 500, quick: 3)")
    p_evo.add_argument("--download", action="store_true", default=False,
                        help="Force re-download market data even if local CSVs exist")
    p_evo.add_argument("--symbols", default=None,
                        help="Comma-separated symbols to download (overrides defaults)")
    p_evo.add_argument("--pareto", action="store_true", default=False,
                        help="Enable multi-objective Pareto evolution (NSGA-III)")
    p_evo.add_argument("--pareto-complexity", action="store_true", default=False,
                        help="Include strategy complexity as 4th objective in Pareto mode")

    # compare-markets
    p_cmp = sub.add_parser("compare-markets", help="Compare strategy performance across different markets")
    p_cmp.add_argument("--dna", required=True, help="Path to DNA JSON file from evolution results")
    p_cmp.add_argument("--markets", default="cn,us,crypto", help="Comma-separated markets to test (default: cn,us,crypto)")
    p_cmp.add_argument("--data-dirs", default=None, help="Comma-separated data directories (optional, auto-detected)")
    p_cmp.add_argument("--output", default=None, help="Save comparison results to JSON file")
    p_chkbt.add_argument("--input", "-i", default=None, help="Backtest results JSON file to check")
    p_chkbt.add_argument("--sharpe", type=float, default=None, help="Sharpe ratio")
    p_chkbt.add_argument("--win-rate", type=float, default=None, help="Win rate (0-1)")
    p_chkbt.add_argument("--trades", type=int, default=0, help="Number of trades")
    p_chkbt.add_argument("--max-drawdown", type=float, default=None, help="Max drawdown (e.g. -0.15)")
    p_chkbt.add_argument("--total-return", type=float, default=None, help="Total return (e.g. 0.45)")
    p_chkbt.add_argument("--period-days", type=int, default=252, help="Backtest period in trading days")

    return parser


def _compare_exchanges(names: list[str]) -> None:
    """Print a feature comparison table for given exchanges."""
    from stratevo.exchanges.registry import ExchangeRegistry

    features = [
        ("OHLCV/Candles", "get_ohlcv"),
        ("Ticker", "get_ticker"),
        ("Orderbook", "get_orderbook"),
        ("Place Order", "place_order"),
        ("Cancel Order", "cancel_order"),
        ("Balance", "get_balance"),
        ("Positions", "get_positions"),
    ]
    # optional extras
    optional = [
        ("Trades", "get_trades"),
        ("Quotes", "get_quotes"),
        ("Fills", "get_fills"),
        ("Dividends", "get_dividends"),
        ("Industry", "get_industry"),
        ("Ticker Details", "get_ticker_details"),
        ("Market Status", "get_market_status"),
        ("Paper Trading", None),
    ]

    adapters = {}
    for name in names:
        try:
            adapters[name] = ExchangeRegistry.get(name)
        except KeyError:
            print(f"  ⚠ Exchange '{name}' not found, skipping")

    if not adapters:
        print("  No valid exchanges to compare.")
        return

    col_w = max(len(n) for n in adapters) + 2
    header = f"  {'Feature':<20}" + "".join(f"{n:^{col_w}}" for n in adapters)
    print(header)
    print("  " + "─" * (len(header) - 2))

    all_features = features + optional
    for label, method in all_features:
        row = f"  {label:<20}"
        for name, adapter in adapters.items():
            if method is None:
                # Special: paper trading
                has = hasattr(adapter, "paper") or hasattr(adapter, "PAPER_URL")
                row += f"{'✅':^{col_w}}" if has else f"{'—':^{col_w}}"
            elif hasattr(adapter, method):
                # Check if it raises NotImplementedError
                import inspect
                src = inspect.getsource(getattr(type(adapter), method))
                if "NotImplementedError" in src:
                    row += f"{'—':^{col_w}}"
                else:
                    row += f"{'✅':^{col_w}}"
            else:
                row += f"{'—':^{col_w}}"
        print(row)

    print()
    print("  Exchange types:")
    for name, adapter in adapters.items():
        print(f"    {name}: {adapter.exchange_type}")


def _cmd_a2a(args):
    """Handle 'stratevo a2a' subcommands."""
    if args.a2a_cmd == "card":
        from stratevo.a2a.agent_card import StratEvoAgentCard
        card = StratEvoAgentCard()
        print(card.to_json())
    elif args.a2a_cmd == "serve":
        from stratevo.a2a.server import run_server
        print(f"  🦀 StratEvo A2A server starting on http://{args.host}:{args.port}")
        print(f"  Agent card: http://{args.host}:{args.port}/.well-known/agent.json")
        asyncio.run(run_server(host=args.host, port=args.port, auth_token=args.auth_token))
    else:
        print("  Usage: stratevo a2a {serve,card}")


# Paper trading session state (persisted in memory for CLI session)
_paper_state_path = os.path.join(os.path.expanduser("~"), ".stratevo", "paper_state.json")


def _load_paper_engine():
    """Load or create paper trading engine."""
    import json as _json
    from stratevo.paper.engine import PaperTradingEngine
    engine = PaperTradingEngine()
    if os.path.exists(_paper_state_path):
        try:
            with open(_paper_state_path) as f:
                state = _json.load(f)
            engine = PaperTradingEngine(
                initial_balance=state.get("initial_balance", 100000),
                exchange=state.get("exchange", "yahoo"),
            )
            engine.balance = state.get("balance", engine.initial_balance)
            engine._realized_pnl = state.get("realized_pnl", 0.0)
            engine.trade_log = state.get("trade_log", [])
            from stratevo.paper.engine import Position
            for sym, pdata in state.get("positions", {}).items():
                engine.positions[sym] = Position(
                    symbol=sym,
                    quantity=pdata["quantity"],
                    avg_cost=pdata["avg_cost"],
                    current_price=pdata.get("current_price", 0),
                )
        except Exception:
            pass
    return engine


def _save_paper_engine(engine):
    """Persist paper trading engine state."""
    import json as _json
    os.makedirs(os.path.dirname(_paper_state_path), exist_ok=True)
    state = {
        "initial_balance": engine.initial_balance,
        "exchange": engine.exchange,
        "balance": engine.balance,
        "realized_pnl": engine._realized_pnl,
        "trade_log": engine.trade_log,
        "positions": {s: {"quantity": p.quantity, "avg_cost": p.avg_cost, "current_price": p.current_price}
                      for s, p in engine.positions.items()},
    }
    with open(_paper_state_path, "w") as f:
        _json.dump(state, f, indent=2)


def _handle_paper(args):
    """Handle paper trading subcommands."""
    from stratevo.paper.engine import PaperTradingEngine
    from stratevo.paper.dashboard import PaperDashboard
    from stratevo.paper.runner import StrategyRunner, BUILTIN_STRATEGIES
    from stratevo.paper.journal import TradeJournal

    cmd = getattr(args, "paper_cmd", None)
    if not cmd:
        print("  Usage: stratevo paper {start,buy,sell,portfolio,pnl,history,dashboard,run-strategy,journal,reset}")
        return

    if cmd == "start":
        engine = PaperTradingEngine(initial_balance=args.balance, exchange=args.exchange)
        _save_paper_engine(engine)
        print("  📄 Paper trading started!")
        print(f"  Balance: ${args.balance:,.2f} | Exchange: {args.exchange}")
        return

    if cmd == "reset":
        if os.path.exists(_paper_state_path):
            os.remove(_paper_state_path)
        print("  📄 Paper trading session reset.")
        return

    engine = _load_paper_engine()

    if cmd == "buy":
        order = engine.buy(args.symbol, args.quantity, getattr(args, "type", "market"), getattr(args, "limit_price", None))
        _save_paper_engine(engine)
        if order.status.value == "filled":
            print(f"  🟢 BUY {args.symbol} x{args.quantity} @${order.filled_price:.2f} = ${order.filled_price * args.quantity:,.2f}")
        else:
            reason = getattr(order, "reject_reason", "") or "Unknown reason"
            print(f"  ❌ Order rejected: {args.symbol} — {reason}")

    elif cmd == "sell":
        order = engine.sell(args.symbol, args.quantity, getattr(args, "type", "market"), getattr(args, "limit_price", None))
        _save_paper_engine(engine)
        if order.status.value == "filled":
            print(f"  🔴 SELL {args.symbol} x{args.quantity} @${order.filled_price:.2f}")
        else:
            reason = getattr(order, "reject_reason", "") or "Unknown reason"
            print(f"  ❌ Order rejected: {args.symbol} — {reason}")

    elif cmd == "portfolio":
        portfolio = engine.get_portfolio()
        print("\n  💼 Paper Portfolio")
        print(f"  Cash:      ${portfolio.cash:>12,.2f}")
        print(f"  Positions: ${portfolio.positions_value:>12,.2f}")
        print(f"  Total:     ${portfolio.total_value:>12,.2f}")
        print(f"  Return:    {portfolio.total_return:>+11.2f}%")
        if portfolio.positions:
            print(f"\n  {'Symbol':<8} {'Qty':>8} {'Avg':>10} {'Price':>10} {'P&L':>12}")
            for sym, pos in sorted(portfolio.positions.items()):
                print(f"  {sym:<8} {pos.quantity:>8.1f} ${pos.avg_cost:>9.2f} ${pos.current_price:>9.2f} ${pos.unrealized_pnl:>+11.2f}")

    elif cmd == "pnl":
        pnl = engine.get_pnl()
        print("\n  📊 Paper P&L")
        print(f"  Realized:   ${pnl.realized:>+12,.2f}")
        print(f"  Unrealized: ${pnl.unrealized:>+12,.2f}")
        print(f"  Total:      ${pnl.total:>+12,.2f}")
        print(f"  Return:     {pnl.total_return_pct:>+11.2f}%")
        if pnl.total_trades > 0:
            print(f"  Win Rate:   {pnl.win_rate:.1f}% ({pnl.win_count}W/{pnl.loss_count}L)")

    elif cmd == "history":
        trades = engine.get_trade_history()
        if not trades:
            print("  No trades yet.")
        else:
            for t in trades:
                ts = datetime.fromtimestamp(t["timestamp"]).strftime("%Y-%m-%d %H:%M")
                print(f"  {ts} {t['side']:<4} {t['symbol']:<6} x{t['quantity']:<8} @${t['price']:.2f}")

    elif cmd == "dashboard":
        dashboard = PaperDashboard()
        print(dashboard.render(engine))

    elif cmd == "run-strategy":
        strategy_name = args.strategy
        if strategy_name not in BUILTIN_STRATEGIES:
            print(f"  Unknown strategy: {strategy_name}")
            print(f"  Available: {', '.join(BUILTIN_STRATEGIES.keys())}")
            return
        symbols = [s.strip() for s in args.symbols.split(",")]
        strategy = BUILTIN_STRATEGIES[strategy_name]()
        runner = StrategyRunner(engine, strategy, symbols=symbols)
        for _ in range(args.ticks):
            runner.tick()
        _save_paper_engine(engine)
        stats = runner.get_stats()
        print(f"  📈 Strategy: {strategy_name}")
        print(f"  Ticks: {stats['ticks']} | Trades: {stats['trades']}")
        print(f"  P&L: ${stats['total_pnl']:+,.2f} | Win Rate: {stats['win_rate']:.1f}%")

    elif cmd == "journal":
        journal_path = os.path.join(os.path.expanduser("~"), ".stratevo", "paper_journal.json")
        journal = TradeJournal(journal_path)
        # Auto-record any trades from engine
        for t in engine.get_trade_history():
            journal.record_trade(t)
        if getattr(args, "export", None):
            print(journal.export(args.export))
        else:
            date = getattr(args, "date", None)
            print(journal.daily_summary(date))


def _cmd_generate_strategy(args):
    """Handle: stratevo generate-strategy"""
    from stratevo.ai_strategy.strategy_generator import StrategyGenerator
    import asyncio

    gen = StrategyGenerator(
        provider_name=args.provider,
        market=args.market,
        risk=args.risk,
    )

    if args.interactive:
        code = asyncio.run(gen.interactive_async())
        if code and args.output:
            with open(args.output, "w") as f:
                f.write(code)
            print(f"  Saved to {args.output}")
        elif code:
            print(f"\n{code}")
        return

    if not args.description:
        print("  Usage: stratevo generate-strategy \"description\" [--market us_stock] [--risk medium]")
        print("         stratevo generate-strategy --interactive")
        return

    print(f"  🤖 Generating strategy for: {args.description}")
    print(f"     Market: {args.market} | Risk: {args.risk}")
    result = gen.generate(args.description)

    if result["valid"]:
        print(f"  ✅ Generated: {result['class_name']}\n")
        print(result["code"])
        if args.output:
            with open(args.output, "w") as f:
                f.write(result["code"])
            print(f"\n  Saved to {args.output}")
    else:
        print(f"  ❌ Generation had issues: {result['errors']}")
        if result["code"]:
            print(result["code"])


def _cmd_optimize_strategy(args):
    """Handle: stratevo optimize-strategy"""
    from stratevo.ai_strategy.strategy_optimizer import StrategyOptimizer

    with open(args.strategy_file) as f:
        code = f.read()

    print(f"  🔧 Analyzing strategy: {args.strategy_file}")
    optimizer = StrategyOptimizer(provider_name=args.provider)

    # Simple backtest results placeholder — in production would run real backtest
    backtest_results = {
        "ticker": args.data,
        "period": args.period,
        "note": "Run a backtest first for real results. This is AI analysis of the code.",
    }

    result = optimizer.analyze(code, backtest_results)
    print(f"\n  📊 Analysis: {result.get('analysis', 'N/A')}")
    suggestions = result.get("suggestions", [])
    if suggestions:
        print("\n  💡 Suggestions:")
        for s in suggestions:
            print(f"    • {s.get('parameter', '?')}: {s.get('current', '?')} → {s.get('suggested', '?')} — {s.get('reason', '')}")
    print(f"\n  ⚠ Risk: {result.get('risk_assessment', 'N/A')}")


def _cmd_copilot(args):
    """Handle: stratevo copilot"""
    from stratevo.ai_strategy.copilot import StratEvoCopilot
    copilot = StratEvoCopilot()
    copilot.run_interactive()


def main(argv=None):
    """Main CLI entry point."""
    # Fix encoding on Windows (cp936/GBK can't handle Unicode box-drawing chars)
    import io
    if sys.stdout.encoding and sys.stdout.encoding.lower().replace('-', '') not in ('utf8', 'utf16'):
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')

    parser = build_parser()
    args = parser.parse_args(argv)

    if not args.command:
        parser.print_help()
        return 1

    try:
        if args.command == "backtest":
            cmd_backtest(args)
        elif args.command == "screen":
            cmd_screen(args)
        elif args.command == "analyze":
            cmd_analyze(args)
        elif args.command == "portfolio":
            if args.portfolio_cmd == "track":
                cmd_portfolio_track(args)
            elif args.portfolio_cmd in ("add", "remove", "show", "history", "alert", "export"):
                _handle_portfolio_tracker(args)
            else:
                print("  Usage: stratevo portfolio {add|remove|show|history|alert|export|track}")
        elif args.command == "price":
            cmd_price(args)
        elif args.command == "options":
            if args.options_cmd == "price":
                cmd_options_price(args)
            else:
                print("  Usage: stratevo options price --type call --S 150 --K 155 --T 0.5 --r 0.05 --sigma 0.25")
        elif args.command == "paper-trade":
            cmd_paper_trade(args)
        elif args.command == "paper":
            _handle_paper(args)
        elif args.command == "report":
            cmd_report(args)
        elif args.command == "tearsheet":
            cmd_tearsheet(args)
        elif args.command == "compare":
            cmd_compare(args)
        elif args.command == "export":
            cmd_export(args)
        elif args.command == "risk":
            cmd_risk(args)
        elif args.command == "risk-report":
            cmd_risk_report(args)
        elif args.command == "position-size":
            cmd_position_size(args)
        elif args.command == "serve":
            from stratevo.api.server import StratEvoAPI
            api = StratEvoAPI(
                host=args.host,
                port=args.port,
                auth_enabled=args.auth,
                max_requests=args.rate_limit,
            )
            api.start()
        elif args.command == "interactive":
            cmd_interactive(args)
        elif args.command == "btc-metrics":
            cmd_btc_metrics(args)
        elif args.command == "defi-tvl":
            cmd_defi_tvl(args)
        elif args.command == "yields":
            cmd_yields(args)
        elif args.command == "stablecoins":
            cmd_stablecoins(args)
        elif args.command == "funding-rates":
            cmd_funding_rates(args)
        elif args.command == "fear-greed":
            cmd_fear_greed(args)
        elif args.command == "crypto":
            cmd_crypto(args)
        elif args.command == "defi":
            cmd_defi(args)
        elif args.command == "cache":
            from stratevo.data.cache import DataCache
            cache = DataCache()
            if args.clear:
                cache.clear()
                print("  Cache cleared.")
            else:
                stats = cache.stats()
                print(f"  Entries: {stats['entries']} | Size: {stats['size_kb']:.1f} KB")
        elif args.command == "demo":
            from stratevo.cli.demo import run_demo
            run_demo()
        elif args.command == "web":
            from stratevo.web.app import create_app
            app = create_app()
            print("🦀 StratEvo Web UI starting...")
            app.launch(
                server_name=args.host,
                server_port=args.port,
                share=args.share,
            )
        elif args.command == "info":
            if args.ticker:
                # Show ticker info
                ticker = args.ticker.upper()
                df = _fetch_data(ticker, period="1y")
                if df is None:
                    print(f"  No data for {ticker}.")
                else:
                    close = df["Close"].tolist()
                    price = close[-1]
                    change = price - close[-2] if len(close) > 1 else 0
                    pct = change / close[-2] if len(close) > 1 else 0
                    hi = max(close)
                    lo = min(close)
                    vol = _calc_vol(close)
                    print(f"\n  ── {ticker} Info ──")
                    print(f"  Price:     ${price:.2f}")
                    print(f"  Change:    {change:+.2f} ({pct:+.2%})")
                    print(f"  52w High:  ${hi:.2f}")
                    print(f"  52w Low:   ${lo:.2f}")
                    print(f"  Ann. Vol:  {vol:.2%}")
                    print()
            else:
                print(f"  StratEvo v{_get_version()} — AI-Powered Financial Intelligence Engine\n")
                print("  📊 Market Data:    price, quote, history, chart, gainers, losers, ccxt-quote, cn-realtime")
                print("  📈 Analysis:       analyze, screen, scan, scan-cn, trend-scan, trend-check, market-check")
                print("  🤖 Backtesting:    backtest, compare, check-backtest, scan-cn-backtest, regime")
                print("  💼 Portfolio:      portfolio, watch, watchlist, paper, paper-trade, paper-report")
                print("  📉 Risk:           risk, risk-report, position-size")
                print("  📰 Sentiment:      sentiment, news, trending, reddit-buzz, fear-greed")
                print("  🌾 DeFi/Crypto:    defi, defi-tvl, yields, stablecoins, btc-metrics, funding-rates, crypto")
                print("  🧠 AI/ML:          predict, generate-strategy, optimize-strategy, copilot, evolve")
                print("  🔧 Strategy:       strategy, plugins, plugin, init-strategy")
                print("  📤 Output:         report, tearsheet, export")
                print("  ⚙️  System:         info, doctor, cache, serve, mcp, a2a, download-crypto, demo")
                print("\n  Run 'stratevo <command> --help' for details on any command.")
        elif args.command == "doctor":
            from stratevo.cli.doctor import run_doctor, format_doctor_output
            results = run_doctor(skip_network=getattr(args, "skip_network", False))
            print(format_doctor_output(results, verbose=getattr(args, "verbose", False)))
            required_fails = [r for r in results if not r.passed and r.severity.value == "required"]
            return 1 if required_fails else 0
        elif args.command == "exchanges":
            from stratevo.exchanges.registry import ExchangeRegistry
            if getattr(args, "exchanges_cmd", "list") == "compare":
                _compare_exchanges(args.exchange_names if args.exchange_names else ExchangeRegistry.list_exchanges())
            else:
                print("  Available exchanges:")
                for etype in ("crypto", "stock_us", "stock_cn"):
                    names = ExchangeRegistry.list_by_type(etype)
                    if names:
                        print(f"    [{etype}] {', '.join(names)}")
        elif args.command == "quote":
            from stratevo.exchanges.registry import ExchangeRegistry
            from stratevo.cli.colors import bold, price_color, pct_color
            # Auto-route crypto pairs (containing "/") to ccxt
            exchange = args.exchange
            symbols = args.symbol  # now a list
            _ccxt_probe_ticker = None  # cache the probe result for reuse
            if any("/" in s for s in symbols) and exchange == "yahoo":
                # Try multiple exchanges for accessibility
                try:
                    from stratevo.exchanges.ccxt_adapter import CCXTAdapter
                    adapter = None
                    for ex_id in ("okx", "bybit", "binance"):
                        try:
                            candidate = CCXTAdapter(exchange_id=ex_id)
                            t = candidate.get_ticker(symbols[0])
                            if "error" not in t:
                                adapter = candidate
                                exchange = ex_id
                                _ccxt_probe_ticker = t  # reuse later
                                break
                        except Exception:
                            pass
                    if adapter is None:
                        print("  ERROR: Could not connect to any crypto exchange for quote.")
                        return 1
                except ImportError:
                    print("  ERROR: ccxt not installed — required for crypto pair quotes.")
                    print("  Install crypto extras:  pip install stratevo[crypto]")
                    print("  Or directly:            pip install ccxt")
                    return 1
            else:
                adapter = ExchangeRegistry.get(exchange)
            if len(symbols) == 1:
                # Single symbol — detailed view
                ticker = _ccxt_probe_ticker or adapter.get_ticker(symbols[0])
                last = ticker.get('last') or ticker.get('price')
                bid = ticker.get('bid', 'N/A')
                ask = ticker.get('ask', 'N/A')
                vol = ticker.get('volume', 'N/A')
                chg = ticker.get('change', 0) or 0
                chg_pct = ticker.get('change_pct', 0) or 0
                chg_str = price_color(chg, f"{chg:>+.2f}") if chg else ""
                pct_str = pct_color(chg_pct / 100, f"{chg_pct:>+.2f}%") if chg_pct else ""
                print(f"\n  {bold(ticker['symbol'])}  {bold(f'${last:.2f}' if isinstance(last, (int,float)) else str(last))}  {chg_str} {pct_str}")
                print(f"  Bid: {bid}  Ask: {ask}  Vol: {vol:,.0f}" if isinstance(vol, (int,float)) else f"  Bid: {bid}  Ask: {ask}  Vol: {vol}")
                print()
            else:
                # Multi-symbol — table view
                print(f"\n  {bold('Symbol'):<18} {bold('Price'):>10} {bold('Change'):>10} {bold('%'):>10} {bold('Volume'):>14}")
                print("  " + "─" * 62)
                for sym in symbols:
                    try:
                        ticker = adapter.get_ticker(sym)
                        last = ticker.get('last') or ticker.get('price')
                        chg = ticker.get('change', 0) or 0
                        chg_pct = ticker.get('change_pct', 0) or 0
                        vol = ticker.get('volume', 'N/A')
                        price_str = f"${last:.2f}" if isinstance(last, (int, float)) else str(last)
                        chg_str = price_color(chg, f"{chg:>+.2f}")
                        pct_str = pct_color(chg_pct / 100, f"{chg_pct:>+.2f}%")
                        vol_str = f"{vol:>14,.0f}" if isinstance(vol, (int, float)) else f"{vol:>14}"
                        print(f"  {sym:<10} {price_str:>10} {chg_str:>10} {pct_str:>10} {vol_str}")
                    except Exception as e:
                        print(f"  {sym:<10} {'Error':>10} {str(e)[:30]}")
                print()
        elif args.command == "history":
            from stratevo.exchanges.registry import ExchangeRegistry
            adapter = ExchangeRegistry.get(args.exchange)
            candles = adapter.get_ohlcv(args.symbol, args.timeframe, args.limit)
            print(f"  {args.symbol} ({args.exchange}) — {len(candles)} candles [{args.timeframe}]")
            print(f"  {'Date/Time':<20} {'Open':>10} {'High':>10} {'Low':>10} {'Close':>10} {'Volume':>12}")
            for c in candles[-args.limit:]:
                ts_raw = c['timestamp']
                try:
                    # Timestamps from exchanges are typically in milliseconds
                    ts_seconds = ts_raw / 1000 if ts_raw > 1e12 else ts_raw
                    ts = datetime.fromtimestamp(ts_seconds).strftime("%Y-%m-%d %H:%M")
                except (OSError, ValueError, TypeError):
                    ts = str(ts_raw)[:20]
                print(f"  {ts:<20} {c['open']:>10.4f} {c['high']:>10.4f} {c['low']:>10.4f} {c['close']:>10.4f} {c['volume']:>12.0f}")
        elif args.command == "plugin":
            from stratevo.plugins.plugin_manager import PluginManager
            pm = PluginManager()
            if args.plugin_cmd == "list":
                available = pm.discover()
                loaded = pm.load_all()
                if not available and not loaded:
                    print("  No plugins found.")
                    print(f"  Plugin directory: {pm.plugin_dir}")
                    print("  Use 'stratevo plugin create --type strategy --name my_strategy' to create one.")
                else:
                    print(f"  Plugins ({len(loaded)} loaded):")
                    for p in loaded:
                        status = "✓" if p.active else "✗"
                        print(f"    {status} {p.name} v{p.version} [{p.plugin_type}] — {p.description}")
            elif args.plugin_cmd == "install":
                info = pm.install(args.source)
                print(f"  Installed: {info.name} v{info.version} [{info.plugin_type}]")
            elif args.plugin_cmd == "create":
                path = pm.create(args.name, args.plugin_type)
                print(f"  Created {args.plugin_type} plugin: {path}")
            elif args.plugin_cmd == "info":
                pm.load_all()
                info = pm.get_plugin(args.name)
                if info:
                    print(f"  Name:        {info.name}")
                    print(f"  Version:     {info.version}")
                    print(f"  Type:        {info.plugin_type}")
                    print(f"  Description: {info.description}")
                    print(f"  Path:        {info.path}")
                    print(f"  Active:      {info.active}")
                else:
                    print(f"  Plugin not found: {args.name}")
            else:
                print("  Usage: stratevo plugin [list|install|create|info]")
        elif args.command == "plugins":
            from stratevo.plugin_system.registry import StrategyRegistry
            registry = StrategyRegistry()
            registry.load_all()
            if args.plugins_cmd == "list":
                plugins = registry.list()
                if not plugins:
                    print("  No strategy plugins found.")
                else:
                    print(f"  Strategy Plugins ({len(plugins)}):")
                    print(f"  {'Name':<25} {'Version':<10} {'Risk':<8} {'Markets':<30} Description")
                    print(f"  {'-'*25} {'-'*10} {'-'*8} {'-'*30} {'-'*30}")
                    for p in plugins:
                        markets = ", ".join(p.markets)
                        print(f"  {p.name:<25} {p.version:<10} {p.risk_level:<8} {markets:<30} {p.description}")
            elif args.plugins_cmd == "info":
                p = registry.get(args.name)
                if p:
                    print(f"  Name:        {p.name}")
                    print(f"  Version:     {p.version}")
                    print(f"  Author:      {p.author}")
                    print(f"  Description: {p.description}")
                    print(f"  Risk Level:  {p.risk_level}")
                    print(f"  Markets:     {', '.join(p.markets)}")
                    params = p.get_parameters()
                    if params:
                        print(f"  Parameters:  {params}")
                    config = p.backtest_config()
                    if config:
                        print(f"  Backtest:    {config}")
                    issues = p.validate()
                    if issues:
                        print(f"  ⚠ Issues:    {issues}")
                else:
                    print(f"  Plugin not found: {args.name}")
                    print(f"  Available: {', '.join(registry.names())}")
            else:
                print("  Usage: stratevo plugins [list|info <name>]")
        elif args.command == "init-strategy":
            name = args.name
            output = args.output
            pkg_name = f"stratevo_strategy_{name}"
            pkg_dir = os.path.join(output, f"stratevo-strategy-{name}")
            os.makedirs(os.path.join(pkg_dir, pkg_name), exist_ok=True)
            os.makedirs(os.path.join(pkg_dir, "tests"), exist_ok=True)

            class_name = name.replace("_", " ").title().replace(" ", "")

            # pyproject.toml
            with open(os.path.join(pkg_dir, "pyproject.toml"), "w") as f:
                f.write(f'''[build-system]
requires = ["setuptools>=68.0", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "stratevo-strategy-{name}"
version = "0.1.0"
description = "StratEvo strategy plugin: {name}"
license = {{text = "MIT"}}
requires-python = ">=3.9"
dependencies = ["pandas>=1.3.0"]

[project.entry-points."stratevo.strategies"]
{name} = "{pkg_name}.strategy:{class_name}Strategy"
''')

            # __init__.py
            with open(os.path.join(pkg_dir, pkg_name, "__init__.py"), "w") as f:
                f.write(f'from {pkg_name}.strategy import {class_name}Strategy\n')

            # strategy.py
            with open(os.path.join(pkg_dir, pkg_name, "strategy.py"), "w") as f:
                f.write(f'''"""
{class_name} Strategy Plugin for StratEvo
"""
import pandas as pd
from stratevo.plugin_system.plugin_types import StrategyPlugin


class {class_name}Strategy(StrategyPlugin):
    name = "{name}"
    version = "0.1.0"
    description = "TODO: describe your strategy"
    author = "Your Name"
    risk_level = "medium"
    markets = ["us_stock"]

    def generate_signals(self, data: pd.DataFrame) -> pd.Series:
        signals = pd.Series(0, index=data.index)
        # TODO: implement your signal logic
        # 1 = buy, -1 = sell, 0 = hold
        return signals

    def get_parameters(self) -> dict:
        return {{}}
''')

            # README
            with open(os.path.join(pkg_dir, "README.md"), "w") as f:
                f.write(f'# stratevo-strategy-{name}\\n\\nStratEvo strategy plugin.\\n\\n```bash\\npip install -e .\\nstratevo plugins list\\n```\\n')

            # test
            with open(os.path.join(pkg_dir, "tests", f"test_{name}.py"), "w") as f:
                f.write(f'''import pandas as pd
import numpy as np
from {pkg_name}.strategy import {class_name}Strategy

def test_signals():
    df = pd.DataFrame({{"Close": np.random.randn(100).cumsum() + 100}},
                       index=pd.date_range("2020-01-01", periods=100))
    s = {class_name}Strategy()
    signals = s.generate_signals(df)
    assert len(signals) == 100
''')

            print(f"  OK Created strategy plugin scaffold: {pkg_dir}")
            print(f"    {pkg_dir}/")
            print("    +-- pyproject.toml")
            print("    +-- README.md")
            print(f"    +-- {pkg_name}/")
            print("    |   +-- __init__.py")
            print("    |   +-- strategy.py")
            print("    +-- tests/")
            print(f"        +-- test_{name}.py")
            print("\n  Next steps:")
            print(f"    cd {pkg_dir}")
            print("    pip install -e .")
            print("    stratevo plugins list")
        elif args.command == "mcp":
            if args.mcp_cmd == "serve":
                from stratevo.mcp.server import StratEvoMCPServer
                from stratevo.mcp.protocol import MCPProtocol
                server = StratEvoMCPServer()
                protocol = MCPProtocol(server)
                protocol.run()
            elif args.mcp_cmd == "config":
                from stratevo.mcp.config import MCPConfigGenerator
                MCPConfigGenerator.print_config(args.client)
            else:
                print("  Usage: stratevo mcp [serve|config]")
        elif args.command == "watchlist":
            cmd_watchlist(args)
        elif args.command == "watch":
            cmd_watch(args)
        elif args.command == "gainers":
            cmd_gainers(args)
        elif args.command == "losers":
            cmd_losers(args)
        elif args.command == "sentiment":
            cmd_sentiment(args)
        elif args.command == "reddit-buzz":
            cmd_reddit_buzz(args)
        elif args.command == "news":
            cmd_news(args)
        elif args.command == "trending":
            cmd_trending(args)
        elif args.command == "market-check":
            cmd_market_check(args)
        elif args.command == "scan-cn":
            cmd_scan_cn(args)
        elif args.command == "scan-cn-backtest":
            cmd_scan_cn_backtest(args)
        elif args.command == "trend-scan":
            cmd_trend_scan(args)
        elif args.command == "trend-check":
            cmd_trend_check(args)
        elif args.command == "scan":
            cmd_scan(args)
        elif args.command == "strategy":
            cmd_strategy(args)
        elif args.command == "predict":
            cmd_predict(args)
        elif args.command == "alert":
            cmd_alert(args)
        elif args.command == "chart":
            cmd_chart(args)
        elif args.command == "a2a":
            _cmd_a2a(args)
        elif args.command == "generate-strategy":
            _cmd_generate_strategy(args)
        elif args.command == "optimize-strategy":
            _cmd_optimize_strategy(args)
        elif args.command == "copilot":
            _cmd_copilot(args)
        elif args.command == "paper-report":
            cmd_paper_report(args)
        elif args.command == "regime":
            cmd_regime(args)
        elif args.command == "check-backtest":
            cmd_check_backtest(args)
        elif args.command == "ccxt-quote":
            cmd_ccxt_quote(args)
        elif args.command == "cn-realtime":
            cmd_cn_realtime(args)
        elif args.command == "cn-fundamentals":
            cmd_cn_fundamentals(args)
        elif args.command == "cn-fund-flow":
            cmd_cn_fund_flow(args)
        elif args.command == "download-crypto":
            cmd_download_crypto(args)
        elif args.command == "evolve":
            cmd_evolve(args)
        elif args.command == "compare-markets":
            cmd_compare_markets(args)
        elif args.command == "dashboard":
            from stratevo.web.evolution_dashboard import cmd_dashboard
            cmd_dashboard(args)
        elif args.command == "discover-factors":
            from stratevo.evolution.factor_discovery import cmd_discover_factors
            cmd_discover_factors(args)
        elif args.command == "pareto-front":
            cmd_pareto_front(args)
        elif args.command == "factor-decay":
            from stratevo.analytics.factor_decay import analyze_data_dir, format_decay_output
            data_dir = args.data_dir
            if data_dir is None:
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
                data_dir = os.path.join(project_root, "data", "crypto_lite")
            if not os.path.isdir(data_dir):
                print(f"  ERROR: data directory not found: {data_dir}")
                print("  Download data first:  stratevo download-crypto --coins BTC,ETH,SOL")
                print("  Or specify a directory:  stratevo factor-decay --data-dir path/to/data")
                return 1
            results = analyze_data_dir(
                data_dir,
                window=args.window,
                ic_threshold=args.ic_threshold,
                drop_threshold=args.drop_threshold,
            )
            print(format_decay_output(results))
        else:
            parser.print_help()
    except KeyboardInterrupt:
        print("\n  Interrupted.")
        return 130
    except Exception as e:
        print(f"\n  ERROR: {e}")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
