"""StratEvo CLI - Shared utility functions."""
import math
import os
import sys

# Ensure project root on path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))


def _get_version() -> str:
    """Read version from pyproject.toml so CLI always matches the package version."""
    try:
        import importlib.metadata
        return importlib.metadata.version("stratevo-ai")
    except Exception:
        pass
    # Fallback: parse pyproject.toml manually
    try:
        import pathlib
        import re
        pyproject = pathlib.Path(__file__).resolve().parents[2] / "pyproject.toml"
        text = pyproject.read_text(encoding="utf-8")
        m = re.search(r'^version\s*=\s*"([^"]+)"', text, re.MULTILINE)
        if m:
            return m.group(1)
    except Exception:
        pass
    return "0.0.0"



def _fetch_data(ticker: str, start: str = None, end: str = None, period: str = "5y"):
    """Fetch price data via yfinance with cache."""
    from stratevo.data.cache import DataCache
    import logging
    import warnings

    cache = DataCache()
    cache_key = f"{ticker}_{start or ''}_{end or ''}_{period}"
    cached = cache.get(cache_key, max_age_hours=24)
    if cached is not None:
        return cached

    try:
        import yfinance as yf
        logging.getLogger("yfinance").setLevel(logging.CRITICAL)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            stock = yf.Ticker(ticker)
            if start:
                df = stock.history(start=start, end=end)
            else:
                df = stock.history(period=period)
        if df.empty or len(df) < 2:
            return None
        cache.set(cache_key, df)
        return df
    except Exception as e:
        print(f"  ERROR fetching {ticker}: {e}")
        return None


def _calc_vol(prices) -> float:
    """Annualized volatility from price series."""
    if len(prices) < 2:
        return 0
    rets = [prices[i] / prices[i - 1] - 1 for i in range(1, len(prices))]
    mean = sum(rets) / len(rets)
    var = sum((r - mean) ** 2 for r in rets) / (len(rets) - 1)
    return var ** 0.5 * math.sqrt(252)


# ────────────────────────────────────────────────────────────────
# Commands
# ────────────────────────────────────────────────────────────────

