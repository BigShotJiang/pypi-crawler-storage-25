"""stratevo.reports - Report generation."""
