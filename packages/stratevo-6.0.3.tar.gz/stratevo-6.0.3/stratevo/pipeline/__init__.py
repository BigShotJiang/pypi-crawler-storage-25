"""stratevo.pipeline - Data pipeline utilities."""
