"""stratevo.notifications - Notification channels."""
