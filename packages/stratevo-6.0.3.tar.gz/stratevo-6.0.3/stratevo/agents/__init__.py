"""stratevo.agents - Trading agents."""
