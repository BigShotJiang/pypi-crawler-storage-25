"""stratevo.events - Event bus for internal messaging."""

from stratevo.events.event_bus import EventBus

__all__ = ["EventBus"]
