"""stratevo.journal - Trade journaling."""
