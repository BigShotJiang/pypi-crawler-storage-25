"""
stratevo.ta — Technical Analysis convenience API.

Provides simple list-in / array-out functions that modules like
cn_scanner, backtest, alert_engine, etc. import.

Functions accept plain lists or numpy arrays of prices and return
numpy arrays (or tuples of arrays).
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple, Union

import numpy as np

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

Numeric = Union[List[float], "np.ndarray"]


def _to_list(arr: Numeric) -> List[float]:
    """Convert input to plain Python list of float."""
    if isinstance(arr, np.ndarray):
        return arr.tolist()
    return list(arr)


def _mean(values: List[float]) -> float:
    return sum(values) / len(values) if values else 0.0


# ---------------------------------------------------------------------------
# SMA / EMA
# ---------------------------------------------------------------------------

def sma(prices: Numeric, period: int) -> np.ndarray:
    """Simple Moving Average.  Returns array of same length; NaN-padded."""
    p = _to_list(prices)
    n = len(p)
    out = [float("nan")] * n
    if n < period:
        return np.array(out)
    window_sum = sum(p[:period])
    out[period - 1] = window_sum / period
    for i in range(period, n):
        window_sum += p[i] - p[i - period]
        out[i] = window_sum / period
    return np.array(out)


def wma(prices: Numeric, period: int) -> np.ndarray:
    """Weighted Moving Average.  NaN-padded."""
    p = _to_list(prices)
    n = len(p)
    out = [float("nan")] * n
    if n < period:
        return np.array(out)
    denom = period * (period + 1) / 2
    for i in range(period - 1, n):
        val = sum(p[i - period + 1 + j] * (j + 1) for j in range(period))
        out[i] = val / denom
    return np.array(out)


def ema(prices: Numeric, period: int) -> np.ndarray:
    """Exponential Moving Average.  Seed = first price."""
    p = _to_list(prices)
    if not p:
        return np.array([])
    alpha = 2.0 / (period + 1)
    out = [p[0]]
    for i in range(1, len(p)):
        out.append(alpha * p[i] + (1 - alpha) * out[-1])
    return np.array(out)


def dema(prices: Numeric, period: int) -> np.ndarray:
    """Double Exponential Moving Average.  DEMA = 2*EMA - EMA(EMA)."""
    e1 = ema(prices, period)
    e2 = ema(e1.tolist(), period)
    return 2 * e1 - e2


def tema(prices: Numeric, period: int) -> np.ndarray:
    """Triple Exponential Moving Average.  TEMA = 3*EMA - 3*EMA(EMA) + EMA(EMA(EMA))."""
    e1 = ema(prices, period)
    e2 = ema(e1.tolist(), period)
    e3 = ema(e2.tolist(), period)
    return 3 * e1 - 3 * e2 + e3


# ---------------------------------------------------------------------------
# Ichimoku Cloud
# ---------------------------------------------------------------------------

def ichimoku(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    tenkan: int = 9,
    kijun: int = 26,
    senkou_b: int = 52,
) -> dict:
    """Ichimoku Cloud.

    Returns dict with keys: tenkan, kijun, senkou_a, senkou_b, chikou.
    All NaN-padded numpy arrays of same length as input.
    """
    h = _to_list(highs)
    l = _to_list(lows)
    c = _to_list(closes)
    n = len(c)

    ts = [float("nan")] * n  # Tenkan-sen
    ks = [float("nan")] * n  # Kijun-sen
    sa = [float("nan")] * n  # Senkou Span A
    sb = [float("nan")] * n  # Senkou Span B
    chikou = [float("nan")] * n

    for i in range(n):
        if i >= tenkan - 1:
            ts[i] = (max(h[i - tenkan + 1: i + 1]) + min(l[i - tenkan + 1: i + 1])) / 2
        if i >= kijun - 1:
            ks[i] = (max(h[i - kijun + 1: i + 1]) + min(l[i - kijun + 1: i + 1])) / 2
        if i >= kijun - 1:
            # Senkou A = (Tenkan + Kijun) / 2 plotted 26 periods ahead
            if not math.isnan(ts[i]) and not math.isnan(ks[i]):
                sa[i] = (ts[i] + ks[i]) / 2
        if i >= senkou_b - 1:
            sb[i] = (max(h[i - senkou_b + 1: i + 1]) + min(l[i - senkou_b + 1: i + 1])) / 2
        # Chikou = close plotted 26 periods back (stored at current index)
        chikou[i] = c[i]

    return {
        "tenkan": np.array(ts),
        "kijun": np.array(ks),
        "senkou_a": np.array(sa),
        "senkou_b": np.array(sb),
        "chikou": np.array(chikou),
    }


# ---------------------------------------------------------------------------
# RSI
# ---------------------------------------------------------------------------

def rsi(prices: Numeric, period: int = 14) -> np.ndarray:
    """Relative Strength Index (Wilder-smoothed).

    Returns array of same length as *prices*; first values are NaN.
    """
    p = _to_list(prices)
    n = len(p)
    out = [float("nan")] * n
    if n < 2:
        return np.array(out)

    gains = [max(p[i] - p[i - 1], 0.0) for i in range(1, n)]
    losses = [max(p[i - 1] - p[i], 0.0) for i in range(1, n)]

    if len(gains) < period:
        return np.array(out)

    avg_gain = _mean(gains[:period])
    avg_loss = _mean(losses[:period])

    for i in range(period, len(gains) + 1):
        if avg_loss == 0:
            out[i] = 100.0
        else:
            rs = avg_gain / avg_loss
            out[i] = 100.0 - 100.0 / (1.0 + rs)
        if i < len(gains):
            avg_gain = (avg_gain * (period - 1) + gains[i]) / period
            avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    return np.array(out)


# ---------------------------------------------------------------------------
# MACD
# ---------------------------------------------------------------------------

def macd(
    prices: Numeric,
    fast: int = 12,
    slow: int = 26,
    signal_period: int = 9,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """MACD.  Returns (macd_line, signal_line, histogram) as numpy arrays."""
    p = _to_list(prices)
    fast_ema = ema(p, fast)
    slow_ema = ema(p, slow)
    macd_line = fast_ema - slow_ema
    signal_line = ema(macd_line.tolist(), signal_period)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


# ---------------------------------------------------------------------------
# Bollinger Bands
# ---------------------------------------------------------------------------

def bollinger_bands(
    prices: Numeric,
    period: int = 20,
    num_std: float = 2.0,
) -> dict:
    """Bollinger Bands.  Returns dict with upper, middle, lower, pct_b, bandwidth."""
    p = _to_list(prices)
    n = len(p)
    mid = sma(p, period)
    upper = np.full(n, float("nan"))
    lower = np.full(n, float("nan"))
    pct_b = np.full(n, float("nan"))
    bandwidth = np.full(n, float("nan"))

    for i in range(period - 1, n):
        window = p[i - period + 1: i + 1]
        sd = (sum((x - mid[i]) ** 2 for x in window) / period) ** 0.5
        upper[i] = mid[i] + num_std * sd
        lower[i] = mid[i] - num_std * sd
        rng = upper[i] - lower[i]
        pct_b[i] = (p[i] - lower[i]) / rng if rng > 0 else 0.5
        bandwidth[i] = rng / mid[i] if mid[i] > 0 else 0.0

    return {
        "upper": upper,
        "middle": mid,
        "lower": lower,
        "pct_b": pct_b,
        "bandwidth": bandwidth,
    }


# ---------------------------------------------------------------------------
# ATR
# ---------------------------------------------------------------------------

def atr(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    period: int = 14,
) -> np.ndarray:
    """Average True Range.  Returns array, NaN-padded."""
    h = _to_list(highs)
    l = _to_list(lows)
    c = _to_list(closes)
    n = len(c)

    tr = [h[0] - l[0]]
    for i in range(1, n):
        tr.append(max(
            h[i] - l[i],
            abs(h[i] - c[i - 1]),
            abs(l[i] - c[i - 1]),
        ))

    out = [float("nan")] * n
    if n < period:
        return np.array(out)
    atr_val = _mean(tr[:period])
    out[period - 1] = atr_val
    for i in range(period, n):
        atr_val = (atr_val * (period - 1) + tr[i]) / period
        out[i] = atr_val
    return np.array(out)


# ---------------------------------------------------------------------------
# ADX (with +DI / -DI)
# ---------------------------------------------------------------------------

def adx(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    period: int = 14,
) -> np.ndarray:
    """Average Directional Index.  Returns ADX as numpy array, NaN-padded."""
    val, _, _ = adx_full(highs, lows, closes, period)
    return val


def adx_full(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    period: int = 14,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """ADX with directional indicators.

    Returns (adx, plus_di, minus_di) as numpy arrays.
    """
    h = _to_list(highs)
    l = _to_list(lows)
    c = _to_list(closes)
    n = len(c)

    out_adx = [float("nan")] * n
    out_plus = [float("nan")] * n
    out_minus = [float("nan")] * n

    if n < period * 2:
        return np.array(out_adx), np.array(out_plus), np.array(out_minus)

    # True Range, +DM, -DM
    tr_arr: List[float] = []
    plus_dm: List[float] = []
    minus_dm: List[float] = []

    for i in range(1, n):
        tr_val = max(
            h[i] - l[i],
            abs(h[i] - c[i - 1]),
            abs(l[i] - c[i - 1]),
        )
        tr_arr.append(tr_val)

        up_move = h[i] - h[i - 1]
        down_move = l[i - 1] - l[i]

        plus_dm.append(up_move if (up_move > down_move and up_move > 0) else 0.0)
        minus_dm.append(down_move if (down_move > up_move and down_move > 0) else 0.0)

    # Wilder smooth first period values
    atr_val = sum(tr_arr[:period]) / period
    sm_plus = sum(plus_dm[:period]) / period
    sm_minus = sum(minus_dm[:period]) / period

    dx_vals: List[float] = []

    for i in range(period - 1, len(tr_arr)):
        if i == period - 1:
            pass  # initial values already computed
        else:
            atr_val = (atr_val * (period - 1) + tr_arr[i]) / period
            sm_plus = (sm_plus * (period - 1) + plus_dm[i]) / period
            sm_minus = (sm_minus * (period - 1) + minus_dm[i]) / period

        plus_di = (sm_plus / atr_val * 100.0) if atr_val > 0 else 0.0
        minus_di = (sm_minus / atr_val * 100.0) if atr_val > 0 else 0.0

        # i in tr_arr corresponds to day i+1 in original prices
        day_idx = i + 1
        out_plus[day_idx] = plus_di
        out_minus[day_idx] = minus_di

        di_sum = plus_di + minus_di
        dx = abs(plus_di - minus_di) / di_sum * 100.0 if di_sum > 0 else 0.0
        dx_vals.append(dx)

    # ADX = smoothed DX over another period
    if len(dx_vals) >= period:
        adx_val = _mean(dx_vals[:period])
        # First ADX value at day: period + period (2*period from start)
        adx_start = period * 2
        if adx_start < n:
            out_adx[adx_start] = adx_val
        for j in range(period, len(dx_vals)):
            adx_val = (adx_val * (period - 1) + dx_vals[j]) / period
            day_idx = j + period
            if day_idx < n:
                out_adx[day_idx] = adx_val

    return np.array(out_adx), np.array(out_plus), np.array(out_minus)


# ---------------------------------------------------------------------------
# OBV (On-Balance Volume)
# ---------------------------------------------------------------------------

def obv(closes: Numeric, volumes: Numeric) -> np.ndarray:
    """On-Balance Volume.  Returns cumulative OBV array."""
    c = _to_list(closes)
    v = _to_list(volumes)
    n = len(c)
    if n == 0:
        return np.array([])
    out = [v[0]]
    for i in range(1, n):
        if c[i] > c[i - 1]:
            out.append(out[-1] + v[i])
        elif c[i] < c[i - 1]:
            out.append(out[-1] - v[i])
        else:
            out.append(out[-1])
    return np.array(out)


# ---------------------------------------------------------------------------
# MFI (Money Flow Index)
# ---------------------------------------------------------------------------

def mfi(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    volumes: Numeric,
    period: int = 14,
) -> np.ndarray:
    """Money Flow Index — RSI weighted by volume.  NaN-padded."""
    h = _to_list(highs)
    l = _to_list(lows)
    c = _to_list(closes)
    v = _to_list(volumes)
    n = len(c)
    out = [float("nan")] * n

    if n < period + 1:
        return np.array(out)

    tp = [(h[i] + l[i] + c[i]) / 3.0 for i in range(n)]
    rmf = [tp[i] * v[i] for i in range(n)]

    for i in range(period, n):
        pos_flow = 0.0
        neg_flow = 0.0
        for j in range(i - period + 1, i + 1):
            if tp[j] > tp[j - 1]:
                pos_flow += rmf[j]
            elif tp[j] < tp[j - 1]:
                neg_flow += rmf[j]
        if neg_flow == 0:
            out[i] = 100.0
        else:
            ratio = pos_flow / neg_flow
            out[i] = 100.0 - 100.0 / (1.0 + ratio)

    return np.array(out)


# ---------------------------------------------------------------------------
# CMF (Chaikin Money Flow)
# ---------------------------------------------------------------------------

def cmf(
    highs: Numeric,
    lows: Numeric,
    closes: Numeric,
    volumes: Numeric,
    period: int = 20,
) -> np.ndarray:
    """Chaikin Money Flow.  NaN-padded."""
    h = _to_list(highs)
    l = _to_list(lows)
    c = _to_list(closes)
    v = _to_list(volumes)
    n = len(c)
    out = [float("nan")] * n

    if n < period:
        return np.array(out)

    # Money Flow Multiplier: ((C - L) - (H - C)) / (H - L)
    mfm = []
    for i in range(n):
        hl = h[i] - l[i]
        mfm.append(((c[i] - l[i]) - (h[i] - c[i])) / hl if hl > 0 else 0.0)

    mfv = [mfm[i] * v[i] for i in range(n)]

    for i in range(period - 1, n):
        vol_sum = sum(v[i - period + 1: i + 1])
        mfv_sum = sum(mfv[i - period + 1: i + 1])
        out[i] = mfv_sum / vol_sum if vol_sum > 0 else 0.0

    return np.array(out)


# ---------------------------------------------------------------------------
# Parabolic SAR
# ---------------------------------------------------------------------------

def parabolic_sar(
    highs: Numeric,
    lows: Numeric,
    af_start: float = 0.02,
    af_step: float = 0.02,
    af_max: float = 0.20,
) -> np.ndarray:
    """Parabolic SAR.  Returns SAR values array."""
    h = _to_list(highs)
    l = _to_list(lows)
    n = len(h)
    if n < 2:
        return np.array([float("nan")] * n)

    out = [float("nan")] * n
    # Start assuming uptrend
    uptrend = True
    af = af_start
    ep = h[0]  # extreme point
    sar = l[0]
    out[0] = sar

    for i in range(1, n):
        prev_sar = sar
        sar = prev_sar + af * (ep - prev_sar)

        if uptrend:
            # SAR must not be above prior two lows
            if i >= 2:
                sar = min(sar, l[i - 1], l[i - 2])
            else:
                sar = min(sar, l[i - 1])

            if l[i] < sar:
                # Switch to downtrend
                uptrend = False
                sar = ep
                ep = l[i]
                af = af_start
            else:
                if h[i] > ep:
                    ep = h[i]
                    af = min(af + af_step, af_max)
        else:
            # SAR must not be below prior two highs
            if i >= 2:
                sar = max(sar, h[i - 1], h[i - 2])
            else:
                sar = max(sar, h[i - 1])

            if h[i] > sar:
                # Switch to uptrend
                uptrend = True
                sar = ep
                ep = h[i]
                af = af_start
            else:
                if l[i] < ep:
                    ep = l[i]
                    af = min(af + af_step, af_max)

        out[i] = sar

    return np.array(out)


# ---------------------------------------------------------------------------
# Stochastic RSI
# ---------------------------------------------------------------------------

def stochastic_rsi(
    prices: Numeric,
    rsi_period: int = 14,
    stoch_period: int = 14,
    k_smooth: int = 3,
    d_smooth: int = 3,
) -> Tuple[np.ndarray, np.ndarray]:
    """Stochastic RSI.  Returns (K, D) arrays, NaN-padded."""
    rsi_vals = rsi(prices, rsi_period)
    n = len(rsi_vals)
    k_out = [float("nan")] * n
    d_out = [float("nan")] * n

    # StochRSI = (RSI - min(RSI, stoch_period)) / (max - min)
    start = rsi_period + stoch_period
    if n < start:
        return np.array(k_out), np.array(d_out)

    raw_stoch = [float("nan")] * n
    for i in range(start - 1, n):
        window = rsi_vals[i - stoch_period + 1: i + 1]
        # skip NaN values
        valid = [v for v in window if not (isinstance(v, float) and math.isnan(v))]
        if len(valid) < 2:
            continue
        mn = min(valid)
        mx = max(valid)
        rng = mx - mn
        cur = rsi_vals[i]
        if isinstance(cur, float) and math.isnan(cur):
            continue
        raw_stoch[i] = (cur - mn) / rng * 100.0 if rng > 0 else 50.0

    # Smooth K (SMA of raw stoch)
    for i in range(start + k_smooth - 2, n):
        window = raw_stoch[i - k_smooth + 1: i + 1]
        valid = [v for v in window if not (isinstance(v, float) and math.isnan(v))]
        if valid:
            k_out[i] = sum(valid) / len(valid)

    # D = SMA of K
    for i in range(start + k_smooth + d_smooth - 3, n):
        window = k_out[i - d_smooth + 1: i + 1]
        valid = [v for v in window if not (isinstance(v, float) and math.isnan(v))]
        if valid:
            d_out[i] = sum(valid) / len(valid)

    return np.array(k_out), np.array(d_out)
