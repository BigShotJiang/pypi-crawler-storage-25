"""stratevo.api - REST API server."""
