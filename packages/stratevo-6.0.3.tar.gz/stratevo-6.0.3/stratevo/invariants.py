"""
Runtime Invariant Guards for StratEvo.

Provides assertion helpers that raise InvariantViolation when critical
assumptions are violated. Used by backtest, evolution, paper trading,
and factor modules to catch bugs early.
"""

from __future__ import annotations

import logging
import math
from typing import Any, Callable, Sequence

logger = logging.getLogger(__name__)


class InvariantViolation(Exception):
    """Runtime invariant has been violated."""
    pass


# ── Backtest Invariants ──────────────────────────────────────────────

def assert_no_lookahead(decision_time: Any, data_time: Any) -> None:
    """Decision must not use data from the future.

    Using the current bar's data at the current bar's close is normal
    (data_time == decision_time).  Only strictly future data is a violation.

    Raises InvariantViolation if data_time > decision_time.
    """
    if data_time > decision_time:
        raise InvariantViolation(
            f"Look-ahead bias detected: decision at {decision_time} "
            f"uses data from {data_time}"
        )


def assert_return_reasonable(daily_return: float, threshold: float = 0.50) -> None:
    """Warn (log) if a single-bar return exceeds ±threshold.

    Does NOT raise; logs a warning so the backtest can continue.
    """
    if not math.isfinite(daily_return):
        logger.warning("Non-finite daily return detected: %s", daily_return)
        return
    if abs(daily_return) > threshold:
        logger.warning(
            "Suspicious daily return: %.2f%% exceeds ±%.0f%% threshold",
            daily_return * 100,
            threshold * 100,
        )


def assert_timestamps_increasing(timestamps: Sequence[Any]) -> None:
    """All timestamps must be strictly increasing.

    Raises InvariantViolation on the first violation.
    """
    for i in range(1, len(timestamps)):
        if timestamps[i] <= timestamps[i - 1]:
            raise InvariantViolation(
                f"Timestamps not strictly increasing at index {i}: "
                f"{timestamps[i - 1]} >= {timestamps[i]}"
            )


def assert_position_bounds(position_pct: float) -> None:
    """Position percentage must be in [0, 1] (0% to 100%).

    Raises InvariantViolation if outside bounds.
    """
    if position_pct < 0:
        raise InvariantViolation(
            f"Negative position detected: {position_pct:.4f}"
        )
    if position_pct > 1.0:
        raise InvariantViolation(
            f"Position exceeds 100%: {position_pct:.4f}"
        )


# ── Evolution Invariants ─────────────────────────────────────────────

def assert_annual_return_reasonable(
    annual_return: float,
    warn_threshold: float = 5000.0,
) -> float:
    """Warn when annualized returns are extremely high (possible short-window artifact).

    Does NOT cap or modify the value — if the underlying trade math is correct,
    high annualized returns from short windows are mathematically valid.
    Logs a warning so the user can investigate.

    Returns the original value unchanged.
    """
    if not math.isfinite(annual_return):
        logger.warning("Non-finite annual return detected: %s", annual_return)
        return 0.0
    if annual_return > warn_threshold:
        logger.warning(
            "Very high annual return %.2f%% — verify underlying trades. "
            "May be short-window annualization (mathematically valid but worth checking).",
            annual_return,
        )
    if annual_return < -100.0:
        return -100.0
    return annual_return


def assert_fitness_sane(fitness: float, ceiling: float = 1_000_000) -> None:
    """Fitness values above ceiling are suspicious — log a warning.

    Does NOT raise; marks as suspicious via logging.
    """
    if not math.isfinite(fitness):
        logger.warning("Non-finite fitness detected: %s", fitness)
        return
    if abs(fitness) > ceiling:
        logger.warning(
            "Suspicious fitness value: %s exceeds ceiling ±%s",
            fitness,
            ceiling,
        )


def assert_dna_weights_valid(weights: Sequence[float]) -> None:
    """All DNA weights must be in [0, 1] range.

    Raises InvariantViolation on the first out-of-range weight.
    """
    for i, w in enumerate(weights):
        if not math.isfinite(w):
            raise InvariantViolation(
                f"DNA weight at index {i} is not finite: {w}"
            )
        if w < 0.0 or w > 1.0:
            raise InvariantViolation(
                f"DNA weight at index {i} out of [0, 1] range: {w}"
            )


def assert_generation_increasing(current_gen: int, previous_gen: int) -> None:
    """Generation number must strictly increase.

    Raises InvariantViolation if current <= previous.
    """
    if current_gen <= previous_gen:
        raise InvariantViolation(
            f"Generation not increasing: current={current_gen} "
            f"<= previous={previous_gen}"
        )


# ── Paper Trading Invariants ─────────────────────────────────────────

def assert_signal_before_order(signal_timestamp: float, order_timestamp: float) -> None:
    """Signal timestamp must be strictly before order timestamp.

    Raises InvariantViolation if signal comes at or after order time.
    """
    if signal_timestamp >= order_timestamp:
        raise InvariantViolation(
            f"Signal timestamp ({signal_timestamp}) must be before "
            f"order timestamp ({order_timestamp})"
        )


def assert_position_size_limit(
    order_value: float,
    total_capital: float,
    max_pct: float = 0.50,
) -> None:
    """Single position must not exceed max_pct of total capital.

    Raises InvariantViolation if order_value > total_capital * max_pct.
    """
    if total_capital <= 0:
        raise InvariantViolation(
            f"Total capital must be positive, got {total_capital}"
        )
    if order_value > total_capital * max_pct:
        raise InvariantViolation(
            f"Position size {order_value:.2f} exceeds "
            f"{max_pct:.0%} of capital {total_capital:.2f} "
            f"(max allowed: {total_capital * max_pct:.2f})"
        )


def assert_max_exposure(
    total_exposure: float,
    max_exposure: float,
) -> None:
    """Total exposure must not exceed configured max_exposure.

    Raises InvariantViolation if exceeded.
    """
    if total_exposure > max_exposure:
        raise InvariantViolation(
            f"Total exposure {total_exposure:.2f} exceeds "
            f"max allowed {max_exposure:.2f}"
        )


# ── Factor Invariants ────────────────────────────────────────────────

def assert_factor_output_range(
    values: "float | Sequence[float]",
    name: str = "factor",
) -> None:
    """Factor output values must be in [0, 1] or NaN.

    Accepts a single float or a sequence of floats.
    Raises InvariantViolation on the first out-of-range value.
    """
    # Handle single float
    if isinstance(values, (int, float)):
        if math.isnan(values):
            return
        if not math.isfinite(values):
            raise InvariantViolation(
                f"{name} output is not finite: {values}"
            )
        if values < 0.0 or values > 1.0:
            raise InvariantViolation(
                f"{name} output out of [0, 1] range: {values}"
            )
        return

    for i, v in enumerate(values):
        if math.isnan(v):
            continue
        if not math.isfinite(v):
            raise InvariantViolation(
                f"{name} output at index {i} is not finite: {v}"
            )
        if v < 0.0 or v > 1.0:
            raise InvariantViolation(
                f"{name} output at index {i} out of [0, 1] range: {v}"
            )


def assert_input_not_empty(data: Any, name: str = "input") -> None:
    """Input data must not be empty.

    Works with lists, numpy arrays, and anything with __len__.
    """
    if data is None:
        raise InvariantViolation(f"{name} is None")
    try:
        length = len(data)
    except TypeError:
        return  # No length concept — skip check
    if length == 0:
        raise InvariantViolation(f"{name} is empty (length 0)")


def audit_factor_no_lookahead(
    factor_fn: "Callable",
    factor_name: str,
    test_length: int = 100,
    test_idx: int = 50,
) -> bool:
    """One-shot audit: verify a factor does not access data beyond idx.

    Creates synthetic data of ``test_length`` bars, calls the factor at
    ``test_idx``, then calls it again with data truncated to ``idx + 1``
    elements.  If results differ, the factor is accessing future data.

    Returns True if the factor is safe, False if look-ahead is detected.
    Logs a warning on failure (does not raise).
    """
    import random
    # Deterministic synthetic data
    rng = random.Random(42)
    base = 100.0
    closes = []
    for _ in range(test_length):
        base *= 1 + rng.uniform(-0.03, 0.03)
        closes.append(base)
    highs = [c * (1 + rng.uniform(0, 0.02)) for c in closes]
    lows = [c * (1 - rng.uniform(0, 0.02)) for c in closes]
    volumes = [rng.uniform(1e6, 1e7) for _ in closes]

    try:
        result_full = factor_fn(closes, highs, lows, volumes, test_idx)
        result_truncated = factor_fn(
            closes[:test_idx + 1],
            highs[:test_idx + 1],
            lows[:test_idx + 1],
            volumes[:test_idx + 1],
            test_idx,
        )

        if not math.isfinite(result_full) and not math.isfinite(result_truncated):
            return True  # Both NaN/inf — can't compare, assume OK

        if abs(float(result_full) - float(result_truncated)) > 1e-10:
            logger.warning(
                "Factor '%s' may have look-ahead bias: "
                "full_data=%.6f vs truncated_data=%.6f (diff=%.6e)",
                factor_name, result_full, result_truncated,
                abs(result_full - result_truncated),
            )
            return False
    except Exception as e:
        logger.warning(
            "Factor '%s' audit failed with exception: %s",
            factor_name, e,
        )
        return True  # Can't determine, don't block

    return True
