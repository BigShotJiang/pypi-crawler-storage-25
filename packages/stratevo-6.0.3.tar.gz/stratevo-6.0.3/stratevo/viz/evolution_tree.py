"""
CLI ASCII visualization of evolution progress.

Reads parsed JSON or raw log files and displays an ASCII-art evolution
timeline in the terminal showing fitness, return, drawdown progression.

Usage:
    python -m stratevo.viz.evolution_tree logs/evolution_auto.log
    python -m stratevo.viz.evolution_tree logs/evolution_data.json
    python -m stratevo.viz.evolution_tree logs/evolution_auto.log --top 20
"""

import json
import sys
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional

# Fix Windows console encoding for Unicode box-drawing chars
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ('utf-8', 'utf8'):
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except Exception:
        pass

from .parse_evolution_log import parse_log_file


# ─── Block characters for bar charts ───
BAR_CHARS = " ▏▎▍▌▋▊█"
SPARK_CHARS = "▁▂▃▄▅▆▇█"

# ─── ANSI colors ───
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"
BG_DARK = "\033[48;5;234m"


def _bar(value: float, max_val: float, width: int = 20) -> str:
    """Create a smooth bar using Unicode block characters."""
    if max_val <= 0:
        return " " * width
    ratio = min(value / max_val, 1.0)
    full_blocks = ratio * width
    n_full = int(full_blocks)
    frac = full_blocks - n_full
    # fractional block index (0-7)
    frac_idx = int(frac * 8)
    frac_idx = min(frac_idx, 7)

    bar = "█" * n_full
    if n_full < width:
        bar += BAR_CHARS[frac_idx]
        bar += " " * (width - n_full - 1)

    return bar


def _sparkline(values: List[float], width: int = 8) -> str:
    """Create a sparkline from a list of values."""
    if not values:
        return " " * width
    mn, mx = min(values), max(values)
    rng = mx - mn if mx > mn else 1.0

    # Sample/bucket values to fit width
    if len(values) <= width:
        sampled = values
    else:
        step = len(values) / width
        sampled = [values[int(i * step)] for i in range(width)]

    chars = []
    for v in sampled:
        idx = int(((v - mn) / rng) * 7)
        idx = min(max(idx, 0), 7)
        chars.append(SPARK_CHARS[idx])

    return "".join(chars)


def _color_dd(dd: float) -> str:
    """Color drawdown: green if low, yellow if medium, red if high."""
    if dd < 10:
        return f"{GREEN}{dd:6.1f}%{RESET}"
    elif dd < 30:
        return f"{YELLOW}{dd:6.1f}%{RESET}"
    else:
        return f"{RED}{dd:6.1f}%{RESET}"


def _color_return(ret: float) -> str:
    """Color return value."""
    if ret >= 1000:
        return f"{GREEN}{BOLD}{ret:>10.1f}%{RESET}"
    elif ret >= 100:
        return f"{GREEN}{ret:>10.1f}%{RESET}"
    elif ret >= 0:
        return f"{WHITE}{ret:>10.1f}%{RESET}"
    else:
        return f"{RED}{ret:>10.1f}%{RESET}"


def _format_time(secs: float) -> str:
    """Format seconds into human-readable string."""
    if secs < 60:
        return f"{secs:.0f}s"
    elif secs < 3600:
        return f"{secs / 60:.1f}m"
    else:
        return f"{secs / 3600:.1f}h"


def print_evolution_table(
    records: List[Dict[str, Any]],
    top_n: Optional[int] = None,
    show_sparkline: bool = True,
    use_color: bool = True,
) -> None:
    """Print a formatted ASCII evolution table."""

    if not records:
        print("No evolution data to display.")
        return

    if not use_color:
        # Override color functions
        global RED, GREEN, YELLOW, BLUE, CYAN, MAGENTA, WHITE, BOLD, DIM, RESET, BG_DARK
        RED = GREEN = YELLOW = BLUE = CYAN = MAGENTA = WHITE = BOLD = DIM = RESET = BG_DARK = ""

    # Select which records to display
    display = records
    if top_n and len(records) > top_n:
        # Always show first, a sample of middle, and last few
        indices = set()
        indices.add(0)  # first
        step = max(1, len(records) // (top_n - 2))
        for i in range(0, len(records), step):
            indices.add(i)
        # Always include the best
        best_idx = max(range(len(records)), key=lambda i: records[i]["fitness"])
        indices.add(best_idx)
        # Last 3
        for i in range(max(0, len(records) - 3), len(records)):
            indices.add(i)
        indices = sorted(indices)[:top_n]
        display = [records[i] for i in indices]

    max_fitness = max(r["fitness"] for r in records)
    max_return = max(r["return_pct"] for r in records)

    # Collect fitness history for sparkline
    all_fitness = [r["fitness"] for r in records]

    # Header
    print()
    print(f"{BOLD}{CYAN}{'═' * 90}{RESET}")
    print(f"{BOLD}{CYAN}  🧬 StratEvo Evolution Timeline{RESET}")
    print(f"{BOLD}{CYAN}{'═' * 90}{RESET}")
    print()

    # Column headers
    header = (
        f"  {BOLD}{'Gen':>5}  "
        f"{'Fitness':>10}  "
        f"{'Bar':^22}  "
        f"{'Return':>10}  "
        f"{'MaxDD':>7}  "
        f"{'Sharpe':>6}  "
        f"{'Trades':>6}  "
        f"{'Time':>6}{RESET}"
    )
    print(header)
    print(f"  {DIM}{'─' * 84}{RESET}")

    # Running best fitness tracker
    running_best = 0

    for rec in display:
        gen = rec["gen"]
        fitness = rec["fitness"]
        ret = rec["return_pct"]
        dd = rec["max_dd"]
        sharpe = rec["sharpe"]
        trades = rec["trades"]
        time_s = rec["time_secs"]

        is_new_best = fitness > running_best
        if fitness > running_best:
            running_best = fitness

        bar = _bar(fitness, max_fitness, 20)
        dd_str = _color_dd(dd)
        ret_str = _color_return(ret)

        # Highlight new best
        if is_new_best:
            gen_str = f"{GREEN}{BOLD}{gen:>5}{RESET}"
            fit_str = f"{GREEN}{BOLD}{fitness:>10.1f}{RESET}"
            bar_str = f"{GREEN}{bar}{RESET}"
            marker = f"{GREEN}★{RESET}"
        else:
            gen_str = f"{WHITE}{gen:>5}{RESET}"
            fit_str = f"{WHITE}{fitness:>10.1f}{RESET}"
            bar_str = f"{DIM}{bar}{RESET}"
            marker = " "

        line = (
            f" {marker}{gen_str}  "
            f"{fit_str}  "
            f"{bar_str}  "
            f"{ret_str}  "
            f"{dd_str}  "
            f"{sharpe:>6.2f}  "
            f"{trades:>6}  "
            f"{_format_time(time_s):>6}"
        )
        print(line)

    # Footer sparkline
    if show_sparkline and len(records) > 4:
        spark = _sparkline(all_fitness, width=min(40, len(records)))
        print()
        print(f"  {DIM}Fitness trend:{RESET} {CYAN}{spark}{RESET}")

    # Summary
    best = max(records, key=lambda r: r["fitness"])
    total_time = sum(r["time_secs"] for r in records)
    print()
    print(f"  {DIM}{'─' * 84}{RESET}")
    print(
        f"  {BOLD}📊 Summary:{RESET} "
        f"{len(records)} generations | "
        f"Best: Gen {best['gen']} "
        f"(fitness={best['fitness']:.1f}, "
        f"return={best['return_pct']:.1f}%, "
        f"dd={best['max_dd']:.1f}%) | "
        f"Total time: {_format_time(total_time)}"
    )
    print()


def print_fitness_chart(records: List[Dict[str, Any]], width: int = 60, height: int = 15) -> None:
    """Print an ASCII fitness curve chart."""
    if not records:
        return

    values = [r["fitness"] for r in records]
    gens = [r["gen"] for r in records]

    mn = min(values)
    mx = max(values)
    rng = mx - mn if mx > mn else 1.0

    # Sample to fit width
    if len(values) > width:
        step = len(values) / width
        sampled_vals = [values[int(i * step)] for i in range(width)]
        sampled_gens = [gens[int(i * step)] for i in range(width)]
    else:
        sampled_vals = values
        sampled_gens = gens

    print(f"\n  {BOLD}{CYAN}📈 Fitness Curve{RESET}\n")

    # Plot
    for row in range(height, 0, -1):
        threshold = mn + (row / height) * rng
        label = f"{threshold:>10.0f}"
        line = f"  {DIM}{label}{RESET} │"
        for v in sampled_vals:
            if v >= threshold:
                line += f"{GREEN}█{RESET}"
            elif v >= threshold - (rng / height) * 0.5:
                line += f"{DIM}▄{RESET}"
            else:
                line += " "
        print(line)

    # X-axis
    print(f"  {'':>10} └{'─' * len(sampled_vals)}")
    if sampled_gens:
        first = sampled_gens[0]
        last = sampled_gens[-1]
        axis_label = f"Gen {first}"
        axis_end = f"Gen {last}"
        padding = len(sampled_vals) - len(axis_label) - len(axis_end)
        if padding > 0:
            print(f"  {'':>11}{axis_label}{' ' * padding}{axis_end}")
        else:
            print(f"  {'':>11}{axis_label} ... {axis_end}")


def print_dd_vs_return(records: List[Dict[str, Any]]) -> None:
    """Print MaxDD vs Return scatter-like view."""
    if not records:
        return

    print(f"\n  {BOLD}{CYAN}⚡ Return vs MaxDrawdown{RESET}\n")
    print(f"  {'Gen':>5}  {'Return':>10}  {'MaxDD':>7}  {'Risk/Reward'}")
    print(f"  {DIM}{'─' * 50}{RESET}")

    max_ret = max(r["return_pct"] for r in records)

    for rec in records:
        ret = rec["return_pct"]
        dd = rec["max_dd"]
        ratio = ret / dd if dd > 0 else 0

        bar_len = int((ret / max_ret) * 30) if max_ret > 0 else 0
        dd_bar_len = int(min(dd / 100, 1.0) * 10)

        ret_bar = f"{GREEN}{'█' * bar_len}{RESET}"
        dd_bar = f"{RED}{'█' * dd_bar_len}{RESET}"

        print(
            f"  {rec['gen']:>5}  "
            f"{ret:>9.1f}%  "
            f"{dd:>6.1f}%  "
            f"{ret_bar} {DIM}vs{RESET} {dd_bar} "
            f"{DIM}({ratio:.1f}x){RESET}"
        )


def load_data(path: str) -> List[Dict[str, Any]]:
    """Load evolution data from JSON file or parse from log file."""
    p = Path(path)
    if not p.exists():
        print(f"❌ File not found: {path}")
        sys.exit(1)

    if p.suffix == ".json":
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "generations" in data:
            return data["generations"]
        return data
    else:
        # Treat as log file
        return parse_log_file(str(p))


def main():
    parser = argparse.ArgumentParser(
        description="StratEvo Evolution Tree - ASCII Visualization"
    )
    parser.add_argument(
        "input_file",
        help="Path to evolution_auto.log or parsed JSON file",
    )
    parser.add_argument(
        "--top",
        type=int,
        default=None,
        help="Show only top N rows in the table (samples evenly)",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI colors",
    )
    parser.add_argument(
        "--chart",
        action="store_true",
        help="Show ASCII fitness curve chart",
    )
    parser.add_argument(
        "--scatter",
        action="store_true",
        help="Show Return vs MaxDD scatter view",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Show all visualizations",
    )

    args = parser.parse_args()

    records = load_data(args.input_file)

    if not records:
        print("❌ No generation data found.")
        sys.exit(1)

    print_evolution_table(
        records,
        top_n=args.top,
        use_color=not args.no_color,
    )

    if args.chart or args.all:
        print_fitness_chart(records)

    if args.scatter or args.all:
        print_dd_vs_return(records)


if __name__ == "__main__":
    main()
