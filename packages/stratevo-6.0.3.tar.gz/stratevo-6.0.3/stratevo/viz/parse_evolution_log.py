"""
Parse evolution_auto.log into structured JSON for visualization.

Usage:
    python -m stratevo.viz.parse_evolution_log logs/evolution_auto.log [-o output.json]
"""

import re
import json
import sys
import argparse
from pathlib import Path
from typing import List, Dict, Any, Optional


# Pattern matches lines like:
# Gen  186 | fitness=20067.84 | return=22333.90% | dd= 2.19% | wr= 66.7% | sharpe= 7.76 | trades=  66 | 10928.8s
GEN_PATTERN = re.compile(
    r"Gen\s+(?P<gen>\d+)\s*\|"
    r"\s*fitness=\s*(?P<fitness>[\d.]+)\s*\|"
    r"\s*return=\s*(?P<ret>[\d.]+)%\s*\|"
    r"\s*dd=\s*(?P<dd>[\d.]+)%\s*\|"
    r"\s*wr=\s*(?P<wr>[\d.]+)%\s*\|"
    r"\s*sharpe=\s*(?P<sharpe>[\d.]+)\s*\|"
    r"\s*trades=\s*(?P<trades>\d+)\s*\|"
    r"\s*(?P<time>[\d.]+)s"
)

# Pattern for factor speedup lines to track active factor counts
FACTOR_PATTERN = re.compile(
    r"\[factors\]\s+speedup:\s+(?P<active>\d+)/(?P<total>\d+)\s+factors active"
)


def parse_log_file(log_path: str) -> List[Dict[str, Any]]:
    """Parse evolution log file and return list of generation records.

    Each record contains: gen, fitness, return_pct, max_dd, win_rate,
    sharpe, trades, time_secs.

    When duplicate generation numbers exist (e.g. engine restarts),
    we keep the last occurrence's best values.
    """
    records: Dict[int, Dict[str, Any]] = {}

    with open(log_path, "r", encoding="utf-8", errors="replace") as f:
        for line in f:
            m = GEN_PATTERN.search(line)
            if m:
                gen = int(m.group("gen"))
                record = {
                    "gen": gen,
                    "fitness": float(m.group("fitness")),
                    "return_pct": float(m.group("ret")),
                    "max_dd": float(m.group("dd")),
                    "win_rate": float(m.group("wr")),
                    "sharpe": float(m.group("sharpe")),
                    "trades": int(m.group("trades")),
                    "time_secs": float(m.group("time")),
                }
                # Keep the record with higher fitness for duplicate gens
                if gen not in records or record["fitness"] > records[gen]["fitness"]:
                    records[gen] = record

    # Sort by generation number
    sorted_records = sorted(records.values(), key=lambda r: r["gen"])
    return sorted_records


def compute_summary(records: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute summary statistics from parsed records."""
    if not records:
        return {"total_generations": 0}

    fitness_vals = [r["fitness"] for r in records]
    return_vals = [r["return_pct"] for r in records]
    dd_vals = [r["max_dd"] for r in records]

    best_idx = max(range(len(records)), key=lambda i: records[i]["fitness"])
    best = records[best_idx]

    return {
        "total_generations": len(records),
        "gen_range": [records[0]["gen"], records[-1]["gen"]],
        "best_generation": best["gen"],
        "best_fitness": best["fitness"],
        "best_return_pct": best["return_pct"],
        "best_max_dd": best["max_dd"],
        "best_sharpe": best["sharpe"],
        "fitness_range": [min(fitness_vals), max(fitness_vals)],
        "return_range": [min(return_vals), max(return_vals)],
        "dd_range": [min(dd_vals), max(dd_vals)],
        "total_time_secs": sum(r["time_secs"] for r in records),
    }


def parse_and_export(
    log_path: str, output_path: Optional[str] = None
) -> Dict[str, Any]:
    """Parse log and optionally export to JSON. Returns full data dict."""
    records = parse_log_file(log_path)
    summary = compute_summary(records)

    data = {
        "source": str(log_path),
        "summary": summary,
        "generations": records,
    }

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"✅ Exported {len(records)} generations to {out}")

    return data


def main():
    parser = argparse.ArgumentParser(
        description="Parse StratEvo evolution log into JSON"
    )
    parser.add_argument("log_file", help="Path to evolution_auto.log")
    parser.add_argument(
        "-o",
        "--output",
        default=None,
        help="Output JSON path (default: <log_dir>/evolution_data.json)",
    )
    args = parser.parse_args()

    log_path = Path(args.log_file)
    if not log_path.exists():
        print(f"❌ Log file not found: {log_path}")
        sys.exit(1)

    output = args.output
    if output is None:
        output = str(log_path.parent / "evolution_data.json")

    data = parse_and_export(str(log_path), output)
    summary = data["summary"]

    print("\n📊 Evolution Summary:")
    print(f"   Generations: {summary['total_generations']}")
    print(
        f"   Gen range:   {summary.get('gen_range', ['?', '?'])[0]} → {summary.get('gen_range', ['?', '?'])[1]}"
    )
    print(
        f"   Best gen:    {summary.get('best_generation', '?')} (fitness={summary.get('best_fitness', '?'):.2f})"
    )
    print(f"   Best return: {summary.get('best_return_pct', '?'):.1f}%")
    print(f"   Best MaxDD:  {summary.get('best_max_dd', '?'):.2f}%")
    print(f"   Best Sharpe: {summary.get('best_sharpe', '?'):.2f}")


if __name__ == "__main__":
    main()
