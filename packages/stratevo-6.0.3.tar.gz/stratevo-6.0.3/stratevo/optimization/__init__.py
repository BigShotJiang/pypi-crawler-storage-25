"""stratevo.optimization - Portfolio and strategy optimization."""
