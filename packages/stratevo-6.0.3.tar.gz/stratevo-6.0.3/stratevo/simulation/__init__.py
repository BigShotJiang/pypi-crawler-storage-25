"""stratevo.simulation - Market simulation scenarios."""
