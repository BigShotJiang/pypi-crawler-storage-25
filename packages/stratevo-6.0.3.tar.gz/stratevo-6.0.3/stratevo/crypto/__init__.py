"""stratevo.crypto - Cryptocurrency trading tools."""
