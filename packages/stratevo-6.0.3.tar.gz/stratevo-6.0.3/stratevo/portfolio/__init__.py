"""stratevo.portfolio - Portfolio tracking and optimization."""

from stratevo.portfolio.tracker import PortfolioTracker
from stratevo.portfolio.optimizer import PortfolioOptimizer
from stratevo.portfolio.rebalancer import PortfolioRebalancer

__all__ = [
    "PortfolioTracker",
    "PortfolioOptimizer",
    "PortfolioRebalancer",
]

try:
    from stratevo.portfolio.attribution import PerformanceAttribution
    __all__.append("PerformanceAttribution")
except ImportError:
    pass

try:
    from stratevo.portfolio.tax_tracker import TaxLotTracker
    __all__.append("TaxLotTracker")
except ImportError:
    pass
