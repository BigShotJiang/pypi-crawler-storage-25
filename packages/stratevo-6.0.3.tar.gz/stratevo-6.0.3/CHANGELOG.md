# Changelog

All notable changes to this project will be documented in this file.
Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [6.0.0] - 2026-04-10

### Changed
- **Project renamed: FinClaw → StratEvo** — repo, package, CLI, all imports updated
- All internal references migrated (652+ files, Dockerfile, dashboard, SVGs, configs)
- README toned down, added honest comparison with competitors, backtest disclaimers

### Added
- Factor decay detection (`stratevo factor-decay`) — rolling Spearman IC monitoring with built-in factors (momentum, volatility, mean_reversion). Contributed by @nandanadileep (#16)
- Better CLI error messages — missing data suggests `--quick`, missing ccxt shows install hint

### Fixed
- HTML nesting bug in README architecture diagram
- Remaining finclaw references in Dockerfile, dashboard TSX, SVG assets, config files

## [5.6.1] - 2026-04-10

### Fixed
- **CI: all 26 test file ignores removed** — 7500+ tests now run in CI (was ~5000)
  - Renamed `test_cli_integration.py` → `test_cli_e2e.py` to avoid `-k "not integration"` false match
  - Renamed `test_plugin_integration.py` → `test_plugin_e2e.py` for same reason
  - Added `pytest.mark.skipif` for ccxt-dependent tests (auto-skip when ccxt not installed)
  - Fixed flaky HMM test (`test_bear_data_labelled_bear`) — increased data, reduced regimes
- **CONTRIBUTING.md: fixed all incorrect paths** — `src/` → `stratevo/`, updated project structure
- **.gitignore: fixed corrupted wide-character entries** at end of file

### Changed
- Moved 27 internal debug scripts to `scripts/internal/`
- Removed `SKILL.md`, `KNOWN_BUGS.md`, `test_dna.json` from repo root
- Updated GitHub repo description for better SEO
- Enabled GitHub Discussions

## [5.6.0] - 2026-04-07

### Added
- **US stock evolution** — `stratevo evolve --market us` with auto-download via yfinance (SP500 top 50)
- **Cross-market comparison** — `stratevo compare-markets` tests same DNA across A-shares, US, and crypto
- Quick mode for US: `stratevo evolve --quick --market us` (5 stocks, ~2 min)
- Standalone download script: `scripts/download_us.py`

### Changed
- US-specific tuning: 0.1% slippage, 1000% annual cap, no limit-up/down restrictions
- US walk-forward config: 4 windows × 15% OOS (each ~9 months)

## [5.5.0] - 2026-04-07

### Added
- **Swing trading support** — hold_days range expanded to 2–60 days
- `capital_utilization` parameter (0.3–1.0) — controls deployed capital fraction
- `trend_exit_enabled` — MA crossover dynamic exit for swing trades
- Architecture diagram (hand-drawn style via D2) in README

### Changed
- take_profit_pct range expanded to 3–200% (catch multi-baggers)
- stop_loss_pct range expanded to 0.5–25% (accommodate longer holds)
- A-share walk-forward: 3 windows × 20% (each ~1 year) instead of 5 × 10%
- Trade count penalty softened for swing strategies (3→8 ramp instead of 10→30)
- min_trades_per_window reduced to 3
- Dashboard screenshots removed from README (showed outdated validation data)
- Honest disclosure updated: mentions year-long OOS windows and return gates

## [5.4.0] - 2026-03-29

### Added
- **Crypto seed DNA** — 5 expert-designed starter strategies for crypto evolution
- `--quick` mode — small dataset, fast iterations, results in ~2 minutes
- Crypto sample data bundled for zero-setup quick mode
- Escalating stagnation injection (L1→L2→L3) for plateau breaking
- 8 walk-forward windows, adaptive stop-loss, weekly trend confirmation
- Kelly criterion position sizing (`kelly_fraction` parameter)
- Factor momentum — adjust selectivity based on recent performance
- 10 classic seed strategies with docs and hand-drawn flow diagrams
- SBX crossover, polynomial mutation, adaptive population sizing
- LLM-guided factor discovery, HMM regime detection
- Auto-download market data (`--download` flag)
- MkDocs documentation site, Gradio Web UI
- Security hardening (input validation, sandbox)

### Fixed
- **Critical: chained CAGR for walk-forward** — industry-standard OOS aggregation
- **Critical: trade-level Sharpe ratio** — was using daily returns, now per-trade
- Sharpe clamped to [-10, 10], min 5 samples required
- Market-aware annual return cap (500% A-share, 5000% crypto)
- Crypto evolution bugs: CAGR calculation, Sharpe, WF window config
- Catastrophic window penalty + lower consistency floor
- OOS-negative fitness gradient preserved (was being zeroed out)
- 13 pre-existing test failures marked xfail
- Ruff F821 lint errors resolved for CI
- Adaptive population override disabled (was forcing pop to 46)
- CLI refactored: split 4300-line main.py into 9 command modules
- Private/temp files cleaned from public repo

### Changed
- P0 market regime gate: `min_breadth_to_trade` prevents trading in bear markets
- Shared metrics module extracted from scoring
- 24 regression tests added for backtest accuracy

## [5.3.0] - 2026-03-23

### Added
- **Crypto-first positioning** — README rewritten to lead with crypto trading
- `stratevo download-crypto` — Download OHLCV data for top 20 crypto pairs
- `stratevo evolve --market crypto` — GA evolution on crypto market data
- `stratevo live --market crypto --mode dry-run` — Paper trading with live exchange feeds
- Telegram notifications for trade signals, executions, and daily summaries
- Risk management config: max drawdown, position limits, stop-loss, daily loss caps
- Crypto trading getting started guide (`docs/crypto-trading/getting-started.md`)
- `[crypto]` optional dependency group in pyproject.toml
- Comparison table vs Freqtrade / 3Commas in README
- New badges: 100+ exchanges, crypto+stocks market indicator
- 47 new tests for crypto download, evolution, and live trading modules (total: 4800+)

### Changed
- README hero line: "Self-evolving crypto trading strategies"
- Quick Start now shows crypto workflow first
- Data Sources table reordered: crypto first
- Dashboard highlights crypto portfolio tracker
- pyproject.toml description updated for crypto-first positioning
- pyproject.toml keywords expanded with crypto, bitcoin, genetic-algorithm, ccxt
- `[full]` extras now include `ccxt>=4.0`

## [5.2.0] - 2026-03-23

### Added
- Factor Quality Analysis: IC/IR/decay/tier classification for all 217 factors
- Factor Correlation Matrix: NxN orthogonality detection with auto-pruning
- 21 new factors: 10 alternative data + 11 Qlib Alpha158 gap-fill
- Monte Carlo validation for strategy robustness
- Turnover penalty in fitness function
- best_ever.json: persistent all-time best strategy DNA
- Hall of Fame: timestamped copies of every record-breaking DNA
- 291 new tests (total: 4753+)
- Factor gap analysis vs Qlib Alpha158 (docs/factor_gap_analysis.md)
- Code coverage with pytest-cov (.coveragerc + CI integration)

### Fixed
- Limit-down exit bug in backtest engine
- 10 stale test references to removed modules
- Killed stale download_a_shares.py process

## [5.1.0] - 2026-03-21

### Added
- Real-time dashboard with live market data (US, CN, Crypto)
- Stock detail pages with TradingView charts and technical indicators
- Strategy evolution engine with genetic algorithm optimization
- Walk-forward validation and Monte Carlo simulation
- Multi-agent debate system for consensus-based analysis
- A2A (Agent-to-Agent) protocol support
- MCP server for AI agent integration

### Changed
- Dashboard redesigned with professional UI (no emoji, data-dense layout)
- All market data now fetched from real APIs (Yahoo Finance, Sina, CoinGecko)
- README cleaned up for professional open-source presentation

### Fixed
- Exchange adapters now handle network errors with retry and rate limiting
- Flaky timestamp test in snapshot manager
- SMA values on homepage cards were showing stale mock data

## [0.1.0] - 2026-03-17

Initial release.

### Features
- **StratEvo API** - High-level `StratEvo` class with `quote()`, `backtest()`, and `paper_trade()` methods
- **Yahoo Finance adapter** - Real-time quotes via yfinance, no API key needed
- **Backtesting engine** - Event-driven backtester with slippage/commission models
- **Paper trading** - Simulated live trading with built-in strategy runners
- **MCP Server** - Model Context Protocol integration for AI agents (Claude, Cursor, OpenClaw)
- **CLI** - Command-line interface for quotes, backtesting, and scanning
- **WebSocket streaming** - Real-time data from Binance, OKX, Bybit
- **Strategy library** - YAML-configured strategies (momentum, mean-reversion, grid, DCA)
- **HTML reports** - Backtest tearsheets with equity curves and drawdown analysis
- **Plugin system** - Extensible architecture for custom strategies and exchange adapters
