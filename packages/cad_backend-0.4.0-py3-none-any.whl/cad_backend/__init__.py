"""Unified AutoCAD + NXOpen API backend server."""

__version__ = "0.4.0"
