"""Billing helpers: projected-cost adjustment and soft budget warnings.

Claude Opus 4.7 ships with a new tokenizer that produces ~35% more tokens
for the same prompt compared to 4.6.  Actual cost still comes from the API
response (`total_cost_usd`), but *projections* and *budget warnings* must
account for the inflation, otherwise the user is surprised when the budget
runs out earlier than estimated.
"""

from __future__ import annotations

from dataclasses import dataclass

# Conservative single-pass multiplier applied to projected usage when the
# active model is Opus 4.7.  Raise this if Anthropic publishes new numbers.
OPUS_47_TOKENIZER_MULTIPLIER: float = 1.35

# Default "soft warning" threshold: warn the user once they have spent
# 80% of their max_budget_usd on projected basis.
DEFAULT_WARNING_THRESHOLD: float = 0.80

# Model id substrings that opt the projection into the +35% multiplier.
_OPUS_47_MARKERS: tuple[str, ...] = ("opus-4-7", "opus-4.7")


def model_uses_new_tokenizer(model_id: str | None) -> bool:
    """Return True when *model_id* is an Opus 4.7 release.

    Accepts both the alias ``opus`` (when paired with a 4.7 override) and
    explicit IDs like ``claude-opus-4-7`` / ``claude-opus-4.7``.
    """
    if not model_id:
        return False
    lowered = model_id.lower()
    return any(marker in lowered for marker in _OPUS_47_MARKERS)


def projected_cost_usd(
    actual_cost_usd: float,
    model_id: str | None,
    *,
    multiplier: float = OPUS_47_TOKENIZER_MULTIPLIER,
) -> float:
    """Return *actual_cost_usd* adjusted for tokenizer inflation.

    The API already bills exact tokens, so this helper is for *forecasting*
    only — it inflates the observed cost by ``multiplier`` when the model
    uses the new tokenizer, otherwise returns the value unchanged.
    """
    if actual_cost_usd <= 0:
        return 0.0
    if model_uses_new_tokenizer(model_id):
        return actual_cost_usd * multiplier
    return actual_cost_usd


@dataclass(frozen=True, slots=True)
class BudgetStatus:
    """Outcome of comparing projected spend against ``max_budget_usd``."""

    level: str  # "ok" | "warn" | "over"
    projected_usd: float
    max_budget_usd: float
    fraction: float  # projected / max_budget; >=0

    @property
    def percent(self) -> int:
        return int(round(self.fraction * 100))


def budget_status(
    actual_cost_usd: float,
    max_budget_usd: float | None,
    model_id: str | None,
    *,
    threshold: float = DEFAULT_WARNING_THRESHOLD,
    multiplier: float = OPUS_47_TOKENIZER_MULTIPLIER,
) -> BudgetStatus | None:
    """Classify the current spend against the configured budget.

    Returns ``None`` when no budget is set or the budget is non-positive.
    ``level`` is one of:

    - ``"ok"``   — projected spend is below ``threshold`` of the budget.
    - ``"warn"`` — projected spend has crossed the threshold.
    - ``"over"`` — projected spend has fully consumed the budget.
    """
    if max_budget_usd is None or max_budget_usd <= 0:
        return None
    projected = projected_cost_usd(actual_cost_usd, model_id, multiplier=multiplier)
    fraction = projected / max_budget_usd
    if fraction >= 1.0:
        level = "over"
    elif fraction >= threshold:
        level = "warn"
    else:
        level = "ok"
    return BudgetStatus(
        level=level,
        projected_usd=projected,
        max_budget_usd=max_budget_usd,
        fraction=fraction,
    )


def format_budget_warning(status: BudgetStatus) -> str:
    """Render a one-line user-facing warning for *status* (English).

    Returns an empty string for ``"ok"`` so callers can append unconditionally.
    """
    if status.level == "ok":
        return ""
    if status.level == "over":
        return (
            f"Budget exceeded: projected ${status.projected_usd:.2f} "
            f"of ${status.max_budget_usd:.2f} (≥100%). "
            "Costs include +35% Opus 4.7 tokenizer adjustment."
        )
    return (
        f"Budget warning: projected ${status.projected_usd:.2f} "
        f"of ${status.max_budget_usd:.2f} ({status.percent}%). "
        "Costs include +35% Opus 4.7 tokenizer adjustment."
    )
