"""Direct API: WebSocket server with E2E encryption."""

from sygen_bot.api.server import ApiServer

__all__ = ["ApiServer", "E2ESession"]


def __getattr__(name: str):  # noqa: ANN001
    if name == "E2ESession":
        from sygen_bot.api.crypto import E2ESession

        return E2ESession
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
