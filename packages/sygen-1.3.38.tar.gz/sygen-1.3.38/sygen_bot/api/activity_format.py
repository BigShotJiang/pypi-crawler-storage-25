"""Localized formatting for activity events and uptime strings.

The mobile app and the admin panel both consume `/api/activity/recent`
and `/api/dashboard/summary`, which must return already-localized
`title`/`subtitle`/`severity` so the clients never render raw machine
types like ``AGENT_TASK_FINISHED_OK``.
"""

from __future__ import annotations

import time
from typing import Any

# Supported locales. Default is Russian (primary user base).
SUPPORTED_LANGS: tuple[str, ...] = ("ru", "en")
DEFAULT_LANG = "ru"

# Severity values returned to clients. Map internal notification severities
# (critical/warning/info/silent) to the event-stream severities
# (info/success/warning/error) used by the mobile/admin UIs.
EVENT_SEVERITIES: tuple[str, ...] = ("info", "success", "warning", "error")

# Machine event types documented in the spec §2.
KNOWN_EVENT_TYPES: tuple[str, ...] = (
    "task_completed",
    "task_failed",
    "agent_started",
    "agent_stopped",
    "cron_fired",
    "cron_failed",
    "webhook_called",
    "auth_login",
)

# Default severity per event type (spec §2 table).
_TYPE_SEVERITY: dict[str, str] = {
    "task_completed": "info",
    "task_failed": "error",
    "agent_started": "success",
    "agent_stopped": "warning",
    "cron_fired": "info",
    "cron_failed": "error",
    "webhook_called": "info",
    "auth_login": "info",
}

# Title templates keyed by (type, lang). `{name}` / `{agent}` / `{user}`
# are filled from the event record.
_TITLE_TEMPLATES: dict[tuple[str, str], str] = {
    ("task_completed", "ru"): "Задача «{name}» завершена",
    ("task_completed", "en"): "Task “{name}” completed",
    ("task_failed", "ru"): "Задача «{name}» упала",
    ("task_failed", "en"): "Task “{name}” failed",
    ("agent_started", "ru"): "Агент {agent} запущен",
    ("agent_started", "en"): "Agent {agent} started",
    ("agent_stopped", "ru"): "Агент {agent} остановлен",
    ("agent_stopped", "en"): "Agent {agent} stopped",
    ("cron_fired", "ru"): "Cron «{name}» выполнен",
    ("cron_fired", "en"): "Cron “{name}” fired",
    ("cron_failed", "ru"): "Cron «{name}» упал",
    ("cron_failed", "en"): "Cron “{name}” failed",
    ("webhook_called", "ru"): "Webhook {name} принял запрос",
    ("webhook_called", "en"): "Webhook {name} received a request",
    ("auth_login", "ru"): "Вход {user}",
    ("auth_login", "en"): "Login {user}",
}

# Fallback titles for unknown types (system/user/etc.) — per-locale verbs
# so we never leak raw machine strings like ``AGENT_TASK_FINISHED_OK``.
_FALLBACK_TITLES: dict[str, dict[str, str]] = {
    "ru": {
        "system": "Системное событие",
        "user": "Пользователь {target}",
        "login": "Вход {user}",
        "agent": "Событие агента",
        "task": "Событие задачи",
        "cron": "Событие cron",
        "webhook": "Событие webhook",
    },
    "en": {
        "system": "System event",
        "user": "User {target}",
        "login": "Login {user}",
        "agent": "Agent event",
        "task": "Task event",
        "cron": "Cron event",
        "webhook": "Webhook event",
    },
}

_GENERIC_FALLBACK: dict[str, str] = {
    "ru": "Событие",
    "en": "Event",
}

_RELATIVE_UNITS_RU: tuple[tuple[int, str, str, str], ...] = (
    (60, "сек", "сек", "сек"),
    (3600, "мин", "мин", "мин"),
    (86400, "ч", "ч", "ч"),
    (2592000, "д", "д", "д"),
)

_RELATIVE_UNITS_EN: tuple[tuple[int, str, str, str], ...] = (
    (60, "s", "s", "s"),
    (3600, "m", "m", "m"),
    (86400, "h", "h", "h"),
    (2592000, "d", "d", "d"),
)

_JUST_NOW: dict[str, str] = {"ru": "только что", "en": "just now"}
_AGO: dict[str, str] = {"ru": "назад", "en": "ago"}


def parse_accept_language(header: str | None) -> str:
    """Return the first supported tag from an ``Accept-Language`` header.

    Empty/unknown → ``DEFAULT_LANG`` (ru). Only the primary tag is honoured;
    quality values and region subtags (``en-US``) are stripped.
    """
    if not header:
        return DEFAULT_LANG
    for part in header.split(","):
        tag = part.strip().split(";", 1)[0].strip().lower()
        if not tag:
            continue
        primary = tag.split("-", 1)[0]
        if primary in SUPPORTED_LANGS:
            return primary
    return DEFAULT_LANG


def format_uptime(seconds: float | int) -> str:
    """Human-readable uptime. Examples: ``9d 18h``, ``3h 12m``, ``4m 30s``.

    < 60 s → ``Ns``. Negative / non-finite input → ``0s``.
    """
    try:
        total = int(seconds)
    except (TypeError, ValueError):
        return "0s"
    if total < 0:
        total = 0

    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, secs = divmod(rem, 60)

    if days > 0:
        return f"{days}d {hours}h" if hours else f"{days}d"
    if hours > 0:
        return f"{hours}h {minutes}m" if minutes else f"{hours}h"
    if minutes > 0:
        return f"{minutes}m {secs}s" if secs else f"{minutes}m"
    return f"{secs}s"


def _relative_time(delta_seconds: float, lang: str) -> str:
    """Turn a delta (now - event_ts) into a short localized string."""
    if delta_seconds < 0:
        delta_seconds = 0
    if delta_seconds < 45:
        return _JUST_NOW.get(lang, _JUST_NOW[DEFAULT_LANG])

    units = _RELATIVE_UNITS_RU if lang == "ru" else _RELATIVE_UNITS_EN
    value = int(delta_seconds)
    if value < 60:
        n, suffix = value, units[0][1]
    elif value < 3600:
        n, suffix = value // 60, units[1][1]
    elif value < 86400:
        n, suffix = value // 3600, units[2][1]
    else:
        n, suffix = value // 86400, units[3][1]

    ago = _AGO.get(lang, _AGO[DEFAULT_LANG])
    return f"{n} {suffix} {ago}"


def _coerce_timestamp(ts: Any) -> float:
    """Best-effort epoch seconds from int/float/ISO-8601 string."""
    if isinstance(ts, (int, float)):
        return float(ts)
    if isinstance(ts, str) and ts:
        s = ts.rstrip("Z")
        for fmt in ("%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f"):
            try:
                import calendar
                tm = time.strptime(s, fmt)
                return calendar.timegm(tm)
            except ValueError:
                continue
    return 0.0


def severity_for_type(event_type: str, fallback_severity: str | None = None) -> str:
    """Return the canonical severity for a known type, else fallback or ``info``."""
    if event_type in _TYPE_SEVERITY:
        return _TYPE_SEVERITY[event_type]
    if fallback_severity in EVENT_SEVERITIES:
        return fallback_severity  # type: ignore[return-value]
    return "info"


def _render_title(event_type: str, lang: str, fields: dict[str, Any]) -> str:
    tpl = _TITLE_TEMPLATES.get((event_type, lang))
    if tpl is None:
        tpl = _TITLE_TEMPLATES.get((event_type, DEFAULT_LANG))
    if tpl is not None:
        safe = {"name": "?", "agent": "?", "user": "?", "target": "?"}
        safe.update({k: ("?" if v in (None, "") else v) for k, v in fields.items()})
        try:
            return tpl.format_map(safe)
        except (KeyError, IndexError):
            return tpl

    # Unknown type fallback.
    bucket = _FALLBACK_TITLES.get(lang) or _FALLBACK_TITLES[DEFAULT_LANG]
    tpl_fb = bucket.get(event_type)
    if tpl_fb is None:
        return _GENERIC_FALLBACK.get(lang, _GENERIC_FALLBACK[DEFAULT_LANG])
    try:
        return tpl_fb.format_map({
            "target": fields.get("target") or fields.get("name") or "?",
            "user": fields.get("user") or "?",
        })
    except (KeyError, IndexError):
        return tpl_fb


def format_event(event: dict[str, Any], lang: str, *, now: float | None = None) -> dict[str, Any]:
    """Return ``{title, subtitle, severity}`` for an activity event.

    ``event`` is the raw aggregated record with at least ``type`` and
    ``timestamp``. Optional fields: ``name`` (task/cron/webhook name),
    ``agent`` (agent id), ``user`` (auth actor), ``severity`` (fallback).
    ``now`` is injected in tests to keep relative times deterministic.
    """
    lang = lang if lang in SUPPORTED_LANGS else DEFAULT_LANG
    event_type = str(event.get("type") or "")
    agent = event.get("agent") or event.get("agent_name") or ""
    user = event.get("user") or event.get("actor") or ""
    name = event.get("name") or ""
    target = event.get("target") or ""

    title = _render_title(
        event_type,
        lang,
        {"name": name, "agent": agent, "user": user, "target": target},
    )

    actor = agent or user or target or ""
    now_ts = now if now is not None else time.time()
    event_ts = _coerce_timestamp(event.get("timestamp"))
    rel = _relative_time(now_ts - event_ts, lang) if event_ts else ""

    if actor and rel:
        subtitle = f"{actor} · {rel}"
    elif rel:
        subtitle = rel
    else:
        subtitle = actor

    severity = severity_for_type(event_type, event.get("severity"))
    return {"title": title, "subtitle": subtitle, "severity": severity}
