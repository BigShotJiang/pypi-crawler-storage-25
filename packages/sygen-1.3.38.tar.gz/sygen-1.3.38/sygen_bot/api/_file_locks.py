"""Process-wide async lock registry for JSON file writes.

Modules that touch the same files (e.g. ``rest_routes.save_chat_message``
and ``chat_history.persist_chat_message`` both write
``chat_history/<sid>.json``) must coordinate through one shared lock per
path — separate registries would race each other and produce truncated
or partially-merged JSON.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

# Single registry shared across modules. Re-exported by callers under
# their original local names for backwards compatibility with existing
# tests that monkeypatch ``module._file_locks``.
FILE_LOCKS: dict[str, asyncio.Lock] = {}


def lock_for(path: Path) -> asyncio.Lock:
    """Return (creating if needed) the asyncio.Lock for ``path``."""
    key = str(path)
    lock = FILE_LOCKS.get(key)
    if lock is None:
        lock = FILE_LOCKS.setdefault(key, asyncio.Lock())
    return lock
