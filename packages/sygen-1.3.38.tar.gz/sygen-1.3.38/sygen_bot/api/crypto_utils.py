"""Crypto helpers for at-rest encryption of sensitive secrets.

Currently used to encrypt TOTP shared secrets in ``users.json`` so a leak
of the user DB does not expose 2FA seeds.  The encryption key is derived
deterministically from the JWT secret so no separate key material has to
be managed — rotating the JWT secret invalidates old ciphertexts, which
is the intended behavior (they will be migrated transparently on read).
"""

from __future__ import annotations

import base64
import hashlib
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_SALT_TOTP = b"sygen-totp-salt-v1"
_PBKDF2_ITERS = 100_000
_KEY_LEN = 32
_NONCE_LEN = 12
_VERSION = b"\x01"


def _derive_totp_key(jwt_secret: str) -> bytes:
    """Derive a 256-bit AES key from the JWT secret (PBKDF2-HMAC-SHA256)."""
    if not jwt_secret:
        raise ValueError("jwt_secret required for TOTP encryption key derivation")
    return hashlib.pbkdf2_hmac(
        "sha256",
        jwt_secret.encode("utf-8"),
        _SALT_TOTP,
        _PBKDF2_ITERS,
        _KEY_LEN,
    )


def encrypt_totp_secret(plaintext: str, jwt_secret: str) -> str:
    """Encrypt a TOTP secret with AES-256-GCM. Returns a base64 string.

    Layout: ``b"\\x01" || nonce(12) || ciphertext || tag(16)`` then base64.
    """
    key = _derive_totp_key(jwt_secret)
    nonce = os.urandom(_NONCE_LEN)
    aes = AESGCM(key)
    ct = aes.encrypt(nonce, plaintext.encode("utf-8"), None)
    blob = _VERSION + nonce + ct
    return base64.b64encode(blob).decode("ascii")


def decrypt_totp_secret(ciphertext_b64: str, jwt_secret: str) -> str:
    """Decrypt a value produced by :func:`encrypt_totp_secret`.

    Raises :class:`ValueError` if the blob is malformed or authentication fails.
    """
    try:
        blob = base64.b64decode(ciphertext_b64, validate=True)
    except (ValueError, base64.binascii.Error) as exc:  # type: ignore[attr-defined]
        raise ValueError("invalid ciphertext encoding") from exc
    if len(blob) < 1 + _NONCE_LEN + 16 or blob[:1] != _VERSION:
        raise ValueError("unsupported ciphertext format")
    nonce = blob[1 : 1 + _NONCE_LEN]
    ct = blob[1 + _NONCE_LEN :]
    key = _derive_totp_key(jwt_secret)
    aes = AESGCM(key)
    pt = aes.decrypt(nonce, ct, None)
    return pt.decode("utf-8")


def looks_like_encrypted_totp(value: str) -> bool:
    """Best-effort detector: True if ``value`` looks like a v1 encrypted blob.

    Used to decide whether to migrate a legacy plaintext TOTP secret to
    the encrypted format on first read.
    """
    if not value:
        return False
    try:
        blob = base64.b64decode(value, validate=True)
    except (ValueError, base64.binascii.Error):  # type: ignore[attr-defined]
        return False
    return len(blob) >= 1 + _NONCE_LEN + 16 and blob[:1] == _VERSION
