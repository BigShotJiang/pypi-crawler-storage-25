"""Throttling for notification deliveries.

Foundation for future push notifications. The function is invoked from the
observer wiring but its return value is currently only logged — no real
push delivery is suppressed yet. The cache is in-memory and per-process.
"""

from __future__ import annotations

import logging
import threading
import time
from collections import OrderedDict

logger = logging.getLogger(__name__)

THROTTLE_WINDOW_SECONDS: float = 60.0
MAX_CACHE_ENTRIES: int = 500

_lock = threading.Lock()
_last_seen: "OrderedDict[str, float]" = OrderedDict()


def _record_locked(source_id: str, now: float) -> None:
    """Insert/refresh source_id and evict the oldest entry when over cap."""
    if source_id in _last_seen:
        _last_seen.move_to_end(source_id)
    _last_seen[source_id] = now
    while len(_last_seen) > MAX_CACHE_ENTRIES:
        _last_seen.popitem(last=False)


def should_throttle(source_id: str, severity: str) -> bool:
    """Decide whether a push for this (source_id, severity) should be skipped.

    Rules:
      - critical: never throttled, always delivered.
      - warning / info: throttled if a record for the same source_id was
        observed within THROTTLE_WINDOW_SECONDS.
      - silent: always throttled (no push).
      - unknown severities: treated as 'info'.
    """
    if severity == "critical":
        with _lock:
            _record_locked(source_id, time.monotonic())
        logger.debug("notification_throttle: critical pass-through (source_id=%s)", source_id)
        return False

    if severity == "silent":
        logger.debug("notification_throttle: silent suppressed (source_id=%s)", source_id)
        return True

    now = time.monotonic()
    with _lock:
        last = _last_seen.get(source_id)
        throttle = last is not None and (now - last) < THROTTLE_WINDOW_SECONDS
        _record_locked(source_id, now)

    if throttle:
        logger.debug(
            "notification_throttle: suppressed within window (source_id=%s severity=%s)",
            source_id,
            severity,
        )
    return throttle


def reset_throttle_cache() -> None:
    """Clear the throttle cache. Intended for tests."""
    with _lock:
        _last_seen.clear()
