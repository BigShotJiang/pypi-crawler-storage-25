#!/usr/bin/env python3
"""List all registered sub-agents and their configuration.

Usage:
    python3 list_agents.py
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def _main_home() -> Path:
    """Resolve the main agent's sygen_home regardless of caller location."""
    import os

    home = Path(os.environ.get("SYGEN_HOME", str(Path.home() / ".sygen")))
    if home.name == ".sygen" or (home / "config").is_dir():
        return home
    candidate = home.parent.parent
    if (candidate / "config").is_dir() or candidate.name == ".sygen":
        return candidate
    return home


def _agents_path() -> Path:
    """Resolve canonical agents.json path with legacy fallback for reads."""
    home = _main_home()
    canonical = home / "_secrets" / "agents.json"
    legacy = home / "agents.json"
    if not canonical.exists() and legacy.is_file():
        return legacy
    return canonical


def main() -> None:
    path = _agents_path()
    if not path.is_file():
        print("No agents.json found. No sub-agents configured.")
        return

    try:
        agents = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        print("Error: Failed to read agents.json", file=sys.stderr)
        sys.exit(1)

    if not agents:
        print("No sub-agents configured.")
        return

    print(f"Registered sub-agents ({len(agents)}):\n")
    for agent in agents:
        name = agent.get("name", "?")
        token = agent.get("telegram_token", "?")
        users = agent.get("allowed_user_ids", [])
        provider = agent.get("provider", "(inherited)")
        model = agent.get("model", "(inherited)")

        # Check if workspace exists
        agent_home = _main_home() / "agents" / name
        workspace_status = "exists" if agent_home.is_dir() else "not created"

        print(f"  {name}")
        print(f"    Token:     {token[:8]}...")
        print(f"    Users:     {users}")
        print(f"    Provider:  {provider}")
        print(f"    Model:     {model}")
        print(f"    Workspace: {workspace_status}")
        print()


if __name__ == "__main__":
    main()
