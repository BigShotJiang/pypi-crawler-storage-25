#!/usr/bin/env python3
"""Remove a sub-agent from agents.json.

The agent is stopped automatically (FileWatcher detects the removal).
The agent's workspace is preserved and can be reused.

Usage:
    python3 remove_agent.py NAME
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


def _main_home() -> Path:
    """Resolve the main agent's sygen_home regardless of caller location."""
    import os

    home = Path(os.environ.get("SYGEN_HOME", str(Path.home() / ".sygen")))
    if home.name == ".sygen" or (home / "config").is_dir():
        return home
    candidate = home.parent.parent
    if (candidate / "config").is_dir() or candidate.name == ".sygen":
        return candidate
    return home


def _agents_path_for_read() -> Path:
    """Canonical agents.json path with legacy fallback for reads."""
    home = _main_home()
    canonical = home / "_secrets" / "agents.json"
    legacy = home / "agents.json"
    if not canonical.exists() and legacy.is_file():
        return legacy
    return canonical


def _agents_path_for_write() -> Path:
    """Canonical agents.json path for writes (always ``_secrets/agents.json``)."""
    home = _main_home()
    secrets_dir = home / "_secrets"
    secrets_dir.mkdir(parents=True, exist_ok=True)
    try:
        secrets_dir.chmod(0o700)
    except OSError:
        pass
    return secrets_dir / "agents.json"


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python3 remove_agent.py NAME", file=sys.stderr)
        sys.exit(1)

    name = sys.argv[1].strip().lower()
    if name == "main":
        print("Error: Cannot remove the main agent.", file=sys.stderr)
        sys.exit(1)

    read_path = _agents_path_for_read()
    if not read_path.is_file():
        print(f"Error: No agents.json found at {read_path}", file=sys.stderr)
        sys.exit(1)

    try:
        agents = json.loads(read_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        print("Error: Failed to read agents.json", file=sys.stderr)
        sys.exit(1)

    remaining = [a for a in agents if a.get("name") != name]
    if len(remaining) == len(agents):
        print(f"Error: Agent '{name}' not found.", file=sys.stderr)
        sys.exit(1)

    write_path = _agents_path_for_write()
    write_path.write_text(
        json.dumps(remaining, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    write_path.chmod(0o600)
    print(f"Agent '{name}' removed from registry.")
    print("The agent will stop automatically within a few seconds.")
    print(f"Note: The workspace at agents/{name}/ is preserved.")


if __name__ == "__main__":
    main()
