#!/usr/bin/env python3
"""Send an async task to another agent via the InterAgentBus.

Unlike ask_agent.py, this returns immediately with a task_id.
The sub-agent's response is delivered back to YOUR Telegram chat
(the calling agent's chat) when ready — NOT to the sub-agent's chat.

The response ALWAYS comes back to YOU (the calling agent). There is no way
to make the sub-agent reply in its own Telegram chat via this tool.

Uses the internal localhost HTTP API to communicate with the bus.
Environment variables SYGEN_AGENT_NAME, SYGEN_INTERAGENT_PORT, and
SYGEN_INTERAGENT_HOST are automatically set by the Sygen framework.

Usage:
    python3 ask_agent_async.py [--new] [--summary "Short description"] TARGET_AGENT "Your message here"

Options:
    --new                Start a fresh session, discarding any prior inter-agent context
                         with the recipient. Without this flag, the recipient resumes
                         the existing session (if any).
    --summary "text"     Short description shown in the recipient's Telegram chat
                         notification instead of a truncated message excerpt.

The end-user identity is taken from the ``SYGEN_CALLER_USER_ID`` environment
variable, which the Sygen framework sets from the authenticated transport
(Telegram/Matrix/API). Overriding it from the command line is intentionally
not supported — doing so would let prompt-injected LLM tool calls impersonate
another user and bypass per-user ACLs.
"""

from __future__ import annotations

import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path


def _find_main_home() -> Path | None:
    """Locate the main agent's sygen_home (see ask_agent.py for rationale)."""
    shared = os.environ.get("SYGEN_SHARED_MEMORY_PATH")
    if shared:
        return Path(shared).parent
    home = os.environ.get("SYGEN_HOME")
    if home:
        return Path(home)
    return None


def _resolve_secret_path(home: Path, filename: str) -> Path:
    """Return ``home/_secrets/filename`` with a fallback to the legacy location."""
    canonical = home / "_secrets" / filename
    legacy = home / filename
    if not canonical.exists() and legacy.is_file():
        return legacy
    return canonical


def _load_caller_token(agent_name: str) -> str | None:
    """Return the inter-agent token for ``agent_name`` or None in legacy mode."""
    main_home = _find_main_home()
    if main_home is None:
        return None
    try:
        if agent_name == "main":
            path = _resolve_secret_path(main_home, "main_agent_token.json")
            if path.is_file():
                data = json.loads(path.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    token = data.get("interagent_token")
                    if isinstance(token, str) and token:
                        return token
            return None
        agents_path = _resolve_secret_path(main_home, "agents.json")
        if not agents_path.is_file():
            return None
        data = json.loads(agents_path.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return None
        for entry in data:
            if isinstance(entry, dict) and entry.get("name") == agent_name:
                token = entry.get("interagent_token")
                if isinstance(token, str) and token:
                    return token
        return None
    except (OSError, json.JSONDecodeError):
        return None


def main() -> None:
    args = sys.argv[1:]
    new_session = False
    summary = ""

    # Parse flags
    while args:
        if args[0] == "--new":
            new_session = True
            args = args[1:]
        elif args[0] == "--summary":
            if len(args) < 2:
                print("Error: --summary requires a value", file=sys.stderr)
                sys.exit(1)
            summary = args[1]
            args = args[2:]
        elif args[0] == "--user-id":
            print(
                "Error: --user-id is no longer supported. The caller user id "
                "is taken from the SYGEN_CALLER_USER_ID environment variable, "
                "which the framework sets from the authenticated transport.",
                file=sys.stderr,
            )
            sys.exit(2)
        else:
            break

    if len(args) < 2:
        print(
            'Usage: python3 ask_agent_async.py [--new] [--summary "desc"] '
            'TARGET_AGENT "message"',
            file=sys.stderr,
        )
        sys.exit(1)

    target = args[0]
    message = args[1]
    port = os.environ.get("SYGEN_INTERAGENT_PORT", "8799")
    host = os.environ.get("SYGEN_INTERAGENT_HOST", "127.0.0.1")
    sender = os.environ.get("SYGEN_AGENT_NAME", "unknown")
    user_id = os.environ.get("SYGEN_CALLER_USER_ID", "")

    url = f"http://{host}:{port}/interagent/send_async"
    body: dict[str, object] = {"from": sender, "to": target, "message": message}
    if new_session:
        body["new_session"] = True
    if summary:
        body["summary"] = summary
    if user_id:
        body["caller_user_id"] = user_id
    chat_id = os.environ.get("SYGEN_CHAT_ID", "")
    topic_id = os.environ.get("SYGEN_TOPIC_ID", "")
    if chat_id:
        body["chat_id"] = int(chat_id)
    if topic_id:
        body["topic_id"] = int(topic_id)
    caller_token = _load_caller_token(sender)
    if caller_token:
        body["caller_token"] = caller_token
    else:
        print(
            "Warning: no inter-agent token for this agent; running in legacy mode",
            file=sys.stderr,
        )
    payload = json.dumps(body).encode()

    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        try:
            result = json.loads(e.read().decode())
            error = result.get("error", f"HTTP {e.code}")
        except Exception:
            error = f"HTTP {e.code}"
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)
    except urllib.error.URLError as e:
        print(f"Error: Cannot reach inter-agent API at {url}: {e}", file=sys.stderr)
        print(
            "Make sure the Sygen supervisor is running with multi-agent support.", file=sys.stderr
        )
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    if result.get("success"):
        task_id = result.get("task_id", "unknown")
        print(
            f"Async task sent to '{target}' (task_id: {task_id}). "
            f"The response will be delivered back to your chat when ready."
        )
    else:
        error = result.get("error", "Unknown error")
        print(f"Error: {error}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
