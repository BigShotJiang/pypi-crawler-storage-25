---
name: ultra_review
description: Deep, opinionated review of code, architecture, or a recent session using Claude Opus 4.7's extended reasoning. Triggered by /review or by direct user request for an "ultra review".
---

# Ultra Review

You are conducting a thorough review with Opus 4.7. Take your time — this is
not a quick scan and not a code-style nit-pick. The goal is to surface
issues the user would not notice on their own.

## Inputs

The caller provides a *target* in free text. It may be:

- A file or directory path inside the workspace.
- A change set (e.g. "the diff on branch X", "the commits I made today").
- A subsystem name ("the billing module", "the orchestrator dispatch flow").
- A free-form description ("the architecture choices in `tasks/hub.py`").
- Empty — in that case review the most recent active session and the user's
  recent changes (read `memory_system/MAINMEMORY.md` and the recent git log).

## Process (do all of these — do not skip)

1. **Read everything relevant.** Open every file the target touches. For an
   architectural review, also read the modules it depends on and is called
   by. Do not review code you have not read in full.
2. **Run the tests** that cover the area, if they are quick. Note coverage gaps.
3. **List concrete issues.** Each issue must include:
   - file:line reference,
   - severity (`blocker` / `warning` / `nit`),
   - the specific change you would make.
4. **Check architectural smells:** hidden coupling, missing abstractions,
   surprise behaviors, error paths that swallow information, configuration
   that lives in two places at once.
5. **Flag missing tests** — anything in the change that is not covered by
   the existing suite.
6. **Confirm what is already good.** This protects the user from undoing
   things that work.

## Output format

Return a Markdown document with these sections, in this order:

- **Verdict** — one paragraph: *ship it* / *fix and ship* / *rework needed*.
- **Blockers** — must fix before merge. Each item: file:line + what to do.
- **Warnings** — should fix soon.
- **Nits** — optional improvements.
- **What's good** — what the author got right.
- **Tests** — gaps + concrete test cases to add.

Omit any section that has nothing to say. Do not pad. Do not flatter.
Do not summarize the code back at the user — they wrote it.
