"""Rolling activity log for inter-agent interactions.

Each agent keeps a compact ``AGENT_ACTIVITY.md`` in its workspace so that
the agent has context about recent inter-agent work when the user opens
a direct chat.  The log is a FIFO buffer with a hard entry limit and
an age-based expiry (entries older than ``_MAX_AGE_DAYS`` are dropped
on every write).
"""

from __future__ import annotations

import logging
import re
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

_MAX_ENTRIES = 15
_MAX_AGE_DAYS = 7
_HEADER = "## Recent Inter-Agent Activity (auto-managed)\n"
_ENTRY_RE = re.compile(r"^- \[.+$")
_DATE_RE = re.compile(r"^- \[(\d{2})-(\d{2}) \d{2}:\d{2}\]")


def _entry_age_days(entry: str, now: datetime) -> int | None:
    """Extract the age in days from an entry's date stamp.

    Returns ``None`` when the date cannot be parsed.
    """
    m = _DATE_RE.match(entry)
    if not m:
        return None
    month, day = int(m.group(1)), int(m.group(2))
    try:
        entry_date = now.replace(month=month, day=day)
        # Handle year wrap (e.g. entry from Dec, now is Jan)
        if entry_date > now:
            entry_date = entry_date.replace(year=now.year - 1)
        return (now - entry_date).days
    except ValueError:
        return None


def _read_entries(path: Path) -> list[str]:
    """Read existing log entries from the activity file."""
    if not path.exists():
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    return [line for line in text.splitlines() if _ENTRY_RE.match(line)]


def _write_log(path: Path, entries: list[str]) -> None:
    """Write the log file with header and entries."""
    path.parent.mkdir(parents=True, exist_ok=True)
    content = _HEADER + "\n" + "\n".join(entries) + "\n"
    try:
        path.write_text(content, encoding="utf-8")
    except OSError:
        logger.debug("Failed to write activity log: %s", path, exc_info=True)


def append_activity(
    activity_path: Path,
    *,
    sender: str,
    message_preview: str,
    result_preview: str,
    success: bool,
    elapsed_seconds: float = 0.0,
) -> None:
    """Append a one-line entry to the activity log, trimming old entries."""
    now = datetime.now(tz=timezone.utc)
    now_str = now.strftime("%m-%d %H:%M")
    status = "ok" if success else "error"

    # Compact one-line preview
    msg = message_preview.replace("\n", " ")[:80]
    res = result_preview.replace("\n", " ")[:60]
    elapsed = f" ({elapsed_seconds:.0f}s)" if elapsed_seconds > 1 else ""

    entry = f"- [{now_str}] from:{sender} [{status}{elapsed}] {msg}"
    if res:
        entry += f" → {res}"

    entries = _read_entries(activity_path)
    entries.append(entry)

    # Age-based expiry: drop entries older than _MAX_AGE_DAYS
    entries = [e for e in entries if (_entry_age_days(e, now) or 0) < _MAX_AGE_DAYS]

    # FIFO trim
    if len(entries) > _MAX_ENTRIES:
        entries = entries[-_MAX_ENTRIES:]

    _write_log(activity_path, entries)
