"""Inter-agent access control: per-agent tokens + allow lists.

The supervisor populates this registry on startup with one entry per agent
(including ``main``) pairing the agent's secret ``interagent_token`` with the
optional ``can_call`` allow list from agents.json.

``InternalAgentAPI`` consults it on every ``/interagent/*`` request to
authenticate the caller and enforce the allow list. Agents without an
explicit allow list fall back to legacy behaviour (all recipients allowed).
"""

from __future__ import annotations

import datetime as dt
import json
import logging
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Strict mode: an unknown caller_user_id (passed but not found in users.json)
# is denied instead of falling through to the can_call check.  Stops ghost
# usernames from bypassing the per-user allow list.  Set to False to restore
# legacy "allow unknown" behaviour.
strict_unknown_user: bool = True


@dataclass(slots=True)
class ACLResult:
    """Outcome of an ACL check."""

    allowed: bool
    caller: str
    reason: str = ""
    status: int = 200


@dataclass(slots=True)
class InterAgentACL:
    """Registry of agent tokens and call allow lists."""

    # token -> agent name
    _tokens: dict[str, str] = field(default_factory=dict)
    # agent name -> allow list (empty list = all allowed)
    _allow: dict[str, list[str]] = field(default_factory=dict)
    # Optional path to an append-only JSON-lines audit log.
    audit_path: Path | None = None

    def register(
        self,
        agent: str,
        token: str | None,
        can_call: list[str] | None = None,
    ) -> None:
        """Register an agent with its token and allow list.

        Re-registering the same agent replaces prior entries. Passing
        ``token=None`` clears any existing token for that agent.
        """
        # Drop any previous tokens mapped to this agent so a rotated token
        # does not stay valid forever.
        stale = [t for t, a in self._tokens.items() if a == agent]
        for t in stale:
            self._tokens.pop(t, None)

        if token:
            self._tokens[token] = agent
        self._allow[agent] = list(can_call or [])

    def unregister(self, agent: str) -> None:
        """Remove an agent from the registry."""
        stale = [t for t, a in self._tokens.items() if a == agent]
        for t in stale:
            self._tokens.pop(t, None)
        self._allow.pop(agent, None)

    def resolve_caller(self, token: str) -> str | None:
        """Return the agent name for a valid token, or None."""
        return self._tokens.get(token)

    def check(
        self,
        *,
        caller_token: str | None,
        sender: str,
        recipient: str,
        caller_user_id: str | None = None,
    ) -> ACLResult:
        """Validate a request.

        ``sender`` is the self-declared agent name from the request body
        (used only for logging when no token is supplied). The authoritative
        caller is derived from ``caller_token`` when present.

        ``caller_user_id`` is the username of the end-user on whose behalf the
        call is being made (propagated from the originating entry point — REST,
        Telegram, or an explicit CLI arg). When supplied, the user's
        ``allowed_agents`` list from ``users.json`` is also enforced.
        When ``caller_user_id`` is provided but the user is absent from
        ``users.json``, the call is denied with ``unknown_user`` (strict mode,
        the default). ``caller_user_id=None`` falls back to ``can_call`` only.
        """
        if caller_token:
            caller = self.resolve_caller(caller_token)
            if caller is None:
                return ACLResult(
                    allowed=False,
                    caller=sender or "unknown",
                    reason="invalid_token",
                    status=401,
                )
            allow_list = self._allow.get(caller) or []
            if allow_list and recipient not in allow_list:
                return ACLResult(
                    allowed=False,
                    caller=caller,
                    reason="not_in_can_call",
                    status=403,
                )
            user_check = _check_user_access(caller_user_id, recipient)
            if user_check is not None:
                return ACLResult(
                    allowed=False,
                    caller=caller,
                    reason=user_check,
                    status=403,
                )
            return ACLResult(allowed=True, caller=caller)

        # Legacy mode: no token supplied. Allow with a warning so old clients
        # keep working until every deployment is updated.
        logger.warning(
            "interagent send without caller_token (legacy): from=%s to=%s",
            sender or "unknown",
            recipient,
        )
        user_check = _check_user_access(caller_user_id, recipient)
        if user_check is not None:
            return ACLResult(
                allowed=False,
                caller=sender or "unknown",
                reason=user_check,
                status=403,
            )
        return ACLResult(
            allowed=True,
            caller=sender or "unknown",
            reason="legacy_no_token",
        )

    def audit(
        self,
        *,
        event: str,
        caller: str,
        target: str,
        reason: str = "",
        user: str = "",
    ) -> None:
        """Append a JSON-lines audit entry. Best-effort; failures are swallowed."""
        if self.audit_path is None:
            return
        entry: dict[str, str] = {
            "ts": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "event": event,
            "caller": caller,
            "target": target,
        }
        if reason:
            entry["reason"] = reason
        if user:
            entry["user"] = user
        try:
            self.audit_path.parent.mkdir(parents=True, exist_ok=True)
            with self.audit_path.open("a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except OSError:
            logger.debug("Failed to write ACL audit entry", exc_info=True)


def _check_user_access(username: str | None, recipient: str) -> str | None:
    """Enforce per-user access. Return None on allow, or a deny reason string.

    * ``username=None`` → None (no user context to check; can_call only).
    * Unknown user: strict mode → ``"unknown_user"``; legacy → None.
    * Known user with empty / no ``allowed_agents`` → None (unrestricted).
    * Known user with ``"*"`` → None.
    * Known user where ``recipient`` not in ``allowed_agents`` →
      ``"user_not_allowed"``.
    """
    if not username:
        return None

    # Imported lazily so the multiagent module stays independent of the
    # api layer at import time (tests and CLI tools can still use ACL).
    from sygen_bot.api.auth import _find_user  # noqa: PLC0415

    user = _find_user(username)
    if user is None:
        return "unknown_user" if strict_unknown_user else None

    allowed_raw = user.get("allowed_agents")
    if not isinstance(allowed_raw, list) or not allowed_raw:
        return None
    if "*" in allowed_raw:
        return None
    return None if recipient in allowed_raw else "user_not_allowed"
