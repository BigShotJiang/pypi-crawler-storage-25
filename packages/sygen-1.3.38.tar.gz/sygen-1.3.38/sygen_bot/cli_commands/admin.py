"""Admin panel management CLI subcommands (``sygen admin ...``)."""

from __future__ import annotations

import json
import os
import shutil
import signal
import subprocess
import sys
import time
from collections.abc import Callable
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

_console = Console()

_ADMIN_SUBCOMMANDS = frozenset({"setup", "start", "stop", "status", "update", "open"})

_ADMIN_REPO = "https://github.com/alexeymorozua/sygen-admin.git"
_DEFAULT_PORT = 3000


def _parse_admin_subcommand(args: list[str]) -> tuple[str | None, list[str]]:
    """Extract the subcommand and remaining args after 'admin'."""
    found = False
    rest: list[str] = []
    sub: str | None = None
    for a in args:
        if a.startswith("-"):
            rest.append(a)
            continue
        if not found and a == "admin":
            found = True
            continue
        if found and sub is None:
            sub = a if a in _ADMIN_SUBCOMMANDS else None
            continue
        rest.append(a)
    return sub, rest


def _admin_dir() -> Path:
    """Return the admin panel installation directory."""
    from sygen_bot.workspace.paths import resolve_paths

    paths = resolve_paths()
    return paths.sygen_home / "admin"


def _pid_file() -> Path:
    return _admin_dir() / ".admin.pid"


def _port_file() -> Path:
    return _admin_dir() / ".admin.port"


def _get_port(args: list[str]) -> int:
    """Extract --port N from args, default 3000."""
    for i, a in enumerate(args):
        if a == "--port" and i + 1 < len(args):
            try:
                return int(args[i + 1])
            except ValueError:
                pass
    return _DEFAULT_PORT


def _is_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def _read_pid() -> int | None:
    pf = _pid_file()
    if not pf.exists():
        return None
    try:
        pid = int(pf.read_text().strip())
        return pid if _is_alive(pid) else None
    except (ValueError, OSError):
        return None


def _node_available() -> bool:
    return shutil.which("node") is not None


def _npm_available() -> bool:
    return shutil.which("npm") is not None


def print_admin_help() -> None:
    """Print the admin subcommand help table."""
    _console.print()
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold green", min_width=30)
    table.add_column()
    table.add_row("sygen admin setup", "Clone repo, install deps, build")
    table.add_row("sygen admin start", "Start the admin panel server")
    table.add_row("sygen admin start --port 3001", "Start on a custom port")
    table.add_row("sygen admin stop", "Stop the admin panel server")
    table.add_row("sygen admin status", "Show admin panel status")
    table.add_row("sygen admin update", "Pull latest changes and rebuild")
    table.add_row("sygen admin open", "Open admin panel in browser")
    _console.print(
        Panel(table, title="[bold]Admin Panel Commands[/bold]", border_style="blue", padding=(1, 0)),
    )
    _console.print()


def _run(cmd: list[str], cwd: Path, *, quiet: bool = False) -> bool:
    """Run a command, return True on success."""
    kwargs: dict = {"cwd": str(cwd)}
    if quiet:
        kwargs["stdout"] = subprocess.DEVNULL
        kwargs["stderr"] = subprocess.DEVNULL
    result = subprocess.run(cmd, **kwargs)
    return result.returncode == 0


def _admin_setup(rest: list[str]) -> None:
    """Clone, install, build the admin panel."""
    if not _npm_available():
        _console.print("[red]Node.js/npm not found.[/red] Install Node.js 20+ first.")
        return

    admin_dir = _admin_dir()

    if admin_dir.exists() and (admin_dir / "package.json").exists():
        _console.print("[yellow]Admin panel already installed.[/yellow] Use [bold]sygen admin update[/bold] to update.")
        return

    _console.print("[bold]Cloning sygen-admin...[/bold]")
    admin_dir.mkdir(parents=True, exist_ok=True)
    if not _run(["git", "clone", _ADMIN_REPO, str(admin_dir)], cwd=admin_dir.parent):
        _console.print("[red]Failed to clone repository.[/red]")
        return

    _console.print("[bold]Installing dependencies...[/bold]")
    if not _run(["npm", "ci"], cwd=admin_dir):
        _console.print("[red]npm ci failed.[/red]")
        return

    _console.print("[bold]Building...[/bold]")
    if not _run(["npm", "run", "build"], cwd=admin_dir):
        _console.print("[red]Build failed.[/red]")
        return

    _console.print("[green]Admin panel installed successfully.[/green]")
    _console.print(f"  Location: {admin_dir}")
    _console.print("  Run [bold]sygen admin start[/bold] to launch.")


def _admin_start(rest: list[str]) -> None:
    """Start the admin panel server."""
    admin_dir = _admin_dir()
    if not (admin_dir / "package.json").exists():
        _console.print("[red]Admin panel not installed.[/red] Run [bold]sygen admin setup[/bold] first.")
        return

    pid = _read_pid()
    if pid is not None:
        port_f = _port_file()
        port = port_f.read_text().strip() if port_f.exists() else str(_DEFAULT_PORT)
        _console.print(f"[yellow]Admin panel already running[/yellow] (PID {pid}, port {port}).")
        return

    port = _get_port(rest)

    # Build environment: inherit current + set PORT and API URL
    env = os.environ.copy()
    env["PORT"] = str(port)

    # Auto-detect Sygen API URL from config
    api_url = _detect_api_url()
    if api_url:
        env.setdefault("NEXT_PUBLIC_SYGEN_API_URL", api_url)
        env.setdefault("SYGEN_API_URL", api_url)

    # Auto-detect API token from config
    api_token = _detect_api_token()
    if api_token:
        env.setdefault("SYGEN_API_TOKEN", api_token)

    _console.print(f"[bold]Starting admin panel on port {port}...[/bold]")

    # Check if .next exists (built)
    if not (admin_dir / ".next").exists():
        _console.print("[yellow]No build found. Building first...[/yellow]")
        if not _run(["npm", "run", "build"], cwd=admin_dir):
            _console.print("[red]Build failed.[/red]")
            return

    log_path = admin_dir / "admin.log"
    log_file = open(log_path, "a")  # noqa: SIM115

    proc = subprocess.Popen(
        ["npm", "run", "start"],
        cwd=str(admin_dir),
        env=env,
        stdout=log_file,
        stderr=log_file,
        start_new_session=True,
    )

    _pid_file().write_text(str(proc.pid))
    _port_file().write_text(str(port))

    # Wait briefly to check it didn't crash
    time.sleep(2)
    if proc.poll() is not None:
        _console.print("[red]Admin panel failed to start.[/red] Check logs:")
        _console.print(f"  {log_path}")
        _pid_file().unlink(missing_ok=True)
        _port_file().unlink(missing_ok=True)
        return

    _console.print(f"[green]Admin panel started.[/green]")
    _console.print(f"  URL:  http://localhost:{port}")
    _console.print(f"  PID:  {proc.pid}")
    _console.print(f"  Logs: {log_path}")


def _detect_api_url() -> str | None:
    """Read the Sygen API URL from config if API is enabled."""
    try:
        from sygen_bot.workspace.paths import resolve_paths

        config_path = resolve_paths().config_path
        if not config_path.exists():
            return None
        cfg = json.loads(config_path.read_text())
        api = cfg.get("api", {})
        if not api.get("enabled"):
            return None
        host = api.get("host", "0.0.0.0")
        port = api.get("port", 8741)
        # Use localhost for the admin panel connection
        return f"http://localhost:{port}"
    except Exception:
        return None


def _detect_api_token() -> str | None:
    """Read the API token from config."""
    try:
        from sygen_bot.workspace.paths import resolve_paths

        config_path = resolve_paths().config_path
        if not config_path.exists():
            return None
        cfg = json.loads(config_path.read_text())
        return cfg.get("api", {}).get("token") or None
    except Exception:
        return None


def _admin_stop(rest: list[str]) -> None:
    """Stop the admin panel server."""
    pid = _read_pid()
    if pid is None:
        _console.print("[yellow]Admin panel is not running.[/yellow]")
        _pid_file().unlink(missing_ok=True)
        _port_file().unlink(missing_ok=True)
        return

    _console.print(f"[bold]Stopping admin panel (PID {pid})...[/bold]")
    try:
        os.kill(pid, signal.SIGTERM)
        # Wait up to 5 seconds for graceful shutdown
        for _ in range(50):
            if not _is_alive(pid):
                break
            time.sleep(0.1)
        else:
            os.kill(pid, signal.SIGKILL)
            time.sleep(0.5)
    except (OSError, ProcessLookupError):
        pass

    _pid_file().unlink(missing_ok=True)
    _port_file().unlink(missing_ok=True)
    _console.print("[green]Admin panel stopped.[/green]")


def _admin_status(rest: list[str]) -> None:
    """Show admin panel status."""
    admin_dir = _admin_dir()
    installed = (admin_dir / "package.json").exists()
    pid = _read_pid()
    port_f = _port_file()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold", min_width=15)
    table.add_column()

    table.add_row("Installed", "[green]yes[/green]" if installed else "[red]no[/red]")
    table.add_row("Location", str(admin_dir) if installed else "—")

    if installed:
        # Show version
        try:
            pkg = json.loads((admin_dir / "package.json").read_text())
            table.add_row("Version", pkg.get("version", "?"))
        except Exception:
            pass

        # Show git info
        try:
            branch = subprocess.run(
                ["git", "rev-parse", "--abbrev-ref", "HEAD"],
                cwd=str(admin_dir),
                capture_output=True,
                text=True,
            )
            if branch.returncode == 0:
                table.add_row("Branch", branch.stdout.strip())
        except Exception:
            pass

    if pid:
        port = port_f.read_text().strip() if port_f.exists() else str(_DEFAULT_PORT)
        table.add_row("Status", f"[green]running[/green] (PID {pid}, port {port})")
    else:
        table.add_row("Status", "[dim]stopped[/dim]")

    _console.print(Panel(table, title="[bold]Admin Panel[/bold]", border_style="blue", padding=(1, 0)))


def _admin_update(rest: list[str]) -> None:
    """Pull latest changes and rebuild."""
    admin_dir = _admin_dir()
    if not (admin_dir / "package.json").exists():
        _console.print("[red]Admin panel not installed.[/red] Run [bold]sygen admin setup[/bold] first.")
        return

    # Stop if running
    pid = _read_pid()
    was_running = pid is not None
    port = _DEFAULT_PORT
    if was_running:
        port_f = _port_file()
        if port_f.exists():
            try:
                port = int(port_f.read_text().strip())
            except ValueError:
                pass
        _console.print("[bold]Stopping admin panel for update...[/bold]")
        _admin_stop(rest)

    _console.print("[bold]Pulling latest changes...[/bold]")
    if not _run(["git", "pull", "origin", "main"], cwd=admin_dir):
        _console.print("[red]git pull failed.[/red]")
        return

    _console.print("[bold]Installing dependencies...[/bold]")
    if not _run(["npm", "ci"], cwd=admin_dir):
        _console.print("[red]npm ci failed.[/red]")
        return

    _console.print("[bold]Building...[/bold]")
    if not _run(["npm", "run", "build"], cwd=admin_dir):
        _console.print("[red]Build failed.[/red]")
        return

    _console.print("[green]Admin panel updated successfully.[/green]")

    if was_running:
        _console.print("[bold]Restarting...[/bold]")
        _admin_start(["--port", str(port)])


def _admin_open(rest: list[str]) -> None:
    """Open admin panel in browser."""
    pid = _read_pid()
    if pid is None:
        _console.print("[yellow]Admin panel is not running.[/yellow] Run [bold]sygen admin start[/bold] first.")
        return

    port_f = _port_file()
    port = port_f.read_text().strip() if port_f.exists() else str(_DEFAULT_PORT)
    url = f"http://localhost:{port}"

    import webbrowser

    webbrowser.open(url)
    _console.print(f"[green]Opening {url}[/green]")


def cmd_admin(args: list[str]) -> None:
    """Handle 'sygen admin <subcommand>'."""
    sub, rest = _parse_admin_subcommand(args)
    if sub is None:
        print_admin_help()
        return

    dispatch: dict[str, Callable[[], None]] = {
        "setup": lambda: _admin_setup(rest),
        "start": lambda: _admin_start(rest),
        "stop": lambda: _admin_stop(rest),
        "status": lambda: _admin_status(rest),
        "update": lambda: _admin_update(rest),
        "open": lambda: _admin_open(rest),
    }
    _console.print()
    dispatch[sub]()
    _console.print()
