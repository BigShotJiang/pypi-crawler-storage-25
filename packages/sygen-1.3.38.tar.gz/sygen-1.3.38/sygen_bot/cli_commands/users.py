"""User management CLI subcommands (``sygen users ...``).

Currently exposes a single command used to unlock admin panel access when
the password has been rotated and is no longer known:

    sygen users set-password [username] [--disable-2fa]

Passwords are never echoed. When the target user has TOTP enabled the
command prompts before disabling it (unless ``--disable-2fa`` is passed).
"""

from __future__ import annotations

import getpass
import time
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

_console = Console()

_USERS_SUBCOMMANDS = frozenset({"set-password"})


def _parse_users_subcommand(args: list[str]) -> tuple[str | None, list[str]]:
    """Extract the subcommand and remaining tokens after ``users``."""
    found = False
    sub: str | None = None
    rest: list[str] = []
    for a in args:
        if not found:
            if a == "users":
                found = True
            continue
        if sub is None and not a.startswith("-"):
            if a in _USERS_SUBCOMMANDS:
                sub = a
                continue
            return None, []
        rest.append(a)
    return sub, rest


def print_users_help() -> None:
    """Print the users subcommand help table."""
    _console.print()
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="bold green", min_width=44)
    table.add_column()
    table.add_row(
        "sygen users set-password [username]",
        "Set a new password (default user: admin)",
    )
    table.add_row(
        "  --disable-2fa",
        "Also disable TOTP for the user (non-interactive)",
    )
    _console.print(
        Panel(
            table,
            title="[bold]User Commands[/bold]",
            border_style="blue",
            padding=(1, 0),
        ),
    )
    _console.print()


def _prompt_password() -> str | None:
    """Prompt twice for a password. Returns ``None`` on mismatch or cancel."""
    try:
        pw1 = getpass.getpass("New password: ")
        pw2 = getpass.getpass("Repeat password: ")
    except (EOFError, KeyboardInterrupt):
        _console.print()
        _console.print("[yellow]Cancelled.[/yellow]")
        return None
    if pw1 != pw2:
        _console.print("[red]Passwords do not match.[/red]")
        return None
    return pw1


def _set_password(args: list[str]) -> None:
    """Implementation of ``sygen users set-password``."""
    # Parse args: first positional = username (default admin), flags = --disable-2fa
    username = "admin"
    disable_2fa = False
    for a in args:
        if a == "--disable-2fa":
            disable_2fa = True
        elif a.startswith("-"):
            _console.print(f"[red]Unknown flag: {a}[/red]")
            return
        else:
            username = a

    # Import lazily so `sygen --help` stays fast and import errors in the
    # auth module don't break unrelated CLI commands.
    from sygen_bot.api.auth import (
        _MIN_PASSWORD_LEN,
        _INITIAL_ADMIN_PW_PATH,
        _read_users,
        _write_users,
        hash_password,
    )

    users: list[dict[str, Any]] = _read_users()
    target: dict[str, Any] | None = None
    for u in users:
        if u.get("username") == username:
            target = u
            break
    if target is None:
        _console.print(f"[red]User '{username}' not found in users.json.[/red]")
        return

    password = _prompt_password()
    if password is None:
        return
    if len(password) < _MIN_PASSWORD_LEN:
        _console.print(
            f"[red]Password must be at least {_MIN_PASSWORD_LEN} characters.[/red]"
        )
        return

    totp_enabled = bool(target.get("totp_enabled"))
    will_disable_2fa = False
    if totp_enabled:
        if disable_2fa:
            will_disable_2fa = True
        else:
            try:
                answer = input(
                    "2FA is enabled for this user. Disable it? [y/N]: "
                ).strip().lower()
            except (EOFError, KeyboardInterrupt):
                _console.print()
                _console.print("[yellow]Cancelled.[/yellow]")
                return
            will_disable_2fa = answer in {"y", "yes"}

    target["password_hash"] = hash_password(password)
    target["token_version"] = int(target.get("token_version", 0)) + 1
    target["password_updated_at"] = time.time()
    if will_disable_2fa:
        target["totp_enabled"] = False
        target.pop("totp_secret", None)

    _write_users(users)

    # Best-effort: remove the bootstrap password file so it can't be mistaken
    # for the current password. Only removes when resetting the admin user
    # (the file only ever holds the initial admin password).
    if username == "admin" and _INITIAL_ADMIN_PW_PATH.exists():
        try:
            _INITIAL_ADMIN_PW_PATH.unlink()
        except OSError:
            pass

    details = []
    details.append(f"user: {username}")
    if totp_enabled:
        details.append("2FA: disabled" if will_disable_2fa else "2FA: kept")
    details.append("existing sessions invalidated")
    _console.print(
        f"[green]Password updated.[/green] " + " · ".join(details),
    )


def cmd_users(args: list[str]) -> None:
    """Entry point for the ``users`` CLI command."""
    sub, rest = _parse_users_subcommand(args)
    if sub is None:
        print_users_help()
        return
    if sub == "set-password":
        _set_password(rest)
        return
    # Unknown subcommand (defensive — _parse filters these out already)
    print_users_help()
