"""Security primitives: injection defense, path validation, secrets isolation."""

from sygen_bot.security.content import detect_suspicious_patterns as detect_suspicious_patterns
from sygen_bot.security.paths import is_path_safe as is_path_safe
from sygen_bot.security.paths import validate_file_path as validate_file_path
from sygen_bot.security.secrets_paths import SECRET_DIRS as SECRET_DIRS
from sygen_bot.security.secrets_paths import SECRET_FILES as SECRET_FILES
from sygen_bot.security.secrets_paths import chmod_secret as chmod_secret
from sygen_bot.security.secrets_paths import ensure_secrets_dir as ensure_secrets_dir
from sygen_bot.security.secrets_paths import get_secret_path as get_secret_path
from sygen_bot.security.secrets_paths import legacy_secret_path as legacy_secret_path
from sygen_bot.security.secrets_paths import migrate_legacy_secrets as migrate_legacy_secrets
from sygen_bot.security.secrets_paths import secrets_dir as secrets_dir

__all__ = [
    "SECRET_DIRS",
    "SECRET_FILES",
    "chmod_secret",
    "detect_suspicious_patterns",
    "ensure_secrets_dir",
    "get_secret_path",
    "is_path_safe",
    "legacy_secret_path",
    "migrate_legacy_secrets",
    "secrets_dir",
    "validate_file_path",
]
