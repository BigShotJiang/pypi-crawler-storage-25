"""Filesystem isolation for Sygen secret files.

Sensitive files (``users.json``, ``agents.json``, ``.env``, ``.jwt_secret``,
``.jwt_blacklist.json``, the audit log and the bootstrap admin password) live
under ``~/.sygen/_secrets/``.  The directory is created with mode ``0700`` and
files are written with mode ``0600``.

Claude CLI processes are scoped to the workspace directory via ``--add-dir``
and ``cwd=~/.sygen/workspace``.  ``_secrets/`` sits outside the workspace so
an agent running under ``permission_mode=acceptEdits`` (operator) cannot
enumerate or read these files through its built-in file tools.

Legacy installs had these files at the top level of ``~/.sygen``.  The
:func:`migrate_legacy_secrets` helper atomically moves them to ``_secrets/``
at startup.  The move is idempotent and safe to call on every boot.
"""

from __future__ import annotations

import logging
import os
import shutil
from collections.abc import Iterable
from pathlib import Path

logger = logging.getLogger(__name__)

SECRETS_SUBDIR = "_secrets"

# Files that must live inside ``_secrets/``. Ordered: most critical first so
# partial migrations always preserve the most sensitive state.
SECRET_FILES: tuple[str, ...] = (
    ".jwt_secret",
    "users.json",
    "agents.json",
    ".jwt_blacklist.json",
    ".env",
    "audit.log",
    ".initial_admin_password",
    "main_agent_token.json",
)

# Sub-directories that must live inside ``_secrets/``. Migrated as a whole
# (rename) from the legacy top-level location.
SECRET_DIRS: tuple[str, ...] = (
    "sub_agent_tokens",
)

_SECRETS_DIR_MODE = 0o700
_SECRET_FILE_MODE = 0o600


def _default_sygen_home() -> Path:
    return Path(os.environ.get("SYGEN_HOME", str(Path.home() / ".sygen")))


def secrets_dir(sygen_home: Path | None = None) -> Path:
    """Return the absolute path to ``<sygen_home>/_secrets``."""
    home = Path(sygen_home) if sygen_home is not None else _default_sygen_home()
    return home / SECRETS_SUBDIR


def ensure_secrets_dir(sygen_home: Path | None = None) -> Path:
    """Create ``_secrets/`` if missing and tighten its permissions to 0700."""
    d = secrets_dir(sygen_home)
    d.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(d, _SECRETS_DIR_MODE)
    except OSError:
        logger.debug("Cannot chmod %s to %o", d, _SECRETS_DIR_MODE, exc_info=True)
    return d


def get_secret_path(
    filename: str,
    sygen_home: Path | None = None,
    *,
    ensure_dir: bool = True,
) -> Path:
    """Return the canonical path ``<sygen_home>/_secrets/<filename>``.

    When *ensure_dir* is true (the default) the parent directory is created
    with restrictive permissions on first access.
    """
    if ensure_dir:
        ensure_secrets_dir(sygen_home)
    return secrets_dir(sygen_home) / filename


def legacy_secret_path(filename: str, sygen_home: Path | None = None) -> Path:
    """Return the pre-migration location ``<sygen_home>/<filename>``."""
    home = Path(sygen_home) if sygen_home is not None else _default_sygen_home()
    return home / filename


def chmod_secret(path: Path) -> None:
    """Best-effort chmod to ``0600``. Silent on unsupported filesystems."""
    try:
        os.chmod(path, _SECRET_FILE_MODE)
    except OSError:
        logger.debug("Cannot chmod %s to %o", path, _SECRET_FILE_MODE, exc_info=True)


def migrate_legacy_secrets(
    sygen_home: Path | None = None,
    filenames: Iterable[str] = SECRET_FILES,
    dirnames: Iterable[str] = SECRET_DIRS,
) -> list[tuple[str, Path, Path]]:
    """Move legacy secret files and directories into ``_secrets/``.

    For each *filename* in *filenames*, if ``<home>/<filename>`` exists and
    ``<home>/_secrets/<filename>`` does not, the file is moved atomically
    (``shutil.move`` performs ``rename`` on the same filesystem).  The new
    file is chmoded to ``0600``.  Directories in *dirnames* are relocated
    the same way (and kept at whatever permissions the caller previously
    set — typically 0700 for ``sub_agent_tokens/``).

    Returns a list of ``(name, old, new)`` tuples for each successful move.

    The function never overwrites an existing entry at the new path — if both
    exist the legacy copy is left untouched so a human can reconcile.  The
    routine is idempotent and safe to run on every startup.
    """
    home = Path(sygen_home) if sygen_home is not None else _default_sygen_home()
    ensure_secrets_dir(home)
    new_dir = secrets_dir(home)
    migrated: list[tuple[str, Path, Path]] = []
    for name in filenames:
        old = home / name
        new = new_dir / name
        if not old.is_file():
            continue
        if new.exists():
            logger.warning(
                "Legacy secret %s found but %s already exists — skipping migration",
                old,
                new,
            )
            continue
        try:
            shutil.move(str(old), str(new))
        except OSError:
            logger.warning("Failed to migrate secret %s", name, exc_info=True)
            continue
        chmod_secret(new)
        migrated.append((name, old, new))
        logger.info("Migrated secret %s -> %s", old, new)
    for name in dirnames:
        old = home / name
        new = new_dir / name
        if not old.is_dir():
            continue
        if new.exists():
            logger.warning(
                "Legacy secret directory %s found but %s already exists — "
                "skipping migration",
                old,
                new,
            )
            continue
        try:
            shutil.move(str(old), str(new))
        except OSError:
            logger.warning("Failed to migrate secret directory %s", name, exc_info=True)
            continue
        migrated.append((name, old, new))
        logger.info("Migrated secret directory %s -> %s", old, new)
    return migrated
