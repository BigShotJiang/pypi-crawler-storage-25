import json
import tempfile

import pytest


@pytest.fixture(autouse=True)
def mock_config(monkeypatch):
    session = {
        "key": "ak_live_test_key",
        "api_url": "https://test.nucl.app",
        "org_id": "org-test",
    }
    monkeypatch.setattr("nucl.mcp_server.load_session", lambda: session)
    monkeypatch.setattr("nucl.mcp_server.get_api_key", lambda: "ak_live_test_key")
    monkeypatch.setattr("nucl.mcp_server.get_org_id", lambda: "org-test")
    monkeypatch.setattr("nucl.api.get_api_key", lambda: "ak_live_test_key")
    monkeypatch.setattr("nucl.api.get_api_url", lambda: "https://test.nucl.app")
    monkeypatch.setattr("nucl.api.get_org_id", lambda: "org-test")


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


def test_auth_status_logged_in():
    from nucl.mcp_server import nucl_auth_status

    result = nucl_auth_status()
    assert "Logged in" in result
    assert "org-test" in result


def test_auth_status_not_logged_in(monkeypatch):
    monkeypatch.setattr("nucl.mcp_server.load_session", lambda: None)
    from nucl.mcp_server import nucl_auth_status

    result = nucl_auth_status()
    assert "Not logged in" in result


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


def test_team_show(httpx_mock):
    httpx_mock.add_response(json={
        "name": "Test Team",
        "defaultPlatform": "azure",
        "azureConfigured": True,
        "vertexConfigured": False,
        "vertexProject": "proj-1",
        "vertexLocation": "us-central1",
        "vertexStagingBucket": "gs://proj-1-staging",
    })
    from nucl.mcp_server import nucl_team_show

    result = nucl_team_show()
    assert "Test Team" in result
    assert "azure" in result.lower()
    assert "proj-1" in result
    assert "gs://proj-1-staging" in result


def test_team_set(monkeypatch, tmp_path):
    session_file = tmp_path / "session.json"
    session_file.write_text(json.dumps({
        "key": "ak_live_test_key",
        "api_url": "https://test.nucl.app",
    }))
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", session_file)

    from nucl.mcp_server import nucl_team_set

    result = nucl_team_set("org-new")
    assert "org-new" in result
    saved = json.loads(session_file.read_text())
    assert saved["org_id"] == "org-new"


def test_team_config_azure(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    from nucl.mcp_server import nucl_team_config_azure

    result = nucl_team_config_azure(
        subscription_id="sub-1",
        resource_group="rg-1",
        workspace="ws-1",
        tenant_id="t-1",
        client_id="c-1",
        client_secret="s-1",
    )
    assert "Azure credentials saved" in result


def test_team_config_vertex(httpx_mock):
    httpx_mock.add_response(json={"ok": True})
    from nucl.mcp_server import nucl_team_config_vertex

    result = nucl_team_config_vertex(
        project="my-proj",
        location="us-central1",
        service_account_json='{"key":"val"}',
    )
    assert "Vertex credentials saved" in result


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


def test_ps(httpx_mock):
    httpx_mock.add_response(json={"jobs": [
        {"id": "j1", "name": "exp/a", "status": "Running", "createdAt": "2026-01-01"},
        {"id": "j2", "name": "exp/b", "status": "Completed", "createdAt": "2026-01-02"},
    ]})
    from nucl.mcp_server import nucl_ps

    result = nucl_ps()
    assert "j1" in result
    assert "j2" in result
    assert "exp/a" in result


def test_ps_with_prefix(httpx_mock):
    httpx_mock.add_response(json={"jobs": [
        {"id": "j1", "name": "exp/a", "status": "Running", "createdAt": "2026-01-01"},
        {"id": "j2", "name": "other/b", "status": "Completed", "createdAt": "2026-01-02"},
    ]})
    from nucl.mcp_server import nucl_ps

    result = nucl_ps(prefix="exp/")
    assert "j1" in result
    assert "j2" not in result


def test_ps_empty(httpx_mock):
    httpx_mock.add_response(json={"jobs": []})
    from nucl.mcp_server import nucl_ps

    result = nucl_ps()
    assert "No jobs found" in result


def test_log(httpx_mock):
    httpx_mock.add_response(json={
        "lines": ["line 1", "line 2"],
        "nextOffset": 2,
        "done": True,
    })
    from nucl.mcp_server import nucl_log

    result = nucl_log("job-1")
    assert "line 1" in result
    assert "line 2" in result


def test_stop(httpx_mock):
    httpx_mock.add_response(json={})
    from nucl.mcp_server import nucl_stop

    result = nucl_stop("job-1")
    assert "job-1 stopped" in result


def test_pull(httpx_mock):
    httpx_mock.add_response(json={"files": [
        {"name": "model.pth", "url": "https://test.nucl.app/files/model.pth"},
    ]}, url="https://test.nucl.app/api/jobs/job-1/outputs")
    httpx_mock.add_response(content=b"model-bytes", url="https://test.nucl.app/files/model.pth")
    from nucl.mcp_server import nucl_pull

    with tempfile.TemporaryDirectory() as d:
        result = nucl_pull("job-1", target=d)
        assert "Downloaded 1 file(s)" in result
        assert "model.pth" in result


def test_pull_no_files(httpx_mock):
    httpx_mock.add_response(json={"files": []})
    from nucl.mcp_server import nucl_pull

    result = nucl_pull("job-1")
    assert "No output files" in result


# ---------------------------------------------------------------------------
# Auth guard
# ---------------------------------------------------------------------------


def test_tools_require_auth(monkeypatch):
    monkeypatch.setattr("nucl.mcp_server.get_api_key", lambda: None)
    from nucl.mcp_server import nucl_ps

    result = nucl_ps()
    assert "Not logged in" in result


def test_tools_require_org(monkeypatch):
    monkeypatch.setattr("nucl.mcp_server.get_org_id", lambda: None)
    from nucl.mcp_server import nucl_ps

    result = nucl_ps()
    assert "No active team" in result


