import json
import threading
import urllib.request
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from nucl.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


# ---------------------------------------------------------------------------
# Helpers for mocking API functions used inside nucl.cli
# ---------------------------------------------------------------------------


@pytest.fixture
def mock_api(monkeypatch):
    mock_get = MagicMock(return_value={})
    mock_post = MagicMock(return_value={"id": "test-123", "consoleUrl": "https://console.test/j/123"})
    mock_post_multipart = MagicMock(return_value={"runId": "wrun_default"})

    monkeypatch.setattr("nucl.operations.get", mock_get)
    monkeypatch.setattr("nucl.operations.post", mock_post)
    monkeypatch.setattr("nucl.operations.post_multipart", mock_post_multipart)

    return {
        "get": mock_get,
        "post": mock_post,
        "post_multipart": mock_post_multipart,
    }


@pytest.fixture
def mock_session(tmp_path, monkeypatch):
    """Set up a valid session so auth-dependent commands work."""
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    data = {"key": "test-key", "api_url": "https://test.nucl.app", "org_id": "org-1"}
    (tmp_path / "session.json").write_text(json.dumps(data))
    return data


# ===========================================================================
# Version
# ===========================================================================


def test_version(runner):
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    from nucl import __version__
    assert __version__ in result.output


# ===========================================================================
# Auth group
# ===========================================================================


def test_auth_status_not_logged_in(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    result = runner.invoke(cli, ["auth", "status"])
    assert result.exit_code == 0
    assert "Not logged in" in result.output


def test_auth_status_logged_in(runner, mock_session):
    result = runner.invoke(cli, ["auth", "status"])
    assert result.exit_code == 0
    assert "Logged in" in result.output
    assert "test.nucl.app" in result.output


def test_auth_status_shows_active_team(runner, mock_session):
    result = runner.invoke(cli, ["auth", "status"])
    assert "org-1" in result.output


def test_auth_status_no_team(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    data = {"key": "k", "api_url": "https://a.com"}
    (tmp_path / "session.json").write_text(json.dumps(data))
    result = runner.invoke(cli, ["auth", "status"])
    assert "No active team" in result.output


def test_auth_logout(runner, mock_session, tmp_path):
    result = runner.invoke(cli, ["auth", "logout"])
    assert result.exit_code == 0
    assert "Logged out" in result.output
    assert not (tmp_path / "session.json").exists()


def test_auth_login_success(runner, tmp_path, monkeypatch):
    """Test auth login by simulating the OAuth callback."""
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")

    def fake_browser_open(url):
        port = url.split("port=")[1]

        def send_callback():
            callback_url = f"http://127.0.0.1:{port}/?key=received-key-abc"
            urllib.request.urlopen(callback_url, timeout=5)

        threading.Thread(target=send_callback, daemon=True).start()

    monkeypatch.setattr("webbrowser.open", fake_browser_open)

    result = runner.invoke(cli, ["auth", "login"])
    assert result.exit_code == 0
    assert "Logged in successfully" in result.output
    session = json.loads((tmp_path / "session.json").read_text())
    assert session["key"] == "received-key-abc"


def test_auth_login_no_key_received(runner, tmp_path, monkeypatch):
    """Test auth login when callback has no key."""
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")

    def fake_browser_open(url):
        port = url.split("port=")[1]

        def send_callback():
            callback_url = f"http://127.0.0.1:{port}/"
            urllib.request.urlopen(callback_url, timeout=5)

        threading.Thread(target=send_callback, daemon=True).start()

    monkeypatch.setattr("webbrowser.open", fake_browser_open)

    result = runner.invoke(cli, ["auth", "login"])
    assert result.exit_code != 0
    assert "Login failed" in result.stderr


def test_auth_login_custom_api_url(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")

    captured_url = []

    def fake_browser_open(url):
        captured_url.append(url)
        port = url.split("port=")[1]

        def send_callback():
            callback_url = f"http://127.0.0.1:{port}/?key=k"
            urllib.request.urlopen(callback_url, timeout=5)

        threading.Thread(target=send_callback, daemon=True).start()

    monkeypatch.setattr("webbrowser.open", fake_browser_open)

    result = runner.invoke(cli, ["auth", "login", "--api-url", "https://custom.api"])
    assert result.exit_code == 0
    assert "custom.api" in captured_url[0]


# ===========================================================================
# Team group
# ===========================================================================


def test_team_show_no_org(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    result = runner.invoke(cli, ["team", "show"])
    assert result.exit_code != 0
    assert "No active team" in result.output


def test_team_show_with_org(runner, mock_session, mock_api):
    mock_api["get"].return_value = {
        "name": "My Team",
        "defaultPlatform": "azure",
        "azureConfigured": True,
        "vertexConfigured": False,
        "vertexProject": "proj-1",
        "vertexLocation": "us-central1",
        "vertexStagingBucket": "gs://proj-1-staging",
    }
    result = runner.invoke(cli, ["team", "show"])
    assert result.exit_code == 0
    assert "My Team" in result.output
    assert "azure" in result.output
    assert "configured" in result.output
    assert "not configured" in result.output
    assert "proj-1" in result.output
    assert "gs://proj-1-staging" in result.output
    mock_api["get"].assert_called_once_with("/api/team/config")


def test_team_set(runner, mock_session):
    result = runner.invoke(cli, ["team", "set", "org-999"])
    assert result.exit_code == 0
    assert "org-999" in result.output
    from nucl.config import get_org_id

    assert get_org_id() == "org-999"


def test_team_config_azure(runner, mock_session, mock_api):
    result = runner.invoke(
        cli,
        ["team", "config", "azure"],
        input="sub-1\nrg-1\nws-1\ntenant-1\nclient-1\nsecret-1\nn\n",
    )
    assert result.exit_code == 0
    assert "Azure credentials saved" in result.output
    mock_api["post"].assert_called_once()
    call_kwargs = mock_api["post"].call_args
    assert call_kwargs[0][0] == "/api/team/config"
    body = call_kwargs[1]["json"]
    assert body["platform"] == "azure"
    assert body["credentials"]["subscriptionId"] == "sub-1"
    assert body["credentials"]["clientSecret"] == "secret-1"
    assert "defaultPlatform" not in body


def test_team_config_azure_set_default(runner, mock_session, mock_api):
    result = runner.invoke(
        cli,
        ["team", "config", "azure"],
        input="sub\nrg\nws\nt\nc\ns\ny\n",
    )
    assert result.exit_code == 0
    body = mock_api["post"].call_args[1]["json"]
    assert body["defaultPlatform"] == "azure"


def test_team_config_azure_no_org(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    result = runner.invoke(cli, ["team", "config", "azure"])
    assert result.exit_code != 0
    assert "No active team" in result.stderr


def test_team_config_vertex(runner, mock_session, mock_api, tmp_path):
    sa_file = tmp_path / "sa.json"
    sa_file.write_text('{"type": "service_account"}')
    result = runner.invoke(
        cli,
        ["team", "config", "vertex"],
        input=f"my-proj\nus-east1\ngs://my-staging\n{sa_file}\nn\n",
    )
    assert result.exit_code == 0
    assert "Vertex credentials saved" in result.output
    body = mock_api["post"].call_args[1]["json"]
    assert body["platform"] == "vertex"
    assert body["credentials"]["project"] == "my-proj"
    assert body["credentials"]["location"] == "us-east1"
    assert body["credentials"]["stagingBucket"] == "gs://my-staging"
    assert "service_account" in body["credentials"]["serviceAccountJson"]


def test_team_config_vertex_set_default(runner, mock_session, mock_api, tmp_path):
    sa_file = tmp_path / "sa.json"
    sa_file.write_text('{}')
    result = runner.invoke(
        cli,
        ["team", "config", "vertex"],
        input=f"proj\n\ngs://proj-staging\n{sa_file}\ny\n",
    )
    assert result.exit_code == 0
    body = mock_api["post"].call_args[1]["json"]
    assert body["defaultPlatform"] == "vertex"


def test_team_config_vertex_no_org(runner, tmp_path, monkeypatch):
    monkeypatch.setattr("nucl.config.CONFIG_DIR", tmp_path)
    monkeypatch.setattr("nucl.config.SESSION_FILE", tmp_path / "session.json")
    result = runner.invoke(cli, ["team", "config", "vertex"])
    assert result.exit_code != 0
    assert "No active team" in result.stderr


# ===========================================================================
# Job commands
# ===========================================================================


def test_ps_no_prefix(runner, mock_api):
    mock_api["get"].return_value = {
        "jobs": [
            {"id": "j1", "name": "train/exp1", "status": "running", "createdAt": "2025-01-01"},
            {"id": "j2", "name": "eval/exp2", "status": "done", "createdAt": "2025-01-02"},
        ]
    }
    result = runner.invoke(cli, ["ps"])
    assert result.exit_code == 0
    assert "j1" in result.output
    assert "j2" in result.output
    mock_api["get"].assert_called_once_with("/api/jobs", limit=20, platform="all")


def test_ps_with_prefix(runner, mock_api):
    mock_api["get"].return_value = {
        "jobs": [
            {"id": "j1", "name": "train/a", "status": "running", "createdAt": ""},
            {"id": "j2", "name": "eval/b", "status": "done", "createdAt": ""},
        ]
    }
    result = runner.invoke(cli, ["ps", "train"])
    assert result.exit_code == 0
    assert "j1" in result.output
    assert "eval/b" not in result.output


def test_ps_with_num_flag(runner, mock_api):
    mock_api["get"].return_value = []
    result = runner.invoke(cli, ["ps", "-n", "5"])
    assert result.exit_code == 0
    mock_api["get"].assert_called_once_with("/api/jobs", limit=5, platform="all")


def test_ps_handles_list_response(runner, mock_api):
    """When API returns a plain list instead of {jobs: [...]}."""
    mock_api["get"].return_value = [
        {"id": "j1", "name": "x", "status": "ok", "createdAt": ""},
    ]
    result = runner.invoke(cli, ["ps"])
    assert result.exit_code == 0
    assert "j1" in result.output


def test_ps_with_platform(runner, mock_api):
    mock_api["get"].return_value = []
    result = runner.invoke(cli, ["ps", "--platform", "vertex"])
    assert result.exit_code == 0
    mock_api["get"].assert_called_once_with("/api/jobs", limit=20, platform="vertex")


def test_run_submits_job(runner, mock_api, tmp_path, monkeypatch):
    mock_api["post_multipart"].return_value = {"runId": "wrun_submit"}
    mock_api["get"].return_value = {
        "done": True,
        "id": "test-123",
        "consoleUrl": "https://console.test/j/123",
    }
    monkeypatch.setattr("nucl.operations.time.sleep", lambda _: None)

    (tmp_path / "train.py").write_text("print('hello')")
    (tmp_path / "data.csv").write_text("a,b\n1,2")

    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(cli, ["run", "--name", "my-exp", "--script", "train.py"])

    assert result.exit_code == 0
    assert "test-123" in result.output
    assert "console.test" in result.output
    mock_api["post_multipart"].assert_called_once()
    call_args = mock_api["post_multipart"].call_args[0]
    assert call_args[0] == "/api/jobs"
    metadata = call_args[1]
    assert metadata["name"] == "my-exp"
    assert metadata["script"] == "train.py"


def test_run_with_gpu_and_docker(runner, mock_api, tmp_path, monkeypatch):
    mock_api["post_multipart"].return_value = {"runId": "wrun_gpu"}
    mock_api["get"].return_value = {"done": True, "id": "gpu-job"}
    monkeypatch.setattr("nucl.operations.time.sleep", lambda _: None)

    (tmp_path / "train.py").write_text("")
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(
            cli,
            ["run", "--name", "gpu-exp", "--script", "train.py", "--gpu-type", "A100", "--docker-image", "nvcr.io/pytorch"],
        )
    assert result.exit_code == 0
    metadata = mock_api["post_multipart"].call_args[0][1]
    assert metadata["gpuType"] == "A100"
    assert metadata["dockerImage"] == "nvcr.io/pytorch"


def test_run_missing_name(runner, mock_api):
    result = runner.invoke(cli, ["run", "--script", "x.py"])
    assert result.exit_code != 0


def test_run_missing_script(runner, mock_api):
    result = runner.invoke(cli, ["run", "--name", "x"])
    assert result.exit_code != 0


def test_run_no_console_url(runner, mock_api, tmp_path, monkeypatch):
    """When response has no consoleUrl, should still succeed."""
    mock_api["post_multipart"].return_value = {"runId": "wrun_no_url"}
    mock_api["get"].return_value = {"done": True, "id": "j-no-url"}
    monkeypatch.setattr("nucl.operations.time.sleep", lambda _: None)

    (tmp_path / "s.py").write_text("")
    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(cli, ["run", "--name", "n", "--script", "s.py"])
    assert result.exit_code == 0
    assert "j-no-url" in result.output
    assert "Console" not in result.output


def test_run_waits_for_workflow_submission_result(runner, mock_api, tmp_path, monkeypatch):
    mock_api["post_multipart"].return_value = {"runId": "wrun_123"}
    mock_api["get"].side_effect = [
        {"done": False, "status": "running", "runId": "wrun_123"},
        {"done": True, "id": "job-9", "consoleUrl": "https://console.test/j/9"},
    ]
    monkeypatch.setattr("nucl.operations.time.sleep", lambda _: None)

    (tmp_path / "train.py").write_text("")

    with runner.isolated_filesystem(temp_dir=tmp_path):
        result = runner.invoke(cli, ["run", "--name", "wf-exp", "--script", "train.py"])

    assert result.exit_code == 0
    assert "job-9" in result.output
    assert "console.test" in result.output


def test_log_prints_lines(runner, mock_api):
    mock_api["get"].return_value = {
        "lines": ["line1", "line2", "line3"],
        "nextOffset": 3,
        "done": True,
    }
    result = runner.invoke(cli, ["log", "job-abc"])
    assert result.exit_code == 0
    assert "line1" in result.output
    assert "line2" in result.output
    assert "line3" in result.output
    mock_api["get"].assert_called_once_with("/api/jobs/job-abc/logs", offset=0)


def test_log_follow_polls_until_done(runner, mock_api, monkeypatch):
    """Follow mode should poll until done=True."""
    monkeypatch.setattr("nucl.cli.time.sleep", lambda s: None)
    call_count = 0

    def mock_get_log(path, **params):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return {"lines": ["first"], "nextOffset": 1, "done": False}
        elif call_count == 2:
            return {"lines": ["second"], "nextOffset": 2, "done": False}
        else:
            return {"lines": ["last"], "nextOffset": 3, "done": True}

    mock_api["get"].side_effect = mock_get_log

    result = runner.invoke(cli, ["log", "j1", "-f"])
    assert result.exit_code == 0
    assert "first" in result.output
    assert "second" in result.output
    assert "last" in result.output
    assert call_count == 3


def test_log_no_follow_stops_after_first(runner, mock_api):
    mock_api["get"].return_value = {"lines": ["only"], "nextOffset": 1, "done": False}
    result = runner.invoke(cli, ["log", "j1"])
    assert result.exit_code == 0
    assert "only" in result.output
    assert mock_api["get"].call_count == 1


def test_stop(runner, mock_api):
    result = runner.invoke(cli, ["stop", "job-to-stop"])
    assert result.exit_code == 0
    assert "job-to-stop" in result.output
    assert "stopped" in result.output
    mock_api["post"].assert_called_once_with("/api/jobs/job-to-stop/stop")


def test_pull_downloads_files(runner, mock_api, tmp_path, monkeypatch):
    mock_api["get"].return_value = {
        "files": [
            {"name": "model.pt", "url": "https://dl.test/model.pt"},
            {"name": "metrics.json", "url": "https://dl.test/metrics.json"},
        ]
    }

    mock_response = MagicMock()
    mock_response.content = b"file-content"
    mock_response.raise_for_status = MagicMock()

    monkeypatch.setattr("nucl.config.get_api_key", lambda: "dl-key")

    with patch("httpx.get", return_value=mock_response) as mock_httpx_get:
        dest = tmp_path / "output"
        result = runner.invoke(cli, ["pull", "job-dl", str(dest)])

    assert result.exit_code == 0
    assert "Downloaded 2 file(s)" in result.output
    assert mock_httpx_get.call_count == 2


def test_pull_no_files(runner, mock_api):
    mock_api["get"].return_value = {"files": []}
    result = runner.invoke(cli, ["pull", "job-empty"])
    assert result.exit_code == 0
    assert "No output files" in result.output
