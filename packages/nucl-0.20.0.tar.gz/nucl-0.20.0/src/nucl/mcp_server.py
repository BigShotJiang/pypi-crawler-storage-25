import time

from mcp.server.fastmcp import FastMCP

from nucl.config import get_api_key, get_org_id, load_session, set_org_id
from nucl import operations as ops

server = FastMCP("nucl")


def _check_auth() -> str | None:
    if not get_api_key():
        return "Not logged in. Run: nucl auth login"
    return None


def _check_org() -> str | None:
    err = _check_auth()
    if err:
        return err
    if not get_org_id():
        return "No active team. Run: nucl team set <org-id>"
    return None


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------


@server.tool()
def nucl_auth_status() -> str:
    """Show current login status."""
    session = load_session()
    if not session:
        return "Not logged in."
    lines = [f"Logged in to {session.get('api_url', 'unknown')}"]
    org = session.get("org_id")
    if org:
        lines.append(f"Active team: {org}")
    else:
        lines.append("No active team. Run: nucl team set <org-id>")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Team
# ---------------------------------------------------------------------------


@server.tool()
def nucl_team_list() -> str:
    """List all teams you belong to."""
    err = _check_auth()
    if err:
        return err
    teams = ops.get_team_list()
    if not teams:
        return "No teams found."
    current = get_org_id()
    lines = [f"{'':2} {'ID':<30} {'Name':<30} {'Role'}"]
    for t in teams:
        marker = "*" if t.get("id") == current else " "
        lines.append(f"{marker:2} {t.get('id', ''):<30} {t.get('name', ''):<30} {t.get('role', '')}")
    return "\n".join(lines)


@server.tool()
def nucl_team_show() -> str:
    """Show current team and configured platforms."""
    err = _check_org()
    if err:
        return err
    data = ops.get_team_config()
    lines = [
        f"Team: {data.get('name', 'unknown')}",
        f"Default platform: {data.get('defaultPlatform', 'azure')}",
        f"Azure: {'configured' if data.get('azureConfigured') else 'not configured'}",
        f"Vertex: {'configured' if data.get('vertexConfigured') else 'not configured'}",
    ]
    if data.get("vertexProject"):
        lines.append(f"Vertex project: {data['vertexProject']}")
    if data.get("vertexLocation"):
        lines.append(f"Vertex location: {data['vertexLocation']}")
    if data.get("vertexStagingBucket"):
        lines.append(f"Vertex staging bucket: {data['vertexStagingBucket']}")
    return "\n".join(lines)


@server.tool()
def nucl_team_set(org_id: str) -> str:
    """Set active team by org ID."""
    err = _check_auth()
    if err:
        return err
    set_org_id(org_id)
    return f"Active team set to {org_id}"


@server.tool()
def nucl_team_config_azure(
    subscription_id: str,
    resource_group: str,
    workspace: str,
    tenant_id: str,
    client_id: str,
    client_secret: str,
    set_default: bool = False,
) -> str:
    """Configure Azure ML credentials for the current team."""
    err = _check_org()
    if err:
        return err
    ops.save_team_config(
        platform="azure",
        credentials={
            "subscriptionId": subscription_id,
            "resourceGroup": resource_group,
            "workspace": workspace,
            "tenantId": tenant_id,
            "clientId": client_id,
            "clientSecret": client_secret,
        },
        set_default=set_default,
    )
    return "Azure credentials saved."


@server.tool()
def nucl_team_config_vertex(
    project: str,
    location: str,
    service_account_json: str,
    set_default: bool = False,
) -> str:
    """Configure Vertex AI credentials for the current team."""
    err = _check_org()
    if err:
        return err
    ops.save_team_config(
        platform="vertex",
        credentials={
            "project": project,
            "location": location,
            "serviceAccountJson": service_account_json,
        },
        set_default=set_default,
    )
    return "Vertex credentials saved."


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


@server.tool()
def nucl_run(
    name: str,
    script: str,
    directory: str = ".",
    gpu_type: str | None = None,
    docker_image: str | None = None,
) -> str:
    """Submit a training job. Packages the given directory and uploads it."""
    err = _check_org()
    if err:
        return err
    result = ops.submit_job(
        name=name,
        script=script,
        directory=directory,
        gpu_type=gpu_type,
        docker_image=docker_image,
    )
    lines = [f"Job submitted: {result.get('id', 'unknown')}"]
    if result.get("consoleUrl"):
        lines.append(f"Console: {result['consoleUrl']}")
    return "\n".join(lines)


@server.tool()
def nucl_ps(prefix: str = "", num: int = 20, platform: str = "all") -> str:
    """List recent jobs. Optionally filter by folder prefix."""
    err = _check_org()
    if err:
        return err
    jobs = ops.list_jobs(limit=num, prefix=prefix, platform=platform)
    if not jobs:
        return "No jobs found."
    lines = [f"{'ID':<20} {'Name':<40} {'Status':<15} {'Created'}"]
    for j in jobs:
        lines.append(
            f"{j.get('id', ''):<20} {j.get('name', ''):<40} "
            f"{j.get('status', ''):<15} {j.get('createdAt', '')}"
        )
    return "\n".join(lines)


@server.tool()
def nucl_log(job_id: str, follow: bool = False) -> str:
    """Get logs for a job. If follow=True, polls until done."""
    err = _check_org()
    if err:
        return err
    all_lines = ops.collect_job_logs(job_id, follow=follow, sleeper=time.sleep)
    return "\n".join(all_lines) if all_lines else "No log output."


@server.tool()
def nucl_stop(job_id: str) -> str:
    """Stop a running job."""
    err = _check_org()
    if err:
        return err
    ops.stop_job(job_id)
    return f"Job {job_id} stopped."


@server.tool()
def nucl_pull(job_id: str, target: str = ".") -> str:
    """Download job outputs to a local directory."""
    err = _check_org()
    if err:
        return err
    files = ops.list_output_files(job_id)
    if not files:
        return "No output files."
    downloaded = ops.download_output_files(files, target=target)
    names = ", ".join(path.name for path in downloaded)
    return f"Downloaded {len(downloaded)} file(s) to {target}: {names}"
