import tarfile
import tempfile
import time
from pathlib import Path
from typing import Callable

import httpx

from nucl.api import get, post, post_multipart
from nucl import config as config_store


def tar_directory(directory: str | Path) -> Path:
    """Create a tar.gz of a directory, excluding .git files."""
    root = Path(directory)
    archive = tempfile.NamedTemporaryFile(suffix=".tar.gz", delete=False)

    with tarfile.open(archive.name, "w:gz") as tar:
        for path in root.rglob("*"):
            if ".git" in path.parts:
                continue
            tar.add(path, arcname=path.relative_to(root))

    return Path(archive.name)


def submit_job(
    *,
    name: str,
    script: str,
    directory: str | Path,
    gpu_type: str | None = None,
    docker_image: str | None = None,
    platform: str | None = None,
) -> dict:
    metadata: dict[str, str] = {"name": name, "script": script}
    if gpu_type:
        metadata["gpuType"] = gpu_type
    if docker_image:
        metadata["dockerImage"] = docker_image
    if platform:
        metadata["platform"] = platform

    archive = tar_directory(directory)
    try:
        response = post_multipart("/api/jobs", metadata, str(archive))
    finally:
        archive.unlink(missing_ok=True)

    run_id = response.get("runId")
    if not run_id:
        return response

    while True:
        status = get(f"/api/jobs/submissions/{run_id}")
        if status.get("done"):
            return {"id": status.get("id"), "consoleUrl": status.get("consoleUrl")}
        time.sleep(1)


def list_jobs(
    *,
    limit: int = 20,
    prefix: str = "",
    platform: str | None = None,
) -> list[dict]:
    params: dict[str, int | str] = {"limit": limit}
    if platform:
        params["platform"] = platform

    data = get("/api/jobs", **params)
    jobs = data.get("jobs", data) if isinstance(data, dict) else data

    if prefix:
        jobs = [job for job in jobs if job.get("name", "").startswith(prefix)]

    return jobs


def collect_job_logs(
    job_id: str,
    *,
    follow: bool = False,
    sleeper: Callable[[float], None] = time.sleep,
) -> list[str]:
    lines: list[str] = []
    offset = 0

    while True:
        data = get(f"/api/jobs/{job_id}/logs", offset=offset)
        lines.extend(data.get("lines", []))
        offset = data.get("nextOffset", offset)

        if not follow or data.get("done"):
            return lines

        sleeper(2)


def stop_job(job_id: str) -> None:
    post(f"/api/jobs/{job_id}/stop")


def list_output_files(job_id: str) -> list[dict]:
    data = get(f"/api/jobs/{job_id}/outputs")
    return data.get("files", [])


def download_output_files(
    files: list[dict],
    *,
    target: str | Path = ".",
    downloader: Callable[..., httpx.Response] | None = None,
) -> list[Path]:
    if not files:
        return []

    destination = Path(target)
    destination.mkdir(parents=True, exist_ok=True)
    key = config_store.get_api_key()
    downloaded: list[Path] = []
    request = downloader or httpx.get

    for file_info in files:
        filename = file_info.get("name", "file")
        url = file_info.get("url", "")
        response = request(
            url,
            headers={"Authorization": f"Bearer {key}"},
            timeout=300,
        )
        response.raise_for_status()
        path = destination / filename
        path.write_bytes(response.content)
        downloaded.append(path)

    return downloaded


def download_job_outputs(
    job_id: str,
    *,
    target: str | Path = ".",
    downloader: Callable[..., httpx.Response] | None = None,
) -> list[Path]:
    return download_output_files(
        list_output_files(job_id),
        target=target,
        downloader=downloader,
    )


def get_team_list() -> list[dict]:
    return get("/api/team/list").get("teams", [])


def get_team_config() -> dict:
    return get("/api/team/config")


def save_team_config(
    *,
    platform: str,
    credentials: dict,
    set_default: bool = False,
) -> None:
    body: dict = {"platform": platform, "credentials": credentials}
    if set_default:
        body["defaultPlatform"] = platform
    post("/api/team/config", json=body)
