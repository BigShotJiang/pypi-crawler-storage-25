import numpy as np
import os
import glob
import re

from astropy.io import fits
from astropy.wcs import WCS
from astropy.wcs.utils import proj_plane_pixel_scales


FILTER_DATABASE = {
    "JWST": {
        "filters": {
            # -----------------
            # NIRCam SW
            # -----------------
            "F070W": {"lambda": 7039.12, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F090W": {"lambda": 9021.53, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F115W": {"lambda": 11542.61, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F140M": {"lambda": 14053.23, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F150W": {"lambda": 15007.44, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F162M": {"lambda": 16272.47, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F164N": {"lambda": 16445.36, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F150W2": {"lambda": 16592.11, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F182M": {"lambda": 18451.67, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F187N": {"lambda": 18738.99, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F200W": {"lambda": 19886.48, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F210M": {"lambda": 20954.51, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},
            "F212N": {"lambda": 21213.18, "instrument": "NIRCam", "group": "SW", "output_group": "NIRCam-SW"},

            # -----------------
            # NIRCam LW
            # -----------------
            "F250M": {"lambda": 25032.33, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F277W": {"lambda": 27617.40, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F300M": {"lambda": 29891.21, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F323N": {"lambda": 32368.53, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F322W2": {"lambda": 32319.76, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F335M": {"lambda": 33620.67, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F356W": {"lambda": 35683.62, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F360M": {"lambda": 36241.76, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F405N": {"lambda": 40516.53, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F410M": {"lambda": 40822.38, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F430M": {"lambda": 42812.58, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F444W": {"lambda": 44043.15, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F460M": {"lambda": 46299.28, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F466N": {"lambda": 46544.30, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F470N": {"lambda": 47077.91, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
            "F480M": {"lambda": 48181.95, "instrument": "NIRCam", "group": "LW", "output_group": "NIRCam-LW"},
        },
    },

    "HST": {
        "filters": {
            # ACS
            "F435W": {"lambda": 4329.85, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F475W": {"lambda": 4746.94, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F555W": {"lambda": 5361.03, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F606W": {"lambda": 5921.88, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F625W": {"lambda": 6311.85, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F775W": {"lambda": 7693.47, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F814W": {"lambda": 8045.53, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},
            "F850LP": {"lambda": 9031.48, "instrument": "ACS", "group": "ACS", "output_group": "ACS"},

            # WFC3 UVIS
            "F225W": {"lambda": 2357.65, "instrument": "WFC3-UVIS", "group": "UVIS", "output_group": "WFC3-UVIS"},
            "F275W": {"lambda": 2702.92, "instrument": "WFC3-UVIS", "group": "UVIS", "output_group": "WFC3-UVIS"},
            "F336W": {"lambda": 3354.60, "instrument": "WFC3-UVIS", "group": "UVIS", "output_group": "WFC3-UVIS"},
            "F390W": {"lambda": 3920.70, "instrument": "WFC3-UVIS", "group": "UVIS", "output_group": "WFC3-UVIS"},

            # WFC3 IR
            "F098M": {"lambda": 9862.72, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F105W": {"lambda": 10550.25, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F110W": {"lambda": 11534.46, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F125W": {"lambda": 12486.07, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F127M": {"lambda": 12741.07, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F139M": {"lambda": 13841.81, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F140W": {"lambda": 13923.21, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F153M": {"lambda": 15332.75, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
            "F160W": {"lambda": 15370.34, "instrument": "WFC3-IR", "group": "IR", "output_group": "WFC3-IR"},
        },
    },

    "LSST": {
        "filters": {
            "u": {"lambda": 3680.04, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
            "g": {"lambda": 4782.26, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
            "r": {"lambda": 6217.82, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
            "i": {"lambda": 7532.28, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
            "z": {"lambda": 8685.06, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
            "y": {"lambda": 9730.05, "instrument": "LSST", "group": "LSST", "output_group": "LSST"},
        },
    },

    "JPAS": {
        "filters": {
            # Broad bands
            "uJAVA": {"lambda": 3545.16, "instrument": "JPAS", "group": "broad", "output_group": "JPAS"},
            "u": {"lambda": 3696.25, "instrument": "JPAS", "group": "broad", "output_group": "JPAS"},
            "gSDSS": {"lambda": 4767.98, "instrument": "JPAS", "group": "broad", "output_group": "JPAS"},
            "rSDSS": {"lambda": 6245.36, "instrument": "JPAS", "group": "broad", "output_group": "JPAS"},
            "iSDSS": {"lambda": 7656.20, "instrument": "JPAS", "group": "broad", "output_group": "JPAS"},

            # Narrow bands
            "J0378": {"lambda": 3796.72, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0390": {"lambda": 3904.35, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0400": {"lambda": 4007.05, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0410": {"lambda": 4116.21, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0420": {"lambda": 4209.93, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0430": {"lambda": 4310.85, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0440": {"lambda": 4408.62, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0450": {"lambda": 4515.05, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0460": {"lambda": 4608.91, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0470": {"lambda": 4705.05, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0480": {"lambda": 4808.56, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0490": {"lambda": 4906.78, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0500": {"lambda": 5005.77, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0510": {"lambda": 5102.18, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0520": {"lambda": 5208.42, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0530": {"lambda": 5304.05, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0540": {"lambda": 5397.35, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0550": {"lambda": 5502.11, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0560": {"lambda": 5604.63, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0570": {"lambda": 5710.16, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0580": {"lambda": 5811.75, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0590": {"lambda": 5920.18, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0600": {"lambda": 6010.29, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0610": {"lambda": 6117.67, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0620": {"lambda": 6209.24, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0630": {"lambda": 6312.87, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0640": {"lambda": 6410.68, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0650": {"lambda": 6507.56, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0660": {"lambda": 6607.63, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0670": {"lambda": 6713.15, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0680": {"lambda": 6810.86, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0690": {"lambda": 6916.25, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0700": {"lambda": 7008.56, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0710": {"lambda": 7121.87, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0720": {"lambda": 7212.05, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0730": {"lambda": 7312.16, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0740": {"lambda": 7416.10, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0750": {"lambda": 7501.82, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0760": {"lambda": 7599.48, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0770": {"lambda": 7720.67, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0780": {"lambda": 7808.15, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0790": {"lambda": 7908.32, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0800": {"lambda": 8007.07, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0810": {"lambda": 8114.29, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0820": {"lambda": 8216.72, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0830": {"lambda": 8318.81, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0840": {"lambda": 8410.94, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0850": {"lambda": 8509.07, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0860": {"lambda": 8598.06, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0870": {"lambda": 8709.04, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0880": {"lambda": 8819.03, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0890": {"lambda": 8910.48, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0900": {"lambda": 9003.26, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J0910": {"lambda": 9095.89, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
            "J1007": {"lambda": 9590.54, "instrument": "JPAS", "group": "narrow", "output_group": "JPAS"},
        },
    },
}


def get_filter(fname):
    """
    Infer filter name from filename using FILTER_DATABASE.
    Works for JWST, HST, LSST, JPAS and future surveys.
    """

    base = os.path.basename(fname).upper()

    all_filters = []
    for telescope in FILTER_DATABASE.values():
        all_filters.extend(telescope["filters"].keys())

    all_filters = sorted(all_filters, key=len, reverse=True)

    for filt in all_filters:
        if filt.upper() in base:
            return filt

    raise ValueError(f"Filter not found in filename: {fname}")


def get_filter_info(filt):
    """
    Return metadata for a given filter from FILTER_DATABASE.
    """
    for telescope in FILTER_DATABASE.values():
        if filt in telescope["filters"]:
            return telescope["filters"][filt]

    raise ValueError(f"Unknown filter: {filt}")

def pick_output_group(filt):
    """
    Return output grouping for a filter.
    """
    return get_filter_info(filt)["output_group"]


def pick_group(filt):
    """
    Return a group for a filter.
    """
    return get_filter_info(filt)["group"]

def pick_instrument(filt):
    """
    Return a instrument for a filter.
    """
    return get_filter_info(filt)["instrument"]

def sort_filters(filters):
    """
    Sort filters by wavelength.
    """
    return sorted(filters, key=lambda f: get_filter_info(f)["lambda"])


def add_custom_dataset(
    dataset_name,
    filters,
    overwrite=False
):
    """
    Add a custom dataset/survey to FILTER_DATABASE.

    Parameters
    ----------
    dataset_name : str
        Name of the telescope/survey (e.g. 'EUCLID', 'ROMAN').

    filters : dict
        Dictionary in format:

        {
            "FILTER1": {
                "lambda": 5500.0 (in angstroms),
                "instrument": "TelescopeCam",
                "group": "broad",
                "output_group": "Telescope"
            },
            ...
        }

    overwrite : bool, optional
        If True, overwrite existing dataset.

    Returns
    -------
    None
    """

    dataset_name = dataset_name.upper()

    required_keys = {
        "lambda",
        "instrument",
        "group",
        "output_group"
    }

    if dataset_name in FILTER_DATABASE and not overwrite:
        raise ValueError(
            f"Dataset '{dataset_name}' already exists. "
            "Use overwrite=True to replace it."
        )

    # validate filters
    for filt, meta in filters.items():

        missing = required_keys - set(meta.keys())
        if missing:
            raise ValueError(
                f"Filter '{filt}' missing keys: {missing}"
            )

        if not isinstance(meta["lambda"], (int, float)):
            raise TypeError(
                f"Filter '{filt}': lambda must be numeric."
            )

    FILTER_DATABASE[dataset_name] = {
        "filters": filters
    }

    print(f"Dataset '{dataset_name}' added successfully.")



def find_ext(hdul):
    """
    Finds the first FITS extension containing valid image data.

    Parameters
    ----------
    hdul : astropy.io.fits.HDUList
        Opened FITS file.

    Returns
    -------
    ext : int or None
        Index of the HDU containing image data. Returns None if not found.
    """
    for i, hdu in enumerate(hdul):
        if hdu.data is not None and isinstance(hdu.data, np.ndarray):
            return i
    return None
    
    
def save_fits(data, header, path):
    """
    Saves a FITS file to disk.

    Parameters
    ----------
    data : numpy.ndarray
        Image data.
    header : astropy.io.fits.Header
        FITS header.
    path : str
        Output FITS path.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fits.PrimaryHDU(data=data, header=header).writeto(path, overwrite=True)
    

def MJy_sr_to_jy(aligned_list):
    """
    Convert FITS images from MJy/sr to Jy/pixel using the PIXAR_SR keyword: Jy/pixel = (MJy/sr) * 1e6 * PIXAR_SR

    Parameters
    ----------
    aligned_list : list of tuples
        List in the form [(fits_path, filter_name), ...].

    Returns
    -------
    new_list : list of tuples
        List in the form [(new_fits_path, filter_name), ...] for the converted files.

    """
    new_list = []

    for fpath, filt in aligned_list:

        with fits.open(fpath) as hdul:
            ext = find_ext(hdul)
            if ext is None:
                print(f"No data extension found in '{fpath}'. Skipping.")
                continue

            data = hdul[ext].data.astype(np.float64)
            header = hdul[ext].header.copy()

            # Pixel area in steradians
            pixar_sr = header.get('PIXAR_SR')
            if pixar_sr is None:
                print(f"PIXAR_SR not found in '{fpath}'. Skipping.")
                continue

            # Conversion factor: MJy to Jy and multiply by pixel area
            factor = 1e6 * pixar_sr
            data_jy = data * factor

            # Update header
            header['BUNIT'] = 'Jy'
            header.add_history(
                f"Converted from MJy/sr to Jy/pixel using PIXAR_SR = {pixar_sr}"
            )

            # Output file name
            out_name = os.path.splitext(fpath)[0] + "_Jy.fits"

            # Save
            fits.PrimaryHDU(data_jy, header=header).writeto(out_name, overwrite=True)
            print(f"Saved: {out_name}")

            new_list.append((out_name, filt))

    return new_list

def get_pixel_scale(fits_path):
    """
    Opens FITS file and computes pixel scale in arcsec/pixel using WCS. Assumes square pixels and no significant distortion.
    """
    with fits.open(fits_path) as hdul:
        ext = find_ext(hdul)
        if ext is None:
            raise ValueError(f"No valid image data in '{fits_path}'.")

        wcs = WCS(hdul[ext].header)

    pixscale = proj_plane_pixel_scales(wcs)[0] * 3600.0
    return pixscale
    
    
def get_pixel_scale_from_wcs(wcs):
    """
    Compute pixel scale in arcsec/pixel from a WCS object.
    Assumes square pixels and no significant distortion.
    """
    return proj_plane_pixel_scales(wcs)[0] * 3600.0


