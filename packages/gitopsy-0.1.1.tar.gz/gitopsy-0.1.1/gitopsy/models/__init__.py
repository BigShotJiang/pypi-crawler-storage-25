"""Gitopsy data models."""
