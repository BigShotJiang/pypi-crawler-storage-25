"""Gitopsy HTML report generation."""
