"""Skaal examples."""
