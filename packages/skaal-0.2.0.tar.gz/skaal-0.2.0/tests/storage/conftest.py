"""Storage test fixtures."""
