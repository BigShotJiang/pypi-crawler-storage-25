"""PR-C1 ask_followup_question tests.

Covers:
- args validation (question length, options cap, empty options normalize)
- happy path: option pick by index, free-text answer
- option-string-equality classified as option_picked (mirrors Cline)
- yolo short-circuit returns the documented error string
- cap-per-turn enforcement (3rd call returns error)
- sub-agent rejection via registry-subset (unknown_tool error)
- plan-mode allowed (no filesystem effects)
- KeyboardInterrupt propagates past the helper
- system-prompt language (the "prefer assumption" bullet)
- empty input re-prompts

Mocking strategy: monkeypatch `fred.tools._ask_prompt._get_prompt_fn`
so no real stdin is touched. Mirrors how `test_permissions.py` swaps
`Prompt.ask`.
"""
from __future__ import annotations

import io
from contextlib import contextmanager
from types import SimpleNamespace
from unittest.mock import patch

import pytest
from rich.console import Console

from fred.system_prompt import build as build_system_prompt
from fred.tools import _ask_prompt
from fred.tools._ask_prompt import (
    AskFollowupContext,
    set_ask_followup_context,
    reset_ask_followup_context,
    prompt_user,
)
from fred.tools.ask_followup import AskFollowupArgs, run as ask_followup_run
from fred.tools.agent_tool import _PARENT_ONLY_TOOLS, subset_for
from fred.tools.registry import default_registry


# ---------- helpers -------------------------------------------------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


@contextmanager
def _scripted_prompt(answers: list[str]):
    """Patch ``_get_prompt_fn`` to return the next scripted answer.

    Each call to ``Prompt.ask`` consumes one entry from ``answers``.
    Raising ``StopIteration`` (we run out) means the test scripted too
    few answers — surface that loudly via IndexError to the test.
    """
    answers_iter = iter(answers)

    def fake_prompt(*_args, **_kwargs):
        try:
            return next(answers_iter)
        except StopIteration as e:
            raise IndexError("scripted prompt ran out of answers") from e

    with patch.object(_ask_prompt, "_get_prompt_fn", lambda: fake_prompt):
        yield


@contextmanager
def _scripted_prompt_raising(exc: BaseException):
    def fake_prompt(*_args, **_kwargs):
        raise exc

    with patch.object(_ask_prompt, "_get_prompt_fn", lambda: fake_prompt):
        yield


@contextmanager
def _ask_ctx(**kwargs):
    """Install an AskFollowupContext for the duration of the block."""
    ctx = AskFollowupContext(**kwargs)
    token = set_ask_followup_context(ctx)
    try:
        yield ctx
    finally:
        reset_ask_followup_context(token)


# ---------- args validation -----------------------------------------------


class TestArgsValidation:
    def test_empty_question_rejected(self):
        with pytest.raises(Exception):
            AskFollowupArgs(question="")

    def test_too_long_question_rejected(self):
        with pytest.raises(Exception):
            AskFollowupArgs(question="x" * 1001)

    def test_too_many_options_rejected(self):
        with pytest.raises(Exception):
            AskFollowupArgs(
                question="pick one",
                options=["a", "b", "c", "d", "e", "f"],
            )

    def test_empty_options_normalize_to_none(self):
        args = AskFollowupArgs(question="hi", options=[])
        assert args.options is None

    def test_whitespace_only_option_rejected(self):
        with pytest.raises(Exception):
            AskFollowupArgs(question="hi", options=["valid", "   "])

    def test_too_long_option_rejected(self):
        with pytest.raises(Exception):
            AskFollowupArgs(question="hi", options=["x" * 201])

    def test_normal_args_accepted(self):
        args = AskFollowupArgs(
            question="which file?", options=["a.py", "b.py"],
        )
        assert args.question == "which file?"
        assert args.options == ["a.py", "b.py"]


# ---------- happy paths ---------------------------------------------------


class TestHappyPath:
    def test_pick_option_by_index(self):
        args = AskFollowupArgs(question="which?", options=["foo", "bar"])
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["2"]):
                out = ask_followup_run(args)
        assert out == "<answer>bar</answer>"

    def test_pick_option_by_exact_text(self):
        args = AskFollowupArgs(question="which?", options=["foo", "bar"])
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["bar"]):
                answer = prompt_user(args.question, args.options)
        assert answer.kind == "option_picked"
        assert answer.option_index == 2
        assert answer.text == "bar"

    def test_free_text_when_options_present(self):
        args = AskFollowupArgs(question="which?", options=["foo", "bar"])
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["something else entirely"]):
                answer = prompt_user(args.question, args.options)
        assert answer.kind == "free_text"
        assert answer.option_index is None
        assert answer.text == "something else entirely"

    def test_free_text_no_options(self):
        args = AskFollowupArgs(question="describe the bug")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["null pointer in foo()"]):
                out = ask_followup_run(args)
        assert out == "<answer>null pointer in foo()</answer>"

    def test_empty_input_reprompts(self):
        args = AskFollowupArgs(question="describe")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["", "  ", "got it"]):
                out = ask_followup_run(args)
        assert out == "<answer>got it</answer>"

    def test_numeric_out_of_range_treated_as_free_text(self):
        # Numeric input that's NOT a valid option index is free text.
        args = AskFollowupArgs(question="which?", options=["foo", "bar"])
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["99"]):
                answer = prompt_user(args.question, args.options)
        assert answer.kind == "free_text"
        assert answer.text == "99"


# ---------- yolo short-circuit -------------------------------------------


class TestYoloMode:
    def test_yolo_returns_error_string_without_prompting(self):
        # The fake prompt should never be called in yolo mode.
        called = []

        def boom(*_a, **_k):
            called.append(True)
            return "this should never run"

        with patch.object(_ask_prompt, "_get_prompt_fn", lambda: boom):
            with _ask_ctx(yolo=True, console=_silent_console()):
                args = AskFollowupArgs(question="hello?")
                out = ask_followup_run(args)

        assert called == []
        assert out.startswith("Error: yolo mode is on")
        assert "Make your best guess" in out


# ---------- cap-per-turn -------------------------------------------------


class TestCapPerTurn:
    def test_third_call_returns_error(self):
        args = AskFollowupArgs(question="ok?")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["a", "b"]):
                out1 = ask_followup_run(args)
                out2 = ask_followup_run(args)
                # third call returns error WITHOUT consuming a scripted answer
                out3 = ask_followup_run(args)
        assert out1 == "<answer>a</answer>"
        assert out2 == "<answer>b</answer>"
        assert out3.startswith("Error: ask_followup_question called too many times")

    def test_counter_isolated_per_context(self):
        # A fresh AskFollowupContext (e.g. next turn) starts at 0.
        args = AskFollowupArgs(question="ok?")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["a", "b"]):
                ask_followup_run(args)
                ask_followup_run(args)
        # New ctx, should NOT see the cap-exceeded error.
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt(["fresh"]):
                out = ask_followup_run(args)
        assert out == "<answer>fresh</answer>"


# ---------- sub-agent rejection ------------------------------------------


class TestSubagentRejection:
    def test_ask_followup_in_parent_only_tools(self):
        assert "ask_followup_question" in _PARENT_ONLY_TOOLS

    def test_general_subset_excludes_ask_followup(self):
        reg = default_registry()
        assert "ask_followup_question" in reg.names()
        general = subset_for("general", reg)
        assert "ask_followup_question" not in general

    def test_explore_profile_excludes_ask_followup(self):
        reg = default_registry()
        explore = subset_for("explore", reg)
        assert "ask_followup_question" not in explore

    def test_plan_profile_excludes_ask_followup(self):
        reg = default_registry()
        plan = subset_for("plan", reg)
        assert "ask_followup_question" not in plan


# ---------- plan-mode allow ----------------------------------------------


class TestPlanMode:
    def test_in_plan_tools_allowlist(self):
        from fred.mode import PLAN_TOOLS
        assert "ask_followup_question" in PLAN_TOOLS


# ---------- interrupt propagation ----------------------------------------


class TestInterruptPropagation:
    def test_keyboard_interrupt_propagates(self):
        args = AskFollowupArgs(question="ok?")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt_raising(KeyboardInterrupt()):
                with pytest.raises(KeyboardInterrupt):
                    ask_followup_run(args)

    def test_eof_propagates(self):
        args = AskFollowupArgs(question="ok?")
        with _ask_ctx(console=_silent_console()):
            with _scripted_prompt_raising(EOFError()):
                with pytest.raises(EOFError):
                    ask_followup_run(args)


# ---------- system prompt language ---------------------------------------


class TestSystemPromptLanguage:
    def test_prefer_assumption_bullet_present_in_act(self):
        p = build_system_prompt(default_registry(), mode="act")
        assert "Prefer making a reasonable assumption and proceeding" in p
        assert "ask_followup_question" in p
        assert "Capped at 2 calls per turn" in p

    def test_prefer_assumption_bullet_present_in_plan(self):
        # Plan mode also surfaces the bullet (plan still wants the model
        # to pick assumptions over excessive clarification).
        p = build_system_prompt(default_registry(), mode="plan")
        assert "Prefer making a reasonable assumption and proceeding" in p


# ---------- telemetry event emission -------------------------------------


class TestTelemetryEvents:
    def test_event_emitted_on_successful_answer(self):
        captured: list[dict] = []

        class _StubTracer:
            def event(self, kind, payload=None, turn=None):
                captured.append({"kind": kind, "payload": payload})

        args = AskFollowupArgs(question="ok?")
        with _ask_ctx(
            console=_silent_console(),
            tracer=_StubTracer(),
            turn=SimpleNamespace(turn_index=0, user_input="x"),
        ):
            with _scripted_prompt(["yes"]):
                ask_followup_run(args)

        ask_events = [c for c in captured if c["kind"] == "ask_followup"]
        assert len(ask_events) == 1
        payload = ask_events[0]["payload"]
        assert payload["question_chars"] == 3
        assert payload["option_count"] == 0
        assert payload["answer_kind"] == "free_text"
        assert payload["answer_chars"] == 3
        assert payload["calls_this_turn"] == 1
