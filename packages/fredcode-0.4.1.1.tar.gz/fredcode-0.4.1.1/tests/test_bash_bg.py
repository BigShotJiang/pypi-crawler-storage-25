"""Background bash family (P3.4): bash_bg / bash_read / bash_kill.

Spawns real subprocesses so we exercise the actual Popen + drain-thread
path. All tests are wrapped in fresh session-state via
``set_session_state`` / ``reset_session_state`` so handles never leak
between cases (and also exercises the ContextVar-isolation contract).
"""
from __future__ import annotations

import contextvars
import time

import pytest

from fred.tools import bash_bg
from fred.tools.bash_bg import (
    BashBgArgs,
    BashKillArgs,
    BashReadArgs,
    cleanup,
    reset_event_emitter,
    reset_session_state,
    run_bg,
    run_kill,
    run_read,
    set_event_emitter,
    set_session_state,
)


# ---------------------------------------------------------------------------
# Fixtures


@pytest.fixture
def isolated_session():
    """Install a fresh per-test session state. Cleanup at teardown."""
    token = set_session_state()
    try:
        yield
    finally:
        # Make sure no procs survive the test
        try:
            cleanup()
        except Exception:
            pass
        reset_session_state(token)


def _wait_until_done(handle: str, timeout_sec: float = 10.0) -> None:
    """Poll bash_read until the process reports done (or timeout)."""
    deadline = time.perf_counter() + timeout_sec
    while time.perf_counter() < deadline:
        out = run_read(BashReadArgs(handle=handle))
        if "[done]" in out:
            return
        time.sleep(0.05)
    raise AssertionError(f"handle {handle} did not finish within {timeout_sec}s")


# ---------------------------------------------------------------------------
# Handle lifecycle


class TestBashBgStart:
    def test_start_returns_sequential_handle(self, isolated_session):
        h1 = run_bg(BashBgArgs(command="true"))
        h2 = run_bg(BashBgArgs(command="true"))
        assert h1 == "bash_1"
        assert h2 == "bash_2"
        # Drain to avoid leaks
        _wait_until_done(h1)
        _wait_until_done(h2)

    def test_handle_format_matches_claude_code(self, isolated_session):
        h = run_bg(BashBgArgs(command="true"))
        assert h.startswith("bash_")
        assert h.removeprefix("bash_").isdigit()
        _wait_until_done(h)

    def test_invalid_cwd_returns_error(self, isolated_session, tmp_path):
        # cwd outside project root is rejected.
        outside = tmp_path / "outside"
        outside.mkdir()
        out = run_bg(BashBgArgs(command="true", cwd=str(outside)))
        assert out.startswith("Error: cwd outside project root")

    def test_nonexistent_cwd_returns_error(self, isolated_session, tmp_path):
        out = run_bg(BashBgArgs(command="true", cwd=str(tmp_path / "nope")))
        assert out.startswith("Error: cwd does not exist")


# ---------------------------------------------------------------------------
# Delta-read semantics


class TestBashRead:
    def test_running_no_output_returns_running(self, isolated_session):
        # Long sleep that emits nothing for a while.
        h = run_bg(BashBgArgs(command="sleep 2"))
        # Read immediately — the process is alive but hasn't produced output.
        out = run_read(BashReadArgs(handle=h))
        assert out == "[running]"
        run_kill(BashKillArgs(handle=h))

    def test_completed_returns_done_with_exit_code(self, isolated_session):
        h = run_bg(BashBgArgs(command="echo hello && exit 0"))
        # Wait for the process to actually finish before reading.
        deadline = time.perf_counter() + 5.0
        out = ""
        while time.perf_counter() < deadline:
            out = run_read(BashReadArgs(handle=h))
            if "[done]" in out:
                break
            time.sleep(0.05)
        assert "hello" in out
        assert "[done] exit=0" in out

    def test_nonzero_exit_in_done_marker(self, isolated_session):
        h = run_bg(BashBgArgs(command="exit 7"))
        deadline = time.perf_counter() + 5.0
        out = ""
        while time.perf_counter() < deadline:
            out = run_read(BashReadArgs(handle=h))
            if "[done]" in out:
                break
            time.sleep(0.05)
        assert "[done] exit=7" in out

    def test_delta_semantics_each_read_returns_only_new(self, isolated_session):
        # Emit two batches with a sleep so we can read between.
        h = run_bg(BashBgArgs(
            command="echo first; sleep 0.3; echo second",
        ))
        # Wait for first line to land.
        deadline = time.perf_counter() + 3.0
        first = ""
        while time.perf_counter() < deadline:
            first = run_read(BashReadArgs(handle=h))
            if "first" in first:
                break
            time.sleep(0.05)
        assert "first" in first
        assert "second" not in first

        # Wait for the second line to drain in.
        deadline = time.perf_counter() + 3.0
        second = ""
        while time.perf_counter() < deadline:
            second = run_read(BashReadArgs(handle=h))
            if "second" in second:
                break
            time.sleep(0.05)
        assert "second" in second
        # The delta must NOT re-include the first line.
        assert "first" not in second
        _wait_until_done(h)

    def test_unknown_handle_returns_error(self, isolated_session):
        out = run_read(BashReadArgs(handle="bash_999"))
        assert out.startswith("Error: unknown handle")

    def test_max_lines_caps_returned_lines(self, isolated_session):
        h = run_bg(BashBgArgs(
            command="for i in 1 2 3 4 5 6 7 8 9 10; do echo line$i; done",
        ))
        # Wait for output to be present.
        deadline = time.perf_counter() + 3.0
        while time.perf_counter() < deadline:
            time.sleep(0.05)
            # Don't read yet — accumulate output first.
            if bash_bg._state().procs[h].popen.poll() is not None:
                break
        out = run_read(BashReadArgs(handle=h, max_lines=3))
        # Three lines + (running or done) marker. We only assert that not
        # all 10 lines are present in this single read.
        assert "line1" in out
        assert "line10" not in out
        # Subsequent read drains the rest.
        out2 = run_read(BashReadArgs(handle=h, max_lines=100))
        assert "line10" in out2
        _wait_until_done(h)


# ---------------------------------------------------------------------------
# Multiple parallel handles


class TestParallelHandles:
    def test_handles_are_independent(self, isolated_session):
        h1 = run_bg(BashBgArgs(command="echo from1"))
        h2 = run_bg(BashBgArgs(command="echo from2"))
        assert h1 != h2
        # Drain both
        deadline = time.perf_counter() + 5.0
        seen_1 = ""
        seen_2 = ""
        while time.perf_counter() < deadline:
            r1 = run_read(BashReadArgs(handle=h1))
            r2 = run_read(BashReadArgs(handle=h2))
            seen_1 += r1
            seen_2 += r2
            if "[done]" in seen_1 and "[done]" in seen_2:
                break
            time.sleep(0.05)
        assert "from1" in seen_1
        assert "from2" in seen_2
        # Reads do not bleed between handles.
        assert "from2" not in seen_1
        assert "from1" not in seen_2


# ---------------------------------------------------------------------------
# Kill semantics


class TestBashKill:
    def test_kill_terminates_long_running_process(self, isolated_session):
        h = run_bg(BashBgArgs(command="sleep 30"))
        t0 = time.perf_counter()
        out = run_kill(BashKillArgs(handle=h))
        elapsed = time.perf_counter() - t0
        assert out.startswith(f"Killed {h}")
        # SIGTERM should land the kill quickly; bound conservatively.
        assert elapsed < 5.0

    def test_kill_unknown_handle_returns_error(self, isolated_session):
        out = run_kill(BashKillArgs(handle="bash_does_not_exist"))
        assert out.startswith("Error: unknown handle")

    def test_kill_already_exited_reports_already_exited(self, isolated_session):
        h = run_bg(BashBgArgs(command="true"))
        # Wait for natural exit.
        deadline = time.perf_counter() + 3.0
        while time.perf_counter() < deadline:
            if bash_bg._state().procs[h].popen.poll() is not None:
                break
            time.sleep(0.02)
        out = run_kill(BashKillArgs(handle=h))
        assert "already exited" in out

    def test_kill_exit_code_reflects_signal(self, isolated_session):
        # SIGTERM => exit code is -15 on Unix (or 143 if shell-mediated).
        h = run_bg(BashBgArgs(command="sleep 30"))
        out = run_kill(BashKillArgs(handle=h))
        # Pull the exit= field out of the confirmation string.
        assert "exit=" in out
        # Either the shell propagated 143 or popen returned -15. Both
        # indicate SIGTERM-driven termination.
        proc = bash_bg._state().procs[h]
        assert proc.exit_code in (-15, 143, -9, 137, None)


# ---------------------------------------------------------------------------
# Cleanup


class TestCleanup:
    def test_cleanup_kills_running_procs(self, isolated_session):
        h1 = run_bg(BashBgArgs(command="sleep 30"))
        h2 = run_bg(BashBgArgs(command="sleep 30"))
        killed = cleanup()
        # Both were running and required termination.
        assert set(killed) == {h1, h2}

    def test_cleanup_skips_already_exited(self, isolated_session):
        h = run_bg(BashBgArgs(command="true"))
        # Wait for natural exit.
        deadline = time.perf_counter() + 3.0
        while time.perf_counter() < deadline:
            if bash_bg._state().procs[h].popen.poll() is not None:
                break
            time.sleep(0.02)
        killed = cleanup()
        assert h not in killed

    def test_cleanup_is_idempotent(self, isolated_session):
        h = run_bg(BashBgArgs(command="sleep 30"))
        first = cleanup()
        second = cleanup()
        assert h in first
        assert second == []  # Already terminated.


# ---------------------------------------------------------------------------
# ContextVar isolation


class TestContextVarIsolation:
    def test_separate_sessions_do_not_share_handles(self):
        # Outer session: spawn one handle.
        outer_token = set_session_state()
        try:
            h_outer = run_bg(BashBgArgs(command="sleep 30"))
            # Counter is 1 in this session.
            assert h_outer == "bash_1"

            # Run "inner session" inside a Context.copy() so the
            # ContextVar swap is genuine.
            ctx = contextvars.copy_context()

            def _inner():
                inner_token = set_session_state()
                try:
                    # Counter resets in the inner session.
                    h_inner = run_bg(BashBgArgs(command="sleep 30"))
                    assert h_inner == "bash_1"
                    # bash_read on the OUTER handle from inside the inner
                    # session must not find it.
                    out = run_read(BashReadArgs(handle="bash_1"))
                    # Either it points at the inner bash_1 (which was just
                    # spawned and shows [running]) — that's fine, we just
                    # care it's a *different* process. The presence test
                    # is on the dict identity.
                    assert "Error" not in out  # inner bash_1 exists
                    inner_state = bash_bg._state()
                    inner_handles = set(inner_state.procs.keys())
                    # Cleanup the inner session
                    cleanup()
                    return inner_handles
                finally:
                    reset_session_state(inner_token)

            inner_handles = ctx.run(_inner)
            # Inner session saw exactly its own one handle.
            assert inner_handles == {"bash_1"}
            # Outer session still has its handle and procs dict.
            outer_state = bash_bg._state()
            assert h_outer in outer_state.procs
            cleanup()
        finally:
            reset_session_state(outer_token)

    def test_fallback_state_used_when_no_contextvar_installed(self):
        # No set_session_state — fallback should be used.
        # Make sure to clean up so we don't pollute other tests.
        h = run_bg(BashBgArgs(command="sleep 30"))
        try:
            assert h.startswith("bash_")
            state = bash_bg._state()
            assert h in state.procs
        finally:
            run_kill(BashKillArgs(handle=h))


# ---------------------------------------------------------------------------
# Telemetry


class TestTelemetry:
    def test_events_emitted_via_emitter(self, isolated_session):
        events: list[tuple[str, dict]] = []

        def cb(kind: str, payload: dict) -> None:
            events.append((kind, payload))

        token = set_event_emitter(cb)
        try:
            h = run_bg(BashBgArgs(command="echo telemetry"))
            # Drain to done.
            deadline = time.perf_counter() + 3.0
            while time.perf_counter() < deadline:
                out = run_read(BashReadArgs(handle=h))
                if "[done]" in out:
                    break
                time.sleep(0.05)
        finally:
            reset_event_emitter(token)

        kinds = [k for k, _ in events]
        assert "bash_bg_start" in kinds
        # bash_bg_read fires on every read call.
        assert "bash_bg_read" in kinds
        # Find the start payload — must include handle + cwd, NOT command.
        start_payload = next(p for k, p in events if k == "bash_bg_start")
        assert start_payload["handle"] == h
        assert "cwd" in start_payload
        assert "command" not in start_payload  # privacy

    def test_kill_event_includes_signal_and_exit_code(self, isolated_session):
        events: list[tuple[str, dict]] = []
        token = set_event_emitter(lambda k, p: events.append((k, p)))
        try:
            h = run_bg(BashBgArgs(command="sleep 30"))
            run_kill(BashKillArgs(handle=h))
        finally:
            reset_event_emitter(token)

        kill_events = [p for k, p in events if k == "bash_bg_kill"]
        assert len(kill_events) >= 1
        last = kill_events[-1]
        assert last["handle"] == h
        assert "exit_code" in last
        assert "signal_used" in last

    def test_emitter_errors_do_not_abort_tool(self, isolated_session):
        # An emitter that raises must not propagate.
        def bad(kind: str, payload: dict) -> None:
            raise RuntimeError("boom")

        token = set_event_emitter(bad)
        try:
            h = run_bg(BashBgArgs(command="true"))
            assert h.startswith("bash_")
        finally:
            reset_event_emitter(token)
        _wait_until_done(h)


# ---------------------------------------------------------------------------
# Tool registration sanity (registry integration)


class TestRegistryIntegration:
    def test_tools_registered_in_default_registry(self):
        from fred.tools.registry import default_registry
        reg = default_registry()
        names = set(reg.names())
        assert "bash_bg" in names
        assert "bash_read" in names
        assert "bash_kill" in names

    def test_bash_bg_requires_permission(self):
        assert bash_bg.tool_bash_bg.requires_permission is True

    def test_bash_kill_requires_permission(self):
        assert bash_bg.tool_bash_kill.requires_permission is True

    def test_bash_read_does_not_require_permission(self):
        # Read is a model-facing observation; granting permission per
        # poll would be unbearable.
        assert bash_bg.tool_bash_read.requires_permission is False
