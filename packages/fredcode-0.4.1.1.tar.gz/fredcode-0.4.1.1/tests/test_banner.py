"""Banner panel snapshot tests.

The banner is rendered via Rich's Panel; we capture the console output
with `color_system=None` so ANSI escapes don't get in the way of plain
text assertions.
"""
from __future__ import annotations

import io

from rich.console import Console

from fred.cli import _render_banner
from fred.tools.registry import default_registry


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=80, color_system=None),
        buf,
    )


class TestBanner:
    def test_ask_permission_mode(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=registry)
        out = buf.getvalue()
        assert "fred" in out
        assert "deepseek-v4-flash" in out
        assert "ask-permission" in out
        assert "tools" in out
        assert "/help for commands" in out
        assert "@path" in out
        assert "!cmd" in out

    def test_yolo_mode(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-pro", yolo=True, registry=registry)
        out = buf.getvalue()
        assert "deepseek-v4-pro" in out
        assert "YOLO" in out
        assert "ask-permission" not in out

    def test_tool_count_matches_registry(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(console, "deepseek-v4-flash", yolo=False, registry=registry)
        out = buf.getvalue()
        # The mode line is "<mode> · N tools"; just confirm the count
        # number that appears matches the registry size.
        assert f"{len(registry.names())} tools" in out

    def test_mcp_row_appears_when_servers_connected(self):
        """When mcp_session reports connected servers, the banner shows
        a `mcp` row with the server names."""
        console, buf = _captured_console()
        registry = default_registry()

        class _FakeMCPSession:
            pass

        # Patch summarize_servers via the cli module's reference.
        from fred import cli

        original = cli.mcp_summarize_servers
        cli.mcp_summarize_servers = lambda _s: [
            {"name": "filesystem", "status": "connected"},
            {"name": "github",     "status": "connected"},
        ]
        try:
            _render_banner(
                console, "deepseek-v4-flash", yolo=False, registry=registry,
                mcp_session=_FakeMCPSession(),
            )
        finally:
            cli.mcp_summarize_servers = original

        out = buf.getvalue()
        assert "mcp" in out
        assert "filesystem" in out
        assert "github" in out

    def test_mcp_row_truncates_past_two(self):
        console, buf = _captured_console()
        registry = default_registry()

        class _FakeMCPSession:
            pass

        from fred import cli

        original = cli.mcp_summarize_servers
        cli.mcp_summarize_servers = lambda _s: [
            {"name": "filesystem", "status": "connected"},
            {"name": "github",     "status": "connected"},
            {"name": "supabase",   "status": "connected"},
            {"name": "linear",     "status": "connected"},
        ]
        try:
            _render_banner(
                console, "deepseek-v4-flash", yolo=False, registry=registry,
                mcp_session=_FakeMCPSession(),
            )
        finally:
            cli.mcp_summarize_servers = original

        out = buf.getvalue()
        assert "filesystem" in out
        assert "github" in out
        assert "+2 more" in out
        assert "supabase" not in out  # truncated past visible window

    def test_no_mcp_row_when_zero_connected(self):
        console, buf = _captured_console()
        registry = default_registry()
        _render_banner(
            console, "deepseek-v4-flash", yolo=False, registry=registry,
            mcp_session=None,
        )
        out = buf.getvalue()
        # The "mcp" label should not appear at the start of any row
        # (matches "  mcp     " row prefix). It can still appear inside
        # other content (it doesn't, in our fixture, but be specific).
        assert "  mcp     " not in out

    def test_narrow_terminal_uses_minimal_layout(self):
        buf = io.StringIO()
        # Width below 40 triggers the one-line fallback.
        console = Console(
            file=buf, force_terminal=False, width=30, color_system=None,
        )
        _render_banner(console, "deepseek-v4-flash", yolo=False,
                       registry=default_registry())
        out = buf.getvalue()
        assert "fred" in out
        assert "deepseek-v4-flash" in out
        assert "ask-permission" in out
        # Wolf art glyph absent: minimal layout doesn't render it.
        assert "╱╲" not in out
