"""Tests for fred.rates.refresh_from_server."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from fred import rates


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = json.dumps(payload) if isinstance(payload, (dict, list)) else str(payload)

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def _install_get(monkeypatch: pytest.MonkeyPatch, response: _FakeResponse | Exception) -> None:
    def fake_get(self, url, *args, **kwargs):  # noqa: ANN001 — httpx signature
        if isinstance(response, Exception):
            raise response
        return response

    monkeypatch.setattr("httpx.Client.get", fake_get)


def test_refresh_writes_cache_on_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    payload = {
        "version": 1,
        "models": [
            {
                "model": "deepseek-v4-flash",
                "effectiveFrom": "2026-05-01T00:00:00Z",
                "effectiveTo": None,
                "upstream": {"inputUncached": 140000, "inputCached": 2800, "output": 280000},
                "billed": {"inputUncached": 350000, "inputCached": 7000, "output": 700000},
            }
        ],
    }
    _install_get(monkeypatch, _FakeResponse(200, payload))

    cache_path = tmp_path / "rate-card.json"
    ok = rates.refresh_from_server("https://app.fredcode.net", path=cache_path)

    assert ok is True
    assert cache_path.exists()
    written = json.loads(cache_path.read_text(encoding="utf-8"))
    assert written["models"] == payload["models"]
    assert isinstance(written["fetched_at"], (int, float))
    assert written["fetched_at"] > 0


def test_refresh_returns_false_on_non_200(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    _install_get(monkeypatch, _FakeResponse(503, {"error": "down"}))

    cache_path = tmp_path / "rate-card.json"
    ok = rates.refresh_from_server("https://app.fredcode.net", path=cache_path)

    assert ok is False
    assert not cache_path.exists()
    err = capsys.readouterr().err
    assert "503" in err


def test_refresh_returns_false_on_network_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    _install_get(monkeypatch, httpx.ConnectError("connection refused"))

    cache_path = tmp_path / "rate-card.json"
    ok = rates.refresh_from_server("https://app.fredcode.net", path=cache_path)

    assert ok is False
    assert not cache_path.exists()


def test_refresh_rejects_unexpected_payload(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    # No "models" key — refresh should not write garbage to disk.
    _install_get(monkeypatch, _FakeResponse(200, {"version": 1}))

    cache_path = tmp_path / "rate-card.json"
    ok = rates.refresh_from_server("https://app.fredcode.net", path=cache_path)

    assert ok is False
    assert not cache_path.exists()


def test_refresh_strips_trailing_slash_from_base_url(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured: dict[str, str] = {}

    def fake_get(self, url, *args, **kwargs):  # noqa: ANN001
        captured["url"] = url
        return _FakeResponse(200, {"models": []})

    monkeypatch.setattr("httpx.Client.get", fake_get)

    cache_path = tmp_path / "rate-card.json"
    rates.refresh_from_server("https://app.fredcode.net/", path=cache_path)

    assert captured["url"] == "https://app.fredcode.net/api/pricing"


def test_refresh_creates_parent_directory(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    _install_get(monkeypatch, _FakeResponse(200, {"models": []}))

    nested = tmp_path / "fresh" / "nested" / "rate-card.json"
    ok = rates.refresh_from_server("https://app.fredcode.net", path=nested)

    assert ok is True
    assert nested.exists()
    assert nested.parent.is_dir()
