"""Tests for fred.auth."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import threading
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from fred.auth import (
    Credentials,
    InsufficientCreditsError,
    LoginError,
    LoginFlow,
    _CallbackHandler,
    _gen_pkce_pair,
    delete_credentials,
    load_credentials,
    save_credentials,
)


# --- PKCE -------------------------------------------------------------


def test_pkce_pair_shape() -> None:
    verifier, challenge = _gen_pkce_pair()
    assert 43 <= len(verifier) <= 128
    # Challenge must be the URL-safe base64 of sha256(verifier), no padding.
    expected = (
        base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest())
        .rstrip(b"=")
        .decode("ascii")
    )
    assert challenge == expected


def test_pkce_pair_unique_each_call() -> None:
    pairs = {_gen_pkce_pair() for _ in range(50)}
    assert len(pairs) == 50  # cryptographically negligible chance of collision


# --- Credentials persistence ------------------------------------------


def _sample_creds(api_key: str = "fred_live_test_xyz") -> Credentials:
    return Credentials(
        version=1,
        api_key=api_key,
        email="test@example.com",
        base_url="https://api.fredcode.net/v1",
        fetched_at="2026-04-30T12:00:00Z",
    )


def test_save_and_load_roundtrip(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    creds = _sample_creds()
    # Disable keyring during the test so the api_key is written to the file.
    with patch("fred.auth._keyring", None):
        save_credentials(creds, p)
        loaded = load_credentials(p)
    assert loaded is not None
    assert loaded.api_key == creds.api_key
    assert loaded.email == creds.email
    assert loaded.base_url == creds.base_url


def test_save_credentials_writes_mode_0600(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    with patch("fred.auth._keyring", None):
        save_credentials(_sample_creds(), p)
    mode = os.stat(p).st_mode & 0o777
    assert mode == 0o600, f"expected 0o600, got {oct(mode)}"


def test_load_credentials_returns_none_for_missing_file(tmp_path: Path) -> None:
    assert load_credentials(tmp_path / "nope.json") is None


def test_load_credentials_returns_none_for_malformed_file(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    p.write_text("{not json}", encoding="utf-8")
    assert load_credentials(p) is None


def test_load_credentials_tightens_loose_permissions(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    with patch("fred.auth._keyring", None):
        save_credentials(_sample_creds(), p)
    os.chmod(p, 0o644)  # simulate a leak
    with patch("fred.auth._keyring", None):
        loaded = load_credentials(p)
    assert loaded is not None
    mode = os.stat(p).st_mode & 0o777
    assert mode == 0o600, f"expected file to be re-tightened to 0o600, got {oct(mode)}"


def test_delete_credentials_removes_file_and_returns_prev(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    creds = _sample_creds()
    with patch("fred.auth._keyring", None):
        save_credentials(creds, p)
        prev = delete_credentials(p)
    assert prev is not None
    assert prev.api_key == creds.api_key
    assert not p.exists()


def test_delete_credentials_when_missing_returns_none(tmp_path: Path) -> None:
    assert delete_credentials(tmp_path / "missing.json") is None


# --- Keyring path -----------------------------------------------------


def test_save_uses_keyring_when_present(tmp_path: Path) -> None:
    p = tmp_path / "creds.json"
    fake_keyring = MagicMock()
    fake_keyring.set_password = MagicMock()
    fake_keyring.get_password = MagicMock(return_value="fred_live_from_keyring")
    creds = _sample_creds()
    with patch("fred.auth._keyring", fake_keyring):
        save_credentials(creds, p)
        fake_keyring.set_password.assert_called_once_with(
            "fredcli", creds.email, creds.api_key
        )
        # File contains an empty api_key when keyring is present.
        on_disk = json.loads(p.read_text(encoding="utf-8"))
        assert on_disk["api_key"] == ""
        loaded = load_credentials(p)
    assert loaded is not None
    assert loaded.api_key == "fred_live_from_keyring"


# --- LoginFlow exchange (HTTP-mocked end-to-end on the localhost path) ---


def test_login_browser_runs_full_flow(tmp_path: Path) -> None:
    """Drive login_browser end-to-end with patched HTTP + a fake browser-open
    that synthesises the localhost callback."""

    flow = LoginFlow(auth_base_url="https://test.fredcode.net", port=41258)
    captured_url: dict[str, str] = {}

    # Mock the three POST endpoints the flow hits.
    request_id = "req_test_123"
    one_time_code = "otc_test_xyz"
    api_key = "fred_live_xyz_abc"

    def fake_open(url: str) -> bool:
        # Capture the URL the flow opens, and synthesise the localhost callback.
        captured_url["authorize"] = url

        def hit_callback() -> None:
            time.sleep(0.1)
            import urllib.request

            urllib.request.urlopen(
                f"http://127.0.0.1:{flow.port}/callback?request_id={request_id}&one_time_code={one_time_code}",
                timeout=5,
            ).read()

        threading.Thread(target=hit_callback, daemon=True).start()
        return True

    class _Resp:
        def __init__(self, status: int, body: dict) -> None:
            self.status_code = status
            self._body = body
            self.text = json.dumps(body)

        def json(self) -> dict:
            return self._body

    def fake_post(self, url: str, **kwargs: object) -> _Resp:
        if url.endswith("/api/cli/start"):
            return _Resp(200, {"requestId": request_id})
        if url.endswith("/api/cli/exchange"):
            return _Resp(
                200,
                {
                    "apiKey": api_key,
                    "userId": "user_test",
                    "baseUrl": "https://api.fredcode.net/v1",
                },
            )
        return _Resp(500, {"error": "unexpected"})

    def fake_get(self, url: str, **kwargs: object) -> _Resp:
        if url.endswith("/api/cli/whoami"):
            return _Resp(200, {"email": "test@example.com"})
        return _Resp(404, {})

    with (
        patch("fred.auth.webbrowser.open", side_effect=fake_open),
        patch("httpx.Client.post", new=fake_post),
        patch("httpx.Client.get", new=fake_get),
    ):
        creds = flow.login_browser()

    assert creds.api_key == api_key
    assert creds.email == "test@example.com"
    assert creds.base_url == "https://api.fredcode.net/v1"
    assert "request_id=" + request_id in captured_url["authorize"]


def test_login_browser_raises_on_request_id_mismatch(monkeypatch: pytest.MonkeyPatch) -> None:
    flow = LoginFlow(auth_base_url="https://test.fredcode.net", port=41259)

    real_request_id = "req_real"
    bad_request_id = "req_attacker"

    class _Resp:
        def __init__(self, status: int, body: dict) -> None:
            self.status_code = status
            self._body = body
            self.text = json.dumps(body)

        def json(self) -> dict:
            return self._body

    def fake_post(self, url: str, **kwargs: object) -> _Resp:
        if url.endswith("/api/cli/start"):
            return _Resp(200, {"requestId": real_request_id})
        return _Resp(500, {"error": "unexpected"})

    def fake_open(url: str) -> bool:
        def hit_callback() -> None:
            time.sleep(0.1)
            import urllib.request

            # Attacker fires a callback with the WRONG request_id.
            urllib.request.urlopen(
                f"http://127.0.0.1:{flow.port}/callback?request_id={bad_request_id}&one_time_code=anything",
                timeout=5,
            ).read()

        threading.Thread(target=hit_callback, daemon=True).start()
        return True

    monkeypatch.setattr("httpx.Client.post", fake_post)
    monkeypatch.setattr("fred.auth.webbrowser.open", fake_open)

    with pytest.raises(LoginError, match="mismatch"):
        flow.login_browser()


# --- Errors -----------------------------------------------------------


def test_insufficient_credits_error_carries_topup_url() -> None:
    err = InsufficientCreditsError("https://app.fredcode.net/billing")
    assert err.topup_url == "https://app.fredcode.net/billing"
    assert "fredcode.net/billing" in str(err)
