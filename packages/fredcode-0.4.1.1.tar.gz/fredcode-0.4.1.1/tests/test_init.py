"""Tests for the `/init` slash command and its supporting machinery.

Covers:
- ``fred.init_prompt`` — mode detection across (no files / AGENTS.md
  only / CLAUDE.md only / both files) and directive lookup.
- ``fred.tools.agent_tool`` — the new ``init`` profile is registered as
  read-only; the system-prompt entry is the one from ``init_prompt``.
- ``AgentArgs`` Literal — ``init`` is NOT model-dispatchable.
- ``cli._handle_init_slash`` — three modes (fresh / improve / migrate),
  three menu choices (write / regenerate / cancel), refusal on
  concurrent-create races, the diff branch in improve mode, telemetry
  payload shape.
"""
from __future__ import annotations

import io
from pathlib import Path
from typing import get_args
from unittest.mock import MagicMock

import pytest
from rich.console import Console

from fred.client import StreamResult
from fred.init_prompt import (
    InitMode,
    detect_init_mode,
    directive_for_mode,
    init_system_prompt,
)
from fred.session import SessionResult
from fred.tools.agent_tool import (
    AGENT_PROFILES,
    AgentArgs,
    _subagent_system_prompt,
)


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return Console(file=buf, force_terminal=False, width=120, color_system=None), buf


class TestDetectInitMode:
    def test_fresh_when_neither_file_exists(self, tmp_path):
        assert detect_init_mode(tmp_path) == ("fresh", None)

    def test_improve_when_only_agents_md_exists(self, tmp_path):
        agents = tmp_path / "AGENTS.md"
        agents.write_text("# stub")
        mode, path = detect_init_mode(tmp_path)
        assert mode == "improve"
        assert path == agents

    def test_migrate_when_only_claude_md_exists(self, tmp_path):
        claude = tmp_path / "CLAUDE.md"
        claude.write_text("# stub")
        mode, path = detect_init_mode(tmp_path)
        assert mode == "migrate"
        assert path == claude

    def test_improve_when_both_exist_agents_wins(self, tmp_path):
        # AGENTS.md takes precedence over CLAUDE.md per
        # config.load_project_memory ordering.
        agents = tmp_path / "AGENTS.md"
        agents.write_text("# agents")
        (tmp_path / "CLAUDE.md").write_text("# claude")
        mode, path = detect_init_mode(tmp_path)
        assert mode == "improve"
        assert path == agents


class TestDirectiveForMode:
    @pytest.mark.parametrize("mode", ["fresh", "improve", "migrate"])
    def test_returns_non_empty_directive(self, mode):
        d = directive_for_mode(mode)
        assert isinstance(d, str)
        assert len(d) > 50  # non-trivial body

    def test_directives_are_distinct(self):
        a = directive_for_mode("fresh")
        b = directive_for_mode("improve")
        c = directive_for_mode("migrate")
        assert len({a, b, c}) == 3

    def test_init_mode_literal_complete(self):
        # If a new mode is added without updating directive_for_mode,
        # this assertion catches it before runtime.
        for m in get_args(InitMode):
            directive_for_mode(m)


class TestInitProfileRegistration:
    def test_init_profile_is_read_only(self):
        # `attempt_completion` (PR-B2) is the explicit terminator. It has
        # no filesystem effects — it only ends the turn — so it's safe
        # to include in the init profile alongside the read-only tools.
        assert AGENT_PROFILES["init"] == frozenset(
            {"view", "grep", "glob", "repo_map", "attempt_completion"},
        )

    def test_init_system_prompt_wired(self):
        # init's subagent dispatch uses the same body as the standalone
        # init_system_prompt() helper. Both resolve through the prompt
        # cache so identity-equality (`is`) doesn't apply — string
        # equality is the contract.
        assert _subagent_system_prompt("init") == init_system_prompt()

    def test_init_not_in_model_dispatchable_literal(self):
        # The model invokes the agent tool with `agent_type` constrained
        # by AgentArgs.agent_type. `init` MUST NOT appear there — only
        # the /init slash command (cli.py) reaches the init profile.
        # Otherwise the model could spawn an init subagent during a
        # regular turn and (with a different orchestrator) write
        # AGENTS.md without explicit user consent.
        annotation = AgentArgs.model_fields["agent_type"].annotation
        allowed = set(get_args(annotation))
        assert "init" not in allowed
        # Sanity: the three intended profiles ARE in the literal.
        assert {"explore", "plan", "general"} <= allowed


class TestInitSystemPromptShape:
    """The prompt is plain text but must include a few load-bearing
    markers so the model produces the expected structure. These tests
    don't validate ML quality — only that the bytes a model is going to
    consume contain the contract."""

    def test_lists_eight_sections(self):
        # Eight numbered headers in the prompt body.
        for i in range(1, 9):
            assert f"{i}." in init_system_prompt(), f"missing section #{i}"

    def test_mentions_length_cap(self):
        assert "150 lines" in init_system_prompt()

    def test_pins_read_only_tools(self):
        for tool in ("view", "grep", "glob", "repo_map"):
            assert tool in init_system_prompt()

    def test_forbids_branded_header(self):
        # Prompt must steer the model AWAY from `# CLAUDE.md` (Claude
        # Code's convention) so Fred users get neutral AGENTS.md output.
        assert 'CLAUDE.md' in init_system_prompt()
        # And it must positively prescribe the AGENTS.md form.
        assert "Project context" in init_system_prompt()


# ---------------------------------------------------------------------
# Integration tests for `_handle_init_slash`. We monkeypatch run_session
# to avoid an actual model call; the unit-of-work is the orchestration
# layer (mode detection → preview → menu → write → telemetry), not the
# model loop.
# ---------------------------------------------------------------------


def _fake_run_session(draft_text: str):
    """Build a fake run_session that returns a SessionResult with a
    pre-baked final_text. Captures the call args for inspection."""
    captured = {}

    def _fake(initial_messages, client, registry, **kwargs):
        captured["initial"] = initial_messages
        captured["registry"] = registry
        captured["kwargs"] = kwargs
        return SessionResult(
            final_text=draft_text,
            total_tokens_in=100,
            total_tokens_out=200,
            total_cached=50,
            tool_calls=[],
            finish_reason="stop",
            ended_at=0.0,
            messages=[
                {"role": "system", "content": initial_messages[0]["content"]},
                {"role": "user", "content": initial_messages[1]["content"]},
                {"role": "assistant", "content": draft_text},
            ],
        )

    _fake.captured = captured  # type: ignore[attr-defined]
    return _fake


def _fake_registry(tool_names: set[str] = None):
    """Stand-in registry that supports `.names()` and `.subset(set)`.
    Returns itself from `.subset` so the slash handler can iterate calls
    on the constrained registry without bringing the full Tool surface
    into the test."""
    if tool_names is None:
        tool_names = {"view", "grep", "glob", "repo_map", "bash"}
    reg = MagicMock()
    reg.names.return_value = tool_names
    sub = MagicMock()
    sub.names.return_value = tool_names & {"view", "grep", "glob", "repo_map"}
    reg.subset.return_value = sub
    return reg


def _fake_renderer():
    """A minimally usable Renderer stand-in. Real Renderer would also
    work but we want full control over headless construction."""
    from fred.render import Renderer
    return Renderer(console=_silent_console(), stream=False, headless=False)


def _fake_tracer():
    """Capture-only tracer so we can assert on emitted events."""
    events = []

    class _T:
        def event(self, name, payload=None, turn=None):
            events.append((name, payload))

        def start_turn(self, **kw):
            return None

        def start_iteration(self, *a, **kw):
            return None

        def end_iteration(self, *a, **kw):
            pass

        def record_tool_call(self, *a, **kw):
            pass

    t = _T()
    t.events = events  # type: ignore[attr-defined]
    return t


class TestHandleInitSlashFresh:
    def test_writes_file_on_w_in_fresh_mode(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Stub run_session to return a deterministic draft.
        draft = (
            "# Project context for Fake\n\n"
            "## What this is\nA test fixture.\n"
        )
        fake = _fake_run_session(draft)
        monkeypatch.setattr("fred.session.run_session", fake)
        # User answers 'w' to write.
        monkeypatch.setattr("builtins.input", lambda _: "w")

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )

        assert outcome == "wrote_fresh"
        target = tmp_path / "AGENTS.md"
        assert target.exists()
        assert target.read_text(encoding="utf-8").startswith(
            "# Project context for Fake",
        )
        # Telemetry: one init_run event with outcome=wrote_fresh
        kinds = [name for name, _ in tracer.events]
        assert "init_run" in kinds
        run_event = [p for n, p in tracer.events if n == "init_run"][-1]
        assert run_event["outcome"] == "wrote_fresh"
        assert run_event["mode"] == "fresh"
        assert run_event["regenerations"] == 0
        assert run_event["draft_lines"] >= 1
        assert run_event["total_tokens"] == 300

    def test_cancels_on_c_writes_no_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session("# stub draft"),
        )
        monkeypatch.setattr("builtins.input", lambda _: "c")

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "cancelled"
        assert not (tmp_path / "AGENTS.md").exists()
        kinds = [name for name, _ in tracer.events]
        assert "init_run" in kinds
        run_event = [p for n, p in tracer.events if n == "init_run"][-1]
        assert run_event["outcome"] == "cancelled"

    def test_regenerate_then_write_increments_counter(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session("# attempt"),
        )
        # 'r' first, then 'w' second.
        answers = iter(["r", "w"])
        monkeypatch.setattr("builtins.input", lambda _: next(answers))

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "wrote_fresh"
        run_event = [p for n, p in tracer.events if n == "init_run"][-1]
        assert run_event["regenerations"] == 1


class TestHandleInitSlashImprove:
    def test_improve_diff_then_write_overwrites_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "AGENTS.md"
        target.write_text(
            "# Project context for Old\n\nOld body.\n",
            encoding="utf-8",
        )
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session("# Project context for New\n\nNew body.\n"),
        )
        # 'd' to view diff, then 'w' to write.
        answers = iter(["d", "w"])
        monkeypatch.setattr("builtins.input", lambda _: next(answers))

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "wrote_improve"
        assert "New body" in target.read_text(encoding="utf-8")
        run_event = [p for n, p in tracer.events if n == "init_run"][-1]
        assert run_event["mode"] == "improve"

    def test_improve_cancel_after_diff_leaves_file_untouched(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        target = tmp_path / "AGENTS.md"
        original = "# Project context for Old\n\nOld body.\n"
        target.write_text(original, encoding="utf-8")
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session("# Project context for New\n\nNew body.\n"),
        )
        # 'd' for diff, then 'c' to cancel.
        answers = iter(["d", "c"])
        monkeypatch.setattr("builtins.input", lambda _: next(answers))

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "cancelled"
        # File content is exactly what it was.
        assert target.read_text(encoding="utf-8") == original


class TestHandleInitSlashMigrate:
    def test_migrate_writes_agents_md_keeps_claude_md(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        claude = tmp_path / "CLAUDE.md"
        claude.write_text("# old claude content", encoding="utf-8")
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session("# Project context for Migrated\n\nBody.\n"),
        )
        # 'w' to write; for the symlink prompt say no (default 'n' / empty).
        answers = iter(["w", ""])
        monkeypatch.setattr("builtins.input", lambda _: next(answers))

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "wrote_migrate"
        assert (tmp_path / "AGENTS.md").exists()
        # CLAUDE.md untouched; symlink declined.
        assert claude.exists() and not claude.is_symlink()
        assert claude.read_text(encoding="utf-8") == "# old claude content"


class TestHandleInitSlashEdgeCases:
    def test_empty_draft_returns_error(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Subagent returned an empty string — model failure mode.
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session(""),
        )
        # input shouldn't be reached, but stub it anyway.
        monkeypatch.setattr("builtins.input", lambda _: "c")

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "error"
        assert not (tmp_path / "AGENTS.md").exists()
        run_event = [p for n, p in tracer.events if n == "init_run"][-1]
        assert run_event["outcome"] == "error"

    def test_keyboard_interrupt_during_session_cancels(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        def _kbd(*a, **kw):
            raise KeyboardInterrupt()

        monkeypatch.setattr("fred.session.run_session", _kbd)
        monkeypatch.setattr("builtins.input", lambda _: "c")

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "cancelled"
        assert not (tmp_path / "AGENTS.md").exists()

    def test_strips_fenced_markdown_wrapper_if_model_added_one(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        wrapped = "```markdown\n# Project context for Wrapped\n\nBody.\n```"
        monkeypatch.setattr(
            "fred.session.run_session",
            _fake_run_session(wrapped),
        )
        monkeypatch.setattr("builtins.input", lambda _: "w")

        from fred.cli import _handle_init_slash
        renderer = _fake_renderer()
        tracer = _fake_tracer()

        outcome = _handle_init_slash(
            client=MagicMock(),
            registry=_fake_registry(),
            permissions=MagicMock(),
            renderer=renderer,
            console=renderer.console,
            tracer=tracer,
            repo_map_provider=lambda: "",
        )
        assert outcome == "wrote_fresh"
        body = (tmp_path / "AGENTS.md").read_text(encoding="utf-8")
        # The fenced wrapper is gone; the markdown content is preserved.
        assert "```" not in body
        assert body.startswith("# Project context for Wrapped")
