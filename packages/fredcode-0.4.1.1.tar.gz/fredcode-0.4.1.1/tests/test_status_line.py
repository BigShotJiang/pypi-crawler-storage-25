"""P3.3: status line + output styles.

Snapshot-style tests for `Renderer.status_line` (pure formatter), the
`Renderer.print_status_line` print path (rule vs reduced-motion plain
print), and the `output_style` axis on `system_prompt.build`. Slash
commands are exercised via the renderer/state surface (the cli.py
branch is glue around these).
"""
from __future__ import annotations

import io

import pytest
from rich.console import Console

from fred.render import Renderer
from fred.system_prompt import build as build_system_prompt
from fred.tools.registry import default_registry


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


class _FakeModelCfg:
    """Light stand-in for ModelConfig the formatter only needs `main_model` from."""

    def __init__(self, name: str) -> None:
        self.main_model = name


class TestStatusLineFormat:
    """Pure-formatter snapshots: `status_line` is a function from kwargs to str."""

    def test_all_fields_present(self):
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(
            model_cfg=_FakeModelCfg("deepseek-v4-flash"),
            mode="act",
            used_tokens=12_345,
            total_tokens=64_000,
            cost=0.0123,
            cache_hit_rate=0.78,
            repo_map_size=247,
            todos_active=(1, 4),
        )
        # Format: model · mode · tokens/total (X% cached) · $cost · repo: N · todos: A/B
        assert "deepseek-v4-flash" in line
        assert "act" in line
        assert "12k/64k" in line
        assert "(78% cached)" in line
        assert "$0.01" in line
        assert "repo: 247 files" in line
        assert "todos: 1/4 in progress" in line
        # Field separator is " · ".
        assert " · " in line

    def test_partial_fields(self):
        # Only model + mode supplied. Other fields skipped (compact mode).
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(
            model_cfg=_FakeModelCfg("deepseek-v4-pro"),
            mode="plan",
        )
        assert line == "deepseek-v4-pro · plan"

    def test_no_fields(self):
        # When everything is None / missing, the line is empty (the
        # printer treats empty as "skip the rule entirely").
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line()
        assert line == ""

    def test_cache_field_omitted_when_no_used_tokens(self):
        # Cache field needs a denominator. Without it, omit cleanly.
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(
            model_cfg=_FakeModelCfg("deepseek-v4-flash"),
            cache_hit_rate=0.5,
        )
        assert "cached" not in line
        assert "deepseek-v4-flash" in line

    def test_todos_omitted_when_total_zero(self):
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(
            model_cfg=_FakeModelCfg("m"),
            todos_active=(0, 0),
        )
        assert "todos" not in line

    def test_cost_dollar_format_small(self):
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(cost=0.00045)
        assert "$0.0004" in line  # 4-decimal precision under 1¢

    def test_cost_dollar_format_large(self):
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(cost=2.50)
        assert "$2.50" in line

    def test_repo_size_omitted_when_zero(self):
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(model_cfg=_FakeModelCfg("m"), repo_map_size=0)
        assert "repo" not in line

    def test_used_only_no_total(self):
        # Status line works with a used count even without a total.
        r = Renderer(console=_captured_console()[0], stream=False)
        line = r.status_line(
            model_cfg=_FakeModelCfg("m"),
            used_tokens=2_500,
            cache_hit_rate=0.4,
        )
        assert "2k" in line
        assert "(40% cached)" in line


class TestStatusLinePrintPath:
    """Print-path tests: `print_status_line` writes to console.

    Reduced-motion swaps `console.rule()` (which emits a horizontal
    divider) for a plain dim print. The test is text-level: the
    reduced-motion path must not contain rule characters and must
    contain the same content.
    """

    def test_default_uses_rule(self, monkeypatch):
        monkeypatch.delenv("FRED_REDUCED_MOTION", raising=False)
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        r.print_status_line(
            model_cfg=_FakeModelCfg("deepseek-v4-flash"),
            mode="act",
            cost=0.05,
        )
        out = buf.getvalue()
        # rich.console.rule emits horizontal separator characters
        # (thin Unicode lines or ASCII dashes depending on font support).
        # We assert at least one of the common ones appears AND the
        # status content is present.
        assert "deepseek-v4-flash" in out
        # Some rule character: ─ or = or - or ━ depending on ASCII fall.
        assert any(ch in out for ch in ("─", "━", "-"))

    def test_reduced_motion_uses_plain_print(self, monkeypatch):
        monkeypatch.setenv("FRED_REDUCED_MOTION", "1")
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        r.print_status_line(
            model_cfg=_FakeModelCfg("deepseek-v4-flash"),
            mode="act",
            cost=0.05,
        )
        out = buf.getvalue()
        assert "deepseek-v4-flash" in out
        # Reduced-motion mode must NOT call rule(), so no horizontal
        # divider characters should sweep the line. The Unicode rule
        # chars don't appear in our content otherwise.
        assert "─" not in out
        assert "━" not in out

    def test_empty_line_does_not_print(self, monkeypatch):
        # If the formatted line is empty, the printer should skip
        # output entirely (no empty rule, no blank line).
        monkeypatch.delenv("FRED_REDUCED_MOTION", raising=False)
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        r.print_status_line()  # all fields None → empty line
        assert buf.getvalue() == ""

    def test_headless_renderer_returns_line_without_printing(self):
        # Headless mode (subagents) returns the rendered line so the
        # caller can feed it to telemetry, but doesn't print to the
        # parent's console.
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False, headless=True)
        line = r.print_status_line(
            model_cfg=_FakeModelCfg("m"),
            mode="act",
        )
        assert line == "m · act"
        assert buf.getvalue() == ""

    def test_returned_string_matches_status_line(self):
        # The print path's return value must equal what `status_line`
        # would have produced — callers feed it to telemetry.
        console, _ = _captured_console()
        r = Renderer(console=console, stream=False)
        line = r.print_status_line(
            model_cfg=_FakeModelCfg("m"),
            mode="plan",
            cost=0.5,
        )
        expected = r.status_line(
            model_cfg=_FakeModelCfg("m"),
            mode="plan",
            cost=0.5,
        )
        assert line == expected


class TestOutputStyleSystemPrompt:
    """`build(reg, output_style="explanatory")` must add the new bullet."""

    def test_concise_default_unchanged(self):
        # The default (`concise`) is byte-identical to passing no style
        # — protects pre-P3.3 callers from drift.
        reg = default_registry()
        a = build_system_prompt(reg)
        b = build_system_prompt(reg, output_style="concise")
        assert a == b

    def test_explanatory_includes_fragment(self):
        reg = default_registry()
        p = build_system_prompt(reg, output_style="explanatory")
        # Three signal phrases from the fragment text.
        assert "After each significant change" in p
        assert "explaining what changed and why" in p
        assert "fuller answers than the default concise mode" in p

    def test_explanatory_keeps_safety_block(self):
        # The fragment is inserted BEFORE the # Safety section, not
        # after — verify safety is still last so no bullet leaks past
        # the contract footer.
        reg = default_registry()
        p = build_system_prompt(reg, output_style="explanatory")
        # `# Safety` must appear after the fragment.
        idx_frag = p.find("After each significant change")
        idx_safety = p.find("# Safety")
        assert idx_frag != -1
        assert idx_safety != -1
        assert idx_frag < idx_safety

    def test_explanatory_works_in_plan_mode(self):
        # The fragment is independent of mode; it should land in the
        # plan-mode template too.
        reg = default_registry()
        p = build_system_prompt(reg, mode="plan", output_style="explanatory")
        assert "You are in PLAN mode" in p  # plan template selected
        assert "After each significant change" in p  # fragment applied

    def test_concise_does_not_include_fragment(self):
        reg = default_registry()
        p = build_system_prompt(reg, output_style="concise")
        assert "After each significant change" not in p

    def test_concise_and_explanatory_differ(self):
        reg = default_registry()
        c = build_system_prompt(reg, output_style="concise")
        e = build_system_prompt(reg, output_style="explanatory")
        assert c != e


class TestStyleSlashFlipState:
    """The `/style` slash mutates the live output_style_state list.

    The full slash branch lives in cli.py, but its core mechanic is
    a list mutation. Test the mechanic directly so the next-turn
    behavior is locked in without a full REPL fixture.
    """

    def test_state_list_mutation_visible_to_helper(self):
        # Mirrors the cli.py pattern: a one-element list shared between
        # the slash handler and `current_output_style()`.
        state: list[str] = ["concise"]

        def current() -> str:
            return state[0]

        assert current() == "concise"
        state[0] = "explanatory"
        assert current() == "explanatory"

    def test_build_initial_messages_picks_up_current_style(self):
        # `_build_initial_messages` accepts an `output_style` kwarg
        # that flows into the system prompt. After /style flips the
        # state and /clear rebuilds, the new prompt picks up the
        # fragment. Test the kwarg plumbing directly.
        from fred.cli import _build_initial_messages
        msgs_concise, _ = _build_initial_messages(output_style="concise")
        msgs_explan, _ = _build_initial_messages(output_style="explanatory")
        assert msgs_concise[0]["content"] != msgs_explan[0]["content"]
        assert (
            "After each significant change"
            in msgs_explan[0]["content"]
        )
        assert (
            "After each significant change"
            not in msgs_concise[0]["content"]
        )
