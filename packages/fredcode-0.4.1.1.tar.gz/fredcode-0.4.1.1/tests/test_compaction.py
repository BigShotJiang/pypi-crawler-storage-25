"""P2.5 — context compaction (pruning + structured weak-model summary).

Covers six surfaces, mirroring the spec in §P2.5:

  1. ``prune_messages`` elides verbose tool-result content older than the
     trailing 20k-token window with a structured marker that names the
     originating tool.
  2. Pruning is idempotent: running it twice yields the same result.
  3. ``compact_messages`` calls the weak client, replaces the older half
     of history with one synthetic system message tagged
     ``COMPACTED_HEADER``, and leaves ``messages[0]`` (the cacheable
     prefix) untouched.
  4. The ``/compact [focus]`` slash command invokes ``compact_messages``,
     emits ``compaction_run`` telemetry, and prints the dim-line
     compaction notification.
  5. The auto-trigger in ``run_session`` fires once per turn when
     ``budget_status`` reports ``"compact"`` (>=85% of context).
  6. The ``Renderer.compaction_notification`` formatter is line-based
     and dim-styled.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from fred.client import DSClient
from fred.context import (
    COMPACTED_HEADER,
    budget_status,
    compact_messages,
    is_compacted_message,
    prune_messages,
)
from fred.permissions import PermissionPolicy
from fred.render import Renderer
from fred.session import run_session
from fred.telemetry import NullTracer
from fred.tools.registry import default_registry


# ---------- helpers (mirrors test_session.py / test_model_routing.py) ----


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls, reasoning_content=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u) if usage is not None else None
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _scripted_client(streams: list) -> DSClient:
    """DSClient whose openai stub returns the next scripted stream per call."""
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


class _CapturingTracer(NullTracer):
    """Lightweight tracer stub that records every `event(...)` call."""

    def __init__(self):
        self.events: list[tuple[str, dict | None]] = []

    def event(self, kind, *, payload=None, turn=None):
        self.events.append((kind, payload))


# ---------- prune_messages ------------------------------------------------


class TestPruneMessages:
    def test_old_verbose_tool_results_get_elided(self):
        # System + user + 50 (assistant -> tool) pairs where every tool
        # result is huge. Only the last few should stay raw; the rest
        # collapse to elision markers.
        big = "x" * 30_000  # well above _PRUNE_THRESHOLD (20k)
        messages: list[dict] = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "go"},
        ]
        for i in range(50):
            messages.append({
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": f"call_{i}",
                    "type": "function",
                    "function": {
                        "name": "view",
                        "arguments": f'{{"path":"src/file_{i}.py"}}',
                    },
                }],
            })
            messages.append({
                "role": "tool",
                "tool_call_id": f"call_{i}",
                "content": big,
            })

        pruned, chars_elided = prune_messages(messages, recent_token_budget=2_000)

        # Same length — pruning rewrites content, never drops messages.
        assert len(pruned) == len(messages)
        # System and user stay byte-identical.
        assert pruned[0] == messages[0]
        assert pruned[1] == messages[1]
        # At least one tool message was elided.
        assert chars_elided > 0
        # The first tool result (oldest) must be elided.
        first_tool_idx = 3  # system, user, assistant, tool
        elided = pruned[first_tool_idx]
        assert elided["role"] == "tool"
        assert elided["tool_call_id"] == "call_0"
        assert elided["content"].startswith("[elided:")
        assert "view" in elided["content"]
        # The marker names a path argument.
        assert "src/file_0.py" in elided["content"]
        # The marker reports the original char count.
        assert "30000 chars" in elided["content"]

    def test_recent_tool_results_stay_raw(self):
        big = "y" * 30_000
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "go"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "old", "type": "function",
                             "function": {"name": "view",
                                          "arguments": '{"path":"old.py"}'}}]},
            {"role": "tool", "tool_call_id": "old", "content": big},
            # Many small messages between to push the older one out of
            # the recent window.
            *[{"role": "user", "content": "z" * 400} for _ in range(20)],
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "new", "type": "function",
                             "function": {"name": "view",
                                          "arguments": '{"path":"new.py"}'}}]},
            {"role": "tool", "tool_call_id": "new", "content": big},
        ]
        pruned, chars_elided = prune_messages(messages, recent_token_budget=2_000)
        # Old tool result elided.
        old = next(m for m in pruned if m.get("tool_call_id") == "old")
        assert old["content"].startswith("[elided:")
        # Newest tool result preserved raw.
        new = next(m for m in pruned if m.get("tool_call_id") == "new")
        assert new["content"] == big

    def test_below_threshold_tool_results_are_left_alone(self):
        # Even when the message is "old," small tool results are kept
        # raw — eliding them costs more than it saves.
        small = "small result"
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "u"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "c1", "type": "function",
                             "function": {"name": "view",
                                          "arguments": '{"path":"a.py"}'}}]},
            {"role": "tool", "tool_call_id": "c1", "content": small},
            *[{"role": "user", "content": "x" * 400} for _ in range(40)],
        ]
        pruned, _ = prune_messages(messages, recent_token_budget=2_000)
        kept = next(m for m in pruned if m.get("tool_call_id") == "c1")
        assert kept["content"] == small

    def test_outer_message_shape_preserved(self):
        big = "z" * 30_000
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "u"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "c1", "type": "function",
                             "function": {"name": "view",
                                          "arguments": '{"path":"a.py"}'}}]},
            {"role": "tool", "tool_call_id": "c1", "content": big,
             "extra_meta": "preserve_me"},
            *[{"role": "user", "content": "x" * 400} for _ in range(40)],
        ]
        pruned, _ = prune_messages(messages, recent_token_budget=2_000)
        elided = next(m for m in pruned if m.get("tool_call_id") == "c1")
        # Role, tool_call_id, and any extra keys survive — only content mutates.
        assert elided["role"] == "tool"
        assert elided["tool_call_id"] == "c1"
        assert elided.get("extra_meta") == "preserve_me"
        assert elided["content"].startswith("[elided:")

    def test_idempotent(self):
        big = "x" * 30_000
        messages: list[dict] = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "go"},
        ]
        for i in range(30):
            messages.append({
                "role": "assistant",
                "content": None,
                "tool_calls": [{
                    "id": f"call_{i}", "type": "function",
                    "function": {
                        "name": "bash",
                        "arguments": f'{{"command":"echo {i}"}}',
                    },
                }],
            })
            messages.append({
                "role": "tool", "tool_call_id": f"call_{i}", "content": big,
            })
        first, _ = prune_messages(messages, recent_token_budget=2_000)
        second, second_elided = prune_messages(first, recent_token_budget=2_000)
        # Second pass elides nothing more.
        assert second_elided == 0
        # Result is byte-equal to the first pass.
        assert first == second

    def test_handles_unknown_tool_call_id(self):
        # If the assistant message that originally emitted the tool_call
        # has been compacted away, the lookup misses; fall back to the
        # generic marker.
        big = "x" * 30_000
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "u"},
            # Tool message with no matching assistant tool_calls entry.
            {"role": "tool", "tool_call_id": "orphan", "content": big},
            *[{"role": "user", "content": "x" * 400} for _ in range(40)],
        ]
        pruned, _ = prune_messages(messages, recent_token_budget=2_000)
        orphan = next(m for m in pruned if m.get("tool_call_id") == "orphan")
        assert orphan["content"].startswith("[elided:")
        assert "tool result" in orphan["content"]
        assert "30000 chars" in orphan["content"]

    def test_does_not_mutate_input(self):
        big = "x" * 30_000
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "u"},
            {"role": "assistant", "content": None,
             "tool_calls": [{"id": "c1", "type": "function",
                             "function": {"name": "view",
                                          "arguments": '{"path":"a.py"}'}}]},
            {"role": "tool", "tool_call_id": "c1", "content": big},
            *[{"role": "user", "content": "x" * 400} for _ in range(40)],
        ]
        before_snapshot = [dict(m) for m in messages]
        prune_messages(messages, recent_token_budget=2_000)
        # Caller's list untouched.
        assert messages == before_snapshot


# ---------- compact_messages ---------------------------------------------


class TestCompactMessages:
    def _scripted_weak(self, summary_text: str) -> DSClient:
        return _scripted_client([iter([
            _delta_chunk(content=summary_text, finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 50, "completion_tokens": 20}),
        ])])

    def _build_long_history(self) -> list[dict]:
        """Long synthetic history with 15 user/assistant pairs."""
        messages: list[dict] = [
            {"role": "system", "content": "real system prompt (cacheable)"},
        ]
        for i in range(15):
            messages.append({"role": "user", "content": f"q{i}"})
            messages.append({"role": "assistant", "content": f"a{i}"})
        return messages

    def test_replaces_older_half_with_summary(self):
        messages = self._build_long_history()
        weak = self._scripted_weak(
            "## Accomplishments\n- did stuff\n\n"
            "## Current modifications\n- file X touched\n"
        )
        new_messages, stats = compact_messages(messages, weak)

        # Cacheable prefix (messages[0]) untouched.
        assert new_messages[0] == messages[0]
        # Synthetic summary inserted at index 1.
        assert new_messages[1]["role"] == "system"
        assert new_messages[1]["content"].startswith(COMPACTED_HEADER)
        assert "did stuff" in new_messages[1]["content"]
        assert is_compacted_message(new_messages[1])
        # Stats are populated.
        assert stats["summary_chars"] > 0
        assert stats["before_tokens"] > 0
        assert stats["after_tokens"] >= 0
        assert "elapsed_ms" in stats

    def test_recent_half_kept_raw(self):
        messages = self._build_long_history()
        weak = self._scripted_weak("summary text")
        new_messages, _ = compact_messages(messages, weak)
        # The recent tail of the original history should still be present
        # as raw user/assistant messages (not collapsed into the summary).
        # Specifically, the last several user entries should appear.
        last_q_contents = [m["content"] for m in new_messages
                           if m.get("role") == "user"]
        # At least the very last user message q14 is preserved.
        assert "q14" in last_q_contents

    def test_does_not_mutate_input(self):
        messages = self._build_long_history()
        snapshot = [dict(m) for m in messages]
        weak = self._scripted_weak("summary")
        compact_messages(messages, weak)
        assert messages == snapshot

    def test_focus_threaded_into_prompt(self):
        # Capture the prompt the weak client receives so we can verify
        # the focus hint is folded in.
        captured: list[list[dict]] = []
        client = DSClient(api_key="test", model="deepseek-v4-flash")

        def fake_create(**kwargs):
            captured.append(list(kwargs.get("messages", [])))
            return iter([
                _delta_chunk(content="ok", finish_reason="stop"),
                _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
            ])

        client._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=fake_create),
            )
        )
        compact_messages(self._build_long_history(), client, focus="billing module")
        assert captured, "weak client was never called"
        prompt_text = captured[0][0]["content"]
        assert "Focus: billing module" in prompt_text

    def test_short_history_no_op(self):
        # Too few messages to compact — return the input cleaned of any
        # prior compaction markers, with stats reflecting no change.
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        weak = self._scripted_weak("(unused)")
        new_messages, stats = compact_messages(messages, weak)
        assert new_messages == messages
        assert stats["before_tokens"] == stats["after_tokens"]
        assert stats["summary_chars"] == 0

    def test_strips_prior_compaction_marker(self):
        # If a previous compaction summary already exists, it gets
        # replaced rather than accumulated.
        messages = [
            {"role": "system", "content": "real system prompt"},
            {"role": "system",
             "content": f"{COMPACTED_HEADER}\nold summary here"},
        ]
        # Add 15 user/assistant pairs after the markers.
        for i in range(15):
            messages.append({"role": "user", "content": f"q{i}"})
            messages.append({"role": "assistant", "content": f"a{i}"})

        weak = self._scripted_weak("fresh summary")
        new_messages, _ = compact_messages(messages, weak)

        # Exactly one COMPACTED_HEADER message in the result.
        compaction_messages = [m for m in new_messages if is_compacted_message(m)]
        assert len(compaction_messages) == 1
        assert "fresh summary" in compaction_messages[0]["content"]
        assert "old summary here" not in compaction_messages[0]["content"]


class TestBudgetStatusCompactTier:
    def test_compact_tier_between_warn_and_hard(self):
        from fred.context import COMPACT_RATIO, CONTEXT_WINDOW
        # Build a synthetic content size that lands in the compact band.
        # Use mid-range to avoid drifting into hard.
        target_tokens = int(CONTEXT_WINDOW * (COMPACT_RATIO + 0.02))
        # Approx 4 chars / token via the fallback; multiply by 5 for safety
        # — count_tokens with tiktoken is more accurate but always >= the
        # fallback's lower bound so we stay above the threshold either way.
        chunk = "word " * (target_tokens)
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": chunk},
        ]
        used, status = budget_status(messages)
        assert status == "compact"
        assert used >= target_tokens

    def test_ok_unchanged_for_small_history(self):
        messages = [
            {"role": "system", "content": "sys"},
            {"role": "user", "content": "tiny"},
        ]
        _, status = budget_status(messages)
        assert status == "ok"


# ---------- /compact slash command ---------------------------------------


class TestCompactSlash:
    """Drive the `/compact` REPL branch via `_handle_compact_slash`-equivalent
    integration: the slash logic lives inline in cli.py's main loop, so we
    re-exercise the same code path by importing the shared helpers.
    """

    def test_compact_slash_invokes_compact_messages(self, monkeypatch):
        # We test the integration through cli's main slash dispatcher by
        # constructing the same arguments the REPL passes to
        # `compact_messages` and `tracer.event`. The point is to verify
        # the wire shape — the slash branch runs `compact_messages(...)`,
        # mutates `messages` in place, fires `compaction_run`, and prints
        # the dim notification.
        from fred.context import compact_messages as cm_real

        captured_calls: list[tuple] = []

        def fake_compact(messages, weak_client, *, focus=None, tracer=None, turn=0):
            captured_calls.append((list(messages), weak_client, focus))
            new = list(messages) + [
                {"role": "system",
                 "content": f"{COMPACTED_HEADER}\nsynthetic summary"}
            ]
            return new, {
                "before_tokens": 1000,
                "after_tokens": 200,
                "summary_chars": 18,
                "elapsed_ms": 5,
            }

        # Monkeypatch where the slash branch imports it.
        monkeypatch.setattr("fred.cli.compact_messages", fake_compact)

        # Drive the slash branch end-to-end via a synthetic REPL turn.
        # We simulate the relevant cli.py code by replicating the
        # imports the branch does and the args it constructs.
        from fred.cli import compact_messages as branch_compact  # rebind for clarity
        assert branch_compact is fake_compact

        # Now re-run the actual slash branch logic in isolation.
        client = DSClient(api_key="test", model="deepseek-v4-flash")
        messages = [
            {"role": "system", "content": "real sys"},
            {"role": "user", "content": "first"},
        ]
        console, buf = _captured_console()
        renderer = Renderer(console=console, stream=False)
        tracer = _CapturingTracer()
        focus = "billing"

        # Replicate the slash-branch body verbatim (the shape under test):
        from fred.config import load_model_config
        weak_cfg = load_model_config()
        weak_client = client.with_model(weak_cfg.weak_model)
        new_messages, stats = branch_compact(messages, weak_client, focus=focus)
        messages[:] = new_messages
        tracer.event("slash_command", payload={"cmd": "/compact", "focus": focus})
        tracer.event("compaction_run", payload={
            "trigger": "manual",
            "before_tokens": stats["before_tokens"],
            "after_tokens": stats["after_tokens"],
            "summary_chars": stats["summary_chars"],
            "focus": focus,
            "elapsed_ms": stats["elapsed_ms"],
        })
        renderer.compaction_notification(
            stats["before_tokens"], stats["after_tokens"], focus,
        )

        # Verify: compact_messages called with our focus.
        assert len(captured_calls) == 1
        _, _, captured_focus = captured_calls[0]
        assert captured_focus == "billing"
        # Messages mutated in place to include the summary marker.
        assert any(is_compacted_message(m) for m in messages)
        # Telemetry events fired.
        kinds = [k for k, _ in tracer.events]
        assert "slash_command" in kinds
        assert "compaction_run" in kinds
        run_payload = next(p for k, p in tracer.events if k == "compaction_run")
        assert run_payload["trigger"] == "manual"
        assert run_payload["focus"] == "billing"
        # Renderer printed the dim notification line.
        out = buf.getvalue()
        assert "compacted" in out
        assert "billing" in out

    def test_compact_slash_no_arg_uses_general_focus(self):
        # When the user types `/compact` with no arg, the renderer
        # surfaces "general" as the focus label.
        console, buf = _captured_console()
        renderer = Renderer(console=console, stream=False)
        renderer.compaction_notification(1000, 200, None)
        out = buf.getvalue()
        assert "general" in out


# ---------- Auto-trigger inside run_session ------------------------------


class TestAutoCompactionTrigger:
    """Auto-fire path: `budget_status` returns `"compact"` (>=85%), so
    `run_session` invokes `compact_messages` once at the start of the
    iteration, then continues normally.
    """

    def test_compaction_fires_once_per_turn(self, monkeypatch):
        # Force budget_status to "compact" so the trigger fires no matter
        # how short the synthetic history is.
        seen_calls = {"count": 0}

        def fake_budget_status(messages):
            return 900_000, "compact"

        # Replace the import inside session.py.
        monkeypatch.setattr("fred.session.budget_status", fake_budget_status)

        compact_calls: list[dict] = []

        def fake_compact(messages, weak_client, *, focus=None, tracer=None, turn=0):
            seen_calls["count"] += 1
            compact_calls.append({
                "messages": list(messages),
                "focus": focus,
            })
            return (
                [{"role": "system", "content": "real sys"},
                 {"role": "system",
                  "content": f"{COMPACTED_HEADER}\nfake summary"}]
                + messages[1:],
                {
                    "before_tokens": 900_000,
                    "after_tokens": 100_000,
                    "summary_chars": 50,
                    "elapsed_ms": 7,
                },
            )

        monkeypatch.setattr("fred.session.compact_messages", fake_compact)

        # Two iterations: tool call, then natural stop. The compaction
        # auto-trigger should fire exactly once across both.
        stream1 = iter([
            _delta_chunk(
                tool_calls=[
                    SimpleNamespace(
                        index=0, id="t1",
                        function=SimpleNamespace(name="view", arguments=None),
                    ),
                ],
            ),
            _delta_chunk(
                tool_calls=[
                    SimpleNamespace(
                        index=0, id=None,
                        function=SimpleNamespace(
                            name=None, arguments='{"path":"/tmp/__never__"}',
                        ),
                    ),
                ],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _scripted_client([stream1, stream2])
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        tracer = _CapturingTracer()

        run_session(
            [
                {"role": "system", "content": "real sys"},
                {"role": "user", "content": "go"},
            ],
            client, default_registry(),
            permissions=permissions,
            renderer=renderer,
            tracer=tracer,
            max_iters=3,
        )

        # Compaction called exactly once.
        assert seen_calls["count"] == 1
        # `compaction_run` event fired with trigger=auto.
        runs = [p for k, p in tracer.events if k == "compaction_run"]
        assert len(runs) == 1
        assert runs[0]["trigger"] == "auto"
        assert runs[0]["before_tokens"] == 900_000
        assert runs[0]["after_tokens"] == 100_000

    def test_no_compaction_when_budget_ok(self, monkeypatch):
        # Default budget tier is "ok" for tiny histories — auto-compaction
        # must not fire.
        compact_calls = {"count": 0}

        def fake_compact(messages, weak_client, *, focus=None, tracer=None, turn=0):
            compact_calls["count"] += 1
            return list(messages), {
                "before_tokens": 0, "after_tokens": 0,
                "summary_chars": 0, "elapsed_ms": 0,
            }

        monkeypatch.setattr("fred.session.compact_messages", fake_compact)

        stream = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _scripted_client([stream])
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())
        tracer = _CapturingTracer()

        run_session(
            [{"role": "system", "content": "sys"}, {"role": "user", "content": "hi"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, tracer=tracer,
        )

        assert compact_calls["count"] == 0
        runs = [p for k, p in tracer.events if k == "compaction_run"]
        assert runs == []


# ---------- Renderer output ----------------------------------------------


class TestRendererCompactionNotification:
    def test_dim_line_format(self):
        console, buf = _captured_console()
        renderer = Renderer(console=console, stream=False)
        renderer.compaction_notification(15_000, 3_200, "billing module")
        out = buf.getvalue()
        # Format: `compacted <X> -> <Y> tokens (focus: billing module)`
        assert "compacted" in out
        assert "billing module" in out
        # k-formatting kicks in for thousands.
        assert "15k" in out or "15000" in out
        assert "3k" in out or "3200" in out

    def test_general_focus_when_none(self):
        console, buf = _captured_console()
        renderer = Renderer(console=console, stream=False)
        renderer.compaction_notification(1_000, 200, None)
        assert "general" in buf.getvalue()

    def test_empty_focus_treated_as_general(self):
        console, buf = _captured_console()
        renderer = Renderer(console=console, stream=False)
        renderer.compaction_notification(1_000, 200, "   ")
        assert "general" in buf.getvalue()
