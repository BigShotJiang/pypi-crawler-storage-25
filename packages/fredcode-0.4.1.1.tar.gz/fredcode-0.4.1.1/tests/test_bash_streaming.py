"""Bash UX bundle (P1.3): streaming + head/tail + ANSI strip + cwd.

These tests exercise the rewritten ``tools/bash.py`` and its helpers.
They Popen real /bin/sh subprocesses for the streaming + timeout cases
because mocking subprocess line iteration is more brittle than just
running cheap one-liners. Pure-Python helpers (`strip_ansi`,
`truncate_head_tail`, cwd validation) are tested without subprocesses.
"""
from __future__ import annotations

import os
import subprocess
import time

from fred.tools import bash as bash_tool
from fred.tools._text_utils import strip_ansi, truncate_head_tail
from fred.tools.bash import BashArgs, run, set_on_line, reset_on_line


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class TestStripAnsi:
    def test_strips_sgr_color_codes(self):
        s = "\x1b[31mred\x1b[0m text \x1b[1;32mgreen\x1b[0m"
        out = strip_ansi(s)
        assert "\x1b" not in out
        assert out == "red text green"

    def test_strips_cursor_move_codes(self):
        s = "before\x1b[2Kafter"
        out = strip_ansi(s)
        assert "\x1b" not in out
        assert "before" in out and "after" in out

    def test_passes_through_non_ansi_text(self):
        s = "hello world\nno escapes here"
        assert strip_ansi(s) == s

    def test_handles_empty(self):
        assert strip_ansi("") == ""


class TestTruncateHeadTail:
    def test_short_string_passes_through(self):
        s = "x" * 100
        assert truncate_head_tail(s, head=200, tail=200) == s

    def test_within_slack_passes_through(self):
        # 1KB slack: head+tail+small overhead returns unchanged.
        s = "x" * (200 + 200 + 500)
        assert truncate_head_tail(s, head=200, tail=200) == s

    def test_long_string_keeps_head_and_tail(self):
        s = "A" * 50_000 + "MIDDLE" * 5_000 + "B" * 50_000
        out = truncate_head_tail(s, head=25_000, tail=25_000)
        # Head preserved
        assert out.startswith("A" * 1000)
        # Tail preserved
        assert out.endswith("B" * 1000)
        # Middle is gone
        assert "MIDDLE" not in out
        # Marker present
        assert "elided" in out

    def test_100kb_string_within_50kb_overhead(self):
        s = "X" * 100_000
        out = truncate_head_tail(s, head=25_000, tail=25_000)
        # 50KB head+tail + a small marker; well under 51KB total.
        assert len(out) < 50_000 + 200

    def test_marker_reports_lines_and_chars_elided(self):
        # Sizes must exceed head + tail + slack (1KB) for truncation to fire.
        head = "a\n" * 1500  # 3000 chars, 1500 newlines
        middle = "b\n" * 5000  # 10000 chars, 5000 newlines (will be elided)
        tail = "c\n" * 1500  # 3000 chars, 1500 newlines
        s = head + middle + tail
        out = truncate_head_tail(s, head=3_000, tail=3_000)
        # Marker mentions both lines and chars elided.
        assert "elided" in out
        assert "lines" in out
        assert "chars" in out
        # Middle marker line is gone from the body
        # but head and tail content survive.
        assert "a\na\n" in out
        assert "c\nc\n" in out


# ---------------------------------------------------------------------------
# Streaming (Popen + drain thread + on_line callback)
# ---------------------------------------------------------------------------

class TestStreaming:
    def test_callback_fires_per_line_in_order(self):
        # Five lines emitted with brief sleeps; assert callback fires 5 times
        # and lines arrive in order.
        seen: list[str] = []

        def on_line(line: str) -> None:
            seen.append(line.rstrip("\n"))

        token = set_on_line(on_line)
        try:
            args = BashArgs(
                command="for i in 1 2 3 4 5; do echo line$i; sleep 0.02; done",
                timeout_sec=10,
            )
            out = run(args)
        finally:
            reset_on_line(token)

        assert len(seen) == 5
        assert seen == ["line1", "line2", "line3", "line4", "line5"]
        assert "line1" in out and "line5" in out

    def test_no_callback_still_captures_output(self):
        args = BashArgs(command="echo hello", timeout_sec=5)
        out = run(args)
        assert "hello" in out

    def test_stderr_merged_into_stdout(self):
        args = BashArgs(
            command="echo out; echo err 1>&2",
            timeout_sec=5,
        )
        out = run(args)
        assert "out" in out
        assert "err" in out

    def test_nonzero_exit_prefixed(self):
        args = BashArgs(command="exit 7", timeout_sec=5)
        out = run(args)
        assert out.startswith("[exit 7]")


# ---------------------------------------------------------------------------
# ANSI handling on real bash output
# ---------------------------------------------------------------------------

class TestAnsiInBashOutput:
    def test_ansi_codes_stripped_from_model_facing_return(self):
        # printf interprets \033 escape sequences.
        cmd = r"printf '\033[31mred\033[0m and \033[32mgreen\033[0m\n'"
        out = run(BashArgs(command=cmd, timeout_sec=5))
        assert "\x1b" not in out
        assert "red" in out
        assert "green" in out


# ---------------------------------------------------------------------------
# Truncation in the bash pipeline
# ---------------------------------------------------------------------------

class TestBashTruncation:
    def test_long_output_keeps_head_and_tail_markers(self):
        # Emit a banner-tail pair around a long middle so we can verify
        # both ends survive truncation. Using printf is much faster than
        # a Python loop for ~30k lines via shell.
        cmd = (
            "echo START_BANNER; "
            "for i in $(seq 1 6000); do echo middle_$i; done; "
            "echo END_BANNER"
        )
        out = run(BashArgs(command=cmd, timeout_sec=30))
        # Tail is preserved (END_BANNER + nearby middle_5xxx lines)
        assert "END_BANNER" in out


# ---------------------------------------------------------------------------
# cwd validation
# ---------------------------------------------------------------------------

class TestCwd:
    def test_explicit_cwd_under_project_root_is_honored(self, monkeypatch, tmp_path):
        # Pretend the project root is tmp_path so we can put a sub-dir
        # under it without leaving the sandbox.
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "marker.txt").write_text("here")
        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        out = run(BashArgs(
            command="ls",
            timeout_sec=5,
            cwd=str(sub),
        ))
        assert "marker.txt" in out

    def test_cwd_is_passed_to_popen(self, monkeypatch, tmp_path):
        sub = tmp_path / "sub2"
        sub.mkdir()
        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())

        captured: dict = {}
        real_popen = subprocess.Popen

        def fake_popen(*a, **kw):
            captured["cwd"] = kw.get("cwd")
            return real_popen(*a, **kw)

        monkeypatch.setattr(subprocess, "Popen", fake_popen)
        run(BashArgs(command="echo ok", timeout_sec=5, cwd=str(sub)))
        assert captured["cwd"] == str(sub.resolve())

    def test_cwd_outside_project_root_rejected(self, monkeypatch, tmp_path):
        # Project root is tmp_path; pass a sibling directory.
        outside = tmp_path.parent / "outside_sibling_dir"
        outside.mkdir(exist_ok=True)
        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        try:
            out = run(BashArgs(
                command="echo nope",
                timeout_sec=5,
                cwd=str(outside),
            ))
            assert out.startswith("Error: cwd outside project root")
        finally:
            try:
                outside.rmdir()
            except OSError:
                pass

    def test_cwd_does_not_exist_rejected(self, monkeypatch, tmp_path):
        monkeypatch.setattr(bash_tool, "_PROJECT_ROOT", tmp_path.resolve())
        out = run(BashArgs(
            command="echo nope",
            timeout_sec=5,
            cwd=str(tmp_path / "does_not_exist"),
        ))
        assert out.startswith("Error: cwd does not exist")

    def test_default_cwd_is_passed_as_none(self, monkeypatch):
        captured: dict = {}
        real_popen = subprocess.Popen

        def fake_popen(*a, **kw):
            captured["cwd"] = kw.get("cwd")
            return real_popen(*a, **kw)

        monkeypatch.setattr(subprocess, "Popen", fake_popen)
        run(BashArgs(command="echo ok", timeout_sec=5))
        assert captured["cwd"] is None


# ---------------------------------------------------------------------------
# Timeout / signal escalation
# ---------------------------------------------------------------------------

class TestTimeout:
    def test_timeout_returns_error_string(self):
        # 1s timeout against a 10s sleep — should fire quickly.
        args = BashArgs(command="sleep 10", timeout_sec=1)
        t0 = time.perf_counter()
        out = run(args)
        elapsed = time.perf_counter() - t0
        assert out.startswith("Error: command timed out after 1s")
        # Killing should be fast: TERM grace 2s + KILL is bounded.
        assert elapsed < 5.0

    def test_timeout_escalates_term_then_kill(self, monkeypatch):
        # Fake Popen.wait to always raise TimeoutExpired so we can assert
        # both SIGTERM and SIGKILL are fired in order.
        sig_calls: list[tuple[int, int]] = []

        def fake_killpg(pgid: int, sig: int) -> None:
            sig_calls.append((pgid, sig))

        # Use a real short-lived process for getpgid to succeed; rig
        # Popen.wait to time out twice in sequence so we hit both branches.
        real_popen = subprocess.Popen

        class TimeoutPopen:
            def __init__(self, *a, **kw):
                self._inner = real_popen(*a, **kw)
                self.pid = self._inner.pid
                self.stdout = self._inner.stdout
                self.returncode = None
                self._wait_calls = 0

            def wait(self, timeout=None):
                self._wait_calls += 1
                # First wait (initial timeout) -> TimeoutExpired
                # Second wait (after SIGTERM grace) -> TimeoutExpired
                # Third wait (post-SIGKILL) -> normal completion via inner
                if self._wait_calls <= 2:
                    raise subprocess.TimeoutExpired(cmd="x", timeout=timeout or 0)
                return self._inner.wait(timeout=timeout)

        monkeypatch.setattr(subprocess, "Popen", TimeoutPopen)
        monkeypatch.setattr(os, "killpg", fake_killpg)

        args = BashArgs(command="echo quick", timeout_sec=1)
        run(args)

        assert any(s == 15 for _, s in sig_calls), \
            f"expected SIGTERM (15) in {sig_calls}"
        assert any(s == 9 for _, s in sig_calls), \
            f"expected SIGKILL (9) in {sig_calls}"
        # Order: TERM before KILL
        idx_term = next(i for i, (_, s) in enumerate(sig_calls) if s == 15)
        idx_kill = next(i for i, (_, s) in enumerate(sig_calls) if s == 9)
        assert idx_term < idx_kill


# ---------------------------------------------------------------------------
# Last-stats consumer hook (used by agent.py for telemetry payload)
# ---------------------------------------------------------------------------

class TestLastStats:
    def test_consume_last_stats_returns_payload(self):
        run(BashArgs(command="echo hi", timeout_sec=5))
        stats = bash_tool.consume_last_stats()
        assert stats is not None
        assert "lines_total" in stats
        assert "exit_code" in stats
        assert "duration_ms" in stats
        assert "ansi_stripped_chars" in stats
        assert "head_kept" in stats
        assert "tail_kept" in stats
        assert stats["exit_code"] == 0
        assert stats["lines_total"] >= 1

    def test_consume_clears_state(self):
        run(BashArgs(command="echo hi", timeout_sec=5))
        bash_tool.consume_last_stats()
        assert bash_tool.consume_last_stats() is None


# ---------------------------------------------------------------------------
# Tool description sanity (model-facing wording is part of the contract).
# ---------------------------------------------------------------------------

class TestToolDescription:
    def test_description_mentions_cwd(self):
        assert "cwd" in bash_tool.tool.description

    def test_description_says_cd_does_not_persist(self):
        # Sharp edge from old description that should remain.
        assert "does NOT persist" in bash_tool.tool.description

    def test_description_no_longer_pushes_absolute_paths_or_chain(self):
        # Old hint replaced by cwd; ensure it's gone.
        assert "absolute paths or chain" not in bash_tool.tool.description
