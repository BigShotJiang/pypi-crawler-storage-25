"""Result-format summaries for web_search / web_fetch."""
from __future__ import annotations

from fred.result_format import format_result


def test_fmt_web_search_with_cost() -> None:
    body = (
        '5 result(s) for: rust async\n'
        "- [1] foo\n  url: https://example.com/foo\n"
        "- [2] bar\n  url: https://example.com/bar\n"
        "- [3] baz\n  url: https://example.com/baz\n"
        "- [4] qux\n  url: https://example.com/qux\n"
        "- [5] quux\n  url: https://example.com/quux\n"
    )
    summary, _ = format_result("web_search", {"query": "rust async"}, body)
    assert "5 results" in summary
    assert '"rust async"' in summary
    assert "$0.020" in summary


def test_fmt_web_search_advanced() -> None:
    body = "1 result(s) for: x\n- [1] r\n  url: https://e/\n"
    summary, _ = format_result(
        "web_search",
        {"query": "x", "search_depth": "advanced"},
        body,
    )
    assert "$0.040" in summary


def test_fmt_web_search_error() -> None:
    body = "Error: web research is disabled. Enable at https://x/"
    summary, preview = format_result(
        "web_search", {"query": "x"}, body,
    )
    assert summary.startswith("Error: web research is disabled")
    assert preview == body


def test_fmt_web_fetch_extracted_count() -> None:
    body = "[ok 2/3 URLs]\n--- [1] https://a/ ---\nfoo\n"
    urls = ["https://a/", "https://b/", "https://c/"]
    summary, _ = format_result("web_fetch", {"urls": urls}, body)
    assert "2/3 URLs extracted" in summary
    # 3 urls basic: ceil(3/5)=1 batch × $0.020
    assert "$0.020" in summary


def test_fmt_web_fetch_advanced_six_urls() -> None:
    body = "[ok 6/6 URLs]\n"
    urls = [f"https://e/{i}" for i in range(6)]
    summary, _ = format_result(
        "web_fetch",
        {"urls": urls, "extract_depth": "advanced"},
        body,
    )
    # 6 urls, advanced: ceil(6/5)=2 batches × $0.040 = $0.080
    assert "$0.080" in summary


def test_fmt_web_fetch_error() -> None:
    body = "Error: out of credits. Top up at https://x/"
    summary, _ = format_result(
        "web_fetch", {"urls": ["https://e/"]}, body,
    )
    assert summary.startswith("Error: out of credits")
