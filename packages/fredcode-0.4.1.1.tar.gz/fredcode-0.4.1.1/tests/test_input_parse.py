"""Tests for @path mention expansion and !cmd shell expansion."""
from __future__ import annotations

from fred.input_parse import _MAX_EMBED, count_mentions, expand_bang, expand_mentions


class TestExpandMentions:
    def test_existing_file_is_embedded(self, tmp_path):
        f = tmp_path / "hello.py"
        f.write_text("print('hi')\n")
        out = expand_mentions(f"please read @{f} and explain")
        assert "<file path=" in out
        assert "```py" in out
        assert "print('hi')" in out
        assert "</file>" in out
        # Surrounding text is preserved.
        assert "please read" in out and "and explain" in out

    def test_truncates_large_files(self, tmp_path):
        f = tmp_path / "big.txt"
        f.write_text("x" * (_MAX_EMBED + 500))
        out = expand_mentions(f"@{f}")
        assert "[truncated]" in out
        assert out.count("x") <= _MAX_EMBED + 50  # some slack for the marker

    def test_nonexistent_path_left_untouched(self):
        out = expand_mentions("see @/nope/this/does/not/exist")
        assert out == "see @/nope/this/does/not/exist"

    def test_mid_word_not_a_mention(self):
        out = expand_mentions("email me at user@example.com please")
        assert "<file path=" not in out
        assert out == "email me at user@example.com please"

    def test_multiple_mentions_all_expand(self, tmp_path):
        a = tmp_path / "a.txt"
        a.write_text("AAA")
        b = tmp_path / "b.txt"
        b.write_text("BBB")
        out = expand_mentions(f"compare @{a} with @{b}")
        assert out.count("<file path=") == 2
        assert "AAA" in out
        assert "BBB" in out

    def test_extension_used_as_fence_lang(self, tmp_path):
        f = tmp_path / "module.rs"
        f.write_text("fn main() {}\n")
        out = expand_mentions(f"@{f}")
        assert "```rs" in out

    def test_extensionless_file_uses_empty_fence(self, tmp_path):
        f = tmp_path / "Makefile"
        f.write_text("all:\n\techo hi\n")
        out = expand_mentions(f"@{f}")
        # Empty extension produces a bare ``` fence.
        assert "```\n" in out

    def test_directory_path_left_untouched(self, tmp_path):
        # @path resolves to a directory, not a file → unchanged.
        out = expand_mentions(f"check @{tmp_path}")
        assert out == f"check @{tmp_path}"


class TestExpandBang:
    def test_non_bang_returns_unchanged(self):
        out, raw, rc = expand_bang("just a question")
        assert out == "just a question"
        assert raw is None
        assert rc is None

    def test_simple_command_captures_stdout(self):
        out, raw, rc = expand_bang("!echo hello-bang")
        assert raw == "echo hello-bang"
        assert rc == 0
        assert "<shell cmd=\"echo hello-bang\"" in out
        assert 'exit="0"' in out
        assert "hello-bang" in out
        assert "</shell>" in out

    def test_failing_command_records_nonzero_exit(self):
        out, raw, rc = expand_bang("!false")
        assert raw == "false"
        assert rc == 1
        assert 'exit="1"' in out

    def test_truncates_long_output(self):
        # awk is universally available and lets us emit a bounded
        # number of bytes without spawning a python interpreter.
        out, _, rc = expand_bang(
            f"!awk 'BEGIN{{for(i=0;i<{_MAX_EMBED + 500};i++)printf \"y\"}}'"
        )
        assert "[truncated]" in out
        assert rc == 0

    def test_strips_leading_whitespace(self):
        # `!  cmd` should still treat the rest as the command.
        out, raw, _ = expand_bang("!  echo trimmed")
        assert raw == "echo trimmed"
        assert "trimmed" in out


class TestCountMentions:
    def test_zero_when_no_at_sign(self):
        assert count_mentions("plain text") == 0

    def test_zero_when_path_does_not_exist(self):
        assert count_mentions("see @/nope/missing/path") == 0

    def test_counts_existing_files(self, tmp_path):
        a = tmp_path / "a.txt"
        a.write_text("a")
        b = tmp_path / "b.txt"
        b.write_text("b")
        assert count_mentions(f"compare @{a} and @{b}") == 2

    def test_skips_email_addresses(self):
        assert count_mentions("user@example.com") == 0

    def test_skips_directory_paths(self, tmp_path):
        assert count_mentions(f"check @{tmp_path}") == 0
