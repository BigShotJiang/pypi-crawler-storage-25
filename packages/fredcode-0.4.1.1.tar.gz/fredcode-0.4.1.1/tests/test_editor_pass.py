"""editor_pass — architect/editor split for file-edit tool_calls.

Covers:
  - bypass conditions (non-allowlisted tool, models match)
  - successful repair (editor returns a different `arguments` dict)
  - exception swallowing (editor errors do not propagate)
  - per-iteration safety cap signaled via `editor_skipped` event
"""
from __future__ import annotations

import io
from unittest.mock import MagicMock

from rich.console import Console

from fred.client import DSClient, StreamResult, ToolCall
from fred.config import ModelConfig
from fred.editor_pass import (
    EDITOR_REVIEWED_TOOLS,
    maybe_editor_repair,
)
from fred.render import Renderer
from fred.telemetry import NullTracer
from fred.tools.registry import default_registry


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


class _CapturingTracer(NullTracer):
    def __init__(self):
        self.events: list[tuple[str, dict | None]] = []

    def event(self, kind, *, payload=None, turn=None):
        self.events.append((kind, payload))


def _cfg(main="deepseek-v4-pro", editor="deepseek-v4-flash"):
    return ModelConfig(
        main_model=main,
        editor_model=editor,
        weak_model="deepseek-v4-flash",
        subagent_main_model="deepseek-v4-flash",
    )


def _bash_tc() -> ToolCall:
    return ToolCall(
        id="c1",
        name="bash",
        arguments={"command": "ls"},
        raw_arguments='{"command":"ls"}',
        parse_error=None,
    )


def _create_file_tc() -> ToolCall:
    return ToolCall(
        id="c2",
        name="create_file",
        arguments={"path": "/tmp/x.txt", "content": "hi"},
        raw_arguments='{"path":"/tmp/x.txt","content":"hi"}',
        parse_error=None,
    )


def test_bypass_for_non_reviewed_tool():
    """`bash` is not in the allowlist — pass-through unchanged, no events,
    no editor model invocation."""
    client = DSClient(api_key="test", model="deepseek-v4-pro")
    tracer = _CapturingTracer()
    tc = _bash_tc()

    out = maybe_editor_repair(
        tc,
        client=client,
        model_cfg=_cfg(),
        registry=default_registry(),
        user_message="hi",
        architect_text="run it",
        architect_reasoning="",
        tracer=tracer,
        turn=0,
        renderer=Renderer(console=_silent_console(), stream=False),
    )
    assert out is tc
    assert tracer.events == []


def test_bypass_when_editor_model_equals_main():
    """When the slot collapses (editor == main) and architect_flag=False,
    skip the pass — no extra spend on a useless second call."""
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    tracer = _CapturingTracer()
    tc = _create_file_tc()

    out = maybe_editor_repair(
        tc,
        client=client,
        model_cfg=_cfg(main="deepseek-v4-flash", editor="deepseek-v4-flash"),
        registry=default_registry(),
        user_message="please",
        architect_text="creating",
        architect_reasoning="",
        tracer=tracer,
        turn=0,
        renderer=Renderer(console=_silent_console(), stream=False),
        architect_flag=False,
    )
    assert out is tc
    assert tracer.events == []


def test_repair_replaces_arguments_preserves_id_and_name():
    """When the editor model emits a different arguments dict, the
    returned ToolCall carries the new args but the original `id` and
    `name` so the wire-level tool_call_id stays consistent."""
    client = DSClient(api_key="test", model="deepseek-v4-pro")
    tc = _create_file_tc()
    repaired = ToolCall(
        id="ignored",
        name="create_file",
        arguments={"path": "/tmp/x.txt", "content": "hi (fixed)"},
        raw_arguments='{"path":"/tmp/x.txt","content":"hi (fixed)"}',
        parse_error=None,
    )
    fake_result = StreamResult(
        text="", tool_calls=[repaired], finish_reason="tool_calls",
        usage={"prompt_tokens": 5, "completion_tokens": 5},
    )

    twin = MagicMock()
    twin.stream_chat.return_value = MagicMock(
        __iter__=lambda self: iter([]),
        result=lambda: fake_result,
    )
    client.with_model = MagicMock(return_value=twin)

    tracer = _CapturingTracer()
    out = maybe_editor_repair(
        tc,
        client=client,
        model_cfg=_cfg(),
        registry=default_registry(),
        user_message="please write hi (fixed)",
        architect_text="creating",
        architect_reasoning="",
        tracer=tracer,
        turn=0,
        renderer=Renderer(console=_silent_console(), stream=False),
    )
    assert out.id == "c2"
    assert out.name == "create_file"
    assert out.arguments["content"] == "hi (fixed)"
    # Both events fire: model_routed (slot=editor, reason=repair) and editor_repair.
    kinds = [k for k, _ in tracer.events]
    assert "model_routed" in kinds
    assert "editor_repair" in kinds
    repair_payload = next(p for k, p in tracer.events if k == "editor_repair")
    assert repair_payload["outcome"] == "changed"
    assert "content" in repair_payload["changed_keys"]


def test_exception_returns_original_and_emits_error_event():
    """If the editor's stream_chat raises, the original ToolCall flows
    through and the renderer's one-time failure notice fires."""
    client = DSClient(api_key="test", model="deepseek-v4-pro")
    tc = _create_file_tc()

    twin = MagicMock()
    twin.stream_chat.side_effect = RuntimeError("network down")
    client.with_model = MagicMock(return_value=twin)

    tracer = _CapturingTracer()
    renderer = Renderer(console=_silent_console(), stream=False)
    out = maybe_editor_repair(
        tc,
        client=client,
        model_cfg=_cfg(),
        registry=default_registry(),
        user_message="please",
        architect_text="creating",
        architect_reasoning="",
        tracer=tracer,
        turn=0,
        renderer=renderer,
    )
    assert out is tc
    repair_payload = next(p for k, p in tracer.events if k == "editor_repair")
    assert repair_payload["outcome"] == "error"
    assert repair_payload["error_type"] == "RuntimeError"
    # First failure flips the renderer's once-per-session flag.
    assert renderer._editor_failure_notified is True


def test_no_tool_call_returns_original():
    """Editor returns text instead of a tool_call (rare; happens if the
    model decides the architect's call was already correct and ignores
    the schema). We pass through unchanged with `outcome="no_tool_call"`."""
    client = DSClient(api_key="test", model="deepseek-v4-pro")
    tc = _create_file_tc()
    fake_result = StreamResult(
        text="looks fine", tool_calls=[], finish_reason="stop",
        usage={"prompt_tokens": 5, "completion_tokens": 2},
    )
    twin = MagicMock()
    twin.stream_chat.return_value = MagicMock(
        __iter__=lambda self: iter([]),
        result=lambda: fake_result,
    )
    client.with_model = MagicMock(return_value=twin)

    tracer = _CapturingTracer()
    out = maybe_editor_repair(
        tc,
        client=client,
        model_cfg=_cfg(),
        registry=default_registry(),
        user_message="x",
        architect_text="creating",
        architect_reasoning="",
        tracer=tracer,
        turn=0,
        renderer=Renderer(console=_silent_console(), stream=False),
    )
    assert out is tc
    repair_payload = next(p for k, p in tracer.events if k == "editor_repair")
    assert repair_payload["outcome"] == "no_tool_call"


def test_allowlist_contents():
    """Document the canonical set so future changes to file-edit
    tools surface in code review."""
    assert EDITOR_REVIEWED_TOOLS == frozenset({"str_replace", "create_file"})
