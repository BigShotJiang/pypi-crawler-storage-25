"""Tests for fred.update_check — PyPI poll, cache, install detection, fred update."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from datetime import datetime, timedelta, timezone
from io import StringIO
from pathlib import Path
from unittest.mock import patch

import httpx
import pytest
import respx
from rich.console import Console

from fred import update_check


@pytest.fixture(autouse=True)
def _isolate_update_cache(tmp_path, monkeypatch):
    """Each test gets a fresh CACHE_PATH and a clean env. Reset the
    module-level Event so kickoff() actually fires across tests."""
    fake = tmp_path / "fred" / "update-check.json"
    monkeypatch.setattr(update_check, "CACHE_PATH", fake)
    monkeypatch.delenv("FRED_NO_UPDATE_CHECK", raising=False)
    monkeypatch.delenv("CI", raising=False)
    monkeypatch.delenv("NO_COLOR", raising=False)
    update_check._thread_started.clear()
    yield
    update_check._thread_started.clear()


# ---------- detect_install_method ------------------------------------------


def _make_dist_stub(*, direct_url=None, installer=None):
    class _Dist:
        def read_text(self, name):
            if name == "direct_url.json":
                return direct_url
            if name == "INSTALLER":
                return installer
            return None
    return _Dist()


def test_detect_dev_install(monkeypatch):
    durl = json.dumps({"dir_info": {"editable": True}})
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(direct_url=durl, installer="pip"),
    )
    assert update_check.detect_install_method() == "dev"


def test_detect_pip_when_direct_url_not_editable(monkeypatch):
    durl = json.dumps({"url": "https://files.pythonhosted.org/.../whl"})
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(direct_url=durl, installer="pip"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/.venv")
    assert update_check.detect_install_method() == "pip"


def test_detect_pipx(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pipx"),
    )
    assert update_check.detect_install_method() == "pipx"


def test_detect_uv_pip(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="uv"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/project/.venv")
    assert update_check.detect_install_method() == "uv"


def test_detect_uv_tool(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="uv"),
    )
    monkeypatch.setattr(
        sys, "prefix", "/Users/me/.local/share/uv/tools/fredcode"
    )
    assert update_check.detect_install_method() == "uv-tool"


def test_detect_brew_apple_silicon(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(
        sys, "prefix", "/opt/homebrew/Cellar/fredcode/0.2.0/libexec"
    )
    assert update_check.detect_install_method() == "brew"


def test_detect_brew_intel(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(
        sys, "prefix", "/usr/local/Cellar/fredcode/0.2.0/libexec"
    )
    assert update_check.detect_install_method() == "brew"


def test_detect_unknown_when_package_missing(monkeypatch):
    from importlib.metadata import PackageNotFoundError

    def _raise(name):
        raise PackageNotFoundError(name)

    monkeypatch.setattr("importlib.metadata.distribution", _raise)
    assert update_check.detect_install_method() == "unknown"


# ---------- upgrade_command ------------------------------------------------


def test_upgrade_command_pip():
    cmd = update_check.upgrade_command("pip")
    assert cmd == [sys.executable, "-m", "pip", "install", "--upgrade", "fredcode"]


def test_upgrade_command_pipx():
    assert update_check.upgrade_command("pipx") == ["pipx", "upgrade", "fredcode"]


def test_upgrade_command_uv_pip():
    assert update_check.upgrade_command("uv") == [
        "uv", "pip", "install", "--upgrade", "fredcode"
    ]


def test_upgrade_command_uv_tool():
    assert update_check.upgrade_command("uv-tool") == [
        "uv", "tool", "upgrade", "fredcode"
    ]


def test_upgrade_command_returns_none_for_brew_dev_unknown():
    assert update_check.upgrade_command("brew") is None
    assert update_check.upgrade_command("dev") is None
    assert update_check.upgrade_command("unknown") is None


# ---------- _is_newer (PEP 440) --------------------------------------------


@pytest.mark.parametrize("latest,current,expected", [
    ("0.3.0", "0.2.0", True),
    ("0.2.0", "0.2.0", False),
    ("0.2.0", "0.3.0", False),
    ("1.2.0", "1.2.0rc1", True),    # final > rc
    ("1.2.0rc1", "1.2.0", False),   # rc < final
    ("1.2.3.post1", "1.2.3", True), # post > release
    ("2.0.0.dev1", "1.9.9", True),  # dev > older release
    ("not-a-version", "1.0.0", False),  # graceful fallthrough
    ("1.0.0", "not-a-version", False),  # graceful fallthrough
])
def test_is_newer_pep440(latest, current, expected):
    assert update_check._is_newer(latest, current) is expected


# ---------- cache roundtrip ------------------------------------------------


def test_save_and_load_cache_roundtrip():
    update_check._save_cache("0.99.0")
    cache = update_check._load_cache()
    assert cache is not None
    assert cache["version"] == 1
    assert cache["latest"] == "0.99.0"
    assert cache["current_at_fetch"] == update_check.__version__
    assert "fetched_at" in cache


def test_load_cache_missing_returns_none():
    assert update_check._load_cache() is None


def test_load_cache_malformed_json_returns_none():
    update_check.CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    update_check.CACHE_PATH.write_text("{not json", encoding="utf-8")
    assert update_check._load_cache() is None


def test_age_seconds_within_ttl():
    iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    age = update_check._age_seconds(iso)
    assert age is not None
    assert age < 5  # well within TTL


def test_age_seconds_beyond_ttl():
    past = datetime.now(timezone.utc) - timedelta(days=2)
    iso = past.strftime("%Y-%m-%dT%H:%M:%SZ")
    age = update_check._age_seconds(iso)
    assert age is not None
    assert age > update_check.CACHE_TTL_S


def test_age_seconds_garbage_returns_none():
    assert update_check._age_seconds("not-a-date") is None
    assert update_check._age_seconds("") is None


# ---------- _fetch_latest_pypi (mocked httpx) ------------------------------


@respx.mock
def test_fetch_pypi_200_returns_version():
    respx.get(update_check.PYPI_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "1.2.3"}})
    )
    assert update_check._fetch_latest_pypi() == "1.2.3"


@respx.mock
def test_fetch_pypi_503_returns_none():
    respx.get(update_check.PYPI_URL).mock(return_value=httpx.Response(503))
    assert update_check._fetch_latest_pypi() is None


@respx.mock
def test_fetch_pypi_timeout_returns_none():
    respx.get(update_check.PYPI_URL).mock(
        side_effect=httpx.TimeoutException("slow")
    )
    assert update_check._fetch_latest_pypi() is None


@respx.mock
def test_fetch_pypi_connect_error_returns_none():
    respx.get(update_check.PYPI_URL).mock(
        side_effect=httpx.ConnectError("dns")
    )
    assert update_check._fetch_latest_pypi() is None


# ---------- kickoff non-blocking -------------------------------------------


@respx.mock
def test_kickoff_returns_immediately_even_with_slow_pypi(monkeypatch):
    # Ensure not-suppressed
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/.venv")

    started = threading.Event()
    finished = threading.Event()

    def _slow_handler(_request):
        started.set()
        time.sleep(0.5)
        finished.set()
        return httpx.Response(200, json={"info": {"version": "9.9.9"}})

    respx.get(update_check.PYPI_URL).mock(side_effect=_slow_handler)

    t0 = time.perf_counter()
    update_check.kickoff()
    elapsed = time.perf_counter() - t0
    assert elapsed < 0.1, f"kickoff blocked for {elapsed:.3f}s"
    # Daemon thread should still be running.
    assert started.wait(timeout=1.0) or finished.is_set()


def test_kickoff_idempotent(monkeypatch):
    """Calling kickoff twice in a process spawns at most one thread."""
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/.venv")
    counts = []
    real_thread = threading.Thread

    def _counting_thread(*a, **kw):
        counts.append(1)
        return real_thread(*a, **kw)

    monkeypatch.setattr("fred.update_check.threading.Thread", _counting_thread)
    update_check.kickoff()
    update_check.kickoff()
    update_check.kickoff()
    assert len(counts) == 1


def test_kickoff_suppressed_when_FRED_NO_UPDATE_CHECK(monkeypatch):
    monkeypatch.setenv("FRED_NO_UPDATE_CHECK", "1")
    counts = []
    monkeypatch.setattr(
        "fred.update_check.threading.Thread",
        lambda *a, **k: counts.append(1) or threading.Thread(*a, **k),
    )
    update_check.kickoff()
    assert counts == []


def test_kickoff_suppressed_in_CI(monkeypatch):
    monkeypatch.setenv("CI", "true")
    counts = []
    monkeypatch.setattr(
        "fred.update_check.threading.Thread",
        lambda *a, **k: counts.append(1) or threading.Thread(*a, **k),
    )
    update_check.kickoff()
    assert counts == []


def test_kickoff_suppressed_for_dev_install(monkeypatch):
    durl = json.dumps({"dir_info": {"editable": True}})
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(direct_url=durl, installer="pip"),
    )
    counts = []
    monkeypatch.setattr(
        "fred.update_check.threading.Thread",
        lambda *a, **k: counts.append(1) or threading.Thread(*a, **k),
    )
    update_check.kickoff()
    assert counts == []


# ---------- maybe_print_notice ---------------------------------------------


def _make_console_with_buffer():
    buf = StringIO()
    # highlight=False stops Rich from splitting "99.0.0" across ANSI
    # escapes (number highlighter), which would defeat substring asserts.
    return Console(
        file=buf, force_terminal=False, no_color=True,
        highlight=False, width=200,
    ), buf


def _write_cache(latest: str, *, age_s: int = 60, current_at_fetch=None):
    """Helper: write a cache file with a controllable timestamp."""
    if current_at_fetch is None:
        current_at_fetch = update_check.__version__
    fetched_at = (
        datetime.now(timezone.utc) - timedelta(seconds=age_s)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")
    update_check.CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    update_check.CACHE_PATH.write_text(
        json.dumps({
            "version": 1,
            "latest": latest,
            "fetched_at": fetched_at,
            "current_at_fetch": current_at_fetch,
        }),
        encoding="utf-8",
    )


def test_notice_prints_when_cache_says_newer(monkeypatch):
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/.venv")
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache("99.0.0")

    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    output = buf.getvalue()
    assert "99.0.0" in output
    assert "fredcode" in output


def test_notice_silent_when_cache_says_same_version(monkeypatch):
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache(update_check.__version__)
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_cache_missing(monkeypatch):
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_NO_COLOR_set(monkeypatch):
    monkeypatch.setenv("NO_COLOR", "1")
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache("99.0.0")
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_FRED_NO_UPDATE_CHECK_set(monkeypatch):
    monkeypatch.setenv("FRED_NO_UPDATE_CHECK", "1")
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache("99.0.0")
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_not_tty(monkeypatch):
    monkeypatch.setattr("sys.stdout.isatty", lambda: False)
    _write_cache("99.0.0")
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_dev_install(monkeypatch):
    durl = json.dumps({"dir_info": {"editable": True}})
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(direct_url=durl, installer="pip"),
    )
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache("99.0.0")
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


def test_notice_silent_when_user_already_upgraded(monkeypatch):
    """Cache was written when user was on 0.0.1; they've since upgraded
    to whatever __version__ is. Stale cache must not falsely promote."""
    monkeypatch.setattr(
        "importlib.metadata.distribution",
        lambda name: _make_dist_stub(installer="pip"),
    )
    monkeypatch.setattr(sys, "prefix", "/Users/me/.venv")
    monkeypatch.setattr("sys.stdout.isatty", lambda: True)
    _write_cache("99.0.0", current_at_fetch="0.0.1")
    console, buf = _make_console_with_buffer()
    update_check.maybe_print_notice(console)
    assert buf.getvalue() == ""


# ---------- prompt_and_run_upgrade -----------------------------------------


def test_prompt_no_run_just_prints(monkeypatch):
    captured = []
    monkeypatch.setattr(
        os, "execvp",
        lambda *a: captured.append(a),
    )
    console, buf = _make_console_with_buffer()
    rc = update_check.prompt_and_run_upgrade(
        "pip", "99.0.0", assume_yes=False, no_run=True, console=console
    )
    assert rc == 0
    assert captured == []  # never exec'd
    assert "Will run" in buf.getvalue()


def test_prompt_yes_execs(monkeypatch):
    captured = []
    monkeypatch.setattr(
        os, "execvp",
        lambda *a: captured.append(a),
    )
    console, _ = _make_console_with_buffer()
    update_check.prompt_and_run_upgrade(
        "pip", "99.0.0", assume_yes=True, no_run=False, console=console
    )
    assert len(captured) == 1
    cmd_path, argv = captured[0]
    assert cmd_path == sys.executable
    assert argv == [sys.executable, "-m", "pip", "install", "--upgrade", "fredcode"]


def test_prompt_pipx_uses_pipx_argv(monkeypatch):
    captured = []
    monkeypatch.setattr(
        os, "execvp",
        lambda *a: captured.append(a),
    )
    console, _ = _make_console_with_buffer()
    update_check.prompt_and_run_upgrade(
        "pipx", "99.0.0", assume_yes=True, no_run=False, console=console
    )
    assert captured[0] == ("pipx", ["pipx", "upgrade", "fredcode"])


def test_prompt_dev_install_no_exec(monkeypatch):
    captured = []
    monkeypatch.setattr(os, "execvp", lambda *a: captured.append(a))
    console, buf = _make_console_with_buffer()
    rc = update_check.prompt_and_run_upgrade(
        "dev", None, assume_yes=True, no_run=False, console=console
    )
    assert rc == 1
    assert captured == []
    assert "dev install" in buf.getvalue()


def test_prompt_brew_no_exec_explains(monkeypatch):
    captured = []
    monkeypatch.setattr(os, "execvp", lambda *a: captured.append(a))
    console, buf = _make_console_with_buffer()
    rc = update_check.prompt_and_run_upgrade(
        "brew", "99.0.0", assume_yes=True, no_run=False, console=console
    )
    assert rc == 1
    assert captured == []
    assert "Homebrew" in buf.getvalue()


def test_prompt_already_up_to_date_returns_zero(monkeypatch):
    captured = []
    monkeypatch.setattr(os, "execvp", lambda *a: captured.append(a))
    console, buf = _make_console_with_buffer()
    rc = update_check.prompt_and_run_upgrade(
        "pip",
        update_check.__version__,
        assume_yes=True,
        no_run=False,
        console=console,
    )
    assert rc == 0
    assert captured == []
    assert "already up to date" in buf.getvalue()


def test_prompt_decline_does_not_exec(monkeypatch):
    """User answers 'n' at the prompt → no exec, exit 1."""
    captured = []
    monkeypatch.setattr(os, "execvp", lambda *a: captured.append(a))
    monkeypatch.setattr(Console, "input", lambda self, prompt="": "n")
    console, buf = _make_console_with_buffer()
    rc = update_check.prompt_and_run_upgrade(
        "pip", "99.0.0", assume_yes=False, no_run=False, console=console
    )
    assert rc == 1
    assert captured == []
    assert "aborted" in buf.getvalue()


def test_prompt_y_at_prompt_execs(monkeypatch):
    captured = []
    monkeypatch.setattr(os, "execvp", lambda *a: captured.append(a))
    monkeypatch.setattr(Console, "input", lambda self, prompt="": "y")
    console, _ = _make_console_with_buffer()
    update_check.prompt_and_run_upgrade(
        "pip", "99.0.0", assume_yes=False, no_run=False, console=console
    )
    assert len(captured) == 1


# ---------- fetch_latest (uses cache) --------------------------------------


@respx.mock
def test_fetch_latest_uses_fresh_cache(monkeypatch):
    _write_cache("0.5.0", age_s=60)
    # Don't mock PyPI — ensure we never hit it.
    rt = respx.get(update_check.PYPI_URL).mock(
        return_value=httpx.Response(500)
    )
    result = update_check.fetch_latest()
    assert result == "0.5.0"
    assert rt.call_count == 0


@respx.mock
def test_fetch_latest_force_ignores_cache():
    _write_cache("0.5.0", age_s=60)
    respx.get(update_check.PYPI_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "0.7.0"}})
    )
    assert update_check.fetch_latest(force=True) == "0.7.0"


@respx.mock
def test_fetch_latest_stale_cache_falls_through_to_network():
    _write_cache("0.5.0", age_s=update_check.CACHE_TTL_S + 100)
    respx.get(update_check.PYPI_URL).mock(
        return_value=httpx.Response(200, json={"info": {"version": "0.7.0"}})
    )
    assert update_check.fetch_latest() == "0.7.0"


# ---------- truststore ordering regression --------------------------------


def test_truststore_injected_before_update_check_import():
    """Regression guard: importing fred must inject truststore BEFORE
    update_check ever runs in a daemon thread that uses httpx.
    truststore.inject_into_ssl() patches ssl.SSLContext (not
    create_default_context). If a future refactor moves _inject_ssl()
    out of fred/__init__.py, this fires loudly here instead of producing
    mysterious cert failures in production daemon threads."""
    import ssl
    # `import fred` ran when this test module was imported (via `from fred
    # import update_check` at the top of the file).
    assert "truststore" in ssl.SSLContext.__module__
