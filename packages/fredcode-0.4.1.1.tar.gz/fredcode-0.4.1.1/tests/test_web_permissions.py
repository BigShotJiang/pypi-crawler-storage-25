"""Permission Panel summary lines for web_search/web_fetch include cost."""
from __future__ import annotations

from fred.permissions import _summary_for


def test_web_search_panel_summary_shows_cost_basic() -> None:
    text = _summary_for("web_search", {"query": "rust async runtime"})
    plain = text.plain
    assert "rust async runtime" in plain
    assert "$0.020" in plain
    assert "(basic)" in plain


def test_web_search_panel_summary_advanced_doubles_cost() -> None:
    text = _summary_for(
        "web_search",
        {"query": "x", "search_depth": "advanced"},
    )
    plain = text.plain
    assert "$0.040" in plain
    assert "(advanced)" in plain


def test_web_fetch_panel_summary_six_urls_basic() -> None:
    urls = [f"https://docs.example/{i}" for i in range(6)]
    text = _summary_for("web_fetch", {"urls": urls})
    plain = text.plain
    assert "6 URLs" in plain
    # 6 urls, basic: ceil(6/5) = 2 batches × $0.020 = $0.040
    assert "$0.040" in plain


def test_web_fetch_panel_summary_truncates_url_list() -> None:
    urls = [f"https://e/{i}" for i in range(8)]
    text = _summary_for("web_fetch", {"urls": urls})
    plain = text.plain
    assert "+3 more" in plain  # 8 total, first 5 shown, +3 more
