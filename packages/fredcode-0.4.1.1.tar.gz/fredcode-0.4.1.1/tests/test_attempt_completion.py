"""PR-B2 attempt_completion tests.

Covers:
- act-mode happy path: tool fires, loop breaks, completion panel renders.
- plan-mode rejection via mode allowlist.
- empty / whitespace-only result rejection.
- multi-call ordering: tools BEFORE attempt_completion run; AFTER are dropped.
- terminator_kind tagging on the iteration row when known at end_iteration time.
- subagent happy path: parent receives the result string verbatim.

Streaming mocks mirror tests/test_session.py and tests/test_subagent.py
(SimpleNamespace-driven fakes, not respx — we're testing the agent loop).
"""
from __future__ import annotations

import io
import json
from types import SimpleNamespace

import pytest
from rich.console import Console

from fred.client import DSClient
from fred.permissions import PermissionPolicy
from fred.render import Renderer
from fred.session import run_session
from fred.tools.attempt_completion import (
    AttemptCompletionArgs,
    run as attempt_completion_run,
)
from fred.tools.registry import default_registry


# ---------- streaming-mock plumbing (mirrors test_session.py) -------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(
        content=content, tool_calls=tool_calls, reasoning_content=None,
    )
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = None
    if usage is not None:
        usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = (
        SimpleNamespace(name=name, arguments=args)
        if (name or args is not None) else None
    )
    return SimpleNamespace(index=index, id=id, function=fn)


def _make_client(scripted_streams):
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(scripted_streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


def _attempt_completion_stream(call_id: str, result: str):
    """Build a one-iteration stream where the model emits ONE tool call:
    attempt_completion(result=...).
    """
    args = json.dumps({"result": result})
    return iter([
        _delta_chunk(tool_calls=[_tc_delta(0, id=call_id, name="attempt_completion")]),
        _delta_chunk(
            tool_calls=[_tc_delta(0, args=args)],
            finish_reason="tool_calls",
        ),
        _final_usage_chunk({"prompt_tokens": 12, "completion_tokens": 4}),
    ])


# ---------- handler-level rejection (no session needed) -------------------


class TestHandlerValidation:
    def test_empty_result_rejected_by_pydantic(self):
        with pytest.raises(Exception):
            AttemptCompletionArgs(result="")

    def test_whitespace_only_returns_error_string(self):
        # Pydantic accepts whitespace (min_length=1); the handler catches it.
        args = AttemptCompletionArgs(result="   \n  ")
        out = attempt_completion_run(args)
        assert out.startswith("Error:")
        assert "non-empty" in out

    def test_max_length_enforced(self):
        with pytest.raises(Exception):
            AttemptCompletionArgs(result="x" * 8001)

    def test_normal_result_returned_verbatim(self):
        args = AttemptCompletionArgs(result="all done — three files updated.")
        assert attempt_completion_run(args) == "all done — three files updated."


# ---------- session-level: act-mode happy path ----------------------------


class TestActModeHappyPath:
    def test_loop_breaks_and_final_text_set(self):
        stream = _attempt_completion_stream("call_1", "Renamed `foo` to `bar`.")
        client = _make_client([stream])
        registry = default_registry()
        console, out = _captured_console()
        renderer = Renderer(console=console, stream=False, headless=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [
                {"role": "system", "content": "sys"},
                {"role": "user", "content": "rename foo"},
            ],
            client, registry,
            permissions=permissions,
            max_iters=5,
            renderer=renderer,
        )

        assert result.final_text == "Renamed `foo` to `bar`."
        assert result.finish_reason == "attempt_completion"
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0].name == "attempt_completion"

    def test_completion_panel_renders(self):
        # Plain prose so terminal-width clipping can't hide it.
        stream = _attempt_completion_stream("call_1", "Renamed foo to bar.")
        client = _make_client([stream])
        # Wide console so the panel body doesn't get truncated horizontally.
        wide_console = Console(
            file=io.StringIO(), force_terminal=False, width=200,
            color_system=None,
        )
        renderer = Renderer(console=wide_console, stream=False, headless=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "go"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, max_iters=5,
        )

        rendered = wide_console.file.getvalue()
        # Panel title contains the "done" marker.
        assert "done" in rendered
        # The result body lands in the panel.
        assert "Renamed foo to bar." in rendered

    def test_generic_tool_panel_suppressed(self):
        # tool_done() must skip the generic tool-result Panel for
        # attempt_completion (mirror agent tool skip). The recent_results
        # entry should still be recorded as a "done" marker.
        stream = _attempt_completion_stream("call_1", "x")
        client = _make_client([stream])
        renderer = Renderer(console=_silent_console(), stream=False, headless=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "go"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, max_iters=5,
        )

        # recent_results gets one entry tagged as a completion.
        kinds = [t for t, _ in renderer.recent_results]
        assert "done" in kinds
        # No tool-result panel was rendered for attempt_completion (no
        # entry whose title contains "attempt_completion ·").
        assert not any(
            isinstance(t, str) and "attempt_completion ·" in t
            for t, _ in renderer.recent_results
        )


# ---------- plan-mode rejection -------------------------------------------


class TestPlanModeRejection:
    def test_plan_mode_blocks_attempt_completion(self):
        # Iteration 1: model erroneously calls attempt_completion in plan
        # mode. The dispatch returns a mode_blocked error string; the loop
        # continues. Iteration 2: model corrects with exit_plan_mode.
        stream1 = _attempt_completion_stream("call_1", "should be blocked")
        # Iteration 2: exit_plan_mode → flips to act → natural stop.
        # We stop after iter 1 with iter cap to keep the assertion narrow.
        client = _make_client([stream1])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "plan"}],
            client, registry,
            permissions=permissions, mode="plan",
            renderer=renderer, max_iters=1,
        )

        # The tool message reflects mode_blocked; final_text NOT set to
        # the would-be result (the loop didn't break on attempt_completion).
        tool_msgs = [m for m in result.messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 1
        # mode_blocked_message names the tool by name.
        assert "attempt_completion" in tool_msgs[0]["content"]
        # finish_reason not set to attempt_completion (loop didn't break).
        assert result.finish_reason != "attempt_completion"


# ---------- multi-call ordering -------------------------------------------


class TestMultiCallOrdering:
    def test_tools_before_attempt_completion_run(self, tmp_path):
        target = tmp_path / "hello.txt"
        target.write_text("hi\n")

        # One iteration emits TWO tool calls: view, then attempt_completion.
        # Both should run; loop breaks after attempt_completion.
        args1 = json.dumps({"path": str(target)})
        args2 = json.dumps({"result": "Read the file."})
        stream = iter([
            _delta_chunk(tool_calls=[
                _tc_delta(0, id="call_v", name="view"),
                _tc_delta(1, id="call_a", name="attempt_completion"),
            ]),
            _delta_chunk(
                tool_calls=[
                    _tc_delta(0, args=args1),
                    _tc_delta(1, args=args2),
                ],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 20, "completion_tokens": 6}),
        ])
        client = _make_client([stream])
        registry = default_registry()
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        result = run_session(
            [
                {"role": "system", "content": "s"},
                {"role": "user", "content": "look + finish"},
            ],
            client, registry,
            permissions=permissions, max_iters=5, renderer=renderer,
        )

        assert result.final_text == "Read the file."
        assert result.finish_reason == "attempt_completion"
        # Both tools dispatched in this iteration:
        names = [tc.name for tc in result.tool_calls]
        assert names == ["view", "attempt_completion"]
        # The view tool's result message lands before attempt_completion
        # closes the loop.
        tool_msgs = [m for m in result.messages if m.get("role") == "tool"]
        assert len(tool_msgs) == 2
        assert "hi" in tool_msgs[0]["content"]


# ---------- terminator_kind tagging --------------------------------------


class TestTerminatorKindTelemetry:
    def test_natural_stop_sets_terminator_kind(self, monkeypatch):
        # Capture iteration writes via a stub tracer. The real PgTracer's
        # submit path is exercised in test_telemetry.py; here we just
        # verify the IterationHandle is mutated with the right value
        # before end_iteration is called.
        captured: list[dict] = []

        from fred.telemetry import NullTracer
        original_end = NullTracer.end_iteration

        def capturing_end(self, it, **kwargs):
            captured.append({
                "iteration_index": it.iteration_index,
                "terminator_kind": it.terminator_kind,
            })
            return original_end(self, it, **kwargs)

        monkeypatch.setattr(NullTracer, "end_iteration", capturing_end)

        stream = iter([
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _make_client([stream])
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "x"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, max_iters=5,
        )

        assert any(c["terminator_kind"] == "natural_stop" for c in captured)

    def test_attempt_completion_sets_terminator_kind(self, monkeypatch):
        captured: list[dict] = []

        from fred.telemetry import NullTracer
        original_end = NullTracer.end_iteration

        def capturing_end(self, it, **kwargs):
            captured.append({
                "iteration_index": it.iteration_index,
                "terminator_kind": it.terminator_kind,
            })
            return original_end(self, it, **kwargs)

        monkeypatch.setattr(NullTracer, "end_iteration", capturing_end)

        stream = _attempt_completion_stream("call_1", "all set.")
        client = _make_client([stream])
        renderer = Renderer(console=_silent_console(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=_silent_console())

        run_session(
            [{"role": "system", "content": "s"}, {"role": "user", "content": "go"}],
            client, default_registry(),
            permissions=permissions, renderer=renderer, max_iters=5,
        )

        assert any(
            c["terminator_kind"] == "attempt_completion" for c in captured
        )
