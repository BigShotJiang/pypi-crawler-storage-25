"""Tests for the P2.4 hook system.

Covers:
  - Settings loading (user-level, project-level, override semantics).
  - Matcher language: `Bash(rm -rf *)`, `Edit(*.py)`, comma-separated lists.
  - Subprocess plumbing: exit codes 0 / 2 / other; JSON stdout `updatedInput`;
    timeout enforcement.
  - PreToolUse + PostToolUse dispatch through `run_session`: blocks render
    with hook_blocked outcome; updated_input mutates handler args; multiple
    hooks short-circuit on first exit-2.
  - UserPromptSubmit gating in the REPL path: blocked prompts skip
    `run_turn` and emit a banner.
  - Stop hook: best-effort, swallows failures.
  - Telemetry: `hook_run` events carry exit_code, blocked, hook_stdout_chars
    (count, NOT body).

Hook scripts are written into ``tmp_path`` as standalone shell snippets so
the tests don't depend on any specific OS shell beyond ``/bin/sh``.
"""
from __future__ import annotations

import io
import json
from pathlib import Path
from types import SimpleNamespace

from rich.console import Console

from fred._matchers import (
    _specifier_for,
    match_glob,
    match_tool_pattern,
)
from fred.client import DSClient
from fred.hooks import (
    HookConfig,
    VALID_EVENTS,
    list_hooks_for,
    load_hooks_config,
    run_hooks,
)
from fred.permissions import PermissionPolicy
from fred.render import Renderer
from fred.session import run_session
from fred.tools.registry import default_registry


# ---------- helpers --------------------------------------------------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120, color_system=None)


class _RecordingTracer:
    """Captures `event` calls so tests can assert payloads without mocks."""

    def __init__(self) -> None:
        self.events: list[tuple[str, dict | None]] = []

    def start_session(self, **_): pass
    def end_session(self, **_): pass
    def start_turn(self, *, user_input=None):
        return SimpleNamespace(turn_index=0, user_input=user_input)

    def start_iteration(self, turn, *, iteration_index, context_used_est, budget_status, mode=None, slot="main", model=None):
        return SimpleNamespace(turn_id="", session_id="", turn_index=turn.turn_index,
                               iteration_index=iteration_index)

    def end_iteration(self, *a, **kw): pass
    def record_tool_call(self, *a, **kw): pass
    def event(self, kind, *, payload=None, turn=None):
        self.events.append((kind, payload))
    def drain(self, timeout=2.0): pass


# ---------- matcher language ----------------------------------------------


class TestMatchTools:
    def test_empty_pattern_matches_anything(self):
        assert match_tool_pattern("", "bash", {"command": "ls"}) is True
        assert match_tool_pattern("*", "bash", {}) is True
        assert match_tool_pattern(None, "view", {}) is True

    def test_tool_name_only_case_insensitive(self):
        assert match_tool_pattern("Bash", "bash", {}) is True
        assert match_tool_pattern("bash", "bash", {}) is True
        assert match_tool_pattern("Bash", "view", {}) is False

    def test_bash_command_glob(self):
        ok = match_tool_pattern("Bash(rm -rf *)", "bash", {"command": "rm -rf /tmp/x"})
        assert ok is True
        no = match_tool_pattern("Bash(rm -rf *)", "bash", {"command": "ls -la"})
        assert no is False

    def test_path_specifier_for_view(self):
        assert _specifier_for("view", {"path": "/etc/passwd"}) == "/etc/passwd"
        ok = match_tool_pattern("View(*.py)", "view", {"path": "src/foo.py"})
        assert ok is True

    def test_comma_separated_any_match_wins(self):
        pat = "Bash(rm -rf *), Edit(*.py)"
        assert match_tool_pattern(pat, "bash", {"command": "rm -rf x"}) is True
        # `str_replace` is the internal name for Edit; not matching here is
        # documented behavior — users write "str_replace(...)" directly or
        # match by their own preferred alias. We're just verifying the
        # comma branch doesn't false-block.
        assert match_tool_pattern(pat, "view", {"path": "x.py"}) is False

    def test_match_glob_passthrough(self):
        assert match_glob("*", "anything") is True
        assert match_glob("foo*", "foobar") is True
        assert match_glob("foo*", "bar") is False


# ---------- settings loading ----------------------------------------------


class TestLoadHooksConfig:
    def test_no_settings_returns_empty_per_event(self, tmp_path):
        cfg = load_hooks_config(tmp_path)
        for ev in VALID_EVENTS:
            assert cfg[ev] == []

    def test_project_settings_loaded(self, tmp_path):
        # Make tmp_path look like a project root by dropping a .git so
        # the walker stops here without climbing into the user's home.
        (tmp_path / ".git").mkdir()
        fred_dir = tmp_path / ".fred"
        fred_dir.mkdir()
        (fred_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [
                    {"matcher": "Bash(*)", "command": "echo hi", "timeout": 5},
                ],
            },
        }))
        cfg = load_hooks_config(tmp_path)
        assert len(cfg["PreToolUse"]) == 1
        h = cfg["PreToolUse"][0]
        assert h.matcher == "Bash(*)"
        assert h.command == "echo hi"
        assert h.timeout == 5

    def test_project_overrides_user_per_event(self, tmp_path, monkeypatch):
        # Stub HOME so the user-level layer points at a tmp_path.
        fake_home = tmp_path / "home"
        fake_home.mkdir()
        monkeypatch.setenv("HOME", str(fake_home))

        user_dir = fake_home / ".fred"
        user_dir.mkdir()
        (user_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [{"command": "user-pre"}],
                "Stop": [{"command": "user-stop"}],
            },
        }))

        project = tmp_path / "project"
        project.mkdir()
        (project / ".git").mkdir()
        proj_dsc = project / ".fred"
        proj_dsc.mkdir()
        (proj_dsc / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [{"command": "project-pre"}],
            },
        }))
        cfg = load_hooks_config(project)
        # Project replaces user for PreToolUse...
        assert len(cfg["PreToolUse"]) == 1
        assert cfg["PreToolUse"][0].command == "project-pre"
        # ...but Stop wasn't redefined so the user-level hook survives.
        assert len(cfg["Stop"]) == 1
        assert cfg["Stop"][0].command == "user-stop"

    def test_malformed_entries_skipped(self, tmp_path):
        (tmp_path / ".git").mkdir()
        fred_dir = tmp_path / ".fred"
        fred_dir.mkdir()
        (fred_dir / "settings.json").write_text(json.dumps({
            "hooks": {
                "PreToolUse": [
                    {"command": ""},                  # empty cmd → skip
                    {"command": 42},                  # non-string → skip
                    "not-a-dict",                     # not dict → skip
                    {"command": "ok", "timeout": -1}, # bad timeout → default
                    {"command": "kept"},
                ],
                "ImaginaryEvent": [{"command": "ignored"}],
            },
        }))
        cfg = load_hooks_config(tmp_path)
        assert len(cfg["PreToolUse"]) == 2
        assert cfg["PreToolUse"][0].command == "ok"
        # default timeout reapplied when input was invalid
        assert cfg["PreToolUse"][0].timeout == 30
        assert cfg["PreToolUse"][1].command == "kept"
        # Unknown events don't appear at all.
        assert "ImaginaryEvent" not in cfg


# ---------- direct hook execution -----------------------------------------


class TestRunHooks:
    def test_exit_zero_returns_unblocked_outcome(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse",
            matcher=None,
            command="exit 0",
            timeout=5,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.blocked is False
        assert out.exit_code == 0

    def test_exit_two_blocks(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command="echo blocked; exit 2", timeout=5,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.blocked is True
        assert out.exit_code == 2
        assert "blocked" in out.stdout

    def test_other_exit_codes_warn_only(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command="exit 7", timeout=5,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.blocked is False
        assert out.exit_code == 7

    def test_updated_input_parses(self, tmp_path):
        # Hook prints `{"updatedInput": {...}}` and exits 0.
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command='echo \'{"updatedInput":{"command":"ls -1"}}\'',
            timeout=5,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.blocked is False
        assert out.updated_input == {"command": "ls -1"}

    def test_non_json_stdout_ignored(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command="echo hello world", timeout=5,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.updated_input is None
        # stdout is captured (we still have the body for debugging) but
        # never sent to telemetry; only the count is.
        assert "hello" in out.stdout

    def test_timeout_enforced(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command="sleep 5", timeout=1,
        )]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.timed_out is True
        # exit_code is None on timeout; matches the documented contract
        # (`hook_run.exit_code` payload is nullable).
        assert out.exit_code is None
        assert out.blocked is False

    def test_matcher_filters_calls(self, tmp_path):
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse",
            matcher="Bash(rm -rf *)",
            command="exit 2",
            timeout=5,
        )]}
        # Doesn't match — hook does NOT run.
        out_safe = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out_safe is None
        # Matches — hook fires and blocks.
        out_dangerous = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "rm -rf /tmp/x"},
        )
        assert out_dangerous is not None
        assert out_dangerous.blocked is True

    def test_multiple_hooks_first_block_short_circuits(self, tmp_path):
        marker = tmp_path / "second_ran"
        cfg = {"PreToolUse": [
            HookConfig(event="PreToolUse", matcher=None,
                       command="exit 2", timeout=5),
            HookConfig(event="PreToolUse", matcher=None,
                       command=f"touch {marker}", timeout=5),
        ]}
        out = run_hooks(
            "PreToolUse", cfg,
            tool_name="bash", tool_input={"command": "ls"},
        )
        assert out is not None
        assert out.blocked is True
        # Second hook never ran.
        assert not marker.exists()

    def test_telemetry_event_payload(self, tmp_path, monkeypatch):
        tracer = _RecordingTracer()
        # Stdout body is produced by reading an env var so the marker
        # only ever appears in the subprocess's runtime output, not in
        # the recorded hook command itself.
        marker = "S3CRET_TOKEN_FROM_STDOUT"
        monkeypatch.setenv("FRED_TEST_HOOK_MARKER", marker)
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command='printf %s "$FRED_TEST_HOOK_MARKER"',
            timeout=5,
        )]}
        run_hooks(
            "PreToolUse", cfg,
            tracer=tracer,
            tool_name="bash", tool_input={"command": "ls"},
        )
        kinds = [k for k, _ in tracer.events]
        assert "hook_run" in kinds
        payload = next(p for k, p in tracer.events if k == "hook_run")
        assert payload["event"] == "PreToolUse"
        assert payload["blocked"] is False
        assert payload["exit_code"] == 0
        # `hook_stdout_chars` is a CHAR COUNT — must be the length, never
        # the body.
        assert payload["hook_stdout_chars"] == len(marker)
        # The stdout body itself is not on the payload (defends against
        # secret leakage when the user's hook accidentally echoes a key).
        assert "stdout" not in payload
        assert marker not in json.dumps(payload)

    def test_no_hooks_returns_none(self):
        out = run_hooks("PreToolUse", {}, tool_name="bash", tool_input={})
        assert out is None


# ---------- end-to-end through run_session --------------------------------


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls,
                            reasoning_content=None)
    return SimpleNamespace(choices=[SimpleNamespace(delta=delta, finish_reason=finish_reason)],
                           usage=None)


def _final_usage_chunk(usage):
    obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


def _make_client(scripted_streams):
    client = DSClient(api_key="test", model="deepseek-v4-flash")
    streams_iter = iter(scripted_streams)

    def fake_create(**_kwargs):
        return next(streams_iter)

    client._client = SimpleNamespace(
        chat=SimpleNamespace(
            completions=SimpleNamespace(create=fake_create),
        )
    )
    return client


class TestSessionDispatch:
    def test_pre_tool_use_blocks_with_outcome(self, tmp_path):
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        # Iter 1: emit a `view` tool call. Iter 2: model wraps up after
        # seeing the blocked-tool wire result.
        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="t1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2])

        tracer = _RecordingTracer()
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command="echo nope; exit 2", timeout=5,
        )]}
        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "look"}],
            client, default_registry(),
            permissions=PermissionPolicy(yolo=True, console=_silent_console()),
            renderer=Renderer(console=_silent_console(), stream=False),
            tracer=tracer,
            hooks_config=cfg,
        )
        # Tool wire result shows the block message.
        tool_msg = next(m for m in result.messages if m["role"] == "tool")
        assert "PreToolUse hook blocked" in tool_msg["content"]
        # And the file's contents were NOT exfiltrated into the wire result
        # (handler never ran).
        assert "hi" not in tool_msg["content"]
        # `hook_run` event has blocked=True and the hook_blocked outcome
        # surfaced via telemetry.
        hook_runs = [p for k, p in tracer.events if k == "hook_run"]
        assert any(p["blocked"] is True for p in hook_runs)

    def test_pre_tool_use_updates_input(self, tmp_path):
        target = tmp_path / "real.txt"
        target.write_text("ACTUAL CONTENTS\n")
        decoy = tmp_path / "decoy.txt"
        decoy.write_text("DECOY\n")

        # Iter 1: model asks for the decoy file. Hook rewrites the path
        # to the real one. Iter 2: model wraps up.
        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="t1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path":"{decoy}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="seen", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2])

        # The hook prints `{"updatedInput": {"path": "<real>"}}` and exits 0.
        cfg = {"PreToolUse": [HookConfig(
            event="PreToolUse", matcher=None,
            command=f"printf '%s' '{{\"updatedInput\":{{\"path\":\"{target}\"}}}}'",
            timeout=5,
        )]}
        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "view it"}],
            client, default_registry(),
            permissions=PermissionPolicy(yolo=True, console=_silent_console()),
            renderer=Renderer(console=_silent_console(), stream=False),
            hooks_config=cfg,
        )
        tool_msg = next(m for m in result.messages if m["role"] == "tool")
        # Handler saw the rewritten path.
        assert "ACTUAL CONTENTS" in tool_msg["content"]
        assert "DECOY" not in tool_msg["content"]

    def test_post_tool_use_does_not_rollback(self, tmp_path):
        target = tmp_path / "f.txt"
        target.write_text("hi\n")
        stream1 = iter([
            _delta_chunk(tool_calls=[_tc_delta(0, id="t1", name="view")]),
            _delta_chunk(tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                         finish_reason="tool_calls"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        stream2 = iter([
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ])
        client = _make_client([stream1, stream2])

        tracer = _RecordingTracer()
        cfg = {"PostToolUse": [HookConfig(
            event="PostToolUse", matcher=None,
            command="exit 2", timeout=5,
        )]}
        result = run_session(
            [{"role": "system", "content": "s"},
             {"role": "user", "content": "look"}],
            client, default_registry(),
            permissions=PermissionPolicy(yolo=True, console=_silent_console()),
            renderer=Renderer(console=_silent_console(), stream=False),
            tracer=tracer,
            hooks_config=cfg,
        )
        tool_msg = next(m for m in result.messages if m["role"] == "tool")
        # Tool ran (we still see its output), but the post-hook annotated
        # the wire text with a block warning.
        assert "PostToolUse hook blocked" in tool_msg["content"]
        assert "hi" in tool_msg["content"]
        # Telemetry recorded the post-hook run with blocked=True.
        post_events = [
            p for k, p in tracer.events
            if k == "hook_run" and p["event"] == "PostToolUse"
        ]
        assert post_events
        assert post_events[0]["blocked"] is True


class TestUserPromptSubmitGate:
    """The CLI gate runs OUTSIDE run_session — we exercise run_hooks
    directly with the `UserPromptSubmit` event, then assert the agent
    loop is never invoked.
    """

    def test_blocked_prompt_short_circuits(self, monkeypatch):
        cfg = {"UserPromptSubmit": [HookConfig(
            event="UserPromptSubmit", matcher=None,
            command="exit 2", timeout=5,
        )]}
        out = run_hooks("UserPromptSubmit", cfg, user_input="hello agent")
        assert out is not None
        assert out.blocked is True

    def test_unblocked_prompt_proceeds(self, monkeypatch):
        cfg = {"UserPromptSubmit": [HookConfig(
            event="UserPromptSubmit", matcher=None,
            command="exit 0", timeout=5,
        )]}
        out = run_hooks("UserPromptSubmit", cfg, user_input="hello agent")
        assert out is not None
        assert out.blocked is False


class TestStopHook:
    def test_runs_with_reason(self):
        tracer = _RecordingTracer()
        cfg = {"Stop": [HookConfig(
            event="Stop", matcher=None,
            command="cat > /dev/null", timeout=5,
        )]}
        out = run_hooks("Stop", cfg, tracer=tracer, reason="exit_cmd")
        assert out is not None
        assert out.blocked is False
        # Telemetry recorded the run.
        assert any(k == "hook_run" for k, _ in tracer.events)

    def test_failure_does_not_raise(self):
        cfg = {"Stop": [HookConfig(
            event="Stop", matcher=None,
            command="exit 9", timeout=5,
        )]}
        # Just shouldn't raise.
        out = run_hooks("Stop", cfg, reason="crash")
        assert out is not None
        assert out.blocked is False


class TestListHooks:
    def test_lists_in_event_order(self):
        cfg = {
            "PreToolUse": [HookConfig(event="PreToolUse", matcher="Bash(*)",
                                       command="a", timeout=5)],
            "Stop": [HookConfig(event="Stop", matcher=None,
                                 command="b", timeout=5)],
        }
        pairs = list(list_hooks_for(cfg))
        assert [p[0] for p in pairs] == ["PreToolUse", "Stop"]
        assert pairs[0][1].command == "a"
        assert pairs[1][1].command == "b"
