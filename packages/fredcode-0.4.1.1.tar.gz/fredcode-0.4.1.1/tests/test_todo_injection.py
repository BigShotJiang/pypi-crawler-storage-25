"""P1.6 persistent todo-list context injection.

Covers `fred.todo_inject` (rendering, sentinel detection, injection placement,
auto-seed heuristics) plus the integration in `fred.session.run_session` that
threads the synthetic todo block through to the model on every iteration.

We mock the streaming OpenAI client (same pattern as test_session.py) and
inspect the captured `messages` argument shape to assert the injected block
sits between system+tools and conversation history.
"""
from __future__ import annotations

import io
from types import SimpleNamespace

import pytest
from rich.console import Console

from fred.client import DSClient
from fred.permissions import PermissionPolicy
from fred.render import Renderer
from fred.session import run_session
from fred.todo_inject import (
    TODO_BLOCK_HEADER,
    inject_todo_block,
    is_todo_block_message,
    render_todo_block,
    todos_state_payload,
)
from fred.tools.registry import default_registry
from fred.tools.todo import TodoItem


# ---------- helpers (mirrors test_session.py) -----------------------------


def _silent_console() -> Console:
    return Console(file=io.StringIO(), force_terminal=False, width=120)


def _captured_console():
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


def _delta_chunk(*, content=None, tool_calls=None, finish_reason=None, usage=None):
    delta = SimpleNamespace(content=content, tool_calls=tool_calls, reasoning_content=None)
    choice = SimpleNamespace(delta=delta, finish_reason=finish_reason)
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u) if usage is not None else None
    return SimpleNamespace(choices=[choice], usage=usage_obj)


def _final_usage_chunk(usage):
    usage_obj = SimpleNamespace(model_dump=lambda u=usage: u)
    return SimpleNamespace(choices=[], usage=usage_obj)


def _tc_delta(index, *, id=None, name=None, args=None):
    fn = SimpleNamespace(name=name, arguments=args) if (name or args is not None) else None
    return SimpleNamespace(index=index, id=id, function=fn)


class _RecordingClient:
    """DSClient with a `chat.completions.create` that records every call's
    `messages` kwarg and returns the next scripted streaming chunk list.
    """
    def __init__(self, scripted_streams: list):
        self._streams = list(scripted_streams)
        self.calls: list[list[dict]] = []

        client = DSClient(api_key="test", model="deepseek-v4-flash")
        outer = self

        def fake_create(**kwargs):
            outer.calls.append([dict(m) for m in kwargs.get("messages", [])])
            return iter(outer._streams.pop(0))

        client._client = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=fake_create),
            )
        )
        self.client = client


def _reset_todo_state():
    """Reset the module-level todo store between tests."""
    from fred.tools.todo import _set_for_test
    _set_for_test([])


@pytest.fixture(autouse=True)
def _clean_todos():
    _reset_todo_state()
    yield
    _reset_todo_state()


# ---------- render_todo_block --------------------------------------------


class TestRenderTodoBlock:
    def test_empty_renders_stable_placeholder(self):
        out = render_todo_block(todos=[])
        assert TODO_BLOCK_HEADER in out
        # PR-D1 collapsed the two-branch hint into one stable placeholder.
        assert "no todos yet" in out
        assert "todo_write" in out

    def test_three_todos_render_with_correct_glyphs(self):
        todos = [
            TodoItem(id="a", content="completed thing", status="completed"),
            TodoItem(id="b", content="in flight thing", status="in_progress"),
            TodoItem(id="c", content="pending thing", status="pending"),
        ]
        out = render_todo_block(todos=todos)
        assert TODO_BLOCK_HEADER in out
        # Glyphs match Renderer.show_todos.
        assert "☑ completed thing" in out
        assert "◐ in flight thing" in out
        assert "☐ pending thing" in out

    def test_default_fetches_get_todos(self, monkeypatch):
        monkeypatch.setattr(
            "fred.todo_inject.get_todos",
            lambda: [TodoItem(id="x", content="default-fetched", status="pending")],
        )
        out = render_todo_block()
        assert "default-fetched" in out
        assert "☐" in out

    def test_empty_placeholder_byte_stable(self):
        # Cache-friendliness: the placeholder must be byte-identical
        # across calls when todos are empty (otherwise the volatile
        # tail invalidates more cache than necessary).
        a = render_todo_block(todos=[])
        b = render_todo_block(todos=[])
        assert a == b



# ---------- is_todo_block_message ----------------------------------------


class TestIsTodoBlockMessage:
    def test_detects_injected_system_message(self):
        msg = {"role": "system", "content": TODO_BLOCK_HEADER + "\n☐ a"}
        assert is_todo_block_message(msg) is True

    def test_rejects_non_system_role(self):
        # Even with the right prefix, a user-role message is not the marker.
        msg = {"role": "user", "content": TODO_BLOCK_HEADER + "\n☐ a"}
        assert is_todo_block_message(msg) is False

    def test_rejects_unrelated_system_message(self):
        msg = {"role": "system", "content": "You are fred..."}
        assert is_todo_block_message(msg) is False

    def test_rejects_non_string_content(self):
        msg = {"role": "system", "content": [{"type": "text", "text": "..."}]}
        assert is_todo_block_message(msg) is False


# ---------- inject_todo_block --------------------------------------------


class TestInjectTodoBlock:
    def test_inserts_after_leading_system_messages(self):
        messages = [
            {"role": "system", "content": "BIG_SYSTEM_PROMPT"},
            {"role": "user", "content": "hi"},
            {"role": "assistant", "content": "hello"},
        ]
        out, n = inject_todo_block(messages, todos=[])
        # Position: AFTER system, BEFORE user.
        assert out[0]["role"] == "system"
        assert out[0]["content"] == "BIG_SYSTEM_PROMPT"
        assert out[1]["role"] == "system"
        assert out[1]["content"].startswith(TODO_BLOCK_HEADER)
        assert out[2]["role"] == "user"
        assert out[3]["role"] == "assistant"
        # Telemetry: byte length of the injected block.
        assert n == len(out[1]["content"].encode("utf-8"))

    def test_inserts_at_zero_when_no_leading_system(self):
        messages = [{"role": "user", "content": "hi"}]
        out, _ = inject_todo_block(messages, todos=[])
        assert out[0]["role"] == "system"
        assert out[0]["content"].startswith(TODO_BLOCK_HEADER)
        assert out[1]["role"] == "user"

    def test_re_injection_replaces_prior_block(self):
        # First inject: empty list.
        m1, _ = inject_todo_block(
            [
                {"role": "system", "content": "S"},
                {"role": "user", "content": "u1"},
            ],
            todos=[],
        )
        assert sum(is_todo_block_message(m) for m in m1) == 1

        # Re-inject with a populated list — prior block is replaced, not duped.
        todos = [TodoItem(id="x", content="now there's a todo", status="pending")]
        m2, _ = inject_todo_block(m1, todos=todos)
        # Exactly one todo block remains.
        assert sum(is_todo_block_message(m) for m in m2) == 1
        # And it reflects the NEW state.
        block = next(m for m in m2 if is_todo_block_message(m))
        assert "now there's a todo" in block["content"]
        # Conversation tail intact.
        assert {"role": "user", "content": "u1"} in m2

    def test_does_not_mutate_input(self):
        messages = [
            {"role": "system", "content": "S"},
            {"role": "user", "content": "U"},
        ]
        snapshot = [dict(m) for m in messages]
        inject_todo_block(messages, todos=[])
        assert messages == snapshot

    def test_handles_multiple_leading_system_messages(self):
        # If a future caller stacks rules / repo-map system messages first,
        # the todo block goes AFTER all of them.
        messages = [
            {"role": "system", "content": "S1"},
            {"role": "system", "content": "S2"},
            {"role": "user", "content": "U"},
        ]
        out, _ = inject_todo_block(messages, todos=[])
        # After both system messages, before user.
        assert [m["role"] for m in out] == ["system", "system", "system", "user"]
        assert out[2]["content"].startswith(TODO_BLOCK_HEADER)


# ---------- todos_state_payload ------------------------------------------


class TestTodosStatePayload:
    def test_counts_each_status(self):
        todos = [
            TodoItem(id="a", content="x", status="pending"),
            TodoItem(id="b", content="y", status="pending"),
            TodoItem(id="c", content="z", status="in_progress"),
            TodoItem(id="d", content="w", status="completed"),
        ]
        payload = todos_state_payload(todos, injected_chars=128)
        assert payload == {
            "count_total": 4,
            "count_pending": 2,
            "count_in_progress": 1,
            "count_completed": 1,
            "injected_chars": 128,
        }

    def test_empty_list(self):
        payload = todos_state_payload([], injected_chars=42)
        assert payload["count_total"] == 0
        assert payload["count_pending"] == 0
        assert payload["count_in_progress"] == 0
        assert payload["count_completed"] == 0
        assert payload["injected_chars"] == 42


# ---------- run_session integration --------------------------------------


class TestSessionInjection:
    """End-to-end: run_session injects the todo block into the messages
    list passed to the model on each iteration, AFTER system+tools and
    BEFORE user/assistant history. Re-injection replaces, not duplicates.
    """

    def _silent(self):
        return _silent_console()

    def _make_basic_session(self, scripted_streams):
        rec = _RecordingClient(scripted_streams)
        registry = default_registry()
        renderer = Renderer(console=self._silent(), stream=False)
        permissions = PermissionPolicy(yolo=True, console=self._silent())
        return rec, registry, renderer, permissions

    def test_empty_todos_block_lands_in_messages(self):
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
        )
        assert len(rec.calls) == 1
        sent = rec.calls[0]
        # Position assertion: [SYS][TODO][USER].
        assert sent[0]["role"] == "system"
        assert sent[0]["content"] == "SYS"
        assert sent[1]["role"] == "system"
        assert sent[1]["content"].startswith(TODO_BLOCK_HEADER)
        # PR-D1 placeholder phrase replaces the prior "empty" wording.
        assert "no todos yet" in sent[1]["content"].lower()
        assert sent[2]["role"] == "user"
        assert sent[2]["content"] == "hi"

    def test_three_todos_render_in_injected_block(self):
        # Seed the todo store with three items in mixed states, then run
        # one iteration and inspect what the model received.
        from fred.tools.todo import _set_for_test
        _set_for_test([
            TodoItem(id="1", content="alpha", status="completed"),
            TodoItem(id="2", content="beta", status="in_progress"),
            TodoItem(id="3", content="gamma", status="pending"),
        ])
        stream = [
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
        )
        block = rec.calls[0][1]["content"]
        assert "☑ alpha" in block
        assert "◐ beta" in block
        assert "☐ gamma" in block

    def test_post_todo_write_next_iteration_reflects_new_state(self, tmp_path):
        # Iteration 1: model emits a todo_write tool call to seed the list.
        # Iteration 2: model's request now includes the freshly-seeded list
        # in the injected block (and ONLY the new list — no duplicates).
        from fred.tools.todo import _set_for_test
        # The tool call args must match TodoWriteArgs schema; build args JSON.
        args_json = (
            '{"todos":['
            '{"id":"t1","content":"first task","status":"in_progress"}'
            ']}'
        )
        stream1 = [
            _delta_chunk(tool_calls=[_tc_delta(0, id="call_x", name="todo_write")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args=args_json)],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        stream2 = [
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream1, stream2])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "go"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
        )

        assert len(rec.calls) == 2
        # First call: empty list (todo_write hadn't been dispatched yet).
        block1 = rec.calls[0][1]["content"]
        assert block1.startswith(TODO_BLOCK_HEADER)
        assert "no todos yet" in block1.lower()

        # Second call: the new state is now in the injected block.
        block2 = rec.calls[1][1]["content"]
        assert block2.startswith(TODO_BLOCK_HEADER)
        assert "first task" in block2
        assert "◐ first task" in block2  # in_progress glyph

        # The second call's messages list must NOT contain TWO todo blocks.
        sent2 = rec.calls[1]
        todo_blocks = [m for m in sent2 if is_todo_block_message(m)]
        assert len(todo_blocks) == 1

    def test_messages_appear_after_block_in_second_iteration(self):
        # Two-iteration shape check: after iter 1, working messages have
        # an assistant + tool message. The iter 2 wire payload must place
        # the todo block at index 1 (after SYS) and the older
        # user/assistant/tool messages AFTER the block.
        from fred.tools.todo import _set_for_test
        _set_for_test([
            TodoItem(id="1", content="active", status="in_progress"),
        ])
        # Use view tool — easy to script with a real tmp_path file.
        import tempfile, os
        td = tempfile.mkdtemp()
        target = os.path.join(td, "x.txt")
        with open(target, "w") as f:
            f.write("payload\n")
        stream1 = [
            _delta_chunk(tool_calls=[_tc_delta(0, id="t1", name="view")]),
            _delta_chunk(
                tool_calls=[_tc_delta(0, args=f'{{"path":"{target}"}}')],
                finish_reason="tool_calls",
            ),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        stream2 = [
            _delta_chunk(content="done", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream1, stream2])
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "go"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
        )
        # Iter 2 shape: SYS, TODO, USER, ASSISTANT(tool_calls), TOOL.
        sent2 = rec.calls[1]
        assert sent2[0]["role"] == "system"
        assert sent2[0]["content"] == "SYS"
        assert is_todo_block_message(sent2[1])
        assert sent2[2]["role"] == "user"
        assert sent2[3]["role"] == "assistant"
        assert sent2[4]["role"] == "tool"

    def test_returned_messages_have_no_injected_blocks(self):
        # The wire-format injection must not bleed into the externally-
        # visible result.messages — that's what cli.py persists across
        # turns and what /save dumps.
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream])
        result = run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
        )
        # No todo-block message should appear in the returned messages.
        assert not any(is_todo_block_message(m) for m in result.messages)
        # SYS, user, assistant — exactly three.
        assert [m["role"] for m in result.messages] == ["system", "user", "assistant"]

    def test_always_on_empty_placeholder(self):
        # PR-D1: empty-state placeholder is always-on (no env gate, no
        # content heuristic) and renders the same single line whether
        # the user prompt is multi-step or single-action.
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream])

        from fred.agent import run_turn
        messages = [{"role": "system", "content": "SYS"}]
        run_turn(
            "First do A, then do B, then do C, then do D.",
            messages, rec.client, reg, ren, perm,
        )
        block = rec.calls[0][1]["content"]
        # Stable placeholder phrase only.
        assert "no todos yet" in block

    def test_telemetry_event_emitted_per_iteration(self):
        # `todos_state` events should fire once per iteration with counts
        # matching the current todo-store state at that moment.
        from fred.tools.todo import _set_for_test
        _set_for_test([
            TodoItem(id="1", content="t", status="pending"),
            TodoItem(id="2", content="u", status="completed"),
        ])
        stream = [
            _delta_chunk(content="ok", finish_reason="stop"),
            _final_usage_chunk({"prompt_tokens": 1, "completion_tokens": 1}),
        ]
        rec, reg, ren, perm = self._make_basic_session([stream])

        # Capture tracer events via a lightweight stub that mirrors the
        # PgTracer surface used by run_session.
        from fred.telemetry import NullTracer

        class _CapturingTracer(NullTracer):
            def __init__(self):
                self.events: list[tuple[str, dict | None]] = []

            def event(self, kind, *, payload=None, turn=None):
                self.events.append((kind, payload))

        cap = _CapturingTracer()
        run_session(
            [
                {"role": "system", "content": "SYS"},
                {"role": "user", "content": "hi"},
            ],
            rec.client,
            reg,
            permissions=perm,
            renderer=ren,
            tracer=cap,
        )
        states = [p for k, p in cap.events if k == "todos_state"]
        assert len(states) == 1
        assert states[0]["count_total"] == 2
        assert states[0]["count_pending"] == 1
        assert states[0]["count_completed"] == 1
        assert states[0]["count_in_progress"] == 0
        assert states[0]["injected_chars"] > 0


# ---------- /todos slash command -----------------------------------------


class TestTodosSlash:
    """The /todos slash command in cli.py prints the same content as
    Renderer.show_todos for non-empty lists, and a one-line note when
    empty. The handler is inline in cli.py — we replicate its logic by
    calling show_todos directly via the same path.
    """

    def test_show_todos_renders_same_as_inline_handler(self, monkeypatch):
        # The handler in cli.py reads `get_todos()` and either calls
        # `renderer.show_todos()` or prints "no todos." This test asserts
        # the rendered output matches `show_todos()` exactly when todos
        # are present.
        from fred.render import Renderer
        from fred.tools.todo import TodoItem
        monkeypatch.setattr(
            "fred.tools.todo.get_todos",
            lambda: [
                TodoItem(id="1", content="alpha", status="in_progress"),
                TodoItem(id="2", content="beta", status="pending"),
            ],
        )
        console, buf = _captured_console()
        r = Renderer(console=console, stream=False)
        r.show_todos()
        out = buf.getvalue()
        assert "Todos" in out
        assert "alpha" in out
        assert "beta" in out
        assert "◐" in out
        assert "☐" in out
