"""Tests for fred.prompt_cache: refresh, load, and missing-cache behavior."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx
import pytest

from fred import prompt_cache
from fred.prompt_cache import (
    PromptsUnavailableError,
    get_component,
    load_components,
    refresh_from_server,
)


class _FakeResponse:
    def __init__(self, status_code: int, payload: Any) -> None:
        self.status_code = status_code
        self._payload = payload
        self.text = json.dumps(payload) if isinstance(payload, (dict, list)) else str(payload)

    def json(self) -> Any:
        if isinstance(self._payload, Exception):
            raise self._payload
        return self._payload


def _install_get(monkeypatch: pytest.MonkeyPatch, response: _FakeResponse | Exception) -> None:
    captured: dict[str, Any] = {}

    def fake_get(self, url, *args, **kwargs):  # noqa: ANN001
        captured["url"] = url
        captured["headers"] = kwargs.get("headers", {})
        if isinstance(response, Exception):
            raise response
        return response

    monkeypatch.setattr("httpx.Client.get", fake_get)
    return captured


# ---------- refresh_from_server -------------------------------------------------


def test_refresh_writes_cache_on_success(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    payload = {
        "version": "1",
        "components": {
            "system_agent_role": "You are fred.",
            "init_system": "Init body.",
        },
    }
    captured = _install_get(monkeypatch, _FakeResponse(200, payload))

    cache_path = tmp_path / "agent-prompts.json"
    ok = refresh_from_server("https://app.fredcode.net", api_key="fred_live_x", path=cache_path)

    assert ok is True
    assert cache_path.exists()
    written = json.loads(cache_path.read_text(encoding="utf-8"))
    assert written["components"] == payload["components"]
    assert isinstance(written["fetched_at"], (int, float))
    assert written["fetched_at"] > 0
    # Auth header was sent.
    assert captured["headers"]["Authorization"] == "Bearer fred_live_x"
    # URL is correctly formed.
    assert captured["url"] == "https://app.fredcode.net/api/cli/agent-prompts"


def test_refresh_strips_trailing_slash_from_base_url(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    captured = _install_get(monkeypatch, _FakeResponse(200, {"components": {"x": "y"}}))
    cache_path = tmp_path / "agent-prompts.json"
    refresh_from_server("https://app.fredcode.net/", api_key="fred_live_y", path=cache_path)
    assert captured["url"] == "https://app.fredcode.net/api/cli/agent-prompts"


def test_refresh_returns_false_on_non_200(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
) -> None:
    _install_get(monkeypatch, _FakeResponse(401, {"error": "invalid_api_key"}))
    cache_path = tmp_path / "agent-prompts.json"
    ok = refresh_from_server("https://app.fredcode.net", api_key="fred_live_x", path=cache_path)
    assert ok is False
    assert not cache_path.exists()
    err = capsys.readouterr().err
    assert "401" in err


def test_refresh_returns_false_on_network_error(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _install_get(monkeypatch, httpx.ConnectError("connection refused"))
    cache_path = tmp_path / "agent-prompts.json"
    ok = refresh_from_server("https://app.fredcode.net", api_key="fred_live_x", path=cache_path)
    assert ok is False
    assert not cache_path.exists()


def test_refresh_rejects_unexpected_payload(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # Missing "components" key.
    _install_get(monkeypatch, _FakeResponse(200, {"version": "1"}))
    cache_path = tmp_path / "agent-prompts.json"
    assert refresh_from_server("https://x", api_key="k", path=cache_path) is False
    assert not cache_path.exists()


def test_refresh_rejects_empty_components(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    _install_get(monkeypatch, _FakeResponse(200, {"version": "1", "components": {}}))
    cache_path = tmp_path / "agent-prompts.json"
    assert refresh_from_server("https://x", api_key="k", path=cache_path) is False


# ---------- load_components / get_component -----------------------------------


def test_load_components_reads_cache_file(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache_path = tmp_path / "agent-prompts.json"
    cache_path.write_text(
        json.dumps({"version": "1", "components": {"a": "alpha", "b": "beta"}}),
        encoding="utf-8",
    )
    # Override the env path the conftest installed for this test only.
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(cache_path))
    out = load_components()
    assert out == {"a": "alpha", "b": "beta"}


def test_load_components_raises_when_missing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(tmp_path / "does-not-exist.json"))
    with pytest.raises(PromptsUnavailableError) as exc:
        load_components()
    assert "fred login" in str(exc.value)


def test_load_components_raises_on_malformed_json(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    bad = tmp_path / "agent-prompts.json"
    bad.write_text("{ not json", encoding="utf-8")
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(bad))
    with pytest.raises(PromptsUnavailableError) as exc:
        load_components()
    assert "fred login" in str(exc.value)


def test_load_components_raises_when_empty(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    empty = tmp_path / "agent-prompts.json"
    empty.write_text(json.dumps({"version": "1", "components": {}}), encoding="utf-8")
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(empty))
    with pytest.raises(PromptsUnavailableError):
        load_components()


def test_get_component_raises_on_missing_key(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    cache_path = tmp_path / "agent-prompts.json"
    cache_path.write_text(
        json.dumps({"version": "1", "components": {"only_one": "x"}}), encoding="utf-8"
    )
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(cache_path))
    with pytest.raises(PromptsUnavailableError) as exc:
        get_component("not_present")
    # Error message points the user at a remediation.
    assert "not_present" in str(exc.value)


# ---------- env override resolution -------------------------------------------


def test_env_override_path_takes_precedence(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    # If both an explicit `path=` arg and the env var are set, the explicit
    # arg wins. (Tests the resolver, not just the env path.)
    env_target = tmp_path / "from-env.json"
    explicit_target = tmp_path / "from-arg.json"
    explicit_target.write_text(
        json.dumps({"version": "1", "components": {"key": "value-from-arg"}}),
        encoding="utf-8",
    )
    monkeypatch.setenv("FRED_AGENT_PROMPTS_PATH", str(env_target))
    out = prompt_cache.load_components(path=explicit_target)
    assert out == {"key": "value-from-arg"}
