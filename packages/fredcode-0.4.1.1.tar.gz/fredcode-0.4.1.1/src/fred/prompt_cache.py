"""Server-fetched agent-prompt cache.

The CLI's system + init + subagent prompts live on FredWeb and are
served from ``GET /api/cli/agent-prompts`` to authenticated callers.
This module is the on-disk cache: a single JSON file at
``~/.config/fred/agent-prompts.json`` holding the verbatim payload plus
a ``fetched_at`` timestamp.

Refresh happens on every successful ``fred login`` (alongside the
rate-card refresh in ``rates.refresh_from_server``). Reads happen on
every ``system_prompt.build()`` and ``init_prompt.*`` call. There is no
bundled fallback — the wheel ships zero prompt text. If the cache is
missing, callers raise :class:`PromptsUnavailableError` and the CLI
exits with a clear "run fred login" message.

Tests bypass the network by pointing the cache at a fixture JSON via
``FRED_AGENT_PROMPTS_PATH`` (see ``tests/conftest.py``).
"""
from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from typing import Any

import httpx

DEFAULT_PROMPTS_PATH = Path.home() / ".config" / "fred" / "agent-prompts.json"
ENV_PATH_OVERRIDE = "FRED_AGENT_PROMPTS_PATH"


class PromptsUnavailableError(RuntimeError):
    """Raised when prompt components can't be loaded — missing cache or
    malformed payload. Callers (system_prompt.build, init_prompt.*) let
    this propagate; cli.py catches it at startup and exits with a clear
    "fred login" message."""


def _resolve_path(path: Path | None) -> Path:
    if path is not None:
        return path
    override = os.environ.get(ENV_PATH_OVERRIDE)
    if override:
        return Path(override)
    return DEFAULT_PROMPTS_PATH


def load_components(path: Path | None = None) -> dict[str, str]:
    """Return the components dict from cache. Raises PromptsUnavailableError
    if the cache file is missing or malformed."""
    target = _resolve_path(path)
    if not target.exists():
        raise PromptsUnavailableError(
            f"Agent prompts not cached at {target}. Run `fred login` to fetch them."
        )
    try:
        raw = json.loads(target.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        raise PromptsUnavailableError(
            f"Could not read agent prompts at {target}: {e}. Run `fred login` to refresh."
        ) from e
    components = raw.get("components")
    if not isinstance(components, dict) or not components:
        raise PromptsUnavailableError(
            f"Agent-prompt cache at {target} has no components. Run `fred login` to refresh."
        )
    return {str(k): str(v) for k, v in components.items()}


def get_component(name: str, path: Path | None = None) -> str:
    """Return one component string. Raises PromptsUnavailableError if
    the cache is missing or the component name isn't present."""
    components = load_components(path)
    if name not in components:
        raise PromptsUnavailableError(
            f"Agent-prompt component '{name}' is missing from the cache. "
            "The CLI is out of sync with the server — run `fred login` to refresh, "
            "or upgrade the CLI."
        )
    return components[name]


def refresh_from_server(
    base_url: str,
    *,
    api_key: str,
    timeout: float = 10.0,
    path: Path | None = None,
) -> bool:
    """Fetch /api/cli/agent-prompts and persist to the cache file.

    Returns True on success, False (with a stderr note) on any failure.
    Never raises — callers handle "no prompts" via the read-side
    PromptsUnavailableError. Login flow uses this best-effort.
    """
    target_path = _resolve_path(path)
    url = f"{base_url.rstrip('/')}/api/cli/agent-prompts"
    try:
        with httpx.Client(timeout=timeout) as client:
            resp = client.get(url, headers={"Authorization": f"Bearer {api_key}"})
        if resp.status_code != 200:
            print(
                f"fred: agent-prompt refresh got HTTP {resp.status_code}; "
                "keeping existing cache",
                file=sys.stderr,
            )
            return False
        payload: Any = resp.json()
    except (httpx.HTTPError, ValueError) as e:
        print(
            f"fred: agent-prompt refresh failed ({e}); keeping existing cache",
            file=sys.stderr,
        )
        return False

    if (
        not isinstance(payload, dict)
        or not isinstance(payload.get("components"), dict)
        or not payload["components"]
    ):
        print(
            "fred: agent-prompt refresh got unexpected payload shape; "
            "keeping existing cache",
            file=sys.stderr,
        )
        return False

    payload["fetched_at"] = time.time()
    try:
        target_path.parent.mkdir(parents=True, exist_ok=True)
        target_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    except OSError as e:
        print(f"fred: could not write agent-prompt cache: {e}", file=sys.stderr)
        return False
    return True
