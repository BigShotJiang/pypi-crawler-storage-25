"""System prompt builder — componentized renderer.

The component bodies (the actual prompt text) live on FredWeb's
``/api/cli/agent-prompts`` endpoint and are cached locally at
``~/.config/fred/agent-prompts.json`` after every ``fred login``. This
module owns the *structure*: which components compose into a turn's
system prompt, which axes (mode / output_style) gate which components,
and how the runtime context (cwd / os / shell / date / tool_catalog)
is interpolated.

Two prompt flows: ``mode="act"`` (default, full write access) and
``mode="plan"`` (read-only; the model produces a plan and calls
``exit_plan_mode`` to switch to act).

``output_style`` is a flag axis on top of mode: ``"concise"`` (default)
keeps the existing terse contract; ``"explanatory"`` appends one bullet
inside the response-style component asking for a short paragraph of
reasoning after each significant change.

The component bodies are byte-identical across calls for a given
context — that's the load-bearing property for DeepSeek's auto
prefix-cache and Anthropic's ``cache_control`` markers.

If the cache is empty (no ``fred login`` has been run yet, or the file
was deleted), :func:`build` raises :class:`PromptsUnavailableError`.
There is no bundled fallback — the wheel ships zero prompt text.
"""
from __future__ import annotations

import os
import platform
from dataclasses import dataclass, field
from datetime import date
from pathlib import Path
from string import Template
from typing import Callable, Literal

from fred.prompt_cache import load_components
from fred.tools.registry import Registry

OutputStyle = Literal["concise", "explanatory"]
Mode = Literal["act", "plan"]


@dataclass(frozen=True)
class PromptContext:
    """Pure-data input to every component renderer."""

    mode: Mode
    output_style: OutputStyle
    cwd: str
    os: str
    shell: str
    date: str
    tool_catalog: str
    components: dict[str, str] = field(default_factory=dict)


Renderer = Callable[[PromptContext], "str | None"]


def _render_agent_role(ctx: PromptContext) -> str:
    return ctx.components["system_agent_role"]


def _render_environment(ctx: PromptContext) -> str:
    tmpl = Template(ctx.components["system_environment_template"])
    return tmpl.safe_substitute(cwd=ctx.cwd, os=ctx.os, shell=ctx.shell, date=ctx.date)


def _render_tools(ctx: PromptContext) -> str:
    tmpl = Template(ctx.components["system_tools_template"])
    return tmpl.safe_substitute(tool_catalog=ctx.tool_catalog)


def _render_mode_contract(ctx: PromptContext) -> str:
    key = "system_mode_plan" if ctx.mode == "plan" else "system_mode_act"
    return ctx.components[key]


def _render_tool_use_protocol(ctx: PromptContext) -> str:
    key = (
        "system_tool_use_protocol_plan"
        if ctx.mode == "plan"
        else "system_tool_use_protocol_act"
    )
    return ctx.components[key]


def _render_editing_files(ctx: PromptContext) -> str | None:
    if ctx.mode == "plan":
        return None
    return ctx.components["system_editing_files"]


def _render_verification(ctx: PromptContext) -> str:
    key = "system_verification_plan" if ctx.mode == "plan" else "system_verification_act"
    return ctx.components[key]


def _render_response_style(ctx: PromptContext) -> str:
    base = ctx.components["system_response_style"]
    if ctx.output_style == "explanatory":
        base += ctx.components["system_response_style_explanatory_addendum"]
    return base


def _render_web_research(ctx: PromptContext) -> str | None:
    if ctx.mode == "plan":
        return None
    return ctx.components["system_web_research"]


def _render_safety(ctx: PromptContext) -> str:
    return ctx.components["system_safety"]


_RENDERERS: tuple[tuple[str, Renderer], ...] = (
    ("agent_role", _render_agent_role),
    ("environment", _render_environment),
    ("tools", _render_tools),
    ("mode_contract", _render_mode_contract),
    ("tool_use_protocol", _render_tool_use_protocol),
    ("editing_files", _render_editing_files),
    ("verification", _render_verification),
    ("response_style", _render_response_style),
    ("web_research", _render_web_research),
    ("safety", _render_safety),
)


def build(
    registry: Registry,
    project_memory: str | None = None,
    *,
    today: str | None = None,
    mode: Mode = "act",
    output_style: OutputStyle = "concise",
) -> str:
    """Render the system prompt for one model call.

    ``today`` is captured once per REPL session (or ``/clear``) by the caller
    so the prefix bytes don't change at midnight; that would invalidate
    DeepSeek's prefix cache and Anthropic's ``cache_control``.

    ``mode`` selects between act and plan component variants. The selected
    components' BYTES are part of the cacheable prefix; flipping mode
    mid-session invalidates the cache for that pivot turn — the right
    tradeoff because the system contract changed.

    ``output_style`` defaults to ``"concise"``. ``"explanatory"`` appends
    one bullet inside the response-style component.

    Raises :class:`PromptsUnavailableError` if the on-disk prompt cache
    is missing or malformed — the caller (cli.py) is expected to surface
    a "run fred login" message and exit cleanly.
    """
    components = load_components()
    catalog = "\n".join(
        f"- `{name}`: {(registry.get(name).description or '').splitlines()[0]}"
        for name in registry.names()
    )
    ctx = PromptContext(
        mode=mode,
        output_style=output_style,
        cwd=str(Path.cwd()),
        os=f"{platform.system()} {platform.release()}",
        shell=os.environ.get("SHELL", "unknown"),
        date=today if today is not None else date.today().isoformat(),
        tool_catalog=catalog,
        components=components,
    )
    parts = [out for _, fn in _RENDERERS if (out := fn(ctx)) is not None]
    body = "\n\n".join(parts) + "\n"

    if project_memory:
        body += "\n\n# Project context (from AGENTS.md)\n```\n" + project_memory + "\n```\n"

    return body
