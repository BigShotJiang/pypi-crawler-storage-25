"""SSL trust setup.

Delegates certificate verification to the OS trust store (macOS Keychain,
Windows Certificate Store, Linux system bundle). This means corporate
TLS-intercepting proxies "just work" as long as their root CA is installed
in the OS keychain — no env-var juggling required.

Falls back silently if truststore is unavailable. The standard env vars
(SSL_CERT_FILE / REQUESTS_CA_BUNDLE) still override if set.
"""
from __future__ import annotations


def inject() -> None:
    try:
        import truststore

        truststore.inject_into_ssl()
    except Exception:
        pass
