"""Web research pricing for permission-Panel estimates only.

Authoritative billing happens in the FredWeb proxy worker; this module
exists so the user sees a ballpark dollar figure on the y/n/a/d Panel
before approving the call. The actual debit comes back from the proxy
in the `x-fred-web-cost-microcents` header.

One credit = $0.008 upstream (Tavily PAYG anchor, May 2026) × 2.5 margin
= $0.020 = 20_000 microcents.
"""
from __future__ import annotations

import math

_PER_CREDIT_BILLED_MICROCENTS = 20_000


def estimate_search_microcents(*, search_depth: str = "basic") -> int:
    return _PER_CREDIT_BILLED_MICROCENTS * (1 if search_depth == "basic" else 2)


def estimate_extract_microcents(*, urls: int, extract_depth: str = "basic") -> int:
    batches = math.ceil(max(1, urls) / 5)
    multiplier = 1 if extract_depth == "basic" else 2
    return _PER_CREDIT_BILLED_MICROCENTS * batches * multiplier


def fmt_dollars(microcents: int) -> str:
    return f"${microcents / 1_000_000:.3f}"
