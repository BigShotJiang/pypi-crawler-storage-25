"""Path validation helpers shared by the file-touching tools.

Both the foreground bash tool and the background bash family validate a
caller-supplied ``cwd`` against the project root before passing it to
``Popen``. The check used to be duplicated character-for-character in
``bash.py`` and ``bash_bg.py``; it lives here now so a future change to
the path-traversal defense doesn't drift between the two.

Each tool keeps its own module-level ``_PROJECT_ROOT`` constant so test
monkeypatches at the tool-module level still apply. The validator takes
the root as a parameter rather than reading it from a module-global,
which keeps the abstraction narrow and lets tests rebind roots per-test
without a shared mutable.
"""
from __future__ import annotations

from pathlib import Path


def is_under_root(p: Path, root: Path) -> bool:
    """Path-traversal-safe membership check.

    Resolves ``p`` (collapsing symlinks) and tests whether the result is
    a subpath of ``root``. Returns False on any OS-level error rather
    than raising — the caller treats every reject case the same way.
    """
    try:
        p.resolve().relative_to(root)
        return True
    except (ValueError, OSError):
        return False


def validate_cwd(cwd: str | None, root: Path) -> tuple[str | None, str | None]:
    """Validate an optional ``cwd`` argument.

    Returns ``(resolved_cwd_str, error_msg)`` where exactly one is None:

    - on success with no cwd supplied: ``(None, None)``
    - on success with a valid cwd: ``(resolved_str, None)``
    - on rejection: ``(None, error_msg)``

    The error messages mirror the legacy bash/bash_bg wording so tool
    contracts don't drift; existing tests asserting on the prefix
    ``"Error: cwd outside project root"`` keep passing.
    """
    if cwd is None:
        return None, None
    try:
        cand = Path(cwd).expanduser()
    except (RuntimeError, ValueError):
        return None, f"Error: invalid cwd {cwd!r}"
    if not cand.exists() or not cand.is_dir():
        return None, f"Error: cwd does not exist or is not a directory: {cwd}"
    if not is_under_root(cand, root):
        return None, f"Error: cwd outside project root: {cwd}"
    return str(cand.resolve()), None


def resolve_search_root(path: str | None) -> tuple[Path | None, str | None]:
    """Resolve a read-only search root for grep/glob.

    Unlike ``validate_cwd``, this does NOT require the path to be under
    the project root — grep and glob are exploratory tools and the user
    owns the search-root decision. Returns ``(root, error_msg)``:

    - ``path is None``: returns ``(Path.cwd(), None)``
    - valid existing directory: returns ``(resolved, None)``
    - missing or non-directory: returns ``(None, error_msg)``
    """
    root = Path(path).expanduser() if path else Path.cwd()
    if not root.exists() or not root.is_dir():
        return None, f"Error: path does not exist or is not a directory: {root}"
    return root, None
