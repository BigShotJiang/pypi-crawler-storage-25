"""grep tool: search file contents. Uses ripgrep when available; Python re fallback."""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

from pydantic import BaseModel, Field

from fred.tools._path_utils import resolve_search_root
from fred.tools.base import Tool, truncate

MAX_MATCHES = 200


class GrepArgs(BaseModel):
    pattern: str = Field(..., description="Regex pattern to search for.")
    path: str | None = Field(None, description="Root directory. Defaults to cwd.")
    glob: str | None = Field(None, description="Optional file glob filter, e.g. '*.py'.")


def _rg(pattern: str, root: Path, glob: str | None) -> str:
    cmd = ["rg", "--no-heading", "-n", "--color", "never", "-S"]
    if glob:
        cmd += ["-g", glob]
    cmd += [pattern, str(root)]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except subprocess.TimeoutExpired:
        return "Error: ripgrep timed out after 30s"
    if proc.returncode == 1:
        return f"No matches for {pattern!r} under {root}"
    if proc.returncode not in (0, 1):
        return f"Error: ripgrep exited {proc.returncode}: {proc.stderr.strip()}"
    lines = proc.stdout.splitlines()
    if len(lines) > MAX_MATCHES:
        body = "\n".join(lines[:MAX_MATCHES])
        body += f"\n[capped at {MAX_MATCHES}; {len(lines) - MAX_MATCHES} more matches]"
    else:
        body = proc.stdout
    return truncate(body) or f"No matches for {pattern!r} under {root}"


def _py_grep(pattern: str, root: Path, glob: str | None) -> str:
    try:
        regex = re.compile(pattern)
    except re.error as e:
        return f"Error: invalid regex: {e}"
    matches: list[str] = []
    iterator = root.rglob(glob) if glob else root.rglob("*")
    for p in iterator:
        if not p.is_file():
            continue
        try:
            with p.open("r", encoding="utf-8", errors="replace") as f:
                for n, line in enumerate(f, 1):
                    if regex.search(line):
                        matches.append(f"{p}:{n}:{line.rstrip()}")
                        if len(matches) >= MAX_MATCHES:
                            matches.append(f"[capped at {MAX_MATCHES}]")
                            return truncate("\n".join(matches))
        except OSError:
            continue
    if not matches:
        return f"No matches for {pattern!r} under {root}"
    return truncate("\n".join(matches))


def run(args: GrepArgs) -> str:
    root, err = resolve_search_root(args.path)
    if err is not None:
        return err
    assert root is not None
    if shutil.which("rg"):
        return _rg(args.pattern, root, args.glob)
    return _py_grep(args.pattern, root, args.glob)


tool = Tool(
    name="grep",
    description=(
        "Search file contents with a regex. Uses ripgrep (rg) when available, "
        "falls back to Python's re. Returns `path:lineno:content` lines, capped "
        "at 200 matches. Smart-case (case-insensitive unless pattern has uppercase)."
    ),
    args_model=GrepArgs,
    handler=run,
    requires_permission=False,
)
