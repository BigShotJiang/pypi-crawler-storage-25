"""Tool base types.

Each tool has:
  - a unique `name` (matches what the model emits in tool_calls)
  - a `description` the model reads to know when to call it
  - an `args_model` (pydantic BaseModel) whose JSON schema is sent to the API
  - a `handler` callable that takes the validated args and returns a string

Convention: handlers return strings. Errors are strings starting with `Error:`
— the model reads them and recovers. Never raise out of a handler unless it's a
programmer bug.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from pydantic import BaseModel


@dataclass
class Tool:
    name: str
    description: str
    args_model: type[BaseModel]
    handler: Callable[[BaseModel], str]
    requires_permission: bool = False

    def to_openai(self) -> dict:
        schema = self.args_model.model_json_schema()
        schema.pop("title", None)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": schema,
            },
        }


def truncate(text: str, limit: int = 50_000) -> str:
    """Cap a tool result at `limit` chars with a clear marker."""
    if len(text) <= limit:
        return text
    head = text[:limit]
    return f"{head}\n\n[truncated: {len(text) - limit} more chars]"
