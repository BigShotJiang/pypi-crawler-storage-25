"""Text shaping helpers shared across tools.

Two utilities, both intentionally small and dependency-free:

- ``strip_ansi`` removes CSI/SGR/cursor-move escape sequences from captured
  shell output before it goes to the model. Pretty terminal output (colors,
  cursor positioning) means nothing to a token stream and just inflates
  context. The renderer keeps ANSI on the user's screen separately.
- ``truncate_head_tail`` caps a long string by retaining the head AND the
  tail with an explicit elision marker between them. Compiler/test failure
  output is almost always at the bottom — head-only truncation throws away
  the part the model needs most.
"""
from __future__ import annotations

import re

# CSI sequences: ESC [ <params> <final-byte>
# Covers SGR (colors, styles), cursor moves, clears, and most other
# common terminal control sequences whose final byte is a letter.
_ANSI_CSI_RE = re.compile(r"\x1b\[[0-9;?]*[a-zA-Z]")
# Bare ESC + single non-bracket finalizer (e.g. ESC = / ESC > / ESC c) — rare,
# but seen in some shells' init output. Cheap to strip.
_ANSI_SHORT_RE = re.compile(r"\x1b[=>c]")


def strip_ansi(s: str) -> str:
    """Remove ANSI escape sequences from ``s``.

    Returns ``s`` unchanged when no escapes are present.
    """
    if "\x1b" not in s:
        return s
    out = _ANSI_CSI_RE.sub("", s)
    out = _ANSI_SHORT_RE.sub("", out)
    return out


def truncate_head_tail(
    s: str,
    head: int = 25_000,
    tail: int = 25_000,
) -> str:
    """Cap ``s`` at roughly ``head + tail`` chars, keeping both ends.

    A small slack is allowed so we don't truncate a string that's only a
    few bytes over the cap. When truncation fires the marker line names
    both elided lines and elided chars so the model can reason about it.
    """
    n = len(s)
    # Slack: anything within an extra 1KB of the budget passes through.
    if n <= head + tail + 1024:
        return s
    head_chunk = s[:head]
    tail_chunk = s[-tail:]
    elided_chars = n - head - tail
    # Count newlines in the elided middle to surface "lines elided" too.
    middle = s[head : n - tail]
    elided_lines = middle.count("\n")
    marker = (
        f"\n[... {elided_lines:,} lines / {elided_chars:,} chars elided ...]\n"
    )
    return head_chunk + marker + tail_chunk
