"""todo_write tool: maintain a turn-scope task checklist.

Storage is a ``ContextVar[list[TodoItem]]`` so each :func:`run_session`
call gets its own list — sub-agents (which dispatch fresh
``run_session`` calls via ``agent_tool.run``) cannot mutate the parent's
list. Mirrors the precedent set by ``mode.py`` (``_MODE_STATE``) and
``agent_tool.py`` (``_AGENT_DISPATCH_CTX``).

Glyphs (``☐ ◐ ☑``) are shared with ``todo_inject.py`` and the
``Renderer.show_todos()`` panel so the user, the model, and slash-
command readbacks all see the same characters.
"""
from __future__ import annotations

import contextvars
from typing import Literal

from pydantic import BaseModel, Field

from fred.tools.base import Tool

Status = Literal["pending", "in_progress", "completed"]


# Shared glyph table — kept in lockstep with ``todo_inject.py`` and
# ``render.py``'s show_todos() so the panel + injection + slash readback
# all read identically. Prior versions were inconsistent (ASCII
# ``[ ] [*] [x]`` vs Unicode ``☐ ◐ ☑``); standardizing here.
GLYPH: dict[Status, str] = {
    "pending": "☐",
    "in_progress": "◐",
    "completed": "☑",
}


class TodoItem(BaseModel):
    id: str = Field(..., description="Stable identifier for the task.")
    content: str = Field(..., description="What needs to be done.")
    status: Status = Field(
        "pending", description="One of pending, in_progress, completed.",
    )


class TodoWriteArgs(BaseModel):
    todos: list[TodoItem] = Field(
        ..., description="The full updated task list. Replaces prior list.",
    )


# Per-session storage. The cli.py REPL boot and ``agent_tool.run``
# install fresh lists for the main session and each sub-agent dispatch
# respectively. ``run`` mutates the list IN PLACE (rather than
# rebinding via ``set()``) so the same list observed via
# ``get_todos()`` reflects writes — matches the ``_MODE_STATE``
# mutation pattern at ``mode.py:78-79``.
_TODOS: contextvars.ContextVar[list[TodoItem]] = contextvars.ContextVar("_TODOS")


def _state() -> list[TodoItem]:
    """Return the active list, lazily initializing if no caller installed one."""
    try:
        return _TODOS.get()
    except LookupError:
        # No outer install — fall back to a fresh module-level list so
        # tools that import `get_todos` outside a session (REPL debugging,
        # smoke scripts) don't crash.
        lst: list[TodoItem] = []
        _TODOS.set(lst)
        return lst


def install_todo_list() -> contextvars.Token:
    """Install a fresh empty todo list for the current context.

    Caller stores the returned token and passes it to
    :func:`reset_todo_list` to undo. Used by the cli.py REPL at boot,
    by ``agent_tool.run`` per sub-agent dispatch, and by tests that
    want isolation per case.
    """
    return _TODOS.set([])


def reset_todo_list(token: contextvars.Token) -> None:
    _TODOS.reset(token)


def get_todos() -> list[TodoItem]:
    """Return a snapshot copy so callers can't accidentally mutate the
    backing list. Snapshots are cheap (one list comprehension)."""
    return list(_state())


def _set_for_test(todos: list[TodoItem]) -> None:
    """Test-only: replace the current todo list IN PLACE.

    Production code paths must use ``run()`` (the tool handler) or
    ``install_todo_list()`` to seed an empty list at session boot.
    Tests use this helper to skip the full dispatch path when the
    pre-state is what's under test, not the write itself.
    """
    state = _state()
    state[:] = list(todos)


def run(args: TodoWriteArgs) -> str:
    state = _state()
    state[:] = list(args.todos)
    if not state:
        return "Todo list cleared."
    lines = ["Todo list updated:"]
    for t in state:
        lines.append(f"  {GLYPH[t.status]} {t.content}")
    return "\n".join(lines)


tool = Tool(
    name="todo_write",
    description=(
        "Replace the session task checklist with the given list. Call this at "
        "the start of any task with more than 1 distinct step, and update it "
        "as you go (mark `in_progress` before starting, `completed` when done). "
        "Trivial single-action requests (one view, one bash for a quick query) "
        "skip todos. Each item has id, content, and status "
        "(pending/in_progress/completed). Pass the FULL updated list each "
        "time — partial updates are not supported."
    ),
    args_model=TodoWriteArgs,
    handler=run,
    requires_permission=False,
)
