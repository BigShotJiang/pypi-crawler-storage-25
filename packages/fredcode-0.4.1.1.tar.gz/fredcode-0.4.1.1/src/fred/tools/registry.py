"""Tool registry: collects tools, builds the OpenAI tools array, dispatches calls."""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Callable

from pydantic import ValidationError

from fred.client import ToolCall
from fred.mode import PLAN_TOOLS, current_mode, mode_blocked_message
from fred.telemetry.redact import canonical_json
from fred.tools._session_files import consume_tool_outcome
from fred.tools.base import Tool
from fred.turn_state import CallStatus

if TYPE_CHECKING:
    from fred.permissions import PermissionPolicy


@dataclass(frozen=True)
class PreHookDecision:
    """The verdict returned from a pre-handler hook.

    Either ``block_message`` (short-circuit with a wire-visible error) or
    ``updated_args`` (mutate the args before the handler runs); not both.
    Returning a ``PreHookDecision`` with both fields ``None`` is a no-op
    equivalent to returning ``None``.
    """

    block_message: str | None = None
    updated_args: dict | None = None
    # Override the meta["outcome"] when blocking. Defaults to
    # "hook_blocked" — the new vocabulary added by P2.4.
    outcome: str | None = None
    # When blocking, also override meta["permission_outcome"] so analysts
    # can attribute the denial to the hook layer rather than the user
    # gate that ran first.
    permission_outcome_override: str | None = None


class Registry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}
        # Cached, byte-stable openai-tools array. Computed once on first call
        # to openai_tools(); invalidated on register(). Round-tripping through
        # canonical_json normalizes pydantic's per-process key ordering so the
        # serialized prompt prefix is stable across Python upgrades and runs.
        self._openai_tools_cache: list[dict] | None = None

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool {tool.name!r} already registered")
        self._tools[tool.name] = tool
        self._openai_tools_cache = None

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def names(self) -> list[str]:
        return sorted(self._tools)

    def subset(self, tool_names: set[str]) -> "Registry":
        """Return a NEW Registry containing only the named tools.

        Order matches the parent's `names()` (sorted). Raises
        `ValueError` if any name in `tool_names` is not registered
        here — the error names the offending tool(s) for forward-compat
        with subagent profile validation (P2.1).

        The new Registry shares Tool objects by reference; tools are
        immutable in practice (their `handler` closures are not mutated).
        """
        missing = sorted(n for n in tool_names if n not in self._tools)
        if missing:
            raise ValueError(
                f"subset: tool(s) not in parent registry: {', '.join(missing)}"
            )
        sub = Registry()
        # Walk the parent's names() so iteration order matches the
        # parent's public ordering. Insertion is via the same `register`
        # mechanism would re-validate, but Tool objects are already
        # validated; assign directly.
        for name in self.names():
            if name in tool_names:
                sub._tools[name] = self._tools[name]
        return sub

    def openai_tools(self) -> list[dict]:
        if self._openai_tools_cache is None:
            # Iterate in names() order (alphabetical) so the array order is
            # deterministic regardless of registration order. Then round-trip
            # each tool dict through canonical_json -> json.loads to normalize
            # all nested dict key orderings to sorted-keys form.
            arr = [self._tools[n].to_openai() for n in self.names()]
            self._openai_tools_cache = [json.loads(canonical_json(t)) for t in arr]
        return self._openai_tools_cache

    def dispatch(
        self,
        call: ToolCall,
        permissions: "PermissionPolicy | None" = None,
        *,
        status_cb: Callable[[CallStatus], None] | None = None,
        pre_handler_hook: Callable[[str, dict], "PreHookDecision | None"] | None = None,
    ) -> tuple[str, dict]:
        """Run a tool call. Returns (result_string, meta).

        meta keys: outcome, permission_outcome, permission_prompt_ms,
        handler_exception_type, duration_ms, started_at, ended_at.

        Optional `status_cb` is invoked at lifecycle transitions
        (PERMISSION → RUNNING / DENIED) so the renderer can update its
        in-frame glyph for this call. Errors prior to permission/run
        (parse_error, unknown_tool, validation_error) skip the callback;
        the renderer surfaces those via tool_done with DONE_ERROR.

        ``pre_handler_hook`` runs AFTER the permission gate and BEFORE
        the tool's handler. It receives the validated tool name and the
        args dict (the same shape passed to the permission Panel). It
        may return:

          - ``None`` to allow the call as-is.
          - ``PreHookDecision(block_message=..., outcome=...)`` to short-
            circuit; the dispatch returns ``(block_message, _meta(outcome))``
            instead of running the handler. P2.4 uses this for hook-blocked
            tools: the message is the user-readable reason, the outcome is
            ``"hook_blocked"``.
          - ``PreHookDecision(updated_args=...)`` to mutate the args the
            handler sees. The new dict is re-validated against the tool's
            pydantic model before dispatch; a validation failure surfaces
            as ``validation_error`` (the original args are NOT used as a
            fallback — the hook said it wanted these and it's a config bug
            if they don't validate).
        """
        started_at = datetime.now(timezone.utc)
        t0 = time.perf_counter_ns()
        permission_outcome: str | None = None
        permission_prompt_ms: int | None = None
        # P3.1: when the rule engine produced ``rule_allow`` / ``rule_deny``,
        # surface the matching pattern string so callers can attach it to
        # the ``permission_rule_match`` telemetry event. ``None`` for
        # every non-rule path (yolo, always_allow, user_y/n/a, etc).
        matched_rule: str | None = None

        def _meta(outcome: str, *, handler_exc: str | None = None) -> dict:
            return {
                "outcome": outcome,
                "permission_outcome": permission_outcome,
                "permission_prompt_ms": permission_prompt_ms,
                "matched_rule": matched_rule,
                "handler_exception_type": handler_exc,
                "duration_ms": (time.perf_counter_ns() - t0) // 1_000_000,
                "started_at": started_at,
                "ended_at": datetime.now(timezone.utc),
            }

        if call.parse_error:
            return f"Error: {call.parse_error}", _meta("parse_error")

        tool = self._tools.get(call.name)
        if tool is None:
            msg = f"Error: unknown tool {call.name!r}. Available: {', '.join(self.names())}"
            return msg, _meta("unknown_tool")

        try:
            args = tool.args_model.model_validate(call.arguments)
        except ValidationError as e:
            return f"Error: invalid arguments for {call.name}: {e}", _meta("validation_error")

        # P2.2 plan mode: in plan mode, block any tool not on the plan
        # allowlist. The block fires AFTER args validation so the model
        # gets feedback specific to the tool, not a parse error. The
        # `mode_blocked` outcome is a structured value the renderer
        # surfaces with a dim ◊ glyph. `exit_plan_mode` is always on
        # the allowlist so plan mode can exit itself.
        if current_mode() == "plan" and call.name not in PLAN_TOOLS:
            if status_cb is not None:
                status_cb(CallStatus.MODE_BLOCKED)
            return mode_blocked_message(call.name), _meta("mode_blocked")

        if tool.requires_permission and permissions is not None:
            if status_cb is not None:
                status_cb(CallStatus.PERMISSION)
            allowed = permissions.check(tool, call.arguments)
            permission_outcome = permissions.last_outcome
            permission_prompt_ms = permissions.last_prompt_ms
            # ``last_matched_rule`` exists on PermissionPolicy from P3.1;
            # the ``getattr`` keeps test stubs that re-implement the
            # policy interface without the new attribute working.
            matched_rule = getattr(permissions, "last_matched_rule", None)
            if not allowed:
                if status_cb is not None:
                    status_cb(CallStatus.DENIED)
                # When a deny-rule fires, the user-facing wire message
                # names the rule so the model can self-correct (e.g.
                # "denied by rule Bash(rm -rf *)" ⇒ stop trying that
                # exact command). Plain user-n keeps the original
                # phrasing for backwards compat with existing tests.
                if permission_outcome == "rule_deny" and matched_rule:
                    msg = (
                        f"Error: denied by permission rule "
                        f"{matched_rule!r} for {call.name}"
                    )
                else:
                    msg = f"Error: user denied permission for {call.name}"
                return msg, _meta("denied")
        else:
            permission_outcome = "not_required"

        # PreToolUse hook (P2.4). Runs against the args the model emitted
        # (call.arguments), AFTER the permission grant. The hook may
        # block the tool or mutate the args before the handler sees them.
        if pre_handler_hook is not None:
            decision = pre_handler_hook(call.name, dict(call.arguments))
            if decision is not None:
                if decision.block_message is not None:
                    if status_cb is not None:
                        status_cb(CallStatus.DENIED)
                    if decision.permission_outcome_override is not None:
                        permission_outcome = decision.permission_outcome_override
                    return decision.block_message, _meta(
                        decision.outcome or "hook_blocked",
                    )
                if decision.updated_args is not None:
                    try:
                        args = tool.args_model.model_validate(decision.updated_args)
                    except ValidationError as e:
                        return (
                            f"Error: invalid arguments for {call.name} after "
                            f"PreToolUse hook: {e}",
                            _meta("validation_error"),
                        )

        if status_cb is not None:
            status_cb(CallStatus.RUNNING)

        try:
            output = tool.handler(args)
        except Exception as e:
            return (
                f"Error: {call.name} raised {type(e).__name__}: {e}",
                _meta("handler_error", handler_exc=type(e).__name__),
            )
        # Tools may surface a finer-grained outcome than the default
        # `"ok"` via the `_session_files` ContextVar — used by
        # `str_replace` for `prior_read_required`, `not_found`,
        # `not_found_with_candidate`, `not_unique` (P1.4). The override
        # is consumed (read + cleared) so it can't leak across calls.
        override = consume_tool_outcome()
        return output, _meta(override or "ok")


def default_registry() -> Registry:
    """Build the default registry with all v0 tools."""
    from fred.tools import (
        agent_tool,
        ask_followup,
        attempt_completion,
        bash,
        bash_bg,
        view,
        create_file,
        str_replace,
        glob_tool,
        grep_tool,
        todo,
        exit_plan_mode,
        request_rule,
        web_search,
        web_fetch,
    )

    reg = Registry()
    reg.register(bash.tool)
    reg.register(view.tool)
    reg.register(create_file.tool)
    reg.register(str_replace.tool)
    reg.register(glob_tool.tool)
    reg.register(grep_tool.tool)
    reg.register(todo.tool)
    # P2.1: register the subagent dispatch tool only on the main
    # registry. AGENT_PROFILES never includes `agent`, so a subagent's
    # constrained registry literally cannot dispatch another agent call —
    # the recursion guard is enforced at the registry layer.
    reg.register(agent_tool.tool)
    # P2.2: register the plan-mode exit tool. Always available; the mode
    # gate in dispatch lets it through regardless of current mode.
    reg.register(exit_plan_mode.tool)
    # PR-B2: explicit turn terminator. The session loop short-circuits on
    # this tool name post-dispatch; the handler itself just validates and
    # echoes the result. NOT allowed in plan mode — the mode gate at
    # registry.dispatch rejects it because attempt_completion is absent
    # from PLAN_TOOLS, which surfaces a self-correcting error string.
    reg.register(attempt_completion.tool)
    # PR-C1: bounded clarification. Allowed in both modes (no filesystem
    # effects) but excluded from sub-agent profiles via _PARENT_ONLY_TOOLS
    # — sub-agents have no user surface. The handler reads an
    # AskFollowupContext ContextVar set by session._run_loop before the
    # per-iteration dispatch loop.
    reg.register(ask_followup.tool)
    # P3.4: background bash family. `bash_bg` spawns a detached process
    # and returns a handle; `bash_read` polls for new output (delta
    # semantics); `bash_kill` terminates the tree. Permission is required
    # for spawn + kill (matches foreground bash); read is permission-free
    # since it only surfaces already-captured output to the model.
    reg.register(bash_bg.tool_bash_bg)
    reg.register(bash_bg.tool_bash_read)
    reg.register(bash_bg.tool_bash_kill)
    # P3.2: register the rule-activation tool. The handler reads a
    # session-scoped ContextVar set by run_session; if no rule context
    # is wired (e.g. headless tests), it returns a structured Error.
    reg.register(request_rule.tool)
    # 0.3.0: web research tools. Both call the FredWeb proxy at
    # /v1/web/{search,extract}; billing happens server-side. Both are
    # permission-gated so the user sees the cost estimate before approving.
    reg.register(web_search.tool)
    reg.register(web_fetch.tool)
    return reg
