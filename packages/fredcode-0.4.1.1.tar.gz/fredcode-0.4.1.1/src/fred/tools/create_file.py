"""create_file tool: write a NEW file. Refuses to overwrite."""
from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, Field

from fred.tools._session_files import mark_tracked
from fred.tools.base import Tool


class CreateFileArgs(BaseModel):
    path: str = Field(..., description="Path of the new file. Refuses to overwrite if it exists.")
    content: str = Field("", description="Initial file content. Empty string creates an empty file.")


def run(args: CreateFileArgs) -> str:
    p = Path(args.path).expanduser()
    if p.exists():
        return f"Error: {p} already exists. Use str_replace to edit, or delete it first via bash."
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(args.content, encoding="utf-8")
    except OSError as e:
        return f"Error: cannot create {p}: {e}"
    # The fresh-create-then-edit exception (P1.4): a successful
    # create_file counts as a "view" for prior-Read enforcement so the
    # model can immediately follow up with `str_replace` without first
    # re-reading content it just wrote.
    mark_tracked(p)
    return f"Created {p} ({len(args.content)} chars)."


tool = Tool(
    name="create_file",
    description=(
        "Create a NEW file with the given content. Refuses to overwrite — to edit "
        "an existing file, use str_replace instead. Creates parent directories as needed."
    ),
    args_model=CreateFileArgs,
    handler=run,
    requires_permission=True,
)
