"""attempt_completion tool — explicit turn terminator.

Model-callable: when the agent has finished the user's task it calls
``attempt_completion`` with a final ``result`` string. The session loop
detects this tool by name post-dispatch and breaks the iteration,
rendering a green completion panel and emitting a
``terminator_kind="attempt_completion"`` telemetry signal.

Compared with Cline's tool of the same name, Fred's variant drops the
optional ``command`` parameter — running shell after a "completion"
signal would bypass Fred's permission engine on bash, a security
regression. Fred also doesn't carry Cline's ``task_progress`` parameter
because the dedicated ``todo_write`` tool is the single source of truth
for in-flight progress.

The tool's handler returns the validated result verbatim; the dispatch
loop in ``session._run_loop`` is what consumes that string. The handler
also rejects whitespace-only inputs at runtime (Pydantic's ``min_length``
catches the empty string but not ``"   "``).
"""
from __future__ import annotations

from pydantic import BaseModel, Field

from fred.tools.base import Tool


class AttemptCompletionArgs(BaseModel):
    result: str = Field(
        ...,
        min_length=1,
        max_length=8000,
        description=(
            "Your final answer. A concrete, terse summary of what was done "
            "and the user-visible outcome. Do NOT end with a question or an "
            "offer for further work — this terminates the turn."
        ),
    )


def run(args: AttemptCompletionArgs) -> str:
    if not args.result.strip():
        return "Error: attempt_completion requires a non-empty result."
    return args.result


tool = Tool(
    name="attempt_completion",
    description=(
        "End the current turn with a final result. Call this when the user's "
        "task is complete and no further tool calls are needed. The result "
        "string is the user-visible summary — concrete, terse, no trailing "
        "question or offer for more work. Subsequent tool calls in the same "
        "iteration run first, but the turn ends as soon as attempt_completion "
        "succeeds. Not allowed in plan mode (use exit_plan_mode there)."
    ),
    args_model=AttemptCompletionArgs,
    handler=run,
    requires_permission=False,
)
