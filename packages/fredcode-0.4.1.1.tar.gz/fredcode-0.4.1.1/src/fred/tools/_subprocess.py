"""Subprocess utilities shared by the bash family.

Both the foreground bash tool and the background bash family need to:

- Kill a process group while swallowing the harmless errors
  (``ProcessLookupError`` and plain ``OSError``) that fire when the OS
  reaper has already collected the child.
- Escalate SIGTERM → grace window → SIGKILL when a process refuses to
  exit, returning both the final exit code and the last signal sent so
  callers can record it in telemetry.

The escalation flow used to live in ``bash.py``'s timeout path AND
``bash_bg.py``'s ``_terminate``; both copies were ~15 lines and
identical except for bookkeeping. The drain-thread bodies stay in their
respective modules — they have materially different sink semantics
(``list[str]`` + per-line callback vs. bounded deque with eviction) and
unifying them would obscure rather than clarify.
"""
from __future__ import annotations

import os
import signal
import subprocess


def safe_killpg(pgid: int, sig: int) -> None:
    """Signal a process group, swallowing already-gone / lookup errors.

    Both the timeout-escalation path and the user-initiated kill path
    can race with the OS reaping the child; ``ProcessLookupError`` and
    plain ``OSError`` (EPERM, ESRCH on Linux) are non-actionable here.
    """
    try:
        os.killpg(pgid, sig)
    except ProcessLookupError:
        pass
    except OSError:
        pass


def terminate_with_escalation(
    popen: subprocess.Popen,
    *,
    sigterm_timeout: float = 2.0,
    sigkill_timeout: float = 1.0,
) -> tuple[int | None, int | None]:
    """SIGTERM the process group; if it doesn't exit in time, SIGKILL.

    Returns ``(exit_code, last_signal_sent)``:

    - ``exit_code`` is ``popen.poll()`` after the escalation completes
      — None if the child is somehow still wedged after both signals.
    - ``last_signal_sent`` is the last signal we issued (``SIGTERM`` or
      ``SIGKILL``), or ``None`` if the process had already exited and
      no signal was needed.

    The PID lookup is best-effort: ``os.getpgid`` raises
    ``ProcessLookupError`` for an already-reaped child, in which case
    we fall through cleanly because there's nothing left to kill. We
    deliberately don't pre-check ``popen.poll()`` — the OS-level error
    handling is already correct, and skipping the poll keeps this
    helper bit-compatible with the legacy ``bash._kill_pg``-shaped
    flow that callers' tests exercise.
    """
    try:
        pgid = os.getpgid(popen.pid)
    except ProcessLookupError:
        pgid = None

    last_signal: int | None = None
    if pgid is not None:
        safe_killpg(pgid, signal.SIGTERM)
        last_signal = int(signal.SIGTERM)

    try:
        popen.wait(timeout=sigterm_timeout)
    except subprocess.TimeoutExpired:
        if pgid is not None:
            safe_killpg(pgid, signal.SIGKILL)
            last_signal = int(signal.SIGKILL)
        try:
            popen.wait(timeout=sigkill_timeout)
        except subprocess.TimeoutExpired:
            pass

    # ``returncode`` is set as a side-effect of ``wait``. Reading the
    # attribute (instead of calling ``poll()``) keeps this helper
    # compatible with test fakes that only mock ``wait``.
    return popen.returncode, last_signal
